from ._init import _init_fn


__version__ = "0.6.0"


def init():
    _init_fn()
