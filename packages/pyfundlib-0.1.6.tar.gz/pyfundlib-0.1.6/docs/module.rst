pyfundlib
=========

.. automodule:: pyfundlib
   :members:

.. toctree::
   :maxdepth: 2

   pyfundlib.backtester
   pyfundlib.ml
   pyfundlib.data
   pyfundlib.strategies
   pyfundlib.execution
   pyfundlib.automation
   pyfundlib.utils