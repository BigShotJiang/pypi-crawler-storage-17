from .vecm import Cointegration

__all__ = ["Cointegration"]
