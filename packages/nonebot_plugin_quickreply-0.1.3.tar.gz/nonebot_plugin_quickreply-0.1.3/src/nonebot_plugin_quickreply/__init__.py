from nonebot.plugin import PluginMetadata, get_plugin_config
from . import plugins
from src.nonebot_plugin_quickreply.plugins.config import Config
__plugin_meta__ = PluginMetadata(
    name="快捷回复",
    description="一个功能强大的快捷回复插件，支持分群/私聊、配置化限制最大快捷回复数量。",
    usage=(
        "上下文相关指令 (仅在当前群聊/私聊生效):\n"
        "  /设置回复 <关键词> <内容>\n"
        "  /删除回复 <关键词>\n"
        "  /回复列表\n"
        "  /管理删除 <关键词> (群管/超管)\n"
        "\n全局指令 (影响您所有的回复):\n"
        "  /清空我的回复\n"
        "  /清空用户回复 <@用户或QQ> (超管)"
    ),
    type="application",
    homepage="https://github.com/FlanChanXwO/nonebot-plugin-quickreply",
    config=Config,
    supported_adapters={"~onebot.v11"},
    extra={"author": "FlanChanXwO", "version": "0.1.0"},
)

plugin_config = get_plugin_config(Config)
