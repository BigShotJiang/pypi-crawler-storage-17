from osbot_utils.type_safe.Type_Safe import Type_Safe


class MGraph__Export__Dot__Config__Render(Type_Safe):
    print_dot_code     : bool = False
    label_show_var_name: bool = False