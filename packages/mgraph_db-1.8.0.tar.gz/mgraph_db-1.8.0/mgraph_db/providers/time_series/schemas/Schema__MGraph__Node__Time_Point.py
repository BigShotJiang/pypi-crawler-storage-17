from mgraph_db.mgraph.schemas.Schema__MGraph__Node__Value import Schema__MGraph__Node__Value

class Schema__MGraph__Node__Time_Point(Schema__MGraph__Node__Value):                                        # Root node for time points
    pass