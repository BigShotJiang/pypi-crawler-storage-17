from mgraph_db.providers.json.schemas.Schema__MGraph__Json__Node                 import Schema__MGraph__Json__Node
from mgraph_db.providers.json.schemas.Schema__MGraph__Json__Node__Property__Data import Schema__MGraph__Json__Node__Property__Data


class Schema__MGraph__Json__Node__Property(Schema__MGraph__Json__Node):             # For object property names
    node_data : Schema__MGraph__Json__Node__Property__Data
