from mgraph_db.providers.mermaid.schemas.Schema__Mermaid__Edge         import Schema__Mermaid__Edge
from mgraph_db.mgraph.models.Model__MGraph__Edge                       import Model__MGraph__Edge


class Model__Mermaid__Edge(Model__MGraph__Edge):
    data  : Schema__Mermaid__Edge