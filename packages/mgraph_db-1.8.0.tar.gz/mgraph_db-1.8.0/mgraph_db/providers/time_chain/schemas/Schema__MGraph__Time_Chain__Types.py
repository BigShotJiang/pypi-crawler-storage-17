class Time_Chain__Year   (str): pass      # year value in the time chain
class Time_Chain__Month  (str): pass      # month value in the context of a year
class Time_Chain__Day    (str): pass      # day value in the context of a year and month
class Time_Chain__Hour   (str): pass      # hour value in the context of a full date
class Time_Chain__Minute (str): pass      # minute value in the context of date and hour
class Time_Chain__Second (str): pass      # second value in the full datetime context
class Time_Chain__Source (str): pass      # source Obj_id