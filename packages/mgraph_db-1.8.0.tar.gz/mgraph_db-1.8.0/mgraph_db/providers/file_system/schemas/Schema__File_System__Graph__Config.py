from mgraph_db.mgraph.schemas.Schema__MGraph__Graph__Data import Schema__MGraph__Graph__Data

class Schema__File_System__Graph__Config(Schema__MGraph__Graph__Data):
    allow_circular_refs: bool = False
