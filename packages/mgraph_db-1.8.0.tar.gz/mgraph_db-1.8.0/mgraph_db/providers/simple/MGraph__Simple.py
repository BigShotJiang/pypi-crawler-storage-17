from mgraph_db.mgraph.MGraph                                 import MGraph
from mgraph_db.providers.simple.domain.Domain__Simple__Graph import Domain__Simple__Graph

class MGraph__Simple(MGraph):
    graph: Domain__Simple__Graph