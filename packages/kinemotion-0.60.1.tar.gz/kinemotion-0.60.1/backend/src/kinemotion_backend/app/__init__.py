"""Application module for kinemotion backend."""

from .main import app

__all__ = ["app"]
