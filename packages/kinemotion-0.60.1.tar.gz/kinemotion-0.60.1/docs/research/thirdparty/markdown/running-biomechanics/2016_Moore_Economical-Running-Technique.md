# Is There an Economical Running Technique? A Review of Modifiable Biomechanical Factors Affecting Running Economy

Isabel S. Moore \[1\]

Published online: 27 January 2016
� The Author(s) 2016. This article is published with open access at Springerlink.com

Abstract Running economy (RE) has a strong relationship with running performance, and modifiable running
biomechanics are a determining factor of RE. The purposes
of this review were to (1) examine the intrinsic and
extrinsic modifiable biomechanical factors affecting RE;
(2) assess training-induced changes in RE and running
biomechanics; (3) evaluate whether an economical running
technique can be recommended and; (4) discuss potential
areas for future research. Based on current evidence, the
intrinsic factors that appeared beneficial for RE were using
a preferred stride length range, which allows for stride
length deviations up to 3 % shorter than preferred stride
length; lower vertical oscillation; greater leg stiffness; low
lower limb moment of inertia; less leg extension at toe-off;
larger stride angles; alignment of the ground reaction force
and leg axis during propulsion; maintaining arm swing;
low thigh antagonist–agonist muscular coactivation; and
low activation of lower limb muscles during propulsion.
Extrinsic factors associated with a better RE were a firm,
compliant shoe–surface interaction and being barefoot or
wearing lightweight shoes. Several other modifiable
biomechanical factors presented inconsistent relationships
with RE. Running biomechanics during ground contact
appeared to play an important role, specifically those during propulsion. Therefore, this phase has the strongest
direct links with RE. Recurring methodological problems
exist within the literature, such as cross-comparisons,
assessing variables in isolation, and acute to short-term
interventions. Therefore, recommending a general

& Isabel S. Moore

<imoore@cardiffmet.ac.uk>

1 Cardiff School of Sport, Cardiff Metropolitan University,
Cardiff CF23 6XD, Wales, UK

economical running technique should be approached with
caution. Future work should focus on interdisciplinary
longitudinal investigations combining RE, kinematics,
kinetics, and neuromuscular and anatomical aspects, as
well as applying a synergistic approach to understanding

the role of kinetics.

Key Points

Running biomechanics during ground contact,
particularly those related to propulsion, such as less
leg extension at toe-off, larger stride angles,
alignment of the ground reaction force and leg axis,
and low activation of the lower limb muscles, appear
to have the strongest direct links with running

economy.

Inconsistent findings and limited understanding still
exist for several spatiotemporal, kinematic, kinetic,
and neuromuscular factors and how they relate to
running economy.

1 Introduction

For competitive runners, decreasing the time needed to
complete a race distance is crucial. Consequently, there is a
need to understand the determinants of running performance. Several physiological determinants have been
identified, which include a high maximal oxygen uptake
(V \[\_\] O2max) \[1, 2\], lactate threshold \[3, 4\], and running
economy (RE) \[5, 6\].

## 123

794 I. S. Moore

In a heterogeneous group of runners, V \[_\] O2max is strongly
related to running performance \[7\]. However, in a group of
runners with a similar V \[_\] O2max, V \[_\] O2max cannot be used to
discern between those who out-perform others \[6\]. A
measure that can distinguish between good and poor running performers is the rate of oxygen consumed at a given
submaximal running velocity, termed RE \[5, 8, 9\], with
lower oxygen consumption (V \[_\] O2) indicating better RE
during steady-state running. For a group of runners with a
similar V \[_\] O2max, RE can differ by as much as 30 % and is a
better predictor of running performance than V \[_\] O2max \[6, 8,
10\]. Several researchers have reported strong associations
between RE and running performance \[5, 7, 11, 12\].
Additionally, RE differs substantially between elite, trained
(recreational), and untrained runners and also between
males and females \[13–17\]. Saunders et al. \[18\] proposed
the following determinants of RE: training, environment,
physiology, anthropometry, and running biomechanics.
Studies utilizing interventions show RE can be
improved \[19\], meaning it is a ‘trainable’ parameter \[20\].
Improvements in RE have ranged from 2 to 8 % using
various short-term training modes, such as plyometric \[21–
23\], strength and resistance \[24–27\], whole-body vibration

\[28\], interval \[29–31\], altitude \[32, 33\], and endurance
running \[34, 35\]. In comparison, long-term physiological
training can improve RE by 15 % \[12\]. Jones \[12\] reported
that such an improvement over 9 years was probably a

crucial factor in the elite marathon runner’s continued

improvement in running performance. For intervention
studies concerned with improving RE, the initial fitness
level of participants is particularly important \[18\], with a
high initial fitness level perhaps explaining why not all
interventions have successfully improved RE \[36–39\].
Nevertheless, the trainability of RE suggests certain factors
affecting RE can be modified. One such factor that can
influence RE is an individual’s running biomechanics.
Understanding what constitutes an economical running
technique has been the focus of much research. Specific
factors include spatiotemporal factors \[40, 41\], lower limb
kinematics \[34, 42\], kinetics \[9, 43, 44\], neuromuscular
factors \[45–48\], the shoe–surface interaction \[49–54\], and
trunk and upper limb biomechanics \[55–57\]. Synthesizing
the literature within this field of research has received
limited attention, with some still drawing upon descriptors
provided up to 20 years ago \[18, 58\]. Much research has
been conducted since, in an attempt to answer the question:
is there an economical running technique? Therefore, the
purposes of this review are to (1) examine the intrinsic and
extrinsic modifiable biomechanical factors affecting RE;
(2) assess training-induced changes in RE and running
biomechanics; (3) evaluate whether an economical running

## 123

technique can be recommended; and (4) discuss potential

areas for future research directions.

2 Modifiable Biomechanical Factors Affecting
Running Economy

Several modifiable biomechanical factors may affect RE.
Each factor can be considered either intrinsic (internal) or
extrinsic (external). Intrinsic factors refer to an individual’s
running biomechanics. These factors can be further categorised as spatiotemporal (parameters relating to changes
in and/or phases of the gait cycle, such as ground contact
time and stride length); kinematics (the movement patterns,
such as lower limb joint angles); kinetics (the forces that
cause motion, such as ground reaction force \[GRF\]); and
neuromuscular (the nerves and muscles, such as the activation and coactivation of muscles). The extrinsic factors

covered in this review relate to the shoe–surface interaction

and focus on footwear, orthotics, and running surface.

Evidence for how each factor affects RE is reviewed and

discussed.

3 Spatiotemporal Factors

Stride frequency and stride length are mutually dependent
and define running speed. If running speed is kept constant,
increasing either stride frequency or stride length will
result in a decrease of the other. Runners appear to naturally choose a stride frequency or stride length that is
economically optimal, or at least very near to being economically optimal. This innate, subconscious fine-tuning of
running biomechanics is referred to as self-optimization

\[34, 42\]. Studies supporting this self-optimizing theory
generally use acute manipulations of stride frequency or
stride length and mathematical curve-fitting procedures to
derive the most economical stride frequency and length

\[40, 59–61\].
Interestingly, a trained runner’s mathematical optimal
stride frequency or stride length is, on average, 3 % faster
or 3 % shorter than their preferred frequency or length \[40,
59, 61\]. Acute and short-term manipulations whereby stride
length has been shortened by 3 % show RE to be unaffected \[50, 62\], whereas stride length deviations greater
than 6 % are detrimental to RE \[59\]. Collectively, these
results suggest there is an optimal stride length ‘range’ that
trained runners can acutely adopt without compromising
their RE. This range appears to be the preferred stride
length minus 3 % to the preferred stride length. Importantly, even in a fatigued state, trained runners reduce their
stride frequency compared with a non-fatigued state and

Modifiable Biomechanical Factors Affecting Running Economy 795

produce a preferred stride frequency that is similar to their
optimal stride frequency achieved in a fatigued state \[60\].
These results imply that trained runners can dynamically
self-optimize their running biomechanics in response to
their physiological state. For novice runners, the difference
between preferred and mathematically optimal stride frequencies is greater than for trained runners (8 vs. 3 %) \[59\]
(Fig. 1). Therefore, generalizing the principle of an optimal
stride length range to all runners should be done with
caution, as self-optimization appears to be a physiological
adaptation resulting from greater running experience.
Similar to stride frequency and stride length, vertical

oscillation can be altered. Acute interventions have shown
that increasing vertical oscillation leads to increases in V \[\_\] O2

\[41, 63\]. Additionally, vertical oscillation increases when
running to exhaustion. However, vertical oscillation changes are minimal and increases in V \[_\] O2 are large \[64, 65\],
meaning several other physiological and biomechanical
factors contribute to increases in V \[_\] O2 during fatigue \[66,
67\]. Furthermore, decreases in vertical oscillation have

been shown when individuals run barefoot and their RE

improves \[50\], probably due to a smaller vertical displacement during stance \[52\]. Yet, it must be noted that
shoe mass and other biomechanical changes associated

Fig. 1 Individual differences (selected-optimal) in stride frequency
(a) and running cost (b) for novice (left) and trained runners (right) on
day 1 (black bars) and day 2 (grey bars). 2 test days were used to
assess the reliability of measures and were separated by at least 48 h.
RCopt running cost of optimal stride frequency, RCsel running cost of
self-selected stride frequency, SFopt optimal stride frequency based
on minimal running cost, SFsel self-selected stride frequency.
X denotes that optimal stride frequency and, consequently, optimal
running cost could not be established in these five trials. Reproduced
from de Ruiter et al. \[59\] by permission of Taylor & Francis Ltd,
[http://www.tandfonline.com](http://www.tandfonline.com)

with barefoot running also influence such RE improvements (see Sect. 3.4). Another study has shown that
decreasing vertical oscillation can slightly improve RE, but
only if the absolute height of the body’s center of mass
(CoM) is not changed \[68\]. Collectively, these results
imply that reducing the magnitude of vertical displacement
should be encouraged. It is possible that reducing vertical
displacement improves RE by reducing the metabolic cost
associated with supporting body weight, as a smaller vertical impulse would be produced \[69\]. Additionally, it
could make a runner more mechanically efficient, as a low
displacement of the body’s CoM produces a low mechanical energy cost, since the body is performing less work
against gravity \[70\].
Notwithstanding these encouraging results, findings

show that female runners have a lower vertical oscillation

than their male counterparts, but findings are conflicting
regarding whether females are more or less economical
than males \[13, 16, 71\]. Eriksson et al. \[72\] demonstrated
that vertical oscillation could be successfully lowered using
visual and auditory feedback, and that runners found it
more natural to change vertical oscillation than step frequency. However, to date, only one study has assessed the
effect of specifically decreasing a runner’s vertical oscillation. This means research has not tried to manipulate
vertical oscillation, in a similar manner to stride frequency
and stride length, to determine whether runners have an
optimal magnitude of vertical oscillation or whether runners would simply benefit from lowering their vertical
oscillation to improve RE.
The time the foot spends in contact with the ground has
equivocal results regarding its association with RE. Several
studies have failed to find any relationship between ground
contact time and RE \[9, 42, 73, 74\], whilst some have
observed a better RE to be associated with longer contact
times \[75, 76\] and others have found the opposite to be true

\[11, 77\]. It is suggested that short ground-contact times
incur a high metabolic cost because faster force production
is required, meaning metabolically expensive fast twitch
muscle fibers are recruited \[78, 79\]. Conversely, long
ground-contact times may incur a high metabolic cost
because force is produced slowly, meaning longer braking
phases when runners undergo deceleration \[77\]. Whilst
both arguments appear plausible, it has been argued that
being able to reduce the amount of speed lost during
ground contact is the most important aspect rather than the
time in contact with it \[77, 80–82\]. Combining this with
evidence that individuals can produce shorter groundcontact times, but similar deceleration times and RE when
forefoot striking compared with rearfoot striking \[83\],
suggests that the time spent decelerating may influence RE.
Another factor that may affect the body’s deceleration is
how far ahead of the body the foot strikes the ground.

## 123

796 I. S. Moore

Evidence from step rate manipulation investigations and
global gait re-training studies instructing runners to adopt a
Pose running method, suggest that significantly decreasing
the horizontal distance between the body’s CoM and foot at
initial ground contact reduces peak braking and propulsive
forces \[84, 85\] and braking impulses (less speed lost)
applied by the runner \[86, 87\]. Yet, both performance and
RE were unaffected during the gait re-training \[85\],
potentially because too many running biomechanics were
modified at once. Others have suggested that a runner’s
optimal stride frequency is a trade-off between the metabolic cost associated with braking impulses and those
associated with swinging the leg \[87\]. Further work into
this braking strategy is required to understand the impli
cations for RE.

Increasing the absolute time spent in the swing phase
has been associated with better RE by several researchers

\[11, 42, 43\]. However, others have failed to find any
relationship between the two \[43, 71\]. Findings from
Barnes et al. \[43\] suggest that sex also affects this relationship; however, this has not been corroborated by others

\[11, 71\]. It is conceivable that a longer absolute swing time
means runners spend a smaller proportion of the gait cycle
in contact with the ground, which is believed to be the
metabolically expensive phase of the cycle. It is important
to note that the swing and ground contact times will impact
the stride frequency and stride length of a runner, and it is
perhaps the relationship between all these aspects that

should be considered.

3.1 Lower Limb Kinematic Factors

Various kinematic parameters have been identified as being
associated with better RE in cross-comparison studies;
greater plantarflexion velocity \[75\], greater horizontal heel
velocity at initial contact \[75\], greater maximal thigh
extension angle with the vertical \[75\], greater knee flexion
during stance \[42\], reduced knee range of motion during
stance \[88\], reduced peak hip flexion during braking \[88\],
slower knee flexion velocity during swing \[42, 71\], greater
dorsiflexion and faster dorsiflexion velocity during stance

\[71\], slower dorsiflexion velocity during stance \[88\], and
greater shank angle at initial contact \[42\]. Intra-individual
comparisons have identified later occurrence of peak dorsiflexion, slower eversion velocity at initial contact, and
less knee flexion at push-off as being associated with
improved RE \[34\].
One of the few kinematic variables to have strong support
from both cross- and intra-individual comparisons as being
beneficial for RE is a less extended leg at toe-off \[34, 42, 50,
71, 75, 89\]. Evidence has shown that this can be achieved
through less plantarflexion and/or less knee extension as the
runner pushes off the ground (Fig. 2). Hip extension is also

## 123

Pre Post

Fig. 2 Differences in knee angle (top) and ankle angle (bottom) at
toe-off between pre and post measurements. Pre refers to baseline
running biomechanics and post refers to running biomechanics after
10 weeks of running whereby beginner runners improved their
running economy and altered their running technique. Reproduced
from Moore et al. \[34\], with permission

likely to contribute, but studies have typically focused on the
knee and ankle angles. Less leg extension could produce
greater propulsive force, as identified by Moore et al. \[34\], by
potentially allowing the leg extensor muscles to operate at a
more favorable position on the force–length curve and higher
gear ratios (GRF moment arm to muscle–tendon moment
arm) being obtained. Both strategies could maximize force
production \[90, 91\]. Additionally, less leg extension would
reduce the amount of flexion needed during swing by already
being partially flexed and potentially reduce the leg’s
moment of inertia, lowering the energy required to flex the
leg during the swing phase. Previous research has shown that
reduced leg moment of inertia lowers the leg’s mechanical
demand during the swing phase, as well as the metabolic
demand, of walking \[92\]. Therefore, it is conceivable that a
similar relationship exists when running, but this needs
investigating.
Another kinematic during the push-off phase that has
been associated with better RE is stride angle, which is
defined as the angle of the parable tangent of the CoM at
toe-off \[11, 93, 94\]. Larger stride angles appear to be
beneficial for lowering V \[\_\] O2 and can be achieved by either
increasing swing time or decreasing stride length. However, the system (Optojump Next) used by each study \[11,
93, 94\] only tracks the foot during ground contact and not
the CoM. Therefore, only inferences can be made

Modifiable Biomechanical Factors Affecting Running Economy 797

regarding the trajectory angle of the CoM and other possible kinematic changes. Future work focusing on the pushoff phase should assess CoM trajectory in relation to
kinematics and kinetics, as increasing swing time would
also increase the vertical displacement of the CoM based
on previous calculations \[11, 93, 94\] and observations \[95\].
Crucially, research suggests that increases to these spatiotemporal parameters appear to have contradictory relationships with RE \[11, 41–43, 63\].
Foot strike patterns have been implicated as a modifiable
factor affecting RE \[96\], with some researchers arguing
that the most economical strike pattern is forefoot striking,
even when RE is not assessed \[97–99\]. However, empirical
evidence refutes this claim. Findings shows no difference
in RE between rearfoot and forefoot striking at slow
(B3 m�s \[-\]\[1\] ) \[51, 83, 100, 101\], medium (3.1–3.9 m�s \[-\]\[1\] )

\[83, 100, 101\], and fast speeds (C4.0 m�s \[-\]\[1\] ) \[83, 100\] or
rearfoot and midfoot striking at medium speeds \[76\].
However, others have shown rearfoot striking to be more
economical than midfoot striking at slow running speeds

\[102\]. Interestingly, habitual forefoot strikers can change to
a rearfoot strike without detrimental consequences to RE,
while an imposed forefoot strike in habitual rearfoot
strikers produces worse RE at slow and medium speeds

\[100\]. Based on the current literature, foot strike appears to
have a negligible effect upon RE, with only habitual
rearfoot strikers likely to experience a worsening of RE by
switching foot strike patterns.

3.2 Kinetic Factors

Early research reported that RE was proportional to the
vertical component of GRF (e.g., force required to support
body weight) and was termed the ‘cost of generating force’
hypothesis \[79, 103, 104\]. However, later investigations
have used a task-by-task approach to partition RE into
individual biomechanical tasks \[105\]. Such work has
demonstrated that braking (decelerating the body) and
propulsive (accelerating the body) forces also incur metabolic costs \[105\]. Typically, the three components of GRF
(anterior-posterior, medial–lateral, and vertical) have been
independently assessed, with evidence suggesting lower
vertical impact force \[42\], lower peak medial–lateral force

\[42, 75\], lower anterior–posterior braking force \[73\], and
higher anterior–posterior propulsive force \[34\] are economical. However, numerous studies have also failed to
identify similar associations between RE and individual
GRF components \[26, 73, 74\].
To understand the metabolic costs incurred during
running Arellano and Kram \[106\] advocate using a synergistic approach, rather than the ‘cost of generating
force’ hypothesis or task-by-task approach. Using this
approach, the vertical force (supporting body weight) and

forward propulsive force (accelerating the body) incur the
greatest metabolic cost (Fig. 3). However, very few
biomechanical studies have utilized such an approach.
Storen et al. \[74\] demonstrated that it could be usefully
applied as they found significant relationships between
the summation of peak vertical and anterior–posterior
forces and 3-km performance (r = -0.71) and RE (r = 0.66). Their findings show that lower forces were associated with a better running performance and RE. Additionally, Moore et al. \[107\] reported near perfect
alignment of the angle of the resultant GRF vector (all
three components) with the angle of the longitudinal leg
axis vector during propulsion when novice runners
improved their RE. This change in alignment was associated with a change in RE (rs = 0.88), suggesting that
minimizing the muscular effort of generating force during
propulsion is beneficial to RE \[107\].

Associations have also been found between GRF

impulses and RE, with lower braking \[87\], total, and net
vertical impulses related to a better RE \[9\]. However, this
finding is not consistent in the literature \[77\]. Through
collectively considering the deceleration and acceleration
(anterior–posterior) impulses, a runner’s change in
momentum can be determined. One pilot study has utilized
this technique, but reported similar changes in momentum
pre and post a 10-week running program that improved RE

\[107\]. The authors suggested that such a short-term training
program might not have been long enough to induce
modifications in momentum \[107\]. It is also conceivable
that a synergistic approach should be applied to momentum
and speed lost during braking.
The magnitude of the GRF during running has a linear
relationship with the body’s vertical displacement \[108\],
suggesting the leg acts like a spring during ground contact

\[44\]. Therefore, use of the spring-mass model to describe
the body’s bounce during the support phase of running has
been widespread. The springs’ stiffness is the ratio of
deformation (vertical displacement) to the force applied to
it (vertical GRF) and therefore represents the stiffness of
the whole body’s musculoskeletal system \[109\]. Leg
stiffness represents the ratio of maximal vertical force to
maximal vertical leg spring compression \[110\]. Greater leg
stiffness has been associated with a better RE \[44\], whilst
fatiguing runs to volitional exhaustion have led to reductions in leg stiffness \[64, 65\]. Furthermore, alterations to
extrinsic factors, such as increasing surface compliance,
can lead to decreases in leg stiffness, resulting in a worse
RE \[111\]. Running in minimalist footwear can increase leg
stiffness and improve RE compared with traditional and
cushioned footwear \[112, 113\]. Interestingly, leg stiffness
is predominately associated with ground-contact time
rather than step frequency \[114\]. Thus, to try and increase
leg stiffness, runners are advised to focus on shortening

## 123

798 I. S. Moore

Fig. 3 The a cost of generating force, b individual task-by-task, and
c synergistic task-by-task approach partition the net metabolic cost of
human running into its biomechanical constituents. The cost of
generating force approach and the individual task-by-task approach
both illustrate that body weight support is the primary determinant of
the net metabolic cost of human running. In the individual task-by-task
approach, forward propulsion represents the second largest determinant. The individual task-by-task approach leads to an overestimation,
while the synergistic task-by-task approach suggests that the synergistic

ground-contact time rather than increasing step frequency.
Such an approach may be beneficial for RE improvements.
As leg stiffness represents the stiffness of the whole
musculoskeletal system, several factors relating to stiffness
are unmodifiable, such as muscle crossbridges and tendon
stiffness. However, neuromuscular activation is a modifi
able characteristic that can modulate stiffness.

3.3 Neuromuscular Factors

The preactivation of muscles prior to ground contact, termed muscle tuning, is believed to increase muscle–tendon
stiffness \[77\], potentially enhance muscular force generation via the stretch–shortening cycle (SSC) \[115\], and
affect leg geometry at initial ground contact \[116–118\].
Nigg et al. \[119\] studied the effect of shoe midsole characteristics on RE and preactivation, and, whilst no overall
shoe-dependent changes were found in either variable,
systematic individual changes in vastus medialis preactivation were evident. Runners who produced higher vastus
medialis preactivation independent of shoe condition also
had a higher V \[_\] O2 \[119\]. However, given the small changes
in RE (\\2 %) the differences may be due to test–retest
measurement error and are unlikely to represent a meaningful change in RE \[120\].
Greater muscular activity of the lower limbs has been
reported as a potential mechanism behind increasing V \[_\] O2
and thus is seen as detrimental to RE \[73\]. The intuitive
link between muscle activity and RE stems from muscles
needing to utilize oxygen to activate, and thereby, control

## 123

tasks of body weight support and forward propulsion are the primary
determinants of the net metabolic cost of human running. Note that leg
swing and lateral balance exact a relatively small net metabolic cost. If
we sum all the biomechanical tasks, the synergistic task-by-task
approach accounts for 89 % of the net metabolic cost of human
running, leaving 11 % of unexplained metabolic cost, and the cost of
generating force accounts for 80 %, leaving 20 % of unexplained
metabolic cost. Reproduced from Arellano and Kram \[106\], with
permission from Oxford University Press

movement patterns and stabilize joints. Therefore, greater
muscle activation, as typically measured using surface
electromyography (EMG), is thought to require a higher
V_O2 and lead to a worsening of RE. In line with this,
findings have shown a higher activation of the gastrocnemius during propulsion and of the biceps femoris during
braking and propulsion to be associated with higher V \[\_\] O2

\[73\]. Additionally, Abe et al. \[45\] found an increase in V \[\_\] O2
during a prolonged run was associated with a decrease in
the ratio of eccentric–concentric vastus lateralis activity.
This change in eccentric–concentric ratio was due to an
increase in activity during propulsion (concentric phase).
Collectively, these findings suggest that needing to utilize
greater muscle activation to propel the runner forwards,
possibly due to a reduced efficiency of the SSC, is detri
mental to RE.

Bourdin et al. \[121\] support this notion, as they found
lower eccentric–concentric ratios of vastus lateralis activity
were associated with a higher energetic cost of running.
Importantly, however, this relationship was more prominent when inter-individual differences were being assessed

and was weaker when intra-individual differences were

considered. Sinclair et al. \[88\] also found a higher activity
of the vastus medialis to be related to a worse RE when

comparing different runners. Conversely, Pinnington and
colleagues \[122, 123\] have suggested that intra-individual
increases in V \[\_\] O2 associated with running on sand compared with on a firm surface are partially due to increased
activation of the quadriceps and hamstrings muscles
involved in greater hip and knee range of motion.

Modifiable Biomechanical Factors Affecting Running Economy 799

However, as V \[\_\] O2 and EMG data were collected in separate
studies, causal interpretations should be made with caution.
Larger intra- and inter-individual variations in lower limb
muscle activity duration and timing of peak activation have
been reported in novice compared with experienced runners \[124\], suggesting that greater running exposure may
alter neuromuscular control. However, longitudinal investigations are needed to confirm this.
Conflicting results have also been reported for the role
of muscular coactivation in relation to RE \[46–48\],
whereby muscular coactivation is defined as the simultaneous activation of two muscles. Heise et al. \[47\] found a
negative relationship between RE and the coactivation of
the rectus femoris and gastrocnemius, suggesting coactivation of biarticular muscles is economical, whereas Moore
et al. \[48\] reported a positive relationship. Furthermore,
muscular coactivation of the proximal agonist–antagonist
leg muscles, rectus femoris and biceps femoris, has also
been shown to have a positive association with RE,
meaning such coactivation is detrimental to RE \[46, 48\].
Coactivation of the proximal thigh antagonist–agonist
muscles occurs during the loading phase of stance as the
knee flexes. Without such coactivation, it is likely that the
leg would collapse \[125\], but essentially the muscles are
performing opposing movements. Using two muscles to
control such a movement would therefore incur a greater
metabolic cost than using one muscle, potentially
decreasing the efficiency of the SSC.
Investigations into the effect of orthotics on muscular
activation during ground contact and RE have provided
inconsistent findings. Kelly et al. \[126\] reported that alterations to muscular activity when wearing orthotics during a
1-h run were not accompanied by changes in RE. Contrastingly, Burke and Papuga \[127\] observed improvements
in RE when runners ran in custom-made orthotics rather

than shoe-fitted insoles, yet there were no changes in lower
limb muscular activity. However, the mass of the different
orthotics used by Burke and Papuga \[127\], and the potential
effect the orthotics had on running biomechanics, were not
assessed and may have influenced their findings.

3.4 Shoe–Surface Interaction Factors

There is a general consensus that running in traditional
running trainers is detrimental to RE compared with running barefoot or in lightweight, minimalist trainers, due to
the added shoe mass \[49–52, 128, 129\]. A recent metaanalysis suggested that a shoe mass (per pair) of less than
440 g does not affect RE, but a shoe mass greater than
440 g negatively affects RE \[129\]. However, when shoe
mass is taken into account, evidence regarding footwear
effects on RE is equivocal due to different methodologies

used. Mathematically correcting for different footwear
mass when expressing V \[_\] O2 in relative terms supports the
above statement that running in traditional trainers is
detrimental to RE compared with barefoot or minimalist
footwear running \[50\]. However, strapping weights equal
to the mass of a shoe to participants’ feet results in either
similar RE \[52\] or worse RE when barefoot compared with
shod \[49\]. One reason for this discrepancy is that mathematically adjusting V_ O2 technically adjusts the whole
body’s mass rather than the foot’s mass and does not take

into account the decrease in lower limb moment of inertia.

When the foot’s CoM is altered (weights strapped to the
top of foot) V \[_\] O2 is worse when barefoot \[49\], but when the
foot’s CoM is unchanged (weights evenly distributed on
the foot), V \[_\] O2 is similar between barefoot and shod conditions \[52\]. Therefore, changes to lower limb moment of
inertia, and not just shoe mass, appear to affect RE.
Findings from Scholz et al. \[130\] support this notion by
showing greater lower limb moment of inertia was associated with higher V \[_\] O2. Other shoe characteristics, such as
stiffness \[131\], comfort \[132\], and cushioning \[133\], are
likely to effect RE and thus, may have also contributed to
the equivocal findings regarding footwear effects on RE
when shoe mass is taken into account. However, if shoe
mass is not adjusted for, running barefoot or in lightweight,
minimalist trainers improves RE compared with traditional
running trainers (shoe mass \[440 g).
Changing footwear can also change the level of cushioning underfoot. Frederick et al. \[134\] proposed the ‘cost
of cushioning’ hypothesis, stating that actively cushioning
the body whilst running may incur a metabolic cost.
Therefore, shoes with limited cushioning or no cushioning
(such as being barefoot) would result in an individual
having to actively cushion the body using the lower limb
muscles \[117\] and lead to an increase in V \[_\] O2. Some evidence to support this claim is provided by Franz et al. \[49\],
who found that running in shoes with increasing mass had a
lower metabolic power demand than running barefoot with
increasing mass strapped to their feet. These results
therefore show that running without cushioning has a
higher metabolic demand than running with cushioning,
even when added shoe mass is similar. However, results
from Divert et al. \[52\] suggest it may be mechanical energy
that is increased rather than V_O2 when barefoot. This
means that barefoot running leads to mechanical efficiency
improvements due to greater work being done for the same
V\_ O2 compared with shod running.
Further, it appears there is an ‘optimal’ level of surface
cushioning for good RE. When running barefoot on a
treadmill, 10 mm of surface cushioning was more beneficial for RE than no surface cushioning and 20 mm of
surface cushioning \[53\]. When considering natural running

## 123

800 I. S. Moore

terrain, Pinnington and Dawson \[122\] found running on
grass elicited a lower V \[\_\] O2 than running on sand. This is
likely due to the damping effects of sand, leading to an
increase in mechanical work done during stance \[135\].
Therefore, a firmer surface that returns the energy it
absorbs will benefit a runner’s RE. Moreover, a firm surface with reduced stiffness, and thus greater compliance,
will return more energy due to the surface’s elastic rebound
and improve RE \[111\].
This theory can also be applied to running shoes, as
Worobets et al. \[54\] showed that a softer shoe, which was
more compliant and lost less energy during impact than a
control shoe, improved RE. Additionally, shoes with a high
forefoot bending elasticity can increase propulsive force and
reduce contact time and gastrocnemius muscle activation
during slow (\\3 m�s \[-\]\[1\] ), but not medium (3.1–3.9 m�s \[-\]\[1\] ),
running speeds compared with a flexible forefoot region

\[136\]. Such shoes may therefore improve RE due to
enhancing propulsion; however, no V \[\_\] O2 data were gathered
during the study, so direct associations cannot be made.
Consequently, it is likely that a medium level of cushioning,
that returns energy, is beneficial for RE compared with the
shoe–surface cushioning being too compliant or too hard.
Footwear (or lack of) can also affect running biomechanics. Several modifications to running biomechanics may
potentially benefit RE, whilst others may not. For example,
in comparison with shod running, barefoot running can
shorten ground contact time and stride length \[49–52, 128,
137–140\], increase knee flexion at initial contact \[139\],
increase leg stiffness \[52, 139, 141, 142\], decrease vertical
oscillation \[50, 138\], increase propulsive force \[143\], and
reduce plantarflexion at toe-off \[50, 139\]. The most commonly cited change when running barefoot is a more anterior foot strike pattern brought about by a flatter foot, such as
switching from a rearfoot to a forefoot strike pattern \[50, 98,
137, 139, 140, 142, 144\]. However, evidence shows many
confounding variables affect foot strike, including speed \[97,
145\], surface stiffness \[146\], stride length \[50\], and familiarization with barefoot running \[147\]. Therefore, footwear
(or lack of) alone cannot explain changes in foot strike.
Based on the several findings above, it can be suggested that
acute exposure to running barefoot may be beneficial for
RE, especially if performed on a surface with a medium
level of cushioning. Aside from acute exposure, the effect of
individual adaptations due to short- and long-term exposure
to barefoot running on RE and running biomechanics is
currently unknown.

3.5 Trunk and Upper Limb Biomechanical Factors

The relationship between RE and trunk and upper body

biomechanics has received limited research attention

## 123

compared with lower limb biomechanics. Swinging the
arms during running plays an important role as it contributes to vertical oscillation \[55, 56\]; counters vertical
angular momentum of the lower limbs \[148\]; and minimizes head, shoulder, and torso rotation \[149, 150\].
Eliminating arm swing by placing the hands on top of the
head can be detrimental to RE \[41, 149\], whilst placing the
hands behind the back or across the chest has provided
inconsistent findings \[41, 56, 63, 149, 150\]. However, there
is no evidence to suggest that individuals can alter arm
kinematics to improve RE and thus, running performance.
Therefore, based on current evidence, individuals are
encouraged to maintain their natural arm swing whilst
running.
Suppressing arm swing can alter several lower limb
biomechanics and kinetics. For example, restraining the
arms behind the back and across the chest decreases peak
vertical force, increases peak hip and knee flexion angles
during stance, and reduces knee adduction during stance

\[151\]. These biomechanical changes appear to be due to
the loss of arm motion rather than the body’s CoM moving
position \[151\], suggesting that arm motion plays an integral
role in an individual’s running technique. Further, the
greater knee flexion and reduced peak vertical force
observed when arm swing is suppressed suggests that leg
stiffness decreases, which may explain the change in RE
found in some studies \[41, 56, 149\]. However, currently,
the relationship between leg stiffness and arm motion
during running is unknown.
It has been suggested that a forward trunk lean during
running improves RE \[58\], based on findings from Williams and Cavanagh \[42\]. Yet, a forward lean has also been
implicated as detrimental to RE. Hausswirth et al. \[57\]
compared the V \[_\] O2 during a marathon run (2 h, 15 min)
with that during a 45-minute run and found the marathon
run had a higher V_ O2 and greater forward trunk lean.
However, this finding should be interpreted in light of the
other modifications to running biomechanics when comparing the marathon run with the 45-min run, such as the
13 % shorter stride lengths. It is possible that shortening
the stride lengths by this amount incurred the highest V \[_\] O2
rather than the forward lean. Additionally, the biomechanical changes could be due to muscular fatigue resulting
from the difference in running time between the two conditions (1 h, 30 min), meaning muscular fatigue could have
led to increases in V \[_\] O2.

For women runners, breast kinematics also have the
potential to affect RE and running biomechanics. Evidence
shows that breast kinematics can affect running kinetics

\[152\], trunk lean via changes in breast support \[153\], and
lower limb biomechanics, in particular knee angle and step
length \[154\]. These findings imply there may be alterations

Modifiable Biomechanical Factors Affecting Running Economy 801

to RE, particularly if the changes in step length are greater
than 3 % of the preferred step length. Further work that
simultaneously assesses RE, breast kinematics, breast
support, and lower limb biomechanics is warranted to

assess whether there is a direct association between the

measures.

4 Simultaneously Modifying Running
Biomechanics and Running Economy Through
Training

Short- and mid-term training interventions (3–12 weeks)
have been conducted to assess relationships between running biomechanics and RE. But to date, no long-term
training interventions have been performed. Early interventions primarily focused on spatiotemporal factors, with
Morgan et al. \[155\] showing that trained runners with
uneconomical stride lengths could be retrained using
audio-feedback over 3 weeks to produce mathematically
derived optimal stride lengths and improved RE. In contrast, Messier and Cirillo \[95\] failed to find improvements
in RE when using verbal and visual feedback for 5 weeks
to change specific running biomechanics, such as longer
stride lengths, shorter ground-contact time, and reduced
vertical oscillation. However, optimal stride length was not
mathematically determined prior to the intervention,
meaning suitable procedures were not used and several
running biomechanics either were not modified or, in the
case of vertical oscillation, actually increased after the
intervention. Bailey and Messier \[156\] also found that if
runners were able to freely choose their stride length over
7 weeks, there was no change in RE. Similarly, if runners
were restricted to their initial freely chosen stride length
over 7 weeks, RE was unaffected \[156\].
Interventions concerned with instructing runners to
retrain their running biomechanics towards a specific global running technique, such as Pose, Chi and midstance to
midstance running, has generally resulted in either no
improvement in RE \[62, 85\] or a worsening of RE \[157\].
Whilst these techniques are often advocated as efficient
forms of running \[157, 158\], and all the interventions led to
modified running biomechanics, currently there appears to
be no evidence to substantiate the claims that they benefit
RE. It is conceivable that the failure of global running
techniques to improve RE is because they are not targeting
the right running biomechanics or because they are trying
to change too many at the same time.
Running gait retraining has also focused on reducing
injury risk \[159–162\], but only one study has assessed the
effect of such retraining on RE as well \[163\]. Clansey et al.

\[163\] provided trained runners with gait re-training using
real-time visual feedback over 3 weeks to modify impact

loading variables associated with tibial stress fracture risk.
Runners reduced peak tibial acceleration and loading rates
without changing RE. Thus, gait re-training to reduce
injury risk can be performed without necessarily affecting
running performance. This is possibly because the gait
alterations were predominantly during the impact phase
and have minimal effect on RE, as individuals increased
plantarflexion at initial contact and exhibited a more
anterior foot strike.

Moore et al. \[34\] reported that novice runners could selfoptimize their running gait over 10 weeks of running
training, with 94 % of the variance of change in RE
explained by less knee extension at toe-off, a later occurrence of peak dorsiflexion, and slower eversion velocity at
initial contact. Furthermore, trained, habitually shod runners can improve their RE when running in minimalist
footwear after a 4-week intervention exposing them to
running in minimalist footwear \[96\]. Although very few
running gait parameters were assessed by Warne and
Warrington \[96\], runners did exhibit a more anterior foot
strike when more economical. Whilst collectively these
results support short-term biomechanical self-optimization
to running training, a previous investigation failed to find
RE improvements and biomechanical changes in trained
runners after 6 weeks of running \[36\]. Consequently,
novice runners may be more responsive to self-optimization in the short-term than trained runners; however providing trained runners with a novel stimulus, such as
different footwear, can lead to short-term self-optimization.
Thus, self-optimization is a physiological adaptation to
running acquired through greater experience of the stimulus. For trained runners, the majority of this physiological
adaptation may have already occurred. A summary of how
training interventions have affected RE is presented in
Fig. 4.

5 Is there an Economical Running Technique?

Based on the literature, several modifiable factors that can
potentially improve RE have been identified, as well as
factors that have conflicting or limited findings regarding
their relationship with RE (Table 1). From this summary, it
is clear that biomechanics during ground contact play an
important role. Furthermore, evidence shows that many of
the running biomechanics identified occur during propulsion, suggesting that this phase has the strongest direct
links with RE. However, theoretical deceleration strategies,
such as short braking times and minimizing the speed lost
during braking, may translate to more economical strategies in the propulsive phase and mediate the relationship
between propulsion and RE. Therefore, utilizing the principles of the SSC is encouraged.

## 123

802 I. S. Moore

Fig. 4 Summary of the training
programs that have
simultaneously measured
running economy and running
biomechanics. The effect on

running economy is denoted in
bold. RE running economy

Considering the empirical evidence, one economical
running strategy could be aiming to shorten ground-contact
times whilst maintaining stride frequency, which may
facilitate greater leg stiffness, larger stride angles, and
longer swing times. However, such a strategy may increase
vertical oscillation and encourage greater muscular activity
during propulsion. Another strategy could involve aligning
the resultant GRF more closely with the leg axis during
propulsion. This may help minimize muscular activity and
agonist–antagonist coactivation and could be produced as a
result of reducing leg extension at toe-off.
An experienced runner’s naturally chosen stride length
is self-optimized to within 3 % of the mathematically
derived optimal. Deviating between naturally chosen and
mathematically optimal will only have a negligible effect
on RE. However, novice runners have not acquired the
running experience necessary to self-optimize as effectively. Therefore, a short-term running training program for
novice runners can lead to running biomechanics being
modified to benefit RE. However, long-term running
training has seldom been investigated. Consequently,

## 123

longitudinal investigations assessing the development of
running biomechanics in both novice runners and experienced runners are required to better understand self-optimization for RE improvements.
Notwithstanding the identified modifiable factors
affecting RE, prescribing an economical way of running
has its limitations based on the current empirical evidence.
The majority of studies have used cross-comparison
methodologies or are restricted to one running population.
Additionally, it is evident from the numerous studies analyzing intra-individual changes that group differences,
which statistically hold more power, provide limited conclusions of modifications to running biomechanics \[88,
119, 164\]. Also, very few studies have assessed running
biomechanics during the swing phase, even though current
findings indicate the position of the CoM and leg during
this phase may be crucial to conserving energy and
reducing V\_ O2. Exploring running biomechanics during
swing and the interaction with stance-phase biomechanics
is recommended in future work. Furthermore, the role of
unmodifiable factors and how they may interact with

Modifiable Biomechanical Factors Affecting Running Economy 803

Table 1 Modifiable intrinsic and extrinsic running biomechanics and their effect on running economy

Evidenced Intrinsic Extrinsic

effect on RE

Spatiotemporal Kinetics Kinematics Neuromuscular

Beneficial Self-selected stride length (minus Greater leg stiffness Less leg
3 %) extension at
toe-off

Low muscle

activation during
propulsion

Firm, compliant
shoe-surface

interaction

Barefoot or

lightweight shoes
(\\440 g)

Low vertical oscillation Alignment of GRF and leg Large stride Low agonist–
axis during propulsion angle antagonist
coactivation

Low lower limb moment Maintain arm

of inertia swing

Conflicting Ground contact time Impact force Trunk lean Biarticular Orthotics
coactivation

Swing time Anterior–posterior forces

Limited or Horizontal distance between the Impulses Swing phase Vastus medialis
unknown foot and CoM at initial contact preactivation

Braking/deceleration time Foot-strike
pattern

Speed lost during ground contact Breast
kinematics

CoM centre of mass, GRF ground reaction force, RE running economy

modifiable factors is an area requiring investigation. For
example, Cavanagh and Williams \[40\] reported that individuals with long legs had a larger increase in V \[_\] O2 when
shortening their strides compared with lengthening them.
In contrast, individuals with shorter legs had a larger
increase in V \[_\] O2 when lengthening their stride than when
shortening it.

Biomechanical case studies of economical runners have

not been published, but could provide interesting findings if
an in-depth runner profile was provided. Such a profile
would need to encompass factors such as running biomechanics, anatomical structures, functional capacity (e.g.,
flexibility, muscular strength, and stiffness), shoe degradation, injury history, and training protocols \[165\]. Whilst
only the former have been discussed here, the interaction

between an individual’s anatomical structures—such as

foot morphology, leg length, and tendon stiffness—and
their running biomechanics is likely to be influential upon
RE. This is certainly a direction for future research to
pursue, as it could identify novel relationships and interactions that inform larger, cohort studies.

6 Conclusion

One of the determining factors of running performance is
RE. Modifiable running biomechanical factors that affect
RE include spatiotemporal factors, lower limb kinematics,
kinetics, neuromuscular factors, shoe–surface interactions, and trunk and upper limb biomechanics. Several
intrinsic factors that appear to benefit RE are a self

selected stride length with a 3 % shorter stride length
range, lower vertical oscillation, greater leg stiffness, low
lower limb moment of inertia, alignment of the GRF and
leg axis vectors, less leg extension at toe-off, larger stride
angles, maintaining arm swing, low muscle activation
during propulsion, and low antagonist–agonist thigh
coactivation. In regards to extrinsic factors, better RE was
found to be associated with a firm, compliant shoe-surface
interaction and being barefoot or wearing lightweight
shoes. Other modifiable biomechanical factors, such as
ground contact time, impact force, anterior–posterior
forces, trunk lean, lower limb biarticular muscle coactivation, and orthotics, presented inconsistent relationships
with RE. Collectively, the evidence shows that many of
the running biomechanics identified occur during
propulsion, suggesting that this phase has the strongest
direct links with RE. However, recurring methodological
problems exist within the literature, such as cross-comparisons, assessing variables in isolation, and acute to
short-term interventions. Further, intra-individual differences due to unmodifiable factors limit the findings of
cross-comparisons, and future research should look to
investigate longitudinal interventions and assess runners
on an individual basis. Consequently, recommending an
economical running technique should be approached with
caution. Directions for further work within the field
should focus on a synergistic approach to assessing
kinetics as well as integrated approaches combining V \[\_\] O2,
kinematics, kinetics, and neuromuscular and anatomical
aspects to increase our understanding of economical
running technique.

## 123

804 I. S. Moore

Acknowledgments The author would like to thank Professor
Andrew Jones and Dr. Victoria Stiles for their critical comments on

earlier versions of the manuscript.

Compliance with Ethical Standards

Funding No sources of funding were used to assist in the preparation of this article.

Conflicts of interest Isabel Moore declares she has no conflicts of
interest relevant to the content of this review.

Open Access This article is distributed under the terms of the
[Creative Commons Attribution 4.0 International License (http://](http://creativecommons.org/licenses/by/4.0/)
[creativecommons.org/licenses/by/4.0/), which permits unrestricted](http://creativecommons.org/licenses/by/4.0/)
use, distribution, and reproduction in any medium, provided you give
appropriate credit to the original author(s) and the source, provide a
link to the Creative Commons license, and indicate if changes were
made.

References

1. Billat VL, Demarle A, Slawinski J, et al. Physical and training
   characteristics of top-class marathon runners. Med Sci Sports
   Exerc. 2001;33:2089–97.
1. Foster C. VO2 max and training indices as determinants of
   competitive running performance. J Sports Sci. 1983;1:13–22.
1. Farrell PA, Wilmore JH, Coyle EF, et al. Plasma lactate accumulation and distance running performance. Med Sci Sports.
   1979;11:338–44.
1. Tanaka K, Matsuura Y. Marathon performance, anaerobic
   threshold, and onset of blood lactate accumulation. J Appl
   Physiol Respir Environ Exerc Physiol. 1984;57:640–3.
1. Conley DL, Krahenbuhl GS. Running economy and distance
   running performance of highly trained athletes. Med Sci Sports
   Exerc. 1980;12:357–60.
1. Morgan DW, Baldini FD, Martin PE, et al. Ten kilometer performance and predicted velocity at VO2max among well-trained
   male runners. Med Sci Sports Exerc. 1989;21:78–83.
1. Pollock ML. Submaximal and maximal working capacity of
   elite distance runners. Part I: cardiorespiratory aspects. Ann N Y
   Acad Sci. 1977;301:310–22.
1. Daniels JT. A physiologist’s view of running economy. Med Sci
   Sports Exerc. 1985;17:332–8.
1. Heise GD, Martin PE. Are variations in running economy in
   humans associated with ground reaction force characteristics?
   Eur J Appl Physiol. 2001;84:438–42.
1. Costill DL, Thomason H, Roberts E. Fractional utilization of the
   aerobic capacity during distance running. Med Sci Sports.
   1973;5:248–52.
1. Santos-Concejero J, Tam N, Granados C, et al. Stride angle as a
   novel indicator of running economy in well-trained runners.
   J Strength Cond Res. 2014;28:1889–95.
1. Jones AM. The physiology of the world record holder for the
   women’s marathon. Int J Sports Sci Coach. 2006;1:101–16.
1. Bransford DR, Howley ET. Oxygen cost of running in trained
   and untrained men and women. Med Sci Sports Exerc.
   1977;9:41–4.
1. Morgan DW, Bransford DR, Costill DL, et al. Variation in the
   aerobic demand of running among trained and untrained subjects. Med Sci Sports Exerc. 1995;27:404–9.
1. Daniels J, Daniels N. Running economy of elite male and elite
   female runners. Med Sci Sports Exerc. 1992;24:483–9.

## 123

16. Helgerud J, Storen O, Hoff J. Are there differences in running
    economy at different velocities for well-trained distance runners? Eur J Appl Physiol. 2010;108:1099–105.
01. Barnes KR, Kilding AE. Running economy: measurement,
    norms, and determining factors. Sports Med Open. 2015;1:8.
01. Saunders PU, Pyne DB, Telford RD, et al. Factors affecting
    running economy in trained distance runners. Sports Med.
    2004;34:465–85.
01. Barnes KR, Kilding AE. Strategies to improve running economy. Sports Med. 2015;45:37–56.
01. Jones AM, Carter H. The effect of endurance training on
    parameters of aerobic fitness. Sports Med. 2000;29:373–86.
01. Saunders PU, Telford RD, Pyne DB, et al. Short-term plyometric training improves running economy in highly trained
    middle and long distance runners. J Strength Cond Res.
    2006;20:947–54.
01. Spurrs RW, Murphy AJ, Watsford ML. The effect of plyometric
    training on distance running performance. Eur J Appl Physiol.
    2003;89:1–7.
01. Turner AM, Owings M, Schwane JA. Improvement in running
    economy after 6 weeks of plyometric training. J Strength Cond
    Res. 2003;17:60–7.
01. Barnes KR, Hopkins WG, McGuigan MR, et al. Effects of
    resistance training on running economy and cross-country performance. Med Sci Sports Exerc. 2013;45:2322–31.
01. Guglielmo LGA, Greco CC, Denadai BS. Effects of strength
    training on running economy. Int J Sports Med. 2009;30:27–32.
01. Paavolainen L, Hakkinen K, Hamalainen I, et al. Explosivestrength training improves 5-km running time by improving
    running economy and muscle power. J Appl Physiol.
    1999;86:1527–33.
01. Støren Ø, Helgerud J, Støa EM, et al. Maximal strength training
    improves running economy in distance runners. Med Sci Sports
    Exerc. 2008;40:1087–92.
01. Cheng CF, Cheng KH, Lee YM, et al. Improvement in running
    economy after 8 weeks of whole-body vibration training.
    J Strength Cond Res. 2012;26:3349–57.
01. Barnes KR, Hopkins WG, McGuigan MR, et al. Effects of
    different uphill interval-training programs on running economy
    and performance. Int J Sports Physiol Perf. 2013;8:639–47.
01. Denadai BS, Ortiz MJ, Greco CC, et al. Interval training at 95%
    and 100% of the velocity at VO2 max: effects on aerobic
    physiological indexes and running performance. Appl Physiol
    Nutr Metab. 2006;31:737–43.
01. Franch J, Madsen K, Djurhuus MS, et al. Improved running
    economy following intensified training correlates with reduced
    ventilatory demands. Med Sci Sports Exerc. 1998;30:1250–6.
01. Saunders PU, Pyne DB, Gore CJ. Endurance training at altitude.
    High Alt Med Biol. 2009;10:135–48.
01. Saunders PU, Telford RD, Pyne DB, et al. Improved running
    economy in elite runners after 20 days of simulated moderatealtitude exposure. J Appl Physiol. 2004;96:931–7.
01. Moore IS, Jones AM, Dixon SJ. Mechanisms for improved
    running economy in beginner runners. Med Sci Sports Exerc.
    2012;44:1756–63.
01. Beneke R, Hutler M. The effect of training on running economy
    and performance in recreational athletes. Med Sci Sports Exerc.
    2005;37:1794–9.
01. Lake MJ, Cavanagh PR. Six weeks of training does not change
    running mechanics or improve running economy. Med Sci
    Sports Exerc. 1996;28:860–9.
01. Ramsbottom R, Williams C, Fleming N, et al. Training induced
    physiological and metabolic changes associated with improvements in running performance. Br J Sports Med. 1989;23:171–6.
01. Ferrauti A, Bergermann M, Fernandez-Fernandez J. Effects of a
    concurrent strength and endurance training on running

Modifiable Biomechanical Factors Affecting Running Economy 805

performance and running economy in recreational marathon
runners. J Strength Cond Res. 2010;24:2770–8.
39\. Roschel H, Barroso R, Tricoli V, et al. Effects of strength
training associated with whole body vibration training on running economy and vertical stiffness. J Strength Cond Res.
2015;29:2215–20.
40\. Cavanagh PR, Williams KR. The effect of stride length variation
on oxygen uptake during distance running. Med Sci Sports
Exerc. 1982;14:30–5.
41\. Tseh W, Caputo JL, Morgan DW. Influence of gait manipulation
on running economy in female distance runners. J Sports Sci
Med. 2008;7:91–5.
42\. Williams KR, Cavanagh PR. Relationship between distance
running mechanics, running economy, and performance. J Appl
Physiol. 1987;63:1236–45.
43\. Barnes KR, McGuigan MR, Kilding AE. Lower-body determinants of running economy in male and female distance runners.
J Strength Cond Res. 2014;28:1289–97.
44\. Dalleau G, Belli A, Bourdin M, et al. The spring-mass model
and the energy cost of treadmill running. Eur J Appl Physiol.
1998;77:257–63.
45\. Abe D, Muraki S, Yanagawa K, et al. Changes in EMG characteristics and metabolic energy cost during 90-min prolonged
running. Gait Posture. 2007;26:607–10.
46\. Frost G, Dowling J, Dyson K, et al. Cocontraction in three age
groups of children during treadmill locomotion. J Electromyogr
Kinesiol. 1997;7:179–86.
47\. Heise G, Shinohara M, Binks L. Biarticular leg muscles and
links to running economy. Int J Sports Med. 2008;29:688–91.
48\. Moore IS, Jones AM, Dixon SJ. Relationship between metabolic
cost and muscular coactivation across running speeds. J Sci Med
Sport. 2013;17:671–6.
49\. Franz JR, Wierzbinski CM, Kram R. Metabolic cost of running
barefoot versus shod: is lighter better? Med Sci Sports Exerc.
2012;44:1519–25.
50\. Moore IS, Jones AM, Dixon SJ. The pursuit of improved running performance: can changes in cushioning and somatosensory feedback influence running economy and injury risk?
Footwear Sci. 2014;6:1–11.
51\. Perl DP, Daoud AI, Lieberman DE. Effects of footwear and
strike type on running economy. Med Sci Sports Exerc.
2012;44:1335–43.
52\. Divert C, Mornieux G, Freychat P, et al. Barefoot-shod running
differences: shoe or mass effect? Int J Sports Med.
2008;29:512–8.
53\. Tung KD, Franz JR, Kram R. A test of the metabolic cost of
cushioning hypothesis during unshod and shod running. Med Sci
Sports Exerc. 2014;46:324–9.
54\. Worobets J, Wannop JW, Tomaras E, et al. Softer and more
resilient running shoe cushioning properties enhance running
economy. Footwear Sci. 2014;6:147–53.
55\. Arellano CJ, Kram R. The energetic cost of maintaining lateral
balance during human running. J Appl Physiol.
2012;112:427–34.
56\. Arellano CJ, Kram R. The effects of step width and arm swing
on energetic cost and lateral balance during running. J Biomech.
2011;44:1291–5.
57\. Hausswirth C, Bigard AX, Guezennec CY. Relationships
between running mechanics and energy cost of running at the
end of a triathlon and a marathon. Int J Sports Med.
1997;18:330–9.
58\. Anderson T. Biomechanics and running economy. Sports Med.
1996;22:76–89.
59\. de Ruiter CJ, Verdijk PW, Werker W, et al. Stride frequency in
relation to oxygen consumption in experienced and novice
runners. Eur J Sport Sci. 2013;14:251–8.

60. Hunter I, Smith GA. Preferred and optimal stride frequency,
    stiffness and economy: changes with fatigue during a 1-h highintensity run. Eur J Appl Physiol. 2007;100:653–61.
01. Connick MJ, Li FX. Changes in timing of muscle contractions
    and running economy with altered stride pattern during running.
    Gait Posture. 2014;39:634–7.
01. Craighead DH, Lehecka N, King DL. A novel running
    mechanic’s class changes kinematics but not running economy.
    J Strength Cond Res. 2014;28:3137–45.
01. Egbuonu ME, Cavanagh PR, Miller TA. Degradation of running
    economy through changes in running mechanics. Med Sci
    Sports Exerc. 1990;22:S17.
01. Fourchet F, Girard O, Kelly L, et al. Changes in leg spring
    behaviour, plantar loading and foot mobility magnitude induced
    by an exhaustive treadmill run in adolescent middle-distance
    runners. J Sci Med Sport. 2014;18:199–203.
01. Hayes PR, Caplan N. Leg stiffness decreases during a run to
    exhaustion at the speed at VO2max. Eur J Sport Sci.
    2014;14:556–62.
01. McKenna MJ, Hargreaves M. Resolving fatigue mechanisms
    determining exercise performance: integrative physiology at its
    finest! J Appl Physiol. 2008;104:286–7.
01. Levine BD. V \[\_\] (O(2), max): what do we know, and what do we
    still need to know? J Physiol. 2008;586:25–34.
01. Halvorsen K, Eriksson M, Gullstrand L. Acute effects of
    reducing vertical displacement and step frequency on running
    economy. J Strength Cond Res. 2012;26:2065–70.
01. Teunissen LP, Grabowski A, Kram R. Effects of independently
    altering body weight and body mass on the metabolic cost of
    running. J Exp Biol. 2007;210:4418–27.
01. Slawinski JS, Billat VL. Difference in mechanical and energy
    cost between highly, well, and nontrained runners. Med Sci
    Sports Exerc. 2004;36:1440–6.
01. Williams KR, Cavanagh PR, Ziff JL. Biomechanical studies of
    elite female distance runners. Int J Sports Med. 1987;8(Suppl
    2):107–18.
01. Eriksson M, Halvorsen KA, Gullstrand L. Immediate effect of
    visual and auditory feedback to control the running mechanics
    of well-trained athletes. J Sports Sci. 2011;29:253–62.
01. Kyrolainen H, Belli A, Komi PV. Biomechanical factors
    affecting running economy. Med Sci Sports Exerc.
    2001;33:1330–7.
01. Storen O, Helgerud J, Hoff J. Running stride peak forces
    inversely determine running economy in elite runners. J Strength
    Cond Res. 2011;25:117–23.
01. Williams KR, Cavanagh PR. Biomechanical correlates with
    running economy in elite distance runners. Proceedings of the
    North American Congress on Biomechanics. Montreal; 1986.
    p. 287–8.
01. Di Michele R, Merni F. The concurrent effects of strike pattern
    and ground-contact time on running economy. J Sci Med Sport.
    2013;17:414–8.
01. Nummela AT, Keranen T, Mikkelsson LO. Factors related to top
    running speed and economy. Int J Sports Med. 2007;28:655–61.
01. Roberts TJ, Kram R, Weyand PG, et al. Energetics of bipedal
    running. I. Metabolic cost of generating force. J Exp Biol.
    1998;201:2745–51.
01. Kram R, Taylor CR. Energetics of running: a new perspective.
    Nature. 1990;346:265–7.
01. Kaneko M, Ito A, Fuchimoto T, et al. Influence of running speed
    on the mechanical efficiency of sprinters and distance runners.
    In: Winter DA, Norman RW, Wells RP, Heyes KC, Patla AE,
    editors. Biomechanics IX-B. Champaign: Human Kinetics;
01. p. 307–12.
01. Nummela AT, Paavolainen L, Sharwood KA, et al. Neuromuscular factors determining 5 km running performance and

## 123

806 I. S. Moore

running economy in well-trained athletes. Eur J Appl Physiol.
2006;97:1–8.
82\. Kong PW, De Heer H. Anthropometric, gait and strength
characteristics of Kenyan distance runners. J Sports Sci Med.
2008;7:499–504.
83\. Ardigo LP, Lafortuna C, Minetti AE, et al. Metabolic and
mechanical aspects of foot landing type, forefoot and rearfoot
strike, in human running. Acta Physiol Scand. 1995;155:17–22.
84\. Arendse RE, Noakes TD, Azevedo LB, et al. Reduced eccentric
loading of the knee with the pose running method. Med Sci
Sports Exerc. 2004;36:272–7.
85\. Fletcher G, Bartlett R, Romanov N, et al. Pose \[�\] method technique improves running performance without economy changes.
Int J Sports Sci Coach. 2008;3:365–80.
86\. Heiderscheit BC, Chumanov ES, Michalski MP, et al. Effects of
step rate manipulation on joint mechanics during running. Med
Sci Sports Exerc. 2011;43:296–302.
87\. Lieberman DE, Warrener AG, Wang J, et al. Effects of stride
frequency and foot position at landing on braking force, hip
torque, impact peak force and the metabolic cost of running in
humans. J Exp Biol. 2015;218:3406–14.
88\. Sinclair J, Taylor PJ, Edmundson CJ, et al. The influence of
footwear kinetic, kinematic and electromyographical parameters
on the energy requirements of steady state running. Mov Sport
Sci. 2013;80:39–49.
89\. Cavanagh PR, Pollock ML, Landa J. A biomechanical comparison of elite and good distance runners. Ann N Y Acad Sci.
1977;301:328–45.
90\. Rassier DE, MacIntosh BR, Herzog W. Length dependence of
active force production in skeletal muscle. J Appl Physiol.
1999;86:1445–57.
91\. Carrier D, Heglund N, Earls K. Variable gearing during locomotion in the human musculoskeletal system. Science.
1994;265:651–3.
92\. Royer TD, Martin PE. Manipulations of leg mass and moment of
inertia: effects on energy cost of walking. Med Sci Sports Exerc.
2005;37:649–56.
93\. Santos-Concejero J, Tam N, Granados C, et al. Interaction
effects of stride angle and strike pattern on running economy. Int
J Sports Med. 2014;35:1118–23.
94\. Santos-Concejero J, Granados C, Irazusta J, et al. Differences in
ground contact time explain the less efficient running economy
in North African runners. Biol Sport. 2013;30:181–7.
95\. Messier SP, Cirillo KJ. Effects of a verbal and visual feedback
system on running technique, perceived exertion and running
economy in female novice runners. J Sports Sci.
1989;7:113–26.
96\. Warne JP, Warrington GD. Four-week habituation to simulated
barefoot running improves running economy when compared
with shod running. Scand J Med Sci Sports. 2014;24:563–8.
97\. Hasegawa H, Yamauchi T, Kraemer WJ. Foot strike patterns of
runners at the 15-km point during an elite-level half marathon.
J Strength Cond Res. 2007;21:888–93.
98\. Lieberman DE, Venkadesan M, Werbel WA, et al. Foot strike
patterns and collision forces in habitually barefoot versus shod
runners. Nature. 2010;463:531–5.
99\. Jenkins DW, Cauthon DJ. Barefoot running claims and controversies: a review of the literature. J Am Podiatr Med Assoc.

2011;101:231–46.
100\. Gruber AH, Umberger BR, Braun B, et al. Economy and rate of
carbohydrate oxidation during running with rearfoot and forefoot strike patterns. J Appl Physiol. 2013;115:194–201.
101\. Cunningham CB, Schilling N, Anders C, et al. The influence of
foot posture on the cost of transport in humans. J Exp Biol.
2010;213:790–7.

## 123

102. Ogueta-Alday A, Rodriguez-Marroyo JA, Garcia-Lopez J.
     Rearfoot striking runners are more economical than midfoot
     strikers. Med Sci Sports Exerc. 2014;46:580–5.
001. Farley CT, McMahon TA. Energetics of walking and running:
     insights from simulated reduced-gravity experiments. J Appl
     Physiol. 1992;73:2709–12.
001. Taylor CR, Heglund NC, McMahon TA, et al. Energetic cost of
     generating muscular force during running: a comparison of large
     and small animals. J Exp Biol. 1980;86:9–18.
001. Chang YH, Kram R. Metabolic cost of generating horizontal
     forces during human running. J Appl Physiol. 1999;86:1657–62.
001. Arellano CJ, Kram R. Partitioning the metabolic cost of human
     running: a task-by-task approach. Integr Comp Biol.
     2014;54:1084–98.
001. Moore IS, Jones AM, Dixon SJ. Reduced oxygen cost of running is
     related to alignment of the resultant GRF and leg axis vector: a
     [pilot study. Scand J Med Sci Sports. 2015. doi:10.1111/sms.12514.](http://dx.doi.org/10.1111/sms.12514)
001. Cavagna GA, Franzetti P, Heglund NC, et al. The determinants
     of the step frequency in running, trotting and hopping in man
     and other vertebrates. J Physiol. 1988;399:81–92.
001. Butler RJ, Crowell HP 3rd, Davis IM. Lower extremity stiffness:
     implications for performance and injury. Clin Biomech.
     2003;18:511–7.
001. Divert C, Baur H, Mornieux G, et al. Stiffness adaptations in
     shod running. J Appl Biomech. 2005;21:311–21.
001. Kerdok AE, Biewener AA, McMahon TA, et al. Energetics and
     mechanics of human running on surfaces of different stiffnesses.
     J Appl Physiol. 2002;92:469–78.
001. Lussiana T, Fabre N, Hebert-Losier K, et al. Effect of slope and
     footwear on running economy and kinematics. Scand J Med Sci
     Sports. 2013;23:246–53.
001. Lussiana T, He´bert-Losier K, Mourot L. Effect of minimal shoes
     and slope on vertical and leg stiffness during running. J Sport
     Health Sci. 2015;4:195–202.
001. Morin JB, Samozino P, Zameziati K, et al. Effects of altered
     stride frequency and contact time on leg-spring behavior in
     human running. J Biomech. 2007;40:3341–8.
001. Ruan M, Li L. Approach run increases preactivation and
     eccentric phases muscle activity during drop jumps from different drop heights. J Electromyogr Kinesiol. 2010;20:932–8.
001. Muller R, Grimmer S, Blickhan R. Running on uneven ground:
     leg adjustments by muscle pre-activation control. Hum Mov Sci.
     2010;29:299–310.
001. Boyer KA, Nigg BM. Muscle activity in the leg is tuned in
     response to impact force characteristics. J Biomech.
     2004;37:1583–8.
001. Boyer KA, Nigg BM. Changes in muscle activity in response to
     different impact forces affect soft tissue compartment mechanical properties. J Biomech Eng. 2007;129:594–602.
001. Nigg BM, Stefanyshyn DJ, Cole G, et al. The effect of material
     characteristics of shoe soles on muscle activiation and energy
     aspects during running. J Biomech. 2003;36:569–75.
001. Saunders PU, Pyne DB, Telford RD, et al. Reliability and
     variability of running economy in elite distance runners. Med
     Sci Sports Exerc. 2004;36:1972–6.
001. Bourdin M, Belli A, Arsac LM, et al. Effect of vertical loading
     on energy cost and kinematics of running in trained male subjects. J Appl Physiol. 1995;79:2078–85.
001. Pinnington HC, Dawson B. The energy cost of running on grass
     compared to soft dry beach sand. J Sci Med Sport.
     2001;4:416–30.
001. Pinnington HC, Lloyd DG, Besier TF, et al. Kinematic and
     electromyography analysis of submaximal differences running
     on a firm surface compared with soft, dry sand. Eur J Appl
     Physiol. 2005;94:242–53.

Modifiable Biomechanical Factors Affecting Running Economy 807

124. Chapman AR, Vicenzino B, Blanch P, et al. Is running less
     skilled in triathletes than runners matched for running training
     history? Med Sci Sports Exerc. 2008;40:557–65.
001. Montgomery WH 3rd, Pink M, Perry J. Electromyographic
     analysis of hip and knee musculature during running. Am J
     Sports Med. 1994;22:272–8.
001. Kelly LA, Girard O, Racinais S. Effect of orthoses on changes in
     neuromuscular control and eerobic cost of a 1-h run. Med Sci

Sports Exerc. 2011;43:2335–43.
127\. Burke JR, Papuga MO. Effects of foot orthotics on running
economy: methodological considerations. J Manip Physiol Ther.
2012;35:327–36.
128\. Burkett LN, Kohrt WM, Buchbinder R. Effects of shoes and foot
orthotics on VO2 and selected frontal plane knee kinematics.
Med Sci Sports Exerc. 1985;17:158–63.
129\. Fuller JT, Bellenger CR, Thewlis D, et al. The effect of footwear
on running performance and running economy in distance runners. Sports Med. 2014;45:411–22.
130\. Scholz MN, Bobbert MF, Van Soest AJ, et al. Running
biomechanics: shorter heels, better economy. J Exp Biol.
2008;211:3266–71.
131\. Roy J-PR, Stefanyshyn DJ. Shoe midsole longitudinal bending
stiffness and running economy, joint energy, and EMG. Med Sci
Sports Exerc. 2006;38:562–9.
132\. Luo G, Stergiou P, Worobets J, et al. Improved footwear comfort reduces oxygen consumption during running. Footwear Sci.
2009;1:25–9.
133\. Frederick EC, Howley ET, Powers S. Lower oxygen demands of
running in soft-soled shoes. Res Q Exerc Sport. 1986;57:174–7.
134\. Frederick EC, Clarke TE, Larsen JL, et al. The effect of shoe
cushioning on the oxygen demands on running. In: Nigg BM,
Kerr BA, editors. Biomechanical aspects of sports shoes and
playing surfaces. Calgary: University of Calgary; 1983.
p. 107–14.
135\. Lejeune TM, Willems PA, Heglund NC. Mechanics and energetics of human locomotion on sand. J Exp Biol.
1998;201:2071–80.
136\. Chen C-H, Tu K-H, Liu C, et al. Effects of forefoot bending
elasticity of running shoes on gait and running performance.
Hum Mov Sci. 2014;38:163–72.
137\. McCallion C, Donne B, Fleming N, et al. Acute differences in
foot strike and spatiotemporal variables for shod, barefoot or
minimalist male runners. J Sports Sci Med. 2014;13:280–6.
138\. Vincent HK, Montero C, Conrad BP, et al. Metabolic responses
of running shod and barefoot in mid-forefoot runners. J Sports
Med Phys Fit. 2014;54:447–55.
139\. De Wit B, De Clercq D, Aerts P. Biomechanical analysis of the
stance phase during barefoot and shod running. J Biomech.
2000;33:269–78.
140\. Moore IS, Pitt W, Nunns M, et al. Effects of a seven-week
minimalist footwear transition programme on footstrike
modality, pressure variables and loading rates. Footwear Sci.
2014;7:17–29.
141\. Chambon N, Delattre N, Gueguen N, et al. Is midsole thickness
a key parameter for the running pattern? Gait Posture.
2014;40:58–63.
142\. Squadrone R, Gallozzi C. Biomechanical and physiological
comparison of barefoot and two shod conditions in experienced
barefoot runners. J Sports Med Phys Fitness. 2009;49:6–13.
143\. Paquette MR, Zhang S, Baumgartner LD. Acute effects of
barefoot, minimal shoes and running shoes on lower limb
mechanics in rear and forefoot strike runners. Footwear Sci.

2013;5:9–18.

144. Hamill J, Russell E, Gruber A, et al. Impact characteristics in
     shod and barefoot running. Footwear Sci. 2011;3:33–40.
001. Breine B, Malcolm P, Frederick EC, et al. Relationship between
     running apeed and initial foot contact patterns. Med Sci Sports
     Exerc. 2014;46:1595–603. [doi:10.249/MSS.](http://dx.doi.org/10.249/MSS.0000000000000267)

[0000000000000267.](http://dx.doi.org/10.249/MSS.0000000000000267)

146. Allison HG, JuliaFreedman S, Peter B, et al. Footfall patterns
     during barefoot running on harder and softer surfaces. Footwear
     Sci. 2013;5:39–44.
001. Moore IS, Dixon SJ. Changes in sagittal plane kinematics with
     treadmill familiarization to barefoot running. J Appl Biomech.
     2014;30:626–31.
001. Hinrichs RN. Upper extremity function in running II: angular
     momentum considerations. J Appl Biomech. 1987;3:242–63.
001. Arellano CJ, Kram R. The metabolic cost of human running: is
     swinging the arms worth it? J Exp Biol. 2014;217:2456–61.
001. Pontzer H, Holloway JH 4th, Raichlen DA, et al. Control and
     function of arm swing in human walking and running. J Exp
     Biol. 2009;212:523–34.
001. Miller RH, Caldwell GE, Van Emmerik RE, et al. Ground
     reaction forces and lower extremity kinematics when running
     with suppressed arm swing. J Biomech Eng. 2009;131:124502.
001. White JL, Scurr JC, Smith NA. The effect of breast support on
     kinetics during overground running performance. Ergonomics.
     2009;52:492–8.
001. Milligan A, Mills C, Corbett J, et al. The influence of breast
     support on torso, pelvis and arm kinematics during a five kilometer treadmill run. Hum Mov Sci. 2015;42:246–60.
001. Milligan A. The effect of breast support on running biome[chanics. PhD thesis. University of Portsmouth; 2013. http://](http://eprints.port.ac.uk/14846/)
     [eprints.port.ac.uk/14846/. Accessed 10 Dec 2015.](http://eprints.port.ac.uk/14846/)
001. Morgan DW, Martin P, Craib M, et al. Effect of step length
     optimization on the aerobic demand of running. J Appl Physiol.
     1994;77:245–51.
001. Bailey SP, Messier SP. Variations in stride length and running
     economy in male novice runners subsequent to a seven-week
     training program. Int J Sports Med. 1991;12:299–304.
001. Dallam GM, Wilber RL, Jadelis K, et al. Effect of a global
     alteration of running technique on kinematics and economy.
     J Sports Sci. 2005;23:757–64.
001. Romanov N, Fletcher G. Runners do not push off the ground but
     fall forwards via a gravitational torque. Sports Biomech.
     2007;6:434–52.
001. Crowell HP, Davis IS. Gait retraining to reduce lower extremity
     loading in runners. Clin Biomech. 2011;26:78–83.
001. Davis IS, Crowell HP, Fellin RE, et al. Reduced impact loading
     following gait retraining over a 6-month period. Gait Posture.
     2009;30:S4–5.
001. Diebal AR, Gregory R, Alitz C, et al. Forefoot running improves
     pain and disability associated with chronic exertional compartment syndrome. Am J Physiol. 2012;40:1060–7.
001. Willy RW, Scholz JP, Davis IS. Mirror gait retraining for the
     treatment of patellofemoral pain in female runners. Clin Biomech. 2012;27:1045–51.
001. Clansey AC, Hanlon M, Wallace ES, et al. Influence of tibial
     shock feedback training on impact loading and running economy. Med Sci Sports Exerc. 2014;46:973–81.
001. Willwacher S, Ko¨nig M, Braunstein B, et al. The gearing
     function of running shoe longitudinal bending stiffness. Gait
     Posture. 2014;40:386–90.
001. Williams KR. Biomechanical factors contributing to marathon
     race success. Sports Med. 2007;37:420–3.

## 123
