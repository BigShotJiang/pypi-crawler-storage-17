from glassdome_waypoint_sdk.api.external.waypoint.v1beta1.site_pb2 import Site

__all__ = [
    "Site",
]
