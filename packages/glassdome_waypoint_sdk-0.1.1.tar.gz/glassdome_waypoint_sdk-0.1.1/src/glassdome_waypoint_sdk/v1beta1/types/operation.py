from glassdome_waypoint_sdk.api.external.waypoint.v1beta1.operation_pb2 import (
    Operation,
    OperationReturnOptions,
)

__all__ = [
    "Operation",
    "OperationReturnOptions",
]
