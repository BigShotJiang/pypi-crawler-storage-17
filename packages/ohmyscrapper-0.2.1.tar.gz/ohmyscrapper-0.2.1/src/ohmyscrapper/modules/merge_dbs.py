import ohmyscrapper.models.urls_manager as urls_manager


def merge_dbs():
    urls_manager.merge_dbs()
    return
