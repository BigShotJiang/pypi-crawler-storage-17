:mod:`schedule`
===============

.. toctree::
   :maxdepth: 1

   schedule/base
   schedule/mlflow

.. currentmodule:: fkat.pytorch.schedule

.. automodule:: fkat.pytorch.schedule
   :members:
   :undoc-members:
