:mod:`monitoring`
=================

.. toctree::
   :maxdepth: 1

   dp

.. currentmodule:: fkat.pytorch.callbacks.monitoring

.. automodule:: fkat.pytorch.callbacks.monitoring
   :members:
   :undoc-members:
