:mod:`batch`
============

.. currentmodule:: fkat.pytorch.actions.aws.batch

.. automodule:: fkat.pytorch.actions.aws.batch
   :members:
   :undoc-members:
