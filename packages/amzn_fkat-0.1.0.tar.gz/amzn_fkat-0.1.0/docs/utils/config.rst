:mod:`config`
=============

.. currentmodule:: fkat.utils.config

.. automodule:: fkat.utils.config
   :members:
   :undoc-members:
