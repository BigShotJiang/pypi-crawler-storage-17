:mod:`shm`
==========

.. currentmodule:: fkat.utils.shm

.. automodule:: fkat.utils.shm
   :members:
   :undoc-members:
