:mod:`rng`
==========

.. currentmodule:: fkat.utils.rng

.. automodule:: fkat.utils.rng
   :members:
   :undoc-members:
