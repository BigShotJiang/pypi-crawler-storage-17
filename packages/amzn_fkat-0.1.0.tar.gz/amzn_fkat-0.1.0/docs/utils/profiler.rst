:mod:`profiler`
===============

.. currentmodule:: fkat.utils.profiler

.. automodule:: fkat.utils.profiler
   :members:
   :undoc-members:
