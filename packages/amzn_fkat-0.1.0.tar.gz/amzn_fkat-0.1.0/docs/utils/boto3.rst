:mod:`boto3`
=============

.. currentmodule:: fkat.utils.boto3

.. automodule:: fkat.utils.boto3
   :members:
   :undoc-members:
