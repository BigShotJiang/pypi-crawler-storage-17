:mod:`xid`
==========

.. currentmodule:: fkat.utils.cuda.xid

.. automodule:: fkat.utils.cuda.xid
   :members:
   :undoc-members:
