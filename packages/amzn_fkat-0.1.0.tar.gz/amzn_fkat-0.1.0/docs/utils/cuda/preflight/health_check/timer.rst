:mod:`timer`
============

.. currentmodule:: fkat.utils.cuda.preflight.health_check.timer

.. automodule:: fkat.utils.cuda.preflight.health_check.timer
   :members:
   :undoc-members: