:mod:`aws`
==========

.. toctree::
   :maxdepth: 1

   aws/imds
