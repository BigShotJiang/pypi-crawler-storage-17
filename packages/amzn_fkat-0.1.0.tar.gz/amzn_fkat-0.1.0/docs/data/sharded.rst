ShardedDataLoader
=================

.. currentmodule:: fkat.data

.. autoclass:: ShardedDataLoader
   :members:
   :undoc-members:
   :show-inheritance:
