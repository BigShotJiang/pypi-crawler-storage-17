ShmDataLoader
=============

.. currentmodule:: fkat.data

.. autoclass:: ShmDataLoader
   :members:
   :undoc-members:
   :show-inheritance:
