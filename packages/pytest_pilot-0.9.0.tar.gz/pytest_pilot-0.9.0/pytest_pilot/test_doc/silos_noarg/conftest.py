from pytest_pilot import EasyMarker

envid = EasyMarker('envid', has_arg=False, mode='silos')

