from pytest_pilot import EasyMarker

envid = EasyMarker('envid', mode='silos')

