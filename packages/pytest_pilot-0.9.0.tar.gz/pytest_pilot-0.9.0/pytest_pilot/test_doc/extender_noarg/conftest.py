from pytest_pilot import EasyMarker

slow = EasyMarker('slow', has_arg=False, mode='extender')

