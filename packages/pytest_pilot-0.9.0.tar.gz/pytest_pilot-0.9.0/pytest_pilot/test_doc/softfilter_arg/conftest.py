from pytest_pilot import EasyMarker

flavour = EasyMarker('flavour', allowed_values=('red', 'yellow'), mode='soft_filter')
