"""Central configuration for expt_logger."""

# Default API base URL
# Change this value to switch to production endpoint
DEFAULT_BASE_URL = "https://expt-platform.vercel.app/"
