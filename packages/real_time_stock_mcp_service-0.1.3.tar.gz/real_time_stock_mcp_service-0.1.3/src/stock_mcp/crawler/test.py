from src.stock_mcp.crawler.market import MarketSpider
market_spider = MarketSpider()
stock_billboard_data = market_spider.get_stock_billboard_data("603019.SH")