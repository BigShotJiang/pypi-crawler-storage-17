#################################
Account Invoice Correction Module
#################################

The *Account Invoice Correction Module* adds a wizard which allows the
correction of unit prices on posted invoice lines.
A new invoice is created with those lines in double: once with the original
quantity, once with the inverted quantity.

.. toctree::
   :maxdepth: 2

   design
   releases
