"""Deprecated: BridgeMiddleware moved to core.middleware."""

from agentic_fleet.core.middleware import BridgeMiddleware

__all__ = ["BridgeMiddleware"]
