"""API v1 package.

Follows the FastAPI full-stack template convention of grouping versioned
endpoints under `api/api_v1/`.
"""
