// Shared contexts - barrel export
export { ThemeProvider } from "./ThemeContext";
export type { Theme } from "./theme-context";
