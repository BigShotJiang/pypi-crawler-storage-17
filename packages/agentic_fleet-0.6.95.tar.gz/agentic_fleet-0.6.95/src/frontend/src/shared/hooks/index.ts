// Shared hooks - barrel export
export { useTheme } from "./useTheme";
export { useIsMobile } from "./useMobile";
