## Reporting a Vulnerability

We appreciate any security concerns brought to our attention and encourage you to notify us of any potential vulnerabilities discovered in our systems or products.
If you believe you have found a security vulnerability, please report it to us at [security@databricks.com](mailto:security@databricks.com).
