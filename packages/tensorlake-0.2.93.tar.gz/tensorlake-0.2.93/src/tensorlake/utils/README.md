## Overview

Put here common functionality that is useful for code written in Python.
