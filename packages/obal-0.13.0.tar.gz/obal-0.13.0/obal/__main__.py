"""
Main module file. This allows you to run python -m obal
"""
from obal import main  # pylint:disable=no-name-in-module
main()
