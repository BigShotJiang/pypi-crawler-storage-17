# -*- coding: utf-8 -*-
"""AiiDA plugin for DFTK."""
__version__ = '0.1.0'
