from moxn.types import base


class Schema(base.BaseSchema): ...
