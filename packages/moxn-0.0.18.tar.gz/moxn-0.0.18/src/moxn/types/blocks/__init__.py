# Content blocks for moxn types
