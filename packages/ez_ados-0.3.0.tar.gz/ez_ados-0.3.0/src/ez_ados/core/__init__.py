"""Core API module."""
