from __future__ import annotations

from pathlib import Path

import joblib
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

from mlops.core import process, log_metric


def _load_xy(csv_path: str | Path):
    df = pd.read_csv(Path(csv_path))
    y = df.pop("label").values
    x = df.values
    return x, y


@process(description="Train a tiny classifier")
def train_model(context=None):
    x, y = _load_xy(context.data_paths["training"])
    model = LogisticRegression(max_iter=200)
    model.fit(x, y)

    train_acc = float(accuracy_score(y, model.predict(x)))
    log_metric("accuracy", train_acc, step=1)

    ckpt_dir = Path(context.checkpoint_dir)
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    model_path = ckpt_dir / "model.joblib"
    joblib.dump(model, model_path)

    return {"model_path": str(model_path), "train_accuracy": train_acc}


@process(description="Evaluate the model")
def evaluate_model(context=None, data=None):
    model_path = (data or {}).get("train_model", {}).get("model_path")
    model = joblib.load(model_path)

    val_path = context.data_paths.get("validation") or context.data_paths["training"]
    x, y = _load_xy(val_path)
    eval_acc = float(accuracy_score(y, model.predict(x)))
    log_metric("accuracy", eval_acc, step=1)

    return {"evaluation_accuracy": eval_acc}

