"""Metrics aggregation and processing.

Functions for parsing and aggregating metrics from various sources.
"""

from __future__ import annotations

__all__ = []
