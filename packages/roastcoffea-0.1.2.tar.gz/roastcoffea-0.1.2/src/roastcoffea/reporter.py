"""Rich table formatters for metrics reporting.

Provides functions to format metrics as Rich tables for terminal display.
"""

from __future__ import annotations
