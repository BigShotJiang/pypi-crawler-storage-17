"""Tests for individual plot functions."""
