#!/usr/bin/env python3
"""
Build script for compiling Nimbus PySDK Cython extensions.

This script handles:
1. Converting .py files to .pyx for Cython compilation
2. Building platform-specific binary extensions
3. Creating distribution wheels for multiple platforms

Usage:
    # Build extensions in-place (for development)
    python scripts/build_extensions.py --inplace

    # Build wheel for distribution
    python scripts/build_extensions.py --wheel

    # Clean all build artifacts
    python scripts/build_extensions.py --clean

    # Full build: convert, compile, wheel
    python scripts/build_extensions.py --full
"""

import argparse
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path


# Root directory of the project
ROOT_DIR = Path(__file__).parent.parent.resolve()

# Modules to protect with Cython compilation
PROTECTED_MODULES = [
    "nimbus_bci/models/nimbus_lda/learning.py",
    "nimbus_bci/models/nimbus_lda/inference.py",
    "nimbus_bci/models/nimbus_gmm/learning.py",
    "nimbus_bci/models/nimbus_gmm/inference.py",
    "nimbus_bci/models/nimbus_softmax/learning.py",
    "nimbus_bci/models/nimbus_softmax/inference.py",
]


def check_dependencies():
    """Check that required build dependencies are installed."""
    missing = []
    
    try:
        import Cython
        print(f"[OK] Cython {Cython.__version__}")
    except ImportError:
        missing.append("Cython>=3.0")
    
    try:
        import numpy
        print(f"[OK] NumPy {numpy.__version__}")
    except ImportError:
        missing.append("numpy")
    
    if missing:
        print(f"\n[ERROR] Missing dependencies: {', '.join(missing)}")
        print(f"Install with: pip install {' '.join(missing)}")
        sys.exit(1)
    
    print()


def convert_to_pyx():
    """Convert protected .py modules to .pyx for Cython compilation."""
    print("Converting .py files to .pyx...")
    converted = []
    
    for module_path in PROTECTED_MODULES:
        py_file = ROOT_DIR / module_path
        pyx_file = py_file.with_suffix(".pyx")
        
        if not py_file.exists():
            print(f"  [WARN] Source not found: {py_file}")
            continue
        
        # Copy .py to .pyx (Cython compiles .pyx files)
        shutil.copy2(py_file, pyx_file)
        converted.append(pyx_file)
        print(f"  [OK] {module_path} -> {pyx_file.name}")
    
    print(f"\nConverted {len(converted)} files\n")
    return converted


def build_inplace():
    """Build Cython extensions in-place for development."""
    print("Building extensions in-place...")
    
    result = subprocess.run(
        [sys.executable, "setup.py", "build_ext", "--inplace"],
        cwd=ROOT_DIR,
        capture_output=True,
        text=True,
    )
    
    if result.returncode != 0:
        print(f"[ERROR] Build failed:\n{result.stderr}")
        sys.exit(1)
    
    print(result.stdout)
    print("[OK] Extensions built successfully\n")
    
    # List compiled extensions
    list_extensions()


def build_wheel():
    """Build a wheel package with compiled extensions."""
    print("Building wheel package...")
    
    # Clean previous builds
    for path in ["build", "dist"]:
        full_path = ROOT_DIR / path
        if full_path.exists():
            shutil.rmtree(full_path)
    
    result = subprocess.run(
        [sys.executable, "-m", "build", "--wheel"],
        cwd=ROOT_DIR,
        capture_output=True,
        text=True,
    )
    
    if result.returncode != 0:
        print(f"[ERROR] Wheel build failed:\n{result.stderr}")
        print("Try: pip install build")
        sys.exit(1)
    
    print(result.stdout)
    
    # List created wheels
    dist_dir = ROOT_DIR / "dist"
    if dist_dir.exists():
        wheels = list(dist_dir.glob("*.whl"))
        print(f"\n[OK] Created {len(wheels)} wheel(s):")
        for wheel in wheels:
            print(f"  {wheel.name}")
    print()


def list_extensions():
    """List compiled extension files."""
    print("Compiled extensions:")
    
    ext = ".pyd" if platform.system() == "Windows" else ".so"
    extensions = list(ROOT_DIR.rglob(f"*{ext}"))
    
    for ext_file in extensions:
        rel_path = ext_file.relative_to(ROOT_DIR)
        size_kb = ext_file.stat().st_size / 1024
        print(f"  {rel_path} ({size_kb:.1f} KB)")
    
    if not extensions:
        print("  (none found)")
    print()


def clean():
    """Remove all build artifacts."""
    print("Cleaning build artifacts...")
    
    patterns_to_remove = [
        "*.so",
        "*.pyd", 
        "*.c",
        "*.cpp",
        "*.pyx",  # Generated .pyx files
        "*.html",  # Cython annotation files
    ]
    
    dirs_to_remove = [
        "build",
        "dist",
        "*.egg-info",
        "cython_debug",
        ".pyarmor",
    ]
    
    removed_count = 0
    
    # Remove files
    for pattern in patterns_to_remove:
        for file in ROOT_DIR.rglob(pattern):
            # Don't remove original source files
            if file.suffix == ".pyx" and file.with_suffix(".py").exists():
                # This is a generated .pyx, safe to remove
                pass
            elif file.suffix in [".so", ".pyd", ".c", ".cpp", ".html"]:
                pass
            else:
                continue
            
            try:
                file.unlink()
                print(f"  Removed: {file.relative_to(ROOT_DIR)}")
                removed_count += 1
            except Exception as e:
                print(f"  [WARN] Could not remove {file}: {e}")
    
    # Remove directories
    for pattern in dirs_to_remove:
        for dir_path in ROOT_DIR.glob(pattern):
            if dir_path.is_dir():
                try:
                    shutil.rmtree(dir_path)
                    print(f"  Removed: {dir_path.relative_to(ROOT_DIR)}/")
                    removed_count += 1
                except Exception as e:
                    print(f"  [WARN] Could not remove {dir_path}: {e}")
    
    print(f"\n[OK] Cleaned {removed_count} items\n")


def remove_source_from_wheel():
    """
    Post-process wheel to remove .py source files for protected modules.
    
    This ensures only compiled .so/.pyd files are distributed, not the
    original Python source code.
    """
    print("Removing source files from wheel...")
    
    dist_dir = ROOT_DIR / "dist"
    if not dist_dir.exists():
        print("  No dist/ directory found")
        return
    
    # This would require unpacking, modifying, and repacking the wheel
    # For production, use `cibuildwheel` which handles this properly
    print("  [INFO] For production wheels, use cibuildwheel or manually exclude .py files")
    print()


def main():
    parser = argparse.ArgumentParser(
        description="Build Nimbus PySDK Cython extensions"
    )
    parser.add_argument(
        "--inplace", action="store_true",
        help="Build extensions in-place for development"
    )
    parser.add_argument(
        "--wheel", action="store_true",
        help="Build wheel package for distribution"
    )
    parser.add_argument(
        "--clean", action="store_true",
        help="Remove all build artifacts"
    )
    parser.add_argument(
        "--convert", action="store_true",
        help="Convert .py files to .pyx only"
    )
    parser.add_argument(
        "--full", action="store_true",
        help="Full build: convert, compile, create wheel"
    )
    parser.add_argument(
        "--list", action="store_true",
        help="List compiled extensions"
    )
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("Nimbus PySDK Extension Builder")
    print(f"Platform: {platform.system()} {platform.machine()}")
    print(f"Python: {sys.version.split()[0]}")
    print("=" * 60)
    print()
    
    if args.clean:
        clean()
        return
    
    if args.list:
        list_extensions()
        return
    
    check_dependencies()
    
    if args.convert or args.full:
        convert_to_pyx()
    
    if args.inplace or args.full:
        build_inplace()
    
    if args.wheel or args.full:
        build_wheel()
    
    if not any([args.inplace, args.wheel, args.clean, args.convert, args.full, args.list]):
        parser.print_help()


if __name__ == "__main__":
    main()


