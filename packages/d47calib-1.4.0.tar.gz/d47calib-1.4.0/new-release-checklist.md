# New Release Checklist

1. Bump `D47calib.__version__`
2. Update `changelog.md`
3. `make`
4. `git commit`
5. `git push`
6. Create new release on GitHub
7. `flit publish`