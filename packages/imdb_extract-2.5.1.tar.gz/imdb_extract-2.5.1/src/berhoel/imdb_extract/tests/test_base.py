"""Basic tests for IMDBExtract."""
