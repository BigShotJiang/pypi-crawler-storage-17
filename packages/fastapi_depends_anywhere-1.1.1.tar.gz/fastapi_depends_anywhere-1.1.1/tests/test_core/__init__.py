"""Tests for fastapi_depends_anywhere.core module."""
