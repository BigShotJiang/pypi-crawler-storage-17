"""Tests for fastapi_depends_anywhere.runners module."""
