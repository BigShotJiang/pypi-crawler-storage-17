from ...base import Instance
from ...const import PLUGIN_SIGNATURES

class BasicTelegramBot01(Instance):
  signature = PLUGIN_SIGNATURES.TELEGRAM_BASIC_BOT_01


