"""Markers for HTTP-based protocols."""
