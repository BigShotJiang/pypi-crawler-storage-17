"""
Support for [HTTPX][1] client – requires `combadge[httpx]` extra.

[1]: https://www.python-httpx.org/
"""
