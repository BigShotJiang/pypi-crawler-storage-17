"""
Client-independent SOAP support.

!!! tip "SOAP is an HTTP-based protocol"

    This packages provides implementations specific to SOAP.
    The generic HTTP features are available as a part of HTTP support.
"""
