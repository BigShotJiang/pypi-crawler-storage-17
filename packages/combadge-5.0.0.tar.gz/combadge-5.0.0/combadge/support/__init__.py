"""Support for specific standards and clients."""
