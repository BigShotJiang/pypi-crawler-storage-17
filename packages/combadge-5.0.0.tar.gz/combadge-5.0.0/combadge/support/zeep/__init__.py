"""
Support for [Zeep][1] client – requires `combadge[zeep]` extra.

[1]: https://docs.python-zeep.org/
"""
