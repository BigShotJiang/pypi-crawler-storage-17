## Features

- [ ] Nicely display different types of LiteLLM errors
    - [ ] Not authorized
    - [ ] Model not found
    - [ ] Provider not found (?)
    - [ ] Rate Limit
    - [ ] Others


## Bugs