"""Outstation tests."""
