"""DNP3 Objects unit tests."""
