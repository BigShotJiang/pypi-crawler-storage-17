"""Tests for DNP3 database module."""
