# Master module tests
