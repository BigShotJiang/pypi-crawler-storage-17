"""Integration tests for DNP3 master/outstation communication."""
