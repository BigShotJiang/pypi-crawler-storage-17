"""Pure Python DNP3 implementation (IEEE 1815-2012)."""

__version__ = "0.1.0"
