"""
Serializers package for Amazon Bedrock model data.
Contains implementations for serializing model data to various formats.
"""
