"""Internal parsers for AWS service responses."""

from .textract_parser import TextractParser

__all__ = ["TextractParser"]
