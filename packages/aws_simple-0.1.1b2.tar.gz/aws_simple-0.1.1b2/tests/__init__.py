"""Tests for aws-simple library."""
