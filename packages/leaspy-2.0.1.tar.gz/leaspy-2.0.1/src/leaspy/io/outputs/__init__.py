from .individual_parameters import IndividualParameters
from .result import Result

__all__ = ["IndividualParameters", "Result"]
