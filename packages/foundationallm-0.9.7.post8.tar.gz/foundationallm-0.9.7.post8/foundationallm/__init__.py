""" 
FoundationaLLM module
"""

from ._version import __version__
