=====
Usage
=====

To use lognflow in a project::

    import lognflow
