def main():
    print("Hello from dsts!")


if __name__ == "__main__":
    main()
