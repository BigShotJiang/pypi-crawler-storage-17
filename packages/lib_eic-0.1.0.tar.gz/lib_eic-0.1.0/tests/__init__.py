"""Tests for LCMS Adduct Finder."""
