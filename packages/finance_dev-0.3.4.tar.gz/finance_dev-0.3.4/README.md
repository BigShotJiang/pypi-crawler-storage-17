# finance-dev

Developer-friendly & type-safe Python SDK specifically catered to leverage *finance-dev* API.

<div align="left">
    <a href="https://www.speakeasy.com/?utm_source=finance-dev&utm_campaign=python"><img src="https://custom-icon-badges.demolab.com/badge/-Built%20By%20Speakeasy-212015?style=for-the-badge&logoColor=FBE331&logo=speakeasy&labelColor=545454" /></a>
    <a href="https://opensource.org/licenses/MIT">
        <img src="https://img.shields.io/badge/License-MIT-blue.svg" style="width: 100px; height: 28px;" />
    </a>
</div>


<br /><br />
> [!IMPORTANT]
> This SDK is not yet ready for production use. To complete setup please follow the steps outlined in your [workspace](https://app.speakeasy.com/org/aries/aries). Delete this section before > publishing to a package manager.

<!-- Start Summary [summary] -->
## Summary

Aries Trading Platform API: Complete API documentation for the Aries trading platform including user management, authentication, account management, order management, market data, and analytics
<!-- End Summary [summary] -->

<!-- Start Table of Contents [toc] -->
## Table of Contents
<!-- $toc-max-depth=2 -->
* [finance-dev](#finance-dev)
  * [SDK Installation](#sdk-installation)
  * [IDE Support](#ide-support)
  * [SDK Example Usage](#sdk-example-usage)
  * [Authentication](#authentication)
  * [Available Resources and Operations](#available-resources-and-operations)
  * [Retries](#retries)
  * [Error Handling](#error-handling)
  * [Server Selection](#server-selection)
  * [Custom HTTP Client](#custom-http-client)
  * [Resource Management](#resource-management)
  * [Debugging](#debugging)
* [Development](#development)
  * [Maturity](#maturity)
  * [Contributions](#contributions)

<!-- End Table of Contents [toc] -->

<!-- Start SDK Installation [installation] -->
## SDK Installation

> [!NOTE]
> **Python version upgrade policy**
>
> Once a Python version reaches its [official end of life date](https://devguide.python.org/versions/), a 3-month grace period is provided for users to upgrade. Following this grace period, the minimum python version supported in the SDK will be updated.

The SDK can be installed with *uv*, *pip*, or *poetry* package managers.

### uv

*uv* is a fast Python package installer and resolver, designed as a drop-in replacement for pip and pip-tools. It's recommended for its speed and modern Python tooling capabilities.

```bash
uv add finance-dev
```

### PIP

*PIP* is the default package installer for Python, enabling easy installation and management of packages from PyPI via the command line.

```bash
pip install finance-dev
```

### Poetry

*Poetry* is a modern tool that simplifies dependency management and package publishing by using a single `pyproject.toml` file to handle project metadata and dependencies.

```bash
poetry add finance-dev
```

### Shell and script usage with `uv`

You can use this SDK in a Python shell with [uv](https://docs.astral.sh/uv/) and the `uvx` command that comes with it like so:

```shell
uvx --from finance-dev python
```

It's also possible to write a standalone Python script without needing to set up a whole project like so:

```python
#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.9"
# dependencies = [
#     "finance-dev",
# ]
# ///

from finance_dev import FinanceDev

sdk = FinanceDev(
  # SDK arguments
)

# Rest of script here...
```

Once that is saved to a file, you can run it with `uv run script.py` where
`script.py` can be replaced with the actual file name.
<!-- End SDK Installation [installation] -->

<!-- Start IDE Support [idesupport] -->
## IDE Support

### PyCharm

Generally, the SDK will work well with most IDEs out of the box. However, when using PyCharm, you can enjoy much better integration with Pydantic by installing an additional plugin.

- [PyCharm Pydantic Plugin](https://docs.pydantic.dev/latest/integrations/pycharm/)
<!-- End IDE Support [idesupport] -->

<!-- Start SDK Example Usage [usage] -->
## SDK Example Usage

### Example

```python
# Synchronous Example
from finance_dev import FinanceDev
import os


with FinanceDev(
    bearer_auth=os.getenv("FINANCEDEV_BEARER_AUTH", ""),
) as fd_client:

    res = fd_client.accounts.get_balances(id="<id>")

    # Handle response
    print(res)
```

</br>

The same SDK client can also be used to make asynchronous requests by importing asyncio.

```python
# Asynchronous Example
import asyncio
from finance_dev import FinanceDev
import os

async def main():

    async with FinanceDev(
        bearer_auth=os.getenv("FINANCEDEV_BEARER_AUTH", ""),
    ) as fd_client:

        res = await fd_client.accounts.get_balances_async(id="<id>")

        # Handle response
        print(res)

asyncio.run(main())
```
<!-- End SDK Example Usage [usage] -->

<!-- Start Authentication [security] -->
## Authentication

### Per-Client Security Schemes

This SDK supports the following security scheme globally:

| Name          | Type | Scheme      | Environment Variable     |
| ------------- | ---- | ----------- | ------------------------ |
| `bearer_auth` | http | HTTP Bearer | `FINANCEDEV_BEARER_AUTH` |

To authenticate with the API the `bearer_auth` parameter must be set when initializing the SDK client instance. For example:
```python
from finance_dev import FinanceDev
import os


with FinanceDev(
    bearer_auth=os.getenv("FINANCEDEV_BEARER_AUTH", ""),
) as fd_client:

    res = fd_client.accounts.get_balances(id="<id>")

    # Handle response
    print(res)

```
<!-- End Authentication [security] -->

<!-- Start Available Resources and Operations [operations] -->
## Available Resources and Operations

<details open>
<summary>Available methods</summary>

### [Accounts](docs/sdks/accounts/README.md)

* [get_balances](docs/sdks/accounts/README.md#get_balances) - Get Account Balances
* [get_orders](docs/sdks/accounts/README.md#get_orders) - Get Account Orders
* [get_positions](docs/sdks/accounts/README.md#get_positions) - Get Account Positions

### [Analytics](docs/sdks/analytics/README.md)

* [get_top_gainers](docs/sdks/analytics/README.md#get_top_gainers) - Get Top Gaining Stocks
* [get_top_losers](docs/sdks/analytics/README.md#get_top_losers) - Get Top Losing Stocks
* [get_most_active](docs/sdks/analytics/README.md#get_most_active) - Get Most Active Stocks
* [get_sector_tickers](docs/sdks/analytics/README.md#get_sector_tickers) - Get Sector Tickers
* [get_sector_wise_change](docs/sdks/analytics/README.md#get_sector_wise_change) - Get Sector-wise Change
* [get_top_options_gainers](docs/sdks/analytics/README.md#get_top_options_gainers) - Get Top Options Gainers for Stocks
* [get_top_volume_options](docs/sdks/analytics/README.md#get_top_volume_options) - Get Top Volume Options for Stocks
* [get_options_top_volume](docs/sdks/analytics/README.md#get_options_top_volume) - Get Top Volume Options for ETFs
* [get_ratings](docs/sdks/analytics/README.md#get_ratings) - Get Analyst Ratings
* [get_market_breadth](docs/sdks/analytics/README.md#get_market_breadth) - Get Market Breadth
* [get_net_inflow](docs/sdks/analytics/README.md#get_net_inflow) - Get Net Inflow

### [Calendars](docs/sdks/calendars/README.md)

* [get_economics](docs/sdks/calendars/README.md#get_economics) - Get Economics Calendar
* [get_historical_data](docs/sdks/calendars/README.md#get_historical_data) - Get Economic Indicator Historical Data
* [get_earnings](docs/sdks/calendars/README.md#get_earnings) - Get Earnings Calendar

### [Chart](docs/sdks/chart/README.md)

* [get_config](docs/sdks/chart/README.md#get_config) - Get Chart Configuration
* [get_symbol](docs/sdks/chart/README.md#get_symbol) - Get Symbol Information
* [get_history](docs/sdks/chart/README.md#get_history) - Get Historical Chart Data
* [get_time](docs/sdks/chart/README.md#get_time) - Get Server Time
* [get_quotes](docs/sdks/chart/README.md#get_quotes) - Get Real-Time Quotes

### [Clients](docs/sdks/clients/README.md)

* [get_all](docs/sdks/clients/README.md#get_all) - Get All Clients
* [create](docs/sdks/clients/README.md#create) - Create OAuth2 Client
* [update](docs/sdks/clients/README.md#update) - Update OAuth2 Client
* [delete](docs/sdks/clients/README.md#delete) - Delete OAuth2 Client
* [update_status](docs/sdks/clients/README.md#update_status) - Update Client Status

### [Config](docs/sdks/config/README.md)

* [get_user_settings](docs/sdks/config/README.md#get_user_settings) - Get Requested User Settings

### [Health](docs/sdks/health/README.md)

* [check](docs/sdks/health/README.md#check) - Health Check

### [MarketData](docs/sdks/marketdata/README.md)

* [get_equity_details](docs/sdks/marketdata/README.md#get_equity_details) - Get equity details

### [News](docs/sdks/news/README.md)

* [get](docs/sdks/news/README.md#get) - Get News

### [Oauth2](docs/sdks/oauth2/README.md)

* [authorize](docs/sdks/oauth2/README.md#authorize) - OAuth2 Authorize
* [confirm_authorization](docs/sdks/oauth2/README.md#confirm_authorization) - OAuth2 Authorize Confirm
* [authorize_mfa](docs/sdks/oauth2/README.md#authorize_mfa) - OAuth2 Authorize MFA
* [get_token](docs/sdks/oauth2/README.md#get_token) - OAuth2 Token

### [Orders](docs/sdks/orders/README.md)

* [place](docs/sdks/orders/README.md#place) - Place Order
* [update](docs/sdks/orders/README.md#update) - Update Order
* [cancel](docs/sdks/orders/README.md#cancel) - Cancel Order
* [preview](docs/sdks/orders/README.md#preview) - Preview Order

### [Settings](docs/sdks/settings/README.md)

* [get](docs/sdks/settings/README.md#get) - Get Settings
* [create](docs/sdks/settings/README.md#create) - Create Setting
* [update](docs/sdks/settings/README.md#update) - Update Setting
* [delete](docs/sdks/settings/README.md#delete) - Delete Settings
* [get_by_key](docs/sdks/settings/README.md#get_by_key) - Get Setting by Key
* [toggle_feature_flag](docs/sdks/settings/README.md#toggle_feature_flag) - Toggle Feature Flag

### [UserManagement](docs/sdks/usermanagement/README.md)

* [get_profile](docs/sdks/usermanagement/README.md#get_profile) - Get User Profile
* [change_email](docs/sdks/usermanagement/README.md#change_email) - Change Email
* [set_trading_password](docs/sdks/usermanagement/README.md#set_trading_password) - Set Trading Password

### [Users](docs/sdks/users/README.md)

* [create](docs/sdks/users/README.md#create) - Create User
* [get_current](docs/sdks/users/README.md#get_current) - Get Current User
* [update_current](docs/sdks/users/README.md#update_current) - Update Current User
* [get_accounts](docs/sdks/users/README.md#get_accounts) - Get User Accounts

### [UserSettings](docs/sdks/usersettings/README.md)

* [get](docs/sdks/usersettings/README.md#get) - Get User Settings
* [create](docs/sdks/usersettings/README.md#create) - Create User Setting
* [update](docs/sdks/usersettings/README.md#update) - Update User Setting
* [delete](docs/sdks/usersettings/README.md#delete) - Delete User Settings
* [get_by_key](docs/sdks/usersettings/README.md#get_by_key) - Get User Setting by Key
* [reset](docs/sdks/usersettings/README.md#reset) - Reset User Settings
* [get_user_settings](docs/sdks/usersettings/README.md#get_user_settings) - Get Requested User Settings

### [Watchlist](docs/sdks/watchlistsdk/README.md)

* [get](docs/sdks/watchlistsdk/README.md#get) - Get Account Watchlists
* [create_or_update](docs/sdks/watchlistsdk/README.md#create_or_update) - Create or Update Watchlist
* [delete_by_account_id](docs/sdks/watchlistsdk/README.md#delete_by_account_id) - Delete All Watchlists by Account ID
* [get_by_id](docs/sdks/watchlistsdk/README.md#get_by_id) - Get Watchlist by ID
* [remove_by_id](docs/sdks/watchlistsdk/README.md#remove_by_id) - Delete Watchlist by ID
* [upsert](docs/sdks/watchlistsdk/README.md#upsert) - Create or Update Watchlists
* [delete](docs/sdks/watchlistsdk/README.md#delete) - Delete Watchlist

</details>
<!-- End Available Resources and Operations [operations] -->

<!-- Start Retries [retries] -->
## Retries

Some of the endpoints in this SDK support retries. If you use the SDK without any configuration, it will fall back to the default retry strategy provided by the API. However, the default retry strategy can be overridden on a per-operation basis, or across the entire SDK.

To change the default retry strategy for a single API call, simply provide a `RetryConfig` object to the call:
```python
from finance_dev import FinanceDev
from finance_dev.utils import BackoffStrategy, RetryConfig
import os


with FinanceDev(
    bearer_auth=os.getenv("FINANCEDEV_BEARER_AUTH", ""),
) as fd_client:

    res = fd_client.accounts.get_balances(id="<id>",
        RetryConfig("backoff", BackoffStrategy(1, 50, 1.1, 100), False))

    # Handle response
    print(res)

```

If you'd like to override the default retry strategy for all operations that support retries, you can use the `retry_config` optional parameter when initializing the SDK:
```python
from finance_dev import FinanceDev
from finance_dev.utils import BackoffStrategy, RetryConfig
import os


with FinanceDev(
    retry_config=RetryConfig("backoff", BackoffStrategy(1, 50, 1.1, 100), False),
    bearer_auth=os.getenv("FINANCEDEV_BEARER_AUTH", ""),
) as fd_client:

    res = fd_client.accounts.get_balances(id="<id>")

    # Handle response
    print(res)

```
<!-- End Retries [retries] -->

<!-- Start Error Handling [errors] -->
## Error Handling

[`FinanceDevError`](./src/finance_dev/errors/financedeverror.py) is the base class for all HTTP error responses. It has the following properties:

| Property           | Type             | Description                                                                             |
| ------------------ | ---------------- | --------------------------------------------------------------------------------------- |
| `err.message`      | `str`            | Error message                                                                           |
| `err.status_code`  | `int`            | HTTP response status code eg `404`                                                      |
| `err.headers`      | `httpx.Headers`  | HTTP response headers                                                                   |
| `err.body`         | `str`            | HTTP body. Can be empty string if no body is returned.                                  |
| `err.raw_response` | `httpx.Response` | Raw HTTP response                                                                       |
| `err.data`         |                  | Optional. Some errors may contain structured data. [See Error Classes](#error-classes). |

### Example
```python
from finance_dev import FinanceDev, errors
import os


with FinanceDev(
    bearer_auth=os.getenv("FINANCEDEV_BEARER_AUTH", ""),
) as fd_client:
    res = None
    try:

        res = fd_client.accounts.get_balances(id="<id>")

        # Handle response
        print(res)


    except errors.FinanceDevError as e:
        # The base class for HTTP error responses
        print(e.message)
        print(e.status_code)
        print(e.body)
        print(e.headers)
        print(e.raw_response)

        # Depending on the method different errors may be thrown
        if isinstance(e, errors.ErrorResponse):
            print(e.data.error)  # Optional[str]
            print(e.data.codes)  # Optional[List[models.Code]]
```

### Error Classes
**Primary error:**
* [`FinanceDevError`](./src/finance_dev/errors/financedeverror.py): The base class for HTTP error responses.

<details><summary>Less common errors (9)</summary>

<br />

**Network errors:**
* [`httpx.RequestError`](https://www.python-httpx.org/exceptions/#httpx.RequestError): Base class for request errors.
    * [`httpx.ConnectError`](https://www.python-httpx.org/exceptions/#httpx.ConnectError): HTTP client was unable to make a request to a server.
    * [`httpx.TimeoutException`](https://www.python-httpx.org/exceptions/#httpx.TimeoutException): HTTP request timed out.


**Inherit from [`FinanceDevError`](./src/finance_dev/errors/financedeverror.py)**:
* [`ErrorResponse`](./src/finance_dev/errors/errorresponse.py): Applicable to 48 of 66 methods.*
* [`BadRequestError`](./src/finance_dev/errors/badrequesterror.py): Bad request - Invalid request body or setting already exists. Status code `400`. Applicable to 4 of 66 methods.*
* [`UnauthorizedError`](./src/finance_dev/errors/unauthorizederror.py): Unauthorized. Status code `401`. Applicable to 4 of 66 methods.*
* [`InternalServerError`](./src/finance_dev/errors/internalservererror.py): Internal server error. Status code `500`. Applicable to 4 of 66 methods.*
* [`ResponseValidationError`](./src/finance_dev/errors/responsevalidationerror.py): Type mismatch between the response data and the expected Pydantic model. Provides access to the Pydantic validation error via the `cause` attribute.

</details>

\* Check [the method documentation](#available-resources-and-operations) to see if the error is applicable.
<!-- End Error Handling [errors] -->

<!-- Start Server Selection [server] -->
## Server Selection

### Override Server URL Per-Client

The default server can be overridden globally by passing a URL to the `server_url: str` optional parameter when initializing the SDK client instance. For example:
```python
from finance_dev import FinanceDev
import os


with FinanceDev(
    server_url="https://api.tradearies.dev",
    bearer_auth=os.getenv("FINANCEDEV_BEARER_AUTH", ""),
) as fd_client:

    res = fd_client.accounts.get_balances(id="<id>")

    # Handle response
    print(res)

```
<!-- End Server Selection [server] -->

<!-- Start Custom HTTP Client [http-client] -->
## Custom HTTP Client

The Python SDK makes API calls using the [httpx](https://www.python-httpx.org/) HTTP library.  In order to provide a convenient way to configure timeouts, cookies, proxies, custom headers, and other low-level configuration, you can initialize the SDK client with your own HTTP client instance.
Depending on whether you are using the sync or async version of the SDK, you can pass an instance of `HttpClient` or `AsyncHttpClient` respectively, which are Protocol's ensuring that the client has the necessary methods to make API calls.
This allows you to wrap the client with your own custom logic, such as adding custom headers, logging, or error handling, or you can just pass an instance of `httpx.Client` or `httpx.AsyncClient` directly.

For example, you could specify a header for every request that this sdk makes as follows:
```python
from finance_dev import FinanceDev
import httpx

http_client = httpx.Client(headers={"x-custom-header": "someValue"})
s = FinanceDev(client=http_client)
```

or you could wrap the client with your own custom logic:
```python
from finance_dev import FinanceDev
from finance_dev.httpclient import AsyncHttpClient
import httpx

class CustomClient(AsyncHttpClient):
    client: AsyncHttpClient

    def __init__(self, client: AsyncHttpClient):
        self.client = client

    async def send(
        self,
        request: httpx.Request,
        *,
        stream: bool = False,
        auth: Union[
            httpx._types.AuthTypes, httpx._client.UseClientDefault, None
        ] = httpx.USE_CLIENT_DEFAULT,
        follow_redirects: Union[
            bool, httpx._client.UseClientDefault
        ] = httpx.USE_CLIENT_DEFAULT,
    ) -> httpx.Response:
        request.headers["Client-Level-Header"] = "added by client"

        return await self.client.send(
            request, stream=stream, auth=auth, follow_redirects=follow_redirects
        )

    def build_request(
        self,
        method: str,
        url: httpx._types.URLTypes,
        *,
        content: Optional[httpx._types.RequestContent] = None,
        data: Optional[httpx._types.RequestData] = None,
        files: Optional[httpx._types.RequestFiles] = None,
        json: Optional[Any] = None,
        params: Optional[httpx._types.QueryParamTypes] = None,
        headers: Optional[httpx._types.HeaderTypes] = None,
        cookies: Optional[httpx._types.CookieTypes] = None,
        timeout: Union[
            httpx._types.TimeoutTypes, httpx._client.UseClientDefault
        ] = httpx.USE_CLIENT_DEFAULT,
        extensions: Optional[httpx._types.RequestExtensions] = None,
    ) -> httpx.Request:
        return self.client.build_request(
            method,
            url,
            content=content,
            data=data,
            files=files,
            json=json,
            params=params,
            headers=headers,
            cookies=cookies,
            timeout=timeout,
            extensions=extensions,
        )

s = FinanceDev(async_client=CustomClient(httpx.AsyncClient()))
```
<!-- End Custom HTTP Client [http-client] -->

<!-- Start Resource Management [resource-management] -->
## Resource Management

The `FinanceDev` class implements the context manager protocol and registers a finalizer function to close the underlying sync and async HTTPX clients it uses under the hood. This will close HTTP connections, release memory and free up other resources held by the SDK. In short-lived Python programs and notebooks that make a few SDK method calls, resource management may not be a concern. However, in longer-lived programs, it is beneficial to create a single SDK instance via a [context manager][context-manager] and reuse it across the application.

[context-manager]: https://docs.python.org/3/reference/datamodel.html#context-managers

```python
from finance_dev import FinanceDev
import os
def main():

    with FinanceDev(
        bearer_auth=os.getenv("FINANCEDEV_BEARER_AUTH", ""),
    ) as fd_client:
        # Rest of application here...


# Or when using async:
async def amain():

    async with FinanceDev(
        bearer_auth=os.getenv("FINANCEDEV_BEARER_AUTH", ""),
    ) as fd_client:
        # Rest of application here...
```
<!-- End Resource Management [resource-management] -->

<!-- Start Debugging [debug] -->
## Debugging

You can setup your SDK to emit debug logs for SDK requests and responses.

You can pass your own logger class directly into your SDK.
```python
from finance_dev import FinanceDev
import logging

logging.basicConfig(level=logging.DEBUG)
s = FinanceDev(debug_logger=logging.getLogger("finance_dev"))
```

You can also enable a default debug logger by setting an environment variable `FINANCEDEV_DEBUG` to true.
<!-- End Debugging [debug] -->

<!-- Placeholder for Future Speakeasy SDK Sections -->

# Development

## Maturity

This SDK is in beta, and there may be breaking changes between versions without a major version update. Therefore, we recommend pinning usage
to a specific package version. This way, you can install the same version each time without breaking changes unless you are intentionally
looking for the latest version.

## Contributions

While we value open-source contributions to this SDK, this library is generated programmatically. Any manual changes added to internal files will be overwritten on the next generation. 
We look forward to hearing your feedback. Feel free to open a PR or an issue with a proof of concept and we'll do our best to include it in a future release. 

### SDK Created by [Speakeasy](https://www.speakeasy.com/?utm_source=finance-dev&utm_campaign=python)
