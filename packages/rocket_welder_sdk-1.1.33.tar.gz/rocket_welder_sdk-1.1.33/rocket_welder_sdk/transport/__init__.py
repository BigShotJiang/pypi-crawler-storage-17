"""
Transport layer for RocketWelder SDK.

Provides transport-agnostic frame sink/source abstractions for protocols.
"""

from .frame_sink import IFrameSink
from .frame_source import IFrameSource
from .nng_transport import NngFrameSink, NngFrameSource
from .stream_transport import StreamFrameSink, StreamFrameSource
from .tcp_transport import TcpFrameSink, TcpFrameSource
from .unix_socket_transport import (
    UnixSocketFrameSink,
    UnixSocketFrameSource,
    UnixSocketServer,
)

__all__ = [
    "IFrameSink",
    "IFrameSource",
    "NngFrameSink",
    "NngFrameSource",
    "StreamFrameSink",
    "StreamFrameSource",
    "TcpFrameSink",
    "TcpFrameSource",
    "UnixSocketFrameSink",
    "UnixSocketFrameSource",
    "UnixSocketServer",
]

# NNG transport is optional (requires pynng package)
try:
    from .nng_transport import NngFrameSink, NngFrameSource

    __all__.extend(["NngFrameSink", "NngFrameSource"])
except ImportError:
    pass  # pynng not installed
