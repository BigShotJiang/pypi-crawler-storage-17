-- simple
create conversion c 
  for ''
  to '' 
  from f;

-- full
create default conversion foo.bar.c 
  for '' 
  to '' 
  from foo.bar;

