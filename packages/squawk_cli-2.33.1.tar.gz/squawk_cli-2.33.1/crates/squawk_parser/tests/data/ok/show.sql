show time zone;
show transaction isolation level;
show session authorization;
show all;

show v;
show a.b;
show a.b.c.d;
