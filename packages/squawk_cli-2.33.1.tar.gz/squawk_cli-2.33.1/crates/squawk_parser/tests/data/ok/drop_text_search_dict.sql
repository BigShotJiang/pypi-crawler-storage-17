-- simple
drop text search dictionary foo;

-- full
drop text search dictionary if exists bar cascade;

-- restrict
drop text search dictionary bar restrict;

