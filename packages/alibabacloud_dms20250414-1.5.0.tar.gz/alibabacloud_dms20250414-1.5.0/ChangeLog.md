2025-12-16 Version: 1.4.1
- Update API CreateDataAgentSession: add request parameters SessionConfig.McpServerIds.
- Update API CreateDataAgentSession: add response parameters Body.Data.SessionConfig.McpServerIds.
- Update API DescribeDataAgentSession: add response parameters Body.Data.SessionConfig.McpServerIds.


2025-12-09 Version: 1.4.0
- Support API CreateDataAgentSession.
- Support API DescribeDataAgentSession.


2025-12-09 Version: 1.3.0
- Support API GetChatContent.
- Support API GetNotebookTaskStatus.
- Support API SendChatMessage.


2025-10-22 Version: 1.2.0
- Support API GetNotebookAndSubmitTask.


2025-08-26 Version: 1.1.0
- Support API BatchCreateDataLakePartitions.
- Support API BatchDeleteDataLakePartitions.
- Support API BatchUpdateDataLakePartitions.
- Support API CreateAirflow.
- Support API CreateDataLakeDatabase.
- Support API CreateDataLakeFunction.
- Support API CreateDataLakePartition.
- Support API CreateDataLakeTable.
- Support API DeleteAirflow.
- Support API DeleteDataLakeDatabase.
- Support API DeleteDataLakeFunction.
- Support API DeleteDataLakePartition.
- Support API DeleteDataLakeTable.
- Support API GetAirflow.
- Support API GetDataLakeCatalog.
- Support API GetDataLakeDatabase.
- Support API GetDataLakeFunction.
- Support API GetDataLakePartition.
- Support API GetDataLakeTable.
- Support API ListAirflows.
- Support API ListDataLakeCatalog.
- Support API ListDataLakeDatabase.
- Support API ListDataLakeFunction.
- Support API ListDataLakeFunctionName.
- Support API ListDataLakePartition.
- Support API ListDataLakePartitionByFilter.
- Support API ListDataLakePartitionName.
- Support API ListDataLakeTable.
- Support API ListDataLakeTableName.
- Support API ListDataLakeTablebaseInfo.
- Support API UpdateAirflow.
- Support API UpdateDataLakeDatabase.
- Support API UpdateDataLakeFunction.
- Support API UpdateDataLakePartition.
- Support API UpdateDataLakeTable.


2025-06-05 Version: 1.0.0
- Generated python 2025-04-14 for Dms.

