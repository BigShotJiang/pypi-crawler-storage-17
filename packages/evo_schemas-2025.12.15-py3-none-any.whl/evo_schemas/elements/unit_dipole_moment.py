import enum


class UnitDipoleMoment_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_C_m = "C.m"
