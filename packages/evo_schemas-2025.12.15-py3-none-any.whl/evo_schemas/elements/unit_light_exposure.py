import enum


class UnitLightExposure_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_lx_s = "lx.s"
    Unit_footcandle_s = "footcandle.s"
