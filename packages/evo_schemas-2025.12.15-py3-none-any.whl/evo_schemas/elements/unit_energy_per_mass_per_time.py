import enum


class UnitEnergyPerMassPerTime_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_Sv_per_s = "Sv/s"
    Unit_mrem_per_h = "mrem/h"
    Unit_mSv_per_h = "mSv/h"
    Unit_rem_per_h = "rem/h"
    Unit_Sv_per_h = "Sv/h"
