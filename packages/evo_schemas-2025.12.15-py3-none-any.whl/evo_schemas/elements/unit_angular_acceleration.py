import enum


class UnitAngularAcceleration_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_rad_per_s2 = "rad/s2"
    Unit_rpm_per_s = "rpm/s"
