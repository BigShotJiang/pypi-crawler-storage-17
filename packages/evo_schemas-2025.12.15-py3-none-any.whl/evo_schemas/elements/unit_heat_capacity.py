import enum


class UnitHeatCapacity_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_J_per_deltaK = "J/deltaK"
