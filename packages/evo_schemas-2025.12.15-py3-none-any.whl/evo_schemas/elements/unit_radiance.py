import enum


class UnitRadiance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_W_per_m2_sr = "W/(m2.sr)"
