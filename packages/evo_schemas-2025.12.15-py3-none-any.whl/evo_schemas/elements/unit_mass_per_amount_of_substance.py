import enum


class UnitMassPerAmountOfSubstance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_kg_per_mol = "kg/mol"
    Unit_g_per_mol = "g/mol"
    Unit_lbm_per_lbmol = "lbm/lbmol"
