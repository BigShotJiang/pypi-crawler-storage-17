import enum


class UnitElectricFieldStrength_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_V_per_m = "V/m"
    Unit_mV_per_ft = "mV/ft"
    Unit_mV_per_m = "mV/m"
    Unit_uV_per_ft = "uV/ft"
    Unit_uV_per_m = "uV/m"
