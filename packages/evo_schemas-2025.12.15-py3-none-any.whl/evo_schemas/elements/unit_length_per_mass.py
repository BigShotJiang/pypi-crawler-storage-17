import enum


class UnitLengthPerMass_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_m_per_kg = "m/kg"
    Unit_ft_per_lbm = "ft/lbm"
