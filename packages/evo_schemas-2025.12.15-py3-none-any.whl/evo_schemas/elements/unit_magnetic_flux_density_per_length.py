import enum


class UnitMagneticFluxDensityPerLength_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_T_per_m = "T/m"
    Unit_gauss_per_cm = "gauss/cm"
    Unit_mT_per_dm = "mT/dm"
