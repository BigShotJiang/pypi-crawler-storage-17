import enum


class UnitInductance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_H = "H"
    Unit_cH = "cH"
    Unit_dH = "dH"
    Unit_EH = "EH"
    Unit_fH = "fH"
    Unit_GH = "GH"
    Unit_kH = "kH"
    Unit_mH = "mH"
    Unit_MH = "MH"
    Unit_nH = "nH"
    Unit_TH = "TH"
    Unit_uH = "uH"
