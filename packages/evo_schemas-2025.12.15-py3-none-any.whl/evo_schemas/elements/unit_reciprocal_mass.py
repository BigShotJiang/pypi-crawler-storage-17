import enum


class UnitReciprocalMass_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_1_per_g = "1/g"
    Unit_1_per_lbm = "1/lbm"
    Unit_1_per_kg = "1/kg"
