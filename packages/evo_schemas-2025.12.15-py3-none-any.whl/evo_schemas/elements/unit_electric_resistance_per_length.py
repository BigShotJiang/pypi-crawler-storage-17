import enum


class UnitElectricResistancePerLength_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_ohm_per_m = "ohm/m"
    Unit_uohm_per_ft = "uohm/ft"
    Unit_uohm_per_m = "uohm/m"
