import enum


class UnitElectricConductivity_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_S_per_m = "S/m"
    Unit_kS_per_m = "kS/m"
    Unit_mS_per_cm = "mS/cm"
    Unit_mS_per_m = "mS/m"
