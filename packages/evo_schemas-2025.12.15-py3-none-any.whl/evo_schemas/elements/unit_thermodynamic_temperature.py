import enum


class UnitThermodynamicTemperature_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_K = "K"
    Unit_degC = "degC"
    Unit_degF = "degF"
    Unit_degR = "degR"
