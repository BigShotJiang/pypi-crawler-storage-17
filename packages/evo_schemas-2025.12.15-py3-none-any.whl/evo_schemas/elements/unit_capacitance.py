import enum


class UnitCapacitance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_F = "F"
    Unit_cF = "cF"
    Unit_dF = "dF"
    Unit_EF = "EF"
    Unit_fF = "fF"
    Unit_GF = "GF"
    Unit_kF = "kF"
    Unit_mF = "mF"
    Unit_MF = "MF"
    Unit_nF = "nF"
    Unit_pF = "pF"
    Unit_TF = "TF"
    Unit_uF = "uF"
