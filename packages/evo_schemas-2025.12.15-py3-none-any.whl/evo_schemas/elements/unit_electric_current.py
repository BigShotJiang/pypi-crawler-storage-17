import enum


class UnitElectricCurrent_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_A = "A"
    Unit_cA = "cA"
    Unit_dA = "dA"
    Unit_EA = "EA"
    Unit_fA = "fA"
    Unit_GA = "GA"
    Unit_kA = "kA"
    Unit_mA = "mA"
    Unit_MA = "MA"
    Unit_nA = "nA"
    Unit_pA = "pA"
    Unit_TA = "TA"
    Unit_uA = "uA"
