import enum


class UnitElectricChargePerMass_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_A_s_per_kg = "A.s/kg"
    Unit_C_per_g = "C/g"
    Unit_C_per_kg = "C/kg"
