import enum


class UnitVolumePerTimeLength_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_m4_per_s = "m4/s"
    Unit_1000_bbl_ft_per_d = "1000 bbl.ft/d"
    Unit_1000_m4_per_d = "1000 m4/d"
