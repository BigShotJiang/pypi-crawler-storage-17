import enum


class UnitElectricChargePerVolume_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_A_s_per_m3 = "A.s/m3"
    Unit_C_per_cm3 = "C/cm3"
    Unit_C_per_mm3 = "C/mm3"
    Unit_C_per_m3 = "C/m3"
