import enum


class UnitReluctance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_1_per_H = "1/H"
