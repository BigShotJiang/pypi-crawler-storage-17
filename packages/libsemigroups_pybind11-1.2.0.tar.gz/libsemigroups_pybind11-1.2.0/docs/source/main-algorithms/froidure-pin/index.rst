..
    Copyright (c) 2021-2024 J. D. Mitchell

    Distributed under the terms of the GPL license version 3.

    The full license is in the file LICENSE, distributed with this software.

Froidure-Pin
============

The functionality in ``libsemigroups_pybind11`` related to the Froidure-Pin
algorithm :cite:`Froidure1997aa` is contained in the class and the helper
functions below.

.. toctree::
    :maxdepth: 1

    class
    helpers
    to-froidure-pin
