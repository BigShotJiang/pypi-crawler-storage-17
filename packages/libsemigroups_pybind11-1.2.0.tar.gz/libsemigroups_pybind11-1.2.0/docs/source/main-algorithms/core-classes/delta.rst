..
    Copyright (c) 2025 Joseph Edwards

    Distributed under the terms of the GPL license version 3.

    The full license is in the file LICENSE, distributed with this software.

.. currentmodule:: _libsemigroups_pybind11

The delta function
==================

This page contains the documentation for the :py:func:`delta` function. 

.. autofunction:: delta
