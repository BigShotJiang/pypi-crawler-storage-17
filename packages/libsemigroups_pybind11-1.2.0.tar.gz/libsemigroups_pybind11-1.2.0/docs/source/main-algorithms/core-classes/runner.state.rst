..
    Copyright (c) 2025 Joseph Edwards

    Distributed under the terms of the GPL license version 3.

    The full license is in the file LICENSE, distributed with this software.

The Runner.state class
======================

This page defines the :any:`Runner.state` enum.

.. autoclass:: libsemigroups_pybind11::Runner.state
    :class-doc-from: class
    :members:
    :exclude-members: name