..
    Copyright (c) 2025, Joseph Edwards

    Distributed under the terms of the GPL license version 3.

    The full license is in the file LICENSE, distributed with this software.

.. currentmodule:: libsemigroups_pybind11

The ReportGuard class
=======================

.. autoclass:: ReportGuard
    :doc-only:
    :class-doc-from: class

Full API
--------

.. autoclass:: ReportGuard
    :members:
    :class-doc-from: init
