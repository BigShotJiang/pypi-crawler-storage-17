..
    Copyright (c) 2025 Joseph Edwards

    Distributed under the terms of the GPL license version 3.

    The full license is in the file LICENSE, distributed with this software.

Partitioned binary relations (PBRs)
===================================

This page describes the functionality for partitioned binary relations (PBRs) in
``libsemigroups_pybind11``.

.. toctree::
    :maxdepth: 1

    class
    helpers
