..
    Copyright (c) 2024 J. D. Mitchell

    Distributed under the terms of the GPL license version 3.

    The full license is in the file LICENSE, distributed with this software.

The Dot.Edge class
==================

.. autoclass:: libsemigroups_pybind11.Dot.Edge
    :class-doc-from: class
    :members:
