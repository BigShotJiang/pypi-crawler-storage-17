.. _libsemigroups: https://libsemigroups.github.io/libsemigroups/
.. _issue tracker: https://github.com/libsemigroups/libsemigroups_pybind11/issues
.. _DOT: https://www.graphviz.org/doc/info/lang.html
.. _Graphviz: https://www.graphviz.org
.. _pybind11: https://pybind11.readthedocs.io/en/stable/#
.. _HPCombi: https://libsemigroups.github.io/HPCombi/
