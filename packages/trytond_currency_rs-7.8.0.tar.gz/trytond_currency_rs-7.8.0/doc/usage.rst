*****
Usage
*****

In order to fetch currency rates from the Serbian National Bank, you need to
`apply to open a user account
<https://nbs.rs/en/drugi-nivo-navigacije/servisi/sistem-veb-servisa-NBS/index.html>`_.
