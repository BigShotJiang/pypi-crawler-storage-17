from typing import TypedDict

class GetDataEndpointResponse(TypedDict):
    DataEndpoint: str