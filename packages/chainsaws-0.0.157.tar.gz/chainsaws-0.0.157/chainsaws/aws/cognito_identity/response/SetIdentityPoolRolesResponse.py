from typing import TypedDict


class SetIdentityPoolRolesResponse(TypedDict, total=False):
    Success: bool


