"""
Setup script for Liora package.

For modern pip installations, pyproject.toml is used.
This file exists for backward compatibility.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
