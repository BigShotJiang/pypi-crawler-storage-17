##############################
Account Receivable Rule Module
##############################

The *Account Receivable Rule Module* defines rules to reconcile receivable
between accounts.

.. toctree::
   :maxdepth: 2

   usage
   design
   reference
   releases
