*****
Usage
*****

.. _Apply automatically account receivable rules:

Apply automatically account receivable rules
============================================

You may want to define a `Scheduled Application of Account Receivable Rules
<model-account.account.receivable.rule>`.
Tryton will apply periodically the rules from all the companies defined on the task.
