*************
API Reference
*************

Rules
=====

.. class:: AccountRuleAbstract

   This abstract_ makes it easy to create :class:`~trytond:trytond.model.Model`
   which implement the receivable rules for other `Account Type
   <account:model-account.account.type>`.


.. class:: AccountRuleAccountAbstract

   This abstract_ completes the creation of the rule.


.. _abstract: https://en.wikipedia.org/wiki/Abstract_type
