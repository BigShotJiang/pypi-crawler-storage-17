# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional

import httpx

from .. import _legacy_response
from ..types import request_forwarding_forward_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import to_streamed_response_wrapper, async_to_streamed_response_wrapper
from .._base_client import make_request_options
from ..types.request_forwarding_forward_response import RequestForwardingForwardResponse

__all__ = ["RequestForwarding", "AsyncRequestForwarding"]


class RequestForwarding(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> RequestForwardingWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Finch-API/finch-api-python#accessing-raw-response-data-eg-headers
        """
        return RequestForwardingWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> RequestForwardingWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Finch-API/finch-api-python#with_streaming_response
        """
        return RequestForwardingWithStreamingResponse(self)

    def forward(
        self,
        *,
        method: str,
        route: str,
        data: Optional[str] | Omit = omit,
        params: Optional[Dict[str, Optional[object]]] | Omit = omit,
        request_headers: Optional[Dict[str, Optional[object]]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RequestForwardingForwardResponse:
        """The Forward API allows you to make direct requests to an employment system.

        If
        Finch's unified API doesn't have a data model that cleanly fits your needs, then
        Forward allows you to push or pull data models directly against an integration's
        API.

        Args:
          method: The HTTP method for the forwarded request. Valid values include: `GET` , `POST`
              , `PUT` , `DELETE` , and `PATCH`.

          route: The URL route path for the forwarded request. This value must begin with a
              forward-slash ( / ) and may only contain alphanumeric characters, hyphens, and
              underscores.

          data: The body for the forwarded request. This value must be specified as either a
              string or a valid JSON object.

          params: The query parameters for the forwarded request. This value must be specified as
              a valid JSON object rather than a query string.

          request_headers: The HTTP headers to include on the forwarded request. This value must be
              specified as an object of key-value pairs. Example:
              `{"Content-Type": "application/xml", "X-API-Version": "v1" }`

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/forward",
            body=maybe_transform(
                {
                    "method": method,
                    "route": route,
                    "data": data,
                    "params": params,
                    "request_headers": request_headers,
                },
                request_forwarding_forward_params.RequestForwardingForwardParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RequestForwardingForwardResponse,
        )


class AsyncRequestForwarding(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncRequestForwardingWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Finch-API/finch-api-python#accessing-raw-response-data-eg-headers
        """
        return AsyncRequestForwardingWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncRequestForwardingWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Finch-API/finch-api-python#with_streaming_response
        """
        return AsyncRequestForwardingWithStreamingResponse(self)

    async def forward(
        self,
        *,
        method: str,
        route: str,
        data: Optional[str] | Omit = omit,
        params: Optional[Dict[str, Optional[object]]] | Omit = omit,
        request_headers: Optional[Dict[str, Optional[object]]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RequestForwardingForwardResponse:
        """The Forward API allows you to make direct requests to an employment system.

        If
        Finch's unified API doesn't have a data model that cleanly fits your needs, then
        Forward allows you to push or pull data models directly against an integration's
        API.

        Args:
          method: The HTTP method for the forwarded request. Valid values include: `GET` , `POST`
              , `PUT` , `DELETE` , and `PATCH`.

          route: The URL route path for the forwarded request. This value must begin with a
              forward-slash ( / ) and may only contain alphanumeric characters, hyphens, and
              underscores.

          data: The body for the forwarded request. This value must be specified as either a
              string or a valid JSON object.

          params: The query parameters for the forwarded request. This value must be specified as
              a valid JSON object rather than a query string.

          request_headers: The HTTP headers to include on the forwarded request. This value must be
              specified as an object of key-value pairs. Example:
              `{"Content-Type": "application/xml", "X-API-Version": "v1" }`

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/forward",
            body=await async_maybe_transform(
                {
                    "method": method,
                    "route": route,
                    "data": data,
                    "params": params,
                    "request_headers": request_headers,
                },
                request_forwarding_forward_params.RequestForwardingForwardParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RequestForwardingForwardResponse,
        )


class RequestForwardingWithRawResponse:
    def __init__(self, request_forwarding: RequestForwarding) -> None:
        self._request_forwarding = request_forwarding

        self.forward = _legacy_response.to_raw_response_wrapper(
            request_forwarding.forward,
        )


class AsyncRequestForwardingWithRawResponse:
    def __init__(self, request_forwarding: AsyncRequestForwarding) -> None:
        self._request_forwarding = request_forwarding

        self.forward = _legacy_response.async_to_raw_response_wrapper(
            request_forwarding.forward,
        )


class RequestForwardingWithStreamingResponse:
    def __init__(self, request_forwarding: RequestForwarding) -> None:
        self._request_forwarding = request_forwarding

        self.forward = to_streamed_response_wrapper(
            request_forwarding.forward,
        )


class AsyncRequestForwardingWithStreamingResponse:
    def __init__(self, request_forwarding: AsyncRequestForwarding) -> None:
        self._request_forwarding = request_forwarding

        self.forward = async_to_streamed_response_wrapper(
            request_forwarding.forward,
        )
