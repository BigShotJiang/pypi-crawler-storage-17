"""
### Typed Bitopro
> A fully typed, validated async client for the Bitopro API

- Details
"""