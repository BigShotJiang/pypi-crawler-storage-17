# Typed Bitopro

> A fully typed, validated async client for the Bitopro API

Use *autocomplete* instead of documentation.

🚧 Under construction.