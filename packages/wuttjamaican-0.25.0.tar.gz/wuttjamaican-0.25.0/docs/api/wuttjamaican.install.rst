
``wuttjamaican.install``
========================

.. automodule:: wuttjamaican.install
   :members:
