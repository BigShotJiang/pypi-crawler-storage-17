"""EDF Carbon Core"""
