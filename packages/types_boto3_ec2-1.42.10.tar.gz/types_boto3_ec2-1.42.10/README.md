<a id="types-boto3-ec2"></a>

# types-boto3-ec2

[![PyPI - types-boto3-ec2](https://img.shields.io/pypi/v/types-boto3-ec2.svg?color=blue)](https://pypi.org/project/types-boto3-ec2/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/types-boto3-ec2.svg?color=blue)](https://pypi.org/project/types-boto3-ec2/)
[![Docs](https://img.shields.io/readthedocs/boto3-stubs.svg?color=blue)](https://youtype.github.io/types_boto3_docs/)
[![PyPI - Downloads](https://static.pepy.tech/badge/types-boto3-ec2)](https://pypistats.org/packages/types-boto3-ec2)

![boto3.typed](https://github.com/youtype/mypy_boto3_builder/raw/main/logo.png)

Type annotations for [boto3 EC2 1.42.10](https://pypi.org/project/boto3/)
compatible with [VSCode](https://code.visualstudio.com/),
[PyCharm](https://www.jetbrains.com/pycharm/),
[Emacs](https://www.gnu.org/software/emacs/),
[Sublime Text](https://www.sublimetext.com/),
[mypy](https://github.com/python/mypy),
[pyright](https://github.com/microsoft/pyright) and other tools.

Generated with
[mypy-boto3-builder 8.12.0](https://github.com/youtype/mypy_boto3_builder).

More information can be found on
[types-boto3](https://pypi.org/project/types-boto3/) page and in
[types-boto3-ec2 docs](https://youtype.github.io/types_boto3_docs/types_boto3_ec2/).

See how it helps you find and fix potential bugs:

![types-boto3 demo](https://github.com/youtype/mypy_boto3_builder/raw/main/demo.gif)

- [types-boto3-ec2](#types-boto3-ec2)
  - [How to install](#how-to-install)
    - [Generate locally (recommended)](<#generate-locally-(recommended)>)
    - [VSCode extension](#vscode-extension)
    - [From PyPI with pip](#from-pypi-with-pip)
  - [How to uninstall](#how-to-uninstall)
  - [Usage](#usage)
    - [VSCode](#vscode)
    - [PyCharm](#pycharm)
    - [Emacs](#emacs)
    - [Sublime Text](#sublime-text)
    - [Other IDEs](#other-ides)
    - [mypy](#mypy)
    - [pyright](#pyright)
    - [Pylint compatibility](#pylint-compatibility)
  - [Explicit type annotations](#explicit-type-annotations)
    - [Client annotations](#client-annotations)
    - [Paginators annotations](#paginators-annotations)
    - [Waiters annotations](#waiters-annotations)
    - [Service Resource annotations](#service-resource-annotations)
    - [Other resources annotations](#other-resources-annotations)
    - [Collections annotations](#collections-annotations)
    - [Literals](#literals)
    - [Type definitions](#type-definitions)
  - [How it works](#how-it-works)
  - [What's new](#what's-new)
    - [Implemented features](#implemented-features)
    - [Latest changes](#latest-changes)
  - [Versioning](#versioning)
  - [Thank you](#thank-you)
  - [Documentation](#documentation)
  - [Support and contributing](#support-and-contributing)

<a id="how-to-install"></a>

## How to install

<a id="generate-locally-(recommended)"></a>

### Generate locally (recommended)

You can generate type annotations for `boto3` package locally with
`mypy-boto3-builder`. Use
[uv](https://docs.astral.sh/uv/getting-started/installation/) for build
isolation.

1. Run mypy-boto3-builder in your package root directory:
   `uvx --with 'boto3==1.42.10' mypy-boto3-builder`
2. Select `boto3` AWS SDK.
3. Add `EC2` service.
4. Use provided commands to install generated packages.

<a id="vscode-extension"></a>

### VSCode extension

Add
[AWS Boto3](https://marketplace.visualstudio.com/items?itemName=Boto3typed.boto3-ide)
extension to your VSCode and run `AWS boto3: Quick Start` command.

Click `Modify` and select `boto3 common` and `EC2`.

<a id="from-pypi-with-pip"></a>

### From PyPI with pip

Install `types-boto3` for `EC2` service.

```bash
# install with boto3 type annotations
python -m pip install 'types-boto3[ec2]'

# Lite version does not provide session.client/resource overloads
# it is more RAM-friendly, but requires explicit type annotations
python -m pip install 'types-boto3-lite[ec2]'

# standalone installation
python -m pip install types-boto3-ec2
```

<a id="how-to-uninstall"></a>

## How to uninstall

```bash
python -m pip uninstall -y types-boto3-ec2
```

<a id="usage"></a>

## Usage

<a id="vscode"></a>

### VSCode

- Install
  [Python extension](https://marketplace.visualstudio.com/items?itemName=ms-python.python)
- Install
  [Pylance extension](https://marketplace.visualstudio.com/items?itemName=ms-python.vscode-pylance)
- Set `Pylance` as your Python Language Server
- Install `types-boto3[ec2]` in your environment:

```bash
python -m pip install 'types-boto3[ec2]'
```

Both type checking and code completion should now work. No explicit type
annotations required, write your `boto3` code as usual.

<a id="pycharm"></a>

### PyCharm

> ⚠️ Due to slow PyCharm performance on `Literal` overloads (issue
> [PY-40997](https://youtrack.jetbrains.com/issue/PY-40997)), it is recommended
> to use [types-boto3-lite](https://pypi.org/project/types-boto3-lite/) until
> the issue is resolved.

> ⚠️ If you experience slow performance and high CPU usage, try to disable
> `PyCharm` type checker and use [mypy](https://github.com/python/mypy) or
> [pyright](https://github.com/microsoft/pyright) instead.

> ⚠️ To continue using `PyCharm` type checker, you can try to replace
> `types-boto3` with
> [types-boto3-lite](https://pypi.org/project/types-boto3-lite/):

```bash
pip uninstall types-boto3
pip install types-boto3-lite
```

Install `types-boto3[ec2]` in your environment:

```bash
python -m pip install 'types-boto3[ec2]'
```

Both type checking and code completion should now work.

<a id="emacs"></a>

### Emacs

- Install `types-boto3` with services you use in your environment:

```bash
python -m pip install 'types-boto3[ec2]'
```

- Install [use-package](https://github.com/jwiegley/use-package),
  [lsp](https://github.com/emacs-lsp/lsp-mode/),
  [company](https://github.com/company-mode/company-mode) and
  [flycheck](https://github.com/flycheck/flycheck) packages
- Install [lsp-pyright](https://github.com/emacs-lsp/lsp-pyright) package

```elisp
(use-package lsp-pyright
  :ensure t
  :hook (python-mode . (lambda ()
                          (require 'lsp-pyright)
                          (lsp)))  ; or lsp-deferred
  :init (when (executable-find "python3")
          (setq lsp-pyright-python-executable-cmd "python3"))
  )
```

- Make sure emacs uses the environment where you have installed `types-boto3`

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="sublime-text"></a>

### Sublime Text

- Install `types-boto3[ec2]` with services you use in your environment:

```bash
python -m pip install 'types-boto3[ec2]'
```

- Install [LSP-pyright](https://github.com/sublimelsp/LSP-pyright) package

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="other-ides"></a>

### Other IDEs

Not tested, but as long as your IDE supports `mypy` or `pyright`, everything
should work.

<a id="mypy"></a>

### mypy

- Install `mypy`: `python -m pip install mypy`
- Install `types-boto3[ec2]` in your environment:

```bash
python -m pip install 'types-boto3[ec2]'
```

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="pyright"></a>

### pyright

- Install `pyright`: `npm i -g pyright`
- Install `types-boto3[ec2]` in your environment:

```bash
python -m pip install 'types-boto3[ec2]'
```

Optionally, you can install `types-boto3` to `typings` directory.

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="pylint-compatibility"></a>

### Pylint compatibility

It is totally safe to use `TYPE_CHECKING` flag in order to avoid
`types-boto3-ec2` dependency in production. However, there is an issue in
`pylint` that it complains about undefined variables. To fix it, set all types
to `object` in non-`TYPE_CHECKING` mode.

```python
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from types_boto3_ec2 import EC2Client, EC2ServiceResource
    from types_boto3_ec2.waiters import BundleTaskCompleteWaiter
    from types_boto3_ec2.paginators import DescribeVolumesPaginator
else:
    EC2Client = object
    EC2ServiceResource = object
    BundleTaskCompleteWaiter = object
    DescribeVolumesPaginator = object

...
```

<a id="explicit-type-annotations"></a>

## Explicit type annotations

<a id="client-annotations"></a>

### Client annotations

`EC2Client` provides annotations for `boto3.client("ec2")`.

```python
from boto3.session import Session

from types_boto3_ec2 import EC2Client

client: EC2Client = Session().client("ec2")

# now client usage is checked by mypy and IDE should provide code completion
```

<a id="paginators-annotations"></a>

### Paginators annotations

`types_boto3_ec2.paginator` module contains type annotations for all
paginators.

```python
from boto3.session import Session

from types_boto3_ec2 import EC2Client
from types_boto3_ec2.paginator import (
    DescribeAddressTransfersPaginator,
    DescribeAddressesAttributePaginator,
    DescribeAwsNetworkPerformanceMetricSubscriptionsPaginator,
    DescribeByoipCidrsPaginator,
    DescribeCapacityBlockExtensionHistoryPaginator,
    DescribeCapacityBlockExtensionOfferingsPaginator,
    DescribeCapacityBlockOfferingsPaginator,
    DescribeCapacityBlockStatusPaginator,
    DescribeCapacityBlocksPaginator,
    DescribeCapacityManagerDataExportsPaginator,
    DescribeCapacityReservationBillingRequestsPaginator,
    DescribeCapacityReservationFleetsPaginator,
    DescribeCapacityReservationsPaginator,
    DescribeCarrierGatewaysPaginator,
    DescribeClassicLinkInstancesPaginator,
    DescribeClientVpnAuthorizationRulesPaginator,
    DescribeClientVpnConnectionsPaginator,
    DescribeClientVpnEndpointsPaginator,
    DescribeClientVpnRoutesPaginator,
    DescribeClientVpnTargetNetworksPaginator,
    DescribeCoipPoolsPaginator,
    DescribeDhcpOptionsPaginator,
    DescribeEgressOnlyInternetGatewaysPaginator,
    DescribeExportImageTasksPaginator,
    DescribeFastLaunchImagesPaginator,
    DescribeFastSnapshotRestoresPaginator,
    DescribeFleetsPaginator,
    DescribeFlowLogsPaginator,
    DescribeFpgaImagesPaginator,
    DescribeHostReservationOfferingsPaginator,
    DescribeHostReservationsPaginator,
    DescribeHostsPaginator,
    DescribeIamInstanceProfileAssociationsPaginator,
    DescribeImageReferencesPaginator,
    DescribeImageUsageReportEntriesPaginator,
    DescribeImageUsageReportsPaginator,
    DescribeImagesPaginator,
    DescribeImportImageTasksPaginator,
    DescribeImportSnapshotTasksPaginator,
    DescribeInstanceConnectEndpointsPaginator,
    DescribeInstanceCreditSpecificationsPaginator,
    DescribeInstanceEventWindowsPaginator,
    DescribeInstanceImageMetadataPaginator,
    DescribeInstanceStatusPaginator,
    DescribeInstanceTopologyPaginator,
    DescribeInstanceTypeOfferingsPaginator,
    DescribeInstanceTypesPaginator,
    DescribeInstancesPaginator,
    DescribeInternetGatewaysPaginator,
    DescribeIpamPoolsPaginator,
    DescribeIpamPrefixListResolverTargetsPaginator,
    DescribeIpamPrefixListResolversPaginator,
    DescribeIpamResourceDiscoveriesPaginator,
    DescribeIpamResourceDiscoveryAssociationsPaginator,
    DescribeIpamScopesPaginator,
    DescribeIpamsPaginator,
    DescribeIpv6PoolsPaginator,
    DescribeLaunchTemplateVersionsPaginator,
    DescribeLaunchTemplatesPaginator,
    DescribeLocalGatewayRouteTableVirtualInterfaceGroupAssociationsPaginator,
    DescribeLocalGatewayRouteTableVpcAssociationsPaginator,
    DescribeLocalGatewayRouteTablesPaginator,
    DescribeLocalGatewayVirtualInterfaceGroupsPaginator,
    DescribeLocalGatewayVirtualInterfacesPaginator,
    DescribeLocalGatewaysPaginator,
    DescribeMacHostsPaginator,
    DescribeMacModificationTasksPaginator,
    DescribeManagedPrefixListsPaginator,
    DescribeMovingAddressesPaginator,
    DescribeNatGatewaysPaginator,
    DescribeNetworkAclsPaginator,
    DescribeNetworkInsightsAccessScopeAnalysesPaginator,
    DescribeNetworkInsightsAccessScopesPaginator,
    DescribeNetworkInsightsAnalysesPaginator,
    DescribeNetworkInsightsPathsPaginator,
    DescribeNetworkInterfacePermissionsPaginator,
    DescribeNetworkInterfacesPaginator,
    DescribePrefixListsPaginator,
    DescribePrincipalIdFormatPaginator,
    DescribePublicIpv4PoolsPaginator,
    DescribeReplaceRootVolumeTasksPaginator,
    DescribeReservedInstancesModificationsPaginator,
    DescribeReservedInstancesOfferingsPaginator,
    DescribeRouteServerEndpointsPaginator,
    DescribeRouteServerPeersPaginator,
    DescribeRouteServersPaginator,
    DescribeRouteTablesPaginator,
    DescribeScheduledInstanceAvailabilityPaginator,
    DescribeScheduledInstancesPaginator,
    DescribeSecurityGroupRulesPaginator,
    DescribeSecurityGroupVpcAssociationsPaginator,
    DescribeSecurityGroupsPaginator,
    DescribeSnapshotTierStatusPaginator,
    DescribeSnapshotsPaginator,
    DescribeSpotFleetInstancesPaginator,
    DescribeSpotFleetRequestsPaginator,
    DescribeSpotInstanceRequestsPaginator,
    DescribeSpotPriceHistoryPaginator,
    DescribeStaleSecurityGroupsPaginator,
    DescribeStoreImageTasksPaginator,
    DescribeSubnetsPaginator,
    DescribeTagsPaginator,
    DescribeTrafficMirrorFiltersPaginator,
    DescribeTrafficMirrorSessionsPaginator,
    DescribeTrafficMirrorTargetsPaginator,
    DescribeTransitGatewayAttachmentsPaginator,
    DescribeTransitGatewayConnectPeersPaginator,
    DescribeTransitGatewayConnectsPaginator,
    DescribeTransitGatewayMulticastDomainsPaginator,
    DescribeTransitGatewayPeeringAttachmentsPaginator,
    DescribeTransitGatewayPolicyTablesPaginator,
    DescribeTransitGatewayRouteTableAnnouncementsPaginator,
    DescribeTransitGatewayRouteTablesPaginator,
    DescribeTransitGatewayVpcAttachmentsPaginator,
    DescribeTransitGatewaysPaginator,
    DescribeTrunkInterfaceAssociationsPaginator,
    DescribeVerifiedAccessEndpointsPaginator,
    DescribeVerifiedAccessGroupsPaginator,
    DescribeVerifiedAccessInstanceLoggingConfigurationsPaginator,
    DescribeVerifiedAccessInstancesPaginator,
    DescribeVerifiedAccessTrustProvidersPaginator,
    DescribeVolumeStatusPaginator,
    DescribeVolumesModificationsPaginator,
    DescribeVolumesPaginator,
    DescribeVpcClassicLinkDnsSupportPaginator,
    DescribeVpcEndpointConnectionNotificationsPaginator,
    DescribeVpcEndpointConnectionsPaginator,
    DescribeVpcEndpointServiceConfigurationsPaginator,
    DescribeVpcEndpointServicePermissionsPaginator,
    DescribeVpcEndpointServicesPaginator,
    DescribeVpcEndpointsPaginator,
    DescribeVpcPeeringConnectionsPaginator,
    DescribeVpcsPaginator,
    DescribeVpnConcentratorsPaginator,
    GetAssociatedIpv6PoolCidrsPaginator,
    GetAwsNetworkPerformanceDataPaginator,
    GetCapacityManagerMetricDataPaginator,
    GetCapacityManagerMetricDimensionsPaginator,
    GetGroupsForCapacityReservationPaginator,
    GetInstanceTypesFromInstanceRequirementsPaginator,
    GetIpamAddressHistoryPaginator,
    GetIpamDiscoveredAccountsPaginator,
    GetIpamDiscoveredResourceCidrsPaginator,
    GetIpamPoolAllocationsPaginator,
    GetIpamPoolCidrsPaginator,
    GetIpamPrefixListResolverRulesPaginator,
    GetIpamPrefixListResolverVersionEntriesPaginator,
    GetIpamPrefixListResolverVersionsPaginator,
    GetIpamResourceCidrsPaginator,
    GetManagedPrefixListAssociationsPaginator,
    GetManagedPrefixListEntriesPaginator,
    GetNetworkInsightsAccessScopeAnalysisFindingsPaginator,
    GetSecurityGroupsForVpcPaginator,
    GetSpotPlacementScoresPaginator,
    GetTransitGatewayAttachmentPropagationsPaginator,
    GetTransitGatewayMulticastDomainAssociationsPaginator,
    GetTransitGatewayPolicyTableAssociationsPaginator,
    GetTransitGatewayPrefixListReferencesPaginator,
    GetTransitGatewayRouteTableAssociationsPaginator,
    GetTransitGatewayRouteTablePropagationsPaginator,
    GetVpnConnectionDeviceTypesPaginator,
    ListImagesInRecycleBinPaginator,
    ListSnapshotsInRecycleBinPaginator,
    SearchLocalGatewayRoutesPaginator,
    SearchTransitGatewayMulticastGroupsPaginator,
)

client: EC2Client = Session().client("ec2")

# Explicit type annotations are optional here
# Types should be correctly discovered by mypy and IDEs
describe_address_transfers_paginator: DescribeAddressTransfersPaginator = client.get_paginator(
    "describe_address_transfers"
)
describe_addresses_attribute_paginator: DescribeAddressesAttributePaginator = client.get_paginator(
    "describe_addresses_attribute"
)
describe_aws_network_performance_metric_subscriptions_paginator: DescribeAwsNetworkPerformanceMetricSubscriptionsPaginator = client.get_paginator(
    "describe_aws_network_performance_metric_subscriptions"
)
describe_byoip_cidrs_paginator: DescribeByoipCidrsPaginator = client.get_paginator(
    "describe_byoip_cidrs"
)
describe_capacity_block_extension_history_paginator: DescribeCapacityBlockExtensionHistoryPaginator = client.get_paginator(
    "describe_capacity_block_extension_history"
)
describe_capacity_block_extension_offerings_paginator: DescribeCapacityBlockExtensionOfferingsPaginator = client.get_paginator(
    "describe_capacity_block_extension_offerings"
)
describe_capacity_block_offerings_paginator: DescribeCapacityBlockOfferingsPaginator = (
    client.get_paginator("describe_capacity_block_offerings")
)
describe_capacity_block_status_paginator: DescribeCapacityBlockStatusPaginator = (
    client.get_paginator("describe_capacity_block_status")
)
describe_capacity_blocks_paginator: DescribeCapacityBlocksPaginator = client.get_paginator(
    "describe_capacity_blocks"
)
describe_capacity_manager_data_exports_paginator: DescribeCapacityManagerDataExportsPaginator = (
    client.get_paginator("describe_capacity_manager_data_exports")
)
describe_capacity_reservation_billing_requests_paginator: DescribeCapacityReservationBillingRequestsPaginator = client.get_paginator(
    "describe_capacity_reservation_billing_requests"
)
describe_capacity_reservation_fleets_paginator: DescribeCapacityReservationFleetsPaginator = (
    client.get_paginator("describe_capacity_reservation_fleets")
)
describe_capacity_reservations_paginator: DescribeCapacityReservationsPaginator = (
    client.get_paginator("describe_capacity_reservations")
)
describe_carrier_gateways_paginator: DescribeCarrierGatewaysPaginator = client.get_paginator(
    "describe_carrier_gateways"
)
describe_classic_link_instances_paginator: DescribeClassicLinkInstancesPaginator = (
    client.get_paginator("describe_classic_link_instances")
)
describe_client_vpn_authorization_rules_paginator: DescribeClientVpnAuthorizationRulesPaginator = (
    client.get_paginator("describe_client_vpn_authorization_rules")
)
describe_client_vpn_connections_paginator: DescribeClientVpnConnectionsPaginator = (
    client.get_paginator("describe_client_vpn_connections")
)
describe_client_vpn_endpoints_paginator: DescribeClientVpnEndpointsPaginator = client.get_paginator(
    "describe_client_vpn_endpoints"
)
describe_client_vpn_routes_paginator: DescribeClientVpnRoutesPaginator = client.get_paginator(
    "describe_client_vpn_routes"
)
describe_client_vpn_target_networks_paginator: DescribeClientVpnTargetNetworksPaginator = (
    client.get_paginator("describe_client_vpn_target_networks")
)
describe_coip_pools_paginator: DescribeCoipPoolsPaginator = client.get_paginator(
    "describe_coip_pools"
)
describe_dhcp_options_paginator: DescribeDhcpOptionsPaginator = client.get_paginator(
    "describe_dhcp_options"
)
describe_egress_only_internet_gateways_paginator: DescribeEgressOnlyInternetGatewaysPaginator = (
    client.get_paginator("describe_egress_only_internet_gateways")
)
describe_export_image_tasks_paginator: DescribeExportImageTasksPaginator = client.get_paginator(
    "describe_export_image_tasks"
)
describe_fast_launch_images_paginator: DescribeFastLaunchImagesPaginator = client.get_paginator(
    "describe_fast_launch_images"
)
describe_fast_snapshot_restores_paginator: DescribeFastSnapshotRestoresPaginator = (
    client.get_paginator("describe_fast_snapshot_restores")
)
describe_fleets_paginator: DescribeFleetsPaginator = client.get_paginator("describe_fleets")
describe_flow_logs_paginator: DescribeFlowLogsPaginator = client.get_paginator("describe_flow_logs")
describe_fpga_images_paginator: DescribeFpgaImagesPaginator = client.get_paginator(
    "describe_fpga_images"
)
describe_host_reservation_offerings_paginator: DescribeHostReservationOfferingsPaginator = (
    client.get_paginator("describe_host_reservation_offerings")
)
describe_host_reservations_paginator: DescribeHostReservationsPaginator = client.get_paginator(
    "describe_host_reservations"
)
describe_hosts_paginator: DescribeHostsPaginator = client.get_paginator("describe_hosts")
describe_iam_instance_profile_associations_paginator: DescribeIamInstanceProfileAssociationsPaginator = client.get_paginator(
    "describe_iam_instance_profile_associations"
)
describe_image_references_paginator: DescribeImageReferencesPaginator = client.get_paginator(
    "describe_image_references"
)
describe_image_usage_report_entries_paginator: DescribeImageUsageReportEntriesPaginator = (
    client.get_paginator("describe_image_usage_report_entries")
)
describe_image_usage_reports_paginator: DescribeImageUsageReportsPaginator = client.get_paginator(
    "describe_image_usage_reports"
)
describe_images_paginator: DescribeImagesPaginator = client.get_paginator("describe_images")
describe_import_image_tasks_paginator: DescribeImportImageTasksPaginator = client.get_paginator(
    "describe_import_image_tasks"
)
describe_import_snapshot_tasks_paginator: DescribeImportSnapshotTasksPaginator = (
    client.get_paginator("describe_import_snapshot_tasks")
)
describe_instance_connect_endpoints_paginator: DescribeInstanceConnectEndpointsPaginator = (
    client.get_paginator("describe_instance_connect_endpoints")
)
describe_instance_credit_specifications_paginator: DescribeInstanceCreditSpecificationsPaginator = (
    client.get_paginator("describe_instance_credit_specifications")
)
describe_instance_event_windows_paginator: DescribeInstanceEventWindowsPaginator = (
    client.get_paginator("describe_instance_event_windows")
)
describe_instance_image_metadata_paginator: DescribeInstanceImageMetadataPaginator = (
    client.get_paginator("describe_instance_image_metadata")
)
describe_instance_status_paginator: DescribeInstanceStatusPaginator = client.get_paginator(
    "describe_instance_status"
)
describe_instance_topology_paginator: DescribeInstanceTopologyPaginator = client.get_paginator(
    "describe_instance_topology"
)
describe_instance_type_offerings_paginator: DescribeInstanceTypeOfferingsPaginator = (
    client.get_paginator("describe_instance_type_offerings")
)
describe_instance_types_paginator: DescribeInstanceTypesPaginator = client.get_paginator(
    "describe_instance_types"
)
describe_instances_paginator: DescribeInstancesPaginator = client.get_paginator(
    "describe_instances"
)
describe_internet_gateways_paginator: DescribeInternetGatewaysPaginator = client.get_paginator(
    "describe_internet_gateways"
)
describe_ipam_pools_paginator: DescribeIpamPoolsPaginator = client.get_paginator(
    "describe_ipam_pools"
)
describe_ipam_prefix_list_resolver_targets_paginator: DescribeIpamPrefixListResolverTargetsPaginator = client.get_paginator(
    "describe_ipam_prefix_list_resolver_targets"
)
describe_ipam_prefix_list_resolvers_paginator: DescribeIpamPrefixListResolversPaginator = (
    client.get_paginator("describe_ipam_prefix_list_resolvers")
)
describe_ipam_resource_discoveries_paginator: DescribeIpamResourceDiscoveriesPaginator = (
    client.get_paginator("describe_ipam_resource_discoveries")
)
describe_ipam_resource_discovery_associations_paginator: DescribeIpamResourceDiscoveryAssociationsPaginator = client.get_paginator(
    "describe_ipam_resource_discovery_associations"
)
describe_ipam_scopes_paginator: DescribeIpamScopesPaginator = client.get_paginator(
    "describe_ipam_scopes"
)
describe_ipams_paginator: DescribeIpamsPaginator = client.get_paginator("describe_ipams")
describe_ipv6_pools_paginator: DescribeIpv6PoolsPaginator = client.get_paginator(
    "describe_ipv6_pools"
)
describe_launch_template_versions_paginator: DescribeLaunchTemplateVersionsPaginator = (
    client.get_paginator("describe_launch_template_versions")
)
describe_launch_templates_paginator: DescribeLaunchTemplatesPaginator = client.get_paginator(
    "describe_launch_templates"
)
describe_local_gateway_route_table_virtual_interface_group_associations_paginator: DescribeLocalGatewayRouteTableVirtualInterfaceGroupAssociationsPaginator = client.get_paginator(
    "describe_local_gateway_route_table_virtual_interface_group_associations"
)
describe_local_gateway_route_table_vpc_associations_paginator: DescribeLocalGatewayRouteTableVpcAssociationsPaginator = client.get_paginator(
    "describe_local_gateway_route_table_vpc_associations"
)
describe_local_gateway_route_tables_paginator: DescribeLocalGatewayRouteTablesPaginator = (
    client.get_paginator("describe_local_gateway_route_tables")
)
describe_local_gateway_virtual_interface_groups_paginator: DescribeLocalGatewayVirtualInterfaceGroupsPaginator = client.get_paginator(
    "describe_local_gateway_virtual_interface_groups"
)
describe_local_gateway_virtual_interfaces_paginator: DescribeLocalGatewayVirtualInterfacesPaginator = client.get_paginator(
    "describe_local_gateway_virtual_interfaces"
)
describe_local_gateways_paginator: DescribeLocalGatewaysPaginator = client.get_paginator(
    "describe_local_gateways"
)
describe_mac_hosts_paginator: DescribeMacHostsPaginator = client.get_paginator("describe_mac_hosts")
describe_mac_modification_tasks_paginator: DescribeMacModificationTasksPaginator = (
    client.get_paginator("describe_mac_modification_tasks")
)
describe_managed_prefix_lists_paginator: DescribeManagedPrefixListsPaginator = client.get_paginator(
    "describe_managed_prefix_lists"
)
describe_moving_addresses_paginator: DescribeMovingAddressesPaginator = client.get_paginator(
    "describe_moving_addresses"
)
describe_nat_gateways_paginator: DescribeNatGatewaysPaginator = client.get_paginator(
    "describe_nat_gateways"
)
describe_network_acls_paginator: DescribeNetworkAclsPaginator = client.get_paginator(
    "describe_network_acls"
)
describe_network_insights_access_scope_analyses_paginator: DescribeNetworkInsightsAccessScopeAnalysesPaginator = client.get_paginator(
    "describe_network_insights_access_scope_analyses"
)
describe_network_insights_access_scopes_paginator: DescribeNetworkInsightsAccessScopesPaginator = (
    client.get_paginator("describe_network_insights_access_scopes")
)
describe_network_insights_analyses_paginator: DescribeNetworkInsightsAnalysesPaginator = (
    client.get_paginator("describe_network_insights_analyses")
)
describe_network_insights_paths_paginator: DescribeNetworkInsightsPathsPaginator = (
    client.get_paginator("describe_network_insights_paths")
)
describe_network_interface_permissions_paginator: DescribeNetworkInterfacePermissionsPaginator = (
    client.get_paginator("describe_network_interface_permissions")
)
describe_network_interfaces_paginator: DescribeNetworkInterfacesPaginator = client.get_paginator(
    "describe_network_interfaces"
)
describe_prefix_lists_paginator: DescribePrefixListsPaginator = client.get_paginator(
    "describe_prefix_lists"
)
describe_principal_id_format_paginator: DescribePrincipalIdFormatPaginator = client.get_paginator(
    "describe_principal_id_format"
)
describe_public_ipv4_pools_paginator: DescribePublicIpv4PoolsPaginator = client.get_paginator(
    "describe_public_ipv4_pools"
)
describe_replace_root_volume_tasks_paginator: DescribeReplaceRootVolumeTasksPaginator = (
    client.get_paginator("describe_replace_root_volume_tasks")
)
describe_reserved_instances_modifications_paginator: DescribeReservedInstancesModificationsPaginator = client.get_paginator(
    "describe_reserved_instances_modifications"
)
describe_reserved_instances_offerings_paginator: DescribeReservedInstancesOfferingsPaginator = (
    client.get_paginator("describe_reserved_instances_offerings")
)
describe_route_server_endpoints_paginator: DescribeRouteServerEndpointsPaginator = (
    client.get_paginator("describe_route_server_endpoints")
)
describe_route_server_peers_paginator: DescribeRouteServerPeersPaginator = client.get_paginator(
    "describe_route_server_peers"
)
describe_route_servers_paginator: DescribeRouteServersPaginator = client.get_paginator(
    "describe_route_servers"
)
describe_route_tables_paginator: DescribeRouteTablesPaginator = client.get_paginator(
    "describe_route_tables"
)
describe_scheduled_instance_availability_paginator: DescribeScheduledInstanceAvailabilityPaginator = client.get_paginator(
    "describe_scheduled_instance_availability"
)
describe_scheduled_instances_paginator: DescribeScheduledInstancesPaginator = client.get_paginator(
    "describe_scheduled_instances"
)
describe_security_group_rules_paginator: DescribeSecurityGroupRulesPaginator = client.get_paginator(
    "describe_security_group_rules"
)
describe_security_group_vpc_associations_paginator: DescribeSecurityGroupVpcAssociationsPaginator = client.get_paginator(
    "describe_security_group_vpc_associations"
)
describe_security_groups_paginator: DescribeSecurityGroupsPaginator = client.get_paginator(
    "describe_security_groups"
)
describe_snapshot_tier_status_paginator: DescribeSnapshotTierStatusPaginator = client.get_paginator(
    "describe_snapshot_tier_status"
)
describe_snapshots_paginator: DescribeSnapshotsPaginator = client.get_paginator(
    "describe_snapshots"
)
describe_spot_fleet_instances_paginator: DescribeSpotFleetInstancesPaginator = client.get_paginator(
    "describe_spot_fleet_instances"
)
describe_spot_fleet_requests_paginator: DescribeSpotFleetRequestsPaginator = client.get_paginator(
    "describe_spot_fleet_requests"
)
describe_spot_instance_requests_paginator: DescribeSpotInstanceRequestsPaginator = (
    client.get_paginator("describe_spot_instance_requests")
)
describe_spot_price_history_paginator: DescribeSpotPriceHistoryPaginator = client.get_paginator(
    "describe_spot_price_history"
)
describe_stale_security_groups_paginator: DescribeStaleSecurityGroupsPaginator = (
    client.get_paginator("describe_stale_security_groups")
)
describe_store_image_tasks_paginator: DescribeStoreImageTasksPaginator = client.get_paginator(
    "describe_store_image_tasks"
)
describe_subnets_paginator: DescribeSubnetsPaginator = client.get_paginator("describe_subnets")
describe_tags_paginator: DescribeTagsPaginator = client.get_paginator("describe_tags")
describe_traffic_mirror_filters_paginator: DescribeTrafficMirrorFiltersPaginator = (
    client.get_paginator("describe_traffic_mirror_filters")
)
describe_traffic_mirror_sessions_paginator: DescribeTrafficMirrorSessionsPaginator = (
    client.get_paginator("describe_traffic_mirror_sessions")
)
describe_traffic_mirror_targets_paginator: DescribeTrafficMirrorTargetsPaginator = (
    client.get_paginator("describe_traffic_mirror_targets")
)
describe_transit_gateway_attachments_paginator: DescribeTransitGatewayAttachmentsPaginator = (
    client.get_paginator("describe_transit_gateway_attachments")
)
describe_transit_gateway_connect_peers_paginator: DescribeTransitGatewayConnectPeersPaginator = (
    client.get_paginator("describe_transit_gateway_connect_peers")
)
describe_transit_gateway_connects_paginator: DescribeTransitGatewayConnectsPaginator = (
    client.get_paginator("describe_transit_gateway_connects")
)
describe_transit_gateway_multicast_domains_paginator: DescribeTransitGatewayMulticastDomainsPaginator = client.get_paginator(
    "describe_transit_gateway_multicast_domains"
)
describe_transit_gateway_peering_attachments_paginator: DescribeTransitGatewayPeeringAttachmentsPaginator = client.get_paginator(
    "describe_transit_gateway_peering_attachments"
)
describe_transit_gateway_policy_tables_paginator: DescribeTransitGatewayPolicyTablesPaginator = (
    client.get_paginator("describe_transit_gateway_policy_tables")
)
describe_transit_gateway_route_table_announcements_paginator: DescribeTransitGatewayRouteTableAnnouncementsPaginator = client.get_paginator(
    "describe_transit_gateway_route_table_announcements"
)
describe_transit_gateway_route_tables_paginator: DescribeTransitGatewayRouteTablesPaginator = (
    client.get_paginator("describe_transit_gateway_route_tables")
)
describe_transit_gateway_vpc_attachments_paginator: DescribeTransitGatewayVpcAttachmentsPaginator = client.get_paginator(
    "describe_transit_gateway_vpc_attachments"
)
describe_transit_gateways_paginator: DescribeTransitGatewaysPaginator = client.get_paginator(
    "describe_transit_gateways"
)
describe_trunk_interface_associations_paginator: DescribeTrunkInterfaceAssociationsPaginator = (
    client.get_paginator("describe_trunk_interface_associations")
)
describe_verified_access_endpoints_paginator: DescribeVerifiedAccessEndpointsPaginator = (
    client.get_paginator("describe_verified_access_endpoints")
)
describe_verified_access_groups_paginator: DescribeVerifiedAccessGroupsPaginator = (
    client.get_paginator("describe_verified_access_groups")
)
describe_verified_access_instance_logging_configurations_paginator: DescribeVerifiedAccessInstanceLoggingConfigurationsPaginator = client.get_paginator(
    "describe_verified_access_instance_logging_configurations"
)
describe_verified_access_instances_paginator: DescribeVerifiedAccessInstancesPaginator = (
    client.get_paginator("describe_verified_access_instances")
)
describe_verified_access_trust_providers_paginator: DescribeVerifiedAccessTrustProvidersPaginator = client.get_paginator(
    "describe_verified_access_trust_providers"
)
describe_volume_status_paginator: DescribeVolumeStatusPaginator = client.get_paginator(
    "describe_volume_status"
)
describe_volumes_modifications_paginator: DescribeVolumesModificationsPaginator = (
    client.get_paginator("describe_volumes_modifications")
)
describe_volumes_paginator: DescribeVolumesPaginator = client.get_paginator("describe_volumes")
describe_vpc_classic_link_dns_support_paginator: DescribeVpcClassicLinkDnsSupportPaginator = (
    client.get_paginator("describe_vpc_classic_link_dns_support")
)
describe_vpc_endpoint_connection_notifications_paginator: DescribeVpcEndpointConnectionNotificationsPaginator = client.get_paginator(
    "describe_vpc_endpoint_connection_notifications"
)
describe_vpc_endpoint_connections_paginator: DescribeVpcEndpointConnectionsPaginator = (
    client.get_paginator("describe_vpc_endpoint_connections")
)
describe_vpc_endpoint_service_configurations_paginator: DescribeVpcEndpointServiceConfigurationsPaginator = client.get_paginator(
    "describe_vpc_endpoint_service_configurations"
)
describe_vpc_endpoint_service_permissions_paginator: DescribeVpcEndpointServicePermissionsPaginator = client.get_paginator(
    "describe_vpc_endpoint_service_permissions"
)
describe_vpc_endpoint_services_paginator: DescribeVpcEndpointServicesPaginator = (
    client.get_paginator("describe_vpc_endpoint_services")
)
describe_vpc_endpoints_paginator: DescribeVpcEndpointsPaginator = client.get_paginator(
    "describe_vpc_endpoints"
)
describe_vpc_peering_connections_paginator: DescribeVpcPeeringConnectionsPaginator = (
    client.get_paginator("describe_vpc_peering_connections")
)
describe_vpcs_paginator: DescribeVpcsPaginator = client.get_paginator("describe_vpcs")
describe_vpn_concentrators_paginator: DescribeVpnConcentratorsPaginator = client.get_paginator(
    "describe_vpn_concentrators"
)
get_associated_ipv6_pool_cidrs_paginator: GetAssociatedIpv6PoolCidrsPaginator = (
    client.get_paginator("get_associated_ipv6_pool_cidrs")
)
get_aws_network_performance_data_paginator: GetAwsNetworkPerformanceDataPaginator = (
    client.get_paginator("get_aws_network_performance_data")
)
get_capacity_manager_metric_data_paginator: GetCapacityManagerMetricDataPaginator = (
    client.get_paginator("get_capacity_manager_metric_data")
)
get_capacity_manager_metric_dimensions_paginator: GetCapacityManagerMetricDimensionsPaginator = (
    client.get_paginator("get_capacity_manager_metric_dimensions")
)
get_groups_for_capacity_reservation_paginator: GetGroupsForCapacityReservationPaginator = (
    client.get_paginator("get_groups_for_capacity_reservation")
)
get_instance_types_from_instance_requirements_paginator: GetInstanceTypesFromInstanceRequirementsPaginator = client.get_paginator(
    "get_instance_types_from_instance_requirements"
)
get_ipam_address_history_paginator: GetIpamAddressHistoryPaginator = client.get_paginator(
    "get_ipam_address_history"
)
get_ipam_discovered_accounts_paginator: GetIpamDiscoveredAccountsPaginator = client.get_paginator(
    "get_ipam_discovered_accounts"
)
get_ipam_discovered_resource_cidrs_paginator: GetIpamDiscoveredResourceCidrsPaginator = (
    client.get_paginator("get_ipam_discovered_resource_cidrs")
)
get_ipam_pool_allocations_paginator: GetIpamPoolAllocationsPaginator = client.get_paginator(
    "get_ipam_pool_allocations"
)
get_ipam_pool_cidrs_paginator: GetIpamPoolCidrsPaginator = client.get_paginator(
    "get_ipam_pool_cidrs"
)
get_ipam_prefix_list_resolver_rules_paginator: GetIpamPrefixListResolverRulesPaginator = (
    client.get_paginator("get_ipam_prefix_list_resolver_rules")
)
get_ipam_prefix_list_resolver_version_entries_paginator: GetIpamPrefixListResolverVersionEntriesPaginator = client.get_paginator(
    "get_ipam_prefix_list_resolver_version_entries"
)
get_ipam_prefix_list_resolver_versions_paginator: GetIpamPrefixListResolverVersionsPaginator = (
    client.get_paginator("get_ipam_prefix_list_resolver_versions")
)
get_ipam_resource_cidrs_paginator: GetIpamResourceCidrsPaginator = client.get_paginator(
    "get_ipam_resource_cidrs"
)
get_managed_prefix_list_associations_paginator: GetManagedPrefixListAssociationsPaginator = (
    client.get_paginator("get_managed_prefix_list_associations")
)
get_managed_prefix_list_entries_paginator: GetManagedPrefixListEntriesPaginator = (
    client.get_paginator("get_managed_prefix_list_entries")
)
get_network_insights_access_scope_analysis_findings_paginator: GetNetworkInsightsAccessScopeAnalysisFindingsPaginator = client.get_paginator(
    "get_network_insights_access_scope_analysis_findings"
)
get_security_groups_for_vpc_paginator: GetSecurityGroupsForVpcPaginator = client.get_paginator(
    "get_security_groups_for_vpc"
)
get_spot_placement_scores_paginator: GetSpotPlacementScoresPaginator = client.get_paginator(
    "get_spot_placement_scores"
)
get_transit_gateway_attachment_propagations_paginator: GetTransitGatewayAttachmentPropagationsPaginator = client.get_paginator(
    "get_transit_gateway_attachment_propagations"
)
get_transit_gateway_multicast_domain_associations_paginator: GetTransitGatewayMulticastDomainAssociationsPaginator = client.get_paginator(
    "get_transit_gateway_multicast_domain_associations"
)
get_transit_gateway_policy_table_associations_paginator: GetTransitGatewayPolicyTableAssociationsPaginator = client.get_paginator(
    "get_transit_gateway_policy_table_associations"
)
get_transit_gateway_prefix_list_references_paginator: GetTransitGatewayPrefixListReferencesPaginator = client.get_paginator(
    "get_transit_gateway_prefix_list_references"
)
get_transit_gateway_route_table_associations_paginator: GetTransitGatewayRouteTableAssociationsPaginator = client.get_paginator(
    "get_transit_gateway_route_table_associations"
)
get_transit_gateway_route_table_propagations_paginator: GetTransitGatewayRouteTablePropagationsPaginator = client.get_paginator(
    "get_transit_gateway_route_table_propagations"
)
get_vpn_connection_device_types_paginator: GetVpnConnectionDeviceTypesPaginator = (
    client.get_paginator("get_vpn_connection_device_types")
)
list_images_in_recycle_bin_paginator: ListImagesInRecycleBinPaginator = client.get_paginator(
    "list_images_in_recycle_bin"
)
list_snapshots_in_recycle_bin_paginator: ListSnapshotsInRecycleBinPaginator = client.get_paginator(
    "list_snapshots_in_recycle_bin"
)
search_local_gateway_routes_paginator: SearchLocalGatewayRoutesPaginator = client.get_paginator(
    "search_local_gateway_routes"
)
search_transit_gateway_multicast_groups_paginator: SearchTransitGatewayMulticastGroupsPaginator = (
    client.get_paginator("search_transit_gateway_multicast_groups")
)
```

<a id="waiters-annotations"></a>

### Waiters annotations

`types_boto3_ec2.waiter` module contains type annotations for all waiters.

```python
from boto3.session import Session

from types_boto3_ec2 import EC2Client
from types_boto3_ec2.waiter import (
    BundleTaskCompleteWaiter,
    ConversionTaskCancelledWaiter,
    ConversionTaskCompletedWaiter,
    ConversionTaskDeletedWaiter,
    CustomerGatewayAvailableWaiter,
    ExportTaskCancelledWaiter,
    ExportTaskCompletedWaiter,
    ImageAvailableWaiter,
    ImageExistsWaiter,
    ImageUsageReportAvailableWaiter,
    InstanceExistsWaiter,
    InstanceRunningWaiter,
    InstanceStatusOkWaiter,
    InstanceStoppedWaiter,
    InstanceTerminatedWaiter,
    InternetGatewayExistsWaiter,
    KeyPairExistsWaiter,
    NatGatewayAvailableWaiter,
    NatGatewayDeletedWaiter,
    NetworkInterfaceAvailableWaiter,
    PasswordDataAvailableWaiter,
    SecurityGroupExistsWaiter,
    SecurityGroupVpcAssociationAssociatedWaiter,
    SecurityGroupVpcAssociationDisassociatedWaiter,
    SnapshotCompletedWaiter,
    SnapshotImportedWaiter,
    SpotInstanceRequestFulfilledWaiter,
    StoreImageTaskCompleteWaiter,
    SubnetAvailableWaiter,
    SystemStatusOkWaiter,
    VolumeAvailableWaiter,
    VolumeDeletedWaiter,
    VolumeInUseWaiter,
    VpcAvailableWaiter,
    VpcExistsWaiter,
    VpcPeeringConnectionDeletedWaiter,
    VpcPeeringConnectionExistsWaiter,
    VpnConnectionAvailableWaiter,
    VpnConnectionDeletedWaiter,
)

client: EC2Client = Session().client("ec2")

# Explicit type annotations are optional here
# Types should be correctly discovered by mypy and IDEs
bundle_task_complete_waiter: BundleTaskCompleteWaiter = client.get_waiter("bundle_task_complete")
conversion_task_cancelled_waiter: ConversionTaskCancelledWaiter = client.get_waiter(
    "conversion_task_cancelled"
)
conversion_task_completed_waiter: ConversionTaskCompletedWaiter = client.get_waiter(
    "conversion_task_completed"
)
conversion_task_deleted_waiter: ConversionTaskDeletedWaiter = client.get_waiter(
    "conversion_task_deleted"
)
customer_gateway_available_waiter: CustomerGatewayAvailableWaiter = client.get_waiter(
    "customer_gateway_available"
)
export_task_cancelled_waiter: ExportTaskCancelledWaiter = client.get_waiter("export_task_cancelled")
export_task_completed_waiter: ExportTaskCompletedWaiter = client.get_waiter("export_task_completed")
image_available_waiter: ImageAvailableWaiter = client.get_waiter("image_available")
image_exists_waiter: ImageExistsWaiter = client.get_waiter("image_exists")
image_usage_report_available_waiter: ImageUsageReportAvailableWaiter = client.get_waiter(
    "image_usage_report_available"
)
instance_exists_waiter: InstanceExistsWaiter = client.get_waiter("instance_exists")
instance_running_waiter: InstanceRunningWaiter = client.get_waiter("instance_running")
instance_status_ok_waiter: InstanceStatusOkWaiter = client.get_waiter("instance_status_ok")
instance_stopped_waiter: InstanceStoppedWaiter = client.get_waiter("instance_stopped")
instance_terminated_waiter: InstanceTerminatedWaiter = client.get_waiter("instance_terminated")
internet_gateway_exists_waiter: InternetGatewayExistsWaiter = client.get_waiter(
    "internet_gateway_exists"
)
key_pair_exists_waiter: KeyPairExistsWaiter = client.get_waiter("key_pair_exists")
nat_gateway_available_waiter: NatGatewayAvailableWaiter = client.get_waiter("nat_gateway_available")
nat_gateway_deleted_waiter: NatGatewayDeletedWaiter = client.get_waiter("nat_gateway_deleted")
network_interface_available_waiter: NetworkInterfaceAvailableWaiter = client.get_waiter(
    "network_interface_available"
)
password_data_available_waiter: PasswordDataAvailableWaiter = client.get_waiter(
    "password_data_available"
)
security_group_exists_waiter: SecurityGroupExistsWaiter = client.get_waiter("security_group_exists")
security_group_vpc_association_associated_waiter: SecurityGroupVpcAssociationAssociatedWaiter = (
    client.get_waiter("security_group_vpc_association_associated")
)
security_group_vpc_association_disassociated_waiter: SecurityGroupVpcAssociationDisassociatedWaiter = client.get_waiter(
    "security_group_vpc_association_disassociated"
)
snapshot_completed_waiter: SnapshotCompletedWaiter = client.get_waiter("snapshot_completed")
snapshot_imported_waiter: SnapshotImportedWaiter = client.get_waiter("snapshot_imported")
spot_instance_request_fulfilled_waiter: SpotInstanceRequestFulfilledWaiter = client.get_waiter(
    "spot_instance_request_fulfilled"
)
store_image_task_complete_waiter: StoreImageTaskCompleteWaiter = client.get_waiter(
    "store_image_task_complete"
)
subnet_available_waiter: SubnetAvailableWaiter = client.get_waiter("subnet_available")
system_status_ok_waiter: SystemStatusOkWaiter = client.get_waiter("system_status_ok")
volume_available_waiter: VolumeAvailableWaiter = client.get_waiter("volume_available")
volume_deleted_waiter: VolumeDeletedWaiter = client.get_waiter("volume_deleted")
volume_in_use_waiter: VolumeInUseWaiter = client.get_waiter("volume_in_use")
vpc_available_waiter: VpcAvailableWaiter = client.get_waiter("vpc_available")
vpc_exists_waiter: VpcExistsWaiter = client.get_waiter("vpc_exists")
vpc_peering_connection_deleted_waiter: VpcPeeringConnectionDeletedWaiter = client.get_waiter(
    "vpc_peering_connection_deleted"
)
vpc_peering_connection_exists_waiter: VpcPeeringConnectionExistsWaiter = client.get_waiter(
    "vpc_peering_connection_exists"
)
vpn_connection_available_waiter: VpnConnectionAvailableWaiter = client.get_waiter(
    "vpn_connection_available"
)
vpn_connection_deleted_waiter: VpnConnectionDeletedWaiter = client.get_waiter(
    "vpn_connection_deleted"
)
```

<a id="service-resource-annotations"></a>

### Service Resource annotations

`EC2ServiceResource` provides annotations for `boto3.resource("ec2")`.

```python
from boto3.session import Session

from types_boto3_ec2 import EC2ServiceResource

resource: EC2ServiceResource = Session().resource("ec2")

# now resource usage is checked by mypy and IDE should provide code completion
```

<a id="other-resources-annotations"></a>

### Other resources annotations

`types_boto3_ec2.service_resource` module contains type annotations for all
resources.

```python
from boto3.session import Session

from types_boto3_ec2 import EC2ServiceResource
from types_boto3_ec2.service_resource import (
    ClassicAddress,
    DhcpOptions,
    Image,
    Instance,
    InternetGateway,
    KeyPair,
    KeyPairInfo,
    NetworkAcl,
    NetworkInterface,
    NetworkInterfaceAssociation,
    PlacementGroup,
    Route,
    RouteTable,
    RouteTableAssociation,
    SecurityGroup,
    Snapshot,
    Subnet,
    Tag,
    Volume,
    Vpc,
    VpcPeeringConnection,
    VpcAddress,
)

resource: EC2ServiceResource = Session().resource("ec2")

# Explicit type annotations are optional here
# Type should be correctly discovered by mypy and IDEs
my_classic_address: ClassicAddress = resource.ClassicAddress(...)
my_dhcp_options: DhcpOptions = resource.DhcpOptions(...)
my_image: Image = resource.Image(...)
my_instance: Instance = resource.Instance(...)
my_internet_gateway: InternetGateway = resource.InternetGateway(...)
my_key_pair: KeyPair = resource.KeyPair(...)
my_key_pair_info: KeyPairInfo = resource.KeyPairInfo(...)
my_network_acl: NetworkAcl = resource.NetworkAcl(...)
my_network_interface: NetworkInterface = resource.NetworkInterface(...)
my_network_interface_association: NetworkInterfaceAssociation = (
    resource.NetworkInterfaceAssociation(...)
)
my_placement_group: PlacementGroup = resource.PlacementGroup(...)
my_route: Route = resource.Route(...)
my_route_table: RouteTable = resource.RouteTable(...)
my_route_table_association: RouteTableAssociation = resource.RouteTableAssociation(...)
my_security_group: SecurityGroup = resource.SecurityGroup(...)
my_snapshot: Snapshot = resource.Snapshot(...)
my_subnet: Subnet = resource.Subnet(...)
my_tag: Tag = resource.Tag(...)
my_volume: Volume = resource.Volume(...)
my_vpc: Vpc = resource.Vpc(...)
my_vpc_peering_connection: VpcPeeringConnection = resource.VpcPeeringConnection(...)
my_vpc_address: VpcAddress = resource.VpcAddress(...)
```

<a id="collections-annotations"></a>

### Collections annotations

`types_boto3_ec2.service_resource` module contains type annotations for all
`EC2ServiceResource` collections.

```python
from boto3.session import Session

from types_boto3_ec2 import EC2ServiceResource
from types_boto3_ec2.service_resource import (
    ServiceResourceClassicAddressesCollection,
    ServiceResourceDhcpOptionsSetsCollection,
    ServiceResourceImagesCollection,
    ServiceResourceInstancesCollection,
    ServiceResourceInternetGatewaysCollection,
    ServiceResourceKeyPairsCollection,
    ServiceResourceNetworkAclsCollection,
    ServiceResourceNetworkInterfacesCollection,
    ServiceResourcePlacementGroupsCollection,
    ServiceResourceRouteTablesCollection,
    ServiceResourceSecurityGroupsCollection,
    ServiceResourceSnapshotsCollection,
    ServiceResourceSubnetsCollection,
    ServiceResourceVolumesCollection,
    ServiceResourceVpcAddressesCollection,
    ServiceResourceVpcPeeringConnectionsCollection,
    ServiceResourceVpcsCollection,
)

resource: EC2ServiceResource = Session().resource("ec2")

# Explicit type annotations are optional here
# Type should be correctly discovered by mypy and IDEs
classic_addresses: ec2_resources.ServiceResourceClassicAddressesCollection = (
    resource.classic_addresses
)
dhcp_options_sets: ec2_resources.ServiceResourceDhcpOptionsSetsCollection = (
    resource.dhcp_options_sets
)
images: ec2_resources.ServiceResourceImagesCollection = resource.images
instances: ec2_resources.ServiceResourceInstancesCollection = resource.instances
internet_gateways: ec2_resources.ServiceResourceInternetGatewaysCollection = (
    resource.internet_gateways
)
key_pairs: ec2_resources.ServiceResourceKeyPairsCollection = resource.key_pairs
network_acls: ec2_resources.ServiceResourceNetworkAclsCollection = resource.network_acls
network_interfaces: ec2_resources.ServiceResourceNetworkInterfacesCollection = (
    resource.network_interfaces
)
placement_groups: ec2_resources.ServiceResourcePlacementGroupsCollection = resource.placement_groups
route_tables: ec2_resources.ServiceResourceRouteTablesCollection = resource.route_tables
security_groups: ec2_resources.ServiceResourceSecurityGroupsCollection = resource.security_groups
snapshots: ec2_resources.ServiceResourceSnapshotsCollection = resource.snapshots
subnets: ec2_resources.ServiceResourceSubnetsCollection = resource.subnets
volumes: ec2_resources.ServiceResourceVolumesCollection = resource.volumes
vpc_addresses: ec2_resources.ServiceResourceVpcAddressesCollection = resource.vpc_addresses
vpc_peering_connections: ec2_resources.ServiceResourceVpcPeeringConnectionsCollection = (
    resource.vpc_peering_connections
)
vpcs: ec2_resources.ServiceResourceVpcsCollection = resource.vpcs
```

<a id="literals"></a>

### Literals

`types_boto3_ec2.literals` module contains literals extracted from shapes that
can be used in user code for type checking.

Full list of `EC2` Literals can be found in
[docs](https://youtype.github.io/types_boto3_docs/types_boto3_ec2/literals/).

```python
from types_boto3_ec2.literals import AcceleratorManufacturerType


def check_value(value: AcceleratorManufacturerType) -> bool: ...
```

<a id="type-definitions"></a>

### Type definitions

`types_boto3_ec2.type_defs` module contains structures and shapes assembled to
typed dictionaries and unions for additional type checking.

Full list of `EC2` TypeDefs can be found in
[docs](https://youtype.github.io/types_boto3_docs/types_boto3_ec2/type_defs/).

```python
# TypedDict usage example
from types_boto3_ec2.type_defs import AcceleratorCountRequestTypeDef


def get_value() -> AcceleratorCountRequestTypeDef:
    return {
        "Min": ...,
    }
```

<a id="how-it-works"></a>

## How it works

Fully automated
[mypy-boto3-builder](https://github.com/youtype/mypy_boto3_builder) carefully
generates type annotations for each service, patiently waiting for `boto3`
updates. It delivers drop-in type annotations for you and makes sure that:

- All available `boto3` services are covered.
- Each public class and method of every `boto3` service gets valid type
  annotations extracted from `botocore` schemas.
- Type annotations include up-to-date documentation.
- Link to documentation is provided for every method.
- Code is processed by [ruff](https://docs.astral.sh/ruff/) for readability.

<a id="what's-new"></a>

## What's new

<a id="implemented-features"></a>

### Implemented features

- Fully type annotated `boto3`, `botocore`, `aiobotocore` and `aioboto3`
  libraries
- `mypy`, `pyright`, `VSCode`, `PyCharm`, `Sublime Text` and `Emacs`
  compatibility
- `Client`, `ServiceResource`, `Resource`, `Waiter` `Paginator` type
  annotations for each service
- Generated `TypeDefs` for each service
- Generated `Literals` for each service
- Auto discovery of types for `boto3.client` and `boto3.resource` calls
- Auto discovery of types for `session.client` and `session.resource` calls
- Auto discovery of types for `client.get_waiter` and `client.get_paginator`
  calls
- Auto discovery of types for `ServiceResource` and `Resource` collections
- Auto discovery of types for `aiobotocore.Session.create_client` calls

<a id="latest-changes"></a>

### Latest changes

Builder changelog can be found in
[Releases](https://github.com/youtype/mypy_boto3_builder/releases).

<a id="versioning"></a>

## Versioning

`types-boto3-ec2` version is the same as related `boto3` version and follows
[Python Packaging version specifiers](https://packaging.python.org/en/latest/specifications/version-specifiers/).

<a id="thank-you"></a>

## Thank you

- [Allie Fitter](https://github.com/alliefitter) for
  [boto3-type-annotations](https://pypi.org/project/boto3-type-annotations/),
  this package is based on top of his work
- [black](https://github.com/psf/black) developers for an awesome formatting
  tool
- [Timothy Edmund Crosley](https://github.com/timothycrosley) for
  [isort](https://github.com/PyCQA/isort) and how flexible it is
- [mypy](https://github.com/python/mypy) developers for doing all dirty work
  for us
- [pyright](https://github.com/microsoft/pyright) team for the new era of typed
  Python

<a id="documentation"></a>

## Documentation

All services type annotations can be found in
[boto3 docs](https://youtype.github.io/types_boto3_docs/types_boto3_ec2/)

<a id="support-and-contributing"></a>

## Support and contributing

This package is auto-generated. Please reports any bugs or request new features
in [mypy-boto3-builder](https://github.com/youtype/mypy_boto3_builder/issues/)
repository.
