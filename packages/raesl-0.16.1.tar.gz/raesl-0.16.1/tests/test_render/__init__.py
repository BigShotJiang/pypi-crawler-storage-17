"""Tests for the rendering module."""
