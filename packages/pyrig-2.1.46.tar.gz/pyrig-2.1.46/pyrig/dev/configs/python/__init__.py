"""Python source file configuration management.

This package provides ConfigFile subclasses for creating and managing
Python source files like __init__.py, main.py, and subcommands.py.
"""
