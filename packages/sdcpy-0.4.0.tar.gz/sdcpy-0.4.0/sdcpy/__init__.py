
"""Top-level package for sdcpy."""

__author__ = """Alejandro Fontal"""
__email__ = 'alejandrofontal92@gmail.com'
__version__ = '0.4.0'
