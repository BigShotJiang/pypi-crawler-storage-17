# Device Models

```{eval-rst}
.. automodule:: ferrmion.devices
   :members:
   :undoc-members:
   :show-inheritance:
```
