#!/usr/bin/env python

""""""
# SPDX-FileCopyrightText: 2025 Ben Bonacci <ben at benbonaccci dot com>
# SPDX-License-Identifier: GPL-3.0-only
""""""
from .ausnumtools import is_au_landline,is_au_mobile,is_au_smartnum,is_au_number
