from .decorator import track_carbon

__all__ = ["track_carbon"]
