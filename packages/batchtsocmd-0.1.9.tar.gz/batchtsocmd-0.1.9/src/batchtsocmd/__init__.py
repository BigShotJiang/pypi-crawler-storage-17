"""
batchtsocmd - Execute TSO commands via IKJEFT1B with encoding conversion
"""

__version__ = "0.1.4"
__author__ = "Mike Fulton"

from .main import execute_tso_command, main

__all__ = ["execute_tso_command", "main"]

# Made with Bob
