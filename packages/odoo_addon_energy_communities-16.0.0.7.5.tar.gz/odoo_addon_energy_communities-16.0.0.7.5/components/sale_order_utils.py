from odoo.addons.component.core import Component


class SaleOrderUtils(Component):
    _name = "sale.order.utils"
    _usage = "sale.order.utils"
    _apply_on = "sale.order"
    _collection = "utils.backend"
