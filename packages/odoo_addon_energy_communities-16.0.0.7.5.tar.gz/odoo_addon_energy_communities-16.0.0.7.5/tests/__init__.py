from . import test_res_company
from . import test_res_users
from . import test_change_coordinator
from . import test_landing_place
