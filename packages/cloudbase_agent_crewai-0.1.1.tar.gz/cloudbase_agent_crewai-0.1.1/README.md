# cloudbase-agent-crewai

Cloudbase Agent Python SDK - CrewAI framework integration

## Installation

```bash
pip install cloudbase-agent-crewai
```

## Usage

```python
from cloudbase_agent import ...
```

## License

Apache-2.0
