"""Version information for netconduit."""

__version__ = "4.0.0"
__protocol_version__ = "1.0"
