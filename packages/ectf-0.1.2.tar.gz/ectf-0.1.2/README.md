# eCTF

[![image](https://img.shields.io/pypi/v/ectf.svg)](https://pypi.python.org/pypi/ectf)
[![image](https://img.shields.io/pypi/l/ectf.svg)](https://pypi.python.org/pypi/ectf)

The official tools for MITRE's [Embedded Capture the Flag](https://ectf.mitre.org)
(eCTF) Competition.

## Use

The tools require [uv](https://docs.astral.sh/uv/) to be run.

The tools can be run with [uvx](https://docs.astral.sh/uv/guides/tools/) with:
```commandline
uvx ectf --help
```

If you do not have the correct Python version installed, you can use uv's manager with:
```commandline
uv python install 3.13
```