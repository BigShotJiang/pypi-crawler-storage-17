"""Main entry point for the CLI."""
from planecompose.cli.root import app

if __name__ == "__main__":
    app()
