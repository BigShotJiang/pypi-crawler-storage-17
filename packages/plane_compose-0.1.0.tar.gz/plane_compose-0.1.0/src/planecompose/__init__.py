"""Plane CLI - Scaffold and sync projects with Plane."""
__version__ = "0.1.0"
