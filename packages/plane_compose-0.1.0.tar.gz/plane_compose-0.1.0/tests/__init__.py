"""Test suite for planecompose."""

