from fast_rub import Client

bot = Client("name_session")