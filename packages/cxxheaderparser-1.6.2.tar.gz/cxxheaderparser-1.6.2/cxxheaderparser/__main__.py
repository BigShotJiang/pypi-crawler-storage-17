from cxxheaderparser.dump import dumpmain

if __name__ == "__main__":
    dumpmain()
