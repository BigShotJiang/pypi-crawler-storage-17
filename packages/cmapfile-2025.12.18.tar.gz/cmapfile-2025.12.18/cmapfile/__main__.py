# cmapfile/__main__.py

"""Cmapfile package command line script."""

import sys

from .cmapfile import main

sys.exit(main())
