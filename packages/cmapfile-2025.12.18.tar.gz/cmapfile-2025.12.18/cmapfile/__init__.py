# cmapfile/__init__.py

from .cmapfile import *
from .cmapfile import __all__, __doc__, __version__, main

# constants are repeated for documentation

__version__ = __version__
"""Cmapfile version string."""
