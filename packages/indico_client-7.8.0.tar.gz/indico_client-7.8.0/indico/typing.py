from typing import Any, Dict

AnyDict = Dict[str, Any]
Payload = AnyDict
