"""
Database connection and query utilities
"""

__all__ = []