"""Tests package for SelfDB SDK."""
