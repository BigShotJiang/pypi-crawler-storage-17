Stock Secondary Unit Module
###########################

The stock secondary unit module adds a secondary unit of measure on the stock
move.
