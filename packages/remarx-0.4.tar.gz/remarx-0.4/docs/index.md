---
title: Overview
hide: [navigation]
---

--8<-- "README.md:overview"

## Development

For development setup, documentation generation, and contributing guidelines, see [Developer Notes](devnotes.md).

## License

This project is licensed under the [Apache 2.0 License](https://www.apache.org/licenses/LICENSE-2.0.txt).

(c)2025 Trustees of Princeton University. Permission granted for non-commercial
distribution online under a standard Open Source license.
