"""Ripperdoc - AI-powered coding agent."""

__version__ = "0.2.7"
