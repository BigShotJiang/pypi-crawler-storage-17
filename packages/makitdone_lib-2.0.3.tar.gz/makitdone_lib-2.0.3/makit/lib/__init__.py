# coding:utf-8

from makit.lib._decorators import singleton, synchronized
from makit.lib._input import *
from makit.lib.command import AppCommand
from makit.lib.config import Config
