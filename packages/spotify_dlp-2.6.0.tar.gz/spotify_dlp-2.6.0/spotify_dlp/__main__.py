from spotify_dlp.spotify_dlp import main

if __name__ == "__main__":
	main()
