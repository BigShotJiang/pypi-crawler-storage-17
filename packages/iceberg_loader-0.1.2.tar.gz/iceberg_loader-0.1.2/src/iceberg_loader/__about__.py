# SPDX-FileCopyrightText: 2025-present Ivan Matveev <vndvtech@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = '0.1.2'
