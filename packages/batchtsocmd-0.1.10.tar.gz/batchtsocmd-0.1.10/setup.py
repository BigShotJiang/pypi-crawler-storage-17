"""
Setup script for batchtsocmd package.
This file is maintained for backward compatibility.
Configuration is in pyproject.toml.
"""

from setuptools import setup

setup()

# Made with Bob
