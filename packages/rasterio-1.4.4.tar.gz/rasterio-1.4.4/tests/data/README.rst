Testing
=======

Rasterio's tests require several raster data files. Grab them from

https://github.com/rasterio/rasterio/tree/master/tests/data

and copy them to this directory.

The RGB.byte.tif file is derived from USGS Landsat 7 ETM imagery. The shade.tif
file is derived from USGS SRTM 90 data. The float.tif and float_nan.tif files
are original works of the Rasterio authors. All test images are licensed under
the CC0 1.0 Universal (CC0 1.0) Public Domain Dedication:
http://creativecommons.org/publicdomain/zero/1.0/.
