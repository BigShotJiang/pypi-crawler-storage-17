.. click:: rasterio.rio.env:env
   :prog: rio env
   :show-nested:
