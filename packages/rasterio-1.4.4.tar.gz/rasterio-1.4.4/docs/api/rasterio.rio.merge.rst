.. click:: rasterio.rio.merge:merge
   :prog: rio merge
   :show-nested:
