.. click:: rasterio.rio.info:info
   :prog: rio info
   :show-nested: