.. click:: rasterio.rio.clip:clip
   :prog: rio clip
