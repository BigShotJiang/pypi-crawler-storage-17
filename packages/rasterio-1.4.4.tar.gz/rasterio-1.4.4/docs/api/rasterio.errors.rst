rasterio.errors module
======================

.. automodule:: rasterio.errors
    :members:
    :undoc-members:
    :show-inheritance:
