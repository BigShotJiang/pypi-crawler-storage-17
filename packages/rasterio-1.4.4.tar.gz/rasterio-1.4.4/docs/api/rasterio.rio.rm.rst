.. click:: rasterio.rio.rm:rm
   :prog: rio rm
   :show-nested:
