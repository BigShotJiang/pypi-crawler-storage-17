rasterio.crs module
===================

.. automodule:: rasterio.crs
    :members:
    :undoc-members:
    :show-inheritance:
