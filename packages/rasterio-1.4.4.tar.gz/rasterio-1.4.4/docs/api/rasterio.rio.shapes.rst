.. click:: rasterio.rio.shapes:shapes
   :prog: rio shapes
   :show-nested:
