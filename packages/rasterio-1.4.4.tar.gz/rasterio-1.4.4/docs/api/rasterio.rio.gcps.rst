.. click:: rasterio.rio.gcps:gcps
   :prog: rio gcps
   :show-nested:
