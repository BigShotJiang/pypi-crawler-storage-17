.. click:: rasterio.rio.warp:warp
   :prog: rio warp
   :show-nested:
