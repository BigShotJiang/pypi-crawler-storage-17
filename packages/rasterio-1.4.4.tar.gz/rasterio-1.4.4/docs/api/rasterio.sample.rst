rasterio.sample module
======================

.. automodule:: rasterio.sample
    :members:
    :undoc-members:
    :show-inheritance:
