.. click:: rasterio.rio.sample:sample
   :prog: rio sample
   :show-nested:
