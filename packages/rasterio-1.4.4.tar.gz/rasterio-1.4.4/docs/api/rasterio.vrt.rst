rasterio.vrt module
===================

.. automodule:: rasterio.vrt
   :inherited-members:
   :members:
   :undoc-members:
   :show-inheritance:
