.. click:: rasterio.rio.convert:convert
   :prog: rio convert
   :show-nested:
