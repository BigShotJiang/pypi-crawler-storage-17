.. click:: rasterio.rio.bounds:bounds
   :prog: rio bounds
   :show-nested:
