.. click:: rasterio.rio.mask:mask
   :prog: rio mask
   :show-nested:
