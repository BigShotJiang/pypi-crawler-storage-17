.. click:: rasterio.rio.blocks:blocks
   :prog: rio blocks
   :show-nested:
