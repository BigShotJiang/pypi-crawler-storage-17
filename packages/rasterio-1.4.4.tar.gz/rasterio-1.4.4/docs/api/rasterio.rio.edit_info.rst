.. click:: rasterio.rio.edit_info:edit
   :prog: rio edit_info
   :show-nested:
