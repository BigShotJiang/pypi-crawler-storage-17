.. click:: rasterio.rio.insp:insp
   :prog: rio insp
   :show-nested:
