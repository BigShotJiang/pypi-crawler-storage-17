.. click:: rasterio.rio.calc:calc
   :prog: rio calc
   :show-nested:

