rasterio.merge module
=====================

.. automodule:: rasterio.merge
    :members:
    :undoc-members:
    :show-inheritance:
