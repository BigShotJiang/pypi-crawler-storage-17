.. click:: rasterio.rio.stack:stack
   :prog: rio stack
   :show-nested:

