.. click:: rasterio.rio.rasterize:rasterize
   :prog: rio rasterize
   :show-nested:
