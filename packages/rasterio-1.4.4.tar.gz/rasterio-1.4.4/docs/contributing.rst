Contributing
============

.. include:: ../CONTRIBUTING.rst

Additional Information
----------------------

More technical information lives on the wiki.

* https://github.com/rasterio/rasterio/wiki/Development-Guide
* https://github.com/rasterio/rasterio/wiki/Exposing-GDAL-Functionality
* https://github.com/rasterio/rasterio/wiki/Cython-and-GDAL

The long term goal is to consolidate into this document.
