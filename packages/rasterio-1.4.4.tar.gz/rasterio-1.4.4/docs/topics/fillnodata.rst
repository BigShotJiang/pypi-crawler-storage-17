Filling nodata areas
====================

.. todo::

    :func:`.fillnodata`
