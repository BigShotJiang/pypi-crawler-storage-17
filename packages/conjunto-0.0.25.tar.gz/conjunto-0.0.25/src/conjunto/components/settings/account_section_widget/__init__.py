from tetra import BasicComponent


class AccountSectionWidget(BasicComponent):
    pass
