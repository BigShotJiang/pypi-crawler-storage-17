from gdaps import hooks

# hooks.define("app.my_hook")
