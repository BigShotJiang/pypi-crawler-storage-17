"""Telegram bot powered by PraisonAI multi-agent framework."""

from telegram_praisonai_bot.client import PraisonAIClient

__all__ = ["PraisonAIClient"]

__version__ = "0.1.0"
