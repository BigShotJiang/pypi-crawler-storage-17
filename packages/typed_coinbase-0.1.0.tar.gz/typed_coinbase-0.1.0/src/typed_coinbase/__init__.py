"""
### Typed Coinbase
> A fully typed, validated async client for the Coinbase API

- Details
"""