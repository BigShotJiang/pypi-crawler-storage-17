# Typed Coinbase

> A fully typed, validated async client for the Coinbase API

Use *autocomplete* instead of documentation.

🚧 Under construction.