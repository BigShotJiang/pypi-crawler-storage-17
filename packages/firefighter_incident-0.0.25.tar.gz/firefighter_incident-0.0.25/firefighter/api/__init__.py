"""The `api` app exposes the API endpoints for the application.

It uses the `rest_framework` package to provide the API endpoints.
"""
