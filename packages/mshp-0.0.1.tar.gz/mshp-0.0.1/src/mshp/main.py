def inp():
	return [int(i) for i in input().split() if i]