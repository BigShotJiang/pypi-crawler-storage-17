"""
### Typed Bitstamp
> A fully typed, validated async client for the Bitstamp API

- Details
"""