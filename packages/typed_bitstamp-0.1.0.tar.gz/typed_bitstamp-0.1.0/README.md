# Typed Bitstamp

> A fully typed, validated async client for the Bitstamp API

Use *autocomplete* instead of documentation.

🚧 Under construction.