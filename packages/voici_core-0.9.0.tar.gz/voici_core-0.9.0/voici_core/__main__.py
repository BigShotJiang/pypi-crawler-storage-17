if __name__ == '__main__':
    from voici.app import main

    main()
