######################
Account Payment Module
######################

The *Account Payment Module* manages the receivable and payable payments.
A payment is an order to pay an amount to a party or to receive an amount from
a party.
Such order can be electronic payment, bank order or checks.


.. toctree::
   :maxdepth: 2

   design
   releases
