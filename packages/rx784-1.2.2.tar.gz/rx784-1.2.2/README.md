### **项目永久终止及免责声明**
### **Project Permanently Terminated & Disclaimer**

**最后更新及终止日期：2025/12/17**
**Last Updated & Termination Date: 2025/12/17**

---

**(English Version)**

This project (`rx784`) has been permanently terminated by its original author.

*   The source code repository has been completely deleted.
*   All versions of this project on PyPI have been yanked and cannot be installed via standard `pip` commands.
*   There will be no further updates, support, or security fixes for this project.

**Warning:**
Anyone who obtains, uses, or distributes any historical version of this package does so at their own extreme risk. The author explicitly disclaims any and all liability for any direct or indirect damages, losses, or legal issues arising from the continued use of this software. This notice serves as a final emphasis on the disclaimer of warranty provided in the project's original open-source license.

---

**(中文版本)**

本项目 (`rx784`) 已被其原作者永久终止。

*   源代码仓库已被完全删除。
*   本项目在 PyPI 上的所有版本均已被撤回 (Yanked)，无法通过 `pip` 常规安装。
*   本项目将不会再有任何更新、支持或安全修复。

**警告：**
任何以任何方式获取、使用或分发本项目的历史版本的行为，均需自行承担全部极端风险。作者明确声明，不对任何因继续使用本软件而导致的直接或间接的损害、损失或法律纠纷承担任何责任。本声明是对项目原始开源许可证中免责条款的最终强调。