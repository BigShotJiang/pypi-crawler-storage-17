# sslm/__init__.py

from .core import SunLM_Model, ols

__all__ = ["SunLM_Model", "ols"]