# TXL plugin for an image viewer
