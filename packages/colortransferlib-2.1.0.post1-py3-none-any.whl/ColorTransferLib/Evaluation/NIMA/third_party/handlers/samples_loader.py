
from ..utils.utils import load_json


def load_samples(samples_file):
    return load_json(samples_file)
