from .Ji22 import Ji22

__all__ = ["Ji22"]