# GENERATED VERSION FILE
# TIME: Tue Jan 28 20:43:31 2025
__version__ = '1.3.4.6'
__gitsha__ = 'unknown'
version_info = (1, 3, 4, 6)
