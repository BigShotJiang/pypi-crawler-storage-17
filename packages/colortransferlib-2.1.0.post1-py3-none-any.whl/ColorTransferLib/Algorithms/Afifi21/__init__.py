from .Afifi21 import Afifi21

__all__ = ["Afifi21"]