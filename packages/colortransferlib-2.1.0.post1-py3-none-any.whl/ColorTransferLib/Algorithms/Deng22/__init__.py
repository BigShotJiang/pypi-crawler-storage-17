from .Deng22 import Deng22

__all__ = ["Deng22"]
