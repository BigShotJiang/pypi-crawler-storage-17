from .Gatys15 import Gatys15

__all__ = ["Gatys15"]
