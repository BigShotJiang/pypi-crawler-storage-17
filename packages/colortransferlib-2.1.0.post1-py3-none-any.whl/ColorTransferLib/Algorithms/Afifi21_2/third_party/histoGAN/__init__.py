#from histoGAN.histoGAN import Trainer, HistoGAN, NanException, \
#  Generator, GeneratorBlock, HistVectorizer, RGBBlock, \
#  Conv2DMod, Discriminator, DiscriminatorBlock