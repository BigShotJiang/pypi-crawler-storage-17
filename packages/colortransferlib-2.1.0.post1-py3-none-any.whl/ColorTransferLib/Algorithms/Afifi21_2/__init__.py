from .Afifi21_2 import Afifi21_2

__all__ = ["Afifi21_2"]