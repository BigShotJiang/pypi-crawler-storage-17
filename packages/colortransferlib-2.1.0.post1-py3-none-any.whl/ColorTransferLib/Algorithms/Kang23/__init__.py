from .Kang23 import Kang23

__all__ = ["Kang23"]