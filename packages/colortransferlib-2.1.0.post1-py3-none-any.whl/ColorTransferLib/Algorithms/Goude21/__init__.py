from .Goude21 import Goude21

__all__ = ["Goude21"]
