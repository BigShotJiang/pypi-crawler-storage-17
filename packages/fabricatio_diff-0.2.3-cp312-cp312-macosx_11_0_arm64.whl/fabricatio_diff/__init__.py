"""An extension of fabricatio, which brings up the diff edit capabilities."""
