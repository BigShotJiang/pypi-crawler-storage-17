"""Actions defined in fabricatio-diff."""
