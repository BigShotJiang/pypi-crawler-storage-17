"""
LRP helpers.
"""
