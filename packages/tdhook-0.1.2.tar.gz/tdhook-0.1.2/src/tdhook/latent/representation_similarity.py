# CKA: Similarity of Neural Network Representations Revisited
# Mutual k-Nearest Neighbor Alignment Metric: The Platonic Representation Hypothesis
# Information Imbalance: A quantitative analysis of semantic information in deep representations of text and images
