"""Utility functions for lsdpy."""

from sclsd.utils.seed import set_all_seeds, get_device

__all__ = ["set_all_seeds", "get_device"]
