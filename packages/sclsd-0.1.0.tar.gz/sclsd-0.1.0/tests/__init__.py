"""LSDpy test suite."""
