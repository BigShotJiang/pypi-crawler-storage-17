"""Integration tests for LSDpy end-to-end workflows."""
