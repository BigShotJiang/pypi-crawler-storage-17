"""Reproducibility and parity tests for LSDpy."""
