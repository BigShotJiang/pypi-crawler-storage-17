# Frame/mockup components for wrapping content
