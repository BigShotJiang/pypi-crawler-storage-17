"""
MCP Tools for Remotion video generation.

This package contains tool definitions organized by functionality:
- theme_tools: Theme management and discovery
"""
