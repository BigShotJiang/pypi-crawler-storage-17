"""Storage layer for chuk-motion artifact management."""

from .artifact_storage import ArtifactStorageManager

__all__ = ["ArtifactStorageManager"]
