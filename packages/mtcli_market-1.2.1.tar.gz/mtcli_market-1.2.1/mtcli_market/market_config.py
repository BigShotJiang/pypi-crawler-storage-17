MARKETS = {
    "b3_fut": {"hour": 9, "minute": 0, "utc_offset": -3},
    "b3_stk": {"hour": 10, "minute": 0, "utc_offset": -3},
    "cfd_us": {"hour": 15, "minute": 30, "utc_offset": -3},
    "cfd_br": {"hour": 13, "minute": 0, "utc_offset": -3},
    "cfd_eu": {"hour": 9, "minute": 0, "utc_offset": -3},
    "cfd_uk": {"hour": 8, "minute": 0, "utc_offset": -3},
    "cfd_jp": {"hour": 1, "minute": 0, "utc_offset": -3},
}
