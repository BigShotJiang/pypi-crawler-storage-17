# -*- coding: utf-8 -*-
"""Motion MCP Server Package."""

__version__ = "0.1.0"
