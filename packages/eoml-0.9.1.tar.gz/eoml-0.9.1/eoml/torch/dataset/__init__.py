"""
Dataset Submodule for PyTorch.

This submodule provides specialized dataset creators and utilities for
specific machine learning tasks in Earth observation applications.
"""
