import pytest
from denemePackaging.statistics import mean


def test_mean():
    assert mean([1, 2, 3, 4]) == 2.5


def test_mean_empty_list():
    with pytest.raises(ValueError):
        mean([])
