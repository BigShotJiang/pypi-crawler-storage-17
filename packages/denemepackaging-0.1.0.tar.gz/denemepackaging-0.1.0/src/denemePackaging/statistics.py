def mean(numbers):
    """
    Calculate the arithmetic mean of a list of numbers.
    """
    if not numbers:
        raise ValueError("The list is empty")

    return sum(numbers) / len(numbers)
