from setuptools import setup, find_packages

setup(
    name='lego_Denis',        # название вашей библиотеки
    version='0.1.0',          # версия
    packages=find_packages(),
    author='Denis',
    author_email='denisfomenko098@gmail.com',
    description='Моя первая библиотека',
    url='https://github.com/Fifaro/lego_Denis',  # если есть
)