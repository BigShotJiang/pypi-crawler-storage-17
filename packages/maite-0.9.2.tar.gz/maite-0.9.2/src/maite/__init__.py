# Copyright 2024, MASSACHUSETTS INSTITUTE OF TECHNOLOGY
# Subject to FAR 52.227-11 – Patent Rights – Ownership by the Contractor (May 2014).
# SPDX-License-Identifier: MIT

from typing import TYPE_CHECKING

if not TYPE_CHECKING:
    try:
        from ._version import __version__
    except ImportError:
        __version__ = "unknown version"
else:  # pragma: no cover
    __version__: str
