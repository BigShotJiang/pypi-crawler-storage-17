# Sentiment Analysis

::: sieves.tasks.predictive.sentiment_analysis.core
::: sieves.tasks.predictive.sentiment_analysis.bridges