# Summarization

::: sieves.tasks.predictive.summarization.core
::: sieves.tasks.predictive.summarization.bridges