# Docling

Note: This task depends on optional ingestion libraries, which are not installed by default. Install them via the ingestion extra, or install the library directly.

Examples:

```bash
pip install "sieves[ingestion]"   # installs ingestion deps via extra
# or install the library directly
pip install docling
```

 ::: sieves.tasks.preprocessing.ingestion.docling_
