# NaiveChunker

::: sieves.tasks.preprocessing.chunking.naive