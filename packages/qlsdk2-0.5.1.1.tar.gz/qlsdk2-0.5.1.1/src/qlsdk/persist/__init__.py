from .edf import EdfHandler
from .rsc_edf import RscEDFHandler
from .ars_edf import ARSKindlingEDFHandler