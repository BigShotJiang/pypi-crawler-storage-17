# version
__version__ = "0.2.0"
# author
__author__ = "Sina Gilassi"
# email
__email__ = "sina.gilassi@gmail.com"
# license
__license__ = "MIT"
# package description
__description__ = "A Python package for thermodynamic property estimation."
