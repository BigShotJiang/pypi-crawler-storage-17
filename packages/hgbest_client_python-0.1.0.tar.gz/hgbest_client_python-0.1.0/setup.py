from setuptools import setup, find_packages

setup(
    name='hgbest-client-python',  # This is the package name for PyPI installation
    version='0.1.0',             # IMPORTANT: Update this version number for every new release!
    author='HAVENGROUP', # Replace with your name/company
    author_email='agborboris5@gmail.com', # Replace with your email
    description='Python SDK for the HgBest API, providing secure, signed access to various services.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/HAVENGROUP12/sdk-python.git', # Replace with the URL to your GitHub repository for this SDK
    packages=find_packages(),    # This will automatically find the 'hgbest_client' directory
    install_requires=[
        'requests>=2.25.1',      # Minimum version of the requests library
    ],
    classifiers=[
        'Development Status :: 3 - Alpha', # Or 4 - Beta, 5 - Production/Stable
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'License :: OSI Approved :: MIT License', # Ensure this matches your LICENSE file
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: OS Independent',
    ],
    keywords='hgbest api sdk client',
    python_requires='>=3.6',     # Minimum Python version required for your SDK
)
