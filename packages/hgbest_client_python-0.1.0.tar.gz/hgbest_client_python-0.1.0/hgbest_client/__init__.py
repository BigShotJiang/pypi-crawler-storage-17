import hashlib
import hmac
import time
import json
import requests

class HgBestClientPython:
    """
    Initializes the HgBestClient with API credentials and base URL.
    """
    def __init__(self, api_key: str, api_secret: str, base_url: str = 'https://hgbest-backend.onrender.com'):
        if not api_key or not api_secret:
            raise ValueError('HgBestClient requires both api_key and api_secret.')

        self.api_key = api_key
        self.api_secret = api_secret.encode('utf-8')  # HMAC secret must be bytes
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        })

    def _generate_sha256_hash(self, data: str) -> str:
        """
        Generates an SHA256 hash of a string.
        """
        return hashlib.sha256(data.encode('utf-8')).hexdigest()

    def _generate_signature(self, method: str, path: str, timestamp: str, request_body: str) -> str:
        """
        Generates an HMAC SHA256 signature for the request.
        """
        body_hash = self._generate_sha256_hash(request_body)

        string_to_sign = f"{method}\n{path}\n{timestamp}\n{body_hash}"

        # hmac.new expects key as bytes
        hmac_obj = hmac.new(self.api_secret, string_to_sign.encode('utf-8'), hashlib.sha256)
        return hmac_obj.hexdigest()

    def _send_signed_request(self, method: str, endpoint: str, data: dict = None):
        """
        Makes a signed API request to the backend.
        """
        timestamp = str(int(time.time() * 1000))  # Unix milliseconds as string

        request_body_str = ""
        if data and (method == 'POST' or method == 'PUT'):
            request_body_str = json.dumps(data, separators=(',', ':')) # Ensure no extra spaces

        signature = self._generate_signature(method, endpoint, timestamp, request_body_str)

        headers = {
            'X-API-KEY': self.api_key,
            'X-API-TIMESTAMP': timestamp,
            'X-API-SIGNATURE': signature,
        }
        self.session.headers.update(headers)

        url = f"{self.base_url}{endpoint}"

        try:
            if method == 'GET':
                response = self.session.get(url, params=data) # GET requests send data as params
            elif method == 'POST':
                response = self.session.post(url, json=data)
            elif method == 'PUT':
                response = self.session.put(url, json=data)
            elif method == 'DELETE':
                response = self.session.delete(url, json=data) # DELETE requests can also have a body
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            response.raise_for_status() # Raise an HTTPError for bad responses (4xx or 5xx)
            return response.json()
        except requests.exceptions.HTTPError as e:
            print(f"API Error for {method} {endpoint}: {e.response.status_code} - {e.response.text}")
            raise
        except requests.exceptions.RequestException as e:
            print(f"Request Error for {method} {endpoint}: {e}")
            raise

    # --- API Methods (Examples) ---

    @property
    def health(self):
        return _HealthAPI(self)

    @property
    def risk(self):
        return _RiskAPI(self)

class _HealthAPI:
    def __init__(self, client: 'HgBestClientPython'):
        self._client = client

    def submit_report(self, payload: dict):
        return self._client._send_signed_request('POST', '/health/reports', payload)

    def get_reports(self, report_id: str = None):
        endpoint = f'/health/reports/{report_id}' if report_id else '/health/reports'
        return self._client._send_signed_request('GET', endpoint)

class _RiskAPI:
    def __init__(self, client: 'HgBestClientPython'):
        self._client = client

    def global_supply_chain_alert(self, payload: dict):
        return self._client._send_signed_request('POST', '/risk/global-supply-chain-alert', payload)


# Example Usage for Python:
if __name__ == "__main__":
    # Replace with your actual API Key and Secret
    API_KEY = "YOUR_API_KEY"
    API_SECRET = "YOUR_API_SECRET"

    client = HgBestClientPython(API_KEY, API_SECRET)

    # Example: Submit a health report (POST request)
    try:
        report_payload = {
            "summaryDate": "2025-12-17",
            "requestId": "unique-report-12345",
            "riskScore": 85,
            "eventType": "SupplyChainDisruption",
            "anticipatedDelay": "2 weeks",
            "summary": "Potential delays due to port congestion in region X.",
            "immediateRecommendation": "Diversify shipping routes."
        }
        print("Submitting health report...")
        submit_response = client.health.submit_report(report_payload)
        print("Submit Report Response:", submit_response)
    except Exception as e:
        print(f"Failed to submit health report: {e}")

    # Example: Get all health reports (GET request)
    try:
        print("\nGetting all health reports...")
        all_reports = client.health.get_reports()
        print("All Reports:", all_reports)
    except Exception as e:
        print(f"Failed to get all health reports: {e}")

    # Example: Get a specific health report (GET request with ID)
    try:
        print("\nGetting specific health report...")
        specific_report = client.health.get_reports("reportIdFromPreviousResponse") # Use an actual report ID if available
        print("Specific Report:", specific_report)
    except Exception as e:
        print(f"Failed to get specific health report: {e}")

    # Example: Global supply chain alert (POST request)
    try:
        risk_payload = {
            "material_type": "Lithium-ion batteries",
            "region_of_origin": "Global",
            "logistics_route": "Asia to Europe via Suez Canal"
        }
        print("\nGetting global supply chain alert...")
        risk_response = client.risk.global_supply_chain_alert(risk_payload)
        print("Risk Alert Response:", risk_response)
    except Exception as e:
        print(f"Failed to get risk alert: {e}")

