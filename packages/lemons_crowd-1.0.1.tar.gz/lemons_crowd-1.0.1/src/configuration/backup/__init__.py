"""Backup subpackage offers modules for exporting Python objects of Crowd, Parameters... to and from dictionaries, and XML formats."""
