"""Configuration subpackage provides the subpackages necessary to create configuration files for a crowd simulation."""
