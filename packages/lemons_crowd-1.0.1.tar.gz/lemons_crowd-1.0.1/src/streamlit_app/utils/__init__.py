"""Utils provides basic useful functions, constants definitions and custom logging settings."""
