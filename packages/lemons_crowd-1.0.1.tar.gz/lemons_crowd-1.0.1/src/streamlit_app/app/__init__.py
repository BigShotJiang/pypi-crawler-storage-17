"""App subpackage provides the main modules to launch the app and document it."""
