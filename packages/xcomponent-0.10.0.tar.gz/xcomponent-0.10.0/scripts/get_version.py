import xcomponent

__version__ = xcomponent.__version__

if __name__ == "__main__":
    print(__version__, end="")
