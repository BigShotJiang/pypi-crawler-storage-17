# __NetKet model Library__

In this folder there are some models you can use with NetKet. 
Most of them are written using Flax.

If you want to understand how to write Flax models, you can find
some inspiration by reading the source code of those models.

In order of difficulty, RBM models are the simplest, ndm are matrix models
that compose several sub-modules, and MPS is relatively complex. 