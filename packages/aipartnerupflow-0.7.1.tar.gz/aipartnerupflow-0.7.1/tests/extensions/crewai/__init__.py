"""
Tests for CrewAI extension module
"""

