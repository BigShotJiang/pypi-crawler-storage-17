from ._base_getter import Getter

class EquivalentAdult(Getter):
	"""
		Obtencion del df de adulto equivalente
	"""

	folder = "adulto_equivalente"
	filename = "adulto_equivalente.zip"
