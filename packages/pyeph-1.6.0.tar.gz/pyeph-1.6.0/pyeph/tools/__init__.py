from .labels import (
    vars_labels,
    etiquetas_vars,
    map_labels,
    etiquetar
)

from .merge import (
    merge, 
    aparear
)