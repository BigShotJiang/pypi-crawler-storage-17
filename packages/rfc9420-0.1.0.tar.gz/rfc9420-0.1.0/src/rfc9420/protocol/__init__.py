"""Protocol-layer primitives and state machines for PyMLS (RFC 9420)."""

