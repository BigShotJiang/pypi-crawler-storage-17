# Extergram

Простая и удобная библиотека для создания Telegram-ботов на Python.

## Установка

\`\`\`bash
pip install extergram
\`\`\`

## Пример использования

\`\`\`python
from extergram import Bot, Msg, ButtonsDesign, Markdown

# Замените 'YOUR_BOT_TOKEN' на ваш токен
bot = Bot('YOUR_BOT_TOKEN')
msg = Msg(bot)

# ID чата, куда будет отправлено сообщение
chat_id = 123456789

# Простое сообщение
msg.send(chat_id, "Привет, мир!")

# Сообщение с MarkdownV2
formatted_text = f"{Markdown.bold('Привет')}, это {Markdown.italic('Extergram')}!"
msg.send(chat_id, formatted_text, parse_mode='MarkdownV2')

# Сообщение с кнопками
buttons = ButtonsDesign().add_row(
    ButtonsDesign.create_button("Кнопка 1", "callback_1"),
    ButtonsDesign.create_button("Кнопка 2", "callback_2")
)
msg.send(chat_id, "Сообщение с кнопками:", reply_markup=buttons)

print("Сообщения отправлены!")
\`\`\`

## Возможности

*   Простой и интуитивно понятный синтаксис.
*   Встроенная поддержка и автоматическое экранирование для MarkdownV2.
*   Удобный конструктор для создания встроенных клавиатур.