class ButtonsDesign:
    def __init__(self, inline_keyboard: list = None):
        self.keyboard = inline_keyboard if inline_keyboard else []

    def add_row(self, *buttons):
        self.keyboard.append(list(buttons))
        return self

    def to_dict(self):
        return {"inline_keyboard": self.keyboard}

    @staticmethod
    def create_button(text: str, callback_data: str):
        return {"text": text, "callback_data": callback_data}
