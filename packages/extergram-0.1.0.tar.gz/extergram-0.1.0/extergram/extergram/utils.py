import re

def escape_markdown_v2(text: str) -> str:
    escape_chars = r'_*[]()~`>#+-=|{}.!'
    return re.sub(f'([{re.escape(escape_chars)}])', r'\\\1', text)

class Markdown:
    @staticmethod
    def bold(text: str) -> str:
        return f"*{escape_markdown_v2(text)}*"

    @staticmethod
    def italic(text: str) -> str:
        return f"_{escape_markdown_v2(text)}_"

    @staticmethod
    def code(text: str) -> str:
        return f"`{escape_markdown_v2(text)}`"

    @staticmethod
    def pre(text: str, language: str = "") -> str:
        return f"```{language}\n{escape_markdown_v2(text)}\n```"

    @staticmethod
    def link(text: str, url: str) -> str:
        return f"[{escape_markdown_v2(text)}]({url})"
