import requests
import json
from .ui import ButtonsDesign
from .utils import escape_markdown_v2

class Bot:
    def __init__(self, token: str):
        self.token = token
        self.api_url = f"https://api.telegram.org/bot{self.token}/"

    def _make_request(self, method: str, params: dict = None):
        response = requests.post(self.api_url + method, json=params)
        response.raise_for_status()
        return response.json()

    def get_updates(self, offset: int = None, timeout: int = 30):
        params = {'timeout': timeout, 'offset': offset}
        return self._make_request('getUpdates', params)

    def send_message(self, chat_id: int, text: str, parse_mode: str = None, reply_markup: dict = None):
        params = {'chat_id': chat_id, 'text': text}
        if parse_mode:
            params['parse_mode'] = parse_mode
        if reply_markup:
            params['reply_markup'] = reply_markup
        return self._make_request('sendMessage', params)

class Msg:
    def __init__(self, bot: Bot):
        self.bot = bot

    def send(self, chat_id: int, text: str, parse_mode: str = None, reply_markup: ButtonsDesign = None):
        markup = reply_markup.to_dict() if reply_markup else None
        return self.bot.send_message(chat_id, text, parse_mode, markup)
