The low-level GL module
=======================

Vispy has a low-level `gl` module which wraps `GL` calls almost to a 1-to-1 ratio. While this is intended mostly for internal use, it is possible to use this to construct programs.
