Sphinx sources for the vispy website
====================================

Build Instructions
------------------

VisPy documentation should be generated via the `make` script in the VisPy
code repository. A typical sequence of commands is::

    python make website html

See the VisPy python repository for details.
