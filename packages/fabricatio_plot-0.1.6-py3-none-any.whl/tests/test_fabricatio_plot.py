"""Tests for the plot."""
