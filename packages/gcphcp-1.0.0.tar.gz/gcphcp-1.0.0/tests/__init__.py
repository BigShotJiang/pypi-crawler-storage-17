"""Test suite for GCP HCP CLI."""
