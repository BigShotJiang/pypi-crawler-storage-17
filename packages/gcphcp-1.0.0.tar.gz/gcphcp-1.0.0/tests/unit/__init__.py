"""Unit tests for GCP HCP CLI."""
