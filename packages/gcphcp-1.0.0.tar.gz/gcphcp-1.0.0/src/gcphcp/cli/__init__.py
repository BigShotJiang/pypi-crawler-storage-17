"""CLI module for GCP HCP CLI."""

from .main import main

__all__ = ["main"]
