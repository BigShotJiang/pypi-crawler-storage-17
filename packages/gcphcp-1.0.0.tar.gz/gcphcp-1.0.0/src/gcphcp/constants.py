"""Common constants used across the gcphcp CLI."""

# Default GCP region for infrastructure and cluster resources
DEFAULT_REGION = "us-central1"
