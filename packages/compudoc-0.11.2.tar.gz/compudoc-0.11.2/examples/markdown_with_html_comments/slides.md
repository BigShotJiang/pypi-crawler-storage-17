---
title: Example
---

# Header 1


$x = 10$
