---
title: Example
---

# Math


If we have $x = 10$ and $y = 4$, then
$x/y = 2.5$.





# Generating slides in a loop: One

text...



# Generating slides in a loop: Two

text...



# Generating slides in a loop: Three

text...



# Including files

Some source code
```cpp
// simple main function
int main()
{
  return 0;
}

```
