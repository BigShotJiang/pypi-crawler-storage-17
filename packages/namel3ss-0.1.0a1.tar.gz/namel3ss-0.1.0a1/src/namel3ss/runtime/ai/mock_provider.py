from __future__ import annotations

from namel3ss.runtime.ai.providers.mock import MockProvider

__all__ = ["MockProvider"]
