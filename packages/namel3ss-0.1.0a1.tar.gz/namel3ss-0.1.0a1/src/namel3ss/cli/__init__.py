"""Command-line interface for Namel3ss."""

