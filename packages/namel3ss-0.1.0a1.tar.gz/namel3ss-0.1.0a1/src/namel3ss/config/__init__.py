from namel3ss.config.loader import load_config
from namel3ss.config.model import AppConfig, OllamaConfig

__all__ = ["load_config", "AppConfig", "OllamaConfig"]
