"""Parsing pipeline for Namel3ss."""

from namel3ss.parser.core import Parser, parse  # noqa: F401
