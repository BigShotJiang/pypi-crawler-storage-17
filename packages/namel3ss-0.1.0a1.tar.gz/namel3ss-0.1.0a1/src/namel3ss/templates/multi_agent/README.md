# {{PROJECT_NAME}} (Multi-Agent)

Planner, critic, and researcher agents collaborating on a shared assistant with a single workflow page.

Run it with:
- `n3 app.ai check`
- `n3 app.ai studio`
- `n3 app.ai actions`

Put any API keys in a local `.env` (not committed).
