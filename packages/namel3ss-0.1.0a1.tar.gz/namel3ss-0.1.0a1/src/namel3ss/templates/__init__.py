"""Project templates for `n3 new`."""

__all__ = []
