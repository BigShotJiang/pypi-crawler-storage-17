# {{PROJECT_NAME}} (CRUD)

Starter CRUD dashboard with a customer record, seed flow, and a combined form/table page.

Run it with:
- `n3 app.ai check`
- `n3 app.ai studio`
- `n3 app.ai actions`

Put any API keys in a local `.env` (not committed).
