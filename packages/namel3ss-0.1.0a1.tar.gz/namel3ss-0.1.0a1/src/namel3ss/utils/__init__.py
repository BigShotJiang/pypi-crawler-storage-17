"""Shared utilities for Namel3ss."""

