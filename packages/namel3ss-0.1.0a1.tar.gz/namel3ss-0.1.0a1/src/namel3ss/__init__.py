"""
Namel3ss: an English-first, AI-native full-stack programming language runtime package.
"""

