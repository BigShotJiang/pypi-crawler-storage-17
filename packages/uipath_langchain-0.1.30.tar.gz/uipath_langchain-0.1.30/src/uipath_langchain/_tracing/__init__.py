from ._instrument_traceable import _instrument_traceable_attributes

__all__ = [
    "_instrument_traceable_attributes",
]
