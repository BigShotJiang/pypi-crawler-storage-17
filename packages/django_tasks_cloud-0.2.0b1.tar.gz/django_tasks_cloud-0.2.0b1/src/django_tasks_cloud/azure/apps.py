from django.apps import AppConfig


class AzureConfig(AppConfig):
    name = "django_tasks_cloud.azure"
