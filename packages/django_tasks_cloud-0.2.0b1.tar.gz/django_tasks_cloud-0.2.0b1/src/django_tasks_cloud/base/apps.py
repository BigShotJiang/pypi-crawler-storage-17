from django.apps import AppConfig


class BaseConfig(AppConfig):
    name = "django_tasks_cloud.base"
