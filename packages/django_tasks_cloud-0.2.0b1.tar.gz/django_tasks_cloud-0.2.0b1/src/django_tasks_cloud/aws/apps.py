from django.apps import AppConfig


class AWSConfig(AppConfig):
    name = "django_tasks_cloud.aws"
