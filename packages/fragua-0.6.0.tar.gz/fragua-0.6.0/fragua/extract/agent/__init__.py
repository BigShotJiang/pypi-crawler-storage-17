"""
Extractor Agent Module.

This module contains:
- Extractor agent class.

"""

from .extractor import Extractor

__all__ = ["Extractor"]
