import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="SingleMeterValue")


@_attrs_define
class SingleMeterValue:
    """
    Example:
        {'technicalName': 'assembly_line_2', 'timestamp': '2024-01-01T00:00:00Z', 'value': 1234.56}

    Attributes:
        technical_name (str):
        timestamp (datetime.datetime):
        value (float):
    """

    technical_name: str
    timestamp: datetime.datetime
    value: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        technical_name = self.technical_name

        timestamp = self.timestamp.isoformat() + "Z"

        value = self.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "technicalName": technical_name,
                "timestamp": timestamp,
                "value": value,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        technical_name = d.pop("technicalName")

        timestamp = isoparse(d.pop("timestamp"))

        value = d.pop("value")

        single_meter_value = cls(
            technical_name=technical_name,
            timestamp=timestamp,
            value=value,
        )

        single_meter_value.additional_properties = d
        return single_meter_value

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
