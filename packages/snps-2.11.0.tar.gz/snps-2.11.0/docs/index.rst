.. lineage documentation master file, created by
   sphinx-quickstart on Wed Jul 19 23:32:11 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

`snps`
======
*tools for reading, writing, merging, and remapping SNPs*


.. toctree::
   :maxdepth: 2
   :caption: Contents

   README <readme>
   output_files
   installation
   snps_banner
   changelog
   contributing
   contributors
   snps

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
