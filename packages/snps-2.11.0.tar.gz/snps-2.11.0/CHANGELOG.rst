Changelog
=========

The changelog is maintained here: https://github.com/apriha/snps/releases
