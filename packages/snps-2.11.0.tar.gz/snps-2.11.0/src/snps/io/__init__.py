"""Classes for reading and writing SNPs."""

from .reader import Reader as Reader
from .reader import get_empty_snps_dataframe as get_empty_snps_dataframe
from .writer import Writer as Writer
