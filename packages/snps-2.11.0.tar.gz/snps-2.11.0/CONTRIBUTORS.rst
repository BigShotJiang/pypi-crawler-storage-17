.. Layout based on https://github.com/pydanny/cookiecutter-django/blob/master/CONTRIBUTORS.rst

Contributors
============

`Contributors <https://github.com/apriha/snps/graphs/contributors>`_ to
``snps`` are listed below.

Core Developers
---------------

=========== ===============
Name        GitHub
=========== ===============
Andrew Riha `@apriha`_
Will Jones  `@willgdjones`_
=========== ===============

.. _@apriha: https://github.com/apriha
.. _@willgdjones: https://github.com/willgdjones

Other Contributors
------------------

Listed in alphabetical order.

================ =================
Name             GitHub
================ =================
Alan Moffet      `@amoffet`_
Anatoli Babenia  `@abitrolly`_
Castedo Ellerman `@castedo`_
Gerard Manning   `@GerardManning`_
Julian Runnels   `@JulianRunnels`_
Kevin Arvai      `@arvkevi`_
Phil Palmer      `@PhilPalmer`_
Yoan Bouzin
================ =================

.. _@amoffet: https://github.com/amoffet
.. _@abitrolly: https://github.com/abitrolly
.. _@castedo: https://github.com/castedo
.. _@GerardManning: https://github.com/GerardManning
.. _@JulianRunnels: https://github.com/JulianRunnels
.. _@arvkevi: https://github.com/arvkevi
.. _@PhilPalmer: https://github.com/PhilPalmer
