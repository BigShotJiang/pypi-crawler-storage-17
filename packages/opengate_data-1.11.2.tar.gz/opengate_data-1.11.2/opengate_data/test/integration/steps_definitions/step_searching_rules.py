# opengate_data/test/integration/steps_definitions/step_searching_entities.py

from pytest_bdd import scenarios

scenarios("searching/searching_rules.feature")

