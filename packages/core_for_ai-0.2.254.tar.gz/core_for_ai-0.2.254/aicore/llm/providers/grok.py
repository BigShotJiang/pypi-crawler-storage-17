from aicore.llm.providers.openai import OpenAiLlm

class GrokLlm(OpenAiLlm):
    
    base_url :str="https://api.x.ai/v1"