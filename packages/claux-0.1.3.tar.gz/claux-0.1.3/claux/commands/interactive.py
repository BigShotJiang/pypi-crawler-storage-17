"""
Interactive menu system for Claux CLI.

Provides a rich, user-friendly terminal interface.
"""

import sys
import os
import typer
from InquirerPy import inquirer
from InquirerPy.base.control import Choice
from InquirerPy.separator import Separator
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from claux import __version__
from claux.i18n import get_language
from claux.core.user_config import get_config

# Fix Windows console encoding
if os.name == "nt":
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleOutputCP(65001)  # UTF-8
    except Exception:
        pass

app = typer.Typer(help="Interactive mode")
console = Console(force_terminal=True, legacy_windows=False)

# Global flag to show banner only once
_banner_shown = False


def get_system_info():
    """Get system status information."""
    try:
        from claux.core.mcp import get_active_config
        from claux.core.profiles import get_active_profile

        mcp_config = get_active_config()
        profile = get_active_profile()
        py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

        return {
            "python": py_version,
            "mcp": mcp_config or "none",
            "profile": profile or "none",
            "language": get_language(),
        }
    except Exception:
        return {
            "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "mcp": "none",
            "profile": "none",
            "language": get_language(),
        }


def show_banner(force=False):
    """Display welcome banner with system info (only once by default)."""
    global _banner_shown

    if _banner_shown and not force:
        return

    _banner_shown = True

    # Get system info
    info = get_system_info()

    # Info bar
    mcp_info = f"🔌 MCP: {info['mcp']}"
    profile_info = f"🤖 Profile: {info['profile']}"
    lang_info = f"🌍 {info['language'].upper()}"
    info_line = f"🐍 Python {info['python']}  *  {mcp_info}  *  {profile_info}  *  {lang_info}"

    banner_panel = Panel(
        f"[bold cyan]🎼 Claux[/bold cyan] [bold white]v{__version__}[/bold white]\n"
        f"[dim italic]Token-Efficient AI Automation[/dim italic]\n\n"
        f"[dim]{info_line}[/dim]",
        border_style="bold cyan",
        padding=(1, 2),
    )

    console.print()
    console.print(banner_panel)
    console.print()


def show_help_footer():
    """Show compact help footer with keyboard shortcuts."""
    console.print("[dim]Keys: ↑↓ navigate | ↵ select | q quit | h help | Ctrl+C exit[/dim]\n")


def show_breadcrumbs(path: str):
    """Show navigation breadcrumbs."""
    breadcrumb = Text()
    breadcrumb.append("┌─ ", style="dim cyan")
    breadcrumb.append("📍 ", style="")

    parts = path.split(" > ")
    for i, part in enumerate(parts):
        if i > 0:
            breadcrumb.append(" -> ", style="dim cyan")
        breadcrumb.append(part, style="bold cyan" if i == len(parts) - 1 else "dim")

    console.print(breadcrumb)
    console.print()


def main_menu():
    """Show main interactive menu."""
    console.clear()
    show_banner()
    console.print("[bold cyan]Main Menu[/bold cyan]\n")
    show_help_footer()

    # Group choices by category for better organization
    choices = [
        # Setup & Quick Start
        Choice(value="wizard", name="🧙  Setup Wizard - Auto-configure projects"),
        Separator(),
        # Configuration
        Choice(value="mcp", name="🔌  MCP Configuration - Manage MCP servers"),
        Choice(value="agents", name="🤖  Agent Profiles - Configure AI agents"),
        Choice(value="config", name="⚙️  Settings - Manage configuration"),
        Choice(value="lang", name="🌍  Language - Change interface language"),
        Separator(),
        # Tools & Utilities
        Choice(value="bookmarks", name="📚  Project Bookmarks - Quick project access"),
        Choice(value="doctor", name="🩺  System Doctor - Diagnose issues"),
        Choice(value="history", name="📜  Command History - View past commands"),
        Separator(),
        # Help & Exit
        Choice(value="help", name="❓  Help & Docs - View documentation"),
        Choice(value="exit", name="🚪  Exit (q)"),
    ]

    try:
        action = inquirer.select(
            message="Select an option:",
            choices=choices,
            default="wizard",
            pointer=">",
        ).execute()

        # Handle keyboard shortcuts
        if action == "q":
            action = "exit"

    except KeyboardInterrupt:
        return "exit"
    except Exception:
        # Fallback for Cygwin and other incompatible terminals
        console.print("[yellow]!  Interactive mode not supported in this terminal.[/yellow]")
        console.print("[dim]Try running in Windows CMD, PowerShell, or Windows Terminal.[/dim]\n")
        console.print("Available commands:")
        console.print("  claux wizard    - Run setup wizard")
        console.print("  claux mcp       - Manage MCP configurations")
        console.print("  claux agents    - Manage agent profiles")
        console.print("  claux lang      - Change language")
        console.print("  claux --help    - Show all commands\n")
        return "exit"

    return action


def mcp_menu():
    """MCP configuration submenu."""
    from claux.core.mcp import list_configs, get_active_config

    console.clear()
    console.print("[bold cyan]MCP Configuration[/bold cyan] [dim](Main Menu > MCP)[/dim]\n")
    show_help_footer()

    configs = list_configs()
    current = get_active_config()

    if not configs:
        console.print("[yellow]No MCP configurations found.[/yellow]")
        console.print("[dim]Make sure you're in a valid project directory.[/dim]\n")
        typer.pause("Press Enter to return...")
        return

    # Create compact table
    table = Table(
        show_header=True,
        header_style="bold white",
        border_style="dim",
        padding=(0, 1),
    )
    table.add_column("", style="green", width=3)  # Status indicator
    table.add_column("Name", style="cyan")
    table.add_column("Tokens", style="yellow", justify="right")
    table.add_column("Description", style="dim")

    config_details = {
        "base": ("~600", "Essential servers (context7, sequential-thinking)"),
        "full": ("~5000", "All servers (supabase, playwright, n8n, shadcn)"),
    }

    for config_name in configs:
        indicator = "[*]" if config_name == current else "[ ]"
        tokens, desc = config_details.get(config_name, ("?", "Custom configuration"))
        table.add_row(indicator, config_name, tokens, desc)

    console.print(table)
    console.print()

    choices = []
    for c in configs:
        prefix = "[*] " if c == current else "    "
        choices.append(Choice(value=c, name=f"{prefix}{c}"))

    choices.append(Separator())
    choices.append(Choice(value="back", name="< Back (b)"))

    selection = inquirer.select(
        message="Select configuration:",
        choices=choices,
        default=current if current else configs[0],
        pointer=">",
    ).execute()

    if selection == "back" or selection == "b":
        return

    # Switch MCP config
    from claux.core.mcp import switch_config

    switch_config(selection)

    console.print(f"\n[green]✓[/green] Switched to [bold cyan]{selection}[/bold cyan]")
    console.print("[yellow]![/yellow] Restart Claude Code for changes to take effect\n")

    typer.pause("Press Enter to continue...")


def agent_profiles_menu():
    """Agent profiles submenu."""
    from claux.core.profiles import list_profiles, get_active_profile

    console.clear()
    console.print("[bold cyan]Agent Profiles[/bold cyan] [dim](Main Menu > Profiles)[/dim]\n")
    show_help_footer()

    profiles = list_profiles()
    current = get_active_profile()

    if not profiles:
        console.print("[yellow]No agent profiles found.[/yellow]")
        console.print("[dim]Make sure you're in a valid project directory.[/dim]\n")
        typer.pause("Press Enter to return...")
        return

    # Create compact table
    table = Table(
        show_header=True,
        header_style="bold white",
        border_style="dim",
        padding=(0, 1),
    )
    table.add_column("", style="green", width=3)
    table.add_column("Profile", style="cyan")
    table.add_column("Agents", style="blue", justify="right")
    table.add_column("Savings", style="yellow", justify="right")
    table.add_column("Description", style="dim")

    profile_info = {
        "base": ("8", "82%", "Minimal set"),
        "nextjs-full": ("28", "22%", "Full Next.js stack"),
        "health-all": ("15", "56%", "Health workflows"),
        "development": ("12", "67%", "General development"),
    }

    for profile in profiles:
        indicator = "[*]" if profile == current else "[ ]"
        agents, savings, desc = profile_info.get(profile, ("?", "?", "Custom"))
        table.add_row(indicator, profile, agents, savings, desc)

    console.print(table)
    console.print()

    choices = []
    for p in profiles:
        prefix = "[*] " if p == current else "    "
        choices.append(Choice(value=p, name=f"{prefix}{p}"))

    choices.append(Separator())
    choices.append(Choice(value="back", name="< Back (b)"))

    selection = inquirer.select(
        message="Select profile:",
        choices=choices,
        default=current if current else profiles[0],
        pointer=">",
    ).execute()

    if selection == "back" or selection == "b":
        return

    # Activate profile
    from claux.core.profiles import activate_profile

    activate_profile(selection)

    agents, savings, _ = profile_info.get(selection, ("?", "?", ""))
    console.print(f"\n[green]✓[/green] Activated [bold cyan]{selection}[/bold cyan]")
    console.print(f"[dim]  Agents: {agents} | Savings: {savings}[/dim]")
    console.print("[yellow]![/yellow] Restart Claude Code for changes to take effect\n")

    typer.pause("Press Enter to continue...")


def language_menu():
    """Language settings submenu."""
    from claux.i18n import get_available_languages, set_language, get_language

    console.clear()
    console.print("[bold cyan]Language Settings[/bold cyan] [dim](Main Menu > Language)[/dim]\n")
    show_help_footer()

    langs = get_available_languages()
    current = get_language()

    lang_names = {
        "en": "English",
        "ru": "Russian (Русский)",
    }

    console.print("[dim]Select your preferred interface language[/dim]\n")

    choices = []
    for lang in langs:
        prefix = "[*] " if lang == current else "    "
        choices.append(Choice(value=lang, name=f"{prefix}{lang_names.get(lang, lang)}"))

    choices.append(Separator())
    choices.append(Choice(value="back", name="< Back (b)"))

    selection = inquirer.select(
        message="Select language:",
        choices=choices,
        default=current,
        pointer=">",
    ).execute()

    if selection == "back" or selection == "b":
        return

    set_language(selection)

    # Reset banner flag so it shows with new language
    global _banner_shown
    _banner_shown = False

    lang_display = lang_names.get(selection, selection)
    console.print(
        f"\n[green]✓[/green] Language: [bold cyan]{lang_display}[/bold cyan]"
    )
    console.print(
        f"[dim]  Set CLAUX_LANG={selection} environment variable for permanent change[/dim]"
    )
    console.print("[dim]  Language will be applied on next screen[/dim]\n")

    typer.pause("Press Enter to continue...")


def config_menu():
    """Configuration menu."""
    config = get_config()

    console.clear()
    console.print("[bold cyan]Settings[/bold cyan] [dim](Main Menu > Settings)[/dim]\n")
    show_help_footer()

    console.print("[dim]Manage Claux configuration[/dim]\n")

    choices = [
        Choice(value="view", name="👁️  View Configuration"),
        Choice(value="edit", name="✏️  Edit Settings"),
        Choice(value="reset", name="🔄  Reset to Defaults"),
        Separator(),
        Choice(value="back", name="< Back (b)"),
    ]

    selection = inquirer.select(
        message="Select action:",
        choices=choices,
        pointer=">",
    ).execute()

    if selection == "back" or selection == "b":
        return
    elif selection == "view":
        import yaml

        console.print()
        console.print("[bold]Current Configuration:[/bold]\n")
        console.print(yaml.dump(config.load(), default_flow_style=False))
    elif selection == "reset":
        confirm = inquirer.confirm(
            message="Reset all settings to defaults?",
            default=False,
        ).execute()
        if confirm:
            config.reset()
            console.print("\n[green]✓[/green] Settings reset to defaults")

    console.print()
    typer.pause("Press Enter to continue...")


@app.command()
def menu():
    """Launch interactive menu."""
    while True:
        action = main_menu()

        if action == "exit":
            console.print("\n[bold cyan]Goodbye! 👋[/bold cyan]\n")
            break
        elif action == "wizard":
            from claux.commands.wizard import wizard_setup

            wizard_setup()
        elif action == "mcp":
            mcp_menu()
        elif action == "agents":
            agent_profiles_menu()
        elif action == "lang":
            language_menu()
        elif action == "config":
            config_menu()
        elif action == "bookmarks":
            console.print("\n[yellow]Bookmarks feature coming soon![/yellow]\n")
            typer.pause()
        elif action == "doctor":
            console.print("\n[yellow]Doctor diagnostic coming soon![/yellow]\n")
            typer.pause()
        elif action == "history":
            console.print("\n[yellow]History feature coming soon![/yellow]\n")
            typer.pause()
        elif action == "help":
            console.print("\n[bold]Help:[/bold] Visit https://github.com/Gerrux/claux\n")
            typer.pause()


if __name__ == "__main__":
    app()
