class QtfException(Exception):
    """ **QuanTI-FRET** Exception class.
    """
    pass
