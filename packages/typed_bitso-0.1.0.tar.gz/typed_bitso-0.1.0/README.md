# Typed Bitso

> A fully typed, validated async client for the Bitso API

Use *autocomplete* instead of documentation.

🚧 Under construction.