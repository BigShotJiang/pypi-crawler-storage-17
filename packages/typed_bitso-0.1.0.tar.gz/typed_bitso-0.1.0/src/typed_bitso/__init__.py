"""
### Typed Bitso
> A fully typed, validated async client for the Bitso API

- Details
"""