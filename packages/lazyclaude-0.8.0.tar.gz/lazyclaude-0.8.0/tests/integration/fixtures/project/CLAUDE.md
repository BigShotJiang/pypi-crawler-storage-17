# Project Guidelines

## Build Commands
- Run tests: `uv run pytest`
- Lint: `uv run ruff check`
