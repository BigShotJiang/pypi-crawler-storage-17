---
name: full-skill
description: A comprehensive test skill
tags: testing, fixtures
---
# Full Skill
This skill has all artifact types for testing.
