# Welcome to Connect Reports !
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=connect-reports&metric=alert_status)](https://sonarcloud.io/dashboard?id=connect-reports)[![Coverage](https://sonarcloud.io/api/project_badges/measure?project=connect-reports&metric=coverage)](https://sonarcloud.io/dashboard?id=connect-reports)[![Maintainability Rating](https://sonarcloud.io/api/project_badges/measure?project=connect-reports&metric=sqale_rating)](https://sonarcloud.io/dashboard?id=connect-reports)


In this repository you can find multiple reports to use with CloudBlue Connect.



## License

**Connect Reports** is licensed under the *Apache Software License 2.0* license.
