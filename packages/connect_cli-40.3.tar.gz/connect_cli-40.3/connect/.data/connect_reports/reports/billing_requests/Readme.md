# Billing Requests Report
This report provides a view of all billing transactions generated for a given period of time

Report accepts to limit the output by:
* List of products
* List of marketplaces
* List of hubs