# Billing Requests Report at line item level
This report provides a view of all billing transactions generated for a given period of time
The generated report will provide a row for each item on the billing request and will include vendor billing requests and provider ones if any.
Report accepts to limit the output by:
* List of products
* List of marketplaces
* List of hubs