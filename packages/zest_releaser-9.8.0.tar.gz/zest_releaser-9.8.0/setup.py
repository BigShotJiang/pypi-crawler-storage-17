from setuptools import setup


setup(
    packages=["zest.releaser", "zest.releaser.tests"],
    include_package_data=True,
    zip_safe=False,
)
