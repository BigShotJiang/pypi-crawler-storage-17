Credits
=======

* `Reinout van Rees <http://reinout.vanrees.org>`_ (Nelen & Schuurmans) is the
  original author. He's still maintaining it, together with Maurits.

* `Maurits van Rees <http://maurits.vanrees.org>`_ (Zest Software) added
  a heapload of improvements and is the maintainer, together with Reinout.

* `Kevin Teague <http://bud.ca>`_ (Canada's Michael Smith Genome Sciences
  Center) added support for multiple version control systems, most notable
  Mercurial.

* `Wouter vanden Hove <http://ugent.be>`_ (University of Gent) added
  support for uploading to multiple servers, using collective.dist.

* `Godefroid Chapelle <http://bubblenet.be>`_ (BubbleNet) added /tag besides
  /tags for subversion.

* `Richard Mitchell <https://github.com/mitchellrj>`_
  (`Isotoma <https://www.isotoma.com/>`_) added Python 3 support.

* `Mateusz Legięcki <https://github.com/Behoston>`_ added a dockerfile for
  much easier testing.

* `Eli Sallé <https://github.com/elisallenens>`_ added pyproject.toml support
  for zest.releaser's own options. We're modern now!
