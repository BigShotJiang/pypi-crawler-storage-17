<div align="center">

# Python Nintendo Parental Controls

A simple, Python API to connect to Nintento Switch Parental Controls.

[![Build Status](https://github.com/pantherale0/pynintendoparental/workflows/build/badge.svg)](https://github.com/pantherale0/pynintendoparental/actions)
[![Coverage Status](https://coveralls.io/repos/github/pantherale0/pynintendoparental/badge.svg?branch=main)](https://coveralls.io/github/pantherale0/pynintendoparental?branch=main)
[![PyPi](https://img.shields.io/pypi/v/pynintendoparental)](https://pypi.org/project/pynintendoparental)
[![Licence](https://img.shields.io/github/license/pantherale0/pynintendoparental)](LICENSE)

## Install

```bash
# Install tool
pip3 install pynintendoparental

# Install locally
just install
```
