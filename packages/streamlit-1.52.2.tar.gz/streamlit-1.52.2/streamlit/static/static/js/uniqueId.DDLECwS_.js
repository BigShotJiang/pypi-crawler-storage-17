import{H as i}from"./index.3bHSf9gi.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
