from safenax.frozen_lake.frozen_lake_v1 import FrozenLakeV1
from safenax.frozen_lake.frozen_lake_v2 import FrozenLakeV2


__all__ = [
    "FrozenLakeV1",
    "FrozenLakeV2",
]
