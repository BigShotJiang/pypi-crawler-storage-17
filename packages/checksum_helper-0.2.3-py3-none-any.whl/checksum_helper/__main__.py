from checksum_helper.checksum_helper import main

main()
