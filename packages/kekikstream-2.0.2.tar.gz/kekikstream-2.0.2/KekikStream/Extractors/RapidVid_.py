# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Extractors.RapidVid import RapidVid

class RapidFilm(RapidVid):
    name     = "RapidFilm"
    main_url = "https://rapid.filmmakinesi.to"
