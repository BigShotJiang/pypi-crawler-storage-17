from DiscoverVersion import get_version

__version__ = get_version('topobank-contact', __file__)
