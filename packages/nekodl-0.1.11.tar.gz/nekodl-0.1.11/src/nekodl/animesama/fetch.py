from ..core.core import Info

def fetch_info(*, url):
    return Info._fetch_info(url=url)