Shared GraphQL queries for the dashboard and SDK.

This and any future nested directories unfortunately must be a python module.
`importlib` won't allow imports of data files from subdirectories.
