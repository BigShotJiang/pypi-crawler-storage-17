"""Shopping List plugin app for Alliance Auth."""

# pylint: disable = invalid-name
default_app_config = "cmShoppingList.apps.DefaultConfig"
__version__ = "0.20"
