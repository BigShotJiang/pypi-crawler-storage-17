"""Check that all the errors in the source code have a documentation entry."""

if __name__ == "__main__":  # pragma: no cover
    from ._check_docs import main

    main()
