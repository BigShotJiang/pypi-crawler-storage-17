---
hide:
  - navigation
---

--8<-- "README.md"
