# Release Notes

All the published release notes can be found via the navigation menu. All patch releases are included in the same minor release (e.g. `v1.2`) document.
