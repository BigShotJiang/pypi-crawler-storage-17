# Compatibility Matrix

| NVDataModels version | Supported Nautobot versions |
| :------------------- | :-------------------------- |
| 1.0.X | 2.3.0 - 2.99.99 |
