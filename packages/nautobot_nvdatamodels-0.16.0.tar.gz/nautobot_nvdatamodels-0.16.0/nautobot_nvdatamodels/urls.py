#  SPDX-FileCopyrightText: Copyright (c) "2025" NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#  SPDX-License-Identifier: Apache-2.0
#
#  Licensed under the Apache License, Version 2.0 (the "License")
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#  http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
"""Django urlpatterns declaration for nautobot_nvdatamodels app."""

from django.templatetags.static import static
from django.urls import path
from django.views.generic import RedirectView
from nautobot.apps.urls import NautobotUIViewSetRouter

from nautobot_nvdatamodels import views

router = NautobotUIViewSetRouter()

router.register("nvlink-domains", views.NVLinkDomainUIViewSet)
router.register("nvlink-domain-memberships", views.NVLinkDomainMembershipUIViewSet)
router.register("resource-blocks", views.ResourceBlockUIViewSet)
router.register("resource-block-memberships", views.ResourceBlockMembershipUIViewSet)

urlpatterns = [
    path("docs/", RedirectView.as_view(url=static("nautobot_nvdatamodels/docs/index.html")), name="docs"),
    path(
        "plugins/nvdatamodels/nvlink-domains/<uuid:pk>/devices/add/",
        views.NVLinkDomainAddDevicesView.as_view(),
        name="nvlinkdomain_add_devices",
    ),
    path(
        "plugins/nvdatamodels/nvlink-domains/<uuid:pk>/devices/remove/",
        views.NVLinkDomainRemoveDevicesView.as_view(),
        name="nvlinkdomain_remove_devices",
    ),
    path(
        "plugins/nvdatamodels/resource-blocks/<uuid:pk>/devices/add/",
        views.ResourceBlockAddDevicesView.as_view(),
        name="resourceblock_add_devices",
    ),
    path(
        "plugins/nvdatamodels/resource-blocks/<uuid:pk>/devices/remove/",
        views.ResourceBlockRemoveDevicesView.as_view(),
        name="resourceblock_remove_devices",
    ),
]

urlpatterns += router.urls
