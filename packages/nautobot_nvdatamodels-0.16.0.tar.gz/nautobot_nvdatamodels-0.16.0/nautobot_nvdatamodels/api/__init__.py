"""REST API module for nautobot_nvdatamodels app."""
