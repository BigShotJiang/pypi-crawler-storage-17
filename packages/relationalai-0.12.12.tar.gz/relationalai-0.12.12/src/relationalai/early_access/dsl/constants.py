from typing_extensions import Final

PRIME: Final = "Prime"
DASHES: Final = "dashes"
PREFIX: Final = "prefix"
VERBAL_PART_CONNECTION: Final = "_"