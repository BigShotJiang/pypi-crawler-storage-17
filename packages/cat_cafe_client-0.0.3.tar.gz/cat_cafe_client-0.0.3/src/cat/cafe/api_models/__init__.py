"""API DTO package.

Import module-specific DTOs directly, e.g.:
    from cat.cafe.api_models.datasets import DatasetExample
"""

__all__: list[str] = []
