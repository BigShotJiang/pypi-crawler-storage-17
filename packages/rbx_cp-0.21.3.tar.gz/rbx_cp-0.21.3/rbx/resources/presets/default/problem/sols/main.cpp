#include <bits/stdc++.h>

using namespace std;

int32_t main() {
  int32_t a, b;
  cin >> a >> b;
  cout << a + b << endl;
}