# Budget

Budget levels for recall/reflect operations.

## Enum

* `LOW` (value: `'low'`)

* `MID` (value: `'mid'`)

* `HIGH` (value: `'high'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


