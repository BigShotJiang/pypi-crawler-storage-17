nectar.exceptions module
========================

.. automodule:: nectar.exceptions
   :members:
   :show-inheritance:
   :undoc-members:
