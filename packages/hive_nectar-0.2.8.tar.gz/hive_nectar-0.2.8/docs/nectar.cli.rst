nectar.cli module
=================

.. automodule:: nectar.cli
   :members:
   :show-inheritance:
   :undoc-members:
