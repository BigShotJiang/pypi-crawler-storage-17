nectar.asciichart module
========================

.. automodule:: nectar.asciichart
   :members:
   :show-inheritance:
   :undoc-members:
