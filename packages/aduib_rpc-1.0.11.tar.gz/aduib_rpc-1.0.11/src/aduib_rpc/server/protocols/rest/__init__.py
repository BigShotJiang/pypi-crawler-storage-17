from .fastapi_app import AduibRpcRestFastAPIApp

__all__ = ["AduibRpcRestFastAPIApp"]