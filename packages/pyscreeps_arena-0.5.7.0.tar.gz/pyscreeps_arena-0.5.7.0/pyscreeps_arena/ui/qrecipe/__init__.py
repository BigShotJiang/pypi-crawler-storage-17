from pyscreeps_arena.ui.qrecipe.qrecipe import QPSARecipe
