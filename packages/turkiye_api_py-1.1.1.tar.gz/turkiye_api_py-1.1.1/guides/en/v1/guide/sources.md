---
outline: deep
---

# Sources

Population of administrative units: [https://biruni.tuik.gov.tr/medas](https://biruni.tuik.gov.tr/medas)

Areas of provinces and districts: [https://web.archive.org/web/20190416051733/https://www.harita.gov.tr/images/urun/il_ilce_alanlari.pdf](https://web.archive.org/web/20190416051733/https://www.harita.gov.tr/images/urun/il_ilce_alanlari.pdf)
