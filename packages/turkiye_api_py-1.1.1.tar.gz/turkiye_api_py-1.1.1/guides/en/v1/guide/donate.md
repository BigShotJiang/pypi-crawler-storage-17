---
outline: deep
---

# Donate

TurkiyeAPI is completely free, open-source, and non-profit. However, if you'd like to support the ongoing development of TurkiyeAPI, you can make a donation. Contributions help cover server costs and fund new features.

To donate, please visit [this link](https://www.buymeacoffee.com/ubeydeozdmr).

<a href="https://www.buymeacoffee.com/ubeydeozdmr"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="buymeacoffee button" width="150" /></a>
