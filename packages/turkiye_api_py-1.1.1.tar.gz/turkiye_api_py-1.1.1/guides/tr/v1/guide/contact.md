---
outline: deep
---

# İletişim

TurkiyeAPI hakkında sorularınız veya geri bildirimleriniz varsa, lütfen aşağıdaki yöntemlerden birini kullanarak benimle iletişime geçin:

- [GitHub Issues](https://github.com/ubeydeozdmr/turkiye-api/issues) sayfasını ziyaret ederek sorunlarınızı bildirin.
- [Mail](mailto:ubeydeozdmr@gmail.com) gönderin.
