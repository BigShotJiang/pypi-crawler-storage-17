---
outline: deep
---

# Bağış Yap

TurkiyeAPI tamamen ücretsiz, açık kaynak kodludur ve kâr amacı gütmemektedir. Yine de TurkiyeAPI'nin geliştirilmesine destek olmak için bağış yapabilirsiniz. Bağışlar, sunucu masraflarını karşılamak ve yeni özellikler eklemek için kullanılacaktır. Bağış yapmak için [bu bağlantıyı](https://www.buymeacoffee.com/ubeydeozdmr) ziyaret edebilirsiniz.

<a href="https://www.buymeacoffee.com/ubeydeozdmr"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="buymeacoffee button" width="150" /></a>
