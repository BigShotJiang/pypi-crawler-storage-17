---
outline: deep
---

# Kaynaklar

Yerleşim birimlerinin nüfusu: [https://biruni.tuik.gov.tr/medas](https://biruni.tuik.gov.tr/medas)

İllerin ve ilçelerin yüzölçümleri: [https://web.archive.org/web/20190416051733/https://www.harita.gov.tr/images/urun/il_ilce_alanlari.pdf](https://web.archive.org/web/20190416051733/https://www.harita.gov.tr/images/urun/il_ilce_alanlari.pdf)
