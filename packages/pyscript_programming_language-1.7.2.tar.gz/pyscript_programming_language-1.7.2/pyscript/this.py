s = """PyScript - AzzamMuhyala

Code won't be completed without hard work.
Python can't be fast enough.
If it's too slow, it's probably of the algorithm code.
Large projects can be achieved by small teams."""

print(s)