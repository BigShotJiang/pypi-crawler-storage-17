# MIT licensed
# Copyright (c) 2013-2025 lilydjwg <lilydjwg@gmail.com>, et al.

__version__ = '2.20'
