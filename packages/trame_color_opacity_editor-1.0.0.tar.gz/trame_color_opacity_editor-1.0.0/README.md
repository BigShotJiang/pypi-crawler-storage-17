# `trame-color-opacity-editor`

![demo_image](demo.png)

## Run the example:
Create a new virtual environment and activate it.
```bash
# Install this package
pip install -e .

cd examples/volume
# install the examples requirements
pip install -r requirements.txt

# run the example
python3 main.py --server
```
