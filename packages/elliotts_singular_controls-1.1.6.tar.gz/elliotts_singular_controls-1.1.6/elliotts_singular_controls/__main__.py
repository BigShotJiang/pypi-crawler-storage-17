"""Entry point for the application."""
from elliotts_singular_controls.gui_launcher import main

if __name__ == "__main__":
    main()