__version__ = "0.11.1"

from jupytergis_lab import GISDocument, explore  # noqa
