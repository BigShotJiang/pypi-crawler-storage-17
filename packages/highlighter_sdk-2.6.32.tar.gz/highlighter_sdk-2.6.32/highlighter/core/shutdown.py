import threading

runtime_stop_event = threading.Event()
