# Pyarmor 9.2.0 (basic), 009672, 2025-12-19T17:17:24.404053
from .pyarmor_runtime import __pyarmor__
