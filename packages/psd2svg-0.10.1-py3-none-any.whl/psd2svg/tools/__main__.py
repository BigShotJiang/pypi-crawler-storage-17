"""Entry point for python -m psd2svg.tools.generate_font_mapping."""

from psd2svg.tools.generate_font_mapping import main

if __name__ == "__main__":
    raise SystemExit(main())
