"""Capabilities defined in fabricatio-yue."""
