"""
End-to-end test fixtures
"""

# E2E fixtures will be added as needed
