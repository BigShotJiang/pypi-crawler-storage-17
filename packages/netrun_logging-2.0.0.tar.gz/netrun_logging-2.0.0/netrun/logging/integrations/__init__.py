"""Integrations for external logging services."""

from netrun.logging.integrations.azure_insights import configure_azure_insights

__all__ = ["configure_azure_insights"]
