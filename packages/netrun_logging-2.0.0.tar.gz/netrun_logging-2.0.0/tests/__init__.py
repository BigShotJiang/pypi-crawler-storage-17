"""Tests for netrun-logging package."""
