"""
Data source handlers for different taxonomic authorities.
"""
