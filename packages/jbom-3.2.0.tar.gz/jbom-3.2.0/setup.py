"""Minimal setup.py for legacy compatibility. All configuration is in pyproject.toml"""
from setuptools import setup

setup()
