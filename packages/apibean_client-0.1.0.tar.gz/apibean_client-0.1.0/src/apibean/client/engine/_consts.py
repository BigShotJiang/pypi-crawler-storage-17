
JF_BASE_URL = 'base_url'
JF_ID = 'id'
JF_EMAIL = 'email'
JF_USERNAME = 'username'
JF_PASSWORD = 'password'
JF_ACTIVATION_CODE = 'activation_code'
JF_ACCESS_TOKEN = 'access_token'
JF_REFRESH_TOKEN = 'refresh_token'
JF_EXPIRATION = 'expiration'

HK_AUTHORIZATION = 'Authorization'
HK_REQUEST_ID = 'X-Request-Id'.lower()
