# Grounder plugins for SmartMemory

from smartmemory.plugins.grounders.wikipedia import WikipediaGrounder

__all__ = ['WikipediaGrounder']
