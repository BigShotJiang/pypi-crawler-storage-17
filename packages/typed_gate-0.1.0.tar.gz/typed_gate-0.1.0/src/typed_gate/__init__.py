"""
### Typed Gate
> A fully typed, validated async client for the Gate API

- Details
"""