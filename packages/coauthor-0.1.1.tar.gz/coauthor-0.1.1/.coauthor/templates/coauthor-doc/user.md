{{ task['path-modify-event'] | include_file_content }}
