"""Murf AI TTS integration for Pipecat."""

from pipecat_murf_tts.tts import MurfTTSService

__version__ = "0.1.0"
__all__ = ["MurfTTSService"]
