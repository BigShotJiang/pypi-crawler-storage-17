def main():
    print("Hello from pipecat-murf-tts!")


if __name__ == "__main__":
    main()
