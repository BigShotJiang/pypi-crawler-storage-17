"""Interface Screenshot"""

from __future__ import annotations

import httpx

from plato._generated.models.screenshot_response import ScreenshotResponse


def sync(
    client: httpx.Client,
    job_id: str,
    authorization: str | None = None,
    x_internal_service: str | None = None,
) -> ScreenshotResponse:
    """Take a screenshot of the interface.

    Available for both browser and computer interfaces.
    Returns base64 encoded PNG image."""

    url = f"/api/v2/interface/{job_id}/screenshot"

    headers: dict[str, str] = {}
    if authorization is not None:
        headers["authorization"] = authorization
    if x_internal_service is not None:
        headers["X-Internal-Service"] = x_internal_service

    response = client.request(
        "GET",
        url,
        headers=headers,
    )
    response.raise_for_status()

    return ScreenshotResponse.from_dict(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    job_id: str,
    authorization: str | None = None,
    x_internal_service: str | None = None,
) -> ScreenshotResponse:
    """Take a screenshot of the interface.

    Available for both browser and computer interfaces.
    Returns base64 encoded PNG image."""

    url = f"/api/v2/interface/{job_id}/screenshot"

    headers: dict[str, str] = {}
    if authorization is not None:
        headers["authorization"] = authorization
    if x_internal_service is not None:
        headers["X-Internal-Service"] = x_internal_service

    response = await client.request(
        "GET",
        url,
        headers=headers,
    )
    response.raise_for_status()

    return ScreenshotResponse.from_dict(response.json())
