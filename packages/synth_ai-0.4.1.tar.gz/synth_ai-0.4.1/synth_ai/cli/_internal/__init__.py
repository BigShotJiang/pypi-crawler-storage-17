"""Internal CLI utilities (not part of public API)."""

__all__: list[str] = []


