from .core import command, register

__all__ = ["command", "register"]
