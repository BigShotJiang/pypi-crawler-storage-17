---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-bp-telemetry-core-test"
  ],
  "created": "2025-12-17T05:33:32.022595+00:00",
  "from": "TestAgent",
  "id": 160,
  "importance": "normal",
  "project": "bp-telemetry-core-test",
  "project_slug": "bp-telemetry-core-test",
  "subject": "MCP Server Test Message",
  "thread_id": null,
  "to": [
    "TestAgent"
  ]
}
---

This is a test message to verify the MCP mail server functionality.
