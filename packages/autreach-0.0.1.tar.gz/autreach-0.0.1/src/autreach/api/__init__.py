from autreach.api.main import app

__all__ = ["app"]
