# Ultralytics YOLO 🚀, AGPL-3.0 license

from .predict import SegmentationPredictor

__all__ = "SegmentationPredictor",
