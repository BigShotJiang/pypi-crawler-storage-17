
from azure.storage.filedatalake import DataLakeServiceClient
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)


from .get_pqt_info_from_log import get_pqt_info_from_log
from .fetch_data import fetch_data

from pandas.core.base import PandasObject

# add the fetch_data method to the pandas DataFrame
PandasObject.fetch_data = fetch_data

class DeltaAgent:

    def __init__(self, account_name=None, account_key=None, container_name=None, table_path=None):

        self.account_name = account_name
        self.account_key = account_key
        self.container_name = container_name
        self.table_path = table_path
    
    def get_azure_service_client(self, account_name=None, account_key=None):

        # the account_name and account_key will also be reconfigured by this method if they are provided as args
        if account_name is not None:
            self.account_name = account_name
        if account_key is not None:
            self.account_key = account_key

        req_attrs_ls = ['account_name', 'account_key']

        if self.validate_attrs(req_attrs_ls):

            azure_service_client = DataLakeServiceClient(account_url="{}://{}.dfs.core.windows.net".format(
            "https", self.account_name), credential=self.account_key)

            return azure_service_client

    def validate_attrs(self, req_attrs_ls):

        missing_attrs_ls = []

        for attr in req_attrs_ls:
            if getattr(self, attr) is None:
                missing_attrs_ls.append(attr)
        if len(missing_attrs_ls) > 0:
            raise Exception(f'Please setup the [{", ".join(missing_attrs_ls)}] attribute(s) first!')
        else:
            return True
    
    def parse_log_as_df(self, container_name=None, table_path=None):

        # the account_name and account_key will also be reconfigured by this method if they are provided as args
        if container_name is not None:
            self.container_name = container_name
        if table_path is not None:
            self.table_path = table_path

        azure_service_client = self.get_azure_service_client()

        req_attrs_ls = ['container_name', 'table_path']

        if self.validate_attrs(req_attrs_ls):
            df_pqt_wt_ptn = get_pqt_info_from_log(azure_service_client, self.container_name, self.table_path)

            propagete_attrs_ls = ['account_name', 'account_key', 'container_name', 'table_path']

            for attr in propagete_attrs_ls:
                df_pqt_wt_ptn.attrs[attr] = getattr(self, attr)

            return df_pqt_wt_ptn