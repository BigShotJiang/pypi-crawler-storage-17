from enum import Enum


class EMOJI(Enum):
    GREEN_CHECK = "\u2705"
    RED_X = "\u274C"
    YELLOW_WARNING = "\033[1m\033[93m\u203c\033[0m"
