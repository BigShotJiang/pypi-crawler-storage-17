"""
Deprecated CLI commands.

These commands are no longer used and will be removed in v2.0.0.
"""

# This module is deprecated and should not be imported
