from .trainer import BPETrainer, UnigramTrainer

__version__ = '0.0.3'
__author__ = 'Shivendra S'