
.. _libdoc_graph:

========================================
:mod:`graph` -- PyTensor Graph Internals
========================================

.. module:: graph

.. moduleauthor:: LISA

.. toctree::
    :maxdepth: 1

    graph
    fgraph
    replace
    features
    op
    type
    utils
