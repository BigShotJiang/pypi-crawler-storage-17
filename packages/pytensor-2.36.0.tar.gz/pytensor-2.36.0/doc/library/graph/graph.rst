.. _libdoc_graph_graph:

================================================
:mod:`graph` -- Interface for the PyTensor graph
================================================

.. automodule:: pytensor.graph.basic
   :members:
