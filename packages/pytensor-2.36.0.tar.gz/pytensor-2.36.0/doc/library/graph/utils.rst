.. _libdoc_graph_utils:

==========================================================
:mod:`utils` -- Utilities functions operating on the graph
==========================================================

.. testsetup:: *

   from pytensor.graph.utils import *

---------
Reference
---------

.. automodule:: pytensor.graph.utils
   :platform: Unix, Windows
   :synopsis: Utilities functions operating on the graph
   :members:
.. moduleauthor:: LISA
