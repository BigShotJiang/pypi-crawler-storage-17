(libdoc_xtensor_math)=
# `xtensor.math` Mathematical operations

```{eval-rst}
.. automodule:: pytensor.xtensor.math
   :members:
   :exclude-members: XDot, dot
```