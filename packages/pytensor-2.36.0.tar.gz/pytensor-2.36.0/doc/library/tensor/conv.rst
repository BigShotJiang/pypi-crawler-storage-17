=========================================
:mod:`tensor.conv` -- Tensor Convolutions
=========================================

.. module:: tensor.conv
   :platform: Unix, Windows
   :synopsis: Tensor Convolutions
.. moduleauthor:: LISA, PyMC Developers, PyTensor Developers

.. automodule:: pytensor.tensor.conv
    :members:
