# thelab-typing

[![Latest Release](https://gitlab.com/thelabnyc/thelab-typing/-/badges/release.svg)](https://gitlab.com/thelabnyc/thelab-typing/-/releases)
[![pipeline status](https://gitlab.com/thelabnyc/thelab-typing/badges/master/pipeline.svg)](https://gitlab.com/thelabnyc/thelab-typing/-/commits/master)
[![coverage report](https://gitlab.com/thelabnyc/thelab-typing/badges/master/coverage.svg)](https://gitlab.com/thelabnyc/thelab-typing/-/commits/master)

This repository is a collection of utilities related to Python type checking.
