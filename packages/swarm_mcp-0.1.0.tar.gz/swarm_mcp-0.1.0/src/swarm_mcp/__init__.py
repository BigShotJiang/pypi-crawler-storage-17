"""MCP server for Foursquare Swarm check-in data."""

__version__ = "0.1.0"
