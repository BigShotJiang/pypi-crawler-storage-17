#!/usr/bin/env python3
"""
Standalone script to run the LibreNMS MCP server.
"""

if __name__ == "__main__":
    from librenms_mcp.server import main

    main()
