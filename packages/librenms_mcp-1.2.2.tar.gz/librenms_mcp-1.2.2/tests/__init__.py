"""
Unit tests for LibreNMS MCP Server
"""
