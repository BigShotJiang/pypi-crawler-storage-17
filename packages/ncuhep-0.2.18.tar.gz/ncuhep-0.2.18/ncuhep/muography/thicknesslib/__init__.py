# thicknesslib/__init__.py
from .thickness import ThicknessMap

__all__ = [
    "ThicknessMap",
]
