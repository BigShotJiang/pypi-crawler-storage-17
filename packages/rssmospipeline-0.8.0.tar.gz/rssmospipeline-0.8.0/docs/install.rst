.. _InstallPage:

============
Installation
============


.. include:: ../INSTALL.rst


