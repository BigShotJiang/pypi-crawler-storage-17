# Future Improvements for Meta Ads MCP

## Note about Meta Ads development work

If you update the MCP server code, please note that *I* have to restart the MCP server. After the server code is changed, ask me to restart it and then proceed with your testing after I confirm it's restarted.

## Access token should remain internal only

Don't share it ever with the LLM, only update the auth cache.

Future improvements can be added to this file as needed. 
