from PyInstaller.utils.conftest import *  # noqa: F403
