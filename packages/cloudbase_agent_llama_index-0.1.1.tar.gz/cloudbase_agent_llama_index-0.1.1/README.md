# cloudbase-agent-llama-index

Cloudbase Agent Python SDK - LlamaIndex framework integration

## Installation

```bash
pip install cloudbase-agent-llama-index
```

## Usage

```python
from cloudbase_agent import ...
```

## License

Apache-2.0
