
.. image:: https://badge.fury.io/py/galaxy-web-stack.svg
   :target: https://pypi.python.org/pypi/galaxy-web-stack/


Overview
--------

The Galaxy_ web strack abstraction.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
