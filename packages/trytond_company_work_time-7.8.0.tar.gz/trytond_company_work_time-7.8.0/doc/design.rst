******
Design
******

The *Company Work Time Module* extends the following concepts:

.. _model-company.company:

Company
=======

The *Company* gains new properties which are used to define the number of hours
in a work day, week, month and year for each company.

.. seealso::

   The `Company <company:model-company.company>` concept is introduced by the
   :doc:`Company Module <company:index>`.
