########################
Company Work Time Module
########################

The *Company Work Time Module* allows companies to define how long a work day,
week and month is.

.. toctree::
   :maxdepth: 2

   design
   releases
