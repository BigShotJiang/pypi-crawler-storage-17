"""Python client for the deo document database."""

from .client import DeoClient, DeoError

__version__ = "0.0.1"
__all__ = ["DeoClient", "DeoError"]
