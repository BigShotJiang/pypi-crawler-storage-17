-- DropIndex
DROP INDEX "LiteLLM_DailyTagSpend_tag_key";

