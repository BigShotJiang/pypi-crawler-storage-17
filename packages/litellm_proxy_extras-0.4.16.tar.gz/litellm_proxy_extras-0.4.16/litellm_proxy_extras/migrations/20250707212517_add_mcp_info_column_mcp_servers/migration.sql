-- AlterTable
ALTER TABLE "LiteLLM_MCPServerTable" ADD COLUMN     "mcp_info" JSONB DEFAULT '{}';

