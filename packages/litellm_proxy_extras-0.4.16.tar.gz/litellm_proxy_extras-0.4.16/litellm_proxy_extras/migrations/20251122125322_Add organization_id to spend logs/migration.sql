-- AlterTable
ALTER TABLE "LiteLLM_SpendLogs" ADD COLUMN     "organization_id" TEXT;

