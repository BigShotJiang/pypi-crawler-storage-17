-- AlterTable
ALTER TABLE "LiteLLM_DailyTagSpend" ADD COLUMN     "request_id" TEXT;

