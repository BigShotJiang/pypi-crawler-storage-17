"""Tests for nanocli."""
