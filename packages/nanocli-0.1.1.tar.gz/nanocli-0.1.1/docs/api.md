# API Reference

## Overview

NanoCLI provides two main modules:

- **[Core](core.md)** - CLI framework (`group`, `run`, `NanoCLI`)
- **[Config](config.md)** - Configuration handling (`compile_config`, `load_yaml`, `option`)
