# Mock Filesystem

This is a directory that mimics enough of what would be found in the
DM stack Lab container to run our unit tests.
