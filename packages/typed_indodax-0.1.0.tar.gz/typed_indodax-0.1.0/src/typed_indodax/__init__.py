"""
### Typed Indodax
> A fully typed, validated async client for the Indodax API

- Details
"""