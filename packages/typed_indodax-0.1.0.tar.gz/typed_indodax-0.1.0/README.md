# Typed Indodax

> A fully typed, validated async client for the Indodax API

Use *autocomplete* instead of documentation.

🚧 Under construction.