"""Initialize the app"""

__version__ = "3.2.0"
__title__ = "BigBrother"
