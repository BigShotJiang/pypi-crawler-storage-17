from setuptools import find_packages, setup

setup(
    name='RecMath',
    packages=find_packages(include=['RecMath']),
    version='1.0',
    description='A strong, complete math library.',
    author='14Alfa',
)