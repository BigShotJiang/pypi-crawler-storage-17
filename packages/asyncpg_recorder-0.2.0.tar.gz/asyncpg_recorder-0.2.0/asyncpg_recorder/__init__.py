from asyncpg_recorder.main import use_cassette

__all__ = ("use_cassette",)
