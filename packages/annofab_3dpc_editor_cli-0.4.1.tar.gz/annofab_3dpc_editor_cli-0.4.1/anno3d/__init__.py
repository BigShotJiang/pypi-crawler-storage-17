__version__ = "0.4.1"  # `poetry-dynamic-versioning`を使ってGitHubのバージョンタグを取得している。変更不要
