"""
Setup script for shopcloud-proxy-client package.
"""

from setuptools import setup

# All configuration is in pyproject.toml
setup()
