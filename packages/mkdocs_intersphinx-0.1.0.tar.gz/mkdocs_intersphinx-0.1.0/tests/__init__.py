"""Tests for mkdocs_intersphinx plugin."""
