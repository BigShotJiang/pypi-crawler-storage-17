*****
Usage
*****

The [:menuselection:`Inventory & Stock`] main menu item allows access to the
items that allow you to view, manage and change things related to stock.

.. include:: shipment.inc.rst
.. include:: quantity.inc.rst
.. include:: value.inc.rst
.. include:: period.inc.rst
