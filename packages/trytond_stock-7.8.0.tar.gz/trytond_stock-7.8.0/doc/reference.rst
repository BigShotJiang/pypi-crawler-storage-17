*************
API Reference
*************

Stock Quantities
================

.. class:: trytond.modules.stock.StockMixin

   This mixin_ provides some common methods that are useful when creating
   classes that provide quantity fields.

   .. _mixin: http://en.wikipedia.org/wiki/Mixin
