******
Design
******

The stock module introduces or extends the following concepts.

.. include:: location.inc.rst
.. include:: move.inc.rst
.. include:: shipment.inc.rst
.. include:: inventory.inc.rst
.. include:: period.inc.rst
.. include:: configuration.inc.rst
.. include:: product.inc.rst
.. include:: reporting.inc.rst
