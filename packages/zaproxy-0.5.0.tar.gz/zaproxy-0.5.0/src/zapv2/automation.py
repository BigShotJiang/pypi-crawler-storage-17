# Zed Attack Proxy (ZAP) and its related class files.
#
# ZAP is an HTTP/HTTPS proxy for assessing web application security.
#
# Copyright 2025 the ZAP development team
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
This file was automatically generated.
"""

import six


class automation(object):

    def __init__(self, zap):
        self.zap = zap

    def plan_progress(self, planid):
        """
        Returns the progress details for the specified planId
        This component is optional and therefore the API will only work if it is installed
        """
        return (self.zap._request(self.zap.base + 'automation/view/planProgress/', {'planId': planid}))

    def run_plan(self, filepath, apikey=''):
        """
        Loads and asynchronously runs the plan in the specified file, returning a planId
        This component is optional and therefore the API will only work if it is installed
        """
        return six.next(six.itervalues(self.zap._request(self.zap.base + 'automation/action/runPlan/', {'filePath': filepath})))

    def stop_plan(self, planid, apikey=''):
        """
        Stops the running plan identified by the planId
        This component is optional and therefore the API will only work if it is installed
        """
        return six.next(six.itervalues(self.zap._request(self.zap.base + 'automation/action/stopPlan/', {'planId': planid})))

    def end_delay_job(self, apikey=''):
        """
        Ends the currently running delay job, if any
        This component is optional and therefore the API will only work if it is installed
        """
        return six.next(six.itervalues(self.zap._request(self.zap.base + 'automation/action/endDelayJob/', {})))
