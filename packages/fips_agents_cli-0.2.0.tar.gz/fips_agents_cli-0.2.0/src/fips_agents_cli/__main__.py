"""Allow execution via python -m fips_agents_cli."""

from fips_agents_cli.cli import main

if __name__ == "__main__":
    main()
