"""FIPS Agents CLI - A tool for creating and managing FIPS-compliant AI agent projects."""

from fips_agents_cli.version import __version__

__all__ = ["__version__"]
