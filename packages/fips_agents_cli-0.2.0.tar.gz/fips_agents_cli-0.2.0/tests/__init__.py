"""Tests for fips-agents-cli."""
