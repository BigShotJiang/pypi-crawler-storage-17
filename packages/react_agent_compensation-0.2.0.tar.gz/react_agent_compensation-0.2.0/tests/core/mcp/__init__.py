"""Tests for MCP integration."""
