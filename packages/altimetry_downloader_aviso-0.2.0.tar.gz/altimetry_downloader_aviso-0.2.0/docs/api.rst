API
===

.. automodule:: altimetry_downloader_aviso
   :members: summary, details, get, AvisoProduct, AvisoCatalog
   :undoc-members:
   :show-inheritance:
