# Package metadata constants
PACKAGE_NAME = "JSTprove"
RUST_BINARY_NAME = "onnx_generic_circuit"
