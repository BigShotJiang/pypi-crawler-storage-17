from __future__ import annotations

MODEL_SOURCE_ONNX: str = "onnx"
MODEL_SOURCE_CLASS: str = "class"
