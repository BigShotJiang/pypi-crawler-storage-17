# hhu-python-tasks
Standard tasks for Python projects
