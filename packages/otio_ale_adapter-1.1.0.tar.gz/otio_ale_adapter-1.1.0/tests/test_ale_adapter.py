# SPDX-License-Identifier: Apache-2.0
# Copyright Contributors to the OpenTimelineIO project

"""Test the ALE adapter."""

# python
import os
import unittest

import opentimelineio as otio

SAMPLE_DATA_DIR = os.path.join(os.path.dirname(__file__), "sample_data")
EXAMPLE_PATH = os.path.join(SAMPLE_DATA_DIR, "sample.ale")
EXAMPLE2_PATH = os.path.join(SAMPLE_DATA_DIR, "sample2.ale")
EXAMPLE_CDL_PATH = os.path.join(SAMPLE_DATA_DIR, "sample_cdl.ale")
EXAMPLEUHD_PATH = os.path.join(SAMPLE_DATA_DIR, "sampleUHD.ale")
EXAMPLE_BLANK_PATH = os.path.join(SAMPLE_DATA_DIR, "sample_blanks.ale")
EXAMPLE_NO_BLANKS = os.path.join(SAMPLE_DATA_DIR, "sample_no_blanks.ale")


class ALEAdapterTest(unittest.TestCase):

    def test_ale_read(self):
        ale_path = EXAMPLE_PATH
        collection = otio.adapters.read_from_file(ale_path)
        self.assertTrue(collection is not None)
        self.assertEqual(type(collection), otio.schema.SerializableCollection)
        self.assertEqual(len(collection), 4)
        fps = float(collection.metadata.get("ALE").get("header").get("FPS"))
        self.assertEqual(fps, 24)
        self.assertEqual(
            [c.name for c in collection],
            ["test_017056", "test_017057", "test_017058", "Something"]
        )
        self.assertEqual(
            [c.source_range for c in collection],
            [
                otio.opentime.TimeRange(
                    otio.opentime.from_timecode("01:00:00:00", fps),
                    otio.opentime.from_timecode("00:00:04:03", fps)
                ),
                otio.opentime.TimeRange(
                    otio.opentime.from_timecode("01:00:00:00", fps),
                    otio.opentime.from_timecode("00:00:04:04", fps)
                ),
                otio.opentime.TimeRange(
                    otio.opentime.from_timecode("01:00:00:00", fps),
                    otio.opentime.from_timecode("00:00:04:05", fps)
                ),
                otio.opentime.TimeRange(
                    otio.opentime.from_timecode("01:00:00:00", fps),
                    otio.opentime.from_timecode("00:00:04:06", fps)
                )
            ]
        )

    def test_ale_read2(self):
        ale_path = EXAMPLE2_PATH
        collection = otio.adapters.read_from_file(ale_path)
        self.assertTrue(collection is not None)
        self.assertEqual(type(collection), otio.schema.SerializableCollection)
        self.assertEqual(len(collection), 2)
        fps = float(collection.metadata.get("ALE").get("header").get("FPS"))
        self.assertEqual(fps, 23.98)
        real_fps = otio.opentime.RationalTime.nearest_smpte_timecode_rate(fps)
        self.assertEqual(
            [c.name for c in collection],
            ["19A-1xa", "19A-2xa"]
        )
        self.assertEqual(
            [c.source_range for c in collection],
            [
                otio.opentime.TimeRange(
                    otio.opentime.from_timecode("04:00:00:00", real_fps),
                    otio.opentime.from_timecode("00:00:46:16", real_fps)
                ),
                otio.opentime.TimeRange(
                    otio.opentime.from_timecode("04:00:46:16", real_fps),
                    otio.opentime.from_timecode("00:00:50:16", real_fps)
                )
            ]
        )

    def test_ale_read_cdl(self):
        ale_path = EXAMPLE_CDL_PATH
        collection = otio.adapters.read_from_file(ale_path)
        self.assertTrue(collection is not None)
        self.assertEqual(type(collection), otio.schema.SerializableCollection)
        self.assertEqual(len(collection), 4)
        fps = float(collection.metadata.get("ALE").get("header").get("FPS"))
        self.assertEqual(fps, 23.976)
        real_fps = otio.opentime.RationalTime.nearest_smpte_timecode_rate(fps)
        self.assertEqual([c.name for c in collection], [
            "A005_C010_0501J0", "A005_C010_0501J0", "A005_C009_0501A0",
            "A005_C010_0501J0"
        ])
        self.assertEqual([c.source_range for c in collection], [

            otio.opentime.TimeRange(
                otio.opentime.from_timecode("17:49:33:01", real_fps),
                otio.opentime.from_timecode("00:00:02:09", real_fps)),

            otio.opentime.TimeRange(
                otio.opentime.from_timecode("17:49:55:19", real_fps),
                otio.opentime.from_timecode("00:00:06:09", real_fps)),

            otio.opentime.TimeRange(
                otio.opentime.from_timecode("17:40:25:06", real_fps),
                otio.opentime.from_timecode("00:00:02:20", real_fps)),

            otio.opentime.TimeRange(
                otio.opentime.from_timecode("17:50:21:23", real_fps),
                otio.opentime.from_timecode("00:00:03:14", real_fps))
        ])

        # Slope, offset, and power values are of type _otio.AnyVector
        # So we have to convert them to lists otherwise
        # the comparison between those two types would fail

        # FIRST CLIP
        self.assertEqual(
            list(collection[0].metadata['cdl']['asc_sop']['slope']),
            [0.8714, 0.9334, 0.9947])
        self.assertEqual(
            list(collection[0].metadata['cdl']['asc_sop']['offset']),
            [-0.087, -0.0922, -0.0808])
        self.assertEqual(
            list(collection[0].metadata['cdl']['asc_sop']['power']),
            [0.9988, 1.0218, 1.0101])
        self.assertEqual(collection[0].metadata['cdl']['asc_sat'], 0.9)

        # SECOND CLIP
        self.assertEqual(
            list(collection[1].metadata['cdl']['asc_sop']['slope']),
            [0.8714, 0.9334, 0.9947])
        self.assertEqual(
            list(collection[1].metadata['cdl']['asc_sop']['offset']),
            [-0.087, -0.0922, -0.0808])
        self.assertEqual(
            list(collection[1].metadata['cdl']['asc_sop']['power']),
            [0.9988, 1.0218, 1.0101])
        self.assertEqual(collection[1].metadata['cdl']['asc_sat'], 0.9)

        # THIRD CLIP
        self.assertEqual(
            list(collection[2].metadata['cdl']['asc_sop']['slope']),
            [0.8604, 0.9252, 0.9755])
        self.assertEqual(
            list(collection[2].metadata['cdl']['asc_sop']['offset']),
            [-0.0735, -0.0813, -0.0737])
        self.assertEqual(
            list(collection[2].metadata['cdl']['asc_sop']['power']),
            [0.9988, 1.0218, 1.0101])
        self.assertEqual(collection[2].metadata['cdl']['asc_sat'], 0.9)

        # FOURTH CLIP
        self.assertEqual(
            list(collection[3].metadata['cdl']['asc_sop']['slope']),
            [0.8714, 0.9334, 0.9947])
        self.assertEqual(
            list(collection[3].metadata['cdl']['asc_sop']['offset']),
            [-0.087, -0.0922, -0.0808])
        self.assertEqual(
            list(collection[3].metadata['cdl']['asc_sop']['power']),
            [0.9988, 1.0218, 1.0101])
        self.assertEqual(collection[3].metadata['cdl']['asc_sat'], 0.9)

    def test_ale_uhd(self):
        ale_path = EXAMPLEUHD_PATH
        collection = otio.adapters.read_from_file(ale_path)
        frmt = str(
            collection.metadata .get("ALE") .get("header") .get("VIDEO_FORMAT")
        )
        self.assertEqual(frmt, "CUSTOM")

    def test_ale_read_blank_lines(self):
        ale_path = EXAMPLE_BLANK_PATH
        collection = otio.adapters.read_from_file(ale_path)
        self.assertTrue(collection is not None)
        self.assertEqual(type(collection), otio.schema.SerializableCollection)
        self.assertEqual(len(collection), 1)
        # The ALE header information is the original FPS stored in the file,
        # and not the nearest SMPTE timecode rate
        fps = float(collection.metadata.get("ALE").get("header").get("FPS"))
        self.assertEqual(fps, 25)
        self.assertEqual([c.name for c in collection], [
            "A020C003_150905_E2XZ.mov"
        ])
        self.assertEqual(collection[0].source_range, otio.opentime.TimeRange(
                otio.opentime.from_timecode("05:42:12:20", fps),
                otio.opentime.from_timecode("00:00:17:17", fps)
        ))

        # Slope, offset, and power values are of type _otio.AnyVector
        # So we have to convert them to lists otherwise
        # the comparison between those two types would fail

        self.assertEqual(
            list(collection[0].metadata['cdl']['asc_sop']['slope']),
            [1.1822, 1.2183, 1.2284])
        self.assertEqual(
            list(collection[0].metadata['cdl']['asc_sop']['offset']),
            [-0.2429, -0.2823, -0.2849])
        self.assertEqual(
            list(collection[0].metadata['cdl']['asc_sop']['power']),
            [0.7283, 0.7096, 0.7054])
        self.assertEqual(collection[0].metadata['cdl']['asc_sat'], 1.0680)

    def test_ale_no_newline_between_sections(self):
        collection = otio.adapters.read_from_file(EXAMPLE_NO_BLANKS)
        assert len(collection) == 6

        # Spot-check one of the clips
        clip = collection[4]
        ale_metadata = clip.metadata["ALE"]

        assert ale_metadata["Tape"] == "A_0076C005_230511_190706_h1CTJ"
        assert ale_metadata["Take"] == "5"

    def test_ale_add_format(self):

        # adds a clip to the supplied timeline, sets the clips "Image Size"
        # metadata and then roundtrips the ALE verifying the supplied format
        # is detected
        def add_then_check(timeline, size, expected_format):
            cl = otio.schema.Clip(
                metadata={'ALE': {'Image Size': size}},
                source_range=otio.opentime.TimeRange(
                    start_time=otio.opentime.RationalTime(0, 24000 / 1001),
                    duration=otio.opentime.RationalTime(48, 24000 / 1001)
                )
            )
            timeline.tracks[0].extend([cl])
            collection = otio.adapters.read_from_string(
                otio.adapters.write_to_string(
                    timeline,
                    adapter_name='ale'
                ),
                adapter_name="ale"
            )
            ale_meta = collection.metadata.get('ALE')
            vid_format = str(ale_meta.get('header').get('VIDEO_FORMAT'))
            self.assertEqual(vid_format, expected_format)

        track = otio.schema.Track()
        tl = otio.schema.Timeline("Add Format", tracks=[track])

        # add multiple clips with various resolutions,
        # we want the ALE to return a project format
        # that is compatible with the largest resolution

        add_then_check(tl, '720 x 486', 'NTSC')
        add_then_check(tl, '720 x 576', 'PAL')
        add_then_check(tl, '1280x 720', '720')
        add_then_check(tl, '1920x1080', '1080')
        add_then_check(tl, '2048x1080', 'CUSTOM')
        add_then_check(tl, '4096x2304', 'CUSTOM')

    def test_ale_roundtrip(self):
        ale_path = EXAMPLE_PATH

        with open(ale_path) as fi:
            original = fi.read()
            collection = otio.adapters.read_from_string(original, "ale")
            output = otio.adapters.write_to_string(collection, "ale")
            self.maxDiff = None
            self.assertMultiLineEqual(original, output)


if __name__ == '__main__':
    unittest.main()
