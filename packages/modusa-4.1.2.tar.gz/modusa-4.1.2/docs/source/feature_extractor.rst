Feature Extractor
=================

.. automethod:: modusa.extract.stft