directoryStructure: Project context scanning has been disabled because {reason}. This prevents permission dialogs and potential system slowdowns. Use the LS tool and other file tools to explore the project structure as needed.

Absolute path: {abs_path}

gitStatus: Use git tools to check repository status if needed.
