from utils_basic import *

class new_patient_transaction:
    
    def changeSexToOneChar(self,sex): 
        if sex.upper() == "MALE":
            sex = "M"
        elif sex.upper() == "FEMALE":
            sex = "F"
        return sex
        
    def Assign_DOB_When_Exists(self,dob):
        if len(dob) > 0:
            dob = Get_Date_From_YYYYMMDD_TO_DDMMMYYYY_Py(dob, yearDigit=4)
        return dob
