import json
from robot.api import logger
from datetime import datetime, timedelta
from random import randrange
import random
import re
from enum import Enum

class BannerField(Enum):
    NAME = "PatientDisplayName"
    LEGALSEX = "PatientGender"
    PROVIDER = "UnreviewedAllergies"
    ADMITDATEANDVITALS = "FirstAdditionalLineRTF"
    BIRTHSEXANDALLERGIES = "SecondAdditionalLineRTF"
    SPECIALNEEDS = "ThirdAdditionalLineRTF"

class patient_fields():
    DELIMITER_LEN = 30
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'  # DON"T DELETE, allows for persistant state
    ONSTAGE_PDF_MAP = ''
    NOVALUE = "''"
    notFound = ""
    JsonFile = ""
    JsonDict = ""
    PatientList = ""
    #
    regexMrn = "^(\\d){7}$"
    regexDob = "^[0-9]{8}\\s(M|F|U)$"
    regexSex = "^[0-9]{8}\\s(M|F|U)$"
    regexPhone = "^[(][\\d]{3}[)][ ]?[\\d]{3}-[\\d]{4}$"

    LAST = ['id=sPT1f16', '']
    FIRST = ['id=sPT1f17', '']
    DOB = ['id=sPT1f4', '']
    PRIMPH = ['id=sPT1f46', '']
    RACE = ['id=sPT1f9', '']
    ETHNICITY = ['id=sPT1f42', '']
    PHTYPE = ['id=sPT1f47', '1']
    BIRSEX = ['xpath=//*[@id="sPT1f6"]/div[1]/div/div[1]/div', ''] # M, F
    LEGSEX = ['id=sPT1f15', '', 'id=rcmLookupBoxButtonOk']
    #BADADDR = ['id=sPT1f45', 'No Fixed Address']
    ADDRVER = ['id=sAf12', '7']
    PATEDITED = {"FIRST": "",  "DOB": "", "LEGSEX": "", "PRIMPH": "", "PHTYPE": "","BIRSEX":"", "LEGSEX":"" ,"RACE": "", "ETHNICITY": ""} #"BADADDR": ""}

    def __init__(self):
        self.JsonFile = open('.\\Resources\\data\\Names.json', 'r')
        self.JsonDict = json.load(self.JsonFile)
        self.PatientList = list(self.JsonDict)
        self.Add_Random_Patient_Field_Values()

    def Add_Random_Patient_Field_Values(self):
        listSize = len(self.JsonDict)
        randNum = random.randint(0, listSize) - 1
        randPat = self.PatientList[randNum]
        self.LAST[1] = randPat['lastname']
        self.FIRST[1] = randPat['firstname']
        self.BIRSEX[1] = 'F'  # randPat['birSex'] # TODO - use from Names.json
        self.LEGSEX[1] = 'F'  # randPat['legSex'] # TODO - use from Names.json
        self.PRIMPH[1] = self.formatForValidPhoneNumber(randPat['primphone'])
        self.DOB[1] = self.Get_Random_DobMDY()

    def Set_Random_Pat_Values(self):
        listSize = len(self.JsonDict)
        randNum = random.randint(0, listSize) - 1
        randPat = self.PatientList[randNum]
        self.PATEDITED["LAST"] = randPat['lastname']
        self.PATEDITED["FIRST"] = randPat['firstname']
        self.PATEDITED["DOB"] = self.Get_Random_DobMDY()
        self.PATEDITED["LEGSEX"] = self.ChangeLegalSex()
        self.PATEDITED["PRIMPH"] = self.formatForValidPhoneNumber(randPat['primphone'])
        self.PATEDITED["PHTYPE"] = self.PHTYPE[1]
        self.PATEDITED["BIRSEX"] = self.BIRSEX[1]
        self.PATEDITED["LEGSEX"] = self.LEGSEX[1]
        self.PATEDITED["RACE"] = self.RACE[1]
        self.PATEDITED["ETHNICITY"] = self.ETHNICITY[1]
        #self.PATEDITED["BADADDR"] = self.BADADDR[1]

    def Assign_Current_Pat_Values(self, firstName, lastName, primphone, birsex, legsex, race, ethnicity, dob):
        self.FIRST[1] = firstName
        self.LAST[1] = lastName
        self.LEGSEX[1] = legsex
        self.PRIMPH[1] = primphone
        self.BIRSEX[1] = birsex
        self.LEGSEX[1] = legsex
        self.RACE[1] = race
        self.ETHNICITY[1] = ethnicity
        self.DOB[1] = dob

    def Get_Random_DobMDY(self):
        star_date = datetime(1920, 1, 1)
        end_date = datetime.now()
        delta = end_date - star_date
        delta_in_second = (delta.days * 24 * 60 * 60) + delta.seconds
        random_second = randrange(delta_in_second)
        randDate = star_date + timedelta(seconds=random_second)
        randDateFmt = randDate.strftime("%m/%d/%Y")
        return randDateFmt

    def ChangeLegalSex(self):
        if "M" == self.LEGSEX[1].upper():
            return "F"
        else:
            return "M"

    def NO_VALUE(self):
        return self.NOVALUE

    def GetFields(self):
        return patient_fields

    def RegexSearchForValue(self, regex, value):
        valueHasNewLine = re.search(regex, value)
        isMatch = bool(valueHasNewLine)
        return isMatch

    def Get_Last_Name(self):
        try:
            for value in self.ONSTAGE_PDF_MAP:
                if "AUTO-ROBOT" in value:
                    return value
        except Exception as e:
            self.notFound = f"*ERROR* - Get_Last_Name - {e}"
        return self.notFound

    def Get_First_Name(self):
        try:
            for value in self.ONSTAGE_PDF_MAP:
                if "FIRST-" in value:
                    return value
        except Exception as e:
            self.notFound = f"*ERROR* - Get_First_Name - {e}"
        return self.notFound


    def Get_Dob(self):
        try:
            for value in self.ONSTAGE_PDF_MAP:
                isMatch = self.RegexSearchForValue(self.regexDob, value)
                if isMatch is True:
                    result = self.Get_Index_Value(name="rptDob", str=value, i1=0)
                    return result
        except Exception as e:
            self.notFound = f"*ERROR* - Get_Dob - {e}"
        return self.notFound

    def Get_Birth_Sex(self):
        try:
            for value in self.ONSTAGE_PDF_MAP:
                isMatch = self.RegexSearchForValue(self.regexSex, value)
                if isMatch is True:
                    result = self.Get_Index_Value(name="rptBirSex", str=value, i1=1)
                    return result
        except Exception as e:
            self.notFound = f"*ERROR* - Get_Birth_Sex - {e}"
        return self.notFound

    def Get_Phone(self):
        try:
            for value in self.ONSTAGE_PDF_MAP:
                valueFmt = value.replace("\n", " ")
                valueFmt = valueFmt.replace(" ", "")
                isMatch = self.RegexSearchForValue(self.regexPhone, valueFmt)
                if isMatch is True:
                    return valueFmt
        except Exception as e:
            self.notFound = f"*ERROR* - Get_Phone - {e}"
        return self.notFound

    def Get_Dob_Formated_Ymd(self):
        dobStr = str(self.DOB[1])
        dobDate = datetime.strptime(dobStr, "%m/%d/%Y").date()
        dobDateFmt = dobDate.strftime("%Y%m%d")
        return dobDateFmt

    def Get_Dob_Edit_Formated_Ymd(self):
        dobStr = str(self.PATEDITED["DOB"])
        dobDate = datetime.strptime(dobStr, "%m/%d/%Y").date()
        dobDateFmt = dobDate.strftime("%Y%m%d")
        return dobDateFmt

    def Get_Pat_Fields_Object(self, patient_str):
        patient_str = patient_str.split("\n\n")
        return patient_str

    def Verify_Match(self, outValue, inValue, field):
        outValueAfter = self.formatForValidPhoneNumber(outValue)
        inValueAfter = self.formatForValidPhoneNumber(inValue)
        try:
            if field.upper() == "ADDRESS":
                outValueAfter = self.Replace_NewLine_With_Space(outValueAfter)
            else:
                outValueAfter = outValueAfter.replace("\n", "")
        except Exception as e:
            outValueAfter = "Verify_Match()**ERROR** = {e}"
            print(outValueAfter)

        doValuesMatch = outValueAfter == inValueAfter
        return doValuesMatch

    def formatForValidPhoneNumber(self, s):
        sFmt = str(s).upper()
        sFmt = sFmt.replace("'", "")
        sFmt = sFmt.replace("(", "")
        sFmt = sFmt.replace(")", "-")
        sFmt = sFmt.replace("- ", "-")
        return sFmt

    def Replace_NewLine_With_Space(self, s):
        regex = "^(.+)(\\n{1})(.+)$"
        isMatch = self.RegexSearchForValue(regex, s)
        sFmt = s
        if isMatch is True:
            sFmt = s.Remove("\n",'')
        return sFmt

    def Get_Index_Value(self, name, str, i1, i2="", delim=" "):
        try:
            index1 = int(i1)
            strArray = str.split(delim)
            value = strArray[index1]
            if i2 != "":
                index2 = int(i2)
                value = value + strArray[index2]
        except Exception as e:  # assign the error to the return value
            value = f"*ERROR* Get_Index_Value() name=${name} i1={i1}, i2={i2}"
            value += f". Error = {e}"
        return value
    
    def Print_Edit_Heading_Py(self, title):
        logger.console("\n")
        logger.console("--------------------------------------------")
        logger.console(f"              {title}")
        logger.console("--------------------------------------------")
        self.Write_Edit_Headers_Py()
        self.Write_Dash_Header(4)

    def Print_Edit_Heading_Py(self, title):
        logger.console("\n")
        logger.console("--------------------------------------------")
        logger.console(f"              {title}")
        logger.console("--------------------------------------------")
        self.Write_Edit_Headers_Py()
        self.Write_Dash_Header_Py(4)
        
    def Write_Edit_Headers_Py(self, delLen=DELIMITER_LEN):
        s = "NAME".ljust(delLen, ' ') + "  "
        s += "OLD_VALUE".ljust(delLen, ' ') + "  "
        s += "NEW_VALUE".ljust(delLen, ' ') + "  "
        s += "LOCATOR"
        logger.console("\n" + s)
        
    def Write_Dash_Header_Py(self, count, delLen=DELIMITER_LEN):
        s = ''
        for i in range(0, int(count)):
            s += "-".replace("-", "-"*delLen) + "  "
        logger.console(s)

    def Write_Old_And_New_Values_Py(self, name, oldVal, newVal, loc, delLen=DELIMITER_LEN):
        s = name.ljust(delLen, ' ') + "  "
        s += oldVal.ljust(delLen, ' ') + "  "
        s += newVal.ljust(delLen, ' ') + "  "
        s += loc
        logger.console(s)

    def Get_Banner_Field_ID(self, name:BannerField):
        """Returns the string value of a BannerField enum member."""
        value = str(name.value)
        return value


if __name__ == '__main__':

    #s = '(963) 495-\n3079'
    #sFmt = s.replace("\n", "")
    #s = re.search(pf.regexPhone, sFmt)
    #match = bool(s)
    print('')
