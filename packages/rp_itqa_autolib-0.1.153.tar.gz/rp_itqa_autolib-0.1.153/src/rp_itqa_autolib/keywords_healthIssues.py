"""
----------------------------------------------------------------------------------
 Author:  Frank Runfola
 Created: 1/20/2024
----------------------------------------------------------------------------------
"""
   
import sys
import time
import datetime
from random import randrange
import random
import re
from time import gmtime, strftime
import pyautogui
import pywinauto
import RPA.Windows as rpawin
import typing
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
import pywinauto.base_wrapper
import pywinauto.controls
import pywinauto.element_info
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows
from pywinauto import timings
from pywinauto import findbestmatch
from pywinauto.application import Application
from datetime import datetime


DELIMITER_LEN = 30
AlteraWindow = "Altera Gateway"
_static_win = None

healthIssuesDict = {
    "BMT":                ["Other specified disorders of pancreatic internal secretion",       "E16.8",  "ICD-10-Billable"],
    "Breast":             ["Carcinoma of other specified sites of female breast",              "C50.819","ICD-10-Billable"],
    "Critical Care":      ["Acute renal failure (ARF)",                                        "N17.9",  "ICD-10-Billable"],
    "Family History":     ["Family history not obtainable due to adoption",                    "Z78.9",  "ICD-10-Billable"],
    "GI":                 ["Secondary malignant neoplasm of other digestive organs and spleen","C78.89", "ICD-10-Billable"],
    "GU":                 ["Anemia of chronic disorder",                                       "D63.8",  "ICD-10-Billable"],
    "GYN":                ["Malignant neoplasm of other specified sites of uterine adnexa",    "C57.4",  "ICD-10-Billable"],
    "Head and Neck":      ["Secondary malignant neoplasm of other specified sites",            "C79.89", "ICD-10-Billable"],
    "Leukemia":           ["Hypothyroidism",                                                   "E03.9",  "ICD-10-Billable"],
    "MNC – PET scans":    ["Malignant neoplasm of external upper lip",                        "C00.0",  "ICD-10-Billable"],

    "No History":         ["Family history not obtainable due to adoption",                    "Z78.9",  "ICD-10-Billable"],
    #"No Pertinent":       ["",                                                                 "",       "ICD-10-Billable"],
    "PFT":                ["Other chronic bronchitis",                                         "J42",     "ICD-10-Billable"],
    "Social History" :    ["Alcohol consumption four to six days per week",                    "Z78.9",   "ICD-10-Billable"],
    "Soft Tissue":        ["Malignant melanoma of other specified sites of skin",              "C43.9",   "ICD-10-Billable"],
    "Solid Tumor":        ["Hypothyroidism",                                                   "E03.9",   "ICD-10-Billable"],
    "Thoracic":           ["Malignant neoplasm of other parts of bronchus or lung",            "C34.90",  "ICD-10-Billable"],
    "*Metastasis":        ["Secondary and unspecified malignant neoplasm of axilla and upper limb lymph nodes",   "C77.3",  "ICD-10-Billable"],
     "Unspecified Metastatic Sites":["Secondary and unspecified malignant neoplasm of lymph nodes of head, face, and neck", "C77.0", "ICD-10-Billable"]
}

def Validate_First_Health_Issue_For_Every_Category_Py():

    logger.console(f"      Validate_First_Health_Issue_For_Every_Category_Py ...[Py]\n")
    app, proc = Get_Health_Issues_Manager_App()
    valid = True

    try:
        app = app.window(handle=proc.handle)
        dlgPnlLower = app.window(auto_id="pnlLower", class_name_re = "WindowsForms10.*")#dlg.print_control_identifiers(depth=3)
        dlg = dlgPnlLower.child_window(auto_id="HealthIssueBrowseControl", class_name_re = "WindowsForms10.*")   
        dlg = dlg.child_window(auto_id="tabControlBrowseItems", control_type="Tab")
        dlg = dlg.child_window(auto_id="Browse", control_type="Pane")
        pnlBrowseDlg = dlg.child_window(auto_id="pnlBrowse", control_type="Pane")

        #FOLDERS
        foldersDlg = dlg.child_window(auto_id="ultraTreeBrowse", control_type="Tree") #foldersDlg.print_control_identifiers()
        folders = foldersDlg.children(control_type="TreeItem")
        
        #TABLE RESULTS
        tableDlg = pnlBrowseDlg.child_window(auto_id="BrowseResultGrid", control_type="Table")
        tableDlg = tableDlg.child_window(title="Band 0", control_type="Table")  #tableDlg.print_control_identifiers()

        #MAXIMIZE PnlLower Panel to see all folders
        
        dlgPnlLowerTitleBar = dlgPnlLower.child_window(title="Add New Health Issue", auto_id="lblLowerPanelTitle", control_type="Text")
        dlgPnlLowerTitleBar.click_input()

        #WRITE HEADERS
        Write_ICD10_Code_Headers()

        for folder in folders:
            #####################################
            # Click on next folder
            #####################################
            try:
                folderText = folder.element_info.name  #folderDlg.print_control_identifiers()
                folderDlg = foldersDlg.child_window(title=folderText, control_type="TreeItem")
                logger.console(f"         {str(folderText).ljust(25)}  ", newline=False)
                folderDlg.click_input()
              
            except Exception as e:
                logger.console(f"\n      **ERROR** in 'Click on next folder' [Py]")
                logger.console(f"      (Error={e} [Py]\n") 
                raise Exception(f"{e}")
        
            #####################################
            # FOLDER HAS NO VALUES
            #####################################
            if folderText == "No Pertinent":
                logger.console(f"FOLDER HAS NO VALUES...(SKIPPING)  ")
                Write_Row_Seperator()
                continue
                
            #####################################
            # GET FIRST TABLE ROW
            #####################################
            try:
                firstRowName = tableDlg.children(control_type="Custom")[0].element_info.name 
                #logger.console(f"{str(firstRowName).ljust(15)}  ", newline=False)
                row1Dlg = tableDlg.child_window(title=firstRowName, control_type="Custom") #row1Dlg.print_control_identifiers()
            except Exception as e:
                logger.console(f"\n      **ERROR** in 'GET FIRST TABLE ROW' [Py]")
                logger.console(f"      (Error={e} [Py]\n") 
                raise Exception(f"{e}")
        
            #####################################
            # GET Health issue Column Value
            #####################################
            try:
                rowErros = ""
                healthIssuesDlg = row1Dlg.child_window(title="Health Issues", control_type=f"DataItem")
                healthIssueGui = healthIssuesDlg.legacy_properties()['Value'] # GET THE TEXT!
                logger.console(f"{str(healthIssueGui[:85]).ljust(85)}  ", newline=False)
                healthIssueDict = healthIssuesDict[folderText][0]
                
                if(healthIssueGui != healthIssueDict):
                    rowErros+=f"\n      --FAIL-- healthIssue Gui('{healthIssueGui}')  **DOESN'T MATCH**  Dict('{healthIssueDict}')"
            
            except Exception as e:
                logger.console(f"\n      **ERROR** in 'GET Health issue Column Value' [Py]")
                logger.console(f"      (Error={e} [Py]\n") 
                raise Exception(f"{e}")
        
            #####################################
            # GET Code Column Value
            #####################################
            try:
                codeDlg = row1Dlg.child_window(title="Code", control_type=f"DataItem")
                codeGui = codeDlg.legacy_properties()['Value'] # GET THE TEXT!
                logger.console(f"{str(codeGui).ljust(10)}  ", newline=False)
                codeDict = healthIssuesDict[folderText][1]
                
                if(codeGui != codeDict):
                    rowErros+=f"\n      --FAIL-- codeGui('{codeGui}')  **DOESN'T MATCH** codeDict('{codeDict}')"

            except Exception as e:
                logger.console(f"\n      **ERROR** in 'GET Code Column Value' [Py]")
                logger.console(f"      (Error={e} [Py]\n") 
                raise Exception(f"{e}")
        

            #####################################
            # GET Coding Scheme Column Value
            #####################################
            codingSchDlg = row1Dlg.child_window(title="Coding Scheme", control_type=f"DataItem")
            codingSchemeGui = codingSchDlg.legacy_properties()['Value'] # GET THE TEXT!
            logger.console(f"{codingSchemeGui}")
            codingSchemeDict = healthIssuesDict[folderText][2]
            
            if(codingSchemeGui != codingSchemeDict):
               rowErros+=f"\n      --FAIL-- codingSchemeGui('{codingSchemeGui})'  **DOESN'T MATCH**  codingSchemeDict('{codingSchemeDict}')"
            
            #####################################
            # WRITE ERRORS
            #####################################
            if (rowErros != ""):
               valid = False
               logger.console(f"{rowErros}")
            else:
              logger.console(f"\n      (PASSED)")
        
            Write_Row_Seperator()

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Validate_First_Health_Issue_For_Every_Category_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")

    finally:
        logger.console(f"")
        if valid == False:
            logger.console(f"\n**FAIL** NOT ALL VALUES MATCH!![Py]\n")

    return valid

def Get_Health_Issues_Manager_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if "Health Issue Manager" in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id, handle=proc.handle)
            break
    return app,proc

def Write_Row_Seperator():
    s = '   '
    for i in range(0, 135):
        s += "-"
    logger.console(s)

def Write_ICD10_Code_Headers():
    logger.console(f"         {str("FOLDER").ljust(25)}  ", newline=False)
    #logger.console(f"{str("ROW").ljust(15)}  ", newline=False)
    logger.console(f"{str("HEALTH ISSUE").ljust(85)}   ", newline=False)
    logger.console(f"{str("CODE").ljust(10)}  ", newline=False)
    logger.console(f"{str("CODING SCHEME")}  ")

    logger.console(f"         {str("------").ljust(25)}  ", newline=False)
    #logger.console(f"{str("---").ljust(15)}  ", newline=False)
    logger.console(f"{str("-----------").ljust(85)}   ", newline=False)
    logger.console(f"{str("----").ljust(10)}  ", newline=False)
    logger.console(f"{str("-------------")}  ")

def Select_Health_Issue_Type_To_Copy_To_Py(row, group, copyToType ):
    logger.console(f"   Select_Health_Issue_Type_To_Copy_To_Py() ...(group={group}) [Py]")
    procs = findwindows.find_elements()
    app, proc = Get_Health_Issues_Manager_App()
    try:
        logger.console(f"      row='{row}'  copyToType='{copyToType}'  group='{group}' ...[Py]")
        app = app.window(handle=proc.handle)
        dlg = app.window(auto_id="pnlUpper", class_name_re = "WindowsForms10.*") #dlg.print_control_identifiers()
        dlg = dlg.child_window(auto_id="ultraGridExistingIssues", class_name_re = "WindowsForms10.*") 
        dlg = dlg.child_window(auto_id="pnlGridContainer", control_type="Pane")
        dlg = dlg.child_window(auto_id="ultraSharedHealthIssueManagerGrid", control_type="Tab")
        dlg = dlg.child_window(auto_id="ultraTabSharedControlsPage1", control_type="Pane")
        dlg = dlg.child_window(auto_id="ugInner", control_type="Table")
        dlg = dlg.child_window(title="Band 0", control_type="Table")
        dlg = dlg.child_window(title=f"Band 0 row {group}", control_type="Custom",found_index=0)
        dlg = dlg.child_window(title=f"Band 0 row {row}", control_type="Custom")
        dlg = dlg.child_window(title="Copy To", control_type="DataItem")
        logger.console(f"      click 'Copy To' ...[Py]")
        dlg.click_input()
        time.sleep(3)
        logger.console(f"      typewrite {copyToType} ...[Py]\n")
        pyautogui.typewrite(f"{copyToType}") #Admitting Dx, Cancer Dx, Active Problems, etc..
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Select_Health_Issue_Type_To_Copy_To_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")

def Select_Health_Issue_By_Group_py(group):
    logger.console(f"   Select_Health_Issue_By_Group_py() ... (group='{group}') [Py]")

    app, proc = Get_Health_Issues_Manager_App()
    try:
        dlg = app.window(handle=proc.handle).window(auto_id="pnlUpper", class_name_re = "WindowsForms10.*") #dlg.print_control_identifiers()
        dlg = dlg.child_window(auto_id="ultraGridExistingIssues", class_name_re = "WindowsForms10.*") 
        dlg = dlg.child_window(auto_id="pnlGridContainer", control_type="Pane")
        dlg = dlg.child_window(auto_id="ultraSharedHealthIssueManagerGrid", control_type="Tab")
        dlg = dlg.child_window(auto_id="ultraTabSharedControlsPage1", control_type="Pane")
        dlg = dlg.child_window(auto_id="ugInner", control_type="Table")
        dlg = dlg.child_window(title="Band 0", control_type="Table")
        dlg = dlg.child_window(title=f"Band 0 row {group}", control_type="Custom", found_index=0)
        dlg = dlg.child_window(title="Band 0 row 1", control_type="Custom")
        logger.console(f"      Click Health Issues (row {group} > Band 0 row 1) ...[Py]\n")
        dlg.click_input()
        time.sleep(3)
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Select_Health_Issue_By_Group_py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        raise Exception(f"{e}")
    
def Add_First_Health_Issue_Under_Full_Catalog_Search_Py():
    logger.console(f"   Add_First_Health_Issue_Under_Full_Catalog_Search_Py() ...[Py]")
    
    app, proc = Get_Health_Issues_Manager_App()
    try:
        win = app.window(handle=proc.handle).window(auto_id="pnlLower", class_name_re = "WindowsForms10.*")
        dlg = win.child_window(auto_id="HealthIssueBrowseControl")
        dlg = dlg.child_window(auto_id="tabControlBrowseItems")
        dlg = dlg.child_window(auto_id="Full Catalog Search")
        dlg = dlg.child_window(auto_id="SearchResultGrid")
        dlg = dlg.child_window(title="Band 0", control_type="Table")
        dlg = dlg.child_window(title="Band 0 row 1", control_type="Custom", found_index=0)
        addButton = dlg.DataItem1
        logger.console(f"      Click 'Add' ...[Py]\n")
        addButton.click_input()
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Add_First_Health_Issue_Under_Full_Catalog_Search_Py' [Py]")
        logger.console(f"      (Error={e}) [Py]\n")
        raise Exception(f"{e}")

def Verify_Visit_Problem_Type_Is_Not_Showing_Py(code):
    logger.console(f"   Add_First_Health_Issue_Under_Full_Catalog_Search_Py() (code={code})...[Py]\n")
    app, proc = Get_Health_Issues_Manager_App()
    try:
        notVerified = True
        dlg = app.window(handle=proc.handle).window(auto_id="pnlUpper", class_name_re = "WindowsForms10.*") #dlg.print_control_identifiers()
        dlg = dlg.child_window(auto_id="ultraGridExistingIssues", class_name_re = "WindowsForms10.*") 
        dlg = dlg.child_window(auto_id="pnlGridContainer", control_type="Pane")
        dlg = dlg.child_window(auto_id="ultraSharedHealthIssueManagerGrid", control_type="Tab")
        dlg = dlg.child_window(auto_id="ultraTabSharedControlsPage1", control_type="Pane")
        dlg = dlg.child_window(auto_id="ugInner", control_type="Table")
        dlgGroups = dlg.child_window(title="Band 0", control_type="Table")#dlg.print_control_identifiers()
        groups = dlgGroups.children(control_type="Custom")
        logger.console(f"      rows={len(groups)}\n")
        
        try:
            logger.console(f"      {str('GroupNumber').ljust(15)}  {str('GroupName').ljust(20)}  {str('Result')}")
            logger.console(f"      ---------------  -------------------  -------------------------")
            for group in groups:
                group = group.element_info.name  #folderDlg.print_control_identifiers()
                dlgGroup = dlg.child_window(title=f"{group}", control_type="Custom", found_index=0)
                groupName = str(dlgGroup.legacy_properties()['Value']) # GET THE TEXT!
                logger.console(f"      {str(group).ljust(15)}  ", newline=False)
                logger.console(f"{str(groupName).ljust(20)}  ", newline=False)
                
                if "Visit Problem" in groupName:
                    logger.console(f"*FOUND*  (SHOULDN'T BE FOUND - FAIL)") # THIS IS A FAIL
                    notVerified = False
                else:
                   logger.console(f"NOT FOUND (PASS)")

        except Exception as e:
            logger.console(f"\n      **ERROR** in group={group} [Py]")
            logger.console(f"      (Error={e} [Py]\n") 
            notVerified = False
            raise Exception(f"{e}")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Verify_Visit_Problem_Type_Is_Not_Showing_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        notVerified = False
        raise Exception(f"{e}")
        
    finally: 
        logger.console(f"")

    return notVerified

###############
#NOT USED
###############
def Select_Health_Issue_Status(status):
    logger.console(f"   Verify_Health_Issue_Status() ...[Py]")
    logger.console(f"      status='{status}' ...[Py]")
    app, proc = Get_Health_Issues_Manager_App()
    
    try:
        dlg = app.window(handle=proc.handle).window(auto_id="pnlUpper", class_name_re = "WindowsForms10.*") #dlg.print_control_identifiers()
        dlg = dlg.child_window(auto_id="ultraGridExistingIssues", class_name_re = "WindowsForms10.*") 
        dlg = dlg.child_window(auto_id="pnlGridContainer", control_type="Pane")
        dlg = dlg.child_window(auto_id="ultraSharedHealthIssueManagerGrid", control_type="Tab")
        dlg = dlg.child_window(auto_id="ultraTabSharedControlsPage1", control_type="Pane")
        dlg = dlg.child_window(auto_id="ugInner", control_type="Table")
        dlg = dlg.child_window(title="Band 0", control_type="Table")#dlg.print_control_identifiers()
        dlg = dlg.child_window(title=f"Band 0 row 1", control_type="Custom", found_index=0)
        dlg = dlg.child_window(title=f"Band 0 row 1", control_type="Custom")#dlgRow.print_control_identifiers()
        dlg = dlg.child_window(title=f"Status", control_type="DataItem", found_index=0)
        logger.console(f"      Select Status 'Add' {status} ...[Py]")
        dlg.click_input()
        pyautogui.typewrite(f"{status}")
        
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Verify_Health_Issue_Status' [Py]")
        logger.console(f"      (Error={e} [Py]")
        raise Exception(f"{e}")

def Verify_Health_Issue_Status_Py(typeCheck, nameCheck, statusCheck, group, index):
    index = int(index)
    logger.console(f"   Verify_Health_Issue_Status_Py() ...[Py]\n")
    currDateCheck = datetime.now().strftime("%m/%d/%Y").lstrip('0').replace("/0", "/")
    logger.console(f"      nameCheck='{nameCheck}'")
    logger.console(f"      typeCheck='{typeCheck}'")
    logger.console(f"      statusCheck='{statusCheck}'")
    logger.console(f"      currDateCheck='{currDateCheck}'\n")
    #logger.console(f"      press 'pageup' 3 (Make sure at top of list)...[py]")
    # pyautogui.press(keys="PAGEUP",presses=3)
    
    app, proc = Get_Health_Issues_Manager_App()
    verified = False
    
    try:
        dlg = app.window(handle=proc.handle).window(auto_id="pnlUpper", class_name_re = "WindowsForms10.*") #dlg.print_control_identifiers()
        dlg = dlg.child_window(auto_id="ultraGridExistingIssues", class_name_re = "WindowsForms10.*") 
        dlg = dlg.child_window(auto_id="pnlGridContainer", control_type="Pane")
        dlg = dlg.child_window(auto_id="ultraSharedHealthIssueManagerGrid", control_type="Tab")
        dlg = dlg.child_window(auto_id="ultraTabSharedControlsPage1", control_type="Pane")
        dlg = dlg.child_window(auto_id="ugInner", control_type="Table")
        allGroups = dlg.child_window(title="Band 0", control_type="Table")#dlg.print_control_identifiers()
        groupHeader = allGroups.child_window(title=f"Band 0 row {group}", control_type="Custom", found_index=index)
        rows = groupHeader.children(control_type="Custom")
        logger.console(f"      rows={len(rows)}\n")
        logger.console(f"      {str('HealthIssue').ljust(30)}  {str('Type').ljust(20)}  {str('Status').ljust(30)}  {str('Entered')}")
        logger.console(f"      ------------------------------  --------------------  ------------------------------  --------------------")

        for row in rows:
            groupName = row.element_info.name
            dlgGroup = groupHeader.child_window(title=f"{groupName}", control_type="Custom", found_index=0)
            hi = dlgGroup.child_window(title=f"Health Issue", control_type="DataItem", found_index=0)
            nameValue = str(hi.legacy_properties()['Value']) # GET THE TEXT!
            logger.console(f"      {str(nameValue).ljust(30)}", newline=False)
            #
            type = dlgGroup.child_window(title=f"Type", control_type="DataItem", found_index=0)
            typeValue = str(type.legacy_properties()['Value']) # GET THE TEXT!
            logger.console(f"  {str(typeValue).ljust(20)}", newline=False)
            #
            status = dlgGroup.child_window(title=f"Status", control_type="DataItem", found_index=0)
            statusValue = str(status.legacy_properties()['Value']) # GET THE TEXT!
            logger.console(f"  {str(statusValue).ljust(30)}", newline=False)
            #
            date = dlgGroup.child_window(title=f"Entered", control_type="DataItem", found_index=0)
            dateValue = str(date.legacy_properties()['Value']) # GET THE TEXT!
            spaceIndex = dateValue.find(" ")
            dateValue = dateValue[0:spaceIndex]
            logger.console(f"  {str(dateValue)}", newline=False)

            nameTest = nameValue == nameCheck
            typeTest = typeValue == typeCheck 
            statusTest = statusValue == statusCheck
            dateTest = dateValue == currDateCheck 

            if  typeTest and nameTest and statusTest and dateTest:
                logger.console(f" (*FOUND*)") 
                verified = True
                break
            else:
                logger.console(f" (NOT FOUND)")
                
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Verify_Health_Issue_Status_Py' [Py]")
        logger.console(f"      (Error={e} [Py]")
        raise Exception(f"{e}")
    
    finally:
        logger.console(f"\n      verified = {verified}\n")
        return verified

def Verify_Health_Concern_Flag():
    logger.console(f"      Verify_Health_Concern_Flag() ...[Py]")
    app, proc = Get_Health_Issues_Manager_App()
    found = False
    
    try:
        app = app.window(handle=proc.handle)
        dlg = app.window(auto_id="pnlUpper", class_name_re = "WindowsForms10.*")
        dlg = dlg.child_window(auto_id="ultraGridExistingIssues", class_name_re = "WindowsForms10.*") 
        dlg = dlg.child_window(auto_id="pnlGridContainer", control_type="Pane")
        dlg = dlg.child_window(auto_id="ultraSharedHealthIssueManagerGrid", control_type="Tab")
        dlg = dlg.child_window(auto_id="ultraTabSharedControlsPage1", control_type="Pane")
        dlg = dlg.child_window(auto_id="ugInner", control_type="Table")
        dlg = dlg.child_window(title="Band 0", control_type="Table")#dlg.print_control_identifiers()
        dlg =  dlg.child_window(title=f"Band 0 row 1", control_type="Custom", found_index=0)
        dlgRow = dlg.child_window(title=f"Band 0 row 1", control_type="Custom")#dlgRow.print_control_identifiers()
        flagfield = dlgRow.Dataitem2
        props = flagfield.legacy_properties()
        flagfieldValue = flagfield.legacy_properties()['Value'] # GET THE TEXT!
        
        flagfield3 = dlgRow.Dataitem3
        props3 = flagfield3.legacy_properties()
        flagfieldValue3 = flagfield3.legacy_properties()['Value'] # GET THE TEXT!
        
        logger.console(f"      flagfieldValue = '{flagfieldValue}'")

        if True:
            logger.console(f"(PASS)")
            found = True
        else:
            logger.console(f"(***FAIL***)")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Verify_Health_Issue_Status' [Py]")
        logger.console(f"      (Error={e} [Py]")
        raise Exception(f"{e}")
        
    finally:
        logger.console(f"")
        return found
    
def  Health_Issue_Right_Click_Py(menuItem, group, row, tabCount):
    logger.console(f"   Health_Issue_Right_Click_Py() ...[Py]")
    logger.console(f"      menuItem='{menuItem}'  row='{row}' group='{group}'  tabCount='{tabCount}' ...[Py]")
    app, proc = Get_Health_Issues_Manager_App()
    match = False
    
    try:
        app = app.window(handle=proc.handle)
        dlg = app.window(auto_id="pnlUpper", class_name_re = "WindowsForms10.*")
        dlg = dlg.child_window(auto_id="ultraGridExistingIssues", class_name_re = "WindowsForms10.*") 
        dlg = dlg.child_window(auto_id="pnlGridContainer", control_type="Pane")
        dlg = dlg.child_window(auto_id="ultraSharedHealthIssueManagerGrid", control_type="Tab")
        dlg = dlg.child_window(auto_id="ultraTabSharedControlsPage1", control_type="Pane")
        dlg = dlg.child_window(auto_id="ugInner", control_type="Table")
        dlg = dlg.child_window(title="Band 0", control_type="Table")
        dlg =  dlg.child_window(title=f"Band 0 row {group}", control_type="Custom", found_index=0)
        dlgRow = dlg.child_window(title=f"Band 0 row {row}", control_type="Custom")#dlgRow.print_control_identifiers()
        logger.console(f"      right click ...[Py]")
        dlgRow.right_click_input()

        for i in range(0, int(tabCount)):
            logger.console(f"      TAB", newline=False)
            pyautogui.press("TAB")
        
        logger.console(f" ...[Py]")
        logger.console(f"      ENTER ...[Py]")

        pyautogui.press("ENTER")
        
        if menuItem == "Delete":
            logger.console(f"      Click 'Yes' to confirm delete...[Py]")
            pyautogui.press("TAB")
            pyautogui.press("ENTER")
            
        elif menuItem == "Add To Favorites":
            logger.console(f"      Click 'OK' to Add to favorites...[Py]")
            pyautogui.press("TAB")
            pyautogui.press("TAB")
            pyautogui.press("TAB")
            pyautogui.press("ENTER")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Health_Issue_Right_Click_Py' ...[Py]")
        logger.console(f"      (Error={e}) [Py]\n")
        raise Exception(f"{e}")
    
    finally:
        logger.console(f"")
        return match

def Add_Acute_Kidney_Failure_Health_Issue_Py():
    time.sleep(5)
    logger.console(f"   Add_Acute_Kidney_Failure_Health_Issue_Py ...[Py]")
    logger.console(f"      group=0 row=38 [Py]")
    app, proc = Get_Health_Issues_Manager_App()

    try:
        app = app.window(handle=proc.handle)
        dlgPnlLower = app.window(auto_id="pnlLower", class_name_re = "WindowsForms10.*")#dlg.print_control_identifiers(depth=3)
        dlg = dlgPnlLower.child_window(auto_id="HealthIssueBrowseControl", class_name_re = "WindowsForms10.*")   
        dlg = dlg.child_window(auto_id="tabControlBrowseItems", control_type="Tab")
        dlg = dlg.child_window(auto_id="Browse", control_type="Pane")
        dlg = dlg.child_window(auto_id="pnlBrowse", control_type="Pane")
        dlg = dlg.child_window(auto_id="BrowseResultGrid", control_type="Table")
        dlg = dlg.child_window(title="Band 0", control_type="Table")  #tableDlg.print_control_identifiers()
        dlg = dlg.child_window(title="Band 0 row 38", control_type="Custom", found_index=0)
        addButton = dlg.DataItem1
        logger.console(f"      Click 'Add' ...[Py]")
        addButton.click_input()
        logger.console(f"")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Add_Acute_Kidney_Failure_Health_Issue_Py' ...[Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")

def  Verify_Health_Issue_Added_To_Favorites_Py(healthIssue, group, row):
    logger.console(f"   Verify_Health_Issue_Added_To_Favorites_Py() ...[Py]")
    logger.console(f"      healthIssue = '{healthIssue}'   group='{group}'   row='{row}' ...[Py]")
    app, proc = Get_Health_Issues_Manager_App()
    verified = False
    try:
        app = app.window(handle=proc.handle)
        dlgPnlLower = app.window(auto_id="pnlLower", class_name_re = "WindowsForms10.*")#dlg.print_control_identifiers(depth=3)
        dlg = dlgPnlLower.child_window(auto_id="HealthIssueBrowseControl", class_name_re = "WindowsForms10.*")   
        dlg = dlg.child_window(auto_id=f"tabControlBrowseItems", control_type="Tab")
        dlg = dlg.child_window(auto_id=f"Favorites", control_type="Pane")
        dlg = dlg.child_window(auto_id=f"ultraGridFav", control_type="Table")
        dlg = dlg.child_window(title=f"Categories", control_type="Table")
        dlg = dlg.child_window(title=f"Categories row 1", control_type="Custom")
        dlg = dlg.child_window(title=f"Relation1", control_type="Table")
        dlg = dlg.child_window(title=f"Relation1 row {row}", control_type="Custom")
        dlg = dlg.child_window(title=f"Health Issues", control_type="DataItem")
        healthIssueElem = dlg.legacy_properties()['Value'] # GET THE TEXT!
        logger.console(f"      valueSearch='{healthIssueElem}',  valueFound '{healthIssueElem}'   ")
        lookingFor = str(healthIssue).upper()
        valueFound = str(healthIssueElem).upper()
        
        if  lookingFor == valueFound:
            logger.console(f"      FOUND in Favorites (PASS) ...[Py]\n") 
            verified = True
        else:
            logger.console(f"      NOT FOUND in Favorites **(FAIL)** ...[Py]\n")
    
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Verify_Health_Issue_Added_To_Favorites_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")
    
    return verified

def Select_First_Health_Issue_Type_To_Copy_To_Py():
    procs = findwindows.find_elements()
    for proc in procs:
        if "Health Issue Manager" in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id) 
            break
    dlg = app.window(handle=proc.handle).window(auto_id="pnlUpper", class_name_re = "WindowsForms10.*") #dlg.print_control_identifiers()
    dlg = dlg.child_window(auto_id="ultraGridExistingIssues", class_name_re = "WindowsForms10.*") 
    dlg = dlg.child_window(auto_id="pnlGridContainer", control_type="Pane")
    dlg = dlg.child_window(auto_id="ultraSharedHealthIssueManagerGrid", control_type="Tab")
    dlg = dlg.child_window(auto_id="ultraTabSharedControlsPage1", control_type="Pane")
    dlg = dlg.child_window(auto_id="ugInner", control_type="Table")
    dlg = dlg.child_window(title="Band 0", control_type="Table")
    dlg = dlg.child_window(title="Band 0 row 3", control_type="Custom")
    dlg = dlg.child_window(title="Band 0 row 1", control_type="Custom")
    dlg = dlg.child_window(title="Copy To", control_type="DataItem")
    dlg.click_input()
    logger.console(f"      select Medical Hx ...[Py]\n")
    pyautogui.typewrite("Medical Hx") #Admitting Dx
   


if __name__ == '__main__':
    logger.console(f"\nBEGIN MAIN....\n")
    #Select_First_Health_Issue_Type_To_Copy_To_Py()
    #Validate_First_Health_Issue_For_Every_Category()
    #Add_First_Health_Issue_Under_Full_Catalog_Search_Py()
    #Verify_Visit_Problem_Type_Is_Not_Showing_Py("A42.1")
    #Select_Health_Issue_Type_To_Copy_To_Py("1","Cancer Dx","4")
    #Verify_Health_Issue_Status("Active","2","1",)
    #Health_Issue_Right_Click("Show/Modify","1","1", 1)
    #Health_Issue_Right_Click("Discontinue","1","1", 2)
    #Health_Issue_Right_Click("Delete","1","1", 3)
    #Health_Issue_Right_Click("Flag As Health Concern","4","1", 4)
    #Health_Issue_Right_Click("Add To Favorites","4","1", 5)
    #Health_Issue_Right_Click("Manuel Mapping","4","1", 6)
    #Verify_Health_Issue_Added_To_Favorites_Py("Acute kidney failure","1","3")
    #Verify_Health_Issue_Status("Medical Hx","Abdominal actinomycosis", "Active", 2, 1)
    #Verify_Health_Issue_Status("Active Problems","Abdominal actinomycosis", "Resolved", 1, 0)
    #Verify_Health_Concern_Flag()
    #Verify_Health_Issue_Status_Is_Resolved("Active Problems", "Abdominal actinomycosis", "Resolved", 1)
    #Select_Health_Issue_Status("Chronic")
    Validate_First_Health_Issue_For_Every_Category_Py()