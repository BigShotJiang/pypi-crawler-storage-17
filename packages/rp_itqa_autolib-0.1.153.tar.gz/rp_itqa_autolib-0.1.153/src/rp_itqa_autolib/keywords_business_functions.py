"""
----------------------------------------------------------------------------------
 Author:  Andrew Bowman, Frank Runfola
 Created: 07/01/2023
----------------------------------------------------------------------------------
"""

import os
import re
import sys
import time
import datetime
import random
import re
import pyautogui
import pywinauto
import RPA.Windows as rpawin
import RPA.Windows as rpawin
import RPA.core.windows.locators

from random import randrange
from time import gmtime, strftime
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows
from pywinauto.application import Application
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
from pywinauto import findwindows
from RPA.core.windows.locators import WindowsElement
from RPA.Excel.Files import Files
from .utils_basic import get_win, find_cascaded_elements
from robot.api import logger
from datetime import datetime, timedelta

CURRENT_DATETIME = datetime.now().strftime('%Y-%m-%d-%H-%M')
_DIALOG_COUNT = 0
FILE_DIR = '\\\\infotech\\itqa$\\FrankRunfola\\EHR_RevCycle'
_ERROR_LOG_FILE_EXT = '.tsv'
_ERROR_LOG_SEP = '\t'

def get_last_day_of_next_month():
    """
    Ex. if today is september 13th, 2021, return '31-Oct-2021'
    Time Complexity: O(1)
    :return:
    """
    current_month = datetime.now().month
    # a little confusing why the next_month calculation is the way it is
    # months are numbered starting at 1
    # in order to do mod ops properly, they should be 0-indexed
    # so, to represent the current month in mod space, we would do
    # next_month = (current_month - 1) % 12 + 1
    # however, we want the next month, so we add 1 to the current month
    # which results in:
    next_month = (current_month % 12) + 1
    next_month_date = datetime.now().replace(month=next_month, day=1)
    if next_month < current_month:
        next_month_date = next_month_date.replace(year=next_month_date.year + 1)
    next_day = next_month_date + timedelta(days=1)
    while next_day.month == next_month:
        next_month_date = next_day + timedelta(days=0)
        next_day = next_month_date + timedelta(days=1)

    return next_month_date.strftime('%d-%b-%Y')

# this is for the tests in 'old' directory
def get_x_orders():
    """
    Get all the orders out of `orders.xlsx` that have an 'x' in column B
    Make sure the file is not open somewhere when you try to open it
    :return:
    """
    files = Files()
    try:
        workbook = files.open_workbook(rf'{FILE_DIR}\\TestData\\orders_audit.xlsx')
    except Exception as e:
        print(e)
        raise Exception(rf'Unable to open {FILE_DIR}\\TestData\\orders_audit.xlsx. Is it open somewhere else?')
    rows = workbook.read_worksheet()
    x_rows = [row['A'] for row in rows if row['B'] == 'x']
    return x_rows

# this is for the tests in 'exploratory' directory
def get_select_orders(keyword: str):
    """
    Get all the orders out of `orders.xlsx` that have the parameter in column B
    Make sure the file is not open somewhere when you try to open it
    :return:
    """
    files = Files()
    try:
        workbook = files.open_workbook(rf'{FILE_DIR}\\TestData\\variables_for_orders_GK_version_100223_version.xlsx')
    except Exception as e:
        print(e)
        raise Exception(rf'Unable to open {FILE_DIR}\\TestData\\variables_for_orders_GK_version_100223_version.xlsx. Is it open somewhere else?')
    rows = workbook.read_worksheet()
    selected_rows = [row['A'] for row in rows if row['B'] is not None and keyword in row['B']]
    return selected_rows

def get_cp_orders():
    """
    Just read all the variables from `cardiopulmonary-orders.csv`
    Note: there is no header in this file
    :return:
    """
    fp = rf'{FILE_DIR}\\TestData\\cardiopulmonary_orders.csv'
    with open(fp, 'r') as f:
        lines = f.readlines()
    return [line.strip() for line in lines if len(line.strip()) > 0]

def get_variables_for_order_type(order_type: str) -> list[str]:
    """
    Read the variables from the spreadsheet from a specific tab.
    The values we want are in column 'A' and we filter by order type, which is in column 'I'
    We also require column 'M' to be 'ORC'.
    """
    SHEET_NAME = 'orders catalogue to sched'
    VALUE_COL = 'A'
    ORDER_TYPE_COL = 'I'
    files = Files()
    try:
        # example of full filename:
        # GK_Orders_to_Scheduling_Automation_worksheet_11152023.xlsx
        file_prefix = 'GK Orders to Scheduling Automation worksheet '

        candidate_files = [ fn for fn in os.listdir(rf'{FILE_DIR}\\TestData') if fn.startswith(file_prefix) ]
        if len(candidate_files) == 0:
            raise Exception(f'Unable to find any files starting with "{file_prefix}"')
        if len(candidate_files) > 1:
            raise Exception(f'Found more than one file starting with "{file_prefix}"')

        filename = candidate_files[0]
        logger.info(f'found valid file: {filename}')

        get_numbers = re.compile(r'\d+')
        date_str = get_numbers.findall(filename)[0]
        logger.info(f'Found date string: {date_str}')

        workbook = files.open_workbook(os.path.join(rf'{FILE_DIR}\\TestData', filename),read_only=True)
    except Exception as e:
        print(e)
        raise Exception(rf'Unable to open {FILE_DIR}\\TestData\\{filename}. Is it open somewhere else?')

    if SHEET_NAME not in workbook.sheetnames:
        raise Exception(f'Unable to find sheet "{SHEET_NAME}" sheet name.')
    
    rows = workbook.read_worksheet(SHEET_NAME)
    selected_rows = [row[VALUE_COL] for row in rows if
                     row[ORDER_TYPE_COL] is not None and order_type in row[ORDER_TYPE_COL]
                     # and row['M'].strip() == 'ORC' # idk where I got this idea
                     ]
    return selected_rows

def check_order_summary(order_summary: str):
    # make sure it was requested for the correct date (last day of next month)
    requested_date_pat = re.compile(r'Requested for: (\d+-[a-zA-Z]+-\d{4})')
    matches = requested_date_pat.findall(order_summary)
    if len(matches) > 0:
        if matches[0] == get_last_day_of_next_month():
            return True
        else:
            raise Exception(f"The match {matches[0]} was not the correct date. It should be {get_last_day_of_next_month()}")
    else:
        raise Exception(f"Order summary \"{order_summary}\" did not contain 'requested date'! See Utils.check_order_summary")

def log_error_file_header(filename: str):
    """
    Log the error to the error file
    :param short_desc:
    :param args:
    :return:
    """
    fp = rf'{FILE_DIR}\\Reports{CURRENT_DATETIME}-{filename}{_ERROR_LOG_FILE_EXT}'
    with open(fp, 'w') as f:
        f.write(f'variable{_ERROR_LOG_SEP}short_desc{_ERROR_LOG_SEP}THIS_IS_HEADER\n')

def get_combined_log_files(filename_contains: str) -> set[tuple[str, str]]:
    """
    Log files are tsv files with the format:
        variable    short_desc    THIS_IS_HEADER
    This gets all the files from the Reports directory containing where the filename
    contains the string in the parameter, and combines them into one set (removing duplicates)
    :param filename_contains:
    :return:
    """
    reports_filepath = rf'{FILE_DIR}\\Reports'
    files = [f for f in os.listdir(reports_filepath) if filename_contains in f]
    all_errors = set()
    for file in files:
        print('reading file: ', file, '...')
        with open(os.path.join(reports_filepath, file), 'r') as f:
            lines = f.readlines()
        for line in lines[1:]:
            variable, short_desc, *args = line.split(_ERROR_LOG_SEP)
            all_errors.add((variable.strip(), short_desc.strip()))

    return all_errors

def get_all_combined_log_files(d: dict[str, str]) -> set[tuple[str, str, str]]:
    """
    Combine all the log files into one. Label each variable with a new column called 'Group'

    :param d: maps a 'filename contains' to a 'Group'. Example: { 'labs-errors': 'Labs', 'rad-errors': 'Rad' }
                The 'Group' should be exactly equal to the first parameter used by the keyword 'Get Select Orders'
                in each of the scripts.
    :return: The data with the columns (variable, short_desc, group)
    """
    print('Gathering data...')
    logs = [ [ (variable, short_desc, group) for variable, short_desc in get_combined_log_files(filename_contains) ] for filename_contains, group in d.items() ]

    # concatenate the lists
    print('Combining data...')
    all_errors = set()
    for log in logs:
        all_errors.update(log)
    return all_errors

def write_log_file_data(header: list[str], data: list[tuple], filename: str):
    """
    Write the log file
    :param header:
    :param data:
    :param filename:
    :return:
    """
    fp = rf'{FILE_DIR}\\Reports{CURRENT_DATETIME}-{filename}{_ERROR_LOG_FILE_EXT}'
    with open(fp, 'w') as f:
        f.write(_ERROR_LOG_SEP.join(header) + '\n')
        for row in data:
            f.write(_ERROR_LOG_SEP.join(row) + '\n')

def log_to_error_file(filename: str, variable: str, short_desc: str, *args):
    """
    Log the error to the error file
    :param short_desc:
    :param args:
    :return:
    """
    fp = rf'{FILE_DIR}\\Reports{CURRENT_DATETIME}-{filename}{_ERROR_LOG_FILE_EXT}'
    def clean_text(text: str):
        return text.replace('\n', '').replace('\r', '').strip()

    with open(fp, 'a') as f:
        f.write(f'{variable}{_ERROR_LOG_SEP}{short_desc}{"".join([f"{_ERROR_LOG_SEP}{clean_text(x)}" for x in args])}\n')

def check_order_summary_for_csa_schedule_instruction(variable: str, order_summary: str):
    # I think it should check to make sure the variable is correct, but G says it's unnecessary
    if variable.lower() not in order_summary.lower():
        raise Exception(f"Not a matching order summary. Expected {variable} to be in {order_summary}")

    # make sure it was requested for the correct date (last day of next month)
    # G said the 'CSA Scheduling Instructions:' part of this is not necessary
    # Updated by Gabe: Changed to 4 weeks instead of one Month per request if G
    requested_date_pat = re.compile(r'4\s*weeks')
    
    matches = requested_date_pat.findall(order_summary)
    if len(matches) > 0:
        return True
    else:
        raise Exception(
            f"Order summary \"{order_summary}\" did not contain '4 weeks'. See Utils.check_order_summary_for_csa_schedule_instruction")

def get_dialogs() -> list[WindowsElement]:
    procs = findwindows.find_elements() 
    win = rpawin.Windows()
    win.control_window('regex:.*Altera.*', timeout=120.0)
    elems = win.get_elements('type:WindowControl', siblings_only=False, search_depth=4)
    return elems

def set_dialog_count():
    global _DIALOG_COUNT
    _DIALOG_COUNT = len(get_dialogs())

def is_new_dialog() -> bool:
    global _DIALOG_COUNT
    dc = len(get_dialogs())
    if dc > _DIALOG_COUNT:
        _DIALOG_COUNT = dc
        return True
    else:
        return False

def has_scrollbar_name(win_elem: RPA.core.windows.locators.WindowsElement):
    win = rpawin.Windows()
    name = win.get_attribute(win_elem, 'Name')
    return name == 'Vertical' or name == 'Horizontal'

def get_patient_element(ID=None, visit_number=None):
    """
    Example usage:
    e = get_patient_element(ID='123456', visit_number='1')
    e.click()

    :param ID: id of the patient
    :param visit_number: visit number of the patient?
    :return:
    """
    ID = str(ID)
    visit_num = str(visit_number)

    es = find_cascaded_elements(r'TempPatientList > regex:TempPatientList\srow\s\d+ > regex:Patient\s*ID[a-zA-Z\s/]*')
    # add their ids and visit numbers by parsing
    def get_id(txt):
        return txt.split('/')[0].strip()
    def get_visit_num(txt):
        return txt.split('/')[1].strip()

    texts = [ get_win().get_value(e) for e in es ]
    print('found patients:')
    print('\n'.join(texts))
    ies = [ { 'id': get_id(txt), 'visit_number': get_visit_num(txt), 'elem': e } for (e, txt) in zip(es, texts) ]

    if id is not None:
        ies = [ e for e in ies if e['id'] == ID ]
    if visit_num is not None:
        ies = [e for e in ies if e['visit_number'] == visit_num]

    if len(ies) == 0:
        raise Exception(f'Could not find patient with ID {ID} and visit number {visit_num}')
    elif len(ies) > 1:
        raise Exception(f'Found multiple patients with ID {ID} and visit number {visit_num}')

    return ies[0]['elem']

#######################################
# ADDED BY FRANK RUNFOLA
# DATE: 7/3/2025
#######################################
def double_click_order_name_py(elemNum=0):
    logger.console(f"   double_click_order_name_py(elemNum={elemNum}) ... [Py]")
    
    try:
        app,proc = Get_Order_Entry_Worksheet_App()
        dlg = app.window(handle=proc.handle) #dlg.print_control_identifiers()
        dlg.maximize()
        dlg.set_focus()
        dlg = dlg.window(class_name="AfxMDIFrame140", control_type="Pane", found_index=0)
        dlg = dlg.window(class_name="AfxMDIFrame140", control_type="Pane")
        dlg = dlg.child_window(class_name="ListBox", control_type="List")
        orders = dlg.children(control_type="ListItem")
        order = orders[elemNum] # get first order
        logger.console(f"      double click first Order ...[Py]\n")
        order.click_input(double=True)

    except Exception as e:
        logger.console(f"\n      **ERROR** double_click_order_name_py [Py]")
        logger.console(f"      (Error={e}[Py] \n")
        raise Exception(f"{e}")


def Get_Order_Entry_Worksheet_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if "Order Entry Worksheet" in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id, handle=proc.handle)
            break
    return app,proc



def Write_Visit_Headers_Py():
    logger.console(f"\n      {str("Row").ljust(3)}  ", newline=False)
    logger.console(f"{str("Admit_Date").ljust(10)}  ", newline=False)
    logger.console(f"{str("Assigned_Location").ljust(28)}  ", newline=False)
    logger.console(f"{str("Visit_Status").ljust(12)}  ", newline=False)
    logger.console(f"{str("MRN").ljust(10)}  ", newline=False)
    logger.console(f"{str("Visit_ID").ljust(14)}")

    logger.console(f"      {str("---").ljust(3)}  ", newline=False)
    logger.console(f"{str("----------").ljust(10)}  ", newline=False)
    logger.console(f"{str("----------------------------").ljust(28)}  ", newline=False)
    logger.console(f"{str("------------").ljust(12)}  ", newline=False)
    logger.console(f"{str("----------").ljust(10)}  ", newline=False)
    logger.console(f"{str("------------").ljust(14)}")


def  Search_Visit_Match_Py (row,admitDate,assignedLoc,VisitStatus,mrn,visitId,statusSearch,aptNumSearch):
    visitMatch = False
    visitId = str(visitId).strip()
    logger.console(f"      {str(row).ljust(3)}  ", newline=False)
    logger.console(f"{str(admitDate).ljust(10)}  ", newline=False)
    logger.console(f"{str(assignedLoc).ljust(28)}  ", newline=False)
    logger.console(f"{str(VisitStatus).ljust(12)}  ", newline=False)
    logger.console(f"{str(mrn).ljust(10)}  ", newline=False)
    logger.console(f"{str(visitId).ljust(14)}", newline=False)
   
    if VisitStatus=='ADM':
        visitMatch = VisitStatus==statusSearch 
    else:
        visitMatch = VisitStatus==statusSearch and visitId==aptNumSearch
    
    if visitMatch:
         logger.console(f"(*MATCH*)")
         visitMatch=True
    else:
        logger.console(f"(NO MATCH)")
    return visitMatch

def Write_Visit_MRN_Headers_Py():
    logger.console(f"\n      {str("Row").ljust(3)}  ", newline=False)
    logger.console(f"{str("Admit_Date").ljust(10)}  ", newline=False)
    logger.console(f"{str("MRN").ljust(10)}  ", newline=False)
    logger.console(f"{str("Visit_ID").ljust(14)}")

    logger.console(f"      {str("---").ljust(3)}  ", newline=False)
    logger.console(f"{str("----------").ljust(10)}  ", newline=False)
    logger.console(f"{str("----------").ljust(10)}  ", newline=False)
    logger.console(f"{str("------------").ljust(14)}")

def  Visit_MRN_Match_Py (row,admitDate,mrn,visitId,mrnSearch,visitIdSearch):
    visitMatch = False
    visitId = str(visitId).strip()
    logger.console(f"      {str(row).ljust(3)}  ", newline=False)
    logger.console(f"{str(admitDate).ljust(10)}  ", newline=False)
    logger.console(f"{str(mrn).ljust(10)}  ", newline=False)
    logger.console(f"{str(visitId).ljust(14)}", newline=False)
   
    visitMatch = mrn==mrnSearch and visitId==visitIdSearch
    
    if visitMatch:
         logger.console(f"(*MATCH*)")
         visitMatch=True
    else:
        logger.console(f"(NO MATCH)")
    return visitMatch

if __name__ == '__main__':
    #get_dialogs()
    double_click_order_name_py()


