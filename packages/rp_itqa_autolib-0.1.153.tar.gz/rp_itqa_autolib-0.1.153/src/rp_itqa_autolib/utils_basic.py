"""
----------------------------------------------------------------------------------
 Author:   Frank Runfola
 Created: 09/01/2023
----------------------------------------------------------------------------------
"""

from pathlib import Path
import sys
import calendar
from time import gmtime, strftime
import time
import datetime
from random import randrange
import random
import re
from time import gmtime, strftime
import pyautogui
import pywinauto
import RPA.Windows as rpawin
import typing
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
import time
from datetime import datetime, timedelta
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows

from pywinauto.application import Application


"""
pywinauto

A Dialog
----------------------------------------------------------------------------------
A window containing several other GUI elements/controls like buttons, edit boxes etc. 
Dialog is not necessarily a main window. 
Message box on top of main form is also a dialog. 
Main form is also considered a dialog by pywinauto.

A control
----------------------------------------------------------------------------------
A GUI element at any level of a hierarchy. 
This definition includes window, button, edit box, grid, grid cell, bar etc.
----------------------------------------------------------------------------------
"""

App               =  "Altera"   # Altera   configurable for PR38
Gateway           =  "Gateway"
#
AppGatewayLogon   =  App + " " + Gateway + " " + "Logon"
AppGateway        =  App + " " + Gateway

HealthIssuesManager = "Health Issue Manager"

_static_win = None
win = rpawin.Windows()


def focus_window_py(title):
    titleRe = f'regex:"{title}.*"'
    win.control_window(titleRe)
 
def Maximize_And_Scroll_Down_RadCT_IV_Form():
    procs = findwindows.find_elements()  
    procName = ''
    for proc in procs:
        if "RAD_CT Scan IV Form" == proc.automation_id:
            app = Application(backend="uia").connect(process=proc.process_id)
            procName = proc.name
            break 
    radCt = app.window(handle=proc.handle)
    radCt.maximize()


def Does_Window_Exist_Py(selector):
    try:
        win = rpawin.Windows()
        win.control_window(selector, timeout=5)
        return True
    except:
        return False

def get_automation_id(selector):
    if type(selector) is str:
        win = rpawin.Windows()
        return win.get_element(selector).automation_id
    else:
        elem = selector
        return elem.automation_id

def _find_cascaded_elements(cascaded_string: str, assume_no_cycles=True, debug_mode=False) -> list['ElementShell']:
    """
    Problem: this query doesn't work: (1) `id:RequestedDate > path:2`
    because multiple elements match the query 'id:RequestedDate'
    The previous solution was to be more specific: (2) `id:RequestedDate name:14-Sep-2023 > path:2`
    but sometimes you can't be more specific.

    This function enables the first query (1) to work by checking
    all the elements that match the query, and narrowing it down
    by the queries following the '>'

    Python example:
        locator = find_cascaded_element('id:RequestedDate > path:2')
        win.click(locator)
    Robot example:
        ${locator}=     find cascaded element    id:RequestedDate > path:2
        click           ${locator}


    Pitfalls / Warnings
    1. Avoid using anchors and this method together. This method makes use of anchors,
        so yours will likely be overwritten.
    2. This method WILL break if you use '>' anywhere else other than to separate queries.

    :param cascaded_string: a string of queries separated by '>'
    :param assume_no_cycles: assume we will never encounter the same element twice in our search (default: True)
    :return: the locator of the element that matches the cascaded string
    """
    win = rpawin.Windows()
    if win.anchor_element is not None:
        raise Exception('You are using an anchor. You CANNOT mix anchors and this method')

    selectors = [s.strip() for s in cascaded_string.split(' > ')]

    elems: list[tuple[ElementShell, list[str]]] = [(ElementShell(e), selectors[1:]) for e in win.get_elements(selectors[0])] # siblings_only=False??
    parent = {e: None for e, _s in elems}
    seen = set(parent.keys())

    # debug printing
    dprint = lambda *args, **kwargs: print(*args, **kwargs) if debug_mode else None

    dprint('\ncurrent elements:', [e.elem.name for (e, _s) in elems])

    leaf_elements = []
    while len(elems) > 0:
        e, s = elems.pop(0)
        if len(s) == 0:
            leaf_elements.append(e)
            continue

        # print(f'setting anchor to {e}')
        win.set_anchor(e.elem)
        # print(f'running query: "{s[0]}"')
        try:
            children = list(map(ElementShell, win.get_elements(s[0])))
            dprint('query', s[0])
            dprint('children found:', [c.elem.name for c in children])
        except ElementNotFound as e:
            # logger.error(f'Error running query: "{s[0]}" with exception: {e}')
            children = []
        win.clear_anchor()

        for child in children:
            if not assume_no_cycles and child in seen:
                continue
            elems.append((child, s[1:]))
            seen.add(child)
            parent[child] = e
            child.parent = e

        dprint('current elements:', [e.elem.name for (e, _s) in elems])

    if len(leaf_elements) == 0:
        logger.error(f'No elements found for cascaded string: {cascaded_string} [Py]')
        raise ElementNotFound(f'No elements found for cascaded string: {cascaded_string}')

    return leaf_elements

def find_cascaded_elements(cascaded_string: str, assume_no_cycles=True, debug_mode=False) -> list[WindowsElement]:
    if debug_mode:
       print("\n-----------------------------------------")
       print("            BEGIN DEBUGGING")
       print("-----------------------------------------")
       
    elems =  [x.elem for x in _find_cascaded_elements(cascaded_string, assume_no_cycles=assume_no_cycles, debug_mode=debug_mode)]
    if debug_mode:
        print("\n-----------------------------------------")
        print("            END DEBUGGING")
        print("-----------------------------------------\n")
    return elems

def find_cascaded_element(cascaded_string: str, assume_no_cycles=True, debug_mode=False) -> WindowsElement:
    leaf_elements = _find_cascaded_elements(cascaded_string, assume_no_cycles=assume_no_cycles, debug_mode=debug_mode)
    if len(leaf_elements) > 1:
        logger.warn(f'Multiple elements ({len(leaf_elements)}) found for cascaded string: {cascaded_string}')

        def print_all_parents(element):
            if element is None:
                return
            print_all_parents(element.parent)
            print(element)

        print('here are the stack traces for each element:')
        for e in leaf_elements:
            print(f'trace for element {e}')
            print_all_parents(e)

        print('here are all the matching elements lined up so you can compare:')
        for e in leaf_elements:
            print(e)

        raise ElementNotFound(f'Multiple elements ({len(leaf_elements)}) found for cascaded string: {cascaded_string}')

    return leaf_elements[0].elem

def enhanced_click(locator):
    win = rpawin.Windows()
    return win.click(find_cascaded_element(locator))

def enhanced_send_keys(locator, keys):
    win = rpawin.Windows()
    return win.send_keys(find_cascaded_element(locator), keys)

def enhanced_select(locator, item):
    win = rpawin.Windows()
    return win.select(find_cascaded_element(locator), item)

def get_win() -> Windows:
    global _static_win
    if _static_win is None:
        import RPA.Windows as rpawin
        _static_win = rpawin.Windows()
    return _static_win

def get_children(e: WindowsElement) -> list[WindowsElement]:
    try:
        return get_win().get_elements('regex:.*', root_element=e, search_depth=1, siblings_only=False, timeout=0.1)
    except Exception as e:
        return []

def Write_NewLine(s, prependNewline=True):
    if prependNewline is True:
        s = "\n" + s
    logger.console(s)

class ElementShell:

    elem: WindowsElement
    parent: 'ElementShell'

    def __init__(self, e: WindowsElement):
        self.elem = e
        self.parent = None
        self.children = None

    # tried to use all the relevant string attributes that won't have weird values

    def __hash__(self):
        # name: str = ""
        # automation_id: str = ""
        # control_type: str = ""
        # class_name: str = ""
        return hash((self.elem.name, self.elem.automation_id, self.elem.control_type, self.elem.class_name))

    def __eq__(self, other):
        if not isinstance(other, ElementShell):
            return False
        return (self.elem.name, self.elem.automation_id, self.elem.control_type, self.elem.class_name) == (
                other.elem.name, other.elem.automation_id, other.elem.control_type, other.elem.class_name)

    def __str__(self):
        return str(self.elem)

    def __repr__(self):
        return repr(self.elem)

class InteractiveElementShell(ElementShell):

    def __init__(self, e: WindowsElement, focus_method: typing.Callable[[], None]):
        super().__init__(e)
        self.focus_method = focus_method
        self.children = None

    @property
    def children(self):
        if self._children is None:
            self._children = []
            self.focus_method()
            for child in get_children(self.elem):
                self._children.append(InteractiveElementShell(child, self.focus_method))

        return self._children

    @children.setter
    def children(self, value):
        self._children = value


    def __str__(self):
        return f"Element({self.elem.name}, {self.elem.automation_id}, {self.elem.control_type}, {self.elem.class_name}, {self.elem.width}x{self.elem.height})"

    def __repr__(self):
        return str(self)

########################################################################################################################
########################################################################################################################
#                                                 PRACTICE                                                             #
########################################################################################################################
########################################################################################################################

def sublime():
    procs = findwindows.find_elements()
    for proc in procs:
        if "Sublime" in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id, handle=proc.handle) # 10,000 items
            break

    win = app.window()
    win = app.window(title_re=".*Sublime Text*.", control_type="Window")
    win = app.window().children()
    win.print_control_identifiers()
    win.print_control_identifiers(filename="sublimeDepth3.txt")
    win = win.TitleBar
    win = win.Minimize
    win.click()
    win.print_control_identifiers()
    
def notepad():
    #app = Application().start("Notepad.exe")
    procs = findwindows.find_elements()
    for proc in procs:
        if "Notepad" in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id, handle=proc.handle) # 10,000 items
            break

    dlg = app.window(title_re=".*Notepad*.", control_type="Window")
    #dlg.print_control_identifiers()
    dlg = dlg.child_window(title="Text Editor", auto_id="15", control_type="Edit")
    dlg = dlg.dump_tree()
    dlg.Notepad.MenuSelect("Edit -> Replace")
    dlg.Replace.print_control_identifiers()

def return_all_elements():
    app = Get_Altera_App()
    win = app.window(title_re='.*22.1.*PR.*', class_name="Window")
    pane =  win.child_window(auto_id="ScmApplicationHost", control_type="Custom")
    pane =  pane.child_window(auto_id="ClrTabHost", control_type="Custom")
    pane =  pane.child_window(class_name="ResultsTabControl", control_type="Custom")
    pane =  pane.child_window(auto_id="_ResultViews", control_type="Custom")
    pane =  pane.child_window(auto_id="ViewHost")
    pane =  pane.child_window(auto_id="SummaryViewGrid")
    pane =  pane.child_window(auto_id="m_SummaryViewGrid", control_type="Table")
    pane =  pane.child_window(title="MasterCategoryBand", control_type="Table")
    pane =  pane.child_window(title="MasterCategoryBand row 1", control_type="Custom")
    pane =  pane.child_window(title="CategoryOneBand", control_type="Table")
    pane =  pane.child_window(title="CategoryOneBand row 6", control_type="Custom")
    logger.console(f"   Check1")
    #pane.print_control_identifiers()    
    logger.console(f"   Check2")

########################################################################################################################
########################################################################################################################
#                                                 DYNAMIC                                                              #
########################################################################################################################
########################################################################################################################



def is_box_checked():
    procs = findwindows.find_elements()  
    for proc in procs:
        if "CPOE_" in proc.automation_id:
            app = Application(backend="uia").connect(process=proc.process_id) #win32
            break
    app.FormPatientHeader  #dynamicCPOEPane = app.window(auto_id="CPOE_Next 10")    
    dynamicCPOEPane = app.window(handle=proc.handle).app.window(title_re=".* - ORDERS.*", class_name_re = "WindowsForms10.*")  
    checkBox = dynamicCPOEPane.window(auto_id = "Quest_CB_3|1", control_type="System.Windows.Forms.CheckBox")  #checkBox.print_control_identifiers()
    #wrapper = checkBox.wrapper_object()
    checkBoxState = checkBox.get_check_state()
    logger.console(f"   CheckBoxState = {checkBoxState} ... [Py]")
    isChecked = False
    if checkBoxState == 1:
        isChecked = True
    return isChecked

def click_add_hi_py():
    logger.console(f"      click_add_health_issue() ... [Py]")
    logger.console(f"      row=1  group=1 ... [Py]")
    app = Get_Health_Issues_Manager_App()
    try:
        win = app.window(auto_id="pnlLower", class_name_re = "WindowsForms10.*") #win.print_control_identifiers()    
        pane = win.child_window(auto_id="HealthIssueBrowseControl", class_name_re = "WindowsForms10.*")   
        pane = pane.child_window(auto_id="Favorites")
        pane = pane.child_window(auto_id="ultraGridFav")
        pane = pane.child_window(title="Categories")
        pane = pane.child_window(title="Categories row 1")
        pane = pane.child_window(title="Relation1", control_type="Table")
        pane = pane.child_window(title=f"Relation1 row 1", control_type="Custom")#pane.print_control_identifiers()    
        pane = pane.DataItem1
        logger.console(f"      click Add Health Issue ...[Py]")
        pane.click_input()
        return
        
    except Exception as e:
        logger.console(f"\n      **ERROR** click_add_health_issue [Py]")
        logger.console(f"      (Error={e}[Py] \n")
        raise Exception(f"{e}")
        


def Find_Name_In_Banner_Py(nameExpected): # Search for ( child_window(title="AUTOO2S-HAYES, SAMANTHA", auto_id="PatientDisplayName", control_type="Text"))

    logger.console(f"      Find_Name_In_Banner_Py (nameExpected='{nameExpected}') ... [Py]")

    app = Get_Altera_App()
    dlg = app.window(title_re='.*22.1.*PR.*', class_name="Window")
    dlg = dlg.child_window(class_name="ScmApplicationHost", control_type="Custom", found_index=0)     #dlg = dlg.children()
    dlg = dlg.child_window(auto_id="_patientHeader", control_type="Custom")  #dlg.print_control_identifiers()
    logger.console(f"         searching for name ...[Py]")
    foundName = str(False)

    try:
        dlg = dlg.child_window(title={nameExpected}, auto_id="PatientDisplayName", control_type="Text")
        dlg = dlg.wait('exists',timeout=300)
        foundName = str(True)
        logger.console(f"         FOUND NAME (nameExpected='{nameExpected}') ...[Py]\n")
        
    except Exception as e:
        logger.console("\n      **ERROR** in Find_Name_In_Banner_Py [Py]")
        logger.console(f"       Name '{nameExpected}' not found [Py]")
        logger.console(f"      (Error={e}\n")
        raise Exception(f"{e}")

    return foundName

def get_ids(obj):
    tempfile = 'path/a.tmp'
    obj.print_control_identifiers(tempfile) # get the ids
    with open(tempfile) as t:
        data = t.read()  # read it from the file
    # os.remove(tempfile)  optional immediate clean up
    return data  # get the string




        
    
def Handle_Warning_Message_Pass(warningMsgWin):
    logger.console(f"      PASS - 'Un-coded Allergy Warning Message' found...[Py]")
    warningMsgWinButton = warningMsgWin.child_window(auto_id="btnOk", control_type="Button")
    warningMsgWinButton.click()
    
def Handle_Warning_Message_Fail():
    logger.console(f"      FAIL - 'Un-coded Allergy Warning Message' NOT found...[Py]")
    



def Verify_Text_In_Banner(textToSearch):
    logger.console(f"   Verify_Text_In_Banner (Search '{textToSearch}') ...[Py]")
    try:
        found = str(False)
        app = Get_Altera_App() 
        dlg = app.window(title_re='.*22.1.*PR.*', class_name="Window")
        dlg = dlg.child_window(class_name="ScmApplicationHost", control_type="Custom", found_index=0)     #dlg = dlg.children()
        dlg = dlg.child_window(auto_id="_patientHeader", control_type="Custom")  #dlg.print_control_identifiers()
        dlg = dlg.child_window(class_name="StandardPatientHeader", control_type="Custom")
        dlg = dlg.child_window(auto_id="FirstAdditionalLineRTF")
        dlgText = dlg.window_text() #texts() 
        bannerTextUpper = str(dlgText).upper().strip()
        textUpper = str(textToSearch).upper()
        logger.console(f"      haystack = '{bannerTextUpper}'   needle = '{textUpper}' [Py]")
        
        if textUpper in bannerTextUpper:
                logger.console(f"      PASS - '{textUpper}' IS FOUND in Banner Text\n") 
                found = str(True)
        else:
            logger.console(f"      FAIL - '{textUpper}' NOT FOUND in Banner Text\n")
            
    except Exception as e:
        logger.console(f"   **ERROR** in 'Verify_Text_In_Banner' [Py]")
        logger.console(f"   (Error={e} [Py]\n")
        raise Exception(f"{e}")
        
    return found

def Verify_Text_In_Banner_Second_Row(textToSearch, negative=False):
    logger.console(f"   Verify_Text_In_Banner_Second_Row (Search '{textToSearch}') ...[Py]")
    try:
        found = str(False)
        app = Get_Altera_App()
        dlg = app.window(title_re='.*22.1.*PR.*', class_name="Window")
        dlg = dlg.child_window(class_name="ScmApplicationHost", control_type="Custom", found_index=0)     #dlg = dlg.children()
        dlg = dlg.child_window(auto_id="_patientHeader", control_type="Custom")  #dlg.print_control_identifiers()
        dlg = dlg.child_window(class_name="StandardPatientHeader", control_type="Custom")
        dlg = dlg.child_window(auto_id="SecondAdditionalLineRTF")
        dlgText = dlg.window_text() #texts() 
        bannerTextUpper = str(dlgText).upper().strip()
        textUp = str(textToSearch).upper()
        logger.console(f"   haystack = '{bannerTextUpper}'   needle = '{textUp}' [Py]")
        
        if negative and textUp not in bannerTextUpper:
            logger.console(f"      PASS - '{textUp}' NOT FOUND in Banner Text") 
            found = str(True)
        elif negative:
            logger.console(f"      FAIL - '{textUp}' FOUND in Banner Text")
        if not negative and textUp in bannerTextUpper:
            logger.console(f"      PASS - '{textUp}' IS FOUND in Banner Text") 
            found = str(True)
        elif not negative:
            logger.console(f"      FAIL - '{textUp}' NOT FOUND in Banner Text")
        
        
    except Exception as e:
        logger.console(f"   **ERROR** in 'Verify_Text_In_Banner_Second_Row' [Py]")
        logger.console(f"   (Error={e} [Py]\n")
        raise Exception(f"{e}")
        
    return found

def Get_Allergy_Name_To_Discontinue():
    allergyName = "NOT FOUND"
    logger.console(f"   Get_Allergy_Name_To_Discontinue ...[Py]")
    time.sleep(2)
    app = Get_Altera_App() 
    
    try:
        dlg = app.window(title_re='.*22.1.*PR.*', control_type="Window") #props = dlg.legacy_properties()
        dlg = dlg.window(auto_id="XAForm", class_name_re="WindowsForms10.*")
        dlg = dlg.child_window(auto_id="AllergySummary", control_type="Pane")  #props = dlg.legacy_properties()
        dlg = dlg.child_window(auto_id="dgAllergies", control_type="Table")
        dlg = dlg.child_window(title="Allergies", control_type="Table") #dlg.print_control_identifiers()
        dlgTopRow = dlg.child_window(title=f"Allergies row 1", control_type="Custom",found_index=0)
        rows = dlgTopRow.children(control_type="Custom")
        rowName = rows[0].element_info.name #dlg.print_control_identifiers()
        logger.console(f"      rowName '{rowName}'", newline=False)
        dlg = dlgTopRow.child_window(title=rowName, control_type="Custom")
        dlg = dlg.child_window(title="Allergen/Product", control_type=f"DataItem")
        allergyName = dlg.legacy_properties()['Value'] # GET THE TEXT!
        logger.console(f"      allergyName = '{allergyName}'")
        
    except Exception as e:
        logger.console(f"\n**ERROR** in 'Get_Allergy_Name_To_Discontinue' [Py]")
        logger.console(f"\n(Error={e} [Py]\n")
        allergyName = "NOT FOUND"
        raise Exception(f"{e}")
    
    return allergyName

def Click_Add_Health_Issue_By_Expanding_Category_Py(row, hiName):
    logger.console(f"      Click_Add_Health_Issue_By_Expanding_Category_Py() (row='{row}'  hiName='{hiName}') ...[Py]")
    app = Get_Health_Issues_Manager_App()
    try:
        win = app.window(auto_id="pnlLower", class_name_re = "WindowsForms10.*") #win.print_control_identifiers()
        dlg = win.child_window(auto_id="HealthIssueBrowseControl")
        dlg = dlg.child_window(auto_id="tabControlBrowseItems")
        dlg = dlg.child_window(auto_id="Favorites")
        dlg = dlg.child_window(auto_id="ultraGridFav")
        dlg = dlg.child_window(title="Categories",control_type="Table")
        ctgyRow = dlg.child_window(title="Categories row 1")
        ######################################################
        #                   CLICK CATEGORY
        ######################################################
        ctgyitem = ctgyRow.child_window(title="Category", control_type="DataItem")
        ctgyitem.click_input()
        logger.console(f"         expanding favorite group ...")
        pyautogui.press("right")
        ######################################################
        #                      CLICK ADD
        ######################################################
        relation = ctgyRow.child_window(title="Relation1",control_type="Table") #relationRow.print_control_identifiers()
        relationRow = relation.child_window(title=f"Relation1 row {row}", control_type="Custom")
        addButton = relationRow.DataItem1
        logger.console(f"         clicking row {row} ...\n")
        addButton.click_input()

    except Exception as e:
        logger.console(f"      **ERROR** Click_Add_Health_Issue_By_Expanding_Category_Py")
        logger.console(f"      (Error={e}[Py] \n")
        raise Exception(f"{e}")
        
    return



def Maximize_Window_Py(name):
    logger.console(f"   Maximize_Window_Py() ... [Py]")
    foundWindow, app,proc = Find_Window(name)

    if not foundWindow:
        raise ElementNotFound(f"{name} Window not found!!!")
    else:
        logger.console(f"      {name} Window found ... [Py]")
        logger.console(f"      maximizing window ... [Py]\n")
        window = app.window(handle=proc.handle)
        window.maximize()

def Find_Window(name, nameAlt="BLAH"):
    foundWindow = False
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if proc.name.startswith(name): 
            app = app.connect(process=proc.process_id)
            app = app.window(handle=proc.handle)
            foundWindow = True
            break
        elif proc.name.startswith(nameAlt): 
            app = app.connect(process=proc.process_id)
            app = app.window(handle=proc.handle)
            foundWindow = True
            break
            
    return foundWindow,app,proc

def  Get_EHR_Window_Status_Py(ehrTitle, ehrLogon):
    try:
        logger.console(f"   Get_EHR_Window_Status_Py (ehrTitle='{ehrTitle}) ...[Py]")
        foundWindow, app,proc = Find_Window(ehrTitle, ehrLogon)
        closeLogon = False
        env = ""
        if foundWindow is True:
            windowName = str(proc.name)
            if ehrLogon not in windowName: # Check for logon screen
                logger.console(f"      EHR Is Logged-in and Running ...[Py]")
                windowNameSplit = windowName.split("22.1")[1].strip()
                envAndPr = windowNameSplit.split("- DB Refresh")[0].strip().split(" ")
                pr = envAndPr[0]
                env = envAndPr[1]
                logger.console(f"      Environment='{env}' PR='{pr}' ...[Py]\n")
            else:
                logger.console(f"      EHR 'Login' Screen is running ...[Py]\n")
                closeLogon = True
        else:
            logger.console(f"      EHR is NOT Running ...[Py]\n")
            
    except Exception as e:
        logger.console(f"\n      (Error={e}[Py] \n")
        raise Exception(f"{e}")
    
    return foundWindow, env, closeLogon

def  Close_Window_If_Open_Py(name):
    try:
        logger.console(f"   Check_If_Window_Open_Py(name={name}) ...[Py]")
        foundWindow, app,proc = Find_Window(name)
        if foundWindow is True:
            logger.console(f"      Window '{name} is Running, Closing window ...\n", newline=False)
            app.close()
        else:
            logger.console(f"      Window '{name} is NOT Running ...[Py]\n")

    except Exception as e:
        logger.console(f"\n      (Error={e}[Py] \n")
        logger.console(f"      Close_Window_If_Open_Py(name='{name}) FAILED!! ...[Py]\n")
       
########################################################################################################################
########################################################################################################################
#                                                 UTILITIES                                                            #
########################################################################################################################
########################################################################################################################
def get_time_stamp_mdyhms():
    timestamp = f"{datetime.now().month}-{datetime.now():%d-%Y_%H%M%S}"
    return timestamp

def get_date_mdy():
    timestamp = f"{datetime.now().month}-{datetime.now():%d-%Y}"
    return timestamp

def get_allergy_count():
    allergyCount =  0
    logger.console(f"   get_allergy_count() ...[Py]\n")
    app = Get_Altera_App() 

    try:
        dlg = app.window(title_re='.*22.1.*PR.*', control_type="Window") #props = dlg.legacy_properties()
        dlg = dlg.window(auto_id="XAForm", class_name_re="WindowsForms10.*",found_index=0)
        dlg = dlg.child_window(auto_id="AllergySummary", control_type="Pane")  #props = dlg.legacy_properties()
        dlg = dlg.child_window(auto_id="dgAllergies", control_type="Table")
        dlg = dlg.child_window(title="Allergies", control_type="Table") #dlg.print_control_identifiers()
        dlg = dlg.child_window(title=f"Allergies row 1", control_type="Custom",found_index=0)# GET THE ith ROW
        allergyCount = dlg.legacy_properties()['Value'] # GET THE TEXT!
        allergyCount  = allergyCount.split("Allergy (",1)[1]
        allergyCount  = int(allergyCount.replace(")",""))
        logger.console(f"      allergyCount={allergyCount} ...[Py]")
    except Exception as e:
        logger.console(f"\n**ERROR** 'get_allergy_count'[Py]")
        logger.console(f"(Error={e}[Py]")
        raise Exception(f"{e}")        
    finally:
        logger.console(f"      Allergies Count = {allergyCount} [Py]")
        
    return allergyCount



def Get_Health_Issues_Manager_App():
    time.sleep(1)
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if HealthIssuesManager in proc.name: 
            app = app.connect(process=proc.process_id).window(handle=proc.handle)
            app.click_input()
            break
    return app

###################################################################################
#  TODO (REFACTOR) NEEDS TO BE IMPLEMENTED WITH ALL THE Altera DIALOGUES
###################################################################################
def Get_Altera_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if AppGateway in proc.name: 
            app = app.connect(process=proc.process_id,handle=proc.handle)
            break
    return app

############################################################
# TODO : NOT NECESSARY BUT NICE TO HAVE
############################################################
def Take_Error_Screenshot(fileName, folder):
    timeStamp = strftime("%m-%d-%Y %H%M%S", gmtime())
    errorFilename = f"errors/{folder}/Screenshots/{fileName}_{timeStamp}.Png"
    pyautogui.screenshot(errorFilename, region=(1, 1, 1900, 1000))

def Double_Click_Coordinates_Py(Name,X,Y):
    logger.console(f"   Double_Click_Coordinates_Py() ...[Py]")
    
    X = int(X)
    Y = int(Y)

    logger.console(f"      (Name='{Name}'  X='{X}' Y='{Y}') ...[Py]")

    try:
        logger.console(f"      CLICK '{Name}' coords=({X},{Y}) ...[py]\n")
        pywinauto.mouse.move(coords=(X,Y))
        time.sleep(2)
        pywinauto.mouse.click(coords=(X,Y),)

    except Exception as e:
        logger.console(f"      **ERROR** in 'Double_Click_Coordinates_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")


def Get_Date_Current_DDMMMYYYY_Dashes_Py(dashDelim=False, getTomorrow=False, includeCentury=False):
    now = datetime.now()
    if getTomorrow == True:
        now = now + timedelta(days=1)

    currMonth = calendar.month_abbr[now.month] # get 3 char month to match EHR
    year = 'y'

    if includeCentury:
       year ='Y'
    if dashDelim == True:
        currDateCheck = now.strftime(f"%d-{currMonth}-%{year}") #Outputs 29May25
    else:
        currDateCheck = now.strftime(f"%d{currMonth}%{year}") #Outputs 29May25
    return currDateCheck


def Get_Date_From_MMDDYYYY_To_DDMMMYYYY_Py(athenaDate, yearDigit:int=2, delimAth='/', delimEhr=''):   #from '09/02/2025' to '02Sep25'
    logger.console(f"   Get_Date_From_MMDDYYYY_To_DDMMMYYYY_Py() ...[Py]")
    logger.console(f"      athenaDate='{athenaDate}', yearDigit={yearDigit}, delimAth='{delimAth}', delimEhr='{delimEhr}' ...[Py]")
    date_object = datetime.strptime(athenaDate, f"%m{delimAth}%d{delimAth}%Y").date()
    currDateCheck = Convert_Date(date_object,athenaDate,yearDigit,delimEhr)
    return currDateCheck

def Get_Date_From_YYYYMMDD_TO_DDMMMYYYY_Py(athenaDate, yearDigit:int=4, delimAth='-', delimEhr='-'):   #from '2000-01-01' to '01-Jan-2000'
    logger.console(f"   Get_Date_From_YYYYMMDD_TO_DDMMMYYYY_Py() ...[Py]")
    logger.console(f"      athenaDate='{athenaDate}', yearDigit={yearDigit}, delimAth='{delimAth}', delimEhr='{delimEhr}' ...[Py]")
    date_object = datetime.strptime(athenaDate, f"%Y{delimAth}%m{delimAth}%d").date()
    currDateCheck = Convert_Date(date_object,athenaDate,yearDigit,delimEhr)
    return currDateCheck


def Convert_Date(date_object,athenaDate,yearDigit,delimEhr):
    logger.console(f"      Athena Date (Original) : '{athenaDate}'")
    day = f'{date_object.day:02d}'
    year =str(date_object.year)[-yearDigit:]
    currMonth = date_object.month
    currMonth = calendar.month_abbr[currMonth]
    currDateCheck = f"{day}{delimEhr}{currMonth}{delimEhr}{year}" #29May25
    logger.console(f"      EHR Date (Converted)   : '{currDateCheck}'\n")
    return currDateCheck

def Get_Date_Current_MMDDYYYY_Slashes_Py(weekOffset=0):
    currDate =   datetime.now() - timedelta(weeks=weekOffset)
    return currDate.strftime(f"%m/%d/%Y")

def Get_Time_HHMM_AMPM_Colon_Py():
    curr_time = datetime.now()# Get the current datetime object
    # --------------------------------------------------------------------
    # Format the time as "HH:MM AM/PM"
    # --------------------------------------------------------------------
    #    %I for hour (12-hour clock with leading zero for single digits)
    #    %M for minute (with leading zero for single digits)
    #    %p for AM/PM
    # --------------------------------------------------------------------
    formatted_time = curr_time.strftime("%I:%M%p")
    return formatted_time

def create_folder_if_not_exists(path: str | Path):
    p = Path(path)
    try:
        p.mkdir(parents=True, exist_ok=True)
    except PermissionError as e:
        raise RuntimeError(f"ERROR: No permission to create: {p}") from e
    except OSError as e:
        raise RuntimeError(f"ERROR: Failed to create {p}: {e}") from e


########################################################################################################################
########################################################################################################################
#                                                 MAIN - To test functions                                             #
########################################################################################################################
########################################################################################################################

def Press_Keys_Py(key,newline=False,sleep=1.5):
    logger.console(f"   Press {key} ...")
    if newline is True:
        logger.console(f"")
    pyautogui.press(key) #Presses enter
    time.sleep(sleep)

if __name__ == '__main__':
    logger.console(f"\nBEGIN MAIN....\n")
    
    #is_allergy_enabled()
    #nameFound = find_name("AUTOO2S-HAYES, SAMANTHA")
    #print(nameFound)
    #click_add_health_issue()
    #is_box_checked()
    #Maximize_And_Scroll_Down_RadCT_IV_Form()
    #Select_Reaction_And_Severity("row 2" , "Alopecia", OtherAllergen=True)
    #find_allergies_in_header()
    #find_no_known_allergies_line_item()
    #find_no_known_allergies_in_banner()
    #find_allergies_in_banner("albuterol, androgens, Barley, Du..", "No Known Allergies", noKnownAllergies=True)
    #find_allergies_in_banner("albuterol, Androgens, Barley, Du..", "un-coded", noKnownAllergies=False)
    #get_allergy_count()
    #-----------------------------------------
    #proc = Get_Allergies_Summary_View_Proc()
    #Click_OK_Allergy_Intolerance_Adding_New(proc)
    #Enter_Description_For_Other_Allergen(proc)
    #Click_OK_Allergy_Intolerance_Adding_New(proc)
    #Click_Uncoded_Allergy_Warning_Message(proc)
    #-----------------------------------------
    #find_uncoded_line_item_py()
    #Verify_Text_In_Banner('BMI: 23.9')
    #Verify_Allergy_Is_Removed_From_Banner("albuterol")
    #find_no_known_allergies_line_item()
    #-----------------------------------------
    #Is_EHR_Already_Open_Py()
    #Close_Window_If_Open_Py("Printing from")
    #Is_EHR_Already_Open_Py()
    #Double_Click_Coordinates_Py("Doc", 992,475)
    #----------------------------------------
    #date1 = Get_Date_From_MMDDYYYY_To_DDMMMYYYY_Py('09/02/2025') #'09/02/2025' to '02Sep25'
    #date2 = Get_Date_From_YYYYMMDD_TO_DDMMMYYYY_Py('2000-01-01') # '2000-01-01' to '01-Jan-2000'
    date3 = Get_Date_From_MMDDYYYY_To_DDMMMYYYY_Py('09/03/2025', delimAth='/', delimEhr='-') # '09/03/2025' to '03Sep25'


