"""
### Typed Oceanex
> A fully typed, validated async client for the Oceanex API

- Details
"""