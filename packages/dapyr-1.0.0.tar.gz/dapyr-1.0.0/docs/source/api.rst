API
===

.. autosummary::
   :toctree: generated

   DAPyr
