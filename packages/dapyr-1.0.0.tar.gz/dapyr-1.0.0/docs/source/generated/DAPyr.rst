﻿DAPyr
=====

.. automodule:: DAPyr

   
   .. rubric:: Functions

   .. autosummary::
   
      copyExpt
      loadExpt
      loadParamFile
      plotExpt
      plotLocalization
      runDA
      saveExpt
   
   .. rubric:: Classes

   .. autosummary::
   
      Expt
   