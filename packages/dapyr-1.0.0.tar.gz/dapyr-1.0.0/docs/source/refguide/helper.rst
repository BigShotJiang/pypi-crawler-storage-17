Helper Functions
=================

Basic Helper Functions
------------------------
.. autofunction:: DAPyr.copyExpt


Saving and Reading Experiments
-------------------------------

.. autofunction:: DAPyr.loadParamFile

.. autofunction:: DAPyr.loadExpt

.. autofunction:: DAPyr.saveExpt

Plotting and Visualization
----------------------------

.. autofunction:: DAPyr.plotLocalization

.. autofunction:: DAPyr.plotExpt

