Running a Data Assimilation Experiment
=======================================

.. autofunction:: DAPyr.runDA


