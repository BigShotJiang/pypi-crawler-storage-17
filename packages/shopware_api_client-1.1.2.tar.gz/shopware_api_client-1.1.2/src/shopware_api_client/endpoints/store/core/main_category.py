from shopware_api_client.models.main_category import MainCategoryBase


class MainCategory(MainCategoryBase):
    pass
