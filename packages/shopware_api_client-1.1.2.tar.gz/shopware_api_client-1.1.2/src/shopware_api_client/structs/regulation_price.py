from shopware_api_client.fieldsets import FieldSetBase


class RegulationPrice(FieldSetBase):
    price: float
