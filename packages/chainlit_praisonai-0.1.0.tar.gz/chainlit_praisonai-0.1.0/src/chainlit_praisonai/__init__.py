"""Chainlit integration for PraisonAI multi-agent framework."""

from chainlit_praisonai.client import PraisonAIClient

__all__ = ["PraisonAIClient"]
__version__ = "0.1.0"
