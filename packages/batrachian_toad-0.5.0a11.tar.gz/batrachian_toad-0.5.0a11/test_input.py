name = input("Your name:")
print("Your name is", name)
