from rich.console import Console


console = Console()
console.print("Hello")
console.show_cursor()
console.print("World")
