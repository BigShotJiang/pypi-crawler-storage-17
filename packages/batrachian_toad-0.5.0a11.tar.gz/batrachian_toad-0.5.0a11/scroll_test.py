from time import sleep

for n in range(200):
    print(f"Scroll {n}")
    sleep(0.1)

