## Bank reconcile

Access Invoicing / Dashboard with a user with Full Acounting
capabilities. Select reconcile on the journal of your choice.

## Account reconcile

Access Invoicing / Accounting / Actions / Reconcile All the possible
reconcile options will show and you will be able to reconcile properly.
You can access the same widget from accounts and Partners.
