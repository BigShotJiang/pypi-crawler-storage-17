from .services import (
    test_coop_agreement_service,
    test_crm_lead_service,
    test_discovery_channel_service,
    test_res_partner_service,
    test_res_partner_public_service,
    test_subscription_request_service,
)