=========
Panel app
=========

.. note::

   Work in progress.

.. raw:: html

   <iframe
     src="_static/panel/app.html"
     height="650px"
     width="490px"
   >
   </iframe>

.. note::

   The `Panel <https://panel.holoviz.org/>`__ app is defined in the
   ``panel`` subdirectory `of the repo <https://github.com/zmoon/stringcalc/tree/main/panel>`__.
