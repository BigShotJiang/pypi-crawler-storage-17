"""Database tools for SingleStore MCP server."""

from .database import run_sql

__all__ = ["run_sql"]
