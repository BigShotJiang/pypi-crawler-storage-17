class GlueFormFieldAttr {
    constructor(name, value) {
        this.name = name
        this.value = value
    }
}
