"""Version information for trust-score-agent."""

__version__ = "0.1.0"

