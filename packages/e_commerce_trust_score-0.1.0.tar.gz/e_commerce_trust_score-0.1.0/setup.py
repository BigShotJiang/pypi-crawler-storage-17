"""Setup script for trust-score-agent package."""

from setuptools import setup

# All configuration is in pyproject.toml
# This file is here for compatibility with older pip versions
setup()

