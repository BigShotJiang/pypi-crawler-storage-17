from ..pipeline.estimators import CORFinder as ECorFinder

# This class has moved
# The future location will be nabu.pipeline.estimators.CORFinder
CORFinder = ECorFinder
