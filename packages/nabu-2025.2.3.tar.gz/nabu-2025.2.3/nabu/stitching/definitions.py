from enum import Enum


class StitchingType(Enum):
    Y_PREPROC = "y-preproc"
    Z_PREPROC = "z-preproc"
    Z_POSTPROC = "z-postproc"
