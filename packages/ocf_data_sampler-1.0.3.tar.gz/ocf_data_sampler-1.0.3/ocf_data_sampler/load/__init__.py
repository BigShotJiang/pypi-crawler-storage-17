from ocf_data_sampler.load.generation import open_generation
from ocf_data_sampler.load.nwp import open_nwp
from ocf_data_sampler.load.satellite import open_sat_data