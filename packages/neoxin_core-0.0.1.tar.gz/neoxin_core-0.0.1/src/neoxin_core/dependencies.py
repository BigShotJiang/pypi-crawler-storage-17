"""
依赖项模块

提供 FastAPI 路由函数所需的依赖项。
"""

from typing import Annotated
from fastapi import HTTPException, status, Header, Depends
from jwt.exceptions import ExpiredSignatureError, InvalidTokenError
from .db import get_session_local
from .security import decode_token
from .storage import get_storage_manager, StorageManager


def get_db():
    """
    获取数据库会话依赖项

    用于在 FastAPI 路由函数中获取数据库会话。

    Yields:
        Session: 数据库会话实例
    """
    SessionLocal = get_session_local()
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def require_authenticated(authorization: str = Header(None)):
    """
    登录依赖, 从Authorization头中获取token, 验证token是否有效
    """
    if not authorization:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="未登录")
    # 解析Authorization头，验证token
    token = authorization.split("Bearer ")[-1]
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="未登录")

    try:
        # 验证token是否有效
        payload = decode_token(token)
        return {
            "id": payload.id,
            "account": payload.account,
            "login_type": payload.login_type,
        }
    except ExpiredSignatureError:
        # token已过期
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="token已过期"
        )
    except InvalidTokenError:
        # token无效
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="token无效"
        )
    except Exception as e:
        # 其他异常
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="token无效"
        ) from e


# 类型注解，方便在路由中使用
StorageManagerDep = Annotated[StorageManager, Depends(get_storage_manager)]
