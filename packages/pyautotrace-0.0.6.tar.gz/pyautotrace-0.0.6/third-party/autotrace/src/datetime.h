#pragma once

#include <glib.h>

gchar *at_time_string(void);
