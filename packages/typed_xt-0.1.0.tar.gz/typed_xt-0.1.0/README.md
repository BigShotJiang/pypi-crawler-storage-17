# Typed Xt

> A fully typed, validated async client for the Xt API

Use *autocomplete* instead of documentation.

🚧 Under construction.