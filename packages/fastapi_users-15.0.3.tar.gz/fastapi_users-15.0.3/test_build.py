# flake8: noqa
import sys

try:
    from fastapi_users import FastAPIUsers
except:
    sys.exit(1)

sys.exit(0)
