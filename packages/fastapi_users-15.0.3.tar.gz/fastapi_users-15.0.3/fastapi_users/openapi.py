from typing import Any

OpenAPIResponseType = dict[int | str, dict[str, Any]]
