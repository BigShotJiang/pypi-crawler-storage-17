from .memvid_rs import *

__doc__ = memvid_rs.__doc__
if hasattr(memvid_rs, "__all__"):
    __all__ = memvid_rs.__all__