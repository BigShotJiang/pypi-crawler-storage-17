"""Gateway metrics for tracking latency, cost, and token usage."""

