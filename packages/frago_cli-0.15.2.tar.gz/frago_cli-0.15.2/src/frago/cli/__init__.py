"""
CLI模块 - 命令行接口

提供与Shell脚本兼容的命令行接口。
"""

from .main import cli

__all__ = ["cli"]