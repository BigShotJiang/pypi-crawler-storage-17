"""
Meta Modules - Self-Evolution and Module Generation

Modules for AI self-improvement and code generation
"""

from . import generator

__all__ = ['generator']
