"""
Atomic Competition Operations
"""

__all__ = []
