# CodeBuddy Agent SDK for Python

SDK for building AI agents with CodeBuddy Code's capabilities. Programmatically interact with AI to build autonomous agents that can understand codebases, edit files, and execute workflows.

## Installation

```bash
# Using uv (recommended)
uv add codebuddy-agent-sdk

# Using pip
pip install codebuddy-agent-sdk
```

## Quick Start

```python
import asyncio
from codebuddy_agent_sdk import query

async def main():
    async for message in query(
        prompt="What files are in this directory?",
        permission_mode="bypassPermissions",
    ):
        if message.type == "assistant":
            for block in message.content:
                if hasattr(block, "text"):
                    print(block.text)

asyncio.run(main())
```

## API Reference

### `query(prompt, **options)`

Create a query to interact with the agent.

```python
async for message in query(
    prompt="Your prompt here",
    model="sonnet",                    # Model to use
    permission_mode="bypassPermissions",  # Permission mode
    max_turns=10,                      # Maximum conversation turns
    cwd="/path/to/project",            # Working directory
):
    # Handle message
    pass
```

### Message Types

- `system` - Session initialization info
- `assistant` - Agent responses (text, tool calls)
- `result` - Query completion status

## Related Links

- [CodeBuddy Code CLI](https://www.npmjs.com/package/@tencent-ai/codebuddy-code)
- [Documentation](https://cnb.cool/codebuddy/codebuddy-code/-/blob/main/docs)
- [Issues](https://cnb.cool/codebuddy/codebuddy-code/-/issues)

## Feedback

- Submit issues at [Issues](https://cnb.cool/codebuddy/codebuddy-code/-/issues)
- Contact: codebuddy@tencent.com
