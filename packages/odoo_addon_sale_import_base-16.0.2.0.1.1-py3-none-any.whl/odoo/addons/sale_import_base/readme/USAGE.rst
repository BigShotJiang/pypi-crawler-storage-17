Use the batch_process_imports method which requires a list of dicts as input and returns a list of job ids.
