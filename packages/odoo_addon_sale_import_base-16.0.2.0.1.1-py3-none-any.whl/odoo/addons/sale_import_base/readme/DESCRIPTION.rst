This module adds an easy way to import and validate sale orders in JSON format.
