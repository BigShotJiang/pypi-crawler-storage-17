"""Tests for Detective Benno."""
