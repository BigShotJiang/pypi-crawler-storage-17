import typer

from adaptivegears import __version__

app = typer.Typer(help="Adaptive Gears CLI tools")


def version_callback(value: bool):
    if value:
        print(f"adaptivegears {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False, "--version", "-v", callback=version_callback, is_eager=True
    ),
):
    pass


# Register subcommands
from adaptivegears.util.cli import app as util_app
from adaptivegears.pg.cli import app as pg_app

app.add_typer(util_app, name="util")
app.add_typer(pg_app, name="pg")
