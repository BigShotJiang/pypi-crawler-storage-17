"""HTML templates for tedana reporting."""
