This directory contains data required for tedana reporting.

html/ :                         HTML templates
