import pytest


from epitech_console.System import Setting
from epitech_console.System import Log
from epitech_console import init, quit


init()


def test_system_has_attributes(
    ) -> None:
    assert hasattr(Setting, "S_PACKAGE_NAME")
    assert hasattr(Setting, "S_PACKAGE_VERSION")
    assert hasattr(Setting, "S_PACKAGE_DESCRIPTION")
    assert hasattr(Setting, "S_PACKAGE_REPOSITORY")
    assert hasattr(Setting, "S_SETTING_SHOW_BANNER")
    assert hasattr(Setting, "S_SETTING_AUTO_COLOR")
    assert hasattr(Setting, "S_SETTING_SAFE_MODE")
    assert hasattr(Setting, "S_SETTING_MINIMAL_MODE")
    assert hasattr(Setting, "S_SETTING_DEBUG")
    assert hasattr(Setting, "S_SETTING_LOG")
    assert hasattr(Setting, "S_LOG")


def test_system_types(
    ) -> None:
    assert isinstance(Setting.S_PACKAGE_NAME, str)
    assert isinstance(Setting.S_PACKAGE_VERSION, str)
    assert isinstance(Setting.S_PACKAGE_DESCRIPTION, str)
    assert isinstance(Setting.S_PACKAGE_REPOSITORY, str)
    assert isinstance(Setting.S_SETTING_SHOW_BANNER, bool)
    assert isinstance(Setting.S_SETTING_AUTO_COLOR, bool)
    assert isinstance(Setting.S_SETTING_SAFE_MODE, bool)
    assert isinstance(Setting.S_SETTING_MINIMAL_MODE, bool)
    assert isinstance(Setting.S_SETTING_DEBUG, bool)
    assert isinstance(Setting.S_SETTING_LOG, bool)
    assert isinstance(Setting.S_LOG, Log)


quit(delete_log=True)
