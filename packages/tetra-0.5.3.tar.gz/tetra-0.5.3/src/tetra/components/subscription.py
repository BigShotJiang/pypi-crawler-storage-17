# TODO evaluate moving to dispatcher
registry: dict[str, list["ReactiveComponent"]] = {}
