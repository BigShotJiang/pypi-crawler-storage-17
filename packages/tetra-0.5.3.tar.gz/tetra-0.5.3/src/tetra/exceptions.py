class ComponentError(Exception):
    pass


class ComponentNotFound(ComponentError):
    pass


class LibraryError(Exception):
    pass
