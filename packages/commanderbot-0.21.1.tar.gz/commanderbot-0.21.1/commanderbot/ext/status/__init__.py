from discord.ext.commands import Bot

from commanderbot.ext.status.status_cog import StatusCog


async def setup(bot: Bot):
    await bot.add_cog(StatusCog(bot))
