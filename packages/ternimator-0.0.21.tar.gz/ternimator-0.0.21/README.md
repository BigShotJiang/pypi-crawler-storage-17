# Ternimator

[![Poetry](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/githuib/ternimator/master/assets/logo.json)](https://pypi.org/project/ternimator)
[![PyPI - Version](https://img.shields.io/pypi/v/ternimator)](https://pypi.org/project/ternimator/#history)
[![PyPI - Python Versions](https://img.shields.io/pypi/pyversions/ternimator)](https://pypi.org/project/ternimator)

Python utilities for animating data as console output.

```
                       ______
                     <((((((\\\
                     /      . }\
                     ;--..--._|}
  (\                 '--/\--'  )
   \\                | '-'  :'|
    \\               . -==- .-|
     \\               \.__.'   \--._
     [\\          __.--|       //  _/'--.
     \ \\       .'-._ ('-----'/ __/      \
      \ \\     /   __>|      | '--.       |
       \ \\   |   \   |     /    /       /
        \ '\ /     \  |     |  _/       /
         \  \       \ |     | /        /
          \  \      \        /
```
