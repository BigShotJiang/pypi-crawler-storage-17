from .my_traders import MyTraders

class Follower(MyTraders):
  ...