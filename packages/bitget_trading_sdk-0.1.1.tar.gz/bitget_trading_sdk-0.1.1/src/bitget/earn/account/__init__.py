from .assets import Assets

class Account(Assets):
  ...