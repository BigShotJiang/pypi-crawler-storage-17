from bitget.core import AuthRouter
from .account import Account

class Earn(AuthRouter):
  account: Account