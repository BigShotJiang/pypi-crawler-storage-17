from .all_positions import AllPositions

class Position(AllPositions):
  ...