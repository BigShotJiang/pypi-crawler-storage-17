from dataclasses import dataclass
from .fills import Fills

@dataclass
class Trade(Fills):
  ...

