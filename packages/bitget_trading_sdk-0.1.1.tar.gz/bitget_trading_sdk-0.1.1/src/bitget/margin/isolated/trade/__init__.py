from .fills import Fills

class Trade(Fills):
  ...