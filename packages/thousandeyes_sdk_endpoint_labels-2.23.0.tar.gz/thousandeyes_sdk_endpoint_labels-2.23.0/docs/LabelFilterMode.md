# LabelFilterMode

Type of matching to be applied for the values:  * `in`: The value on the agent must match one of the list of values provided. * `not-in`: The value on the agent must not match any of the list of values provided. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


