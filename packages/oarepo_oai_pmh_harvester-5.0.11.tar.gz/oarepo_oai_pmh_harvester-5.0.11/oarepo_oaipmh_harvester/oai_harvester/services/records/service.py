from oarepo_oaipmh_harvester.common.services.oai_harvester import (
    BaseOaiHarvesterService,
)


class OaiHarvesterService(BaseOaiHarvesterService):
    """OaiHarvesterRecord service."""
