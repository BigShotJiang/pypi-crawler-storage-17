from oarepo_runtime.records.dumpers.edtf_interval import EDTFIntervalDumperExt


class OaiHarvesterEDTFIntervalDumperExt(EDTFIntervalDumperExt):
    """edtf interval dumper."""

    paths = []
