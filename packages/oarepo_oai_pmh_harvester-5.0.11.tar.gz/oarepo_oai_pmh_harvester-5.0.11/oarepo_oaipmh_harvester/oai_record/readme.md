# OAI Record

The OAI Record is stored directly in the database.
This module serves as a Invenio record compatibility layer,
modeled after the invenio-users-resources module.

It provides mappings for OpenSearch and periodic tasks
to synchronize the database OAI record with the OpenSearch index.
