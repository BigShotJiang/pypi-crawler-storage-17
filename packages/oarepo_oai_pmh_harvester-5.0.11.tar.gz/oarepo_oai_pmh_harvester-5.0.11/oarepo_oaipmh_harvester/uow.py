from oarepo_runtime.uow import BulkUnitOfWork

# moved to oarepo_runtime.uow, but kept here for backward compatibility

__all__ = ["BulkUnitOfWork"]
