"""
CLI tests for Tactus command-line interface.
"""
