

class Toolz:
    def __init__(self) -> None:
        pass
