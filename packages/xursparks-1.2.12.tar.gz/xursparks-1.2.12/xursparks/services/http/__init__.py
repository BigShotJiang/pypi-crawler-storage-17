from .main import Xurl
from ...error.main import GenericXursparksException, ApiServiceException