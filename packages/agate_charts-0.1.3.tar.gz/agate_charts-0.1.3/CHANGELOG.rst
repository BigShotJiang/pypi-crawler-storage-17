0.1.3 - December 15, 2025
-------------------------

* Add Python 3.13 and 3.14 support. Drop support for end-of-life versions 3.8 and 3.9.

0.1.2 - February 23, 2024
-------------------------

* Add Python 3.12 support.
* Drop Python 3.7 support (end-of-life was June 27, 2023).

0.1.1 - October 4, 2023
-----------------------

* Update to recent agate, matplotlib and Python versions.

0.1.0 - September 23, 2015
--------------------------

* Use agate 0.10.0 extension API.
* TableSet.bar_chart
* TableSet.scatter_chart
* TableSet.column_chart
* TableSet.line_chart
* Table.bar_chart
* Table.scatter_chart
* Table.column_chart
* Table.line_chart
