===
API
===

.. automodule:: agatecharts.table
    :members:
    :undoc-members:
    :private-members:

.. automodule:: agatecharts.tableset
    :members:
    :undoc-members:
    :private-members:
