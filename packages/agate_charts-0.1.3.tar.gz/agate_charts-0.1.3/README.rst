.. image:: https://github.com/wireservice/agate-charts/workflows/CI/badge.svg
    :target: https://github.com/wireservice/agate-charts/actions
    :alt: Build status

.. image:: https://coveralls.io/repos/wireservice/agate-charts/badge.svg?branch=master
    :target: https://coveralls.io/r/wireservice/agate-charts
    :alt: Coverage status

.. image:: https://img.shields.io/pypi/dw/agate-charts.svg
    :target: https://pypi.python.org/pypi/agate-charts
    :alt: PyPI downloads

.. image:: https://img.shields.io/pypi/v/agate-charts.svg
    :target: https://pypi.python.org/pypi/agate-charts
    :alt: Version

.. image:: https://img.shields.io/pypi/l/agate-charts.svg
    :target: https://pypi.python.org/pypi/agate-charts
    :alt: License

.. image:: https://img.shields.io/pypi/pyversions/agate-charts.svg
    :target: https://pypi.python.org/pypi/agate-charts
    :alt: Support Python versions

agate-charts adds exploratory charting support to `agate <https://github.com/wireservice/agate>`_.

Important links:

* agate:            https://agate.rtfd.org
* Documentation:    https://agate-charts.rtfd.org
* Repository:       https://github.com/wireservice/agate-charts
* Issues:           https://github.com/wireservice/agate-charts/issues
