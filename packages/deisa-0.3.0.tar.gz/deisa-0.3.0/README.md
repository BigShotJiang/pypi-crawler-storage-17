
Deisa common library.
Contains the definition of a common interface that may be used with Dask and Ray.
