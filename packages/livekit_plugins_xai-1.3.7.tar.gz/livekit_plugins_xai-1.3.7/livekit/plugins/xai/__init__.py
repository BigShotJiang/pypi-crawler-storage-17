"""xAI plugin for LiveKit Agents"""

from .realtime import RealtimeModel

__all__ = [
    "RealtimeModel",
]
