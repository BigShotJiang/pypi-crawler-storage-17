# xAI plugin for LiveKit Agents

Support for the [xAI](https://x.ai/) realtime model.

See [https://docs.livekit.io/agents/integrations/xai/](https://docs.livekit.io/agents/integrations/xai/) for more information.

