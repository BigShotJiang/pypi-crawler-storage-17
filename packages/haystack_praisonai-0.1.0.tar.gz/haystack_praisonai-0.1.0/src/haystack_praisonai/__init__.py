"""Haystack integration for PraisonAI multi-agent framework."""

from haystack_praisonai.component import PraisonAIComponent

__all__ = ["PraisonAIComponent"]
__version__ = "0.1.0"
