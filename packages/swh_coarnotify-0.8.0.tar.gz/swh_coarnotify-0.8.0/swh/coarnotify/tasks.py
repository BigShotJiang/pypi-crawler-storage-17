# Copyright (C) 2025  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU Affero General Public License version 3, or any later version
# See top-level LICENSE file for more information
"""Celery tasks."""

from celery import shared_task
from celery.exceptions import MaxRetriesExceededError
from requests.exceptions import RequestException
import sentry_sdk


@shared_task(name=__name__ + ".ProcessInboundNotificationTask")
def coarnotify_process_inbound(notification_id: str):
    """Process a COAR Notification we've received.

    The scheduler task type is ``coarnotify-process-inbound``.

    Args:
        notification_id: a `InboundNotification` ID
    """
    from swh.coarnotify.server.handlers import get_handler
    from swh.coarnotify.server.models import InboundNotification

    notification = InboundNotification.objects.get(pk=notification_id)
    if handler := get_handler(notification):
        handler(notification)


@shared_task(bind=True, name=__name__ + ".SendOutboundNotificationTask")
def coarnotify_send_outbound(self, notification_id: str):
    """Send a COAR Notification we've prepared.

    The scheduler task type is ``coarnotify-send-outbound``.

    Args:
        notification_id: a `OutboundNotification` ID
    """
    from django.conf import settings
    from django.utils.module_loading import import_string

    from swh.coarnotify.server.models import OutboundNotification, Statuses

    notification = OutboundNotification.objects.get(pk=notification_id)
    COARClient = import_string(settings.CN_CLIENT)
    client = COARClient()
    try:
        client.send(notification.payload)
        notification.status = Statuses.PROCESSED
        notification.error_message = ""
        notification.save()
    except RequestException as exc:
        sentry_sdk.capture_exception(exc)
        notification.status = Statuses.RETRY
        notification.error_message = str(exc)
        notification.save()
        try:
            raise self.retry()
        except MaxRetriesExceededError:
            notification.status = Statuses.REJECTED
            notification.save()
