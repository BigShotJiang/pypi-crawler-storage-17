# Copyright (C) 2025  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU Affero General Public License version 3, or any later version
# See top-level LICENSE file for more information
import logging

from celery.contrib.testing.manager import Manager
from pyld import jsonld
import pytest
from rest_framework.authtoken.models import Token
from rest_framework.test import APIClient, APIRequestFactory

from swh.coarnotify.server.models import (
    InboundNotification,
    Organization,
    OutboundNotification,
)
from swh.model.model import Origin
from swh.scheduler.celery_backend.runner import run_ready_tasks
from swh.scheduler.model import TaskType
from swh.storage.tests.storage_data import StorageData

from . import notification

LOGGER = logging.getLogger(__name__)


@pytest.fixture(autouse=True)
def test_settings(settings):
    settings.CN_CLIENT = "swh.coarnotify.client.DummyCOARNotifyClient"


@pytest.fixture
def default_origin():
    return Origin("https://github.com/rdicosmo/parmap")


@pytest.fixture
def default_snapshot():
    return StorageData.snapshot


@pytest.fixture
def default_directory():
    return StorageData.directory


@pytest.fixture
def default_revision():
    return StorageData.revision


@pytest.fixture
def notification_payload(default_origin):
    return notification("00000000-0000-0000-0000-000000000000", default_origin.url)


@pytest.fixture
def inbound_notification(partner, default_origin):
    raw_payload = notification(
        "00000000-0000-0000-0000-000000000000", default_origin.url
    )
    payload = jsonld.compact(raw_payload, raw_payload["@context"])  # XXX cache ?
    return InboundNotification.objects.create(
        id="00000000-0000-0000-0000-000000000000",
        payload=payload,
        sender=partner,
        raw_payload=raw_payload,
    )


@pytest.fixture
def outbound_notification():
    return OutboundNotification.objects.create(
        id="bd6160ef-ed8e-4d61-a4c9-599169b2c351",
        payload=notification("bd6160ef-ed8e-4d61-a4c9-599169b2c351"),
    )


@pytest.fixture
def partner(db):
    return Organization.objects.create(
        url="http://partner.local", inbox="http://inbox.partner.local", name="Partner"
    )


@pytest.fixture
def member(partner, django_user_model):
    return django_user_model.objects.create_user(
        "member@partner.local", organization=partner
    )


@pytest.fixture
def member_token(member):
    return Token.objects.get(user=member)


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def authenticated_api_client(api_client, member_token):
    api_client.credentials(HTTP_AUTHORIZATION=f"Token {member_token.key}")
    return api_client


@pytest.fixture
def api_rf():
    return APIRequestFactory()


@pytest.fixture
def swh_storage(
    default_origin,
    default_snapshot,
    default_directory,
    mocker,
    swh_storage,
):
    swh_storage.origin_add([default_origin])
    swh_storage.snapshot_add([default_snapshot])
    swh_storage.directory_add([default_directory])
    mocker.patch("swh.coarnotify.server.handlers.get_storage", return_value=swh_storage)
    return swh_storage


@pytest.fixture
def cn_task_types():
    return [
        TaskType(
            type="coarnotify-process-inbound",
            description="Process a COAR Notification we've received",
            backend_name="swh.coarnotify.tasks.ProcessInboundNotificationTask",
        ),
        TaskType(
            type="coarnotify-send-outbound",
            description="Send a COAR Notification we've prepared",
            backend_name="swh.coarnotify.tasks.SendOutboundNotificationTask",
        ),
    ]


@pytest.fixture
def swh_scheduler(swh_scheduler, cn_task_types, mocker):
    """Create our task types and patch the scheduler calls."""
    for task_type in cn_task_types:
        swh_scheduler.create_task_type(task_type)
    for module in ["views.get_scheduler", "utils.get_scheduler"]:
        mocker.patch(f"swh.coarnotify.server.{module}", return_value=swh_scheduler)
    yield swh_scheduler


@pytest.fixture(scope="session")
def swh_scheduler_celery_worker(swh_scheduler_celery_worker, django_db_setup):
    """Override swh_scheduler_celery_worker to allow django db access."""
    return swh_scheduler_celery_worker


@pytest.fixture
def run_tasks(
    swh_scheduler, swh_scheduler_celery_app, swh_scheduler_celery_worker, cn_task_types
):
    """A fixture to make celery run tasks during the tests and wait a bit.

    Tests using this fixture **must** be marked with `django_db(transaction=True)`.
    """

    def _run_tasks(max_retries=5):
        manager = Manager(swh_scheduler_celery_app)
        expected_total = {"celery.ping": 1}

        for task_type in cn_task_types:
            tasks = swh_scheduler.search_tasks(task_type=task_type.type)
            if tasks:
                expected_total[task_type.backend_name] = len(tasks)

        attempts = 0
        run_ready_tasks(swh_scheduler, swh_scheduler_celery_app, cn_task_types)
        while next(iter(manager.inspect().stats().values()))["total"] != expected_total:
            attempts += 1
            if attempts >= max_retries:
                swh_scheduler_celery_app.log.get_default_logger().error(
                    "Task results %s were not found after %d attempt(s)",
                    expected_total,
                    attempts,
                )
                break
            pass

    yield _run_tasks
