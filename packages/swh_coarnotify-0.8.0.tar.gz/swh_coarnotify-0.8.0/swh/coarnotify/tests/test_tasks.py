# Copyright (C) 2025  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU General Public License version 3, or any later version
# See top-level LICENSE file for more information
from django.core.exceptions import ObjectDoesNotExist
import pytest


@pytest.mark.parametrize(
    "task_name",
    [
        "swh.coarnotify.tasks.ProcessInboundNotificationTask",
        "swh.coarnotify.tasks.SendOutboundNotificationTask",
    ],
)
def test_task_exists(
    swh_scheduler_celery_app, swh_scheduler_celery_worker, db, task_name
):
    res = swh_scheduler_celery_app.send_task(task_name, args=[123])
    assert res
    with pytest.raises(ObjectDoesNotExist):
        res.wait()
    assert res.failed()
