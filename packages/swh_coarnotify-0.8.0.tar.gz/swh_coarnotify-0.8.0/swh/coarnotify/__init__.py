# Copyright (C) 2025  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU Affero General Public License version 3, or any later version
# See top-level LICENSE file for more information

from __future__ import annotations

from typing import Any


def register_tasks() -> dict[str, Any]:
    return {
        "task_modules": [f"{__name__}.tasks"],
    }
