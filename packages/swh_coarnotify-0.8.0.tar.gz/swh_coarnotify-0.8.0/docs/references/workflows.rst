Workflows
=========

.. admonition:: Work in progress
   :class: note

   swh-coarnotify is a new project, some parts of its documentation have not been
   written yet.


General workflow for sending and replying to a Notification
-----------------------------------------------------------

.. mermaid::

   sequenceDiagram
      autonumber
      participant Partner as Partner
      participant Inbox as SWH Inbox
      participant DB as Database
      participant Scheduler as Scheduler
      participant Worker as Worker
      participant REMD as Raw Extrinsic<br> Metadata Storage

      Partner->>Inbox: Send a Notification 123

      Inbox->>Inbox: Validate (auth, format, etc.)
      alt invalid notification / auth
         Inbox->>Partner: Reply with a HTTP 4xx code
      else notification is valid
         Inbox->>DB: Store the inbound<br> notification 123
         Inbox->>Scheduler: Create a coarnotify-process-inbound<br>task for 123
         Inbox->>Partner: Reply with a HTTP 201 code
      end

      Worker-->Scheduler: picks up cn-process-inbound<br>task for 123
      Worker->>Worker: Process the notification 123
      alt origin URL or SWHID is unknown
         Worker->>DB: Create a Reject outbound notification 456
      else origin is archived
         Worker->>REMD: Store the raw notification 123
         Worker->>DB: Create a Accept outbound notification 456
      end
      Worker->>DB: Update notification 123 status
      Worker->>Scheduler: Creates a coarnotify-send-outbound<br>task for 456
      Worker-->>Scheduler: picks up coarnotify-send-outbound<br>task for 456
      Worker->>Partner: Send notification 456
      Worker->>DB: Updates notification 456 status

The Inbox always replies with an `HTTP 201` if the Notification is structurally valid.
Then a background task is created to process the content of the Notification.

If the software mentioned in the Notification is in the archive we store the whole
raw Notification in the Raw Extrinsic Metadata Storage so it can be later processed
by the Indexer.