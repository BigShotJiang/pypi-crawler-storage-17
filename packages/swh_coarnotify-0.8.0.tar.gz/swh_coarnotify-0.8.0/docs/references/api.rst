Rest API
========

HEAD /
------

Returns a ``HTTP 200`` response with a ``Link`` header containing the URL of the Inbox.

GET /
-----

An unauthenticated call to this endpoint will return the Inbox home page in HTML. But
with a ``Authorization: Token xxx`` header it will return the current user inbox with
all the Notification that were accepted by the server in a json-ld format.

.. code-block:: json

   {
      "@context": "http://www.w3.org/ns/ldp",
      "@id": "https://inbox.swh",
      "contains": [
            "https://inbox.swh/<uuid>",
            "https://inbox.swh/<uuid>",
            "https://inbox.swh/<uuid>",
      ],
   }

GET /<uuid>
-----------

Requires an authentication token. Will return the Notification <uuid> if it was sent by
the current user and a ``HTTP 403`` otherwise.

.. code-block:: json

   {
      "@context": [
         "https://www.w3.org/ns/activitystreams",
         "https://coar-notify.net"
      ],
      "id": "urn:uuid:<uuid>",
      "...": "..."
   }

POST /
------

Requires an authentication token. Submit a Notification to the Inbox.
See :doc:`../references/payloads` for a reference of the payload content or
:doc:`../howto/mention` for an how-to guide.