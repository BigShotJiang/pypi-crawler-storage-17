Access the inbox
================

.. admonition:: Work in progress
   :class: note

   swh-coarnotify is a new project, some parts of its documentation have not been
   written yet.

An account and an authorization token is required to access the Inbox.

To create an account use the admin interface available on `/admin`.

First create an Organization for your user, it's important to have its `inbox_url`
matching a real COAR Notification inbox to validate the notification and send replies.

Then create a user attached to this Organization.

A django signal automatically creates an access token for each new user, take note of
it somewhere as you will need it to authentication your API calls.