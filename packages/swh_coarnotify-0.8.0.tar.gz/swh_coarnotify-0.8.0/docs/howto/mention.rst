Send a mention of a software in a scientific paper
==================================================

.. admonition:: Work in progress
   :class: note

   swh-coarnotify is a new project, some parts of its documentation have not been
   written yet.