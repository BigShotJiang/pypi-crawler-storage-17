How-to guides
=============

Learn how to use COAR Notify to exchange with Software Heritage.

.. toctree::
   :maxdepth: 1

   install.rst
   access.rst
   mention.rst