Welcome to tabmat!
==========================================

Please see the `project README <https://github.com/Quantco/tabmat>`_ for a broad overview of what ``tabmat`` is.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   Benchmarks <benchmarks>
   API Reference <api>
   Changelog <changelog>

:ref:`genindex`
