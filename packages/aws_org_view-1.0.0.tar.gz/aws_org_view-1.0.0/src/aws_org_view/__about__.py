# SPDX-FileCopyrightText: 2025-present Neil Smith <neil@nsmith.net>
#
# SPDX-License-Identifier: MIT
__version__ = "1.0.0"
