"""Test fixtures for common subsystem tests."""
