conops.solar_panel
==================

.. automodule:: conops.solar_panel
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
