conops.ditl.ditl\_mixin
=========================

.. automodule:: conops.ditl.ditl_mixin
   :members: DITLMixin
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
   :no-index:
