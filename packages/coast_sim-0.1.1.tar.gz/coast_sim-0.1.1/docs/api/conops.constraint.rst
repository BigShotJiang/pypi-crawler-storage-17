conops.constraint
=================

.. automodule:: conops.constraint
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
