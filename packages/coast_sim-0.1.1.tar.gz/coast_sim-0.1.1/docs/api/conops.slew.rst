conops.slew
===========

.. automodule:: conops.slew
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
