conops.simulation.roll
======================

.. automodule:: conops.simulation.roll
   :members: optimum_roll, optimum_roll_sidemount
   :undoc-members:
   :show-inheritance:
   :no-index:
