conops.constants
================

.. automodule:: conops.constants
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
