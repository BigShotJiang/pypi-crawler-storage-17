conops.battery
==============

.. automodule:: conops.battery
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
