conops.config.observation\_categories
=====================================

.. automodule:: conops.config.observation_categories
   :members: ObservationCategories, ObservationCategory
   :undoc-members:
   :show-inheritance:
   :no-index:
