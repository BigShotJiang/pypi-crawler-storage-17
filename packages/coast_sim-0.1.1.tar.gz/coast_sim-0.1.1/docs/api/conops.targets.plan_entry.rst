conops.targets.plan\_entry
==========================

.. automodule:: conops.targets.plan_entry
   :members: PlanEntry
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
   :no-index:
