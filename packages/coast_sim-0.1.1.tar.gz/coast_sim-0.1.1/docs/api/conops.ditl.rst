conops.ditl
===========

.. automodule:: conops.ditl
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
