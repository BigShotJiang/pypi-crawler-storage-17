conops.schedulers.scheduler
============================

.. automodule:: conops.schedulers.scheduler
   :members: DumbScheduler
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
   :no-index:
