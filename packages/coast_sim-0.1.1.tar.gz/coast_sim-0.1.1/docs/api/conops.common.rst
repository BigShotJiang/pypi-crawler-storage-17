conops.common
=============

.. automodule:: conops.common
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
