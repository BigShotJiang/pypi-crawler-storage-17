conops.ditl.ditl\_log\_store
==========================

DITLLogStore is implemented as a Pydantic model for simple validation and
ergonomic construction. The SQLite connection is held as a private attribute
and excluded from serialization.

.. automodule:: conops.ditl.ditl_log_store
   :members: DITLLogStore
   :undoc-members:
   :show-inheritance:
   :no-index:
