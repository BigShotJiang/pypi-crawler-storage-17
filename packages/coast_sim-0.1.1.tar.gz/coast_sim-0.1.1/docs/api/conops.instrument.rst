conops.instrument
=================

.. automodule:: conops.config.instrument
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__

DataGeneration
--------------

.. autoclass:: conops.config.instrument.DataGeneration
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__

Instrument
----------

.. autoclass:: conops.config.instrument.Instrument
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__

Payload
-------

.. autoclass:: conops.config.instrument.Payload
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
