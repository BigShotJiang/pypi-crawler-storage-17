conops.targets.pointing
========================

.. automodule:: conops.targets.pointing
   :members: Pointing
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
   :no-index:
