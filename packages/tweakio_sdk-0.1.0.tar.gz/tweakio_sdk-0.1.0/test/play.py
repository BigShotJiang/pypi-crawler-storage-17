import time
print()
print(str(time.time()))