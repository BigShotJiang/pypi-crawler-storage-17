"""Configuration utilities."""

from .app_dir import get_app_dir

__all__ = [
    "get_app_dir",
]
