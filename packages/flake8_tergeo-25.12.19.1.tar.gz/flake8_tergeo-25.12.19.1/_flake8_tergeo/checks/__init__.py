"""Implementation of checks provided by flake8-tergeo."""

from __future__ import annotations
