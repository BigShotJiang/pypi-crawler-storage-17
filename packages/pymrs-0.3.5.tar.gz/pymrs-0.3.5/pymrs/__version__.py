__title__ = "pymrs"
__description__ = "Python SDK for Memoza Rest Server."
__version__ = "0.3.5"
