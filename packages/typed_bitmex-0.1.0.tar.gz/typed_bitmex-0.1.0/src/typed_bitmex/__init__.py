"""
### Typed Bitmex
> A fully typed, validated async client for the Bitmex API

- Details
"""