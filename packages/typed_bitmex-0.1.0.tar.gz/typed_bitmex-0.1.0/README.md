# Typed Bitmex

> A fully typed, validated async client for the Bitmex API

Use *autocomplete* instead of documentation.

🚧 Under construction.