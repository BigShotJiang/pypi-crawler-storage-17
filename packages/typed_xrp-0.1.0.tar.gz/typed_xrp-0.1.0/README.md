# Typed Xrp

> A fully typed, validated async client for the Xrp API

Use *autocomplete* instead of documentation.

🚧 Under construction.