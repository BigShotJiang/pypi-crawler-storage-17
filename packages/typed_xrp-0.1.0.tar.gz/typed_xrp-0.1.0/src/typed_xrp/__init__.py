"""
### Typed Xrp
> A fully typed, validated async client for the Xrp API

- Details
"""