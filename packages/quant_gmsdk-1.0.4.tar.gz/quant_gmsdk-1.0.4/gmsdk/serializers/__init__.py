"""
Serialization utilities.
"""

# This module is currently empty as we use direct pickle/json serialization
# in the main SDK functions.

__all__ = []