# framcore/juliamodels/__init__.py

from framcore.juliamodels.JuliaModel import JuliaModel

__all__ = [
    "JuliaModel",
]
