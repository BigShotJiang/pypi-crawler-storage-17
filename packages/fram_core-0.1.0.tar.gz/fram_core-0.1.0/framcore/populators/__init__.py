# framcore/populators/__init__.py

from framcore.populators.Populator import Populator

__all__ = [
    "Populator",
]
