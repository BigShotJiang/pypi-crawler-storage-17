'''No need for a docstring i think.'''
from .core import Vulcan