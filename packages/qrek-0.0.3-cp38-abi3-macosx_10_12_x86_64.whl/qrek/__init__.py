from .qrek import *

__doc__ = qrek.__doc__
if hasattr(qrek, "__all__"):
    __all__ = qrek.__all__