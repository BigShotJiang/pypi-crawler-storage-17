"""TUI application for campers."""

from campers.tui.app import CampersTUI

__all__ = ["CampersTUI"]
