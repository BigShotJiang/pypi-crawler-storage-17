"""Examples package for skelarm."""
