"""Tests for Network MCP Server."""
