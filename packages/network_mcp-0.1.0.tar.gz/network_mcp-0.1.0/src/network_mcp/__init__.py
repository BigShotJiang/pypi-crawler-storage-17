"""Network MCP Server - Connectivity testing and pcap analysis for AI agents."""

__version__ = "0.1.0"
