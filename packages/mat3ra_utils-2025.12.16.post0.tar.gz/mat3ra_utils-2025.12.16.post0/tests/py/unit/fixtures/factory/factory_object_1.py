class FactoryObject1(object):
    """
    Factory Object1 class.
    """

    pass
