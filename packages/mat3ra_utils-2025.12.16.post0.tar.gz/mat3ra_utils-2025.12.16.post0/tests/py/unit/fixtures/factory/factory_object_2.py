class FactoryObject2(object):
    """
    Factory Object1 class.
    """

    pass
