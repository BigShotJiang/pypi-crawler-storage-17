# Pyarmor 8.5.12 (trial), 000000, 2025-12-17T21:18:32.222564
from .pyarmor_runtime import __pyarmor__
