TOKEN_SCOPE_AUTHORIZED_UPLOAD = 'authorized_upload'
