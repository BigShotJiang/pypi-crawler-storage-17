/*
 * SPDX-FileCopyrightText: 2025 Eaton Corporation
 *
 * SPDX-License-Identifier: MIT
 */
#include<stdio.h>

int main(void)
{
    printf("Hello world!");
    return 0;
}
