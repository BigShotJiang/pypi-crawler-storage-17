from emailify.models import Style

IMAGE_STYLE = Style(
    align="left",
    padding="0px 10px",
)
