# ThingsBoard Common

> Note: 
> 
> This is not an official project of the [
ThingsBoard](https://thingsboard.io/) authors! Please refer to [ThingsBoard - Open-source IoT Platform](https://github.com/thingsboard) for official ThingsBoard projects!

This project serves as a toolkit allowing other projects to use the same packages/modules as codebase.

These projects are using the [ThingsBoard](https://thingsboard.io/) platform and extend it with additional functionality.
