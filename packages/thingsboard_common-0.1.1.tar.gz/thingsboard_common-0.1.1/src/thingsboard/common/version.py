#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'Thomas Sterren'
__contributors__ = []
__version__ = '0.1.1'


def main():
    print(__version__)


if __name__ == '__main__':
    main()

