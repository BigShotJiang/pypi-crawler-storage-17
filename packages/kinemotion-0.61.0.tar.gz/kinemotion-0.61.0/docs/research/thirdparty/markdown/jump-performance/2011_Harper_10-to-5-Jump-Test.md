## Harper, Damian, Hobbs, Sarah and Moore, Jason (2011) Harper, D.J., Hobbs, S.J. & Moore, J. (2011). The ten to five repeated jump test: A new test for evaluation of lower body reactive strength. BASES 2011 Annual Student Conference. Integrations and Innovations: An Interdisciplinary Approach to Sport and Exercise Science. 2011 April 12-13; Chester, United Kingdom. Chester,: The University of Chester; 2011. In: BASES Student Conference 2011, 12-13 April, University of Chester. (Unpublished)

### Downloaded from: <https://ray.yorksj.ac.uk/id/eprint/2664/>

Research at York St John (RaY) is an institutional repository. It supports the principles of

open access by making the research outputs of the University available in digital form.

Copyright of the items stored in RaY reside with the authors and/or other copyright

owners. Users may access full text items free of charge, and may download a copy for

private study or non-commercial research. For further reuse terms, see licence terms

[governing individual outputs. Institutional Repository Policy Statement](https://www.yorksj.ac.uk/ils/repository-policies/)

# RaY

## Research at the University of York St John

[For more information please contact RaY at ray@yorksj.ac.uk](mailto:ray@yorksj.ac.uk)
