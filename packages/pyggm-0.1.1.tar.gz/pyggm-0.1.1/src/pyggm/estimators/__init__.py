"""Estimators for Gaussian Graphical Models."""

from .ggm import GaussianGraphicalModel

__all__ = ["GaussianGraphicalModel"]
