"""Langflow CLI - A command-line tool for managing Langflow environments and resources."""

__version__ = "0.1.0"

