# this file is @generated

from .common import BaseModel


class AppPortalAccessOut(BaseModel):
    token: str

    url: str
