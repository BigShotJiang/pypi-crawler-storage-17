# this file is @generated

from .common import BaseModel


class VeriffConfig(BaseModel):
    secret: str
