# this file is @generated
import typing as t

from .common import BaseModel


class OtelTracingPatchConfig(BaseModel):
    url: t.Optional[str] = None
