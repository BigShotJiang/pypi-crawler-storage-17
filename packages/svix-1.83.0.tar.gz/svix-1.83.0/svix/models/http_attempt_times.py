# this file is @generated
from datetime import datetime

from .common import BaseModel


class HttpAttemptTimes(BaseModel):
    end: datetime

    start: datetime
