# this file is @generated

from .common import BaseModel
from .event_type_import_open_api_out_data import EventTypeImportOpenApiOutData


class EventTypeImportOpenApiOut(BaseModel):
    data: EventTypeImportOpenApiOutData
