# this file is @generated

from .common import BaseModel


class TelnyxConfig(BaseModel):
    public_key: str
