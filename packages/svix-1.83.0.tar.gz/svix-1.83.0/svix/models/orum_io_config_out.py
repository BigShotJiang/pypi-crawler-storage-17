# this file is @generated

from .common import BaseModel


class OrumIoConfigOut(BaseModel):
    public_key: str
