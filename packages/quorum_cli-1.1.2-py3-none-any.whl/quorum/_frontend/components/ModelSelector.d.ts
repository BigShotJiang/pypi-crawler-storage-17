/**
 * Model selection component.
 */
interface ModelSelectorProps {
    onSelect: () => void;
}
export declare function ModelSelector({ onSelect }: ModelSelectorProps): import("react/jsx-runtime").JSX.Element;
export {};
