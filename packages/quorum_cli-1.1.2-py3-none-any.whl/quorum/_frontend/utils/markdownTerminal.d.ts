/**
 * Terminal markdown renderer using ink components.
 */
import React from "react";
interface MarkdownProps {
    children: string;
}
export declare function Markdown({ children }: MarkdownProps): React.ReactElement;
export {};
