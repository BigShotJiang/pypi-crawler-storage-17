/**
 * Delphi method JSON export schema
 * 3-4 phases: Round 1 -> Round 2 -> Round 3 (optional) -> Aggregation
 */
export {};
