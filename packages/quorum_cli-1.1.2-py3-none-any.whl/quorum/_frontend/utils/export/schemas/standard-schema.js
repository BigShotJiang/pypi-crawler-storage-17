/**
 * Standard method JSON export schema
 * 5 phases: Independent Answers -> Critique -> Discussion -> Final Positions -> Synthesis
 */
export {};
