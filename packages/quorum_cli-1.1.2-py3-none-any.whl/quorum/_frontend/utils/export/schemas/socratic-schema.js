/**
 * Socratic method JSON export schema
 * 3 phases: Initial Thesis -> Socratic Inquiry -> Aporia & Insights
 */
export {};
