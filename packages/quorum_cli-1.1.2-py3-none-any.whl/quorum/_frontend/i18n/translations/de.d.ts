/**
 * German translations.
 */
import type { Translations } from "../types.js";
export declare const de: Translations;
