/**
 * Spanish translations.
 */
import type { Translations } from "../types.js";
export declare const es: Translations;
