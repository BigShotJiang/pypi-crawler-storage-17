"""Quorum - Multi-agent consensus system using AutoGen."""

from .constants import __version__

__all__ = ["__version__"]
