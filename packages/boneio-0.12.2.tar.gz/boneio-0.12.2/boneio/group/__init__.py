"""Group classes."""
from .output import OutputGroup

__all__ = ["OutputGroup"]
