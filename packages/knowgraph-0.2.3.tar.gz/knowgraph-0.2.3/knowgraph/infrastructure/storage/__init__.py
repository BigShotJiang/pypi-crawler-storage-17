"""Storage infrastructure - File system operations and persistence."""
