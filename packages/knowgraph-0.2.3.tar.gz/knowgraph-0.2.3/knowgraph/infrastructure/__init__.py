"""Infrastructure layer - I/O operations and external services."""
