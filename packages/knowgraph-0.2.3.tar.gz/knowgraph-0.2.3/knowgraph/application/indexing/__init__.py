"""Indexing use cases - Repository indexing and graph construction."""
