"""Domain algorithms - Pure functions for graph analysis."""
