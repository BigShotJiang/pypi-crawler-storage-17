"""Domain layer - Core business logic with zero external dependencies."""
