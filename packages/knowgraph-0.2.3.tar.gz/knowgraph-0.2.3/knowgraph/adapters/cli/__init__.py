"""CLI adapters - Command-line interface implementation."""
