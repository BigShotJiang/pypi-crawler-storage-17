from flake8_multiline_equals.checker import MultilineNamedArgsCheckerPlugin

__all__ = ['MultilineNamedArgsCheckerPlugin', 'checker']
