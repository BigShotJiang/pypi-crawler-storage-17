from .classifier import RegularizedDiscriminantAnalysis

__all__ = ["RegularizedDiscriminantAnalysis"]
