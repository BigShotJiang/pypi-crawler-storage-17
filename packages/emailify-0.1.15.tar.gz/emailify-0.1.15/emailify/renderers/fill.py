from email.mime.application import MIMEApplication

from emailify.models import Fill
from emailify.renderers.core import _render_mjml_template
from emailify.renderers.style import render_mjml_obj_props


def render_fill(fill: Fill) -> tuple[str, list[MIMEApplication]]:
    body = _render_mjml_template(
        "fill",
        fill=fill,
        extra_props=render_mjml_obj_props("fill", fill.style),
    )
    return body, []
