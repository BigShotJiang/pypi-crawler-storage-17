let window = globalThis;
let self = globalThis;
let navigator = { userAgent: "quickjs" };
let document = {
    createElement: function () { return { style: {}, appendChild: function () { }, setAttribute: function () { }, innerHTML: "" }; },
    createTextNode: function (t) { return t; },
    getElementsByTagName: function () { return []; },
    querySelector: function () { return null; },
    body: { appendChild: function () { } }
};
if (typeof getComputedStyle === "undefined") { globalThis.getComputedStyle = function () { return {}; }; }
let module = { exports: {} };
let exports = module.exports;
let process = { env: { NODE_ENV: "production" } };
let define = undefined;


