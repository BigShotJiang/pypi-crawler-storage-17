from .evaluate import to_filter

__all__ = ["to_filter"]
