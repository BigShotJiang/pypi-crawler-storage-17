The following license applies to the entire contents of this directory (the "Contents"), which contains software for use with the Stretch mobile manipulators, which are robots produced and sold by Hello Robot Inc.

Copyright 2020-2024 Hello Robot Inc.
 
This software is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License v3.0 (GNU LGPLv3) as published by the Free Software Foundation.

This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License v3.0 (GNU LGPLv3) for more details, which can be found via the following link: 

https://www.gnu.org/licenses/lgpl-3.0.en.html

For further information about the Contents including inquiries about dual licensing, please contact Hello Robot Inc.
