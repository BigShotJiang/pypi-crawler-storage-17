#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author : aidenmo
# @Email : aidenmo@tencent.com
# @Time : 2025/11/19 12:05
from openai import OpenAI

client = OpenAI(
    api_key="EMPTY",
    base_url="http://21.91.23.205:8000/v1",
    timeout=3600
)

# Task-specific base prompts
TASKS = {
    "ocr": "OCR:",
    "table": "Table Recognition:",
    "formula": "Formula Recognition:",
    "chart": "Chart Recognition:",
}

messages = [
    {
        "role": "user",
        "content": [
            {
                "type": "image_url",
                "image_url": {
                    "url": "https://tme-dev-test-cos-1257943044.cos-internal.ap-guangzhou.tencentcos.cn/page-shot/image/da2ce0563235c1337a22abb54ea56f4d.png"
                }
            },
            {
                "type": "text",
                "text": TASKS["table"]
            }
        ]
    }
]

response = client.chat.completions.create(
    model="PaddlePaddle/PaddleOCR-VL",
    messages=messages,
    temperature=0.0,
)
print(f"{response.choices[0].message.content}")