from django.apps import AppConfig


class ObjectsAPIClientConfig(AppConfig):
    name = "objectsapiclient"
    default_auto_field = "django.db.models.AutoField"
