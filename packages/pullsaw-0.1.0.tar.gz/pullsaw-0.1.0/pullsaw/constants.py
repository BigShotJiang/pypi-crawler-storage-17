"""Shared constants for PullSaw."""

# Directory name for pullsaw working files
PULLSAW_DIR = ".pullsaw"
