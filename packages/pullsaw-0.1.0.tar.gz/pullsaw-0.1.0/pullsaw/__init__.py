"""PullSaw - Split large PRs into stacked PRs using Claude Code."""

__version__ = "0.1.0"
