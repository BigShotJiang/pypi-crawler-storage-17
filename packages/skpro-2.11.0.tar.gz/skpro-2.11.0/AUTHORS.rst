==========
Developers
==========

**skpro** is developed by the sktime community.

We follow the all-contributors specification for giving credit.
Contributions of any kind are welcome!

For a list of contributors, see the file
`all-contributorsrc <https://github.com/sktime/skpro/blob/main/.all-contributorsrc>`_.
