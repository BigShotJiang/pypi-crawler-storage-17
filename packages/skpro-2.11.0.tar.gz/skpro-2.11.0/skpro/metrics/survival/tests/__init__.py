"""Tests for metrics for time-to-event or survival prediction."""
# copyright: skpro developers, BSD-3-Clause License (see LICENSE file)
