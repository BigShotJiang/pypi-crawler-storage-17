"""Tests for probabilistic metrics."""
