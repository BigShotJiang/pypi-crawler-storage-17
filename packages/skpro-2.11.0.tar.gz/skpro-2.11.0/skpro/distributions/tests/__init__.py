"""Tests for skpro probability distribution objects."""
