"""Tests for adapters for probability distribution objects, scipy facing."""
# copyright: skpro developers, BSD-3-Clause License (see LICENSE file)
