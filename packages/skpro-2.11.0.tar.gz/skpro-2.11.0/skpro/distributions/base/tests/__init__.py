"""Tests for skpro distribution base class."""
