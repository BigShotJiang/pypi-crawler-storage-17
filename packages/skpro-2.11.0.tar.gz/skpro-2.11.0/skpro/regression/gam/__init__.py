"""GAM regressor using pyGAM."""
# copyright: skpro developers, BSD-3-Clause License (see LICENSE file)

from skpro.regression.gam._gam import GAMRegressor

__all__ = ["GAMRegressor"]
