"""Tests for the show_versions utility."""
