"""Tests for data types module."""
