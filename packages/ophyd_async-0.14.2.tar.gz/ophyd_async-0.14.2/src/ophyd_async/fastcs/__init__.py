"""FastCS support for Signals via EPICS or Tango, and Devices that use them."""
