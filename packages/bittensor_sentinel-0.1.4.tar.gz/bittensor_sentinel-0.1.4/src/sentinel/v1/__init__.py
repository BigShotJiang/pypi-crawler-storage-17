"""
Public interface of the sentinel package.
"""
