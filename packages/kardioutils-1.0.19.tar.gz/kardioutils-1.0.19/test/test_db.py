import asyncio
import numpy as np
import pytest
from dl2050utils.core import is_numeric_str, check_float, check_int, check_str, check
from dl2050utils.core import listify, oget, xre, LRUCache

# ##########################################################################################
# Test is_numeric_str
# ##########################################################################################




if __name__ == "__main__":
    pytest.main()