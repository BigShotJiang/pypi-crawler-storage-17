# bec_testing_plugin

This is a plugin repository for BEC, created with the [BEC plugin copier template](https://gitea.psi.ch/bec/bec_plugin_copier_template).
It is intended to host a variety of example plugin features which can be used to develop features in the other BEC
packages, perform integration testing against, and test out plugin template upgrades.
