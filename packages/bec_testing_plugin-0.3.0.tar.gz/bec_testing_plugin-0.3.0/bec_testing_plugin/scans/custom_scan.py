from bec_server.scan_server.scans import LineScan


class CustomTestingScan(LineScan):
    scan_name = "custom_testing_scan"
