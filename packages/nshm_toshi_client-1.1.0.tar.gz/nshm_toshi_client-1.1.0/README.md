# nshm-toshi-client

[![pypi](https://img.shields.io/pypi/v/nshm-toshi-client.svg)](https://pypi.org/project/nshm-toshi-client/)
[![python](https://img.shields.io/pypi/pyversions/nshm-toshi-client.svg)](https://pypi.org/project/nshm-toshi-client/)
[![Build Status](https://github.com/gns-science/nshm-toshi-client/actions/workflows/dev.yml/badge.svg)](https://github.com/gns-science/nshm-toshi-client/actions/workflows/dev.yml)
[![codecov](https://codecov.io/gh/gns-science/nshm-toshi-client/branch/main/graphs/badge.svg)](https://codecov.io/github/gns-science/nshm-toshi-client)

A python3 client for the nshm-toshi-api.

* Documentation: <https://gns-science.github.io/nshm-toshi-client>
* GitHub: <https://github.com/gns-science/nshm-toshi-client>
* PyPI: <https://pypi.org/project/nshm-toshi-client/>
* Free software: MIT


