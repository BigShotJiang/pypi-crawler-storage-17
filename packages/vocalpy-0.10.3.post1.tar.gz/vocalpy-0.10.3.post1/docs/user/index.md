(user-guide)=
# User guide

This user guide provides more in-depth tutorials, 
as well as how-to's that walk you through achieving specific tasks.
This guide also provides in-depth information on the
concepts of VocalPy, with useful background information and explanation. 

```{toctree}
:maxdepth: 1

howto/index
background
```
