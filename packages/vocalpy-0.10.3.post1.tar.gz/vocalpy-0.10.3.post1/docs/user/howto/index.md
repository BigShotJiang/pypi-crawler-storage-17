!(how-tos)
# How-Tos

```{toctree}
:maxdepth: 1

segmentation-ir-metrics
use-vocalpy-with-scikit-learn
use-vocalpy-with-UMAP-and-HDBSCAN
```

