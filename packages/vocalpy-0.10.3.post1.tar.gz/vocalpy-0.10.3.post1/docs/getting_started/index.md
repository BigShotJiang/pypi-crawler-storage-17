# Getting started

This guide gets you started with VocalPy as quickly as possible. 

```{toctree}
:maxdepth: 1

installation
quickstart
```
