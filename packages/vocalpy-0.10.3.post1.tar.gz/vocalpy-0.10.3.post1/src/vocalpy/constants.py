"""Constants used throughout :mod:`vocalpy`."""

SPECT_FILE_EXT = ".spect.npz"
