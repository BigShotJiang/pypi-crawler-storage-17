"""Metrics for methods and models in acoustic communication."""

from . import segmentation

__all__ = [
    "segmentation",
]
