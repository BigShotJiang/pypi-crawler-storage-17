# Silero VAD

Silero Voice Activity Detection (VAD) plugin.

## Configuration

```json
{
    "listener": {
        "VAD": {
            "module": "ovos-vad-plugin-silero",
            "ovos-vad-plugin-silero": {
                "model": "/optional/path/to/model.onnx"
            }
        }
    }
}
```
