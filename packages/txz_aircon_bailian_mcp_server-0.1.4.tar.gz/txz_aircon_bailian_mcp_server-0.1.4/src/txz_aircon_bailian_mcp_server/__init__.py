from .tool_server import run
def main() -> None:
    run()