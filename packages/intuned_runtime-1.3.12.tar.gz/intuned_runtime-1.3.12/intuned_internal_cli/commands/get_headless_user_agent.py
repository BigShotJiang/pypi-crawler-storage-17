import sys

from intuned_internal_cli.utils.wrapper import internal_cli_command
from runtime.browser.launch_browser import get_browser_executable_path
from runtime.browser.launch_chromium import get_chromium_headless_user_agent
from runtime.env import get_browser_type


@internal_cli_command
async def get_headless_user_agent():
    from playwright.async_api import async_playwright

    browser_type = get_browser_type()

    if browser_type == "camoufox":
        print("Camoufox is not supported", sys.stderr)
        sys.exit(1)

    async with async_playwright() as playwright:
        print(
            await get_chromium_headless_user_agent(
                playwright=playwright,
                executable_path=await get_browser_executable_path(browser_type) if browser_type else None,
            )
        )
