import{_ as a,cU as s}from"./index-CrzlrGNr.js";const c=a(s,[["__scopeId","data-v-565bc716"]]);export{c as M};
