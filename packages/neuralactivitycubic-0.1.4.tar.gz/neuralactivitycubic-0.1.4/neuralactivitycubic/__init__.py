__version__ = "0.1.4"

from neuralactivitycubic.controller import open_gui
from neuralactivitycubic.api import run_analysis
from neuralactivitycubic.datamodels import Config
