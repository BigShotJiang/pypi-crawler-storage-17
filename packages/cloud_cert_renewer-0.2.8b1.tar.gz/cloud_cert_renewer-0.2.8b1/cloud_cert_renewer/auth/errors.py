class AuthError(ValueError):
    """Authentication/credential resolution error."""
