class ValidationException(Exception):
    """Exception raised for validation errors in tool definitions."""
