#!/usr/bin/env python
"""Main entry point for fr_env_resolver."""

from ._internal.cli.main import main

if __name__ == "__main__":
    main()
