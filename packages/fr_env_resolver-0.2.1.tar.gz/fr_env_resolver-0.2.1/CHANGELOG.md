# Changelog

## [0.2.1] - 2025-12-17

### Fixed

- Corrected GitHub repository URL from `Floating-Rock-Studio` to `FloatingRockStudio`

## [0.2.0] - 2025-12-16

- Initial public release
- Environment and tool resolution for rez-based pipelines
- Context path resolution with cascading configuration
- Manifest path resolution
- Tool descriptor support
- Workflow management
- Built on fr_config for cascading configuration
