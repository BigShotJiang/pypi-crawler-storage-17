"""
Alias for the pywrenfold.type_info module.
"""

from pywrenfold.type_info import *  # noqa: F403
