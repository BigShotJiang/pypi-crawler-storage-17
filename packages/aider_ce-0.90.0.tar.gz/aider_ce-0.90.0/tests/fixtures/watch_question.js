// Regular AI comment
//ai do 1 something
//AI make 2 this better
//ai! urgent 3 change needed
//AI! another 4 urgent one
// ai with 5 space
// with questions AI?

// this is not an ai comment
// aider is not an ai! comment

