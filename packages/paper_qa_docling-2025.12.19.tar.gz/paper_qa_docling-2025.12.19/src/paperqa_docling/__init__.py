"""Docling-backed readers for PaperQA."""

from .reader import parse_pdf_to_pages

__all__ = ["parse_pdf_to_pages"]
