from setuptools import setup, find_packages

# Importing contents of README.md for long description
with open("README.md", "r", encoding="utf-8") as fh:
  long_description = fh.read()

setup(
  name="ckx_jokes",
  version="0.3",
  packages=find_packages(),
  install_requires=[
    # Add dependencies here.
    "flask",
    "wheel",
    "pyjokes",
    "ascii-magic",
    "python-dotenv",
  ],
  entry_points={
    "console_scripts": [
      "jokes-server=ckx_jokes:server",
    ],
  },
  long_description=long_description,
  long_description_content_type="text/markdown",
  author="CryptoKingXavier",
  author_email="cryptokingxavier001@gmail.com"
)
