import noamath
print(noamath.remove(25, 3,4))