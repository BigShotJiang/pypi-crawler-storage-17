# Archived Documentation

Files in this directory are preserved for historical context but are not maintained.

If something here conflicts with active docs or CLI `--help` output, treat the CLI and the non-archived docs as the source of truth.

