from cumulusci.utils.deprecation import warn_moved

from .org_config import *  # noqa

warn_moved(".org_config", ".OrgConfig")
