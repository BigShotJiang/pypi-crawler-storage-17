from __future__ import annotations
from win32more._prelude import *
import win32more.Windows.Gaming.XboxLive
StorageApiContract: UInt32 = 65536


make_ready(__name__)
