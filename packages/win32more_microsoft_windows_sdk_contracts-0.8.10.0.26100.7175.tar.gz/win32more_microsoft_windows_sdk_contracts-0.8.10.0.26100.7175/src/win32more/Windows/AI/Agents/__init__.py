from __future__ import annotations
from win32more._prelude import *
import win32more.Windows.AI.Agents
AgentsContract: UInt32 = 131072


make_ready(__name__)
