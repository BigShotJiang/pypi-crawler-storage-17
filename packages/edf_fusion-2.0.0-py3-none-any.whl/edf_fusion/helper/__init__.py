"""Fusion Core Helper Module"""
