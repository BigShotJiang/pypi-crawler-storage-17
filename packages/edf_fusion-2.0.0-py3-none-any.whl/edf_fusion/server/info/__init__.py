"""Fusion Info API"""

from .config import FusionInfoAPIConfig
from .impl import FusionInfoAPI, get_fusion_info_api
