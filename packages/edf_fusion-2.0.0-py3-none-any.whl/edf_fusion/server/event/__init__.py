"""Fusion Event API"""

from .config import FusionEventAPIConfig
from .impl import FusionEventAPI, get_fusion_evt_api
