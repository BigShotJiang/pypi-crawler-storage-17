"""Fusion Constant API"""

from .config import FusionConstantAPIConfig
from .impl import FusionConstantAPI, get_fusion_const_api
