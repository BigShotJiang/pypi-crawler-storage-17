from .diffx_python import *

__doc__ = diffx_python.__doc__
if hasattr(diffx_python, "__all__"):
    __all__ = diffx_python.__all__