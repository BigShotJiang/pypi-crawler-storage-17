# laddu-mpi

This package provides the MPI backend for the `laddu` library.

It is not intended to be used directly. Please install `laddu[mpi]` instead.
