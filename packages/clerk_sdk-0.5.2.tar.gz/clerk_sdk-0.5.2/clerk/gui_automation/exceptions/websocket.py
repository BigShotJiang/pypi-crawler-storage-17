class WebSocketConnectionFailed(Exception):
    """
    Connection to websocket was not successful
    """

    pass
