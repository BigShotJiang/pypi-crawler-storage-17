Create a Python file named calc.py.

Inside it, define a function:

    def add(a, b):
        return a + b

The validator imports calc.py and calls add(2, 3).
