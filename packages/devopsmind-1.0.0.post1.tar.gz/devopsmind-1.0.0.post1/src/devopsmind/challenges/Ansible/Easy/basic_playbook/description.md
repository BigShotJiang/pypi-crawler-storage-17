Create a file named playbook.yml.

Requirements:
- It must define a single play.
- The play must have one task that uses the `debug` module.
- The task must print the message: Hello Ansible

This teaches basic YAML structure and playbook formatting.
