Task:
1. Create a directory named `project`.
2. Inside it create a file named `notes.txt`.
3. The file must contain exactly: DevOpsMind
