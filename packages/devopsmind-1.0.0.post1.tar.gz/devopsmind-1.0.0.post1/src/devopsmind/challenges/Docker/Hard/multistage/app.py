print("Hello from multi-stage Docker build")
