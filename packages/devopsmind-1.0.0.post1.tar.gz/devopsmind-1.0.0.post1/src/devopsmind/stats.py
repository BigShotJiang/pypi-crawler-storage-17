from .progress import load_state

def stats():
    return load_state()
