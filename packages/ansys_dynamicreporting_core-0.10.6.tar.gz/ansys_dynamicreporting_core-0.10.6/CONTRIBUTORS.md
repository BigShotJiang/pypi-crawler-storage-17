# Contributors

## Project Lead

* [Marina Galvagni](https://github.com/margalva)

## Individual Contributors

* [Cadey Chen](https://github.com/cadeyansys)
* [Dragan Colic](https://github.com/dcansys)
* [inimaz](https://github.com/inimaz)
* [James Derrick](https://github.com/jgd10)
* [JennaPaikowsky](https://github.com/JennaPaikowsky)
* [Kathy Pippert](https://github.com/PipKat)
* [Mario Ostieri](https://github.com/mariostieriansys)
* [Om Patel](https://github.com/ompat5)
* [Phillip Chen](https://github.com/phchen95)
* [Randy Frank](https://github.com/randallfrank)
* [Revathy Venugopal](https://github.com/Revathyvenugopal162)
* [Roberto Pastor Muela](https://github.com/RobPasMue)
* [Sébastien Morais](https://github.com/SMoraisAnsys)
* [Visesh Rajendraprasad](https://github.com/viseshrp)
* [Yuanrui Zhang](https://github.com/zhang-yuanrui)
