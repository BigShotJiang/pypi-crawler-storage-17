import build_info
import read_prop

if __name__ == "__main__":
    build_info.generate()
    read_prop.generate()
