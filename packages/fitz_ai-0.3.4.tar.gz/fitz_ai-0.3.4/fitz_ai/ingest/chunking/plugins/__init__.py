"""
Plugin namespace for chunker plugins.
Modules inside this package will be auto-discovered.
"""
