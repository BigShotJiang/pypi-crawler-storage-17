# pipeline/__init__.py

"""
fitz_ai.engines.classic_rag.pipeline

Retrieval-Augmented Generation (RAG) package.
"""

__all__ = []
