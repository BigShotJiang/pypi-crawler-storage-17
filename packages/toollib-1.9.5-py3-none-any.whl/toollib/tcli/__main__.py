"""
@author axiner
@version v1.0.0
@created 2022/2/27 11:20
@abstract
@description
@history
"""
from toollib.tcli.cmder import run


def main():
    run()


if __name__ == '__main__':
    main()
