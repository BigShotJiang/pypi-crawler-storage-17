"""See README.md for more information and examples."""

from cg_flake8_reporter import plugin

CustomFormatter = plugin.CustomFormatter
