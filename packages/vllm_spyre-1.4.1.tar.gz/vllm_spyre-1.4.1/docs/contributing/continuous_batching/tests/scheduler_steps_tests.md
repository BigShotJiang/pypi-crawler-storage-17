# Scheduler Steps Tests

!!! note
    Unless otherwise specified, all the continuous batching tests are running with `max_model_len=512`

::: tests.e2e.test_spyre_cb_scheduler_steps
