from ..common import BaseStruct


class ActArchiveNewsItemData(BaseStruct):
    newsId: str
    newsSortId: int
