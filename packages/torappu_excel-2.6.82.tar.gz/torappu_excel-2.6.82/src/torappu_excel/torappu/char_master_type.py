from enum import StrEnum


class CharMasterType(StrEnum):
    NONE = "NONE"
    SYSTEM = "SYSTEM"
    BATTLE = "BATTLE"
