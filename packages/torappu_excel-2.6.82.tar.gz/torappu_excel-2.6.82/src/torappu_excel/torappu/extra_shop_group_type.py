from enum import IntEnum


class ExtraShopGroupType(IntEnum):
    TEMP = 0
    PERM = 1
    MONTH = 2
    Enum = 3
