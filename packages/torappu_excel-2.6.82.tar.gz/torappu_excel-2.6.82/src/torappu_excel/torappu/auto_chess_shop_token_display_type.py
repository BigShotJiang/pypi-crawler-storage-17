from enum import StrEnum


class AutoChessShopTokenDisplayType(StrEnum):
    DEFAULT = "DEFAULT"
    HIDDEN = "HIDDEN"
