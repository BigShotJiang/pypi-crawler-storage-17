from enum import StrEnum


class ClimbTowerCardType(StrEnum):
    SEASON = "SEASON"
    TOWER = "TOWER"
