from ..common import BaseStruct


class ActivitySwitchCheckinConstData(BaseStruct):
    activityTime: str
    activityRule: str
