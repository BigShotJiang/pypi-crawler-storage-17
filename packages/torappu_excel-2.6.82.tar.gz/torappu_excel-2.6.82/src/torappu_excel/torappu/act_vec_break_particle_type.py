from enum import StrEnum


class ActVecBreakParticleType(StrEnum):
    NONE = "NONE"
    NORMAL = "NORMAL"
    HARD = "HARD"
