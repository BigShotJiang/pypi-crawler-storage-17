from ..common import BaseStruct


class Act4funLiveMatEffectInfo(BaseStruct):
    liveMatEffectId: str
    valueId: str
    performGroup: str
