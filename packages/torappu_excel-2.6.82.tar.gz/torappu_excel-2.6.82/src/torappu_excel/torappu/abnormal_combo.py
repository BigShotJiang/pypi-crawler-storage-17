from enum import StrEnum


class AbnormalCombo(StrEnum):
    SLEEPING = "SLEEPING"
    SHELTERING = "SHELTERING"
    E_NUM = "E_NUM"
