from ..common import BaseStruct


class ActMainSSZoneAdditionData(BaseStruct):
    unlockTip: str
    unlockTipAfterRetro: str
