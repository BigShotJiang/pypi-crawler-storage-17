from ..common import BaseStruct


class ActMultiV3TitleData(BaseStruct):
    order: int
    titleDesc: str
    isBack: bool
