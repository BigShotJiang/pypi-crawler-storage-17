from ..common import BaseStruct


class Act4funStageExtraData(BaseStruct):
    description: str
    valueIconId: str | None
