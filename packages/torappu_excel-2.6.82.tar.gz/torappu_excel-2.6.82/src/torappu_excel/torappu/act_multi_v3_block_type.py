from enum import StrEnum


class ActMultiV3BlockType(StrEnum):
    NONE = "NONE"
    START = "START"
    END = "END"
    MID = "MID"
