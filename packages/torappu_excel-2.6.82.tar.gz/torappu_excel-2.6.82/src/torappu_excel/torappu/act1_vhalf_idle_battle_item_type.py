from enum import StrEnum


class Act1VHalfIdleBattleItemType(StrEnum):
    EQUIP = "EQUIP"
    TRAP = "TRAP"
