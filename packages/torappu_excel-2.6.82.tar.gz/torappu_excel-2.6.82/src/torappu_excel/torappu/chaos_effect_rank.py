from ..common import CustomIntEnum


class ChaosEffectRank(CustomIntEnum):
    CHAOS_EFFECT_0 = "CHAOS_EFFECT_0", 0
    CHAOS_EFFECT_1 = "CHAOS_EFFECT_1", 1
    CHAOS_EFFECT_2 = "CHAOS_EFFECT_2", 2
