from enum import StrEnum


class ClimbTowerLevelType(StrEnum):
    NORMAL = "NORMAL"
    HIGHLEVEL = "HIGHLEVEL"
    BOSS = "BOSS"
