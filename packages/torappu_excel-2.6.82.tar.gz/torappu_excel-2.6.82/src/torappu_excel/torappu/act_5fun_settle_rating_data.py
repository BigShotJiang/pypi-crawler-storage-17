from ..common import BaseStruct


class Act5FunSettleRatingData(BaseStruct):
    minRating: int
    maxRating: int
    ratingDesc: str
