from enum import StrEnum


class CartCompetitionRank(StrEnum):
    NONE = "NONE"
    B = "B"
    A = "A"
    S = "S"
    SS = "SS"
