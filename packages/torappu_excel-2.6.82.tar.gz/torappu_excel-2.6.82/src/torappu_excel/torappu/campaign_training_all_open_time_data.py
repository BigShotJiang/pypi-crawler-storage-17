from ..common import BaseStruct


class CampaignTrainingAllOpenTimeData(BaseStruct):
    groupId: str
    startTs: int
    endTs: int
