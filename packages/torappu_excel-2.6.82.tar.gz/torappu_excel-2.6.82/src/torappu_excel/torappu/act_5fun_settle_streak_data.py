from ..common import BaseStruct


class Act5FunSettleStreakData(BaseStruct):
    count: int
    desc: str
