from ..common import BaseStruct


class AprilFoolConst(BaseStruct):
    battleFinishLoseDes: str
    killEnemyDes: str
    killBossDes: str
    totalTime: str
