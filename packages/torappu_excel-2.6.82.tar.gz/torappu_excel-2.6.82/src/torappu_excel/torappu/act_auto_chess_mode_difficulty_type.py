from enum import StrEnum


class ActAutoChessModeDifficultyType(StrEnum):
    NONE = "NONE"
    TRAINING = "TRAINING"
    FUNNY = "FUNNY"
    NORMAL = "NORMAL"
    HARD = "HARD"
