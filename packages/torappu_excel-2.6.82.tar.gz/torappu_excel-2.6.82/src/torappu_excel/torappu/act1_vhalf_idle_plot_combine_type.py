from enum import StrEnum


class Act1VHalfIdlePlotCombineType(StrEnum):
    NONE = "NONE"
    SINGLE = "SINGLE"
    PLUS = "PLUS"
    PLUS_OR = "PLUS_OR"
