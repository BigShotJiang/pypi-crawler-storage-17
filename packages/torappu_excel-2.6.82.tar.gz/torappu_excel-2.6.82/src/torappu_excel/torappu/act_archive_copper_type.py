from enum import StrEnum


class ActArchiveCopperType(StrEnum):
    LUCK = "LUCK"
    COPPER = "COPPER"
    GILD = "GILD"
