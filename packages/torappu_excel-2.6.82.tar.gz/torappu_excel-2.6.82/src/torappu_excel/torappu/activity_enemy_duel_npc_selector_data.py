from ..common import BaseStruct


class ActivityEnemyDuelNpcSelectorData(BaseStruct):
    enemyId: str
    score: float
