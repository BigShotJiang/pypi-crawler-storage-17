from ..common import BaseStruct


class CharSkinGroupInfo(BaseStruct):
    skinGroupId: str
    publishTime: int
