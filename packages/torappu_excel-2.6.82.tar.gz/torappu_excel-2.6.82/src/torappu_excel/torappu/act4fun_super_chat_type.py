from ..common import CustomIntEnum


class Act4funSuperChatType(CustomIntEnum):
    ROLLED = "ROLLED", 0
    RELATED = "RELATED", 1
