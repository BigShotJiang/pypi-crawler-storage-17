from enum import StrEnum


class AutoChessBondType(StrEnum):
    NONE = "NONE"
    REGULAR = "REGULAR"
    SEASON = "SEASON"
