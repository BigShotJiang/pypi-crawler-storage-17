from ..common import BaseStruct


class ActMultiV3ReportData(BaseStruct):
    id: str
    sortId: int
    txt: str
    desc: str
