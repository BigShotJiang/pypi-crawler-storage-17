from ..common import BaseStruct


class FavorCharacterInfo(BaseStruct):
    itemId: str
    charId: str
    favorAddAmt: int
