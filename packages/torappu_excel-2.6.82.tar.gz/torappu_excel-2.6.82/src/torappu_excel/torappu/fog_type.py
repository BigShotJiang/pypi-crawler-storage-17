from enum import StrEnum


class FogType(StrEnum):
    ZONE = "ZONE"
    STAGE = "STAGE"
