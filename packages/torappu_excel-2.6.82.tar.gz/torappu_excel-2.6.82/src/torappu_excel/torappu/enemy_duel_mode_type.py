from enum import StrEnum


class EnemyDuelModeType(StrEnum):
    OPERATION = "OPERATION"
    STAND = "STAND"
