from enum import StrEnum


class DiceResultShowType(StrEnum):
    RAW_TEXT = "RAW_TEXT"
    MUTATION = "MUTATION"
    VIRTUE = "VIRTUE"
