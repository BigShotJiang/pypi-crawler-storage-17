from ..common import BaseStruct


class ActArchiveChallengeBookItemData(BaseStruct):
    storyId: str
    sortId: int
