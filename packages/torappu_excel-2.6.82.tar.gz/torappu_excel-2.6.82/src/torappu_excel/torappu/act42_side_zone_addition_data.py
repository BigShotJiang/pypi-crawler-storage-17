from ..common import BaseStruct


class Act42SideZoneAdditionData(BaseStruct):
    zoneId: str
    unlockText: str
