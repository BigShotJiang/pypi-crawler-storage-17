from ..common import BaseStruct


class CrossDayTrackData(BaseStruct):
    updateEndTs: int
    id: str
