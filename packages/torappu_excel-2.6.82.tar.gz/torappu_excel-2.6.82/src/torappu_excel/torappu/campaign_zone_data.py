from ..common import BaseStruct


class CampaignZoneData(BaseStruct):
    id: str
    name: str
    regionId: str
    templateId: str
