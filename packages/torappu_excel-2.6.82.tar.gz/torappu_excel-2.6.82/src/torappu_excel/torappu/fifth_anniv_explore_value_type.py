from ..common import CustomIntEnum


class FifthAnnivExploreValueType(CustomIntEnum):
    TEAMVALUE_1 = "TEAMVALUE_1", 0
    TEAMVALUE_2 = "TEAMVALUE_2", 1
    TEAMVALUE_3 = "TEAMVALUE_3", 2
