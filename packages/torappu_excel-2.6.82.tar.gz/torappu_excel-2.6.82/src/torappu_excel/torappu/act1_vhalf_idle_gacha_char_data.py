from ..common import BaseStruct


class Act1VHalfIdleGachaCharData(BaseStruct):
    charId: str
    isLinkageChar: bool
