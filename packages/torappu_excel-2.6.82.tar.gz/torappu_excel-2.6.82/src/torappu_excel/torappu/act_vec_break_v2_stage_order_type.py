from enum import StrEnum


class ActVecBreakV2StageOrderType(StrEnum):
    NONE = "NONE"
    A = "A"
    B = "B"
    C = "C"
    D = "D"
