from .item_bundle import ItemBundle
from ..common import BaseStruct


class ActivityYear5GeneralUnlimitedApRewardData(BaseStruct):
    rewardIndex: int
    rewardItem: ItemBundle
