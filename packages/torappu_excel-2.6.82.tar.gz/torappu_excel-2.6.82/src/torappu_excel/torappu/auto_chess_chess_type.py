from enum import StrEnum


class AutoChessChessType(StrEnum):
    NORMAL = "NORMAL"
    DIY = "DIY"
    PRESET = "PRESET"
