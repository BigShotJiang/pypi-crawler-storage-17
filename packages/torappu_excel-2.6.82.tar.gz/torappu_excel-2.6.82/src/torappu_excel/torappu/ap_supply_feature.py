from ..common import BaseStruct


class ApSupplyFeature(BaseStruct):
    id: str
    ap: int
    hasTs: bool
