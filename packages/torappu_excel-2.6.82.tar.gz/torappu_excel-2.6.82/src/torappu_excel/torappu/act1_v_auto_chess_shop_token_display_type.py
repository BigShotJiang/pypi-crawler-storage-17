from ..common import CustomIntEnum


class Act1VAutoChessShopTokenDisplayType(CustomIntEnum):
    DEFAULT = "DEFAULT", 0
    HIDDEN = "HIDDEN", 1
