from enum import StrEnum


class EnemyLevelType(StrEnum):
    NORMAL = "NORMAL"
    ELITE = "ELITE"
    BOSS = "BOSS"
    E_NUM = "E_NUM"
