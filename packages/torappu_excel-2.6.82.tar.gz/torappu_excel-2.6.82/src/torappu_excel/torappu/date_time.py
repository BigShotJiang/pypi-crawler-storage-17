from ..common import BaseStruct


class DateTime(BaseStruct):
    pass
