from enum import StrEnum


class ActAutoChessModeType(StrEnum):
    NONE = "NONE"
    LOCAL = "LOCAL"
    SINGLE = "SINGLE"
    MULTI = "MULTI"
