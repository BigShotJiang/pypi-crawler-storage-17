from enum import StrEnum


class CommonUnlockType(StrEnum):
    STAGECLEAR = "STAGECLEAR"
    HASCHAR = "HASCHAR"
    NONE = "NONE"
