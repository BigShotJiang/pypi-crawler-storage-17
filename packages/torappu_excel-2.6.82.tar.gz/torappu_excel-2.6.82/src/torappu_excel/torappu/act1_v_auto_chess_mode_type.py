from ..common import CustomIntEnum


class Act1VAutoChessModeType(CustomIntEnum):
    TRAINING = "TRAINING", 0
    FUNNY = "FUNNY", 1
    NORMAL = "NORMAL", 2
