from ..common import BaseStruct


class FifthAnnivExploreBroadcastData(BaseStruct):
    id: str
    eventCount: int
    stageId: str
    content: str
