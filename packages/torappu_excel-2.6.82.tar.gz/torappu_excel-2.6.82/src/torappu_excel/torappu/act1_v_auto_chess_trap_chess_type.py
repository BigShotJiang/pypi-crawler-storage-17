from ..common import CustomIntEnum


class Act1VAutoChessTrapChessType(CustomIntEnum):
    NONE = "NONE", 0
    EQUIP = "EQUIP", 1
    MAGIC = "MAGIC", 2
