from ..common import BaseStruct


class ActArchiveAvgItemData(BaseStruct):
    avgId: str
    avgSortId: int
