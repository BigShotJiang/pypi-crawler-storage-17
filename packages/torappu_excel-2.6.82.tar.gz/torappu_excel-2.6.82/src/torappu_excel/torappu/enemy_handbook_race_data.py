from ..common import BaseStruct


class EnemyHandbookRaceData(BaseStruct):
    id: str
    raceName: str
    sortId: int
