from enum import StrEnum


class Act1VHalfIdleTechTreeNodeType(StrEnum):
    NONE = "NONE"
    NORMAL = "NORMAL"
    DIFFICULTY = "DIFFICULTY"
