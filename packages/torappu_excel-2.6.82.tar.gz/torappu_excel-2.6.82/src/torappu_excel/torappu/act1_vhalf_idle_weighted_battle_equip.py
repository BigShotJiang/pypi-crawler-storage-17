from ..common import BaseStruct


class Act1VHalfIdleWeightedBattleEquip(BaseStruct):
    weight: float
    equipId: str
    level: int
    alias: str
