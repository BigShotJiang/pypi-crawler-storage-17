from enum import StrEnum


class ActArchivePicType(StrEnum):
    IMAGE = "IMAGE"
    BACKGROUND = "BACKGROUND"
    ENDING_IMAGE = "ENDING_IMAGE"
    ROGUE_IMAGE = "ROGUE_IMAGE"
