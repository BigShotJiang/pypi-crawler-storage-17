from ..common import BaseStruct


class CampaignRegionData(BaseStruct):
    id: str
    isUnknwon: int
