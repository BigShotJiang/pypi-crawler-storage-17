from ..common import BaseStruct


class Act5FunEnemyIdMappingData(BaseStruct):
    enemyId: str
    originalEnemyId: str
