from ..common import BaseStruct


class CommonReportPlayerData(BaseStruct):
    id: str
    sortId: int
    txt: str
    desc: str
