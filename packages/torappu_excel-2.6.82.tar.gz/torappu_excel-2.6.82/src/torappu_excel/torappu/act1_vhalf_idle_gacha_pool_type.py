from enum import StrEnum


class Act1VHalfIdleGachaPoolType(StrEnum):
    NONE = "NONE"
    GACHA_NORMAL = "GACHA_NORMAL"
    GACHA_NEWPLAYER = "GACHA_NEWPLAYER"
    GACHA_PAC = "GACHA_PAC"
    GACHA_DIRECT = "GACHA_DIRECT"
