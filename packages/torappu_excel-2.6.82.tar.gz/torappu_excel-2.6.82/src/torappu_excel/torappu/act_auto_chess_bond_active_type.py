from enum import StrEnum


class ActAutoChessBondActiveType(StrEnum):
    BATTLE = "BATTLE"
    ALL = "ALL"
    MANI = "MANI"
