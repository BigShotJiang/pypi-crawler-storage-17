from ..common import BaseStruct


class ActVecBreakV2DefenseBasicData(BaseStruct):
    stageId: str
    groupId: str | None
    sortId: int
    startTs: int
