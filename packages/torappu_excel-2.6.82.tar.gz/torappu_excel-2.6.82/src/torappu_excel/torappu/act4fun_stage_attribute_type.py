from enum import StrEnum


class Act4funStageAttributeType(StrEnum):
    POS = "POS"
    NEG = "NEG"
