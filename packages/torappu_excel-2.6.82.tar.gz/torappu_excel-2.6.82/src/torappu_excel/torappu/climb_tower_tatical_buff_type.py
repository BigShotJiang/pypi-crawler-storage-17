from enum import StrEnum


class ClimbTowerTaticalBuffType(StrEnum):
    A = "A"
    B = "B"
