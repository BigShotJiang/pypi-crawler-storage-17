__version__ = "2.6.82"

client_version = "2.6.82"
data_version = "25-12-09-11-06-25_6d7e1b"
major_version = 410

from .constants import ExcelTableManager as ExcelTableManager  # noqa: E402
from .torappu.player_data_model import PlayerDataModel as PlayerDataModel  # noqa: E402
