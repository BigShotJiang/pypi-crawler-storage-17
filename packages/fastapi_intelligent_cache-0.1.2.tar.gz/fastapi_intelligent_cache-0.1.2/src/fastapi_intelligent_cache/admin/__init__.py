"""Admin routes for cache management."""
