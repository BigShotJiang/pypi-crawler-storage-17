# Trainviz
Trainviz is a python package for visualizing AI training in the browser


![Alt text](example.png)
