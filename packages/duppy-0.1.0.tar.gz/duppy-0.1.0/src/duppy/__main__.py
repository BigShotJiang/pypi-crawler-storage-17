#!/usr/bin/python3
' this is a wrapper for when you just download this code, rather than install it from pypi '
import duppy
duppy.main_wrapper()