from enum import Enum


class NsisTaskType(Enum):
    REG_NUMBER = "REG_NUMBER"
    VIN = "VIN"
