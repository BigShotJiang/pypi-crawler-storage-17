Darl

Darl is a lightweight code execution framework that transparently provides incremental computations, caching, scenario/shock analysis, parallel/distributed execution and more. The code you write closely resembles standard python code with some structural conventions added to automatically unlock these abilities.
