# Contributing

BeeWare <3's contributions!

Please be aware that BeeWare operates under a [Code of Conduct](https://beeware.org/community/behavior/code-of-conduct/).

If you experience problems with system-pyside6, [log them on GitHub](https://github.com/beeware/system-pyside6/issues).

If you'd like to contribute to the development if system-pyside6, [submit a pull request](https://github.com/beeware/system-pyside6/pulls).
