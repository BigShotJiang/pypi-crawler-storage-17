# Changelog

## 0.1.0 (16 Dec 2025)

Initial release.
