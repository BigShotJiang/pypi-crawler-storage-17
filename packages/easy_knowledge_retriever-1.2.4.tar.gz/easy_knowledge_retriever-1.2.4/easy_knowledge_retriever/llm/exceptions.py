class InvalidResponseError(Exception):
    """Custom exception class for triggering retry mechanism"""

    pass
