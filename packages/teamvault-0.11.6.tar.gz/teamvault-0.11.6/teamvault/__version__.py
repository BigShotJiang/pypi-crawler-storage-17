__version__ = "0.11.6"  # Also change in pyproject.toml
