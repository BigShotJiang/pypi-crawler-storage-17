from django.apps import AppConfig


class SecretsConfig(AppConfig):
    name = 'teamvault.apps.secrets'
