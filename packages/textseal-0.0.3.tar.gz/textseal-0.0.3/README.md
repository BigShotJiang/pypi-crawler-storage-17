# TextSeal

Posthoc watermarking for LLM generated text