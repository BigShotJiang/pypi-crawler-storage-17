Types
=====

.. automodule:: pymax.types
   :members:

.. automodule:: pymax.static.enum
   :members:
