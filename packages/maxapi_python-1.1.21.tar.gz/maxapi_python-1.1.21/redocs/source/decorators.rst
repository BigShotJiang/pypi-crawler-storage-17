Decorators
==========

.. autoclass:: pymax.mixins.handler.HandlerMixin
    :members:
    :undoc-members:
