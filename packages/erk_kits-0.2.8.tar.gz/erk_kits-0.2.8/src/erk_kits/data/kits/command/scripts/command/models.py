"""Data models for command execution."""


class CommandNotFoundError(Exception):
    """Raised when command file not found."""

    pass
