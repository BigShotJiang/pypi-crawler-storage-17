import ohmyscrapper.models.urls_manager as urls_manager


def untouch_all():
    urls_manager.untouch_all_urls()
    print("urls have been untouched")
    return
