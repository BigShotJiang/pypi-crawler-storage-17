"""
BugPilot CLI - AI-Powered Penetration Testing Tool
Developer: LAKSHMIKANTHAN K (letchupkt)
"""

__version__ = "1.0.0"
__author__ = "LAKSHMIKANTHAN K (letchupkt)"
__description__ = "AI-powered penetration testing and bug hunting CLI tool"
