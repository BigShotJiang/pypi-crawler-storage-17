from endstone_qqsync_plugin.qqsync_plugin import qqsync

__all__ = ["qqsync"]