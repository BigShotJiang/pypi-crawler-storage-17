"""Version information for djb.

This file is automatically updated by `djb publish`.
"""

__version__ = "0.2.31"
