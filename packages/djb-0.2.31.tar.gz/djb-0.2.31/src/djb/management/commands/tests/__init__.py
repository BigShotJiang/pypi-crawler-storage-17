"""
Test utilities for djb management command tests.

Configuration (from conftest.py pytest_configure):
    Django is configured with minimal settings before test collection,
    using an in-memory SQLite database and auth/contenttypes apps.
"""
