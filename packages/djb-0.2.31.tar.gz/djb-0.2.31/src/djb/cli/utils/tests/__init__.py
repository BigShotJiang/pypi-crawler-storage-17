"""Tests for djb.cli.utils package."""
