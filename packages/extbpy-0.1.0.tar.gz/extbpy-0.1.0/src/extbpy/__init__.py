"""
extbpy - A minimal CLI tool for building Blender extensions with Python dependencies.
"""

__version__ = "0.1.0"
__author__ = "extbpy contributors"
__description__ = "Minimal Blender extension builder"
