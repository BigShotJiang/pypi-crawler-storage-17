# Attribution

These tests were copied directly from mdakit_sasa: https://github.com/pegerto/mdakit_sasa/tree/main

All credit for the tests goes to @pegerto.

Some tests have been modified to work with the current implementation.
