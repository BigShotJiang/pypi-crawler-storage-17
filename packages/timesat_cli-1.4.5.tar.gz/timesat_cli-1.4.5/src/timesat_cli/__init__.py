"""
TIMESAT CLI package.

This package provides a Python interface and CLI wrapper for running TIMESAT
processing pipelines.
"""


