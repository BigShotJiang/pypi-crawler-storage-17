"""Exceptions for kseal."""


class KsealError(Exception):
    """Base exception for kseal errors."""

    pass
