"""Entry point for kseal CLI."""

from kseal.cli import main

if __name__ == "__main__":
    main()
