"""DFT-based magnetic material properties."""

import importlib.metadata

from mammos_dft import db as db

__version__ = importlib.metadata.version(__package__)
