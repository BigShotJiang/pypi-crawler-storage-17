import coverage

# This is for calls via multiprocessing to be counted in coverage assessment
coverage.process_startup()
