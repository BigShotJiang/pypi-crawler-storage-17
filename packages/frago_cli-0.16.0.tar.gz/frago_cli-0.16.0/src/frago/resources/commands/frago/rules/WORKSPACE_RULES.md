# 工作目录与空间管理

适用于：`/frago.run`、`/frago.do`

## 一、projects 目录

所有 run 实例存放在 `~/.frago/projects/`，这是固定位置。

```bash
frago run init "my-task"  # 创建 ~/.frago/projects/<id>/
```

---

## 二、工作空间隔离原则

### 所有产出物必须放在 Project 工作空间内

```
~/.frago/projects/<id>/      # run 实例工作空间根目录
├── project.json             # 元数据
├── logs/
│   └── execution.jsonl      # 执行日志
├── scripts/                 # 执行脚本
├── screenshots/             # 截图
├── outputs/                 # 任务产出物（数据、报告、视频等）
│   ├── video_script.json    # 生成的脚本实例
│   ├── final_video.mp4      # 视频产出
│   └── analysis.json        # 分析结果
└── temp/                    # 临时文件（任务完成后清理）
```

### 禁止的行为

- ❌ 在桌面、/tmp、下载目录等外部位置创建文件
- ❌ 配方执行时不指定 output_dir，使用配方默认位置
- ❌ 产出物散落在工作空间外的目录

### 正确做法

- ✅ 所有文件使用 `~/.frago/projects/<id>/` 下的路径
- ✅ 调用配方时明确指定 `output_dir` 为工作空间内的目录
- ✅ 临时文件放在 `temp/`，任务完成后清理

```bash
# ✅ 正确：所有输出都在工作空间内
frago recipe run video_produce_from_script \
  --params '{
    "script_file": "~/.frago/projects/<id>/outputs/video_script.json",
    "output_dir": "~/.frago/projects/<id>/outputs/video"
  }'

# ❌ 错误：使用外部目录
frago recipe run video_produce_from_script \
  --params '{"script_file": "~/Desktop/script.json"}'
```

---

## 三、单一运行互斥

**系统仅允许一个活跃的 Project 上下文。** 这是设计约束，确保工作聚焦。

### 互斥规则

- 当 `set-context` 时，若已有其他活跃的 project，命令会失败并提示先释放
- 同一 project 可以重复 `set-context`（恢复工作）
- 任务完成后**必须**释放上下文

### 典型工作流

```bash
# 1. 开始任务
frago run init "upwork python job apply"
frago run set-context upwork-python-job-apply

# 2. 执行任务...

# 3. 任务完成，释放上下文（必须！）
frago run release

# 4. 开始新任务
frago run init "another task"
frago run set-context another-task
```

### 如果忘记释放

```bash
# 尝试设置新上下文时会看到错误
Error: Another run 'upwork-python-job-apply' is currently active.
Run 'frago run release' to release it first,
or 'frago run set-context upwork-python-job-apply' to continue it.
```

---

## 四、工作目录管理

**禁止使用 `cd` 命令切换目录！** 这会导致 `frago` 命令失效。

### 正确做法

**始终在项目根目录执行所有命令**，使用绝对路径或相对路径访问文件：

```bash
# ✅ 正确：使用绝对路径执行脚本
uv run python ~/.frago/projects/<id>/scripts/filter_jobs.py

# ✅ 正确：使用绝对路径读取文件
cat ~/.frago/projects/<id>/outputs/result.json

# ✅ 正确：使用 find 查看文件结构
find ~/.frago/projects/<id> -type f -name "*.md" | sort
```

### 错误做法

```bash
# ❌ 错误：不要使用 cd
cd ~/.frago/projects/<id> && uv run python scripts/filter_jobs.py

# ❌ 错误：切换目录后 frago 会失效
cd ~/.frago/projects/<id>
frago run log ...  # 这会报错！
```

### 文件路径约定

在 project 实例内部引用文件时，使用**相对于 project 根目录的路径**：

```bash
# 记录日志时，data.file 使用相对路径
frago run log \
  --data '{"file": "scripts/filter_jobs.py", "result_file": "outputs/filtered_jobs.json"}'

# 但执行脚本时，使用完整相对路径或绝对路径
uv run python ~/.frago/projects/<id>/scripts/filter_jobs.py
```

---

## 五、注意事项

- **上下文存储**：`~/.frago/current_run`
- **上下文优先级**：环境变量 `FRAGO_CURRENT_RUN` > 配置文件
- **并发安全**：同一时间只在一个 run 实例中工作
