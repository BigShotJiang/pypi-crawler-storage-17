# Copyright (C) 2025 Intel Corporation
# SPDX-License-Identifier: MIT
"""Package for Connection-specific Process implementations."""

from .base import RemoteProcess
