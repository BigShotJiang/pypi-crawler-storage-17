# Copyright (C) 2025 Intel Corporation
# SPDX-License-Identifier: MIT
"""Console utils."""

BLACK_BACKGROUND_COLOR = 40
ANSITERM_ROWS_SIZE = 30
ANSITERM_COLS_SIZE = 80
