"""Setup configuration for storytelling-mcp."""

from setuptools import setup

setup()
