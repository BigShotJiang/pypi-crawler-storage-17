{
    "name": "Odoo config from env cli",
    "description": """Odoo config from env cli""",
    "author": "Mangono",
    "maintainers": "Mangono",
    "website": "https://mangono.fr",
    "category": "Technical",
    "version": "1.7.0",
    "license": "AGPL-3",
    "installable": False,
}
