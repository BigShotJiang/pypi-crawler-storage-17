"""Default lfn2pfn."""

__all__ = ["lfn2pfn"]


def lfn2pfn(scope, name, rse, rse_attrs, protocol_attrs):
    """True identity LFN2PFN algorithm."""
    return name
