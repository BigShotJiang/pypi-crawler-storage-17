#![cfg(target_os = "macos")]

mod asset_catalog;

pub use asset_catalog::inspect_asset_catalog;
