//
//  safeValueForKey.h
//  AppSizeAnalyzer
//
//  Created by Itay Brenner on 29/4/25.
//

#import <Foundation/Foundation.h>

id safeValueForKey(id object, NSString *key);
