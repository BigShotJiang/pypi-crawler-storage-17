"""Integration tests for bioamla."""
