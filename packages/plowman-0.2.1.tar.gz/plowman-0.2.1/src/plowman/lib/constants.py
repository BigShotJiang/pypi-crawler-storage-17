from pathlib import Path

HOME = Path.home()
CONFIG_PATH = HOME.joinpath(".config", "plowman", "config.yaml")
