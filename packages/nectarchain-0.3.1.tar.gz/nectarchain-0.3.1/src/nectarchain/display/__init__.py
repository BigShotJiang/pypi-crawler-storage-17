""" This module contains the display class for the container.
"""

from .display import ContainerDisplay

__all__ = ["ContainerDisplay"]
