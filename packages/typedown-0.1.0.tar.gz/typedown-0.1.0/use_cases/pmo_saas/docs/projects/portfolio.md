# Strategic Projects 2024

## Project Alpha (Beijing)

```entity:Project
id: "proj_alpha"
name: "Alpha Cloud Migration"
region: "CN-BJ"
status: "ACTIVE"
manager_id: "emp_charlie"
budget_cap: 500000.0
description: "Core banking migration to private cloud."
```

## Project Beta (Shanghai)

```entity:Project
id: "proj_beta"
name: "Beta Mobile App"
region: "CN-SH"
status: "ACTIVE"
manager_id: "emp_charlie"
budget_cap: 200000.0
description: "Next-gen mobile experience."
```
