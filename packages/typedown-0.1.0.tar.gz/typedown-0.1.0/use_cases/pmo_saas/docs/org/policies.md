# Travel Policies 2024

```entity:RegionalPolicy
region_code: "CN-BJ"
travel_allowance_per_day: 300.0
description: "Beijing standard allowance"
```

```entity:RegionalPolicy
region_code: "CN-SH"
travel_allowance_per_day: 350.0
description: "Shanghai standard allowance"
```

```entity:RegionalPolicy
region_code: "REMOTE"
travel_allowance_per_day: 0.0
description: "No allowance for remote work"
```
