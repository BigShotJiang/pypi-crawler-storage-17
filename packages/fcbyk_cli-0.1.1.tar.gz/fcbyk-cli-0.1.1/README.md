![image](https://github.com/user-attachments/assets/655b2999-fd7a-4a63-bc54-c0297c16e0a8)

[![PyPI](https://img.shields.io/pypi/v/fcbyk-cli.svg)](https://pypi.org/project/fcbyk-cli/)
[![Tests](https://github.com/fcbyk/fcbyk-cli/actions/workflows/test.yml/badge.svg)](https://github.com/fcbyk/fcbyk-cli/actions/workflows/test.yml)
[![codecov](https://codecov.io/gh/fcbyk/fcbyk-cli/branch/main/graph/badge.svg)](https://codecov.io/gh/fcbyk/fcbyk-cli)
[![License](https://img.shields.io/github/license/fcbyk/fcbyk-cli.svg)](https://github.com/fcbyk/fcbyk-cli/blob/main/LICENSE)

## 子命令

- lansend：在指定端口开启 `http服务器`，用于局域网内共享文件
- openai：在控制台与 `ai`交互 （需自行配置`api-key`）
- pick：随机抽取一个元素（可用于抽奖、随机选择等）
- jiahao：黑客终端模拟器