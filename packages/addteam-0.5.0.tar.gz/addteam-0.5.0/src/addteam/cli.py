from __future__ import annotations

from .bootstrap_repo import run


def main() -> None:
    raise SystemExit(run())

