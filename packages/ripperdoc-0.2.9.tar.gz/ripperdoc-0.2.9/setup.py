"""
Ripperdoc Python Package Setup Script

This is a placeholder setup.py for backwards compatibility.
The actual build configuration is in pyproject.toml
"""

from setuptools import setup

setup()
