"""
Investify Utils - Shared utilities for Investify services.

Install with optional dependencies:
    pip install investify-utils[postgres]        # Sync PostgreSQL client
    pip install investify-utils[postgres-async]  # Async PostgreSQL client
    pip install investify-utils[postgres-all]    # Both clients

Usage:
    from investify_utils.postgres import PostgresClient, AsyncPostgresClient
"""

__version__ = "2.0.0a2"
