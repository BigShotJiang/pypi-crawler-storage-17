import logging
import time
import uuid
from contextvars import ContextVar
from typing import Annotated, Awaitable, Callable

from fastapi.params import Header
from starlette import status
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.cors import CORSMiddleware as CORSMiddleware
from starlette.middleware.gzip import GZipMiddleware as GZipMiddleware
from starlette.requests import Request
from starlette.responses import Response

from fml._utils import utc_now
from fml.exceptions import ProblemDetailsResponse

logger = logging.getLogger(__name__)

correlation_id_ctx_var: ContextVar[str | None] = ContextVar(
    "correlation_id", default=None
)
request_id_ctx_var: ContextVar[str | None] = ContextVar("request_id", default=None)

RequestIdHeader = Annotated[str | None, Header()]

CorrelationIdHeader = Annotated[str | None, Header()]


def get_correlation_id(request: Request | None) -> str | None:
    correlation_id: str | None = None

    if request is None:
        correlation_id = correlation_id_ctx_var.get()
        return correlation_id

    correlation_id = request.headers.get("X-Correlation-ID")
    if correlation_id is not None:
        return correlation_id

    if hasattr(request.state, "correlation_id"):
        correlation_id = str(request.state.correlation_id)
        return correlation_id

    return None


def get_request_id(request: Request | None = None) -> str | None:
    request_id: str | None = None

    if request is None:
        request_id = request_id_ctx_var.get()
        return request_id

    request_id = request.headers.get("X-Request-ID")
    if request_id is not None:
        return request_id

    if hasattr(request.state, "request_id"):
        request_id = str(request.state.request_id)
        return request_id

    return None


class CorrelationIdMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        correlation_id = get_correlation_id(request) or str(uuid.uuid4())

        request.state.correlation_id = correlation_id
        token = correlation_id_ctx_var.set(correlation_id)

        try:
            response: Response = await call_next(request)
        finally:
            correlation_id_ctx_var.reset(token)

        response.headers["X-Correlation-ID"] = correlation_id

        return response


class RequestIdMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        request_id = get_request_id(request) or str(uuid.uuid4())

        request.state.request_id = request_id
        token = request_id_ctx_var.set(request_id)

        try:
            response: Response = await call_next(request)
        finally:
            request_id_ctx_var.reset(token)

        response.headers["X-Request-ID"] = request_id

        return response


class ProcessTimeMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        start_time = time.perf_counter()
        response: Response = await call_next(request)
        process_time = time.perf_counter() - start_time
        response.headers["X-Process-Time"] = f"{process_time:.6f}"
        return response


class ExceptionMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        try:
            response = await call_next(request)
        except Exception as exc:
            logger.exception(exc)
            return ProblemDetailsResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                title="Internal Server Error",
                detail="The server encountered an unexpected error",
            )
        else:
            return response


class LoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        request_id = str(request.state.request_id)
        request_id_short = request_id[:8]

        request_info = {
            "correlation_id": request.state.correlation_id,
            "request_id": request_id,
            "method": request.method,
            "url": request.url,
            "client_host": request.client.host if request.client is not None else None,
            "user_agent": request.headers.get("User-Agent"),
            "start_time": utc_now(),
        }

        logger.info("Processing request %s", request_id_short, extra=request_info)

        try:
            response: Response = await call_next(request)
        except Exception as exc:
            request_info["end_time"] = utc_now()
            request_info["error"] = str(exc)
            logger.exception("Request %s failed", request_id_short, extra=request_info)
            raise

        request_info["end_time"] = utc_now()
        request_info["status_code"] = response.status_code

        if 200 <= response.status_code < 400:
            logger.info("Request %s completed", request_id_short, extra=request_info)
        else:
            logger.warning("Request %s failed", request_id_short, extra=request_info)

        return response
