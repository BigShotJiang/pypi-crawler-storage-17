Ancillary Functions
-------------------

.. automodule:: s1ard.ancillary
    :members:
    :undoc-members:
    :show-inheritance:

    .. autosummary::
        :nosignatures:

        set_logging