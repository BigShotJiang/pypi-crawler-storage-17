# Changelog

<!-- Have a look at: -->
<!-- https://raw.githubusercontent.com/pypa/hatch/97c76ed53a38c1a376fb80a597d31752168527a0/docs/history/hatchling.md -->

## Footnote

All notable changes to Hatchling will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
