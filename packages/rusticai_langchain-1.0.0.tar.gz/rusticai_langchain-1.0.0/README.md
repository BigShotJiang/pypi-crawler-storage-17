# Rustic AI LangChain

Rustic AI module with [LangChain](https://www.langchain.com/) integrations.

## Installing

```shell
pip install rusticai-langchain
```
**Note:** It depends on [rusticai-core](https://pypi.org/project/rusticai-core/).


## Building from Source

```shell
poetry install --with dev
poetry build
```
