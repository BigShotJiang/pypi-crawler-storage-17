"""Summary plugin for Pulka."""

from .plugin import SummarySheet, register

__all__ = ["SummarySheet", "register"]
