"""Version information for nmaipy."""

__version__ = "3.5.2"
__version_info__ = tuple(int(i) for i in __version__.split("."))
