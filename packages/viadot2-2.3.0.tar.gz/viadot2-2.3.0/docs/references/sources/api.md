# API sources

::: viadot.sources.bigquery.BigQuery

::: viadot.sources.business_core.BusinessCore

::: viadot.sources.cloud_for_customers.CloudForCustomers

::: viadot.sources.customer_gauge.CustomerGauge

::: viadot.sources.epicor.Epicor

::: viadot.sources.eurostat.Eurostat

::: viadot.sources.exchange_rates.ExchangeRates

::: viadot.sources.genesys.Genesys

::: viadot.sources.hubspot.Hubspot

::: viadot.sources.mediatool.Mediatool

::: viadot.sources.mindful.Mindful

::: viadot.sources._minio.MinIO

::: viadot.sources.outlook.Outlook

::: viadot.sources.salesforce.Salesforce

::: viadot.sources.sharepoint.Sharepoint

::: viadot.sources.supermetrics.Supermetrics

::: viadot.sources.uk_carbon_intensity.UKCarbonIntensity

::: viadot.sources.vid_club.VidClub
