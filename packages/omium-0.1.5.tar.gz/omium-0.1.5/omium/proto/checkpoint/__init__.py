"""
Checkpoint protobuf definitions.
"""

from . import checkpoint_pb2
from . import checkpoint_pb2_grpc

__all__ = ["checkpoint_pb2", "checkpoint_pb2_grpc"]

