# Consensus Coordinator Proto
from .consensus_pb2 import *
from .consensus_pb2_grpc import *

