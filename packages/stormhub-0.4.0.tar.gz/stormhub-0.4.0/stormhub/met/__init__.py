"""Package for handling data and creation of storm STAC Items."""
