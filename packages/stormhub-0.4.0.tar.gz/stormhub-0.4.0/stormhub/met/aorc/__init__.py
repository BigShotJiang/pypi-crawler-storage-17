"""Handle AORC storm STAC items."""
