"""Package for creating USGS gage STAC objects."""
