from .predictor import LanguageIdentifier
