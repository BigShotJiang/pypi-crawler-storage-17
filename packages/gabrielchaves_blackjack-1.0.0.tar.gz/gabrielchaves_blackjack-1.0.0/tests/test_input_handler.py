import pytest
from blackjack.input_handler import get_simple_input, get_filtered_input


# =========================
#   get_simple_input
# =========================
def test_get_simple_input_accepts_valid_char(monkeypatch):
  # Simulates user input
  monkeypatch.setattr('builtins.input', lambda prompt: 'a')
  result = get_simple_input("Enter choice: ", "abc")
  assert result == "A"  # always uppercase


def test_get_simple_input_rejects_invalid_then_accept(monkeypatch):
  inputs = iter(["x", "B"])  # first invalid, then valid
  monkeypatch.setattr('builtins.input', lambda prompt: next(inputs))
  result = get_simple_input("Enter choice: ", "abc")
  assert result == "B"


def test_get_simple_input_strips_whitespace(monkeypatch):
  monkeypatch.setattr('builtins.input', lambda prompt: '  c  ')
  result = get_simple_input("Enter choice: ", "abc")
  assert result == "C"


# =========================
# get_filtered_input with simple fallback
# =========================
def test_get_filtered_input_use_simple(monkeypatch):
  monkeypatch.setattr('builtins.input', lambda prompt: '2')
  result = get_filtered_input("Enter choice: ", "12345Q", use_simple=True)
  assert result == "2"


def test_get_filtered_input_invalid_then_valid(monkeypatch):
  inputs = iter(["x", "q"])
  monkeypatch.setattr('builtins.input', lambda prompt: next(inputs))
  result = get_filtered_input("Enter choice: ", "12345Q", use_simple=True)
  assert result == "Q"


# =========================
#   Edge cases
# =========================
def test_get_simple_input_uppercase(monkeypatch):
  monkeypatch.setattr('builtins.input', lambda prompt: 'b')
  result = get_simple_input("Enter choice: ", "B")
  assert result == "B"

def test_get_simple_input_single_char(monkeypatch):
  monkeypatch.setattr('builtins.input', lambda prompt: 'A')
  result = get_simple_input("Enter choice: ", "ABCDE")
  assert result == "A"
