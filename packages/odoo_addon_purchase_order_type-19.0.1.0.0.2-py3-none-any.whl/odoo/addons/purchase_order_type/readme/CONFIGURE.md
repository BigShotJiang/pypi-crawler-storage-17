To configure this module, you need to:

- Go to **Purchases \> Configuration \> Purchase types**
- Modify / create the purchase order types
