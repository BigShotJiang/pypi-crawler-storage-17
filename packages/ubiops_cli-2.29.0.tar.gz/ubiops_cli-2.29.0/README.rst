Command Line Interface to interact with the UbiOps API (v2.1).

Read the documentation at: https://github.com/UbiOps/command-line-interface

More information about UbiOps: https://ubiops.com/

UbiOps-cli is compatible with Python 3.8+ and is distributed under the Apache 2.0 License.
