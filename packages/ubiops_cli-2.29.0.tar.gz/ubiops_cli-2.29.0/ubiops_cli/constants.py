STRUCTURED_TYPE = "structured"
PLAIN_TYPE = "plain"
ML_MODEL_FILE_NAME_KEY = "ML_MODEL_FILE_NAME"
ML_MODEL_FILE_NAME_VALUE = "model"
SYS_DEPLOYMENT_FILE_NAME_KEY = "SYS_DEPLOYMENT_FILE_NAME"
SYS_DEPLOYMENT_FILE_NAME_VALUE = "deployment"

STATUS_UNAVAILABLE = "unavailable"
SUCCESS_STATUSES = ["completed", "available", "success", "running"]
WARNING_STATUSES = [
    "queued",
    "pending",
    "initialising",
    "processing",
    "building",
    "confirmation",
    "confirmation_pending",
]
ERROR_STATUSES = ["failed", "cancelled_pending", "cancelled"]
DEFAULT_IGNORE_FILE = ".ubiops-ignore"
IMPLICIT_ENVIRONMENT_FILES = [
    "ubiops.yaml",
    "requirements.txt",
    "environment.yaml",
]

UPDATE_TIME = 30  # seconds to wait between update and new file upload

DEPLOYMENT_AGENT_WARNING = (
    "WARNING: You are uploading a custom docker image to an environment that supports request format."
    " Please make sure the image contains a UbiOps deployment agent that handles requests."
    " If the image doesn't contain a UbiOps deployment agent, please disable request format support."
)
