import click
import ubiops as api

from .helpers.pipeline_helpers import define_pipeline, get_changed_pipeline_structure, PIPELINE_REQUIRED_FIELDS
from .helpers.helpers import get_label_filter
from .helpers.formatting import (
    print_list,
    print_item,
    format_yaml,
    format_pipeline_requests_reference,
    format_pipeline_requests_oneline,
    format_json,
)
from .helpers import options
from .requests import get_request_input_output, list_requests

from ..constants import STRUCTURED_TYPE
from ..exceptions import UbiOpsException
from ..utils import get_current_project, init_client, read_json, read_yaml, write_yaml, parse_json


LIST_ITEMS = ["last_updated", "name", "labels"]


@click.group(name=["pipelines", "ppl"], short_help="Manage your pipelines")
def commands():
    """
    Manage your pipelines.
    """

    return


@commands.command(name="list", short_help="List pipelines")
@options.LABELS_FILTER
@options.LIST_FORMATS
def pipelines_list(labels, format_):
    """
    List pipelines in project.

    The <labels> option can be used to filter on specific labels.
    """

    label_filter = get_label_filter(labels)

    project_name = get_current_project(error=True)
    if project_name:
        client = init_client()
        pipelines = client.pipelines_list(project_name=project_name, labels=label_filter)
        print_list(pipelines, LIST_ITEMS, sorting_col=1, fmt=format_)
        client.api_client.close()


@commands.command(name="get", short_help="Get a pipeline")
@options.PIPELINE_NAME_ARGUMENT
@options.PIPELINE_YAML_OUTPUT
@options.QUIET
@options.GET_FORMATS
def pipelines_get(pipeline_name, output_path, quiet, format_):
    """
    Get the pipeline settings, like, input_type and input_fields.

    If you specify the <output_path> option, this location will be used to store the
    pipeline structure in a yaml file. You can either specify the <output_path> as file or
    directory. If the specified <output_path> is a directory, the settings will be
    stored in `pipeline.yaml`.
    """

    project_name = get_current_project(error=True)

    client = init_client()
    pipeline = client.pipelines_get(project_name=project_name, pipeline_name=pipeline_name)
    client.api_client.close()

    if output_path is not None:
        dictionary = format_yaml(
            pipeline,
            required_front=["name", "description", "input_type"],
            optional=[
                "input_fields name",
                "input_fields data_type",
                "output_type",
                "output_fields name",
                "output_fields data_type",
            ],
            rename={"name": "pipeline_name", "description": "pipeline_description"},
            as_str=False,
        )

        yaml_file = write_yaml(output_path, dictionary, default_file_name="pipeline.yaml")
        if not quiet:
            click.echo(f"Pipeline file is stored in: {yaml_file}")

    else:
        print_item(
            pipeline,
            row_attrs=LIST_ITEMS,
            required_front=["name", "description", "input_type"],
            optional=[
                "input_fields name",
                "input_fields data_type",
                "output_type",
                "output_fields name",
                "output_fields data_type",
                "creation_date",
                "last_updated",
                "default_version",
            ],
            rename={"name": "pipeline_name", "description": "pipeline_description"},
            fmt=format_,
        )


@commands.command(name="create", short_help="Create a pipeline")
@options.PIPELINE_NAME_OVERRULE
@options.PIPELINE_YAML_FILE
@options.CREATE_FORMATS
def pipelines_create(pipeline_name, yaml_file, format_):
    """
    Create a new pipeline.

    \b
    Define the pipeline parameters using a yaml file.
    For example:
    ```
    pipeline_name: my-pipeline-name
    pipeline_description: Pipeline created via command line.
    pipeline_labels:
      my-key-1: my-label-1
      my-key-2: my-label-2
    input_type: structured
    input_fields:
      - name: my-pipeline-param1
        data_type: int
    output_type: structured
    output_fields:
      - name: my-pipeline-output1
        data_type: int
    ```

    Possible input/output types: [structured, plain].
    Possible data_types: [int, string, double, bool, dict, file, array_string, array_int, array_double, array_file].
    """

    client = init_client()
    project_name = get_current_project(error=True)

    yaml_content = read_yaml(yaml_file, required_fields=PIPELINE_REQUIRED_FIELDS)
    assert (
        "pipeline_name" in yaml_content or pipeline_name
    ), "Please, specify the pipeline name in either the yaml file or as a command argument"

    pipeline_fields, input_fields, output_fields = define_pipeline(yaml_content, pipeline_name)
    pipeline_data = api.PipelineCreate(**pipeline_fields, **input_fields, **output_fields)
    pipeline_response = client.pipelines_create(project_name=project_name, data=pipeline_data)
    client.api_client.close()

    print_item(
        pipeline_response,
        row_attrs=LIST_ITEMS,
        required_front=["name", "description", "input_type"],
        optional=[
            "input_fields name",
            "input_fields data_type",
            "output_type",
            "output_fields name",
            "output_fields data_type",
            "creation_date",
            "last_updated",
        ],
        rename={"name": "pipeline_name", "description": "pipeline_description"},
        fmt=format_,
    )


@commands.command(name="update", short_help="Update a pipeline")
@options.PIPELINE_NAME_ARGUMENT
@options.PIPELINE_NAME_UPDATE
@options.PIPELINE_YAML_FILE_UPDATE
@options.VERSION_DEFAULT_UPDATE
@options.QUIET
def pipelines_update(pipeline_name, new_name, yaml_file, default_version, quiet):
    """
    Update a pipeline.

    If you only want to update the name of the pipeline or the default pipeline version,
    use the options `<new_name>` and `<default_version>`.
    If you want to update the pipeline input/output type and fields, please use a yaml file to define the new pipeline.

    Please note that it's only possible to update the input of a pipeline for pipelines that have no pipeline versions
    with a connected pipeline start, that it's only possible to update the output of a pipeline for pipelines that have
    no pipeline versions with a connected pipeline end.
    """

    client = init_client()
    project_name = get_current_project(error=True)

    # Check if pipeline exists
    existing_pipeline = client.pipelines_get(project_name=project_name, pipeline_name=pipeline_name)

    if yaml_file:
        # Update pipeline according to yaml (and default version update if given)
        yaml_content = read_yaml(yaml_file, required_fields=PIPELINE_REQUIRED_FIELDS)

        pipeline_fields, input_fields, output_fields = define_pipeline(
            yaml_content, pipeline_name, current_pipeline_name=pipeline_name
        )
        changed_input_data = get_changed_pipeline_structure(existing_pipeline, input_fields)
        changed_output_data = get_changed_pipeline_structure(existing_pipeline, output_fields, is_input=False)

        pipeline = api.PipelineUpdate(
            **pipeline_fields, **changed_input_data, **changed_output_data, default_version=default_version
        )
        if pipeline.name != pipeline_name:
            # Pipeline will be renamed
            try:
                client.pipelines_get(project_name=project_name, pipeline_name=pipeline.name)
                raise UbiOpsException(
                    f"Trying to rename pipeline '{pipeline_name}' to '{pipeline.name}', but a pipeline with the new "
                    "name already exists"
                )
            except api.exceptions.ApiException:
                pass

        client.pipelines_update(project_name=project_name, pipeline_name=pipeline_name, data=pipeline)

        if not quiet:
            click.echo("Pipeline was successfully updated")

    elif new_name and new_name != pipeline_name:
        # Pipeline will be renamed (and default version update if given)
        try:
            client.pipelines_get(project_name=project_name, pipeline_name=new_name)
            raise UbiOpsException(
                f"Trying to rename pipeline '{pipeline_name}' to '{new_name}', but a pipeline with the new "
                "name already exists"
            )
        except api.exceptions.ApiException:
            pass

        pipeline = api.PipelineUpdate(name=new_name, default_version=default_version)
        client.pipelines_update(project_name=project_name, pipeline_name=pipeline_name, data=pipeline)

        if not quiet:
            click.echo("Pipeline was successfully updated")

    elif default_version is not None:
        # Pipeline default version will be changed
        pipeline = api.PipelineUpdate(default_version=default_version)
        client.pipelines_update(project_name=project_name, pipeline_name=pipeline_name, data=pipeline)

        if not quiet:
            click.echo("Pipeline default version was successfully updated")

    else:
        if not quiet:
            click.echo("Nothing to update")

    client.api_client.close()


@commands.command(name="delete", short_help="Delete a pipeline")
@options.PIPELINE_NAME_ARGUMENT
@options.ASSUME_YES
@options.QUIET
def pipelines_delete(pipeline_name, assume_yes, quiet):
    """
    Delete a pipeline.
    """

    project_name = get_current_project(error=True)

    if assume_yes or click.confirm(
        f"Are you sure you want to delete pipeline <{pipeline_name}> of project <{project_name}>?"
    ):
        client = init_client()
        client.pipelines_delete(project_name=project_name, pipeline_name=pipeline_name)
        client.api_client.close()

        if not quiet:
            click.echo("Pipeline was successfully deleted")


@commands.group(name="requests", short_help="Manage your pipeline requests")
def requests():
    """
    Manage your pipeline requests.
    """

    return


# pylint: disable=too-many-arguments,too-many-branches,too-many-locals,too-many-statements
@requests.command(name="create", short_help="Create pipeline request")
@options.PIPELINE_NAME_ARGUMENT
@options.VERSION_NAME_OPTIONAL
@options.REQUEST_BATCH
@options.REQUEST_TIMEOUT
@options.REQUEST_OBJECT_TIMEOUT
@options.REQUEST_DATA_MULTI
@options.REQUEST_DATA_FILE
@options.REQUESTS_FORMATS
def requests_create(pipeline_name, version_name, batch, timeout, deployment_timeout, data, json_file, format_):
    """
    Create a pipeline request. Use `--batch` to create a batch (asynchronous) request.
    It's only possible to create a direct (synchronous) request to pipelines without 'batch' mode deployments. In
    contrast, batch (asynchronous) requests can be made to any pipeline, independent on the deployment modes.

    Pipeline requests are only stored for pipeline versions with `request_retention_mode` 'full' or 'metadata'.

    Use the option `timeout` to specify the timeout of the pipeline request. The minimum value is 10 seconds.
    The maximum value is 7200 (2 hours) for direct requests and 345600 (96 hours) for batch requests. The default value
    is 3600 (1 hour) for direct requests and 14400 (4 hours) for batch requests.

    Use the version option to make a request to a specific pipeline version:
    `ubiops pipelines requests create <my-pipeline> -v <my-version> --data <input>`

    If not specified, a request is made to the default version:
    `ubiops pipelines requests create <my-pipeline> --data <input>`

    Use `--batch` to make an asynchronous batch request:
    `ubiops pipelines requests create <my-pipeline> --batch --data <input>`

    Multiple data inputs can be specified at once and send as batch by using the '--data' options multiple times:
    `ubiops pipelines requests create <my-pipeline> --batch --data <input-1> --data <input-2> --data <input-3>`

    For structured input, specify each data input as JSON formatted string. For example:
    `ubiops pipelines requests create <my-pipeline> --data "{\\"param1\\": 1, \\"param2\\": \\"two\\"}"`
    """

    data = list(data)

    project_name = get_current_project(error=True)

    client = init_client()
    pipeline = client.pipelines_get(project_name=project_name, pipeline_name=pipeline_name)

    if batch and deployment_timeout is not None:
        raise UbiOpsException("It's not possible to pass a deployment timeout for a batch pipeline request")

    if json_file and data:
        raise UbiOpsException("Specify data either using the <data> or <json_file> option, not both")

    if json_file:
        input_data = read_json(json_file)
        if not isinstance(input_data, list):
            input_data = [input_data]

    elif data:
        if pipeline.input_type == STRUCTURED_TYPE:
            input_data = []
            for data_item in data:
                input_data.append(parse_json(data=data_item))
        else:
            input_data = data

    else:
        raise UbiOpsException("Missing option <data> or <json_file>")

    params = {"project_name": project_name, "pipeline_name": pipeline_name}
    if version_name is not None:
        params["version"] = version_name
    if timeout is not None:
        params["timeout"] = timeout

    if batch:
        if version_name is not None:
            response = getattr(client, "batch_pipeline_version_requests_create")(**params, data=input_data)
        else:
            response = getattr(client, "batch_pipeline_requests_create")(**params, data=input_data)

    else:
        # We don't support list input for plain type, create the requests one by one
        if pipeline.input_type == STRUCTURED_TYPE:
            input_data = [input_data]

        response = []
        for item in input_data:
            for streaming_update in api.utils.stream_pipeline_request(
                client=client.api_client, data=item, full_response=True, **params
            ):
                if isinstance(streaming_update, str):
                    # Immediately show streaming updates
                    click.echo(streaming_update)
                else:
                    # Keep the final result to display in the correct format
                    response.append(streaming_update)

    client.api_client.close()

    if format_ == "reference":
        click.echo(format_pipeline_requests_reference(response))
    elif format_ == "oneline":
        click.echo(format_pipeline_requests_oneline(response))
    elif format_ == "json":
        click.echo(format_json(response, skip_attributes=["success"]))
    else:
        click.echo(format_pipeline_requests_reference(response))


@requests.command(name="get", short_help="Get a pipeline request")
@options.PIPELINE_NAME_ARGUMENT
@options.VERSION_NAME_OPTIONAL
@options.REQUEST_ID_MULTI
@options.REQUESTS_FORMATS
def requests_get(pipeline_name, version_name, request_id, format_):
    """
    Get one or more pipeline requests.
    Pipeline requests are only stored for pipeline versions with `request_retention_mode` 'full' or 'metadata'.

    Use the version option to get a request for a specific pipeline version.
    If not specified, the request is retrieved for the default version.

    Multiple request ids can be specified at once by using the '-id' options multiple times:
    `ubiops pipelines requests get <my-pipeline> -v <my-version> -id <id-1> -id <id-2> -id <id-3>`
    """

    request_ids = list(request_id)

    project_name = get_current_project(error=True)

    client = init_client()
    if version_name is not None:
        response = client.pipeline_version_requests_batch_get(
            project_name=project_name, pipeline_name=pipeline_name, version=version_name, data=request_ids
        )

    else:
        response = client.pipeline_requests_batch_get(
            project_name=project_name, pipeline_name=pipeline_name, data=request_ids
        )

    client.api_client.close()

    # Fields request_data and result are deprecated for requests GET
    if format_ == "reference":
        click.echo(format_pipeline_requests_reference(response, skip_attributes=["request_data", "result"]))

    elif format_ == "oneline":
        click.echo(format_pipeline_requests_oneline(response, skip_attributes=["request_data", "result"]))

    elif format_ == "json":
        click.echo(format_json(response, skip_attributes=["success", "request_data", "result"]))

    else:
        click.echo(format_pipeline_requests_reference(response, skip_attributes=["request_data", "result"]))


@requests.command(name="list", short_help="List pipeline requests")
@options.PIPELINE_NAME_ARGUMENT
@options.VERSION_NAME_OPTIONAL
@options.OFFSET
@options.REQUEST_LIMIT
@options.REQUEST_FILTER_STATUS
@options.REQUEST_FILTER_START_DATE
@options.REQUEST_FILTER_END_DATE
@options.REQUEST_FILTER_SEARCH_ID
@options.LIST_FORMATS
def requests_list(pipeline_name, version_name, limit, format_, **kwargs):
    """
    List pipeline requests.
    Pipeline requests are only stored for pipeline versions with `request_retention_mode` 'full' or 'metadata'.

    Use the version option to list the requests for a specific pipeline version.
    If not specified, the requests are listed for the default version.
    """

    list_requests(
        object_type="pipeline",
        object_name=pipeline_name,
        version_name=version_name,
        limit=limit,
        format_=format_,
        **kwargs,
    )


@requests.command(name="input", short_help="Get pipeline request input")
@options.PIPELINE_NAME_ARGUMENT
@options.VERSION_NAME_OPTIONAL
@options.REQUEST_ID
@options.INPUT_OUTPUT_DOWNLOAD_PATH
@options.ASSUME_YES
def requests_input(pipeline_name, version_name, request_id, output_path, assume_yes):
    """
    Get the input data of a pipeline request.
    Data is only stored for pipeline versions with `request_retention_mode` 'full'.

    Use the version option to get the input data for a request of a specific pipeline version.
    If not specified, the input data is retrieved for the default version.
    """

    get_request_input_output(
        data_type="input",
        object_type="pipeline",
        object_name=pipeline_name,
        version_name=version_name,
        request_id=request_id,
        output_path=output_path,
        assume_yes=assume_yes,
    )


@requests.command(name="output", short_help="Get pipeline request output")
@options.PIPELINE_NAME_ARGUMENT
@options.VERSION_NAME_OPTIONAL
@options.REQUEST_ID
@options.INPUT_OUTPUT_DOWNLOAD_PATH
@options.ASSUME_YES
def requests_output(pipeline_name, version_name, request_id, output_path, assume_yes):
    """
    Get the output data of a pipeline request.
    Data is only stored for pipeline versions with `request_retention_mode` 'full'.

    Use the version option to get the output data for a request of a specific pipeline version.
    If not specified, the output data is retrieved for the default version.
    """

    get_request_input_output(
        data_type="output",
        object_type="pipeline",
        object_name=pipeline_name,
        version_name=version_name,
        request_id=request_id,
        output_path=output_path,
        assume_yes=assume_yes,
    )
