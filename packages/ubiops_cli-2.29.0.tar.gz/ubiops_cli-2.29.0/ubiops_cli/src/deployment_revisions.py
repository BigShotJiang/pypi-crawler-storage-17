import click
import ubiops as api

from .helpers.formatting import print_list, print_item
from .helpers.wait_for import wait_for
from .helpers import options
from ..utils import init_client, get_current_project, write_blob

LIST_ITEMS = ["creation_date", "id", "created_by", "status"]


@click.group(name=["version_revisions", "revisions"], short_help="Manage your deployment version revisions")
def commands():
    """
    Manage your deployment version revisions.
    """

    return


@commands.command(name="list", short_help="List the revisions")
@options.DEPLOYMENT_NAME_OPTION
@options.VERSION_NAME_OPTION
@options.LIST_FORMATS
def revisions_list(deployment_name, version_name, format_):
    """
    List the revisions of a deployment version.
    """

    project_name = get_current_project(error=True)

    client = init_client()
    response = client.revisions_list(project_name=project_name, deployment_name=deployment_name, version=version_name)
    client.api_client.close()

    print_list(response, LIST_ITEMS, sorting_col=0, fmt=format_)


@commands.command(name="get", short_help="Get a revision of a deployment version")
@options.DEPLOYMENT_NAME_OPTION
@options.VERSION_NAME_OPTION
@options.REVISION_ID
@options.GET_FORMATS
def revisions_get(deployment_name, version_name, revision_id, format_):
    """
    Get a revision of a deployment version.
    """

    project_name = get_current_project(error=True)

    client = init_client()
    revision = client.revisions_get(
        project_name=project_name, deployment_name=deployment_name, version=version_name, revision_id=revision_id
    )
    client.api_client.close()

    print_item(revision, row_attrs=LIST_ITEMS, fmt=format_)


@commands.command(name="download", short_help="Download a revision of a deployment version")
@options.DEPLOYMENT_NAME_OPTION
@options.VERSION_NAME_OPTION
@options.REVISION_ID
@options.DEPLOYMENT_ARCHIVE_OUTPUT
@options.QUIET
def revisions_download(deployment_name, version_name, revision_id, output_path, quiet):
    """
    Download a revision of a deployment version.

    The `<output_path>` option will be used as output location of the archive file. If not specified,
    the current directory will be used.
    """

    if not output_path:
        output_path = "."

    project_name = get_current_project(error=True)

    client = init_client()
    with client.revisions_file_download(
        project_name=project_name, deployment_name=deployment_name, version=version_name, revision_id=revision_id
    ) as response:
        output_path = write_blob(response.read(), output_path, response.getfilename())
    client.api_client.close()

    if not quiet:
        click.echo(f"Archive stored in: {output_path}")


@commands.command(name="upload", short_help="Create a revision of a deployment version")
@options.DEPLOYMENT_NAME_OPTION
@options.VERSION_NAME_OPTION
@options.DEPLOYMENT_ARCHIVE_INPUT
@options.PROGRESS_BAR
@options.GET_FORMATS
def revisions_upload(deployment_name, version_name, archive_path, progress_bar, format_):
    """
    Create a revision of a deployment version by uploading a deployment package archive file.

    Please, specify the deployment package `<archive_path>` that should be uploaded.
    """

    project_name = get_current_project(error=True)

    client = init_client()
    revision = client.revisions_file_upload(
        project_name=project_name,
        deployment_name=deployment_name,
        version=version_name,
        file=archive_path,
        _progress_bar=False if not archive_path else progress_bar,
    )
    client.api_client.close()

    print_item(revision, row_attrs=["revision", "build"], fmt=format_)


# pylint: disable=too-many-arguments
@commands.command(name="wait", short_help="Wait for a deployment revision to be ready")
@options.DEPLOYMENT_NAME_OPTION
@options.VERSION_NAME_OPTION
@options.REVISION_ID
@options.TIMEOUT_OPTION
@options.STREAM_LOGS
@options.QUIET
def revisions_wait(deployment_name, version_name, revision_id, timeout, stream_logs, quiet):
    """
    Wait for a deployment revision to be ready.
    """

    project_name = get_current_project(error=True)

    client = init_client()
    wait_for(
        api.utils.wait_for.wait_for_revision,
        client=client.api_client,
        project_name=project_name,
        deployment_name=deployment_name,
        version=version_name,
        revision_id=revision_id,
        timeout=timeout,
        quiet=quiet,
        stream_logs=stream_logs,
    )
    client.api_client.close()
