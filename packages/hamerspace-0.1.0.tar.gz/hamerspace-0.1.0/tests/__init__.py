"""Tests for Hamerspace."""
