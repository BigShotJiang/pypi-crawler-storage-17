"""Convenience import for OptimizationResult."""
from hamerspace.core.optimizer import OptimizationResult

__all__ = ["OptimizationResult"]
