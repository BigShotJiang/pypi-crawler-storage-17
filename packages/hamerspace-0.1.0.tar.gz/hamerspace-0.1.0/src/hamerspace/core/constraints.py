"""Convenience import for Constraints."""
from hamerspace.core.models import Constraints

__all__ = ["Constraints"]
