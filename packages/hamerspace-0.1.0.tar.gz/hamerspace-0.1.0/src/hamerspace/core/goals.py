"""Convenience import for OptimizationGoal."""
from hamerspace.core.models import OptimizationGoal

__all__ = ["OptimizationGoal"]
