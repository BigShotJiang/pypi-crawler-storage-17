"""Benchmarking module."""

from hamerspace.benchmarks.benchmarker import Benchmarker

__all__ = ["Benchmarker"]
