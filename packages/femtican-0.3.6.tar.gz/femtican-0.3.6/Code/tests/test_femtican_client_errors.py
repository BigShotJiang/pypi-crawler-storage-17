from femtican import FemticanClient


def _create_client():
    client = FemticanClient()
    client.connect("127.0.0.1")
    errors = []
    client.error_handler = errors.append
    return client, errors


def test_connect_failure_calls_error_handler():
    client, errors = _create_client()

    # Port 9 on localhost is almost never open—this will trigger the connect-failed path.
    client.connect("127.0.0.1", port=9)

    assert errors, "Expected error_handler to be called on TCP connect failure"
    assert errors[0].startswith("TCP connect failed:")
