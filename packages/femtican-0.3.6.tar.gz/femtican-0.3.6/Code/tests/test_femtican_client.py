import time

import pytest

from femtican.femtican_client import FemticanClient

femtican_connection_string = "carlita.local"
femtican_connection_string_port = 60200


class TestFemticanLive:
    # Tests require a running backend
    def __create_connected_femtican(self):
        client = FemticanClient()
        client.connect(femtican_connection_string, femtican_connection_string_port)
        return client

    def test_connection(self):
        client = FemticanClient()
        ok, err = client.connect("carlita.local")
        assert ok
        client.disconnect()

    @pytest.mark.skip(reason="Skipping so a tester doesn't accidentally write data to the real machine")
    def test_set_register(self):
        client = self.__create_connected_femtican()
        client.set_register_index(162, 67, 0, 1)

        def error_handler(err_msg):
            print(f"Error: {err_msg}")

        client.error_handler = error_handler
        time.sleep(5)
        client.disconnect()

    @pytest.mark.skip(reason="Skipping so a tester doesn't accidentally write data to the real machine")
    def test_trigger_broadcasts(self):
        client = self.__create_connected_femtican()
        received_values = []

        def global_handler(device_id, register_id, value):
            print(f"{device_id}-{register_id}----{value}")
            if (device_id, register_id) == (162, 0x10):
                received_values.append(value)

        def error_handler(error_message):
            print(f"Error: {error_message}")

        client.broadcast_handler = global_handler
        client.error_handler = error_handler
        time.sleep(10)

        # for _ in range(10):
        #   client.set_register(162, 0x10, None)
        #   time.sleep(0.05)

        time.sleep(1)
        client.disconnect()

        assert len(received_values) >= 10, "Expected at least 10 broadcast values to be received"

    @pytest.mark.skip(reason="Skipping so a tester doesn't accidentally write data to the real machine")
    def test_global_broadcast_handler(self):
        client = self.__create_connected_femtican()
        all_payloads = []

        def global_handler(device_id, register_id, value):
            print(f"{device_id}-{register_id}----{value}")
            all_payloads.append((device_id, register_id, value))

        client.broadcast_handler = global_handler

        # wait up to 2 seconds for broadcasts
        time.sleep(2)

        assert all_payloads, "Global handler did not receive any broadcasts"
        client.disconnect()

    # @pytest.mark.skip(reason="Skipping so a tester doesn't accidentally write data to the real machine")
    def test_broadcast_handlers(self):
        client = self.__create_connected_femtican()

        def aries_handler(device_id, register_id, value):
            print(f"{device_id}-{register_id}----{value} -- aries")

        def random_handler(device_id, register_id, value):
            print(f"{device_id}-{register_id}----{value} -- random")

        client.add_broadcast_handler(162, 50, aries_handler)
        client.add_broadcast_handler(162, 48, random_handler)

        for _ in range(10):
            client.trigger_broadcast(162, 50)
            time.sleep(0.05)
        # wait up to 2 seconds for broadcasts
        time.sleep(2)

        client.remove_broadcast_handler(162, 50)
        client.remove_broadcast_handler(162, 48)

        client.disconnect()
