from unittest import TestCase

from femtican.tcp_client import TcpClient


class TestTcpClientSync(TestCase):
    def test_try_connect_invalid_string(self):
        client = TcpClient()
        ok, err = client.try_connect("")
        self.assertFalse(ok)
        self.assertIn("meaningful", err.lower())

    def test_try_connect_malformed_string(self):
        client = TcpClient()
        ok, err = client.try_connect("noport")
        self.assertFalse(ok)
        self.assertIn("malformed", err.lower())

    def test_try_connect_unreachable_host(self):
        client = TcpClient()
        ok, err = client.try_connect("127.0.0.1:12345")
        self.assertFalse(ok)
        self.assertIn("failed", err.lower())
