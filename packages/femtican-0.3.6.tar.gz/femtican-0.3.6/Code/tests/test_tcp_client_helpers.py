import zlib

import pytest

from femtican.frames import TcpFrame
from femtican.data_helpers import (
    extract_data_length,
    extract_id,
    extract_data,
    calculate_hash,
    extract_hash,
    try_parse_connection_string,
)


@pytest.fixture
def sample_buffer():
    # Build a minimal valid TCP frame:
    # SOF=0x01, length=3, id=0xAABBCCDD, data=b'\x10\x20\x30'
    sof = b"\x01"
    length = (3).to_bytes(2, "little")
    can_id = (0xAABBCCDD).to_bytes(4, "little")
    data = b"\x10\x20\x30"
    naked = sof + length + can_id + data
    crc = zlib.crc32(naked).to_bytes(4, "little")
    frame_bytes = naked + crc

    # pad into a larger buffer
    buf = bytearray(100)
    buf[5: 5 + len(frame_bytes)] = frame_bytes
    return buf, 5, 3  # buffer, sof_index, data_length


def test_extract_data_length(sample_buffer):
    buf, sof_i, _ = sample_buffer
    assert extract_data_length(buf, sof_i) == 3


def test_extract_id_and_data(sample_buffer):
    buf, sof_i, data_length = sample_buffer
    expected_id = 0xAABBCCDD
    assert extract_id(buf, sof_i) == expected_id
    assert extract_data(buf, sof_i, data_length) == b"\x10\x20\x30"


def test_hash_functions(sample_buffer):
    buf, sof_i, data_length = sample_buffer
    # calculate_hash should match Python's zlib.crc32
    expected = (
        zlib.crc32(buf[sof_i: sof_i + TcpFrame.LENGTH_OF_SOF_LENGTH_ID + data_length])
        & 0xFFFFFFFF
    )
    assert calculate_hash(buf, sof_i, data_length) == expected
    # extract_hash should pull the CRC we computed
    full_crc = buf[
               sof_i
               + TcpFrame.LENGTH_OF_SOF_LENGTH_ID
               + data_length: sof_i
                              + TcpFrame.LENGTH_OF_SOF_LENGTH_ID
                              + data_length
                              + TcpFrame.LENGTH_OF_CRC
               ]
    assert extract_hash(buf, sof_i, data_length) == int.from_bytes(full_crc, "little")


@pytest.mark.parametrize(
    "input_string,expected",
    [
        ("host:1234", (True, "host", 1234, "")),
        ("http://example.com:80", (True, "example.com", 80, "")),
        ("https://bad:443", (False, "", 0, "HTTPS is not supported.")),
        ("noport", (False, "", 0, "Malformed connection string.")),
        ("host:99999", (False, "", 0, "Port must be a number between 0 and 65535.")),
    ],
)
def test_try_parse_connection_string(input_string, expected):
    assert try_parse_connection_string(input_string) == expected
