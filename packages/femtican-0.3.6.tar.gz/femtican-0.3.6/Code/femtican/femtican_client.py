import struct
import threading
from typing import Tuple, Optional, Union, Any, Dict

from femtican.data_type import DataType
from femtican.frame_helpers import parse_frame_type, \
    parse_frame_global_id, parse_frame_data_type, to_raw_frame, construct_text_frame, construct_number_frame, \
    construct_empty_frame, construct_number_index_frame
from femtican.frames import GenericFrame, FrameType
from femtican.global_id import GlobalId
from femtican.tcp_client import TcpClient


class FemticanClient:
    def __init__(self):
        self.broadcast_handler = None  # a catch-all callback
        self._broadcast_handlers: Dict[GlobalId, Any] = {}
        self.error_handler = None  # catch-all error callback
        self._handlers_lock = threading.Lock()
        self._tcp_client: Optional[TcpClient] = None
        self._thread: Optional[threading.Thread] = None
        self._cancel_event = threading.Event()

    def add_broadcast_handler(self, device_id: int, register_id: int, handler: Any):
        global_id = GlobalId(device_id, register_id)
        with self._handlers_lock:
            self._broadcast_handlers[global_id] = handler

    def remove_broadcast_handler(self, device_id: int, register_id: int) -> None:
        global_id = GlobalId(device_id, register_id)
        with self._handlers_lock:
            current = self._broadcast_handlers.get(global_id)
            if current:
                self._broadcast_handlers.pop(global_id, None)

    def connect(self, connection_string: str, port: int = 60200) -> Tuple[bool, Optional[str]]:
        tcp_client = TcpClient()

        ok, err = tcp_client.try_connect(f"{connection_string}:{port}")
        if not ok:
            if self.error_handler:
                self.error_handler(f"TCP connect failed: {err}")
                return False, f"TCP connect failed: {err}"

        self.__start_tcp_client(tcp_client)
        return True, None

    def disconnect(self):
        if isinstance(self._tcp_client, TcpClient):
            self._tcp_client.disconnect()
            self._cancel_event.set()
            if self._thread:
                self._thread.join()

    def __post_request(self, frame: GenericFrame):
        if self._tcp_client is None:
            if self.error_handler:
                self.error_handler("Cannot send request, no CAN provider is set")
            return
        raw_frame = to_raw_frame(frame)
        self._tcp_client.post_frame(raw_frame)

    def set_register(self, device_id: int, register_id: int, value: Union[None, float, int, str]):
        try:
            global_id = GlobalId(device_id, register_id)
        except Exception as ex:
            if self.error_handler:
                self.error_handler(f"Invalid GlobalId: {ex}")
            return

        if value is None:
            frame = construct_empty_frame(global_id)
        elif isinstance(value, (float, int)):
            frame = construct_number_frame(global_id, value)
        elif isinstance(value, str):
            frame = construct_text_frame(global_id, value)
        else:
            if self.error_handler:
                self.error_handler("Unsupported value type for set_register")
            return

        self.__post_request(frame)

    def set_register_index(self, device_id: int, register_id: int, index: int, value: Union[float, int]):
        try:
            global_id = GlobalId(device_id, register_id)
        except Exception as ex:
            if self.error_handler:
                self.error_handler(f"Invalid GlobalId: {ex}")
            return

        ok, data = construct_number_index_frame(global_id, index, value, frame_type=FrameType.SET_REQUEST)
        if ok:
            self.__post_request(data)
        elif self.error_handler:
            self.error_handler(data)

    def trigger_broadcast(self, device_id: int, register_id: int):
        try:
            global_id = GlobalId(device_id, register_id)
        except Exception as ex:
            if self.error_handler:
                self.error_handler(f"Invalid GlobalId: {ex}")
            return

        frame = construct_empty_frame(global_id, frame_type=FrameType.GET_REQUEST)
        self.__post_request(frame)

    def __start_tcp_client(self, tcp_client: TcpClient):
        if self._thread and self._thread.is_alive():
            self._cancel_event.set()
            self._thread.join()

        self._cancel_event = threading.Event()
        self._tcp_client = tcp_client
        self._thread = threading.Thread(
            target=self.__process_can_frames_continuously,
            args=(tcp_client, self._cancel_event),
            daemon=True,
        )
        self._thread.start()

    def __process_can_frames_continuously(self, tcp_client: TcpClient, cancel_event: threading.Event) -> None:
        for raw_frame in tcp_client.fetch_frames(cancel_event):
            frame_type = parse_frame_type(raw_frame)
            global_id = parse_frame_global_id(raw_frame)
            data_type = parse_frame_data_type(raw_frame)
            data = raw_frame.data
            try:
                if data_type == DataType.NUMBER:
                    if len(data) % 4 != 0 and self.error_handler:
                        self.error_handler(
                            f"Invalid numeric payload length from device:{global_id.device_id}, register:{global_id.register_id}")
                        return
                    count = len(data) // 4
                    payload = struct.unpack(f"<{count}f", data)
                elif data_type == DataType.TEXT:
                    payload = data.decode("utf-8")
                else:
                    payload = None
            except Exception as ex:
                if self.error_handler:
                    self.error_handler(str(ex))
                continue

            if frame_type is FrameType.BROADCAST:
                if self.broadcast_handler:
                    try:
                        self.broadcast_handler(global_id.device_id, global_id.register_id, payload)
                    except Exception as ex:
                        if self.error_handler:
                            self.error_handler(f"Broadcast handler error: {ex}")

                handler = None
                with self._handlers_lock:
                    handler = self._broadcast_handlers.get(global_id)
                if handler:
                    try:
                        handler(global_id.device_id, global_id.register_id, payload)
                    except Exception as ex:
                        if self.error_handler:
                            self.error_handler(f"Broadcast handler error: {ex}")

            if frame_type is FrameType.RESPONSE:
                ok, err_msg = self.__process_response(data)
                if not ok:
                    if self.error_handler:
                        self.error_handler(f"{global_id} : {err_msg}")
                continue

    def __process_response(self, data: bytes) -> Tuple[bool, str]:
        # Byte 0: response code (0=OK)
        # Byte 1: original request type (1=Get, 2=Set)
        # Bytes 2-3: reserved
        # Bytes 4-63: optional error text
        if len(data) < 2:
            return False, "Invalid response payload length"

        code = data[0]
        error_message = ""
        if len(data) > 4:
            error_message = data[4:64].split(b'\x00', 1)[0].decode("utf-8", errors="ignore")

        if code != 0:
            return False, error_message or f"Error: Response code {code}"
        return True, ""
