import queue
import socket
import threading
import time
import zlib
from typing import Optional, Tuple, Iterable

from femtican.frames import RawFrame, PostResponse
from femtican.data_helpers import try_parse_connection_string
from femtican.intermediate_buffer import IntermediateBuffer


class TcpClient():
    """
    Provides a TCP connection to a Femtican TCP relay.
    """

    def __init__(self):
        self._relay_queue: queue.Queue[RawFrame] = queue.Queue()  # Queue for incoming frames
        self._global_cancel_event = threading.Event()
        self.is_connected: bool = False
        self.is_disconnected: bool = True
        self._is_socket_monitor_running: bool = False
        self._last_used_connection_string: str = ""
        self._socket: Optional[socket.socket] = None
        self._intermediate_buffer = IntermediateBuffer()

        self._reader_thread: Optional[threading.Thread] = None  # Background task

    def try_connect(self, connection_string: str) -> Tuple[bool, str]:
        """
        Tries to connect using the given "hostname:port" string.
        Returns (success, error_message).
        """
        if not connection_string:
            return False, "Connection string must be something meaningful."

        ok, host, port, err = try_parse_connection_string(connection_string)
        if not ok:
            return False, err

        # If already connected to the same endpoint, do nothing
        if self.is_connected and connection_string == self._last_used_connection_string:
            return True, ""

        # If connected to a different endpoint, disconnect first
        if self.is_connected:
            self.disconnect()

        self._last_used_connection_string = connection_string
        address_family = socket.getaddrinfo(host, port)[0][0]  # Accessing address family of host

        # Create and connect the socket with a 1s timeout
        sock = socket.socket(address_family, socket.SOCK_STREAM)
        sock.settimeout(1.0)

        try:
            sock.connect((host, port))
        except (socket.timeout, socket.error) as ex:
            return False, f"Connection to {connection_string} failed. {ex}"

        # Connection succeeded
        self._socket = sock
        self.is_connected = True
        self.is_disconnected = False

        # Start reading frames in the background
        self._reader_thread = threading.Thread(target=self.__process_socket_continuously, daemon=True)
        self._reader_thread.start()
        return True, ""

    def fetch_frames(self, cancel_event: Optional[threading.Event] = None) -> Iterable[RawFrame]:
        """
        Generator yielding RawFrame as they arrive.
        """
        cancel_event_ = cancel_event or self._global_cancel_event
        while not cancel_event_.is_set():
            try:
                frame = self._relay_queue.get(timeout=0.1)  # small timeout to check cancel event
                yield frame
            except queue.Empty:
                continue

    def post_frame(self, frame: RawFrame) -> PostResponse:
        """
        Sends a RawFrame over TCP and returns a PostResponse.
        """
        if not self.is_connected or self._socket is None:
            return PostResponse(False, "Cannot post frame, socket is not connected.")

        # Build frame bytes: SOF (1) + length (2) + ID (4) + data + CRC (4)
        sof = b"\x01"
        length_bytes = len(frame.data).to_bytes(2, "little")
        id_bytes = frame.id.to_bytes(4, "little")
        payload = frame.data
        frame_without_crc = sof + length_bytes + id_bytes + payload
        crc = zlib.crc32(frame_without_crc).to_bytes(4, "little")
        try:
            self._socket.sendall(frame_without_crc + crc)
        except socket.error as ex:
            return PostResponse(False, str(ex))

        return PostResponse(True, "")

    def disconnect(self) -> None:
        """
        Gracefully disconnect the TCP channel.
        """
        if self.is_disconnected:
            return

        self.is_connected = False
        self._global_cancel_event.set()

        # Disconnect may happen from within the reader thread as well as triggered manually, and this affects the join.
        if self._reader_thread.is_alive() and self._reader_thread is not threading.current_thread():
            self._reader_thread.join(timeout=1.0)

        if self._socket:
            try:
                self._socket.shutdown(socket.SHUT_RDWR)
            except (socket.error, OSError):
                pass
            finally:
                self._socket.close()

        self.is_disconnected = True

    def __process_socket_continuously(self) -> None:
        """
        Read incoming bytes, parse frames, and enqueue them.
        """
        self._is_socket_monitor_running = True
        try:
            while not self._global_cancel_event.is_set():
                if not self.is_connected or self._socket is None:
                    time.sleep(0.1)
                    continue

                # Receive up to 2048 bytes (blocking)
                try:
                    data = self._socket.recv(2048)
                    if data:
                        self._intermediate_buffer.add_data(data, len(data))
                        while True:
                            found, frame = self._intermediate_buffer.try_extract_frame()
                            if not found:
                                break
                            self._relay_queue.put(RawFrame(frame.id, frame.data))
                    else:
                        break
                except socket.error:
                    break
        finally:
            self._is_socket_monitor_running = False
            self.disconnect()
