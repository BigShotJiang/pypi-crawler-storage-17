import zlib
from typing import Tuple

from femtican.frames import TcpFrame


def calculate_hash(array: bytearray, sof_index: int, data_length: int) -> int:
    """
    Calculate CRC32 over the slice from sof_index to sof_index + LENGTH_OF_SOF_LENGTH_ID + data_length.
    """
    start = sof_index
    end = sof_index + TcpFrame.LENGTH_OF_SOF_LENGTH_ID + data_length
    return zlib.crc32(array[start:end])


def extract_data(array: bytearray, sof_index: int, data_length: int) -> bytes:
    """
    Extract the data payload from the buffer.
    """
    start = sof_index + TcpFrame.LENGTH_OF_SOF_LENGTH_ID
    end = start + data_length
    return bytes(array[start:end])


def extract_data_length(array: bytearray, sof_index: int) -> int:
    """
    Read a 2-byte little-endian unsigned short from after SOF to get payload length.
    """
    start = sof_index + TcpFrame.LENGTH_OF_SOF
    # little-endian unsigned short
    return int.from_bytes(array[start: start + 2], "little")


def extract_hash(array: bytearray, sof_index: int, data_length: int) -> int:
    """
    Read the CRC32 value appended after the payload.
    """
    start = sof_index + TcpFrame.LENGTH_OF_SOF_LENGTH_ID + data_length
    end = start + TcpFrame.LENGTH_OF_CRC
    return int.from_bytes(array[start:end], "little")


def extract_id(array: bytearray, sof_index: int) -> int:
    """
    Read the 4-byte CAN ID right after SOF length fields.
    """
    start = sof_index + TcpFrame.LENGTH_OF_SOF_LENGTH
    end = start + 4
    return int.from_bytes(array[start:end], "little")


def try_parse_connection_string(input_string: str) -> Tuple[bool, str, int, str]:
    """
    Parse "hostname:port" strings.
    Returns (success, hostname, port, error_message).
    """
    string = input_string
    if string.startswith("https:"):
        return False, "", 0, "HTTPS is not supported."
    if string.startswith("http://"):
        string = string[7:]
    if ":" not in string:
        return False, "", 0, "Malformed connection string."

    hostname, port_str = string.split(":", 1)
    port = int(port_str)
    if not (0 <= port <= 65535):
        return False, "", 0, "Port must be a number between 0 and 65535."

    return True, hostname, port, ""
