from dataclasses import dataclass


@dataclass(frozen=True)
class GlobalId:
    device_id: int = 0
    register_id: int = 0

    def __post_init__(self):
        if not (0x00 <= self.device_id <= 0xFF):
            raise ValueError(
                f"device_id must be between 0x00 and 0xFF, got {self.device_id}"
            )
        if not (0x000 <= self.register_id <= 0xFFF):
            raise ValueError(
                f"register_id must be between 0x000 and 0xFFF, got {self.register_id}"
            )

    def __str__(self) -> str:
        return f"{self.device_id}-{self.register_id}"
