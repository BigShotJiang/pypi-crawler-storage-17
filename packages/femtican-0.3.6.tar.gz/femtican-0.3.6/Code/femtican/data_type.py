from enum import Enum


class DataType(Enum):
    NUMBER = 0
    TEXT = 1
    RAW_DATA = 2
    MULTI_PACKET_RAW = 3
    EMPTY = 14
    FRAME_SPECIFIC = 15
