from enum import Enum


class ResponseResult(Enum):
    OK = 0
    WRONG_DIRECTION = 1
    WRONG_REGISTER_ID = 2
    WRONG_DATA_TYPE = 3
    VALUE_OUT_OF_BOUNDS = 4
    WRONG_STATE = 5
    INDEX_OUT_OF_BOUNDS = 6
