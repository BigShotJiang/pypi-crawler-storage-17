import math
import struct
from typing import Tuple, Union

from femtican.frames import GenericFrame, RawFrame, FrameType
from femtican.global_id import GlobalId
from femtican.data_type import DataType


def to_raw_frame(frame: GenericFrame) -> RawFrame:
    # build id bits
    id_ = 0
    id_ |= frame.data_type.value
    id_ |= frame.global_id.register_id << 4
    id_ |= frame.global_id.device_id << 16
    id_ |= frame.frame_type.value << 26

    return RawFrame(id_, frame.payload)


def parse_frame_type(raw: RawFrame) -> FrameType:
    bits = (raw.id >> 26) & 0b11
    return FrameType(bits)


def parse_frame_data_type(raw: RawFrame) -> DataType:
    bits = raw.id & 0b1111
    return DataType(bits)


def parse_frame_global_id(raw: RawFrame) -> GlobalId:
    device = (raw.id >> 16) & 0xFF
    register = (raw.id >> 4) & 0x0FFF
    return GlobalId(device, register)


def construct_empty_frame(global_id: GlobalId, frame_type: FrameType = FrameType.SET_REQUEST) -> GenericFrame:
    return GenericFrame(
        frame_type=frame_type,
        global_id=global_id,
        data_type=DataType.EMPTY,
        payload=b""
    )


def construct_number_frame(global_id: GlobalId, value: Union[int, float],
                           frame_type: FrameType = FrameType.SET_REQUEST) -> GenericFrame:
    payload = struct.pack("<f", float(value))  # pack a single float
    return GenericFrame(
        frame_type=frame_type,
        global_id=global_id,
        data_type=DataType.NUMBER,
        payload=payload
    )


def construct_number_index_frame(global_id: GlobalId,
                                 index: int,
                                 value: Union[int, float],
                                 frame_type: FrameType = FrameType.SET_REQUEST) -> (
    Tuple)[bool, Union[GenericFrame, str]]:
    if index < 0 or index > 15:
        return False, "Index must be non-negative and below 16"

    converted_value = float(value)
    values = [math.nan] * index + [converted_value]
    payload = b"".join(struct.pack("<f", val) for val in values)

    frame = GenericFrame(
        frame_type=frame_type,
        global_id=global_id,
        data_type=DataType.NUMBER,
        payload=payload
    )
    return True, frame


def construct_text_frame(global_id: GlobalId, text: str, frame_type: FrameType = FrameType.SET_REQUEST) -> GenericFrame:
    encoded = text.encode("utf-8")[:64]  # utf-8 encode and trim to 64 bytes
    return GenericFrame(
        frame_type=frame_type,
        global_id=global_id,
        data_type=DataType.TEXT,
        payload=encoded
    )
