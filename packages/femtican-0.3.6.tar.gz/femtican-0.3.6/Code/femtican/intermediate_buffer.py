import threading
from typing import Tuple

from femtican.frames import TcpFrame
from femtican.data_helpers import (
    extract_data,
    extract_id,
    extract_data_length,
    extract_hash,
    calculate_hash,
)


class IntermediateBuffer:
    _buffer_size: int = 8192

    def __init__(self):
        self._array_lock = threading.Lock()
        self._process_buffer = bytearray(self._buffer_size)
        self._head_index = 0
        self._tail_index = 0

    def add_data(self, data_to_add: bytes, count: int) -> None:
        with self._array_lock:
            data_count_to_copy = count

            if self._tail_index + count >= self._buffer_size:
                data_count_to_copy = self._buffer_size - self._tail_index  # Incoming data cannot fit in the receive buffer. Some data is lost.

            self._process_buffer[self._tail_index: self._tail_index + data_count_to_copy] = data_to_add[
                                                                                            :data_count_to_copy]
            self._tail_index += data_count_to_copy

    def try_extract_frame(self) -> Tuple[bool, TcpFrame]:
        """
        Attempt to parse and extract a single TcpFrame from the buffer.
        Returns (True, frame) if successful, otherwise (False, TcpFrame.empty()).
        """
        is_frame_detected = False
        detected_frame = TcpFrame.empty()

        with self._array_lock:
            original_head = self._head_index

            for i in range(self._head_index, self._tail_index):
                # Ensure minimum length present
                if i + TcpFrame.MIN_LENGTH > self._tail_index:
                    break

                # Detect SOF
                if self._process_buffer[i] != 0x01:
                    self._head_index = i
                    continue

                data_length = extract_data_length(self._process_buffer, i)
                frame_len = (
                    TcpFrame.LENGTH_OF_SOF_LENGTH_ID
                    + data_length
                    + TcpFrame.LENGTH_OF_CRC
                )

                # Check full frame present
                if i + frame_len > self._tail_index:
                    continue

                sent_hash = extract_hash(self._process_buffer, i, data_length)
                actual_hash = calculate_hash(self._process_buffer, i, data_length)

                if sent_hash == actual_hash:
                    frame_id = extract_id(self._process_buffer, i)
                    payload = extract_data(self._process_buffer, i, data_length)
                    detected_frame = TcpFrame(frame_id, data_length, payload)
                    # Advance head past this frame
                    self._head_index += frame_len
                    is_frame_detected = True
                    break
                else:
                    # False positive SOF
                    self._head_index = i

            # Drop garbage if too much unparsed data
            if (
                not is_frame_detected
                and (self._head_index - original_head) >= TcpFrame.MAX_LENGTH
            ):
                # Data at the start of the buffer is unrecognized, dropping bytes
                self._head_index += TcpFrame.MAX_LENGTH

            # Condensing buffer from time to time.
            if self._head_index > (self._buffer_size // 2):
                remaining = self._tail_index - self._head_index
                # Shift remaining data to start
                self._process_buffer[:remaining] = self._process_buffer[
                                                   self._head_index: self._tail_index
                                                   ]
                self._tail_index = remaining
                self._head_index = 0

        if not is_frame_detected:
            return False, TcpFrame.empty()

        return True, detected_frame
