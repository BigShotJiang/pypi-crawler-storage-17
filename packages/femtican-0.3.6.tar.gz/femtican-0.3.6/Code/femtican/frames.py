import zlib
from dataclasses import dataclass
from enum import Enum
from typing import ClassVar

from femtican.data_type import DataType
from femtican.global_id import GlobalId


class FrameType(Enum):
    BROADCAST = 0
    GET_REQUEST = 1
    SET_REQUEST = 2
    RESPONSE = 3


@dataclass(frozen=True)
class GenericFrame:
    frame_type: FrameType
    global_id: GlobalId
    data_type: DataType
    payload: bytes


@dataclass
class RawFrame:
    id: int
    data: bytes


@dataclass
class PostResponse:
    is_ok: bool
    error_message: str = ""


class TcpFrame:
    """
    CAN frame wrapped for TCP transmission.
    """

    LENGTH_OF_CRC: ClassVar[int] = 4
    LENGTH_OF_SOF: ClassVar[int] = 1
    LENGTH_OF_SOF_LENGTH: ClassVar[int] = LENGTH_OF_SOF + 2
    LENGTH_OF_SOF_LENGTH_ID: ClassVar[int] = LENGTH_OF_SOF_LENGTH + 4
    MIN_LENGTH: ClassVar[int] = LENGTH_OF_SOF_LENGTH_ID + LENGTH_OF_CRC
    MAX_LENGTH: ClassVar[int] = LENGTH_OF_SOF_LENGTH_ID + 64 + LENGTH_OF_CRC

    def __init__(self, index: int, data_length: int, data: bytes):
        if data is None:
            raise ValueError("Data cannot be None")
        if len(data) < data_length:
            raise ValueError(
                f"Data length must be at least {data_length}, got {len(data)}"
            )
        self.id: int = index
        self.data_length: int = data_length
        self.data: bytes = data[:data_length]  # Copy the data array

    @classmethod
    def empty(cls) -> "TcpFrame":
        """
        Returns an empty TCP frame. It shall not be sent over the network.
        """
        return cls(0, 0, b"")

    def to_bytes(self) -> bytes:
        """
        Convert the TcpFrame into its wire-format bytes:
        [SOF(1)] [DataLength(2)] [Id(4)] [Data...] [CRC(4)]
        """
        sof = bytes([0x01])  # Start-of-frame byte
        length_bytes = self.data_length.to_bytes(2, "little")  # Data length (2 bytes little-endian)

        id_bytes = self.id.to_bytes(4, "little")  # CAN ID (4 bytes little-endian)

        naked_frame = sof + length_bytes + id_bytes + self.data  # Naked frame (without CRC)

        # Calculate CRC32 over naked_frame
        crc_value = zlib.crc32(naked_frame) & 0xFFFFFFFF
        crc_bytes = crc_value.to_bytes(self.LENGTH_OF_CRC, "little")
        return naked_frame + crc_bytes  # Full frame with CRC appended
