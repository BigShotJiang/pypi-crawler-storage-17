# lib-femtican.py

## Environment setup

Consult [DevBook section 10-50.](https://github.com/Femtika/zeta-DevBook/blob/Development/Documents/Chapter%2010.%20General/10-50.%20Python%20Environment.md)

If you have conda installed correctly, run `conda env create` in the root project folder.

### How to build this as a package

Change the package **version** in the **pyproject.toml** file according
to [semantic versioning rules.](https://medium.com/@kodegasm.id/semantic-versioning-in-software-engineering-8bc42c61364b)

Inside a conda environment, run:

`python -m build . --sdist`

### Importing the package

`pip install [path]/femtican-[version].tar.gz`

### Importing the package in Thonny IDE

Tools -> Manage packages -> Install from local file -> locate femtican-[version].tar.gz

## Usage

### Listening to broadcasts

``` python
import time
from femtican import FemticanClient

client = FemticanClient()
# default port is 60200. If you want to use a different IP or port, connect like this:
# e.g. client.connect("172.168.1.2", 50000)
client.connect("cmp.local")

def global_handler(device_id, register_id, value):
    match device_id, register_id:
        case 208, 49:
            print(f"Filtered data {value} from Device: 208, Register: 49")

client.broadcast_handler = global_handler
time.sleep(2)

client.disconnect()
```

### Listening to broadcast (using per-register handlers)

``` python
import time
from femtican import FemticanClient

client = FemticanClient()
client.connect("cmp.local")  # default port: 60200

def aries_handler(device_id, register_id, value):
    print(f"{device_id}-{register_id}----{value} -- aries")

def random_handler(device_id, register_id, value):
    print(f"{device_id}-{register_id}----{value} -- random")

client.add_broadcast_handler(162, 50, aries_handler)
client.add_broadcast_handler(162, 48, random_handler)

# optional: trigger a few broadcasts (example)
for _ in range(10):
    client.trigger_broadcast(162, 50)
    time.sleep(0.05)

# wait for incoming broadcasts
time.sleep(2)

client.remove_broadcast_handler(162, 50)
client.remove_broadcast_handler(162, 48)

client.disconnect()
```

### Triggering a broadcast on a device

``` python
from femtican import FemticanClient

client = FemticanClient()
client.connect("cmp.local")

client.trigger_broadcast(208, 49) # device_id, register_id

client.disconnect()
```

### Setting a value to a register

``` python
from femtican import FemticanClient

client = FemticanClient()
client.connect("cmp.local")

client.set_register(208, 49, 0) # device_id, register_id, value. Value can be text (string), float or None type
client.set_register_index(208, 49, 1, 3.0) # device_id, register_id, index, value. Value can only be float type

client.disconnect()

```

### Error handling

``` python
import time
from femtican import FemticanClient

client = FemticanClient()
client.connect("cmp.local")

def error_handler(error_message):
    print(f"Error: {error_message}")

client.error_handler = error_handler
time.sleep(2)

client.disconnect()
```

### Publishing to PyPI


