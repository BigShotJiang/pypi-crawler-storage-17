"""ORTEX Python SDK - Official SDK for ORTEX Financial Data API.

This SDK provides easy access to ORTEX financial data including:
- Short interest data (shares on loan, utilization, cost to borrow)
- Stock prices (OHLCV data)
- Stock data (free float, shares outstanding, splits)
- Stock scores (quality, value, momentum, growth)
- Options data (expiries, chains, put/call ratios)
- Fundamentals (income, balance, cash flow, ratios)
- Regulatory short interest (EU positions, official SI)
- Market data (earnings, exchanges, macro events, government trades)

Quick Start:
    >>> import ortex
    >>>
    >>> # Set your API key (or use ORTEX_API_KEY environment variable)
    >>> ortex.set_api_key("your-api-key")
    >>>
    >>> # Get short interest data
    >>> df = ortex.get_short_interest("NYSE", "AMC")
    >>>
    >>> # Get stock prices
    >>> df = ortex.get_price("NASDAQ", "AAPL", "2024-01-01", "2024-12-31")

Get your API key at: https://app.ortex.com/apis
Full documentation: https://docs.ortex.com
"""

from __future__ import annotations

__version__ = "1.0.0"
__author__ = "ORTEX Technologies LTD"

from .api import (
    get_balance_sheet,
    get_cash_flow,
    get_client,
    get_close_price,
    get_cost_to_borrow,
    get_days_to_cover,
    get_earnings,
    get_eu_short_positions,
    get_eu_short_total,
    get_exchanges,
    get_financial_ratios,
    get_free_float,
    get_fundamentals_summary,
    get_government_trades,
    get_income_statement,
    get_macro_events,
    get_official_short_interest,
    get_options_chain,
    get_options_expiries,
    get_price,
    get_put_call_ratio,
    get_shares_outstanding,
    get_short_availability,
    get_short_interest,
    get_splits,
    get_stock_scores,
    get_stock_scores_custom,
    get_valuation,
    set_api_key,
)
from .client import OrtexClient
from .exceptions import (
    AuthenticationError,
    NetworkError,
    NotFoundError,
    OrtexError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)

__all__ = [
    # Version
    "__version__",
    # Core
    "OrtexClient",
    # Configuration
    "set_api_key",
    "get_client",
    # Exceptions
    "OrtexError",
    "AuthenticationError",
    "RateLimitError",
    "NotFoundError",
    "ValidationError",
    "ServerError",
    "TimeoutError",
    "NetworkError",
    # Short Interest
    "get_short_interest",
    "get_short_availability",
    "get_cost_to_borrow",
    "get_days_to_cover",
    # Prices
    "get_price",
    "get_close_price",
    # Stock Data
    "get_free_float",
    "get_shares_outstanding",
    "get_splits",
    "get_stock_scores",
    "get_stock_scores_custom",
    # Options
    "get_options_expiries",
    "get_options_chain",
    "get_put_call_ratio",
    # Fundamentals
    "get_income_statement",
    "get_balance_sheet",
    "get_cash_flow",
    "get_financial_ratios",
    "get_fundamentals_summary",
    "get_valuation",
    # Regulatory Short Interest
    "get_eu_short_positions",
    "get_eu_short_total",
    "get_official_short_interest",
    # Market Data
    "get_earnings",
    "get_exchanges",
    "get_macro_events",
    "get_government_trades",
]
