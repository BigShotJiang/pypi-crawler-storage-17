"""ORTEX API functions for retrieving financial data.

This module provides high-level functions for accessing all ORTEX API endpoints.
All functions return pandas DataFrames for easy data manipulation and analysis.
"""

from __future__ import annotations

import os
from datetime import date, datetime
from typing import Any

import pandas as pd

from .client import (
    OrtexClient,
    normalize_date,
    normalize_exchange,
    normalize_ticker,
    to_dataframe,
)
from .exceptions import AuthenticationError

# Global client instance for convenience
_client: OrtexClient | None = None


def set_api_key(api_key: str) -> None:
    """Set the global API key for all ORTEX functions.

    This function sets the API key that will be used by all module-level
    functions. Alternatively, you can set the ORTEX_API_KEY environment
    variable or pass an api_key to each function.

    Args:
        api_key: Your ORTEX API key from https://app.ortex.com/apis

    Example:
        >>> import ortex
        >>> ortex.set_api_key("your-api-key")
        >>> df = ortex.get_short_interest("NYSE", "AMC")
    """
    global _client
    _client = OrtexClient(api_key=api_key)


def get_client(api_key: str | None = None) -> OrtexClient:
    """Get or create an ORTEX client instance.

    Args:
        api_key: Optional API key. If not provided, uses global client
            or ORTEX_API_KEY environment variable.

    Returns:
        OrtexClient instance.

    Raises:
        AuthenticationError: If no API key is available.
    """
    global _client

    if api_key:
        return OrtexClient(api_key=api_key)

    if _client is not None:
        return _client

    # Try environment variable
    env_key = os.environ.get("ORTEX_API_KEY")
    if env_key:
        _client = OrtexClient(api_key=env_key)
        return _client

    raise AuthenticationError(
        "No API key configured. Use ortex.set_api_key('your-key'), "
        "pass api_key parameter, or set ORTEX_API_KEY environment variable. "
        "Get your API key at https://app.ortex.com/apis"
    )


# =============================================================================
# Short Interest Functions
# =============================================================================


def get_short_interest(
    exchange: str,
    ticker: str,
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get short interest data for a stock.

    Retrieves short interest metrics including shares on loan, utilization,
    and short interest percentage of free float.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol (e.g., "AMC", "AAPL").
        start_date: Start date for historical data. If None, returns latest only.
        end_date: End date for historical data. If None, returns up to today.
        api_key: Optional API key override.

    Returns:
        DataFrame with columns:
            - date: Date of the data point
            - sharesOnLoan: Number of shares currently on loan
            - utilization: Percentage of available shares on loan
            - siPercentFloat: Short interest as percentage of free float
            - daysToCovers: Days to cover based on average volume
            - and more...

    Example:
        >>> df = ortex.get_short_interest("NYSE", "AMC")
        >>> df = ortex.get_short_interest("NYSE", "AMC", "2024-01-01", "2024-12-31")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    if start_date is None and end_date is None:
        # Latest data
        endpoint = f"/short/si/{exchange}/{ticker}"
        data = client.get(endpoint)
    else:
        # Historical data
        endpoint = f"/short/si/{exchange}/{ticker}"
        params: dict[str, Any] = {}
        if start_date:
            params["from"] = normalize_date(start_date)
        if end_date:
            params["to"] = normalize_date(end_date)
        data = client.get(endpoint, params=params)

    return to_dataframe(data)


def get_short_availability(
    exchange: str,
    ticker: str,
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get share availability for shorting.

    Retrieves the number of shares available to borrow for short selling.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        start_date: Start date for historical data. If None, returns latest only.
        end_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with columns:
            - date: Date of the data point
            - sharesAvailable: Number of shares available to short

    Example:
        >>> df = ortex.get_short_availability("NYSE", "AMC")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/short/availability/{exchange}/{ticker}"
    params: dict[str, Any] = {}
    if start_date:
        params["from"] = normalize_date(start_date)
    if end_date:
        params["to"] = normalize_date(end_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_cost_to_borrow(
    exchange: str,
    ticker: str,
    loan_type: str = "all",
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get cost to borrow data for short selling.

    Retrieves the annualized cost to borrow shares for short selling.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        loan_type: Type of loans - "all" for all loans, "new" for new loans only.
        start_date: Start date for historical data. If None, returns latest only.
        end_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with columns:
            - date: Date of the data point
            - ctbMin: Minimum cost to borrow (annualized %)
            - ctbAvg: Average cost to borrow (annualized %)
            - ctbMax: Maximum cost to borrow (annualized %)

    Example:
        >>> df = ortex.get_cost_to_borrow("NYSE", "AMC")
        >>> df = ortex.get_cost_to_borrow("NYSE", "AMC", loan_type="new")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    loan_type = loan_type.lower()
    if loan_type not in ("all", "new"):
        loan_type = "all"

    endpoint = f"/short/ctb/{loan_type}/{exchange}/{ticker}"
    params: dict[str, Any] = {}
    if start_date:
        params["from"] = normalize_date(start_date)
    if end_date:
        params["to"] = normalize_date(end_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_days_to_cover(
    exchange: str,
    ticker: str,
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get days to cover data.

    Days to cover represents the number of days it would take to cover
    all short positions based on average daily trading volume.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        start_date: Start date for historical data. If None, returns latest only.
        end_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with columns:
            - date: Date of the data point
            - daysToCover: Days to cover metric

    Example:
        >>> df = ortex.get_days_to_cover("NYSE", "AMC")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/short/dtc/{exchange}/{ticker}"
    params: dict[str, Any] = {}
    if start_date:
        params["from"] = normalize_date(start_date)
    if end_date:
        params["to"] = normalize_date(end_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


# =============================================================================
# Price Functions
# =============================================================================


def get_price(
    exchange: str,
    ticker: str,
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get OHLCV price data for a stock.

    Retrieves open, high, low, close prices and volume data.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        start_date: Start date for historical data. If None, returns latest only.
        end_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with columns:
            - date: Date of the data point
            - open: Opening price
            - high: High price
            - low: Low price
            - close: Closing price
            - volume: Trading volume

    Example:
        >>> df = ortex.get_price("NASDAQ", "AAPL")
        >>> df = ortex.get_price("NASDAQ", "AAPL", "2024-01-01", "2024-12-31")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/stock/ohlcv/{exchange}/{ticker}"
    params: dict[str, Any] = {}
    if start_date:
        params["from"] = normalize_date(start_date)
    if end_date:
        params["to"] = normalize_date(end_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_close_price(
    exchange: str,
    ticker: str,
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get closing price data for a stock.

    Retrieves only the closing price for efficiency when full OHLCV is not needed.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        start_date: Start date for historical data. If None, returns latest only.
        end_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with columns:
            - date: Date of the data point
            - close: Closing price

    Example:
        >>> df = ortex.get_close_price("NASDAQ", "AAPL")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/stock/close/{exchange}/{ticker}"
    params: dict[str, Any] = {}
    if start_date:
        params["from"] = normalize_date(start_date)
    if end_date:
        params["to"] = normalize_date(end_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


# =============================================================================
# Stock Data Functions
# =============================================================================


def get_free_float(
    exchange: str,
    ticker: str,
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get free float data for a stock.

    Free float represents the number of shares available for public trading.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        start_date: Start date for historical data. If None, returns latest only.
        end_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with columns:
            - date: Date of the data point
            - freeFloat: Number of shares in free float

    Example:
        >>> df = ortex.get_free_float("NYSE", "F")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/stock/freefloat/{exchange}/{ticker}"
    params: dict[str, Any] = {}
    if start_date:
        params["from"] = normalize_date(start_date)
    if end_date:
        params["to"] = normalize_date(end_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_shares_outstanding(
    exchange: str,
    ticker: str,
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get shares outstanding data for a stock.

    Shares outstanding is the total number of shares issued by a company.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        start_date: Start date for historical data. If None, returns latest only.
        end_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with columns:
            - date: Date of the data point
            - sharesOutstanding: Total shares outstanding

    Example:
        >>> df = ortex.get_shares_outstanding("NYSE", "F")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/stock/sharesoutstanding/{exchange}/{ticker}"
    params: dict[str, Any] = {}
    if start_date:
        params["from"] = normalize_date(start_date)
    if end_date:
        params["to"] = normalize_date(end_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_splits(
    exchange: str,
    ticker: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get stock split history.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        api_key: Optional API key override.

    Returns:
        DataFrame with columns:
            - date: Date of the split
            - ratio: Split ratio (e.g., 2.0 for 2:1 split)

    Example:
        >>> df = ortex.get_splits("NASDAQ", "AAPL")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/stock/splits/{exchange}/{ticker}"
    data = client.get(endpoint)
    return to_dataframe(data)


def get_stock_scores(
    exchange: str,
    ticker: str,
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get ORTEX stock scores.

    Retrieves quality, value, momentum, and growth scores for a stock.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        start_date: Start date for historical data. If None, returns latest only.
        end_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with columns:
            - date: Date of the scores
            - qualityScore: Quality score (0-100)
            - valueScore: Value score (0-100)
            - momentumScore: Momentum score (0-100)
            - growthScore: Growth score (0-100)
            - overallScore: Combined overall score

    Example:
        >>> df = ortex.get_stock_scores("NYSE", "F")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/stock/scores/{exchange}/{ticker}"
    params: dict[str, Any] = {}
    if start_date:
        params["from"] = normalize_date(start_date)
    if end_date:
        params["to"] = normalize_date(end_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_stock_scores_custom(
    exchange: str,
    ticker: str,
    weights: dict[str, int],
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get ORTEX stock scores with custom weights.

    Retrieves stock scores calculated with your custom weighting.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        weights: Dictionary of score weights. Keys can include:
            - quality: Weight for quality score (0-100)
            - value: Weight for value score (0-100)
            - momentum: Weight for momentum score (0-100)
            - growth: Weight for growth score (0-100)
            Weights should sum to 100.
        start_date: Start date for historical data. If None, returns latest only.
        end_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with custom weighted scores.

    Example:
        >>> weights = {"quality": 50, "momentum": 50}
        >>> df = ortex.get_stock_scores_custom("NYSE", "F", weights)
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/stock/scores/custom/{exchange}/{ticker}"
    params: dict[str, Any] = {"weights": str(weights)}
    if start_date:
        params["from"] = normalize_date(start_date)
    if end_date:
        params["to"] = normalize_date(end_date)

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


# =============================================================================
# Options Functions
# =============================================================================


def get_options_expiries(
    exchange: str,
    ticker: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get available option expiry dates.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        api_key: Optional API key override.

    Returns:
        DataFrame with columns:
            - expiryDate: Available expiry dates

    Example:
        >>> df = ortex.get_options_expiries("NYSE", "F")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/options/expiries/{exchange}/{ticker}"
    data = client.get(endpoint)
    return to_dataframe(data)


def get_options_chain(
    exchange: str,
    ticker: str,
    expiry: str | date | datetime,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get options chain for a specific expiry.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        expiry: Option expiry date.
        api_key: Optional API key override.

    Returns:
        DataFrame with options chain data including:
            - strike: Strike price
            - type: Call or Put
            - bid: Bid price
            - ask: Ask price
            - lastPrice: Last traded price
            - volume: Trading volume
            - openInterest: Open interest
            - impliedVolatility: Implied volatility
            - delta, gamma, theta, vega: Greeks

    Example:
        >>> df = ortex.get_options_chain("NYSE", "F", "2025-01-17")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)
    expiry_str = normalize_date(expiry)

    endpoint = f"/options/chain/{exchange}/{ticker}/{expiry_str}"
    data = client.get(endpoint)
    return to_dataframe(data)


def get_put_call_ratio(
    exchange: str,
    ticker: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get put/call ratio data.

    The put/call ratio indicates market sentiment based on options activity.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        api_key: Optional API key override.

    Returns:
        DataFrame with columns:
            - date: Date
            - putCallRatio: Put/call ratio
            - putVolume: Put option volume
            - callVolume: Call option volume

    Example:
        >>> df = ortex.get_put_call_ratio("NYSE", "F")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/options/pcr/{exchange}/{ticker}"
    data = client.get(endpoint)
    return to_dataframe(data)


# =============================================================================
# Fundamentals Functions
# =============================================================================


def get_income_statement(
    exchange: str,
    ticker: str,
    period: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get income statement data.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        period: Reporting period (e.g., "2024Q3" for Q3 2024, "2024" for annual).
        api_key: Optional API key override.

    Returns:
        DataFrame with income statement line items including:
            - revenue, costOfRevenue, grossProfit
            - operatingExpenses, operatingIncome
            - netIncome, eps, and more

    Example:
        >>> df = ortex.get_income_statement("NYSE", "F", "2024Q3")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/fundamentals/income/{exchange}/{ticker}/{period}"
    data = client.get(endpoint)
    return to_dataframe(data)


def get_balance_sheet(
    exchange: str,
    ticker: str,
    period: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get balance sheet data.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        period: Reporting period (e.g., "2024Q3" for Q3 2024).
        api_key: Optional API key override.

    Returns:
        DataFrame with balance sheet items including:
            - totalAssets, totalLiabilities, totalEquity
            - cash, inventory, receivables
            - longTermDebt, shortTermDebt, and more

    Example:
        >>> df = ortex.get_balance_sheet("NYSE", "F", "2024Q3")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/fundamentals/balance/{exchange}/{ticker}/{period}"
    data = client.get(endpoint)
    return to_dataframe(data)


def get_cash_flow(
    exchange: str,
    ticker: str,
    period: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get cash flow statement data.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        period: Reporting period (e.g., "2024Q3" for Q3 2024).
        api_key: Optional API key override.

    Returns:
        DataFrame with cash flow items including:
            - operatingCashFlow, investingCashFlow, financingCashFlow
            - freeCashFlow, capitalExpenditures
            - dividendsPaid, and more

    Example:
        >>> df = ortex.get_cash_flow("NYSE", "F", "2024Q3")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/fundamentals/cashflow/{exchange}/{ticker}/{period}"
    data = client.get(endpoint)
    return to_dataframe(data)


def get_financial_ratios(
    exchange: str,
    ticker: str,
    period: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get financial ratios.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        period: Reporting period (e.g., "2024Q3" for Q3 2024).
        api_key: Optional API key override.

    Returns:
        DataFrame with financial ratios including:
            - peRatio, pbRatio, psRatio
            - roe, roa, roic
            - debtToEquity, currentRatio
            - grossMargin, netMargin, and more

    Example:
        >>> df = ortex.get_financial_ratios("NYSE", "F", "2024Q3")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/fundamentals/ratios/{exchange}/{ticker}/{period}"
    data = client.get(endpoint)
    return to_dataframe(data)


def get_fundamentals_summary(
    exchange: str,
    ticker: str,
    period: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get fundamentals summary.

    Returns a comprehensive summary of key fundamental metrics.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        period: Reporting period (e.g., "2024Q3" for Q3 2024).
        api_key: Optional API key override.

    Returns:
        DataFrame with summary of key fundamentals.

    Example:
        >>> df = ortex.get_fundamentals_summary("NYSE", "F", "2024Q3")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/fundamentals/summary/{exchange}/{ticker}/{period}"
    data = client.get(endpoint)
    return to_dataframe(data)


def get_valuation(
    exchange: str,
    ticker: str,
    period: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get valuation metrics.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        period: Reporting period (e.g., "2024Q3" for Q3 2024).
        api_key: Optional API key override.

    Returns:
        DataFrame with valuation metrics including:
            - marketCap, enterpriseValue
            - evToRevenue, evToEbitda
            - priceToBook, priceToSales, and more

    Example:
        >>> df = ortex.get_valuation("NYSE", "F", "2024Q3")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/fundamentals/valuation/{exchange}/{ticker}/{period}"
    data = client.get(endpoint)
    return to_dataframe(data)


# =============================================================================
# Regulatory Short Interest Functions
# =============================================================================


def get_eu_short_positions(
    exchange: str,
    ticker: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get EU regulatory short positions.

    Returns disclosed short positions from EU regulatory filings.

    Args:
        exchange: Exchange code (e.g., "XETR" for Germany).
        ticker: Stock ticker symbol.
        api_key: Optional API key override.

    Returns:
        DataFrame with EU short position data including:
            - holder: Name of the position holder
            - position: Short position percentage
            - date: Date of filing

    Example:
        >>> df = ortex.get_eu_short_positions("XETR", "SAP")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/short/regulatory/eu/positions/{exchange}/{ticker}"
    data = client.get(endpoint)
    return to_dataframe(data)


def get_eu_short_total(
    exchange: str,
    ticker: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get total EU regulatory short interest.

    Returns the aggregate short position from EU regulatory filings.

    Args:
        exchange: Exchange code (e.g., "XETR" for Germany).
        ticker: Stock ticker symbol.
        api_key: Optional API key override.

    Returns:
        DataFrame with total EU short interest.

    Example:
        >>> df = ortex.get_eu_short_total("XETR", "SAP")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"/short/regulatory/eu/total/{exchange}/{ticker}"
    data = client.get(endpoint)
    return to_dataframe(data)


def get_official_short_interest(
    ticker: str,
    country: str = "US",
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get official regulatory short interest.

    Returns official short interest data from regulatory bodies (FINRA for US,
    IIROC for Canada, ASIC for Australia, SFC for Hong Kong).

    Args:
        ticker: Stock ticker symbol.
        country: Country code - "US", "CA", "AU", or "HK".
        start_date: Start date for historical data.
        end_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with official short interest data including:
            - settlementDate: Settlement date
            - shortInterest: Short interest shares
            - daysToCover: Days to cover

    Example:
        >>> df = ortex.get_official_short_interest("AMC", "US")
        >>> df = ortex.get_official_short_interest("AMC", "US", "2024-01-01", "2024-12-31")
    """
    client = get_client(api_key)
    ticker = normalize_ticker(ticker)
    country = country.upper()

    endpoint = f"/short/regulatory/official/{ticker}/{country}"
    params: dict[str, Any] = {}
    if start_date:
        params["from"] = normalize_date(start_date)
    if end_date:
        params["to"] = normalize_date(end_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


# =============================================================================
# Market Data Functions
# =============================================================================


def get_earnings(
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get earnings calendar.

    Returns upcoming or historical earnings announcements.

    Args:
        start_date: Start date. If None, returns upcoming earnings.
        end_date: End date.
        api_key: Optional API key override.

    Returns:
        DataFrame with earnings data including:
            - ticker: Stock ticker
            - company: Company name
            - date: Earnings date
            - time: Before market, after market, etc.
            - epsEstimate: Consensus EPS estimate
            - epsActual: Actual EPS (if reported)

    Example:
        >>> df = ortex.get_earnings()  # Upcoming
        >>> df = ortex.get_earnings("2024-12-01", "2024-12-31")  # Historical
    """
    client = get_client(api_key)

    if start_date is None and end_date is None:
        endpoint = "/earnings/upcoming"
        data = client.get(endpoint)
    else:
        endpoint = "/earnings"
        params: dict[str, Any] = {}
        if start_date:
            params["from"] = normalize_date(start_date)
        if end_date:
            params["to"] = normalize_date(end_date)
        data = client.get(endpoint, params=params)

    return to_dataframe(data)


def get_exchanges(
    country: str | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get list of supported exchanges.

    Args:
        country: Optional country filter (e.g., "United States").
        api_key: Optional API key override.

    Returns:
        DataFrame with exchange information including:
            - code: Exchange code (e.g., "NYSE")
            - name: Exchange name
            - country: Country
            - timezone: Timezone

    Example:
        >>> df = ortex.get_exchanges()
        >>> df = ortex.get_exchanges("United States")
    """
    client = get_client(api_key)

    endpoint = "/exchanges"
    params: dict[str, Any] = {}
    if country:
        params["country"] = country

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_macro_events(
    country: str = "US",
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get macroeconomic events calendar.

    Args:
        country: Country code (e.g., "US", "GB", "EU").
        start_date: Start date. If None, returns recent events.
        end_date: End date.
        api_key: Optional API key override.

    Returns:
        DataFrame with macro events including:
            - event: Event name
            - date: Event date
            - time: Event time
            - actual: Actual value (if released)
            - forecast: Forecast value
            - previous: Previous value
            - impact: Expected market impact (low/medium/high)

    Example:
        >>> df = ortex.get_macro_events("US")
        >>> df = ortex.get_macro_events("US", "2024-12-01", "2024-12-15")
    """
    client = get_client(api_key)
    country = country.upper()

    if start_date is None and end_date is None:
        endpoint = f"/macro/events/recent/{country}"
        data = client.get(endpoint)
    else:
        endpoint = f"/macro/events/{country}"
        params: dict[str, Any] = {}
        if start_date:
            params["from"] = normalize_date(start_date)
        if end_date:
            params["to"] = normalize_date(end_date)
        data = client.get(endpoint, params=params)

    return to_dataframe(data)


def get_government_trades(
    start_date: str | date | datetime | None = None,
    end_date: str | date | datetime | None = None,
    ticker: str | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get US government official stock trades.

    Returns disclosed stock trades by US government officials.

    Args:
        start_date: Start date for trade search.
        end_date: End date for trade search.
        ticker: Optional filter by stock ticker.
        api_key: Optional API key override.

    Returns:
        DataFrame with government trade data including:
            - politician: Name of the official
            - party: Political party
            - ticker: Stock ticker
            - type: Buy or Sell
            - amount: Trade amount range
            - date: Trade date

    Example:
        >>> df = ortex.get_government_trades()  # Recent trades
        >>> df = ortex.get_government_trades("2024-12-01", "2024-12-31", "AAPL")
    """
    client = get_client(api_key)

    endpoint = "/government/trades"
    params: dict[str, Any] = {}
    if start_date:
        params["from"] = normalize_date(start_date)
    if end_date:
        params["to"] = normalize_date(end_date)
    if ticker:
        params["ticker"] = normalize_ticker(ticker)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)
