# ORTEX Python SDK

Official Python SDK for the ORTEX Financial Data API. Access comprehensive financial data including short interest, stock prices, options, fundamentals, and more.

[![PyPI version](https://badge.fury.io/py/ortex.svg)](https://pypi.org/project/ortex/)
[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Features

- **Short Interest Data** - Shares on loan, utilization, cost to borrow, days to cover
- **Stock Prices** - OHLCV data with historical support
- **Stock Data** - Free float, shares outstanding, splits, ORTEX scores
- **Options Data** - Expiry dates, full option chains, put/call ratios
- **Fundamentals** - Income statements, balance sheets, cash flow, ratios
- **Regulatory Short Interest** - EU positions, official SI (US/CA/AU/HK)
- **Market Data** - Earnings calendar, macro events, government trades

## Installation

```bash
pip install ortex
```

## Quick Start

### Get Your API Key

Get your API key at **[app.ortex.com/apis](https://app.ortex.com/apis)**

### Set Up Authentication

```python
import ortex

# Option 1: Set API key directly
ortex.set_api_key("your-api-key")

# Option 2: Use environment variable
# export ORTEX_API_KEY="your-api-key"
# The SDK will automatically use this

# Option 3: Pass to each function
df = ortex.get_short_interest("NYSE", "AMC", api_key="your-api-key")
```

### Basic Usage

```python
import ortex

ortex.set_api_key("your-api-key")

# Get latest short interest data
df = ortex.get_short_interest("NYSE", "AMC")
print(df)

# Get historical short interest
df = ortex.get_short_interest("NYSE", "AMC", "2024-01-01", "2024-12-31")

# Get stock prices
df = ortex.get_price("NASDAQ", "AAPL", "2024-01-01", "2024-12-31")

# Get options chain
df = ortex.get_options_chain("NYSE", "F", "2025-01-17")
```

## All Available Functions

### Short Interest

```python
# Latest short interest data
df = ortex.get_short_interest("NYSE", "AMC")

# Historical short interest
df = ortex.get_short_interest("NYSE", "AMC", "2024-01-01", "2024-12-31")

# Share availability for shorting
df = ortex.get_short_availability("NYSE", "AMC")

# Cost to borrow (all loans)
df = ortex.get_cost_to_borrow("NYSE", "AMC")

# Cost to borrow (new loans only)
df = ortex.get_cost_to_borrow("NYSE", "AMC", loan_type="new")

# Days to cover
df = ortex.get_days_to_cover("NYSE", "AMC")
```

### Stock Prices

```python
# Full OHLCV data
df = ortex.get_price("NASDAQ", "AAPL")
df = ortex.get_price("NASDAQ", "AAPL", "2024-01-01", "2024-12-31")

# Close price only (more efficient)
df = ortex.get_close_price("NASDAQ", "AAPL")
```

### Stock Data

```python
# Free float shares
df = ortex.get_free_float("NYSE", "F")

# Shares outstanding
df = ortex.get_shares_outstanding("NYSE", "F")

# Stock splits history
df = ortex.get_splits("NASDAQ", "AAPL")

# ORTEX stock scores
df = ortex.get_stock_scores("NYSE", "F")

# Custom weighted scores
weights = {"quality": 50, "momentum": 50}
df = ortex.get_stock_scores_custom("NYSE", "F", weights)
```

### Options

```python
# Available expiry dates
df = ortex.get_options_expiries("NYSE", "F")

# Full options chain for an expiry
df = ortex.get_options_chain("NYSE", "F", "2025-01-17")

# Put/call ratio
df = ortex.get_put_call_ratio("NYSE", "F")
```

### Fundamentals

```python
# Income statement
df = ortex.get_income_statement("NYSE", "F", "2024Q3")

# Balance sheet
df = ortex.get_balance_sheet("NYSE", "F", "2024Q3")

# Cash flow statement
df = ortex.get_cash_flow("NYSE", "F", "2024Q3")

# Financial ratios
df = ortex.get_financial_ratios("NYSE", "F", "2024Q3")

# Fundamentals summary
df = ortex.get_fundamentals_summary("NYSE", "F", "2024Q3")

# Valuation metrics
df = ortex.get_valuation("NYSE", "F", "2024Q3")
```

### Regulatory Short Interest

```python
# EU short positions (individual holders)
df = ortex.get_eu_short_positions("XETR", "SAP")

# EU total short interest
df = ortex.get_eu_short_total("XETR", "SAP")

# Official regulatory short interest (US, CA, AU, HK)
df = ortex.get_official_short_interest("AMC", "US")
df = ortex.get_official_short_interest("AMC", "US", "2024-01-01", "2024-12-31")
```

### Market Data

```python
# Upcoming earnings
df = ortex.get_earnings()

# Historical earnings
df = ortex.get_earnings("2024-12-01", "2024-12-31")

# List of exchanges
df = ortex.get_exchanges()
df = ortex.get_exchanges("United States")

# Macro economic events
df = ortex.get_macro_events("US")
df = ortex.get_macro_events("US", "2024-12-01", "2024-12-15")

# US government official trades
df = ortex.get_government_trades()
df = ortex.get_government_trades("2024-12-01", "2024-12-31", ticker="AAPL")
```

## Using the Client Directly

For more control, use the `OrtexClient` class:

```python
from ortex import OrtexClient

# Create client
client = OrtexClient(api_key="your-api-key")

# Make requests
data = client.get("/short/si/NYSE/AMC")

# Use as context manager
with OrtexClient(api_key="your-api-key") as client:
    data = client.get("/stock/ohlcv/NASDAQ/AAPL")
```

## Date Handling

The SDK accepts dates in multiple formats:

```python
from datetime import date, datetime

# String format (YYYY-MM-DD)
df = ortex.get_short_interest("NYSE", "AMC", "2024-01-01", "2024-12-31")

# Python date objects
df = ortex.get_short_interest("NYSE", "AMC", date(2024, 1, 1), date(2024, 12, 31))

# Python datetime objects
df = ortex.get_short_interest("NYSE", "AMC", datetime(2024, 1, 1), datetime(2024, 12, 31))
```

## Error Handling

The SDK provides specific exception types:

```python
import ortex
from ortex import (
    OrtexError,
    AuthenticationError,
    RateLimitError,
    NotFoundError,
    ValidationError,
    ServerError,
)

try:
    df = ortex.get_short_interest("NYSE", "INVALID")
except AuthenticationError:
    print("Invalid API key")
except RateLimitError as e:
    print(f"Rate limited. Retry after {e.retry_after} seconds")
except NotFoundError:
    print("Stock not found")
except ValidationError as e:
    print(f"Invalid parameters: {e}")
except ServerError:
    print("ORTEX server error")
except OrtexError as e:
    print(f"API error: {e}")
```

## Rate Limiting

The SDK automatically handles rate limiting with exponential backoff:

- Automatically retries on 429 (rate limit) responses
- Uses exponential backoff (1s, 2s, 4s, 8s, up to 60s)
- Maximum 5 retry attempts by default

Configure retry behavior:

```python
from ortex import OrtexClient

client = OrtexClient(
    api_key="your-api-key",
    timeout=60,      # Request timeout in seconds
    max_retries=10,  # Maximum retry attempts
)
```

## All Return Values are DataFrames

All functions return pandas DataFrames for easy analysis:

```python
import ortex

df = ortex.get_short_interest("NYSE", "AMC", "2024-01-01", "2024-12-31")

# Standard pandas operations
print(df.columns)
print(df.describe())
df.to_csv("short_interest.csv")

# Filter and analyze
high_utilization = df[df["utilization"] > 90]
```

## Documentation

- **Full API Documentation**: [docs.ortex.com](https://docs.ortex.com)
- **Get API Key**: [app.ortex.com/apis](https://app.ortex.com/apis)
- **Support**: support@ortex.com

## Requirements

- Python 3.12+
- pandas >= 2.0.0
- requests >= 2.31.0
- tenacity >= 8.2.0

## License

MIT License - ORTEX Technologies LTD

## Version

1.0.0
