#!/bin/bash
#uv run maturin build --release --features extension-module
maturin build --release --features extension-module
