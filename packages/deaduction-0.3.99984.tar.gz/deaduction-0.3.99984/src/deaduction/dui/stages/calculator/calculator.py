"""
calculator.py : provide the Calculator and CalculatorWindow class.

The calculator enables usr to construct mathematical objects that will be
translated into Lean code. The interface tries to echo the global interface,
with
- a target area where the object under construction is shown; this is a
QTextEdit whose keyEvents are hacked to call buttons.
- ButtonGroups, where each button allows to insert some math patterns.
There are 3 kinds of buttons:
    (1) Usual buttons are provided by the Node class
e.g. 1, +, <=>, and so on
    (2) Context buttons are associated to context objects
    (3) Definitions buttons are associated to definitions from the current Lean
    file. These are built from Lean constants, the condition for a constant
    to gives rise to a button is to be present both in a definition statement
    of the currentLean file, and in one of the PatternMathDisplay
    dictionaries.

Furthermore, there are a special button who are associated to
GENERIC_APPLICATION, whose symbol is f(·). When pushed,
the calculator tried to insert an APPLICATION pattern: for instance if the
context contain local constants u and f, respectively a sequence and a
function, and if selected object in target is u or f, then it will be
replaced by APP(f, ,?) or APP(u, ?).

Every button has a shortcut, which is either set "manually" or computed
automatically.

Author(s)     : Frédéric Le Roux frederic.le-roux@imj-prg.fr
Maintainer(s) : Frédéric Le Roux frederic.le-roux@imj-prg.fr
Created       : 06 2023 (creation)
Repo          : https://github.com/dEAduction/dEAduction

Copyright (c) 2023 the d∃∀duction team

This file is part of d∃∀duction.

    d∃∀duction is free software: you can redistribute it and/or modify it under
    the terms of the GNU General Public License as published by the Free
    Software Foundation, either version 3 of the License, or (at your option)
    any later version.

    d∃∀duction is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details.

    You should have received a copy of the GNU General Public License along
    with dEAduction.  If not, see <https://www.gnu.org/licenses/>.
"""
# from deaduction.pylib.math_display.pattern_data import is_type

if __name__ == '__main__':
    from deaduction.dui.__main__ import language_check
    language_check()


import logging

from PySide2.QtCore import Signal, Slot, Qt, QTimer, QSettings
from PySide2.QtGui     import  QKeySequence, QIcon
from PySide2.QtWidgets import (QApplication, QWidget,
                               QSizePolicy, QScrollArea,
                               QHBoxLayout, QVBoxLayout, QGridLayout, QToolBar,
                               QAction, QDialog, QGroupBox, QMainWindow,
                               QTabWidget)

import deaduction.pylib.config.dirs as cdirs
import deaduction.pylib.config.vars as cvars
from deaduction.pylib.actions import MissingCalculatorOutput
from deaduction.pylib.actions.exceptions import CalculatorRequest

from deaduction.pylib.math_display import MathDisplay
from deaduction.pylib.math_display.nodes import (Node, LogicalNode,
                                                 SetTheoryNode, FunctionNode,
                                                 NumberNode, InequalityNode
                                                 )

from deaduction.pylib.mathobj import MathObject
from deaduction.pylib.pattern_math_obj import (PatternMathObject,
                                               MetaVar)

from deaduction.pylib.marked_pattern_math_object import (MarkedPatternMathObject,
                                                         MarkedMetavar,
                                                         CalculatorPatternLines)

# from deaduction.dui.primitives.base_math_widgets_styling import MathTextWidget
from deaduction.dui.primitives import (DisclosureTitleWidget,
                                       DeaductionTutorialDialog)

from deaduction.dui.stages.calculator.calculator_targets import (
    CalculatorTargets)
from deaduction.dui.stages.calculator.calculator_button import CalculatorButton


global _
log = logging.getLogger(__name__)

if __name__ == "__main__":
    from deaduction.pylib import logger
    logger.configure(domains="deaduction",
                     display_level="debug",
                     filename=None)


Node.PatternMathObject = PatternMathObject
Node.MarkedPatternMathObject = MarkedPatternMathObject


class AbstractToolBar(QToolBar):

    def animate_click(self, action: QAction):
        """
        Simulate a click on the tool button corresponding to the QAction.
        """
        button = self.widgetForAction(action)
        button.animateClick(100)


class CalculatorToolbar(AbstractToolBar):
    def __init__(self):
        super().__init__()
        icons_dir = cdirs.icons

        # TODO: implement tooltips for shortcuts
        undo_shortcut = QKeySequence.keyBindings(QKeySequence.Undo)[0].toString()
        redo_shortcut = QKeySequence.keyBindings(QKeySequence.Redo)[0].toString()
        self.rewind = QAction(QIcon(str((icons_dir /
                                     'goback-begining.png').resolve())),
                _('Undo all'), self)
        self.undo_action = QAction(QIcon(str((icons_dir /
                                          'undo_action.png').resolve())),
                _('Undo'), self)
        self.redo_action = QAction(QIcon(str((icons_dir /
                                          'redo_action.png').resolve())),
                _('Redo'), self)
        self.go_to_end = QAction(QIcon(str((icons_dir /
                                            'go-end-96.png').resolve())),
                _('Redo all'), self)

        self.addAction(self.rewind)
        self.addAction(self.undo_action)
        self.addAction(self.redo_action)
        self.addAction(self.go_to_end)


class NavigationBar(AbstractToolBar):
    """
    A toolbar with navigation buttons: left, right, delete arrows.
    """
    def __init__(self):
        super().__init__()
        # self.setLayoutDirection(Qt.RightToLeft)

        icons_dir = cdirs.icons
        beg_path = str((icons_dir / 'icons8-double-left-48.png').resolve())

        # TODO: implement tooltips for shortcuts
        # beginning_shortcut = QKeySequence.keyBindings(
        #     QKeySequence.MoveToPreviousWord)[0].toString()
        # beginning_shortcut = f"({_('type')} {beginning_shortcut})"
        #
        # left_shortcut = QKeySequence.keyBindings(
        #     QKeySequence.MoveToPreviousChar)[0].toString()
        # right_shortcut = QKeySequence.keyBindings(
        #     QKeySequence.MoveToNextChar)[0].toString()
        # end_shortcut = QKeySequence.keyBindings(
        #     QKeySequence.MoveToNextWord)[0].toString()
        # delete_shortcut = QKeySequence.keyBindings(
        #     QKeySequence.Delete)[0].toString()
        self.beginning_action = QAction(QIcon(beg_path),
                                        _('Go to beginning'),
                                        self)

        left_path = str((icons_dir / 'icons8-back-48.png').resolve())
        self.left_action = QAction(QIcon(left_path), _('Move left'), self)

        up_path = str((icons_dir / 'icons8-expand-48.png').resolve())
        self.up_action = QAction(QIcon(up_path), _('Expand selection'), self)

        down_path = str((icons_dir / 'icons8-shrink-48.png').resolve())
        self.down_action = QAction(QIcon(down_path), _('Shrink selection'),
                                   self)

        right_path = str((icons_dir / 'icons8-forward-48.png').resolve())
        self.right_action = QAction(QIcon(right_path), _('Move right'), self)

        end_path = str((icons_dir / 'icons8-double-right-48.png').resolve())
        self.end_action = QAction(QIcon(end_path), _('Go to end'), self)

        self.delete = QAction(QIcon(str((icons_dir /
                                         'icons8-clear-48.png').resolve())),
                              _('Delete selected block'), self)

        self.addAction(self.beginning_action)
        self.addAction(self.left_action)
        # self.addAction(self.up_action)
        self.addAction(self.right_action)
        self.addAction(self.end_action)
        self.addSeparator()
        self.addAction(self.up_action)
        self.addAction(self.down_action)
        self.addSeparator()
        self.addAction(self.delete)


class CalculatorButtonsGroup(QWidget):
    """
    A widget to display a list of CalculatorButtons, with a title and a
    disclosure triangle.
    """

    # TODO: API for including new (e.g. context) buttons on the fly.

    col_size = 5

    def __init__(self, title, calculator_buttons: [CalculatorButton],
                 col_size=None, hidden=False):

        super().__init__()
        # self.setFocusPolicy(Qt.NoFocus)
        self.title = title
        self.group_box = QGroupBox()

        # Title widget #
        self.title_widget = DisclosureTitleWidget(title=self.title,
                                                  hidden=hidden)
        self.title_widget.clicked.connect(self.set_hidden)

        # Buttons widget #
        if col_size:
            self.col_size = col_size
        self.buttons = []
        self.buttons_layout = QGridLayout()
        self.set_buttons(calculator_buttons)
        # for btn in calculator_buttons:
        #     self.add_button(btn)

        self.margin_btns_lyt = QHBoxLayout()
        self.margin_btns_lyt.addStretch()
        self.margin_btns_lyt.addLayout(self.buttons_layout)
        self.margin_btns_lyt.addStretch()

        # Fill-in main layout
        group_box_layout = QVBoxLayout()
        group_box_layout.addLayout(self.margin_btns_lyt)
        self.group_box.setLayout(group_box_layout)

        main_lyt = QVBoxLayout()
        main_lyt.setSpacing(0)
        main_lyt.setContentsMargins(0, 0, 0, 0)

        main_lyt.addWidget(self.title_widget)
        main_lyt.addWidget(self.group_box)
        self.setLayout(main_lyt)

        if self.title_widget.hidden:
            self.toggle_buttons()

    @property
    def hidden(self):
        return self.title_widget.hidden

    @hidden.setter
    def hidden(self, yes):
        self.title_widget.hidden = yes

    # def init_btns_lyt(self):
    #     # TODO: clear lyt
    #
    #     calculator_buttons = self.buttons
    #     self.buttons = []
    #     for btn in calculator_buttons:
    #         self.add_button(btn)

    def remove_all_shortcuts(self):
        for button in self.buttons:
            button.remove_shortcut()  # Remove from shortcut_dic

    def remove_all_buttons(self):
        # log.debug("Removing bv buttons...")
        item = self.buttons_layout.takeAt(0)
        while item:
            button = item.widget()
            if button:
                log.debug(button.text())
                # button.remove_shortcut()  # Remove from shortcut_dic
                button.hide()
                button.deleteLater()
            item = self.buttons_layout.takeAt(0)

    def add_button(self, button: CalculatorButton):
        line = len(self.buttons) // self.col_size
        col = len(self.buttons) - (line * self.col_size)
        self.buttons_layout.addWidget(button, line, col)
        self.buttons.append(button)

    def set_buttons(self, calculator_buttons: [CalculatorButton]):
        self.remove_all_buttons()
        for btn in calculator_buttons:
            self.add_button(btn)

    def remove_button(self, button):
        self.buttons_layout.removeWidget(button)
        self.buttons.remove(button)
        button.hide()

    def patterns(self):
        """
        List of all patterns from buttons in the group.
        """
        patterns = []
        for button in self.buttons:
            patterns.extend(button.patterns)
        return patterns

    @classmethod
    def from_node_subclass(cls, node_class, col_size=4):
        """
        Construct a CalculatorButtonsGroup from instances of a Node subclass.
        Here node_class should be for instance LogicalNode.
        """
        buttons = [CalculatorButton.from_node(node)
                   for node in node_class.calculator_nodes]
        buttons_group = cls(title=node_class.name(),
                            calculator_buttons=buttons,
                            col_size=col_size)
        return buttons_group

    @classmethod
    def from_calculator_pattern_lines(cls, calc_pattern):
        buttons = []
        # If more than one line, then col_size = length of first line
        col_size = (len(calc_pattern.latex_symbols[0]) if len(
            calc_pattern.latex_symbols) > 1
                    else None)
        for btn_symbols, latex_symbols in zip(calc_pattern.button_symbols,
                                              calc_pattern.latex_symbols):
            for symbol, latex in zip(btn_symbols, latex_symbols):
                # print(f"Creating button {symbol}, {latex}")
                buttons.append(CalculatorButton(latex_symbol=latex,
                                                button_symbol=symbol))

        buttons_group = cls(title=calc_pattern.title,
                            calculator_buttons=buttons,
                            col_size=col_size)
        return buttons_group

    @classmethod
    def from_bound_vars(cls, bound_vars):
        title = CalculatorPatternLines.bound_vars_title
        buttons = [CalculatorButton.from_math_object(bound_var)
                   for bound_var in bound_vars]
        btn_group = cls(title=title,
                        calculator_buttons=buttons)
        return btn_group

    def deleteLater(self):
        bad_keys = [key for key, button in CalculatorButton.shortcuts_dic
                    if button in self.buttons]
        for key in bad_keys:
            CalculatorButton.shortcuts_dic.pop(key)
        super().deleteLater()

    def toggle_buttons(self):
        self.title_widget.set_hidden(self.hidden)
        if self.hidden:
            self.group_box.hide()
            for button in self.buttons:
                button.hide()
        else:
            self.group_box.show()
            for button in self.buttons:
                button.show()

    def set_hidden(self, hidden=None):
        if hidden is None:
            self.hidden = not self.hidden
        else:
            self.hidden = hidden
        self.toggle_buttons()


class CalculatorTabButtonWidget(QTabWidget):
    """
    A class to display two instances of CalculatorAllButtons,
    a complete one and a simplified one.
    """
    send_pattern = Signal(list, str)
    # targets_window: CalculatorTargets = None
    # controller = None  # Set by CalculatorController
    targets_window_is_closed = False

    # We always need app pattern (e.g. to get f(x) ) and parentheses
    app_pats = FunctionNode.application.marked_pattern_math_objects()
    application_pattern = app_pats[0]
    par_pats = NumberNode.parentheses.marked_pattern_math_objects()
    parentheses_pattern = par_pats[0]

    def __init__(self, calc_patterns: [CalculatorPatternLines],
                 node_classes=None,
                 only_numbers=False):
        """
        If only_numbers is True then the simplified tab will be selected.
        node_classes is the list of names of node classes that should be
        displayed in the complete tab.
        """
        super().__init__()

        # Set CalculatorButton shortcuts dict:
        self.shortcuts_dic = dict()
        CalculatorButton.shortcuts_dic = self.shortcuts_dic
        CalculatorButton.original_shortcuts_dic = dict()

        self.complete_widget = CalculatorAllButtons(calc_patterns,
                                                    node_classes=node_classes)

        # In simple mode, no bounded vars and no defs
        simple_calc_patterns = [cp for cp in calc_patterns
                                if cp.tag not in cp.complex_tags]
        self.simple_widget = CalculatorAllButtons(simple_calc_patterns,
                                                  only_numbers=True)

        self.addTab(self.simple_widget, _("Number mode"))
        self.addTab(self.complete_widget, _("Full mode"))

        if only_numbers:
            self.setCurrentIndex(0)
        else:
            self.setCurrentIndex(1)

        # Connect signals
        self.complete_widget.send_pattern.connect(self.send_pattern)
        self.simple_widget.send_pattern.connect(self.send_pattern)

    def closeEvent(self, event):
        if not self.targets_window_is_closed:
            event.ignore()
        else:
            super().closeEvent(event)


class CalculatorAllButtons(QWidget):
    """
    A class to display groups of CalculatorButtons, with a vertical scroll bar.
    Each Button, when clicked, emit the btn_send_pattern signal, which is
    connected to CalculatorAllButtons.process_click, which in turn emit the
    CalculatorAllButtons.send_pattern signal, which is connected to
    CalculatorController.insert_pattern() method:
    CalculatorButton.btn_process_click
        --> CalculatorButton.btn_send_pattern signal
        --> CalculatorAllButtons.process_click
        --> CalculatorAllButtons.send_pattern signal
        --> CalculatorController.insert_pattern():
    """

    send_pattern = Signal(list, str)

    def __init__(self, calc_patterns: [CalculatorPatternLines],
                 node_classes=None,
                 only_numbers=False):
        """
        If only_numbers is True then only nodes pertinent to enter a number
        are displayed. Otherwise, node_classes is the list of names of node
        classes that should be displayed.
        """
        super().__init__()
        self.setAttribute(Qt.WA_AlwaysShowToolTips, True)
        self.setWindowFlag(Qt.WindowStaysOnTopHint, True)
        self.setWindowTitle(_("Logical Calculator") + " — d∃∀duction")
        # self.setFocusPolicy(Qt.NoFocus)  --> Buttons cannot be clicked!
        self.buttons_groups = []

        main_lyt = QVBoxLayout()

        ###############
        # Add buttons #
        ###############
        self.btns_wgt = QWidget()

        # (1) Lines from pattern_lines
        for calc_pattern in calc_patterns:
            # Avoid empty context (except for bound vars)
            if (calc_pattern.tag != 'bound vars'
                    and all(not line for line in calc_pattern.latex_symbols)):
                continue

            buttons = CalculatorButtonsGroup.from_calculator_pattern_lines(
                calc_pattern)
            if buttons:
                self.buttons_groups.append(buttons)

        # (2) Lines from nodes
        if only_numbers:
            node_classes = ["numbers", "inequalities"]
        for node_name, NodeClass, col_size in (
                ("logic", LogicalNode, 5),
                ("sets", SetTheoryNode, 5),
                ("functions", FunctionNode, 5),
                ("numbers", NumberNode, 4),
                ("inequalities", InequalityNode, 5)):
            # TODO: add settings test on buttons name
            if (not node_classes) or node_name in node_classes:
                buttons = CalculatorButtonsGroup.from_node_subclass(NodeClass,
                                                                    col_size)
                self.buttons_groups.append(buttons)

        self.btns_lyt = QVBoxLayout()
        self.set_buttons()
        self.btns_wgt.setLayout(self.btns_lyt)

        self.btns_scroll_area = QScrollArea()
        self.btns_scroll_area.setWidgetResizable(True)
        # self.btns_scroll_area.setSizePolicy(QSizePolicy.Expanding)
        self.btns_scroll_area.setWidget(self.btns_wgt)

        main_lyt.addWidget(self.btns_scroll_area)
        self.setLayout(main_lyt)

        # Connect button signals
        for btn in self.buttons():
            btn.btn_send_pattern.connect(self.process_clic)

        self.set_geometry()

    def set_buttons(self):
        btns_lyt = self.btns_lyt
        idx = 0
        for btns in self.buttons_groups:
            if idx:
                btns_lyt.addSpacing(20)
            btns_lyt.addWidget(btns)
            idx += 1
        btns_lyt.addStretch()

    def set_geometry(self, geometry=None):
        settings = QSettings("deaduction")
        value = settings.value("calculator/geometry")
        if value:
            self.restoreGeometry(value)
        elif geometry:
            self.setGeometry(geometry)

        for buttons in self.buttons_groups:
            hidden = settings.value(f"calculator/{buttons.title}",
                                    buttons.hidden)
            hidden = (hidden in (True, "true"))
            # if buttons.hidden != hidden:
            #     buttons.hidden = not hidden
            #     buttons.toggle_buttons()
            # else:
            buttons.set_hidden(hidden=hidden)

    def closeEvent(self, event):
        if not self.targets_window_is_closed:
            event.ignore()
        else:
            super().closeEvent(event)

    def close(self):
        # Save window geometry
        settings = QSettings("deaduction")
        settings.setValue("calculator/geometry", self.saveGeometry())

        # Save states of disclosure triangles
        for buttons in self.buttons_groups:
            settings.setValue(f"calculator/{buttons.title}",
                              buttons.hidden)
        super().close()
        # print("Buttons wd closed!")
        # self.window_closed.emit()

    def buttons(self) -> [CalculatorButton]:
        btns = []
        for buttons_group in self.buttons_groups:
            btns.extend(buttons_group.buttons)
        return btns

    @Slot()
    def process_clic(self, pattern, symbol):
        self.send_pattern.emit(pattern, symbol)

    def bound_var_group(self):
        for group in self.buttons_groups:
            if group.title == CalculatorPatternLines.bound_vars_title:
                return group

    def add_button(self,
                   buttons_group: CalculatorButtonsGroup,
                   button: CalculatorButton):
        """
        Add a new button to the specified button groups.
        """
        buttons_group.add_button(button)
        button.btn_send_pattern.connect(self.process_clic)


class CalculatorMainWindow(QDialog):
    """
    The main window, which display the targets widget and the calculator
    buttons,
        - either side by side, if horizontal mode is True,
        - or the targets below, if horizontal mode is False.
    """
    def __init__(self, window_title,
                 targets_widget: QWidget,
                 calculator_widget: QWidget,
                 horizontal_mode=True):
        super().__init__()
        CalculatorButton.calculator_window = self

        self.setWindowTitle(window_title + " — d∃∀duction")
        self.setWindowModality(Qt.WindowModal)

        self.targets_widget = targets_widget
        self.calculator_widget = calculator_widget

        # Set size policies.
        sp = targets_widget.sizePolicy()
        sp.setHorizontalStretch(2)
        sp.setVerticalStretch(1)
        targets_widget.setSizePolicy(sp)

        sp = calculator_widget.sizePolicy()
        sp.setHorizontalPolicy(QSizePolicy.MinimumExpanding)
        sp.setHorizontalStretch(1)
        sp.setVerticalStretch(3)
        calculator_widget.setSizePolicy(sp)

        self.targets_widget.button_box.accepted.connect(self.close_n_accept)

        self.geometry_mode = ("horizontal_mode" if horizontal_mode
                              else "vertical_mode")
        if horizontal_mode:
            lyt = QHBoxLayout()
            lyt.addWidget(self.targets_widget)
            lyt.addWidget(self.calculator_widget)
        else:
            lyt = QVBoxLayout()
            lyt.addWidget(self.calculator_widget)
            lyt.addWidget(self.targets_widget)

        self.setLayout(lyt)

        self.set_geometry()

    def set_geometry(self):
        """
        Restore saved position for horizontal or vertical mode.
        """
        settings = QSettings("deaduction")
        key = "calculator_window/position/" + self.geometry_mode
        value = settings.value(key)
        if value:
            # self.move(value)
            try:
                self.restoreGeometry(value)
            except TypeError:
                pass
    #     # Resize height window to minimum, but not width
    #     self.setMinimumWidth(self.width())
    #     QTimer.singleShot(1, self.update_size)

    def close(self):
        # Save window geometry
        settings = QSettings("deaduction")
        key = "calculator_window/position/" + self.geometry_mode
        # settings.setValue(key, self.pos())
        settings.setValue(key, self.saveGeometry())
        self.calculator_widget.close()

    def close_n_accept(self):
        self.close()
        self.accept()

    def reject(self):
        self.close()
        super().reject()


class CalculatorController:
    """
    The calculator controller. This is initiated with
    - a MarkedPatternMathObject, typically just a Metavar, that stands for
    the object under construction.
    - a dictionary of CalculatorGroup instances, that is used to build the
    various buttons groups. This is in general empty, since buttons are
    automatically generated:
        - context and definition buttons, in __init__()
        - standard buttons, in CalculatorWidget.

    Note that the targets are entirely managed from the CalculatorController,
    and not at the CalculatorTargets level.
    """

    _target: MarkedPatternMathObject
    targets_widget: CalculatorTargets

    ################
    # init methods #
    ################

    def __init__(self,
                 targets,
                 are_math_type,
                 goal=None,
                 window_title="Logical Calculator",
                 task_title=None,
                 titles=None,
                 task_goal=None,
                 prop=None):
        """

        @param targets: list of targets (or type, as indicated by
        are_math_type) to be filled by usr
        @param goal: the current goal
        @param window_title:
        @param task_title:
        @param titles: titles corresponding to target types
        @param task_goal:
        @param prop:
        """
        self.goal = goal
        self.targets = []
        self.are_math_type = are_math_type
        self.pre_targets = targets
        self.calculator_groups = []
        nb = len(targets)
        # One history empty list per target, but they must be distinct lists!
        self.histories: [[MarkedPatternMathObject]] = []
        for idx in range(nb):
            self.histories.append([])
        # First target history will be updated immediately (so set at -1)
        self.history_indices = [0] * nb

        targets_widget = CalculatorTargets(targets=targets,
                                           # are_math_type=are_math_type,
                                           titles=titles,
                                           task_title=task_title,
                                           # task_description=task_description,
                                           task_goal=task_goal,
                                           prop=prop)
        self.targets_widget = targets_widget
        self.status_bar.proof_msg = self.help_msg

        focus_changed = QApplication.instance().focusChanged
        focus_changed.connect(targets_widget.on_focus_changed)
        focus_has_changed = targets_widget.focus_has_changed
        focus_has_changed.connect(self.target_focus_has_changed)

        ######################
        # Calculator Buttons #
        ######################
        # Context buttons #
        if goal:
            context = goal.context_objects
            context_line = CalculatorPatternLines.from_context(context)
            if context_line.latex_symbols:
                self.calculator_groups.extend([context_line])
            # Compute applications on ContextMathObjects:
            MarkedPatternMathObject.populate_applications_from_context(context)

        bound_vars_line = CalculatorPatternLines.bound_vars()
        self.calculator_groups.extend([bound_vars_line])

        # if calculator_groups:
        #     self.calculator_groups.extend(calculator_groups)

        # Definition buttons #
        cpls = CalculatorPatternLines.constants_from_definitions(
            only_numbers=self.targets_are_numbers)
        self.calculator_groups.extend(cpls)

        # User interface #
        self.buttons_window = CalculatorTabButtonWidget(
            self.calculator_groups, only_numbers=self.targets_are_numbers)
        self.__set_targets()
        self.__init_multiple_signals()
        self.buttons_window.send_pattern.connect(self.insert_pattern)

        h_mode = True if self.targets_widget.task_widget else False
        self.main_window = CalculatorMainWindow(window_title,
                                                self.targets_widget,
                                                self.buttons_window,
                                                horizontal_mode=h_mode)

        for target_wdg in self.target_widgets:
            target_wdg.enable_actions = self.enable_actions
            target_wdg.mouse_pressed_at_pos.connect(self.go_to_linear_position)

        self.__init_histories()
        self.__init_targets()
        self.set_target_and_update_ui()

        QTimer.singleShot(0, self.__show_intro)

    @property
    def targets_are_numbers(self):
        all_types = [mo if is_type else mo.math_type
                     for mo, is_type in zip (self.pre_targets,
                                             self.are_math_type)]
        return all(t_type and t_type.is_number() for t_type in all_types)

    def __show_intro(self):
        """
        Show a dialog help window:
        - 1st time, about the calculator
        - Else 1st case based reasonning.
        """
        cname = "dialogs.calculator_intro"
        if cvars.get(cname):
            text = _("<div>Use the Logical Calculator to fill-in the "
                     "form.<br> </div>"
                     "<div>Please note the green selection: when you click a "
                     "calculator button, the corresponding operator will "
                     "apply to the selection.<br> </div>"
                     "<div>Use the Enlarge (up) and Shrink (down) arrows to "
                     "modify the selection.</div>")
            calc_intro_box = DeaductionTutorialDialog(config_name=cname,
                                                      text=text,
                                                      parent=self.main_window)
            calc_intro_box.exec()

    @classmethod
    def __show_by_cases(self):

        cname = "dialogs.case_based"
        if cvars.get(cname):
            text = _("<div>Use the Logical Calculator to enter a property.<br>"
                     "</div>"
                     "<div>The proof will successively examines the case "
                     "when the property is verified, and the case "
                     "when it is not.<br> </div>")
            calc_intro_box = DeaductionTutorialDialog(config_name=cname,
                                                      text=text)
            calc_intro_box.exec()

    @classmethod
    def get_items(cls, goal=None,
                  missing_output: MissingCalculatorOutput = None,
                  geometries=None) -> ([MathObject], bool):
        """
        Get one or several targets.
        """
        window_title = missing_output.title
        task_title = missing_output.task_title()
        targets, are_math_type, titles = missing_output.targets_n_titles()
        # task_description = missing_output.task_description()
        statement = missing_output.statement
        task_goal = statement.goal() if statement else None
        prop = missing_output.explicit_math_type_of_prop

        if missing_output.request_type is CalculatorRequest.ProofByCases:
            cls.__show_by_cases()

        log.debug(f"Calculator with target types")
        cc = cls(targets=targets,
                 are_math_type=are_math_type,
                 goal=goal,
                 window_title=window_title,
                 task_title=task_title,
                 titles=titles,
                 # task_description=task_description,
                 task_goal=task_goal,
                 prop=prop)

        # Execute the CalculatorMainWindow and wait for results
        OK = cc.main_window.exec()

        if not OK:
            log.debug("Closing with no data")
            cc.main_window.close()
            return [], OK
        ############################
        # After exec: post-process #
        ############################
        if cc.lean_mode:
            cc.set_lean_target()
        targets = cc.targets
        math_objects = []

        for target in targets:
            target.unmark()
            if target.is_metavar:
                if not target.assigned_math_object:
                    # log.debug("No target")
                    # No more data from this point
                    break
            if cc.lean_mode:
                lean_code = cc.polished_lean_code()
                log.debug(f"Calculator output Lean code {lean_code}")
                math_object = MathObject.raw_lean_code(lean_code)
            else:
                # math_object = target.assigned_math_object
                math_object = target
            math_objects.append(math_object)

        math_objects = missing_output.initial_place_holders + math_objects
        return math_objects, OK

    def __set_targets(self):
        """
        Fill-in self.targets with MarkedMetavar whose target types are taken
        in self.target_types.
        """
        self.targets = []
        idx = 0
        for target, is_type in zip(self.pre_targets, self.are_math_type):
            if is_type:
                if target:
                    target_mvar = MetaVar(math_type=target)
                else:
                    target_mvar = MetaVar(math_type=None)
                target_mmvar = MarkedMetavar.from_mvar(target_mvar)
            else:
                target_mmvar = MarkedPatternMathObject.from_math_object(target)

            target_mmvar.mark()
            text = target_mmvar.to_display(format_='html')
            self.targets_widget.target_wdgs[idx].setHtml(text)
            self.targets.append(target_mmvar)
            idx += 1

    def __init_multiple_signals(self):
        targets_window = self.targets_widget

        t_bar = targets_window.toolbar
        t_bar.undo_all.triggered.connect(self.history_to_beginning)
        t_bar.undo_action.triggered.connect(self.history_undo)
        t_bar.redo_action.triggered.connect(self.history_redo)
        t_bar.redo_all.triggered.connect(self.history_to_end)

        n_bar = targets_window.navigation_bar
        n_bar.beginning_action.triggered.connect(self.go_to_beginning)
        n_bar.left_action.triggered.connect(self.move_left)
        n_bar.up_action.triggered.connect(self.move_up)
        n_bar.down_action.triggered.connect(self.move_down)
        n_bar.right_action.triggered.connect(self.move_right)
        n_bar.end_action.triggered.connect(self.go_to_end)
        targets_window.lean_mode_wdg.stateChanged.connect(self.toggle_lean_mode)
        n_bar.delete.triggered.connect(self.delete)

        for calculator_target in self.target_widgets:
            calculator_target.shortcut_msg.connect(self.status_bar.show_msg)

    def __init_histories(self):
        for target, history in zip(self.targets, self.histories):
            history.append(target)

    def __init_targets(self):
        """
        Display initial targets.
        """
        if self.targets_widget:
            idx = 0
            for target, target_wdg in zip(self.targets,
                                          self.targets_widget.target_wdgs):
                target.set_math_cursor()
                mvar = target.first_mvar(unassigned=True)
                moved = False
                if mvar:
                    moved = target.math_cursor.go_to(mvar)
                if not moved:
                    target.math_cursor.go_to_end()
                target_wdg.setHtml(target.to_display(format_='html'))
                self.targets_widget.set_focused_target_idx(idx)
                self.update_cursor()
                idx += 1

            self.targets_widget.set_focused_target_idx(0)

    @property
    def target_widgets(self):
        """
        List of all target widgets in self.
        Do not mistake for self.targets_widget, which is an optional single
        widget (containing several target widgets).
        """
        return self.targets_widget.target_wdgs

    # def show(self):
    #     if self.target_types:
    #         self.targets_widget.show()
    #     else:
    #         self.calculator_ui.show()

    def targets_window_closed(self):
        # print("Targets wd closed")
        self.buttons_window.targets_window_is_closed = True
        self.buttons_window.close()
        # self.main_window.close()

    @property
    def application_pattern(self):
        return self.buttons_window.application_pattern

    @property
    def parentheses_pattern(self):
        return self.buttons_window.parentheses_pattern

    @property
    def nb_of_targets(self):
        return len(self.targets)

    @property
    def current_target_idx(self):

        idx = (self.targets_widget.focused_target_idx if self.targets_widget
               else 0)
        return idx

    @property
    def history(self) -> []:
        return self.histories[self.current_target_idx]

    @history.setter
    def history(self, old_target) -> []:
        self.histories[self.current_target_idx] = old_target

    @property
    def history_idx(self):
        return self.history_indices[self.current_target_idx]

    @history_idx.setter
    def history_idx(self, idx):
        self.history_indices[self.current_target_idx] = idx

    @property
    def current_target_wdg(self):
        return self.targets_widget.focused_target

    @property
    def current_lean_code(self):
        text = self.current_target_wdg.toPlainText().strip()
        # log.debug(f"Current Lean code: {text}")
        return text

    @property
    def current_target(self):
        return self.targets[self.current_target_idx]

    @property
    def target(self):
        return self.current_target

    # @property
    # def target(self):
    #     return self._target
    #

    @target.setter
    def target(self, target):
        """
        Set current target.
        """
        self.targets[self.current_target_idx] = target

    @property
    def math_cursor(self):
        if self.target:
            return self.target.math_cursor

    @Slot()
    def toggle_lean_mode(self):
        """
        This is called when the Lean box is checked or unchecked.
        """
        self.current_target_wdg.lean_mode = self.lean_mode
        if not self.lean_mode:
            # Leaving lean mode, set target as a MathObject from code
            self.set_lean_target()
            self.history_update()
        else:
            # Entering Lean mode, modify display
            self.enable_actions()
            self.display_target()

    @property
    def lean_mode(self) -> bool:
        mode = self.lean_mode_wdg.isChecked()
        return mode

    def target_to_text(self):
        if self.lean_mode:
            mo = self.target.assigned_math_object
            if mo:
                text = mo.to_display(format_='lean')
                text = text.replace('?', ' ')
                text = text.strip()
            else:
                text = ''
        else:
            text = self.target.to_display(format_='html',
                                          pretty_parentheses=False)
        return text

    # @property
    # def current_html_target(self):
    #     if self.lean_mode:
    #         text = self.current_target.to_display(format_='lean')
    #     else:
    #         text = self.current_target.to_display(format_='html',
    #                                               pretty_parentheses=False)
    #     return text

    @property
    def navigation_bar(self):
        return self.targets_widget.navigation_bar

    @property
    def toolbar(self):
        return self.targets_widget.toolbar

    @property
    def lean_mode_wdg(self):
        return self.targets_widget.lean_mode_wdg

    @property
    def beginning_action(self):
        return self.navigation_bar.beginning_action

    @property
    def left_action(self):
        return self.navigation_bar.left_action

    @property
    def up_action(self):
        return self.navigation_bar.up_action

    @property
    def down_action(self):
        return self.navigation_bar.down_action

    @property
    def right_action(self):
        return self.navigation_bar.right_action

    @property
    def end_action(self):
        return self.navigation_bar.end_action

    @property
    def undo_action(self):
        return self.toolbar.undo_action

    @property
    def redo_action(self):
        return self.toolbar.redo_action

    @property
    def undo_all(self):
        return self.toolbar.undo_all

    @property
    def redo_all(self):
        return self.toolbar.redo_all

    @property
    def delete_action(self):
        return self.navigation_bar.delete

    #########################
    # Status bar management #
    #########################
    @property
    def status_bar(self):
        return self.targets_widget.status_bar

    def show_error_msg(self, msg):
        self.status_bar.show_error_msg(msg)

    def show_success_msg(self, msg):
        self.status_bar.show_success_msg(msg)

    def show_help_msg(self):
        self.status_bar.show_pending_msgs()
        # if True:
        #     duration = self.status_bar.pending_msg_time_interval
        #     self.status_bar.timer.setInterval(duration)
        #     # self.timer.singleShot(duration, self.show_pending_msgs)
        #     self.status_bar.timer.start()
        # else:  # Show immediately
        #     self.status_bar.show_pending_msgs()

    def show_shortcut_msg(self, msg, delay):
        self.status_bar.show_msg(msg, delay)

    def help_msg(self):
        """
        Always return empty string.
        TODO: pertinent help messages.
        """
        msg = ""
        DEBUG=False
        current_mo = self.current_target.marked_descendant()
        target_expected_type = current_mo._math_type
        # self.current_target.marked_descendant().assigned_math_object
        if current_mo.math_type:
            display_type = current_mo.math_type_to_display(format_='utf8',
                                                           text=True)
        else:
            display_type = "((no type))"
        if target_expected_type is PatternMathObject.NO_MATH_TYPE:
            expected_type = ""
        else:
            expected_type = target_expected_type.try_to_display(text=True,
                                                                is_type=True)

        if not current_mo.is_metavar:
            if DEBUG:
                msg = "((not a metavar))"
        elif current_mo.assigned_math_object:
            if DEBUG:
                msg = current_mo.check_type()
                if not msg:
                    msg = (f"((type checked : expected {expected_type},"
                           f"got {display_type}))")
        else:
            if (expected_type and not (target_expected_type.is_metavar
                    and not target_expected_type.assigned_math_object)):
                msg = _("Enter {}").format(expected_type)
            else:
                msg = _("(No help available)")

        if not DEBUG:
            msg = ""
        return msg

    def polished_lean_code(self):
        """
        Polish Lean code by replacing latex macro found in
        CalculatorButton.original_shortcuts_dic
        by lean code (button.lean_symbol).
        TODO: write a proper parser!
        """
        # Lean code to MathObject
        polished_code = self.current_lean_code
        if not polished_code:
            return ""

        for shortcut, button in (
                CalculatorButton.original_shortcuts_dic.items()):
            if shortcut.startswith('\\'):
                text = button.lean_symbol
                print(f"Replacing {shortcut} by {text}")
                polished_code = polished_code.replace(shortcut, text)

        return polished_code

    def set_lean_target(self):
        """
        This method is called when self goes from lean_mode=True to
        lean_mode=False: the pure Lean code in encapsulated in a
        MarkedPatternMathObject.
        """
        if not self.current_lean_code:
            return

        pure_code = self.polished_lean_code()
        # print(f"Pure code: {pure_code}")
        math_object_code = MathObject.raw_lean_code(pure_code)
        pmo = MarkedPatternMathObject.from_math_object(math_object_code)
        # print(f"MPMO: {pmo.to_display(format_='utf8')}")

        # Set target
        math_type = self.target.math_type
        target = MarkedMetavar.from_mvar(MetaVar(math_type=math_type))
        target.assigned_math_object = pmo
        # print(f"target text: {self.target_to_text()}")
        target.set_math_cursor()
        target.math_cursor.go_to_end()
        self.target = target

    @Slot()
    def display_target(self):
        text = self.target_to_text()
        if self.lean_mode:
            self.current_target_wdg.clear()
            # self.current_target_wdg.currentCharFormat().clearBackground()
            # self.current_target_wdg.currentCharFormat().clearForeground()
            self.current_target_wdg.setPlainText(text)
        else:
            self.current_target_wdg.setHtml(text)
        # self.calculator_ui.set_html(self.html_target)

    def virtual_cursor_position(self):
        """
        Return the position at which the cursor should be seen, corresponding to
        the current marked node of self.target, if any, or the end.
        """
        return self.math_cursor.linear_text_cursor_position()

    def update_cursor(self):
        # self.target.adjust_cursor_pos()
        # self.calculator_ui.calculator_target.setFocus()
        position = self.virtual_cursor_position()
        self.current_target_wdg.go_to_position(position)

    def enable_actions(self):
        """
        Freeze/unfreeze buttons according to context.
        In particular, the OK button is frozen unless a non void initial
        sub-list of self.targets have assigned_math_objects.
        """
        # target = self.target
        cursor = self.math_cursor
        if self.lean_mode: # FIXME
            self.beginning_action.setEnabled(False)
            self.left_action.setEnabled(False)
            # self.up_action.setEnabled(bool(target.parent_of_marked()))
            self.right_action.setEnabled(False)
            self.end_action.setEnabled(False)
            self.undo_action.setEnabled(False)
            self.redo_action.setEnabled(False)
            self.undo_all.setEnabled(False)
            self.redo_all.setEnabled(False)
            self.up_action.setEnabled(False)
            self.down_action.setEnabled(False)
            self.delete_action.setEnabled(False)
        else:
            self.beginning_action.setEnabled(not cursor.is_visually_at_beginning())
            self.left_action.setEnabled(not cursor.is_visually_at_beginning())
            self.right_action.setEnabled(not cursor.is_visually_at_end())
            self.end_action.setEnabled(not cursor.is_visually_at_end())
            self.undo_action.setEnabled(self.history_idx > 0)
            self.redo_action.setEnabled(self.history_idx < len(self.history) - 1)
            self.undo_all.setEnabled(self.history_idx > 0)
            self.redo_all.setEnabled(self.history_idx < len(self.history) - 1)

            self.up_action.setEnabled(not cursor.is_at_top())
            self.down_action.setEnabled(not cursor.is_at_bottom())
            can_delete = bool(self.target.marked_descendant().assigned_math_object)
            self.delete_action.setEnabled(can_delete)

        # Has usr filled-in enough targets?
        #  All place_holders must be at the end,
        #  i.e. no assigned_math_object after unassigned
        # CAUTION, these are str in Lean mode
        assigned_math_objects = [var.assigned_math_object if var.is_metavar
                                 else var for var in self.targets]
        # Take into account current target may be in Lean mode
        if self.lean_mode:
            idx = self.current_target_idx
            assigned_math_objects[idx] = self.current_lean_code

        place_holders_found = False
        OK = False
        for mo in assigned_math_objects:
            if not mo:
                if not OK:  # No initial assigned_math_object
                    break
                else:
                    place_holders_found = True
            elif mo is not None and place_holders_found:
                OK = False
                break
            else:  # At least one assigned_math_object
                OK = True

        # Do not enable OK if some target contains "?" (unassigned metavar)
        if not self.lean_mode:
            for mo in assigned_math_objects:
                if mo and mo.contains_unassigned_metavar():
                    OK = False

        button_box = self.targets_widget.button_box
        button_box.setEnabled(OK)

    @Slot()
    def target_focus_has_changed(self):
        self.enable_actions()

    # def update_cursor_and_enable_actions(self):
    #     self.update_cursor()
    #     self.enable_actions()
    #     self.current_target_wdg.setFocus()
    #     # print(self.target)

    def give_focus_back_to_target_wdg(self):
        """
        Give focus back to targets_widget (and thus to the active
        target_wdg). This prevents the Buttons window to keep focus.
        """
        # print("Focus on targets")
        if self.targets_widget:
            self.targets_widget.activateWindow()
            self.targets_widget.setFocus()

    def set_target_and_update_ui(self):
        self.display_target()
        # self.update_bound_vars()
        self.update_cursor()
        self.enable_actions()
        self.give_focus_back_to_target_wdg()
        self.show_help_msg()

    ##################
    # Target editing #
    ##################

    def bound_vars_update(self):
        self.rename_bound_vars()
        self.set_bound_var_buttons()

    def history_update(self):
        """
        Update target display, and store it in history.
        Delete the end of history if any.
        This is called after insert_pattern() and delete() methods.
        """

        self.history_idx += 1
        self.history = self.history[:self.history_idx]
        self.history.append(self.target)

        self.bound_vars_update()
        self.set_target_and_update_ui()

    @property
    def bound_var_buttons(self):
        bv_group = self.buttons_window.complete_widget.bound_var_group()
        return bv_group

    def bound_vars(self):
        return self.bound_var_buttons.patterns()

    def rename_bound_vars(self):
        """
        Rename all bound vars in current target.
        """

        bound_vars = self.current_target.bound_vars()
        for bv in bound_vars:
            # print(f"Unnaming bv {bv}")
            bv.set_unnamed_bound_var()
        self.current_target.set_local_context()
        # Erase name_hints, otherwise they will forbid previously used letters:
        self.goal.name_hints = []
        self.goal.recursive_name_all_bound_vars(self.current_target)
        # for bv in bound_vars:
        #     print(f"New name: {bv}, id = {bv.identifier_nb}")

    def set_bound_var_buttons(self):
        # NB: MarkedPMO associated to BoundVar button is bound_var,
        #  not just a deep_copy of it:
        if not self.bound_var_buttons:
            return

        self.bound_var_buttons.remove_all_shortcuts()

        # print(self.current_target.bound_vars())
        buttons = [CalculatorButton.from_math_object(bound_var,
                                                     copy_math_object=False)
                   for bound_var in self.current_target.bound_vars()]
        # print(buttons)
        # print(CalculatorButton.shortcuts_dic.get('x'))

        self.bound_var_buttons.set_buttons(buttons)
        for btn in buttons:
            btn.btn_send_pattern.connect(
                self.buttons_window.complete_widget.process_clic)

    @Slot()
    def insert_pattern(self, pattern_s: [MarkedPatternMathObject],
                       latex_symbol):
        """
        Try to insert pattern (or patterns) in self.target.
        If several patterns are provided, they are tried in order until
        success.

        The case of the special pattern "GENERIC_APPLICATION" is different.
        This is called when usr push the "()" button, or the "f(·)" button.
        If the marked_descendant is a function g from the context, then the
        insertion will result in the object g(·). This is done by computing
        beforehand the pattern APP(g, ?) for every context function g.
        """

        log.debug(f"Action: insert {pattern_s}")
        if not isinstance(pattern_s, list):
            pattern_s = [pattern_s]

        if self.lean_mode:
            text_wdg = self.current_target_wdg
            # FIXME: better formatting in Lean mode?
            lean_symbol = MathDisplay.latex_to_lean(latex_symbol)
            text_wdg.insertPlainText(lean_symbol)
            # self.set_lean_target()
            # self.history_update()
            return

        potential_bv = pattern_s[0]
        if potential_bv.is_bound_var:
            # pattern_s MUST refer to copied bv in new_target below
            original_bvs = [potential_bv]
            copied_bvs = [potential_bv.deep_copy(potential_bv)]
            pattern_s[0] = copied_bvs[0]
            # DEBUG: here bv are NOT marked
        else:
            original_bvs = []
            copied_bvs = []

        target = self.target
        new_target = target.deep_copy(self.target,
                                      original_bvs,
                                      copied_bvs)

        # Do not affect marked_descendant:
        new_target.set_math_cursor(go_to_end=False)
        new_target.math_cursor.set_cursor_at_the_same_position_as(
            self.target.math_cursor)
        # print(new_target.marked_descendant()) --> OK, a single marked desc
        # assert (new_target.math_cursor.cursor_address ==
        #         self.target.math_cursor.cursor_address)
        # assert (new_target.math_cursor.cursor_is_after ==
        #         self.target.math_cursor.cursor_is_after)
        # print("Target, new target ordered descendants:")
        # print(self.target.ordered_descendants(include_cursor=True))
        # print(new_target.ordered_descendants(include_cursor=True))

        assigned_mvar = None
        # print(f"New target: {new_target}")

        # ####### (1) Normal insert ########
        for pattern in pattern_s:
            # print(pattern.node, self.parentheses_pattern.node)
            # print(target.marked_descendant().is_suitable_for_app(),
            # target.cursor_is_after_marked_descendant())
            if (pattern == self.parentheses_pattern
                and target.marked_descendant().is_suitable_for_app()
                    and target.cursor_is_after_marked_descendant()):
                # ###### (1a) Special buttons: parentheses ######
                # If after a function or like, then insert APP
                log.debug("(Trying application)")
                assigned_mvar = new_target.insert(self.application_pattern)
                # print(new_target.marked_descendant()) -> 2 md
            else:
                # (1b) Normal insert
                assigned_mvar = new_target.insert(pattern)
                # print(new_target.marked_descendant())
                # assigned_mvar = new_target.new_insert(pattern)
            if assigned_mvar:
                break

        pattern = pattern_s[-1]
        # ###### (2) Automatic patterns ######
        # g, x --> g(x)  ; u, n --> u_n
        if (not assigned_mvar) and target.cursor_is_after_marked_descendant():
            # print(new_target.marked_descendant())
            assigned_mvar = new_target.insert_application_with_arg2(pattern)

        # ###### (3) Force insertion with LAST pattern ######
        # For now this just fusions digits
        #  1, 2 --> 12
        if not assigned_mvar:
            assigned_mvar = new_target.generic_insert(pattern)

        # print(f"New target: {new_target}")
        if assigned_mvar:  # SUCCESS!
            # The following is not pertinent:
            # assigned_mvar.adjust_type_of_assigned_math_object()
            # self.check_new_bound_var(assigned_mvar)
            self.target = new_target
            # DEBUG
            # print(new_target.to_display(format_='lean'))

            # check_type_msg = new_target.check_type()
            # if check_type_msg:
            #     self.show_error_msg(check_type_msg)
            # else:
            #     self.show_success_msg(_(f"{symbol} inserted!"))
            # self.show_help_msg()

            # was_at_end = (self.target.math_cursor.is_at_end()
            #               or self.target.marked_descendant() ==
            #               self.target.ordered_descendants()[-1])
            self.target.move_after_insert(assigned_mvar,
                                          was_at_end=False)
            self.history_update()
        else:  # ERROR!
            # Fixme
            symbol = MathDisplay.latex_to_utf8(latex_symbol)
            error_msg = _("Cannot insert {} here").format(symbol)
            self.show_error_msg(error_msg)
            self.current_target_wdg.setFocus()
            # self.show_help_msg()

        # DEBUGGING:
        # print(f"Shape: {self.target.latex_shape()}")
        # print(f"New target after move: {new_target}")
        # print("Math list:")
        # self.math_cursor.show_cursor()
        # print(self.target.math_list())
        # self.math_cursor.hide_cursor()
        # print("Linear list, idx:")
        # print(self.target.ordered_descendants())
        # print(self.target.current_index_in_ordered_descendants())
        # total, cursor = self.target.total_and_cursor_list()
        # print("Total and cursor lists:")
        # print(total)
        # print(cursor)
        # print("Bound vars:")
        # print("Target:")
        # print(self.target.math_list())
        # BV = self.target.all_bound_vars()
        # print(BV)
        # if BV:
        #     print([bv.info.get('identifier_nb') for bv in BV])
        #     print([bv is BV[0] for bv in BV])
        # print(self.target.math_type)
        # if pattern_s[0].is_bound_var:
        #     # FIXME
        #     main_bv = self.target.children[1]
        #     print(f"pattern is {main_bv}? --> {pattern_s[0] is main_bv}")
        #     # child = self.target.children[2]
        #     # if child.children:
        #     #     bv = child.children[0].assigned_math_object
        #     #     print(f"{bv} is {main_bv},"
        #     #           f"{bv is main_bv}")
        #     for bv in BV:
        #         print(f"{bv} is {main_bv}? --> {bv is main_bv}")

    @Slot()
    def delete(self):
        log.debug("Action: delete")
        new_target = self.target.deep_copy(self.target)
        # FIXME: record element previous to marked, and go_to that element
        #  after deletion
        success = new_target.clear_marked_mvar()
        # print(new_target)
        if success:
            self.target = new_target
            # Remove obsolete bound vars buttons
            self.set_bound_var_buttons()
            self.history_update()

    #################
    # History moves #
    #################

    def after_history_move(self):
        """
        Update after a history move.
        """
        self.target = self.history[self.history_idx]
        self.bound_vars_update()
        self.set_target_and_update_ui()

    @Slot()
    def history_undo(self):
        log.debug("Action: Undo")
        if self.history_idx > 0:
            self.history_idx -= 1
            self.after_history_move()

    @Slot()
    def history_redo(self):
        log.debug("Action: Redo")
        if self.history_idx < len(self.history) - 1:
            self.history_idx += 1
            self.after_history_move()

    @Slot()
    def history_to_beginning(self):
        log.debug("Action: Undo all")
        self.history_idx = 0
        self.after_history_move()

    @Slot()
    def history_to_end(self):
        log.debug("Action: Redo all")
        self.history_idx = len(self.history) - 1
        self.after_history_move()

    ################
    # Cursor moves #
    ################

    @Slot()
    def move_up(self):
        log.debug("Action: Move up")
        self.math_cursor.actually_enlarge_selection()
        self.set_target_and_update_ui()

    @Slot()
    def move_down(self):
        log.debug("Action: Move down")
        self.math_cursor.actually_shrink_selection()
        self.set_target_and_update_ui()

    @Slot()
    def move_right(self):
        """
        Move the cursor to the right, and shrink selection as much as
        possible; unless the cursor is at end, then select everything.
        """
        log.debug("Action: Move right")
        # self.math_cursor.increase_pos()
        if self.math_cursor.is_almost_at_end():
            self.go_to_end()
        else:
            self.math_cursor.actually_increase_pos()
            self.math_cursor.max_shrink_selection()
        self.set_target_and_update_ui()

    @Slot()
    def move_left(self):
        log.debug("Action: Move left")
        # self.math_cursor.decrease_pos()
        if self.math_cursor.is_almost_at_beginning():
            self.go_to_beginning()
        else:
            self.math_cursor.actually_decrease_pos()
            self.math_cursor.max_shrink_selection()
        self.set_target_and_update_ui()

    @Slot()
    def go_to_beginning(self):
        log.debug("Action: go to beginning")
        self.math_cursor.go_to_beginning()
        self.math_cursor.max_shrink_selection()
        self.set_target_and_update_ui()

    @Slot()
    def go_to_end(self):
        log.debug("Action: go to end")
        self.math_cursor.go_to_end()
        self.math_cursor.max_shrink_selection()
        self.set_target_and_update_ui()

    @Slot()
    def go_to_linear_position(self, position):
        self.math_cursor.go_to_linear_position(position)
        self.math_cursor.max_shrink_selection()
        self.set_target_and_update_ui()

    # @Slot()
    # def move_to_next_unassigned(self):
    #     success = self.target.move_right_to_next_unassigned()
    #     if success:
    #         self.set_target_and_update_ui()

    # @Slot()
    # def move_to_previous_unassigned(self):
    #     success = self.target.move_left_to_previous_unassigned()
    #     if success:
    #         self.set_target_and_update_ui()

    # @Slot()
    # def move_up(self):
    #     success = self.target.move_up()
    #     if success:
    #         self.set_target_and_update()


def main():

    from deaduction.pylib.mathobj import MathObject
    target = MarkedPatternMathObject.from_string('?0: SET(?1)')
    target = MarkedPatternMathObject.from_string('?0: *NUMBER_TYPES')
    # target.mark()
    app = QApplication([])
    # calculator = CalculatorController(target=target)
    # calculator.show()

    # target_type = MarkedPatternMathObject.from_string('SET(?1)')
    # target_type = MarkedPatternMathObject.from_string('*NUMBER_TYPES')
    # target_type = MarkedPatternMathObject.from_string('CONSTANT/name=ℝ')
    # target_type = MathObject(node="CONSTANT", info = {'name': 'ℝ'},
    #                          children=[])

    type_ = MathObject(node='TYPE', info={}, children=[])
    set_ = MathObject(node='CONSTANT', info={'name': 'X'}, children=[],
                      math_type=type_)
    target_type = MathObject(node="SET", info={},
                             children=[set_])
    target_type = MathObject(node="CONSTANT", info={'name': 'ℝ'},
                             children=[])
    # FIXME: obsolete
    # choice, ok = CalculatorController.get_item(goal=None,
    #                                            target_type=target_type,
    #                                            title='Essai')

    # sys.exit(app.exec_())
    # print(ok, choice)
    # if isinstance(choice, str):
    #     print(choice)
    # else:
    #     print(choice.to_display(format_='lean'))


if __name__ == '__main__':
    main()






