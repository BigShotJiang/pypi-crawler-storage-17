# pervpy
pervpy is created with the aim to provide a centralized package for profiling and analyzing the performance of different Python applications.

At the current stage, it only supports monitoring Django ORM's SQL queries.

## Install

`pervpy` should only be used in development and should not be added in production

```bash
uv add --dev pervpy
# or
pip install pervpy
```


## Sections
[DjangoORMWatch](./docs/django_orm_watch.md)
