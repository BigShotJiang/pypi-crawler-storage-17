import smtplib
from email.mime.text import MIMEText
import webbrowser
import pyautogui
import time

def send_whats_msg(number: str, message: str):
    try:
        message = message.replace(" ", "%20")
        webbrowser.open(f"https://web.whatsapp.com/send?phone={number}&text={message}")
        print("WhatsApp Web has opened... Wait a moment for the download to complete")
        time.sleep(15)
        pyautogui.press("enter")
        print("Successfully send.")
    
    except Exception as e:
        print(f"Error: {e}")


def send_mail(email_sender: str, password: str, subject: str, body: str, email_receiver: str):
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] =  email_sender
    msg['To'] = email_receiver
    
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as sender_email:
        sender_email.login(email_sender, password)
        sender_email.sendmail(email_sender, email_receiver, msg.as_string())
    print("The email has been sent!")


def send_html_mail(email_sender: str, password: str, subject: str, html_code: str, email_receiver: str):
    msg = MIMEText(html_code, 'html')
    msg['Subject'] = subject
    msg['From'] =  email_sender
    msg['To'] = email_receiver
    
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as sender_email:
        sender_email.login(email_sender, password)
        sender_email.sendmail(email_sender, email_receiver, msg.as_string())
    print("The email HTML has been sent!")
