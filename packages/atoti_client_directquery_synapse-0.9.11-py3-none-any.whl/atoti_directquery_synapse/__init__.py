"""Code to use DirectQuery on `Azure Synapse Analytics <https://azure.microsoft.com/en-us/services/synapse-analytics>`__."""

from .connection_config import ConnectionConfig as ConnectionConfig
from .table_config import TableConfig as TableConfig
