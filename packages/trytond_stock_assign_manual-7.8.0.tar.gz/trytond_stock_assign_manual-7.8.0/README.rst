Stock Assign Manual Module
##########################

The Stock Assign Manual module adds a wizard on shipments and production that
allows you to decide from which precise location to pick products.

Another wizard allows either the whole amount, or a specific quantity, to be
unassigned of each move.
