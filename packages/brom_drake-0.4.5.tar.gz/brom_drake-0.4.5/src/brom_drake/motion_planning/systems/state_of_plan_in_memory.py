from enum import IntEnum

class StateOfPlanInMemory(IntEnum):
    kNotSet = 0
    kSet = 1