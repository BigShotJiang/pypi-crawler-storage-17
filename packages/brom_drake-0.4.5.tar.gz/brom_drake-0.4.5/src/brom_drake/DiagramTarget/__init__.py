from .DiagramTarget import DiagramTarget

__all__ = [
    "DiagramTarget"
]
