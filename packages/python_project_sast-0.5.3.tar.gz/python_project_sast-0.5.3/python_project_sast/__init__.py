"""Python Project is a Python library created with https://gitlab.com/galactipy/galactipy."""

# Placeholder for poetry-dynamic-versioning, DO NOT CHANGE
# https://github.com/mtkennerly/poetry-dynamic-versioning#installation
__version__ = "0.5.3"

# TODO Update with imported objects  # noqa: TD002,TD003
# __all__ = []  # noqa: ERA001
