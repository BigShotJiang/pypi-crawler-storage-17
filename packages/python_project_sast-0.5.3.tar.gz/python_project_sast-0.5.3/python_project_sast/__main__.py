"""Launch the Python Project interface as a module script."""

from python_project_sast.config import AppManager
from python_project_sast.tui.main_window import TerminalApp

APP_MANAGER = AppManager.default()

app = TerminalApp(APP_MANAGER.settings.theme)
app.run()
