"""Retrieve foundational values for enabling standard behaviour for Python Project."""

from pathlib import Path

from platformdirs import user_config_path, user_log_path

from python_project_sast import __version__


def get_default_config() -> Path:
    """Retrieve the default configuration path for Python Project.

    Returns
    -------
    Path
        A Path object pointing to the User Config Path where configuration for
        Python Project will be stored.
    """
    return user_config_path("python-project-sast")


def get_default_log_path(filename: str | Path) -> Path:
    """Retrieve the default path to store Python Project logs.

    Parameters
    ----------
    filename : str, Path
        Name of the file to be created inside the User Log Path.

    Returns
    -------
    Path
        A Path object pointing to the User Log Path where a file for Python Project logs
        will be stored.
    """
    return user_log_path("python-project-sast") / filename


def generate_default_config_schema():
    """Create the default configuration schema for Python Project.

    Returns
    -------
    dict
        A dictionary containing the keys and values for the vanilla Python Project
        configuration, wrapped inside a function to avoid mutation issues.
    """
    return {
        "VERSION": __version__,
        "THEME": "noctis",
        # UPDATEME with future default sections to be included
    }
