"""Helper functions for streamlining Python Project functionality."""

from typing import TYPE_CHECKING, Literal

from pathlib import Path

from python_project_sast.config.manager import AppManager

if TYPE_CHECKING:
    from orbittings import Nucleus

    from python_project_sast.config.mappings import ConfigurationDomain


def resolve_app_manager(
    domain: "Literal['settings', 'secrets'] | ConfigurationDomain",
    custom_path: Path | None = None,
) -> "Nucleus":
    """Resolve the Orbittings Manager to be used for other operations.

    Parameters
    ----------
    domain : {"settings", "secrets"}
        Flag to treat the given `path` as a settings or secrets file.
    custom_path : Path, optional
        A custom path to load a configuration from.

    Returns
    -------
    Nucleus
        A manager object for accessing global settings or secrets.
    """
    if custom_path is None:
        return AppManager.default()

    return AppManager.custom(custom_path, domain)
