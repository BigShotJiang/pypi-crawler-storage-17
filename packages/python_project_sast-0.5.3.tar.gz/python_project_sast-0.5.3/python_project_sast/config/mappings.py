"""Mapping objects for the Python Project configuration manager."""

from enum import Enum


class EnvvarPrefix(Enum):
    """Environment variable prefixes for Python Project configuration."""

    SETTINGS = "PYTHON_PROJECT_SAST"
    SECRETS = "PYTHON_PROJECT_SAST_SECRET"


class ConfigurationDomain(Enum):
    """Configuration domain identifiers."""

    SETTINGS = "settings"
    SECRETS = "secrets"

    @classmethod
    def from_flag(cls, *, is_secret: bool) -> "ConfigurationDomain":
        """Return the appropriate domain based on the secret flag.

        Parameters
        ----------
        is_secret : bool
            Whether the configuration is secret/sensitive.

        Returns
        -------
        ConfigurationDomain
            The corresponding configuration domain.
        """
        return cls.SECRETS if is_secret else cls.SETTINGS
