__version__ = "2025.5.6"  # noqa: W292
