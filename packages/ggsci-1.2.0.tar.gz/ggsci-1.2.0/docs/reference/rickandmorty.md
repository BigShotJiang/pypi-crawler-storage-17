# Rick and Morty

::: ggsci.palettes
    options:
      members:
        - pal_rickandmorty
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_rickandmorty
        - scale_colour_rickandmorty
        - scale_fill_rickandmorty
      show_root_heading: true
      show_source: false
