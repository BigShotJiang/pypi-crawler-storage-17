# BS5

::: ggsci.palettes
    options:
      members:
        - pal_bs5
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_bs5
        - scale_colour_bs5
        - scale_fill_bs5
      show_root_heading: true
      show_source: false
