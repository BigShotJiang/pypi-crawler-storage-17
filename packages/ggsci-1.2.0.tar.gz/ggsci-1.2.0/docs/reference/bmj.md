# BMJ

::: ggsci.palettes
    options:
      members:
        - pal_bmj
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_bmj
        - scale_colour_bmj
        - scale_fill_bmj
      show_root_heading: true
      show_source: false
