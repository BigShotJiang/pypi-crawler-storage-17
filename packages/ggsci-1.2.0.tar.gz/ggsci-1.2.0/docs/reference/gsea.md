# GSEA

::: ggsci.palettes
    options:
      members:
        - pal_gsea
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_gsea
        - scale_colour_gsea
        - scale_fill_gsea
      show_root_heading: true
      show_source: false
