# iTerm

::: ggsci.palettes
    options:
      members:
        - pal_iterm
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_iterm
        - scale_colour_iterm
        - scale_fill_iterm
      show_root_heading: true
      show_source: false
