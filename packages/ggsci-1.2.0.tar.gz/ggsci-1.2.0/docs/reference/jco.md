# JCO

::: ggsci.palettes
    options:
      members:
        - pal_jco
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_jco
        - scale_colour_jco
        - scale_fill_jco
      show_root_heading: true
      show_source: false
