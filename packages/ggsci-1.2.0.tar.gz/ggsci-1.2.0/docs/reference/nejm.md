# NEJM

::: ggsci.palettes
    options:
      members:
        - pal_nejm
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_nejm
        - scale_colour_nejm
        - scale_fill_nejm
      show_root_heading: true
      show_source: false
