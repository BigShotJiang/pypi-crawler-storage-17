# NPG

::: ggsci.palettes
    options:
      members:
        - pal_npg
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_npg
        - scale_colour_npg
        - scale_fill_npg
      show_root_heading: true
      show_source: false
