# Flat UI

::: ggsci.palettes
    options:
      members:
        - pal_flatui
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_flatui
        - scale_colour_flatui
        - scale_fill_flatui
      show_root_heading: true
      show_source: false
