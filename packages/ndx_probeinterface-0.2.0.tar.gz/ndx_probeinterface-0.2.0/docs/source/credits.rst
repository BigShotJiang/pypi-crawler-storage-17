*******
Credits
*******

.. note::
    Add the credits for your extension here

Acknowledgments
===============


Authors
=======


*****
Legal
*****

License
=======
