"""TeDa version"""

# Edit version below, same in ../pyproject.toml
version_tuple = (4, 0, 3)

__version__ = '.'.join([str(n) for n in version_tuple])