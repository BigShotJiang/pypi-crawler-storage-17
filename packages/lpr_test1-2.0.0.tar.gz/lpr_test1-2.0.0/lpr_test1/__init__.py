from .test import test as lpr_test1

name = "test"