def test():
    print("This is a test function in pkg1/test/test.py")