# coding:utf-8

__project__ = "casm"
__version__ = "0.10.3"
__urlhome__ = "https://github.com/podboy/casm/"
__description__ = "Container Assembler"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
