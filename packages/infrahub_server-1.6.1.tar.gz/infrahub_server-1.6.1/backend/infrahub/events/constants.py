from enum import StrEnum

EVENT_NAMESPACE = "infrahub"


class EventSortOrder(StrEnum):
    ASC = "asc"
    DESC = "desc"
