# Youtube Autonomous Timer Module

The way to measure the code execution time properly.