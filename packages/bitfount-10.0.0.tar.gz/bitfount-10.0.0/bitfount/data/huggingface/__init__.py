"""Data modules for HuggingFace."""

from __future__ import annotations
