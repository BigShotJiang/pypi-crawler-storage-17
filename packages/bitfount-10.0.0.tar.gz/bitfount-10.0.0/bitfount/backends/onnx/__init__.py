"""ONNX backend for Bitfount."""

from bitfount.backends.onnx.models import ONNXModel

__all__ = ["ONNXModel"]
