from ...private_eye.optos.optos_parser import OptosParser
