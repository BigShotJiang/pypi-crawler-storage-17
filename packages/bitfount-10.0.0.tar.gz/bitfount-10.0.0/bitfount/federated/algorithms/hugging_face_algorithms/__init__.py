"""Algorithms for remote Hugging Face models."""

from __future__ import annotations
