def get_image_file_type(encoding):
    if (encoding == 'Raw'):
        return '.ATKIMAGE'
    elif (encoding == 'Jxl'):
        return '.jxl'
    return '.jpg'
