The goal of this development is to create a field for validation to
notate which customers require a purchase order in order to create an
invoice.
