# !/usr/bin/python
# coding=utf-8
"""Tentacle slots subpackage.

All classes are lazy-loaded via tentacle root package.
Import from tentacle directly: from tentacle import [ClassName]
"""

# Lazy-loaded via parent package - no explicit imports needed

# --------------------------------------------------------------------------------------------
# Notes
# --------------------------------------------------------------------------------------------
