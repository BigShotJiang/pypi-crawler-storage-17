## Stock picking send by mail

This module was written to extend the functionality of stock picking and
allow you to send the picking order by email.
