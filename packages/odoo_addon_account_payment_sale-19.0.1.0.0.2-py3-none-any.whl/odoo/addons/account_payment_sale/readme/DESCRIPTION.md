This modules adds one field on sale orders: *Payment Mode*. This field
is copied from customer to sale order and then from sale order to
customer invoice.
