You are able to add a payment mode directly on a partner. This payment
mode is automatically associated to the sale order, then copied to the
related invoice. This default value can be changed sale orders or on
draft invoices.
