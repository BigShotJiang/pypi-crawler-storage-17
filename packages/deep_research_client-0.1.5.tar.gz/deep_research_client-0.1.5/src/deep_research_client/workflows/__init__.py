"""Bundled workflow definitions for deep-research-client providers."""
