"""Test suite for the datachain package."""
