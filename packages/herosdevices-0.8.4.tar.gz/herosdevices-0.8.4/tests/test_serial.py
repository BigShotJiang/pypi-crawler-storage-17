def test_import():
    from src.herosdevices.core.bus import SerialConnection

    assert SerialConnection
