"""This module contains all the device drivers which directly represent a specific hardware type.

We recommend using the classes in this module together with BOSS, however they can be also used standalone in theory.
"""
