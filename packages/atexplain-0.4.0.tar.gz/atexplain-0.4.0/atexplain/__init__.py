from .engine import auto_explain

__version__ = "0.4.0"

auto_explain()
