Authors
-------

IntbitSet was originally developed for use in `Invenio <http://inveniosoftware.org>`_ 
digital library software and is now used by several other projects as a library
that need a fast integer set.

Contact the current maintainer at `Philippe Ombredanne <pombredanne@gmail.com>`_
Contact Invenio at `info@inveniosoftware.org <mailto:info@inveniosoftware.org>`_

Contributors
^^^^^^^^^^^^

* Alessio Deiana <alessio.deiana@cern.ch> @Osso
* Andrew Mundy @mundya
* Ayan Sinha Mahapatra @AyanSinhaMahapatra
* Jiri Kuncar <jiri.kuncar@cern.ch> @jirikuncar
* Konrad Weihmann @priv-kweihmann
* Lars Holm Nielsen <lars.holm.nielsen@cern.ch> @lnielsen
* Marco Neumann <marco@crepererum.net> @crepererum
* Maximiliano Curia @maxyz
* Maximilian Teegen @max-te
* Nikola Yolov <nikola.yolov@cern.ch> @NikolaYolov
* Philippe Ombredanne <pombredanne@gmail.com> @pombredanne
* Pierre Tardy <tardyp@gmail.com> @tardyp
* Samuele Kaplun <samuele.kaplun@cern.ch> @kaplun
* Steven Esser @steven-esser
* Tibor Simko <tibor.simko@cern.ch> @tiborsimko
