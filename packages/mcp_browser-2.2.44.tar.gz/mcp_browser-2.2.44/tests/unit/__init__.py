"""Unit tests for MCP Browser services."""
