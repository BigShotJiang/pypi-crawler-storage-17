"""Welcome to the Graph Algorithm Classes

These classes provide functionality for Graphs (NetworkX).

- TBD: TBD
"""

from .light.proximity_graph import ProximityGraph

__all__ = ["ProximityGraph"]
