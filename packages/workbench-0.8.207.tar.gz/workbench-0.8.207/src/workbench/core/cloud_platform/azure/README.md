# Azure Platform Specific Code
This directory holds code that's specific to the Azure Cloud Platform.