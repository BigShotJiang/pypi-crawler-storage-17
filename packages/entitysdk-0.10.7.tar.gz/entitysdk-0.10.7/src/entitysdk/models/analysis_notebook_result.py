"""Analysis notebook result model."""

from entitysdk.models.entity import Entity


class AnalysisNotebookResult(Entity):
    """Analysis notebook result model."""
