"""Skeletonization config generation model."""

from entitysdk.models.activity import Activity


class SkeletonizationConfigGeneration(Activity):
    """Skeletonization config generation activity class."""
