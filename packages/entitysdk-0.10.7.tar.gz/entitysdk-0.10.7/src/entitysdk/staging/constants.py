"""Staging constants."""

DEFAULT_NODE_POPULATION_NAME = "All"
DEFAULT_NODE_SET_NAME = "All"
