# Youtube Autonomous Web Scraper add-on

The way to navigate through the Internet automatically.