.. _examples:

========
Examples
========

Below you will find a handful of examples of typical Sarracen usage. More
documentation is always appreciated!

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   examples/ot
   examples/dustydisc
   examples/k3d
