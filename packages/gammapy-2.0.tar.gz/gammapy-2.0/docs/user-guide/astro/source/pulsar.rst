.. _astro-source-pulsar:

Pulsar Source Models
====================

Plot spin frequency of the pulsar with time:

.. plot:: user-guide/astro/source/plot_pulsar_spindown.py
    :include-source:
