.. _api_maps:

***************
maps - Sky maps
***************

.. currentmodule:: gammapy.maps

.. automodapi:: gammapy.maps
    :no-inheritance-diagram:
    :include-all-objects:
