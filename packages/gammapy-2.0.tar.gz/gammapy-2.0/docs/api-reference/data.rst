.. _api_data:

********************************
data - DL3 data and observations
********************************

.. currentmodule:: gammapy.data

.. automodapi:: gammapy.data
    :no-inheritance-diagram:
    :include-all-objects:
