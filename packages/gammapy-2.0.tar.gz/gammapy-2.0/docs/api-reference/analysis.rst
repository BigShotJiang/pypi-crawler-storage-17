.. _api_analysis:

*******************************
analysis - High level interface
*******************************

.. currentmodule:: gammapy.analysis

.. automodapi:: gammapy.analysis
    :no-inheritance-diagram:
    :include-all-objects:
