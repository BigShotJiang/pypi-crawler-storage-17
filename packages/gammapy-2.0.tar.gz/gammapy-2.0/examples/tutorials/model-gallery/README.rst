Model Gallery
=============

A gallery of all possible spectral, spatial and temporal models can be found in this page:
:ref:`model-gallery`.
