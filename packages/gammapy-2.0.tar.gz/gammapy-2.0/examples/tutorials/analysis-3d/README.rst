3D Cube
-------