"""
----------------------------------------------------------------------------------
 Author:  Frank Runfola
 Created: 1/20/2024
 ----------------------------------------------------------------------------------
Verify Items:
- Check name
- Apt start time matches what was selected in Athena
- Check in time matches what time you did step 2
- Appointment Type matches what was selected in Athena
- Status is set to Checked In
- Attending matches what was selected in Athena.
 ---------------------------------------------------------------------------------
 """
   
import sys
import time
import datetime
from random import randrange
import random
import re
from time import gmtime, strftime
import pyautogui
import pywinauto
import RPA.Windows as rpawin
import typing
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows
from pywinauto import timings
from pywinauto import findbestmatch
from pywinauto.application import Application
from RPA.core.windows.locators import WindowsElement
from utils_basic   import  focus_window_py


DELIMITER_LEN = 30
AlteraWindow = "Altera Gateway"
_static_win = None


dict = {
    "TonyStark":  ["Genius", "Billionarie",  "Playboy"],  
    "SteveRogers": ["Super Soldier", "Captain America", "Avenger"],
    "BruceBanner": ["Genius", "Hulk", "Avenger"],
    "NatashaRomanoff": ["Black Widow", "Avenger"],
    "ClintBarton": ["Hawkeye", "Avenger"]
}

def Get_Altera_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if "Altera Gateway" in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id, handle=proc.handle)
            break
    return app,proc

def Enter_Order_Item_Py(indexSearch, itemName):
    logger.console(f"   Enter_Order_Item() ...[Py]")
    logger.console(f"      index='{indexSearch}', name='{itemName}'...[Py]")
    focus_window_py("Orders with Alerts")
    indexSearch = int(indexSearch)
    app, proc = Get_Altera_App()
  
    try:
        dlg = app.window(handle=proc.handle)
        dlg = dlg.child_window(title_re="Order Entry Worksheet.*", found_index=0) #dlg.print_control_identifiers()
        dlg = dlg.child_window(title_re="BMT_Admit.*", found_index=0)
        dlg = dlg.child_window(title_re="Orders with Alerts.*Warnings or Errors.*", found_index=0)
        dlg = dlg.child_window(title="Order Items",control_type="List")
        
        allRows = dlg.children(control_type="ListItem") # GET ALL ROWS

        for row in allRows:
            orderIndex = row.legacy_properties()['ChildId']
            if orderIndex==indexSearch:
                logger.console(f"      double Clicking OrderItem ...[Py]")
                row.double_click_input()

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Enter_Order_Item' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")


if __name__ == '__main__':
    logger.console(f"\nBEGIN MAIN....\n")
    #Enter_Order_Item_Py(1, "Clostridium Difficile Antigen And Toxin Result Alert")
