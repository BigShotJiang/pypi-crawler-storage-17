"""
----------------------------------------------------------------------------------
 Author:  Frank Runfola
 Created: 12/01/2024
----------------------------------------------------------------------------------
"""

import sys
import time
import datetime
from random import randrange
import random
import re
from time import gmtime, strftime
import pyautogui
import pywinauto
import RPA.Windows as rpawin
import typing
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
import pywinauto.base_wrapper
import pywinauto.controls
import pywinauto.element_info
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows
from pywinauto import timings
from pywinauto import findbestmatch
from pywinauto.application import Application


_static_win = None
App               =  "Altera"   # Altera   configurable for PR38
Gateway           =  "Gateway"
#
AppGatewayLogon   =  App + " " + Gateway + " " + "Logon"
AppGateway        =  App + " " + Gateway
#
AllergiesIntolerances = "Allergies/Intolerances"
AllergiesIntolSumm = "Allergies/Intolerances Summary"

###################################################################################
#  TODO (REFACTOR) NEEDS TO BE IMPLEMENTED WITH ALL THE Altera DIALOGUES
###################################################################################
def Get_Altera_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if AppGateway in proc.name: 
            app = app.connect(process=proc.process_id,handle=proc.handle)
            break
    return app

#################################################################################################
#                           For Adding 4 Allergies
#################################################################################################
def verify_new_allergies_in_banner_py(allergy): 
    logger.console(f"   verify_new_allergies_in_banner_py() ...[Py]")
    found = str(False)
    try:
        dlgText  = get_allergy_banner_dialogue_text()
        found = search_allergy_in_banner(allergy,dlgText)
    except Exception as e:
        logger.console(f"\n**ERROR** {allergy} not found[Py]")
        logger.console(f"(Error={e}[Py]")
        raise Exception(f"{e}")
        
    finally:
        logger.console(f"      New Allergies In Banner = {found} [Py]")
    
    return found

def search_multiple_new_allergies_in_banner(allergiesText, dlgText):
    logger.console(f"   search_new_allergies_in_banner() ...[Py]")
    logger.console(f"      allergiesText = {allergiesText}, dlgText = {dlgText} ...[Py]\n")
    found = str(False)
    regexAllergies = "^(.*)({ALBUTEROL})(.*)(ANDROGENS)(.*)(BARLEY)(.*)(DU)(.*)$"
    dlgTextUp = str(dlgText).upper().split("ALLERGIES:",1)[1].strip()
    logger.console(f"      dlgTextUpper = {dlgTextUp} [Py]")
    allergiesFound = RegexSearchForValue(regexAllergies, dlgTextUp)
    noKnownAlgText = "NO KNOWN ALLERGIES"
    
    if allergiesFound is True:
        logger.console(f"      PASS - '{allergiesText}' FOUND in Intolerances [Py]")
        regexNoKnownAllg = f"^(.*)({noKnownAlgText})(.*)$"
        noKnownAllgFound = RegexSearchForValue(regexNoKnownAllg, dlgTextUp)
        
        if  noKnownAllgFound is False:
            logger.console(f"      PASS - '{noKnownAlgText}' NOT FOUND in Intolerances [Py]")
            found = str(True)
        else:
            logger.console(f"      FAIL - '{noKnownAlgText}' IS FOUND in Intolerances [Py]")

    else: 
        logger.console(f"      FAIL-('{noKnownAlgText} NOT FOUND[Py]") 
    return found



#################################################################################################
#                                    Free Text, Discontinue
#################################################################################################
def verify_new_allergy_in_banner_py(allergy): #"un-coded"
    logger.console(f"   verify_new_allergy_in_banner_py ...[Py]")
    logger.console(f"      allergy = {allergy} ...[Py]\n")
    found = str(False)
    try:
        dlgText  = get_allergy_banner_dialogue_text()
        found = search_allergy_in_banner(allergy,dlgText)
    except Exception as e:
        logger.console(f"   **ERROR** {allergy} not found[Py]")
        logger.console(f"   (Error={e}[Py]")
        raise Exception(f"{e}")
        
    finally:
        logger.console(f"      New Allergy In Banner = {found} ...[Py]\n")

    return found

def get_allergy_banner_dialogue_text():
    procs = findwindows.find_elements()
    for proc in procs:
        if AppGateway in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id, handle=proc.handle) # 10,000 items
            break
    dlg = app.window(title_re='.*22.1.*PR.*', class_name="Window")
    dlg = dlg.child_window(class_name="ScmApplicationHost", control_type="Custom", found_index=0)     #dlg = dlg.children()
    dlg = dlg.child_window(auto_id="_patientHeader", control_type="Custom")  #dlg.print_control_identifiers()
    dlg = dlg.child_window(class_name="StandardPatientHeader", control_type="Custom")
    dlg = dlg.child_window(title_re=f".*Allergies.*", auto_id="SecondAdditionalLineRTF")
    dlgText = dlg.window_text() #texts()
    return dlgText
    
def search_allergy_in_banner(allergy,dlgText):
    logger.console(f"   search_uncoded_allergy_in_banner() ...[Py]")
    logger.console(f"      allergy = {allergy}, dlgText = {dlgText} ...[Py]\n")
    found = str(False)
    allergyUpper = str(allergy).upper()
    regex = f"^(.*)({allergyUpper})(.*)$"
    dlgTextUp = str(dlgText).upper().split("ALLERGIES:",1)[1].strip()
    logger.console(f"   dlgTextUpper = {dlgTextUp} (Searching for {allergyUpper}) [Py]")
    allergiesFound = RegexSearchForValue(regex, dlgTextUp)
    
    if allergiesFound is True:
        logger.console(f"      PASS - '{allergyUpper}' FOUND in ALLERGIES ...[Py]\n")
        found = str(True)            
    else:
        logger.console(f"      FAIL - '{allergyUpper}' NOT FOUND ...[Py]\n")

    return found


def Select_Reaction_And_Severity(reactionRow, text, freeTextAllergy=False):
    try:
        logger.console(f"      Select_Reaction_And_Severity ...[Py]")
        proc = Get_Allergies_Summary_View_Proc()
        dlgAddNewWin, dlgAddNewPane, reactionText = Get_Reaction_Item(proc, reactionRow)
        Click_Reaction(reactionText,text,reactionRow )
        Choose_Serverity(dlgAddNewPane)
        Click_OK_Reaction_Details(dlgAddNewWin)
        
        if freeTextAllergy == True:
            logger.console(f"      [freeTextAllergy = {freeTextAllergy}] ...[Py]") 
            Enter_Description_For_Other_Allergen(proc) 
            Click_OK_Allergy_Intolerance_Adding_New(proc)
            Click_Uncoded_Allergy_Warning_Message(proc)
        else:
            Click_OK_Allergy_Intolerance_Adding_New(proc)
    
    except Exception as e:
        logger.console(f"   Select_Reaction_And_Severity ERROR = {e} ...")
        raise Exception(f"{e}")

def Enter_Description_For_Other_Allergen(proc):
    try:
        logger.console(f"         Entering Description for <Other> Allergen ...[Py]")
        app = Application(backend="uia").connect(process=proc.process_id)
        dlgSumView= app.window(handle=proc.handle).window(auto_id="XAForm", class_name_re = "WindowsForms10.*", found_index=0)
        dlgAllDet = dlgSumView.child_window(auto_id="AllergyDetail", control_type="Pane")
        dlgGrpDet = dlgAllDet.child_window(auto_id="grpDetails", control_type="Group")
        dlgEdit = dlgGrpDet.child_window(auto_id="txtDescription", control_type="Edit")
        dlgEdit.click_input()
        pyautogui.typewrite("<Other> Description")
    
    except Exception as e:
        logger.console(f"         Enter_Description_For_Other_Allergen ERROR = {e} ...")
        raise Exception(f"{e}")


def Get_Allergies_Summary_View_Proc():
    time.sleep(2)
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    procFound = None
    for proc in procs:
        if AllergiesIntolSumm in proc.name:
            procFound = proc 
            break
    return procFound


def Get_Reaction_Item(proc, reactionRow):
        app = Application(backend="uia").connect(process=proc.process_id)
        dlgSumView= app.window(handle=proc.handle).window(auto_id="XAForm", class_name_re = "WindowsForms10.*", found_index=0)
        dlgAddNewWin = dlgSumView.child_window(auto_id="XAForm", control_type="Window", title="Reaction Details")
        dlgAddNewPane = dlgAddNewWin.child_window(auto_id="ReactionDetails", control_type="Pane")
        dlgGrp = dlgAddNewPane.child_window(auto_id="grpbxMain", control_type="Group")
        dlgTable = dlgGrp.child_window(auto_id="dgReactions", control_type="Table")  #dlg.print_control_identifiers()
        dlgRow2 = dlgTable.child_window(title=reactionRow, control_type="Custom",found_index=0) 
        dlgRow2.click_input()
        reactionText = dlgRow2.DataItem 
        return dlgAddNewWin, dlgAddNewPane, reactionText

def find_no_known_allergies_line_item(): #child_window(title=" SSA(s): Paragh MD,; Fountzilas MD, Intolerances:  Allergies:  No Known Allergies",
    logger.console(f"   find_no_known_allergies_line_item() ...[Py]")
    time.sleep(2)
    found = str(False)
    app = Get_Altera_App()
    try:
        dlg = app.window(title_re='.*22.1.*PR.*', control_type="Window") #props = dlg.legacy_properties()
        dlg = dlg.window(auto_id="XAForm", class_name_re="WindowsForms10.*")
        dlg = dlg.child_window(auto_id="AllergySummary", control_type="Pane")  #props = dlg.legacy_properties()
        dlg = dlg.child_window(auto_id="dgAllergies", control_type="Table")
        dlg = dlg.child_window(title="Allergies", control_type="Table") #dlg.print_control_identifiers()
        dlg = dlg.child_window(title="Allergies row 1", control_type="Custom", found_index=0)  
        dlg = dlg.child_window(title_re="Allergies row.*", control_type="Custom", found_index=0) # GET THE FIRST ROW
        dlg = dlg.child_window(title="Allergen/Product", control_type="DataItem")
        text = str(dlg.legacy_properties()['Value']) # GET THE TEXT!
        noKnownAllergies = "No Known Allergies"
        
        if noKnownAllergies in text:
            found = str(True)

        logger.console(f"      allergy = '{text}'...[Py]")

    except Exception as e:
        logger.console(f"   **ERROR** 'No Known Allgeries' not found [Py]")
        logger.console(f"   (Error={e} [Py]\n")
        raise Exception(f"{e}")
    finally:
        logger.console(f"      'No Known Allgeries' = {found} [Py]\n")

    return found


def Click_Reaction(dlgReaction, text, reactionRow):
        logger.console(f"      Clicking '{text}' ({reactionRow})...[Py]")
        dlgReaction.click_input()
        pyautogui.press("TAB")
        pyautogui.press("ENTER")

def Choose_Serverity(dlg):
    logger.console(f"      Typing 'mild'...[Py]") #dlg.print_control_identifiers(filename="ids.txt") # print id's to file
    dlg = dlg.child_window(auto_id="dgReactions_EmbeddableTextBox", control_type="Edit")
    dlg.type_keys("mild") # TODO **Make Severity Dynamic

def Click_OK_Allergy_Intolerance_Adding_New(proc):
    try:
        logger.console(f"         Click 'OK'(Adding New)...[Py]")
        app = Application(backend="uia").connect(process=proc.process_id)
        dlgSumView= app.window(handle=proc.handle).window(auto_id="XAForm", class_name_re = "WindowsForms10.*", found_index=0)
        dlgSumView.click_input()
        dlgAllDet = dlgSumView.child_window(auto_id="AllergyDetail", control_type="Pane")#
        dlgPnl = dlgAllDet.child_window(auto_id="pnlActionButtons", control_type="Pane")
        dlgPnlBottom = dlgPnl.child_window(auto_id="pnlBottomDock", control_type="Pane")
        dlgOk = dlgPnlBottom.child_window(auto_id="btnOk", control_type="Button")#dlgAllDet.print_control_identifiers()
        dlgOk.click_input()
    except Exception as e:
        logger.console(f"         Click_OK_Allergy_Intolerance_Adding_New ERROR = {e} ...")
        raise Exception(f"{e}")
        
def Click_Uncoded_Allergy_Warning_Message(proc):
    try:
        logger.console(f"         Click_Uncoded_Allergy_Warning_Message ...[Py]")
        app = Application(backend="uia").connect(process=proc.process_id)
        dlgSumView= app.window(handle=proc.handle).window(auto_id="XAForm", class_name_re = "WindowsForms10.*", found_index=0)
        dlgSumView.click_input()
        #dlgAddNew = dlgSumView.window(auto_id="XAForm", control_type="Window")
        dlgWarn = dlgSumView.window(title="Un-coded Allergy Warning Message", control_type="Window")
        dlgOk = dlgWarn.child_window(title="OK", control_type="Button")
        logger.console(f"      Click 'OK' ...[Py]")
        dlgOk.click_input()
        logger.console(f"      PASS - 'Click_Uncoded_Allergy_Warning_Message' found...[Py]\n")
    except Exception as e:
        logger.console(f"   FAIL - Click_Uncoded_Allergy_Warning_Message ERROR = {e} ...")
        raise Exception(f"{e}")
        
def Click_OK_Reaction_Details(dlgRD2):
    try:
        logger.console(f"      Click 'OK'(Reaction Details) ...[Py]")
        dlgOk = dlgRD2.child_window(auto_id="btnOk", control_type="Button")
        dlgOk.click()
    except Exception as e:
        logger.console(f"         Click_OK_Reaction_Details ERROR = {e} ...")
        raise Exception(f"{e}")

def find_uncoded_line_item_py():
    logger.console(f"   find_uncoded_line_item_py() ...[Py]")
    time.sleep(2)
    found = str(False)
    app = Get_Altera_App()
    try:
        dlg = app.window(title_re='.*22.1.*PR.*', control_type="Window") #props = dlg.legacy_properties()
        dlg = dlg.window(auto_id="XAForm", class_name_re="WindowsForms10.*")
        dlg = dlg.child_window(auto_id="AllergySummary", control_type="Pane")  #props = dlg.legacy_properties()
        dlg = dlg.child_window(auto_id="dgAllergies", control_type="Table")
        dlg = dlg.child_window(title="Allergies", control_type="Table") #dlg.print_control_identifiers()
        dlgTopRow = dlg.child_window(title=f"Allergies row 1", control_type="Custom",found_index=0)
        rows = dlgTopRow.children(control_type="Custom")
       
        for row in rows:
            rowName = row.element_info.name #dlg.print_control_identifiers()
            logger.console(f"      checking '{rowName}'", newline=False)
            dlg = dlgTopRow.child_window(title=rowName, control_type="Custom")
            dlg = dlg.child_window(title="Allergen/Product", control_type=f"DataItem")
            text = dlg.legacy_properties()['Value'] # GET THE TEXT!
            logger.console(f"   VALUE = '{text}'   ", newline=False)
            
            if "un-coded" in text:
                found = str(True)
                logger.console(f"PASS-found 'un-coded'...[Py]")
                break
            else:
                logger.console(f"FAIL-notFound...[Py]")

    except Exception as e:
        logger.console(f"      **ERROR** 'Uncoded' not found [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")
    
    finally:
        logger.console(f"      'Uncoded' = {found} ...[Py]\n", newline=False)

    return found

def Verify_Discontinued_Allergy_Is_InActive_Py(discontAllergy):
    logger.console(f"   Verify_Discontinued_Allergy_Is_InActive_Py ...[Py]")
    time.sleep(2)
    found = str(False)
    app = Get_Altera_App()
    try:
        dlg = app.window(title_re='.*22.1.*PR.*', control_type="Window") #props = dlg.legacy_properties()
        dlg = dlg.window(auto_id="XAForm", class_name_re="WindowsForms10.*")
        dlg = dlg.child_window(auto_id="AllergySummary", control_type="Pane")  #props = dlg.legacy_properties()
        dlg = dlg.child_window(auto_id="dgAllergies", control_type="Table")
        dlg = dlg.child_window(title="Allergies", control_type="Table") #dlg.print_control_identifiers()
        dlgTopRow = dlg.child_window(title=f"Allergies row 1", control_type="Custom",found_index=0)
        rows = dlgTopRow.children(control_type="Custom")
       
        for row in rows:
            rowName = row.element_info.name #dlg.print_control_identifiers()
            logger.console(f"      checking '{rowName}'", newline=False)
            dlgCurRow = dlgTopRow.child_window(title=rowName, control_type="Custom")
            dlgAlergy = dlgCurRow.child_window(title="Allergen/Product", control_type=f"DataItem")
            dlgStatus = dlgCurRow.child_window(title="Status", control_type=f"DataItem")
            dlgAlergyText = dlgAlergy.legacy_properties()['Value'] # GET THE TEXT!
            dlgStatusText = dlgStatus.legacy_properties()['Value'] # GET THE TEXT!
            logger.console(f"      ALLERGY = '{dlgAlergyText}'   STATUS = '{dlgStatusText}'")
            
            if discontAllergy in dlgAlergyText and "Inactive" == dlgStatusText:  #LOOK FOR DISCONTINUED LINE
                found = str(True)
                logger.console(f"      found 'un-coded' - PASS ...[Py]")
                break
            else:
                logger.console(f"   not found - FAIL!! ...[Py]")

    except Exception as e:
        logger.console(f"   **ERROR** in 'Verify_Discontinued_Allergy_Is_InActive_Py' [Py]")
        logger.console(f"   (Error={e} [Py]\n")
        raise Exception(f"{e}")
        
    finally:
        logger.console(f"   'found' = {found} ... [Py]\n")

    return found

def find_no_known_allergies_in_banner():
    logger.console(f"   find_no_known_allergies_in_banner ...[Py]")
    app = Get_Altera_App()
    try:
        dlg = app.window(title_re='.*22.1.*PR.*', control_type="Window")
        dlg = dlg.child_window(class_name="ScmApplicationHost", control_type="Custom", found_index=0)     #dlg = dlg.children()
        dlg = dlg.child_window(auto_id="_patientHeader", control_type="Custom")  #dlg.print_control_identifiers()
        dlg = dlg.child_window(class_name="StandardPatientHeader", control_type="Custom") #props = dlg.legacy_properties()       
        found = dlg.child_window(title_re=".*No Known Allergies.*", control_type="Document").exists()
        
        if found == True:
             logger.console(f"   PASS - 'No Known Allergies' found in Banner [Py]")
        else:
            logger.console(f"   FAIL - 'No Known Allergies' NOT found in Banner [Py]")
            raise Exception(f"FAIL - 'No Known Allergies' NOT found in Banner")
            
            
    except Exception as e:
        logger.console(f"**ERROR** 'No Known Allergies' not found [Py]")
        logger.console(f"(Error={e} [Py]\n")
        raise Exception(f"{e}")
        
   
def Verify_Allergy_Is_Removed_From_Banner(discontAllergy):
    logger.console(f"   Verify_Allergy_Is_Removed_From_Banner (Search '{discontAllergy}') ...[Py]")
    try:
        found = str(False)
        app = Get_Altera_App() 
        dlg = app.window(title_re='.*22.1.*PR.*', class_name="Window")
        dlg = dlg.child_window(class_name="ScmApplicationHost", control_type="Custom", found_index=0)     #dlg = dlg.children()
        dlg = dlg.child_window(auto_id="_patientHeader", control_type="Custom")  #dlg.print_control_identifiers()
        dlg = dlg.child_window(class_name="StandardPatientHeader", control_type="Custom")
        dlg = dlg.child_window(title_re=f".* Intolerances:.*", auto_id="SecondAdditionalLineRTF")
        dlgText = dlg.window_text() #texts() 
        bannerTextUpper = str(dlgText).upper().split("ALLERGIES:",1)[1].strip()
        discontAllergyUp = str(discontAllergy).upper()
        logger.console(f"      haystack = '{bannerTextUpper}'   needle = '{discontAllergyUp}' ...[Py]")
        
        if discontAllergyUp not in bannerTextUpper:
                logger.console(f"      PASS - '{discontAllergyUp}' NOT FOUND in Intolerances ...[Py]")
                found = str(True)
        else:
            logger.console(f"      FAIL - '{discontAllergyUp}' IS FOUND in Intolerances ...[Py]")
            
    except Exception as e:
        logger.console(f"   **ERROR** in 'Verify_Allergy_Is_Removed_From_Banner' ...[Py]")
        logger.console(f"   (Error={e} [Py]\n")
        raise Exception(f"{e}")
        
    return found

def is_allergy_enabled_py():
    try:
        logger.console(f"   is_allergy_enabled ...[Py]")
        #appVerify = timings.wait_until_passes(20, 0.5,getAllergyApp) # this will ensure the window is visable before you begin
        time.sleep(4) #make sure windows finish loading
        procs = findwindows.find_elements()
        isEnabled = ''
        for proc in procs:
            if "Allergies/Intolerances" in proc.name:
                app = Application(backend="uia").connect(process=proc.process_id)
                break
    
        win = app.window(handle=proc.handle).window(auto_id="XAForm", class_name_re="WindowsForms10.*")
        win = win.child_window(auto_id="AllergyType", class_name_re="WindowsForms10.*")
        #win.wait('visible', timeout=5)
        win = win.child_window(auto_id="grpbxMain", class_name_re="WindowsForms10.*")  #props = dlg.legacy_properties()
        win = win.child_window(auto_id="rdoNoKnownAllergies")  #app.print_control_identifiers()
        isEnabled = win.is_enabled()
    except Exception as e:
        logger.console(f"      is_allergy_enabled ERROR = {e} ...")
        raise Exception(f"{e}")
    finally:
        logger.console(f"      isEnabled = {isEnabled} ...")
    return isEnabled



def getAllergyApp():
    winHandle = findwindows.find_windows(title_re=f'${AllergiesIntolerances}.*', class_name_re="WindowsForms10.*")[0]
    app = Application(backend="uia").connect(handle=winHandle)
    return app



def RegexSearchForValue(regex,value):
        valueHasNewLine = re.search(regex, value)
        isMatch = bool(valueHasNewLine)
        return isMatch
    

if __name__ == '__main__':
    logger.console(f"\nBEGIN MAIN....\n")
    verify_new_allergies_in_banner_py("albuterol, androgens, Barley, Dust")