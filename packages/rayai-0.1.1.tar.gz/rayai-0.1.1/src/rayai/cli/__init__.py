"""RayAI CLI package."""

from .cli import main

__all__ = ["main"]
