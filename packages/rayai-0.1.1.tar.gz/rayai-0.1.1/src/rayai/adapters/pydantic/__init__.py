"""Pydantic AI tools for Ray distributed execution."""

from rayai.adapters.pydantic.tools import from_pydantic_tool

__all__ = ["from_pydantic_tool"]
