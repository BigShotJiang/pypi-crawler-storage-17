"""LangChain tools for Ray Agents."""

from rayai.adapters.langchain.tools import from_langchain_tool

__all__ = ["from_langchain_tool"]
