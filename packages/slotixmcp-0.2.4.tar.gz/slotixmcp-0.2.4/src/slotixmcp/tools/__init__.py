"""Tools module (tools are defined in server.py for simplicity)."""
