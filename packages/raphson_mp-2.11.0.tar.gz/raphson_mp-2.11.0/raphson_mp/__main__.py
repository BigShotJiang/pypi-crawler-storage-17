from raphson_mp.cli import cli


cli.main()
