# brdb
[![GitHub stars](https://img.shields.io/github/stars/braveua/brdb?style=social)](https://github.com/braveua/brdb)

**brdb** – lib for ora db.

## 📦 Установка

```bash
uv add brdb
```