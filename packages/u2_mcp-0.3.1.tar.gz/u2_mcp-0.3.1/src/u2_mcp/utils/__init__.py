"""Utility functions for u2-mcp."""
