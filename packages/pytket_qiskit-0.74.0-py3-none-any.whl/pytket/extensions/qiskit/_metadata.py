__extension_version__ = "0.74.0"
__extension_name__ = "pytket-qiskit"
