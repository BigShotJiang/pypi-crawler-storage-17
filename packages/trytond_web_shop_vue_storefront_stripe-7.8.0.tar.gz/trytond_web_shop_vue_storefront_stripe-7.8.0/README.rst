Web Shop Vue Storefront Stripe Module
#####################################

The web_shop_vue_storefront_stripe module provides support of `Stripe payment
for Vue Storefront`_ integration.

.. _`Stripe payment for Vue Storefront`: https://github.com/develodesign/vsf-payment-stripe
