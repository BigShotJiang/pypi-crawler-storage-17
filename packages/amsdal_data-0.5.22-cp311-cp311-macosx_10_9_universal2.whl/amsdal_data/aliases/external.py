# External service connection aliases
EMAIL_ALIAS = 'email'
EMAIL_ASYNC_ALIAS = 'email-async'
IMAP_ALIAS = 'imap'
IMAP_ASYNC_ALIAS = 'imap-async'
STORAGE_ALIAS = 'storage'
STORAGE_ASYNC_ALIAS = 'storage-async'
CACHE_ALIAS = 'cache'
CACHE_ASYNC_ALIAS = 'cache-async'
