#################################
Web Shop Product Data Feed Module
#################################

The *Web Shop Product Data Feed Module* exposes products of web shop as data
feed for `Google Merchant <https://merchants.google.com/>`_ and `Meta for
business <https://www.facebook.com/business/>`_.

.. toctree::
   :maxdepth: 2

   usage
   configuration
   design
   reference
   releases
