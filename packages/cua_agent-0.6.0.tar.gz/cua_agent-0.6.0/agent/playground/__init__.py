"""Playground server for CUA agents."""

from .server import PlaygroundServer

__all__ = ["PlaygroundServer"]
