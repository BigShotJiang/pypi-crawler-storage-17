"""
Implementation of the Nest models for cerebellar cortex simulations.
"""
