# szn-search-mlops-signals-downloader

This is a security placeholder package created to prevent dependency confusion attacks.