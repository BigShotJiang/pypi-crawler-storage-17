from __future__ import annotations
from win32more._prelude import *
import win32more.Microsoft.UI.Composition
import win32more.Microsoft.UI.Content
import win32more.Microsoft.UI.Dispatching
import win32more.Microsoft.UI.Input
import win32more.Microsoft.UI.Windowing
import win32more.Microsoft.UI.Xaml
import win32more.Microsoft.UI.Xaml.Automation.Peers
import win32more.Microsoft.UI.Xaml.Controls
import win32more.Microsoft.UI.Xaml.Controls.Primitives
import win32more.Microsoft.UI.Xaml.Data
import win32more.Microsoft.UI.Xaml.Input
import win32more.Microsoft.UI.Xaml.Media
import win32more.Microsoft.UI.Xaml.Media.Animation
import win32more.Microsoft.UI.Xaml.Media.Imaging
import win32more.Microsoft.UI.Xaml.Media.Media3D
import win32more.Microsoft.Windows.ApplicationModel.Resources
import win32more.Windows.ApplicationModel
import win32more.Windows.ApplicationModel.Activation
import win32more.Windows.ApplicationModel.Core
import win32more.Windows.ApplicationModel.DataTransfer
import win32more.Windows.ApplicationModel.DataTransfer.DragDrop
import win32more.Windows.Foundation
import win32more.Windows.Foundation.Collections
import win32more.Windows.Foundation.Numerics
import win32more.Windows.Graphics.Imaging
import win32more.Windows.UI
import win32more.Windows.UI.Core
import win32more.Windows.UI.Xaml.Interop
class _AdaptiveTrigger_Meta_(ComPtr.__class__):
    pass
class AdaptiveTrigger(ComPtr, metaclass=_AdaptiveTrigger_Meta_):
    extends: win32more.Microsoft.UI.Xaml.StateTriggerBase
    default_interface: win32more.Microsoft.UI.Xaml.IAdaptiveTrigger
    _classid_ = 'Microsoft.UI.Xaml.AdaptiveTrigger'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.AdaptiveTrigger.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IAdaptiveTriggerFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.AdaptiveTrigger: ...
    @winrt_mixinmethod
    def get_MinWindowWidth(self: win32more.Microsoft.UI.Xaml.IAdaptiveTrigger) -> Double: ...
    @winrt_mixinmethod
    def put_MinWindowWidth(self: win32more.Microsoft.UI.Xaml.IAdaptiveTrigger, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_MinWindowHeight(self: win32more.Microsoft.UI.Xaml.IAdaptiveTrigger) -> Double: ...
    @winrt_mixinmethod
    def put_MinWindowHeight(self: win32more.Microsoft.UI.Xaml.IAdaptiveTrigger, value: Double) -> Void: ...
    @winrt_classmethod
    def get_MinWindowWidthProperty(cls: win32more.Microsoft.UI.Xaml.IAdaptiveTriggerStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_MinWindowHeightProperty(cls: win32more.Microsoft.UI.Xaml.IAdaptiveTriggerStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    MinWindowHeight = property(get_MinWindowHeight, put_MinWindowHeight)
    MinWindowWidth = property(get_MinWindowWidth, put_MinWindowWidth)
    _AdaptiveTrigger_Meta_.MinWindowHeightProperty = property(get_MinWindowHeightProperty, None)
    _AdaptiveTrigger_Meta_.MinWindowWidthProperty = property(get_MinWindowWidthProperty, None)
class _Application_Meta_(ComPtr.__class__):
    pass
class Application(ComPtr, metaclass=_Application_Meta_):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IApplication
    _classid_ = 'Microsoft.UI.Xaml.Application'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.Application.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IApplicationFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.Application: ...
    @winrt_mixinmethod
    def get_Resources(self: win32more.Microsoft.UI.Xaml.IApplication) -> win32more.Microsoft.UI.Xaml.ResourceDictionary: ...
    @winrt_mixinmethod
    def put_Resources(self: win32more.Microsoft.UI.Xaml.IApplication, value: win32more.Microsoft.UI.Xaml.ResourceDictionary) -> Void: ...
    @winrt_mixinmethod
    def get_DebugSettings(self: win32more.Microsoft.UI.Xaml.IApplication) -> win32more.Microsoft.UI.Xaml.DebugSettings: ...
    @winrt_mixinmethod
    def get_RequestedTheme(self: win32more.Microsoft.UI.Xaml.IApplication) -> win32more.Microsoft.UI.Xaml.ApplicationTheme: ...
    @winrt_mixinmethod
    def put_RequestedTheme(self: win32more.Microsoft.UI.Xaml.IApplication, value: win32more.Microsoft.UI.Xaml.ApplicationTheme) -> Void: ...
    @winrt_mixinmethod
    def get_FocusVisualKind(self: win32more.Microsoft.UI.Xaml.IApplication) -> win32more.Microsoft.UI.Xaml.FocusVisualKind: ...
    @winrt_mixinmethod
    def put_FocusVisualKind(self: win32more.Microsoft.UI.Xaml.IApplication, value: win32more.Microsoft.UI.Xaml.FocusVisualKind) -> Void: ...
    @winrt_mixinmethod
    def get_HighContrastAdjustment(self: win32more.Microsoft.UI.Xaml.IApplication) -> win32more.Microsoft.UI.Xaml.ApplicationHighContrastAdjustment: ...
    @winrt_mixinmethod
    def put_HighContrastAdjustment(self: win32more.Microsoft.UI.Xaml.IApplication, value: win32more.Microsoft.UI.Xaml.ApplicationHighContrastAdjustment) -> Void: ...
    @winrt_mixinmethod
    def add_UnhandledException(self: win32more.Microsoft.UI.Xaml.IApplication, handler: win32more.Microsoft.UI.Xaml.UnhandledExceptionEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_UnhandledException(self: win32more.Microsoft.UI.Xaml.IApplication, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def Exit(self: win32more.Microsoft.UI.Xaml.IApplication) -> Void: ...
    @winrt_mixinmethod
    def add_ResourceManagerRequested(self: win32more.Microsoft.UI.Xaml.IApplication2, handler: win32more.Windows.Foundation.TypedEventHandler[IInspectable, win32more.Microsoft.UI.Xaml.ResourceManagerRequestedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_ResourceManagerRequested(self: win32more.Microsoft.UI.Xaml.IApplication2, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def get_DispatcherShutdownMode(self: win32more.Microsoft.UI.Xaml.IApplication3) -> win32more.Microsoft.UI.Xaml.DispatcherShutdownMode: ...
    @winrt_mixinmethod
    def put_DispatcherShutdownMode(self: win32more.Microsoft.UI.Xaml.IApplication3, value: win32more.Microsoft.UI.Xaml.DispatcherShutdownMode) -> Void: ...
    @winrt_mixinmethod
    def OnLaunched(self: win32more.Microsoft.UI.Xaml.IApplicationOverrides, args: win32more.Microsoft.UI.Xaml.LaunchActivatedEventArgs) -> Void: ...
    @winrt_classmethod
    def get_Current(cls: win32more.Microsoft.UI.Xaml.IApplicationStatics) -> win32more.Microsoft.UI.Xaml.Application: ...
    @winrt_classmethod
    def Start(cls: win32more.Microsoft.UI.Xaml.IApplicationStatics, callback: win32more.Microsoft.UI.Xaml.ApplicationInitializationCallback) -> Void: ...
    @winrt_classmethod
    def LoadComponent(cls: win32more.Microsoft.UI.Xaml.IApplicationStatics, component: IInspectable, resourceLocator: win32more.Windows.Foundation.Uri) -> Void: ...
    @winrt_classmethod
    def LoadComponentWithResourceLocation(cls: win32more.Microsoft.UI.Xaml.IApplicationStatics, component: IInspectable, resourceLocator: win32more.Windows.Foundation.Uri, componentResourceLocation: win32more.Microsoft.UI.Xaml.Controls.Primitives.ComponentResourceLocation) -> Void: ...
    DebugSettings = property(get_DebugSettings, None)
    DispatcherShutdownMode = property(get_DispatcherShutdownMode, put_DispatcherShutdownMode)
    FocusVisualKind = property(get_FocusVisualKind, put_FocusVisualKind)
    HighContrastAdjustment = property(get_HighContrastAdjustment, put_HighContrastAdjustment)
    RequestedTheme = property(get_RequestedTheme, put_RequestedTheme)
    Resources = property(get_Resources, put_Resources)
    _Application_Meta_.Current = property(get_Current, None)
    ResourceManagerRequested = event(add_ResourceManagerRequested, remove_ResourceManagerRequested)
    UnhandledException = event(add_UnhandledException, remove_UnhandledException)
class ApplicationHighContrastAdjustment(Enum, UInt32):
    _name_ = 'Microsoft.UI.Xaml.ApplicationHighContrastAdjustment'
    None_ = 0
    Auto = 4294967295
class ApplicationInitializationCallback(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{d8eef1c9-1234-56f1-9963-45dd9c80a661}')
    @winrt_commethod(3)
    def Invoke(self, p: win32more.Microsoft.UI.Xaml.ApplicationInitializationCallbackParams) -> Void: ...
class ApplicationInitializationCallbackParams(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IApplicationInitializationCallbackParams
    _classid_ = 'Microsoft.UI.Xaml.ApplicationInitializationCallbackParams'
class ApplicationRequiresPointerMode(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.ApplicationRequiresPointerMode'
    Auto = 0
    WhenRequested = 1
class ApplicationTheme(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.ApplicationTheme'
    Light = 0
    Dark = 1
class AutomationTextAttributesEnum(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.AutomationTextAttributesEnum'
    AnimationStyleAttribute = 40000
    BackgroundColorAttribute = 40001
    BulletStyleAttribute = 40002
    CapStyleAttribute = 40003
    CultureAttribute = 40004
    FontNameAttribute = 40005
    FontSizeAttribute = 40006
    FontWeightAttribute = 40007
    ForegroundColorAttribute = 40008
    HorizontalTextAlignmentAttribute = 40009
    IndentationFirstLineAttribute = 40010
    IndentationLeadingAttribute = 40011
    IndentationTrailingAttribute = 40012
    IsHiddenAttribute = 40013
    IsItalicAttribute = 40014
    IsReadOnlyAttribute = 40015
    IsSubscriptAttribute = 40016
    IsSuperscriptAttribute = 40017
    MarginBottomAttribute = 40018
    MarginLeadingAttribute = 40019
    MarginTopAttribute = 40020
    MarginTrailingAttribute = 40021
    OutlineStylesAttribute = 40022
    OverlineColorAttribute = 40023
    OverlineStyleAttribute = 40024
    StrikethroughColorAttribute = 40025
    StrikethroughStyleAttribute = 40026
    TabsAttribute = 40027
    TextFlowDirectionsAttribute = 40028
    UnderlineColorAttribute = 40029
    UnderlineStyleAttribute = 40030
    AnnotationTypesAttribute = 40031
    AnnotationObjectsAttribute = 40032
    StyleNameAttribute = 40033
    StyleIdAttribute = 40034
    LinkAttribute = 40035
    IsActiveAttribute = 40036
    SelectionActiveEndAttribute = 40037
    CaretPositionAttribute = 40038
    CaretBidiModeAttribute = 40039
class BindingFailedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IBindingFailedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.BindingFailedEventArgs'
    @winrt_mixinmethod
    def get_Message(self: win32more.Microsoft.UI.Xaml.IBindingFailedEventArgs) -> hstr: ...
    Message = property(get_Message, None)
class BindingFailedEventHandler(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{a3160ab0-a8a9-5f38-af17-5cd91a2b33f5}')
    @winrt_commethod(3)
    def Invoke(self, sender: IInspectable, e: win32more.Microsoft.UI.Xaml.BindingFailedEventArgs) -> Void: ...
class BringIntoViewOptions(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions
    _classid_ = 'Microsoft.UI.Xaml.BringIntoViewOptions'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.BringIntoViewOptions.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.BringIntoViewOptions: ...
    @winrt_mixinmethod
    def get_AnimationDesired(self: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions) -> Boolean: ...
    @winrt_mixinmethod
    def put_AnimationDesired(self: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_TargetRect(self: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions) -> win32more.Windows.Foundation.IReference[win32more.Windows.Foundation.Rect]: ...
    @winrt_mixinmethod
    def put_TargetRect(self: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions, value: win32more.Windows.Foundation.IReference[win32more.Windows.Foundation.Rect]) -> Void: ...
    @winrt_mixinmethod
    def get_HorizontalAlignmentRatio(self: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions) -> Double: ...
    @winrt_mixinmethod
    def put_HorizontalAlignmentRatio(self: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_VerticalAlignmentRatio(self: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions) -> Double: ...
    @winrt_mixinmethod
    def put_VerticalAlignmentRatio(self: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_HorizontalOffset(self: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions) -> Double: ...
    @winrt_mixinmethod
    def put_HorizontalOffset(self: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_VerticalOffset(self: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions) -> Double: ...
    @winrt_mixinmethod
    def put_VerticalOffset(self: win32more.Microsoft.UI.Xaml.IBringIntoViewOptions, value: Double) -> Void: ...
    AnimationDesired = property(get_AnimationDesired, put_AnimationDesired)
    HorizontalAlignmentRatio = property(get_HorizontalAlignmentRatio, put_HorizontalAlignmentRatio)
    HorizontalOffset = property(get_HorizontalOffset, put_HorizontalOffset)
    TargetRect = property(get_TargetRect, put_TargetRect)
    VerticalAlignmentRatio = property(get_VerticalAlignmentRatio, put_VerticalAlignmentRatio)
    VerticalOffset = property(get_VerticalOffset, put_VerticalOffset)
class BringIntoViewRequestedEventArgs(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.RoutedEventArgs
    default_interface: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.BringIntoViewRequestedEventArgs'
    @winrt_mixinmethod
    def get_TargetElement(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_mixinmethod
    def put_TargetElement(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    @winrt_mixinmethod
    def get_AnimationDesired(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs) -> Boolean: ...
    @winrt_mixinmethod
    def put_AnimationDesired(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_TargetRect(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs) -> win32more.Windows.Foundation.Rect: ...
    @winrt_mixinmethod
    def put_TargetRect(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs, value: win32more.Windows.Foundation.Rect) -> Void: ...
    @winrt_mixinmethod
    def get_HorizontalAlignmentRatio(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs) -> Double: ...
    @winrt_mixinmethod
    def get_VerticalAlignmentRatio(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs) -> Double: ...
    @winrt_mixinmethod
    def get_HorizontalOffset(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs) -> Double: ...
    @winrt_mixinmethod
    def put_HorizontalOffset(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_VerticalOffset(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs) -> Double: ...
    @winrt_mixinmethod
    def put_VerticalOffset(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_Handled(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs) -> Boolean: ...
    @winrt_mixinmethod
    def put_Handled(self: win32more.Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs, value: Boolean) -> Void: ...
    AnimationDesired = property(get_AnimationDesired, put_AnimationDesired)
    Handled = property(get_Handled, put_Handled)
    HorizontalAlignmentRatio = property(get_HorizontalAlignmentRatio, None)
    HorizontalOffset = property(get_HorizontalOffset, put_HorizontalOffset)
    TargetElement = property(get_TargetElement, put_TargetElement)
    TargetRect = property(get_TargetRect, put_TargetRect)
    VerticalAlignmentRatio = property(get_VerticalAlignmentRatio, None)
    VerticalOffset = property(get_VerticalOffset, put_VerticalOffset)
class BrushTransition(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IBrushTransition
    _classid_ = 'Microsoft.UI.Xaml.BrushTransition'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.BrushTransition.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IBrushTransitionFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.BrushTransition: ...
    @winrt_mixinmethod
    def get_Duration(self: win32more.Microsoft.UI.Xaml.IBrushTransition) -> win32more.Windows.Foundation.TimeSpan: ...
    @winrt_mixinmethod
    def put_Duration(self: win32more.Microsoft.UI.Xaml.IBrushTransition, value: win32more.Windows.Foundation.TimeSpan) -> Void: ...
    Duration = property(get_Duration, put_Duration)
class ColorPaletteResources(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.ResourceDictionary
    default_interface: win32more.Microsoft.UI.Xaml.IColorPaletteResources
    _classid_ = 'Microsoft.UI.Xaml.ColorPaletteResources'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.ColorPaletteResources.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IColorPaletteResourcesFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.ColorPaletteResources: ...
    @winrt_mixinmethod
    def get_AltHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_AltHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_AltLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_AltLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_AltMedium(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_AltMedium(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_AltMediumHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_AltMediumHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_AltMediumLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_AltMediumLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_BaseHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_BaseHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_BaseLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_BaseLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_BaseMedium(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_BaseMedium(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_BaseMediumHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_BaseMediumHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_BaseMediumLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_BaseMediumLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeAltLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeAltLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeBlackHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeBlackHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeBlackLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeBlackLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeBlackMediumLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeBlackMediumLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeBlackMedium(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeBlackMedium(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeDisabledHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeDisabledHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeDisabledLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeDisabledLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeHigh(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeMedium(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeMedium(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeMediumLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeMediumLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeWhite(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeWhite(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ChromeGray(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ChromeGray(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ListLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ListLow(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ListMedium(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ListMedium(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_ErrorText(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_ErrorText(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_mixinmethod
    def get_Accent(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_mixinmethod
    def put_Accent(self: win32more.Microsoft.UI.Xaml.IColorPaletteResources, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    Accent = property(get_Accent, put_Accent)
    AltHigh = property(get_AltHigh, put_AltHigh)
    AltLow = property(get_AltLow, put_AltLow)
    AltMedium = property(get_AltMedium, put_AltMedium)
    AltMediumHigh = property(get_AltMediumHigh, put_AltMediumHigh)
    AltMediumLow = property(get_AltMediumLow, put_AltMediumLow)
    BaseHigh = property(get_BaseHigh, put_BaseHigh)
    BaseLow = property(get_BaseLow, put_BaseLow)
    BaseMedium = property(get_BaseMedium, put_BaseMedium)
    BaseMediumHigh = property(get_BaseMediumHigh, put_BaseMediumHigh)
    BaseMediumLow = property(get_BaseMediumLow, put_BaseMediumLow)
    ChromeAltLow = property(get_ChromeAltLow, put_ChromeAltLow)
    ChromeBlackHigh = property(get_ChromeBlackHigh, put_ChromeBlackHigh)
    ChromeBlackLow = property(get_ChromeBlackLow, put_ChromeBlackLow)
    ChromeBlackMedium = property(get_ChromeBlackMedium, put_ChromeBlackMedium)
    ChromeBlackMediumLow = property(get_ChromeBlackMediumLow, put_ChromeBlackMediumLow)
    ChromeDisabledHigh = property(get_ChromeDisabledHigh, put_ChromeDisabledHigh)
    ChromeDisabledLow = property(get_ChromeDisabledLow, put_ChromeDisabledLow)
    ChromeGray = property(get_ChromeGray, put_ChromeGray)
    ChromeHigh = property(get_ChromeHigh, put_ChromeHigh)
    ChromeLow = property(get_ChromeLow, put_ChromeLow)
    ChromeMedium = property(get_ChromeMedium, put_ChromeMedium)
    ChromeMediumLow = property(get_ChromeMediumLow, put_ChromeMediumLow)
    ChromeWhite = property(get_ChromeWhite, put_ChromeWhite)
    ErrorText = property(get_ErrorText, put_ErrorText)
    ListLow = property(get_ListLow, put_ListLow)
    ListMedium = property(get_ListMedium, put_ListMedium)
class CornerRadius(Structure):
    _name_ = 'Microsoft.UI.Xaml.CornerRadius'
    TopLeft: Double
    TopRight: Double
    BottomRight: Double
    BottomLeft: Double
class CornerRadiusHelper(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.ICornerRadiusHelper
    _classid_ = 'Microsoft.UI.Xaml.CornerRadiusHelper'
    @winrt_classmethod
    def FromRadii(cls: win32more.Microsoft.UI.Xaml.ICornerRadiusHelperStatics, topLeft: Double, topRight: Double, bottomRight: Double, bottomLeft: Double) -> win32more.Microsoft.UI.Xaml.CornerRadius: ...
    @winrt_classmethod
    def FromUniformRadius(cls: win32more.Microsoft.UI.Xaml.ICornerRadiusHelperStatics, uniformRadius: Double) -> win32more.Microsoft.UI.Xaml.CornerRadius: ...
class CreateDefaultValueCallback(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{7f808c05-2ac4-5ad9-ac8a-26890333d81e}')
    @winrt_commethod(3)
    def Invoke(self) -> IInspectable: ...
class DataContextChangedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IDataContextChangedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.DataContextChangedEventArgs'
    @winrt_mixinmethod
    def get_NewValue(self: win32more.Microsoft.UI.Xaml.IDataContextChangedEventArgs) -> IInspectable: ...
    @winrt_mixinmethod
    def get_Handled(self: win32more.Microsoft.UI.Xaml.IDataContextChangedEventArgs) -> Boolean: ...
    @winrt_mixinmethod
    def put_Handled(self: win32more.Microsoft.UI.Xaml.IDataContextChangedEventArgs, value: Boolean) -> Void: ...
    Handled = property(get_Handled, put_Handled)
    NewValue = property(get_NewValue, None)
class _DataTemplate_Meta_(ComPtr.__class__):
    pass
class DataTemplate(ComPtr, metaclass=_DataTemplate_Meta_):
    extends: win32more.Microsoft.UI.Xaml.FrameworkTemplate
    default_interface: win32more.Microsoft.UI.Xaml.IDataTemplate
    _classid_ = 'Microsoft.UI.Xaml.DataTemplate'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.DataTemplate.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IDataTemplateFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.DataTemplate: ...
    @winrt_mixinmethod
    def LoadContent(self: win32more.Microsoft.UI.Xaml.IDataTemplate) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_mixinmethod
    def GetElement(self: win32more.Microsoft.UI.Xaml.IElementFactory, args: win32more.Microsoft.UI.Xaml.ElementFactoryGetArgs) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_mixinmethod
    def RecycleElement(self: win32more.Microsoft.UI.Xaml.IElementFactory, args: win32more.Microsoft.UI.Xaml.ElementFactoryRecycleArgs) -> Void: ...
    @winrt_classmethod
    def get_ExtensionInstanceProperty(cls: win32more.Microsoft.UI.Xaml.IDataTemplateStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def GetExtensionInstance(cls: win32more.Microsoft.UI.Xaml.IDataTemplateStatics, element: win32more.Microsoft.UI.Xaml.FrameworkElement) -> win32more.Microsoft.UI.Xaml.IDataTemplateExtension: ...
    @winrt_classmethod
    def SetExtensionInstance(cls: win32more.Microsoft.UI.Xaml.IDataTemplateStatics, element: win32more.Microsoft.UI.Xaml.FrameworkElement, value: win32more.Microsoft.UI.Xaml.IDataTemplateExtension) -> Void: ...
    _DataTemplate_Meta_.ExtensionInstanceProperty = property(get_ExtensionInstanceProperty, None)
class DataTemplateKey(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IDataTemplateKey
    _classid_ = 'Microsoft.UI.Xaml.DataTemplateKey'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.DataTemplateKey.CreateInstance(*args, None, None))
        elif len(args) == 1:
            super().__init__(move=win32more.Microsoft.UI.Xaml.DataTemplateKey.CreateInstanceWithType(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IDataTemplateKeyFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.DataTemplateKey: ...
    @winrt_factorymethod
    def CreateInstanceWithType(cls: win32more.Microsoft.UI.Xaml.IDataTemplateKeyFactory, dataType: IInspectable, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.DataTemplateKey: ...
    @winrt_mixinmethod
    def get_DataType(self: win32more.Microsoft.UI.Xaml.IDataTemplateKey) -> IInspectable: ...
    @winrt_mixinmethod
    def put_DataType(self: win32more.Microsoft.UI.Xaml.IDataTemplateKey, value: IInspectable) -> Void: ...
    DataType = property(get_DataType, put_DataType)
class DebugSettings(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IDebugSettings
    _classid_ = 'Microsoft.UI.Xaml.DebugSettings'
    @winrt_mixinmethod
    def get_EnableFrameRateCounter(self: win32more.Microsoft.UI.Xaml.IDebugSettings) -> Boolean: ...
    @winrt_mixinmethod
    def put_EnableFrameRateCounter(self: win32more.Microsoft.UI.Xaml.IDebugSettings, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_IsBindingTracingEnabled(self: win32more.Microsoft.UI.Xaml.IDebugSettings) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsBindingTracingEnabled(self: win32more.Microsoft.UI.Xaml.IDebugSettings, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_IsTextPerformanceVisualizationEnabled(self: win32more.Microsoft.UI.Xaml.IDebugSettings) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsTextPerformanceVisualizationEnabled(self: win32more.Microsoft.UI.Xaml.IDebugSettings, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_FailFastOnErrors(self: win32more.Microsoft.UI.Xaml.IDebugSettings) -> Boolean: ...
    @winrt_mixinmethod
    def put_FailFastOnErrors(self: win32more.Microsoft.UI.Xaml.IDebugSettings, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def add_BindingFailed(self: win32more.Microsoft.UI.Xaml.IDebugSettings, handler: win32more.Microsoft.UI.Xaml.BindingFailedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_BindingFailed(self: win32more.Microsoft.UI.Xaml.IDebugSettings, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def get_IsXamlResourceReferenceTracingEnabled(self: win32more.Microsoft.UI.Xaml.IDebugSettings2) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsXamlResourceReferenceTracingEnabled(self: win32more.Microsoft.UI.Xaml.IDebugSettings2, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def add_XamlResourceReferenceFailed(self: win32more.Microsoft.UI.Xaml.IDebugSettings2, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.DebugSettings, win32more.Microsoft.UI.Xaml.XamlResourceReferenceFailedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_XamlResourceReferenceFailed(self: win32more.Microsoft.UI.Xaml.IDebugSettings2, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def get_LayoutCycleTracingLevel(self: win32more.Microsoft.UI.Xaml.IDebugSettings3) -> win32more.Microsoft.UI.Xaml.LayoutCycleTracingLevel: ...
    @winrt_mixinmethod
    def put_LayoutCycleTracingLevel(self: win32more.Microsoft.UI.Xaml.IDebugSettings3, value: win32more.Microsoft.UI.Xaml.LayoutCycleTracingLevel) -> Void: ...
    @winrt_mixinmethod
    def get_LayoutCycleDebugBreakLevel(self: win32more.Microsoft.UI.Xaml.IDebugSettings3) -> win32more.Microsoft.UI.Xaml.LayoutCycleDebugBreakLevel: ...
    @winrt_mixinmethod
    def put_LayoutCycleDebugBreakLevel(self: win32more.Microsoft.UI.Xaml.IDebugSettings3, value: win32more.Microsoft.UI.Xaml.LayoutCycleDebugBreakLevel) -> Void: ...
    EnableFrameRateCounter = property(get_EnableFrameRateCounter, put_EnableFrameRateCounter)
    FailFastOnErrors = property(get_FailFastOnErrors, put_FailFastOnErrors)
    IsBindingTracingEnabled = property(get_IsBindingTracingEnabled, put_IsBindingTracingEnabled)
    IsTextPerformanceVisualizationEnabled = property(get_IsTextPerformanceVisualizationEnabled, put_IsTextPerformanceVisualizationEnabled)
    IsXamlResourceReferenceTracingEnabled = property(get_IsXamlResourceReferenceTracingEnabled, put_IsXamlResourceReferenceTracingEnabled)
    LayoutCycleDebugBreakLevel = property(get_LayoutCycleDebugBreakLevel, put_LayoutCycleDebugBreakLevel)
    LayoutCycleTracingLevel = property(get_LayoutCycleTracingLevel, put_LayoutCycleTracingLevel)
    BindingFailed = event(add_BindingFailed, remove_BindingFailed)
    XamlResourceReferenceFailed = event(add_XamlResourceReferenceFailed, remove_XamlResourceReferenceFailed)
class DependencyObject(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IDependencyObject
    _classid_ = 'Microsoft.UI.Xaml.DependencyObject'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.DependencyObject.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IDependencyObjectFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_mixinmethod
    def GetValue(self: win32more.Microsoft.UI.Xaml.IDependencyObject, dp: win32more.Microsoft.UI.Xaml.DependencyProperty) -> IInspectable: ...
    @winrt_mixinmethod
    def SetValue(self: win32more.Microsoft.UI.Xaml.IDependencyObject, dp: win32more.Microsoft.UI.Xaml.DependencyProperty, value: IInspectable) -> Void: ...
    @winrt_mixinmethod
    def ClearValue(self: win32more.Microsoft.UI.Xaml.IDependencyObject, dp: win32more.Microsoft.UI.Xaml.DependencyProperty) -> Void: ...
    @winrt_mixinmethod
    def ReadLocalValue(self: win32more.Microsoft.UI.Xaml.IDependencyObject, dp: win32more.Microsoft.UI.Xaml.DependencyProperty) -> IInspectable: ...
    @winrt_mixinmethod
    def GetAnimationBaseValue(self: win32more.Microsoft.UI.Xaml.IDependencyObject, dp: win32more.Microsoft.UI.Xaml.DependencyProperty) -> IInspectable: ...
    @winrt_mixinmethod
    def RegisterPropertyChangedCallback(self: win32more.Microsoft.UI.Xaml.IDependencyObject, dp: win32more.Microsoft.UI.Xaml.DependencyProperty, callback: win32more.Microsoft.UI.Xaml.DependencyPropertyChangedCallback) -> Int64: ...
    @winrt_mixinmethod
    def UnregisterPropertyChangedCallback(self: win32more.Microsoft.UI.Xaml.IDependencyObject, dp: win32more.Microsoft.UI.Xaml.DependencyProperty, token: Int64) -> Void: ...
    @winrt_mixinmethod
    def get_Dispatcher(self: win32more.Microsoft.UI.Xaml.IDependencyObject) -> win32more.Windows.UI.Core.CoreDispatcher: ...
    @winrt_mixinmethod
    def get_DispatcherQueue(self: win32more.Microsoft.UI.Xaml.IDependencyObject) -> win32more.Microsoft.UI.Dispatching.DispatcherQueue: ...
    Dispatcher = property(get_Dispatcher, None)
    DispatcherQueue = property(get_DispatcherQueue, None)
class DependencyObjectCollection(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    implements: Tuple[SequenceProtocol[win32more.Microsoft.UI.Xaml.DependencyObject]]
    default_interface: win32more.Windows.Foundation.Collections.IObservableVector[win32more.Microsoft.UI.Xaml.DependencyObject]
    _classid_ = 'Microsoft.UI.Xaml.DependencyObjectCollection'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.DependencyObjectCollection.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IDependencyObjectCollectionFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.DependencyObjectCollection: ...
    @winrt_mixinmethod
    def add_VectorChanged(self: win32more.Windows.Foundation.Collections.IObservableVector[win32more.Microsoft.UI.Xaml.DependencyObject], vhnd: win32more.Windows.Foundation.Collections.VectorChangedEventHandler[win32more.Microsoft.UI.Xaml.DependencyObject]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_VectorChanged(self: win32more.Windows.Foundation.Collections.IObservableVector[win32more.Microsoft.UI.Xaml.DependencyObject], token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def GetAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.DependencyObject], index: UInt32) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_mixinmethod
    def get_Size(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.DependencyObject]) -> UInt32: ...
    @winrt_mixinmethod
    def GetView(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.DependencyObject]) -> win32more.Windows.Foundation.Collections.IVectorView[win32more.Microsoft.UI.Xaml.DependencyObject]: ...
    @winrt_mixinmethod
    def IndexOf(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.DependencyObject], value: win32more.Microsoft.UI.Xaml.DependencyObject, index: POINTER(UInt32)) -> Boolean: ...
    @winrt_mixinmethod
    def SetAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.DependencyObject], index: UInt32, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_mixinmethod
    def InsertAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.DependencyObject], index: UInt32, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_mixinmethod
    def RemoveAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.DependencyObject], index: UInt32) -> Void: ...
    @winrt_mixinmethod
    def Append(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.DependencyObject], value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_mixinmethod
    def RemoveAtEnd(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.DependencyObject]) -> Void: ...
    @winrt_mixinmethod
    def Clear(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.DependencyObject]) -> Void: ...
    @winrt_mixinmethod
    def GetMany(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.DependencyObject], startIndex: UInt32, items: FillArray[win32more.Microsoft.UI.Xaml.DependencyObject]) -> UInt32: ...
    @winrt_mixinmethod
    def ReplaceAll(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.DependencyObject], items: PassArray[win32more.Microsoft.UI.Xaml.DependencyObject]) -> Void: ...
    @winrt_mixinmethod
    def First(self: win32more.Windows.Foundation.Collections.IIterable[win32more.Microsoft.UI.Xaml.DependencyObject]) -> win32more.Windows.Foundation.Collections.IIterator[win32more.Microsoft.UI.Xaml.DependencyObject]: ...
    Size = property(get_Size, None)
    VectorChanged = event(add_VectorChanged, remove_VectorChanged)
class _DependencyProperty_Meta_(ComPtr.__class__):
    pass
class DependencyProperty(ComPtr, metaclass=_DependencyProperty_Meta_):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IDependencyProperty
    _classid_ = 'Microsoft.UI.Xaml.DependencyProperty'
    @winrt_mixinmethod
    def GetMetadata(self: win32more.Microsoft.UI.Xaml.IDependencyProperty, forType: win32more.Windows.UI.Xaml.Interop.TypeName) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
    @winrt_classmethod
    def get_UnsetValue(cls: win32more.Microsoft.UI.Xaml.IDependencyPropertyStatics) -> IInspectable: ...
    @winrt_classmethod
    def Register(cls: win32more.Microsoft.UI.Xaml.IDependencyPropertyStatics, name: hstr, propertyType: win32more.Windows.UI.Xaml.Interop.TypeName, ownerType: win32more.Windows.UI.Xaml.Interop.TypeName, typeMetadata: win32more.Microsoft.UI.Xaml.PropertyMetadata) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def RegisterAttached(cls: win32more.Microsoft.UI.Xaml.IDependencyPropertyStatics, name: hstr, propertyType: win32more.Windows.UI.Xaml.Interop.TypeName, ownerType: win32more.Windows.UI.Xaml.Interop.TypeName, defaultMetadata: win32more.Microsoft.UI.Xaml.PropertyMetadata) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    _DependencyProperty_Meta_.UnsetValue = property(get_UnsetValue, None)
class DependencyPropertyChangedCallback(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{f055bb21-219b-5b0c-805d-bcaedae15458}')
    @winrt_commethod(3)
    def Invoke(self, sender: win32more.Microsoft.UI.Xaml.DependencyObject, dp: win32more.Microsoft.UI.Xaml.DependencyProperty) -> Void: ...
class DependencyPropertyChangedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IDependencyPropertyChangedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.DependencyPropertyChangedEventArgs'
    @winrt_mixinmethod
    def get_Property(self: win32more.Microsoft.UI.Xaml.IDependencyPropertyChangedEventArgs) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_mixinmethod
    def get_OldValue(self: win32more.Microsoft.UI.Xaml.IDependencyPropertyChangedEventArgs) -> IInspectable: ...
    @winrt_mixinmethod
    def get_NewValue(self: win32more.Microsoft.UI.Xaml.IDependencyPropertyChangedEventArgs) -> IInspectable: ...
    NewValue = property(get_NewValue, None)
    OldValue = property(get_OldValue, None)
    Property = property(get_Property, None)
class DependencyPropertyChangedEventHandler(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{4be8dc75-373d-5f4e-a0b4-54b9eeafb4a9}')
    @winrt_commethod(3)
    def Invoke(self, sender: IInspectable, e: win32more.Microsoft.UI.Xaml.DependencyPropertyChangedEventArgs) -> Void: ...
class DispatcherShutdownMode(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.DispatcherShutdownMode'
    OnLastWindowClose = 0
    OnExplicitShutdown = 1
class DispatcherTimer(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IDispatcherTimer
    _classid_ = 'Microsoft.UI.Xaml.DispatcherTimer'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.DispatcherTimer.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IDispatcherTimerFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.DispatcherTimer: ...
    @winrt_mixinmethod
    def get_Interval(self: win32more.Microsoft.UI.Xaml.IDispatcherTimer) -> win32more.Windows.Foundation.TimeSpan: ...
    @winrt_mixinmethod
    def put_Interval(self: win32more.Microsoft.UI.Xaml.IDispatcherTimer, value: win32more.Windows.Foundation.TimeSpan) -> Void: ...
    @winrt_mixinmethod
    def get_IsEnabled(self: win32more.Microsoft.UI.Xaml.IDispatcherTimer) -> Boolean: ...
    @winrt_mixinmethod
    def add_Tick(self: win32more.Microsoft.UI.Xaml.IDispatcherTimer, handler: win32more.Windows.Foundation.EventHandler[IInspectable]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_Tick(self: win32more.Microsoft.UI.Xaml.IDispatcherTimer, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def Start(self: win32more.Microsoft.UI.Xaml.IDispatcherTimer) -> Void: ...
    @winrt_mixinmethod
    def Stop(self: win32more.Microsoft.UI.Xaml.IDispatcherTimer) -> Void: ...
    Interval = property(get_Interval, put_Interval)
    IsEnabled = property(get_IsEnabled, None)
    Tick = event(add_Tick, remove_Tick)
class DragEventArgs(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.RoutedEventArgs
    default_interface: win32more.Microsoft.UI.Xaml.IDragEventArgs
    _classid_ = 'Microsoft.UI.Xaml.DragEventArgs'
    @winrt_mixinmethod
    def get_Handled(self: win32more.Microsoft.UI.Xaml.IDragEventArgs) -> Boolean: ...
    @winrt_mixinmethod
    def put_Handled(self: win32more.Microsoft.UI.Xaml.IDragEventArgs, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_Data(self: win32more.Microsoft.UI.Xaml.IDragEventArgs) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackage: ...
    @winrt_mixinmethod
    def put_Data(self: win32more.Microsoft.UI.Xaml.IDragEventArgs, value: win32more.Windows.ApplicationModel.DataTransfer.DataPackage) -> Void: ...
    @winrt_mixinmethod
    def get_DataView(self: win32more.Microsoft.UI.Xaml.IDragEventArgs) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackageView: ...
    @winrt_mixinmethod
    def get_DragUIOverride(self: win32more.Microsoft.UI.Xaml.IDragEventArgs) -> win32more.Microsoft.UI.Xaml.DragUIOverride: ...
    @winrt_mixinmethod
    def get_Modifiers(self: win32more.Microsoft.UI.Xaml.IDragEventArgs) -> win32more.Windows.ApplicationModel.DataTransfer.DragDrop.DragDropModifiers: ...
    @winrt_mixinmethod
    def get_AcceptedOperation(self: win32more.Microsoft.UI.Xaml.IDragEventArgs) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation: ...
    @winrt_mixinmethod
    def put_AcceptedOperation(self: win32more.Microsoft.UI.Xaml.IDragEventArgs, value: win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation) -> Void: ...
    @winrt_mixinmethod
    def get_AllowedOperations(self: win32more.Microsoft.UI.Xaml.IDragEventArgs) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation: ...
    @winrt_mixinmethod
    def GetDeferral(self: win32more.Microsoft.UI.Xaml.IDragEventArgs) -> win32more.Microsoft.UI.Xaml.DragOperationDeferral: ...
    @winrt_mixinmethod
    def GetPosition(self: win32more.Microsoft.UI.Xaml.IDragEventArgs, relativeTo: win32more.Microsoft.UI.Xaml.UIElement) -> win32more.Windows.Foundation.Point: ...
    AcceptedOperation = property(get_AcceptedOperation, put_AcceptedOperation)
    AllowedOperations = property(get_AllowedOperations, None)
    Data = property(get_Data, put_Data)
    DataView = property(get_DataView, None)
    DragUIOverride = property(get_DragUIOverride, None)
    Handled = property(get_Handled, put_Handled)
    Modifiers = property(get_Modifiers, None)
class DragEventHandler(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{277afc83-cb67-56c8-b601-1b9c0f1c3d32}')
    @winrt_commethod(3)
    def Invoke(self, sender: IInspectable, e: win32more.Microsoft.UI.Xaml.DragEventArgs) -> Void: ...
class DragOperationDeferral(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IDragOperationDeferral
    _classid_ = 'Microsoft.UI.Xaml.DragOperationDeferral'
    @winrt_mixinmethod
    def Complete(self: win32more.Microsoft.UI.Xaml.IDragOperationDeferral) -> Void: ...
class DragStartingEventArgs(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.RoutedEventArgs
    default_interface: win32more.Microsoft.UI.Xaml.IDragStartingEventArgs
    _classid_ = 'Microsoft.UI.Xaml.DragStartingEventArgs'
    @winrt_mixinmethod
    def get_Cancel(self: win32more.Microsoft.UI.Xaml.IDragStartingEventArgs) -> Boolean: ...
    @winrt_mixinmethod
    def put_Cancel(self: win32more.Microsoft.UI.Xaml.IDragStartingEventArgs, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_Data(self: win32more.Microsoft.UI.Xaml.IDragStartingEventArgs) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackage: ...
    @winrt_mixinmethod
    def get_DragUI(self: win32more.Microsoft.UI.Xaml.IDragStartingEventArgs) -> win32more.Microsoft.UI.Xaml.DragUI: ...
    @winrt_mixinmethod
    def get_AllowedOperations(self: win32more.Microsoft.UI.Xaml.IDragStartingEventArgs) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation: ...
    @winrt_mixinmethod
    def put_AllowedOperations(self: win32more.Microsoft.UI.Xaml.IDragStartingEventArgs, value: win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation) -> Void: ...
    @winrt_mixinmethod
    def GetDeferral(self: win32more.Microsoft.UI.Xaml.IDragStartingEventArgs) -> win32more.Microsoft.UI.Xaml.DragOperationDeferral: ...
    @winrt_mixinmethod
    def GetPosition(self: win32more.Microsoft.UI.Xaml.IDragStartingEventArgs, relativeTo: win32more.Microsoft.UI.Xaml.UIElement) -> win32more.Windows.Foundation.Point: ...
    AllowedOperations = property(get_AllowedOperations, put_AllowedOperations)
    Cancel = property(get_Cancel, put_Cancel)
    Data = property(get_Data, None)
    DragUI = property(get_DragUI, None)
class DragUI(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IDragUI
    _classid_ = 'Microsoft.UI.Xaml.DragUI'
    @winrt_mixinmethod
    def SetContentFromBitmapImage(self: win32more.Microsoft.UI.Xaml.IDragUI, bitmapImage: win32more.Microsoft.UI.Xaml.Media.Imaging.BitmapImage) -> Void: ...
    @winrt_mixinmethod
    def SetContentFromBitmapImageWithAnchorPoint(self: win32more.Microsoft.UI.Xaml.IDragUI, bitmapImage: win32more.Microsoft.UI.Xaml.Media.Imaging.BitmapImage, anchorPoint: win32more.Windows.Foundation.Point) -> Void: ...
    @winrt_mixinmethod
    def SetContentFromSoftwareBitmap(self: win32more.Microsoft.UI.Xaml.IDragUI, softwareBitmap: win32more.Windows.Graphics.Imaging.SoftwareBitmap) -> Void: ...
    @winrt_mixinmethod
    def SetContentFromSoftwareBitmapWithAnchorPoint(self: win32more.Microsoft.UI.Xaml.IDragUI, softwareBitmap: win32more.Windows.Graphics.Imaging.SoftwareBitmap, anchorPoint: win32more.Windows.Foundation.Point) -> Void: ...
    @winrt_mixinmethod
    def SetContentFromDataPackage(self: win32more.Microsoft.UI.Xaml.IDragUI) -> Void: ...
class DragUIOverride(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IDragUIOverride
    _classid_ = 'Microsoft.UI.Xaml.DragUIOverride'
    @winrt_mixinmethod
    def get_Caption(self: win32more.Microsoft.UI.Xaml.IDragUIOverride) -> hstr: ...
    @winrt_mixinmethod
    def put_Caption(self: win32more.Microsoft.UI.Xaml.IDragUIOverride, value: hstr) -> Void: ...
    @winrt_mixinmethod
    def get_IsContentVisible(self: win32more.Microsoft.UI.Xaml.IDragUIOverride) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsContentVisible(self: win32more.Microsoft.UI.Xaml.IDragUIOverride, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_IsCaptionVisible(self: win32more.Microsoft.UI.Xaml.IDragUIOverride) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsCaptionVisible(self: win32more.Microsoft.UI.Xaml.IDragUIOverride, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_IsGlyphVisible(self: win32more.Microsoft.UI.Xaml.IDragUIOverride) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsGlyphVisible(self: win32more.Microsoft.UI.Xaml.IDragUIOverride, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def Clear(self: win32more.Microsoft.UI.Xaml.IDragUIOverride) -> Void: ...
    @winrt_mixinmethod
    def SetContentFromBitmapImage(self: win32more.Microsoft.UI.Xaml.IDragUIOverride, bitmapImage: win32more.Microsoft.UI.Xaml.Media.Imaging.BitmapImage) -> Void: ...
    @winrt_mixinmethod
    def SetContentFromBitmapImageWithAnchorPoint(self: win32more.Microsoft.UI.Xaml.IDragUIOverride, bitmapImage: win32more.Microsoft.UI.Xaml.Media.Imaging.BitmapImage, anchorPoint: win32more.Windows.Foundation.Point) -> Void: ...
    @winrt_mixinmethod
    def SetContentFromSoftwareBitmap(self: win32more.Microsoft.UI.Xaml.IDragUIOverride, softwareBitmap: win32more.Windows.Graphics.Imaging.SoftwareBitmap) -> Void: ...
    @winrt_mixinmethod
    def SetContentFromSoftwareBitmapWithAnchorPoint(self: win32more.Microsoft.UI.Xaml.IDragUIOverride, softwareBitmap: win32more.Windows.Graphics.Imaging.SoftwareBitmap, anchorPoint: win32more.Windows.Foundation.Point) -> Void: ...
    Caption = property(get_Caption, put_Caption)
    IsCaptionVisible = property(get_IsCaptionVisible, put_IsCaptionVisible)
    IsContentVisible = property(get_IsContentVisible, put_IsContentVisible)
    IsGlyphVisible = property(get_IsGlyphVisible, put_IsGlyphVisible)
class DropCompletedEventArgs(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.RoutedEventArgs
    default_interface: win32more.Microsoft.UI.Xaml.IDropCompletedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.DropCompletedEventArgs'
    @winrt_mixinmethod
    def get_DropResult(self: win32more.Microsoft.UI.Xaml.IDropCompletedEventArgs) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation: ...
    DropResult = property(get_DropResult, None)
class Duration(Structure):
    _name_ = 'Microsoft.UI.Xaml.Duration'
    TimeSpan: win32more.Windows.Foundation.TimeSpan
    Type: win32more.Microsoft.UI.Xaml.DurationType
class _DurationHelper_Meta_(ComPtr.__class__):
    pass
class DurationHelper(ComPtr, metaclass=_DurationHelper_Meta_):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IDurationHelper
    _classid_ = 'Microsoft.UI.Xaml.DurationHelper'
    @winrt_classmethod
    def get_Automatic(cls: win32more.Microsoft.UI.Xaml.IDurationHelperStatics) -> win32more.Microsoft.UI.Xaml.Duration: ...
    @winrt_classmethod
    def get_Forever(cls: win32more.Microsoft.UI.Xaml.IDurationHelperStatics) -> win32more.Microsoft.UI.Xaml.Duration: ...
    @winrt_classmethod
    def Compare(cls: win32more.Microsoft.UI.Xaml.IDurationHelperStatics, duration1: win32more.Microsoft.UI.Xaml.Duration, duration2: win32more.Microsoft.UI.Xaml.Duration) -> Int32: ...
    @winrt_classmethod
    def FromTimeSpan(cls: win32more.Microsoft.UI.Xaml.IDurationHelperStatics, timeSpan: win32more.Windows.Foundation.TimeSpan) -> win32more.Microsoft.UI.Xaml.Duration: ...
    @winrt_classmethod
    def GetHasTimeSpan(cls: win32more.Microsoft.UI.Xaml.IDurationHelperStatics, target: win32more.Microsoft.UI.Xaml.Duration) -> Boolean: ...
    @winrt_classmethod
    def Add(cls: win32more.Microsoft.UI.Xaml.IDurationHelperStatics, target: win32more.Microsoft.UI.Xaml.Duration, duration: win32more.Microsoft.UI.Xaml.Duration) -> win32more.Microsoft.UI.Xaml.Duration: ...
    @winrt_classmethod
    def Equals(cls: win32more.Microsoft.UI.Xaml.IDurationHelperStatics, target: win32more.Microsoft.UI.Xaml.Duration, value: win32more.Microsoft.UI.Xaml.Duration) -> Boolean: ...
    @winrt_classmethod
    def Subtract(cls: win32more.Microsoft.UI.Xaml.IDurationHelperStatics, target: win32more.Microsoft.UI.Xaml.Duration, duration: win32more.Microsoft.UI.Xaml.Duration) -> win32more.Microsoft.UI.Xaml.Duration: ...
    _DurationHelper_Meta_.Automatic = property(get_Automatic, None)
    _DurationHelper_Meta_.Forever = property(get_Forever, None)
class DurationType(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.DurationType'
    Automatic = 0
    TimeSpan = 1
    Forever = 2
class EffectiveViewportChangedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IEffectiveViewportChangedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.EffectiveViewportChangedEventArgs'
    @winrt_mixinmethod
    def get_EffectiveViewport(self: win32more.Microsoft.UI.Xaml.IEffectiveViewportChangedEventArgs) -> win32more.Windows.Foundation.Rect: ...
    @winrt_mixinmethod
    def get_MaxViewport(self: win32more.Microsoft.UI.Xaml.IEffectiveViewportChangedEventArgs) -> win32more.Windows.Foundation.Rect: ...
    @winrt_mixinmethod
    def get_BringIntoViewDistanceX(self: win32more.Microsoft.UI.Xaml.IEffectiveViewportChangedEventArgs) -> Double: ...
    @winrt_mixinmethod
    def get_BringIntoViewDistanceY(self: win32more.Microsoft.UI.Xaml.IEffectiveViewportChangedEventArgs) -> Double: ...
    BringIntoViewDistanceX = property(get_BringIntoViewDistanceX, None)
    BringIntoViewDistanceY = property(get_BringIntoViewDistanceY, None)
    EffectiveViewport = property(get_EffectiveViewport, None)
    MaxViewport = property(get_MaxViewport, None)
class ElementFactoryGetArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IElementFactoryGetArgs
    _classid_ = 'Microsoft.UI.Xaml.ElementFactoryGetArgs'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.ElementFactoryGetArgs.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IElementFactoryGetArgsFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.ElementFactoryGetArgs: ...
    @winrt_mixinmethod
    def get_Data(self: win32more.Microsoft.UI.Xaml.IElementFactoryGetArgs) -> IInspectable: ...
    @winrt_mixinmethod
    def put_Data(self: win32more.Microsoft.UI.Xaml.IElementFactoryGetArgs, value: IInspectable) -> Void: ...
    @winrt_mixinmethod
    def get_Parent(self: win32more.Microsoft.UI.Xaml.IElementFactoryGetArgs) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_mixinmethod
    def put_Parent(self: win32more.Microsoft.UI.Xaml.IElementFactoryGetArgs, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    Data = property(get_Data, put_Data)
    Parent = property(get_Parent, put_Parent)
class ElementFactoryRecycleArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IElementFactoryRecycleArgs
    _classid_ = 'Microsoft.UI.Xaml.ElementFactoryRecycleArgs'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.ElementFactoryRecycleArgs.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IElementFactoryRecycleArgsFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.ElementFactoryRecycleArgs: ...
    @winrt_mixinmethod
    def get_Element(self: win32more.Microsoft.UI.Xaml.IElementFactoryRecycleArgs) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_mixinmethod
    def put_Element(self: win32more.Microsoft.UI.Xaml.IElementFactoryRecycleArgs, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    @winrt_mixinmethod
    def get_Parent(self: win32more.Microsoft.UI.Xaml.IElementFactoryRecycleArgs) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_mixinmethod
    def put_Parent(self: win32more.Microsoft.UI.Xaml.IElementFactoryRecycleArgs, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    Element = property(get_Element, put_Element)
    Parent = property(get_Parent, put_Parent)
class ElementHighContrastAdjustment(Enum, UInt32):
    _name_ = 'Microsoft.UI.Xaml.ElementHighContrastAdjustment'
    None_ = 0
    Application = 2147483648
    Auto = 4294967295
class ElementSoundKind(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.ElementSoundKind'
    Focus = 0
    Invoke = 1
    Show = 2
    Hide = 3
    MovePrevious = 4
    MoveNext = 5
    GoBack = 6
class ElementSoundMode(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.ElementSoundMode'
    Default = 0
    FocusOnly = 1
    Off = 2
class _ElementSoundPlayer_Meta_(ComPtr.__class__):
    pass
class ElementSoundPlayer(ComPtr, metaclass=_ElementSoundPlayer_Meta_):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IElementSoundPlayer
    _classid_ = 'Microsoft.UI.Xaml.ElementSoundPlayer'
    @winrt_classmethod
    def get_Volume(cls: win32more.Microsoft.UI.Xaml.IElementSoundPlayerStatics) -> Double: ...
    @winrt_classmethod
    def put_Volume(cls: win32more.Microsoft.UI.Xaml.IElementSoundPlayerStatics, value: Double) -> Void: ...
    @winrt_classmethod
    def get_State(cls: win32more.Microsoft.UI.Xaml.IElementSoundPlayerStatics) -> win32more.Microsoft.UI.Xaml.ElementSoundPlayerState: ...
    @winrt_classmethod
    def put_State(cls: win32more.Microsoft.UI.Xaml.IElementSoundPlayerStatics, value: win32more.Microsoft.UI.Xaml.ElementSoundPlayerState) -> Void: ...
    @winrt_classmethod
    def get_SpatialAudioMode(cls: win32more.Microsoft.UI.Xaml.IElementSoundPlayerStatics) -> win32more.Microsoft.UI.Xaml.ElementSpatialAudioMode: ...
    @winrt_classmethod
    def put_SpatialAudioMode(cls: win32more.Microsoft.UI.Xaml.IElementSoundPlayerStatics, value: win32more.Microsoft.UI.Xaml.ElementSpatialAudioMode) -> Void: ...
    @winrt_classmethod
    def Play(cls: win32more.Microsoft.UI.Xaml.IElementSoundPlayerStatics, sound: win32more.Microsoft.UI.Xaml.ElementSoundKind) -> Void: ...
    _ElementSoundPlayer_Meta_.SpatialAudioMode = property(get_SpatialAudioMode, put_SpatialAudioMode)
    _ElementSoundPlayer_Meta_.State = property(get_State, put_State)
    _ElementSoundPlayer_Meta_.Volume = property(get_Volume, put_Volume)
class ElementSoundPlayerState(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.ElementSoundPlayerState'
    Auto = 0
    Off = 1
    On = 2
class ElementSpatialAudioMode(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.ElementSpatialAudioMode'
    Auto = 0
    Off = 1
    On = 2
class ElementTheme(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.ElementTheme'
    Default = 0
    Light = 1
    Dark = 2
class EnteredBackgroundEventHandler(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{f9a5148d-8f72-553f-b479-21b68610899d}')
    @winrt_commethod(3)
    def Invoke(self, sender: IInspectable, e: win32more.Windows.ApplicationModel.EnteredBackgroundEventArgs) -> Void: ...
class EventTrigger(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.TriggerBase
    default_interface: win32more.Microsoft.UI.Xaml.IEventTrigger
    _classid_ = 'Microsoft.UI.Xaml.EventTrigger'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.EventTrigger.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.EventTrigger: ...
    @winrt_mixinmethod
    def get_RoutedEvent(self: win32more.Microsoft.UI.Xaml.IEventTrigger) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_mixinmethod
    def put_RoutedEvent(self: win32more.Microsoft.UI.Xaml.IEventTrigger, value: win32more.Microsoft.UI.Xaml.RoutedEvent) -> Void: ...
    @winrt_mixinmethod
    def get_Actions(self: win32more.Microsoft.UI.Xaml.IEventTrigger) -> win32more.Microsoft.UI.Xaml.TriggerActionCollection: ...
    Actions = property(get_Actions, None)
    RoutedEvent = property(get_RoutedEvent, put_RoutedEvent)
class ExceptionRoutedEventArgs(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.RoutedEventArgs
    default_interface: win32more.Microsoft.UI.Xaml.IExceptionRoutedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.ExceptionRoutedEventArgs'
    @winrt_mixinmethod
    def get_ErrorMessage(self: win32more.Microsoft.UI.Xaml.IExceptionRoutedEventArgs) -> hstr: ...
    ErrorMessage = property(get_ErrorMessage, None)
class ExceptionRoutedEventHandler(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{45fbb85d-54f9-5a2a-8a38-00a3b7761f96}')
    @winrt_commethod(3)
    def Invoke(self, sender: IInspectable, e: win32more.Microsoft.UI.Xaml.ExceptionRoutedEventArgs) -> Void: ...
class FlowDirection(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.FlowDirection'
    LeftToRight = 0
    RightToLeft = 1
class FocusState(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.FocusState'
    Unfocused = 0
    Pointer = 1
    Keyboard = 2
    Programmatic = 3
class FocusVisualKind(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.FocusVisualKind'
    DottedLine = 0
    HighVisibility = 1
    Reveal = 2
class FontCapitals(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.FontCapitals'
    Normal = 0
    AllSmallCaps = 1
    SmallCaps = 2
    AllPetiteCaps = 3
    PetiteCaps = 4
    Unicase = 5
    Titling = 6
class FontEastAsianLanguage(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.FontEastAsianLanguage'
    Normal = 0
    HojoKanji = 1
    Jis04 = 2
    Jis78 = 3
    Jis83 = 4
    Jis90 = 5
    NlcKanji = 6
    Simplified = 7
    Traditional = 8
    TraditionalNames = 9
class FontEastAsianWidths(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.FontEastAsianWidths'
    Normal = 0
    Full = 1
    Half = 2
    Proportional = 3
    Quarter = 4
    Third = 5
class FontFraction(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.FontFraction'
    Normal = 0
    Stacked = 1
    Slashed = 2
class FontNumeralAlignment(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.FontNumeralAlignment'
    Normal = 0
    Proportional = 1
    Tabular = 2
class FontNumeralStyle(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.FontNumeralStyle'
    Normal = 0
    Lining = 1
    OldStyle = 2
class FontVariants(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.FontVariants'
    Normal = 0
    Superscript = 1
    Subscript = 2
    Ordinal = 3
    Inferior = 4
    Ruby = 5
class _FrameworkElement_Meta_(ComPtr.__class__):
    pass
class FrameworkElement(ComPtr, metaclass=_FrameworkElement_Meta_):
    extends: win32more.Microsoft.UI.Xaml.UIElement
    default_interface: win32more.Microsoft.UI.Xaml.IFrameworkElement
    _classid_ = 'Microsoft.UI.Xaml.FrameworkElement'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.FrameworkElement.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.FrameworkElement: ...
    @winrt_mixinmethod
    def get_Triggers(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.TriggerCollection: ...
    @winrt_mixinmethod
    def get_Resources(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.ResourceDictionary: ...
    @winrt_mixinmethod
    def put_Resources(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: win32more.Microsoft.UI.Xaml.ResourceDictionary) -> Void: ...
    @winrt_mixinmethod
    def get_Tag(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> IInspectable: ...
    @winrt_mixinmethod
    def put_Tag(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: IInspectable) -> Void: ...
    @winrt_mixinmethod
    def get_Language(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> hstr: ...
    @winrt_mixinmethod
    def put_Language(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: hstr) -> Void: ...
    @winrt_mixinmethod
    def get_ActualWidth(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> Double: ...
    @winrt_mixinmethod
    def get_ActualHeight(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> Double: ...
    @winrt_mixinmethod
    def get_Width(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> Double: ...
    @winrt_mixinmethod
    def put_Width(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_Height(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> Double: ...
    @winrt_mixinmethod
    def put_Height(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_MinWidth(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> Double: ...
    @winrt_mixinmethod
    def put_MinWidth(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_MaxWidth(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> Double: ...
    @winrt_mixinmethod
    def put_MaxWidth(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_MinHeight(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> Double: ...
    @winrt_mixinmethod
    def put_MinHeight(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_MaxHeight(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> Double: ...
    @winrt_mixinmethod
    def put_MaxHeight(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_HorizontalAlignment(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.HorizontalAlignment: ...
    @winrt_mixinmethod
    def put_HorizontalAlignment(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: win32more.Microsoft.UI.Xaml.HorizontalAlignment) -> Void: ...
    @winrt_mixinmethod
    def get_VerticalAlignment(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.VerticalAlignment: ...
    @winrt_mixinmethod
    def put_VerticalAlignment(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: win32more.Microsoft.UI.Xaml.VerticalAlignment) -> Void: ...
    @winrt_mixinmethod
    def get_Margin(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.Thickness: ...
    @winrt_mixinmethod
    def put_Margin(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: win32more.Microsoft.UI.Xaml.Thickness) -> Void: ...
    @winrt_mixinmethod
    def get_Name(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> hstr: ...
    @winrt_mixinmethod
    def put_Name(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: hstr) -> Void: ...
    @winrt_mixinmethod
    def get_BaseUri(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Windows.Foundation.Uri: ...
    @winrt_mixinmethod
    def get_DataContext(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> IInspectable: ...
    @winrt_mixinmethod
    def put_DataContext(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: IInspectable) -> Void: ...
    @winrt_mixinmethod
    def get_AllowFocusOnInteraction(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_AllowFocusOnInteraction(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_FocusVisualMargin(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.Thickness: ...
    @winrt_mixinmethod
    def put_FocusVisualMargin(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: win32more.Microsoft.UI.Xaml.Thickness) -> Void: ...
    @winrt_mixinmethod
    def get_FocusVisualSecondaryThickness(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.Thickness: ...
    @winrt_mixinmethod
    def put_FocusVisualSecondaryThickness(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: win32more.Microsoft.UI.Xaml.Thickness) -> Void: ...
    @winrt_mixinmethod
    def get_FocusVisualPrimaryThickness(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.Thickness: ...
    @winrt_mixinmethod
    def put_FocusVisualPrimaryThickness(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: win32more.Microsoft.UI.Xaml.Thickness) -> Void: ...
    @winrt_mixinmethod
    def get_FocusVisualSecondaryBrush(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.Media.Brush: ...
    @winrt_mixinmethod
    def put_FocusVisualSecondaryBrush(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: win32more.Microsoft.UI.Xaml.Media.Brush) -> Void: ...
    @winrt_mixinmethod
    def get_FocusVisualPrimaryBrush(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.Media.Brush: ...
    @winrt_mixinmethod
    def put_FocusVisualPrimaryBrush(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: win32more.Microsoft.UI.Xaml.Media.Brush) -> Void: ...
    @winrt_mixinmethod
    def get_AllowFocusWhenDisabled(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_AllowFocusWhenDisabled(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_Style(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.Style: ...
    @winrt_mixinmethod
    def put_Style(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: win32more.Microsoft.UI.Xaml.Style) -> Void: ...
    @winrt_mixinmethod
    def get_Parent(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_mixinmethod
    def get_FlowDirection(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.FlowDirection: ...
    @winrt_mixinmethod
    def put_FlowDirection(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: win32more.Microsoft.UI.Xaml.FlowDirection) -> Void: ...
    @winrt_mixinmethod
    def get_RequestedTheme(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.ElementTheme: ...
    @winrt_mixinmethod
    def put_RequestedTheme(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, value: win32more.Microsoft.UI.Xaml.ElementTheme) -> Void: ...
    @winrt_mixinmethod
    def get_IsLoaded(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> Boolean: ...
    @winrt_mixinmethod
    def get_ActualTheme(self: win32more.Microsoft.UI.Xaml.IFrameworkElement) -> win32more.Microsoft.UI.Xaml.ElementTheme: ...
    @winrt_mixinmethod
    def add_Loaded(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, handler: win32more.Microsoft.UI.Xaml.RoutedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_Loaded(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_Unloaded(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, handler: win32more.Microsoft.UI.Xaml.RoutedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_Unloaded(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_DataContextChanged(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.FrameworkElement, win32more.Microsoft.UI.Xaml.DataContextChangedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_DataContextChanged(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_SizeChanged(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, handler: win32more.Microsoft.UI.Xaml.SizeChangedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_SizeChanged(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_LayoutUpdated(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, handler: win32more.Windows.Foundation.EventHandler[IInspectable]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_LayoutUpdated(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_Loading(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.FrameworkElement, IInspectable]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_Loading(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_ActualThemeChanged(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.FrameworkElement, IInspectable]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_ActualThemeChanged(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_EffectiveViewportChanged(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.FrameworkElement, win32more.Microsoft.UI.Xaml.EffectiveViewportChangedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_EffectiveViewportChanged(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def FindName(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, name: hstr) -> IInspectable: ...
    @winrt_mixinmethod
    def SetBinding(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, dp: win32more.Microsoft.UI.Xaml.DependencyProperty, binding: win32more.Microsoft.UI.Xaml.Data.BindingBase) -> Void: ...
    @winrt_mixinmethod
    def GetBindingExpression(self: win32more.Microsoft.UI.Xaml.IFrameworkElement, dp: win32more.Microsoft.UI.Xaml.DependencyProperty) -> win32more.Microsoft.UI.Xaml.Data.BindingExpression: ...
    @winrt_mixinmethod
    def InvalidateViewport(self: win32more.Microsoft.UI.Xaml.IFrameworkElementProtected) -> Void: ...
    @winrt_mixinmethod
    def MeasureOverride(self: win32more.Microsoft.UI.Xaml.IFrameworkElementOverrides, availableSize: win32more.Windows.Foundation.Size) -> win32more.Windows.Foundation.Size: ...
    @winrt_mixinmethod
    def ArrangeOverride(self: win32more.Microsoft.UI.Xaml.IFrameworkElementOverrides, finalSize: win32more.Windows.Foundation.Size) -> win32more.Windows.Foundation.Size: ...
    @winrt_mixinmethod
    def OnApplyTemplate(self: win32more.Microsoft.UI.Xaml.IFrameworkElementOverrides) -> Void: ...
    @winrt_mixinmethod
    def GoToElementStateCore(self: win32more.Microsoft.UI.Xaml.IFrameworkElementOverrides, stateName: hstr, useTransitions: Boolean) -> Boolean: ...
    @winrt_classmethod
    def get_TagProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_LanguageProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_ActualWidthProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_ActualHeightProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_WidthProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_HeightProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_MinWidthProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_MaxWidthProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_MinHeightProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_MaxHeightProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_HorizontalAlignmentProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_VerticalAlignmentProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_MarginProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_NameProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_DataContextProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_AllowFocusOnInteractionProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_FocusVisualMarginProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_FocusVisualSecondaryThicknessProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_FocusVisualPrimaryThicknessProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_FocusVisualSecondaryBrushProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_FocusVisualPrimaryBrushProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_AllowFocusWhenDisabledProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_StyleProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_FlowDirectionProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_RequestedThemeProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_ActualThemeProperty(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def DeferTree(cls: win32more.Microsoft.UI.Xaml.IFrameworkElementStatics, element: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    ActualHeight = property(get_ActualHeight, None)
    ActualTheme = property(get_ActualTheme, None)
    ActualWidth = property(get_ActualWidth, None)
    AllowFocusOnInteraction = property(get_AllowFocusOnInteraction, put_AllowFocusOnInteraction)
    AllowFocusWhenDisabled = property(get_AllowFocusWhenDisabled, put_AllowFocusWhenDisabled)
    BaseUri = property(get_BaseUri, None)
    DataContext = property(get_DataContext, put_DataContext)
    FlowDirection = property(get_FlowDirection, put_FlowDirection)
    FocusVisualMargin = property(get_FocusVisualMargin, put_FocusVisualMargin)
    FocusVisualPrimaryBrush = property(get_FocusVisualPrimaryBrush, put_FocusVisualPrimaryBrush)
    FocusVisualPrimaryThickness = property(get_FocusVisualPrimaryThickness, put_FocusVisualPrimaryThickness)
    FocusVisualSecondaryBrush = property(get_FocusVisualSecondaryBrush, put_FocusVisualSecondaryBrush)
    FocusVisualSecondaryThickness = property(get_FocusVisualSecondaryThickness, put_FocusVisualSecondaryThickness)
    Height = property(get_Height, put_Height)
    HorizontalAlignment = property(get_HorizontalAlignment, put_HorizontalAlignment)
    IsLoaded = property(get_IsLoaded, None)
    Language = property(get_Language, put_Language)
    Margin = property(get_Margin, put_Margin)
    MaxHeight = property(get_MaxHeight, put_MaxHeight)
    MaxWidth = property(get_MaxWidth, put_MaxWidth)
    MinHeight = property(get_MinHeight, put_MinHeight)
    MinWidth = property(get_MinWidth, put_MinWidth)
    Name = property(get_Name, put_Name)
    Parent = property(get_Parent, None)
    RequestedTheme = property(get_RequestedTheme, put_RequestedTheme)
    Resources = property(get_Resources, put_Resources)
    Style = property(get_Style, put_Style)
    Tag = property(get_Tag, put_Tag)
    Triggers = property(get_Triggers, None)
    VerticalAlignment = property(get_VerticalAlignment, put_VerticalAlignment)
    Width = property(get_Width, put_Width)
    _FrameworkElement_Meta_.ActualHeightProperty = property(get_ActualHeightProperty, None)
    _FrameworkElement_Meta_.ActualThemeProperty = property(get_ActualThemeProperty, None)
    _FrameworkElement_Meta_.ActualWidthProperty = property(get_ActualWidthProperty, None)
    _FrameworkElement_Meta_.AllowFocusOnInteractionProperty = property(get_AllowFocusOnInteractionProperty, None)
    _FrameworkElement_Meta_.AllowFocusWhenDisabledProperty = property(get_AllowFocusWhenDisabledProperty, None)
    _FrameworkElement_Meta_.DataContextProperty = property(get_DataContextProperty, None)
    _FrameworkElement_Meta_.FlowDirectionProperty = property(get_FlowDirectionProperty, None)
    _FrameworkElement_Meta_.FocusVisualMarginProperty = property(get_FocusVisualMarginProperty, None)
    _FrameworkElement_Meta_.FocusVisualPrimaryBrushProperty = property(get_FocusVisualPrimaryBrushProperty, None)
    _FrameworkElement_Meta_.FocusVisualPrimaryThicknessProperty = property(get_FocusVisualPrimaryThicknessProperty, None)
    _FrameworkElement_Meta_.FocusVisualSecondaryBrushProperty = property(get_FocusVisualSecondaryBrushProperty, None)
    _FrameworkElement_Meta_.FocusVisualSecondaryThicknessProperty = property(get_FocusVisualSecondaryThicknessProperty, None)
    _FrameworkElement_Meta_.HeightProperty = property(get_HeightProperty, None)
    _FrameworkElement_Meta_.HorizontalAlignmentProperty = property(get_HorizontalAlignmentProperty, None)
    _FrameworkElement_Meta_.LanguageProperty = property(get_LanguageProperty, None)
    _FrameworkElement_Meta_.MarginProperty = property(get_MarginProperty, None)
    _FrameworkElement_Meta_.MaxHeightProperty = property(get_MaxHeightProperty, None)
    _FrameworkElement_Meta_.MaxWidthProperty = property(get_MaxWidthProperty, None)
    _FrameworkElement_Meta_.MinHeightProperty = property(get_MinHeightProperty, None)
    _FrameworkElement_Meta_.MinWidthProperty = property(get_MinWidthProperty, None)
    _FrameworkElement_Meta_.NameProperty = property(get_NameProperty, None)
    _FrameworkElement_Meta_.RequestedThemeProperty = property(get_RequestedThemeProperty, None)
    _FrameworkElement_Meta_.StyleProperty = property(get_StyleProperty, None)
    _FrameworkElement_Meta_.TagProperty = property(get_TagProperty, None)
    _FrameworkElement_Meta_.VerticalAlignmentProperty = property(get_VerticalAlignmentProperty, None)
    _FrameworkElement_Meta_.WidthProperty = property(get_WidthProperty, None)
    ActualThemeChanged = event(add_ActualThemeChanged, remove_ActualThemeChanged)
    DataContextChanged = event(add_DataContextChanged, remove_DataContextChanged)
    EffectiveViewportChanged = event(add_EffectiveViewportChanged, remove_EffectiveViewportChanged)
    LayoutUpdated = event(add_LayoutUpdated, remove_LayoutUpdated)
    Loaded = event(add_Loaded, remove_Loaded)
    Loading = event(add_Loading, remove_Loading)
    SizeChanged = event(add_SizeChanged, remove_SizeChanged)
    Unloaded = event(add_Unloaded, remove_Unloaded)
class FrameworkTemplate(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    default_interface: win32more.Microsoft.UI.Xaml.IFrameworkTemplate
    _classid_ = 'Microsoft.UI.Xaml.FrameworkTemplate'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.FrameworkTemplate.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IFrameworkTemplateFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.FrameworkTemplate: ...
class FrameworkView(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IFrameworkView
    _classid_ = 'Microsoft.UI.Xaml.FrameworkView'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.FrameworkView.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.FrameworkView: ...
    @winrt_mixinmethod
    def Initialize(self: win32more.Windows.ApplicationModel.Core.IFrameworkView, applicationView: win32more.Windows.ApplicationModel.Core.CoreApplicationView) -> Void: ...
    @winrt_mixinmethod
    def SetWindow(self: win32more.Windows.ApplicationModel.Core.IFrameworkView, window: win32more.Windows.UI.Core.CoreWindow) -> Void: ...
    @winrt_mixinmethod
    def Load(self: win32more.Windows.ApplicationModel.Core.IFrameworkView, entryPoint: hstr) -> Void: ...
    @winrt_mixinmethod
    def Run(self: win32more.Windows.ApplicationModel.Core.IFrameworkView) -> Void: ...
    @winrt_mixinmethod
    def Uninitialize(self: win32more.Windows.ApplicationModel.Core.IFrameworkView) -> Void: ...
class FrameworkViewSource(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IFrameworkViewSource
    _classid_ = 'Microsoft.UI.Xaml.FrameworkViewSource'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.FrameworkViewSource.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.FrameworkViewSource: ...
    @winrt_mixinmethod
    def CreateView(self: win32more.Windows.ApplicationModel.Core.IFrameworkViewSource) -> win32more.Windows.ApplicationModel.Core.IFrameworkView: ...
class GridLength(Structure):
    _name_ = 'Microsoft.UI.Xaml.GridLength'
    Value: Double
    GridUnitType: win32more.Microsoft.UI.Xaml.GridUnitType
class _GridLengthHelper_Meta_(ComPtr.__class__):
    pass
class GridLengthHelper(ComPtr, metaclass=_GridLengthHelper_Meta_):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IGridLengthHelper
    _classid_ = 'Microsoft.UI.Xaml.GridLengthHelper'
    @winrt_classmethod
    def get_Auto(cls: win32more.Microsoft.UI.Xaml.IGridLengthHelperStatics) -> win32more.Microsoft.UI.Xaml.GridLength: ...
    @winrt_classmethod
    def FromPixels(cls: win32more.Microsoft.UI.Xaml.IGridLengthHelperStatics, pixels: Double) -> win32more.Microsoft.UI.Xaml.GridLength: ...
    @winrt_classmethod
    def FromValueAndType(cls: win32more.Microsoft.UI.Xaml.IGridLengthHelperStatics, value: Double, type: win32more.Microsoft.UI.Xaml.GridUnitType) -> win32more.Microsoft.UI.Xaml.GridLength: ...
    @winrt_classmethod
    def GetIsAbsolute(cls: win32more.Microsoft.UI.Xaml.IGridLengthHelperStatics, target: win32more.Microsoft.UI.Xaml.GridLength) -> Boolean: ...
    @winrt_classmethod
    def GetIsAuto(cls: win32more.Microsoft.UI.Xaml.IGridLengthHelperStatics, target: win32more.Microsoft.UI.Xaml.GridLength) -> Boolean: ...
    @winrt_classmethod
    def GetIsStar(cls: win32more.Microsoft.UI.Xaml.IGridLengthHelperStatics, target: win32more.Microsoft.UI.Xaml.GridLength) -> Boolean: ...
    @winrt_classmethod
    def Equals(cls: win32more.Microsoft.UI.Xaml.IGridLengthHelperStatics, target: win32more.Microsoft.UI.Xaml.GridLength, value: win32more.Microsoft.UI.Xaml.GridLength) -> Boolean: ...
    _GridLengthHelper_Meta_.Auto = property(get_Auto, None)
class GridUnitType(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.GridUnitType'
    Auto = 0
    Pixel = 1
    Star = 2
class HorizontalAlignment(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.HorizontalAlignment'
    Left = 0
    Center = 1
    Right = 2
    Stretch = 3
class IAdaptiveTrigger(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IAdaptiveTrigger'
    _iid_ = Guid('{b2b18ae8-48d9-5a1d-a555-6685ddd4da80}')
    @winrt_commethod(6)
    def get_MinWindowWidth(self) -> Double: ...
    @winrt_commethod(7)
    def put_MinWindowWidth(self, value: Double) -> Void: ...
    @winrt_commethod(8)
    def get_MinWindowHeight(self) -> Double: ...
    @winrt_commethod(9)
    def put_MinWindowHeight(self, value: Double) -> Void: ...
    MinWindowHeight = property(get_MinWindowHeight, put_MinWindowHeight)
    MinWindowWidth = property(get_MinWindowWidth, put_MinWindowWidth)
class IAdaptiveTriggerFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IAdaptiveTriggerFactory'
    _iid_ = Guid('{9c9560bb-4099-5175-9250-45a15e753da8}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.AdaptiveTrigger: ...
class IAdaptiveTriggerStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IAdaptiveTriggerStatics'
    _iid_ = Guid('{e7a3547f-c077-5f20-aab1-d16c30d9d37f}')
    @winrt_commethod(6)
    def get_MinWindowWidthProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(7)
    def get_MinWindowHeightProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    MinWindowHeightProperty = property(get_MinWindowHeightProperty, None)
    MinWindowWidthProperty = property(get_MinWindowWidthProperty, None)
class IApplication(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IApplication'
    _iid_ = Guid('{06a8f4e7-1146-55af-820d-ebd55643b021}')
    @winrt_commethod(6)
    def get_Resources(self) -> win32more.Microsoft.UI.Xaml.ResourceDictionary: ...
    @winrt_commethod(7)
    def put_Resources(self, value: win32more.Microsoft.UI.Xaml.ResourceDictionary) -> Void: ...
    @winrt_commethod(8)
    def get_DebugSettings(self) -> win32more.Microsoft.UI.Xaml.DebugSettings: ...
    @winrt_commethod(9)
    def get_RequestedTheme(self) -> win32more.Microsoft.UI.Xaml.ApplicationTheme: ...
    @winrt_commethod(10)
    def put_RequestedTheme(self, value: win32more.Microsoft.UI.Xaml.ApplicationTheme) -> Void: ...
    @winrt_commethod(11)
    def get_FocusVisualKind(self) -> win32more.Microsoft.UI.Xaml.FocusVisualKind: ...
    @winrt_commethod(12)
    def put_FocusVisualKind(self, value: win32more.Microsoft.UI.Xaml.FocusVisualKind) -> Void: ...
    @winrt_commethod(13)
    def get_HighContrastAdjustment(self) -> win32more.Microsoft.UI.Xaml.ApplicationHighContrastAdjustment: ...
    @winrt_commethod(14)
    def put_HighContrastAdjustment(self, value: win32more.Microsoft.UI.Xaml.ApplicationHighContrastAdjustment) -> Void: ...
    @winrt_commethod(15)
    def add_UnhandledException(self, handler: win32more.Microsoft.UI.Xaml.UnhandledExceptionEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(16)
    def remove_UnhandledException(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(17)
    def Exit(self) -> Void: ...
    DebugSettings = property(get_DebugSettings, None)
    FocusVisualKind = property(get_FocusVisualKind, put_FocusVisualKind)
    HighContrastAdjustment = property(get_HighContrastAdjustment, put_HighContrastAdjustment)
    RequestedTheme = property(get_RequestedTheme, put_RequestedTheme)
    Resources = property(get_Resources, put_Resources)
    UnhandledException = event(add_UnhandledException, remove_UnhandledException)
class IApplication2(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IApplication2'
    _iid_ = Guid('{469e6d36-2e11-5b06-9e0a-c5eef0cf8f12}')
    @winrt_commethod(6)
    def add_ResourceManagerRequested(self, handler: win32more.Windows.Foundation.TypedEventHandler[IInspectable, win32more.Microsoft.UI.Xaml.ResourceManagerRequestedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(7)
    def remove_ResourceManagerRequested(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    ResourceManagerRequested = event(add_ResourceManagerRequested, remove_ResourceManagerRequested)
class IApplication3(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IApplication3'
    _iid_ = Guid('{be941595-61fe-5b36-a3d3-962a647d7c6f}')
    @winrt_commethod(6)
    def get_DispatcherShutdownMode(self) -> win32more.Microsoft.UI.Xaml.DispatcherShutdownMode: ...
    @winrt_commethod(7)
    def put_DispatcherShutdownMode(self, value: win32more.Microsoft.UI.Xaml.DispatcherShutdownMode) -> Void: ...
    DispatcherShutdownMode = property(get_DispatcherShutdownMode, put_DispatcherShutdownMode)
class IApplicationFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IApplicationFactory'
    _iid_ = Guid('{9fd96657-5294-5a65-a1db-4fea143597da}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.Application: ...
class IApplicationInitializationCallbackParams(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IApplicationInitializationCallbackParams'
    _iid_ = Guid('{1b1906ea-5b7b-5876-81ab-7c2281ac3d20}')
class IApplicationOverrides(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IApplicationOverrides'
    _iid_ = Guid('{a33e81ef-c665-503b-8827-d27ef1720a06}')
    @winrt_commethod(6)
    def OnLaunched(self, args: win32more.Microsoft.UI.Xaml.LaunchActivatedEventArgs) -> Void: ...
class IApplicationStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IApplicationStatics'
    _iid_ = Guid('{4e0d09f5-4358-512c-a987-503b52848e95}')
    @winrt_commethod(6)
    def get_Current(self) -> win32more.Microsoft.UI.Xaml.Application: ...
    @winrt_commethod(7)
    def Start(self, callback: win32more.Microsoft.UI.Xaml.ApplicationInitializationCallback) -> Void: ...
    @winrt_commethod(8)
    def LoadComponent(self, component: IInspectable, resourceLocator: win32more.Windows.Foundation.Uri) -> Void: ...
    @winrt_commethod(9)
    def LoadComponentWithResourceLocation(self, component: IInspectable, resourceLocator: win32more.Windows.Foundation.Uri, componentResourceLocation: win32more.Microsoft.UI.Xaml.Controls.Primitives.ComponentResourceLocation) -> Void: ...
    Current = property(get_Current, None)
class IBindingFailedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IBindingFailedEventArgs'
    _iid_ = Guid('{a7bf50f3-dbc0-5b44-be74-56e8f80fd716}')
    @winrt_commethod(6)
    def get_Message(self) -> hstr: ...
    Message = property(get_Message, None)
class IBringIntoViewOptions(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IBringIntoViewOptions'
    _iid_ = Guid('{eeb4a447-eb9e-5003-a479-b9e3a886b708}')
    @winrt_commethod(6)
    def get_AnimationDesired(self) -> Boolean: ...
    @winrt_commethod(7)
    def put_AnimationDesired(self, value: Boolean) -> Void: ...
    @winrt_commethod(8)
    def get_TargetRect(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.Foundation.Rect]: ...
    @winrt_commethod(9)
    def put_TargetRect(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.Foundation.Rect]) -> Void: ...
    @winrt_commethod(10)
    def get_HorizontalAlignmentRatio(self) -> Double: ...
    @winrt_commethod(11)
    def put_HorizontalAlignmentRatio(self, value: Double) -> Void: ...
    @winrt_commethod(12)
    def get_VerticalAlignmentRatio(self) -> Double: ...
    @winrt_commethod(13)
    def put_VerticalAlignmentRatio(self, value: Double) -> Void: ...
    @winrt_commethod(14)
    def get_HorizontalOffset(self) -> Double: ...
    @winrt_commethod(15)
    def put_HorizontalOffset(self, value: Double) -> Void: ...
    @winrt_commethod(16)
    def get_VerticalOffset(self) -> Double: ...
    @winrt_commethod(17)
    def put_VerticalOffset(self, value: Double) -> Void: ...
    AnimationDesired = property(get_AnimationDesired, put_AnimationDesired)
    HorizontalAlignmentRatio = property(get_HorizontalAlignmentRatio, put_HorizontalAlignmentRatio)
    HorizontalOffset = property(get_HorizontalOffset, put_HorizontalOffset)
    TargetRect = property(get_TargetRect, put_TargetRect)
    VerticalAlignmentRatio = property(get_VerticalAlignmentRatio, put_VerticalAlignmentRatio)
    VerticalOffset = property(get_VerticalOffset, put_VerticalOffset)
class IBringIntoViewRequestedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IBringIntoViewRequestedEventArgs'
    _iid_ = Guid('{807de8f9-b1dc-5a63-8101-5ee966841a27}')
    @winrt_commethod(6)
    def get_TargetElement(self) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_commethod(7)
    def put_TargetElement(self, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    @winrt_commethod(8)
    def get_AnimationDesired(self) -> Boolean: ...
    @winrt_commethod(9)
    def put_AnimationDesired(self, value: Boolean) -> Void: ...
    @winrt_commethod(10)
    def get_TargetRect(self) -> win32more.Windows.Foundation.Rect: ...
    @winrt_commethod(11)
    def put_TargetRect(self, value: win32more.Windows.Foundation.Rect) -> Void: ...
    @winrt_commethod(12)
    def get_HorizontalAlignmentRatio(self) -> Double: ...
    @winrt_commethod(13)
    def get_VerticalAlignmentRatio(self) -> Double: ...
    @winrt_commethod(14)
    def get_HorizontalOffset(self) -> Double: ...
    @winrt_commethod(15)
    def put_HorizontalOffset(self, value: Double) -> Void: ...
    @winrt_commethod(16)
    def get_VerticalOffset(self) -> Double: ...
    @winrt_commethod(17)
    def put_VerticalOffset(self, value: Double) -> Void: ...
    @winrt_commethod(18)
    def get_Handled(self) -> Boolean: ...
    @winrt_commethod(19)
    def put_Handled(self, value: Boolean) -> Void: ...
    AnimationDesired = property(get_AnimationDesired, put_AnimationDesired)
    Handled = property(get_Handled, put_Handled)
    HorizontalAlignmentRatio = property(get_HorizontalAlignmentRatio, None)
    HorizontalOffset = property(get_HorizontalOffset, put_HorizontalOffset)
    TargetElement = property(get_TargetElement, put_TargetElement)
    TargetRect = property(get_TargetRect, put_TargetRect)
    VerticalAlignmentRatio = property(get_VerticalAlignmentRatio, None)
    VerticalOffset = property(get_VerticalOffset, put_VerticalOffset)
class IBrushTransition(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IBrushTransition'
    _iid_ = Guid('{a996a7ba-4567-5963-a112-76e3c0000204}')
    @winrt_commethod(6)
    def get_Duration(self) -> win32more.Windows.Foundation.TimeSpan: ...
    @winrt_commethod(7)
    def put_Duration(self, value: win32more.Windows.Foundation.TimeSpan) -> Void: ...
    Duration = property(get_Duration, put_Duration)
class IBrushTransitionFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IBrushTransitionFactory'
    _iid_ = Guid('{13735998-c3b6-5c24-b40a-7b166a6ffc2c}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.BrushTransition: ...
class IColorPaletteResources(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IColorPaletteResources'
    _iid_ = Guid('{1903a03c-1750-54fe-a434-14b227cbe701}')
    @winrt_commethod(6)
    def get_AltHigh(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(7)
    def put_AltHigh(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(8)
    def get_AltLow(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(9)
    def put_AltLow(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(10)
    def get_AltMedium(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(11)
    def put_AltMedium(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(12)
    def get_AltMediumHigh(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(13)
    def put_AltMediumHigh(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(14)
    def get_AltMediumLow(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(15)
    def put_AltMediumLow(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(16)
    def get_BaseHigh(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(17)
    def put_BaseHigh(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(18)
    def get_BaseLow(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(19)
    def put_BaseLow(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(20)
    def get_BaseMedium(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(21)
    def put_BaseMedium(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(22)
    def get_BaseMediumHigh(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(23)
    def put_BaseMediumHigh(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(24)
    def get_BaseMediumLow(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(25)
    def put_BaseMediumLow(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(26)
    def get_ChromeAltLow(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(27)
    def put_ChromeAltLow(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(28)
    def get_ChromeBlackHigh(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(29)
    def put_ChromeBlackHigh(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(30)
    def get_ChromeBlackLow(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(31)
    def put_ChromeBlackLow(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(32)
    def get_ChromeBlackMediumLow(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(33)
    def put_ChromeBlackMediumLow(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(34)
    def get_ChromeBlackMedium(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(35)
    def put_ChromeBlackMedium(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(36)
    def get_ChromeDisabledHigh(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(37)
    def put_ChromeDisabledHigh(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(38)
    def get_ChromeDisabledLow(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(39)
    def put_ChromeDisabledLow(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(40)
    def get_ChromeHigh(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(41)
    def put_ChromeHigh(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(42)
    def get_ChromeLow(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(43)
    def put_ChromeLow(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(44)
    def get_ChromeMedium(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(45)
    def put_ChromeMedium(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(46)
    def get_ChromeMediumLow(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(47)
    def put_ChromeMediumLow(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(48)
    def get_ChromeWhite(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(49)
    def put_ChromeWhite(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(50)
    def get_ChromeGray(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(51)
    def put_ChromeGray(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(52)
    def get_ListLow(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(53)
    def put_ListLow(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(54)
    def get_ListMedium(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(55)
    def put_ListMedium(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(56)
    def get_ErrorText(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(57)
    def put_ErrorText(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    @winrt_commethod(58)
    def get_Accent(self) -> win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]: ...
    @winrt_commethod(59)
    def put_Accent(self, value: win32more.Windows.Foundation.IReference[win32more.Windows.UI.Color]) -> Void: ...
    Accent = property(get_Accent, put_Accent)
    AltHigh = property(get_AltHigh, put_AltHigh)
    AltLow = property(get_AltLow, put_AltLow)
    AltMedium = property(get_AltMedium, put_AltMedium)
    AltMediumHigh = property(get_AltMediumHigh, put_AltMediumHigh)
    AltMediumLow = property(get_AltMediumLow, put_AltMediumLow)
    BaseHigh = property(get_BaseHigh, put_BaseHigh)
    BaseLow = property(get_BaseLow, put_BaseLow)
    BaseMedium = property(get_BaseMedium, put_BaseMedium)
    BaseMediumHigh = property(get_BaseMediumHigh, put_BaseMediumHigh)
    BaseMediumLow = property(get_BaseMediumLow, put_BaseMediumLow)
    ChromeAltLow = property(get_ChromeAltLow, put_ChromeAltLow)
    ChromeBlackHigh = property(get_ChromeBlackHigh, put_ChromeBlackHigh)
    ChromeBlackLow = property(get_ChromeBlackLow, put_ChromeBlackLow)
    ChromeBlackMedium = property(get_ChromeBlackMedium, put_ChromeBlackMedium)
    ChromeBlackMediumLow = property(get_ChromeBlackMediumLow, put_ChromeBlackMediumLow)
    ChromeDisabledHigh = property(get_ChromeDisabledHigh, put_ChromeDisabledHigh)
    ChromeDisabledLow = property(get_ChromeDisabledLow, put_ChromeDisabledLow)
    ChromeGray = property(get_ChromeGray, put_ChromeGray)
    ChromeHigh = property(get_ChromeHigh, put_ChromeHigh)
    ChromeLow = property(get_ChromeLow, put_ChromeLow)
    ChromeMedium = property(get_ChromeMedium, put_ChromeMedium)
    ChromeMediumLow = property(get_ChromeMediumLow, put_ChromeMediumLow)
    ChromeWhite = property(get_ChromeWhite, put_ChromeWhite)
    ErrorText = property(get_ErrorText, put_ErrorText)
    ListLow = property(get_ListLow, put_ListLow)
    ListMedium = property(get_ListMedium, put_ListMedium)
class IColorPaletteResourcesFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IColorPaletteResourcesFactory'
    _iid_ = Guid('{32fde185-8544-59c0-9e0a-e6e0bad9edcf}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.ColorPaletteResources: ...
class ICornerRadiusHelper(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ICornerRadiusHelper'
    _iid_ = Guid('{dfcc382d-cfa8-5614-a35a-4091d1a81c9e}')
class ICornerRadiusHelperStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ICornerRadiusHelperStatics'
    _iid_ = Guid('{77352882-894b-5ded-b54c-a86105e4e068}')
    @winrt_commethod(6)
    def FromRadii(self, topLeft: Double, topRight: Double, bottomRight: Double, bottomLeft: Double) -> win32more.Microsoft.UI.Xaml.CornerRadius: ...
    @winrt_commethod(7)
    def FromUniformRadius(self, uniformRadius: Double) -> win32more.Microsoft.UI.Xaml.CornerRadius: ...
class IDataContextChangedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDataContextChangedEventArgs'
    _iid_ = Guid('{a1be80f4-cf83-5022-b113-9233f1d4fafa}')
    @winrt_commethod(6)
    def get_NewValue(self) -> IInspectable: ...
    @winrt_commethod(7)
    def get_Handled(self) -> Boolean: ...
    @winrt_commethod(8)
    def put_Handled(self, value: Boolean) -> Void: ...
    Handled = property(get_Handled, put_Handled)
    NewValue = property(get_NewValue, None)
class IDataTemplate(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDataTemplate'
    _iid_ = Guid('{08fa70fa-ee75-5e92-a101-f52d0e1e9fab}')
    @winrt_commethod(6)
    def LoadContent(self) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
class IDataTemplateExtension(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDataTemplateExtension'
    _iid_ = Guid('{351e63c4-8fa3-5cc3-b073-7f84baa6485d}')
    @winrt_commethod(6)
    def ResetTemplate(self) -> Void: ...
    @winrt_commethod(7)
    def ProcessBinding(self, phase: UInt32) -> Boolean: ...
    @winrt_commethod(8)
    def ProcessBindings(self, arg: win32more.Microsoft.UI.Xaml.Controls.ContainerContentChangingEventArgs) -> Int32: ...
class IDataTemplateFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDataTemplateFactory'
    _iid_ = Guid('{d8e8249d-305b-5ca5-acf8-3e1beffd0219}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.DataTemplate: ...
class IDataTemplateKey(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDataTemplateKey'
    _iid_ = Guid('{6e704a95-4b2f-5ba8-ada5-1261c832baed}')
    @winrt_commethod(6)
    def get_DataType(self) -> IInspectable: ...
    @winrt_commethod(7)
    def put_DataType(self, value: IInspectable) -> Void: ...
    DataType = property(get_DataType, put_DataType)
class IDataTemplateKeyFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDataTemplateKeyFactory'
    _iid_ = Guid('{13b2f604-eebc-5daa-8a5b-460c4fabdeb7}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.DataTemplateKey: ...
    @winrt_commethod(7)
    def CreateInstanceWithType(self, dataType: IInspectable, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.DataTemplateKey: ...
class IDataTemplateStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDataTemplateStatics'
    _iid_ = Guid('{cf6ada69-4bf1-5f2d-8bdb-09ea1a26f975}')
    @winrt_commethod(6)
    def get_ExtensionInstanceProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(7)
    def GetExtensionInstance(self, element: win32more.Microsoft.UI.Xaml.FrameworkElement) -> win32more.Microsoft.UI.Xaml.IDataTemplateExtension: ...
    @winrt_commethod(8)
    def SetExtensionInstance(self, element: win32more.Microsoft.UI.Xaml.FrameworkElement, value: win32more.Microsoft.UI.Xaml.IDataTemplateExtension) -> Void: ...
    ExtensionInstanceProperty = property(get_ExtensionInstanceProperty, None)
class IDebugSettings(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDebugSettings'
    _iid_ = Guid('{4004943b-2509-5476-bba2-3fe05ecf615d}')
    @winrt_commethod(6)
    def get_EnableFrameRateCounter(self) -> Boolean: ...
    @winrt_commethod(7)
    def put_EnableFrameRateCounter(self, value: Boolean) -> Void: ...
    @winrt_commethod(8)
    def get_IsBindingTracingEnabled(self) -> Boolean: ...
    @winrt_commethod(9)
    def put_IsBindingTracingEnabled(self, value: Boolean) -> Void: ...
    @winrt_commethod(10)
    def get_IsTextPerformanceVisualizationEnabled(self) -> Boolean: ...
    @winrt_commethod(11)
    def put_IsTextPerformanceVisualizationEnabled(self, value: Boolean) -> Void: ...
    @winrt_commethod(12)
    def get_FailFastOnErrors(self) -> Boolean: ...
    @winrt_commethod(13)
    def put_FailFastOnErrors(self, value: Boolean) -> Void: ...
    @winrt_commethod(14)
    def add_BindingFailed(self, handler: win32more.Microsoft.UI.Xaml.BindingFailedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(15)
    def remove_BindingFailed(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    EnableFrameRateCounter = property(get_EnableFrameRateCounter, put_EnableFrameRateCounter)
    FailFastOnErrors = property(get_FailFastOnErrors, put_FailFastOnErrors)
    IsBindingTracingEnabled = property(get_IsBindingTracingEnabled, put_IsBindingTracingEnabled)
    IsTextPerformanceVisualizationEnabled = property(get_IsTextPerformanceVisualizationEnabled, put_IsTextPerformanceVisualizationEnabled)
    BindingFailed = event(add_BindingFailed, remove_BindingFailed)
class IDebugSettings2(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDebugSettings2'
    _iid_ = Guid('{6dfb6f51-d2f8-59c4-8bca-4410929577d0}')
    @winrt_commethod(6)
    def get_IsXamlResourceReferenceTracingEnabled(self) -> Boolean: ...
    @winrt_commethod(7)
    def put_IsXamlResourceReferenceTracingEnabled(self, value: Boolean) -> Void: ...
    @winrt_commethod(8)
    def add_XamlResourceReferenceFailed(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.DebugSettings, win32more.Microsoft.UI.Xaml.XamlResourceReferenceFailedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(9)
    def remove_XamlResourceReferenceFailed(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    IsXamlResourceReferenceTracingEnabled = property(get_IsXamlResourceReferenceTracingEnabled, put_IsXamlResourceReferenceTracingEnabled)
    XamlResourceReferenceFailed = event(add_XamlResourceReferenceFailed, remove_XamlResourceReferenceFailed)
class IDebugSettings3(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDebugSettings3'
    _iid_ = Guid('{36135bd5-3917-5c8d-a3c6-2fc89a503f26}')
    @winrt_commethod(6)
    def get_LayoutCycleTracingLevel(self) -> win32more.Microsoft.UI.Xaml.LayoutCycleTracingLevel: ...
    @winrt_commethod(7)
    def put_LayoutCycleTracingLevel(self, value: win32more.Microsoft.UI.Xaml.LayoutCycleTracingLevel) -> Void: ...
    @winrt_commethod(8)
    def get_LayoutCycleDebugBreakLevel(self) -> win32more.Microsoft.UI.Xaml.LayoutCycleDebugBreakLevel: ...
    @winrt_commethod(9)
    def put_LayoutCycleDebugBreakLevel(self, value: win32more.Microsoft.UI.Xaml.LayoutCycleDebugBreakLevel) -> Void: ...
    LayoutCycleDebugBreakLevel = property(get_LayoutCycleDebugBreakLevel, put_LayoutCycleDebugBreakLevel)
    LayoutCycleTracingLevel = property(get_LayoutCycleTracingLevel, put_LayoutCycleTracingLevel)
class IDependencyObject(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDependencyObject'
    _iid_ = Guid('{e7beaee7-160e-50f7-8789-d63463f979fa}')
    @winrt_commethod(6)
    def GetValue(self, dp: win32more.Microsoft.UI.Xaml.DependencyProperty) -> IInspectable: ...
    @winrt_commethod(7)
    def SetValue(self, dp: win32more.Microsoft.UI.Xaml.DependencyProperty, value: IInspectable) -> Void: ...
    @winrt_commethod(8)
    def ClearValue(self, dp: win32more.Microsoft.UI.Xaml.DependencyProperty) -> Void: ...
    @winrt_commethod(9)
    def ReadLocalValue(self, dp: win32more.Microsoft.UI.Xaml.DependencyProperty) -> IInspectable: ...
    @winrt_commethod(10)
    def GetAnimationBaseValue(self, dp: win32more.Microsoft.UI.Xaml.DependencyProperty) -> IInspectable: ...
    @winrt_commethod(11)
    def RegisterPropertyChangedCallback(self, dp: win32more.Microsoft.UI.Xaml.DependencyProperty, callback: win32more.Microsoft.UI.Xaml.DependencyPropertyChangedCallback) -> Int64: ...
    @winrt_commethod(12)
    def UnregisterPropertyChangedCallback(self, dp: win32more.Microsoft.UI.Xaml.DependencyProperty, token: Int64) -> Void: ...
    @winrt_commethod(13)
    def get_Dispatcher(self) -> win32more.Windows.UI.Core.CoreDispatcher: ...
    @winrt_commethod(14)
    def get_DispatcherQueue(self) -> win32more.Microsoft.UI.Dispatching.DispatcherQueue: ...
    Dispatcher = property(get_Dispatcher, None)
    DispatcherQueue = property(get_DispatcherQueue, None)
class IDependencyObjectCollectionFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDependencyObjectCollectionFactory'
    _iid_ = Guid('{2a74ee43-90fd-5d61-9383-584ea8422b39}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.DependencyObjectCollection: ...
class IDependencyObjectFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDependencyObjectFactory'
    _iid_ = Guid('{936b614c-475f-5d7d-b3f7-bf1fbea28126}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
class IDependencyProperty(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDependencyProperty'
    _iid_ = Guid('{960eab49-9672-58a0-995b-3a42e5ea6278}')
    @winrt_commethod(6)
    def GetMetadata(self, forType: win32more.Windows.UI.Xaml.Interop.TypeName) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
class IDependencyPropertyChangedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDependencyPropertyChangedEventArgs'
    _iid_ = Guid('{84ead020-7849-5e98-8030-488a80d164ec}')
    @winrt_commethod(6)
    def get_Property(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(7)
    def get_OldValue(self) -> IInspectable: ...
    @winrt_commethod(8)
    def get_NewValue(self) -> IInspectable: ...
    NewValue = property(get_NewValue, None)
    OldValue = property(get_OldValue, None)
    Property = property(get_Property, None)
class IDependencyPropertyStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDependencyPropertyStatics'
    _iid_ = Guid('{61ddc651-0383-5d6f-98ce-5c046aaaaa8f}')
    @winrt_commethod(6)
    def get_UnsetValue(self) -> IInspectable: ...
    @winrt_commethod(7)
    def Register(self, name: hstr, propertyType: win32more.Windows.UI.Xaml.Interop.TypeName, ownerType: win32more.Windows.UI.Xaml.Interop.TypeName, typeMetadata: win32more.Microsoft.UI.Xaml.PropertyMetadata) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(8)
    def RegisterAttached(self, name: hstr, propertyType: win32more.Windows.UI.Xaml.Interop.TypeName, ownerType: win32more.Windows.UI.Xaml.Interop.TypeName, defaultMetadata: win32more.Microsoft.UI.Xaml.PropertyMetadata) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    UnsetValue = property(get_UnsetValue, None)
class IDispatcherTimer(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDispatcherTimer'
    _iid_ = Guid('{58a4abf1-a4a3-53dd-ae21-08f43231e817}')
    @winrt_commethod(6)
    def get_Interval(self) -> win32more.Windows.Foundation.TimeSpan: ...
    @winrt_commethod(7)
    def put_Interval(self, value: win32more.Windows.Foundation.TimeSpan) -> Void: ...
    @winrt_commethod(8)
    def get_IsEnabled(self) -> Boolean: ...
    @winrt_commethod(9)
    def add_Tick(self, handler: win32more.Windows.Foundation.EventHandler[IInspectable]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(10)
    def remove_Tick(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(11)
    def Start(self) -> Void: ...
    @winrt_commethod(12)
    def Stop(self) -> Void: ...
    Interval = property(get_Interval, put_Interval)
    IsEnabled = property(get_IsEnabled, None)
    Tick = event(add_Tick, remove_Tick)
class IDispatcherTimerFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDispatcherTimerFactory'
    _iid_ = Guid('{1bcb3166-22e4-50bf-a5a2-b78ca4377bd0}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.DispatcherTimer: ...
class IDragEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDragEventArgs'
    _iid_ = Guid('{47ac5757-e4bc-52ba-8ab9-1bf81aad7900}')
    @winrt_commethod(6)
    def get_Handled(self) -> Boolean: ...
    @winrt_commethod(7)
    def put_Handled(self, value: Boolean) -> Void: ...
    @winrt_commethod(8)
    def get_Data(self) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackage: ...
    @winrt_commethod(9)
    def put_Data(self, value: win32more.Windows.ApplicationModel.DataTransfer.DataPackage) -> Void: ...
    @winrt_commethod(10)
    def get_DataView(self) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackageView: ...
    @winrt_commethod(11)
    def get_DragUIOverride(self) -> win32more.Microsoft.UI.Xaml.DragUIOverride: ...
    @winrt_commethod(12)
    def get_Modifiers(self) -> win32more.Windows.ApplicationModel.DataTransfer.DragDrop.DragDropModifiers: ...
    @winrt_commethod(13)
    def get_AcceptedOperation(self) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation: ...
    @winrt_commethod(14)
    def put_AcceptedOperation(self, value: win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation) -> Void: ...
    @winrt_commethod(15)
    def get_AllowedOperations(self) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation: ...
    @winrt_commethod(16)
    def GetDeferral(self) -> win32more.Microsoft.UI.Xaml.DragOperationDeferral: ...
    @winrt_commethod(17)
    def GetPosition(self, relativeTo: win32more.Microsoft.UI.Xaml.UIElement) -> win32more.Windows.Foundation.Point: ...
    AcceptedOperation = property(get_AcceptedOperation, put_AcceptedOperation)
    AllowedOperations = property(get_AllowedOperations, None)
    Data = property(get_Data, put_Data)
    DataView = property(get_DataView, None)
    DragUIOverride = property(get_DragUIOverride, None)
    Handled = property(get_Handled, put_Handled)
    Modifiers = property(get_Modifiers, None)
class IDragOperationDeferral(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDragOperationDeferral'
    _iid_ = Guid('{462c1880-fc6a-5035-8abf-564bacb78158}')
    @winrt_commethod(6)
    def Complete(self) -> Void: ...
class IDragStartingEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDragStartingEventArgs'
    _iid_ = Guid('{ad17bace-9613-5666-a31b-79a73fba77cf}')
    @winrt_commethod(6)
    def get_Cancel(self) -> Boolean: ...
    @winrt_commethod(7)
    def put_Cancel(self, value: Boolean) -> Void: ...
    @winrt_commethod(8)
    def get_Data(self) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackage: ...
    @winrt_commethod(9)
    def get_DragUI(self) -> win32more.Microsoft.UI.Xaml.DragUI: ...
    @winrt_commethod(10)
    def get_AllowedOperations(self) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation: ...
    @winrt_commethod(11)
    def put_AllowedOperations(self, value: win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation) -> Void: ...
    @winrt_commethod(12)
    def GetDeferral(self) -> win32more.Microsoft.UI.Xaml.DragOperationDeferral: ...
    @winrt_commethod(13)
    def GetPosition(self, relativeTo: win32more.Microsoft.UI.Xaml.UIElement) -> win32more.Windows.Foundation.Point: ...
    AllowedOperations = property(get_AllowedOperations, put_AllowedOperations)
    Cancel = property(get_Cancel, put_Cancel)
    Data = property(get_Data, None)
    DragUI = property(get_DragUI, None)
class IDragUI(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDragUI'
    _iid_ = Guid('{35f170e0-93bf-58da-877a-8ec77d8d9f00}')
    @winrt_commethod(6)
    def SetContentFromBitmapImage(self, bitmapImage: win32more.Microsoft.UI.Xaml.Media.Imaging.BitmapImage) -> Void: ...
    @winrt_commethod(7)
    def SetContentFromBitmapImageWithAnchorPoint(self, bitmapImage: win32more.Microsoft.UI.Xaml.Media.Imaging.BitmapImage, anchorPoint: win32more.Windows.Foundation.Point) -> Void: ...
    @winrt_commethod(8)
    def SetContentFromSoftwareBitmap(self, softwareBitmap: win32more.Windows.Graphics.Imaging.SoftwareBitmap) -> Void: ...
    @winrt_commethod(9)
    def SetContentFromSoftwareBitmapWithAnchorPoint(self, softwareBitmap: win32more.Windows.Graphics.Imaging.SoftwareBitmap, anchorPoint: win32more.Windows.Foundation.Point) -> Void: ...
    @winrt_commethod(10)
    def SetContentFromDataPackage(self) -> Void: ...
class IDragUIOverride(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDragUIOverride'
    _iid_ = Guid('{3260b18b-70df-5df2-b98a-56beb0601f79}')
    @winrt_commethod(6)
    def get_Caption(self) -> hstr: ...
    @winrt_commethod(7)
    def put_Caption(self, value: hstr) -> Void: ...
    @winrt_commethod(8)
    def get_IsContentVisible(self) -> Boolean: ...
    @winrt_commethod(9)
    def put_IsContentVisible(self, value: Boolean) -> Void: ...
    @winrt_commethod(10)
    def get_IsCaptionVisible(self) -> Boolean: ...
    @winrt_commethod(11)
    def put_IsCaptionVisible(self, value: Boolean) -> Void: ...
    @winrt_commethod(12)
    def get_IsGlyphVisible(self) -> Boolean: ...
    @winrt_commethod(13)
    def put_IsGlyphVisible(self, value: Boolean) -> Void: ...
    @winrt_commethod(14)
    def Clear(self) -> Void: ...
    @winrt_commethod(15)
    def SetContentFromBitmapImage(self, bitmapImage: win32more.Microsoft.UI.Xaml.Media.Imaging.BitmapImage) -> Void: ...
    @winrt_commethod(16)
    def SetContentFromBitmapImageWithAnchorPoint(self, bitmapImage: win32more.Microsoft.UI.Xaml.Media.Imaging.BitmapImage, anchorPoint: win32more.Windows.Foundation.Point) -> Void: ...
    @winrt_commethod(17)
    def SetContentFromSoftwareBitmap(self, softwareBitmap: win32more.Windows.Graphics.Imaging.SoftwareBitmap) -> Void: ...
    @winrt_commethod(18)
    def SetContentFromSoftwareBitmapWithAnchorPoint(self, softwareBitmap: win32more.Windows.Graphics.Imaging.SoftwareBitmap, anchorPoint: win32more.Windows.Foundation.Point) -> Void: ...
    Caption = property(get_Caption, put_Caption)
    IsCaptionVisible = property(get_IsCaptionVisible, put_IsCaptionVisible)
    IsContentVisible = property(get_IsContentVisible, put_IsContentVisible)
    IsGlyphVisible = property(get_IsGlyphVisible, put_IsGlyphVisible)
class IDropCompletedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDropCompletedEventArgs'
    _iid_ = Guid('{e700082d-c640-5d44-b23a-f213dfbeb245}')
    @winrt_commethod(6)
    def get_DropResult(self) -> win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation: ...
    DropResult = property(get_DropResult, None)
class IDurationHelper(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDurationHelper'
    _iid_ = Guid('{cc1089ab-8041-5c3e-b753-8397e7358cc6}')
class IDurationHelperStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IDurationHelperStatics'
    _iid_ = Guid('{491feb2c-3475-5f89-b15c-49c236eb514c}')
    @winrt_commethod(6)
    def get_Automatic(self) -> win32more.Microsoft.UI.Xaml.Duration: ...
    @winrt_commethod(7)
    def get_Forever(self) -> win32more.Microsoft.UI.Xaml.Duration: ...
    @winrt_commethod(8)
    def Compare(self, duration1: win32more.Microsoft.UI.Xaml.Duration, duration2: win32more.Microsoft.UI.Xaml.Duration) -> Int32: ...
    @winrt_commethod(9)
    def FromTimeSpan(self, timeSpan: win32more.Windows.Foundation.TimeSpan) -> win32more.Microsoft.UI.Xaml.Duration: ...
    @winrt_commethod(10)
    def GetHasTimeSpan(self, target: win32more.Microsoft.UI.Xaml.Duration) -> Boolean: ...
    @winrt_commethod(11)
    def Add(self, target: win32more.Microsoft.UI.Xaml.Duration, duration: win32more.Microsoft.UI.Xaml.Duration) -> win32more.Microsoft.UI.Xaml.Duration: ...
    @winrt_commethod(12)
    def Equals(self, target: win32more.Microsoft.UI.Xaml.Duration, value: win32more.Microsoft.UI.Xaml.Duration) -> Boolean: ...
    @winrt_commethod(13)
    def Subtract(self, target: win32more.Microsoft.UI.Xaml.Duration, duration: win32more.Microsoft.UI.Xaml.Duration) -> win32more.Microsoft.UI.Xaml.Duration: ...
    Automatic = property(get_Automatic, None)
    Forever = property(get_Forever, None)
class IEffectiveViewportChangedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IEffectiveViewportChangedEventArgs'
    _iid_ = Guid('{636e8159-2d82-538a-8483-cd576e41d0df}')
    @winrt_commethod(6)
    def get_EffectiveViewport(self) -> win32more.Windows.Foundation.Rect: ...
    @winrt_commethod(7)
    def get_MaxViewport(self) -> win32more.Windows.Foundation.Rect: ...
    @winrt_commethod(8)
    def get_BringIntoViewDistanceX(self) -> Double: ...
    @winrt_commethod(9)
    def get_BringIntoViewDistanceY(self) -> Double: ...
    BringIntoViewDistanceX = property(get_BringIntoViewDistanceX, None)
    BringIntoViewDistanceY = property(get_BringIntoViewDistanceY, None)
    EffectiveViewport = property(get_EffectiveViewport, None)
    MaxViewport = property(get_MaxViewport, None)
class IElementFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IElementFactory'
    _iid_ = Guid('{75faba47-2cf2-54ae-91e6-0581556fddaa}')
    @winrt_commethod(6)
    def GetElement(self, args: win32more.Microsoft.UI.Xaml.ElementFactoryGetArgs) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_commethod(7)
    def RecycleElement(self, args: win32more.Microsoft.UI.Xaml.ElementFactoryRecycleArgs) -> Void: ...
class IElementFactoryGetArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IElementFactoryGetArgs'
    _iid_ = Guid('{b7017d68-ec9e-5435-b078-be6f906f0953}')
    @winrt_commethod(6)
    def get_Data(self) -> IInspectable: ...
    @winrt_commethod(7)
    def put_Data(self, value: IInspectable) -> Void: ...
    @winrt_commethod(8)
    def get_Parent(self) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_commethod(9)
    def put_Parent(self, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    Data = property(get_Data, put_Data)
    Parent = property(get_Parent, put_Parent)
class IElementFactoryGetArgsFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IElementFactoryGetArgsFactory'
    _iid_ = Guid('{a88e401b-9fe5-5960-87a3-89a3cfe2531c}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.ElementFactoryGetArgs: ...
class IElementFactoryRecycleArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IElementFactoryRecycleArgs'
    _iid_ = Guid('{46e444f7-05d3-5c5e-9b7a-5541f63e4ef9}')
    @winrt_commethod(6)
    def get_Element(self) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_commethod(7)
    def put_Element(self, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    @winrt_commethod(8)
    def get_Parent(self) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_commethod(9)
    def put_Parent(self, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    Element = property(get_Element, put_Element)
    Parent = property(get_Parent, put_Parent)
class IElementFactoryRecycleArgsFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IElementFactoryRecycleArgsFactory'
    _iid_ = Guid('{30ee194a-fe4d-53e7-a84a-cd34fab0d4ef}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.ElementFactoryRecycleArgs: ...
class IElementSoundPlayer(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IElementSoundPlayer'
    _iid_ = Guid('{0ea67e68-937c-5c00-b609-53b63d9a5d42}')
class IElementSoundPlayerStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IElementSoundPlayerStatics'
    _iid_ = Guid('{5a5a20c3-1c9b-5d61-9d63-487c8bf16ecb}')
    @winrt_commethod(6)
    def get_Volume(self) -> Double: ...
    @winrt_commethod(7)
    def put_Volume(self, value: Double) -> Void: ...
    @winrt_commethod(8)
    def get_State(self) -> win32more.Microsoft.UI.Xaml.ElementSoundPlayerState: ...
    @winrt_commethod(9)
    def put_State(self, value: win32more.Microsoft.UI.Xaml.ElementSoundPlayerState) -> Void: ...
    @winrt_commethod(10)
    def get_SpatialAudioMode(self) -> win32more.Microsoft.UI.Xaml.ElementSpatialAudioMode: ...
    @winrt_commethod(11)
    def put_SpatialAudioMode(self, value: win32more.Microsoft.UI.Xaml.ElementSpatialAudioMode) -> Void: ...
    @winrt_commethod(12)
    def Play(self, sound: win32more.Microsoft.UI.Xaml.ElementSoundKind) -> Void: ...
    SpatialAudioMode = property(get_SpatialAudioMode, put_SpatialAudioMode)
    State = property(get_State, put_State)
    Volume = property(get_Volume, put_Volume)
class IEventTrigger(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IEventTrigger'
    _iid_ = Guid('{8c6f0541-c6ac-5f27-9d45-cf8bdbdfabe6}')
    @winrt_commethod(6)
    def get_RoutedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(7)
    def put_RoutedEvent(self, value: win32more.Microsoft.UI.Xaml.RoutedEvent) -> Void: ...
    @winrt_commethod(8)
    def get_Actions(self) -> win32more.Microsoft.UI.Xaml.TriggerActionCollection: ...
    Actions = property(get_Actions, None)
    RoutedEvent = property(get_RoutedEvent, put_RoutedEvent)
class IExceptionRoutedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IExceptionRoutedEventArgs'
    _iid_ = Guid('{e8bcb6d2-d3f5-5393-a84f-dfcd44a2df34}')
    @winrt_commethod(6)
    def get_ErrorMessage(self) -> hstr: ...
    ErrorMessage = property(get_ErrorMessage, None)
class IExceptionRoutedEventArgsFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IExceptionRoutedEventArgsFactory'
    _iid_ = Guid('{e1e71fb6-2ad0-5189-8d96-33bae488c5fb}')
class IFrameworkElement(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IFrameworkElement'
    _iid_ = Guid('{fe08f13d-dc6a-5495-ad44-c2d8d21863b0}')
    @winrt_commethod(6)
    def get_Triggers(self) -> win32more.Microsoft.UI.Xaml.TriggerCollection: ...
    @winrt_commethod(7)
    def get_Resources(self) -> win32more.Microsoft.UI.Xaml.ResourceDictionary: ...
    @winrt_commethod(8)
    def put_Resources(self, value: win32more.Microsoft.UI.Xaml.ResourceDictionary) -> Void: ...
    @winrt_commethod(9)
    def get_Tag(self) -> IInspectable: ...
    @winrt_commethod(10)
    def put_Tag(self, value: IInspectable) -> Void: ...
    @winrt_commethod(11)
    def get_Language(self) -> hstr: ...
    @winrt_commethod(12)
    def put_Language(self, value: hstr) -> Void: ...
    @winrt_commethod(13)
    def get_ActualWidth(self) -> Double: ...
    @winrt_commethod(14)
    def get_ActualHeight(self) -> Double: ...
    @winrt_commethod(15)
    def get_Width(self) -> Double: ...
    @winrt_commethod(16)
    def put_Width(self, value: Double) -> Void: ...
    @winrt_commethod(17)
    def get_Height(self) -> Double: ...
    @winrt_commethod(18)
    def put_Height(self, value: Double) -> Void: ...
    @winrt_commethod(19)
    def get_MinWidth(self) -> Double: ...
    @winrt_commethod(20)
    def put_MinWidth(self, value: Double) -> Void: ...
    @winrt_commethod(21)
    def get_MaxWidth(self) -> Double: ...
    @winrt_commethod(22)
    def put_MaxWidth(self, value: Double) -> Void: ...
    @winrt_commethod(23)
    def get_MinHeight(self) -> Double: ...
    @winrt_commethod(24)
    def put_MinHeight(self, value: Double) -> Void: ...
    @winrt_commethod(25)
    def get_MaxHeight(self) -> Double: ...
    @winrt_commethod(26)
    def put_MaxHeight(self, value: Double) -> Void: ...
    @winrt_commethod(27)
    def get_HorizontalAlignment(self) -> win32more.Microsoft.UI.Xaml.HorizontalAlignment: ...
    @winrt_commethod(28)
    def put_HorizontalAlignment(self, value: win32more.Microsoft.UI.Xaml.HorizontalAlignment) -> Void: ...
    @winrt_commethod(29)
    def get_VerticalAlignment(self) -> win32more.Microsoft.UI.Xaml.VerticalAlignment: ...
    @winrt_commethod(30)
    def put_VerticalAlignment(self, value: win32more.Microsoft.UI.Xaml.VerticalAlignment) -> Void: ...
    @winrt_commethod(31)
    def get_Margin(self) -> win32more.Microsoft.UI.Xaml.Thickness: ...
    @winrt_commethod(32)
    def put_Margin(self, value: win32more.Microsoft.UI.Xaml.Thickness) -> Void: ...
    @winrt_commethod(33)
    def get_Name(self) -> hstr: ...
    @winrt_commethod(34)
    def put_Name(self, value: hstr) -> Void: ...
    @winrt_commethod(35)
    def get_BaseUri(self) -> win32more.Windows.Foundation.Uri: ...
    @winrt_commethod(36)
    def get_DataContext(self) -> IInspectable: ...
    @winrt_commethod(37)
    def put_DataContext(self, value: IInspectable) -> Void: ...
    @winrt_commethod(38)
    def get_AllowFocusOnInteraction(self) -> Boolean: ...
    @winrt_commethod(39)
    def put_AllowFocusOnInteraction(self, value: Boolean) -> Void: ...
    @winrt_commethod(40)
    def get_FocusVisualMargin(self) -> win32more.Microsoft.UI.Xaml.Thickness: ...
    @winrt_commethod(41)
    def put_FocusVisualMargin(self, value: win32more.Microsoft.UI.Xaml.Thickness) -> Void: ...
    @winrt_commethod(42)
    def get_FocusVisualSecondaryThickness(self) -> win32more.Microsoft.UI.Xaml.Thickness: ...
    @winrt_commethod(43)
    def put_FocusVisualSecondaryThickness(self, value: win32more.Microsoft.UI.Xaml.Thickness) -> Void: ...
    @winrt_commethod(44)
    def get_FocusVisualPrimaryThickness(self) -> win32more.Microsoft.UI.Xaml.Thickness: ...
    @winrt_commethod(45)
    def put_FocusVisualPrimaryThickness(self, value: win32more.Microsoft.UI.Xaml.Thickness) -> Void: ...
    @winrt_commethod(46)
    def get_FocusVisualSecondaryBrush(self) -> win32more.Microsoft.UI.Xaml.Media.Brush: ...
    @winrt_commethod(47)
    def put_FocusVisualSecondaryBrush(self, value: win32more.Microsoft.UI.Xaml.Media.Brush) -> Void: ...
    @winrt_commethod(48)
    def get_FocusVisualPrimaryBrush(self) -> win32more.Microsoft.UI.Xaml.Media.Brush: ...
    @winrt_commethod(49)
    def put_FocusVisualPrimaryBrush(self, value: win32more.Microsoft.UI.Xaml.Media.Brush) -> Void: ...
    @winrt_commethod(50)
    def get_AllowFocusWhenDisabled(self) -> Boolean: ...
    @winrt_commethod(51)
    def put_AllowFocusWhenDisabled(self, value: Boolean) -> Void: ...
    @winrt_commethod(52)
    def get_Style(self) -> win32more.Microsoft.UI.Xaml.Style: ...
    @winrt_commethod(53)
    def put_Style(self, value: win32more.Microsoft.UI.Xaml.Style) -> Void: ...
    @winrt_commethod(54)
    def get_Parent(self) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_commethod(55)
    def get_FlowDirection(self) -> win32more.Microsoft.UI.Xaml.FlowDirection: ...
    @winrt_commethod(56)
    def put_FlowDirection(self, value: win32more.Microsoft.UI.Xaml.FlowDirection) -> Void: ...
    @winrt_commethod(57)
    def get_RequestedTheme(self) -> win32more.Microsoft.UI.Xaml.ElementTheme: ...
    @winrt_commethod(58)
    def put_RequestedTheme(self, value: win32more.Microsoft.UI.Xaml.ElementTheme) -> Void: ...
    @winrt_commethod(59)
    def get_IsLoaded(self) -> Boolean: ...
    @winrt_commethod(60)
    def get_ActualTheme(self) -> win32more.Microsoft.UI.Xaml.ElementTheme: ...
    @winrt_commethod(61)
    def add_Loaded(self, handler: win32more.Microsoft.UI.Xaml.RoutedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(62)
    def remove_Loaded(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(63)
    def add_Unloaded(self, handler: win32more.Microsoft.UI.Xaml.RoutedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(64)
    def remove_Unloaded(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(65)
    def add_DataContextChanged(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.FrameworkElement, win32more.Microsoft.UI.Xaml.DataContextChangedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(66)
    def remove_DataContextChanged(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(67)
    def add_SizeChanged(self, handler: win32more.Microsoft.UI.Xaml.SizeChangedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(68)
    def remove_SizeChanged(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(69)
    def add_LayoutUpdated(self, handler: win32more.Windows.Foundation.EventHandler[IInspectable]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(70)
    def remove_LayoutUpdated(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(71)
    def add_Loading(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.FrameworkElement, IInspectable]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(72)
    def remove_Loading(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(73)
    def add_ActualThemeChanged(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.FrameworkElement, IInspectable]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(74)
    def remove_ActualThemeChanged(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(75)
    def add_EffectiveViewportChanged(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.FrameworkElement, win32more.Microsoft.UI.Xaml.EffectiveViewportChangedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(76)
    def remove_EffectiveViewportChanged(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(77)
    def FindName(self, name: hstr) -> IInspectable: ...
    @winrt_commethod(78)
    def SetBinding(self, dp: win32more.Microsoft.UI.Xaml.DependencyProperty, binding: win32more.Microsoft.UI.Xaml.Data.BindingBase) -> Void: ...
    @winrt_commethod(79)
    def GetBindingExpression(self, dp: win32more.Microsoft.UI.Xaml.DependencyProperty) -> win32more.Microsoft.UI.Xaml.Data.BindingExpression: ...
    ActualHeight = property(get_ActualHeight, None)
    ActualTheme = property(get_ActualTheme, None)
    ActualWidth = property(get_ActualWidth, None)
    AllowFocusOnInteraction = property(get_AllowFocusOnInteraction, put_AllowFocusOnInteraction)
    AllowFocusWhenDisabled = property(get_AllowFocusWhenDisabled, put_AllowFocusWhenDisabled)
    BaseUri = property(get_BaseUri, None)
    DataContext = property(get_DataContext, put_DataContext)
    FlowDirection = property(get_FlowDirection, put_FlowDirection)
    FocusVisualMargin = property(get_FocusVisualMargin, put_FocusVisualMargin)
    FocusVisualPrimaryBrush = property(get_FocusVisualPrimaryBrush, put_FocusVisualPrimaryBrush)
    FocusVisualPrimaryThickness = property(get_FocusVisualPrimaryThickness, put_FocusVisualPrimaryThickness)
    FocusVisualSecondaryBrush = property(get_FocusVisualSecondaryBrush, put_FocusVisualSecondaryBrush)
    FocusVisualSecondaryThickness = property(get_FocusVisualSecondaryThickness, put_FocusVisualSecondaryThickness)
    Height = property(get_Height, put_Height)
    HorizontalAlignment = property(get_HorizontalAlignment, put_HorizontalAlignment)
    IsLoaded = property(get_IsLoaded, None)
    Language = property(get_Language, put_Language)
    Margin = property(get_Margin, put_Margin)
    MaxHeight = property(get_MaxHeight, put_MaxHeight)
    MaxWidth = property(get_MaxWidth, put_MaxWidth)
    MinHeight = property(get_MinHeight, put_MinHeight)
    MinWidth = property(get_MinWidth, put_MinWidth)
    Name = property(get_Name, put_Name)
    Parent = property(get_Parent, None)
    RequestedTheme = property(get_RequestedTheme, put_RequestedTheme)
    Resources = property(get_Resources, put_Resources)
    Style = property(get_Style, put_Style)
    Tag = property(get_Tag, put_Tag)
    Triggers = property(get_Triggers, None)
    VerticalAlignment = property(get_VerticalAlignment, put_VerticalAlignment)
    Width = property(get_Width, put_Width)
    ActualThemeChanged = event(add_ActualThemeChanged, remove_ActualThemeChanged)
    DataContextChanged = event(add_DataContextChanged, remove_DataContextChanged)
    EffectiveViewportChanged = event(add_EffectiveViewportChanged, remove_EffectiveViewportChanged)
    LayoutUpdated = event(add_LayoutUpdated, remove_LayoutUpdated)
    Loaded = event(add_Loaded, remove_Loaded)
    Loading = event(add_Loading, remove_Loading)
    SizeChanged = event(add_SizeChanged, remove_SizeChanged)
    Unloaded = event(add_Unloaded, remove_Unloaded)
class IFrameworkElementFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IFrameworkElementFactory'
    _iid_ = Guid('{bd3f2272-3efa-5f92-b759-90b1cc3e784c}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.FrameworkElement: ...
class IFrameworkElementOverrides(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IFrameworkElementOverrides'
    _iid_ = Guid('{ffc6fd98-f38c-5904-9ce4-97a3427cf4ba}')
    @winrt_commethod(6)
    def MeasureOverride(self, availableSize: win32more.Windows.Foundation.Size) -> win32more.Windows.Foundation.Size: ...
    @winrt_commethod(7)
    def ArrangeOverride(self, finalSize: win32more.Windows.Foundation.Size) -> win32more.Windows.Foundation.Size: ...
    @winrt_commethod(8)
    def OnApplyTemplate(self) -> Void: ...
    @winrt_commethod(9)
    def GoToElementStateCore(self, stateName: hstr, useTransitions: Boolean) -> Boolean: ...
class IFrameworkElementProtected(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IFrameworkElementProtected'
    _iid_ = Guid('{e59a3db0-91e5-5903-9caf-d1bb9f458bf2}')
    @winrt_commethod(6)
    def InvalidateViewport(self) -> Void: ...
class IFrameworkElementStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IFrameworkElementStatics'
    _iid_ = Guid('{894e2704-14e7-569a-b21e-afc7df7145a1}')
    @winrt_commethod(6)
    def get_TagProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(7)
    def get_LanguageProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(8)
    def get_ActualWidthProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(9)
    def get_ActualHeightProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(10)
    def get_WidthProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(11)
    def get_HeightProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(12)
    def get_MinWidthProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(13)
    def get_MaxWidthProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(14)
    def get_MinHeightProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(15)
    def get_MaxHeightProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(16)
    def get_HorizontalAlignmentProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(17)
    def get_VerticalAlignmentProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(18)
    def get_MarginProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(19)
    def get_NameProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(20)
    def get_DataContextProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(21)
    def get_AllowFocusOnInteractionProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(22)
    def get_FocusVisualMarginProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(23)
    def get_FocusVisualSecondaryThicknessProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(24)
    def get_FocusVisualPrimaryThicknessProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(25)
    def get_FocusVisualSecondaryBrushProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(26)
    def get_FocusVisualPrimaryBrushProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(27)
    def get_AllowFocusWhenDisabledProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(28)
    def get_StyleProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(29)
    def get_FlowDirectionProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(30)
    def get_RequestedThemeProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(31)
    def get_ActualThemeProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(32)
    def DeferTree(self, element: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    ActualHeightProperty = property(get_ActualHeightProperty, None)
    ActualThemeProperty = property(get_ActualThemeProperty, None)
    ActualWidthProperty = property(get_ActualWidthProperty, None)
    AllowFocusOnInteractionProperty = property(get_AllowFocusOnInteractionProperty, None)
    AllowFocusWhenDisabledProperty = property(get_AllowFocusWhenDisabledProperty, None)
    DataContextProperty = property(get_DataContextProperty, None)
    FlowDirectionProperty = property(get_FlowDirectionProperty, None)
    FocusVisualMarginProperty = property(get_FocusVisualMarginProperty, None)
    FocusVisualPrimaryBrushProperty = property(get_FocusVisualPrimaryBrushProperty, None)
    FocusVisualPrimaryThicknessProperty = property(get_FocusVisualPrimaryThicknessProperty, None)
    FocusVisualSecondaryBrushProperty = property(get_FocusVisualSecondaryBrushProperty, None)
    FocusVisualSecondaryThicknessProperty = property(get_FocusVisualSecondaryThicknessProperty, None)
    HeightProperty = property(get_HeightProperty, None)
    HorizontalAlignmentProperty = property(get_HorizontalAlignmentProperty, None)
    LanguageProperty = property(get_LanguageProperty, None)
    MarginProperty = property(get_MarginProperty, None)
    MaxHeightProperty = property(get_MaxHeightProperty, None)
    MaxWidthProperty = property(get_MaxWidthProperty, None)
    MinHeightProperty = property(get_MinHeightProperty, None)
    MinWidthProperty = property(get_MinWidthProperty, None)
    NameProperty = property(get_NameProperty, None)
    RequestedThemeProperty = property(get_RequestedThemeProperty, None)
    StyleProperty = property(get_StyleProperty, None)
    TagProperty = property(get_TagProperty, None)
    VerticalAlignmentProperty = property(get_VerticalAlignmentProperty, None)
    WidthProperty = property(get_WidthProperty, None)
class IFrameworkTemplate(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IFrameworkTemplate'
    _iid_ = Guid('{0084c7c2-de48-5b0b-8a5a-e4fb76b7f7d1}')
class IFrameworkTemplateFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IFrameworkTemplateFactory'
    _iid_ = Guid('{616dd6db-b064-561d-b162-46ceb45dc562}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.FrameworkTemplate: ...
class IFrameworkView(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IFrameworkView'
    _iid_ = Guid('{e60094c3-45af-5a8f-9511-1781d7df1799}')
class IFrameworkViewSource(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IFrameworkViewSource'
    _iid_ = Guid('{52b5d975-6fa6-5b66-a248-d17443b2bca0}')
class IGridLengthHelper(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IGridLengthHelper'
    _iid_ = Guid('{592b4fd5-6564-54e0-87d6-1c41939ed499}')
class IGridLengthHelperStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IGridLengthHelperStatics'
    _iid_ = Guid('{cea8881b-4e64-535d-9fcd-b4828d3979b0}')
    @winrt_commethod(6)
    def get_Auto(self) -> win32more.Microsoft.UI.Xaml.GridLength: ...
    @winrt_commethod(7)
    def FromPixels(self, pixels: Double) -> win32more.Microsoft.UI.Xaml.GridLength: ...
    @winrt_commethod(8)
    def FromValueAndType(self, value: Double, type: win32more.Microsoft.UI.Xaml.GridUnitType) -> win32more.Microsoft.UI.Xaml.GridLength: ...
    @winrt_commethod(9)
    def GetIsAbsolute(self, target: win32more.Microsoft.UI.Xaml.GridLength) -> Boolean: ...
    @winrt_commethod(10)
    def GetIsAuto(self, target: win32more.Microsoft.UI.Xaml.GridLength) -> Boolean: ...
    @winrt_commethod(11)
    def GetIsStar(self, target: win32more.Microsoft.UI.Xaml.GridLength) -> Boolean: ...
    @winrt_commethod(12)
    def Equals(self, target: win32more.Microsoft.UI.Xaml.GridLength, value: win32more.Microsoft.UI.Xaml.GridLength) -> Boolean: ...
    Auto = property(get_Auto, None)
class ILaunchActivatedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ILaunchActivatedEventArgs'
    _iid_ = Guid('{d505cea9-1bcb-5b29-a8be-944e00f06f78}')
    @winrt_commethod(6)
    def get_Arguments(self) -> hstr: ...
    @winrt_commethod(7)
    def get_UWPLaunchActivatedEventArgs(self) -> win32more.Windows.ApplicationModel.Activation.LaunchActivatedEventArgs: ...
    Arguments = property(get_Arguments, None)
    UWPLaunchActivatedEventArgs = property(get_UWPLaunchActivatedEventArgs, None)
class IMediaFailedRoutedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IMediaFailedRoutedEventArgs'
    _iid_ = Guid('{a1dce737-539b-5e54-99af-75ece428bf9b}')
    @winrt_commethod(6)
    def get_ErrorTrace(self) -> hstr: ...
    ErrorTrace = property(get_ErrorTrace, None)
class IPointHelper(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IPointHelper'
    _iid_ = Guid('{06fcc7a4-6099-5f2e-83a5-f3be0e2c90aa}')
class IPointHelperStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IPointHelperStatics'
    _iid_ = Guid('{b0b2bd44-600b-51b3-a42c-3fd36c1ab042}')
    @winrt_commethod(6)
    def FromCoordinates(self, x: Single, y: Single) -> win32more.Windows.Foundation.Point: ...
class IPropertyMetadata(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IPropertyMetadata'
    _iid_ = Guid('{b3644425-9464-5434-b0ae-aff8d3159fe1}')
    @winrt_commethod(6)
    def get_DefaultValue(self) -> IInspectable: ...
    @winrt_commethod(7)
    def get_CreateDefaultValueCallback(self) -> win32more.Microsoft.UI.Xaml.CreateDefaultValueCallback: ...
    CreateDefaultValueCallback = property(get_CreateDefaultValueCallback, None)
    DefaultValue = property(get_DefaultValue, None)
class IPropertyMetadataFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IPropertyMetadataFactory'
    _iid_ = Guid('{9f420906-111a-5465-91ee-bed14b3e7fec}')
    @winrt_commethod(6)
    def CreateInstanceWithDefaultValue(self, defaultValue: IInspectable, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
    @winrt_commethod(7)
    def CreateInstanceWithDefaultValueAndCallback(self, defaultValue: IInspectable, propertyChangedCallback: win32more.Microsoft.UI.Xaml.PropertyChangedCallback, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
class IPropertyMetadataStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IPropertyMetadataStatics'
    _iid_ = Guid('{37b8add4-7a4a-5cf7-a174-235182cd082e}')
    @winrt_commethod(6)
    def CreateWithDefaultValue(self, defaultValue: IInspectable) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
    @winrt_commethod(7)
    def CreateWithDefaultValueAndCallback(self, defaultValue: IInspectable, propertyChangedCallback: win32more.Microsoft.UI.Xaml.PropertyChangedCallback) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
    @winrt_commethod(8)
    def CreateWithFactory(self, createDefaultValueCallback: win32more.Microsoft.UI.Xaml.CreateDefaultValueCallback) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
    @winrt_commethod(9)
    def CreateWithFactoryAndCallback(self, createDefaultValueCallback: win32more.Microsoft.UI.Xaml.CreateDefaultValueCallback, propertyChangedCallback: win32more.Microsoft.UI.Xaml.PropertyChangedCallback) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
class IPropertyPath(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IPropertyPath'
    _iid_ = Guid('{8b0712f6-9e57-53b0-80b1-966a79f60b96}')
    @winrt_commethod(6)
    def get_Path(self) -> hstr: ...
    Path = property(get_Path, None)
class IPropertyPathFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IPropertyPathFactory'
    _iid_ = Guid('{08a8ccab-7ff8-5cec-bd3c-72c98804d989}')
    @winrt_commethod(6)
    def CreateInstance(self, path: hstr) -> win32more.Microsoft.UI.Xaml.PropertyPath: ...
class IRectHelper(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IRectHelper'
    _iid_ = Guid('{5fece92a-a3d2-5bc0-aca1-e9e1fa86ae9d}')
class IRectHelperStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IRectHelperStatics'
    _iid_ = Guid('{a9cf37ad-5430-5086-a39f-74f0d1ed1072}')
    @winrt_commethod(6)
    def get_Empty(self) -> win32more.Windows.Foundation.Rect: ...
    @winrt_commethod(7)
    def FromCoordinatesAndDimensions(self, x: Single, y: Single, width: Single, height: Single) -> win32more.Windows.Foundation.Rect: ...
    @winrt_commethod(8)
    def FromPoints(self, point1: win32more.Windows.Foundation.Point, point2: win32more.Windows.Foundation.Point) -> win32more.Windows.Foundation.Rect: ...
    @winrt_commethod(9)
    def FromLocationAndSize(self, location: win32more.Windows.Foundation.Point, size: win32more.Windows.Foundation.Size) -> win32more.Windows.Foundation.Rect: ...
    @winrt_commethod(10)
    def GetIsEmpty(self, target: win32more.Windows.Foundation.Rect) -> Boolean: ...
    @winrt_commethod(11)
    def GetBottom(self, target: win32more.Windows.Foundation.Rect) -> Single: ...
    @winrt_commethod(12)
    def GetLeft(self, target: win32more.Windows.Foundation.Rect) -> Single: ...
    @winrt_commethod(13)
    def GetRight(self, target: win32more.Windows.Foundation.Rect) -> Single: ...
    @winrt_commethod(14)
    def GetTop(self, target: win32more.Windows.Foundation.Rect) -> Single: ...
    @winrt_commethod(15)
    def Contains(self, target: win32more.Windows.Foundation.Rect, point: win32more.Windows.Foundation.Point) -> Boolean: ...
    @winrt_commethod(16)
    def Equals(self, target: win32more.Windows.Foundation.Rect, value: win32more.Windows.Foundation.Rect) -> Boolean: ...
    @winrt_commethod(17)
    def Intersect(self, target: win32more.Windows.Foundation.Rect, rect: win32more.Windows.Foundation.Rect) -> win32more.Windows.Foundation.Rect: ...
    @winrt_commethod(18)
    def UnionWithPoint(self, target: win32more.Windows.Foundation.Rect, point: win32more.Windows.Foundation.Point) -> win32more.Windows.Foundation.Rect: ...
    @winrt_commethod(19)
    def UnionWithRect(self, target: win32more.Windows.Foundation.Rect, rect: win32more.Windows.Foundation.Rect) -> win32more.Windows.Foundation.Rect: ...
    Empty = property(get_Empty, None)
class IResourceDictionary(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IResourceDictionary'
    _iid_ = Guid('{1b690975-a710-5783-a6e1-15836f6186c2}')
    @winrt_commethod(6)
    def get_Source(self) -> win32more.Windows.Foundation.Uri: ...
    @winrt_commethod(7)
    def put_Source(self, value: win32more.Windows.Foundation.Uri) -> Void: ...
    @winrt_commethod(8)
    def get_MergedDictionaries(self) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.ResourceDictionary]: ...
    @winrt_commethod(9)
    def get_ThemeDictionaries(self) -> win32more.Windows.Foundation.Collections.IMap[IInspectable, IInspectable]: ...
    MergedDictionaries = property(get_MergedDictionaries, None)
    Source = property(get_Source, put_Source)
    ThemeDictionaries = property(get_ThemeDictionaries, None)
class IResourceDictionaryFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IResourceDictionaryFactory'
    _iid_ = Guid('{ea22a48f-ab71-56f6-a392-d82310c8aa7b}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.ResourceDictionary: ...
class IResourceManagerRequestedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IResourceManagerRequestedEventArgs'
    _iid_ = Guid('{c35f4cf1-fcd6-5c6b-9be2-4cfaefb68b2a}')
    @winrt_commethod(6)
    def get_CustomResourceManager(self) -> win32more.Microsoft.Windows.ApplicationModel.Resources.IResourceManager: ...
    @winrt_commethod(7)
    def put_CustomResourceManager(self, value: win32more.Microsoft.Windows.ApplicationModel.Resources.IResourceManager) -> Void: ...
    CustomResourceManager = property(get_CustomResourceManager, put_CustomResourceManager)
class IRoutedEvent(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IRoutedEvent'
    _iid_ = Guid('{b2b432bc-efca-575e-9d2a-703f8b9c380f}')
class IRoutedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IRoutedEventArgs'
    _iid_ = Guid('{0908c407-1c7d-5de3-9c50-d971c62ec8ec}')
    @winrt_commethod(6)
    def get_OriginalSource(self) -> IInspectable: ...
    OriginalSource = property(get_OriginalSource, None)
class IRoutedEventArgsFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IRoutedEventArgsFactory'
    _iid_ = Guid('{914b02c7-076b-5b89-98e7-6c373379e9af}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.RoutedEventArgs: ...
class IScalarTransition(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IScalarTransition'
    _iid_ = Guid('{c2da2ac8-814c-5889-b2f4-4ebe4b001ee3}')
    @winrt_commethod(6)
    def get_Duration(self) -> win32more.Windows.Foundation.TimeSpan: ...
    @winrt_commethod(7)
    def put_Duration(self, value: win32more.Windows.Foundation.TimeSpan) -> Void: ...
    Duration = property(get_Duration, put_Duration)
class IScalarTransitionFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IScalarTransitionFactory'
    _iid_ = Guid('{a1650cf8-a15b-54fc-b595-c52491318f58}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.ScalarTransition: ...
class ISetter(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ISetter'
    _iid_ = Guid('{bbd6074d-686f-5ae1-b8de-5f16aa30b80a}')
    @winrt_commethod(6)
    def get_Property(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(7)
    def put_Property(self, value: win32more.Microsoft.UI.Xaml.DependencyProperty) -> Void: ...
    @winrt_commethod(8)
    def get_Value(self) -> IInspectable: ...
    @winrt_commethod(9)
    def put_Value(self, value: IInspectable) -> Void: ...
    @winrt_commethod(10)
    def get_Target(self) -> win32more.Microsoft.UI.Xaml.TargetPropertyPath: ...
    @winrt_commethod(11)
    def put_Target(self, value: win32more.Microsoft.UI.Xaml.TargetPropertyPath) -> Void: ...
    Property = property(get_Property, put_Property)
    Target = property(get_Target, put_Target)
    Value = property(get_Value, put_Value)
class ISetterBase(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ISetterBase'
    _iid_ = Guid('{5a7c1347-cda3-55be-bfef-5c7582213980}')
    @winrt_commethod(6)
    def get_IsSealed(self) -> Boolean: ...
    IsSealed = property(get_IsSealed, None)
class ISetterBaseCollection(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ISetterBaseCollection'
    _iid_ = Guid('{63bf7c0f-b290-5c0c-9185-3338cd350d7f}')
    @winrt_commethod(6)
    def get_IsSealed(self) -> Boolean: ...
    IsSealed = property(get_IsSealed, None)
class ISetterBaseFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ISetterBaseFactory'
    _iid_ = Guid('{780a1d2f-c4be-5707-8a8a-4550dc22583e}')
class ISetterFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ISetterFactory'
    _iid_ = Guid('{13910a06-a327-5407-ae91-b9d2cc3a7ab5}')
    @winrt_commethod(6)
    def CreateInstance(self, targetProperty: win32more.Microsoft.UI.Xaml.DependencyProperty, value: IInspectable) -> win32more.Microsoft.UI.Xaml.Setter: ...
class ISizeChangedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ISizeChangedEventArgs'
    _iid_ = Guid('{fe76324e-6dfb-58b1-9dcd-886ca8f9a2ea}')
    @winrt_commethod(6)
    def get_PreviousSize(self) -> win32more.Windows.Foundation.Size: ...
    @winrt_commethod(7)
    def get_NewSize(self) -> win32more.Windows.Foundation.Size: ...
    NewSize = property(get_NewSize, None)
    PreviousSize = property(get_PreviousSize, None)
class ISizeHelper(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ISizeHelper'
    _iid_ = Guid('{5df9eee1-a2a8-5e55-8668-afedc0b36deb}')
class ISizeHelperStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ISizeHelperStatics'
    _iid_ = Guid('{cff1b27f-84f1-5b14-9459-764af5714fe5}')
    @winrt_commethod(6)
    def get_Empty(self) -> win32more.Windows.Foundation.Size: ...
    @winrt_commethod(7)
    def FromDimensions(self, width: Single, height: Single) -> win32more.Windows.Foundation.Size: ...
    @winrt_commethod(8)
    def GetIsEmpty(self, target: win32more.Windows.Foundation.Size) -> Boolean: ...
    @winrt_commethod(9)
    def Equals(self, target: win32more.Windows.Foundation.Size, value: win32more.Windows.Foundation.Size) -> Boolean: ...
    Empty = property(get_Empty, None)
class IStateTrigger(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IStateTrigger'
    _iid_ = Guid('{7b098126-1dab-5b58-aca7-f2b7de2e1033}')
    @winrt_commethod(6)
    def get_IsActive(self) -> Boolean: ...
    @winrt_commethod(7)
    def put_IsActive(self, value: Boolean) -> Void: ...
    IsActive = property(get_IsActive, put_IsActive)
class IStateTriggerBase(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IStateTriggerBase'
    _iid_ = Guid('{f07b0f7b-5b94-58ae-8717-22ab093bc131}')
class IStateTriggerBaseFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IStateTriggerBaseFactory'
    _iid_ = Guid('{e7724d65-fc7e-5c67-bb84-b4c7b020adc3}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.StateTriggerBase: ...
class IStateTriggerBaseProtected(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IStateTriggerBaseProtected'
    _iid_ = Guid('{2f695047-335b-5c00-a0d4-2a8fa54544c6}')
    @winrt_commethod(6)
    def SetActive(self, IsActive: Boolean) -> Void: ...
class IStateTriggerStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IStateTriggerStatics'
    _iid_ = Guid('{bd60c019-833b-5432-a41d-89d72410eb47}')
    @winrt_commethod(6)
    def get_IsActiveProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    IsActiveProperty = property(get_IsActiveProperty, None)
class IStyle(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IStyle'
    _iid_ = Guid('{65e1d164-572f-5b0e-a80f-9c02441fac49}')
    @winrt_commethod(6)
    def get_IsSealed(self) -> Boolean: ...
    @winrt_commethod(7)
    def get_Setters(self) -> win32more.Microsoft.UI.Xaml.SetterBaseCollection: ...
    @winrt_commethod(8)
    def get_TargetType(self) -> win32more.Windows.UI.Xaml.Interop.TypeName: ...
    @winrt_commethod(9)
    def put_TargetType(self, value: win32more.Windows.UI.Xaml.Interop.TypeName) -> Void: ...
    @winrt_commethod(10)
    def get_BasedOn(self) -> win32more.Microsoft.UI.Xaml.Style: ...
    @winrt_commethod(11)
    def put_BasedOn(self, value: win32more.Microsoft.UI.Xaml.Style) -> Void: ...
    @winrt_commethod(12)
    def Seal(self) -> Void: ...
    BasedOn = property(get_BasedOn, put_BasedOn)
    IsSealed = property(get_IsSealed, None)
    Setters = property(get_Setters, None)
    TargetType = property(get_TargetType, put_TargetType)
class IStyleFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IStyleFactory'
    _iid_ = Guid('{c2d924a2-3862-517c-b083-9a9120d7302d}')
    @winrt_commethod(6)
    def CreateInstance(self, targetType: win32more.Windows.UI.Xaml.Interop.TypeName) -> win32more.Microsoft.UI.Xaml.Style: ...
class ITargetPropertyPath(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ITargetPropertyPath'
    _iid_ = Guid('{b1442f0e-f66b-531c-979b-193fd344e2a8}')
    @winrt_commethod(6)
    def get_Path(self) -> win32more.Microsoft.UI.Xaml.PropertyPath: ...
    @winrt_commethod(7)
    def put_Path(self, value: win32more.Microsoft.UI.Xaml.PropertyPath) -> Void: ...
    @winrt_commethod(8)
    def get_Target(self) -> IInspectable: ...
    @winrt_commethod(9)
    def put_Target(self, value: IInspectable) -> Void: ...
    Path = property(get_Path, put_Path)
    Target = property(get_Target, put_Target)
class ITargetPropertyPathFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ITargetPropertyPathFactory'
    _iid_ = Guid('{894cb11d-5c16-555b-b661-f41b29fd9b21}')
    @winrt_commethod(6)
    def CreateInstance(self, targetProperty: win32more.Microsoft.UI.Xaml.DependencyProperty) -> win32more.Microsoft.UI.Xaml.TargetPropertyPath: ...
class IThicknessHelper(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IThicknessHelper'
    _iid_ = Guid('{5e496347-3c49-55ee-b442-530789b42b6f}')
class IThicknessHelperStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IThicknessHelperStatics'
    _iid_ = Guid('{0e3b81ce-d278-577f-98ea-1b6010f86d7f}')
    @winrt_commethod(6)
    def FromLengths(self, left: Double, top: Double, right: Double, bottom: Double) -> win32more.Microsoft.UI.Xaml.Thickness: ...
    @winrt_commethod(7)
    def FromUniformLength(self, uniformLength: Double) -> win32more.Microsoft.UI.Xaml.Thickness: ...
class ITriggerAction(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ITriggerAction'
    _iid_ = Guid('{1fa35464-a690-586c-aedf-6c88cac7d14a}')
class ITriggerActionFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ITriggerActionFactory'
    _iid_ = Guid('{1e1faf1a-f614-554a-822a-d98fe46575d1}')
class ITriggerBase(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ITriggerBase'
    _iid_ = Guid('{d37da89d-0d71-58cf-a901-99a7d3e5e434}')
class ITriggerBaseFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.ITriggerBaseFactory'
    _iid_ = Guid('{23088eaa-17ec-51b2-b181-5bedfa8b8fa4}')
class IUIElement(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IUIElement'
    _iid_ = Guid('{c3c01020-320c-5cf6-9d24-d396bbfa4d8b}')
    @winrt_commethod(6)
    def get_DesiredSize(self) -> win32more.Windows.Foundation.Size: ...
    @winrt_commethod(7)
    def get_AllowDrop(self) -> Boolean: ...
    @winrt_commethod(8)
    def put_AllowDrop(self, value: Boolean) -> Void: ...
    @winrt_commethod(9)
    def get_Opacity(self) -> Double: ...
    @winrt_commethod(10)
    def put_Opacity(self, value: Double) -> Void: ...
    @winrt_commethod(11)
    def get_Clip(self) -> win32more.Microsoft.UI.Xaml.Media.RectangleGeometry: ...
    @winrt_commethod(12)
    def put_Clip(self, value: win32more.Microsoft.UI.Xaml.Media.RectangleGeometry) -> Void: ...
    @winrt_commethod(13)
    def get_RenderTransform(self) -> win32more.Microsoft.UI.Xaml.Media.Transform: ...
    @winrt_commethod(14)
    def put_RenderTransform(self, value: win32more.Microsoft.UI.Xaml.Media.Transform) -> Void: ...
    @winrt_commethod(15)
    def get_Projection(self) -> win32more.Microsoft.UI.Xaml.Media.Projection: ...
    @winrt_commethod(16)
    def put_Projection(self, value: win32more.Microsoft.UI.Xaml.Media.Projection) -> Void: ...
    @winrt_commethod(17)
    def get_Transform3D(self) -> win32more.Microsoft.UI.Xaml.Media.Media3D.Transform3D: ...
    @winrt_commethod(18)
    def put_Transform3D(self, value: win32more.Microsoft.UI.Xaml.Media.Media3D.Transform3D) -> Void: ...
    @winrt_commethod(19)
    def get_RenderTransformOrigin(self) -> win32more.Windows.Foundation.Point: ...
    @winrt_commethod(20)
    def put_RenderTransformOrigin(self, value: win32more.Windows.Foundation.Point) -> Void: ...
    @winrt_commethod(21)
    def get_IsHitTestVisible(self) -> Boolean: ...
    @winrt_commethod(22)
    def put_IsHitTestVisible(self, value: Boolean) -> Void: ...
    @winrt_commethod(23)
    def get_Visibility(self) -> win32more.Microsoft.UI.Xaml.Visibility: ...
    @winrt_commethod(24)
    def put_Visibility(self, value: win32more.Microsoft.UI.Xaml.Visibility) -> Void: ...
    @winrt_commethod(25)
    def get_RenderSize(self) -> win32more.Windows.Foundation.Size: ...
    @winrt_commethod(26)
    def get_UseLayoutRounding(self) -> Boolean: ...
    @winrt_commethod(27)
    def put_UseLayoutRounding(self, value: Boolean) -> Void: ...
    @winrt_commethod(28)
    def get_Transitions(self) -> win32more.Microsoft.UI.Xaml.Media.Animation.TransitionCollection: ...
    @winrt_commethod(29)
    def put_Transitions(self, value: win32more.Microsoft.UI.Xaml.Media.Animation.TransitionCollection) -> Void: ...
    @winrt_commethod(30)
    def get_CacheMode(self) -> win32more.Microsoft.UI.Xaml.Media.CacheMode: ...
    @winrt_commethod(31)
    def put_CacheMode(self, value: win32more.Microsoft.UI.Xaml.Media.CacheMode) -> Void: ...
    @winrt_commethod(32)
    def get_IsTapEnabled(self) -> Boolean: ...
    @winrt_commethod(33)
    def put_IsTapEnabled(self, value: Boolean) -> Void: ...
    @winrt_commethod(34)
    def get_IsDoubleTapEnabled(self) -> Boolean: ...
    @winrt_commethod(35)
    def put_IsDoubleTapEnabled(self, value: Boolean) -> Void: ...
    @winrt_commethod(36)
    def get_CanDrag(self) -> Boolean: ...
    @winrt_commethod(37)
    def put_CanDrag(self, value: Boolean) -> Void: ...
    @winrt_commethod(38)
    def get_IsRightTapEnabled(self) -> Boolean: ...
    @winrt_commethod(39)
    def put_IsRightTapEnabled(self, value: Boolean) -> Void: ...
    @winrt_commethod(40)
    def get_IsHoldingEnabled(self) -> Boolean: ...
    @winrt_commethod(41)
    def put_IsHoldingEnabled(self, value: Boolean) -> Void: ...
    @winrt_commethod(42)
    def get_ManipulationMode(self) -> win32more.Microsoft.UI.Xaml.Input.ManipulationModes: ...
    @winrt_commethod(43)
    def put_ManipulationMode(self, value: win32more.Microsoft.UI.Xaml.Input.ManipulationModes) -> Void: ...
    @winrt_commethod(44)
    def get_PointerCaptures(self) -> win32more.Windows.Foundation.Collections.IVectorView[win32more.Microsoft.UI.Xaml.Input.Pointer]: ...
    @winrt_commethod(45)
    def get_ContextFlyout(self) -> win32more.Microsoft.UI.Xaml.Controls.Primitives.FlyoutBase: ...
    @winrt_commethod(46)
    def put_ContextFlyout(self, value: win32more.Microsoft.UI.Xaml.Controls.Primitives.FlyoutBase) -> Void: ...
    @winrt_commethod(47)
    def get_CompositeMode(self) -> win32more.Microsoft.UI.Xaml.Media.ElementCompositeMode: ...
    @winrt_commethod(48)
    def put_CompositeMode(self, value: win32more.Microsoft.UI.Xaml.Media.ElementCompositeMode) -> Void: ...
    @winrt_commethod(49)
    def get_Lights(self) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.Media.XamlLight]: ...
    @winrt_commethod(50)
    def get_CanBeScrollAnchor(self) -> Boolean: ...
    @winrt_commethod(51)
    def put_CanBeScrollAnchor(self, value: Boolean) -> Void: ...
    @winrt_commethod(52)
    def get_ExitDisplayModeOnAccessKeyInvoked(self) -> Boolean: ...
    @winrt_commethod(53)
    def put_ExitDisplayModeOnAccessKeyInvoked(self, value: Boolean) -> Void: ...
    @winrt_commethod(54)
    def get_IsAccessKeyScope(self) -> Boolean: ...
    @winrt_commethod(55)
    def put_IsAccessKeyScope(self, value: Boolean) -> Void: ...
    @winrt_commethod(56)
    def get_AccessKeyScopeOwner(self) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_commethod(57)
    def put_AccessKeyScopeOwner(self, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_commethod(58)
    def get_AccessKey(self) -> hstr: ...
    @winrt_commethod(59)
    def put_AccessKey(self, value: hstr) -> Void: ...
    @winrt_commethod(60)
    def get_KeyTipPlacementMode(self) -> win32more.Microsoft.UI.Xaml.Input.KeyTipPlacementMode: ...
    @winrt_commethod(61)
    def put_KeyTipPlacementMode(self, value: win32more.Microsoft.UI.Xaml.Input.KeyTipPlacementMode) -> Void: ...
    @winrt_commethod(62)
    def get_KeyTipHorizontalOffset(self) -> Double: ...
    @winrt_commethod(63)
    def put_KeyTipHorizontalOffset(self, value: Double) -> Void: ...
    @winrt_commethod(64)
    def get_KeyTipVerticalOffset(self) -> Double: ...
    @winrt_commethod(65)
    def put_KeyTipVerticalOffset(self, value: Double) -> Void: ...
    @winrt_commethod(66)
    def get_KeyTipTarget(self) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_commethod(67)
    def put_KeyTipTarget(self, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_commethod(68)
    def get_XYFocusKeyboardNavigation(self) -> win32more.Microsoft.UI.Xaml.Input.XYFocusKeyboardNavigationMode: ...
    @winrt_commethod(69)
    def put_XYFocusKeyboardNavigation(self, value: win32more.Microsoft.UI.Xaml.Input.XYFocusKeyboardNavigationMode) -> Void: ...
    @winrt_commethod(70)
    def get_XYFocusUpNavigationStrategy(self) -> win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy: ...
    @winrt_commethod(71)
    def put_XYFocusUpNavigationStrategy(self, value: win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy) -> Void: ...
    @winrt_commethod(72)
    def get_XYFocusDownNavigationStrategy(self) -> win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy: ...
    @winrt_commethod(73)
    def put_XYFocusDownNavigationStrategy(self, value: win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy) -> Void: ...
    @winrt_commethod(74)
    def get_XYFocusLeftNavigationStrategy(self) -> win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy: ...
    @winrt_commethod(75)
    def put_XYFocusLeftNavigationStrategy(self, value: win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy) -> Void: ...
    @winrt_commethod(76)
    def get_XYFocusRightNavigationStrategy(self) -> win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy: ...
    @winrt_commethod(77)
    def put_XYFocusRightNavigationStrategy(self, value: win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy) -> Void: ...
    @winrt_commethod(78)
    def get_KeyboardAccelerators(self) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.Input.KeyboardAccelerator]: ...
    @winrt_commethod(79)
    def get_KeyboardAcceleratorPlacementTarget(self) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_commethod(80)
    def put_KeyboardAcceleratorPlacementTarget(self, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_commethod(81)
    def get_KeyboardAcceleratorPlacementMode(self) -> win32more.Microsoft.UI.Xaml.Input.KeyboardAcceleratorPlacementMode: ...
    @winrt_commethod(82)
    def put_KeyboardAcceleratorPlacementMode(self, value: win32more.Microsoft.UI.Xaml.Input.KeyboardAcceleratorPlacementMode) -> Void: ...
    @winrt_commethod(83)
    def get_HighContrastAdjustment(self) -> win32more.Microsoft.UI.Xaml.ElementHighContrastAdjustment: ...
    @winrt_commethod(84)
    def put_HighContrastAdjustment(self, value: win32more.Microsoft.UI.Xaml.ElementHighContrastAdjustment) -> Void: ...
    @winrt_commethod(85)
    def get_TabFocusNavigation(self) -> win32more.Microsoft.UI.Xaml.Input.KeyboardNavigationMode: ...
    @winrt_commethod(86)
    def put_TabFocusNavigation(self, value: win32more.Microsoft.UI.Xaml.Input.KeyboardNavigationMode) -> Void: ...
    @winrt_commethod(87)
    def get_OpacityTransition(self) -> win32more.Microsoft.UI.Xaml.ScalarTransition: ...
    @winrt_commethod(88)
    def put_OpacityTransition(self, value: win32more.Microsoft.UI.Xaml.ScalarTransition) -> Void: ...
    @winrt_commethod(89)
    def get_Translation(self) -> win32more.Windows.Foundation.Numerics.Vector3: ...
    @winrt_commethod(90)
    def put_Translation(self, value: win32more.Windows.Foundation.Numerics.Vector3) -> Void: ...
    @winrt_commethod(91)
    def get_TranslationTransition(self) -> win32more.Microsoft.UI.Xaml.Vector3Transition: ...
    @winrt_commethod(92)
    def put_TranslationTransition(self, value: win32more.Microsoft.UI.Xaml.Vector3Transition) -> Void: ...
    @winrt_commethod(93)
    def get_Rotation(self) -> Single: ...
    @winrt_commethod(94)
    def put_Rotation(self, value: Single) -> Void: ...
    @winrt_commethod(95)
    def get_RotationTransition(self) -> win32more.Microsoft.UI.Xaml.ScalarTransition: ...
    @winrt_commethod(96)
    def put_RotationTransition(self, value: win32more.Microsoft.UI.Xaml.ScalarTransition) -> Void: ...
    @winrt_commethod(97)
    def get_Scale(self) -> win32more.Windows.Foundation.Numerics.Vector3: ...
    @winrt_commethod(98)
    def put_Scale(self, value: win32more.Windows.Foundation.Numerics.Vector3) -> Void: ...
    @winrt_commethod(99)
    def get_ScaleTransition(self) -> win32more.Microsoft.UI.Xaml.Vector3Transition: ...
    @winrt_commethod(100)
    def put_ScaleTransition(self, value: win32more.Microsoft.UI.Xaml.Vector3Transition) -> Void: ...
    @winrt_commethod(101)
    def get_TransformMatrix(self) -> win32more.Windows.Foundation.Numerics.Matrix4x4: ...
    @winrt_commethod(102)
    def put_TransformMatrix(self, value: win32more.Windows.Foundation.Numerics.Matrix4x4) -> Void: ...
    @winrt_commethod(103)
    def get_CenterPoint(self) -> win32more.Windows.Foundation.Numerics.Vector3: ...
    @winrt_commethod(104)
    def put_CenterPoint(self, value: win32more.Windows.Foundation.Numerics.Vector3) -> Void: ...
    @winrt_commethod(105)
    def get_RotationAxis(self) -> win32more.Windows.Foundation.Numerics.Vector3: ...
    @winrt_commethod(106)
    def put_RotationAxis(self, value: win32more.Windows.Foundation.Numerics.Vector3) -> Void: ...
    @winrt_commethod(107)
    def get_ActualOffset(self) -> win32more.Windows.Foundation.Numerics.Vector3: ...
    @winrt_commethod(108)
    def get_ActualSize(self) -> win32more.Windows.Foundation.Numerics.Vector2: ...
    @winrt_commethod(109)
    def get_XamlRoot(self) -> win32more.Microsoft.UI.Xaml.XamlRoot: ...
    @winrt_commethod(110)
    def put_XamlRoot(self, value: win32more.Microsoft.UI.Xaml.XamlRoot) -> Void: ...
    @winrt_commethod(111)
    def get_Shadow(self) -> win32more.Microsoft.UI.Xaml.Media.Shadow: ...
    @winrt_commethod(112)
    def put_Shadow(self, value: win32more.Microsoft.UI.Xaml.Media.Shadow) -> Void: ...
    @winrt_commethod(113)
    def get_RasterizationScale(self) -> Double: ...
    @winrt_commethod(114)
    def put_RasterizationScale(self, value: Double) -> Void: ...
    @winrt_commethod(115)
    def get_FocusState(self) -> win32more.Microsoft.UI.Xaml.FocusState: ...
    @winrt_commethod(116)
    def get_UseSystemFocusVisuals(self) -> Boolean: ...
    @winrt_commethod(117)
    def put_UseSystemFocusVisuals(self, value: Boolean) -> Void: ...
    @winrt_commethod(118)
    def get_XYFocusLeft(self) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_commethod(119)
    def put_XYFocusLeft(self, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_commethod(120)
    def get_XYFocusRight(self) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_commethod(121)
    def put_XYFocusRight(self, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_commethod(122)
    def get_XYFocusUp(self) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_commethod(123)
    def put_XYFocusUp(self, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_commethod(124)
    def get_XYFocusDown(self) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_commethod(125)
    def put_XYFocusDown(self, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_commethod(126)
    def get_IsTabStop(self) -> Boolean: ...
    @winrt_commethod(127)
    def put_IsTabStop(self, value: Boolean) -> Void: ...
    @winrt_commethod(128)
    def get_TabIndex(self) -> Int32: ...
    @winrt_commethod(129)
    def put_TabIndex(self, value: Int32) -> Void: ...
    @winrt_commethod(130)
    def add_KeyUp(self, handler: win32more.Microsoft.UI.Xaml.Input.KeyEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(131)
    def remove_KeyUp(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(132)
    def add_KeyDown(self, handler: win32more.Microsoft.UI.Xaml.Input.KeyEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(133)
    def remove_KeyDown(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(134)
    def add_GotFocus(self, handler: win32more.Microsoft.UI.Xaml.RoutedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(135)
    def remove_GotFocus(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(136)
    def add_LostFocus(self, handler: win32more.Microsoft.UI.Xaml.RoutedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(137)
    def remove_LostFocus(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(138)
    def add_DragStarting(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.DragStartingEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(139)
    def remove_DragStarting(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(140)
    def add_DropCompleted(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.DropCompletedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(141)
    def remove_DropCompleted(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(142)
    def add_CharacterReceived(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.CharacterReceivedRoutedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(143)
    def remove_CharacterReceived(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(144)
    def add_DragEnter(self, handler: win32more.Microsoft.UI.Xaml.DragEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(145)
    def remove_DragEnter(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(146)
    def add_DragLeave(self, handler: win32more.Microsoft.UI.Xaml.DragEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(147)
    def remove_DragLeave(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(148)
    def add_DragOver(self, handler: win32more.Microsoft.UI.Xaml.DragEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(149)
    def remove_DragOver(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(150)
    def add_Drop(self, handler: win32more.Microsoft.UI.Xaml.DragEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(151)
    def remove_Drop(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(152)
    def add_PointerPressed(self, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(153)
    def remove_PointerPressed(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(154)
    def add_PointerMoved(self, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(155)
    def remove_PointerMoved(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(156)
    def add_PointerReleased(self, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(157)
    def remove_PointerReleased(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(158)
    def add_PointerEntered(self, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(159)
    def remove_PointerEntered(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(160)
    def add_PointerExited(self, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(161)
    def remove_PointerExited(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(162)
    def add_PointerCaptureLost(self, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(163)
    def remove_PointerCaptureLost(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(164)
    def add_PointerCanceled(self, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(165)
    def remove_PointerCanceled(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(166)
    def add_PointerWheelChanged(self, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(167)
    def remove_PointerWheelChanged(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(168)
    def add_Tapped(self, handler: win32more.Microsoft.UI.Xaml.Input.TappedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(169)
    def remove_Tapped(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(170)
    def add_DoubleTapped(self, handler: win32more.Microsoft.UI.Xaml.Input.DoubleTappedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(171)
    def remove_DoubleTapped(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(172)
    def add_Holding(self, handler: win32more.Microsoft.UI.Xaml.Input.HoldingEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(173)
    def remove_Holding(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(174)
    def add_ContextRequested(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.ContextRequestedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(175)
    def remove_ContextRequested(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(176)
    def add_ContextCanceled(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.RoutedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(177)
    def remove_ContextCanceled(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(178)
    def add_RightTapped(self, handler: win32more.Microsoft.UI.Xaml.Input.RightTappedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(179)
    def remove_RightTapped(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(180)
    def add_ManipulationStarting(self, handler: win32more.Microsoft.UI.Xaml.Input.ManipulationStartingEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(181)
    def remove_ManipulationStarting(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(182)
    def add_ManipulationInertiaStarting(self, handler: win32more.Microsoft.UI.Xaml.Input.ManipulationInertiaStartingEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(183)
    def remove_ManipulationInertiaStarting(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(184)
    def add_ManipulationStarted(self, handler: win32more.Microsoft.UI.Xaml.Input.ManipulationStartedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(185)
    def remove_ManipulationStarted(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(186)
    def add_ManipulationDelta(self, handler: win32more.Microsoft.UI.Xaml.Input.ManipulationDeltaEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(187)
    def remove_ManipulationDelta(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(188)
    def add_ManipulationCompleted(self, handler: win32more.Microsoft.UI.Xaml.Input.ManipulationCompletedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(189)
    def remove_ManipulationCompleted(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(190)
    def add_AccessKeyDisplayRequested(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.AccessKeyDisplayRequestedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(191)
    def remove_AccessKeyDisplayRequested(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(192)
    def add_AccessKeyDisplayDismissed(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.AccessKeyDisplayDismissedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(193)
    def remove_AccessKeyDisplayDismissed(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(194)
    def add_AccessKeyInvoked(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.AccessKeyInvokedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(195)
    def remove_AccessKeyInvoked(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(196)
    def add_ProcessKeyboardAccelerators(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.ProcessKeyboardAcceleratorEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(197)
    def remove_ProcessKeyboardAccelerators(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(198)
    def add_GettingFocus(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.GettingFocusEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(199)
    def remove_GettingFocus(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(200)
    def add_LosingFocus(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.LosingFocusEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(201)
    def remove_LosingFocus(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(202)
    def add_NoFocusCandidateFound(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.NoFocusCandidateFoundEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(203)
    def remove_NoFocusCandidateFound(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(204)
    def add_PreviewKeyDown(self, handler: win32more.Microsoft.UI.Xaml.Input.KeyEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(205)
    def remove_PreviewKeyDown(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(206)
    def add_PreviewKeyUp(self, handler: win32more.Microsoft.UI.Xaml.Input.KeyEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(207)
    def remove_PreviewKeyUp(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(208)
    def add_BringIntoViewRequested(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.BringIntoViewRequestedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(209)
    def remove_BringIntoViewRequested(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(210)
    def Measure(self, availableSize: win32more.Windows.Foundation.Size) -> Void: ...
    @winrt_commethod(211)
    def Arrange(self, finalRect: win32more.Windows.Foundation.Rect) -> Void: ...
    @winrt_commethod(212)
    def CapturePointer(self, value: win32more.Microsoft.UI.Xaml.Input.Pointer) -> Boolean: ...
    @winrt_commethod(213)
    def ReleasePointerCapture(self, value: win32more.Microsoft.UI.Xaml.Input.Pointer) -> Void: ...
    @winrt_commethod(214)
    def ReleasePointerCaptures(self) -> Void: ...
    @winrt_commethod(215)
    def AddHandler(self, routedEvent: win32more.Microsoft.UI.Xaml.RoutedEvent, handler: IInspectable, handledEventsToo: Boolean) -> Void: ...
    @winrt_commethod(216)
    def RemoveHandler(self, routedEvent: win32more.Microsoft.UI.Xaml.RoutedEvent, handler: IInspectable) -> Void: ...
    @winrt_commethod(217)
    def TransformToVisual(self, visual: win32more.Microsoft.UI.Xaml.UIElement) -> win32more.Microsoft.UI.Xaml.Media.GeneralTransform: ...
    @winrt_commethod(218)
    def InvalidateMeasure(self) -> Void: ...
    @winrt_commethod(219)
    def InvalidateArrange(self) -> Void: ...
    @winrt_commethod(220)
    def UpdateLayout(self) -> Void: ...
    @winrt_commethod(221)
    def CancelDirectManipulations(self) -> Boolean: ...
    @winrt_commethod(222)
    def StartDragAsync(self, pointerPoint: win32more.Microsoft.UI.Input.PointerPoint) -> win32more.Windows.Foundation.IAsyncOperation[win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation]: ...
    @winrt_commethod(223)
    def StartBringIntoView(self) -> Void: ...
    @winrt_commethod(224)
    def StartBringIntoViewWithOptions(self, options: win32more.Microsoft.UI.Xaml.BringIntoViewOptions) -> Void: ...
    @winrt_commethod(225)
    def TryInvokeKeyboardAccelerator(self, args: win32more.Microsoft.UI.Xaml.Input.ProcessKeyboardAcceleratorEventArgs) -> Void: ...
    @winrt_commethod(226)
    def Focus(self, value: win32more.Microsoft.UI.Xaml.FocusState) -> Boolean: ...
    @winrt_commethod(227)
    def StartAnimation(self, animation: win32more.Microsoft.UI.Composition.ICompositionAnimationBase) -> Void: ...
    @winrt_commethod(228)
    def StopAnimation(self, animation: win32more.Microsoft.UI.Composition.ICompositionAnimationBase) -> Void: ...
    AccessKey = property(get_AccessKey, put_AccessKey)
    AccessKeyScopeOwner = property(get_AccessKeyScopeOwner, put_AccessKeyScopeOwner)
    ActualOffset = property(get_ActualOffset, None)
    ActualSize = property(get_ActualSize, None)
    AllowDrop = property(get_AllowDrop, put_AllowDrop)
    CacheMode = property(get_CacheMode, put_CacheMode)
    CanBeScrollAnchor = property(get_CanBeScrollAnchor, put_CanBeScrollAnchor)
    CanDrag = property(get_CanDrag, put_CanDrag)
    CenterPoint = property(get_CenterPoint, put_CenterPoint)
    Clip = property(get_Clip, put_Clip)
    CompositeMode = property(get_CompositeMode, put_CompositeMode)
    ContextFlyout = property(get_ContextFlyout, put_ContextFlyout)
    DesiredSize = property(get_DesiredSize, None)
    ExitDisplayModeOnAccessKeyInvoked = property(get_ExitDisplayModeOnAccessKeyInvoked, put_ExitDisplayModeOnAccessKeyInvoked)
    FocusState = property(get_FocusState, None)
    HighContrastAdjustment = property(get_HighContrastAdjustment, put_HighContrastAdjustment)
    IsAccessKeyScope = property(get_IsAccessKeyScope, put_IsAccessKeyScope)
    IsDoubleTapEnabled = property(get_IsDoubleTapEnabled, put_IsDoubleTapEnabled)
    IsHitTestVisible = property(get_IsHitTestVisible, put_IsHitTestVisible)
    IsHoldingEnabled = property(get_IsHoldingEnabled, put_IsHoldingEnabled)
    IsRightTapEnabled = property(get_IsRightTapEnabled, put_IsRightTapEnabled)
    IsTabStop = property(get_IsTabStop, put_IsTabStop)
    IsTapEnabled = property(get_IsTapEnabled, put_IsTapEnabled)
    KeyTipHorizontalOffset = property(get_KeyTipHorizontalOffset, put_KeyTipHorizontalOffset)
    KeyTipPlacementMode = property(get_KeyTipPlacementMode, put_KeyTipPlacementMode)
    KeyTipTarget = property(get_KeyTipTarget, put_KeyTipTarget)
    KeyTipVerticalOffset = property(get_KeyTipVerticalOffset, put_KeyTipVerticalOffset)
    KeyboardAcceleratorPlacementMode = property(get_KeyboardAcceleratorPlacementMode, put_KeyboardAcceleratorPlacementMode)
    KeyboardAcceleratorPlacementTarget = property(get_KeyboardAcceleratorPlacementTarget, put_KeyboardAcceleratorPlacementTarget)
    KeyboardAccelerators = property(get_KeyboardAccelerators, None)
    Lights = property(get_Lights, None)
    ManipulationMode = property(get_ManipulationMode, put_ManipulationMode)
    Opacity = property(get_Opacity, put_Opacity)
    OpacityTransition = property(get_OpacityTransition, put_OpacityTransition)
    PointerCaptures = property(get_PointerCaptures, None)
    Projection = property(get_Projection, put_Projection)
    RasterizationScale = property(get_RasterizationScale, put_RasterizationScale)
    RenderSize = property(get_RenderSize, None)
    RenderTransform = property(get_RenderTransform, put_RenderTransform)
    RenderTransformOrigin = property(get_RenderTransformOrigin, put_RenderTransformOrigin)
    Rotation = property(get_Rotation, put_Rotation)
    RotationAxis = property(get_RotationAxis, put_RotationAxis)
    RotationTransition = property(get_RotationTransition, put_RotationTransition)
    Scale = property(get_Scale, put_Scale)
    ScaleTransition = property(get_ScaleTransition, put_ScaleTransition)
    Shadow = property(get_Shadow, put_Shadow)
    TabFocusNavigation = property(get_TabFocusNavigation, put_TabFocusNavigation)
    TabIndex = property(get_TabIndex, put_TabIndex)
    Transform3D = property(get_Transform3D, put_Transform3D)
    TransformMatrix = property(get_TransformMatrix, put_TransformMatrix)
    Transitions = property(get_Transitions, put_Transitions)
    Translation = property(get_Translation, put_Translation)
    TranslationTransition = property(get_TranslationTransition, put_TranslationTransition)
    UseLayoutRounding = property(get_UseLayoutRounding, put_UseLayoutRounding)
    UseSystemFocusVisuals = property(get_UseSystemFocusVisuals, put_UseSystemFocusVisuals)
    Visibility = property(get_Visibility, put_Visibility)
    XYFocusDown = property(get_XYFocusDown, put_XYFocusDown)
    XYFocusDownNavigationStrategy = property(get_XYFocusDownNavigationStrategy, put_XYFocusDownNavigationStrategy)
    XYFocusKeyboardNavigation = property(get_XYFocusKeyboardNavigation, put_XYFocusKeyboardNavigation)
    XYFocusLeft = property(get_XYFocusLeft, put_XYFocusLeft)
    XYFocusLeftNavigationStrategy = property(get_XYFocusLeftNavigationStrategy, put_XYFocusLeftNavigationStrategy)
    XYFocusRight = property(get_XYFocusRight, put_XYFocusRight)
    XYFocusRightNavigationStrategy = property(get_XYFocusRightNavigationStrategy, put_XYFocusRightNavigationStrategy)
    XYFocusUp = property(get_XYFocusUp, put_XYFocusUp)
    XYFocusUpNavigationStrategy = property(get_XYFocusUpNavigationStrategy, put_XYFocusUpNavigationStrategy)
    XamlRoot = property(get_XamlRoot, put_XamlRoot)
    AccessKeyDisplayDismissed = event(add_AccessKeyDisplayDismissed, remove_AccessKeyDisplayDismissed)
    AccessKeyDisplayRequested = event(add_AccessKeyDisplayRequested, remove_AccessKeyDisplayRequested)
    AccessKeyInvoked = event(add_AccessKeyInvoked, remove_AccessKeyInvoked)
    BringIntoViewRequested = event(add_BringIntoViewRequested, remove_BringIntoViewRequested)
    CharacterReceived = event(add_CharacterReceived, remove_CharacterReceived)
    ContextCanceled = event(add_ContextCanceled, remove_ContextCanceled)
    ContextRequested = event(add_ContextRequested, remove_ContextRequested)
    DoubleTapped = event(add_DoubleTapped, remove_DoubleTapped)
    DragEnter = event(add_DragEnter, remove_DragEnter)
    DragLeave = event(add_DragLeave, remove_DragLeave)
    DragOver = event(add_DragOver, remove_DragOver)
    DragStarting = event(add_DragStarting, remove_DragStarting)
    Drop = event(add_Drop, remove_Drop)
    DropCompleted = event(add_DropCompleted, remove_DropCompleted)
    GettingFocus = event(add_GettingFocus, remove_GettingFocus)
    GotFocus = event(add_GotFocus, remove_GotFocus)
    Holding = event(add_Holding, remove_Holding)
    KeyDown = event(add_KeyDown, remove_KeyDown)
    KeyUp = event(add_KeyUp, remove_KeyUp)
    LosingFocus = event(add_LosingFocus, remove_LosingFocus)
    LostFocus = event(add_LostFocus, remove_LostFocus)
    ManipulationCompleted = event(add_ManipulationCompleted, remove_ManipulationCompleted)
    ManipulationDelta = event(add_ManipulationDelta, remove_ManipulationDelta)
    ManipulationInertiaStarting = event(add_ManipulationInertiaStarting, remove_ManipulationInertiaStarting)
    ManipulationStarted = event(add_ManipulationStarted, remove_ManipulationStarted)
    ManipulationStarting = event(add_ManipulationStarting, remove_ManipulationStarting)
    NoFocusCandidateFound = event(add_NoFocusCandidateFound, remove_NoFocusCandidateFound)
    PointerCanceled = event(add_PointerCanceled, remove_PointerCanceled)
    PointerCaptureLost = event(add_PointerCaptureLost, remove_PointerCaptureLost)
    PointerEntered = event(add_PointerEntered, remove_PointerEntered)
    PointerExited = event(add_PointerExited, remove_PointerExited)
    PointerMoved = event(add_PointerMoved, remove_PointerMoved)
    PointerPressed = event(add_PointerPressed, remove_PointerPressed)
    PointerReleased = event(add_PointerReleased, remove_PointerReleased)
    PointerWheelChanged = event(add_PointerWheelChanged, remove_PointerWheelChanged)
    PreviewKeyDown = event(add_PreviewKeyDown, remove_PreviewKeyDown)
    PreviewKeyUp = event(add_PreviewKeyUp, remove_PreviewKeyUp)
    ProcessKeyboardAccelerators = event(add_ProcessKeyboardAccelerators, remove_ProcessKeyboardAccelerators)
    RightTapped = event(add_RightTapped, remove_RightTapped)
    Tapped = event(add_Tapped, remove_Tapped)
class IUIElementFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IUIElementFactory'
    _iid_ = Guid('{14d1d309-add0-5ccb-b946-77488cd70f87}')
class IUIElementOverrides(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IUIElementOverrides'
    _iid_ = Guid('{9034f41e-ab7b-59e7-8168-50de6b689dde}')
    @winrt_commethod(6)
    def OnCreateAutomationPeer(self) -> win32more.Microsoft.UI.Xaml.Automation.Peers.AutomationPeer: ...
    @winrt_commethod(7)
    def OnDisconnectVisualChildren(self) -> Void: ...
    @winrt_commethod(8)
    def FindSubElementsForTouchTargeting(self, point: win32more.Windows.Foundation.Point, boundingRect: win32more.Windows.Foundation.Rect) -> win32more.Windows.Foundation.Collections.IIterable[win32more.Windows.Foundation.Collections.IIterable[win32more.Windows.Foundation.Point]]: ...
    @winrt_commethod(9)
    def GetChildrenInTabFocusOrder(self) -> win32more.Windows.Foundation.Collections.IIterable[win32more.Microsoft.UI.Xaml.DependencyObject]: ...
    @winrt_commethod(10)
    def OnKeyboardAcceleratorInvoked(self, args: win32more.Microsoft.UI.Xaml.Input.KeyboardAcceleratorInvokedEventArgs) -> Void: ...
    @winrt_commethod(11)
    def OnProcessKeyboardAccelerators(self, args: win32more.Microsoft.UI.Xaml.Input.ProcessKeyboardAcceleratorEventArgs) -> Void: ...
    @winrt_commethod(12)
    def OnBringIntoViewRequested(self, e: win32more.Microsoft.UI.Xaml.BringIntoViewRequestedEventArgs) -> Void: ...
    @winrt_commethod(13)
    def PopulatePropertyInfoOverride(self, propertyName: hstr, animationPropertyInfo: win32more.Microsoft.UI.Composition.AnimationPropertyInfo) -> Void: ...
class IUIElementProtected(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IUIElementProtected'
    _iid_ = Guid('{8f69b9e9-1f00-5834-9bf1-a9257bed39f0}')
    @winrt_commethod(6)
    def get_ProtectedCursor(self) -> win32more.Microsoft.UI.Input.InputCursor: ...
    @winrt_commethod(7)
    def put_ProtectedCursor(self, value: win32more.Microsoft.UI.Input.InputCursor) -> Void: ...
    ProtectedCursor = property(get_ProtectedCursor, put_ProtectedCursor)
class IUIElementStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IUIElementStatics'
    _iid_ = Guid('{d2921d87-3584-5e22-8a3a-c2c78dab4f6e}')
    @winrt_commethod(6)
    def get_KeyDownEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(7)
    def get_KeyUpEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(8)
    def get_PointerEnteredEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(9)
    def get_PointerPressedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(10)
    def get_PointerMovedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(11)
    def get_PointerReleasedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(12)
    def get_PointerExitedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(13)
    def get_PointerCaptureLostEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(14)
    def get_PointerCanceledEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(15)
    def get_PointerWheelChangedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(16)
    def get_TappedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(17)
    def get_DoubleTappedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(18)
    def get_HoldingEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(19)
    def get_RightTappedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(20)
    def get_ManipulationStartingEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(21)
    def get_ManipulationInertiaStartingEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(22)
    def get_ManipulationStartedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(23)
    def get_ManipulationDeltaEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(24)
    def get_ManipulationCompletedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(25)
    def get_DragEnterEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(26)
    def get_DragLeaveEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(27)
    def get_DragOverEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(28)
    def get_DropEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(29)
    def get_GettingFocusEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(30)
    def get_LosingFocusEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(31)
    def get_NoFocusCandidateFoundEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(32)
    def get_PreviewKeyDownEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(33)
    def get_CharacterReceivedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(34)
    def get_PreviewKeyUpEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(35)
    def get_BringIntoViewRequestedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(36)
    def get_ContextRequestedEvent(self) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_commethod(37)
    def get_AllowDropProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(38)
    def get_OpacityProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(39)
    def get_ClipProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(40)
    def get_RenderTransformProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(41)
    def get_ProjectionProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(42)
    def get_Transform3DProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(43)
    def get_RenderTransformOriginProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(44)
    def get_IsHitTestVisibleProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(45)
    def get_VisibilityProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(46)
    def get_UseLayoutRoundingProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(47)
    def get_TransitionsProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(48)
    def get_CacheModeProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(49)
    def get_IsTapEnabledProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(50)
    def get_IsDoubleTapEnabledProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(51)
    def get_CanDragProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(52)
    def get_IsRightTapEnabledProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(53)
    def get_IsHoldingEnabledProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(54)
    def get_ManipulationModeProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(55)
    def get_PointerCapturesProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(56)
    def get_ContextFlyoutProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(57)
    def get_CompositeModeProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(58)
    def get_LightsProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(59)
    def get_CanBeScrollAnchorProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(60)
    def get_ExitDisplayModeOnAccessKeyInvokedProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(61)
    def get_IsAccessKeyScopeProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(62)
    def get_AccessKeyScopeOwnerProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(63)
    def get_AccessKeyProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(64)
    def get_KeyTipPlacementModeProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(65)
    def get_KeyTipHorizontalOffsetProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(66)
    def get_KeyTipVerticalOffsetProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(67)
    def get_KeyTipTargetProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(68)
    def get_XYFocusKeyboardNavigationProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(69)
    def get_XYFocusUpNavigationStrategyProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(70)
    def get_XYFocusDownNavigationStrategyProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(71)
    def get_XYFocusLeftNavigationStrategyProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(72)
    def get_XYFocusRightNavigationStrategyProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(73)
    def get_KeyboardAcceleratorPlacementTargetProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(74)
    def get_KeyboardAcceleratorPlacementModeProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(75)
    def get_HighContrastAdjustmentProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(76)
    def get_TabFocusNavigationProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(77)
    def get_ShadowProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(78)
    def get_FocusStateProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(79)
    def get_UseSystemFocusVisualsProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(80)
    def get_XYFocusLeftProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(81)
    def get_XYFocusRightProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(82)
    def get_XYFocusUpProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(83)
    def get_XYFocusDownProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(84)
    def get_IsTabStopProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(85)
    def get_TabIndexProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(86)
    def TryStartDirectManipulation(self, value: win32more.Microsoft.UI.Xaml.Input.Pointer) -> Boolean: ...
    @winrt_commethod(87)
    def RegisterAsScrollPort(self, element: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    AccessKeyProperty = property(get_AccessKeyProperty, None)
    AccessKeyScopeOwnerProperty = property(get_AccessKeyScopeOwnerProperty, None)
    AllowDropProperty = property(get_AllowDropProperty, None)
    BringIntoViewRequestedEvent = property(get_BringIntoViewRequestedEvent, None)
    CacheModeProperty = property(get_CacheModeProperty, None)
    CanBeScrollAnchorProperty = property(get_CanBeScrollAnchorProperty, None)
    CanDragProperty = property(get_CanDragProperty, None)
    CharacterReceivedEvent = property(get_CharacterReceivedEvent, None)
    ClipProperty = property(get_ClipProperty, None)
    CompositeModeProperty = property(get_CompositeModeProperty, None)
    ContextFlyoutProperty = property(get_ContextFlyoutProperty, None)
    ContextRequestedEvent = property(get_ContextRequestedEvent, None)
    DoubleTappedEvent = property(get_DoubleTappedEvent, None)
    DragEnterEvent = property(get_DragEnterEvent, None)
    DragLeaveEvent = property(get_DragLeaveEvent, None)
    DragOverEvent = property(get_DragOverEvent, None)
    DropEvent = property(get_DropEvent, None)
    ExitDisplayModeOnAccessKeyInvokedProperty = property(get_ExitDisplayModeOnAccessKeyInvokedProperty, None)
    FocusStateProperty = property(get_FocusStateProperty, None)
    GettingFocusEvent = property(get_GettingFocusEvent, None)
    HighContrastAdjustmentProperty = property(get_HighContrastAdjustmentProperty, None)
    HoldingEvent = property(get_HoldingEvent, None)
    IsAccessKeyScopeProperty = property(get_IsAccessKeyScopeProperty, None)
    IsDoubleTapEnabledProperty = property(get_IsDoubleTapEnabledProperty, None)
    IsHitTestVisibleProperty = property(get_IsHitTestVisibleProperty, None)
    IsHoldingEnabledProperty = property(get_IsHoldingEnabledProperty, None)
    IsRightTapEnabledProperty = property(get_IsRightTapEnabledProperty, None)
    IsTabStopProperty = property(get_IsTabStopProperty, None)
    IsTapEnabledProperty = property(get_IsTapEnabledProperty, None)
    KeyDownEvent = property(get_KeyDownEvent, None)
    KeyTipHorizontalOffsetProperty = property(get_KeyTipHorizontalOffsetProperty, None)
    KeyTipPlacementModeProperty = property(get_KeyTipPlacementModeProperty, None)
    KeyTipTargetProperty = property(get_KeyTipTargetProperty, None)
    KeyTipVerticalOffsetProperty = property(get_KeyTipVerticalOffsetProperty, None)
    KeyUpEvent = property(get_KeyUpEvent, None)
    KeyboardAcceleratorPlacementModeProperty = property(get_KeyboardAcceleratorPlacementModeProperty, None)
    KeyboardAcceleratorPlacementTargetProperty = property(get_KeyboardAcceleratorPlacementTargetProperty, None)
    LightsProperty = property(get_LightsProperty, None)
    LosingFocusEvent = property(get_LosingFocusEvent, None)
    ManipulationCompletedEvent = property(get_ManipulationCompletedEvent, None)
    ManipulationDeltaEvent = property(get_ManipulationDeltaEvent, None)
    ManipulationInertiaStartingEvent = property(get_ManipulationInertiaStartingEvent, None)
    ManipulationModeProperty = property(get_ManipulationModeProperty, None)
    ManipulationStartedEvent = property(get_ManipulationStartedEvent, None)
    ManipulationStartingEvent = property(get_ManipulationStartingEvent, None)
    NoFocusCandidateFoundEvent = property(get_NoFocusCandidateFoundEvent, None)
    OpacityProperty = property(get_OpacityProperty, None)
    PointerCanceledEvent = property(get_PointerCanceledEvent, None)
    PointerCaptureLostEvent = property(get_PointerCaptureLostEvent, None)
    PointerCapturesProperty = property(get_PointerCapturesProperty, None)
    PointerEnteredEvent = property(get_PointerEnteredEvent, None)
    PointerExitedEvent = property(get_PointerExitedEvent, None)
    PointerMovedEvent = property(get_PointerMovedEvent, None)
    PointerPressedEvent = property(get_PointerPressedEvent, None)
    PointerReleasedEvent = property(get_PointerReleasedEvent, None)
    PointerWheelChangedEvent = property(get_PointerWheelChangedEvent, None)
    PreviewKeyDownEvent = property(get_PreviewKeyDownEvent, None)
    PreviewKeyUpEvent = property(get_PreviewKeyUpEvent, None)
    ProjectionProperty = property(get_ProjectionProperty, None)
    RenderTransformOriginProperty = property(get_RenderTransformOriginProperty, None)
    RenderTransformProperty = property(get_RenderTransformProperty, None)
    RightTappedEvent = property(get_RightTappedEvent, None)
    ShadowProperty = property(get_ShadowProperty, None)
    TabFocusNavigationProperty = property(get_TabFocusNavigationProperty, None)
    TabIndexProperty = property(get_TabIndexProperty, None)
    TappedEvent = property(get_TappedEvent, None)
    Transform3DProperty = property(get_Transform3DProperty, None)
    TransitionsProperty = property(get_TransitionsProperty, None)
    UseLayoutRoundingProperty = property(get_UseLayoutRoundingProperty, None)
    UseSystemFocusVisualsProperty = property(get_UseSystemFocusVisualsProperty, None)
    VisibilityProperty = property(get_VisibilityProperty, None)
    XYFocusDownNavigationStrategyProperty = property(get_XYFocusDownNavigationStrategyProperty, None)
    XYFocusDownProperty = property(get_XYFocusDownProperty, None)
    XYFocusKeyboardNavigationProperty = property(get_XYFocusKeyboardNavigationProperty, None)
    XYFocusLeftNavigationStrategyProperty = property(get_XYFocusLeftNavigationStrategyProperty, None)
    XYFocusLeftProperty = property(get_XYFocusLeftProperty, None)
    XYFocusRightNavigationStrategyProperty = property(get_XYFocusRightNavigationStrategyProperty, None)
    XYFocusRightProperty = property(get_XYFocusRightProperty, None)
    XYFocusUpNavigationStrategyProperty = property(get_XYFocusUpNavigationStrategyProperty, None)
    XYFocusUpProperty = property(get_XYFocusUpProperty, None)
class IUIElementWeakCollectionFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IUIElementWeakCollectionFactory'
    _iid_ = Guid('{b4d69f09-d494-5bc8-ae68-b6307d845049}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.UIElementWeakCollection: ...
class IUnhandledExceptionEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IUnhandledExceptionEventArgs'
    _iid_ = Guid('{59eaeba9-8f9c-5be7-9b3b-820960faa220}')
    @winrt_commethod(6)
    def get_Exception(self) -> win32more.Windows.Foundation.HResult: ...
    @winrt_commethod(7)
    def get_Message(self) -> hstr: ...
    @winrt_commethod(8)
    def get_Handled(self) -> Boolean: ...
    @winrt_commethod(9)
    def put_Handled(self, value: Boolean) -> Void: ...
    Exception = property(get_Exception, None)
    Handled = property(get_Handled, put_Handled)
    Message = property(get_Message, None)
class IVector3Transition(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IVector3Transition'
    _iid_ = Guid('{0c408bb9-f9a2-55d7-8aed-143d36d603f2}')
    @winrt_commethod(6)
    def get_Duration(self) -> win32more.Windows.Foundation.TimeSpan: ...
    @winrt_commethod(7)
    def put_Duration(self, value: win32more.Windows.Foundation.TimeSpan) -> Void: ...
    @winrt_commethod(8)
    def get_Components(self) -> win32more.Microsoft.UI.Xaml.Vector3TransitionComponents: ...
    @winrt_commethod(9)
    def put_Components(self, value: win32more.Microsoft.UI.Xaml.Vector3TransitionComponents) -> Void: ...
    Components = property(get_Components, put_Components)
    Duration = property(get_Duration, put_Duration)
class IVector3TransitionFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IVector3TransitionFactory'
    _iid_ = Guid('{a3a084fc-b965-534b-900f-78e288129232}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.Vector3Transition: ...
class IVisualState(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IVisualState'
    _iid_ = Guid('{4bb32ae8-0e28-5521-a7f5-66b661372994}')
    @winrt_commethod(6)
    def get_Name(self) -> hstr: ...
    @winrt_commethod(7)
    def get_Storyboard(self) -> win32more.Microsoft.UI.Xaml.Media.Animation.Storyboard: ...
    @winrt_commethod(8)
    def put_Storyboard(self, value: win32more.Microsoft.UI.Xaml.Media.Animation.Storyboard) -> Void: ...
    @winrt_commethod(9)
    def get_Setters(self) -> win32more.Microsoft.UI.Xaml.SetterBaseCollection: ...
    @winrt_commethod(10)
    def get_StateTriggers(self) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.StateTriggerBase]: ...
    Name = property(get_Name, None)
    Setters = property(get_Setters, None)
    StateTriggers = property(get_StateTriggers, None)
    Storyboard = property(get_Storyboard, put_Storyboard)
class IVisualStateChangedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IVisualStateChangedEventArgs'
    _iid_ = Guid('{11de9510-a195-577b-88c8-06391618868c}')
    @winrt_commethod(6)
    def get_OldState(self) -> win32more.Microsoft.UI.Xaml.VisualState: ...
    @winrt_commethod(7)
    def put_OldState(self, value: win32more.Microsoft.UI.Xaml.VisualState) -> Void: ...
    @winrt_commethod(8)
    def get_NewState(self) -> win32more.Microsoft.UI.Xaml.VisualState: ...
    @winrt_commethod(9)
    def put_NewState(self, value: win32more.Microsoft.UI.Xaml.VisualState) -> Void: ...
    @winrt_commethod(10)
    def get_Control(self) -> win32more.Microsoft.UI.Xaml.Controls.Control: ...
    @winrt_commethod(11)
    def put_Control(self, value: win32more.Microsoft.UI.Xaml.Controls.Control) -> Void: ...
    Control = property(get_Control, put_Control)
    NewState = property(get_NewState, put_NewState)
    OldState = property(get_OldState, put_OldState)
class IVisualStateGroup(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IVisualStateGroup'
    _iid_ = Guid('{8dfd691b-710c-5d6d-b71a-7a7f5ed54ac7}')
    @winrt_commethod(6)
    def get_Name(self) -> hstr: ...
    @winrt_commethod(7)
    def get_Transitions(self) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.VisualTransition]: ...
    @winrt_commethod(8)
    def get_States(self) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.VisualState]: ...
    @winrt_commethod(9)
    def get_CurrentState(self) -> win32more.Microsoft.UI.Xaml.VisualState: ...
    @winrt_commethod(10)
    def add_CurrentStateChanged(self, handler: win32more.Microsoft.UI.Xaml.VisualStateChangedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(11)
    def remove_CurrentStateChanged(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(12)
    def add_CurrentStateChanging(self, handler: win32more.Microsoft.UI.Xaml.VisualStateChangedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(13)
    def remove_CurrentStateChanging(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    CurrentState = property(get_CurrentState, None)
    Name = property(get_Name, None)
    States = property(get_States, None)
    Transitions = property(get_Transitions, None)
    CurrentStateChanged = event(add_CurrentStateChanged, remove_CurrentStateChanged)
    CurrentStateChanging = event(add_CurrentStateChanging, remove_CurrentStateChanging)
class IVisualStateManager(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IVisualStateManager'
    _iid_ = Guid('{342c8d32-ad61-5925-93d1-0c704df2a7d1}')
class IVisualStateManagerFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IVisualStateManagerFactory'
    _iid_ = Guid('{713daf82-92b3-58f2-8fc1-b0d9a2cad03c}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.VisualStateManager: ...
class IVisualStateManagerOverrides(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IVisualStateManagerOverrides'
    _iid_ = Guid('{e3f8e9c9-9432-514c-923e-142cd8c82730}')
    @winrt_commethod(6)
    def GoToStateCore(self, control: win32more.Microsoft.UI.Xaml.Controls.Control, templateRoot: win32more.Microsoft.UI.Xaml.FrameworkElement, stateName: hstr, group: win32more.Microsoft.UI.Xaml.VisualStateGroup, state: win32more.Microsoft.UI.Xaml.VisualState, useTransitions: Boolean) -> Boolean: ...
class IVisualStateManagerProtected(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IVisualStateManagerProtected'
    _iid_ = Guid('{0f008013-787f-5599-a5ad-0a10b988ed24}')
    @winrt_commethod(6)
    def RaiseCurrentStateChanging(self, stateGroup: win32more.Microsoft.UI.Xaml.VisualStateGroup, oldState: win32more.Microsoft.UI.Xaml.VisualState, newState: win32more.Microsoft.UI.Xaml.VisualState, control: win32more.Microsoft.UI.Xaml.Controls.Control) -> Void: ...
    @winrt_commethod(7)
    def RaiseCurrentStateChanged(self, stateGroup: win32more.Microsoft.UI.Xaml.VisualStateGroup, oldState: win32more.Microsoft.UI.Xaml.VisualState, newState: win32more.Microsoft.UI.Xaml.VisualState, control: win32more.Microsoft.UI.Xaml.Controls.Control) -> Void: ...
class IVisualStateManagerStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IVisualStateManagerStatics'
    _iid_ = Guid('{a4d5147d-88c3-57ed-ad83-245df5f6b50d}')
    @winrt_commethod(6)
    def GetVisualStateGroups(self, obj: win32more.Microsoft.UI.Xaml.FrameworkElement) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.VisualStateGroup]: ...
    @winrt_commethod(7)
    def get_CustomVisualStateManagerProperty(self) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_commethod(8)
    def GetCustomVisualStateManager(self, obj: win32more.Microsoft.UI.Xaml.FrameworkElement) -> win32more.Microsoft.UI.Xaml.VisualStateManager: ...
    @winrt_commethod(9)
    def SetCustomVisualStateManager(self, obj: win32more.Microsoft.UI.Xaml.FrameworkElement, value: win32more.Microsoft.UI.Xaml.VisualStateManager) -> Void: ...
    @winrt_commethod(10)
    def GoToState(self, control: win32more.Microsoft.UI.Xaml.Controls.Control, stateName: hstr, useTransitions: Boolean) -> Boolean: ...
    CustomVisualStateManagerProperty = property(get_CustomVisualStateManagerProperty, None)
class IVisualTransition(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IVisualTransition'
    _iid_ = Guid('{dd21af54-2ce1-59de-9fd1-2b45f6bf6581}')
    @winrt_commethod(6)
    def get_GeneratedDuration(self) -> win32more.Microsoft.UI.Xaml.Duration: ...
    @winrt_commethod(7)
    def put_GeneratedDuration(self, value: win32more.Microsoft.UI.Xaml.Duration) -> Void: ...
    @winrt_commethod(8)
    def get_GeneratedEasingFunction(self) -> win32more.Microsoft.UI.Xaml.Media.Animation.EasingFunctionBase: ...
    @winrt_commethod(9)
    def put_GeneratedEasingFunction(self, value: win32more.Microsoft.UI.Xaml.Media.Animation.EasingFunctionBase) -> Void: ...
    @winrt_commethod(10)
    def get_To(self) -> hstr: ...
    @winrt_commethod(11)
    def put_To(self, value: hstr) -> Void: ...
    @winrt_commethod(12)
    def get_From(self) -> hstr: ...
    @winrt_commethod(13)
    def put_From(self, value: hstr) -> Void: ...
    @winrt_commethod(14)
    def get_Storyboard(self) -> win32more.Microsoft.UI.Xaml.Media.Animation.Storyboard: ...
    @winrt_commethod(15)
    def put_Storyboard(self, value: win32more.Microsoft.UI.Xaml.Media.Animation.Storyboard) -> Void: ...
    From = property(get_From, put_From)
    GeneratedDuration = property(get_GeneratedDuration, put_GeneratedDuration)
    GeneratedEasingFunction = property(get_GeneratedEasingFunction, put_GeneratedEasingFunction)
    Storyboard = property(get_Storyboard, put_Storyboard)
    To = property(get_To, put_To)
class IVisualTransitionFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IVisualTransitionFactory'
    _iid_ = Guid('{f3e74c0d-0b5b-5920-a309-08cb6bf2a739}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.VisualTransition: ...
class IWindow(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IWindow'
    _iid_ = Guid('{61f0ec79-5d52-56b5-86fb-40fa4af288b0}')
    @winrt_commethod(6)
    def get_Bounds(self) -> win32more.Windows.Foundation.Rect: ...
    @winrt_commethod(7)
    def get_Visible(self) -> Boolean: ...
    @winrt_commethod(8)
    def get_Content(self) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_commethod(9)
    def put_Content(self, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    @winrt_commethod(10)
    def get_CoreWindow(self) -> win32more.Windows.UI.Core.CoreWindow: ...
    @winrt_commethod(11)
    def get_Compositor(self) -> win32more.Microsoft.UI.Composition.Compositor: ...
    @winrt_commethod(12)
    def get_Dispatcher(self) -> win32more.Windows.UI.Core.CoreDispatcher: ...
    @winrt_commethod(13)
    def get_DispatcherQueue(self) -> win32more.Microsoft.UI.Dispatching.DispatcherQueue: ...
    @winrt_commethod(14)
    def get_Title(self) -> hstr: ...
    @winrt_commethod(15)
    def put_Title(self, value: hstr) -> Void: ...
    @winrt_commethod(16)
    def get_ExtendsContentIntoTitleBar(self) -> Boolean: ...
    @winrt_commethod(17)
    def put_ExtendsContentIntoTitleBar(self, value: Boolean) -> Void: ...
    @winrt_commethod(18)
    def add_Activated(self, handler: win32more.Windows.Foundation.TypedEventHandler[IInspectable, win32more.Microsoft.UI.Xaml.WindowActivatedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(19)
    def remove_Activated(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(20)
    def add_Closed(self, handler: win32more.Windows.Foundation.TypedEventHandler[IInspectable, win32more.Microsoft.UI.Xaml.WindowEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(21)
    def remove_Closed(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(22)
    def add_SizeChanged(self, handler: win32more.Windows.Foundation.TypedEventHandler[IInspectable, win32more.Microsoft.UI.Xaml.WindowSizeChangedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(23)
    def remove_SizeChanged(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(24)
    def add_VisibilityChanged(self, handler: win32more.Windows.Foundation.TypedEventHandler[IInspectable, win32more.Microsoft.UI.Xaml.WindowVisibilityChangedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(25)
    def remove_VisibilityChanged(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_commethod(26)
    def Activate(self) -> Void: ...
    @winrt_commethod(27)
    def Close(self) -> Void: ...
    @winrt_commethod(28)
    def SetTitleBar(self, titleBar: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    Bounds = property(get_Bounds, None)
    Compositor = property(get_Compositor, None)
    Content = property(get_Content, put_Content)
    CoreWindow = property(get_CoreWindow, None)
    Dispatcher = property(get_Dispatcher, None)
    DispatcherQueue = property(get_DispatcherQueue, None)
    ExtendsContentIntoTitleBar = property(get_ExtendsContentIntoTitleBar, put_ExtendsContentIntoTitleBar)
    Title = property(get_Title, put_Title)
    Visible = property(get_Visible, None)
    Activated = event(add_Activated, remove_Activated)
    Closed = event(add_Closed, remove_Closed)
    SizeChanged = event(add_SizeChanged, remove_SizeChanged)
    VisibilityChanged = event(add_VisibilityChanged, remove_VisibilityChanged)
class IWindow2(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IWindow2'
    _iid_ = Guid('{42febaa5-1c32-522a-a591-57618c6f665d}')
    @winrt_commethod(6)
    def get_SystemBackdrop(self) -> win32more.Microsoft.UI.Xaml.Media.SystemBackdrop: ...
    @winrt_commethod(7)
    def put_SystemBackdrop(self, value: win32more.Microsoft.UI.Xaml.Media.SystemBackdrop) -> Void: ...
    @winrt_commethod(8)
    def get_AppWindow(self) -> win32more.Microsoft.UI.Windowing.AppWindow: ...
    AppWindow = property(get_AppWindow, None)
    SystemBackdrop = property(get_SystemBackdrop, put_SystemBackdrop)
class IWindowActivatedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IWindowActivatedEventArgs'
    _iid_ = Guid('{c723a5ea-82c4-5dd6-861b-70ef573b88d6}')
    @winrt_commethod(6)
    def get_Handled(self) -> Boolean: ...
    @winrt_commethod(7)
    def put_Handled(self, value: Boolean) -> Void: ...
    @winrt_commethod(8)
    def get_WindowActivationState(self) -> win32more.Microsoft.UI.Xaml.WindowActivationState: ...
    Handled = property(get_Handled, put_Handled)
    WindowActivationState = property(get_WindowActivationState, None)
class IWindowEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IWindowEventArgs'
    _iid_ = Guid('{1140827c-fe0a-5268-bc2b-f4492c2ccb49}')
    @winrt_commethod(6)
    def get_Handled(self) -> Boolean: ...
    @winrt_commethod(7)
    def put_Handled(self, value: Boolean) -> Void: ...
    Handled = property(get_Handled, put_Handled)
class IWindowFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IWindowFactory'
    _iid_ = Guid('{f0441536-afef-5222-918f-324a9b2dec75}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.Window: ...
class IWindowSizeChangedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IWindowSizeChangedEventArgs'
    _iid_ = Guid('{542f6f2c-4b64-5c72-a7a5-3a7e0664b8ff}')
    @winrt_commethod(6)
    def get_Handled(self) -> Boolean: ...
    @winrt_commethod(7)
    def put_Handled(self, value: Boolean) -> Void: ...
    @winrt_commethod(8)
    def get_Size(self) -> win32more.Windows.Foundation.Size: ...
    Handled = property(get_Handled, put_Handled)
    Size = property(get_Size, None)
class IWindowStatics(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IWindowStatics'
    _iid_ = Guid('{8cc985e3-a41a-5df4-b531-d3a1788d86c5}')
    @winrt_commethod(6)
    def get_Current(self) -> win32more.Microsoft.UI.Xaml.Window: ...
    Current = property(get_Current, None)
class IWindowVisibilityChangedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IWindowVisibilityChangedEventArgs'
    _iid_ = Guid('{7bb24a6d-070c-5cb6-8e9c-547905be8265}')
    @winrt_commethod(6)
    def get_Handled(self) -> Boolean: ...
    @winrt_commethod(7)
    def put_Handled(self, value: Boolean) -> Void: ...
    @winrt_commethod(8)
    def get_Visible(self) -> Boolean: ...
    Handled = property(get_Handled, put_Handled)
    Visible = property(get_Visible, None)
class IXamlIsland(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IXamlIsland'
    _iid_ = Guid('{845a5c62-b0f3-5db8-b4ff-4142bbd8a044}')
    @winrt_commethod(6)
    def get_Content(self) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_commethod(7)
    def put_Content(self, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    @winrt_commethod(8)
    def get_ContentIsland(self) -> win32more.Microsoft.UI.Content.ContentIsland: ...
    @winrt_commethod(9)
    def get_SystemBackdrop(self) -> win32more.Microsoft.UI.Xaml.Media.SystemBackdrop: ...
    @winrt_commethod(10)
    def put_SystemBackdrop(self, value: win32more.Microsoft.UI.Xaml.Media.SystemBackdrop) -> Void: ...
    Content = property(get_Content, put_Content)
    ContentIsland = property(get_ContentIsland, None)
    SystemBackdrop = property(get_SystemBackdrop, put_SystemBackdrop)
class IXamlIslandFactory(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IXamlIslandFactory'
    _iid_ = Guid('{267f707c-5e18-57b4-9ff7-d11da66e4a11}')
    @winrt_commethod(6)
    def CreateInstance(self, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.XamlIsland: ...
class IXamlResourceReferenceFailedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IXamlResourceReferenceFailedEventArgs'
    _iid_ = Guid('{1b175ee6-d08b-50ff-8f89-a1ff27edef66}')
    @winrt_commethod(6)
    def get_Message(self) -> hstr: ...
    Message = property(get_Message, None)
class IXamlRoot(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IXamlRoot'
    _iid_ = Guid('{60cb215a-ad15-520a-8b01-4416824f0441}')
    @winrt_commethod(6)
    def get_Content(self) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_commethod(7)
    def get_Size(self) -> win32more.Windows.Foundation.Size: ...
    @winrt_commethod(8)
    def get_RasterizationScale(self) -> Double: ...
    @winrt_commethod(9)
    def get_IsHostVisible(self) -> Boolean: ...
    @winrt_commethod(10)
    def add_Changed(self, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.XamlRoot, win32more.Microsoft.UI.Xaml.XamlRootChangedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_commethod(11)
    def remove_Changed(self, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    Content = property(get_Content, None)
    IsHostVisible = property(get_IsHostVisible, None)
    RasterizationScale = property(get_RasterizationScale, None)
    Size = property(get_Size, None)
    Changed = event(add_Changed, remove_Changed)
class IXamlRoot2(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IXamlRoot2'
    _iid_ = Guid('{bdee0f42-71cb-50c5-829b-4614d98c5794}')
    @winrt_commethod(6)
    def get_ContentIslandEnvironment(self) -> win32more.Microsoft.UI.Content.ContentIslandEnvironment: ...
    ContentIslandEnvironment = property(get_ContentIslandEnvironment, None)
class IXamlRoot3(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IXamlRoot3'
    _iid_ = Guid('{b71dbf3b-2e0f-5de0-ac68-f0c1f65114c8}')
    @winrt_commethod(6)
    def get_CoordinateConverter(self) -> win32more.Microsoft.UI.Content.ContentCoordinateConverter: ...
    CoordinateConverter = property(get_CoordinateConverter, None)
class IXamlRoot4(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IXamlRoot4'
    _iid_ = Guid('{377bec22-632b-52be-b26f-5edf7838e5ca}')
    @winrt_commethod(6)
    def get_ContentIsland(self) -> win32more.Microsoft.UI.Content.ContentIsland: ...
    ContentIsland = property(get_ContentIsland, None)
class IXamlRootChangedEventArgs(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IXamlRootChangedEventArgs'
    _iid_ = Guid('{61d2c719-f8a1-515a-902c-cfa498ba7a7f}')
class IXamlServiceProvider(ComPtr):
    extends: IInspectable
    _classid_ = 'Microsoft.UI.Xaml.IXamlServiceProvider'
    _iid_ = Guid('{68b3a2df-8173-539f-b524-c8a2348f5afb}')
    @winrt_commethod(6)
    def GetService(self, type: win32more.Windows.UI.Xaml.Interop.TypeName) -> IInspectable: ...
class LaunchActivatedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.ILaunchActivatedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.LaunchActivatedEventArgs'
    @winrt_mixinmethod
    def get_Arguments(self: win32more.Microsoft.UI.Xaml.ILaunchActivatedEventArgs) -> hstr: ...
    @winrt_mixinmethod
    def get_UWPLaunchActivatedEventArgs(self: win32more.Microsoft.UI.Xaml.ILaunchActivatedEventArgs) -> win32more.Windows.ApplicationModel.Activation.LaunchActivatedEventArgs: ...
    Arguments = property(get_Arguments, None)
    UWPLaunchActivatedEventArgs = property(get_UWPLaunchActivatedEventArgs, None)
class LayoutCycleDebugBreakLevel(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.LayoutCycleDebugBreakLevel'
    None_ = 0
    Low = 1
    High = 2
class LayoutCycleTracingLevel(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.LayoutCycleTracingLevel'
    None_ = 0
    Low = 1
    High = 2
class LeavingBackgroundEventHandler(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{3d723b94-fbcf-5c0d-b6ef-5062e68bf9f8}')
    @winrt_commethod(3)
    def Invoke(self, sender: IInspectable, e: win32more.Windows.ApplicationModel.LeavingBackgroundEventArgs) -> Void: ...
class LineStackingStrategy(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.LineStackingStrategy'
    MaxHeight = 0
    BlockLineHeight = 1
    BaselineToBaseline = 2
class MediaFailedRoutedEventArgs(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.ExceptionRoutedEventArgs
    default_interface: win32more.Microsoft.UI.Xaml.IMediaFailedRoutedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.MediaFailedRoutedEventArgs'
    @winrt_mixinmethod
    def get_ErrorTrace(self: win32more.Microsoft.UI.Xaml.IMediaFailedRoutedEventArgs) -> hstr: ...
    ErrorTrace = property(get_ErrorTrace, None)
class OpticalMarginAlignment(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.OpticalMarginAlignment'
    None_ = 0
    TrimSideBearings = 1
class PointHelper(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IPointHelper
    _classid_ = 'Microsoft.UI.Xaml.PointHelper'
    @winrt_classmethod
    def FromCoordinates(cls: win32more.Microsoft.UI.Xaml.IPointHelperStatics, x: Single, y: Single) -> win32more.Windows.Foundation.Point: ...
class PropertyChangedCallback(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{5fd9243a-2422-53c9-8d6f-f1ba1a0bba9a}')
    @winrt_commethod(3)
    def Invoke(self, d: win32more.Microsoft.UI.Xaml.DependencyObject, e: win32more.Microsoft.UI.Xaml.DependencyPropertyChangedEventArgs) -> Void: ...
class PropertyMetadata(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IPropertyMetadata
    _classid_ = 'Microsoft.UI.Xaml.PropertyMetadata'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 1:
            super().__init__(move=win32more.Microsoft.UI.Xaml.PropertyMetadata.CreateInstanceWithDefaultValue(*args, None, None))
        elif len(args) == 2:
            super().__init__(move=win32more.Microsoft.UI.Xaml.PropertyMetadata.CreateInstanceWithDefaultValueAndCallback(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstanceWithDefaultValue(cls: win32more.Microsoft.UI.Xaml.IPropertyMetadataFactory, defaultValue: IInspectable, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
    @winrt_factorymethod
    def CreateInstanceWithDefaultValueAndCallback(cls: win32more.Microsoft.UI.Xaml.IPropertyMetadataFactory, defaultValue: IInspectable, propertyChangedCallback: win32more.Microsoft.UI.Xaml.PropertyChangedCallback, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
    @winrt_mixinmethod
    def get_DefaultValue(self: win32more.Microsoft.UI.Xaml.IPropertyMetadata) -> IInspectable: ...
    @winrt_mixinmethod
    def get_CreateDefaultValueCallback(self: win32more.Microsoft.UI.Xaml.IPropertyMetadata) -> win32more.Microsoft.UI.Xaml.CreateDefaultValueCallback: ...
    @winrt_classmethod
    def CreateWithDefaultValue(cls: win32more.Microsoft.UI.Xaml.IPropertyMetadataStatics, defaultValue: IInspectable) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
    @winrt_classmethod
    def CreateWithDefaultValueAndCallback(cls: win32more.Microsoft.UI.Xaml.IPropertyMetadataStatics, defaultValue: IInspectable, propertyChangedCallback: win32more.Microsoft.UI.Xaml.PropertyChangedCallback) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
    @winrt_classmethod
    def CreateWithFactory(cls: win32more.Microsoft.UI.Xaml.IPropertyMetadataStatics, createDefaultValueCallback: win32more.Microsoft.UI.Xaml.CreateDefaultValueCallback) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
    @winrt_classmethod
    def CreateWithFactoryAndCallback(cls: win32more.Microsoft.UI.Xaml.IPropertyMetadataStatics, createDefaultValueCallback: win32more.Microsoft.UI.Xaml.CreateDefaultValueCallback, propertyChangedCallback: win32more.Microsoft.UI.Xaml.PropertyChangedCallback) -> win32more.Microsoft.UI.Xaml.PropertyMetadata: ...
    CreateDefaultValueCallback = property(get_CreateDefaultValueCallback, None)
    DefaultValue = property(get_DefaultValue, None)
class PropertyPath(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    default_interface: win32more.Microsoft.UI.Xaml.IPropertyPath
    _classid_ = 'Microsoft.UI.Xaml.PropertyPath'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 1:
            super().__init__(move=win32more.Microsoft.UI.Xaml.PropertyPath.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IPropertyPathFactory, path: hstr) -> win32more.Microsoft.UI.Xaml.PropertyPath: ...
    @winrt_mixinmethod
    def get_Path(self: win32more.Microsoft.UI.Xaml.IPropertyPath) -> hstr: ...
    Path = property(get_Path, None)
class _RectHelper_Meta_(ComPtr.__class__):
    pass
class RectHelper(ComPtr, metaclass=_RectHelper_Meta_):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IRectHelper
    _classid_ = 'Microsoft.UI.Xaml.RectHelper'
    @winrt_classmethod
    def get_Empty(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics) -> win32more.Windows.Foundation.Rect: ...
    @winrt_classmethod
    def FromCoordinatesAndDimensions(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, x: Single, y: Single, width: Single, height: Single) -> win32more.Windows.Foundation.Rect: ...
    @winrt_classmethod
    def FromPoints(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, point1: win32more.Windows.Foundation.Point, point2: win32more.Windows.Foundation.Point) -> win32more.Windows.Foundation.Rect: ...
    @winrt_classmethod
    def FromLocationAndSize(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, location: win32more.Windows.Foundation.Point, size: win32more.Windows.Foundation.Size) -> win32more.Windows.Foundation.Rect: ...
    @winrt_classmethod
    def GetIsEmpty(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, target: win32more.Windows.Foundation.Rect) -> Boolean: ...
    @winrt_classmethod
    def GetBottom(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, target: win32more.Windows.Foundation.Rect) -> Single: ...
    @winrt_classmethod
    def GetLeft(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, target: win32more.Windows.Foundation.Rect) -> Single: ...
    @winrt_classmethod
    def GetRight(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, target: win32more.Windows.Foundation.Rect) -> Single: ...
    @winrt_classmethod
    def GetTop(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, target: win32more.Windows.Foundation.Rect) -> Single: ...
    @winrt_classmethod
    def Contains(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, target: win32more.Windows.Foundation.Rect, point: win32more.Windows.Foundation.Point) -> Boolean: ...
    @winrt_classmethod
    def Equals(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, target: win32more.Windows.Foundation.Rect, value: win32more.Windows.Foundation.Rect) -> Boolean: ...
    @winrt_classmethod
    def Intersect(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, target: win32more.Windows.Foundation.Rect, rect: win32more.Windows.Foundation.Rect) -> win32more.Windows.Foundation.Rect: ...
    @winrt_classmethod
    def UnionWithPoint(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, target: win32more.Windows.Foundation.Rect, point: win32more.Windows.Foundation.Point) -> win32more.Windows.Foundation.Rect: ...
    @winrt_classmethod
    def UnionWithRect(cls: win32more.Microsoft.UI.Xaml.IRectHelperStatics, target: win32more.Windows.Foundation.Rect, rect: win32more.Windows.Foundation.Rect) -> win32more.Windows.Foundation.Rect: ...
    _RectHelper_Meta_.Empty = property(get_Empty, None)
class ResourceDictionary(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    implements: Tuple[MappingProtocol[IInspectable, IInspectable]]
    default_interface: win32more.Microsoft.UI.Xaml.IResourceDictionary
    _classid_ = 'Microsoft.UI.Xaml.ResourceDictionary'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.ResourceDictionary.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IResourceDictionaryFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.ResourceDictionary: ...
    @winrt_mixinmethod
    def get_Source(self: win32more.Microsoft.UI.Xaml.IResourceDictionary) -> win32more.Windows.Foundation.Uri: ...
    @winrt_mixinmethod
    def put_Source(self: win32more.Microsoft.UI.Xaml.IResourceDictionary, value: win32more.Windows.Foundation.Uri) -> Void: ...
    @winrt_mixinmethod
    def get_MergedDictionaries(self: win32more.Microsoft.UI.Xaml.IResourceDictionary) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.ResourceDictionary]: ...
    @winrt_mixinmethod
    def get_ThemeDictionaries(self: win32more.Microsoft.UI.Xaml.IResourceDictionary) -> win32more.Windows.Foundation.Collections.IMap[IInspectable, IInspectable]: ...
    @winrt_mixinmethod
    def Lookup(self: win32more.Windows.Foundation.Collections.IMap[IInspectable, IInspectable], key: IInspectable) -> IInspectable: ...
    @winrt_mixinmethod
    def get_Size(self: win32more.Windows.Foundation.Collections.IMap[IInspectable, IInspectable]) -> UInt32: ...
    @winrt_mixinmethod
    def HasKey(self: win32more.Windows.Foundation.Collections.IMap[IInspectable, IInspectable], key: IInspectable) -> Boolean: ...
    @winrt_mixinmethod
    def GetView(self: win32more.Windows.Foundation.Collections.IMap[IInspectable, IInspectable]) -> win32more.Windows.Foundation.Collections.IMapView[IInspectable, IInspectable]: ...
    @winrt_mixinmethod
    def Insert(self: win32more.Windows.Foundation.Collections.IMap[IInspectable, IInspectable], key: IInspectable, value: IInspectable) -> Boolean: ...
    @winrt_mixinmethod
    def Remove(self: win32more.Windows.Foundation.Collections.IMap[IInspectable, IInspectable], key: IInspectable) -> Void: ...
    @winrt_mixinmethod
    def Clear(self: win32more.Windows.Foundation.Collections.IMap[IInspectable, IInspectable]) -> Void: ...
    @winrt_mixinmethod
    def First(self: win32more.Windows.Foundation.Collections.IIterable[win32more.Windows.Foundation.Collections.IKeyValuePair[IInspectable, IInspectable]]) -> win32more.Windows.Foundation.Collections.IIterator[win32more.Windows.Foundation.Collections.IKeyValuePair[IInspectable, IInspectable]]: ...
    MergedDictionaries = property(get_MergedDictionaries, None)
    Size = property(get_Size, None)
    Source = property(get_Source, put_Source)
    ThemeDictionaries = property(get_ThemeDictionaries, None)
class ResourceManagerRequestedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IResourceManagerRequestedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.ResourceManagerRequestedEventArgs'
    @winrt_mixinmethod
    def get_CustomResourceManager(self: win32more.Microsoft.UI.Xaml.IResourceManagerRequestedEventArgs) -> win32more.Microsoft.Windows.ApplicationModel.Resources.IResourceManager: ...
    @winrt_mixinmethod
    def put_CustomResourceManager(self: win32more.Microsoft.UI.Xaml.IResourceManagerRequestedEventArgs, value: win32more.Microsoft.Windows.ApplicationModel.Resources.IResourceManager) -> Void: ...
    CustomResourceManager = property(get_CustomResourceManager, put_CustomResourceManager)
class RoutedEvent(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IRoutedEvent
    _classid_ = 'Microsoft.UI.Xaml.RoutedEvent'
class RoutedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IRoutedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.RoutedEventArgs'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.RoutedEventArgs.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IRoutedEventArgsFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.RoutedEventArgs: ...
    @winrt_mixinmethod
    def get_OriginalSource(self: win32more.Microsoft.UI.Xaml.IRoutedEventArgs) -> IInspectable: ...
    OriginalSource = property(get_OriginalSource, None)
class RoutedEventHandler(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{dae23d85-69ca-5bdf-805b-6161a3a215cc}')
    @winrt_commethod(3)
    def Invoke(self, sender: IInspectable, e: win32more.Microsoft.UI.Xaml.RoutedEventArgs) -> Void: ...
class ScalarTransition(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IScalarTransition
    _classid_ = 'Microsoft.UI.Xaml.ScalarTransition'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.ScalarTransition.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IScalarTransitionFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.ScalarTransition: ...
    @winrt_mixinmethod
    def get_Duration(self: win32more.Microsoft.UI.Xaml.IScalarTransition) -> win32more.Windows.Foundation.TimeSpan: ...
    @winrt_mixinmethod
    def put_Duration(self: win32more.Microsoft.UI.Xaml.IScalarTransition, value: win32more.Windows.Foundation.TimeSpan) -> Void: ...
    Duration = property(get_Duration, put_Duration)
class Setter(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.SetterBase
    default_interface: win32more.Microsoft.UI.Xaml.ISetter
    _classid_ = 'Microsoft.UI.Xaml.Setter'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.Setter.CreateInstance(*args))
        elif len(args) == 2:
            super().__init__(move=win32more.Microsoft.UI.Xaml.Setter.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_overload
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.Setter: ...
    @CreateInstance.register
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.ISetterFactory, targetProperty: win32more.Microsoft.UI.Xaml.DependencyProperty, value: IInspectable) -> win32more.Microsoft.UI.Xaml.Setter: ...
    @winrt_mixinmethod
    def get_Property(self: win32more.Microsoft.UI.Xaml.ISetter) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_mixinmethod
    def put_Property(self: win32more.Microsoft.UI.Xaml.ISetter, value: win32more.Microsoft.UI.Xaml.DependencyProperty) -> Void: ...
    @winrt_mixinmethod
    def get_Value(self: win32more.Microsoft.UI.Xaml.ISetter) -> IInspectable: ...
    @winrt_mixinmethod
    def put_Value(self: win32more.Microsoft.UI.Xaml.ISetter, value: IInspectable) -> Void: ...
    @winrt_mixinmethod
    def get_Target(self: win32more.Microsoft.UI.Xaml.ISetter) -> win32more.Microsoft.UI.Xaml.TargetPropertyPath: ...
    @winrt_mixinmethod
    def put_Target(self: win32more.Microsoft.UI.Xaml.ISetter, value: win32more.Microsoft.UI.Xaml.TargetPropertyPath) -> Void: ...
    Property = property(get_Property, put_Property)
    Target = property(get_Target, put_Target)
    Value = property(get_Value, put_Value)
class SetterBase(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    default_interface: win32more.Microsoft.UI.Xaml.ISetterBase
    _classid_ = 'Microsoft.UI.Xaml.SetterBase'
    @winrt_mixinmethod
    def get_IsSealed(self: win32more.Microsoft.UI.Xaml.ISetterBase) -> Boolean: ...
    IsSealed = property(get_IsSealed, None)
class SetterBaseCollection(ComPtr):
    extends: IInspectable
    implements: Tuple[SequenceProtocol[win32more.Microsoft.UI.Xaml.SetterBase]]
    default_interface: win32more.Microsoft.UI.Xaml.ISetterBaseCollection
    _classid_ = 'Microsoft.UI.Xaml.SetterBaseCollection'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.SetterBaseCollection.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.SetterBaseCollection: ...
    @winrt_mixinmethod
    def get_IsSealed(self: win32more.Microsoft.UI.Xaml.ISetterBaseCollection) -> Boolean: ...
    @winrt_mixinmethod
    def GetAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.SetterBase], index: UInt32) -> win32more.Microsoft.UI.Xaml.SetterBase: ...
    @winrt_mixinmethod
    def get_Size(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.SetterBase]) -> UInt32: ...
    @winrt_mixinmethod
    def GetView(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.SetterBase]) -> win32more.Windows.Foundation.Collections.IVectorView[win32more.Microsoft.UI.Xaml.SetterBase]: ...
    @winrt_mixinmethod
    def IndexOf(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.SetterBase], value: win32more.Microsoft.UI.Xaml.SetterBase, index: POINTER(UInt32)) -> Boolean: ...
    @winrt_mixinmethod
    def SetAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.SetterBase], index: UInt32, value: win32more.Microsoft.UI.Xaml.SetterBase) -> Void: ...
    @winrt_mixinmethod
    def InsertAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.SetterBase], index: UInt32, value: win32more.Microsoft.UI.Xaml.SetterBase) -> Void: ...
    @winrt_mixinmethod
    def RemoveAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.SetterBase], index: UInt32) -> Void: ...
    @winrt_mixinmethod
    def Append(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.SetterBase], value: win32more.Microsoft.UI.Xaml.SetterBase) -> Void: ...
    @winrt_mixinmethod
    def RemoveAtEnd(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.SetterBase]) -> Void: ...
    @winrt_mixinmethod
    def Clear(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.SetterBase]) -> Void: ...
    @winrt_mixinmethod
    def GetMany(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.SetterBase], startIndex: UInt32, items: FillArray[win32more.Microsoft.UI.Xaml.SetterBase]) -> UInt32: ...
    @winrt_mixinmethod
    def ReplaceAll(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.SetterBase], items: PassArray[win32more.Microsoft.UI.Xaml.SetterBase]) -> Void: ...
    @winrt_mixinmethod
    def First(self: win32more.Windows.Foundation.Collections.IIterable[win32more.Microsoft.UI.Xaml.SetterBase]) -> win32more.Windows.Foundation.Collections.IIterator[win32more.Microsoft.UI.Xaml.SetterBase]: ...
    IsSealed = property(get_IsSealed, None)
    Size = property(get_Size, None)
class SizeChangedEventArgs(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.RoutedEventArgs
    default_interface: win32more.Microsoft.UI.Xaml.ISizeChangedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.SizeChangedEventArgs'
    @winrt_mixinmethod
    def get_PreviousSize(self: win32more.Microsoft.UI.Xaml.ISizeChangedEventArgs) -> win32more.Windows.Foundation.Size: ...
    @winrt_mixinmethod
    def get_NewSize(self: win32more.Microsoft.UI.Xaml.ISizeChangedEventArgs) -> win32more.Windows.Foundation.Size: ...
    NewSize = property(get_NewSize, None)
    PreviousSize = property(get_PreviousSize, None)
class SizeChangedEventHandler(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{8d7b1a58-14c6-51c9-892c-9fcce368e77d}')
    @winrt_commethod(3)
    def Invoke(self, sender: IInspectable, e: win32more.Microsoft.UI.Xaml.SizeChangedEventArgs) -> Void: ...
class _SizeHelper_Meta_(ComPtr.__class__):
    pass
class SizeHelper(ComPtr, metaclass=_SizeHelper_Meta_):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.ISizeHelper
    _classid_ = 'Microsoft.UI.Xaml.SizeHelper'
    @winrt_classmethod
    def get_Empty(cls: win32more.Microsoft.UI.Xaml.ISizeHelperStatics) -> win32more.Windows.Foundation.Size: ...
    @winrt_classmethod
    def FromDimensions(cls: win32more.Microsoft.UI.Xaml.ISizeHelperStatics, width: Single, height: Single) -> win32more.Windows.Foundation.Size: ...
    @winrt_classmethod
    def GetIsEmpty(cls: win32more.Microsoft.UI.Xaml.ISizeHelperStatics, target: win32more.Windows.Foundation.Size) -> Boolean: ...
    @winrt_classmethod
    def Equals(cls: win32more.Microsoft.UI.Xaml.ISizeHelperStatics, target: win32more.Windows.Foundation.Size, value: win32more.Windows.Foundation.Size) -> Boolean: ...
    _SizeHelper_Meta_.Empty = property(get_Empty, None)
class _StateTrigger_Meta_(ComPtr.__class__):
    pass
class StateTrigger(ComPtr, metaclass=_StateTrigger_Meta_):
    extends: win32more.Microsoft.UI.Xaml.StateTriggerBase
    default_interface: win32more.Microsoft.UI.Xaml.IStateTrigger
    _classid_ = 'Microsoft.UI.Xaml.StateTrigger'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.StateTrigger.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.StateTrigger: ...
    @winrt_mixinmethod
    def get_IsActive(self: win32more.Microsoft.UI.Xaml.IStateTrigger) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsActive(self: win32more.Microsoft.UI.Xaml.IStateTrigger, value: Boolean) -> Void: ...
    @winrt_classmethod
    def get_IsActiveProperty(cls: win32more.Microsoft.UI.Xaml.IStateTriggerStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    IsActive = property(get_IsActive, put_IsActive)
    _StateTrigger_Meta_.IsActiveProperty = property(get_IsActiveProperty, None)
class StateTriggerBase(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    default_interface: win32more.Microsoft.UI.Xaml.IStateTriggerBase
    _classid_ = 'Microsoft.UI.Xaml.StateTriggerBase'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.StateTriggerBase.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IStateTriggerBaseFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.StateTriggerBase: ...
    @winrt_mixinmethod
    def SetActive(self: win32more.Microsoft.UI.Xaml.IStateTriggerBaseProtected, IsActive: Boolean) -> Void: ...
class Style(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    default_interface: win32more.Microsoft.UI.Xaml.IStyle
    _classid_ = 'Microsoft.UI.Xaml.Style'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.Style.CreateInstance(*args))
        elif len(args) == 1:
            super().__init__(move=win32more.Microsoft.UI.Xaml.Style.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_overload
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.Style: ...
    @CreateInstance.register
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IStyleFactory, targetType: win32more.Windows.UI.Xaml.Interop.TypeName) -> win32more.Microsoft.UI.Xaml.Style: ...
    @winrt_mixinmethod
    def get_IsSealed(self: win32more.Microsoft.UI.Xaml.IStyle) -> Boolean: ...
    @winrt_mixinmethod
    def get_Setters(self: win32more.Microsoft.UI.Xaml.IStyle) -> win32more.Microsoft.UI.Xaml.SetterBaseCollection: ...
    @winrt_mixinmethod
    def get_TargetType(self: win32more.Microsoft.UI.Xaml.IStyle) -> win32more.Windows.UI.Xaml.Interop.TypeName: ...
    @winrt_mixinmethod
    def put_TargetType(self: win32more.Microsoft.UI.Xaml.IStyle, value: win32more.Windows.UI.Xaml.Interop.TypeName) -> Void: ...
    @winrt_mixinmethod
    def get_BasedOn(self: win32more.Microsoft.UI.Xaml.IStyle) -> win32more.Microsoft.UI.Xaml.Style: ...
    @winrt_mixinmethod
    def put_BasedOn(self: win32more.Microsoft.UI.Xaml.IStyle, value: win32more.Microsoft.UI.Xaml.Style) -> Void: ...
    @winrt_mixinmethod
    def Seal(self: win32more.Microsoft.UI.Xaml.IStyle) -> Void: ...
    BasedOn = property(get_BasedOn, put_BasedOn)
    IsSealed = property(get_IsSealed, None)
    Setters = property(get_Setters, None)
    TargetType = property(get_TargetType, put_TargetType)
class SuspendingEventHandler(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{e4beec79-95fd-5841-aceb-01a8a1fb73d0}')
    @winrt_commethod(3)
    def Invoke(self, sender: IInspectable, e: win32more.Windows.ApplicationModel.SuspendingEventArgs) -> Void: ...
class TargetPropertyPath(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.ITargetPropertyPath
    _classid_ = 'Microsoft.UI.Xaml.TargetPropertyPath'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.TargetPropertyPath.CreateInstance(*args))
        elif len(args) == 1:
            super().__init__(move=win32more.Microsoft.UI.Xaml.TargetPropertyPath.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_overload
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.TargetPropertyPath: ...
    @CreateInstance.register
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.ITargetPropertyPathFactory, targetProperty: win32more.Microsoft.UI.Xaml.DependencyProperty) -> win32more.Microsoft.UI.Xaml.TargetPropertyPath: ...
    @winrt_mixinmethod
    def get_Path(self: win32more.Microsoft.UI.Xaml.ITargetPropertyPath) -> win32more.Microsoft.UI.Xaml.PropertyPath: ...
    @winrt_mixinmethod
    def put_Path(self: win32more.Microsoft.UI.Xaml.ITargetPropertyPath, value: win32more.Microsoft.UI.Xaml.PropertyPath) -> Void: ...
    @winrt_mixinmethod
    def get_Target(self: win32more.Microsoft.UI.Xaml.ITargetPropertyPath) -> IInspectable: ...
    @winrt_mixinmethod
    def put_Target(self: win32more.Microsoft.UI.Xaml.ITargetPropertyPath, value: IInspectable) -> Void: ...
    Path = property(get_Path, put_Path)
    Target = property(get_Target, put_Target)
class TextAlignment(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.TextAlignment'
    Center = 0
    Left = 1
    Start = 1
    Right = 2
    End = 2
    Justify = 3
    DetectFromContent = 4
class TextLineBounds(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.TextLineBounds'
    Full = 0
    TrimToCapHeight = 1
    TrimToBaseline = 2
    Tight = 3
class TextReadingOrder(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.TextReadingOrder'
    Default = 0
    UseFlowDirection = 0
    DetectFromContent = 1
class TextTrimming(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.TextTrimming'
    None_ = 0
    CharacterEllipsis = 1
    WordEllipsis = 2
    Clip = 3
class TextWrapping(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.TextWrapping'
    NoWrap = 1
    Wrap = 2
    WrapWholeWords = 3
class Thickness(Structure):
    _name_ = 'Microsoft.UI.Xaml.Thickness'
    Left: Double
    Top: Double
    Right: Double
    Bottom: Double
class ThicknessHelper(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IThicknessHelper
    _classid_ = 'Microsoft.UI.Xaml.ThicknessHelper'
    @winrt_classmethod
    def FromLengths(cls: win32more.Microsoft.UI.Xaml.IThicknessHelperStatics, left: Double, top: Double, right: Double, bottom: Double) -> win32more.Microsoft.UI.Xaml.Thickness: ...
    @winrt_classmethod
    def FromUniformLength(cls: win32more.Microsoft.UI.Xaml.IThicknessHelperStatics, uniformLength: Double) -> win32more.Microsoft.UI.Xaml.Thickness: ...
class TriggerAction(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    default_interface: win32more.Microsoft.UI.Xaml.ITriggerAction
    _classid_ = 'Microsoft.UI.Xaml.TriggerAction'
class TriggerActionCollection(ComPtr):
    extends: IInspectable
    implements: Tuple[SequenceProtocol[win32more.Microsoft.UI.Xaml.TriggerAction]]
    default_interface: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction]
    _classid_ = 'Microsoft.UI.Xaml.TriggerActionCollection'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.TriggerActionCollection.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.TriggerActionCollection: ...
    @winrt_mixinmethod
    def GetAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction], index: UInt32) -> win32more.Microsoft.UI.Xaml.TriggerAction: ...
    @winrt_mixinmethod
    def get_Size(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction]) -> UInt32: ...
    @winrt_mixinmethod
    def GetView(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction]) -> win32more.Windows.Foundation.Collections.IVectorView[win32more.Microsoft.UI.Xaml.TriggerAction]: ...
    @winrt_mixinmethod
    def IndexOf(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction], value: win32more.Microsoft.UI.Xaml.TriggerAction, index: POINTER(UInt32)) -> Boolean: ...
    @winrt_mixinmethod
    def SetAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction], index: UInt32, value: win32more.Microsoft.UI.Xaml.TriggerAction) -> Void: ...
    @winrt_mixinmethod
    def InsertAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction], index: UInt32, value: win32more.Microsoft.UI.Xaml.TriggerAction) -> Void: ...
    @winrt_mixinmethod
    def RemoveAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction], index: UInt32) -> Void: ...
    @winrt_mixinmethod
    def Append(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction], value: win32more.Microsoft.UI.Xaml.TriggerAction) -> Void: ...
    @winrt_mixinmethod
    def RemoveAtEnd(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction]) -> Void: ...
    @winrt_mixinmethod
    def Clear(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction]) -> Void: ...
    @winrt_mixinmethod
    def GetMany(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction], startIndex: UInt32, items: FillArray[win32more.Microsoft.UI.Xaml.TriggerAction]) -> UInt32: ...
    @winrt_mixinmethod
    def ReplaceAll(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerAction], items: PassArray[win32more.Microsoft.UI.Xaml.TriggerAction]) -> Void: ...
    @winrt_mixinmethod
    def First(self: win32more.Windows.Foundation.Collections.IIterable[win32more.Microsoft.UI.Xaml.TriggerAction]) -> win32more.Windows.Foundation.Collections.IIterator[win32more.Microsoft.UI.Xaml.TriggerAction]: ...
    Size = property(get_Size, None)
class TriggerBase(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    default_interface: win32more.Microsoft.UI.Xaml.ITriggerBase
    _classid_ = 'Microsoft.UI.Xaml.TriggerBase'
class TriggerCollection(ComPtr):
    extends: IInspectable
    implements: Tuple[SequenceProtocol[win32more.Microsoft.UI.Xaml.TriggerBase]]
    default_interface: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase]
    _classid_ = 'Microsoft.UI.Xaml.TriggerCollection'
    @winrt_mixinmethod
    def GetAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase], index: UInt32) -> win32more.Microsoft.UI.Xaml.TriggerBase: ...
    @winrt_mixinmethod
    def get_Size(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase]) -> UInt32: ...
    @winrt_mixinmethod
    def GetView(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase]) -> win32more.Windows.Foundation.Collections.IVectorView[win32more.Microsoft.UI.Xaml.TriggerBase]: ...
    @winrt_mixinmethod
    def IndexOf(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase], value: win32more.Microsoft.UI.Xaml.TriggerBase, index: POINTER(UInt32)) -> Boolean: ...
    @winrt_mixinmethod
    def SetAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase], index: UInt32, value: win32more.Microsoft.UI.Xaml.TriggerBase) -> Void: ...
    @winrt_mixinmethod
    def InsertAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase], index: UInt32, value: win32more.Microsoft.UI.Xaml.TriggerBase) -> Void: ...
    @winrt_mixinmethod
    def RemoveAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase], index: UInt32) -> Void: ...
    @winrt_mixinmethod
    def Append(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase], value: win32more.Microsoft.UI.Xaml.TriggerBase) -> Void: ...
    @winrt_mixinmethod
    def RemoveAtEnd(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase]) -> Void: ...
    @winrt_mixinmethod
    def Clear(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase]) -> Void: ...
    @winrt_mixinmethod
    def GetMany(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase], startIndex: UInt32, items: FillArray[win32more.Microsoft.UI.Xaml.TriggerBase]) -> UInt32: ...
    @winrt_mixinmethod
    def ReplaceAll(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.TriggerBase], items: PassArray[win32more.Microsoft.UI.Xaml.TriggerBase]) -> Void: ...
    @winrt_mixinmethod
    def First(self: win32more.Windows.Foundation.Collections.IIterable[win32more.Microsoft.UI.Xaml.TriggerBase]) -> win32more.Windows.Foundation.Collections.IIterator[win32more.Microsoft.UI.Xaml.TriggerBase]: ...
    Size = property(get_Size, None)
class _UIElement_Meta_(ComPtr.__class__):
    pass
class UIElement(ComPtr, metaclass=_UIElement_Meta_):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    default_interface: win32more.Microsoft.UI.Xaml.IUIElement
    _classid_ = 'Microsoft.UI.Xaml.UIElement'
    @winrt_mixinmethod
    def get_DesiredSize(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Size: ...
    @winrt_mixinmethod
    def get_AllowDrop(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_AllowDrop(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_Opacity(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Double: ...
    @winrt_mixinmethod
    def put_Opacity(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_Clip(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Media.RectangleGeometry: ...
    @winrt_mixinmethod
    def put_Clip(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Media.RectangleGeometry) -> Void: ...
    @winrt_mixinmethod
    def get_RenderTransform(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Media.Transform: ...
    @winrt_mixinmethod
    def put_RenderTransform(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Media.Transform) -> Void: ...
    @winrt_mixinmethod
    def get_Projection(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Media.Projection: ...
    @winrt_mixinmethod
    def put_Projection(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Media.Projection) -> Void: ...
    @winrt_mixinmethod
    def get_Transform3D(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Media.Media3D.Transform3D: ...
    @winrt_mixinmethod
    def put_Transform3D(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Media.Media3D.Transform3D) -> Void: ...
    @winrt_mixinmethod
    def get_RenderTransformOrigin(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Point: ...
    @winrt_mixinmethod
    def put_RenderTransformOrigin(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Windows.Foundation.Point) -> Void: ...
    @winrt_mixinmethod
    def get_IsHitTestVisible(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsHitTestVisible(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_Visibility(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Visibility: ...
    @winrt_mixinmethod
    def put_Visibility(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Visibility) -> Void: ...
    @winrt_mixinmethod
    def get_RenderSize(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Size: ...
    @winrt_mixinmethod
    def get_UseLayoutRounding(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_UseLayoutRounding(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_Transitions(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Media.Animation.TransitionCollection: ...
    @winrt_mixinmethod
    def put_Transitions(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Media.Animation.TransitionCollection) -> Void: ...
    @winrt_mixinmethod
    def get_CacheMode(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Media.CacheMode: ...
    @winrt_mixinmethod
    def put_CacheMode(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Media.CacheMode) -> Void: ...
    @winrt_mixinmethod
    def get_IsTapEnabled(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsTapEnabled(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_IsDoubleTapEnabled(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsDoubleTapEnabled(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_CanDrag(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_CanDrag(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_IsRightTapEnabled(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsRightTapEnabled(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_IsHoldingEnabled(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsHoldingEnabled(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_ManipulationMode(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Input.ManipulationModes: ...
    @winrt_mixinmethod
    def put_ManipulationMode(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Input.ManipulationModes) -> Void: ...
    @winrt_mixinmethod
    def get_PointerCaptures(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Collections.IVectorView[win32more.Microsoft.UI.Xaml.Input.Pointer]: ...
    @winrt_mixinmethod
    def get_ContextFlyout(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Controls.Primitives.FlyoutBase: ...
    @winrt_mixinmethod
    def put_ContextFlyout(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Controls.Primitives.FlyoutBase) -> Void: ...
    @winrt_mixinmethod
    def get_CompositeMode(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Media.ElementCompositeMode: ...
    @winrt_mixinmethod
    def put_CompositeMode(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Media.ElementCompositeMode) -> Void: ...
    @winrt_mixinmethod
    def get_Lights(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.Media.XamlLight]: ...
    @winrt_mixinmethod
    def get_CanBeScrollAnchor(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_CanBeScrollAnchor(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_ExitDisplayModeOnAccessKeyInvoked(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_ExitDisplayModeOnAccessKeyInvoked(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_IsAccessKeyScope(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsAccessKeyScope(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_AccessKeyScopeOwner(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_mixinmethod
    def put_AccessKeyScopeOwner(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_mixinmethod
    def get_AccessKey(self: win32more.Microsoft.UI.Xaml.IUIElement) -> hstr: ...
    @winrt_mixinmethod
    def put_AccessKey(self: win32more.Microsoft.UI.Xaml.IUIElement, value: hstr) -> Void: ...
    @winrt_mixinmethod
    def get_KeyTipPlacementMode(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Input.KeyTipPlacementMode: ...
    @winrt_mixinmethod
    def put_KeyTipPlacementMode(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Input.KeyTipPlacementMode) -> Void: ...
    @winrt_mixinmethod
    def get_KeyTipHorizontalOffset(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Double: ...
    @winrt_mixinmethod
    def put_KeyTipHorizontalOffset(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_KeyTipVerticalOffset(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Double: ...
    @winrt_mixinmethod
    def put_KeyTipVerticalOffset(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_KeyTipTarget(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_mixinmethod
    def put_KeyTipTarget(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_mixinmethod
    def get_XYFocusKeyboardNavigation(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Input.XYFocusKeyboardNavigationMode: ...
    @winrt_mixinmethod
    def put_XYFocusKeyboardNavigation(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Input.XYFocusKeyboardNavigationMode) -> Void: ...
    @winrt_mixinmethod
    def get_XYFocusUpNavigationStrategy(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy: ...
    @winrt_mixinmethod
    def put_XYFocusUpNavigationStrategy(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy) -> Void: ...
    @winrt_mixinmethod
    def get_XYFocusDownNavigationStrategy(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy: ...
    @winrt_mixinmethod
    def put_XYFocusDownNavigationStrategy(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy) -> Void: ...
    @winrt_mixinmethod
    def get_XYFocusLeftNavigationStrategy(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy: ...
    @winrt_mixinmethod
    def put_XYFocusLeftNavigationStrategy(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy) -> Void: ...
    @winrt_mixinmethod
    def get_XYFocusRightNavigationStrategy(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy: ...
    @winrt_mixinmethod
    def put_XYFocusRightNavigationStrategy(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Input.XYFocusNavigationStrategy) -> Void: ...
    @winrt_mixinmethod
    def get_KeyboardAccelerators(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.Input.KeyboardAccelerator]: ...
    @winrt_mixinmethod
    def get_KeyboardAcceleratorPlacementTarget(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_mixinmethod
    def put_KeyboardAcceleratorPlacementTarget(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_mixinmethod
    def get_KeyboardAcceleratorPlacementMode(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Input.KeyboardAcceleratorPlacementMode: ...
    @winrt_mixinmethod
    def put_KeyboardAcceleratorPlacementMode(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Input.KeyboardAcceleratorPlacementMode) -> Void: ...
    @winrt_mixinmethod
    def get_HighContrastAdjustment(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.ElementHighContrastAdjustment: ...
    @winrt_mixinmethod
    def put_HighContrastAdjustment(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.ElementHighContrastAdjustment) -> Void: ...
    @winrt_mixinmethod
    def get_TabFocusNavigation(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Input.KeyboardNavigationMode: ...
    @winrt_mixinmethod
    def put_TabFocusNavigation(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Input.KeyboardNavigationMode) -> Void: ...
    @winrt_mixinmethod
    def get_OpacityTransition(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.ScalarTransition: ...
    @winrt_mixinmethod
    def put_OpacityTransition(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.ScalarTransition) -> Void: ...
    @winrt_mixinmethod
    def get_Translation(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Numerics.Vector3: ...
    @winrt_mixinmethod
    def put_Translation(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Windows.Foundation.Numerics.Vector3) -> Void: ...
    @winrt_mixinmethod
    def get_TranslationTransition(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Vector3Transition: ...
    @winrt_mixinmethod
    def put_TranslationTransition(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Vector3Transition) -> Void: ...
    @winrt_mixinmethod
    def get_Rotation(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Single: ...
    @winrt_mixinmethod
    def put_Rotation(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Single) -> Void: ...
    @winrt_mixinmethod
    def get_RotationTransition(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.ScalarTransition: ...
    @winrt_mixinmethod
    def put_RotationTransition(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.ScalarTransition) -> Void: ...
    @winrt_mixinmethod
    def get_Scale(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Numerics.Vector3: ...
    @winrt_mixinmethod
    def put_Scale(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Windows.Foundation.Numerics.Vector3) -> Void: ...
    @winrt_mixinmethod
    def get_ScaleTransition(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Vector3Transition: ...
    @winrt_mixinmethod
    def put_ScaleTransition(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Vector3Transition) -> Void: ...
    @winrt_mixinmethod
    def get_TransformMatrix(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Numerics.Matrix4x4: ...
    @winrt_mixinmethod
    def put_TransformMatrix(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Windows.Foundation.Numerics.Matrix4x4) -> Void: ...
    @winrt_mixinmethod
    def get_CenterPoint(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Numerics.Vector3: ...
    @winrt_mixinmethod
    def put_CenterPoint(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Windows.Foundation.Numerics.Vector3) -> Void: ...
    @winrt_mixinmethod
    def get_RotationAxis(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Numerics.Vector3: ...
    @winrt_mixinmethod
    def put_RotationAxis(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Windows.Foundation.Numerics.Vector3) -> Void: ...
    @winrt_mixinmethod
    def get_ActualOffset(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Numerics.Vector3: ...
    @winrt_mixinmethod
    def get_ActualSize(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Windows.Foundation.Numerics.Vector2: ...
    @winrt_mixinmethod
    def get_XamlRoot(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.XamlRoot: ...
    @winrt_mixinmethod
    def put_XamlRoot(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.XamlRoot) -> Void: ...
    @winrt_mixinmethod
    def get_Shadow(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.Media.Shadow: ...
    @winrt_mixinmethod
    def put_Shadow(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Media.Shadow) -> Void: ...
    @winrt_mixinmethod
    def get_RasterizationScale(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Double: ...
    @winrt_mixinmethod
    def put_RasterizationScale(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Double) -> Void: ...
    @winrt_mixinmethod
    def get_FocusState(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.FocusState: ...
    @winrt_mixinmethod
    def get_UseSystemFocusVisuals(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_UseSystemFocusVisuals(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_XYFocusLeft(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_mixinmethod
    def put_XYFocusLeft(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_mixinmethod
    def get_XYFocusRight(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_mixinmethod
    def put_XYFocusRight(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_mixinmethod
    def get_XYFocusUp(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_mixinmethod
    def put_XYFocusUp(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_mixinmethod
    def get_XYFocusDown(self: win32more.Microsoft.UI.Xaml.IUIElement) -> win32more.Microsoft.UI.Xaml.DependencyObject: ...
    @winrt_mixinmethod
    def put_XYFocusDown(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.DependencyObject) -> Void: ...
    @winrt_mixinmethod
    def get_IsTabStop(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def put_IsTabStop(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_TabIndex(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Int32: ...
    @winrt_mixinmethod
    def put_TabIndex(self: win32more.Microsoft.UI.Xaml.IUIElement, value: Int32) -> Void: ...
    @winrt_mixinmethod
    def add_KeyUp(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.KeyEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_KeyUp(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_KeyDown(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.KeyEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_KeyDown(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_GotFocus(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.RoutedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_GotFocus(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_LostFocus(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.RoutedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_LostFocus(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_DragStarting(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.DragStartingEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_DragStarting(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_DropCompleted(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.DropCompletedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_DropCompleted(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_CharacterReceived(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.CharacterReceivedRoutedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_CharacterReceived(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_DragEnter(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.DragEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_DragEnter(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_DragLeave(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.DragEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_DragLeave(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_DragOver(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.DragEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_DragOver(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_Drop(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.DragEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_Drop(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_PointerPressed(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_PointerPressed(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_PointerMoved(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_PointerMoved(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_PointerReleased(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_PointerReleased(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_PointerEntered(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_PointerEntered(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_PointerExited(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_PointerExited(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_PointerCaptureLost(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_PointerCaptureLost(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_PointerCanceled(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_PointerCanceled(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_PointerWheelChanged(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.PointerEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_PointerWheelChanged(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_Tapped(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.TappedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_Tapped(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_DoubleTapped(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.DoubleTappedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_DoubleTapped(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_Holding(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.HoldingEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_Holding(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_ContextRequested(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.ContextRequestedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_ContextRequested(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_ContextCanceled(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.RoutedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_ContextCanceled(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_RightTapped(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.RightTappedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_RightTapped(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_ManipulationStarting(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.ManipulationStartingEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_ManipulationStarting(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_ManipulationInertiaStarting(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.ManipulationInertiaStartingEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_ManipulationInertiaStarting(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_ManipulationStarted(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.ManipulationStartedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_ManipulationStarted(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_ManipulationDelta(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.ManipulationDeltaEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_ManipulationDelta(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_ManipulationCompleted(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.ManipulationCompletedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_ManipulationCompleted(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_AccessKeyDisplayRequested(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.AccessKeyDisplayRequestedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_AccessKeyDisplayRequested(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_AccessKeyDisplayDismissed(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.AccessKeyDisplayDismissedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_AccessKeyDisplayDismissed(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_AccessKeyInvoked(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.AccessKeyInvokedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_AccessKeyInvoked(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_ProcessKeyboardAccelerators(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.ProcessKeyboardAcceleratorEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_ProcessKeyboardAccelerators(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_GettingFocus(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.GettingFocusEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_GettingFocus(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_LosingFocus(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.LosingFocusEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_LosingFocus(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_NoFocusCandidateFound(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.Input.NoFocusCandidateFoundEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_NoFocusCandidateFound(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_PreviewKeyDown(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.KeyEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_PreviewKeyDown(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_PreviewKeyUp(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Microsoft.UI.Xaml.Input.KeyEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_PreviewKeyUp(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_BringIntoViewRequested(self: win32more.Microsoft.UI.Xaml.IUIElement, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.UIElement, win32more.Microsoft.UI.Xaml.BringIntoViewRequestedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_BringIntoViewRequested(self: win32more.Microsoft.UI.Xaml.IUIElement, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def Measure(self: win32more.Microsoft.UI.Xaml.IUIElement, availableSize: win32more.Windows.Foundation.Size) -> Void: ...
    @winrt_mixinmethod
    def Arrange(self: win32more.Microsoft.UI.Xaml.IUIElement, finalRect: win32more.Windows.Foundation.Rect) -> Void: ...
    @winrt_mixinmethod
    def CapturePointer(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Input.Pointer) -> Boolean: ...
    @winrt_mixinmethod
    def ReleasePointerCapture(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.Input.Pointer) -> Void: ...
    @winrt_mixinmethod
    def ReleasePointerCaptures(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Void: ...
    @winrt_mixinmethod
    def AddHandler(self: win32more.Microsoft.UI.Xaml.IUIElement, routedEvent: win32more.Microsoft.UI.Xaml.RoutedEvent, handler: IInspectable, handledEventsToo: Boolean) -> Void: ...
    @winrt_mixinmethod
    def RemoveHandler(self: win32more.Microsoft.UI.Xaml.IUIElement, routedEvent: win32more.Microsoft.UI.Xaml.RoutedEvent, handler: IInspectable) -> Void: ...
    @winrt_mixinmethod
    def TransformToVisual(self: win32more.Microsoft.UI.Xaml.IUIElement, visual: win32more.Microsoft.UI.Xaml.UIElement) -> win32more.Microsoft.UI.Xaml.Media.GeneralTransform: ...
    @winrt_mixinmethod
    def InvalidateMeasure(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Void: ...
    @winrt_mixinmethod
    def InvalidateArrange(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Void: ...
    @winrt_mixinmethod
    def UpdateLayout(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Void: ...
    @winrt_mixinmethod
    def CancelDirectManipulations(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Boolean: ...
    @winrt_mixinmethod
    def StartDragAsync(self: win32more.Microsoft.UI.Xaml.IUIElement, pointerPoint: win32more.Microsoft.UI.Input.PointerPoint) -> win32more.Windows.Foundation.IAsyncOperation[win32more.Windows.ApplicationModel.DataTransfer.DataPackageOperation]: ...
    @winrt_mixinmethod
    def StartBringIntoView(self: win32more.Microsoft.UI.Xaml.IUIElement) -> Void: ...
    @winrt_mixinmethod
    def StartBringIntoViewWithOptions(self: win32more.Microsoft.UI.Xaml.IUIElement, options: win32more.Microsoft.UI.Xaml.BringIntoViewOptions) -> Void: ...
    @winrt_mixinmethod
    def TryInvokeKeyboardAccelerator(self: win32more.Microsoft.UI.Xaml.IUIElement, args: win32more.Microsoft.UI.Xaml.Input.ProcessKeyboardAcceleratorEventArgs) -> Void: ...
    @winrt_mixinmethod
    def Focus(self: win32more.Microsoft.UI.Xaml.IUIElement, value: win32more.Microsoft.UI.Xaml.FocusState) -> Boolean: ...
    @winrt_mixinmethod
    def StartAnimation(self: win32more.Microsoft.UI.Xaml.IUIElement, animation: win32more.Microsoft.UI.Composition.ICompositionAnimationBase) -> Void: ...
    @winrt_mixinmethod
    def StopAnimation(self: win32more.Microsoft.UI.Xaml.IUIElement, animation: win32more.Microsoft.UI.Composition.ICompositionAnimationBase) -> Void: ...
    @winrt_mixinmethod
    def get_ProtectedCursor(self: win32more.Microsoft.UI.Xaml.IUIElementProtected) -> win32more.Microsoft.UI.Input.InputCursor: ...
    @winrt_mixinmethod
    def put_ProtectedCursor(self: win32more.Microsoft.UI.Xaml.IUIElementProtected, value: win32more.Microsoft.UI.Input.InputCursor) -> Void: ...
    @winrt_mixinmethod
    def OnCreateAutomationPeer(self: win32more.Microsoft.UI.Xaml.IUIElementOverrides) -> win32more.Microsoft.UI.Xaml.Automation.Peers.AutomationPeer: ...
    @winrt_mixinmethod
    def OnDisconnectVisualChildren(self: win32more.Microsoft.UI.Xaml.IUIElementOverrides) -> Void: ...
    @winrt_mixinmethod
    def FindSubElementsForTouchTargeting(self: win32more.Microsoft.UI.Xaml.IUIElementOverrides, point: win32more.Windows.Foundation.Point, boundingRect: win32more.Windows.Foundation.Rect) -> win32more.Windows.Foundation.Collections.IIterable[win32more.Windows.Foundation.Collections.IIterable[win32more.Windows.Foundation.Point]]: ...
    @winrt_mixinmethod
    def GetChildrenInTabFocusOrder(self: win32more.Microsoft.UI.Xaml.IUIElementOverrides) -> win32more.Windows.Foundation.Collections.IIterable[win32more.Microsoft.UI.Xaml.DependencyObject]: ...
    @winrt_mixinmethod
    def OnKeyboardAcceleratorInvoked(self: win32more.Microsoft.UI.Xaml.IUIElementOverrides, args: win32more.Microsoft.UI.Xaml.Input.KeyboardAcceleratorInvokedEventArgs) -> Void: ...
    @winrt_mixinmethod
    def OnProcessKeyboardAccelerators(self: win32more.Microsoft.UI.Xaml.IUIElementOverrides, args: win32more.Microsoft.UI.Xaml.Input.ProcessKeyboardAcceleratorEventArgs) -> Void: ...
    @winrt_mixinmethod
    def OnBringIntoViewRequested(self: win32more.Microsoft.UI.Xaml.IUIElementOverrides, e: win32more.Microsoft.UI.Xaml.BringIntoViewRequestedEventArgs) -> Void: ...
    @winrt_mixinmethod
    def PopulatePropertyInfoOverride(self: win32more.Microsoft.UI.Xaml.IUIElementOverrides, propertyName: hstr, animationPropertyInfo: win32more.Microsoft.UI.Composition.AnimationPropertyInfo) -> Void: ...
    @winrt_mixinmethod
    def PopulatePropertyInfo(self: win32more.Microsoft.UI.Composition.IAnimationObject, propertyName: hstr, propertyInfo: win32more.Microsoft.UI.Composition.AnimationPropertyInfo) -> Void: ...
    @winrt_mixinmethod
    def GetVisualInternal(self: win32more.Microsoft.UI.Composition.IVisualElement2) -> win32more.Microsoft.UI.Composition.Visual: ...
    @winrt_classmethod
    def get_KeyDownEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_KeyUpEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_PointerEnteredEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_PointerPressedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_PointerMovedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_PointerReleasedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_PointerExitedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_PointerCaptureLostEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_PointerCanceledEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_PointerWheelChangedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_TappedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_DoubleTappedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_HoldingEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_RightTappedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_ManipulationStartingEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_ManipulationInertiaStartingEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_ManipulationStartedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_ManipulationDeltaEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_ManipulationCompletedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_DragEnterEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_DragLeaveEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_DragOverEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_DropEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_GettingFocusEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_LosingFocusEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_NoFocusCandidateFoundEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_PreviewKeyDownEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_CharacterReceivedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_PreviewKeyUpEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_BringIntoViewRequestedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_ContextRequestedEvent(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.RoutedEvent: ...
    @winrt_classmethod
    def get_AllowDropProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_OpacityProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_ClipProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_RenderTransformProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_ProjectionProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_Transform3DProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_RenderTransformOriginProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_IsHitTestVisibleProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_VisibilityProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_UseLayoutRoundingProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_TransitionsProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_CacheModeProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_IsTapEnabledProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_IsDoubleTapEnabledProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_CanDragProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_IsRightTapEnabledProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_IsHoldingEnabledProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_ManipulationModeProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_PointerCapturesProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_ContextFlyoutProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_CompositeModeProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_LightsProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_CanBeScrollAnchorProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_ExitDisplayModeOnAccessKeyInvokedProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_IsAccessKeyScopeProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_AccessKeyScopeOwnerProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_AccessKeyProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_KeyTipPlacementModeProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_KeyTipHorizontalOffsetProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_KeyTipVerticalOffsetProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_KeyTipTargetProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_XYFocusKeyboardNavigationProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_XYFocusUpNavigationStrategyProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_XYFocusDownNavigationStrategyProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_XYFocusLeftNavigationStrategyProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_XYFocusRightNavigationStrategyProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_KeyboardAcceleratorPlacementTargetProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_KeyboardAcceleratorPlacementModeProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_HighContrastAdjustmentProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_TabFocusNavigationProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_ShadowProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_FocusStateProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_UseSystemFocusVisualsProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_XYFocusLeftProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_XYFocusRightProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_XYFocusUpProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_XYFocusDownProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_IsTabStopProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def get_TabIndexProperty(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def TryStartDirectManipulation(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics, value: win32more.Microsoft.UI.Xaml.Input.Pointer) -> Boolean: ...
    @winrt_classmethod
    def RegisterAsScrollPort(cls: win32more.Microsoft.UI.Xaml.IUIElementStatics, element: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    AccessKey = property(get_AccessKey, put_AccessKey)
    AccessKeyScopeOwner = property(get_AccessKeyScopeOwner, put_AccessKeyScopeOwner)
    ActualOffset = property(get_ActualOffset, None)
    ActualSize = property(get_ActualSize, None)
    AllowDrop = property(get_AllowDrop, put_AllowDrop)
    CacheMode = property(get_CacheMode, put_CacheMode)
    CanBeScrollAnchor = property(get_CanBeScrollAnchor, put_CanBeScrollAnchor)
    CanDrag = property(get_CanDrag, put_CanDrag)
    CenterPoint = property(get_CenterPoint, put_CenterPoint)
    Clip = property(get_Clip, put_Clip)
    CompositeMode = property(get_CompositeMode, put_CompositeMode)
    ContextFlyout = property(get_ContextFlyout, put_ContextFlyout)
    DesiredSize = property(get_DesiredSize, None)
    ExitDisplayModeOnAccessKeyInvoked = property(get_ExitDisplayModeOnAccessKeyInvoked, put_ExitDisplayModeOnAccessKeyInvoked)
    FocusState = property(get_FocusState, None)
    HighContrastAdjustment = property(get_HighContrastAdjustment, put_HighContrastAdjustment)
    IsAccessKeyScope = property(get_IsAccessKeyScope, put_IsAccessKeyScope)
    IsDoubleTapEnabled = property(get_IsDoubleTapEnabled, put_IsDoubleTapEnabled)
    IsHitTestVisible = property(get_IsHitTestVisible, put_IsHitTestVisible)
    IsHoldingEnabled = property(get_IsHoldingEnabled, put_IsHoldingEnabled)
    IsRightTapEnabled = property(get_IsRightTapEnabled, put_IsRightTapEnabled)
    IsTabStop = property(get_IsTabStop, put_IsTabStop)
    IsTapEnabled = property(get_IsTapEnabled, put_IsTapEnabled)
    KeyTipHorizontalOffset = property(get_KeyTipHorizontalOffset, put_KeyTipHorizontalOffset)
    KeyTipPlacementMode = property(get_KeyTipPlacementMode, put_KeyTipPlacementMode)
    KeyTipTarget = property(get_KeyTipTarget, put_KeyTipTarget)
    KeyTipVerticalOffset = property(get_KeyTipVerticalOffset, put_KeyTipVerticalOffset)
    KeyboardAcceleratorPlacementMode = property(get_KeyboardAcceleratorPlacementMode, put_KeyboardAcceleratorPlacementMode)
    KeyboardAcceleratorPlacementTarget = property(get_KeyboardAcceleratorPlacementTarget, put_KeyboardAcceleratorPlacementTarget)
    KeyboardAccelerators = property(get_KeyboardAccelerators, None)
    Lights = property(get_Lights, None)
    ManipulationMode = property(get_ManipulationMode, put_ManipulationMode)
    Opacity = property(get_Opacity, put_Opacity)
    OpacityTransition = property(get_OpacityTransition, put_OpacityTransition)
    PointerCaptures = property(get_PointerCaptures, None)
    Projection = property(get_Projection, put_Projection)
    ProtectedCursor = property(get_ProtectedCursor, put_ProtectedCursor)
    RasterizationScale = property(get_RasterizationScale, put_RasterizationScale)
    RenderSize = property(get_RenderSize, None)
    RenderTransform = property(get_RenderTransform, put_RenderTransform)
    RenderTransformOrigin = property(get_RenderTransformOrigin, put_RenderTransformOrigin)
    Rotation = property(get_Rotation, put_Rotation)
    RotationAxis = property(get_RotationAxis, put_RotationAxis)
    RotationTransition = property(get_RotationTransition, put_RotationTransition)
    Scale = property(get_Scale, put_Scale)
    ScaleTransition = property(get_ScaleTransition, put_ScaleTransition)
    Shadow = property(get_Shadow, put_Shadow)
    TabFocusNavigation = property(get_TabFocusNavigation, put_TabFocusNavigation)
    TabIndex = property(get_TabIndex, put_TabIndex)
    Transform3D = property(get_Transform3D, put_Transform3D)
    TransformMatrix = property(get_TransformMatrix, put_TransformMatrix)
    Transitions = property(get_Transitions, put_Transitions)
    Translation = property(get_Translation, put_Translation)
    TranslationTransition = property(get_TranslationTransition, put_TranslationTransition)
    UseLayoutRounding = property(get_UseLayoutRounding, put_UseLayoutRounding)
    UseSystemFocusVisuals = property(get_UseSystemFocusVisuals, put_UseSystemFocusVisuals)
    Visibility = property(get_Visibility, put_Visibility)
    XYFocusDown = property(get_XYFocusDown, put_XYFocusDown)
    XYFocusDownNavigationStrategy = property(get_XYFocusDownNavigationStrategy, put_XYFocusDownNavigationStrategy)
    XYFocusKeyboardNavigation = property(get_XYFocusKeyboardNavigation, put_XYFocusKeyboardNavigation)
    XYFocusLeft = property(get_XYFocusLeft, put_XYFocusLeft)
    XYFocusLeftNavigationStrategy = property(get_XYFocusLeftNavigationStrategy, put_XYFocusLeftNavigationStrategy)
    XYFocusRight = property(get_XYFocusRight, put_XYFocusRight)
    XYFocusRightNavigationStrategy = property(get_XYFocusRightNavigationStrategy, put_XYFocusRightNavigationStrategy)
    XYFocusUp = property(get_XYFocusUp, put_XYFocusUp)
    XYFocusUpNavigationStrategy = property(get_XYFocusUpNavigationStrategy, put_XYFocusUpNavigationStrategy)
    XamlRoot = property(get_XamlRoot, put_XamlRoot)
    _UIElement_Meta_.AccessKeyProperty = property(get_AccessKeyProperty, None)
    _UIElement_Meta_.AccessKeyScopeOwnerProperty = property(get_AccessKeyScopeOwnerProperty, None)
    _UIElement_Meta_.AllowDropProperty = property(get_AllowDropProperty, None)
    _UIElement_Meta_.BringIntoViewRequestedEvent = property(get_BringIntoViewRequestedEvent, None)
    _UIElement_Meta_.CacheModeProperty = property(get_CacheModeProperty, None)
    _UIElement_Meta_.CanBeScrollAnchorProperty = property(get_CanBeScrollAnchorProperty, None)
    _UIElement_Meta_.CanDragProperty = property(get_CanDragProperty, None)
    _UIElement_Meta_.CharacterReceivedEvent = property(get_CharacterReceivedEvent, None)
    _UIElement_Meta_.ClipProperty = property(get_ClipProperty, None)
    _UIElement_Meta_.CompositeModeProperty = property(get_CompositeModeProperty, None)
    _UIElement_Meta_.ContextFlyoutProperty = property(get_ContextFlyoutProperty, None)
    _UIElement_Meta_.ContextRequestedEvent = property(get_ContextRequestedEvent, None)
    _UIElement_Meta_.DoubleTappedEvent = property(get_DoubleTappedEvent, None)
    _UIElement_Meta_.DragEnterEvent = property(get_DragEnterEvent, None)
    _UIElement_Meta_.DragLeaveEvent = property(get_DragLeaveEvent, None)
    _UIElement_Meta_.DragOverEvent = property(get_DragOverEvent, None)
    _UIElement_Meta_.DropEvent = property(get_DropEvent, None)
    _UIElement_Meta_.ExitDisplayModeOnAccessKeyInvokedProperty = property(get_ExitDisplayModeOnAccessKeyInvokedProperty, None)
    _UIElement_Meta_.FocusStateProperty = property(get_FocusStateProperty, None)
    _UIElement_Meta_.GettingFocusEvent = property(get_GettingFocusEvent, None)
    _UIElement_Meta_.HighContrastAdjustmentProperty = property(get_HighContrastAdjustmentProperty, None)
    _UIElement_Meta_.HoldingEvent = property(get_HoldingEvent, None)
    _UIElement_Meta_.IsAccessKeyScopeProperty = property(get_IsAccessKeyScopeProperty, None)
    _UIElement_Meta_.IsDoubleTapEnabledProperty = property(get_IsDoubleTapEnabledProperty, None)
    _UIElement_Meta_.IsHitTestVisibleProperty = property(get_IsHitTestVisibleProperty, None)
    _UIElement_Meta_.IsHoldingEnabledProperty = property(get_IsHoldingEnabledProperty, None)
    _UIElement_Meta_.IsRightTapEnabledProperty = property(get_IsRightTapEnabledProperty, None)
    _UIElement_Meta_.IsTabStopProperty = property(get_IsTabStopProperty, None)
    _UIElement_Meta_.IsTapEnabledProperty = property(get_IsTapEnabledProperty, None)
    _UIElement_Meta_.KeyDownEvent = property(get_KeyDownEvent, None)
    _UIElement_Meta_.KeyTipHorizontalOffsetProperty = property(get_KeyTipHorizontalOffsetProperty, None)
    _UIElement_Meta_.KeyTipPlacementModeProperty = property(get_KeyTipPlacementModeProperty, None)
    _UIElement_Meta_.KeyTipTargetProperty = property(get_KeyTipTargetProperty, None)
    _UIElement_Meta_.KeyTipVerticalOffsetProperty = property(get_KeyTipVerticalOffsetProperty, None)
    _UIElement_Meta_.KeyUpEvent = property(get_KeyUpEvent, None)
    _UIElement_Meta_.KeyboardAcceleratorPlacementModeProperty = property(get_KeyboardAcceleratorPlacementModeProperty, None)
    _UIElement_Meta_.KeyboardAcceleratorPlacementTargetProperty = property(get_KeyboardAcceleratorPlacementTargetProperty, None)
    _UIElement_Meta_.LightsProperty = property(get_LightsProperty, None)
    _UIElement_Meta_.LosingFocusEvent = property(get_LosingFocusEvent, None)
    _UIElement_Meta_.ManipulationCompletedEvent = property(get_ManipulationCompletedEvent, None)
    _UIElement_Meta_.ManipulationDeltaEvent = property(get_ManipulationDeltaEvent, None)
    _UIElement_Meta_.ManipulationInertiaStartingEvent = property(get_ManipulationInertiaStartingEvent, None)
    _UIElement_Meta_.ManipulationModeProperty = property(get_ManipulationModeProperty, None)
    _UIElement_Meta_.ManipulationStartedEvent = property(get_ManipulationStartedEvent, None)
    _UIElement_Meta_.ManipulationStartingEvent = property(get_ManipulationStartingEvent, None)
    _UIElement_Meta_.NoFocusCandidateFoundEvent = property(get_NoFocusCandidateFoundEvent, None)
    _UIElement_Meta_.OpacityProperty = property(get_OpacityProperty, None)
    _UIElement_Meta_.PointerCanceledEvent = property(get_PointerCanceledEvent, None)
    _UIElement_Meta_.PointerCaptureLostEvent = property(get_PointerCaptureLostEvent, None)
    _UIElement_Meta_.PointerCapturesProperty = property(get_PointerCapturesProperty, None)
    _UIElement_Meta_.PointerEnteredEvent = property(get_PointerEnteredEvent, None)
    _UIElement_Meta_.PointerExitedEvent = property(get_PointerExitedEvent, None)
    _UIElement_Meta_.PointerMovedEvent = property(get_PointerMovedEvent, None)
    _UIElement_Meta_.PointerPressedEvent = property(get_PointerPressedEvent, None)
    _UIElement_Meta_.PointerReleasedEvent = property(get_PointerReleasedEvent, None)
    _UIElement_Meta_.PointerWheelChangedEvent = property(get_PointerWheelChangedEvent, None)
    _UIElement_Meta_.PreviewKeyDownEvent = property(get_PreviewKeyDownEvent, None)
    _UIElement_Meta_.PreviewKeyUpEvent = property(get_PreviewKeyUpEvent, None)
    _UIElement_Meta_.ProjectionProperty = property(get_ProjectionProperty, None)
    _UIElement_Meta_.RenderTransformOriginProperty = property(get_RenderTransformOriginProperty, None)
    _UIElement_Meta_.RenderTransformProperty = property(get_RenderTransformProperty, None)
    _UIElement_Meta_.RightTappedEvent = property(get_RightTappedEvent, None)
    _UIElement_Meta_.ShadowProperty = property(get_ShadowProperty, None)
    _UIElement_Meta_.TabFocusNavigationProperty = property(get_TabFocusNavigationProperty, None)
    _UIElement_Meta_.TabIndexProperty = property(get_TabIndexProperty, None)
    _UIElement_Meta_.TappedEvent = property(get_TappedEvent, None)
    _UIElement_Meta_.Transform3DProperty = property(get_Transform3DProperty, None)
    _UIElement_Meta_.TransitionsProperty = property(get_TransitionsProperty, None)
    _UIElement_Meta_.UseLayoutRoundingProperty = property(get_UseLayoutRoundingProperty, None)
    _UIElement_Meta_.UseSystemFocusVisualsProperty = property(get_UseSystemFocusVisualsProperty, None)
    _UIElement_Meta_.VisibilityProperty = property(get_VisibilityProperty, None)
    _UIElement_Meta_.XYFocusDownNavigationStrategyProperty = property(get_XYFocusDownNavigationStrategyProperty, None)
    _UIElement_Meta_.XYFocusDownProperty = property(get_XYFocusDownProperty, None)
    _UIElement_Meta_.XYFocusKeyboardNavigationProperty = property(get_XYFocusKeyboardNavigationProperty, None)
    _UIElement_Meta_.XYFocusLeftNavigationStrategyProperty = property(get_XYFocusLeftNavigationStrategyProperty, None)
    _UIElement_Meta_.XYFocusLeftProperty = property(get_XYFocusLeftProperty, None)
    _UIElement_Meta_.XYFocusRightNavigationStrategyProperty = property(get_XYFocusRightNavigationStrategyProperty, None)
    _UIElement_Meta_.XYFocusRightProperty = property(get_XYFocusRightProperty, None)
    _UIElement_Meta_.XYFocusUpNavigationStrategyProperty = property(get_XYFocusUpNavigationStrategyProperty, None)
    _UIElement_Meta_.XYFocusUpProperty = property(get_XYFocusUpProperty, None)
    AccessKeyDisplayDismissed = event(add_AccessKeyDisplayDismissed, remove_AccessKeyDisplayDismissed)
    AccessKeyDisplayRequested = event(add_AccessKeyDisplayRequested, remove_AccessKeyDisplayRequested)
    AccessKeyInvoked = event(add_AccessKeyInvoked, remove_AccessKeyInvoked)
    BringIntoViewRequested = event(add_BringIntoViewRequested, remove_BringIntoViewRequested)
    CharacterReceived = event(add_CharacterReceived, remove_CharacterReceived)
    ContextCanceled = event(add_ContextCanceled, remove_ContextCanceled)
    ContextRequested = event(add_ContextRequested, remove_ContextRequested)
    DoubleTapped = event(add_DoubleTapped, remove_DoubleTapped)
    DragEnter = event(add_DragEnter, remove_DragEnter)
    DragLeave = event(add_DragLeave, remove_DragLeave)
    DragOver = event(add_DragOver, remove_DragOver)
    DragStarting = event(add_DragStarting, remove_DragStarting)
    Drop = event(add_Drop, remove_Drop)
    DropCompleted = event(add_DropCompleted, remove_DropCompleted)
    GettingFocus = event(add_GettingFocus, remove_GettingFocus)
    GotFocus = event(add_GotFocus, remove_GotFocus)
    Holding = event(add_Holding, remove_Holding)
    KeyDown = event(add_KeyDown, remove_KeyDown)
    KeyUp = event(add_KeyUp, remove_KeyUp)
    LosingFocus = event(add_LosingFocus, remove_LosingFocus)
    LostFocus = event(add_LostFocus, remove_LostFocus)
    ManipulationCompleted = event(add_ManipulationCompleted, remove_ManipulationCompleted)
    ManipulationDelta = event(add_ManipulationDelta, remove_ManipulationDelta)
    ManipulationInertiaStarting = event(add_ManipulationInertiaStarting, remove_ManipulationInertiaStarting)
    ManipulationStarted = event(add_ManipulationStarted, remove_ManipulationStarted)
    ManipulationStarting = event(add_ManipulationStarting, remove_ManipulationStarting)
    NoFocusCandidateFound = event(add_NoFocusCandidateFound, remove_NoFocusCandidateFound)
    PointerCanceled = event(add_PointerCanceled, remove_PointerCanceled)
    PointerCaptureLost = event(add_PointerCaptureLost, remove_PointerCaptureLost)
    PointerEntered = event(add_PointerEntered, remove_PointerEntered)
    PointerExited = event(add_PointerExited, remove_PointerExited)
    PointerMoved = event(add_PointerMoved, remove_PointerMoved)
    PointerPressed = event(add_PointerPressed, remove_PointerPressed)
    PointerReleased = event(add_PointerReleased, remove_PointerReleased)
    PointerWheelChanged = event(add_PointerWheelChanged, remove_PointerWheelChanged)
    PreviewKeyDown = event(add_PreviewKeyDown, remove_PreviewKeyDown)
    PreviewKeyUp = event(add_PreviewKeyUp, remove_PreviewKeyUp)
    ProcessKeyboardAccelerators = event(add_ProcessKeyboardAccelerators, remove_ProcessKeyboardAccelerators)
    RightTapped = event(add_RightTapped, remove_RightTapped)
    Tapped = event(add_Tapped, remove_Tapped)
class UIElementWeakCollection(ComPtr):
    extends: IInspectable
    implements: Tuple[SequenceProtocol[win32more.Microsoft.UI.Xaml.UIElement]]
    default_interface: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement]
    _classid_ = 'Microsoft.UI.Xaml.UIElementWeakCollection'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.UIElementWeakCollection.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IUIElementWeakCollectionFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.UIElementWeakCollection: ...
    @winrt_mixinmethod
    def GetAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement], index: UInt32) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_mixinmethod
    def get_Size(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement]) -> UInt32: ...
    @winrt_mixinmethod
    def GetView(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement]) -> win32more.Windows.Foundation.Collections.IVectorView[win32more.Microsoft.UI.Xaml.UIElement]: ...
    @winrt_mixinmethod
    def IndexOf(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement], value: win32more.Microsoft.UI.Xaml.UIElement, index: POINTER(UInt32)) -> Boolean: ...
    @winrt_mixinmethod
    def SetAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement], index: UInt32, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    @winrt_mixinmethod
    def InsertAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement], index: UInt32, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    @winrt_mixinmethod
    def RemoveAt(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement], index: UInt32) -> Void: ...
    @winrt_mixinmethod
    def Append(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement], value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    @winrt_mixinmethod
    def RemoveAtEnd(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement]) -> Void: ...
    @winrt_mixinmethod
    def Clear(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement]) -> Void: ...
    @winrt_mixinmethod
    def GetMany(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement], startIndex: UInt32, items: FillArray[win32more.Microsoft.UI.Xaml.UIElement]) -> UInt32: ...
    @winrt_mixinmethod
    def ReplaceAll(self: win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.UIElement], items: PassArray[win32more.Microsoft.UI.Xaml.UIElement]) -> Void: ...
    @winrt_mixinmethod
    def First(self: win32more.Windows.Foundation.Collections.IIterable[win32more.Microsoft.UI.Xaml.UIElement]) -> win32more.Windows.Foundation.Collections.IIterator[win32more.Microsoft.UI.Xaml.UIElement]: ...
    Size = property(get_Size, None)
class UnhandledExceptionEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IUnhandledExceptionEventArgs
    _classid_ = 'Microsoft.UI.Xaml.UnhandledExceptionEventArgs'
    @winrt_mixinmethod
    def get_Exception(self: win32more.Microsoft.UI.Xaml.IUnhandledExceptionEventArgs) -> win32more.Windows.Foundation.HResult: ...
    @winrt_mixinmethod
    def get_Message(self: win32more.Microsoft.UI.Xaml.IUnhandledExceptionEventArgs) -> hstr: ...
    @winrt_mixinmethod
    def get_Handled(self: win32more.Microsoft.UI.Xaml.IUnhandledExceptionEventArgs) -> Boolean: ...
    @winrt_mixinmethod
    def put_Handled(self: win32more.Microsoft.UI.Xaml.IUnhandledExceptionEventArgs, value: Boolean) -> Void: ...
    Exception = property(get_Exception, None)
    Handled = property(get_Handled, put_Handled)
    Message = property(get_Message, None)
class UnhandledExceptionEventHandler(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{3427c1b6-5eca-5631-84b8-5bae732fb67f}')
    @winrt_commethod(3)
    def Invoke(self, sender: IInspectable, e: win32more.Microsoft.UI.Xaml.UnhandledExceptionEventArgs) -> Void: ...
class Vector3Transition(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IVector3Transition
    _classid_ = 'Microsoft.UI.Xaml.Vector3Transition'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.Vector3Transition.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IVector3TransitionFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.Vector3Transition: ...
    @winrt_mixinmethod
    def get_Duration(self: win32more.Microsoft.UI.Xaml.IVector3Transition) -> win32more.Windows.Foundation.TimeSpan: ...
    @winrt_mixinmethod
    def put_Duration(self: win32more.Microsoft.UI.Xaml.IVector3Transition, value: win32more.Windows.Foundation.TimeSpan) -> Void: ...
    @winrt_mixinmethod
    def get_Components(self: win32more.Microsoft.UI.Xaml.IVector3Transition) -> win32more.Microsoft.UI.Xaml.Vector3TransitionComponents: ...
    @winrt_mixinmethod
    def put_Components(self: win32more.Microsoft.UI.Xaml.IVector3Transition, value: win32more.Microsoft.UI.Xaml.Vector3TransitionComponents) -> Void: ...
    Components = property(get_Components, put_Components)
    Duration = property(get_Duration, put_Duration)
class Vector3TransitionComponents(Enum, UInt32):
    _name_ = 'Microsoft.UI.Xaml.Vector3TransitionComponents'
    X = 1
    Y = 2
    Z = 4
class VerticalAlignment(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.VerticalAlignment'
    Top = 0
    Center = 1
    Bottom = 2
    Stretch = 3
class Visibility(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.Visibility'
    Visible = 0
    Collapsed = 1
class VisualState(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    default_interface: win32more.Microsoft.UI.Xaml.IVisualState
    _classid_ = 'Microsoft.UI.Xaml.VisualState'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.VisualState.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.VisualState: ...
    @winrt_mixinmethod
    def get_Name(self: win32more.Microsoft.UI.Xaml.IVisualState) -> hstr: ...
    @winrt_mixinmethod
    def get_Storyboard(self: win32more.Microsoft.UI.Xaml.IVisualState) -> win32more.Microsoft.UI.Xaml.Media.Animation.Storyboard: ...
    @winrt_mixinmethod
    def put_Storyboard(self: win32more.Microsoft.UI.Xaml.IVisualState, value: win32more.Microsoft.UI.Xaml.Media.Animation.Storyboard) -> Void: ...
    @winrt_mixinmethod
    def get_Setters(self: win32more.Microsoft.UI.Xaml.IVisualState) -> win32more.Microsoft.UI.Xaml.SetterBaseCollection: ...
    @winrt_mixinmethod
    def get_StateTriggers(self: win32more.Microsoft.UI.Xaml.IVisualState) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.StateTriggerBase]: ...
    Name = property(get_Name, None)
    Setters = property(get_Setters, None)
    StateTriggers = property(get_StateTriggers, None)
    Storyboard = property(get_Storyboard, put_Storyboard)
class VisualStateChangedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IVisualStateChangedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.VisualStateChangedEventArgs'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.VisualStateChangedEventArgs.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.VisualStateChangedEventArgs: ...
    @winrt_mixinmethod
    def get_OldState(self: win32more.Microsoft.UI.Xaml.IVisualStateChangedEventArgs) -> win32more.Microsoft.UI.Xaml.VisualState: ...
    @winrt_mixinmethod
    def put_OldState(self: win32more.Microsoft.UI.Xaml.IVisualStateChangedEventArgs, value: win32more.Microsoft.UI.Xaml.VisualState) -> Void: ...
    @winrt_mixinmethod
    def get_NewState(self: win32more.Microsoft.UI.Xaml.IVisualStateChangedEventArgs) -> win32more.Microsoft.UI.Xaml.VisualState: ...
    @winrt_mixinmethod
    def put_NewState(self: win32more.Microsoft.UI.Xaml.IVisualStateChangedEventArgs, value: win32more.Microsoft.UI.Xaml.VisualState) -> Void: ...
    @winrt_mixinmethod
    def get_Control(self: win32more.Microsoft.UI.Xaml.IVisualStateChangedEventArgs) -> win32more.Microsoft.UI.Xaml.Controls.Control: ...
    @winrt_mixinmethod
    def put_Control(self: win32more.Microsoft.UI.Xaml.IVisualStateChangedEventArgs, value: win32more.Microsoft.UI.Xaml.Controls.Control) -> Void: ...
    Control = property(get_Control, put_Control)
    NewState = property(get_NewState, put_NewState)
    OldState = property(get_OldState, put_OldState)
class VisualStateChangedEventHandler(MulticastDelegate):
    extends: IUnknown
    _iid_ = Guid('{cdbbd854-0539-5bff-b448-33193d2f41b8}')
    @winrt_commethod(3)
    def Invoke(self, sender: IInspectable, e: win32more.Microsoft.UI.Xaml.VisualStateChangedEventArgs) -> Void: ...
class VisualStateGroup(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    default_interface: win32more.Microsoft.UI.Xaml.IVisualStateGroup
    _classid_ = 'Microsoft.UI.Xaml.VisualStateGroup'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.VisualStateGroup.CreateInstance(*args))
        else:
            raise ValueError('no matched constructor')
    @winrt_activatemethod
    def CreateInstance(cls) -> win32more.Microsoft.UI.Xaml.VisualStateGroup: ...
    @winrt_mixinmethod
    def get_Name(self: win32more.Microsoft.UI.Xaml.IVisualStateGroup) -> hstr: ...
    @winrt_mixinmethod
    def get_Transitions(self: win32more.Microsoft.UI.Xaml.IVisualStateGroup) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.VisualTransition]: ...
    @winrt_mixinmethod
    def get_States(self: win32more.Microsoft.UI.Xaml.IVisualStateGroup) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.VisualState]: ...
    @winrt_mixinmethod
    def get_CurrentState(self: win32more.Microsoft.UI.Xaml.IVisualStateGroup) -> win32more.Microsoft.UI.Xaml.VisualState: ...
    @winrt_mixinmethod
    def add_CurrentStateChanged(self: win32more.Microsoft.UI.Xaml.IVisualStateGroup, handler: win32more.Microsoft.UI.Xaml.VisualStateChangedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_CurrentStateChanged(self: win32more.Microsoft.UI.Xaml.IVisualStateGroup, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_CurrentStateChanging(self: win32more.Microsoft.UI.Xaml.IVisualStateGroup, handler: win32more.Microsoft.UI.Xaml.VisualStateChangedEventHandler) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_CurrentStateChanging(self: win32more.Microsoft.UI.Xaml.IVisualStateGroup, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    CurrentState = property(get_CurrentState, None)
    Name = property(get_Name, None)
    States = property(get_States, None)
    Transitions = property(get_Transitions, None)
    CurrentStateChanged = event(add_CurrentStateChanged, remove_CurrentStateChanged)
    CurrentStateChanging = event(add_CurrentStateChanging, remove_CurrentStateChanging)
class _VisualStateManager_Meta_(ComPtr.__class__):
    pass
class VisualStateManager(ComPtr, metaclass=_VisualStateManager_Meta_):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    default_interface: win32more.Microsoft.UI.Xaml.IVisualStateManager
    _classid_ = 'Microsoft.UI.Xaml.VisualStateManager'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.VisualStateManager.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IVisualStateManagerFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.VisualStateManager: ...
    @winrt_mixinmethod
    def RaiseCurrentStateChanging(self: win32more.Microsoft.UI.Xaml.IVisualStateManagerProtected, stateGroup: win32more.Microsoft.UI.Xaml.VisualStateGroup, oldState: win32more.Microsoft.UI.Xaml.VisualState, newState: win32more.Microsoft.UI.Xaml.VisualState, control: win32more.Microsoft.UI.Xaml.Controls.Control) -> Void: ...
    @winrt_mixinmethod
    def RaiseCurrentStateChanged(self: win32more.Microsoft.UI.Xaml.IVisualStateManagerProtected, stateGroup: win32more.Microsoft.UI.Xaml.VisualStateGroup, oldState: win32more.Microsoft.UI.Xaml.VisualState, newState: win32more.Microsoft.UI.Xaml.VisualState, control: win32more.Microsoft.UI.Xaml.Controls.Control) -> Void: ...
    @winrt_mixinmethod
    def GoToStateCore(self: win32more.Microsoft.UI.Xaml.IVisualStateManagerOverrides, control: win32more.Microsoft.UI.Xaml.Controls.Control, templateRoot: win32more.Microsoft.UI.Xaml.FrameworkElement, stateName: hstr, group: win32more.Microsoft.UI.Xaml.VisualStateGroup, state: win32more.Microsoft.UI.Xaml.VisualState, useTransitions: Boolean) -> Boolean: ...
    @winrt_classmethod
    def GetVisualStateGroups(cls: win32more.Microsoft.UI.Xaml.IVisualStateManagerStatics, obj: win32more.Microsoft.UI.Xaml.FrameworkElement) -> win32more.Windows.Foundation.Collections.IVector[win32more.Microsoft.UI.Xaml.VisualStateGroup]: ...
    @winrt_classmethod
    def get_CustomVisualStateManagerProperty(cls: win32more.Microsoft.UI.Xaml.IVisualStateManagerStatics) -> win32more.Microsoft.UI.Xaml.DependencyProperty: ...
    @winrt_classmethod
    def GetCustomVisualStateManager(cls: win32more.Microsoft.UI.Xaml.IVisualStateManagerStatics, obj: win32more.Microsoft.UI.Xaml.FrameworkElement) -> win32more.Microsoft.UI.Xaml.VisualStateManager: ...
    @winrt_classmethod
    def SetCustomVisualStateManager(cls: win32more.Microsoft.UI.Xaml.IVisualStateManagerStatics, obj: win32more.Microsoft.UI.Xaml.FrameworkElement, value: win32more.Microsoft.UI.Xaml.VisualStateManager) -> Void: ...
    @winrt_classmethod
    def GoToState(cls: win32more.Microsoft.UI.Xaml.IVisualStateManagerStatics, control: win32more.Microsoft.UI.Xaml.Controls.Control, stateName: hstr, useTransitions: Boolean) -> Boolean: ...
    _VisualStateManager_Meta_.CustomVisualStateManagerProperty = property(get_CustomVisualStateManagerProperty, None)
class VisualTransition(ComPtr):
    extends: win32more.Microsoft.UI.Xaml.DependencyObject
    default_interface: win32more.Microsoft.UI.Xaml.IVisualTransition
    _classid_ = 'Microsoft.UI.Xaml.VisualTransition'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.VisualTransition.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IVisualTransitionFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.VisualTransition: ...
    @winrt_mixinmethod
    def get_GeneratedDuration(self: win32more.Microsoft.UI.Xaml.IVisualTransition) -> win32more.Microsoft.UI.Xaml.Duration: ...
    @winrt_mixinmethod
    def put_GeneratedDuration(self: win32more.Microsoft.UI.Xaml.IVisualTransition, value: win32more.Microsoft.UI.Xaml.Duration) -> Void: ...
    @winrt_mixinmethod
    def get_GeneratedEasingFunction(self: win32more.Microsoft.UI.Xaml.IVisualTransition) -> win32more.Microsoft.UI.Xaml.Media.Animation.EasingFunctionBase: ...
    @winrt_mixinmethod
    def put_GeneratedEasingFunction(self: win32more.Microsoft.UI.Xaml.IVisualTransition, value: win32more.Microsoft.UI.Xaml.Media.Animation.EasingFunctionBase) -> Void: ...
    @winrt_mixinmethod
    def get_To(self: win32more.Microsoft.UI.Xaml.IVisualTransition) -> hstr: ...
    @winrt_mixinmethod
    def put_To(self: win32more.Microsoft.UI.Xaml.IVisualTransition, value: hstr) -> Void: ...
    @winrt_mixinmethod
    def get_From(self: win32more.Microsoft.UI.Xaml.IVisualTransition) -> hstr: ...
    @winrt_mixinmethod
    def put_From(self: win32more.Microsoft.UI.Xaml.IVisualTransition, value: hstr) -> Void: ...
    @winrt_mixinmethod
    def get_Storyboard(self: win32more.Microsoft.UI.Xaml.IVisualTransition) -> win32more.Microsoft.UI.Xaml.Media.Animation.Storyboard: ...
    @winrt_mixinmethod
    def put_Storyboard(self: win32more.Microsoft.UI.Xaml.IVisualTransition, value: win32more.Microsoft.UI.Xaml.Media.Animation.Storyboard) -> Void: ...
    From = property(get_From, put_From)
    GeneratedDuration = property(get_GeneratedDuration, put_GeneratedDuration)
    GeneratedEasingFunction = property(get_GeneratedEasingFunction, put_GeneratedEasingFunction)
    Storyboard = property(get_Storyboard, put_Storyboard)
    To = property(get_To, put_To)
WinUIContract: UInt32 = 589824
class _Window_Meta_(ComPtr.__class__):
    pass
class Window(ComPtr, metaclass=_Window_Meta_):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IWindow
    _classid_ = 'Microsoft.UI.Xaml.Window'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.Window.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IWindowFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.Window: ...
    @winrt_mixinmethod
    def get_Bounds(self: win32more.Microsoft.UI.Xaml.IWindow) -> win32more.Windows.Foundation.Rect: ...
    @winrt_mixinmethod
    def get_Visible(self: win32more.Microsoft.UI.Xaml.IWindow) -> Boolean: ...
    @winrt_mixinmethod
    def get_Content(self: win32more.Microsoft.UI.Xaml.IWindow) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_mixinmethod
    def put_Content(self: win32more.Microsoft.UI.Xaml.IWindow, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    @winrt_mixinmethod
    def get_CoreWindow(self: win32more.Microsoft.UI.Xaml.IWindow) -> win32more.Windows.UI.Core.CoreWindow: ...
    @winrt_mixinmethod
    def get_Compositor(self: win32more.Microsoft.UI.Xaml.IWindow) -> win32more.Microsoft.UI.Composition.Compositor: ...
    @winrt_mixinmethod
    def get_Dispatcher(self: win32more.Microsoft.UI.Xaml.IWindow) -> win32more.Windows.UI.Core.CoreDispatcher: ...
    @winrt_mixinmethod
    def get_DispatcherQueue(self: win32more.Microsoft.UI.Xaml.IWindow) -> win32more.Microsoft.UI.Dispatching.DispatcherQueue: ...
    @winrt_mixinmethod
    def get_Title(self: win32more.Microsoft.UI.Xaml.IWindow) -> hstr: ...
    @winrt_mixinmethod
    def put_Title(self: win32more.Microsoft.UI.Xaml.IWindow, value: hstr) -> Void: ...
    @winrt_mixinmethod
    def get_ExtendsContentIntoTitleBar(self: win32more.Microsoft.UI.Xaml.IWindow) -> Boolean: ...
    @winrt_mixinmethod
    def put_ExtendsContentIntoTitleBar(self: win32more.Microsoft.UI.Xaml.IWindow, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def add_Activated(self: win32more.Microsoft.UI.Xaml.IWindow, handler: win32more.Windows.Foundation.TypedEventHandler[IInspectable, win32more.Microsoft.UI.Xaml.WindowActivatedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_Activated(self: win32more.Microsoft.UI.Xaml.IWindow, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_Closed(self: win32more.Microsoft.UI.Xaml.IWindow, handler: win32more.Windows.Foundation.TypedEventHandler[IInspectable, win32more.Microsoft.UI.Xaml.WindowEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_Closed(self: win32more.Microsoft.UI.Xaml.IWindow, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_SizeChanged(self: win32more.Microsoft.UI.Xaml.IWindow, handler: win32more.Windows.Foundation.TypedEventHandler[IInspectable, win32more.Microsoft.UI.Xaml.WindowSizeChangedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_SizeChanged(self: win32more.Microsoft.UI.Xaml.IWindow, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def add_VisibilityChanged(self: win32more.Microsoft.UI.Xaml.IWindow, handler: win32more.Windows.Foundation.TypedEventHandler[IInspectable, win32more.Microsoft.UI.Xaml.WindowVisibilityChangedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_VisibilityChanged(self: win32more.Microsoft.UI.Xaml.IWindow, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def Activate(self: win32more.Microsoft.UI.Xaml.IWindow) -> Void: ...
    @winrt_mixinmethod
    def Close(self: win32more.Microsoft.UI.Xaml.IWindow) -> Void: ...
    @winrt_mixinmethod
    def SetTitleBar(self: win32more.Microsoft.UI.Xaml.IWindow, titleBar: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    @winrt_mixinmethod
    def get_SystemBackdrop(self: win32more.Microsoft.UI.Xaml.IWindow2) -> win32more.Microsoft.UI.Xaml.Media.SystemBackdrop: ...
    @winrt_mixinmethod
    def put_SystemBackdrop(self: win32more.Microsoft.UI.Xaml.IWindow2, value: win32more.Microsoft.UI.Xaml.Media.SystemBackdrop) -> Void: ...
    @winrt_mixinmethod
    def get_AppWindow(self: win32more.Microsoft.UI.Xaml.IWindow2) -> win32more.Microsoft.UI.Windowing.AppWindow: ...
    @winrt_classmethod
    def get_Current(cls: win32more.Microsoft.UI.Xaml.IWindowStatics) -> win32more.Microsoft.UI.Xaml.Window: ...
    AppWindow = property(get_AppWindow, None)
    Bounds = property(get_Bounds, None)
    Compositor = property(get_Compositor, None)
    Content = property(get_Content, put_Content)
    CoreWindow = property(get_CoreWindow, None)
    Dispatcher = property(get_Dispatcher, None)
    DispatcherQueue = property(get_DispatcherQueue, None)
    ExtendsContentIntoTitleBar = property(get_ExtendsContentIntoTitleBar, put_ExtendsContentIntoTitleBar)
    SystemBackdrop = property(get_SystemBackdrop, put_SystemBackdrop)
    Title = property(get_Title, put_Title)
    Visible = property(get_Visible, None)
    _Window_Meta_.Current = property(get_Current, None)
    Activated = event(add_Activated, remove_Activated)
    Closed = event(add_Closed, remove_Closed)
    SizeChanged = event(add_SizeChanged, remove_SizeChanged)
    VisibilityChanged = event(add_VisibilityChanged, remove_VisibilityChanged)
class WindowActivatedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IWindowActivatedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.WindowActivatedEventArgs'
    @winrt_mixinmethod
    def get_Handled(self: win32more.Microsoft.UI.Xaml.IWindowActivatedEventArgs) -> Boolean: ...
    @winrt_mixinmethod
    def put_Handled(self: win32more.Microsoft.UI.Xaml.IWindowActivatedEventArgs, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_WindowActivationState(self: win32more.Microsoft.UI.Xaml.IWindowActivatedEventArgs) -> win32more.Microsoft.UI.Xaml.WindowActivationState: ...
    Handled = property(get_Handled, put_Handled)
    WindowActivationState = property(get_WindowActivationState, None)
class WindowActivationState(Enum, Int32):
    _name_ = 'Microsoft.UI.Xaml.WindowActivationState'
    CodeActivated = 0
    Deactivated = 1
    PointerActivated = 2
class WindowEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IWindowEventArgs
    _classid_ = 'Microsoft.UI.Xaml.WindowEventArgs'
    @winrt_mixinmethod
    def get_Handled(self: win32more.Microsoft.UI.Xaml.IWindowEventArgs) -> Boolean: ...
    @winrt_mixinmethod
    def put_Handled(self: win32more.Microsoft.UI.Xaml.IWindowEventArgs, value: Boolean) -> Void: ...
    Handled = property(get_Handled, put_Handled)
class WindowSizeChangedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IWindowSizeChangedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.WindowSizeChangedEventArgs'
    @winrt_mixinmethod
    def get_Handled(self: win32more.Microsoft.UI.Xaml.IWindowSizeChangedEventArgs) -> Boolean: ...
    @winrt_mixinmethod
    def put_Handled(self: win32more.Microsoft.UI.Xaml.IWindowSizeChangedEventArgs, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_Size(self: win32more.Microsoft.UI.Xaml.IWindowSizeChangedEventArgs) -> win32more.Windows.Foundation.Size: ...
    Handled = property(get_Handled, put_Handled)
    Size = property(get_Size, None)
class WindowVisibilityChangedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IWindowVisibilityChangedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.WindowVisibilityChangedEventArgs'
    @winrt_mixinmethod
    def get_Handled(self: win32more.Microsoft.UI.Xaml.IWindowVisibilityChangedEventArgs) -> Boolean: ...
    @winrt_mixinmethod
    def put_Handled(self: win32more.Microsoft.UI.Xaml.IWindowVisibilityChangedEventArgs, value: Boolean) -> Void: ...
    @winrt_mixinmethod
    def get_Visible(self: win32more.Microsoft.UI.Xaml.IWindowVisibilityChangedEventArgs) -> Boolean: ...
    Handled = property(get_Handled, put_Handled)
    Visible = property(get_Visible, None)
XamlContract: UInt32 = 589824
class XamlIsland(ComPtr):
    extends: IInspectable
    implements: Tuple[ContextManagerProtocol]
    default_interface: win32more.Microsoft.UI.Xaml.IXamlIsland
    _classid_ = 'Microsoft.UI.Xaml.XamlIsland'
    def __init__(self, *args, **kwargs):
        if kwargs:
            super().__init__(**kwargs)
        elif len(args) == 0:
            super().__init__(move=win32more.Microsoft.UI.Xaml.XamlIsland.CreateInstance(*args, None, None))
        else:
            raise ValueError('no matched constructor')
    @winrt_factorymethod
    def CreateInstance(cls: win32more.Microsoft.UI.Xaml.IXamlIslandFactory, baseInterface: IInspectable, innerInterface: POINTER(IInspectable)) -> win32more.Microsoft.UI.Xaml.XamlIsland: ...
    @winrt_mixinmethod
    def get_Content(self: win32more.Microsoft.UI.Xaml.IXamlIsland) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_mixinmethod
    def put_Content(self: win32more.Microsoft.UI.Xaml.IXamlIsland, value: win32more.Microsoft.UI.Xaml.UIElement) -> Void: ...
    @winrt_mixinmethod
    def get_ContentIsland(self: win32more.Microsoft.UI.Xaml.IXamlIsland) -> win32more.Microsoft.UI.Content.ContentIsland: ...
    @winrt_mixinmethod
    def get_SystemBackdrop(self: win32more.Microsoft.UI.Xaml.IXamlIsland) -> win32more.Microsoft.UI.Xaml.Media.SystemBackdrop: ...
    @winrt_mixinmethod
    def put_SystemBackdrop(self: win32more.Microsoft.UI.Xaml.IXamlIsland, value: win32more.Microsoft.UI.Xaml.Media.SystemBackdrop) -> Void: ...
    @winrt_mixinmethod
    def Close(self: win32more.Windows.Foundation.IClosable) -> Void: ...
    Content = property(get_Content, put_Content)
    ContentIsland = property(get_ContentIsland, None)
    SystemBackdrop = property(get_SystemBackdrop, put_SystemBackdrop)
class XamlResourceReferenceFailedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IXamlResourceReferenceFailedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.XamlResourceReferenceFailedEventArgs'
    @winrt_mixinmethod
    def get_Message(self: win32more.Microsoft.UI.Xaml.IXamlResourceReferenceFailedEventArgs) -> hstr: ...
    Message = property(get_Message, None)
class XamlRoot(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IXamlRoot
    _classid_ = 'Microsoft.UI.Xaml.XamlRoot'
    @winrt_mixinmethod
    def get_Content(self: win32more.Microsoft.UI.Xaml.IXamlRoot) -> win32more.Microsoft.UI.Xaml.UIElement: ...
    @winrt_mixinmethod
    def get_Size(self: win32more.Microsoft.UI.Xaml.IXamlRoot) -> win32more.Windows.Foundation.Size: ...
    @winrt_mixinmethod
    def get_RasterizationScale(self: win32more.Microsoft.UI.Xaml.IXamlRoot) -> Double: ...
    @winrt_mixinmethod
    def get_IsHostVisible(self: win32more.Microsoft.UI.Xaml.IXamlRoot) -> Boolean: ...
    @winrt_mixinmethod
    def add_Changed(self: win32more.Microsoft.UI.Xaml.IXamlRoot, handler: win32more.Windows.Foundation.TypedEventHandler[win32more.Microsoft.UI.Xaml.XamlRoot, win32more.Microsoft.UI.Xaml.XamlRootChangedEventArgs]) -> win32more.Windows.Foundation.EventRegistrationToken: ...
    @winrt_mixinmethod
    def remove_Changed(self: win32more.Microsoft.UI.Xaml.IXamlRoot, token: win32more.Windows.Foundation.EventRegistrationToken) -> Void: ...
    @winrt_mixinmethod
    def get_ContentIslandEnvironment(self: win32more.Microsoft.UI.Xaml.IXamlRoot2) -> win32more.Microsoft.UI.Content.ContentIslandEnvironment: ...
    @winrt_mixinmethod
    def get_CoordinateConverter(self: win32more.Microsoft.UI.Xaml.IXamlRoot3) -> win32more.Microsoft.UI.Content.ContentCoordinateConverter: ...
    @winrt_mixinmethod
    def get_ContentIsland(self: win32more.Microsoft.UI.Xaml.IXamlRoot4) -> win32more.Microsoft.UI.Content.ContentIsland: ...
    Content = property(get_Content, None)
    ContentIsland = property(get_ContentIsland, None)
    ContentIslandEnvironment = property(get_ContentIslandEnvironment, None)
    CoordinateConverter = property(get_CoordinateConverter, None)
    IsHostVisible = property(get_IsHostVisible, None)
    RasterizationScale = property(get_RasterizationScale, None)
    Size = property(get_Size, None)
    Changed = event(add_Changed, remove_Changed)
class XamlRootChangedEventArgs(ComPtr):
    extends: IInspectable
    default_interface: win32more.Microsoft.UI.Xaml.IXamlRootChangedEventArgs
    _classid_ = 'Microsoft.UI.Xaml.XamlRootChangedEventArgs'


make_ready(__name__)
