#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.

from openjiuwen.core.operator.llm_call.base import LLMCall

__all__ = [
    "LLMCall",
]
