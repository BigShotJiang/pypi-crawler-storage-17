"""Task-NG: A modern Python reimagining of Taskwarrior."""

__version__ = "0.1.0"
__author__ = "Task-NG Contributors"
