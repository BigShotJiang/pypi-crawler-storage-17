"""Version information including git commit details.

This file is generated at build time by scripts/generate_version.py.
Do not edit manually.
"""

# These values are updated at build time
GIT_COMMIT = "0604aca"
GIT_DATE = "2025-12-16 23:59:05 +0100"
