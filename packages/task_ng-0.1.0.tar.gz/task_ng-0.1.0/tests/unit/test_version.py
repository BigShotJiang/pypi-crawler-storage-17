"""Test version and basic imports."""

from taskng import __version__


def test_version():
    """Version should be 0.1.0."""
    assert __version__ == "0.1.0"


def test_version_format():
    """Version should be a valid semver string."""
    parts = __version__.split(".")
    assert len(parts) == 3
    assert all(part.isdigit() for part in parts)
