# VideoSDK Cerebras Plugin

Agent Framework plugin for LLM services from Cerebras.

## Installation

```bash
pip install videosdk-plugins-cerebras
```