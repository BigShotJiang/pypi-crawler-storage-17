# Authors

This is the official list of CosmPy authors (the lists are in the alphabetical order:):

### Leads

- Ali Hosseini <ali.hosseini@fetch.ai> [5A11](https://github.com/5A11)
- James Riehl <james.riehl@fetch.ai> [jrriehl](https://github.com/jrriehl)

### Primary Current and Past Contributors

- Alejandro Madrigal <alejandro.madrigal@fetch.ai> [Alejandro-Morales](https://github.com/Alejandro-Morales)
- Ed Fitzgerald <ed.fitzgerald@fetch.ai> [ejfitzgerald](https://github.com/ejfitzgerald)
- Jiri Vestfal <jiri.vestfal@fetch.ai> [MissingNO57](https://github.com/MissingNO57)
- Lokman Rahmani <lokman.rahmani@fetch.ai> [lrahmani](https://github.com/lrahmani)
- Oleg Panasevych <oleg.panasevych@n-cube.co.uk> [Panasevychol](https://github.com/panasevychol)
- Peter Bukva <peter.bukva@fetch.ai> [pbukva](https://github.com/pbukva)
- Yuri Turchenkov <yuri.turchenkov@fetch.ai> [solarw](https://github.com/solarw)

## Other Contributors

See the GitHub commit log for a list of recent contributors. We would like to thank everyone who has contributed to the project in any way.
