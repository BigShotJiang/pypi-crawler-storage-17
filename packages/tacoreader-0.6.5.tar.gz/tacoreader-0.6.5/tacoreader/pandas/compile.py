def compile():
    pass