def main():
    print("Hello from code-edit-mcp!")


if __name__ == "__main__":
    main()
