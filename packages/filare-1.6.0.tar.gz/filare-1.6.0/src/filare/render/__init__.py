"""Rendering helpers for graphviz/html/pdf output."""

# Avoid eager imports here to prevent circular dependencies; import modules directly where needed.
