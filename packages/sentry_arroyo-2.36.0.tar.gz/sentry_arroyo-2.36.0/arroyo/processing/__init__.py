from arroyo.processing.processor import StreamProcessor

__all__ = ["StreamProcessor"]
