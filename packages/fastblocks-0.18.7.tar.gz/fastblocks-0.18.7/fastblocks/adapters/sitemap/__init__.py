"""FastBlocks sitemap adapters."""
