"""Entry point for running u2-mcp as a module: python -m u2_mcp"""

from .server import main

if __name__ == "__main__":
    main()
