"""Training CLI commands (train, train_cfg, watch).

Commands for running and monitoring training jobs.
"""

__all__: list[str] = []


