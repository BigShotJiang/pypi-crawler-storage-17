class NotValidDidBlockchainError(Exception):
    """When a Walytis blockchain doesn't contain valid DID-Manager blocks."""
