"""A minimal package."""

__version__ = "0.1.0"


def hello() -> str:
    """Return a greeting."""
    return "Hello from agentops-core!"

