# agentops-core

A minimal package.

## Installation

```bash
pip install agentops-core
```

## Usage

```python
from agentops_sdk import hello

print(hello())
```
