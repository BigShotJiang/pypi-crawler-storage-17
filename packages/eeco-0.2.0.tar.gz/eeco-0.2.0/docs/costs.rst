.. contents::

.. _costs:

*****
costs
*****

This module consists of code that computes a user's electricity bill given an electricity consumption profile.

.. automodule:: eeco.costs
   :members: