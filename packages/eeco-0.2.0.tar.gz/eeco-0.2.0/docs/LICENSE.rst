.. contents::

.. _LICENSE:

MIT License
===========

.. include:: ../LICENSE