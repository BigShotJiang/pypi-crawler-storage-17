# -*- coding: utf-8 -*-
"""Main package for Electric Emissions & Cost Optimizer (EECO)."""

__author__ = "WE3Lab"
__email__ = "fchapin@stanford.edu"
# Do not edit this string manually, always use bumpversion
# Details in CONTRIBUTING.rst
__version__ = "0.2.0"


def get_module_version():
    return __version__
