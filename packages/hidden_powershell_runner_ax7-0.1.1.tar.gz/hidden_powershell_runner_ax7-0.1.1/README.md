# hidden-powershell-runner-ax7

مكتبة بايثون صغيرة تشغل أمر PowerShell في وضع مخفي باستخدام `subprocess.Popen`.

## التثبيت

```bash
pip install -e .
```

## الاستخدام

```python
from command_runner import run_hidden_command

run_hidden_command("echo ofds")
```

يتم تشغيل PowerShell بدون نافذة وبلا مخرجات مرئية.

## رفع الحزمة إلى PyPI

يوجد ملف `command.bat` لتنفيذ خطوات البناء والرفع على Windows.

```bat
:: استبدل القيمة بتوكن PyPI الخاص بك
command.bat pypi-AgENdGVzdC5weXBpLm9yZwIk...
```

الملف يقوم بـ:
- تثبيت الأدوات المطلوبة (`pip`, `build`, `twine`).
- تنظيف مجلدات `dist` و `build`.
- بناء الحزمة (sdist و wheel).
- رفعها إلى PyPI باستخدام التوكن الممرّر.

