"""CLI entrypoint for Celesto Agentor."""

from .main import app

__all__ = ["app"]
