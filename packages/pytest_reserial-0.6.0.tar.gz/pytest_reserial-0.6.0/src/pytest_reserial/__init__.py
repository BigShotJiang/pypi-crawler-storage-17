"""Pytest fixture for recording and replaying serial port traffic."""

__version__ = "0.6.0"
