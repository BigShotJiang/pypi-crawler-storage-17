"""Scripts for moneyflow development and documentation."""
