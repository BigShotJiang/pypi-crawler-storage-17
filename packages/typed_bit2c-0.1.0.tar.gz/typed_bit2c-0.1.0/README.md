# Typed Bit2c

> A fully typed, validated async client for the Bit2c API

Use *autocomplete* instead of documentation.

🚧 Under construction.