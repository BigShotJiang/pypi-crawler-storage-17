"""Mistral chat model integration."""

from browser_use.llm.mistral.chat import ChatMistral

__all__ = ['ChatMistral']
