"""Agent adapters for connecting to different agent frameworks."""
