"""Mock implementations for testing."""
