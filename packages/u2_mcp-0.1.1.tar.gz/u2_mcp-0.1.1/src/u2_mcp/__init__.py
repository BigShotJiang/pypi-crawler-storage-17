"""u2-mcp: MCP server for Rocket Universe/UniData MultiValue databases."""

__version__ = "0.1.0"
