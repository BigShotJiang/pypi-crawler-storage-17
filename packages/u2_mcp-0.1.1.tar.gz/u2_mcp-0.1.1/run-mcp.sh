#!/bin/bash
cd /Users/peter/Documents/Code/Active/u2-mcp
exec .venv/bin/python -m u2_mcp
