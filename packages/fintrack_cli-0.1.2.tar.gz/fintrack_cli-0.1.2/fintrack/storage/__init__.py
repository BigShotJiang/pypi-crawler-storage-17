"""Storage layer with repository abstractions."""
