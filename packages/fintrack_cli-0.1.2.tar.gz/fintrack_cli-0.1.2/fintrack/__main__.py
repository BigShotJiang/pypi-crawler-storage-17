"""Entry point for running fintrack as a module: python -m fintrack."""

from fintrack.cli.main import app

if __name__ == "__main__":
    app()
