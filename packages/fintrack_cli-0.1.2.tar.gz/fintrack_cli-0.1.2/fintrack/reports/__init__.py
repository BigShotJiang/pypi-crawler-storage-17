"""HTML report generation."""
