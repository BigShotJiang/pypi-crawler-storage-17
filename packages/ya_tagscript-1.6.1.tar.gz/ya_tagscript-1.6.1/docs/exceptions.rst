==========
Exceptions
==========

.. automodule:: ya_tagscript.exceptions
    :synopsis: Exceptions used by the library
    :members:
