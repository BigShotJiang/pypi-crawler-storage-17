"""Plugin template."""

from .interface import Plugin


class Extension(Plugin):
    """Sample plugin template."""
