"""Package version."""

VERSION = "2.4.7-7"
