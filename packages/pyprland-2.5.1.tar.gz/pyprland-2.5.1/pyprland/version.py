"""Package version."""

VERSION = "2.5.1"
