from .map import infer_device
