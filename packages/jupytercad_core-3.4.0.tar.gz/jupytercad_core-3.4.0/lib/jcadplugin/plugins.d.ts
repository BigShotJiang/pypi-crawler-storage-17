import { JupyterFrontEndPlugin } from '@jupyterlab/application';
declare const jcadPlugin: JupyterFrontEndPlugin<void>;
export default jcadPlugin;
