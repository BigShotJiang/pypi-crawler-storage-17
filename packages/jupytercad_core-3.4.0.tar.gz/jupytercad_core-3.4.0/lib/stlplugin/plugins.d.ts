import { JupyterFrontEndPlugin } from '@jupyterlab/application';
declare const stlPlugin: JupyterFrontEndPlugin<void>;
export default stlPlugin;
