from ._core import SVGDiagram

__all__ = ["SVGDiagram"]
