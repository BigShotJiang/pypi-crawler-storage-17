#!/usr/bin/env python3
# builtin
import setuptools

setuptools.setup()
