API Specification
-----------------

This page contains the specification for all classes and methods available in
ArangoRDF.

ArangoRDF
=========

.. autoclass:: arango_rdf.main.ArangoRDF
    :members:


ArangoRDFController
===================

.. autoclass:: arango_rdf.controller.ArangoRDFController
    :members:
