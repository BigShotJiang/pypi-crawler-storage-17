"""Template system for TunaCode."""

from .loader import Template

__all__ = ["Template"]
