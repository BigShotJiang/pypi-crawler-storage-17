# Acknowledgments

The development of BrainPy is being or has been supported by many organizations, programs, and individuals since 2020. 
The following list of support received is therefore necessarily incomplete.


This project has received funding from:

- Science and Technology Innovation 2030 (China Brain Project): Brain Science and Brain-inspired Intelligence Project (No. 2021ZD0200204).
- Young Scientists Fund of the National Natural Science Foundation of China (No. 32400937).
- China Postdoctoral Science Foundation (No. 2024M750076), 
- Postdoctoral Fellowship Program of CPSF (No. GZC20230106).


Additionally, BrainPy gratefully acknowledges the support and funding received from:

- 新一代人工智能开源开放平台 OpenI
- Beijing Academy of Artificial Intelligence. 
