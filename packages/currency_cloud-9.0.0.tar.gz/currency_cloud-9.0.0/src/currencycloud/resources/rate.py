'''This module provides the object representation of a CurrencyCloud Rate'''

from currencycloud.resources.resource import Resource


class Rate(Resource):
    '''This class represents a CurrencyCloud Rate'''
    pass


class Rates(Resource):
    '''This class represents a CurrencyCloud Rate'''
    pass
