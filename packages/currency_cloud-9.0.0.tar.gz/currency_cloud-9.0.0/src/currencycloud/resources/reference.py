from currencycloud.resources.resource import Resource


class Currency(Resource):
    pass


class ConversionDates(Resource):
    pass


class SettlementAccount(Resource):
    pass


class BeneficiaryRequiredDetails(Resource):
    pass


class PayerRequiredDetails(Resource):
    pass


class PaymentPurposeCode(Resource):
    pass


class BankDetails(Resource):
    pass


class PaymentFeeRule(Resource):
    pass

