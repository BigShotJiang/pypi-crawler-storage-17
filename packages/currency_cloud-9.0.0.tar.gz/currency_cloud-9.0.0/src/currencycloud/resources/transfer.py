'''This module provides the object representation of a CurrencyCloud Transfer'''

from currencycloud.resources.resource import Resource


class Transfer(Resource):
    '''This class represents a CurrencyCloud Transfer'''
    pass
