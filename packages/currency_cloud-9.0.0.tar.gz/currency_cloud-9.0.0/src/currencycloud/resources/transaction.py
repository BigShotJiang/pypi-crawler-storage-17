'''This module provides the object representation of a CurrencyCloud Transaction'''

from currencycloud.resources.resource import Resource


class Transaction(Resource):
    '''This class represents a CurrencyCloud Transaction'''
    pass
