'''Utility Mixins to abstract common behavior for CC API Resources'''

from currencycloud.resources.actions.delete import DeleteMixin
from currencycloud.resources.actions.update import UpdateMixin
