'''This module provides the object representation of a CurrencyCloud Payer'''

from currencycloud.resources.resource import Resource


class Payer(Resource):
    '''This class represents a CurrencyCloud Payer'''
    pass
