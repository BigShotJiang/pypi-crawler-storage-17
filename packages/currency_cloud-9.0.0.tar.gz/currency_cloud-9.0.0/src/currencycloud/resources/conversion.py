'''This module provides the object representation of a CurrencyCloud Conversion'''

from currencycloud.resources.resource import Resource


class Conversion(Resource):
    '''This class represents a CurrencyCloud Conversion'''
    pass
