from currencycloud.resources.resource import Resource


class Sender (Resource):
    """This class represents a CurrencyCloud Sender"""
    pass
