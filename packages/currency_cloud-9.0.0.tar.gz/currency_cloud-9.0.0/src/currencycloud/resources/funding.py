'''This module provides the object representation of a CurrencyCloud Funding'''

from currencycloud.resources.resource import Resource

class FundingAccount(Resource):
    '''This class represents a CurrencyCloud Funding Account'''
    pass

