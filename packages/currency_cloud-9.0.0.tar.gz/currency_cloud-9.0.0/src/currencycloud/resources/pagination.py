from currencycloud.resources.resource import Resource


class Pagination(Resource):
    pass
