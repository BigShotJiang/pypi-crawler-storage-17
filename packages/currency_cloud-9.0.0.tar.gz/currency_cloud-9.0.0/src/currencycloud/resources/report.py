
from currencycloud.resources.resource import Resource


class Report (Resource):
    """This class represents a CurrencyCloud Report"""
    pass
