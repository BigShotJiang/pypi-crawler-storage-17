"""Skalds: An event-driven, modular distributed task scheduling and execution system."""
from skalds.skald import Skald


__version__ = "0.3.6"
