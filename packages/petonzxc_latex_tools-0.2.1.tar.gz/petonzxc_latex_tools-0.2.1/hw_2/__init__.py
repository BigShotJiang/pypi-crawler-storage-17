from .latex_generator import generate_table_latex, generate_image_latex

__version__ = "0.1.0"
__all__ = ["generate_table_latex", "generate_image_latex"]