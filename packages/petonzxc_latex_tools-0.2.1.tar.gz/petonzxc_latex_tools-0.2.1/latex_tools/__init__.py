from .latex_generator import generate_table_latex, generate_image_latex

__version__ = "0.2.1"
__all__ = ["generate_table_latex", "generate_image_latex"]