
__name__ = 'tinybird_cli'
__description__ = 'Tinybird Command Line Tool'
__url__ = 'https://www.tinybird.co/docs/cli'
__author__ = 'Tinybird'
__author_email__ = 'support@tinybird.co'
__version__ = '5.22.0'
__revision__ = '5f5959a'
