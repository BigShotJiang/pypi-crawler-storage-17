This module adds Assign Owner (owner_id) field in purchase order, whose
value will be passed to the corresponding field of the incoming picking
upon order confirmation.

This module can be useful in a business situation where you purchase
products in place of a client (you seprately issue an invoice to the
client and the inventory is owned by them, although you physically keep
the inventory in your premise).
