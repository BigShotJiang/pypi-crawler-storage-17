from . import test_account_payment_mode
from . import test_account_payment_partner
