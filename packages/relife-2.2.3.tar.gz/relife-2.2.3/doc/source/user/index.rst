User guide
==========

.. note::

    More examples will be given soon. For now, look at the API section of the documentation.

.. toctree::
    :maxdepth: 2

    about_numpy

Lifetime models
---------------

.. toctree::
    :maxdepth: 2

    non_parametric_lifetime_models.ipynb
    lifetime_distributions.ipynb
    lifetime_regressions.ipynb
