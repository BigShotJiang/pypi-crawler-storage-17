{{ name | escape | underline }}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}