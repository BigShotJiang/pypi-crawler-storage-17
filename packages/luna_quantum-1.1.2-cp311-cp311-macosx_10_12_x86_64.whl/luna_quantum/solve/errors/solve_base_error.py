from luna_quantum.exceptions.base_luna_quantum_error import BaseLunaQuantumError


class SolveBaseError(BaseLunaQuantumError):
    """Base class for all solve errors."""
