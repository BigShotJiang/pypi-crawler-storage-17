import logging

logger = logging.getLogger("email_service")
logger.setLevel(logging.INFO)
