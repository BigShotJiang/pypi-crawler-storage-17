If you want to control the automatic creation of supplier price lists:

1. Go to Purchase, then to Configuration, and open the purchasing settings.
2. In the Orders section, find the "Enable Automatic Supplier Price Lists" option.
3. Check this box to enable the automatic creation of supplier price lists when validating purchase orders, or uncheck it to prevent these lines from being generated automatically.
4. The setting is applied per company, allowing for different configurations in a multi-company environment.
