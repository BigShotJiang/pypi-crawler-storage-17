
> - [Sygel](https://www.sygel.es):
>
> > - Juan Alberto Raja Martinez\<<juan.raja@sygel.es>\>
> > - Valentín Vinagre Urteaga\<<valentin.vinagre@sygel.es>\>
> > - Manuel Regidor\<<manuel.regidor@sygel.es>\>
