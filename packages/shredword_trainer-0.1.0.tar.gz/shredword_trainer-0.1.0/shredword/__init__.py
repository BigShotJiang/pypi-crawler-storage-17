from .trainer import BPETrainer, UnigramTrainer

__version__ = '0.1.0'
__author__ = 'Shivendra S'