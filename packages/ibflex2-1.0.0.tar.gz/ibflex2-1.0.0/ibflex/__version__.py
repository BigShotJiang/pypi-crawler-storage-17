"""
Get a job, save your money, listen to Jane
Everybody knows umbrellas cost more in the rain
All the news is bad
Is there any other kind?
Everybody's talking at the same time

It's hard times for some
For others it's sweet
Someone makes money when there's blood in the street
Don't take any lip
Stay in line
Everybody's talking at the same time
"""
__title__ = "ibflex2"
__description__ = (
    "Parse Interactive Brokers Flex XML reports and convert to Python types (maintained fork)"
),
__url__ = "https://github.com/robcohen/ibflex2"
__upstream_url__ = "https://github.com/csingley/ibflex"
__version__ = "1.0.0"
__author__ = "Christopher Singley"
__author_email__ = "csingley@gmail.com"
__maintainer__ = "robcohen"
__license__ = "MIT"
__copyright__ = "Copyright 2017 Christopher Singley"
