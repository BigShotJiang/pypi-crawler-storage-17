"""
Utilities for testing of openEO client workflows.
"""


# Legacy import for backwards compatibility
from openeo.testing.io import TestDataLoader
