"""
Wrappers for openEO API concepts.
"""
