
# BIDS Manager

**BIDS Manager** is a **PyQt-based** GUI that converts **DICOM** folders into **BIDS**-compliant datasets and allows easy metadata editing.

---
# Check the 📜 [documentation](https://ancplaboldenburg.github.io/bids_manager_documentation/) 📜

