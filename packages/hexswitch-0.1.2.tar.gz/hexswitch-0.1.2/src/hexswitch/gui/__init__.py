"""GUI module for HexSwitch framework."""

from hexswitch.gui.server import GuiServer

__all__ = ["GuiServer"]

