"""Pipeline module for canonical message processing."""

from hexswitch.pipeline.pipeline import Pipeline, PipelineContext

__all__ = ["Pipeline", "PipelineContext"]

