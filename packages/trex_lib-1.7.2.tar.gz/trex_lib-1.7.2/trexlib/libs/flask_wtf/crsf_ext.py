'''
Created on 22 Jan 2021

@author: jacklok
'''
from flask_wtf.csrf import CSRFProtect

class CRSFProtectExt(CSRFProtect):
    pass
