import pyv

global_dict = {}
local_dict = {}
pyv.exec_pyv_file("test.pyv", global_dict, local_dict)
