#[derive(Debug)]
pub enum PlayerError {
    MoneyNotAvailable,
    AnimalsNotAvailable,
}
