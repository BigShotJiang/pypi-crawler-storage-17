## [1.0.3] - 2025-12-16

* Added funding information


## [1.0.2] - 2025-12-16

* Name conflicts; Set module name to: docoli


## [1.0.1] - 2025-12-16

* Now buildable via python


## [1.0.0] - 2025-12-16

* Initial Release

