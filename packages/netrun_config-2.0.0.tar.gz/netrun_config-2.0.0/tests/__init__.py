"""Test suite for netrun-config."""
