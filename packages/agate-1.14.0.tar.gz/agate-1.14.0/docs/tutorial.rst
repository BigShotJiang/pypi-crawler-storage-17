========
Tutorial
========

The agate tutorial is now available in new-and-improved Jupyter Notebook format.

Find it |link-pre|\ |version|\ |link-post|

.. |link-pre| raw:: html

	<a href="https://github.com/wireservice/agate/blob/

.. |link-post| raw:: html

	 /tutorial.ipynb">on GitHub</a>!
