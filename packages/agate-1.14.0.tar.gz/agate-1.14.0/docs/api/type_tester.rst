==============
Type inference
==============

.. automodule:: agate.type_tester
    :no-members:

.. autoclass:: agate.TypeTester
