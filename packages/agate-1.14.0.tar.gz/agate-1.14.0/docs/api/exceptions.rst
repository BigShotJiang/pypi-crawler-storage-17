============
Exceptions
============

.. autosummary::
    :nosignatures:

    agate.DataTypeError
    agate.UnsupportedAggregationError
    agate.CastError
    agate.FieldSizeLimitError

.. autoexception:: agate.DataTypeError
.. autoexception:: agate.UnsupportedAggregationError
.. autoexception:: agate.CastError
.. autoexception:: agate.FieldSizeLimitError
