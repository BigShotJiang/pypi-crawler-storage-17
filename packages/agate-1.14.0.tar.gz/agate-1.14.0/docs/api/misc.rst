=============
Miscellaneous
=============

.. autosummary::
    :nosignatures:

    agate.NullOrder
    agate.Quantiles

.. autoclass:: agate.NullOrder
.. autoclass:: agate.Quantiles
