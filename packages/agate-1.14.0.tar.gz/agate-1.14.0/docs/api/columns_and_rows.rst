================
Columns and rows
================

.. autosummary::
    :nosignatures:

    agate.MappedSequence
    agate.Column
    agate.Row

.. autoclass:: agate.MappedSequence

.. autoclass:: agate.Column

.. autoclass:: agate.Row
