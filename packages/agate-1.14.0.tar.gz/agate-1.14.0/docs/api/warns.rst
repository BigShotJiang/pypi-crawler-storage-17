========
Warnings
========

.. autoclass:: agate.NullCalculationWarning
.. autoclass:: agate.DuplicateColumnWarning

.. autofunction:: agate.warn_null_calculation
.. autofunction:: agate.warn_duplicate_column
