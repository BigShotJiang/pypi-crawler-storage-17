"""Tests for wagtail-herald."""
