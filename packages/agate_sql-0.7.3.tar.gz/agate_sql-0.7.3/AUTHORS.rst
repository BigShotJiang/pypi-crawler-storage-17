The following individuals have contributed code to agate-sql:

* `Christopher Groskopf <https://github.com/onyxfish>`_
* `Adrian Klaver <https://github.com/aklaver>`_
* `James McKinney <https://github.com/jpmckinney>`_
* `Chris Keller <https://github.com/chrislkeller>`_
* `git-clueless <https://github.com/git-clueless>`_
* `z2s8 <https://github.com/z2s8>`_
* `Jake Zimmerman <https://github.com/jez>`_
* `Shige Takeda <https://github.com/smtakeda>`_
* `Roger Webb <https://github.com/RogerWebb>`_
* `Steve Kowalik <https://github.com/s-t-e-v-e-n-k>`_
