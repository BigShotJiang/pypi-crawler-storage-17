"""Library for interacting with the ICOtronic system"""

from importlib.metadata import version

__version__ = version("icotronic")
