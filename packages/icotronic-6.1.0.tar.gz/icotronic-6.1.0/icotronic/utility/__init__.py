"""Misc utility code"""
