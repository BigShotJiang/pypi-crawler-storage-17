
class Regexs:

    DATA01 = r"https?://(?:www\.)?[^\s/$.?#].[^\s]*"
