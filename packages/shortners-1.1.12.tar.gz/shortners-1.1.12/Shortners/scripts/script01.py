class Scripted:

    DATA01 = "1a2b3c4d5e6f7g8h9"
    DATA02 = "https://telegram.me/clinton_abraham"
