"""WACCY extension for SEC EDGAR filing parsing."""

__version__ = "0.1.0"

