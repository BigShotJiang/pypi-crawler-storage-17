# Python tests for life-restart-core
