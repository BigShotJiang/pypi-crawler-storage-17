# Tests for pydantic-bq

