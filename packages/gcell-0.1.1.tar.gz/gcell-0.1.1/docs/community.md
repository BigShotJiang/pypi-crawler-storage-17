# Community

gcell is a community driven project. There are multiple channels for users and developers to communicate and connect.

## [Github Issue Tracker](https://github.com/GET-Foundation/gcell/issues)

The [gcell](https://github.com/GET-Foundation/gcell/issues) issue trackers are for reports and discussion of:

- Bug reports
- Documentation issues
- Feature requests
