(News)=
### News

<!-- marker: after prelude -->

#### Publication of get_model
GET is now published on [Nature](https://www.nature.com/articles/s41586-024-08391-z)!

<!-- marker: before old news -->
