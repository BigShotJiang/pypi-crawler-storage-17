"""This is the autogluon version file."""

__version__ = "1.4.0"
__lite__ = False
