"""
Generative Recommendation Models

This module contains generative models for recommendation tasks.
"""

from nextrec.models.generative.hstu import HSTU

__all__ = ["HSTU"]
