API
===

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    UnderstatClient <understatapi.api.rst>
    Endpoints <endpoints_index.rst>
    Misc <misc_index.rst>
