Misc
====

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    Utils <understatapi.utils.rst>
    Exceptions <understatapi.exceptions.rst>