void dummy(void) {
}
