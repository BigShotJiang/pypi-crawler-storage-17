__version__ = "2025.5.7"  # noqa: W292
