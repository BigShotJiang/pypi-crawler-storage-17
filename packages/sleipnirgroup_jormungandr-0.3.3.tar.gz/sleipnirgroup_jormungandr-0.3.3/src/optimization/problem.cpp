// Copyright (c) Sleipnir contributors

#include "sleipnir/optimization/problem.hpp"

template class EXPORT_TEMPLATE_DEFINE(SLEIPNIR_DLLEXPORT) slp::Problem<double>;
