// Copyright (c) Sleipnir contributors

#include "sleipnir/autodiff/jacobian.hpp"

template class EXPORT_TEMPLATE_DEFINE(SLEIPNIR_DLLEXPORT) slp::Jacobian<double>;
