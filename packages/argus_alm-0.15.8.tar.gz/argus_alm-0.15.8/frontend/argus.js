import {} from "bootstrap";
import "github-markdown-css/github-markdown-light.css";
import "./argus.css";
import "./fonts/noto.css";

export const applicationCurrentUser = gArgusCurrentUser ?? {};
