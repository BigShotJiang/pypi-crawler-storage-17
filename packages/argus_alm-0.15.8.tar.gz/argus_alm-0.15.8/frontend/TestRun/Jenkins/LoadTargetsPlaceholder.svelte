<script>

    /**
     * @typedef {Object} Props
     * @property {{testId: string}} args
     */

    /** @type {Props} */
    let { args } = $props();
</script>

<div>
    <span class="spinner-border spinner-border-sm"></span> Loading targets...
</div>
