trytond
=======

The server of Tryton.
Tryton is business software, ideal for companies of any size, easy to use,
complete and 100% Open Source.
It provides modularity, scalability and security.
