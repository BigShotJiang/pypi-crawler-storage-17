Builtin Modules
===============

Tryton comes with modules that are integral to every installation and are
always activated.

.. toctree::
   :maxdepth: 2

   ir/index
   res/index
