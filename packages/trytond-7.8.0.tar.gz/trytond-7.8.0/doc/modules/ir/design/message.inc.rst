.. _model-ir.message:

Message
=======

The *Message* stores translatable text that is shown to the `Users
<model-res.user>`.

.. seealso::

   The Messages can be found by opening the main menu item:

      |Administration --> Localization --> Messages|__

      .. |Administration --> Localization --> Messages| replace:: :menuselection:`Administration --> Localization --> Messages`
      __ https://demo.tryton.org/model/ir.message
