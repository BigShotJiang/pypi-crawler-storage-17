.. _model-ir.configuration:

Configuration
=============

The *Configuration* is a :class:`~trytond.model.ModelSingleton` that stores
configuration from the `database setup <topics-setup-database>`, like the
default language and the host name.
