.. _model-ir.session:

Session
=======

The *Session* generates and stores the session keys for connected `Users
<model-res.user>`.

.. _model-ir.session.wizard:

Session Wizard
==============

The *Session Wizard* stores the data from active :class:`~trytond.wizard.State`
of the :class:`~trytond.wizard.Wizard`.
