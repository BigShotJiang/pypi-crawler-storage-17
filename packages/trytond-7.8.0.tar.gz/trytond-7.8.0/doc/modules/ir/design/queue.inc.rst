.. _model-ir.queue:

Queue
=====

The *Queue* stores the `tasks <topics-task-queue>` to be run asynchronously.
An expected :py:class:`~datetime.datetime` can be set to define when the task
should be run.
