.. _model-ir.cache:

Cache
=====

The *Cache* stores when the named :class:`~trytond.cache.Cache` was last
invalidated.
