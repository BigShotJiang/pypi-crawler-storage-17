.. _model-ir.date:

Date
====

The *Date* :class:`~trytond.model.Model` provides the current date.
