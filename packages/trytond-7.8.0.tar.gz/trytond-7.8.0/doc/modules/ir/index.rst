.. _ir:

########################
Internal Resource Module
########################

The *Internal Resource Module* provides the basic internal resources needed to
run Tryton.
This includes the models, actions and user interface definitions.

.. toctree::
   :maxdepth: 2

   design/index
   reference
