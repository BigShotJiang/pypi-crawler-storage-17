.. _ref-tools-chart:
.. module:: trytond.tools.chart

chart
=====

.. function:: sparkline(numbers)

   Return a string of the same length as ``numbers`` with unicode blocks
   representing a `sparkline <https://en.wikipedia.org/wiki/Sparkline>`_
