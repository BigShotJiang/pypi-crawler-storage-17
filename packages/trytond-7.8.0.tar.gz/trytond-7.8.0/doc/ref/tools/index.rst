.. _ref-tools-index:

=====
Tools
=====

Tools API reference.

.. toctree::
   :maxdepth: 1

   barcode
   chart
   decimal
   email
   immutabledict
   logging
   misc
   multiprocessing
   qrcode
   singleton
   timezone
