.. _ref-tools-decimal:
.. module:: trytond.tools.decimal_

decimal_
========

.. function:: decistmt(string)

   Substitute Decimals for floats and integers in the string statements.

.. class:: DecimalNull

   A Decimal that behaves like the SQL ``NULL``.
