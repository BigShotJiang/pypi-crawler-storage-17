.. _ref-tools-singleton:
.. module:: trytond.tools.singleton

Singleton
=========

.. class:: Singleton

   A metaclass to create a `singleton`_ object.

.. _`singleton`: http://en.wikipedia.org/wiki/Singleton_pattern
