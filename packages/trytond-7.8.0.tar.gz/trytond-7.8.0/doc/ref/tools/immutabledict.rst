.. _ref-immutabledict:
.. module:: trytond.tools.immutabledict

ImmutableDict
=============

.. class:: ImmutableDict

   Implement an immutable dictionary.
