"""
MCP Context Tools

Implements context tools:
- paircoder_context_read: Read project context files
"""

from pathlib import Path
from typing import Any, Optional


def find_paircoder_dir() -> Path:
    """Find the .paircoder directory."""
    current = Path.cwd()
    while current != current.parent:
        paircoder_dir = current / ".paircoder"
        if paircoder_dir.exists():
            return paircoder_dir
        current = current.parent
    raise FileNotFoundError("No .paircoder directory found")


def register_context_tools(server: Any) -> None:
    """Register context tools with the MCP server."""

    @server.tool()
    async def paircoder_context_read(
        file: str = "state",
    ) -> dict:
        """
        Read project context files.

        Args:
            file: Context file to read (state, project, workflow, config, capabilities)

        Returns:
            File content and metadata
        """
        try:
            paircoder_dir = find_paircoder_dir()

            # Map file names to paths
            file_map = {
                "state": paircoder_dir / "context" / "state.md",
                "project": paircoder_dir / "context" / "project.md",
                "workflow": paircoder_dir / "context" / "workflow.md",
                "config": paircoder_dir / "config.yaml",
                "capabilities": paircoder_dir / "capabilities.yaml",
            }

            if file not in file_map:
                return {
                    "error": {
                        "code": "INVALID_FILE",
                        "message": f"Unknown file: {file}. Valid options: {', '.join(file_map.keys())}",
                    }
                }

            file_path = file_map[file]

            if not file_path.exists():
                return {
                    "error": {
                        "code": "FILE_NOT_FOUND",
                        "message": f"Context file not found: {file_path}",
                    }
                }

            content = file_path.read_text(encoding="utf-8")

            return {
                "file": file,
                "path": str(file_path),
                "content": content,
                "size": len(content),
            }
        except FileNotFoundError:
            return {"error": {"code": "NOT_FOUND", "message": "No .paircoder directory found"}}
        except Exception as e:
            return {"error": {"code": "ERROR", "message": str(e)}}
