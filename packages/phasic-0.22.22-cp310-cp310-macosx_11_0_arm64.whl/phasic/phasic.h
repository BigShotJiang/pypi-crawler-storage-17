

// #ifndef phasic_h_INCLUDED
// #define phasic_h_INCLUDED
#include "./phasic/api/c/phasic.h"
// #endif

// #ifndef phasic_c_INCLUDED
// #define phasic_c_INCLUDED
#include "./phasic/src/c/phasic.c"
// #endif

// #ifndef phasiccpp_h_INCLUDED
// #define phasiccpp_h_INCLUDED
#include "./phasic/api/cpp/phasiccpp.h"
// #endif
