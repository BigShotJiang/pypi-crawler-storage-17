## 0.5.0 / 2025-11-25
 * fix MS Visual C++ build
 * fix test.py to pass on python3
 * fix distutils sdist run wit MANIFEST.in
