Development
###########
This section provides examples and guidance on how to create benchmarks based on the IQM Benchmarks package.

.. toctree::
   :maxdepth: 1

   how_to_make_your_own_benchmark
   generate_2qubit_cliffords
