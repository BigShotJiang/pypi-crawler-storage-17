# system modules

# internal modules

# external modules
import numpy as np

np.random.seed(42)
