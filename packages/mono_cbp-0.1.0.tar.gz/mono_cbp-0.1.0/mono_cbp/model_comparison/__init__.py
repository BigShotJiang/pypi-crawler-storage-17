"""Model comparison module for mono-cbp."""

from .comparator import ModelComparator

__all__ = ["ModelComparator"]
