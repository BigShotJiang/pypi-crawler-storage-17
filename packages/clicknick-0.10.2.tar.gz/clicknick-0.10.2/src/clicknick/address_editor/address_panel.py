"""Single panel widget for editing addresses of one memory type.

Uses tksheet for high-performance table display with virtual rows.
"""

from __future__ import annotations

import logging
import tkinter as tk
from collections.abc import Callable
from tkinter import ttk
from typing import TYPE_CHECKING

from tksheet import Sheet, num2alpha

from .address_model import NON_EDITABLE_TYPES
from .char_limit_tooltip import CharLimitTooltip

# --- LOGGING CONFIGURATION ---
DEBUG_MODE = False  # <--- CHANGE THIS TO True TO ENABLE DEBUGGING
logger = logging.getLogger(__name__)
if DEBUG_MODE:
    logger.setLevel(logging.DEBUG)
    # Ensure output goes to console if this is the main entry point or not configured elsewhere
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter("%(levelname)s:%(name)s:%(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
else:
    logger.setLevel(logging.WARNING)  # Only show Warnings/Errors in production
# -----------------------------

from .address_model import (
    ADDRESS_RANGES,
    DATA_TYPE_BIT,
    DEFAULT_RETENTIVE,
    MEMORY_TYPE_TO_DATA_TYPE,
    PAIRED_RETENTIVE_TYPES,
    AddressRow,
    validate_nickname,
)
from .blocktag_model import parse_block_tag

if TYPE_CHECKING:
    pass


class WarningNoteSheet(Sheet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Override the internal main table's redraw_corner method
        self.MT.redraw_corner = self.custom_redraw_corner

    def custom_redraw_corner(self, x: float, y: float, tags: str | tuple[str]) -> None:
        # Position the symbol slightly offset from the top-right corner
        text_x = x - 7
        text_y = y + 7

        if self.MT.hidd_corners:
            iid = self.MT.hidd_corners.pop()
            # Update position and properties for the symbol
            self.MT.coords(iid, text_x, text_y)
            self.MT.itemconfig(
                iid, text="⚠", fill="black", font=("Arial", 10, "bold"), state="normal", tags=tags
            )
            self.MT.disp_corners.add(iid)
        else:
            # Create a new text object instead of a polygon
            iid = self.MT.create_text(
                text_x, text_y, text="⚠", fill="black", font=("Arial", 10, "bold"), tags=tags
            )
            self.MT.disp_corners.add(iid)


class AddressPanel(ttk.Frame):
    """Single panel for editing one memory type's addresses.

    Displays ALL possible addresses for the memory type (virtual rows),
    with existing nicknames from the database pre-filled.

    Supports combined types (e.g., T+TD interleaved) via combined_types parameter.
    """

    # Column indices (Address is now in row index, not a data column)
    COL_USED = 0
    COL_NICKNAME = 1
    COL_COMMENT = 2
    COL_INIT_VALUE = 3
    COL_RETENTIVE = 4

    def _is_bit_type_panel(self) -> bool:
        """Check if this panel displays a single BIT-type memory (X, Y, C, SC).

        Returns False for combined panels (T/TD, CT/CTD) since they mix BIT and non-BIT rows.
        """
        if self.combined_types and len(self.combined_types) > 1:
            return False
        return MEMORY_TYPE_TO_DATA_TYPE.get(self.memory_type, 0) == DATA_TYPE_BIT

    def _find_paired_row(self, row: AddressRow) -> AddressRow | None:
        """Find the paired T/CT row for a TD/CTD row.

        TD rows share retentive with T rows at the same address.
        CTD rows share retentive with CT rows at the same address.

        Returns None if row is not a paired type or paired row not found.
        """
        paired_type = PAIRED_RETENTIVE_TYPES.get(row.memory_type)
        if not paired_type:
            return None

        # Find the row with the same address and the paired type
        for other_row in self.rows:
            if other_row.memory_type == paired_type and other_row.address == row.address:
                return other_row

        return None

    def _on_close_clicked(self) -> None:
        """Handle close button click."""
        if self.on_close:
            self.on_close(self)

    def _get_block_colors_for_rows(self) -> dict[int, str]:
        """Compute block background colors for each row address.

        Parses block tags from row comments to determine which rows
        should have colored row indices. Nested blocks override outer blocks.

        Returns:
            Dict mapping row index (in self.rows) to bg color string.
        """

        # Build list of colored blocks: (start_idx, end_idx, bg_color)
        # We use row indices not addresses for easier lookup
        colored_blocks: list[tuple[int, int | None, str]] = []

        # Stack for tracking open tags: name -> [(start_idx, bg_color), ...]
        open_tags: dict[str, list[tuple[int, str | None]]] = {}

        for row_idx, row in enumerate(self.rows):
            block_tag = parse_block_tag(row.comment)
            if not block_tag.name:
                continue

            if block_tag.tag_type == "self-closing":
                if block_tag.bg_color:
                    colored_blocks.append((row_idx, row_idx, block_tag.bg_color))
            elif block_tag.tag_type == "open":
                if block_tag.name not in open_tags:
                    open_tags[block_tag.name] = []
                open_tags[block_tag.name].append((row_idx, block_tag.bg_color))
            elif block_tag.tag_type == "close":
                if block_tag.name in open_tags and open_tags[block_tag.name]:
                    start_idx, start_bg_color = open_tags[block_tag.name].pop()
                    if start_bg_color:
                        colored_blocks.append((start_idx, row_idx, start_bg_color))

        # Handle unclosed tags as singular points
        for stack in open_tags.values():
            for start_idx, bg_color in stack:
                if bg_color:
                    colored_blocks.append((start_idx, start_idx, bg_color))

        # Build row_idx -> color map, with inner blocks overriding outer
        # Sort by range size descending (larger ranges first), then by start index
        # This ensures inner (smaller) blocks are processed last and override
        colored_blocks.sort(key=lambda b: (-(b[1] - b[0]) if b[1] else 0, b[0]))

        row_colors: dict[int, str] = {}
        for start_idx, end_idx, bg_color in colored_blocks:
            if end_idx is None:
                end_idx = start_idx
            for idx in range(start_idx, end_idx + 1):
                row_colors[idx] = bg_color

        return row_colors

    def _get_init_value_hint(self, data_type: int) -> str:
        """Get the hint text for initial value based on data type.

        Args:
            data_type: The data type code

        Returns:
            Hint string describing valid range/values
        """
        from .address_model import (
            DATA_TYPE_BIT,
            DATA_TYPE_FLOAT,
            DATA_TYPE_HEX,
            DATA_TYPE_INT,
            DATA_TYPE_INT2,
            DATA_TYPE_TXT,
            FLOAT_MAX,
            FLOAT_MIN,
            INT2_MAX,
            INT2_MIN,
            INT_MAX,
            INT_MIN,
        )

        if data_type == DATA_TYPE_BIT:
            return "0 or 1"
        elif data_type == DATA_TYPE_INT:
            return f"Range: {INT_MIN} to {INT_MAX}"
        elif data_type == DATA_TYPE_INT2:
            return f"Range: {INT2_MIN} to {INT2_MAX}"
        elif data_type == DATA_TYPE_FLOAT:
            return f"Range: {FLOAT_MIN:.2e} to {FLOAT_MAX:.2e}"
        elif data_type == DATA_TYPE_HEX:
            return "Hex value (e.g., FF or 0xFF)"
        elif data_type == DATA_TYPE_TXT:
            return "Text string"
        else:
            return "Enter initial value"

    def _update_cell_notes(self) -> None:
        """Update cell notes for validation errors and hints.

        Uses a local cache to prevent calling sheet.note() redundantly.
        """
        # 1. Calculate the 'Target State' (what the sheet should look like right now)
        target_notes: dict[tuple[int, int], str] = {}

        for data_idx, row in enumerate(self.rows):
            # --- Nickname Column ---
            nickname_note = None
            if row.has_reportable_error:
                nickname_note = row.validation_error

            if nickname_note:
                target_notes[(data_idx, self.COL_NICKNAME)] = nickname_note

            # --- Init Value Column ---
            init_note = None
            if not row.initial_value_valid and row.initial_value != "":
                init_note = row.initial_value_error

            if init_note:
                target_notes[(data_idx, self.COL_INIT_VALUE)] = init_note

        # 2. Compare Target vs Cache
        # If the sheet is new, self._note_cache is empty, so everything gets drawn.

        # A. Remove notes that are in cache but NOT in target
        for cell_key in list(self._note_cache.keys()):
            if cell_key not in target_notes:
                # Note exists in UI but shouldn't anymore -> Remove it
                self.sheet.note(cell_key[0], cell_key[1], note=None)
                del self._note_cache[cell_key]

        # B. Add/Update notes that are in target
        for cell_key, note_text in target_notes.items():
            current_cached_text = self._note_cache.get(cell_key)

            # Only talk to tksheet if the text is different/new
            if current_cached_text != note_text:
                self.sheet.note(cell_key[0], cell_key[1], note=note_text)
                self._note_cache[cell_key] = note_text

    def _apply_row_styling(self) -> None:
        """Apply visual styling to rows based on state.

        Note: highlight_cells() uses DATA row indices, not display indices.
        This ensures highlights persist correctly when rows are filtered.
        """
        # Clear all existing highlights first
        self.sheet.dehighlight_all()

        # Get block colors for row indices
        block_colors = self._get_block_colors_for_rows()

        for data_idx in self._displayed_rows:
            row = self.rows[data_idx]

            # Apply block color to row index only (not data cells)
            if data_idx in block_colors:
                # Import here to avoid circular imports
                from .colors import get_block_color_hex

                # Convert color name to hex (supports both names and hex codes)
                hex_color = get_block_color_hex(block_colors[data_idx])
                if hex_color:
                    self.sheet.highlight_cells(
                        row=data_idx,
                        bg=hex_color,
                        canvas="row_index",
                    )

            # Alternate row colors for combined types to distinguish between types
            if self.combined_types and len(self.combined_types) > 1:
                try:
                    type_idx = self.combined_types.index(row.memory_type)
                except ValueError:
                    type_idx = 0

                if type_idx == 1:  # Second type gets slight background tint
                    for col in range(5):  # 5 data columns
                        self.sheet.highlight_cells(
                            row=data_idx,
                            column=col,
                            bg="#f0f8ff",  # Light blue tint for TD/CTD rows
                        )

            # Invalid rows get red background on nickname cell (or orange if ignored)
            if row.has_reportable_error:
                # Red for real errors
                self.sheet.highlight_cells(
                    row=data_idx,
                    column=self.COL_NICKNAME,
                    bg="#ffcccc",
                    fg="black",
                )
            # Dirty nickname gets light yellow background
            elif row.is_nickname_dirty:
                self.sheet.highlight_cells(
                    row=data_idx,
                    column=self.COL_NICKNAME,
                    bg="#ffffcc",
                    fg="black",
                )

            # Dirty comment gets light yellow background
            if row.is_comment_dirty:
                self.sheet.highlight_cells(
                    row=data_idx,
                    column=self.COL_COMMENT,
                    bg="#ffffcc",
                    fg="black",
                )

            # Dirty initial value gets light yellow background
            if row.is_initial_value_dirty:
                self.sheet.highlight_cells(
                    row=data_idx,
                    column=self.COL_INIT_VALUE,
                    bg="#ffffcc",
                    fg="black",
                )

            # Dirty retentive gets light yellow background
            if row.is_retentive_dirty:
                self.sheet.highlight_cells(
                    row=data_idx,
                    column=self.COL_RETENTIVE,
                    bg="#ffffcc",
                    fg="black",
                )

            # Invalid initial value gets red background
            if not row.initial_value_valid and row.initial_value != "":
                self.sheet.highlight_cells(
                    row=data_idx,
                    column=self.COL_INIT_VALUE,
                    bg="#ffcccc",
                    fg="black",
                )

            # Non-editable types get gray background on init/retentive columns
            if not row.can_edit_initial_value:
                self.sheet.highlight_cells(
                    row=data_idx,
                    column=self.COL_INIT_VALUE,
                    bg="#e0e0e0",
                    fg="#666666",
                )
                self.sheet.highlight_cells(
                    row=data_idx,
                    column=self.COL_RETENTIVE,
                    bg="#e0e0e0",
                    fg="#666666",
                )

    def _toggle_init_ret_columns(self) -> None:
        """Toggle visibility of Init Value and Retentive columns."""
        hide = self.hide_init_ret_var.get()
        columns_to_toggle = {self.COL_INIT_VALUE, self.COL_RETENTIVE}
        if hide:
            self.sheet.hide_columns(columns=columns_to_toggle, data_indexes=True)
        else:
            self.sheet.show_columns(columns=columns_to_toggle)

    def _toggle_used_column(self) -> None:
        """Toggle visibility of Used column."""
        hide = self.hide_used_var.get()
        if hide:
            self.sheet.hide_columns(columns={self.COL_USED}, data_indexes=True)
        else:
            self.sheet.show_columns(columns={self.COL_USED})

    def _update_status(self) -> None:
        """Update the status label with current counts."""
        total_visible = len(self._displayed_rows)
        error_count = sum(
            1
            for idx in self._displayed_rows
            if not self.rows[idx].is_valid
            and not self.rows[idx].is_empty
            and not self.rows[idx].should_ignore_validation_error
        )
        modified_count = sum(1 for idx in self._displayed_rows if self.rows[idx].is_dirty)

        self.status_label.config(
            text=f"Rows: {total_visible} | Errors: {error_count} | Modified: {modified_count}"
        )

    def _refresh_display(self) -> None:
        """Refresh styling and status (lightweight, no data rebuild)."""
        self._apply_row_styling()
        self._update_cell_notes()
        self._update_status()
        # Use set_refresh_timer() instead of redraw() to prevent multiple redraws
        # and ensure proper refresh after set_cell_data() calls
        self.sheet.set_refresh_timer()

    def _get_data_index(self, display_idx: int) -> int | None:
        """Convert display row index to data row index.

        Args:
            display_idx: The row index as displayed in the sheet

        Returns:
            The corresponding index in self.rows, or None if invalid
        """
        try:
            return self.sheet.displayed_row_to_data(display_idx)
        except (IndexError, KeyError):
            return None

    def _save_selection(self) -> None:
        """Save the currently selected row index (in self.rows) and its visual position before filter changes."""
        selected = self.sheet.get_selected_rows()
        if selected:
            # Get the first selected display row and map to actual row index
            display_idx = min(selected)
            # Use our _displayed_rows list for consistent conversion
            if display_idx < len(self._displayed_rows):
                self._selected_row_idx = self._displayed_rows[display_idx]
                # Save the visual position (row offset from top of visible area)
                try:
                    start_row, end_row = self.sheet.visible_rows
                    self._selected_row_visual_offset = display_idx - start_row
                except (ValueError, TypeError):
                    self._selected_row_visual_offset = 0
            else:
                self._selected_row_idx = None
                self._selected_row_visual_offset = None
        else:
            self._selected_row_idx = None
            self._selected_row_visual_offset = None

    def _scroll_to_row(
        self, display_idx: int, align_top: bool = False, offset: int | None = None
    ) -> None:
        """Scroll to a specific row in the displayed rows.

        Args:
            display_idx: Index of the row in _displayed_rows
            align_top: If True, ensure the row is at the top of the viewport.
                       If False, just ensure it's visible somewhere in the viewport.
            offset: Optional visual offset from the top (if align_top=True).
                    None means row is at the very top, 0 means row is at the top,
                    >0 means row is that many lines down from the top.
        """
        if align_top:
            # Calculate scroll position
            total_rows = len(self._displayed_rows)
            if total_rows > 0:
                if offset is not None:
                    # Scroll so that the row at 'offset' lines from top is at the top
                    target_top_row = max(0, display_idx - offset)
                    self.sheet.yview_moveto(target_top_row / total_rows)
                else:
                    # Put target row at the top
                    self.sheet.yview_moveto(display_idx / total_rows)

                self.sheet.see(display_idx, self.COL_NICKNAME)
            # Select the row after scrolling
            self.sheet.select_row(display_idx)
        else:
            # Original behavior: just ensure it's visible
            self.sheet.see(display_idx, self.COL_NICKNAME)
            self.sheet.select_row(display_idx)

    def _restore_selection(self) -> None:
        """Restore selection to the previously selected row at the same visual position after filter changes."""
        if self._selected_row_idx is None:
            return

        # Find the display index for the saved row in currently displayed rows
        try:
            display_idx = self._displayed_rows.index(self._selected_row_idx)

            # Clear existing selection and select the row
            self.sheet.deselect()
            self.sheet.select_row(display_idx)

            # Use helper function for scrolling with offset
            self._scroll_to_row(
                display_idx, align_top=True, offset=self._selected_row_visual_offset
            )
        except ValueError:
            # Row is not visible in current filter - clear saved selection
            pass

    def _apply_filters(self) -> None:
        """Apply current filter settings using tksheet's display_rows()."""
        # Save current selection before changing filter
        self._save_selection()

        filter_text = self.filter_var.get().lower()
        hide_empty = self.hide_empty_var.get()
        hide_assigned = self.hide_assigned_var.get()
        show_unsaved_only = self.show_unsaved_only_var.get()

        # Check if any filters are active
        no_filters = (
            not filter_text and not hide_empty and not hide_assigned and not show_unsaved_only
        )

        if no_filters:
            # Show all rows
            self._displayed_rows = list(range(len(self.rows)))
            self.sheet.display_rows("all", redraw=True)
        else:
            # Build list of rows to display
            self._displayed_rows = []
            for i, row in enumerate(self.rows):
                # Filter by text (matches address, nickname, or comment)
                if filter_text:
                    if (
                        filter_text not in row.display_address.lower()
                        and filter_text not in row.nickname.lower()
                        and filter_text not in row.comment.lower()
                    ):
                        continue

                # Hide empty rows (no nickname)
                if hide_empty and row.is_empty:
                    continue

                # Hide assigned rows (has nickname)
                if hide_assigned and not row.is_empty:
                    continue

                # Show only unsaved (dirty) rows
                if show_unsaved_only and not row.is_dirty:
                    continue

                self._displayed_rows.append(i)

            self.sheet.display_rows(rows=self._displayed_rows, all_displayed=False, redraw=True)

        # Restore selection after filter change
        self._restore_selection()

    def _validate_all(self) -> None:
        """Validate all rows against current nickname registry."""
        for row in self.rows:
            row.validate(self._all_nicknames)

    def _fire_batched_notifications(self) -> None:
        """Fire batched notifications for all pending changes."""
        self._notification_timer = None

        # Fire nickname changes (batched)
        if self._pending_nickname_changes and self.on_nickname_changed:
            for addr_key, old_nick, new_nick in self._pending_nickname_changes:
                self.on_nickname_changed(addr_key, old_nick, new_nick)
        self._pending_nickname_changes = []

        # Fire data change notification once
        if self._pending_data_changed and self.on_data_changed:
            self.on_data_changed()
        self._pending_data_changed = False

    def _schedule_notifications(self) -> None:
        """Schedule batched notifications after a short delay.

        This debounces rapid changes (like Replace All) to avoid
        triggering expensive cross-panel validation for each cell.
        """
        # Cancel any existing timer
        if self._notification_timer is not None:
            self.after_cancel(self._notification_timer)

        # Schedule notification after 50ms idle
        self._notification_timer = self.after(50, self._fire_batched_notifications)

    def _bulk_validate(self, event) -> object:
        """Bulk validation handler for paste and multi-cell edits.

        This is called BEFORE changes are applied to the sheet.
        We can modify event.data to filter out invalid changes,
        or return the event to accept all changes.

        Args:
            event: EventDataDict containing proposed changes

        Returns:
            The (possibly modified) event to apply changes, or None to reject all.
        """
        # For now, accept all changes - validation happens after in _on_sheet_modified
        # We could add pre-validation here if needed (e.g., reject non-editable cells)

        # Get the proposed changes
        if not hasattr(event, "data") or not event.data:
            return event

        table_data = event.data.get("table", {})
        if not table_data:
            return event
        # Filter out changes to non-editable cells
        filtered_table = {}
        for (display_row, col), value in table_data.items():
            # Map display row to data row
            data_idx = self._get_data_index(display_row)
            if data_idx is None:
                continue

            address_row = self.rows[data_idx]

            # Check if this column is editable for this row
            if col == self.COL_USED:
                # Read-only column - skip
                continue
            elif col == self.COL_INIT_VALUE and not address_row.can_edit_initial_value:
                # Non-editable init value - skip
                continue
            elif col == self.COL_RETENTIVE and not address_row.can_edit_retentive:
                # Non-editable retentive - skip
                continue
            else:
                # Accept this change
                filtered_table[(display_row, col)] = value

        # Update event data with filtered changes
        event.data["table"] = filtered_table

        return event

    def _build_row_display_data(self, row: AddressRow) -> list:
        """Build display data array for a single row.

        Args:
            row: The AddressRow to build display data for

        Returns:
            List of display values for the row's columns
        """
        is_bit_panel = self._is_bit_type_panel()
        is_combined_panel = self.combined_types and len(self.combined_types) > 1

        # Used column display
        used_display = "\u2713" if row.used else ""

        # Init value: logic to determine if we show "-", Checkbox (bool), or Text
        paired_row = self._find_paired_row(row)
        effective_retentive = paired_row.retentive if paired_row else row.retentive

        # If Retentive is ON and not exempt, force display to "-"
        if effective_retentive and row.memory_type not in NON_EDITABLE_TYPES:
            init_value_display = "-"
        else:
            # Otherwise show the underlying value
            # For BIT types, return bool so tksheet knows to check/uncheck the checkbox
            if is_bit_panel or (is_combined_panel and row.data_type == DATA_TYPE_BIT):
                init_value_display = row.initial_value == "1"
            else:
                init_value_display = row.initial_value

        # Retentive: TD/CTD rows share retentive with their paired T/CT row
        retentive_display = effective_retentive

        return [
            used_display,
            row.nickname,
            row.comment,
            init_value_display,
            retentive_display,  # Boolean for checkbox
        ]

    def _update_row_display(self, data_idx: int) -> None:
        """Update display data for a single row after changes.

        Args:
            data_idx: Index into self.rows (data index, not display index)
        """
        row = self.rows[data_idx]
        display_data = self._build_row_display_data(row)

        # Update each cell in the row
        for col, value in enumerate(display_data):
            # Special handling for Init Value to switch between Checkbox and Text
            if col == self.COL_INIT_VALUE:
                # Always attempt to delete existing checkbox in this cell to ensure clean state
                self.sheet.delete_checkbox(data_idx, col)

                if value == "-":
                    # Just set the text "-"
                    self.sheet.set_cell_data(data_idx, col, value)
                elif row.data_type == DATA_TYPE_BIT:
                    # It's a BIT type and not masked -> Create Checkbox
                    is_checked = value is True
                    state = "normal" if row.can_edit_initial_value else "readonly"
                    self.sheet.create_checkbox(
                        r=data_idx,
                        c=col,
                        checked=is_checked,
                        state=state,
                        text="",
                    )
                    # Also set the data model to the boolean value
                    self.sheet.set_cell_data(data_idx, col, is_checked)
                else:
                    # Standard value (Word/Float/Text) -> Just set data
                    self.sheet.set_cell_data(data_idx, col, value)
            else:
                self.sheet.set_cell_data(data_idx, col, value)

    def _on_sheet_modified(self, event) -> None:
        """Handle sheet modification events (called AFTER changes are applied).

        This handles all types of modifications including single cell edits,
        paste operations, and bulk edits. The changes have already been
        applied to the sheet at this point.
        """
        # Skip processing if notifications are suppressed (e.g., during load)
        if self._suppress_notifications:
            return

        # Get modified cells from event
        cells = getattr(event, "cells", None)
        if not cells:
            return

        # tksheet v7 structure: {'table': {(row, col): value}, 'header': {}, 'index': {}}
        table_cells = cells.get("table", {})
        if not table_cells:
            return

        nickname_changed = False
        data_changed = False
        needs_revalidate = False

        # Track old nicknames for cross-panel notification
        nickname_changes: list[tuple[int, str, str]] = []  # (addr_key, old, new)

        # Track which data rows were modified for display update
        modified_data_indices: set[int] = set()

        # Process each modified cell
        for (event_row, col), old_value in table_cells.items():
            logger.debug(
                f"event_row={event_row}, "
                f"displayed_rows_count={len(self._displayed_rows)}, "
                f"filter_active={len(self._displayed_rows) != len(self.rows)}"
            )

            data_idx = event_row

            if data_idx is None or data_idx >= len(self.rows):
                logger.debug(f"Skipping invalid data_idx={data_idx}")
                continue

            address_row = self.rows[data_idx]
            logger.debug(
                f"address_row.display_address={address_row.display_address}, nickname={address_row.nickname}"
            )

            # Get the NEW value from the sheet using data index
            new_value = self.sheet.get_cell_data(data_idx, col)
            logger.debug(f"new_value from sheet={new_value}, old_value from event={old_value}")

            if col == self.COL_NICKNAME:
                old_nickname = old_value if old_value else ""
                new_nickname = new_value if new_value else ""

                # Skip if no change
                if new_nickname == address_row.nickname:
                    continue

                # Update the row
                address_row.nickname = new_nickname
                modified_data_indices.add(data_idx)

                # Update global nickname registry
                if old_nickname and address_row.addr_key in self._all_nicknames:
                    del self._all_nicknames[address_row.addr_key]
                if new_nickname:
                    self._all_nicknames[address_row.addr_key] = new_nickname

                nickname_changed = True
                data_changed = True

                # Queue notification for parent
                nickname_changes.append((address_row.addr_key, old_nickname, new_nickname))

            elif col == self.COL_COMMENT:
                new_comment = new_value if new_value else ""

                # Skip if no change
                if new_comment == address_row.comment:
                    continue

                # Update the row
                address_row.comment = new_comment
                modified_data_indices.add(data_idx)
                data_changed = True

            elif col == self.COL_INIT_VALUE:
                # Skip if type doesn't allow editing initial value
                if not address_row.can_edit_initial_value:
                    continue

                # Check if row is currently masked by Retentive (showing "-")
                # If so, revert any edit attempts immediately
                paired_row = self._find_paired_row(address_row)
                effective_retentive = paired_row.retentive if paired_row else address_row.retentive

                if effective_retentive and address_row.memory_type not in NON_EDITABLE_TYPES:
                    # User tried to edit a masked value. Revert visual to "-"
                    # We add to modified_indices so _update_row_display restores the "-"
                    modified_data_indices.add(data_idx)
                    continue

                # Standard update logic
                if address_row.data_type == DATA_TYPE_BIT:
                    new_init = "1" if bool(new_value) else "0"
                else:
                    new_init = new_value if new_value else ""

                # Skip if no change
                if new_init == address_row.initial_value:
                    continue

                # Update the row
                address_row.initial_value = new_init
                modified_data_indices.add(data_idx)
                data_changed = True
                needs_revalidate = True

            elif col == self.COL_RETENTIVE:
                # Skip if type doesn't allow editing retentive
                if not address_row.can_edit_retentive:
                    continue

                # Handle retentive checkbox toggle - value is boolean
                new_retentive = bool(new_value)

                # For TD/CTD rows, update the paired T/CT row instead
                paired_row = self._find_paired_row(address_row)
                target_row = paired_row if paired_row else address_row

                # Skip if no change
                if new_retentive == target_row.retentive:
                    continue

                # Update the target row
                target_row.retentive = new_retentive
                modified_data_indices.add(data_idx)

                # If we toggled retentive, we might need to update the paired row's display too
                # (e.g. Toggled T retentive -> TD init value needs to show/hide "-")
                if paired_row:
                    # We need to find the data index of the paired row to refresh it
                    # Simple linear search (optimization: map could be cached)
                    for i, r in enumerate(self.rows):
                        if r is paired_row:
                            modified_data_indices.add(i)
                            break

                # Also if there is a pair that uses the same address but isn't the current row
                # (e.g. We are on TD, we toggled Ret (which maps to T). We need to refresh T row too)
                if self.combined_types and len(self.combined_types) > 1:
                    for i, r in enumerate(self.rows):
                        if r.address == address_row.address and r is not address_row:
                            modified_data_indices.add(i)

                data_changed = True

        # Refresh display for all modified rows (handles toggling "-" vs Checkbox/Value)
        for idx in modified_data_indices:
            self._update_row_display(idx)

        if nickname_changed or needs_revalidate:
            self._validate_all()

        # Refresh styling and status
        self._refresh_display()

        # Queue notifications for batched delivery (debounced)
        # This prevents expensive cross-panel validation for each cell in bulk operations
        if nickname_changes:
            self._pending_nickname_changes.extend(nickname_changes)

        if data_changed:
            self._pending_data_changed = True

        # Schedule batched notification delivery
        if nickname_changes or data_changed:
            self._schedule_notifications()

    def _setup_header_notes(self) -> None:
        """Set up tooltip notes on column headers with hints."""

        # Used column
        self.sheet.note(
            self.sheet.span(num2alpha(self.COL_USED), header=True, table=False),
            note="Used in PLC program",
        )

        # Nickname column
        self.sheet.note(
            self.sheet.span(num2alpha(self.COL_NICKNAME), header=True, table=False),
            note="Nickname (≤24 chars, unique)",
        )

        # Init Value column - hint depends on panel type
        if self._is_bit_type_panel():
            init_hint = "Initial value: 0 or 1 (checkbox)"
        elif self.combined_types and len(self.combined_types) > 1:
            primary_type = self.combined_types[0]
            data_type = MEMORY_TYPE_TO_DATA_TYPE.get(primary_type, 0)
            init_hint = f"Initial value\n{self._get_init_value_hint(data_type)}"
        else:
            data_type = MEMORY_TYPE_TO_DATA_TYPE.get(self.memory_type, 0)
            init_hint = f"Initial value\n{self._get_init_value_hint(data_type)}"

        self.sheet.note(
            self.sheet.span(num2alpha(self.COL_INIT_VALUE), header=True, table=False),
            note=init_hint,
        )

        # Retentive column
        self.sheet.note(
            self.sheet.span(num2alpha(self.COL_RETENTIVE), header=True, table=False),
            note="Retains value across power cycles",
        )

        # Comment column
        self.sheet.note(
            self.sheet.span(num2alpha(self.COL_COMMENT), header=True, table=False),
            note="Comment (max 128 chars)",
        )

    def _create_widgets(self) -> None:
        """Create all panel widgets."""
        # Header frame with title and optional close button
        header = ttk.Frame(self)
        header.pack(fill=tk.X, padx=5, pady=(5, 2))

        # Title shows combined types if applicable
        if self.combined_types and len(self.combined_types) > 1:
            title_text = "/".join(self.combined_types) + " Addresses"
        else:
            title_text = f"{self.memory_type} Addresses"

        ttk.Label(
            header,
            text=title_text,
            font=("TkDefaultFont", 10, "bold"),
        ).pack(side=tk.LEFT)

        # Close button (X) - only if callback provided
        if self.on_close:
            close_btn = ttk.Button(header, text="X", width=2, command=self._on_close_clicked)
            close_btn.pack(side=tk.RIGHT)

        # Filter controls frame
        filter_frame = ttk.Frame(self)
        filter_frame.pack(fill=tk.X, padx=5, pady=2)

        ttk.Label(filter_frame, text="Filter:").pack(side=tk.LEFT)
        self.filter_var = tk.StringVar()
        self.filter_entry = ttk.Entry(filter_frame, textvariable=self.filter_var, width=15)
        self.filter_entry.pack(side=tk.LEFT, padx=(5, 10))
        self.filter_var.trace_add("write", lambda *_: self._apply_filters())

        self.hide_empty_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            filter_frame,
            text="Hide empty",
            variable=self.hide_empty_var,
            command=self._apply_filters,
        ).pack(side=tk.LEFT, padx=(0, 5))

        self.hide_assigned_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            filter_frame,
            text="Hide assigned",
            variable=self.hide_assigned_var,
            command=self._apply_filters,
        ).pack(side=tk.LEFT)

        self.show_unsaved_only_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            filter_frame,
            text="Unsaved only",
            variable=self.show_unsaved_only_var,
            command=self._apply_filters,
        ).pack(side=tk.LEFT, padx=(5, 0))

        ttk.Label(filter_frame, text="Columns:", font=("TkDefaultFont", 10, "bold")).pack(
            side=tk.LEFT, padx=(20, 0)
        )

        self.hide_used_var = tk.BooleanVar(value=False)  # shown by default
        ttk.Checkbutton(
            filter_frame,
            text="Hide Used",
            variable=self.hide_used_var,
            command=self._toggle_used_column,
        ).pack(side=tk.LEFT, padx=(5, 0))

        self.hide_init_ret_var = tk.BooleanVar(value=True)  # Hidden by default
        ttk.Checkbutton(
            filter_frame,
            text="Hide Initial Value/Retentive",
            variable=self.hide_init_ret_var,
            command=self._toggle_init_ret_columns,
        ).pack(side=tk.LEFT, padx=(5, 0))

        # Table (tksheet) - Address is shown in row index for row selection
        self.sheet = WarningNoteSheet(
            self,
            headers=["Used", "Nickname", "Comment", "Init Value", "Ret"],
            show_row_index=True,
            index_align="w",  # Left-align the row index
            height=400,
            width=800,
            note_corners=True,  # Enable note indicators
        )
        self.sheet.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        CharLimitTooltip(
            sheet=self.sheet, char_limits={self.COL_NICKNAME: 24, self.COL_COMMENT: 128}
        )

        # Configure notes to behave like tooltips
        self.sheet.set_options(
            tooltip_hover_delay=300,  # Appears in 300ms instead of 1200ms
            tooltip_width=300,  # Wider to prevent horizontal scrolling
            tooltip_height=100,  # Height to fit a few lines without scrolling
        )

        # Enable standard bindings for editing, but disable unwanted ones
        self.sheet.enable_bindings()
        # Change Find/Replace binding from Ctrl+H to Ctrl+R
        self.sheet.set_options(toggle_replace_bindings=["<Control-r>", "<Control-R>"])
        # Disable column header right-click menu and sorting options
        self.sheet.disable_bindings(
            "column_drag_and_drop",
            "row_drag_and_drop",
            "rc_select_column",
            "rc_insert_row",
            "rc_delete_row",
            "sort_cells",
            "sort_row",
            "sort_column",
            "sort_rows",
            "sort_columns",
            "undo",
        )
        # Set column widths (address is in row index now)
        self.sheet.set_column_widths([40, 200, 400, 90, 30])
        self.sheet.row_index(70)  # Set row index width
        self.sheet.readonly_columns([self.COL_USED])

        # Set up header notes with hints
        self._setup_header_notes()

        # Use bulk_table_edit_validation for paste operations ===
        # This ensures the entire paste completes before validation runs
        self.sheet.bulk_table_edit_validation(self._bulk_validate)

        # Bind to <<SheetModified>> for post-edit processing ===
        # This fires AFTER the sheet has been modified, not during
        self.sheet.bind("<<SheetModified>>", self._on_sheet_modified)

        # Apply initial column visibility
        self._toggle_used_column()
        self._toggle_init_ret_columns()  # hidden by default

        # Footer with status
        footer = ttk.Frame(self)
        footer.pack(fill=tk.X, padx=5, pady=(2, 5))

        self.status_label = ttk.Label(footer, text="Rows: 0 | Errors: 0 | Modified: 0")
        self.status_label.pack(side=tk.LEFT)

    def __init__(
        self,
        parent: tk.Widget,
        memory_type: str,
        combined_types: list[str] | None = None,
        on_nickname_changed: Callable[[int, str, str], None] | None = None,
        on_data_changed: Callable[[], None] | None = None,
        on_close: Callable[[AddressPanel], None] | None = None,
    ):
        """Initialize the address panel.

        Args:
            parent: Parent widget
            memory_type: The memory type to edit (X, Y, C, etc.)
            combined_types: List of types to show interleaved (e.g., ["T", "TD"])
            on_nickname_changed: Callback when a nickname changes (for cross-panel validation).
            on_data_changed: Callback when any data changes (for multi-window sync).
            on_close: Callback when panel close button is clicked.
        """
        super().__init__(parent)

        self.memory_type = memory_type
        self.combined_types = combined_types  # None means single type
        self.on_nickname_changed = on_nickname_changed
        self.on_data_changed = on_data_changed
        self.on_close = on_close

        self.rows: list[AddressRow] = []
        self._all_nicknames: dict[int, str] = {}
        self._displayed_rows: list[int] = []  # Data indices of currently displayed rows
        self._cells_with_notes: set[tuple[int, int]] = set()  # (row, col) pairs
        self._note_cache: dict[tuple[int, int], str] = {}

        # Flag to suppress change notifications during programmatic updates
        self._suppress_notifications = False

        # Track selected row for filter changes (actual row index in self.rows)
        self._selected_row_idx: int | None = None
        self._selected_row_visual_offset = None

        # Debounce timer for batching notifications
        self._notification_timer: str | None = None
        self._pending_nickname_changes: list[tuple[int, str, str]] = []
        self._pending_data_changed: bool = False

        self._create_widgets()

    def _populate_sheet_data(self) -> None:
        """Populate sheet with ALL row data (called once at load time).

        This sets up the full dataset and creates cell-specific checkboxes.
        """
        # Build and set all data at once
        data = [self._build_row_display_data(row) for row in self.rows]
        self.sheet.set_sheet_data(data, reset_col_positions=False)
        self.sheet.set_index_data([row.display_address for row in self.rows])

        # Create checkboxes
        for data_idx, row in enumerate(self.rows):
            # Retentive checkbox
            self.sheet.create_checkbox(
                r=data_idx,
                c=self.COL_RETENTIVE,
                checked=row.retentive,
                text="",
            )
            # Initial value checkbox
            if row.data_type == DATA_TYPE_BIT:
                init_val = data[data_idx][self.COL_INIT_VALUE]
                if init_val != "-":
                    self.sheet.create_checkbox(
                        r=data_idx,
                        c=self.COL_INIT_VALUE,
                        checked=(init_val is True),
                        text="",
                    )

    def _validate_row(self, row: AddressRow) -> None:
        """Validate a single row."""
        row.validate(self._all_nicknames)

    def _create_row_from_data(
        self,
        mem_type: str,
        addr: int,
        data: dict | None,
        all_nicknames: dict[int, str],
    ) -> AddressRow:
        """Create an AddressRow from database data or defaults.

        Args:
            mem_type: Memory type (X, Y, T, TD, etc.)
            addr: Address number
            data: Data dict from database, or None for virtual row
            all_nicknames: Global nicknames for validation

        Returns:
            Configured AddressRow
        """
        default_data_type = MEMORY_TYPE_TO_DATA_TYPE.get(mem_type, 0)
        default_retentive = DEFAULT_RETENTIVE.get(mem_type, False)

        if data:
            nickname = data.get("nickname", "")
            comment = data.get("comment", "")
            used = data.get("used", False)
            data_type = data.get("data_type", default_data_type)
            initial_value = data.get("initial_value", "")
            retentive = data.get("retentive", default_retentive)

            row = AddressRow(
                memory_type=mem_type,
                address=addr,
                nickname=nickname,
                original_nickname=nickname,
                comment=comment,
                original_comment=comment,
                used=used,
                exists_in_mdb=True,
                data_type=data_type,
                initial_value=initial_value,
                original_initial_value=initial_value,
                retentive=retentive,
                original_retentive=retentive,
            )

            # Mark X/SC/SD rows that load with invalid nicknames
            if mem_type in ("X", "SC", "SD") and nickname:
                is_valid, _ = validate_nickname(nickname, all_nicknames, row.addr_key)
                if not is_valid:
                    row.loaded_with_error = True
        else:
            row = AddressRow(
                memory_type=mem_type,
                address=addr,
                exists_in_mdb=False,
                data_type=default_data_type,
                retentive=default_retentive,
                original_retentive=default_retentive,
            )

        return row

    def _build_interleaved_rows(
        self,
        all_rows: dict[int, AddressRow],
        types: list[str],
        all_nicknames: dict[int, str],
    ) -> list[AddressRow]:
        """Build interleaved rows for combined types.

        For T+TD: T1, TD1, T2, TD2, ...
        For CT+CTD: CT1, CTD1, CT2, CTD2, ...
        """
        from .mdb_operations import get_data_for_type

        # Get existing data for all types from preloaded data
        existing_by_type = {}
        for mem_type in types:
            existing_by_type[mem_type] = get_data_for_type(all_rows, mem_type)

        # Find the common address range
        all_starts = []
        all_ends = []
        for mem_type in types:
            if mem_type in ADDRESS_RANGES:
                start, end = ADDRESS_RANGES[mem_type]
                all_starts.append(start)
                all_ends.append(end)

        if not all_starts:
            return []

        # Use the overlapping range
        range_start = max(all_starts)
        range_end = min(all_ends)

        rows = []
        for addr in range(range_start, range_end + 1):
            # Add a row for each type at this address (interleaved)
            for mem_type in types:
                data = existing_by_type[mem_type].get(addr)
                row = self._create_row_from_data(mem_type, addr, data, all_nicknames)
                rows.append(row)

        return rows

    def _build_single_type_rows(
        self,
        all_rows: dict[int, AddressRow],
        mem_type: str,
        all_nicknames: dict[int, str],
    ) -> list[AddressRow]:
        """Build rows for a single memory type."""
        from .mdb_operations import get_data_for_type

        start, end = ADDRESS_RANGES[mem_type]
        existing = get_data_for_type(all_rows, mem_type)

        rows = []
        for addr in range(start, end + 1):
            data = existing.get(addr)
            row = self._create_row_from_data(mem_type, addr, data, all_nicknames)
            rows.append(row)

        return rows

    def load_data(
        self,
        all_rows: dict[int, AddressRow],
        all_nicknames: dict[int, str],
    ) -> None:
        """Load all addresses for this memory type.

        Args:
            all_rows: Dict mapping AddrKey to AddressRow (preloaded data)
            all_nicknames: Global dict of all nicknames for validation
        """
        # Suppress notifications during load to avoid triggering sync logic
        self._suppress_notifications = True

        try:
            # Check if this is a combined type panel
            if self.combined_types and len(self.combined_types) > 1:
                self.rows = self._build_interleaved_rows(
                    all_rows, self.combined_types, all_nicknames
                )
            else:
                self.rows = self._build_single_type_rows(all_rows, self.memory_type, all_nicknames)

            self._all_nicknames = all_nicknames
            self._validate_all()

            # Populate sheet with ALL data once (use display_rows for filtering)
            self._populate_sheet_data()

            # Apply initial filters (uses display_rows internally)
            self._apply_filters()

            self._refresh_display()
        finally:
            self._suppress_notifications = False

    def update_from_external(
        self,
        all_rows: dict[int, AddressRow],
        all_nicknames: dict[int, str],
    ) -> None:
        """Update data from external source (e.g., MDB file changed).

        Only updates non-dirty rows to preserve user edits.

        Args:
            all_rows: Dict mapping AddrKey to AddressRow (preloaded data)
            all_nicknames: Global dict of all nicknames
        """
        # Suppress notifications during external update
        self._suppress_notifications = True

        try:
            from .mdb_operations import get_data_for_type

            # Get fresh data from preloaded rows
            if self.combined_types and len(self.combined_types) > 1:
                existing_by_type = {}
                for mem_type in self.combined_types:
                    existing_by_type[mem_type] = get_data_for_type(all_rows, mem_type)
            else:
                existing_data = get_data_for_type(all_rows, self.memory_type)

            # Update non-dirty rows
            for row in self.rows:
                if row.is_dirty:
                    # Skip dirty rows - preserve user edits
                    continue

                # Get fresh data for this row
                if self.combined_types and len(self.combined_types) > 1:
                    data = existing_by_type.get(row.memory_type, {}).get(row.address)
                else:
                    data = existing_data.get(row.address)

                if data:
                    # Update from database
                    row.nickname = data.get("nickname", "")
                    row.original_nickname = row.nickname
                    row.comment = data.get("comment", "")
                    row.original_comment = row.comment
                    row.used = data.get("used", False)
                    row.initial_value = data.get("initial_value", "")
                    row.original_initial_value = row.initial_value
                    row.retentive = data.get("retentive", row.retentive)
                    row.original_retentive = row.retentive
                    row.exists_in_mdb = True
                else:
                    # Row no longer exists in database - reset to defaults
                    row.nickname = ""
                    row.original_nickname = ""
                    row.comment = ""
                    row.original_comment = ""
                    row.used = False
                    row.initial_value = ""
                    row.original_initial_value = ""
                    row.exists_in_mdb = False

            # Update nickname registry and revalidate
            self._all_nicknames = all_nicknames
            self._validate_all()

            # Update all row displays with new data
            for data_idx in range(len(self.rows)):
                self._update_row_display(data_idx)

            # Refresh styling and status
            self._refresh_display()

        finally:
            self._suppress_notifications = False

    def revalidate(self) -> None:
        """Re-validate all rows (called when global nicknames change)."""
        self._validate_all()
        self._refresh_display()

    def refresh_from_external(self) -> None:
        """Refresh all row displays after external data changes.

        Call this when AddressRow objects have been updated externally
        (e.g., via row.update_from_db()) to sync the sheet's cell data.
        """
        # Update all row displays to sync AddressRow data to sheet cells
        for data_idx in range(len(self.rows)):
            self._update_row_display(data_idx)

        # Revalidate and refresh styling
        self._validate_all()
        self._refresh_display()

    def get_dirty_rows(self) -> list[AddressRow]:
        """Get all rows that have been modified."""
        return [row for row in self.rows if row.is_dirty]

    def has_errors(self) -> bool:
        """Check if any rows have validation errors."""
        return any(row.has_reportable_error for row in self.rows)

    def get_error_count(self) -> int:
        """Get count of rows with validation errors."""
        return sum(1 for row in self.rows if row.has_reportable_error)

    def _clear_row_highlight(self, data_idx: int) -> None:
        """Clear the temporary highlight from a row and restore normal styling.

        Args:
            data_idx: The data index of the row to clear
        """
        # Dehighlight the row
        for col in range(5):  # 5 data columns
            self.sheet.dehighlight_cells(row=data_idx, column=col)
        self.sheet.dehighlight_cells(row=data_idx, canvas="row_index")

        # Re-apply normal styling (this will restore any state-based highlights)
        self._apply_row_styling()
        self.sheet.set_refresh_timer()

    def _highlight_row(self, data_idx: int, duration_ms: int = 1500) -> None:
        """Temporarily highlight a row to draw user attention.

        Args:
            data_idx: The data index of the row to highlight
            duration_ms: How long to show the highlight in milliseconds
        """
        # Highlight all visible columns with a distinct color
        highlight_color = "#90EE90"  # Light green
        for col in range(5):  # 5 data columns
            self.sheet.highlight_cells(
                row=data_idx,
                column=col,
                bg=highlight_color,
            )
        # Also highlight the row index
        self.sheet.highlight_cells(
            row=data_idx,
            bg=highlight_color,
            canvas="row_index",
        )
        self.sheet.set_refresh_timer()

        # Schedule removal of highlight
        self.after(duration_ms, lambda: self._clear_row_highlight(data_idx))

    def scroll_to_address(
        self, address: int, memory_type: str | None = None, align_top: bool = False
    ) -> bool:
        """Scroll to show a specific address.

        Args:
            address: The address number to scroll to
            memory_type: Optional memory type for combined panels
            align_top: If True, ensure the address is at the top of the viewport.
                       If False (default), just ensure it's visible somewhere in the viewport.

        Returns:
            True if address was found and scrolled to
        """
        # Find the row index for this address
        target_type = memory_type or self.memory_type

        row_idx = None
        for i, row in enumerate(self.rows):
            if row.address == address and row.memory_type == target_type:
                row_idx = i
                break

        if row_idx is None:
            # Try without type match (for single-type panels)
            for i, row in enumerate(self.rows):
                if row.address == address:
                    row_idx = i
                    break

        if row_idx is None:
            return False

        # Check if it's visible in current filter
        if row_idx not in self._displayed_rows:
            self.filter_var.set("")
            self.hide_empty_var.set(False)
            self.hide_assigned_var.set(False)
            self._apply_filters()

        try:
            display_idx = self._displayed_rows.index(row_idx)

            # Use helper function for scrolling
            self._scroll_to_row(display_idx, align_top=align_top)

            # Highlight the row briefly to show the user where it is
            self._highlight_row(row_idx)
            return True
        except ValueError:
            return False
