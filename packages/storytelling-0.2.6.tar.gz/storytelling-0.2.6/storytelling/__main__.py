"""Entry point for storytelling package when called as a module."""

from .cli import main

if __name__ == "__main__":
    exit(main())
