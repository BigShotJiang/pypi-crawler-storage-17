dbt-utils.json source: https://hub.getdbt.com/api/v1/dbt-labs/dbt_utils.json
