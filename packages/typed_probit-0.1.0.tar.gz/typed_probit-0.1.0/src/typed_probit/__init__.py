"""
### Typed Probit
> A fully typed, validated async client for the Probit API

- Details
"""