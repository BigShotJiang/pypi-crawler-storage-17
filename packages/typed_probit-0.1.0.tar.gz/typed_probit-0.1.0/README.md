# Typed Probit

> A fully typed, validated async client for the Probit API

Use *autocomplete* instead of documentation.

🚧 Under construction.