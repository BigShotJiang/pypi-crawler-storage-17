from mijnbib import __version__

USER_AGENT = f"{__package__} v{__version__}"
TIMEOUT = 30
