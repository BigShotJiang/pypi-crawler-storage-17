Send the invoices to the Peppol accesspoint immediately when the user clicks Send in the
invoice Send & Print wizard.
