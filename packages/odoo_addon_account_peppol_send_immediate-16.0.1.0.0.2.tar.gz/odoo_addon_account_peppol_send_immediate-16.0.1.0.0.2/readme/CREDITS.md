This backport was financially supported by ACSONE.
