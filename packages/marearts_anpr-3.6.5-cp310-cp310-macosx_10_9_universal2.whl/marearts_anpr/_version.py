"""Version information for marearts-anpr package."""

__version__ = "3.6.5"