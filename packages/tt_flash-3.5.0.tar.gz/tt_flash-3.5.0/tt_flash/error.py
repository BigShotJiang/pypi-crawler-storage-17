# SPDX-FileCopyrightText: © 2024 Tenstorrent AI ULC
# SPDX-License-Identifier: Apache-2.0


class TTError(Exception):
    """Base class for exceptions in this module."""

    pass
