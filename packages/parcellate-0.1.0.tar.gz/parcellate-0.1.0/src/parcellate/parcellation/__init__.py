"""Parcellation utilities for volumetric images."""

from parcellate.parcellation.volume import VolumetricParcellator

__all__ = ["VolumetricParcellator"]
