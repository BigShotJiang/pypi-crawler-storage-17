from parcellate.utils.image import _load_nifti

__all__ = ["_load_nifti"]
