from parcellate.parcellation import VolumetricParcellator

__all__ = ["VolumetricParcellator"]
