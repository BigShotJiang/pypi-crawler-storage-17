"""mitol.hubspot_api"""

default_app_config = "mitol.hubspot_api.apps.HubspotApiApp"

__version__ = "2025.12.18"
__distributionname__ = "mitol-django-hubspot-api"
