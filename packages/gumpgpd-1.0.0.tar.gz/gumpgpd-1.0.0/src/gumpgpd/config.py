"""
Not in use currently. Can be used to set config parameters.
"""
# Turn it on (set to true) so the cost function will save the results to files
# Only used after the fit is finished!
Export_Mode = False

INC_JPSI = False

INC_gGFF = False