"""ATSPM Report Generator - Anomaly detection for traffic signal data."""

from .generator import ReportGenerator

__version__ = "0.0.0"
__all__ = ["ReportGenerator"]
