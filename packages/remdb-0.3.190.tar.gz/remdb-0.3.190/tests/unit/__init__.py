"""
Unit tests for REM
"""
