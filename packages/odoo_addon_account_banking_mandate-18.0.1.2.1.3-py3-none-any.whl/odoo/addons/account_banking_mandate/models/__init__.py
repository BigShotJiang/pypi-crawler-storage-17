from . import account_banking_mandate
from . import account_payment_method
from . import account_move
from . import res_partner_bank
from . import res_partner
from . import account_payment_line
from . import account_move_line
from . import account_payment
