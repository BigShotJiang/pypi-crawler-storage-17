The following individuals have contributed code to agate-lookup:

* `Christopher Groskopf <https://github.com/onyxfish>`_
* `James McKinney <https://github.com/jpmckinney>`_
