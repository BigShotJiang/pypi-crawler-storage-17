# -*- coding: utf-8 -*-
"""
Data package for wparc.

This package contains data files used by the WordPress API crawler.
"""
