# Tutorials

Start here if you are new to fsspeckit and want a guided introduction.

- [Getting Started](getting-started.md) – Install fsspeckit, configure storage, and run your first dataset workflow

