============
 oslo.limit
============

Limit enforcement library to assist with quota calculation.

Contents
========

.. toctree::
   :maxdepth: 2

   install/index
   contributor/index
   reference/index
   user/index

Release Notes
=============

Read also the `oslo.limit Release Notes
<https://docs.openstack.org/releasenotes/oslo.limit/>`_.

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

