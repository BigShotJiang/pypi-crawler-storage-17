MAX_MESSAGE_LENGTH = 4096

TELEGRAM_SEND_MESSAGE_URL = 'https://api.telegram.org/bot{bot_token}/sendMessage'
