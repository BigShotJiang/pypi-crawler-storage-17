"""Set of acquisition function optimizer."""
