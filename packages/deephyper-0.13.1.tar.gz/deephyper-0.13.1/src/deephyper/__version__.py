"""Define version number for the package."""

__version__ = "0.13.1"

# alpha/beta/rc tags
__version_suffix__ = ""
