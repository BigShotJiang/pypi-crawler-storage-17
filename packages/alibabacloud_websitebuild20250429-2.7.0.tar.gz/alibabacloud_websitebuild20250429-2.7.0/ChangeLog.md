2025-11-06 Version: 2.6.1
- Generated python 2025-04-29 for WebsiteBuild.

2025-11-06 Version: 2.6.0
- Support API DispatchConsoleAPIForPartner.
- Support API GetUserAccessTokenForPartner.


2025-09-19 Version: 2.5.0
- Support API BindAppDomain.
- Support API DeleteAppDomainCertificate.
- Support API DeleteAppDomainRedirect.
- Support API DescribeAppDomainDnsRecord.
- Support API ListAppDomainRedirectRecords.
- Support API ListAppInstanceDomains.
- Support API SetAppDomainCertificate.
- Support API UnbindAppDomain.


2025-09-12 Version: 2.4.0
- Support API GetDomainInfoForPartner.


2025-09-09 Version: 2.3.0
- Support API GetIcpFilingInfoForPartner.
- Support API GetUserTmpIdentityForPartner.


2025-08-01 Version: 2.2.0
- Support API SearchImage.


2025-07-23 Version: 2.1.0
- Support API SyncAppInstanceForPartner.


2025-07-10 Version: 2.0.0
- Update API CreateLogoTask: add request parameters LogoVersion.
- Update API CreateLogoTask: delete request parameters Version.


2025-06-25 Version: 1.2.1
- Generated python 2025-04-29 for WebsiteBuild.

2025-06-24 Version: 1.2.0
- Support API CreateLogoTask.
- Support API GetCreateLogoTask.


2025-06-12 Version: 1.1.0
- Support API OperateAppInstanceForPartner.


2025-05-24 Version: 1.0.0
- Generated python 2025-04-29 for WebsiteBuild.

