from __future__ import annotations

from logging import getLogger

LOGGER = getLogger("actions")


__all__ = ["LOGGER"]
