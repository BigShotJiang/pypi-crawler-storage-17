# Test data

Test files required by the test suite:

* The RGB-red.byte.tif file was obtained from [rasterio](https://github.com/rasterio/rasterio) test suite and downsampled to reduce its size. The original image is derived from USGS Landsat 7 ETM imagery and is licensed under the [CC0 1.0 Universal (CC0 1.0) Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/).
