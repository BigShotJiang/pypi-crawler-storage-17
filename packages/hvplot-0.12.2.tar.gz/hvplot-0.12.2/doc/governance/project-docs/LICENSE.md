# License

For the license, see [HoloViz/hvPlot - LICENSE.txt](https://github.com/holoviz/hvplot/blob/main/LICENSE).
