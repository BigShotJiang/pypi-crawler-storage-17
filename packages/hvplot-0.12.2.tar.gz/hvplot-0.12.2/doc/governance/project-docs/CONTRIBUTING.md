# Contributing

For the contributing policy, see [HoloViz/HoloViz - CONTRIBUTING.md](https://github.com/holoviz/holoviz/blob/hvplot-gov/doc/governance/project-docs/CONTRIBUTING.md).

The hvPlot Project’s equivalently named documents take precedence over any external materials referenced within this linked document above.
