
from setuptools import setup

setup(package_data={'assertpy-stubs': ['__init__.pyi', 'assertpy.pyi', 'base.pyi', 'collection.pyi', 'contains.pyi', 'date.pyi', 'dict.pyi', 'dynamic.pyi', 'exception.pyi', 'extracting.pyi', 'file.pyi', 'helpers.pyi', 'numeric.pyi', 'snapshot.pyi', 'string.pyi', 'METADATA.toml', 'py.typed']})
