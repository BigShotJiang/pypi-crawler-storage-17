from __future__ import annotations

# Force "international" dates with 24h time
SHORT_DATE_FORMAT = "Y/m/d"
SHORT_DATETIME_FORMAT = "Y/m/d H:i"
