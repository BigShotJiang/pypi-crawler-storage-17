Elasticipy.tensors.fourth_order
======================================

.. automodule:: elasticipy.tensors.fourth_order
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
