"""MCP Resources for BigKinds."""

from . import news
