"""Core components for BigKinds MCP Server."""
