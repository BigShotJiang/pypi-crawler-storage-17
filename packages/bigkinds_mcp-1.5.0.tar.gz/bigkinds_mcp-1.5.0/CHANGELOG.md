# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.2.1] - 2025-12-15

### Fixed
- **기사 URL 반환 수정**: `PROVIDER_LINK_PAGE` 필드 매핑 추가로 실제 언론사 기사 URL 반환

---

## [1.2.0] - 2025-12-15

### Fixed
- **필터 기능 완전 수정** (86% → 100% 성공률)
  - 카테고리 필터: 9-digit 숫자 코드로 수정 (001000000~008000000)
  - 언론사 필터: 실제 API 응답 기준 72개 체계적 수집
  - 사용자는 여전히 친화적 이름 사용 가능 ("경향신문", "IT_과학" 등)
- **total_pages 정확도 수정**: 병합된 결과 수가 아닌 API 실제 총 개수 사용
- **ArticleSummary 스키마 보강**: provider_code, category_code 필드 추가

### Added
- **새 분석 도구 3개**:
  - `compare_keywords`: 여러 키워드 트렌드 비교 분석
  - `smart_sample`: 대용량 검색 결과에서 대표 샘플 추출 (3가지 전략)
  - `cache_stats`: 캐시 사용 현황 모니터링
- **GitHub Actions 워크플로**:
  - 자동 테스트 (test.yml)
  - PyPI 자동 배포 (publish.yml)
  - 월간 필터 검증 (filter-validation.yml)
- **PDCA 문서화**: 개선 프로세스 전체 문서화 (docs/pdca/improvement-2025-12-15/)

### Changed
- 언론사 코드 커버리지: 23개 → 72개 (종합일간지, 경제지, 지역일간지, 방송사 등)
- 테스트 커버리지 강화: 필터 관련 테스트 3개 추가

## [1.1.2] - 2025-12-10

### Fixed
- 기사 조회 시 news_id만으로 조회 가능하도록 URL 캐시 추가
- 언론사/카테고리 필터 이름→코드 자동 변환 기능 개선

## [1.1.0] - 2025-12-08

### Added
- PyPI 배포 설정 완료
- MCP 서버 전체 구현 완료

### Fixed
- 다양한 버그 수정 및 안정성 개선

## [1.0.0] - 2025-12-01

### Added
- 초기 릴리즈
- BigKinds MCP Server 기본 기능 구현
