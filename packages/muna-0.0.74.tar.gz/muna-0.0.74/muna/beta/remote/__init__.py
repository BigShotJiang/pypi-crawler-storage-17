# 
#   Muna
#   Copyright © 2025 NatML Inc. All Rights Reserved.
#

from .prediction import PredictionService
from .schema import RemoteAcceleration, RemotePrediction, RemoteValue
from .utils import remote_value_to_object