"""CLI commands for devs webhook."""

# Import main CLI from parent module
from ..main_cli import main

__all__ = ["main"]