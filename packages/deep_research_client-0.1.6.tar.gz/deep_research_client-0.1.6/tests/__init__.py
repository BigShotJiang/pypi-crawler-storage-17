"""Tests for deep-research-client."""
