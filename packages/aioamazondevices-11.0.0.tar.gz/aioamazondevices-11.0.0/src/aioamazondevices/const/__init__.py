"""aioamazondevices const package."""
