.. _class_diagrams:

Class Diagram
=============

.. image:: classes.png
    :alt: FIREWHEEL Class Diagram
    :width: 100 %

.. _package_diagrams:

Package Diagram
===============

.. image:: packages.png
    :alt: FIREWHEEL Package Diagram
    :width: 100 %
