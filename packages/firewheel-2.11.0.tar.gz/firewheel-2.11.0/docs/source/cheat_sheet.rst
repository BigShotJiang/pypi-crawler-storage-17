*********************
FIREWHEEL Cheat Sheet
*********************

.. raw:: html

    <p>You can download the cheat sheet here: <a href="_static/FIREWHEEL_Cheat_Sheet_final.pdf" target="_blank">FIREWHEEL Cheat Sheet</a></p>

