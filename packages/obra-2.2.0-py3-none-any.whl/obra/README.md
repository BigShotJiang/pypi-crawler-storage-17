# Obra

Cloud-native AI orchestration platform for autonomous software development.

## Overview

Obra combines server-side intelligence with client-side execution to provide a powerful, scalable AI orchestration system. The server handles strategic planning, quality review, and refinement logic, while the client executes LLM calls and code operations locally.

## Installation

```bash
pip install obra
```

## Quick Start

```bash
# Authenticate
obra login

# Start a derivation workflow
obra derive "Add user authentication to the application"

# Check session status
obra status

# Resume an interrupted session
obra resume <session-id>

# View/edit configuration
obra config
```

## Features

- **Hybrid Architecture**: Server intelligence + client execution
- **Quality-Gated Refinement**: Iterative improvement with automated quality checks
- **Multi-Agent Review**: Security, testing, documentation, and code quality agents
- **Resume Support**: Seamlessly resume interrupted sessions
- **Rich CLI**: Beautiful terminal UI with progress tracking

## Commands

| Command | Description |
|---------|-------------|
| `obra login` | Authenticate with Obra |
| `obra logout` | Clear stored credentials |
| `obra whoami` | Show current user |
| `obra derive` | Start orchestrated workflow |
| `obra status` | Check session status |
| `obra resume` | Resume interrupted session |
| `obra config` | Manage configuration |
| `obra version` | Show version info |

## Requirements

- Python 3.12+
- Active Obra account (sign up at [obra.dev](https://obra.dev))

## Documentation

Full documentation available at [obra.dev/docs](https://obra.dev/docs)

## Migration from obra-client

If you were using `obra-client`, migrate to `obra`:

```bash
pip uninstall obra-client
pip install obra
```

The CLI commands have been simplified:
- `obra-client orchestrate` -> `obra derive`
- `obra-client setup` -> `obra login`

## License

Proprietary - All Rights Reserved. Copyright (c) 2024-2025 Unpossible Creations, Inc.

See [LICENSE](https://github.com/Unpossible-Creations/Obra/blob/main/LICENSE) for details.
