"""Initialize the app"""

__version__ = "3.2.3"
__title__ = "BigBrother"
