"""
Helpers for constructing links against shared blacklist tools.
"""

def generate_blacklist_links():
    """
    Returns an empty string. Placeholder for future coalition blacklist integration.
    """
    return ""
