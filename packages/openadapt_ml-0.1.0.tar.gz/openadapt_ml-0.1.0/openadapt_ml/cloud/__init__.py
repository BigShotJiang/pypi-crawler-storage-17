"""Cloud GPU providers for training."""

from openadapt_ml.cloud.lambda_labs import LambdaLabsClient

__all__ = ["LambdaLabsClient"]
