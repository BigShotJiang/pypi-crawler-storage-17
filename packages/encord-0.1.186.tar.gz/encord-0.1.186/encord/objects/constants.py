"""---
title: "Objects - Constants"
slug: "sdk-ref-objects-constant"
hidden: false
metadata:
  title: "Objects - Constants"
  description: "Encord SDK Objects - Constants."
category: "64e481b57b6027003f20aaa0"
---
"""

from __future__ import annotations

# for backwards compatibility
from encord.common.constants import DATETIME_LONG_STRING_FORMAT

DEFAULT_CONFIDENCE = 1.0
DEFAULT_MANUAL_ANNOTATION = True
AVAILABLE_COLORS = (
    "#D33115",
    "#E27300",
    "#16406C",
    "#FE9200",
    "#FCDC00",
    "#DBDF00",
    "#A4DD00",
    "#68CCCA",
    "#73D8FF",
    "#AEA1FF",
    "#FCC400",
    "#B0BC00",
    "#68BC00",
    "#16A5A5",
    "#009CE0",
    "#7B64FF",
    "#FA28FF",
    "#B3B3B3",
    "#9F0500",
    "#C45100",
    "#FB9E00",
    "#808900",
    "#194D33",
    "#0C797D",
    "#0062B1",
    "#653294",
    "#AB149E",
)
