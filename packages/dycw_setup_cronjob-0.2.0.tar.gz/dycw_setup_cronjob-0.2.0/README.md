# `setup-cronjob`

Library to set up cron jobs

## Installation

```console
uv add dycw-setup-cronjob
```
