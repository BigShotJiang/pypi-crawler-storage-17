
def bytes_to_gb(x: int) -> float:
    return x / (1024 ** 3)


