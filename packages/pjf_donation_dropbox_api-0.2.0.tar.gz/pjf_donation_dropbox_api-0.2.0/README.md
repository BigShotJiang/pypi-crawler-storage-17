# pjf_donation_dropbox_api

A python package that allows software to connect to the Philippine Jesuit Foundation's Donations Dropbox through various data stores like the dropbox cloud, file system, and a custom database.

## Installation

```bash
$ pip install pjf_donation_dropbox_api
```

## Usage

`pjf_donation_dropbox_api` can be used to connect to the dropbox account and cache it as a sqlite database in a local mount as follows:

```python
DROPBOX_ACCESS_TOKEN = os.getenv("DROPBOX_ACCESS_TOKEN")

dropbox_fs = pjf_donation_dropbox_api.DropboxCloudFileSystem(DROPBOX_ACCESS_TOKEN)

# We create a CachedFilesDatabase object from this package that will reference and read the dropbox object.
db = pjf_donation_dropbox_api.CachedFilesDatabase(dropbox_fs_reference=dropbox_fs, autosave=False)

sqlite_db_to_store_dropbox = "/path/to/db.sqlite" # you could also store in sqlite memory.

# The database object copies the entire dropbox starting from the root. It then places each file and excel file as a database record in the table. Knowing the schema of the underlying db is not required for the API user. You can still access the cached files through methods like .read() below.
db.save_entire_state(destination_path=sqlite_db_to_store_dropbox)

# Read back the file to verify
file = db.read("/test_data_folder/test_file.txt")
```



## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`pjf_donation_dropbox_api` was created by Kenneth Salanga. It is licensed under the terms of the Proprietary license.

## Credits

`pjf_donation_dropbox_api` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
