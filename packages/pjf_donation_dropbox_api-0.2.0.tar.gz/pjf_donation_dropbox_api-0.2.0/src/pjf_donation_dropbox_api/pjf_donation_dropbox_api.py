from __future__ import annotations
import io
import os
from datetime import datetime, timezone
from typing import Protocol, Dict, List, Optional, Any
from dataclasses import dataclass
import dropbox  # from dropbox package
from dropbox.files import FileMetadata
import peewee as pw

from pjf_donation_dropbox_api.file_formats import Excel, File
from pjf_donation_dropbox_api.models import ExcelDbDocument, FileDbDocument

# =====================
# Interfaces
# =====================

class FileReader(Protocol):
    """<<Interface>> Defines file reading operations.
    
    This protocol defines the interface for reading various file types
    from different storage systems.
    """

    def read(self, path: str) -> File:
        """Read a generic file.
        
        Parameters
        ----------
        path : str
            Path to the file to read.
            
        Returns
        -------
        File
            File object containing content and metadata.
        """
        ...

    def read_excel(self, path: str) -> "Excel":
        """Read an Excel file and return an Excel object.
        
        Parameters
        ----------
        path : str
            Path to the Excel file to read.
            
        Returns
        -------
        Excel
            Excel object containing workbook and dataframes.
        """
        ...

    # Future extensions
    def readcsv(self) -> Any: ...
    def readpdf(self, path: str) -> Any: ...
    def readword(self, path: str) -> Any: ...

class FileWriter(Protocol):
    """<<Interface>> Defines file writing operations.
    
    This protocol defines the interface for writing files to
    different storage systems.
    """

    def write(self, file_from: str, file_to: str) -> None:
        """Write file from source to destination (generic copy).
        
        Parameters
        ----------
        file_from : str
            Source file path to copy from.
        file_to : str
            Destination file path to copy to.
        """
        ...

    # Future extensions
    def writeexcel(self, path: str, sheet: str, content: List[List[Any]], metadata: Dict[str, Any]) -> None: ...
    def writecsv(self) -> None: ...
    def writepdf(self, path: str, content: Any, metadata: Dict[str, Any]) -> None: ...
    def writeword(self, path: str, content: Any, metadata: Dict[str, Any]) -> None: ...

class Savable(Protocol):
    """<<Interface>> Defines save/load operations for objects.
    
    This protocol defines the interface for saving and loading
    object state to persistent storage.
    """

    def save_entire_state(self, destination_path: str) -> None:
        """Save object state to destination path.
        
        Parameters
        ----------
        destination_path : str
            Path where the object state will be saved.
        """
        ...

# =====================
# Implementations
# =====================

@dataclass
class LocalFileSystem(FileReader, Savable):
    """Concrete implementation using local filesystem.
    
    This class provides file reading operations from a local filesystem
    with optional caching of Dropbox files.
    
    Attributes
    ----------
    local_root_path : str
        Path to the local filesystem root directory (relative to the running
        script's working directory). This attribute ONLY applies if dropbox_fs is None.
    """

    # path is relative to the running script's working directory
    local_root_path: str

    def __init__(self, local_root_path: str | None = None,
                 dropbox_fs: DropboxCloudFileSystem | None = None,
                 autosave: bool = False, autosave_location: str | None = None):
        """Initialize a LocalFileSystem by path or a dropbox filesystem.
        
        Parameters
        ----------
        path : str, optional
            Path to the local filesystem root directory.
        dropbox_fs : DropboxCloudFileSystem, optional
            Dropbox filesystem to use as source.
        autosave : bool, default=False
            If True, automatically cache ALL files locally.
        autosave_location : str, optional
            Local path to cache ALL files if autosave is True.
            
        Raises
        ------
        ValueError
            If both path and dropbox_fs are provided, or 
            if autosave is True but autosave_location is not provided, or 
            if path does not exist.
        """

        # Can only set one of path or dropbox_fs
        if local_root_path and dropbox_fs:
            raise ValueError("Only one of path or dropbox_fs can be set.")
        
        self.local_root_path = local_root_path
        self.dropbox_fs = dropbox_fs
        self.autosave = autosave
        self.autosave_location = autosave_location

        
        if local_root_path:
            if local_root_path and not os.path.exists(local_root_path):
                raise ValueError(f"Local path {local_root_path} does not exist.")
            self.local_root_path = local_root_path or ""
            self.dropbox_fs = None
        else:
            self.dropbox_fs = dropbox_fs

            if self.autosave and self.autosave_location:
                self.autosave = autosave
                self.autosave_location = autosave_location
                self.save_entire_state(self.autosave_location)
            elif self.autosave and not self.autosave_location:
                raise ValueError("autosave_location must be provided if autosave is True.")
                

    def read(self, path: str) -> File:
        """Read a file from the local filesystem, Dropbox cloud source, or dropbox cloud source that has been optionally cached into a local file system. 
        
        If there is a Dropbox source and it is not saved as a local file system cache, read uses the dropbox source to get files.

        Parameters
        ----------
        path : str
            Path to the file relative to the local_root_path or dropbox_fs object declared in constructor.
            
        Returns
        -------
        File
            File object containing content and metadata.
        """
        if self.dropbox_fs and not self.autosave:
            return self.dropbox_fs.read(path)
        
        if self.dropbox_fs and self.autosave:
            # Read path from auto save location as the cache mount
            cached_path = os.path.join(self.autosave_location, path.lstrip("/"))
            # standardize cached_path to use forward slashes
            cached_path = cached_path.replace("\\", "/")
            with open(cached_path, "rb") as f:
                file_bytes = io.BytesIO(f.read())
                file_metadata = os.stat(cached_path)

                return File(
                    id=hash(path),
                    path=path,
                    content=file_bytes,
                    metadata=file_metadata
                )
                

        with open(path, "rb") as f:
            return File(
                id=hash(path),
                path=path,
                content= io.BytesIO(f.read()),
                metadata=os.stat(path)
            )

    def read_excel(self, path: str) -> Excel:
        """Read an Excel file from the local filesystem or Dropbox.
        
        Parameters
        ----------
        path : str
            Path to the Excel file relative to the local_root_path or dropbox_fs object declared in constructor.
            
        Returns
        -------
        Excel
            Excel object containing workbook and dataframes.
        """
        if self.dropbox_fs and not self.autosave:
            return self.dropbox_fs.read_excel(path)
        
        if self.dropbox_fs and self.autosave:
            # Read path from auto save location as the cache mount
            cached_path = os.path.join(self.autosave_location, os.path.relpath(path, self.local_root_path))
            return Excel(file_path=cached_path)
        
        return Excel(file_path=path)
    
    def save_entire_state(self, destination_path):
        """Save all files from Dropbox filesystem to local path.
        
        Parameters
        ----------
        destination_path : str
            Local directory path root to save all files to.
            
        Raises
        ------
        ValueError
            If no dropbox filesystem is configured.
        """
        
        # If the dropbox_fs field is not set or is None, raise an error
        if not self.dropbox_fs:
            raise ValueError("No dropbox filesystem to save from.")
        
        # If dropbox_fs is not type DropboxCloudFileSystem, raise an error
        if not isinstance(self.dropbox_fs, DropboxCloudFileSystem):
            raise ValueError("dropbox_fs must be an instance of DropboxCloudFileSystem.")

        # Save all files from dropbox_fs to local destination path
        if not os.path.exists(destination_path):
            os.makedirs(destination_path)

        for dropbox_file_path in self.dropbox_fs.traverse(""):
            local_path = os.path.join(destination_path, dropbox_file_path.lstrip("/"))
            local_dir = os.path.dirname(local_path)
            if not os.path.exists(local_dir):
                os.makedirs(local_dir)

            with open(local_path, "wb") as f:
                f.write(self.dropbox_fs.read(dropbox_file_path).content.getvalue())
        
    def traverse_root(self) -> List[str]:
        """List all file paths in the root directory initiated in the constructor.
        
        Returns
        -------
        list of str
            List of all file paths in the root directory, with paths
            standardized to use forward slashes.
        """
        if not self.local_root_path:
            return self.dropbox_fs.traverse("") 

        file_paths = []
        for root, _, files in os.walk(self.local_root_path or self.autosave_location):
            for file in files:
                # join the root and file and standardize to use forward slashes
                full_path = os.path.join(root, file).replace("\\", "/")
                file_paths.append(full_path)
        return file_paths

@dataclass
class DropboxCloudFileSystem(FileReader, FileWriter):
    """Implements FileReader/FileWriter using Dropbox API.
    
    This class provides file reading and writing operations using
    the Dropbox cloud storage service.
    
    Attributes
    ----------
    dropbox : dropbox.Dropbox
        Dropbox API client instance.
    """
    dropbox: dropbox.Dropbox

    def __init__(self, access_token: str):
        """Initialize Dropbox filesystem with access token.
        
        Parameters
        ----------
        access_token : str
            Dropbox API access token for authentication.
        """
        self.dropbox = dropbox.Dropbox(access_token)

    def read(self, path: str) -> File:
        """Read a file from Dropbox.
        
        Parameters
        ----------
        path : str
            Path to the file in Dropbox.
            
        Returns
        -------
        File
            File object containing content and metadata.
        """
        dropbox_metadata, res = self.dropbox.files_download(path)

        file_bytes = io.BytesIO(res.content)

        file_metadata = DropboxCloudFileSystem.dropbox_to_stat(dropbox_metadata)

        return File(
            id=hash(path),
            path=path,
            content=file_bytes,
            metadata=file_metadata
        )

    def read_excel(self, path: str) -> Excel:
        """Read an Excel file from Dropbox.
        
        Downloads the Excel file to a temporary location, loads it,
        and then removes the temporary file.
        
        Parameters
        ----------
        path : str
            Path to the Excel file in Dropbox.
            
        Returns
        -------
        Excel
            Excel object containing workbook and dataframes.
        """
        _, res = self.dropbox.files_download(path)
        temp_file = "temp.xlsx"
        with open(temp_file, "wb") as f:
            f.write(res.content)
        
        excel = Excel(file_path=temp_file)
        os.remove(temp_file)

        return excel

    def write(self, file_from: str, file_to: str) -> None:
        """Write a file to Dropbox.
        
        Uploads a local file to Dropbox, overwriting if it exists.
        
        Parameters
        ----------
        file_from : str
            Local file path to upload from.
        file_to : str
            Dropbox path to upload to.
        """
        with open(file_from, "rb") as f:
            self.dropbox.files_upload(f.read(), file_to, mode=dropbox.files.WriteMode.overwrite)

    def dropbox_to_stat(metadata: FileMetadata) -> os.stat_result:
        """Convert Dropbox FileMetadata to os.stat_result.
        
        Parameters
        ----------
        metadata : dropbox.files.FileMetadata
            Dropbox file metadata to convert.
            
        Returns
        -------
        os.stat_result
            Standard Python file stat result.
            
        Raises
        ------
        TypeError
            If metadata is not a FileMetadata instance.
        """
        if not isinstance(metadata, FileMetadata):
            raise TypeError("Expected dropbox.files.FileMetadata")

        st_mode = 0o100644  # regular file, rw-r--r--
        st_ino = 0
        st_dev = 0
        st_nlink = 1
        st_uid = os.getuid() if hasattr(os, "getuid") else 1000
        st_gid = os.getgid() if hasattr(os, "getgid") else 1000
        st_size = metadata.size or 0

        st_mtime = metadata.server_modified.timestamp()
        st_atime = metadata.client_modified.timestamp()
        st_ctime = st_mtime  # Dropbox lacks creation time info

        return os.stat_result((
            st_mode, st_ino, st_dev, st_nlink,
            st_uid, st_gid, st_size,
            st_atime, st_mtime, st_ctime
        ))


    def stat_to_dropbox(
        path: str,
        stat: os.stat_result,
        rev: Optional[str] = None
    ) -> FileMetadata:
        """Convert os.stat_result to synthetic Dropbox FileMetadata.
        
        Useful for local emulation or testing.
        
        Parameters
        ----------
        path : str
            File path.
        stat : os.stat_result
            File stat result to convert.
        rev : str, optional
            Dropbox file revision string. Defaults to "0000000000000000".
            
        Returns
        -------
        dropbox.files.FileMetadata
            Synthetic Dropbox file metadata.
        """
        client_modified = datetime.fromtimestamp(stat.st_atime, tz=timezone.utc)
        server_modified = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)

        return FileMetadata(
            name=os.path.basename(path),
            path_lower=path.lower(),
            path_display=path,
            id=f"id:{os.path.basename(path)}",
            client_modified=client_modified,
            server_modified=server_modified,
            rev=rev or "0000000000000000",
            size=stat.st_size,
            media_info=None,  # could set MediaInfo if you want image/video metadata
            is_downloadable=True,
            content_hash=None
        )
    
    def traverse(self, folder_path: str) -> List[str]:
        """List all file paths in a Dropbox folder.
        
        Recursively lists all files in the specified folder.
        
        Parameters
        ----------
        folder_path : str
            Dropbox folder path to traverse.
            
        Returns
        -------
        list of str
            List of all file paths in the folder (lowercase).
        """
        result = []
        try:
            res = self.dropbox.files_list_folder(folder_path, recursive=True)
            for entry in res.entries:
                if isinstance(entry, FileMetadata):
                    result.append(entry.path_lower)
            while res.has_more:
                res = self.dropbox.files_list_folder_continue(res.cursor)
                for entry in res.entries:
                    if isinstance(entry, FileMetadata):
                        result.append(entry.path_lower)
        except dropbox.exceptions.ApiError as e:
            print(f"Dropbox API error: {e}")
        return result

@dataclass
class CachedFilesDatabase(FileReader, Savable):
    """[DEPRECATED] A database/cache layer wrapping file access systems.
    
    Reason for deprecation:
    First, it was simply too big of a binary file to fit into the standard sqlite; for example, a 2.9mb excel file blew up into a 5gb openpyxl workbook object. Secondly, reading the whole excel file on the first run was painfully slow.

    This class provides a SQLite-backed caching layer for files from
    local filesystem or Dropbox, with optional auto-save functionality.
    
    Attributes
    ----------
    source_file_path : str
        Path to the SQLite database file.
    """

    # The source file system which we will copy
    source_file_path: str

    def __init__(self, source_file_path: str | None = None,
                 local_fs_reference: LocalFileSystem | None = None,
                 dropbox_fs_reference: DropboxCloudFileSystem | None = None,
                 autosave: bool = False, autosave_location: str | None = None):
        """Initialize CachedFilesDatabase by path or local/dropbox filesystem.
        
        Parameters
        ----------
        source_file_path : str, optional
            Path to SQLite database file (must end with .sqlite or be :memory:).
        local_fs_reference : LocalFileSystem, optional
            Local filesystem to use as source.
        dropbox_fs_reference : DropboxCloudFileSystem, optional
            Dropbox filesystem to use as source.
        autosave : bool, default=False
            If True, automatically cache ALL files to database.
        autosave_location : str, optional
            SQLite database path to cache files if autosave is True.
            
        Raises
        ------
        ValueError
            If multiple source parameters are provided, or if paths are invalid,
            or if autosave requirements are not met.
        """

        print("WARNING: The CachedFilesDatabase class will no longer be supported. This is for two reasons: 1. This class creates an openpyxl workbook object for excel files, and this obj will be saved as a blob into CachedFilesDatabase's db; Saving a large excel file into this class's database runs into a sqlite3.DataError: string or blob too big. No compression solution worked to fix it. 2. Loading a large excel file using openpyxl workbook takes very long to load. You will not run into these problems if your excel files are small, so it still has limited use cases.")

        self._validate_constructor_params(source_file_path, local_fs_reference, dropbox_fs_reference)
        
        self._validate_cached_db_path(source_file_path)

        self._vaildate_autosave_params(autosave, autosave_location)
        
        source_system_type = self._get_source_type(source_file_path, local_fs_reference, dropbox_fs_reference)

        self.FileDbDocument = FileDbDocument
        self.ExcelDbDocument = ExcelDbDocument
        
        match source_system_type:
            case "sqlite":
                self.source_file_path = source_file_path or ""

                self.autosave = False
                self.autosave_location = None
                self.local_fs = None
                self.dropbox_fs = None

                self.connect_db(self.source_file_path)
                # Autosave only applies to local_fs and dropbox_fs
            case "local_fs":
                self.local_fs = local_fs_reference
            case "dropbox_fs":
                self.dropbox_fs = dropbox_fs_reference
            case _:
                raise ValueError("At least one source parameter must be provided.")

        
        self.autosave = autosave
        self.autosave_location = autosave_location

        if self.autosave and self.autosave_location:
            self.save_entire_state(self.autosave_location)

    def connect_db(self, path: str):
        """Connect to SQLite database and bind models.
        
        Creates tables if they don't exist and binds the FileDbDocument
        and ExcelDbDocument models to the database.
        
        Parameters
        ----------
        path : str
            Path to SQLite database file.
            
        Notes
        -----
        See https://docs.peewee-orm.com/en/latest/peewee/database.html#setting-the-database-at-run-time
        """
        self.database = pw.SqliteDatabase(path)

        
        self.database.connect()
        self.database.bind([self.ExcelDbDocument, self.FileDbDocument])
        self.database.create_tables([self.ExcelDbDocument, self.FileDbDocument])

    def disconnect_db(self):
        """Disconnect from the SQLite database.
        
        Safely closes the database connection if one exists.
        """
        if hasattr(self, "database") is False or self.database is None:
            return
        
        self.database.close()

    def get_file_db_document(self, id: int):
        """Get a FileDbDocument by ID.
        
        Parameters
        ----------
        id : int
            File document ID.
            
        Returns
        -------
        FileDbDocument
            The requested file document.
        """
        return self.FileDbDocument.get(self.FileDbDocument.id == id)
    
    def read(self, path: str) -> File:
        """Read a file from cache database or source filesystem. If the instantiated CachedFilesDatabase uses a source other than a database and no manual or auto save to database has occurred, the source filesystem will be used to read the file.
        
        Parameters
        ----------
        path : str
            Path to the file (relative to filesystem root if applicable).
            
        Returns
        -------
        File or Excel
            File object or Excel object if path points to an Excel file.
        """
        no_linked_db = hasattr(self, "database") is False or self.database is None

        if self.local_fs and no_linked_db:
            return self.local_fs.read(path)
        
        if self.dropbox_fs and no_linked_db:
            return self.dropbox_fs.read(path)


        if path.lower().endswith((".xlsx", ".xls")):
            # Could probably optimize this to avoid the join if we store the path in both tables
            excel_db_doc = (self.ExcelDbDocument
                           .select()
                           .join(self.FileDbDocument)
                           .where(self.FileDbDocument.path == path)
                           .get())
            
            return excel_db_doc.to_excel()
        else:
            file_db_doc = self.FileDbDocument.get(self.FileDbDocument.path == path)
            return file_db_doc.to_file()

    def read_excel(self, path: str) -> Excel:
        """Read an Excel file from cache database or source filesystem. If the instantiated CachedFilesDatabase uses a source other than a database and no manual or auto save to database has occurred, the source filesystem will be used to read the file.
        
        Parameters
        ----------
        path : str
            Path to the Excel file.
            
        Returns
        -------
        Excel
            Excel object containing workbook and dataframes.
        """
        no_linked_db = hasattr(self, "database") is False or self.database is None

        if self.local_fs and no_linked_db:
            return self.local_fs.read_excel(path)
        if self.dropbox_fs and no_linked_db:
            return self.dropbox_fs.read_excel(path)

        return self.read(path)

    def save_entire_state(self, destination_path: str) -> None:
        """Save all files from either local file source filesystem or Dropbox source filesystem to the database at destination path.
        Parameters
        ----------
        destination_path : str
            Path to the SQLite database file where files will be saved.
        """

        # get the og filesystem and file paths
        if self.local_fs:
            file_paths = self.local_fs.traverse_root()
        elif self.dropbox_fs:
            file_paths = self.dropbox_fs.traverse("")
        else:
            # saving the entire state to a db does not apply to a sqlite db source because it's already a db that contains the files
            return
        
        # Connect to the database at path only if database is not connected to a db yet.
        if not hasattr(self, "database") or self.database is None:
            self.connect_db(destination_path)
        
        for path in file_paths:
            self.save_file_path_to_db(path)



    def save_file_path_to_db(self, path: str):
        """Read a file from path relative to the source filesystem root and save it to the database.
        
        Determines if the file is an Excel file and saves it accordingly,
        creating the appropriate database document.
        
        Parameters
        ----------
        path : str
            Path to the file to save.
        """
        if self.dropbox_fs:
            file_obj = self.dropbox_fs.read(path)
        else:
            file_obj = File(path=path, id=hash(path))

        file_is_excel = path.lower().endswith((".xlsx", ".xls"))

        if file_is_excel:
            excel_obj = Excel(file=file_obj)
            self._save_excel_obj_to_db(excel_obj)
        else:
            self._save_file_obj_to_db(file_obj)
        
    def _save_file_obj_to_db(self, file: File):
        """Save a File object to the database.
        
        Parameters
        ----------
        file : File
            File object to save.
        """
        file_db_doc = self.FileDbDocument.from_file(file)
        
        with self.database.atomic():
            file_db_doc.save(force_insert=True)

    def _save_excel_obj_to_db(self, excel: Excel):
        """Save an Excel object and its linked File object to the database.
        
        Parameters
        ----------
        excel : Excel
            Excel object to save.
        """
        excel_db_doc = self.ExcelDbDocument.from_excel(excel)
        self._save_excel_db_document(excel_db_doc)

    def _save_excel_db_document(self, excel_db_doc: ExcelDbDocument):
        """Save an ExcelDbDocument and its linked FileDbDocument to the database.
        
        Uses an atomic transaction to ensure both documents are saved together.
        
        Parameters
        ----------
        excel_db_doc : ExcelDbDocument
            Excel database document to save.
        """
        with self.database.atomic():
            excel_db_doc.linked_file_document.save(force_insert=True)
            excel_db_doc.save(force_insert=True)

    def _validate_constructor_params(self,
                                     source_file_path: str | None,
                                     local_fs_reference: LocalFileSystem | None,
                                     dropbox_fs_reference: DropboxCloudFileSystem | None):
        """Validate constructor parameters.
        
        Ensures only one source parameter is provided and sets instance variables.
        
        Parameters
        ----------
        source_file_path : str, optional
            SQLite database path.
        local_fs_reference : LocalFileSystem, optional
            Local filesystem reference.
        dropbox_fs_reference : DropboxCloudFileSystem, optional
            Dropbox filesystem reference.
            
        Raises
        ------
        ValueError
            If multiple source parameters are provided.
        """
        self.source_file_path = source_file_path
        self.local_fs = local_fs_reference
        self.dropbox_fs = dropbox_fs_reference

        if source_file_path and (local_fs_reference or dropbox_fs_reference):
            raise ValueError("Only one of path or local_fs/dropbox_fs can be set.")
        
    def _validate_cached_db_path(self, source_file_path: str | None) -> bool:
        """Validate that the cached db path is a .sqlite file or :memory:.
        
        Parameters
        ----------
        source_file_path : str, optional
            Path to validate.
            
        Returns
        -------
        bool
            True if validation passes.
            
        Raises
        ------
        ValueError
            If path is not a .sqlite file or :memory:.
        """
        
        valid_cached_db_path = source_file_path.endswith(".sqlite") or source_file_path == ":memory:" if source_file_path else False

        # CachedFilesDatabaese local path or autosave location MUST be an sqlite db file
        if source_file_path and not valid_cached_db_path:
            raise ValueError("path must be a .sqlite file for CachedFilesDatabase.")
    
    def _vaildate_autosave_params(self,
                              autosave: bool,
                              autosave_location: str | None):
        """Validate autosave parameters.
        
        Parameters
        ----------
        autosave : bool
            Whether autosave is enabled.
        autosave_location : str, optional
            Path to autosave database.
            
        Raises
        ------
        ValueError
            If autosave is True but autosave_location is not provided,
            or if autosave_location is not a .sqlite file or :memory:.
        """
        if autosave and not autosave_location:
            raise ValueError("autosave_location must be provided if autosave is True.")
        
        if autosave and autosave_location and not (autosave_location.endswith(".sqlite") or autosave_location == ":memory:"):
            raise ValueError("autosave_location must be a .sqlite file or :memory: for CachedFilesDatabase.")

    def _source_system_type(self,
                           source_file_path: str | None = None,
                           local_fs_reference: LocalFileSystem | None = None,
                           dropbox_fs_reference: DropboxCloudFileSystem | None = None) -> type:
        """Return the type of the source system based on which parameter is not None.
        
        Parameters
        ----------
        source_file_path : str, optional
            SQLite database path.
        local_fs_reference : LocalFileSystem, optional
            Local filesystem reference.
        dropbox_fs_reference : DropboxCloudFileSystem, optional
            Dropbox filesystem reference.
            
        Returns
        -------
        type
            The type of the provided source (str, LocalFileSystem, or DropboxCloudFileSystem).
            
        Raises
        ------
        ValueError
            If no source parameter is provided.
        """
        if source_file_path is not None:
            return str
        elif local_fs_reference is not None:
            return LocalFileSystem
        elif dropbox_fs_reference is not None:
            return DropboxCloudFileSystem
        else:
            raise ValueError("At least one source parameter must be provided.")
    
    def _get_source_type(self,
                           source_file_path: str | None = None,
                           local_fs_reference: LocalFileSystem | None = None,
                           dropbox_fs_reference: DropboxCloudFileSystem | None = None):
        """Handle different source types with a switch-like pattern.
        
        Uses match/case to determine and return the source type string.
        
        Parameters
        ----------
        source_file_path : str, optional
            SQLite database path.
        local_fs_reference : LocalFileSystem, optional
            Local filesystem reference.
        dropbox_fs_reference : DropboxCloudFileSystem, optional
            Dropbox filesystem reference.
            
        Returns
        -------
        str
            Source type identifier: 'sqlite', 'local_fs', or 'dropbox_fs'.
            
        Raises
        ------
        ValueError
            If source type is unknown.
        """
        source_type = self._source_system_type(source_file_path, local_fs_reference, dropbox_fs_reference)
        
        match source_type:
            case type() if source_type == str:
                # Handle sqlite database source
                return "sqlite"
            case type() if source_type == LocalFileSystem:
                # Handle local filesystem source
                return "local_fs"
            case type() if source_type == DropboxCloudFileSystem:
                # Handle dropbox filesystem source
                return "dropbox_fs"
            case _:
                raise ValueError(f"Unknown source type: {source_type}")