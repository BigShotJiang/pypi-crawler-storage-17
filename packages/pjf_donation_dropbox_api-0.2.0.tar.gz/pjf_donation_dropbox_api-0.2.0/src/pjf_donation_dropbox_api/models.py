"""
Database models for Excel and File classes. 
- Excel Class is represented by ExcelDbDocument model.
- File Class is represented by FileDbDocument model.

The models can convert ExcelDbDocument to Excel and FileDbDocument to File in both directions.

FileDbDocument stores the exact same field names as File, except its data types might be slightly different in the database. conversion would be needed.

ExcelDbDocument stores the exact field names as Excel, except its data types might be slightly different in the database. conversion would be needed. ex: workbook is a workbook object with excel, but workbook would be a python pickled type in the ExcelDbDocument and database representation
"""

import io
import os
import peewee as pw
from pjf_donation_dropbox_api.file_formats import File
from pjf_donation_dropbox_api.file_formats import Excel
import datetime
from playhouse.fields import PickleField

class FileDbDocument(pw.Model):
    """[DEPRECATED] Database model for File class.
    
    This model represents a file in the database with content stored as binary
    data and metadata pickled for persistence.
    
    Attributes
    ----------
    id : pw.AutoField
        Auto-incrementing primary key.
    path : pw.CharField
        File path (max 255 characters).
    content : pw.BlobField
        Binary file content.
    metadata : PickleField
        Pickled os.stat_result metadata.
    created_at : pw.DateTimeField
        Timestamp when the record was created.
    updated_at : pw.DateTimeField
        Timestamp when the record was last updated.
    """
    # File fields
    id = pw.AutoField()
    path = pw.CharField(max_length=255)
    content = pw.BlobField()
    metadata = PickleField(null=True)  # Store os.stat_result as a pickled object
    
    # Database fields
    created_at = pw.DateTimeField(default=datetime.datetime.now)
    updated_at = pw.DateTimeField(default=datetime.datetime.now)

    @classmethod
    def construct(cls, path: pw.CharField, id: pw.AutoField, content: pw.BlobField, metadata: PickleField) -> 'FileDbDocument':
        """Construct a FileDbDocument from field values.
        
        Parameters
        ----------
        path : str
            File path.
        id : int
            File ID.
        content : bytes
            Binary file content.
        metadata : os.stat_result
            File metadata to be pickled.
            
        Returns
        -------
        FileDbDocument
            Constructed file document instance.
        """
        print("WARNING: The FileDbDocument class is deprecated. It is not capable of storing extremely large files into the db. Your use case my vary if you use medium sized files less than 1mb.")
        file_db_doc = cls()

        file_db_doc.path = path
        file_db_doc.id = id
        file_db_doc.content = content
        file_db_doc.metadata = metadata
        file_db_doc.created_at = datetime.datetime.now()
        file_db_doc.updated_at = datetime.datetime.now()

        return file_db_doc

    def to_file(self) -> 'File':
        """Convert FileDbDocument to File object.
        
        Returns
        -------
        File
            File object with content as BytesIO.
        """
        return File(
            id=self.id,
            path=self.path,
            content=io.BytesIO(self.content),
            metadata=self.metadata
        )

    @classmethod
    def from_file(cls, file: 'File') -> 'FileDbDocument':
        """Create FileDbDocument from File object.
        
        Parameters
        ----------
        file : File
            File object to convert.
            
        Returns
        -------
        FileDbDocument
            Database document representation of the file.
        """
        return cls.construct(
            id=file.id,
            path=file.path,
            content=file.content.getvalue(),
            metadata=file.metadata
        )
    
    @classmethod
    def from_file_data(cls, id: int, path: str, content: io.BytesIO, metadata: os.stat_result) -> 'FileDbDocument':
        """Create FileDbDocument from raw file data.
        
        Parameters
        ----------
        id : int
            File ID.
        path : str
            File path.
        content : io.BytesIO
            File content as BytesIO.
        metadata : os.stat_result
            File metadata.
            
        Returns
        -------
        FileDbDocument
            Database document representation of the file data.
        """
        return cls.construct(
            id=id,
            path=path,
            content=content.getvalue(),
            metadata=metadata
        )

class ExcelDbDocument(pw.Model):
    """[DEPRECATED] Database model for Excel class.
    
    This model represents an Excel file in the database with workbook and
    dataframes pickled for persistence, linked to a FileDbDocument.
    
    Attributes
    ----------
    workbook : PickleField
        Pickled openpyxl Workbook object.
    dataframes : PickleField
        Pickled dictionary of pandas DataFrames.
    bolded_cells : PickleField
        Pickled list of bolded cell coordinates.
    linked_file_document : pw.ForeignKeyField
        Foreign key to associated FileDbDocument.
    """
    workbook = PickleField()
    dataframes = PickleField(null=True)
    bolded_cells = PickleField(null=True)
    linked_file_document= pw.ForeignKeyField(FileDbDocument, backref='excels', on_delete='CASCADE')

    @classmethod
    def construct(cls, workbook: PickleField, dataframes: PickleField, bolded_cells: PickleField, file: FileDbDocument) -> 'ExcelDbDocument':
        """Construct an ExcelDbDocument from field values.
        
        Parameters
        ----------
        workbook : openpyxl.Workbook
            Excel workbook object.
        dataframes : dict
            Dictionary mapping sheet names to pandas DataFrames.
        bolded_cells : list
            List of bolded cell coordinates.
        file : FileDbDocument
            Associated file document.
            
        Returns
        -------
        ExcelDbDocument
            Constructed Excel document instance.
        """
        
        print("WARNING: The ExcelDbDocument class is deprecated. It is not capable of storing extremely large files into the db. Your use case my vary if you use medium sized files less than 1mb.")

        excel_db_doc = cls()

        excel_db_doc.workbook = workbook
        excel_db_doc.dataframes = dataframes
        excel_db_doc.bolded_cells = bolded_cells
        excel_db_doc.linked_file_document = file

        return excel_db_doc

    def to_excel(self) -> 'Excel':
        """Convert ExcelDbDocument to Excel object.
        
        Returns
        -------
        Excel
            Excel object with workbook and dataframes.
        """
        # Get the FileDbDocument related to this ExcelDbDocument
        file_db_doc = self.linked_file_document
        excel_file = file_db_doc.to_file()

        return Excel(
            file=excel_file,
            workbook=self.workbook,
            dataframes=self.dataframes
        )
    
    @classmethod
    def from_excel(cls, excel: 'Excel') -> 'ExcelDbDocument':
        """Create ExcelDbDocument from Excel instance.
        
        Parameters
        ----------
        excel : Excel
            Excel object to convert.
            
        Returns
        -------
        ExcelDbDocument
            Database document representation of the Excel file.
        """
        # Create ExcelDbDocument from Excel instance

        return cls.construct(
            workbook=excel.workbook,
            dataframes=excel.dataframes,
            bolded_cells=excel.bolded_cells,
            file=FileDbDocument.from_file_data(excel.id, excel.path, excel.content, excel.metadata)
        )