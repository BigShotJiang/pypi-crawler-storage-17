import io
import os
from dataclasses import dataclass

import pandas as pd
from openpyxl import Workbook, load_workbook
from typing import Dict, List

# =====================
# Data Classes
# =====================

@dataclass
class File:
    """Represents a generic file in the system.
    
    This class handles file loading, storing content as BytesIO and
    metadata as os.stat_result.
    
    Attributes
    ----------
    id : int
        Unique file identifier (hash of path by default).
    path : str
        File path.
    content : io.BytesIO
        File content as bytes in memory.
    metadata : os.stat_result
        File metadata from os.stat.
    """
    id: int
    path: str
    content: io.BytesIO
    metadata: os.stat_result

    def __init__(self, path, id: int | None = None, content: io.BytesIO | None = None, metadata: os.stat_result | None = None):
        """Initialize a File object.
        
        Parameters
        ----------
        path : str
            Path to the file.
        id : int, optional
            File ID. If not provided, will be generated as hash of path.
        content : io.BytesIO, optional
            File content. If not provided, will be loaded from path.
        metadata : os.stat_result, optional
            File metadata. If not provided, will be loaded from path.
            
        Raises
        ------
        ValueError
            If id, content, and metadata are not all provided together or all omitted.
        """
        self.path = path

        # id, content, and metadata must be set together or none at all
        if (id is None) != (content is None) != (metadata is None):
            raise ValueError("id, content, and metadata must be provided together or none at all.")

        if id and content and metadata:
            self._construct_file_with_prepopulated_fields(id, content, metadata)
            return

        # If only path is provided, load the file
        self._generate_file_fields(id)

    def _construct_file_with_prepopulated_fields(self, id: int, content: io.BytesIO, metadata: os.stat_result):
        """Construct a prepopulated File object.
        
        Parameters
        ----------
        id : int
            File ID.
        content : io.BytesIO
            File content.
        metadata : os.stat_result
            File metadata.
        """
        self.id = id
        self.content = content
        self.metadata = metadata

    def _generate_file_fields(self, id: int | None = None):
        """Generate file fields from the current path.
        
        Loads the file content and metadata from disk.
        
        Parameters
        ----------
        id : int, optional
            File ID. If not provided, will be generated as hash of path.
        """
        if id is None:
            self.id = hash(self.path)
        else:
            self.id = id
        with open(self.path, "rb") as f:
            self.content = io.BytesIO(f.read())

        self.metadata = os.stat(self.path)

    def _construct_file_from_optional_fields(self, content: io.BytesIO, metadata: os.stat_result):
        """Construct file from optional content and metadata fields.
        
        Parameters
        ----------
        content : io.BytesIO
            File content.
        metadata : os.stat_result
            File metadata.
        """
        self.content = content
        self.metadata = metadata

@dataclass
class Excel(File):
    """Represents an Excel file loaded into memory.
    
    Extends File class with Excel-specific functionality including
    workbook, dataframes, and bolded cells tracking.
    
    Attributes
    ----------
    workbook : openpyxl.Workbook
        Loaded Excel workbook.
    dataframes : dict of str to pd.DataFrame
        Dictionary mapping sheet names to pandas DataFrames.
    bolded_cells : list of str
        List of bolded cell coordinates in "SheetName!CellCoordinate" format.
    """
    workbook: Workbook
    dataframes: Dict[str, pd.DataFrame]
    bolded_cells: List[str]

    def __init__(self,
                 file_path: str | None = None,
                 file: File | None = None,
                 workbook: Workbook | None = None,
                 dataframes: Dict[str, pd.DataFrame] | None = None):
        """Initialize Excel from file path or components.
        
        Parameters
        ----------
        file_path : str, optional
            Path to Excel file (.xlsx or .xls).
        file : File, optional
            File object to construct Excel from.
        workbook : openpyxl.Workbook, optional
            Pre-loaded workbook. If not provided with file, will be loaded.
        dataframes : dict of str to pd.DataFrame, optional
            Pre-loaded dataframes. If not provided with file, will be loaded.
            
        Raises
        ------
        ValueError
            If both file_path and file are provided, or neither is provided,
            or if file_path is not an Excel file.
        """
        
        only_path_provided = file_path is not None and file is None 
        only_file_provided = file_path is None and file is not None

        if only_path_provided:
            self._construct_excel_from_path(file_path)
        elif only_file_provided:
            self._construct_excel_from_file(file, workbook, dataframes)
        else:
            raise ValueError("Either file_path or file, but not both, must be provided.")

        self.bolded_cells = []

        self.bolded_cells = self.get_bold_cells()

    def _construct_excel_from_path(self, path: str):
        """Construct Excel object from file path.
        
        Loads the workbook and dataframes from the specified path.
        
        Parameters
        ----------
        path : str
            Path to Excel file.
            
        Raises
        ------
        ValueError
            If path is not an Excel file (.xlsx or .xls).
        """
        # Assert file path is an excel file
        if path and not path.lower().endswith((".xlsx", ".xls")):
            raise ValueError("file_path must be an Excel file (.xlsx or .xls).")
        
        super().__init__(path)
        self.workbook = load_workbook(path)
        self.dataframes = pd.read_excel(path, engine="calamine", sheet_name=None, header=None)

    def _construct_excel_from_file(self, file: File, workbook: Workbook, dataframes: Dict[str, pd.DataFrame]):
        """Construct Excel object from File object and optional components.
        
        Parameters
        ----------
        file : File
            File object containing the Excel file data.
        workbook : openpyxl.Workbook, optional
            Pre-loaded workbook. If None, will be loaded from file content.
        dataframes : dict of str to pd.DataFrame, optional
            Pre-loaded dataframes. If None, will be loaded from file content.
        """
        super().__init__(path=file.path, id=file.id, content=file.content, metadata=file.metadata)
        self.workbook = workbook or load_workbook(io.BytesIO(file.content.getvalue()))
        self.dataframes = dataframes or pd.read_excel(io.BytesIO(file.content.getvalue()), engine="calamine", sheet_name=None, header=None)


    def get_bold_cells(self) -> List[str]:
        """Get all bolded cells in the workbook.
        
        Returns
        -------
        list of str
            List of bolded cell coordinates in "SheetName!CellCoordinate" format.
            For example: ["Sheet1!A1", "Sheet2!B5"].
        """
        for sheet in self.workbook.worksheets:
            for row in sheet.iter_rows():
                for cell in row:
                    if cell.font.bold:
                        self.bolded_cells.append(f"{sheet.title}!{cell.coordinate}")

        return self.bolded_cells