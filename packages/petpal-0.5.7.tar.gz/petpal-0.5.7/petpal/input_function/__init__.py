from . import blood_input
from . import idif_necktangle

def main():
    print("PETPAL - Input Functions")


if __name__ == "__main__":
    main()
    