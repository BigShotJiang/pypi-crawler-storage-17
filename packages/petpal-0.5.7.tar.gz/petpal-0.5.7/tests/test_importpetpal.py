import pytest

def test_import_utils():
    import petpal