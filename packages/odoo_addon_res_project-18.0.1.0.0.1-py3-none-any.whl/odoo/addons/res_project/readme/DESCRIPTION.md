This module is one of the master data used in all Project sections as
information

This module adds the possibility of defining a sequence for the project's reference.
The reference is then set as the default when creating a new project, using the defined sequence.

NOTE:
Before installing this module, you should check the following information

* For projects that have a parent project, the code will be overwritten with the code of the parent project and followed by a sub-code, such as PJ00001-1

* For main projects, if the code already exists, it will not be changed. However, if the code does not exist, a new code will be automatically assigned