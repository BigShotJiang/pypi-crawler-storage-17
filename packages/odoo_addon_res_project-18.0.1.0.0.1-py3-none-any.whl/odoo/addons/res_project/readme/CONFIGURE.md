To configure this module, following access right must be set.

- Go to Settings \> Users & Companies \> Users

- Select User that you have to see Project

- Select access right on Res Project Field  
  - Project User
  - Project Manager


To configure sequence, following access right must be set.
- You can change the default sequence (PJ00001) by the one of your choice
  going to *Settings > Technical > Sequences & Identifiers > Sequences*, and
  editing the record name `Res Project Sequence`.
  
**Note:**

- Project User: Users will be able to see all project documents but
  cannot create documents.
- Project Manager: Users will be able to see all project documents,
  create documents and configuration.
- You will only have access to that section if your section has `Technical features`
  permission check marked.
