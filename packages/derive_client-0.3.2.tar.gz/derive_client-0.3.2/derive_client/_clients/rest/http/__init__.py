"""REST API HTTPClient."""
