# moreniius
A project to contain custom components required to use `eniius` to produce `NeXus Structure` `JSON` from `mccode-antlr` simulated instruments.
Simply, _more_ `eniius`.
