"""
CLI command implementations.
"""
