"""
Application layer for Grompt.

This layer contains use cases and CLI commands.
"""
