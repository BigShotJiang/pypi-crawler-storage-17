"""Setup configuration for actron_neo_api package."""

from setuptools import setup

setup(
    use_scm_version=True,
    setup_requires=["setuptools_scm"],
)
