COLUMN_TYPES = {
    "ARRAY",
    "BINARY",
    "BOOLEAN",
    "CUSTOM",
    "DATE",
    "DECIMAL",
    "ENUM",
    "FLOAT",
    "GEOGRAPHY",
    "INTEGER",
    "INTERVAL",
    "OBJECT",
    "STRING",
    "TEXT",
    "TIME",
    "TIMESTAMP",
}

TABLE_TYPES = {"TABLE", "VIEW", "EXTERNAL"}
