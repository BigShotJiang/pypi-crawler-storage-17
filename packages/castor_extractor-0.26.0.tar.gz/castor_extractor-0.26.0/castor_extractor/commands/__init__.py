from castor_extractor.utils import deprecate_python  # type: ignore

deprecate_python(min_version_supported=(3, 10))
