# SPDX-FileCopyrightText: 2025-present Ivan Matveev <skioneim@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = '0.1.0'
