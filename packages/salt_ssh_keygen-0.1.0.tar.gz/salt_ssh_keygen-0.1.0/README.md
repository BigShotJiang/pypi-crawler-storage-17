# Helpers for ssh-keygen with Saltstack
