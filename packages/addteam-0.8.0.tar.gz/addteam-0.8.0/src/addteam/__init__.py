"""addteam: one-command access + onboarding bootstrap."""

