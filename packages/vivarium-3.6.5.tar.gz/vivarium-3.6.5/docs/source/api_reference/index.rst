API Reference
=============

.. automodule:: vivarium

.. toctree::
   :maxdepth: 1
   :glob:

   *
   */index
