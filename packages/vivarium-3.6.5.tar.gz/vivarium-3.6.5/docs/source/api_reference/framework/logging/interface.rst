.. automodule:: vivarium.framework.logging.interface
