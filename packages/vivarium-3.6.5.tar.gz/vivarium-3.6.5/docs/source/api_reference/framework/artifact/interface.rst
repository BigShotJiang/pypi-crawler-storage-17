.. automodule:: vivarium.framework.artifact.interface
