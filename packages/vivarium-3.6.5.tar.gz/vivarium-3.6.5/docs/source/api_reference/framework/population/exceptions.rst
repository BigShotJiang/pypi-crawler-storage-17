.. automodule:: vivarium.framework.population.exceptions
