.. automodule:: vivarium.framework.lookup.interface
