.. automodule:: vivarium.framework.components.interface
