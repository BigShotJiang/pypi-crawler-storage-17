.. automodule:: vivarium.manager
