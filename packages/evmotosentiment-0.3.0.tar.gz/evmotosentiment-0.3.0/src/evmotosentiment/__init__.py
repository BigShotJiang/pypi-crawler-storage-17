"""
sentiment
=========
A package that scores text according to the sentiment type
"""
from . import wsentiment

__all__ = ["wsentiment"]