from .lab_value import LabValue

__all__ = [
    "LabValue",
]