// Auto-generated from package.json
export const VERSION = '2.0.5';
