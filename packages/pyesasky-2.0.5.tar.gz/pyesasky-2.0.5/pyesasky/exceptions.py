class CommNotInitializedError(Exception):
    "Raised when attempting to use comm before it has been initialized"
    pass