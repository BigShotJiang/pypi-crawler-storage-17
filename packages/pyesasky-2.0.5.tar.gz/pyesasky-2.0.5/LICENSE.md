# European Space Agency Public License – v2.4 – Permissive (Type 3)

This software is licensed under the [European Space Agency Public License – v2.4 – Permissive (Type 3)](https://essr.esa.int/license/european-space-agency-public-license-v2-4-permissive-type-3).

By using or distributing this software, you agree to the terms of the license.
