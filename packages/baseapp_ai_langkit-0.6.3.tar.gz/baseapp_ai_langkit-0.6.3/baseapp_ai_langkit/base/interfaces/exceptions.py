class LLMChatInterfaceException(Exception):
    """
    Used to identify exceptions coming from LLM chat interfaces.
    """

    pass
