"""
Configuration package for MCP database tools.
"""