__version__ = "24.6.4"
__tool_name__ = "sca_cleanup_tool"
__description__ = "Mend SCA Cleanup Tool"
