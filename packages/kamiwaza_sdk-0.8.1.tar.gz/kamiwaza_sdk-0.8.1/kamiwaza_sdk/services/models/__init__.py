from .base import ModelService

__all__ = ['ModelService']
