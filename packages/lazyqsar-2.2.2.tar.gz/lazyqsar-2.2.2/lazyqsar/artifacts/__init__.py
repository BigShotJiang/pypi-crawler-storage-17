from .artifact_binary_classifier import LazyBinaryClassifierArtifact  # noqa: F401  # required for dynamic import
