# API reference

```{toctree}
:maxdepth: 2

ffsim
ffsim.contract
ffsim.linalg
ffsim.optimize
ffsim.qiskit
ffsim.random
ffsim.testing
```
