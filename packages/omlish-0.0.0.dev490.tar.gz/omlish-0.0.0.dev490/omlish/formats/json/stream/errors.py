class JsonStreamError(Exception):
    pass
