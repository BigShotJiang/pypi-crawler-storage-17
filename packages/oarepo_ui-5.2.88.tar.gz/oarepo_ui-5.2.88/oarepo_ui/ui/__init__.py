# Copyright (c) 2025 CESNET
#
# This software is released under the MIT License.
# https://opensource.org/licenses/MIT

"""OARepo UI package."""
