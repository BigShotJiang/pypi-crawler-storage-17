# nb. some tests require this to be a true package
