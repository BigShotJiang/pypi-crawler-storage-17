# -*- coding: utf-8; -*-
"""
Package Version
"""

from importlib.metadata import version


__version__ = version("WuttJamaican")
