
``wuttjamaican.batch``
======================

.. automodule:: wuttjamaican.batch
   :members:
