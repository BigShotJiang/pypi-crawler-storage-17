
``wuttjamaican.db.model.upgrades``
==================================

.. automodule:: wuttjamaican.db.model.upgrades
   :members:
