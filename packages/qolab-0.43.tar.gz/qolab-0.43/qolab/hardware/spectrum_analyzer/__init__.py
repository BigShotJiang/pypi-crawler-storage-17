"""Spectrum Analyzer package."""

from .agilent_E4405B import Agilent_E4405B

__all__ = ["Agilent_E4405B"]
