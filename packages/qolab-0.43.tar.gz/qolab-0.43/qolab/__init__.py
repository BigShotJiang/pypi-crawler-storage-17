"""Classes and functions useful for the quantum optics lab: qolab."""

__version__ = "0.43"
