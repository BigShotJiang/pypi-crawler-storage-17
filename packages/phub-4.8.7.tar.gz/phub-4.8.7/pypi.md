<p align="center">
  <img width="200" src="https://raw.githubusercontent.com/Egsagon/PHUB/master/assets/logo.svg">
</p>

# PHUB - An API wrapper for PornHub.

PHUB is an easy-to-use API wrapper for Pornhub. It can access most used or useful
PH features, such as video searching, account features, video downloading, and more.

- Project documentation: [phub.readthedocs.io](https://phub.readthedocs.io)
- Project repository: [EchterAlsFake/PHUB](https://github.com/EchterAlsFake/PHUB)
