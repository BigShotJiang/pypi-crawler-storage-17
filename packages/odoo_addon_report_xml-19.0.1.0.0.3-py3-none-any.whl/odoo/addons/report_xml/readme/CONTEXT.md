We create this module to allow the system to generate and download XMLs as reports.

Otherwise, the system can generate XMLs, but will be downloaded as HTML or PDF.