- [Dixmit](https://www.dixmit.com)
    -   Enric Tobella

-   [Tecnativa](https://www.tecnativa.com):  
    -   Jairo Llopis

-   [Avoin.Systems](https://avoin.systems/):  
    -   Tatiana Deribina

-   Iván Antón \<<ozono@ozonomultimedia.com>\>
