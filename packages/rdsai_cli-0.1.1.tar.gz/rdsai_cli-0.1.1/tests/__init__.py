"""Tests for rdsai-cli."""

