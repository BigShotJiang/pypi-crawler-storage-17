"""Tests for database package."""

