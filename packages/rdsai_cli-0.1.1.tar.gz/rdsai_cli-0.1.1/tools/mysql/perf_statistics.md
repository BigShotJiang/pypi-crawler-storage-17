Get system performance statistics from AliSQL Performance Agent (information_schema.PERF_STATISTICS).

**Parameters:**
- **interval** (optional): Time interval in seconds to retrieve data for (default: 60, max: 3600)

Returns CSV format data with CPU usage, memory usage, IOPS, and read/write throughput metrics.
