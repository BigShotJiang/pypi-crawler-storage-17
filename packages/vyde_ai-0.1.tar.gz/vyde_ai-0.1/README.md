# Vyde AI

Composable LangGraph agents, nodes, ingestion utilities, and OpenSearch vector store helpers used at Dive Code. The library ships agents for RAG, semantic search, and supervisor-style orchestration, plus ingestion helpers for DOCX/PPTX and vector store management.

## Requirements
- Python 3.12
- OpenSearch reachable for vector store features (SSL on, cert verification disabled by default)
- Optional tracing: set `LANGCHAIN_API_KEY`, `LANGCHAIN_TRACING_V2=true`, and `LANGCHAIN_PROJECT=<name>` for LangSmith

## Local development setup
```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e .
```

## Running tests and coverage
```bash
python coverage/run_coverage.py
# or
python -m unittest discover
```
Coverage HTML report is written to `coverage/htmlcov/index.html`.

## Building distribution artifacts
```bash
python -m pip install --upgrade build
python -m build
# outputs wheel and sdist in dist/
```

## Use in external projects
Install from a built artifact or directly from the repository:
```bash
pip install dist/vyde_ai-0.1-py3-none-any.whl
# or
pip install git+ssh://<YOUR-GIT-URL>/Divecode.AI.git
```

### Semantic search example
```python
from langgraph.graph import MessagesState
from langchain.embeddings import OpenAIEmbeddings
from vyde_ai import AbstractVectorStoreManager, SemanticSearchAgent

class MyVectorStore(AbstractVectorStoreManager):
    def _check_api_key(self):
        return True  # e.g., ensure OPENAI_API_KEY is set

embedding = OpenAIEmbeddings()

agent = SemanticSearchAgent(
    state_cls=MessagesState,
    vectorstore_class=MyVectorStore,
    project_name="my-project",
    embedding_function=embedding,
)

graph = agent.graph()
result = graph.invoke({
    "index": "my-index",
    "query": "What is the refund policy?",
    "messages": [],
    "k": 5,
    "filters_must": {"country": ["IT"]},
})
print(result["chunks"])
```

### RAG agent skeleton
```python
from langgraph.graph import MessagesState
from langchain.embeddings import OpenAIEmbeddings
from vyde_ai import (
    AbstractVectorStoreManager,
    GenerateQueriesNode,
    RagAgent,
    SemanticSearchNode,
)

class MyVectorStore(AbstractVectorStoreManager):
    def _check_api_key(self):
        return True

class MyGenerateQueries(GenerateQueriesNode):
    def build_invoke_args(self, state):
        return {"domanda": state["query"]}
    def compose_queries(self, queries):
        return [q["query"] for q in queries]

embedding = OpenAIEmbeddings()
search_node = SemanticSearchNode(
    name="semantic_search",
    embedding_function=embedding,
    vectorstore_class=MyVectorStore,
)

rag = RagAgent(
    state_cls=MessagesState,
    project_name="my-project",
    generate_queries_node=MyGenerateQueries(name="generate_queries"),
    call_semantic_search_node=search_node,
)

graph = rag.graph()
response = graph.invoke({
    "query": "Explain product warranties",
    "messages": [],
    "idx_current_query": -1,
    "idx_current_chunk": -1,
    "chunks": [],
    "valid_chunks": [],
    "queries": [],
})
print(response["response"])
```

### Ingestion helpers
- DOCX: `vyde_ai.ingestion.ingest_docx.docx_to_chunks(file_obj, mandatory_level1, mandatory_level2, extra_checks)` → returns `(chunks, compliance_info)`.
- PPTX: `vyde_ai.ingestion.ingest_pptx.pptx_to_chunks(file_obj)` → returns list of chunks.
- HTML helpers in `vyde_ai/ingestion/utils/html.py` sanitize and split content.

## Troubleshooting
- OpenSearch: verify host/port/user/password and that SSL is reachable; cert verification is disabled in `vectorstore/database.py` by default.
- Tracing: set LangSmith environment variables or pass `disable_tracing=True` to agents/nodes to turn it off.
- State fields: semantic search expects `index` and `query`; RAG adds `chunks`, `valid_chunks`, `queries`, and iterator fields (`idx_current_query`, `idx_current_chunk`).
