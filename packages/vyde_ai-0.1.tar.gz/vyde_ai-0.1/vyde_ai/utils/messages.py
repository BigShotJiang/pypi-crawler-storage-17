__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from langchain.messages import HumanMessage
from langchain_core.messages import BaseMessage
from typing import List


def convert_messages_to_conversation(messages: List[BaseMessage]) -> str:
    return "\n".join(f"user: '{m.content}'" if type(m) == HumanMessage else
                     f"assistant: '{m.content}'" for m in messages)
