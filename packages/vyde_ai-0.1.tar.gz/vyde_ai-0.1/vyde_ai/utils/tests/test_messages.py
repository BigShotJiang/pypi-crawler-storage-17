__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from langchain_core.messages import HumanMessage, AIMessage
import unittest

from vyde_ai.utils.messages import convert_messages_to_conversation


class TestMessages(unittest.TestCase):
    def test_empty_conversation(self):
        conversation = convert_messages_to_conversation([])
        self.assertEqual(conversation, "")

    def test_conversation(self):
        conversation = convert_messages_to_conversation([
            HumanMessage("Hello World"),
            AIMessage("Hello you too!"),
        ])
        self.assertEqual(conversation, "user: 'Hello World'\nassistant: 'Hello you too!'")


if __name__ == "__main__":
    unittest.main()
