__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from spire.presentation import Cell, IAutoShape, ITable, ISmartArt, ISmartArtNode, Presentation
from typing import List, Tuple, FrozenSet


FONTS_DIR = "vyde_ai/ingestion/assets/fonts/dejavu"


def _tf_text(tf: IAutoShape | Cell | ISmartArtNode) -> str:
    if tf is None:
        return ""

    if hasattr(tf, "Text") and tf.Text is not None:
        return tf.Text.replace('\r', '').strip()

    tr = getattr(tf, "TextRange", None)
    if tr is not None and hasattr(tr, "Text") and tr.Text is not None:
        return tr.Text.replace('\r', '').strip()

    return ""


def _autoshape_lines(shape: IAutoShape) -> List[str]:
    """Pure: returns lines derived from an autoshape without mutating inputs."""
    txt = _tf_text(getattr(shape, "TextFrame", None))
    return [txt, ""] if txt else []


def _table_lines(table_shape: ITable) -> List[str]:
    """Pure: returns markdown lines for a table without mutating inputs."""
    lines: List[str] = []
    add_header = True

    for row in table_shape.TableRows:
        cells: List[str] = []
        for i in range(row.Count):
            cell = row[i]
            cells.append(_tf_text(getattr(cell, "TextFrame", None)) or "")

        if any(x.strip() for x in cells):
            lines.append(" | ".join(cells))
            if add_header:
                lines.append(" --- | " * (len(cells) - 1) + " ---")
                add_header = False

    if lines:
        lines.append("")
    return lines


def _smartart_node_lines(node: ISmartArtNode, level: int, seen: FrozenSet[str]) -> Tuple[List[str], FrozenSet[str]]:
    """
    Pure: returns (lines, new_seen). Does not mutate 'seen'.
    """
    lines: List[str] = []
    prefix = "  " * level + "- "
    txt = _tf_text(getattr(node, "TextFrame", None))

    new_seen = seen
    if txt:
        if txt not in seen:
            lines.append(prefix + txt)
            new_seen = seen | {txt}

    # Recurse on children, threading 'seen' immutably
    for child in node.ChildNodes:
        child_lines, new_seen = _smartart_node_lines(child, level + 1, new_seen)
        # concat to avoid mutating passed lists
        lines = lines + child_lines

    return lines, new_seen


def _smartart_lines(smart: ISmartArt) -> List[str]:
    """Pure: returns markdown lines for a SmartArt without mutating inputs."""
    all_lines: List[str] = []
    seen: FrozenSet[str] = frozenset()

    for node in smart.Nodes:
        node_lines, seen = _smartart_node_lines(node, level=0, seen=seen)
        all_lines = all_lines + node_lines

    if all_lines:
        all_lines.append("")
    return all_lines


def pptx_to_markdown(pres: Presentation) -> List[str]:
    slides: List[str] = []
    try:
        for i, slide in enumerate(pres.Slides, start=1):
            # Local list only; not shared outside this scope
            md_lines: List[str] = []

            for shape in slide.Shapes:
                if isinstance(shape, IAutoShape):
                    md_lines = md_lines + _autoshape_lines(shape)
                elif isinstance(shape, ITable):
                    md_lines = md_lines + _table_lines(shape)
                elif isinstance(shape, ISmartArt):
                    md_lines = md_lines + _smartart_lines(shape)

            if md_lines:
                slides.append("\n".join(md_lines).strip())
    finally:
        pres.Dispose()
    return slides
