__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from bs4 import BeautifulSoup
import io
import mammoth
import string
from typing import Dict, List, Optional, Tuple, TypedDict, Callable

from vyde_ai.ingestion.utils import sanitize_soup, split_by_headers

class Compliance(TypedDict):
    compliance: bool
    message: Optional[str]


def evaluate_existence(expected_chapter: str, existing_chapters: List[Dict], message_on_missing: str) -> Compliance:
    compliance_result = next(
        (c for c in existing_chapters if c['header'].strip().upper() == expected_chapter.upper()), None)

    if compliance_result is None:
        return Compliance(compliance=False, message=message_on_missing)

    return Compliance(compliance=True, message=None)


def evaluate_chapters_existence(expected_chapters: List[str], existing_chapters: List[Dict], message_on_missing: string.Template) -> Dict[str, Compliance]:
    compliance = {}

    for chapter in expected_chapters:
        compliance[chapter] = evaluate_existence(
            expected_chapter=chapter,
            existing_chapters=existing_chapters,
            message_on_missing=message_on_missing.substitute(chapter=chapter)
        )

    return compliance


def docx_to_chunks(
        file_obj: io.BytesIO,
        mandatory_chapters_level_1: List[str],
        mandatory_chapters_level_2: List[str],
        additional_compliance_functions: List[Callable],
) -> Tuple[List[Dict], Dict]:

    result = mammoth.convert_to_html(file_obj)
    html = result.value

    soup = BeautifulSoup(html, "html.parser")
    soup = sanitize_soup(soup)
    chunks = split_by_headers(soup)

    chapters_level_1 = [c for c in chunks if c['level'] == 1]
    chapters_level_2 = [c for c in chunks if c['level'] == 2]

    compliance = {}
    compliance.update(evaluate_chapters_existence(
        expected_chapters=mandatory_chapters_level_1,
        existing_chapters=chapters_level_1,
        message_on_missing=string.Template('Missing mandatory chapter $chapter')
    ))

    for f in additional_compliance_functions:
        compliance = f(compliance=compliance, chapters_level_1=chapters_level_1, chapters_level_2=chapters_level_2)

    compliance.update(evaluate_chapters_existence(
        expected_chapters=mandatory_chapters_level_2,
        existing_chapters=chapters_level_2,
        message_on_missing=string.Template('Missing mandatory sub-chapter $chapter')
    ))


    if all([val['compliance'] for _, val in compliance.items()]) is False:
        return (chunks,
                {
                    "status": False,
                    "errors": [val['message'] for _, val in compliance.items() if val['compliance'] is False]
                })

    return chunks, {"status": True}
