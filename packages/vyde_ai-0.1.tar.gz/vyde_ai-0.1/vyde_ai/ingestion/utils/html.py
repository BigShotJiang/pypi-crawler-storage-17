__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from bs4 import BeautifulSoup, Tag
import html2text
from typing import Dict, Iterable, List, Optional, Tuple, TypedDict


class HTMLChunk(TypedDict):
    level: Optional[int]   # None for preamble
    header: Optional[str]  # None for preamble
    html: str
    order: int


def convert_html_to_markdown(html: str) -> str:
    text_maker = html2text.HTML2Text()
    text_maker.ignore_links = True
    text_maker.ignore_emphasis = True
    text_maker.body_width = 0
    text_maker.single_line_break = True

    return text_maker.handle(html)


def contains_only_table(html: str) -> bool:
    soup = BeautifulSoup(html.strip(), 'html.parser')

    contents = soup.contents
    if len(contents) != 1 or contents[0].name != 'table':
        return False
    return True


def _iter_header_groups(body: Tag, header_tags: Iterable[str]) -> Iterable[Tuple[Optional[Tag], List[Tag]]]:
    """
    Yield (current_header, nodes) groups scanned top-to-bottom.
    - First group may have current_header=None for preamble.
    - Each subsequent group starts at a header tag included in its nodes list.
    """
    current_header: Optional[Tag] = None
    current_nodes: List[Tag] = []

    for node in body.children:
        if isinstance(node, Tag) and node.name in header_tags:
            # Emit the previous group (preamble or previous header section)
            if current_header is not None or current_nodes:
                yield current_header, current_nodes
            # Start a new group with this header included
            current_header = node
            current_nodes = [node]
        else:
            current_nodes.append(node)

    # Emit the trailing group
    if current_header is not None or current_nodes:
        yield current_header, current_nodes


def _emit_chunks_from_group(header_tag: Optional[Tag], nodes: List[Tag], order_offset: int) -> List[HTMLChunk]:
    """
    From a (header_tag, nodes) group, create 1+ Chunk(s).
    - If header_tag is present, ensure the first emitted segment includes it.
    - If there are no nodes for a header (empty section), still emit a header-only chunk.
    """
    level = None if header_tag is None else int(header_tag.name[1])
    header_text = None if header_tag is None else header_tag.get_text(strip=True)

    segments = _split_nodes_into_segments(nodes)

    # Empty header -> still produce one header-only segment
    if header_tag is not None and not segments:
        segments = [[header_tag]]

    chunks: List[HTMLChunk] = []
    for i, seg in enumerate(segments):
        seg_nodes = list(seg)

        # Include the header HTML only in the first segment (if not already present)
        if i == 0 and header_tag is not None:
            if not seg_nodes or seg_nodes[0] is not header_tag:
                seg_nodes = [header_tag] + seg_nodes

        html = "".join(str(n) for n in seg_nodes)
        chunks.append(HTMLChunk(level=level, header=header_text, html=html, order=len(chunks)+order_offset))

    return chunks


def sanitize_soup(soup: BeautifulSoup) -> BeautifulSoup:
    """
    Mutates the soup in place:
      - remove style/script-like elements and images
      - strip all attributes from remaining tags
    """
    new_soup = BeautifulSoup(str(soup), "html.parser")
    for tag in new_soup(["style", "script", "noscript", "template", "iframe", "canvas", "svg", "form"]):
        tag.decompose()
    for img in new_soup.find_all("img"):
        img.decompose()

    allowed_attrs = {
        "td": {"rowspan", "colspan"},
        "th": {"rowspan", "colspan"},
    }

    for t in new_soup.find_all(True):
        if t.name in allowed_attrs:
            # keep only whitelisted attributes
            t.attrs = {k: v for k, v in t.attrs.items() if k in allowed_attrs[t.name]}
        else:
            t.attrs = {}

    return new_soup


def _split_nodes_into_segments(nodes: List[Tag]) -> List[List[Tag]]:
    """
    Split nodes so each <table> is its own segment, and non-table runs are grouped.
    """
    segments: List[List[Tag]] = []
    buf: List[Tag] = []
    for n in nodes:
        if isinstance(n, Tag) and n.name == "table":
            if buf:
                segments.append(buf)
                buf = []
            segments.append([n])  # table as its own segment
        else:
            buf.append(n)
    if buf:
        segments.append(buf)
    return segments


def split_by_headers(soup: BeautifulSoup, min_level: int = 1, max_level: int = 6) -> List[Dict]:
    """
    Split an HTML document into chunks at each header (h1..h6).

    - Sanitizes first (removes style/script/etc., images, and all attributes) via `sanitize_soup`.
    - Each header chunk includes its header element.
    - If a chunk contains one or more <table>, it is further split so each table
      is its own chunk; text before/after/between tables becomes separate chunks.
    - Content before the first header becomes a 'preamble' chunk with level=None.
    Returns: List of dicts with keys: {level, header, html}.
    """
    body = soup.body or soup

    header_tags = {f"h{i}" for i in range(min_level, max_level + 1)}

    all_chunks: List[HTMLChunk] = []
    for header_tag, nodes in _iter_header_groups(body, header_tags):
        # Preamble case: header_tag is None
        if header_tag is None:
            # Split preamble around tables the same way
            for seg in _split_nodes_into_segments(nodes):
                html = "".join(str(n) for n in seg)
                # Skip empty fragments (e.g., only whitespace)
                if html.strip():
                    all_chunks.append(HTMLChunk(level=None, header=None, html=html.strip(), order=len(all_chunks)))
            continue

        # Headered sections
        all_chunks.extend(_emit_chunks_from_group(header_tag, nodes, len(all_chunks)))

    # Convert to the expected list-of-dicts shape
    return [dict(c) for c in all_chunks]