__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from bs4 import BeautifulSoup, Tag
import unittest

from vyde_ai.ingestion.utils.html import (convert_html_to_markdown, contains_only_table, _iter_header_groups,
                                          _emit_chunks_from_group, sanitize_soup, _split_nodes_into_segments,
                                          split_by_headers)


class TestConvertHTMLToMarkdown(unittest.TestCase):
    def test_base_case(self):
        html = """<h1>Main Document Title</h1>
<p>This is a paragraph containing <strong>bold text</strong>, <em>italic text</em>, and a mix.</p>
<ul>
    <li>First item.</li>
    <li>Second item with a <a href="https://www.example.com">helpful link</a>.</li>
    <li>Third item, followed by a hard line break.<br>This line should appear immediately after the break.</li>
</ul>"""

        expected_md = """# Main Document Title
This is a paragraph containing bold text, italic text, and a mix.
  * First item.
  * Second item with a helpful link.
  * Third item, followed by a hard line break.  
This line should appear immediately after the break.


"""

        self.assertEqual(expected_md, convert_html_to_markdown(html))

    def test_table_case(self):
        html = """<h1>Main Document Title</h1>
<p>This is a paragraph containing <strong>bold text</strong>, <em>italic text</em>, and a mix.</p>
<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Age</th>
            <th>City</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Alice</td>
            <td>30</td>
            <td>New York</td>
        </tr>
        <tr>
            <td>Bob</td>
            <td>25</td>
            <td>London</td>
        </tr>
    </tbody>
</table>
<p>This paragraph should appear immediately after the table</p>"""

        expected_md = """# Main Document Title
This is a paragraph containing bold text, italic text, and a mix.
Name | Age | City  
---|---|---  
Alice | 30 | New York  
Bob | 25 | London  
This paragraph should appear immediately after the table
"""

        self.assertEqual(expected_md, convert_html_to_markdown(html))

    def test_advanced_table_case(self):
        html = """<h1>Main Document Title</h1>
<p>This is a paragraph containing <strong>bold text</strong>, <em>italic text</em>, and a mix.</p>
<table>
    <thead>
        <tr>
            <th colspan="2">Product Details</th>
            <th>Price</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td rowspan="2">Electronics</td>
            <td>Laptop</td>
            <td>$1200</td>
        </tr>
        <tr>
            <td>Smartphone</td>
            <td>$700</td>
        </tr>
        <tr>
            <td>Books</td>
            <td>Fiction</td>
            <td>$15</td>
        </tr>
    </tbody>
</table>
<p>This paragraph should appear immediately after the table</p>"""

        expected_md = """# Main Document Title
This is a paragraph containing bold text, italic text, and a mix.
Product Details | Price  
---|---  
Electronics | Laptop | $1200  
Smartphone | $700  
Books | Fiction | $15  
This paragraph should appear immediately after the table
"""

        self.assertEqual(expected_md, convert_html_to_markdown(html))


class TestContainsOnlyTable(unittest.TestCase):
    def test_base_case(self):
        html = """<h1>Main Document Title</h1>
<p>This is a paragraph containing <strong>bold text</strong>, <em>italic text</em>, and a mix.</p>
<ul>
    <li>First item.</li>
    <li>Second item with a <a href='https://www.example.com'>helpful link</a>.</li>
    <li>Third item, followed by a hard line break.<br>This line should appear immediately after the break.</li>
</ul>"""

        self.assertFalse(contains_only_table(html))

    def test_mixed_case(self):
        html = """<h1>Main Document Title</h1>
<p>This is a paragraph containing <strong>bold text</strong>, <em>italic text</em>, and a mix.</p>
<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Age</th>
            <th>City</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Alice</td>
            <td>30</td>
            <td>New York</td>
        </tr>
        <tr>
            <td>Bob</td>
            <td>25</td>
            <td>London</td>
        </tr>
    </tbody>
</table>
<p>This paragraph should appear immediately after the table</p>"""

        self.assertFalse(contains_only_table(html))

    def test_case(self):
        html = """<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Age</th>
            <th>City</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Alice</td>
            <td>30</td>
            <td>New York</td>
        </tr>
        <tr>
            <td>Bob</td>
            <td>25</td>
            <td>London</td>
        </tr>
    </tbody>
</table>"""

        self.assertTrue(contains_only_table(html))

    def test_advanced_mixed_case(self):
        html = """
    
<table>
    <thead>
        <tr>
            <th colspan="2">Product Details</th>
            <th>Price</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td rowspan="2">Electronics</td>
            <td>Laptop</td>
            <td>$1200</td>
        </tr>
        <tr>
            <td>Smartphone</td>
            <td>$700</td>
        </tr>
        <tr>
            <td>Books</td>
            <td>Fiction</td>
            <td>$15</td>
        </tr>
    </tbody>
</table>

"""

        self.assertTrue(contains_only_table(html))


class TestSanitizeSoup(unittest.TestCase):
    def test_remove_script_and_style_tags(self):
        html = """
        <html>
            <head>
                <script>alert("Hello World");</script>
                <style>body {background-color: blue;}</style>
            </head>
            <body>
                <h1>Welcome</h1>
                <p>This is a paragraph.</p>
            </body>
        </html>
        """
        soup = BeautifulSoup(html, "html.parser")
        sanitized_soup = sanitize_soup(soup)
        sanitized_html = str(sanitized_soup)

        self.assertNotIn('<script>', sanitized_html)
        self.assertNotIn('<style>', sanitized_html)
        self.assertIn('<h1>Welcome</h1>', sanitized_html)
        self.assertIn('<p>This is a paragraph.</p>', sanitized_html)

    def test_remove_img_tags(self):
        html = """
        <html>
            <body>
                <img src="image.jpg" alt="Image">
                <p>This is a paragraph.</p>
            </body>
        </html>
        """
        soup = BeautifulSoup(html, "html.parser")
        sanitized_soup = sanitize_soup(soup)
        sanitized_html = str(sanitized_soup)

        self.assertNotIn('<img', sanitized_html)
        self.assertIn('<p>This is a paragraph.</p>', sanitized_html)

    def test_remove_iframe_and_noscript_tags(self):
        html = """
        <html>
            <body>
                <iframe src="https://example.com"></iframe>
                <noscript>JavaScript is required!</noscript>
                <p>This is visible.</p>
            </body>
        </html>
        """
        soup = BeautifulSoup(html, "html.parser")
        sanitized_soup = sanitize_soup(soup)
        sanitized_html = str(sanitized_soup)

        self.assertNotIn('<iframe', sanitized_html)
        self.assertNotIn('<noscript>', sanitized_html)
        self.assertIn('<p>This is visible.</p>', sanitized_html)

    def test_strip_all_attributes_except_whitelisted(self):
        html = """
        <html>
            <body>
                <table>
                    <tr><td rowspan="2">Cell 1</td><td>Cell 2</td></tr>
                    <tr><td colspan="2">Cell 3</td></tr>
                </table>
                <a href="https://example.com" class="link" style="color:red">Click here</a>
            </body>
        </html>
        """
        soup = BeautifulSoup(html, "html.parser")
        sanitized_soup = sanitize_soup(soup)
        sanitized_html = str(sanitized_soup)

        # The <a> tag should have no attributes left
        self.assertIn('<a>Click here</a>', sanitized_html)
        self.assertNotIn('href=', sanitized_html)
        self.assertNotIn('class=', sanitized_html)
        self.assertNotIn('style=', sanitized_html)

        # The <td> tags should keep their 'rowspan' and 'colspan' attributes
        self.assertIn('rowspan="2"', sanitized_html)
        self.assertIn('colspan="2"', sanitized_html)

    def test_empty_input(self):
        html = "<html><body></body></html>"
        soup = BeautifulSoup(html, "html.parser")
        sanitized_soup = sanitize_soup(soup)
        sanitized_html = str(sanitized_soup)

        self.assertIn('<body></body>', sanitized_html)

    def test_strip_non_whitelisted_attributes(self):
        html = """
        <html>
            <body>
                <div class="content" id="main">Main Content</div>
                <table>
                    <tr><td rowspan="1">Cell 1</td></tr>
                    <tr><td colspan="1">Cell 2</td></tr>
                </table>
            </body>
        </html>
        """
        soup = BeautifulSoup(html, "html.parser")
        sanitized_soup = sanitize_soup(soup)
        sanitized_html = str(sanitized_soup)

        # The <div> tag should have its 'class' and 'id' attributes removed
        self.assertNotIn('class="content"', sanitized_html)
        self.assertNotIn('id="main"', sanitized_html)

        # The <td> tags should retain 'rowspan' and 'colspan' attributes
        self.assertIn('rowspan="1"', sanitized_html)
        self.assertIn('colspan="1"', sanitized_html)

    def test_nested_tags(self):
        html = """
        <html>
            <body>
                <div>
                    <p class="text">Paragraph inside div.</p>
                    <script>console.log("This should be removed")</script>
                </div>
            </body>
        </html>
        """
        soup = BeautifulSoup(html, "html.parser")
        sanitized_soup = sanitize_soup(soup)
        sanitized_html = str(sanitized_soup)

        # The <script> tag should be removed
        self.assertNotIn('<script>', sanitized_html)

        # The <p> tag should have its 'class' attribute removed
        self.assertIn('<p>Paragraph inside div.</p>', sanitized_html)
        self.assertNotIn('class="text"', sanitized_html)

    def test_retaining_allowed_attributes_for_td_th(self):
        html = """
        <html>
            <body>
                <table>
                    <tr><td rowspan="3">Cell 1</td><th colspan="2">Header</th></tr>
                    <tr><td>Cell 2</td><td>Cell 3</td></tr>
                </table>
            </body>
        </html>
        """
        soup = BeautifulSoup(html, "html.parser")
        sanitized_soup = sanitize_soup(soup)
        sanitized_html = str(sanitized_soup)

        # The <td> and <th> tags should retain 'rowspan' and 'colspan' attributes
        self.assertIn('rowspan="3"', sanitized_html)
        self.assertIn('colspan="2"', sanitized_html)

        # No other attributes should remain
        self.assertNotIn('class=', sanitized_html)
        self.assertNotIn('style=', sanitized_html)


class TestIterHeaderGroups(unittest.TestCase):

    def test_basic_case(self):
        html = """<h1>Header 1</h1>
<p>Paragraph 1</p>
<h2>Header 2</h2>
<p>Paragraph 2</p>"""
        soup = BeautifulSoup(html, "html.parser")
        body = soup
        header_tags = ['h1', 'h2']

        result = list(_iter_header_groups(body, header_tags))

        # We expect 2 groups: one starting with <h1> and one starting with <h2>
        self.assertEqual(len(result), 2)

        # Check the first group starts with h1 and includes its content
        self.assertEqual(result[0][0].name, 'h1')
        self.assertIn(result[0][0], result[0][1])  # <h1> should be in its own group
        self.assertIn('Paragraph 1', str(result[0][1]))

        # Check the second group starts with h2 and includes its content
        self.assertEqual(result[1][0].name, 'h2')
        self.assertIn(result[1][0], result[1][1])  # <h2> should be in its own group
        self.assertIn('Paragraph 2', str(result[1][1]))

    def test_empty_body(self):
        html = ""
        soup = BeautifulSoup(html, "html.parser")
        body = soup
        header_tags = ['h1', 'h2']

        result = list(_iter_header_groups(body, header_tags))

        # There should be no groups in the result
        self.assertEqual(result, [])

    def test_no_headers(self):
        html = """
        <p>Paragraph 1</p>
        <p>Paragraph 2</p>
        """
        soup = BeautifulSoup(html, "html.parser")
        body = soup
        header_tags = ['h1', 'h2']

        result = list(_iter_header_groups(body, header_tags))

        # We expect a single group with no headers
        self.assertEqual(len(result), 1)
        self.assertIsNone(result[0][0])  # No header in this group
        self.assertIn('Paragraph 1', str(result[0][1]))
        self.assertIn('Paragraph 2', str(result[0][1]))

    def test_multiple_headers_of_same_type(self):
        html = """<h1>Header 1</h1>
<h1>Header 2</h1>
<p>Paragraph 1</p>
<h1>Header 3</h1>"""

        soup = BeautifulSoup(html, "html.parser")
        body = soup
        header_tags = ['h1']

        result = list(_iter_header_groups(body, header_tags))

        # We expect 3 groups
        self.assertEqual(len(result), 3)

        # First group starts with Header 1
        self.assertEqual(result[0][0].name, 'h1')
        self.assertIn('Header 1', str(result[0][0]))

        # Second group starts with Header 2
        self.assertEqual(result[1][0].name, 'h1')
        self.assertIn('Header 2', str(result[1][0]))

        # Third group contains Paragraph 1 (after Header 2)
        self.assertIsNotNone(result[1][1])
        self.assertIn('Paragraph 1', str(result[1][1]))

        # Fourth group starts with Header 3
        self.assertEqual(result[2][0].name, 'h1')
        self.assertIn('Header 3', str(result[2][0]))

    def test_no_preamble(self):
        html = """<h2>Header 1</h2>
<p>Paragraph 1</p>
<h2>Header 2</h2>
<p>Paragraph 2</p>"""
        soup = BeautifulSoup(html, "html.parser")
        body = soup
        header_tags = ['h2']

        result = list(_iter_header_groups(body, header_tags))

        # We expect 2 groups, both starting with h2 headers
        self.assertEqual(len(result), 2)

        # Check the first group starts with h2 and includes its content
        self.assertEqual(result[0][0].name, 'h2')
        self.assertIn('Header 1', str(result[0][0]))
        self.assertIn('Paragraph 1', str(result[0][1]))

        # Check the second group starts with h2 and includes its content
        self.assertEqual(result[1][0].name, 'h2')
        self.assertIn('Header 2', str(result[1][0]))
        self.assertIn('Paragraph 2', str(result[1][1]))

    def test_preamble(self):
        html = """<p>Preamble</p>
<h2>Header 1</h2>
<p>Paragraph 1</p>
<h2>Header 2</h2>
<p>Paragraph 2</p>"""

        soup = BeautifulSoup(html, "html.parser")
        body = soup
        header_tags = ['h2']

        result = list(_iter_header_groups(body, header_tags))

        # We expect 2 groups, both starting with h2 headers
        self.assertEqual(len(result), 3)

        # Check the first group starts with None and includes its content
        self.assertIsNone(result[0][0])
        self.assertIn('Preamble', str(result[0][1]))

        # Check the second group starts with h2 and includes its content
        self.assertEqual(result[1][0].name, 'h2')
        self.assertIn('Header 1', str(result[1][0]))
        self.assertIn('Paragraph 1', str(result[1][1]))

        # Check the third group starts with h2 and includes its content
        self.assertEqual(result[2][0].name, 'h2')
        self.assertIn('Header 2', str(result[2][0]))
        self.assertIn('Paragraph 2', str(result[2][1]))

    def test_single_group_with_no_headers(self):
        html = """
        <p>Paragraph 1</p>
        <p>Paragraph 2</p>
        """
        soup = BeautifulSoup(html, "html.parser")
        body = soup
        header_tags = ['h1', 'h2']

        result = list(_iter_header_groups(body, header_tags))

        # One group with no headers
        self.assertEqual(len(result), 1)
        self.assertIsNone(result[0][0])  # No header
        self.assertIn('Paragraph 1', str(result[0][1]))
        self.assertIn('Paragraph 2', str(result[0][1]))


class TestSplitNodesIntoSegments(unittest.TestCase):
    def setUp(self):
        # Helper function to create a mock Tag with a name
        def create_tag(name):
            tag = Tag(name=name)
            return tag
        self.create_tag = create_tag

    def test_no_table_tags(self):
        nodes = [self.create_tag('div'), self.create_tag('span')]
        result = _split_nodes_into_segments(nodes)
        # Expecting all nodes to be grouped in one segment
        self.assertEqual(result, [[self.create_tag('div'), self.create_tag('span')]])

    def test_single_table_tag(self):
        nodes = [self.create_tag('div'), self.create_tag('table'), self.create_tag('span')]
        result = _split_nodes_into_segments(nodes)
        # Table tag should be its own segment, others grouped together
        expected = [[self.create_tag('div')], [self.create_tag('table')], [self.create_tag('span')]]
        self.assertEqual(result, expected)

    def test_multiple_table_tags(self):
        nodes = [self.create_tag('h1'), self.create_tag('table'), self.create_tag('h2'), self.create_tag('table')]
        result = _split_nodes_into_segments(nodes)
        # Tables should each be in their own segment
        expected = [[self.create_tag('h1')], [self.create_tag('table')], [self.create_tag('h2')],
                    [self.create_tag('table')]]
        self.assertEqual(result, expected)

    def test_empty_list(self):
        nodes = []
        result = _split_nodes_into_segments(nodes)
        # Empty input should return an empty list
        self.assertEqual(result, [])

    def test_table_at_the_end(self):
        nodes = [self.create_tag('div'), self.create_tag('span'), self.create_tag('table')]
        result = _split_nodes_into_segments(nodes)
        # The table should be its own segment at the end
        expected = [[self.create_tag('div'), self.create_tag('span')], [self.create_tag('table')]]
        self.assertEqual(result, expected)


class TestEmitChunksFromGroup(unittest.TestCase):
    def setUp(self):
        # Helper function to create a mock Tag with a name
        def create_tag(name):
            tag = Tag(name=name)
            return tag

        # Store the helper function for creating tags
        self.create_tag = create_tag

    def test_no_header_tag_and_no_nodes(self):
        result = _emit_chunks_from_group(None, [], 3)
        # No header and no nodes -> empty list of chunks
        self.assertEqual(result, [])

    def test_no_header_tag_with_nodes(self):
        nodes = [self.create_tag('div'), self.create_tag('span')]
        result = _emit_chunks_from_group(None, nodes, 3)
        # No header tag, just group the nodes
        expected = [{"level": None, "header": None, "html": "<div></div><span></span>", "order": 3}]
        self.assertEqual(result, expected)

    def test_with_header_tag_and_nodes(self):
        header_tag = self.create_tag('h1')
        header_tag.append("Header text")
        nodes = [self.create_tag('div'), self.create_tag('span')]
        result = _emit_chunks_from_group(header_tag, nodes, 3)
        # The header should be included in the first chunk, followed by the rest of the nodes
        expected = [
            {"level": 1,
             "header": "Header text",
             "html": "<h1>Header text</h1><div></div><span></span>",
             "order": 3
             }
        ]
        self.assertEqual(result, expected)

    def test_with_header_tag_and_empty_nodes(self):
        header_tag = self.create_tag('h2')
        header_tag.append("Empty section")
        nodes = []
        result = _emit_chunks_from_group(header_tag, nodes, 3)
        # No nodes, just the header as a chunk
        expected = [{"level": 2, "header": "Empty section", "html": "<h2>Empty section</h2>", "order": 3}]
        self.assertEqual(result, expected)

    def test_with_header_tag_and_nodes_that_include_header(self):
        header_tag = self.create_tag('h1')
        header_tag.append("Header text")
        nodes = [header_tag, self.create_tag('div')]
        result = _emit_chunks_from_group(header_tag, nodes, 3)
        # The header is already in the nodes, it should not be added again
        expected = [{"level": 1, "header": "Header text", "html": "<h1>Header text</h1><div></div>", "order": 3}]
        self.assertEqual(result, expected)

    def test_empty_section_with_header_only(self):
        header_tag = self.create_tag('h3')
        header_tag.append("Section with only header")
        nodes = []
        result = _emit_chunks_from_group(header_tag, nodes, 3)
        # Empty section but with header only chunk
        expected = [
            {
                "level": 3,
                "header": "Section with only header",
                "html": "<h3>Section with only header</h3>",
                "order": 3
            }
        ]
        self.assertEqual(result, expected)


class TestSplitByHeaders(unittest.TestCase):
    def test_base_case(self):
        html = """<h1>Main Document Title</h1>
<p>This is a paragraph containing <strong>bold text</strong>, <em>italic text</em>, and a mix.</p>
<ul>
<li>First item.</li>
<li>Second item with a <a href="https://www.example.com">helpful link</a>.</li>
<li>Third item, followed by a hard line break.<br/>This line should appear immediately after the break.</li>
</ul>"""

        expected = [
            {
                "level": 1,
                "header": "Main Document Title",
                "html": html,
                "order": 0
            }
        ]

        self.assertEqual(split_by_headers(BeautifulSoup(html, "html.parser"), 1, 6), expected)

    def test_case_headers_out_of_range_above(self):
        html = """<h3>Main Document Title</h3>
<p>This is a paragraph containing <strong>bold text</strong>, <em>italic text</em>, and a mix.</p>
<ul>
<li>First item.</li>
<li>Second item with a <a href="https://www.example.com">helpful link</a>.</li>
<li>Third item, followed by a hard line break.<br/>This line should appear immediately after the break.</li>
</ul>"""

        expected = [
            {
                "level": None,
                "header": None,
                "html": html,
                "order": 0
            }
        ]

        self.assertEqual(split_by_headers(BeautifulSoup(html, "html.parser"), 1, 2), expected)

    def test_case_headers_out_of_range_below(self):
        html = """<h3>Main Document Title</h3>
<p>This is a paragraph containing <strong>bold text</strong>, <em>italic text</em>, and a mix.</p>
<ul>
<li>First item.</li>
<li>Second item with a <a href="https://www.example.com">helpful link</a>.</li>
<li>Third item, followed by a hard line break.<br/>This line should appear immediately after the break.</li>
</ul>"""

        expected = [
            {
                "level": None,
                "header": None,
                "html": html,
                "order": 0
            }
        ]

        self.assertEqual(split_by_headers(BeautifulSoup(html, "html.parser"), 4, 6), expected)

    def test_case_preamble(self):
        html = """<p>This is a preamble.</p>
<h3>Main Document Title</h3>
<p>This is a paragraph containing <strong>bold text</strong>, <em>italic text</em>, and a mix.</p>
<ul>
<li>First item.</li>
<li>Second item with a <a href="https://www.example.com">helpful link</a>.</li>
<li>Third item, followed by a hard line break.<br/>This line should appear immediately after the break.</li>
</ul>"""

        expected = [
            {
                "level": None,
                "header": None,
                "html": "<p>This is a preamble.</p>",
                "order": 0
            },
            {
                "level": 3,
                "header": "Main Document Title",
                "html": """<h3>Main Document Title</h3>
<p>This is a paragraph containing <strong>bold text</strong>, <em>italic text</em>, and a mix.</p>
<ul>
<li>First item.</li>
<li>Second item with a <a href="https://www.example.com">helpful link</a>.</li>
<li>Third item, followed by a hard line break.<br/>This line should appear immediately after the break.</li>
</ul>""",
                "order": 1
            }
        ]

        self.assertEqual(split_by_headers(BeautifulSoup(html, "html.parser"), 1, 6), expected)

    def test_case_no_html(self):
        self.assertEqual(split_by_headers(BeautifulSoup("", "html.parser"), 1, 2), [])

    def test_case_table(self):
        html = """<h1>Main Document Title</h1>
<p>This is a paragraph containing <strong>bold text</strong>, <em>italic text</em>, and a mix.</p>
<table>
<thead>
<tr>
<th>Name</th>
<th>Age</th>
<th>City</th>
</tr>
</thead>
<tbody>
<tr>
<td>Alice</td>
<td>30</td>
<td>New York</td>
</tr>
<tr>
<td>Bob</td>
<td>25</td>
<td>London</td>
</tr>
</tbody>
</table>
<p>This paragraph should appear immediately after the table</p>"""

        expected = [
            {
                "level": 1,
                "header": "Main Document Title",
                "html": """<h1>Main Document Title</h1>
<p>This is a paragraph containing <strong>bold text</strong>, <em>italic text</em>, and a mix.</p>
""",
                "order": 0
            },
            {
                "level": 1,
                "header": "Main Document Title",
                "html": """<table>
<thead>
<tr>
<th>Name</th>
<th>Age</th>
<th>City</th>
</tr>
</thead>
<tbody>
<tr>
<td>Alice</td>
<td>30</td>
<td>New York</td>
</tr>
<tr>
<td>Bob</td>
<td>25</td>
<td>London</td>
</tr>
</tbody>
</table>""",
                "order": 1
            },
            {
                "level": 1,
                "header": "Main Document Title",
                "html": "\n<p>This paragraph should appear immediately after the table</p>",
                "order": 2
            }
        ]

        self.assertEqual(split_by_headers(BeautifulSoup(html, "html.parser"), 1, 6), expected)

    def test_case_table_after_heading(self):
        html = """<h1>Main Document Title</h1><table>
<thead>
<tr>
<th>Name</th>
<th>Age</th>
<th>City</th>
</tr>
</thead>
<tbody>
<tr>
<td>Alice</td>
<td>30</td>
<td>New York</td>
</tr>
<tr>
<td>Bob</td>
<td>25</td>
<td>London</td>
</tr>
</tbody>
</table><p>This paragraph should appear immediately after the table</p>"""

        expected = [
            {
                "level": 1,
                "header": "Main Document Title",
                "html": "<h1>Main Document Title</h1>",
                "order": 0
            },
            {
                "level": 1,
                "header": "Main Document Title",
                "html": """<table>
<thead>
<tr>
<th>Name</th>
<th>Age</th>
<th>City</th>
</tr>
</thead>
<tbody>
<tr>
<td>Alice</td>
<td>30</td>
<td>New York</td>
</tr>
<tr>
<td>Bob</td>
<td>25</td>
<td>London</td>
</tr>
</tbody>
</table>""",
                "order": 1
            },
            {
                "level": 1,
                "header": "Main Document Title",
                "html": "<p>This paragraph should appear immediately after the table</p>",
                "order": 2
            }
        ]

        self.assertEqual(split_by_headers(BeautifulSoup(html, "html.parser"), 1, 6), expected)


if __name__ == "__main__":
    unittest.main()
