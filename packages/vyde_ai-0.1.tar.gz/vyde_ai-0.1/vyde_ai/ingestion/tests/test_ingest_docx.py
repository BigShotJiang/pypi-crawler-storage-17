__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

import string
import unittest
from io import BytesIO
from types import SimpleNamespace
from unittest.mock import patch

from vyde_ai.ingestion.ingest_docx import evaluate_chapters_existence, evaluate_existence, docx_to_chunks


class TestCaseIngestDOCX(unittest.TestCase):
    def test_evaluate_existence_found(self):
        # Setup mock data
        chapters = [{'header': 'Chapter 1', 'html': 'Content 1'}, {'header': 'Chapter 2', 'html': 'Content 2'}]
        expected_chapter = 'Chapter 1'
        message = "Chapter is missing"

        # Run the function
        result = evaluate_existence(expected_chapter, chapters, message)

        # Test if compliance is True and message is None
        self.assertTrue(result['compliance'])
        self.assertIsNone(result['message'])

    def test_evaluate_existence_not_found(self):
        # Setup mock data
        chapters = [{'header': 'Chapter 1', 'html': 'Content 1'}, {'header': 'Chapter 2', 'html': 'Content 2'}]
        expected_chapter = 'Chapter 3'
        message = "Chapter is missing"

        # Run the function
        result = evaluate_existence(expected_chapter, chapters, message)

        # Test if compliance is False and the message is correct
        self.assertFalse(result['compliance'])
        self.assertEqual(result['message'], message)

    def test_evaluate_chapters_existence_all_found(self):
        # Setup mock data
        chapters = [{'header': 'Chapter 1', 'html': 'Content'}, {'header': 'Chapter 2', 'html': 'Content'}]
        expected_chapters = ['Chapter 1', 'Chapter 2']
        message = string.Template("The chapter $chapter is missing.")

        # Run the function
        result = evaluate_chapters_existence(expected_chapters, chapters, message)

        # Test if all chapters have compliance True and no message
        for chapter in expected_chapters:
            self.assertTrue(result[chapter]['compliance'])
            self.assertIsNone(result[chapter]['message'])

    def test_evaluate_chapters_existence_some_not_found(self):
        # Setup mock data
        chapters = [{'header': 'Chapter 1', 'html': 'Content'}]
        expected_chapters = ['Chapter 1', 'Chapter 2']
        message = string.Template("The chapter $chapter is missing.")

        # Run the function
        result = evaluate_chapters_existence(expected_chapters, chapters, message)

        # Test if Chapter 1 has compliance True and no message, and Chapter 2 has compliance False and the correct message
        self.assertTrue(result['Chapter 1']['compliance'])
        self.assertIsNone(result['Chapter 1']['message'])

        self.assertFalse(result['Chapter 2']['compliance'])
        self.assertEqual(result['Chapter 2']['message'], "The chapter Chapter 2 is missing.")

    def test_docx_to_chunks_successful_compliance(self):
        fake_chunks = [
            {'level': 1, 'header': 'Introduction', 'html': '<h1>Introduction</h1>'},
            {'level': 2, 'header': 'Scope', 'html': '<h2>Scope</h2>'}
        ]

        def extra_compliance_check(compliance, chapters_level_1, chapters_level_2):
            self.assertEqual(chapters_level_1, [fake_chunks[0]])
            self.assertEqual(chapters_level_2, [fake_chunks[1]])
            compliance['custom'] = {'compliance': True, 'message': None}
            return compliance

        with patch('vyde_ai.ingestion.ingest_docx.mammoth.convert_to_html') as mock_convert, \
                patch('vyde_ai.ingestion.ingest_docx.sanitize_soup') as mock_sanitize, \
                patch('vyde_ai.ingestion.ingest_docx.split_by_headers') as mock_split:
            mock_convert.return_value = SimpleNamespace(value="<h1>Introduction</h1>")
            mock_sanitize.return_value = "sanitized soup"
            mock_split.return_value = fake_chunks

            chunks, compliance = docx_to_chunks(
                file_obj=BytesIO(b'fake docx content'),
                mandatory_chapters_level_1=['Introduction'],
                mandatory_chapters_level_2=['Scope'],
                additional_compliance_functions=[extra_compliance_check],
            )

        self.assertEqual(chunks, fake_chunks)
        self.assertTrue(compliance['status'])

    def test_docx_to_chunks_missing_chapter_returns_errors(self):
        fake_chunks = [{'level': 1, 'header': 'Overview', 'html': '<h1>Overview</h1>'}]

        with patch('vyde_ai.ingestion.ingest_docx.mammoth.convert_to_html') as mock_convert, \
                patch('vyde_ai.ingestion.ingest_docx.sanitize_soup') as mock_sanitize, \
                patch('vyde_ai.ingestion.ingest_docx.split_by_headers') as mock_split:
            mock_convert.return_value = SimpleNamespace(value="<h1>Overview</h1>")
            mock_sanitize.return_value = "sanitized soup"
            mock_split.return_value = fake_chunks

            chunks, compliance = docx_to_chunks(
                file_obj=BytesIO(b'fake docx content'),
                mandatory_chapters_level_1=['Introduction'],
                mandatory_chapters_level_2=[],
                additional_compliance_functions=[],
            )

        self.assertEqual(chunks, fake_chunks)
        self.assertFalse(compliance['status'])
        self.assertIn('Missing mandatory chapter Introduction', compliance['errors'])

if __name__ == '__main__':
    unittest.main()
