__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from spire.presentation import Presentation, IAutoShape, ShapeType
from spire.presentation import ITable, ISmartArt, SmartArtLayoutType
from spire.presentation.common import RectangleF
from typing import List
from types import SimpleNamespace
from unittest.mock import patch
import unittest

from vyde_ai.ingestion.ingest_pptx import (_autoshape_lines, pptx_to_markdown, _smartart_lines, _smartart_node_lines,
                                           _table_lines, _tf_text, FONTS_DIR)
import vyde_ai.ingestion.ingest_pptx as ingest_module

class TestIngestPPTX(unittest.TestCase):
    def setUp(self):
        self.pres = Presentation()


        # Spire method name is (annoyingly) misspelled in many builds
        if hasattr(self.pres, "SetCustomFontsDirctory"):
            self.pres.SetCustomFontsDirctory(FONTS_DIR)
        else:
            self.pres.SetCustomFontsDirectory(FONTS_DIR)  # fallback if your build uses the correct spelling

        if len(self.pres.Slides) == 0:
            self.pres.Slides.Append()
        self.slide = self.pres.Slides[0]

    def tearDown(self):
        self.pres.Dispose()

    def _new_rect_shape(self, x=30, y=40, w=400, h=120) -> IAutoShape:
        rect = RectangleF.FromLTRB(x, y, x + w, y + h)
        shape: IAutoShape = self.slide.Shapes.AppendShape(ShapeType.Rectangle, rect)
        return shape

    def _new_smartart(self, layout=SmartArtLayoutType.BasicBlockList):
        smart = self.slide.Shapes.AppendSmartArt(10, 10, 400, 300, layout)
        return smart

    def _new_table(self, rows: List[int], cols: List[int]):
        # bounding box arbitraria
        table = self.slide.Shapes.AppendTable(100, 100, cols, rows)
        return table

    def _clear_smartart_text(self, smart):
        """Imposta Text='' su tutti i nodi e sotto-nodi SmartArt, per avere uno stato noto nei test."""
        def _clear_node(node):
            if getattr(node, "TextFrame", None) is not None:
                node.TextFrame.Text = ""
            for child in node.ChildNodes:
                _clear_node(child)

        for node in smart.Nodes:
            _clear_node(node)

    def _new_presentation_with_slide(self):
        pres = Presentation()

        # stessa logica di setUp per i font
        if hasattr(pres, "SetCustomFontsDirctory"):
            pres.SetCustomFontsDirctory(FONTS_DIR)
        else:
            pres.SetCustomFontsDirectory(FONTS_DIR)

        if len(pres.Slides) == 0:
            pres.Slides.Append()

        slide = pres.Slides[0]
        return pres, slide

    def test_autoshape_text_basic_and_normalization(self):
        """Text present -> used; strip + remove \\r applied."""
        rect = RectangleF.FromLTRB(30, 50, 400, 120)
        shape: IAutoShape = self.slide.Shapes.AppendShape(ShapeType.Rectangle, rect)
        # Make sure this is a text box with a text frame
        shape.AppendTextFrame("  Hello\rWorld  ")
        tf = shape.TextFrame  # this is the Spire text frame object
        self.assertEqual(_tf_text(tf), "HelloWorld")  # '\r' removed, spaces stripped

    def test_autoshape_text_empty_string(self):
        rect = RectangleF.FromLTRB(30, 150, 400, 220)
        shape: IAutoShape = self.slide.Shapes.AppendShape(ShapeType.Rectangle, rect)
        shape.AppendTextFrame("")  # explicit empty text
        tf = shape.TextFrame
        self.assertEqual(_tf_text(tf), "")

    def test_autoshape_text_whitespace_only(self):
        rect = RectangleF.FromLTRB(30, 250, 400, 320)
        shape: IAutoShape = self.slide.Shapes.AppendShape(ShapeType.Rectangle, rect)
        shape.AppendTextFrame("   \r   ")
        tf = shape.TextFrame
        self.assertEqual(_tf_text(tf), "")

    def test_textrange_used_when_text_is_none(self):
        """
        Force Text to None by clearing and then writing via paragraph/range,
        then pull a real TextRange and ensure fallback is used.
        """
        rect = RectangleF.FromLTRB(30, 350, 500, 420)
        shape: IAutoShape = self.slide.Shapes.AppendShape(ShapeType.Rectangle, rect)
        shape.AppendTextFrame(None)  # ensure TextFrame exists but Text is None
        # Populate via paragraph/range API so we have a real TextRange.Text
        # Spire creates a default paragraph; ensure at least one range:
        para = shape.TextFrame.Paragraphs[0]
        # If a default range exists, set it; otherwise, append one
        if para.TextRanges.Count > 0:
            rng = para.TextRanges[0]
        else:
            rng = para.TextRanges.Append("")
        rng.Text = "  From TextRange \r "
        # Now pass the *TextFrame* (which has Text=None) to _tf_text
        tf = shape.TextFrame
        self.assertEqual(_tf_text(tf), "From TextRange")

    def test_textrange_attribute_without_textframe_object(self):
        class DummyRange:
            def __init__(self, text: str):
                self.Text = text

        class DummyText:
            def __init__(self):
                self.Text = None
                self.TextRange = DummyRange("  Via TextRange \r ")

        dummy = DummyText()
        self.assertEqual(_tf_text(dummy), "Via TextRange")

    def test_text_takes_precedence_over_textrange(self):
        rect = RectangleF.FromLTRB(30, 450, 500, 520)
        shape: IAutoShape = self.slide.Shapes.AppendShape(ShapeType.Rectangle, rect)
        # First create a range value:
        shape.AppendTextFrame(None)
        para = shape.TextFrame.Paragraphs[0]
        rng = para.TextRanges[0] if para.TextRanges.Count > 0 else para.TextRanges.Append("")
        rng.Text = "Other"
        # Now set TextFrame.Text to something; this must win
        shape.TextFrame.Text = "  Title \r "
        tf = shape.TextFrame
        self.assertEqual(_tf_text(tf), "Title")

    def test_table_cell_textframe_text(self):
        """Table cells expose TextFrame; verify extraction & header-like content."""
        # 2x2 table
        table: ITable = self.slide.Shapes.AppendTable(30, 540, [300, 300], [100, 100])
        table.TableRows[0][0].TextFrame.Text = "  A \r "
        table.TableRows[0][1].TextFrame.Text = "B"
        table.TableRows[1][0].TextFrame.Text = " "
        table.TableRows[1][1].TextFrame.Text = ""

        self.assertEqual(_tf_text(table.TableRows[0][0].TextFrame), "A")  # normalize
        self.assertEqual(_tf_text(table.TableRows[0][1].TextFrame), "B")
        self.assertEqual(_tf_text(table.TableRows[1][0].TextFrame), "")
        self.assertEqual(_tf_text(table.TableRows[1][1].TextFrame), "")

    def test_smartart_node_text(self):
        """SmartArt nodes have TextFrame; verify normalization."""
        # Layout choice just needs to create nodes; content is what we care about
        smart: ISmartArt = self.slide.Shapes.AppendSmartArt(30, 660, 400, 200, SmartArtLayoutType.BasicBlockList)
        # Ensure at least one node exists and set its text
        node = smart.Nodes[0]
        node.TextFrame.Text = "  Smart \r Art  "
        self.assertEqual(_tf_text(node.TextFrame), "Smart  Art")

    def test_none_input_returns_empty(self):
        self.assertEqual(_tf_text(None), "")

    def test_object_without_text_or_textrange_returns_empty(self):
        class Bare:
            pass

        self.assertEqual(_tf_text(Bare()), "")

    def test_returns_lines_for_autoshape_with_text_and_normalizes(self):
        """Text present -> returns [normalized_text, ""]."""
        shape = self._new_rect_shape()
        shape.AppendTextFrame("  Hello\rWorld  ")
        out = _autoshape_lines(shape)
        self.assertEqual(out, ["HelloWorld", ""])

    def test_returns_empty_for_empty_string_text(self):
        shape = self._new_rect_shape(y=180)
        shape.AppendTextFrame("")  # empty
        out = _autoshape_lines(shape)
        self.assertEqual(out, [])  # because normalized string is ""

    def test_returns_empty_for_whitespace_only_text(self):
        shape = self._new_rect_shape(y=320)
        shape.AppendTextFrame("   \r   ")
        out = _autoshape_lines(shape)
        self.assertEqual(out, [])

    def test_uses_textrange_when_text_is_none(self):
        """
        Force TextFrame.Text to None and set content via TextRange.
        Expect [normalized_text, ""]
        """
        shape = self._new_rect_shape(y=460)
        shape.AppendTextFrame(None)  # ensures TextFrame exists but Text is None
        para = shape.TextFrame.Paragraphs[0]
        rng = para.TextRanges[0] if para.TextRanges.Count > 0 else para.TextRanges.Append("")
        rng.Text = "  From TextRange \r "
        out = _autoshape_lines(shape)
        self.assertEqual(out, ["From TextRange", ""])

    def test_object_without_textframe_attribute_returns_empty(self):
        """Defensive branch: getattr(..., None) -> _tf_text(None) -> '' -> []"""

        class NoTextFrame:
            pass

        out = _autoshape_lines(NoTextFrame())
        self.assertEqual(out, [])

    def test_table_rows_but_all_cells_empty(self):
        """Tutte le celle vuote → nessuna riga markdown prodotta"""
        table = self._new_table([100, 100], [100, 100])
        # Lasciamo tutte le celle con Text=None
        self.assertEqual(_table_lines(table), [])

    def test_table_lines_with_plain_python_objects(self):
        class DummyRow:
            def __init__(self, values):
                self.cells = [SimpleNamespace(TextFrame=SimpleNamespace(Text=val)) for val in values]
                self.Count = len(self.cells)

            def __getitem__(self, idx):
                return self.cells[idx]

        table = SimpleNamespace(TableRows=[
            DummyRow(["H1", "H2"]),
            DummyRow(["V1", "V2"]),
        ])

        self.assertEqual(_table_lines(table), [
            "H1 | H2",
            " --- |  ---",
            "V1 | V2",
            ""
        ])

    def test_first_row_non_empty_generates_header(self):
        """La prima riga valida genera l'header markdown"""
        table = self._new_table([100, 100], [100, 100])
        table.TableRows[0][0].TextFrame.Text = "A"
        table.TableRows[0][1].TextFrame.Text = "B"
        table.TableRows[1][0].TextFrame.Text = "C"
        table.TableRows[1][1].TextFrame.Text = "D"

        lines = _table_lines(table)
        self.assertEqual(lines, [
            "A | B",
            " --- |  ---",
            "C | D",
            ""
        ])

    def test_first_row_empty_second_row_nonempty(self):
        """
        Corner-case: prima riga con tutte celle vuote → NON è header
        La seconda riga viene trattata come riga normale e NON genera header
        """
        table = self._new_table([100, 100], [100, 100])
        # Prima riga vuota
        # Seconda riga con contenuto
        table.TableRows[1][0].TextFrame.Text = "X"
        table.TableRows[1][1].TextFrame.Text = "Y"

        lines = _table_lines(table)
        self.assertEqual(lines, [
            "X | Y",
            " --- |  ---",
            ""  # markdown termina con riga vuota se c’è almeno una riga valida
        ])

    def test_mixed_empty_and_nonempty_rows(self):
        """Righe miste: solo quelle con almeno una cella non vuota vengono emesse"""
        table = self._new_table([100, 100, 100, 100], [100, 100])

        # riga 0: non empty → header
        table.TableRows[0][0].TextFrame.Text = "H1"
        table.TableRows[0][1].TextFrame.Text = "H2"

        # riga 1: empty → ignorata
        # riga 2: non empty
        table.TableRows[2][0].TextFrame.Text = "A"
        table.TableRows[2][1].TextFrame.Text = "B"

        # riga 3: empty → ignorata

        lines = _table_lines(table)
        self.assertEqual(lines, [
            "H1 | H2",
            " --- |  ---",
            "A | B",
            ""
        ])

    def test_cells_with_whitespace_only(self):
        """Celle con solo whitespace devono essere trattate come vuote"""
        table = self._new_table([100, 100], [100, 100])

        table.TableRows[0][0].TextFrame.Text = "   "  # empty
        table.TableRows[0][1].TextFrame.Text = " "  # empty
        table.TableRows[1][0].TextFrame.Text = "A"  # non empty
        table.TableRows[1][1].TextFrame.Text = "B"

        lines = _table_lines(table)
        # Header generato sulla prima riga *non blank* → la seconda riga
        self.assertEqual(lines, [
            "A | B",
            " --- |  ---",
            ""
        ])

    def test_cells_with_none_text(self):
        """Celle con TextFrame.Text=None devono essere interpretate come vuote"""
        table = self._new_table([100, 100], [100, 100])

        # prima riga None → ignorata
        table.TableRows[1][0].TextFrame.Text = "A"
        table.TableRows[1][1].TextFrame.Text = "B"

        lines = _table_lines(table)
        self.assertEqual(lines, [
            "A | B",
            " --- |  ---",
            ""
        ])

    def test_multiline_text(self):
        """Il testo multilinea viene pulito via _tf_text"""
        table = self._new_table([100], [100, 100])
        table.TableRows[0][0].TextFrame.Text = "Hello\rWorld"
        table.TableRows[0][1].TextFrame.Text = "X\rY"

        lines = _table_lines(table)
        # \r è rimosso → "HelloWorld"
        self.assertEqual(lines, [
            "HelloWorld | XY",
            " --- |  ---",
            ""
        ])

    def test_single_node_with_text(self):
        smart = self._new_smartart()
        node = smart.Nodes[0]
        node.TextFrame.Text = "Hello"

        lines, seen = _smartart_node_lines(node, level=0, seen=frozenset())

        self.assertEqual(lines, ["- Hello"])
        self.assertEqual(seen, frozenset({"Hello"}))

    def test_single_node_empty_text(self):
        smart = self._new_smartart()
        node = smart.Nodes[0]
        node.TextFrame.Text = ""

        lines, seen = _smartart_node_lines(node, level=0, seen=frozenset())

        self.assertEqual(lines, [])  # nessuna linea
        self.assertEqual(seen, frozenset())

    def test_trim_and_remove_cr(self):
        smart = self._new_smartart()
        node = smart.Nodes[0]
        node.TextFrame.Text = "  Hello\rWorld  "

        lines, seen = _smartart_node_lines(node, 0, frozenset())

        # _tf_text rimuove \r e trimma → "HelloWorld"
        self.assertEqual(lines, ["- HelloWorld"])
        self.assertIn("HelloWorld", seen)

    def test_node_with_child(self):
        smart = self._new_smartart()
        root = smart.Nodes[0]
        root.TextFrame.Text = "Parent"

        child = root.ChildNodes.AddNode()
        child.TextFrame.Text = "Child"

        lines, seen = _smartart_node_lines(root, 0, frozenset())

        self.assertEqual(lines, [
            "- Parent",
            "  - Child"
        ])
        self.assertEqual(seen, frozenset({"Parent", "Child"}))

    def test_child_without_text(self):
        smart = self._new_smartart()
        root = smart.Nodes[0]
        root.TextFrame.Text = "Root"

        child = root.ChildNodes.AddNode()
        child.TextFrame.Text = ""  # empty

        lines, seen = _smartart_node_lines(root, 0, frozenset())

        self.assertEqual(lines, ["- Root"])  # child skipped
        self.assertEqual(seen, frozenset({"Root"}))

    def test_duplicate_text_skipped(self):
        smart = self._new_smartart()
        root = smart.Nodes[0]
        root.TextFrame.Text = "Item"

        child1 = root.ChildNodes.AddNode()
        child1.TextFrame.Text = "Item"  # duplicate

        child2 = root.ChildNodes.AddNode()
        child2.TextFrame.Text = "Other"

        lines, seen = _smartart_node_lines(root, 0, frozenset())

        self.assertEqual(lines, [
            "- Item",
            "  - Other"
        ])
        self.assertEqual(seen, frozenset({"Item", "Other"}))

    def test_duplicates_in_different_branches(self):
        smart = self._new_smartart()
        root = smart.Nodes[0]
        root.TextFrame.Text = "Root"

        child1 = root.ChildNodes.AddNode()
        child1.TextFrame.Text = "A"

        child2 = root.ChildNodes.AddNode()
        child2.TextFrame.Text = "A"  # duplicate in sibling branch

        lines, seen = _smartart_node_lines(root, 0, frozenset())

        self.assertEqual(lines, [
            "- Root",
            "  - A"
        ])
        self.assertEqual(seen, frozenset({"Root", "A"}))


    def test_multi_level_nested(self):
        smart = self._new_smartart()
        root = smart.Nodes[0]
        root.TextFrame.Text = "L1"

        c1 = root.ChildNodes.AddNode()
        c1.TextFrame.Text = "L2"

        c2 = c1.ChildNodes.AddNode()
        c2.TextFrame.Text = "L3"

        lines, seen = _smartart_node_lines(root, 0, frozenset())

        self.assertEqual(lines, [
            "- L1",
            "  - L2",
            "    - L3",
        ])
        self.assertEqual(seen, frozenset({"L1", "L2", "L3"}))

    def test_smartart_lines_all_nodes_empty(self):
        """Se tutti i nodi (e figli) hanno testo vuoto → nessuna linea."""
        smart = self._new_smartart()
        self._clear_smartart_text(smart)

        lines = _smartart_lines(smart)

        self.assertEqual(lines, [])  # niente "" finale se non ci sono linee

    def test_smartart_lines_single_root_node(self):
        """SmartArt con un solo nodo root con testo semplice."""
        smart = self._new_smartart()
        self._clear_smartart_text(smart)

        root = smart.Nodes[0]
        root.TextFrame.Text = "Root"

        lines = _smartart_lines(smart)

        self.assertEqual(lines, [
            "- Root",
            ""
        ])

    def test_smartart_lines_multiple_root_nodes(self):
        """Più root node con testo diverso vengono emessi in sequenza."""
        smart = self._new_smartart()
        self._clear_smartart_text(smart)

        root1 = smart.Nodes[0]
        root1.TextFrame.Text = "First"

        root2 = smart.Nodes.AddNode()
        root2.TextFrame.Text = "Second"

        lines = _smartart_lines(smart)

        self.assertEqual(lines, [
            "- First",
            "- Second",
            ""
        ])

    def test_smartart_lines_dedup_across_roots(self):
        """Test deduplicazione tra root diversi grazie a 'seen' condiviso."""
        smart = self._new_smartart()
        self._clear_smartart_text(smart)

        root1 = smart.Nodes[0]
        root1.TextFrame.Text = "Same"

        root2 = smart.Nodes.AddNode()
        root2.TextFrame.Text = "Same"  # duplicato

        lines = _smartart_lines(smart)

        # Il secondo "Same" viene ignorato completamente
        self.assertEqual(lines, [
            "- Same",
            ""
        ])

    def test_smartart_lines_nested_multiple_roots(self):
        """Struttura annidata con più root: controlla indentazione e ordine."""
        smart = self._new_smartart()
        self._clear_smartart_text(smart)

        # Primo root con un figlio
        root1 = smart.Nodes[0]
        root1.TextFrame.Text = "Root1"
        child1 = root1.ChildNodes.AddNode()
        child1.TextFrame.Text = "Child1"

        # Secondo root con un figlio
        root2 = smart.Nodes.AddNode()
        root2.TextFrame.Text = "Root2"
        child2 = root2.ChildNodes.AddNode()
        child2.TextFrame.Text = "Child2"

        lines = _smartart_lines(smart)

        self.assertEqual(lines, [
            "- Root1",
            "  - Child1",
            "- Root2",
            "  - Child2",
            ""
        ])

    def test_smartart_lines_trim_and_cr_handling(self):
        """Verifica che _tf_text venga applicato anche via _smartart_lines."""
        smart = self._new_smartart()
        self._clear_smartart_text(smart)

        root = smart.Nodes[0]
        root.TextFrame.Text = "  Hello\rWorld  "

        lines = _smartart_lines(smart)

        # \r rimosso e testo trimmato → "HelloWorld"
        self.assertEqual(lines, [
            "- HelloWorld",
            ""
        ])

    def test_pptx_to_markdown_empty_presentation(self):
        pres = Presentation()
        # niente slide aggiunte

        md = pptx_to_markdown(pres)

        self.assertEqual(md, [])

    def test_pptx_to_markdown_single_slide_autoshape(self):
        pres, slide = self._new_presentation_with_slide()

        rect = RectangleF.FromLTRB(30, 40, 430, 160)
        shape = slide.Shapes.AppendShape(ShapeType.Rectangle, rect)
        shape.TextFrame.Text = "Hello world"

        md = pptx_to_markdown(pres)

        # una sola slide
        self.assertEqual(len(md), 1)
        text = md[0]

        # struttura base
        self.assertIn("Hello world", text)

        # forma esatta attesa:
        self.assertEqual(text, "Hello world")

    def test_pptx_to_markdown_slide_with_autoshape_table_smartart(self):
        pres, slide = self._new_presentation_with_slide()

        # 1) AutoShape (heading)
        rect = RectangleF.FromLTRB(10, 10, 410, 80)
        shape = slide.Shapes.AppendShape(ShapeType.Rectangle, rect)
        shape.TextFrame.Text = "Heading"

        # 2) Table
        col_widths = [100, 100]
        row_heights = [20, 20]
        table = slide.Shapes.AppendTable(100, 120, col_widths, row_heights)

        # Header row
        table.TableRows[0][0].TextFrame.Text = "Col1"
        table.TableRows[0][1].TextFrame.Text = "Col2"
        # Data row
        table.TableRows[1][0].TextFrame.Text = "A"
        table.TableRows[1][1].TextFrame.Text = "B"

        # 3) SmartArt
        smart = slide.Shapes.AppendSmartArt(10, 10, 400, 300, SmartArtLayoutType.BasicBlockList)
        root = smart.Nodes[0]
        root.TextFrame.Text = "Item1"
        child = root.ChildNodes.AddNode()
        child.TextFrame.Text = "Sub1"

        md = pptx_to_markdown(pres)

        self.assertEqual(len(md), 1)
        text = md[0]

        # Contenuti attesi
        self.assertIn("Heading", text)
        self.assertIn("Col1 | Col2", text)
        self.assertIn(" --- |  ---", text)
        self.assertIn("A | B", text)
        self.assertIn("- Item1", text)
        self.assertIn("  - Sub1", text)

        # Ordine: Heading -> Table -> SmartArt
        idx_heading = text.find("Heading")
        idx_table = text.find("Col1 | Col2")
        idx_smart = text.find("- Item1")

        self.assertNotEqual(idx_heading, -1)
        self.assertNotEqual(idx_table, -1)
        self.assertNotEqual(idx_smart, -1)

        self.assertLess(idx_heading, idx_table)
        self.assertLess(idx_table, idx_smart)

    def test_pptx_to_markdown_multiple_slides(self):
        pres = Presentation()

        # fonts
        if hasattr(pres, "SetCustomFontsDirctory"):
            pres.SetCustomFontsDirctory(FONTS_DIR)
        else:
            pres.SetCustomFontsDirectory(FONTS_DIR)

        # Slide 1
        pres.Slides.Append()
        slide1 = pres.Slides[0]
        rect1 = RectangleF.FromLTRB(10, 10, 400, 100)
        shp1 = slide1.Shapes.AppendShape(ShapeType.Rectangle, rect1)
        shp1.TextFrame.Text = "First slide content"

        # Slide 2
        pres.Slides.Append()
        slide2 = pres.Slides[1]
        rect2 = RectangleF.FromLTRB(10, 10, 400, 100)
        shp2 = slide2.Shapes.AppendShape(ShapeType.Rectangle, rect2)
        shp2.TextFrame.Text = "Second slide content"

        md = pptx_to_markdown(pres)

        self.assertEqual(len(md), 2)

        slide1_md = md[0]
        slide2_md = md[1]

        self.assertIn("First slide content", slide1_md)
        self.assertIn("Second slide content", slide2_md)

    def test_pptx_to_markdown_pythonic_table_and_smartart(self):
        class DummyPresentation:
            def __init__(self, slides):
                self.Slides = slides
                self.disposed = False

            def Dispose(self):
                self.disposed = True

        class DummySlide:
            def __init__(self, shapes):
                self.Shapes = shapes

        class FakeTableShape:
            pass

        class FakeSmartArtShape:
            pass

        table_shape = FakeTableShape()
        smart_shape = FakeSmartArtShape()
        pres = DummyPresentation([DummySlide([table_shape, smart_shape])])

        fake_auto_shape = type("FakeAutoShape", (), {})

        with patch.multiple(ingest_module, IAutoShape=fake_auto_shape, ITable=FakeTableShape, ISmartArt=FakeSmartArtShape):
            with patch.object(ingest_module, "_table_lines", return_value=["Table block"]) as table_mock, \
                 patch.object(ingest_module, "_smartart_lines", return_value=["Smart block"]) as smart_mock:
                md = pptx_to_markdown(pres)

        self.assertEqual(md, ["Table block\nSmart block"])
        self.assertTrue(pres.disposed)
        table_mock.assert_called_once_with(table_shape)
        smart_mock.assert_called_once_with(smart_shape)


if __name__ == '__main__':
    unittest.main()
