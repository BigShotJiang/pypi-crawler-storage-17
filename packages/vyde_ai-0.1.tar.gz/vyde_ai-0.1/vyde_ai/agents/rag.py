__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from langgraph.graph import END, START, StateGraph
from typing import Any, Callable, Dict, Optional, Type

from vyde_ai.agents.base import BaseAgent, T
from vyde_ai.nodes import ChainNode, EvaluateChunksNode, IterateNode, GenerateQueriesNode, LLMNode


class RagAgent(BaseAgent[T]):
    def __init__(
            self,
            state_cls: Type[T],
            project_name: str,
            generate_queries_node: GenerateQueriesNode,
            call_semantic_search_node: ChainNode,
            pre_run_graph: Optional[StateGraph] = None,
            iterable_query_field: str = 'idx_current_query',
            iterable_chunk_field: str = 'idx_current_chunk',
            chunks_field: str = 'chunks',
            valid_chunks_field: str = 'valid_chunks',
            queries_field: str = 'queries',
            agent_name: str = "rag",
            disable_tracing: bool = False,
            graph_modifier: Optional[Callable[[StateGraph], None]] = None,
    ):
        super().__init__(
            agent_name=agent_name,
            project_name=project_name,
            state_cls=state_cls,
            disable_tracing=disable_tracing,
            graph_modifier=graph_modifier
        )

        self.queries_field = queries_field
        self.chunk_field = chunks_field
        self.iterable_query_field = iterable_query_field
        self.iterable_chunk_field = iterable_chunk_field

        self.pre_run_graph = pre_run_graph

        # Set-up nodes
        self.iterate_queries_node = IterateNode(name='iterate_queries', iterable_field=self.iterable_query_field)
        self.iterate_chunks_node = IterateNode(name='iterate_chunks', iterable_field=self.iterable_chunk_field)

        class GenerateResponseNode(LLMNode):
            def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
                context = "\n\n".join([d.page_content for d in state[valid_chunks_field]])
                return {"context": context}

            def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
                return {'response': response}

        self.generate_response = GenerateResponseNode(name='generate_response')

        self.call_semantic_search_node = call_semantic_search_node

        self.evaluate_chunks_node = EvaluateChunksNode(
            name='evaluate_chunks',
            iterable_field=iterable_chunk_field,
            chunks_field=chunks_field,
            valid_chunks_field=valid_chunks_field
        )

        self.generate_queries_node = generate_queries_node
        self.generate_queries_node.chunks_field=chunks_field
        self.generate_queries_node.iterable_query_field=iterable_query_field
        self.generate_queries_node.iterable_chunk_field = iterable_chunk_field
        self.generate_queries_node.queries_field = queries_field
        self.generate_queries_node.valid_chunks_field = valid_chunks_field

    def _add_nodes(self):
        if self.pre_run_graph is not None:
            self.builder.add_node(f"{self.agent_name}__call_pre_run_graph", self.pre_run_graph.compile())

        self.nodes.append(self.call_semantic_search_node)
        self.nodes.append(self.iterate_queries_node)
        self.nodes.append(self.iterate_chunks_node)
        self.nodes.append(self.evaluate_chunks_node)
        self.nodes.append(self.generate_queries_node)
        self.nodes.append(self.generate_response)

    def _design_graph(self):
        if self.pre_run_graph is not None:
            self.builder.add_edge(START, f"{self.agent_name}__call_pre_run_graph")
            self.builder.add_edge(f"{self.agent_name}__call_pre_run_graph", self.generate_queries_node.name)
        else:
            self.builder.add_edge(START, self.generate_queries_node.name)

        self.builder.add_edge(self.generate_queries_node.name, self.iterate_queries_node.name)
        self.builder.add_conditional_edges(
            self.iterate_queries_node.name,
            lambda state: 'exit' if state[self.iterable_query_field] == len(state[self.queries_field]) else 'loop',
            {
                'exit': self.iterate_chunks_node.name,
                'loop': self.call_semantic_search_node.name,
            }
        )
        self.builder.add_edge(self.call_semantic_search_node.name, self.iterate_queries_node.name)

        self.builder.add_conditional_edges(
            self.iterate_chunks_node.name,
            lambda state: 'exit' if state[self.iterable_chunk_field] == len(state[self.chunk_field]) else 'loop',
            {
                'exit': self.generate_response.name,
                'loop': self.evaluate_chunks_node.name,
            }
        )
        self.builder.add_edge(self.evaluate_chunks_node.name, self.iterate_chunks_node.name)
        self.builder.add_edge(self.generate_response.name, END)
