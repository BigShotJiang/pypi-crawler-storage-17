__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from langchain.embeddings import Embeddings
from langgraph.graph import END, START, StateGraph
from typing import Callable, Optional, Type

from vyde_ai.agents.base import BaseAgent, T
from vyde_ai.vectorstore import AbstractVectorStoreManager
from vyde_ai.nodes import SemanticSearchNode


class SemanticSearchAgent(BaseAgent[T]):
    def __init__(
            self,
            state_cls: Type[T],
            vectorstore_class: Type[AbstractVectorStoreManager],
            project_name: str,
            embedding_function: Embeddings,
            agent_name: str = "semantic_search",
            disable_tracing: bool = False,
            graph_modifier: Optional[Callable[[StateGraph], None]] = None,
    ):
        super().__init__(
            agent_name=agent_name,
            project_name=project_name,
            state_cls=state_cls,
            disable_tracing=disable_tracing,
            graph_modifier=graph_modifier,
        )

        self.search_node = SemanticSearchNode(
            name="run_semantic_search",
            vectorstore_class=vectorstore_class,
            embedding_function=embedding_function,
            agent_name=agent_name,
            project_name=project_name,
            disable_tracing=disable_tracing
        )

    def _add_nodes(self):
        self.nodes.append(self.search_node)

    def _design_graph(self):
        self.builder.add_edge(START, self.search_node.name)
        self.builder.add_edge(self.search_node.name, END)
