__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from langgraph.graph import END, START, StateGraph
from typing import Callable, Dict, Optional, Type

from vyde_ai.agents.base import BaseAgent, T
from vyde_ai.nodes.base import AbstractNode
from vyde_ai.nodes import OrchestratorNode, PlannerNode


class SupervisorAgent(BaseAgent[T]):
    def __init__(
            self,
            state_cls: Type[T],
            project_name: str,
            action_nodes: Dict[str, AbstractNode],
            respond_node: AbstractNode,
            fallback_node: AbstractNode,
            agent_name: str = "supervisor",
            actions: str = 'actions',
            consumable_actions: str = 'consumable_actions',
            context: str = 'context',
            fallback_action: str = 'Fallback and clarification',
            next_action: str = 'next_action',
            disable_tracing: bool = False,
            graph_modifier: Optional[Callable[[StateGraph], None]] = None,
    ):
        super().__init__(
            agent_name=agent_name,
            project_name=project_name,
            state_cls=state_cls,
            disable_tracing=disable_tracing,
            graph_modifier=graph_modifier,
        )

        self.action_nodes = []
        self.action_mapping = {}

        for key, node in action_nodes.items():
            node.agent_name = self.agent_name
            node.project_name = self.project_name
            node.disable_tracing = self.disable_tracing

            self.action_nodes.append(node)
            self.action_mapping[key] = node.name

        self.actions = actions
        self.consumable_actions = consumable_actions
        self.context = context
        self.fallback_action = fallback_action
        self.next_action = next_action

        self.planner_node = PlannerNode(
            name='planner',
            agent_name=self.agent_name,
            project_name=self.project_name,
            actions=self.actions,
            context=self.context,
            fallback_action=self.fallback_action,
            consumable_actions=self.consumable_actions,
            disable_tracing=self.disable_tracing,
        )

        self.orchestrator_node = OrchestratorNode(
            name='orchestrator',
            agent_name=self.agent_name,
            project_name=self.project_name,
            consumable_actions=self.consumable_actions,
            disable_tracing=self.disable_tracing,
            next_action=self.next_action,
        )

        self.respond_node = respond_node
        self.fallback_node = fallback_node

    def _add_nodes(self):
        self.nodes.append(self.planner_node)
        self.nodes.append(self.orchestrator_node)
        self.nodes.append(self.fallback_node)

        for node in self.action_nodes:
            self.nodes.append(node)

        self.nodes.append(self.respond_node)

    def _design_graph(self):
        self.builder.add_edge(START, self.planner_node.name)
        self.builder.add_edge(self.planner_node.name, self.orchestrator_node.name)

        self.builder.add_conditional_edges(
            self.orchestrator_node.name,
            lambda state: state[self.next_action],
            {**self.action_mapping, self.fallback_action: self.fallback_node.name, "END": self.respond_node.name}
        )

        for node in self.action_nodes:
            self.builder.add_edge(node.name, self.orchestrator_node.name)

        self.builder.add_edge(self.fallback_node.name, self.orchestrator_node.name)
        self.builder.add_edge(self.respond_node.name, END)
