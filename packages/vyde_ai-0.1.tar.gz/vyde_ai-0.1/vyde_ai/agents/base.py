__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from abc import ABC, abstractmethod
from typing import Callable, Generic, Optional, Type, TypeVar

from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.graph import StateGraph
from langgraph.graph.state import CompiledStateGraph


T = TypeVar("T")


class BaseAgent(ABC, Generic[T]):
    def __init__(
            self,
            state_cls: Type[T],
            agent_name: str,
            project_name: str,
            disable_tracing: bool = False,
            graph_modifier: Optional[Callable[[StateGraph], None]] = None,
    ):
        self.agent_name = agent_name
        self.nodes = []
        self.project_name = project_name
        self.disable_tracing = disable_tracing
        self.graph_modifier = graph_modifier
        self.builder = StateGraph(state_cls)
        self.is_graph_built = False

    @abstractmethod
    def _add_nodes(self):
        pass

    @abstractmethod
    def _design_graph(self):
        pass

    def _prepare_nodes(self):
        for node in self.nodes:
            node.agent_name = self.agent_name
            node.project_name = self.project_name
            node.disable_tracing = self.disable_tracing

            self.builder.add_node(node.name, node.node())


    def graph(self, memory: Optional[BaseCheckpointSaver] = None) -> CompiledStateGraph:
        if not self.is_graph_built:
            self._add_nodes()
            self._prepare_nodes()
            self._design_graph()
            if self.graph_modifier is not None:
                self.graph_modifier(self.builder)
            self.is_graph_built = True

        if memory is not None:
            return self.builder.compile(checkpointer=memory)

        return self.builder.compile(checkpointer=True)
