__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from langgraph.graph import START, END, MessagesState
from typing import Dict, Any
import unittest
from unittest.mock import MagicMock, patch

from vyde_ai.agents.supervisor import SupervisorAgent
from vyde_ai.nodes.base import AbstractNode
from vyde_ai.nodes import OrchestratorNode, PlannerNode


class TestNode(AbstractNode):
    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        return {"response": "ok"}

    def invoke(self, state):
        return {"res": "done"}


class TestSupervisorAgent(unittest.TestCase):
    @patch("vyde_ai.agents.base.StateGraph")
    def test_initialization_correctly_rewrites_action_nodes(self, mock_graph_cls):
        """SupervisorAgent must rewrite action node attributes and build mapping."""

        mock_graph_cls.return_value = MagicMock()

        action1 = TestNode(
            name="nodeA",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=True
        )
        action2 = TestNode(
            name="nodeB",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=True
        )
        respond = TestNode(
            name="respond",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=True
        )
        fallback = TestNode(
            name="fallback",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=True
        )

        agent = SupervisorAgent(
            state_cls=MessagesState,
            project_name="MyProject",
            action_nodes={"A": action1, "B": action2},
            respond_node=respond,
            fallback_node=fallback,
        )

        for node in agent.action_nodes:
            self.assertEqual(node.agent_name, "supervisor")
            self.assertEqual(node.project_name, "MyProject")

        self.assertIsInstance(agent.planner_node, PlannerNode)
        self.assertIsInstance(agent.orchestrator_node, OrchestratorNode)

    @patch("vyde_ai.agents.base.StateGraph")
    def test_add_nodes_registers_all_supervisor_specific_nodes(self, mock_graph_cls):
        """Ensure SupervisorAgent._add_nodes() registers planner, orchestrator,
        fallback, all action nodes, and respond node."""

        mock_builder = MagicMock()
        mock_graph_cls.return_value = mock_builder

        actA = TestNode(
            name="A1",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=True
        )
        actB = TestNode(
            name="A2",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=True
        )
        resp = TestNode(
            name="resp",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=True
        )
        fallback = TestNode(
            name="fallback",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=True
        )

        agent = SupervisorAgent(
            state_cls=MessagesState,
            project_name="P",
            action_nodes={"X": actA, "Y": actB},
            respond_node=resp,
            fallback_node=fallback,
        )

        agent._add_nodes()
        agent._prepare_nodes()

        # Extract (node_name, _) from each actual call
        actual_called_nodes = [
            call_args.args[0]  # first positional arg = node name
            for call_args in mock_builder.add_node.call_args_list
        ]

        expected_nodes = [
            agent.planner_node.name,
            agent.orchestrator_node.name,
            fallback.name,
            actA.name,
            actB.name,
            resp.name,
        ]

        self.assertEqual(actual_called_nodes, expected_nodes)
        self.assertEqual(mock_builder.add_node.call_count, len(expected_nodes))

    @patch("vyde_ai.agents.base.StateGraph")
    def test_design_graph_connects_supervisor_logic_correctly(self, mock_graph_cls):
        """SupervisorAgent._design_graph() wiring is unique: planner → orchestrator,
        action nodes → orchestrator, fallback → orchestrator, respond → END,
        and conditional logic from orchestrator."""

        mock_builder = MagicMock()
        mock_graph_cls.return_value = mock_builder

        act1 = TestNode(
            name="A1",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=True
        )
        act2 = TestNode(
            name="A2",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=True
        )
        respond = TestNode(
            name="resp",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=True
        )
        fallback = TestNode(
            name="fallback",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=True
        )

        agent = SupervisorAgent(
            state_cls=MessagesState,
            project_name="PROJ",
            action_nodes={"X": act1, "Y": act2},
            respond_node=respond,
            fallback_node=fallback,
        )

        agent._add_nodes()
        agent._prepare_nodes()
        agent._design_graph()

        mock_builder.add_edge.assert_any_call(START, agent.planner_node.name)
        mock_builder.add_edge.assert_any_call(agent.planner_node.name, agent.orchestrator_node.name)
        mock_builder.add_conditional_edges.assert_called_once()
        args, kwargs = mock_builder.add_conditional_edges.call_args

        self.assertEqual(args[0], agent.orchestrator_node.name)
        self.assertTrue(callable(args[1]))

        expected_mapping = {
            "X": "supervisor__A1",
            "Y": "supervisor__A2",
            agent.fallback_action: "supervisor__fallback",
            "END": "supervisor__resp",
        }
        self.assertEqual(args[2], expected_mapping)

        mock_builder.add_edge.assert_any_call("supervisor__A1", agent.orchestrator_node.name)
        mock_builder.add_edge.assert_any_call("supervisor__A2", agent.orchestrator_node.name)

        mock_builder.add_edge.assert_any_call("supervisor__fallback", agent.orchestrator_node.name)

        mock_builder.add_edge.assert_any_call("supervisor__resp", END)


if __name__ == "__main__":
    unittest.main()
