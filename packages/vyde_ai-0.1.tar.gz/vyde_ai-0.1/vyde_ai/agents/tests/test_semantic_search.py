__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from langchain_community.embeddings import FakeEmbeddings
from langgraph.graph import START, END, MessagesState
import unittest
from unittest.mock import MagicMock, patch

from vyde_ai.agents.semantic_search import SemanticSearchAgent


class TestSemanticSearch(unittest.TestCase):
    @patch("vyde_ai.agents.semantic_search.SemanticSearchNode")
    def setUp(self, mock_node_class):
        """Patch SemanticSearchNode so we can verify instantiation and so that no real node behavior runs."""
        self.mock_node_instance = MagicMock()
        mock_node_class.return_value = self.mock_node_instance

        self.mock_vectorstore = MagicMock()
        self.mock_vectorstore.similarity_search_by_vector.return_value = ["chunk1", "chunk2"]

        self.mock_vectorstore.embeddings = MagicMock()
        self.mock_vectorstore.embeddings.embed_query.return_value = [0.1, 0.2, 0.3]

        self.mock_manager_instance = MagicMock()
        self.mock_manager_instance.vectorstore = self.mock_vectorstore

        self.mock_vectorstore_class = MagicMock(return_value=self.mock_manager_instance)

        self.agent = SemanticSearchAgent(
            state_cls=MessagesState,
            project_name="proj",
            vectorstore_class=self.mock_vectorstore_class,
            embedding_function=FakeEmbeddings(size=3),
            agent_name="semantic_agent",
            disable_tracing=True
        )

        self.mock_node_class = mock_node_class

    def test_initialization_creates_search_node(self):
        """Ensure SemanticSearchNode was constructed with correct args."""
        self.mock_node_class.assert_called_once_with(
            name="run_semantic_search",
            vectorstore_class=self.mock_vectorstore_class,
            embedding_function=FakeEmbeddings(size=3),
            agent_name="semantic_agent",
            project_name="proj",
            disable_tracing=True
        )

        self.assertEqual(self.agent.search_node, self.mock_node_instance)

    def test_add_nodes_adds_search_node(self):
        """Ensure _add_nodes() invokes builder.add_node correctly."""
        self.agent.builder = MagicMock()
        self.agent.search_node.node.return_value = {"node": "value"}
        self.agent._add_nodes()
        self.agent._prepare_nodes()

        self.agent.builder.add_node.assert_called_once_with(
            self.agent.search_node.name,
            {"node": "value"}
        )

    def test_design_graph_creates_correct_edges(self):
        """Ensure start→search and search→end edges are added."""
        self.agent.builder = MagicMock()

        search_name = self.agent.search_node.name

        self.agent._design_graph()

        self.agent.builder.add_edge.assert_any_call(START, search_name)
        self.agent.builder.add_edge.assert_any_call(search_name, END)

        self.assertEqual(self.agent.builder.add_edge.call_count, 2)


if __name__ == "__main__":
    unittest.main()
