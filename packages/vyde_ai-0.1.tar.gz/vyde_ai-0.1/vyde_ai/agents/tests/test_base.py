__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from typing import Any, Dict
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, MessagesState, START
from langgraph.graph.state import CompiledStateGraph
import unittest
from unittest.mock import MagicMock

from vyde_ai.agents.base import BaseAgent
from vyde_ai.nodes.base import AbstractNode


class Node(AbstractNode):
    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        return {'response': 'sure'}

    def invoke(self, state) -> Dict[str, Any]:
        return {'res': 'yes'}


class ConcreteAgent(BaseAgent):
    """A valid subclass implementing abstract methods."""
    def _add_nodes(self):
        # Simulate adding nodes
        node = Node(
            name="node",
            run_type="abstract",
            agent_name="test_agent",
            project_name="test_project",
            disable_tracing=False
        )
        self.nodes.append(node)

    def _design_graph(self):
        # Simulate designing graph
        node_name = self.nodes[0].name
        self.builder.add_edge(START, node_name)
        self.builder.add_edge(node_name, END)


class PassThroughAgent(BaseAgent):
    """Subclass that delegates to BaseAgent methods for coverage."""
    def _add_nodes(self):
        return super()._add_nodes()

    def _design_graph(self):
        return super()._design_graph()


class MissingAddNodes(BaseAgent):
    """Subclass missing _add_nodes → should not be instantiable."""
    def _design_graph(self):
        pass


class MissingDesignGraph(BaseAgent):
    """Subclass missing _design_graph → should not be instantiable."""
    def _add_nodes(self):
        pass


class TestBaseAgent(unittest.TestCase):
    def test_base_add_nodes_and_design_graph_noops(self):
        agent = PassThroughAgent(MessagesState, "Agent", "Project")
        self.assertIsNone(agent._add_nodes())
        self.assertIsNone(agent._design_graph())

    def test_prepare_nodes_sets_attributes_and_adds_nodes_to_builder(self):
        agent = ConcreteAgent(MessagesState, "AgentA", "ProjectX", disable_tracing=True)

        mock_builder = MagicMock()
        agent.builder = mock_builder
        node = Node(
            name="node",
            run_type="abstract",
            agent_name="initial_agent",
            project_name="initial_project",
            disable_tracing=False
        )
        node.node = MagicMock(return_value="callable")
        agent.nodes = [node]

        agent._prepare_nodes()

        self.assertEqual(node.agent_name, "AgentA")
        self.assertEqual(node.project_name, "ProjectX")
        self.assertTrue(node.disable_tracing)
        mock_builder.add_node.assert_called_once_with(node.name, "callable")

    def test_missing_add_nodes_fails_instantiation(self):
        """Subclass missing _add_nodes must not instantiate."""
        with self.assertRaises(TypeError):
            MissingAddNodes(MessagesState, "agent", "proj")

    def test_missing_design_graph_fails_instantiation(self):
        """Subclass missing _design_graph must not instantiate."""
        with self.assertRaises(TypeError):
            MissingDesignGraph(MessagesState, "agent", "proj")

    def test_initialization_sets_attributes(self):
        agent = ConcreteAgent(MessagesState, "AgentA", "ProjectX", disable_tracing=True)

        self.assertEqual(agent.agent_name, "AgentA")
        self.assertEqual(agent.project_name, "ProjectX")
        self.assertTrue(agent.disable_tracing)
        self.assertIs(agent.builder.state_schema, MessagesState)

    def test_disable_tracing_default(self):
        agent = ConcreteAgent(MessagesState, "AgentB", "ProjectY")
        self.assertFalse(agent.disable_tracing)

    def test_graph_modifier_applied(self):
        graph_modifier = MagicMock()
        agent = ConcreteAgent(MessagesState, "AgentC", "ProjectZ", graph_modifier=graph_modifier)

        agent.graph(memory=MemorySaver())

        graph_modifier.assert_called_once_with(agent.builder)

    def test_graph_returns_compiledgraph(self):
        agent = ConcreteAgent(MessagesState, "AgentA", "ProjectX")

        result = agent.graph(memory=MemorySaver())
        self.assertIsInstance(result, CompiledStateGraph)

    def test_graph_is_built(self):
        agent = ConcreteAgent(MessagesState, "A", "P")
        agent.graph(memory=MemorySaver())

        self.assertTrue(agent.is_graph_built)

    def test_compile_called_with_checkpointer(self):
        agent = ConcreteAgent(MessagesState, "A", "P")
        memory = MemorySaver()
        compiled = agent.graph(memory=memory)

        self.assertIsInstance(compiled, CompiledStateGraph)

    def test_graph_with_null_memory_still_compiles(self):
        """If memory is None, compile should still be invoked."""
        agent = ConcreteAgent(int, "A", "P")
        compiled = agent.graph(None)
        self.assertIsInstance(compiled, CompiledStateGraph)

    def test_graph_called_multiple_times_still_valid(self):
        agent = ConcreteAgent(MessagesState, "A", "P")
        mem1 = MemorySaver()
        mem2 = MemorySaver()

        c1 = agent.graph(mem1)
        c2 = agent.graph(mem2)

        self.assertIsInstance(c1, CompiledStateGraph)
        self.assertIsInstance(c2, CompiledStateGraph)

    def test_invalid_agent_name(self):
        """Check edge case: non-string agent name."""
        agent = ConcreteAgent(MessagesState, 123, "P")
        self.assertEqual(agent.agent_name, 123)  # no type validation, so allowed

    def test_invalid_project_name(self):
        """Check edge case: non-string project name."""
        agent = ConcreteAgent(MessagesState, "A", 999)
        self.assertEqual(agent.project_name, 999)

    def test_disable_tracing_boolean_coercion(self):
        agent = ConcreteAgent(MessagesState, "A", "P", disable_tracing="yes")
        # No validation → should preserve given value
        self.assertEqual(agent.disable_tracing, "yes")


if __name__ == "__main__":
    unittest.main()
