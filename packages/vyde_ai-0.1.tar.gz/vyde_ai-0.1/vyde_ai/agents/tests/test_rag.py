__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from langgraph.graph import END, START
from typing import Any, Dict, List
import unittest
from unittest.mock import MagicMock, patch

from vyde_ai.agents.rag import RagAgent
from vyde_ai.nodes import ChainNode, GenerateQueriesNode


class DummyChainNode(ChainNode):
    def __init__(self, name: str = "semantic_search"):
        super().__init__(name=name, disable_tracing=True)

    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {"state": state}


class DummyGenerateQueriesNode(GenerateQueriesNode):
    def __init__(self, name: str = "generate_queries"):
        super().__init__(name=name, disable_tracing=True)
        self.composed_queries: List[Any] = []
        self.args_seen: List[Dict[str, Any]] = []

    def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
        self.args_seen.append(state)
        return {"prompt": "value"}

    def compose_queries(self, queries: List[Dict[str, Any]]) -> List[Any]:
        self.composed_queries = [item["q"] for item in queries]
        return self.composed_queries


class TestRagAgent(unittest.TestCase):
    def setUp(self):
        patcher = patch("vyde_ai.agents.base.StateGraph")
        self.addCleanup(patcher.stop)
        self.mock_state_graph_cls = patcher.start()
        self.mock_builder = MagicMock(name="StateGraphBuilder")
        self.mock_state_graph_cls.return_value = self.mock_builder

    def _build_agent(self, **kwargs):
        generator = kwargs.pop("generate_queries_node", DummyGenerateQueriesNode())
        semantic_chain = kwargs.pop("call_semantic_search_node", DummyChainNode())

        return RagAgent(
            state_cls=dict,
            project_name="project",
            generate_queries_node=generator,
            call_semantic_search_node=semantic_chain,
            **kwargs,
        )

    def test_initialization_assigns_fields_and_updates_generate_queries_node(self):
        generator = DummyGenerateQueriesNode()
        chain = DummyChainNode()
        agent = RagAgent(
            state_cls=dict,
            project_name="proj",
            generate_queries_node=generator,
            call_semantic_search_node=chain,
            iterable_query_field="current_query",
            iterable_chunk_field="current_chunk",
            chunks_field="doc_chunks",
            valid_chunks_field="usable_chunks",
            queries_field="query_bank",
            agent_name="qa_agent",
        )

        self.assertEqual(agent.iterable_query_field, "current_query")
        self.assertEqual(agent.iterable_chunk_field, "current_chunk")
        self.assertEqual(agent.chunk_field, "doc_chunks")
        self.assertEqual(agent.queries_field, "query_bank")
        self.assertEqual(agent.call_semantic_search_node, chain)

        self.assertEqual(agent.generate_queries_node.iterable_query_field, "current_query")
        self.assertEqual(agent.generate_queries_node.iterable_chunk_field, "current_chunk")
        self.assertEqual(agent.generate_queries_node.chunks_field, "doc_chunks")
        self.assertEqual(agent.generate_queries_node.valid_chunks_field, "usable_chunks")
        self.assertEqual(agent.generate_queries_node.queries_field, "query_bank")

    def test_generate_response_node_builds_context_and_wraps_response(self):
        agent = self._build_agent()

        class Chunk:
            def __init__(self, content: str):
                self.page_content = content

        chunks = [Chunk("first"), Chunk("second")]
        state = {"valid_chunks": chunks}

        invoke_args = agent.generate_response.build_invoke_args(state)
        self.assertEqual(invoke_args, {"context": "first\n\nsecond"})

        empty_args = agent.generate_response.build_invoke_args({"valid_chunks": []})
        self.assertEqual(empty_args, {"context": ""})

        response_payload = {"answer": "final"}
        post_result = agent.generate_response.post_invoke({}, response_payload)
        self.assertEqual(post_result, {"response": response_payload})

    def test_add_nodes_without_pre_run_graph_registers_all_runtime_nodes(self):
        agent = self._build_agent()
        agent._add_nodes()

        expected_order = [
            agent.call_semantic_search_node,
            agent.iterate_queries_node,
            agent.iterate_chunks_node,
            agent.evaluate_chunks_node,
            agent.generate_queries_node,
            agent.generate_response,
        ]
        self.assertEqual(agent.nodes, expected_order)
        self.mock_builder.add_node.assert_not_called()

    def test_add_nodes_with_pre_run_graph_registers_compiled_graph(self):
        pre_graph = MagicMock()
        pre_graph.compile.return_value = "compiled_pre_graph"
        agent = self._build_agent(pre_run_graph=pre_graph)

        agent._add_nodes()
        self.mock_builder.add_node.assert_called_once_with(
            f"{agent.agent_name}__call_pre_run_graph", "compiled_pre_graph"
        )

    def test_design_graph_without_pre_run_graph_wires_edges_and_conditionals(self):
        agent = self._build_agent()
        agent._add_nodes()
        agent._prepare_nodes()
        agent.builder.reset_mock()

        agent._design_graph()

        agent.builder.add_edge.assert_any_call(START, agent.generate_queries_node.name)
        agent.builder.add_edge.assert_any_call(agent.generate_queries_node.name, agent.iterate_queries_node.name)
        agent.builder.add_edge.assert_any_call(agent.call_semantic_search_node.name, agent.iterate_queries_node.name)
        agent.builder.add_edge.assert_any_call(agent.evaluate_chunks_node.name, agent.iterate_chunks_node.name)
        agent.builder.add_edge.assert_any_call(agent.generate_response.name, END)

        conditional_calls = agent.builder.add_conditional_edges.call_args_list
        query_call = next(call for call in conditional_calls if call.args[0] == agent.iterate_queries_node.name)
        chunk_call = next(call for call in conditional_calls if call.args[0] == agent.iterate_chunks_node.name)

        query_predicate = query_call.args[1]
        self.assertEqual(
            query_call.args[2],
            {
                "exit": agent.iterate_chunks_node.name,
                "loop": agent.call_semantic_search_node.name,
            },
        )
        loop_state = {agent.iterable_query_field: 0, agent.queries_field: ["q1", "q2"]}
        exit_state = {agent.iterable_query_field: 2, agent.queries_field: ["q1", "q2"]}
        self.assertEqual(query_predicate(loop_state), "loop")
        self.assertEqual(query_predicate(exit_state), "exit")

        chunk_predicate = chunk_call.args[1]
        self.assertEqual(
            chunk_call.args[2],
            {
                "exit": agent.generate_response.name,
                "loop": agent.evaluate_chunks_node.name,
            },
        )
        chunk_loop = {agent.iterable_chunk_field: 0, agent.chunk_field: ["c1"]}
        chunk_exit = {agent.iterable_chunk_field: 1, agent.chunk_field: ["c1"]}
        self.assertEqual(chunk_predicate(chunk_loop), "loop")
        self.assertEqual(chunk_predicate(chunk_exit), "exit")

    def test_design_graph_with_pre_run_graph_inserts_pre_run_edges(self):
        pre_graph = MagicMock()
        agent = self._build_agent(pre_run_graph=pre_graph)

        agent._add_nodes()
        agent._prepare_nodes()
        agent.builder.reset_mock()
        agent._design_graph()

        pre_node_name = f"{agent.agent_name}__call_pre_run_graph"
        agent.builder.add_edge.assert_any_call(START, pre_node_name)
        agent.builder.add_edge.assert_any_call(pre_node_name, agent.generate_queries_node.name)

    def test_conditional_lambdas_respect_custom_field_names(self):
        agent = self._build_agent(
            iterable_query_field="idx_query",
            iterable_chunk_field="idx_chunk",
            chunks_field="documents",
            queries_field="search_queries",
        )
        agent._add_nodes()
        agent._prepare_nodes()
        agent.builder.reset_mock()
        agent._design_graph()

        conditional_calls = agent.builder.add_conditional_edges.call_args_list
        query_call = next(call for call in conditional_calls if call.args[0] == agent.iterate_queries_node.name)
        chunk_call = next(call for call in conditional_calls if call.args[0] == agent.iterate_chunks_node.name)

        query_predicate = query_call.args[1]
        self.assertEqual(query_predicate({"idx_query": 0, "search_queries": [1]}), "loop")
        self.assertEqual(query_predicate({"idx_query": 1, "search_queries": [1]}), "exit")

        chunk_predicate = chunk_call.args[1]
        self.assertEqual(chunk_predicate({"idx_chunk": 0, "documents": ["c"]}), "loop")
        self.assertEqual(chunk_predicate({"idx_chunk": 1, "documents": ["c"]}), "exit")


if __name__ == "__main__":
    unittest.main()
