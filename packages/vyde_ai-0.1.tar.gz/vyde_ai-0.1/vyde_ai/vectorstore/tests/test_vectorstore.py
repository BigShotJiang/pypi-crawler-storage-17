__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from langchain_core.documents import Document
from langchain_community.embeddings import FakeEmbeddings
import unittest
from unittest.mock import MagicMock, patch

from vyde_ai.vectorstore import AbstractVectorStoreManager

OPENSEARCH_HOST = "db-opensearch-fra1-71378-do-user-17169954-0.g.db.ondigitalocean.com"
OPENSEARCH_PORT = 25060
OPENSEARCH_USERNAME = "doadmin"
OPENSEARCH_PASSWORD = "AVNS_6h1x75THeBxyTubzPFP"

EMPTY_INDEX = 'empty_index'
NOT_EXISTING_INDEX = 'not_existing_index'
TEST_INDEX = 'test_index'
TEST_INDEX_NO_EMBEDDINGS = 'test_index_no_embeddings'


class DummyVectorStoreManager(AbstractVectorStoreManager):
    def _check_api_key(self):
        return True


class TestAbstractVectorStoreManager(unittest.TestCase):
    def setUp(self):
        self.embedding_function = FakeEmbeddings(size=123)

    def _create_stub_manager(self):
        manager = DummyVectorStoreManager.__new__(DummyVectorStoreManager)
        manager.embedding_function = self.embedding_function
        manager.opensearch_host = "host"
        manager.opensearch_port = 1234
        manager.opensearch_username = "username"
        manager.opensearch_password = "password"
        manager.index_name = "test-index"
        manager.vectorstore = MagicMock()
        manager.empty_vectorstore = False
        return manager

    def test_base_check_api_key_noop(self):
        class ApiKeyChecker(AbstractVectorStoreManager):
            def __init__(self):
                pass

            def _check_api_key(self):
                return super()._check_api_key()

        manager = ApiKeyChecker()

        self.assertIsNone(manager._check_api_key())

    def test_init_not_existing_host(self):
        vsm = DummyVectorStoreManager(
            opensearch_host='not-existing',
            opensearch_port=8000,
            opensearch_username='username',
            opensearch_password='password',
            index_name=NOT_EXISTING_INDEX,
            embedding_function=self.embedding_function
        )
        self.assertIsNone(vsm.vectorstore)

    def test_init_not_existing_index(self):
        # Expect vsm not initialized
        vsm = DummyVectorStoreManager(
            opensearch_host=OPENSEARCH_HOST,
            opensearch_port=OPENSEARCH_PORT,
            opensearch_username=OPENSEARCH_USERNAME,
            opensearch_password=OPENSEARCH_PASSWORD,
            index_name=NOT_EXISTING_INDEX,
            embedding_function=self.embedding_function
        )

        self.assertIsNotNone(vsm.vectorstore)

    def test_init_empty_vectorstore(self):
        # Expect vsm initialized
        vsm = DummyVectorStoreManager(
            opensearch_host=OPENSEARCH_HOST,
            opensearch_port=OPENSEARCH_PORT,
            opensearch_username=OPENSEARCH_USERNAME,
            opensearch_password=OPENSEARCH_PASSWORD,
            index_name=EMPTY_INDEX,
            embedding_function=self.embedding_function
        )
        self.assertIsNotNone(vsm.vectorstore)

    def test_init_populated_vectorstore(self):
        # Expect vsm initialized
        vsm = DummyVectorStoreManager(
            opensearch_host=OPENSEARCH_HOST,
            opensearch_port=OPENSEARCH_PORT,
            opensearch_username=OPENSEARCH_USERNAME,
            opensearch_password=OPENSEARCH_PASSWORD,
            index_name=TEST_INDEX,
            embedding_function=self.embedding_function
        )

        all_stored_docs = vsm.vectorstore.similarity_search("", k=100)
        self.assertEqual(len(all_stored_docs), 1)

    def test_update_vectorstore_with_new_docs(self):
        # Expect vsm initialized
        vsm = DummyVectorStoreManager(
            opensearch_host=OPENSEARCH_HOST,
            opensearch_port=OPENSEARCH_PORT,
            opensearch_username=OPENSEARCH_USERNAME,
            opensearch_password=OPENSEARCH_PASSWORD,
            index_name=TEST_INDEX,
            embedding_function=self.embedding_function
        )

        documents = [
            Document(
                page_content="I had chocolate chip pancakes and scrambled eggs for breakfast this morning.",
                metadata={"document_id": "doc_1", "root_code": "100"}
            ),
            Document(
                page_content="The weather forecast for tomorrow is cloudy and overcast, with a high of 62 degrees.",
                metadata={"document_id": "doc_2", "root_code": "200"}
            ),
            Document(
                page_content="Building an exciting new project with LangChain - come check it out!",
                metadata={"document_id": "doc_3", "root_code": "300"})
        ]

        vsm.add_documents(documents)

        results = vsm.vectorstore.similarity_search(
            query="",
            search_type="script_scoring",
            pre_filter={"bool": {"must": {"terms": {"metadata.root_code.keyword": ["100", "200", "300"]}}}},
            k=100
        )
        vsm.delete_documents_from_root_code(["100", "200", "300"])

        self.assertEqual(len(results), 3)

    def test_update_vectorstore_with_existing_docs(self):
        # Expect vsm initialized
        vsm = DummyVectorStoreManager(
            opensearch_host=OPENSEARCH_HOST,
            opensearch_port=OPENSEARCH_PORT,
            opensearch_username=OPENSEARCH_USERNAME,
            opensearch_password=OPENSEARCH_PASSWORD,
            index_name=TEST_INDEX,
            embedding_function=self.embedding_function
        )

        documents_1 = [
            Document(
                page_content="I had chocolate chip pancakes and scrambled eggs for breakfast this morning.",
                metadata={"document_id": "doc_1", "root_code": "100"}
            ),
            Document(
                page_content="The weather forecast for tomorrow is cloudy and overcast, with a high of 62 degrees.",
                metadata={"document_id": "doc_2", "source": "news", "root_code": "200"}
            ),
            Document(
                page_content="Building an exciting new project with LangChain - come check it out!",
                metadata={"document_id": "doc_3", "source": "tweet", "root_code": "300"})
        ]

        vsm.add_documents(documents_1)

        documents_2 = [
            Document(
                page_content="I have a bad feeling I am going to get deleted :(",
                metadata={"document_id": "doc_1", "root_code": "100"}
            ),
            Document(
                page_content="The stock market is down 500 points today due to fears of a recession.",
                metadata={"document_id": "doc_4", "root_code": "150"}
            ),
            Document(
                page_content="LangGraph is the best framework for building stateful, agentic applications!",
                metadata={"document_id": "doc_3", "root_code": "300"})
        ]

        vsm.add_documents(documents_2)

        results_100 = vsm.vectorstore.similarity_search(
            query="",
            search_type="script_scoring",
            pre_filter={"bool": {"must": {"terms": {"metadata.root_code.keyword": ["100"]}}}},
            k=100
        )
        results_150 = vsm.vectorstore.similarity_search(
            query="",
            search_type="script_scoring",
            pre_filter={"bool": {"must": {"terms": {"metadata.root_code.keyword": ["150"]}}}},
            k=100
        )
        results_200 = vsm.vectorstore.similarity_search(
            query="",
            search_type="script_scoring",
            pre_filter={"bool": {"must": {"terms": {"metadata.root_code.keyword": ["200"]}}}},
            k=100
        )
        results_300 = vsm.vectorstore.similarity_search(
            query="",
            search_type="script_scoring",
            pre_filter={"bool": {"must": {"terms": {"metadata.root_code.keyword": ["300"]}}}},
            k=100
        )

        vsm.delete_documents_from_root_code(["100", "150", "200", "300"])

        self.assertEqual(len(results_100), 1)
        self.assertEqual(results_100[0].page_content,
                         "I have a bad feeling I am going to get deleted :(")

        self.assertEqual(len(results_150), 1)
        self.assertEqual(results_150[0].page_content,
                         "The stock market is down 500 points today due to fears of a recession.")

        self.assertEqual(len(results_200), 1)
        self.assertEqual(results_200[0].page_content,
                         "The weather forecast for tomorrow is cloudy and overcast, with a high of 62 degrees.")

        self.assertEqual(len(results_300), 1)
        self.assertEqual(results_300[0].page_content,
                         "LangGraph is the best framework for building stateful, agentic applications!")

    def test_add_documents_returns_false_when_vectorstore_add_fails(self):
        manager = self._create_stub_manager()
        manager.vectorstore.add_documents.side_effect = RuntimeError("boom")
        documents = [
            Document(
                page_content="content",
                metadata={"document_id": "doc_1", "root_code": "100"}
            )
        ]

        with patch('vyde_ai.vectorstore.vectorstore.logger') as mock_logger:
            result = manager.add_documents(documents, batch_size=1)

        self.assertFalse(result)
        self.assertTrue(
            any("Failed updating the vectorstore" in call.args[0] for call in mock_logger.error.call_args_list)
        )

    def test_delete_documents_from_document_ids_logs_when_not_initialized(self):
        manager = self._create_stub_manager()

        mock_dbm = MagicMock()
        mock_dbm.connect.return_value = True
        mock_dbm.is_initialized.return_value = False

        with patch('vyde_ai.vectorstore.vectorstore.DatabaseManager', return_value=mock_dbm):
            with patch('vyde_ai.vectorstore.vectorstore.logger') as mock_logger:
                result = manager.delete_documents_from_document_ids(["doc_1"])

        self.assertTrue(result)
        mock_logger.error.assert_any_call("Database not initialized")

    def test_delete_documents_from_document_ids_logs_when_not_connected(self):
        manager = self._create_stub_manager()

        mock_dbm = MagicMock()
        mock_dbm.connect.return_value = False

        with patch('vyde_ai.vectorstore.vectorstore.DatabaseManager', return_value=mock_dbm):
            with patch('vyde_ai.vectorstore.vectorstore.logger') as mock_logger:
                result = manager.delete_documents_from_document_ids(["doc_1"])

        self.assertTrue(result)
        mock_logger.error.assert_any_call("Database not connected")

    def test_delete_documents_from_document_ids_handles_exceptions(self):
        manager = self._create_stub_manager()

        with patch('vyde_ai.vectorstore.vectorstore.DatabaseManager', side_effect=RuntimeError("boom")):
            with patch('vyde_ai.vectorstore.vectorstore.logger') as mock_logger:
                result = manager.delete_documents_from_document_ids(["doc_1"])

        self.assertFalse(result)
        self.assertTrue(
            any("Failed deleting the documents" in call.args[0] for call in mock_logger.error.call_args_list)
        )

    def test_delete_documents_from_root_code_logs_when_not_initialized(self):
        manager = self._create_stub_manager()

        mock_dbm = MagicMock()
        mock_dbm.connect.return_value = True
        mock_dbm.is_initialized.return_value = False

        with patch('vyde_ai.vectorstore.vectorstore.DatabaseManager', return_value=mock_dbm):
            with patch('vyde_ai.vectorstore.vectorstore.logger') as mock_logger:
                result = manager.delete_documents_from_root_code(["100"])

        self.assertTrue(result)
        mock_logger.error.assert_any_call("Database not initialized")

    def test_delete_documents_from_root_code_logs_when_not_connected(self):
        manager = self._create_stub_manager()

        mock_dbm = MagicMock()
        mock_dbm.connect.return_value = False

        with patch('vyde_ai.vectorstore.vectorstore.DatabaseManager', return_value=mock_dbm):
            with patch('vyde_ai.vectorstore.vectorstore.logger') as mock_logger:
                result = manager.delete_documents_from_root_code(["100"])

        self.assertTrue(result)
        mock_logger.error.assert_any_call("Database not connected")

    def test_delete_documents_from_root_code_handles_exceptions(self):
        manager = self._create_stub_manager()

        with patch('vyde_ai.vectorstore.vectorstore.DatabaseManager', side_effect=RuntimeError("boom")):
            with patch('vyde_ai.vectorstore.vectorstore.logger') as mock_logger:
                result = manager.delete_documents_from_root_code(["100"])

        self.assertFalse(result)
        self.assertTrue(
            any("Failed deleting the documents" in call.args[0] for call in mock_logger.error.call_args_list)
        )

if __name__ == "__main__":
    unittest.main()
