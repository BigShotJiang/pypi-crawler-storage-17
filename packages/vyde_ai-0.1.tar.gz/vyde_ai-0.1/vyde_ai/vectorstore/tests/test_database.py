__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from pydantic import SecretStr
import unittest
from unittest.mock import MagicMock, patch

from vyde_ai.vectorstore.database import DatabaseManager


EMPTY_INDEX = 'empty_index'
NOT_EXISTING_INDEX = 'not_existing_index'
TEST_INDEX = 'test_index'

OPENSEARCH_HOST = "db-opensearch-fra1-71378-do-user-17169954-0.g.db.ondigitalocean.com"
OPENSEARCH_PORT = 25060
OPENSEARCH_USERNAME = "doadmin"
OPENSEARCH_PASSWORD = SecretStr("AVNS_6h1x75THeBxyTubzPFP")


class TestDatabase(unittest.TestCase):
    def test_not_existing_host(self):
        # Expect database not connected
        opensearch_host = 'not-existing'
        opensearch_port = 8000

        dbm = DatabaseManager(host=opensearch_host, port=opensearch_port)
        connected = dbm.connect()

        self.assertFalse(connected)

    def test_existing_database(self):
        # Expect database connected
        dbm = DatabaseManager(
            host=OPENSEARCH_HOST,
            port=OPENSEARCH_PORT,
            username=OPENSEARCH_USERNAME,
            password=OPENSEARCH_PASSWORD.get_secret_value()
        )
        connected = dbm.connect()

        self.assertTrue(connected)

    def test_index_not_existing(self):
        # Expect index not existing
        dbm = DatabaseManager(
            host=OPENSEARCH_HOST,
            port=OPENSEARCH_PORT,
            username=OPENSEARCH_USERNAME,
            password=OPENSEARCH_PASSWORD.get_secret_value()
        )
        dbm.connect()
        is_initialized = dbm.is_initialized(index_name=NOT_EXISTING_INDEX)

        self.assertFalse(is_initialized)

    def test_index_empty(self):
        # Expect index not initialized
        dbm = DatabaseManager(
            host=OPENSEARCH_HOST,
            port=OPENSEARCH_PORT,
            username=OPENSEARCH_USERNAME,
            password=OPENSEARCH_PASSWORD.get_secret_value()
        )
        dbm.connect()
        is_initialized = dbm.is_initialized(index_name=EMPTY_INDEX)

        self.assertFalse(is_initialized)

    def test_index_existing(self):
        # Expect index initialized
        dbm = DatabaseManager(
            host=OPENSEARCH_HOST,
            port=OPENSEARCH_PORT,
            username=OPENSEARCH_USERNAME,
            password=OPENSEARCH_PASSWORD.get_secret_value()
        )
        dbm.connect()
        is_initialized = dbm.is_initialized(index_name=TEST_INDEX)

        self.assertTrue(is_initialized)


    def test_check_init_on_not_existing_host(self):
        # Expect database not initialized
        opensearch_host = 'not-existing'
        opensearch_port = 8000

        dbm = DatabaseManager(host=opensearch_host, port=opensearch_port)
        dbm.connect()

        is_initialized = dbm.is_initialized(index_name=NOT_EXISTING_INDEX)

        self.assertFalse(is_initialized)


    def test_check_init_on_not_connected_database(self):
        # Expect database not initialized
        dbm = DatabaseManager(
            host=OPENSEARCH_HOST,
            port=OPENSEARCH_PORT,
            username=OPENSEARCH_USERNAME,
            password=OPENSEARCH_PASSWORD.get_secret_value()
        )

        is_initialized = dbm.is_initialized(index_name=NOT_EXISTING_INDEX)

        self.assertFalse(is_initialized)

    def test_is_initialized_exception_on_exists(self):
        dbm = DatabaseManager(
            host=OPENSEARCH_HOST,
            port=OPENSEARCH_PORT,
            username=OPENSEARCH_USERNAME,
            password=OPENSEARCH_PASSWORD.get_secret_value()
        )
        dbm.connect()
        dbm.client = MagicMock()

        dbm.client.indices.exists.side_effect = Exception("test error")

        result = dbm.is_initialized(index_name=NOT_EXISTING_INDEX)

        self.assertFalse(result)


if __name__ == "__main__":
    unittest.main()
