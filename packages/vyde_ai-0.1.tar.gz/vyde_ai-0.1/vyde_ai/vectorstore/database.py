__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

import logging
from opensearchpy import OpenSearch
from pydantic import SecretStr


logger = logging.getLogger(__name__)


class DatabaseManager:
    def __init__(self, host: str, port: int, username: str = None, password: str | SecretStr = None):
        """
        Initializes the connection to a remote ChromaDB server.
        """
        self.host = host
        self.port = port
        self.username = username
        self.password = password.get_secret_value() if isinstance(password, SecretStr) else password

        self.client = None
        self.db = None

    def connect(self) -> bool:
        """
        Connect to the OpenSearch server.

        Returns:
            bool: True if the connection is successful, False otherwise.
        """
        logger.info(f"Connecting to OpenSearch at {self.host}:{self.port}.")

        try:
            self.client = OpenSearch(
                hosts=[{"host": self.host, "port": self.port}],
                http_auth=(self.username, self.password) if self.username and self.password else None,
                use_ssl=True,
                verify_certs=False,
                ssl_show_warn=False,
            )

            # Check if the connection is successful
            info = self.client.info()
            logger.info(f"Successfully connected to OpenSearch: {info}")

        except Exception as e:
            logger.error(f"Failed to connect to OpenSearch: {e}")
            self.client = None
            return False

        return True


    def is_initialized(self, index_name: str) -> bool:
        """
        Check if an OpenSearch index exists and contains data.

        Args:
            index_name (str): Name of the index.

        Returns:
            bool: True if the index exists and has documents, False otherwise.
        """
        if self.client is None:
            logger.error("OpenSearch client is not connected.")
            return False

        try:
            # Check if the index exists
            if not self.client.indices.exists(index=index_name):
                logger.error(f"Index '{index_name}' does not exist.")
                return False

            # Check if the index has any documents
            count = self.client.count(index=index_name)["count"]
            if count == 0:
                logger.error("Index exists but is empty.")
                return False

            return True

        except Exception as e:
            logger.error(f"Error checking index: {e}")
            return False
