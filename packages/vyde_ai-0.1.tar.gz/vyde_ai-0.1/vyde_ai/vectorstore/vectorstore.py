__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from abc import ABC, abstractmethod
from langchain_community.vectorstores import OpenSearchVectorSearch
from langchain_core.documents import Document
from langchain.embeddings.base import Embeddings
import logging
from opensearchpy.connection import RequestsHttpConnection
from tqdm import tqdm
from typing import List, Optional

from vyde_ai.vectorstore.database import DatabaseManager


logger = logging.getLogger(__name__)


def chunked_iterable(iterable, size):
    for i in range(0, len(iterable), size):
        yield iterable[i:i + size]


class AbstractVectorStoreManager(ABC):
    """
    A simple manager class that wraps a OpenSearchIndex vector store using OpenAI Embeddings.
    """
    def __init__(
            self,
            index_name: str,
            embedding_function: Embeddings,
            opensearch_host: str | None = None,
            opensearch_port: int | None = None,
            opensearch_username: str | None = None,
            opensearch_password: str | None = None
    ):

        if self._check_api_key():
            self.embedding_function = embedding_function

        self.opensearch_host = opensearch_host
        self.opensearch_port = opensearch_port
        self.opensearch_username = opensearch_username
        self.opensearch_password = opensearch_password
        self.index_name = index_name
        self.empty_vectorstore = True
        self.vectorstore: Optional[OpenSearchVectorSearch] = self._maybe_load_vectorstore()

    @abstractmethod
    def _check_api_key(self):
        pass

    def _maybe_load_vectorstore(self) -> Optional[OpenSearchVectorSearch]:
        dbm = DatabaseManager(
            host=self.opensearch_host,
            port=self.opensearch_port,
            username=self.opensearch_username,
            password=self.opensearch_password
        )
        if dbm.connect():
            # Can connect to database. Check if empty.
            if dbm.is_initialized(self.index_name):
                self.empty_vectorstore = False

            return OpenSearchVectorSearch(index_name=self.index_name,
                                          embedding_function=self.embedding_function,
                                          opensearch_url=f"https://{dbm.host}:{dbm.port}",
                                          http_auth=(dbm.username, dbm.password),
                                          timeout=360,
                                          connection_class=RequestsHttpConnection,
                                          use_ssl=True,
                                          verify_certs=True,
                                          max_retries=30,
                                          retry_on_timeout=True,
                                          pool_maxsize=50)
        else:
            # Can connect to database
            logger.error("Can't connect to opensearch")

        return None

    def add_documents(self, documents: List[Document], batch_size: int = 100) -> bool:
        """
        Initialize the vector store with the given documents.
        """
        try:
            if not self.empty_vectorstore:
                logger.info("Removing documents with same document_id")
                unique_document_id = list({doc.metadata["document_id"] for doc in documents})

                num_batches = len(unique_document_id) // batch_size
                for codes in tqdm(chunked_iterable(unique_document_id, batch_size), total=num_batches):
                    self.delete_documents_from_document_ids(codes)

            logger.info("Adding documents")
            num_batches = len(documents) // batch_size
            for batch in tqdm(chunked_iterable(documents, batch_size), total=num_batches):
                self.vectorstore.add_documents(documents=batch, space_type="cosinesimil")
            self.empty_vectorstore = False

        except Exception as e:
            logger.error(f"Failed updating the vectorstore. Exception: {e}")

            return False

        return True

    def delete_documents_from_document_ids(self, unique_ids: List[str]) -> bool:
        try:
            logger.info("Deleting documents with given unique_ids")

            dbm = DatabaseManager(host=self.opensearch_host,
                                  port=self.opensearch_port,
                                  username=self.opensearch_username,
                                  password=self.opensearch_password)
            if dbm.connect():
                # Can connect to database. Check if empty.
                if dbm.is_initialized(self.index_name):
                    delete_query = {
                        "query": {
                            "bool": {
                                "must": {
                                    "terms": {"metadata.document_id.keyword": unique_ids}
                                }
                            }
                        }
                    }

                    dbm.client.delete_by_query(index=self.index_name, body=delete_query)
                else:
                    logger.error("Database not initialized")
            else:
                logger.error("Database not connected")

        except Exception as e:
            logger.error(f"Failed deleting the documents. Exception: {e}")

            return False

        return True

    def delete_documents_from_root_code(self, root_codes: List[str]) -> bool:
        try:
            logger.info("Deleting documents with given root_code")

            dbm = DatabaseManager(host=self.opensearch_host,
                                  port=self.opensearch_port,
                                  username=self.opensearch_username,
                                  password=self.opensearch_password)
            if dbm.connect():
                # Can connect to database. Check if empty.
                if dbm.is_initialized(self.index_name):
                    delete_query = {
                        "query": {
                            "bool": {
                                "must": {
                                    "terms": {"metadata.root_code.keyword": root_codes}
                                }
                            }
                        }
                    }

                    dbm.client.delete_by_query(index=self.index_name, body=delete_query)
                else:
                    logger.error("Database not initialized")
            else:
                logger.error("Database not connected")

        except Exception as e:
            logger.error(f"Failed deleting the documents. Exception: {e}")

            return False

        return True
