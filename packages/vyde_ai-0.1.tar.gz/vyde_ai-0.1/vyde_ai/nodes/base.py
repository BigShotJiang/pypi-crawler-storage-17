__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from abc import ABC, abstractmethod
from langchain_core.rate_limiters import InMemoryRateLimiter
from langsmith import Client, traceable
import logging
from typing import Any, Dict, Optional, Tuple

from vyde_ai.nodes.types import *
from vyde_ai.utils import convert_messages_to_conversation


logger = logging.getLogger(__name__)

LLM_ERROR_TOKENS_PER_MINUTE = "tokens_per_minute_exceeded"
LLM_ERROR_TOKENS_PER_REQUEST = "tokens_per_request_exceeded"
LLM_ERROR_REQUESTS_PER_MINUTE = "requests_per_minute_exceeded"
LLM_ERROR_GENERIC = "generic_error"

DEFAULT_RATE_LIMITER: Optional[InMemoryRateLimiter] = None


class LLMInvocationError(RuntimeError):
    def __init__(self, kind: str, message: str, original_error: Exception):
        super().__init__(message)
        self.kind = kind
        self.original_error = original_error


class AbstractNode(ABC):
    def __init__(
            self,
            name: str,
            run_type: RUN_TYPES,
            agent_name: str,
            project_name: str,
            disable_tracing: bool
    ):
        self.agent_name = agent_name
        self.disable_tracing = disable_tracing
        self._raw_name = name
        self.project_name = project_name
        self.run_type = run_type

    @property
    def name(self):
        return f"{self.agent_name}__{self._raw_name}"

    @abstractmethod
    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        pass

    @abstractmethod
    def invoke(self, state) -> Dict[str, Any]:
        pass

    def _node(self, state: Dict[str, Any]):
        logger.debug("Enter node")

        updates = {}
        if self.disable_tracing:
            updates["log"] = [f"call node {self.name}"]

        if state.get("error"):
            logger.warning("Skipping node %s because error flag is set", self.name)
            updates["error"] = True
            logger.debug("Exit node")
            return updates

        try:
            response = self.invoke(state)
            updates.update(self.post_invoke(state, response))
        except Exception:
            logger.exception("Error while executing node %s", self.name)
            updates["error"] = True
            logger.debug("Exit node")
            return updates

        logger.debug("Exit node")
        return updates

    def node(self):
        if not self.disable_tracing:
            @traceable(
                run_type=self.run_type,
                name=self.name,
                project_name=self.project_name,
                metadata={"agent": self.agent_name},
            )
            def nodo_with_tracing(state):
                return self._node(state)

            return nodo_with_tracing
        else:
            return self._node


class ChainNode(AbstractNode):
    def __init__(
            self,
            name: str,
            agent_name: Optional[str] = None,
            project_name: Optional[str] = None,
            disable_tracing: bool = False
    ):
        super().__init__(
            name=name,
            run_type=CHAIN,
            agent_name=agent_name,
            project_name=project_name,
            disable_tracing=disable_tracing
        )

    @abstractmethod
    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        pass

    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        return response


class LLMNode(AbstractNode):
    def __init__(
            self,
            name: str,
            agent_name: Optional[str] = None,
            project_name: Optional[str] = None,
            disable_tracing: bool = False,
            include_conversation: bool = True,
            rate_limiter: Optional[InMemoryRateLimiter] = None,
    ):
        super().__init__(
            name=name,
            run_type=LLM,
            agent_name=agent_name,
            project_name=project_name,
            disable_tracing=disable_tracing
        )

        self.include_conversation = include_conversation
        self.rate_limiter = rate_limiter

    @abstractmethod
    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        pass

    @abstractmethod
    def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
        pass

    @staticmethod
    def _classify_llm_error(exc: Exception) -> Tuple[str, str]:
        message = str(exc) or exc.__class__.__name__
        lower_message = message.lower()

        if "tokens per minute" in lower_message or "token per minute" in lower_message or "tpm" in lower_message:
            return LLM_ERROR_TOKENS_PER_MINUTE, message

        if ("tokens per request" in lower_message or "token per request" in lower_message or "tpr" in lower_message
                or "maximum context length" in lower_message):
            return LLM_ERROR_TOKENS_PER_REQUEST, message

        if "requests per minute" in lower_message or "request per minute" in lower_message or "rpm" in lower_message:
            return LLM_ERROR_REQUESTS_PER_MINUTE, message

        return LLM_ERROR_GENERIC, message

    def invoke(self, state: Dict[str, Any]):
        client = Client()
        chain = client.pull_prompt(self.name, include_model=True)

        invoke_args = self.build_invoke_args(state)
        if self.include_conversation:
            invoke_args["conversation"] = convert_messages_to_conversation(state["messages"])

        limiter = self.rate_limiter or DEFAULT_RATE_LIMITER
        if limiter is not None:
            limiter.acquire()

        try:
            return chain.invoke(invoke_args)
        except Exception as exc:
            error_kind, error_message = self._classify_llm_error(exc)
            logger.error("Error invoking LLM chain %s (%s): %s", self.name, error_kind, error_message)
            raise LLMInvocationError(error_kind, error_message, exc) from exc


class RetrieverNode(AbstractNode):
    def __init__(
            self,
            name: str,
            agent_name: Optional[str] = None,
            project_name: Optional[str] = None,
            disable_tracing: bool = False
    ):
        super().__init__(
            name=name,
            run_type=RETRIEVER,
            agent_name=agent_name,
            project_name=project_name,
            disable_tracing=disable_tracing
        )

    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        return response

    @abstractmethod
    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        pass


class ToolNode(AbstractNode):
    def __init__(
            self,
            name: str,
            agent_name: Optional[str] = None,
            project_name: Optional[str] = None,
            disable_tracing: bool = False
    ):
        super().__init__(
            name=name,
            run_type=TOOL,
            agent_name=agent_name,
            project_name=project_name,
            disable_tracing=disable_tracing
        )

    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        return response

    @abstractmethod
    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        pass
