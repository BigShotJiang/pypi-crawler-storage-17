__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from abc import abstractmethod
from langsmith import Client
from typing import Any, Dict

from vyde_ai.nodes.base import LLMNode


class RoutingNode(LLMNode):
    @abstractmethod
    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        pass

    @abstractmethod
    def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
        pass

    def invoke(self, state: Dict[str, Any]):
        client = Client()
        chain = client.pull_prompt(self.name, include_model=True)

        invoke_args = self.build_invoke_args(state)
        invoke_args["user"] = state["messages"][-1]
        return chain.invoke(invoke_args)
