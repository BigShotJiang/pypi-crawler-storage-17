__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from typing import Any, Dict, Optional

from vyde_ai.nodes.base import ToolNode


class IterateNode(ToolNode):
    def __init__(
            self,
            name: str,
            iterable_field: str,
            agent_name: Optional[str] = None,
            project_name: Optional[str] = None,
            disable_tracing: bool = True,
    ):
        self.iterable_field = iterable_field

        super().__init__(
            name=name,
            agent_name=agent_name,
            project_name=project_name,
            disable_tracing=disable_tracing
        )

    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {self.iterable_field: state[self.iterable_field]+1}
