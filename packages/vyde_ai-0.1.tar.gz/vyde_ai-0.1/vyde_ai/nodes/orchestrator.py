__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from typing import Any, Dict, Optional

from vyde_ai.nodes.base import ToolNode


class OrchestratorNode(ToolNode):
    def __init__(
            self,
            name: str,
            agent_name: Optional[str] = None,
            project_name: Optional[str] = None,
            disable_tracing: bool = True,
            consumable_actions: str = 'consumable_actions',
            next_action: str = 'next_action'
    ):
        self.consumable_actions = consumable_actions
        self.next_action = next_action

        super().__init__(
            name=name,
            agent_name=agent_name,
            project_name=project_name,
            disable_tracing=disable_tracing
        )

    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        consumable_actions = state.get(self.consumable_actions, [])

        if len(consumable_actions) == 0:
            return {self.next_action: 'END'}

        return {self.next_action: state[self.consumable_actions].pop(0)}
