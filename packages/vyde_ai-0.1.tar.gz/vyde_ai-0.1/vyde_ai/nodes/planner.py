__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from langgraph.types import Overwrite
from typing import Any, Dict, Optional

from vyde_ai.nodes.base import LLMNode


class PlannerNode(LLMNode):
    def __init__(
            self,
            name: str,
            agent_name: Optional[str] = None,
            project_name: Optional[str] = None,
            disable_tracing: bool = True,
            actions: str = 'actions',
            consumable_actions: str = 'consumable_actions',
            context: str = 'context',
            fallback_action: str = 'Fallback and clarification',
    ):
        self.actions = actions
        self.consumable_actions = consumable_actions
        self.context = context
        self.fallback_action = fallback_action

        super().__init__(
            name=name,
            agent_name=agent_name,
            project_name=project_name,
            disable_tracing=disable_tracing,
            include_conversation=False
        )

    def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {"user": state["messages"][-1].content}

    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        actions = state.get(self.actions, [])

        if response["last_message_informative"] is False:
            if len(actions) > 0:
                consumable_actions = actions
            else:
                consumable_actions = [self.fallback_action]
        else:
            intents = response.get("intents", [])

            if len(intents) > 0:
                if len(intents) == 1:
                    if intents[0]['confidence'] >= 0.6:
                        consumable_actions = [intents[0]['intent']]
                    else:
                        consumable_actions = [self.fallback_action]
                else:
                    consumable_actions = [i['intent'] for i in intents if i['confidence'] >= 0.6]

                    if len(consumable_actions) == 0:
                        consumable_actions = [self.fallback_action]
            else:
                consumable_actions = [self.fallback_action]

        return {
            self.consumable_actions: consumable_actions.copy(),
            self.actions: consumable_actions.copy(),
            self.context: Overwrite([])
        }
