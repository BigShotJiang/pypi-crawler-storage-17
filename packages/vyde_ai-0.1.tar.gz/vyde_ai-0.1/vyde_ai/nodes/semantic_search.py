__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from langchain.embeddings import Embeddings
from typing import Any, Dict, Optional, Type, TypeVar

from vyde_ai.nodes.base import RetrieverNode
from vyde_ai.vectorstore import AbstractVectorStoreManager


class SemanticSearchNode(RetrieverNode):
    def __init__(
            self,
            name: str,
            embedding_function: Embeddings,
            vectorstore_class: Type[AbstractVectorStoreManager],
            index_field: str = "index",
            query_field: str = "query",
            agent_name: Optional[str] = None,
            project_name: Optional[str] = None,
            disable_tracing: bool = False,
    ):
        super().__init__(name=name, agent_name=agent_name, project_name=project_name, disable_tracing=disable_tracing)
        self.vectorstore_class = vectorstore_class
        self.index_field = index_field
        self.embedding_function = embedding_function
        self.query_field = query_field

    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        vsm = self.vectorstore_class(embedding_function=self.embedding_function, index_name=state[self.index_field])

        vectorstore = vsm.vectorstore
        query_vector = vsm.vectorstore.embeddings.embed_query(state[self.query_field])

        filters_must = state.get('filters_must', {})
        filters_must_not = state.get('filters_must_not', {})

        search_filter = {}
        terms_must = [{"terms": {f"metadata.{key}.keyword": val}} for key, val in filters_must.items()]
        terms_must_not = [{"terms": {f"metadata.{key}.keyword": val}} for key, val in filters_must_not.items()]

        if len(terms_must) > 0:
            search_filter['must'] = terms_must if len(terms_must) > 1 else terms_must[0]

        if len(terms_must_not) > 0:
            search_filter['must_not'] = terms_must_not if len(terms_must_not) > 1 else terms_must_not[0]

        k = state.get('k', 10)
        score_threshold = state.get('score_threshold', 1.20)

        if search_filter:
            chunks = vectorstore.similarity_search_by_vector(
                query_vector,
                k=k,
                search_type="script_scoring",
                space_type="cosinesimil",
                score_threshold=score_threshold,
                pre_filter={"bool": search_filter}
            )

        else:
            chunks = vectorstore.similarity_search_by_vector(
                query_vector,
                k=k,
                search_type="script_scoring",
                space_type="cosinesimil",
                score_threshold=score_threshold,
            )

        return {'chunks': chunks}
