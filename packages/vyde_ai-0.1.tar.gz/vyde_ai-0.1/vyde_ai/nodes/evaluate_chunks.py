__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from typing import Any, Dict, Optional

from vyde_ai.nodes.base import LLMNode


class EvaluateChunksNode(LLMNode):
    def __init__(
            self,
            name: str,
            iterable_field: str = 'idx_current_chunk',
            chunks_field: str = 'chunks',
            valid_chunks_field: str = 'valid_chunks',
            agent_name: Optional[str] = None,
            project_name: Optional[str] = None,
            disable_tracing: bool = True,
    ):
        self.iterable_field = iterable_field
        self.chunks_field = chunks_field
        self.valid_chunks_field = valid_chunks_field

        super().__init__(
            name=name,
            agent_name=agent_name,
            project_name=project_name,
            disable_tracing=disable_tracing
        )

    def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
        doc = state[self.chunks_field][state[self.iterable_field]]
        return {"document": doc.page_content}


    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        if response['valid']:
            return {self.valid_chunks_field: [state[self.chunks_field][state[self.iterable_field]]]}

        return {}
