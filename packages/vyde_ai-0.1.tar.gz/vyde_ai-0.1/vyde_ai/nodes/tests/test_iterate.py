__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

import unittest

from vyde_ai.nodes.iterate import IterateNode


class TestIterateNode(unittest.TestCase):
    def test_initialization_sets_field_and_defaults(self):
        node = IterateNode(name="iterate_queries", iterable_field="idx_current_query")

        self.assertEqual(node.iterable_field, "idx_current_query")
        self.assertTrue(node.disable_tracing)

    def test_invoke_increments_counter_and_returns_new_value(self):
        node = IterateNode(name="iterate", iterable_field="cursor")
        state = {"cursor": 4, "other": "value"}

        result = node.invoke(state)

        self.assertEqual(result, {"cursor": 5})
        self.assertNotIn("other", result)

    def test_invoke_handles_negative_indices(self):
        node = IterateNode(name="iterate", iterable_field="pointer")
        state = {"pointer": -1}

        self.assertEqual(node.invoke(state), {"pointer": 0})

    def test_missing_iterable_field_raises_key_error(self):
        node = IterateNode(name="iterate", iterable_field="missing_field")

        with self.assertRaises(KeyError):
            node.invoke({})

    def test_non_numeric_value_raises_type_error(self):
        node = IterateNode(name="iterate", iterable_field="idx")
        state = {"idx": "invalid"}

        with self.assertRaises(TypeError):
            node.invoke(state)


if __name__ == "__main__":
    unittest.main()
