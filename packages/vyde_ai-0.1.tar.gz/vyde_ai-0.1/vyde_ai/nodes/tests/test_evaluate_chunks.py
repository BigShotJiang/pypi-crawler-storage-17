__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

import unittest

from vyde_ai.nodes.evaluate_chunks import EvaluateChunksNode


class Chunk:
    def __init__(self, page_content: str):
        self.page_content = page_content


class TestEvaluateChunksNode(unittest.TestCase):
    def test_initialization_defaults(self):
        node = EvaluateChunksNode(name="evaluate")

        self.assertEqual(node.iterable_field, "idx_current_chunk")
        self.assertEqual(node.chunks_field, "chunks")
        self.assertEqual(node.valid_chunks_field, "valid_chunks")
        self.assertTrue(node.disable_tracing)
        self.assertTrue(node.include_conversation)

    def test_initialization_custom_fields(self):
        node = EvaluateChunksNode(
            name="evaluate",
            iterable_field="chunk_idx",
            chunks_field="documents",
            valid_chunks_field="usable_docs",
            disable_tracing=False,
        )

        self.assertEqual(node.iterable_field, "chunk_idx")
        self.assertEqual(node.chunks_field, "documents")
        self.assertEqual(node.valid_chunks_field, "usable_docs")
        self.assertFalse(node.disable_tracing)

    def test_build_invoke_args_reads_current_chunk_content(self):
        node = EvaluateChunksNode(name="evaluate")
        state = {
            node.iterable_field: 1,
            node.chunks_field: [Chunk("alpha"), Chunk("beta"), Chunk("gamma")],
        }

        invoke_args = node.build_invoke_args(state)
        self.assertEqual(invoke_args, {"document": "beta"})

    def test_post_invoke_returns_selected_chunk_when_valid(self):
        node = EvaluateChunksNode(name="evaluate")
        chunks = [Chunk("one"), Chunk("two")]
        state = {node.iterable_field: 0, node.chunks_field: chunks}

        result = node.post_invoke(state, {"valid": True})
        self.assertEqual(result[node.valid_chunks_field], [chunks[0]])
        self.assertIs(result[node.valid_chunks_field][0], chunks[0])

    def test_post_invoke_returns_empty_dict_when_invalid(self):
        node = EvaluateChunksNode(name="evaluate")
        state = {node.iterable_field: 0, node.chunks_field: [Chunk("only")]}

        result = node.post_invoke(state, {"valid": False})
        self.assertEqual(result, {})

    def test_custom_field_names_are_used_in_build_and_post_invoke(self):
        node = EvaluateChunksNode(
            name="evaluate",
            iterable_field="chunk_cursor",
            chunks_field="docs",
            valid_chunks_field="good_docs",
        )
        chunks = [Chunk("docA"), Chunk("docB")]
        state = {"chunk_cursor": 1, "docs": chunks}

        invoke_args = node.build_invoke_args(state)
        self.assertEqual(invoke_args, {"document": "docB"})

        result = node.post_invoke(state, {"valid": True})
        self.assertIn("good_docs", result)
        self.assertEqual(result["good_docs"], [chunks[1]])


if __name__ == "__main__":
    unittest.main()
