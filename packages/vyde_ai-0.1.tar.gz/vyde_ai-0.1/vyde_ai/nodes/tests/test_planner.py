__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

import unittest
from langgraph.types import Overwrite

from vyde_ai.nodes.planner import PlannerNode


class TestPlannerNode(unittest.TestCase):

    def setUp(self):
        """Create a basic PlannerNode for reuse."""
        self.node = PlannerNode(
            name="planner",
            agent_name="test_agent",
            project_name="test_project"
        )

    def test_initialization(self):
        """Node should store constructor arguments correctly."""
        self.assertEqual(self.node.actions, "actions")
        self.assertEqual(self.node.consumable_actions, "consumable_actions")
        self.assertEqual(self.node.context, "context")
        self.assertEqual(self.node.fallback_action, "Fallback and clarification")


    def test_build_invoke_args(self):
        """Ensure the last user message is extracted correctly."""
        state = {
            "messages": ["msg1", "msg2", "final_user_msg"]
        }
        result = self.node.build_invoke_args(state)
        self.assertEqual(result, {"user": "final_user_msg"})

    def test_post_invoke_not_informative_with_actions(self):
        """When response is not informative and actions exist -> use actions."""
        state = {"actions": ["A1", "A2"]}
        response = {"last_message_informative": False}

        result = self.node.post_invoke(state, response)

        self.assertEqual(result["consumable_actions"], ["A1", "A2"])
        self.assertEqual(result["actions"], ["A1", "A2"])
        self.assertEqual(result["context"], Overwrite([]))

    def test_post_invoke_not_informative_without_actions(self):
        """When not informative and no actions -> fallback."""
        state = {"actions": []}
        response = {"last_message_informative": False}

        result = self.node.post_invoke(state, response)

        self.assertEqual(result["consumable_actions"], ["Fallback and clarification"])
        self.assertEqual(result["actions"], ["Fallback and clarification"])
        self.assertEqual(result["context"], Overwrite([]))

    def test_post_invoke_single_intent_high_confidence(self):
        """One intent with confidence >= 0.6 should be selected."""
        state = {"actions": []}
        response = {
            "last_message_informative": True,
            "intents": [{"intent": "DoSomething", "confidence": 0.9}]
        }

        result = self.node.post_invoke(state, response)

        self.assertEqual(result["consumable_actions"], ["DoSomething"])
        self.assertEqual(result["actions"], ["DoSomething"])

    def test_post_invoke_single_intent_low_confidence(self):
        """Single intent < 0.6 should trigger fallback."""
        state = {"actions": []}
        response = {
            "last_message_informative": True,
            "intents": [{"intent": "LowConfidenceAction", "confidence": 0.3}]
        }

        result = self.node.post_invoke(state, response)

        self.assertEqual(result["consumable_actions"], ["Fallback and clarification"])
        self.assertEqual(result["actions"], ["Fallback and clarification"])

    def test_post_invoke_multiple_intents_mixed_confidence(self):
        """Multiple intents: only those with >= 0.6 confidence should be used."""
        state = {"actions": []}
        response = {
            "last_message_informative": True,
            "intents": [
                {"intent": "A", "confidence": 0.2},
                {"intent": "B", "confidence": 0.61},
                {"intent": "C", "confidence": 0.95}
            ]
        }

        result = self.node.post_invoke(state, response)

        self.assertEqual(result["consumable_actions"], ["B", "C"])
        self.assertEqual(result["actions"], ["B", "C"])

    def test_post_invoke_multiple_intents_none_high_confidence(self):
        """Multiple intents but none with >= 0.6 -> fallback."""
        state = {"actions": []}
        response = {
            "last_message_informative": True,
            "intents": [
                {"intent": "A", "confidence": 0.3},
                {"intent": "B", "confidence": 0.5},
            ]
        }

        result = self.node.post_invoke(state, response)

        self.assertEqual(result["consumable_actions"], ["Fallback and clarification"])
        self.assertEqual(result["actions"], ["Fallback and clarification"])

    def test_post_invoke_informative_no_intents(self):
        """Informative but no intents -> fallback."""
        state = {"actions": []}
        response = {"last_message_informative": True, "intents": []}

        result = self.node.post_invoke(state, response)

        self.assertEqual(result["consumable_actions"], ["Fallback and clarification"])
        self.assertEqual(result["actions"], ["Fallback and clarification"])

    def test_post_invoke_context_is_overwrite(self):
        """Context must always be Overwrite([])."""
        state = {"actions": ["A"]}
        response = {"last_message_informative": False}

        result = self.node.post_invoke(state, response)

        self.assertIsInstance(result["context"], Overwrite)
        self.assertEqual(result["context"], Overwrite([]))

    def test_post_invoke_returns_copies_not_mutable_links(self):
        """Returned lists must be copies, not references to same object."""
        state = {"actions": ["A"]}
        response = {"last_message_informative": False}

        result = self.node.post_invoke(state, response)

        result["actions"].append("NEW")

        self.assertEqual(state["actions"], ["A"])


if __name__ == "__main__":
    unittest.main()
