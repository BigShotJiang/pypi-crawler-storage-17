__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

import unittest
from unittest.mock import MagicMock

from langchain_community.embeddings import FakeEmbeddings
from vyde_ai.nodes.semantic_search import SemanticSearchNode


class TestSemanticSearchNode(unittest.TestCase):
    def setUp(self):
        self.mock_vectorstore = MagicMock()
        self.mock_vectorstore.similarity_search_by_vector.return_value = ["chunk1", "chunk2"]

        self.mock_vectorstore.embeddings = MagicMock()
        self.mock_vectorstore.embeddings.embed_query.return_value = [0.1, 0.2, 0.3]

        self.mock_manager_instance = MagicMock()
        self.mock_manager_instance.vectorstore = self.mock_vectorstore

        self.mock_vectorstore_class = MagicMock(return_value=self.mock_manager_instance)

        self.fake_embeddings = FakeEmbeddings(size=3)

        self.node = SemanticSearchNode(
            name="test_node",
            embedding_function=self.fake_embeddings,
            vectorstore_class=self.mock_vectorstore_class,
            agent_name="agent",
            project_name="project",
            disable_tracing=True,
        )

    def test_invoke_no_filters_defaults(self):
        state = {"query": "test query", "index": "test_index"}
        result = self.node.invoke(state)

        self.mock_vectorstore.embeddings.embed_query.assert_called_once_with("test query")

        self.mock_vectorstore.similarity_search_by_vector.assert_called_once_with(
            [0.1, 0.2, 0.3],
            k=10,
            search_type="script_scoring",
            space_type="cosinesimil",
            score_threshold=1.20,
        )

        self.assertEqual(result, {"chunks": ["chunk1", "chunk2"]})

    def test_invoke_custom_k_and_score_threshold(self):
        state = {
            "query": "hello",
            "k": 5,
            "score_threshold": 0.75,
            "index": "test_index"
        }

        self.node.invoke(state)

        self.mock_vectorstore.similarity_search_by_vector.assert_called_once_with(
            [0.1, 0.2, 0.3],
            k=5,
            search_type="script_scoring",
            space_type="cosinesimil",
            score_threshold=0.75,
        )

    def test_invoke_filters_must(self):
        state = {
            "query": "test query",
            "filters_must": {"category": ["x", "y"]},
            "index": "test_index"
        }

        self.node.invoke(state)

        call_args = self.mock_vectorstore.similarity_search_by_vector.call_args.kwargs

        self.assertIn("pre_filter", call_args)
        self.assertEqual(
            call_args["pre_filter"],
            {"bool": {"must": {"terms": {"metadata.category.keyword": ["x", "y"]}}}},
        )

    def test_invoke_filters_must_not(self):
        state = {
            "query": "test query",
            "filters_must_not": {"author": ["bob"]},
            "index": "test_index"
        }

        self.node.invoke(state)

        call_args = self.mock_vectorstore.similarity_search_by_vector.call_args.kwargs

        self.assertIn("pre_filter", call_args)
        self.assertEqual(
            call_args["pre_filter"],
            {"bool": {"must_not": {"terms": {"metadata.author.keyword": ["bob"]}}}},
        )

    def test_invoke_filters_both(self):
        state = {
            "query": "test query",
            "filters_must": {"color": ["red"]},
            "filters_must_not": {"size": ["large"]},
            "index": "test_index"
        }

        self.node.invoke(state)

        call_args = self.mock_vectorstore.similarity_search_by_vector.call_args.kwargs

        self.assertEqual(
            call_args["pre_filter"],
            {
                "bool": {
                    "must": {"terms": {"metadata.color.keyword": ["red"]}},
                    "must_not": {"terms": {"metadata.size.keyword": ["large"]}},
                }
            },
        )

    def test_invoke_multiple_must_filters(self):
        state = {
            "query": "test query",
            "filters_must": {
                "color": ["red"],
                "brand": ["nike"],
            },
            "index": "test_index"
        }

        self.node.invoke(state)

        pf = self.mock_vectorstore.similarity_search_by_vector.call_args.kwargs["pre_filter"]

        expected_terms = [
            {"terms": {"metadata.color.keyword": ["red"]}},
            {"terms": {"metadata.brand.keyword": ["nike"]}},
        ]

        self.assertEqual(pf["bool"]["must"], expected_terms)

    def test_invoke_multiple_must_not_filters(self):
        state = {
            "query": "test query",
            "filters_must_not": {
                "size": ["large"],
                "category": ["books"],
            },
            "index": "test_index"
        }

        self.node.invoke(state)

        pf = self.mock_vectorstore.similarity_search_by_vector.call_args.kwargs["pre_filter"]

        expected_terms = [
            {"terms": {"metadata.size.keyword": ["large"]}},
            {"terms": {"metadata.category.keyword": ["books"]}},
        ]

        self.assertEqual(pf["bool"]["must_not"], expected_terms)


if __name__ == "__main__":
    unittest.main()
