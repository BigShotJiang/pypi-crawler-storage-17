__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

import unittest
from unittest.mock import patch

from vyde_ai.nodes.orchestrator import OrchestratorNode


class TestOrchestratorNode(unittest.TestCase):
    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_default_init_uses_default_attribute_names(self, mock_super_init):
        node = OrchestratorNode(name="router")

        self.assertEqual(node.consumable_actions, "consumable_actions")
        self.assertEqual(node.next_action, "next_action")
        mock_super_init.assert_called_once_with(
            name="router",
            agent_name=None,
            project_name=None,
            disable_tracing=True
        )

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_custom_attribute_names_are_stored(self, mock_super_init):
        node = OrchestratorNode(
            name="router",
            consumable_actions="actions",
            next_action="step"
        )

        self.assertEqual(node.consumable_actions, "actions")
        self.assertEqual(node.next_action, "step")
        mock_super_init.assert_called_once_with(
            name="router",
            agent_name=None,
            project_name=None,
            disable_tracing=True
        )

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_positional_and_keyword_args_are_forwarded_to_super(self, mock_super_init):
        node = OrchestratorNode(
            name="router",
            agent_name="agent",
            project_name="proj",
            disable_tracing=False,
            consumable_actions="my_actions",
            next_action="my_next"
        )

        self.assertEqual(node.consumable_actions, "my_actions")
        self.assertEqual(node.next_action, "my_next")

        mock_super_init.assert_called_once_with(
            name="router",
            agent_name="agent",
            project_name="proj",
            disable_tracing=False
        )

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_missing_consumable_actions_returns_end(self, _):
        node = OrchestratorNode(name="router")
        state = {}

        result = node.invoke(state)
        self.assertEqual(result, {"next_action": "END"})
        self.assertEqual(state, {})

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_empty_consumable_actions_returns_end(self, _):
        node = OrchestratorNode(name="router")
        state = {"consumable_actions": []}

        result = node.invoke(state)
        self.assertEqual(result, {"next_action": "END"})
        self.assertEqual(state["consumable_actions"], [])

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_returns_first_action_and_mutates_list(self, _):
        node = OrchestratorNode(name="router")
        state = {"consumable_actions": ["A", "B", "C"]}

        result = node.invoke(state)
        self.assertEqual(result, {"next_action": "A"})
        self.assertEqual(state["consumable_actions"], ["B", "C"])

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_single_element_list_then_end(self, _):
        node = OrchestratorNode(name="router")
        state = {"consumable_actions": ["ONE"]}

        r1 = node.invoke(state)
        self.assertEqual(r1, {"next_action": "ONE"})
        self.assertEqual(state["consumable_actions"], [])

        r2 = node.invoke(state)
        self.assertEqual(r2, {"next_action": "END"})

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_custom_next_action_key(self, _):
        node = OrchestratorNode(name="router")
        node.next_action = "step_to_run"

        state = {"consumable_actions": ["task"]}
        result = node.invoke(state)
        self.assertEqual(result, {"step_to_run": "task"})

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_custom_consumable_actions_key(self, _):
        node = OrchestratorNode(
            name="router",
            consumable_actions="actions",
            next_action="next_step"
        )
        state = {"actions": ["X", "Y"]}

        result = node.invoke(state)
        self.assertEqual(result, {"next_step": "X"})
        self.assertEqual(state["actions"], ["Y"])

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_falsy_values(self, _):
        node = OrchestratorNode(name="router")
        state = {"consumable_actions": [None, "", 0, False]}

        r1 = node.invoke(state)
        self.assertEqual(r1, {"next_action": None})
        self.assertEqual(state["consumable_actions"], ["", 0, False])

        r2 = node.invoke(state)
        self.assertEqual(r2, {"next_action": ""})
        self.assertEqual(state["consumable_actions"], [0, False])

        r3 = node.invoke(state)
        self.assertEqual(r3, {"next_action": 0})
        self.assertEqual(state["consumable_actions"], [False])

        r4 = node.invoke(state)
        self.assertEqual(r4, {"next_action": False})
        self.assertEqual(state["consumable_actions"], [])

        r5 = node.invoke(state)
        self.assertEqual(r5, {"next_action": "END"})

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_no_unexpected_state_mutation(self, _):
        node = OrchestratorNode(name="router")
        state = {"other": 999}

        result = node.invoke(state)
        self.assertEqual(result, {"next_action": "END"})
        self.assertNotIn("consumable_actions", state)
        self.assertEqual(state["other"], 999)

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_none_consumable_actions_raises(self, _):
        node = OrchestratorNode(name="router")
        state = {"consumable_actions": None}

        with self.assertRaises(TypeError):
            node.invoke(state)

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_no_pop_method_raises(self, _):
        node = OrchestratorNode(name="router")
        state = {"consumable_actions": ("A", "B")}  # tuple has no pop

        with self.assertRaises(AttributeError):
            node.invoke(state)

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_list_subclass_supported(self, _):
        node = OrchestratorNode(name="router")

        class L(list):
            pass

        lst = L(["X", "Y"])

        state = {"consumable_actions": lst}
        result = node.invoke(state)

        self.assertEqual(result, {"next_action": "X"})
        self.assertEqual(state["consumable_actions"], L(["Y"]))

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_attribute_modification_after_init(self, _):
        node = OrchestratorNode(name="router")
        node.consumable_actions = "queue"
        node.next_action = "operation"

        state = {"queue": ["job1", "job2"]}

        result = node.invoke(state)
        self.assertEqual(result, {"operation": "job1"})
        self.assertEqual(state["queue"], ["job2"])

    @patch("vyde_ai.nodes.orchestrator.ToolNode.__init__", return_value=None)
    def test_custom_consumable_key_missing_returns_end_even_if_default_present(self, _):
        node = OrchestratorNode(
            name="router",
            consumable_actions="actions",
            next_action="next_step"
        )
        state = {"consumable_actions": ["fallback"], "other": 123}

        result = node.invoke(state)

        self.assertEqual(result, {"next_step": "END"})
        self.assertEqual(state["consumable_actions"], ["fallback"])


if __name__ == "__main__":
    unittest.main()
