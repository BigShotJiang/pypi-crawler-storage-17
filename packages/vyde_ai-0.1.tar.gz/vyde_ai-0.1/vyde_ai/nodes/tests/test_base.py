__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

import unittest
from unittest.mock import MagicMock, patch
from typing import Dict, Any

from vyde_ai.nodes.base import (AbstractNode, ChainNode, LLMNode, RetrieverNode, ToolNode, LLMInvocationError,
                        LLM_ERROR_GENERIC, LLM_ERROR_REQUESTS_PER_MINUTE, LLM_ERROR_TOKENS_PER_MINUTE,
                        LLM_ERROR_TOKENS_PER_REQUEST)


class ConcreteAbstractNode(AbstractNode):
    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {"invoke": True}

    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        return {"post": True}


class PassThroughAbstractNode(AbstractNode):
    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return super().invoke(state)

    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        return super().post_invoke(state, response)


class ConcreteChainNode(ChainNode):
    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {"chain": True}


class PassThroughChainNode(ChainNode):
    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return super().invoke(state)


class ConcreteLLMNode(LLMNode):
    def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {"x": 1}

    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        return {"post": True}


class PassThroughLLMNode(LLMNode):
    def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return super().build_invoke_args(state)

    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        return super().post_invoke(state, response)


class ConcreteRetrieverNode(RetrieverNode):
    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {"retrieved": True}


class PassThroughRetrieverNode(RetrieverNode):
    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return super().invoke(state)


class ConcreteToolNode(ToolNode):
    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {"tool": True}


class PassThroughToolNode(ToolNode):
    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return super().invoke(state)


class TestAbstractNode(unittest.TestCase):
    def test_super_methods_from_abstract_node_are_noops(self):
        node = PassThroughAbstractNode(
            name="base",
            run_type="X",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        self.assertIsNone(node.invoke({}))
        self.assertIsNone(node.post_invoke({}, {}))

    def test_node_without_tracing(self):
        node = ConcreteAbstractNode(
            name="test",
            run_type="X",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        state = {}
        updates = node.node()(state)

        self.assertEqual(updates, {"log": ["call node agent__test"], "post": True})

    def test_node_with_tracing(self):
        node = ConcreteAbstractNode(
            name="test",
            run_type="X",
            agent_name="agent",
            project_name="proj",
            disable_tracing=False
        )

        trace_calls = []
        wrapper_called = {"value": False}

        def fake_traceable(*args, **kwargs):
            trace_calls.append((args, kwargs))

            def decorator(fn):
                def wrapped(*w_args, **w_kwargs):
                    wrapper_called["value"] = True
                    return fn(*w_args, **w_kwargs)
                return wrapped

            return decorator

        with patch("vyde_ai.nodes.base.traceable", side_effect=fake_traceable):
            f = node.node()
            result = f({})

        self.assertEqual(result, {"post": True})
        self.assertTrue(wrapper_called["value"])
        self.assertEqual(len(trace_calls), 1)
        _, kwargs = trace_calls[0]
        self.assertEqual(kwargs["run_type"], "X")
        self.assertEqual(kwargs["name"], "agent__test")
        self.assertEqual(kwargs["project_name"], "proj")
        self.assertEqual(kwargs["metadata"], {"agent": "agent"})


class TestChainNode(unittest.TestCase):
    def test_chain_invoke_and_post(self):
        node = ConcreteChainNode(
            name="chain",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        state = {}
        result = node._node(state)
        self.assertEqual(result, {"chain": True, 'log': ['call node agent__chain']})

    def test_chain_invoke_super_noop(self):
        node = PassThroughChainNode(
            name="chain",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        self.assertIsNone(node.invoke({}))

    def test_node_skips_invoke_when_error_flagged(self):
        node = ConcreteChainNode(
            name="chain",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        node.invoke = MagicMock(return_value={"chain": True})
        state = {"error": True}

        result = node._node(state)

        node.invoke.assert_not_called()
        self.assertEqual(result, {"error": True, 'log': ['call node agent__chain']})

    def test_node_sets_error_flag_when_exception_raised(self):
        node = ConcreteChainNode(
            name="chain",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        node.invoke = MagicMock(side_effect=RuntimeError("boom"))
        result = node._node({})

        node.invoke.assert_called_once()
        self.assertEqual(result, {"error": True, 'log': ['call node agent__chain']})


class TestLLMNode(unittest.TestCase):
    def test_llm_super_methods_are_noops(self):
        node = PassThroughLLMNode(
            name="llm",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        self.assertIsNone(node.build_invoke_args({}))
        self.assertIsNone(node.post_invoke({}, {}))

    @patch("vyde_ai.nodes.base.convert_messages_to_conversation", return_value="CONV")
    @patch("vyde_ai.nodes.base.Client")
    def test_llm_invoke(self, mock_client_class, mock_conv):
        mock_client = MagicMock()
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = {"result": True}
        mock_client.pull_prompt.return_value = mock_chain
        mock_client_class.return_value = mock_client

        node = ConcreteLLMNode(
            name="llm",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True,
            include_conversation=True
        )

        state = {"messages": ["hello"]}
        result = node.invoke(state)

        mock_client.pull_prompt.assert_called_once_with("agent__llm", include_model=True)
        mock_chain.invoke.assert_called_once_with({"x": 1, "conversation": "CONV"})

        self.assertEqual(result, {"result": True})

    @patch("vyde_ai.nodes.base.convert_messages_to_conversation", return_value="CONV")
    @patch("vyde_ai.nodes.base.Client")
    def test_llm_invoke_respects_rate_limiter(self, mock_client_class, mock_conv):
        mock_client = MagicMock()
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = {"result": True}
        mock_client.pull_prompt.return_value = mock_chain
        mock_client_class.return_value = mock_client

        rate_limiter = MagicMock()

        node = ConcreteLLMNode(
            name="llm",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True,
            include_conversation=True,
            rate_limiter=rate_limiter,
        )

        state = {"messages": ["hello"]}
        node.invoke(state)

        rate_limiter.acquire.assert_called_once()
        mock_chain.invoke.assert_called_once()

    @patch("vyde_ai.nodes.base.convert_messages_to_conversation", return_value="CONV")
    @patch("vyde_ai.nodes.base.Client")
    def test_llm_invoke_uses_global_rate_limiter_when_not_provided(self, mock_client_class, mock_conv):
        mock_client = MagicMock()
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = {"result": True}
        mock_client.pull_prompt.return_value = mock_chain
        mock_client_class.return_value = mock_client

        with patch("vyde_ai.nodes.base.DEFAULT_RATE_LIMITER") as global_limiter:
            node = ConcreteLLMNode(
                name="llm",
                agent_name="agent",
                project_name="proj",
                disable_tracing=True,
                include_conversation=True,
                rate_limiter=None,
            )

            state = {"messages": ["hello"]}
            node.invoke(state)

            global_limiter.acquire.assert_called_once()
            mock_chain.invoke.assert_called_once()

    def _invoke_llm_and_get_error(self, error_message: str) -> LLMInvocationError:
        with patch("vyde_ai.nodes.base.convert_messages_to_conversation", return_value="CONV"), \
             patch("vyde_ai.nodes.base.Client") as mock_client_class:
            mock_client = MagicMock()
            mock_chain = MagicMock()
            mock_chain.invoke.side_effect = Exception(error_message)
            mock_client.pull_prompt.return_value = mock_chain
            mock_client_class.return_value = mock_client

            node = ConcreteLLMNode(
                name="llm",
                agent_name="agent",
                project_name="proj",
                disable_tracing=True,
                include_conversation=True
            )

            with self.assertRaises(LLMInvocationError) as ctx:
                node.invoke({"messages": ["hello"]})

            return ctx.exception

    def test_llm_invoke_handles_tokens_per_minute_error(self):
        exc = self._invoke_llm_and_get_error("Rate limit reached for tokens per minute")
        self.assertEqual(exc.kind, LLM_ERROR_TOKENS_PER_MINUTE)
        self.assertIn("tokens per minute", str(exc).lower())

    def test_llm_invoke_handles_tokens_per_request_error(self):
        exc = self._invoke_llm_and_get_error("token per request limit exceeded")
        self.assertEqual(exc.kind, LLM_ERROR_TOKENS_PER_REQUEST)
        self.assertIn("token per request", str(exc).lower())

    def test_llm_invoke_handles_requests_per_minute_error(self):
        exc = self._invoke_llm_and_get_error("requests per minute quota reached")
        self.assertEqual(exc.kind, LLM_ERROR_REQUESTS_PER_MINUTE)
        self.assertIn("requests per minute", str(exc).lower())

    def test_llm_invoke_handles_generic_error(self):
        exc = self._invoke_llm_and_get_error("unexpected failure")
        self.assertEqual(exc.kind, LLM_ERROR_GENERIC)
        self.assertIn("unexpected failure", str(exc))

    @patch("vyde_ai.nodes.base.convert_messages_to_conversation", return_value="CONV")
    @patch("vyde_ai.nodes.base.Client")
    def test_llm_node_sets_error_flag_on_invoke_exception(self, mock_client_class, mock_conv):
        mock_client = MagicMock()
        mock_chain = MagicMock()
        mock_chain.invoke.side_effect = Exception("explode")
        mock_client.pull_prompt.return_value = mock_chain
        mock_client_class.return_value = mock_client

        node = ConcreteLLMNode(
            name="llm",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True,
            include_conversation=True
        )

        result = node._node({"messages": ["hello"]})

        self.assertEqual(result, {"error": True, 'log': ['call node agent__llm']})
        mock_chain.invoke.assert_called_once()


class TestRetrieverNode(unittest.TestCase):
    def test_retriever_invoke(self):
        node = ConcreteRetrieverNode(
            name="retriever",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        state = {}
        result = node._node(state)
        self.assertEqual(result, {"retrieved": True, 'log': ['call node agent__retriever']})

    def test_retriever_invoke_super_noop(self):
        node = PassThroughRetrieverNode(
            name="retriever",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        self.assertIsNone(node.invoke({}))


class TestToolNode(unittest.TestCase):

    def test_tool_invoke(self):
        node = ConcreteToolNode(
            name="tool",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        state = {}
        result = node._node(state)
        self.assertEqual(result, {"tool": True, 'log': ['call node agent__tool']})

    def test_tool_invoke_super_noop(self):
        node = PassThroughToolNode(
            name="tool",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        self.assertIsNone(node.invoke({}))


if __name__ == "__main__":
    unittest.main()
