__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

import unittest
from unittest.mock import MagicMock, patch
from typing import Dict, Any

from vyde_ai.nodes.routing import RoutingNode


class ConcreteRoutingNode(RoutingNode):
    def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return {"route": True}

    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        return {"post": True}


class SuperRoutingNode(RoutingNode):
    def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return super().build_invoke_args(state)

    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        return super().post_invoke(state, response)


class TestRoutingNode(unittest.TestCase):
    @patch("vyde_ai.nodes.routing.Client")
    def test_routing_invoke(self, mock_client_class):
        mock_client = MagicMock()
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = {"routing": True}
        mock_client.pull_prompt.return_value = mock_chain
        mock_client_class.return_value = mock_client

        node = ConcreteRoutingNode(
            name="routing",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        state = {"messages": ["hello", "final message"]}
        result = node.invoke(state)

        mock_chain.invoke.assert_called_once_with({"route": True, "user": "final message"})
        self.assertEqual(result, {"routing": True})

    def test_base_post_invoke_and_build_args_noop(self):
        node = SuperRoutingNode(
            name="routing",
            agent_name="agent",
            project_name="proj",
            disable_tracing=True
        )

        self.assertIsNone(node.post_invoke({}, {}))
        self.assertIsNone(node.build_invoke_args({}))


if __name__ == "__main__":
    unittest.main()
