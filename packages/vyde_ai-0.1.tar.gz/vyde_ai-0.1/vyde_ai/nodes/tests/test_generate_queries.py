__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from langgraph.types import Overwrite
from typing import Any, Dict, List
import unittest
from unittest.mock import MagicMock

from vyde_ai.nodes.generate_queries import GenerateQueriesNode


class ConcreteGenerateQueriesNode(GenerateQueriesNode):
    """Minimal concrete implementation so we can exercise the base logic."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.seen_states: List[Dict[str, Any]] = []

    def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
        self.seen_states.append(state)
        return {"state": state}

    def compose_queries(self, queries: List[Dict[str, Any]]) -> List[Any]:
        # Return the `q` field if present, otherwise the raw dictionary
        return [item.get("q", item) for item in queries]


class PassThroughGenerateQueriesNode(GenerateQueriesNode):
    """Subclass that simply delegates to the base class for coverage."""

    def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return super().build_invoke_args(state)

    def compose_queries(self, queries: List[Dict[str, Any]]) -> List[Any]:
        return super().compose_queries(queries)


class TestGenerateQueriesNode(unittest.TestCase):
    def test_base_build_invoke_args_and_compose_queries_are_noops(self):
        node = PassThroughGenerateQueriesNode(name="noop")
        self.assertIsNone(node.build_invoke_args({"foo": "bar"}))
        self.assertIsNone(node.compose_queries([{"q": "value"}]))

    def test_initialization_uses_default_fields_and_flags(self):
        node = ConcreteGenerateQueriesNode(
            name="generate_queries",
            agent_name="rag_agent",
            project_name="rag_project",
        )

        self.assertEqual(node.iterable_query_field, "idx_current_query")
        self.assertEqual(node.iterable_chunk_field, "idx_current_chunk")
        self.assertEqual(node.chunks_field, "chunks")
        self.assertEqual(node.valid_chunks_field, "valid_chunks")
        self.assertEqual(node.queries_field, "queries")
        self.assertTrue(node.include_conversation)
        self.assertFalse(node.disable_tracing)
        self.assertEqual(node.agent_name, "rag_agent")
        self.assertEqual(node.project_name, "rag_project")

    def test_initialization_accepts_custom_fields_and_flags(self):
        node = ConcreteGenerateQueriesNode(
            name="generate",
            agent_name="agent",
            project_name="project",
            include_conversation=False,
            disable_tracing=True,
            iterable_query_field="current_query",
            iterable_chunk_field="current_chunk",
            chunks_field="chunk_storage",
            valid_chunks_field="approved_chunks",
            queries_field="pending_queries",
        )

        self.assertEqual(node.iterable_query_field, "current_query")
        self.assertEqual(node.iterable_chunk_field, "current_chunk")
        self.assertEqual(node.chunks_field, "chunk_storage")
        self.assertEqual(node.valid_chunks_field, "approved_chunks")
        self.assertEqual(node.queries_field, "pending_queries")
        self.assertFalse(node.include_conversation)
        self.assertTrue(node.disable_tracing)

    def test_post_invoke_formats_queries_and_resets_iteration_fields(self):
        node = ConcreteGenerateQueriesNode(name="gen")
        node.compose_queries = MagicMock(return_value=["Q1", "Q2"])

        raw_queries = [{"q": "query-a"}, {"q": "query-b"}]
        updated = node.post_invoke(
            state={"idx_current_query": 2, "idx_current_chunk": 1},
            response={"queries": raw_queries},
        )

        node.compose_queries.assert_called_once_with(raw_queries)
        self.assertEqual(updated[node.queries_field], ["Q1", "Q2"])

        for field_name in (node.chunks_field, node.valid_chunks_field):
            self.assertIsInstance(updated[field_name], Overwrite)
            self.assertEqual(updated[field_name].value, [])

        self.assertEqual(updated[node.iterable_query_field], -1)
        self.assertEqual(updated[node.iterable_chunk_field], -1)

    def test_post_invoke_respects_custom_field_names_and_empty_payload(self):
        node = ConcreteGenerateQueriesNode(
            name="gen",
            iterable_query_field="query_idx",
            iterable_chunk_field="chunk_idx",
            chunks_field="documents",
            valid_chunks_field="usable_documents",
            queries_field="composed_queries",
        )

        updated = node.post_invoke(state={}, response={"queries": []})

        self.assertEqual(updated["composed_queries"], [])
        self.assertEqual(updated["query_idx"], -1)
        self.assertEqual(updated["chunk_idx"], -1)
        self.assertIsInstance(updated["documents"], Overwrite)
        self.assertIsInstance(updated["usable_documents"], Overwrite)

    def test_post_invoke_creates_fresh_overwrite_instances_each_call(self):
        node = ConcreteGenerateQueriesNode(name="gen")

        first = node.post_invoke(state={}, response={"queries": []})
        second = node.post_invoke(state={}, response={"queries": []})

        self.assertIsNot(first[node.chunks_field], second[node.chunks_field])
        self.assertIsNot(first[node.valid_chunks_field], second[node.valid_chunks_field])


if __name__ == "__main__":
    unittest.main()
