__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from abc import abstractmethod
from langgraph.types import Overwrite
from typing import Any, Dict, List, Optional

from vyde_ai.nodes.base import LLMNode


class GenerateQueriesNode(LLMNode):
    def __init__(
            self,
            name: str,
            agent_name: Optional[str] = None,
            project_name: Optional[str] = None,
            disable_tracing: bool = False,
            include_conversation: bool = True,
            iterable_query_field: str = 'idx_current_query',
            iterable_chunk_field: str = 'idx_current_chunk',
            chunks_field: str = 'chunks',
            valid_chunks_field: str = 'valid_chunks',
            queries_field: str = 'queries',
    ):
        super().__init__(
            name=name,
            include_conversation=include_conversation,
            agent_name=agent_name,
            project_name=project_name,
            disable_tracing=disable_tracing
        )

        self.iterable_query_field = iterable_query_field
        self.iterable_chunk_field = iterable_chunk_field
        self.chunks_field = chunks_field
        self.valid_chunks_field = valid_chunks_field
        self.queries_field = queries_field

    @abstractmethod
    def build_invoke_args(self, state: Dict[str, Any]) -> Dict[str, Any]:
        pass

    @abstractmethod
    def compose_queries(self, queries: List[Dict[str, Any]]) -> List:
        pass

    def post_invoke(self, state: Dict[str, Any], response: Dict[str, Any]) -> Dict[str, Any]:
        queries = response['queries']

        return {
            self.queries_field: self.compose_queries(queries),
            self.chunks_field: Overwrite([]),
            self.valid_chunks_field: Overwrite([]),
            self.iterable_query_field: -1,
            self.iterable_chunk_field: -1
        }
