__version__ = "0.1"
__company__ = "Dive Code"
__author__ = "Fabrizio Radaelli"

from typing import Literal


CHAIN = "chain"
EMBEDDING = "embedding"
LLM = "llm"
PARSE = "parser"
PROMPT = "prompt"
RETRIEVER = "retriever"
TOOL = "tool"

RUN_TYPES = Literal[CHAIN, EMBEDDING, LLM, PARSE, PROMPT, RETRIEVER, TOOL]
