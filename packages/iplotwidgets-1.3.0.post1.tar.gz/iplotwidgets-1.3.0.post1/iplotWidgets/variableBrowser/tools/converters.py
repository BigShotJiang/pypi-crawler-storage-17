from typing import List

def parse_imaspy_pulses(lines: List) -> dict:
    return lines