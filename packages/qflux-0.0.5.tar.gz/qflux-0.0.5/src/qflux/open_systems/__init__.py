from .numerical_methods import DynamicsOS, DVR_grid
from .quantum_simulation import QubitDynamicsOS
