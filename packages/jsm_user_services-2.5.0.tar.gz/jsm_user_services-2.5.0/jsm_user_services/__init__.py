import threading

local_threading = threading.local()
