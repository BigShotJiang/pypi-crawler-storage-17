from django.apps import AppConfig


class JsmUserServicesConfig(AppConfig):
    name = "jsm_user_services"
