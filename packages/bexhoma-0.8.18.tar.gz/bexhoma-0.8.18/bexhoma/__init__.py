"""
The clustermanager module
"""
__all__ = ["evaluators", "clusters", "experiments", "configurations", "collectors"]
from .__version__ import __version__
