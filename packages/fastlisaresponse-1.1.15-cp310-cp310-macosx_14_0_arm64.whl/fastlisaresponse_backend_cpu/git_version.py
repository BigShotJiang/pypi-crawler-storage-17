"""Metadata deduced from git at build time."""

id: str
short_id: str

id = "1ce3ec96ac94f411f81b90e6d16d3f9329f5586b"
short_id = "1ce3ec9"
