# snakemake-executor-plugin-slurm

A Snakemake executor plugin for running srun jobs inside of SLURM jobs (meant for
internal use by snakemake-executor-plugin-slurm).