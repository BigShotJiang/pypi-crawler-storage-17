def main():
    print("Hello from pynlopt!")


if __name__ == "__main__":
    main()
