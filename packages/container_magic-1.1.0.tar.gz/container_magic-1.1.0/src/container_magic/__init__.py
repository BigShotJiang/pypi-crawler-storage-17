"""Container-magic: Rapidly create containerised development environments."""

__version__ = "0.1.0"
