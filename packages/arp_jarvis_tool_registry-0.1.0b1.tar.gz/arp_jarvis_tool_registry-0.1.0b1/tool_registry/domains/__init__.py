"""In-repo tool sources ("domains")."""

