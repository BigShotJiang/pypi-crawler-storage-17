# `sarzaminget`
IR Downloader

## Sites
* [Aparat]
* [Sarzamin Download]
* [Soft98]
* [p30download]

[Aparat]: https://aparat.com
[Sarzamin Download]: https://sarzamindownload.com
[Soft98]: https://soft98.ir
[p30download]: https://p30download.ir

<!--
SPDX-License-Identifier: CC0-1.0
SPDX-FileCopyrightText: 2025 NexusSfan <nexussfan@duck.com>
-->