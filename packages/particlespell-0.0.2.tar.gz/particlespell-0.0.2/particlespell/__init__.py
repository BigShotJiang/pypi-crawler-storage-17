# 从主文件导入核心类，暴露给包的顶层
from .particlespell import Particle