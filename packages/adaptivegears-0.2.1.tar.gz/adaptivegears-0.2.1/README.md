# adaptivegears

CLI tools for data engineering workflows.

## Installation

```bash
# Via uvx (recommended)
uvx adaptivegears --help

# Or install globally
uv tool install adaptivegears
```

## Usage

```bash
# Generate UUIDs
uvx adaptivegears util uuid
uvx adaptivegears util uuid --v7
uvx adaptivegears util uuid --count 5

# PostgreSQL utilities (requires [pg] extra)
uvx 'adaptivegears[pg]' pg list tables
uvx 'adaptivegears[pg]' pg list tables --schema public
uvx 'adaptivegears[pg]' pg list tables --json
```

## PostgreSQL Commands

Requires `DATABASE_URL` environment variable:

```bash
export DATABASE_URL="postgresql://user:pass@localhost/dbname"
uvx 'adaptivegears[pg]' pg list tables
```
