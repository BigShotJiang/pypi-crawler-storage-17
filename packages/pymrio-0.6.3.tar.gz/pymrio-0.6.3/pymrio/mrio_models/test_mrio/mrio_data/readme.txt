This folder contains a small test mrio for the development.

The mrio system in this folder is the one loaded using pymrio.load_test() as described in the readme.md in the root.


