# More or less generic tools for IO processing
