"""
The project is configured in pyproject.toml. This script is left for the editable installation.
"""

from setuptools import setup  # type: ignore

setup()
