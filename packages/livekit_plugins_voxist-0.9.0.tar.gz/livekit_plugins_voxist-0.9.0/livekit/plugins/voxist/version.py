"""Version information for livekit-plugins-voxist."""

__version__ = "0.1.0"
