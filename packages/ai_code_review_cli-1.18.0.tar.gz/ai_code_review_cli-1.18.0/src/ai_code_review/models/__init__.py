"""Data models for AI Code Review tool."""
