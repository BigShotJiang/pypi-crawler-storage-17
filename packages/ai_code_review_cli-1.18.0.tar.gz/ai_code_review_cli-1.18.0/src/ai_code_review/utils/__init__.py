"""Utility functions for AI Code Review tool."""
