# Copyright 2025 Rebellions Inc. All rights reserved.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
from os import environ


this_path = os.path.abspath(__file__)
local_dir = "/" + os.path.join(*this_path.split("/")[:-1]) + "/hf_hub_cached"
environ["LOCAL_CACHE_ROOT_CUSTOM_CODE_MIDM"] = local_dir

from .configuration_exaone import RBLNExaoneForCausalLMConfig
from .modeling_exaone import RBLNExaoneForCausalLM
