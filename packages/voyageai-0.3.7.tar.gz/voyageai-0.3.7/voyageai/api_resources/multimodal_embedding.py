from voyageai.api_resources.embedding import Embedding


class MultimodalEmbedding(Embedding):
    OBJECT_NAME = "multimodalembeddings"
