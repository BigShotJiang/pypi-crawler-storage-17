import importlib.metadata

VERSION = importlib.metadata.version("voyageai")
