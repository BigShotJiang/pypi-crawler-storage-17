# module
from ._gribberish_python import *