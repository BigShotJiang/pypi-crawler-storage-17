raise ModuleNotFoundError(
    "lightning_pose.model has been moved to lightning_pose.api.model"
)
