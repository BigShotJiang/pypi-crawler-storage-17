"""Keybinding configuration for LazyClaude."""

__all__: list[str] = []
