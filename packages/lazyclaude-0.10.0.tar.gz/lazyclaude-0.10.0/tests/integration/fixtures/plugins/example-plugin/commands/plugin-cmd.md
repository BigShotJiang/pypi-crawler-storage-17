---
description: A command from a plugin
---
# Plugin Command
This command comes from the example-plugin.
