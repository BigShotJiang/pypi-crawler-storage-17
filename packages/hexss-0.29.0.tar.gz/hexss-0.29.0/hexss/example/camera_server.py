from hexss.server import camera_server

if __name__ == '__main__':
    camera_server.run()