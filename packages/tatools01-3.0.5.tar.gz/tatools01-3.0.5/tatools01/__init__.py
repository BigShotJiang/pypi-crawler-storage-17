"""

tatools01


An python parametters library.
"""


__version__ = "3.0.5" # Nhớ update cả Readme.md


__author__ = "Nguyễn Tuấn Anh - nt.anh.fai@gmail.com"

__credits__ = "MIT License"
__console__ = "tact"
import os

import sys

import argparse

import json
 
   

from . import ParamsBase

from tatools01.Thoi_gian.taTimers import MultiTimer

 
    

