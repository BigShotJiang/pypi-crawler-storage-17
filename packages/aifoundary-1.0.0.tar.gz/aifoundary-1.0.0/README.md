Aifoundary
Enterprise AI Compliance Package with PII Detection & Secure RAG System.
Installation
Bashpip install aifoundary
Quickstart
See examples/quickstart.py.
Features

Hybrid PII Detection (Regex + BERT NER)
PII-Filtered RAG with FAISS & Sentence Transformers
Immutable Audit Logging
LangChain Integration

Development
Bashpip install -e .[dev]
pytest
