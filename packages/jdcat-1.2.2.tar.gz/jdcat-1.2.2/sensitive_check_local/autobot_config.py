AGENT_ID = "54772"
TOKEN = "6d30ef7483ac48c9b82741f897ad2afa"

APP_CODE_DEFAULT = ""

# 接口地址（如需覆盖可改这里，而非环境变量）
RUN_URL = "http://autobots-bk.jd.local/autobots/api/v1/runWorkflow"
RESULT_URL = "http://autobots-bk.jd.local/autobots/api/v1/getWorkflowResult"
