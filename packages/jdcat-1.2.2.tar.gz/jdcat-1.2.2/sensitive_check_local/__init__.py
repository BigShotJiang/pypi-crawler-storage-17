"""
Local helper CLI for sensitive-check project.
"""

from typing import Final

__version__: Final[str] = "0.0.1"