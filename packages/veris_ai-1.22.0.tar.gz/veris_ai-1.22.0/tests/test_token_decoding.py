"""Tests for token decoding functionality."""

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa

from veris_ai import veris


def generate_test_keypair():
    """Generate a test RSA key pair."""
    return rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )


def create_test_jwt(claims: dict, private_key) -> str:
    """Create a test JWT with the given claims."""
    return jwt.encode(claims, private_key, algorithm="RS256")


class TestTokenDecoding:
    """Test token decoding via parse_token()."""

    def test_decode_valid_token_with_both_ids(self):
        """Test decoding a valid token with both session_id and thread_id."""
        private_key = generate_test_keypair()
        token = create_test_jwt(
            {"session_id": "test-session-123", "thread_id": "thread-456"},
            private_key,
        )

        try:
            veris.parse_token(token, verify_signature=False)
            assert veris.session_id == "test-session-123"
            assert veris.thread_id == "thread-456"
        finally:
            veris.clear_context()

    def test_decode_valid_token_with_only_session_id(self):
        """Test decoding a token with only session_id (no thread_id)."""
        private_key = generate_test_keypair()
        token = create_test_jwt({"session_id": "test-session-789"}, private_key)

        try:
            veris.parse_token(token, verify_signature=False)
            assert veris.session_id == "test-session-789"
            assert veris.thread_id is None
        finally:
            veris.clear_context()

    def test_decode_token_with_uuid_format(self):
        """Test decoding token with UUID-formatted IDs."""
        private_key = generate_test_keypair()
        session_id = "550e8400-e29b-41d4-a716-446655440000"
        thread_id = "6ba7b810-9dad-11d1-80b4-00c04fd430c8"
        token = create_test_jwt(
            {"session_id": session_id, "thread_id": thread_id},
            private_key,
        )

        try:
            veris.parse_token(token, verify_signature=False)
            assert veris.session_id == session_id
            assert veris.thread_id == thread_id
        finally:
            veris.clear_context()

    def test_decode_invalid_token_raises_error(self):
        """Test that invalid token raises ValueError."""
        with pytest.raises(ValueError, match="Invalid JWT"):
            veris.parse_token("not-valid-jwt!!!", verify_signature=False)

    def test_decode_token_without_session_id(self):
        """Test that token without session_id still works (session_id is optional)."""
        private_key = generate_test_keypair()
        token = create_test_jwt({"thread_id": "thread-only"}, private_key)

        try:
            claims = veris.parse_token(token, verify_signature=False)
            assert claims.session_id is None
            assert claims.thread_id == "thread-only"
        finally:
            veris.clear_context()

    def test_clear_context_clears_all_values(self):
        """Test that clear_context clears session_id, thread_id, etc."""
        private_key = generate_test_keypair()
        token = create_test_jwt(
            {"session_id": "test-session", "thread_id": "test-thread"},
            private_key,
        )

        veris.parse_token(token, verify_signature=False)
        assert veris.session_id == "test-session"
        assert veris.thread_id == "test-thread"

        veris.clear_context()
        assert veris.session_id is None
        assert veris.thread_id is None

    def test_decode_token_with_additional_fields(self):
        """Test that additional fields in token don't break parsing."""
        private_key = generate_test_keypair()
        token = create_test_jwt(
            {
                "session_id": "test-session",
                "thread_id": "test-thread",
                "extra_field": "ignored",
                "another": 123,
            },
            private_key,
        )

        try:
            veris.parse_token(token, verify_signature=False)
            assert veris.session_id == "test-session"
            assert veris.thread_id == "test-thread"
        finally:
            veris.clear_context()


class TestParseToken:
    """Test parse_token method."""

    def test_parse_token_returns_claims(self):
        """Test that parse_token returns JWTClaims model."""
        private_key = generate_test_keypair()
        token = create_test_jwt(
            {
                "session_id": "sess_claims",
                "thread_id": "thread_claims",
                "api_url": "http://localhost/",
            },
            private_key,
        )

        try:
            claims = veris.parse_token(token, verify_signature=False)

            assert claims.session_id == "sess_claims"
            assert claims.thread_id == "thread_claims"
            assert claims.api_url == "http://localhost/"
        finally:
            veris.clear_context()
