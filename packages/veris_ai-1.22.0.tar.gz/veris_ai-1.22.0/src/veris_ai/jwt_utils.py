"""JWT utilities for Veris SDK.

This module provides JWT decoding and verification functionality,
including JWKS-based signature verification.
"""

import logging
from urllib.parse import urljoin

import httpx
import jwt
from jwt import PyJWKClient, PyJWKClientError
from pydantic import BaseModel

logger = logging.getLogger(__name__)

# Constants
JWKS_CACHE_TTL = 300  # 5 minutes

# Module-level cache for JWKS clients (keyed by URL)
_jwks_clients: dict[str, PyJWKClient] = {}


class JWTClaims(BaseModel, extra="ignore"):
    """Parsed JWT claims with typed fields."""

    session_id: str | None = None
    thread_id: str | None = None
    api_url: str | None = None
    logfire_token: str | None = None
    run_id: str | None = None
    sub: str | None = None
    iss: str | None = None
    aud: str | list[str] | None = None
    exp: int | None = None
    iat: int | None = None
    jti: str | None = None


def _get_jwks_client(jwks_url: str) -> PyJWKClient:
    """Get or create a cached JWKS client for the given URL."""
    if jwks_url not in _jwks_clients:
        _jwks_clients[jwks_url] = PyJWKClient(jwks_url, cache_keys=True, lifespan=JWKS_CACHE_TTL)
    return _jwks_clients[jwks_url]


def clear_jwks_cache() -> None:
    """Clear all cached JWKS clients."""
    _jwks_clients.clear()


def _verify_jwt_signature(token: str, iss: str) -> None:
    """Verify JWT signature using JWKS from the issuer.

    Args:
        token: The JWT token to verify.
        iss: The issuer URL to fetch JWKS from.

    Raises:
        ValueError: If verification fails.
    """
    # Build JWKS URL from issuer
    base_url = iss if iss.endswith("/") else iss + "/"
    jwks_url = urljoin(base_url, ".well-known/jwks.json")

    # Get signing key from JWKS
    try:
        client = _get_jwks_client(jwks_url)
        signing_key = client.get_signing_key_from_jwt(token)
    except PyJWKClientError as e:
        msg = f"Failed to get JWKS signing key: {e}"
        raise ValueError(msg) from e
    except httpx.HTTPError as e:
        msg = f"Failed to fetch JWKS: {e}"
        raise ValueError(msg) from e

    # Verify the token signature
    try:
        jwt.decode(token, signing_key.key, algorithms=["RS256"])
    except jwt.ExpiredSignatureError as e:
        raise ValueError("JWT has expired") from e
    except jwt.InvalidTokenError as e:
        msg = f"JWT verification failed: {e}"
        raise ValueError(msg) from e


def decode_token(
    token: str,
    *,
    verify_signature: bool = True,
) -> JWTClaims:
    """Decode a JWT token.

    Args:
        token: The JWT token to decode.
        verify_signature: Whether to verify JWT signature using JWKS (default True).

    Returns:
        Parsed JWT claims.

    Raises:
        ValueError: If the token is invalid or verification fails.
    """
    # Step 1: Decode the JWT
    try:
        claims = jwt.decode(token, options={"verify_signature": False})
    except jwt.InvalidTokenError as e:
        msg = f"Invalid JWT: {e}"
        raise ValueError(msg) from e

    # Step 2: Optionally verify signature
    if verify_signature and claims.get("iss"):
        _verify_jwt_signature(token, claims["iss"])

    return JWTClaims.model_validate(claims)
