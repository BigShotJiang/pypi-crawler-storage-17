# coding:utf-8

__project__ = "xmanage"
__version__ = "0.7.2"
__urlhome__ = "https://github.com/bondbox/xmanage/"
__description__ = "System and service management tool"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
