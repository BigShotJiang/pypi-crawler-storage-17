# -------------------------------------------------------------------------
#
#  Part of the CodeChecker project, under the Apache License v2.0 with
#  LLVM Exceptions. See LICENSE for license information.
#  SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
#
# -------------------------------------------------------------------------
"""
Base class for various source analyzers.
"""


from abc import ABCMeta, abstractmethod
import os
from semver.version import Version
import signal
import subprocess
import sys
import shlex

from typing import List, Optional

from codechecker_analyzer import analyzer_context
from codechecker_common.logger import get_logger

LOG = get_logger('analyzer')


class AnalyzerConfig:
    def __init__(self, option: str, documentation: str, value_type: type):
        self.option = option
        self.documentation = documentation
        self.value_type = value_type


class CheckerConfig:
    def __init__(self, checker: str, option: str, documentation: str):
        self.checker = checker
        self.option = option
        self.documentation = documentation


class SourceAnalyzer(metaclass=ABCMeta):
    """
    Base class for different source analyzers.
    """

    def __init__(self, config_handler, buildaction):
        self.__config_handler = config_handler
        self.__build_action = buildaction
        # Currently analyzed source file.
        self.source_file = ''

    @property
    def buildaction(self):
        return self.__build_action

    @property
    def config_handler(self):
        return self.__config_handler

    @abstractmethod
    def construct_analyzer_cmd(self, result_handler):
        raise NotImplementedError("Subclasses should implement this!")

    @classmethod
    def resolve_missing_binary(cls, configured_binary, environ):
        """
        In case of the configured binary for the analyzer is not found in the
        PATH, this method is used to find a callable binary.
        """
        raise NotImplementedError("Subclasses should implement this!")

    @classmethod
    @abstractmethod
    def get_binary_version(cls) -> Optional[Version]:
        """
        Return the version number of the binary that CodeChecker found, even
        if it's incompatible.
        """
        raise NotImplementedError("Subclasses should implement this!")

    @classmethod
    def is_binary_version_incompatible(cls) -> Optional[str]:
        """
        CodeChecker can only execute certain versions of analyzers.
        Returns a error object (an optional string). If the return value is
        None, the analyzer binary is compatible with the current CodeChecker
        version. Otherwise, the it should be a message describing the precise
        version mismatch.
        """
        raise NotImplementedError("Subclasses should implement this!")

    @classmethod
    def construct_config_handler(cls, args):
        """ Should return a subclass of AnalyzerConfigHandler."""
        raise NotImplementedError("Subclasses should implement this!")

    @abstractmethod
    def get_analyzer_mentioned_files(self, output):
        """
        Return a collection of files that were mentioned by the analyzer in
        its standard outputs, which should be analyzer_stdout or
        analyzer_stderr from a result handler.
        """
        raise NotImplementedError("Subclasses should implement this!")

    @abstractmethod
    def construct_result_handler(self, buildaction, report_output,
                                 skiplist_handler):
        """
        This method constructs the class that is responsible to handle the
        results of the analysis. The result should be a subclass of
        ResultHandler
        """
        raise NotImplementedError("Subclasses should implement this!")

    def analyze(self, analyzer_cmd, res_handler, proc_callback=None, env=None):
        """
        Run the analyzer.
        Don't specify the env unless really needed!
        The package internal or original env will be selected
        based on the location of the called binary.
        """
        LOG.debug('Running analyzer ...')

        LOG.debug_analyzer('\n%s',
                           ' '.join([shlex.quote(x) for x in analyzer_cmd]))

        res_handler.analyzer_cmd = analyzer_cmd
        try:
            ret_code, stdout, stderr \
                = SourceAnalyzer.run_proc(analyzer_cmd,
                                          res_handler.buildaction.directory,
                                          proc_callback,
                                          env)
            res_handler.analyzer_returncode = ret_code
            res_handler.analyzer_stdout = stdout
            res_handler.analyzer_stderr = stderr
            return res_handler

        except Exception as ex:
            LOG.error(ex)
            res_handler.analyzer_returncode = 1
            return res_handler

    @classmethod
    def get_analyzer_checkers(cls):
        """
        Return the checkers available in the analyzer.
        """
        raise NotImplementedError("Subclasses should implement this!")

    @classmethod
    def get_analyzer_config(cls) -> List[AnalyzerConfig]:
        return []

    @classmethod
    def get_checker_config(cls) -> List[CheckerConfig]:
        return []

    def post_analyze(self, result_handler):
        """
        Run immediately after the analyze function.
        """

    @staticmethod
    def run_proc(command, cwd=None, proc_callback=None, env=None):
        """
        Just run the given command and return the return code
        and the stdout and stderr outputs of the process.

        Don't specify the env unless really needed!
        The package internal or original env will be selected
        based on the location of the called binary.
        """

        def signal_handler(signum, _):
            # Clang does not kill its child processes, so I have to.
            try:
                g_pid = proc.pid
                os.killpg(g_pid, signal.SIGTERM)
            finally:
                sys.exit(128 + signum)

        signal.signal(signal.SIGINT, signal_handler)

        if not env:
            env = analyzer_context.get_context().get_env_for_bin(
                command[0])

        LOG.debug('\nexecuting:%s\n', command)
        LOG.debug('\nENV:\n')
        LOG.debug(env)

        proc = subprocess.Popen(
            command,
            bufsize=-1,
            env=env,
            preexec_fn=None if sys.platform == 'win32' else os.setsid,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True,
            encoding="utf-8",
            errors="ignore")

        # Send the created analyzer process' object if somebody wanted it.
        if proc_callback:
            proc_callback(proc)

        stdout, stderr = proc.communicate()
        return proc.returncode, stdout, stderr
