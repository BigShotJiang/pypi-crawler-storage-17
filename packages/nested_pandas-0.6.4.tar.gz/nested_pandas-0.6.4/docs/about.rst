About Nested-Pandas
===================


.. toctree::

    Internal Representation of Nested Data <about/internals>
    Performance Impact of Nested-Pandas <pre_executed/performance>