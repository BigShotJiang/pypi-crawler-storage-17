=========
.nest Series Accessor
=========
.. currentmodule:: nested_pandas

Constructor
~~~~~~~~~~~
.. autosummary::
   :toctree: api/

   NestSeriesAccessor

Functions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.. autosummary::
    :toctree: api/

    NestSeriesAccessor.to_lists
    NestSeriesAccessor.to_flat
    NestSeriesAccessor.to_flatten_inner
    NestSeriesAccessor.set_column
    NestSeriesAccessor.set_flat_column
    NestSeriesAccessor.set_list_column
    NestSeriesAccessor.set_filled_column
    NestSeriesAccessor.drop
    NestSeriesAccessor.query
