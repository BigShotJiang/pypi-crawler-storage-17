# phasma

<!--[![PyPI - Version](https://img.shields.io/pypi/v/behsan-text-to-vec.svg)](https://pypi.org/project/behsan-text-to-vec)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/behsan-text-to-vec.svg)](https://pypi.org/project/behsan-text-to-vec)
-->
-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install phasma
```

## License

`phasma` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
