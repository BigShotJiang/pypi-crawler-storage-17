"""Main entry point for Flow CLI."""

import sys

from flow.cli.app import main

if __name__ == "__main__":
    sys.exit(main())
