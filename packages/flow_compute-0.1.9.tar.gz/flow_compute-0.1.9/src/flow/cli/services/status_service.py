"""Service: status command logic and data retrieval.

Separates provider calls, filtering, and JSON shaping from CLI presentation.
"""

from __future__ import annotations
