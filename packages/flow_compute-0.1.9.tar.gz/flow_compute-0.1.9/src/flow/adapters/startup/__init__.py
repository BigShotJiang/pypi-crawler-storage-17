from __future__ import annotations

# Adapters startup namespace. The generic builder is exposed via builder.py.
