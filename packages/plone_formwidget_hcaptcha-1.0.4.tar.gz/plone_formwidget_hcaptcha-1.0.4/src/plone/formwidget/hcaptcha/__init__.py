# -*- coding: utf-8 -*-
from plone.formwidget.hcaptcha.validator import HCaptchaValidator  # noqa
from plone.formwidget.hcaptcha.widget import HCaptchaFieldWidget  # noqa
from plone.formwidget.hcaptcha.widget import HCaptchaWidget  # noqa
