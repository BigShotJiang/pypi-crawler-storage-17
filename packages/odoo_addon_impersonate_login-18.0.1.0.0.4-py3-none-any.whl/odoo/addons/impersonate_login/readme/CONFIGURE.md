The impersonating user must belong to group "Impersonate Users".
