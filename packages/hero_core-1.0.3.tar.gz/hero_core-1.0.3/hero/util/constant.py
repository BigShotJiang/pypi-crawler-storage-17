TASK_HISTORY_FILENAME = "hero_history.json"
TASK_ENHANCE_FILENAME = "hero_enhance.json"