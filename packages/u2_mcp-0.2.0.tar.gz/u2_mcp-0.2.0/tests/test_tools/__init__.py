"""Tests for MCP tools."""
