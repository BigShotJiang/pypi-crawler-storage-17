"""Packaged JSON Schemas for NetGraph.

Exposes schema files as importable package resources.
"""
