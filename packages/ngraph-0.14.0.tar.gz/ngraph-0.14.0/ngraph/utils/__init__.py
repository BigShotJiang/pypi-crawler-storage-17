"""Utility helpers used across NetGraph.

This package contains small, self-contained utilities that do not depend on
project internals. Keep modules minimal and focused.
"""

__all__: list[str] = []
