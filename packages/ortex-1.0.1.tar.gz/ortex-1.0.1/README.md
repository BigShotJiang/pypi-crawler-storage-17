# ORTEX Python SDK

Official Python SDK for the ORTEX Financial Data API. Access comprehensive financial data including short interest, stock prices, fundamentals, and more.

[![PyPI version](https://pypi-camo.freetls.fastly.net/8de881fe815a5540c08b12109ec90958fabe23ac/68747470733a2f2f62616467652e667572792e696f2f70792f6f727465782e737667)](https://pypi.org/project/ortex/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Features

- **Short Interest Data** - Shares on loan, utilization, cost to borrow, days to cover
- **Stock Prices** - OHLCV data with historical support
- **Stock Data** - Free float, shares outstanding
- **Fundamentals** - Income statements, balance sheets, cash flow, ratios
- **EU Short Interest** - European regulatory short positions
- **Market Data** - Earnings calendar, macro events, exchanges

## Installation

```bash
pip install ortex
```

## Quick Start

### Get Your API Key

Get your API key at **[app.ortex.com/apis](https://app.ortex.com/apis)**

### Set Up Authentication

```python
import ortex

# Option 1: Set API key directly
ortex.set_api_key("your-api-key")

# Option 2: Use environment variable
# export ORTEX_API_KEY="your-api-key"
# The SDK will automatically use this

# Option 3: Pass to each function
df = ortex.get_short_interest("NYSE", "AMC", api_key="your-api-key")
```

### Basic Usage

```python
import ortex

ortex.set_api_key("your-api-key")

# Get short interest data
df = ortex.get_short_interest("NYSE", "AMC")
print(df)

# Get historical short interest
df = ortex.get_short_interest("NYSE", "AMC", "2024-01-01", "2024-12-31")

# Get stock prices
df = ortex.get_price("NASDAQ", "AAPL", "2024-01-01", "2024-12-31")
```

## All Available Functions

### Short Interest

```python
# Short interest data for a stock
df = ortex.get_short_interest("NYSE", "AMC")
df = ortex.get_short_interest("NYSE", "AMC", "2024-01-01", "2024-12-31")

# Short interest for an index (S&P 500, NASDAQ 100, etc.)
df = ortex.get_index_short_interest("US-S 500")

# Share availability for shorting
df = ortex.get_short_availability("NYSE", "AMC")

# Cost to borrow (all loans or new loans)
df = ortex.get_cost_to_borrow("NYSE", "AMC")
df = ortex.get_cost_to_borrow("NYSE", "AMC", loan_type="new")

# Days to cover
df = ortex.get_days_to_cover("NYSE", "AMC")
```

### Index Short Data

```python
# Index-level short interest data
df = ortex.get_index_short_interest("US-S 500")
df = ortex.get_index_short_availability("US-S 500")
df = ortex.get_index_cost_to_borrow("US-S 500")
df = ortex.get_index_days_to_cover("US-S 500")
```

### Stock Prices

```python
# OHLCV price data
df = ortex.get_price("NASDAQ", "AAPL")
df = ortex.get_price("NASDAQ", "AAPL", "2024-01-01", "2024-12-31")

# Close price (alias for get_price)
df = ortex.get_close_price("NASDAQ", "AAPL")
```

### Stock Data

```python
# Free float shares (from_date is required)
df = ortex.get_free_float("NYSE", "F", "2024-01-01")

# Shares outstanding (uses free_float endpoint)
df = ortex.get_shares_outstanding("NYSE", "F", "2024-01-01")
```

### Fundamentals

```python
# Income statement
df = ortex.get_income_statement("NYSE", "F", "2024Q3")

# Balance sheet
df = ortex.get_balance_sheet("NYSE", "F", "2024Q3")

# Cash flow statement
df = ortex.get_cash_flow("NYSE", "F", "2024Q3")

# Financial ratios
df = ortex.get_financial_ratios("NYSE", "F", "2024Q3")

# Fundamentals summary
df = ortex.get_fundamentals_summary("NYSE", "F", "2024Q3")

# Valuation metrics
df = ortex.get_valuation("NYSE", "F", "2024Q3")
```

### EU Short Interest

```python
# EU short positions (individual holders)
df = ortex.get_eu_short_positions("XETR", "SAP")

# EU short positions at a specific date
df = ortex.get_eu_short_positions("XETR", "SAP", "2024-12-01")

# EU short positions history
df = ortex.get_eu_short_positions_history("XETR", "SAP", "2024-01-01", "2024-12-31")

# Total EU short interest
df = ortex.get_eu_short_total("XETR", "SAP")
```

### Market Data

```python
# Earnings calendar
df = ortex.get_earnings()  # Upcoming
df = ortex.get_earnings("2024-12-01", "2024-12-31")  # Historical

# List of exchanges
df = ortex.get_exchanges()
df = ortex.get_exchanges("United States")

# Macro economic events
df = ortex.get_macro_events("US")
df = ortex.get_macro_events("US", "2024-12-01", "2024-12-15")
```

## Using the Client Directly

For more control, use the `OrtexClient` class:

```python
from ortex import OrtexClient

# Create client
client = OrtexClient(api_key="your-api-key")

# Make requests
data = client.get("NYSE/AMC/short_interest")

# Use as context manager
with OrtexClient(api_key="your-api-key") as client:
    data = client.get("stock/NASDAQ/AAPL/closing_prices")
```

## Date Handling

The SDK accepts dates in multiple formats:

```python
from datetime import date, datetime

# String format (YYYY-MM-DD)
df = ortex.get_short_interest("NYSE", "AMC", "2024-01-01", "2024-12-31")

# Python date objects
df = ortex.get_short_interest("NYSE", "AMC", date(2024, 1, 1), date(2024, 12, 31))

# Python datetime objects
df = ortex.get_short_interest("NYSE", "AMC", datetime(2024, 1, 1), datetime(2024, 12, 31))
```

## Error Handling

The SDK provides specific exception types:

```python
import ortex
from ortex import (
    OrtexError,
    AuthenticationError,
    RateLimitError,
    NotFoundError,
    ValidationError,
    ServerError,
)

try:
    df = ortex.get_short_interest("NYSE", "INVALID")
except AuthenticationError:
    print("Invalid API key")
except RateLimitError as e:
    print(f"Rate limited. Retry after {e.retry_after} seconds")
except NotFoundError:
    print("Stock not found")
except ValidationError as e:
    print(f"Invalid parameters: {e}")
except ServerError:
    print("ORTEX server error")
except OrtexError as e:
    print(f"API error: {e}")
```

## Rate Limiting

The SDK automatically handles rate limiting with exponential backoff:

- Automatically retries on 429 (rate limit) responses
- Uses exponential backoff (1s, 2s, 4s, 8s, up to 60s)
- Maximum 5 retry attempts by default

Configure retry behavior:

```python
from ortex import OrtexClient

client = OrtexClient(
    api_key="your-api-key",
    timeout=60,      # Request timeout in seconds
    max_retries=10,  # Maximum retry attempts
)
```

## All Return Values are DataFrames

All functions return pandas DataFrames for easy analysis:

```python
import ortex

df = ortex.get_short_interest("NYSE", "AMC", "2024-01-01", "2024-12-31")

# Standard pandas operations
print(df.columns)
print(df.describe())
df.to_csv("short_interest.csv")

# Filter and analyze
high_utilization = df[df["utilization"] > 90]
```

## Documentation

- **Full API Documentation**: [docs.ortex.com](https://docs.ortex.com)
- **Get API Key**: [app.ortex.com/apis](https://app.ortex.com/apis)
- **Support**: support@ortex.com

## Requirements

- Python 3.9+
- pandas >= 2.0.0
- requests >= 2.31.0
- tenacity >= 8.2.0

## License

MIT License - ORTEX Technologies LTD

## Version

1.0.0
