"""ORTEX API functions for retrieving financial data.

This module provides high-level functions for accessing all ORTEX API endpoints.
All functions return pandas DataFrames for easy data manipulation and analysis.
"""

from __future__ import annotations

import os
from datetime import date, datetime
from typing import Any

import pandas as pd

from .client import (
    OrtexClient,
    normalize_date,
    normalize_exchange,
    normalize_ticker,
    to_dataframe,
)
from .exceptions import AuthenticationError

# Global client instance for convenience
_client: OrtexClient | None = None


def set_api_key(api_key: str) -> None:
    """Set the global API key for all ORTEX functions.

    This function sets the API key that will be used by all module-level
    functions. Alternatively, you can set the ORTEX_API_KEY environment
    variable or pass an api_key to each function.

    Args:
        api_key: Your ORTEX API key from https://app.ortex.com/apis

    Example:
        >>> import ortex
        >>> ortex.set_api_key("your-api-key")
        >>> df = ortex.get_short_interest("NYSE", "AMC")
    """
    global _client
    _client = OrtexClient(api_key=api_key)


def get_client(api_key: str | None = None) -> OrtexClient:
    """Get or create an ORTEX client instance.

    Args:
        api_key: Optional API key. If not provided, uses global client
            or ORTEX_API_KEY environment variable.

    Returns:
        OrtexClient instance.

    Raises:
        AuthenticationError: If no API key is available.
    """
    global _client

    if api_key:
        return OrtexClient(api_key=api_key)

    if _client is not None:
        return _client

    # Try environment variable
    env_key = os.environ.get("ORTEX_API_KEY")
    if env_key:
        _client = OrtexClient(api_key=env_key)
        return _client

    raise AuthenticationError(
        "No API key configured. Use ortex.set_api_key('your-key'), "
        "pass api_key parameter, or set ORTEX_API_KEY environment variable. "
        "Get your API key at https://app.ortex.com/apis"
    )


# =============================================================================
# Short Interest Functions
# =============================================================================


def get_short_interest(
    exchange: str,
    ticker: str,
    from_date: str | date | datetime | None = None,
    to_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get short interest data for a stock.

    Retrieves short interest metrics including shares on loan, utilization,
    and short interest percentage of free float.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol (e.g., "AMC", "AAPL").
        from_date: Start date for historical data.
        to_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with short interest data.

    Example:
        >>> df = ortex.get_short_interest("NYSE", "AMC")
        >>> df = ortex.get_short_interest("NYSE", "AMC", "2024-01-01", "2024-12-31")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"{exchange}/{ticker}/short_interest"
    params: dict[str, Any] = {}
    if from_date:
        params["from_date"] = normalize_date(from_date)
    if to_date:
        params["to_date"] = normalize_date(to_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_index_short_interest(
    index: str = "US-S 500",
    date_val: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get short interest data for an index.

    Retrieves short interest metrics for multiple stocks in an index.

    Args:
        index: Index name - "US-S 500", "US-N 100", "UK Top 100", "Europe Top 600".
        date_val: Date for the data. If None, returns latest.
        api_key: Optional API key override.

    Returns:
        DataFrame with index short interest data.

    Example:
        >>> df = ortex.get_index_short_interest("US-S 500")
    """
    client = get_client(api_key)

    endpoint = "index/short_interest"
    params: dict[str, Any] = {"index": index}
    if date_val:
        params["date"] = normalize_date(date_val)

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


def get_short_availability(
    exchange: str,
    ticker: str,
    from_date: str | date | datetime | None = None,
    to_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get share availability for shorting.

    Retrieves the number of shares available to borrow for short selling.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        from_date: Start date for historical data.
        to_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with availability data.

    Example:
        >>> df = ortex.get_short_availability("NYSE", "AMC")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/availability"
    params: dict[str, Any] = {}
    if from_date:
        params["from_date"] = normalize_date(from_date)
    if to_date:
        params["to_date"] = normalize_date(to_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_cost_to_borrow(
    exchange: str,
    ticker: str,
    loan_type: str = "all",
    from_date: str | date | datetime | None = None,
    to_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get cost to borrow data for short selling.

    Retrieves the annualized cost to borrow shares for short selling.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        loan_type: Type of loans - "all" for all loans, "new" for new loans only.
        from_date: Start date for historical data.
        to_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with cost to borrow data.

    Example:
        >>> df = ortex.get_cost_to_borrow("NYSE", "AMC")
        >>> df = ortex.get_cost_to_borrow("NYSE", "AMC", loan_type="new")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    loan_type = loan_type.lower()
    if loan_type not in ("all", "new"):
        loan_type = "all"

    endpoint = f"stock/{exchange}/{ticker}/ctb/{loan_type}"
    params: dict[str, Any] = {}
    if from_date:
        params["from_date"] = normalize_date(from_date)
    if to_date:
        params["to_date"] = normalize_date(to_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_days_to_cover(
    exchange: str,
    ticker: str,
    from_date: str | date | datetime | None = None,
    to_date: str | date | datetime | None = None,
    period: str = "1m",
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get days to cover data.

    Days to cover represents the number of days it would take to cover
    all short positions based on average daily trading volume.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        from_date: Start date for historical data.
        to_date: End date for historical data.
        period: Volume averaging period - "1w", "2w", "1m", "3m".
        api_key: Optional API key override.

    Returns:
        DataFrame with days to cover data.

    Example:
        >>> df = ortex.get_days_to_cover("NYSE", "AMC")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/dtc"
    params: dict[str, Any] = {"period": period}
    if from_date:
        params["from_date"] = normalize_date(from_date)
    if to_date:
        params["to_date"] = normalize_date(to_date)

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


# =============================================================================
# Price Functions
# =============================================================================


def get_price(
    exchange: str,
    ticker: str,
    from_date: str | date | datetime | None = None,
    to_date: str | date | datetime | None = None,
    volume_from_all_exchanges: bool = False,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get OHLCV price data for a stock.

    Retrieves open, high, low, close prices and volume data.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        from_date: Start date for historical data.
        to_date: End date for historical data.
        volume_from_all_exchanges: If True, include volume from all exchanges.
        api_key: Optional API key override.

    Returns:
        DataFrame with OHLCV data.

    Example:
        >>> df = ortex.get_price("NASDAQ", "AAPL")
        >>> df = ortex.get_price("NASDAQ", "AAPL", "2024-01-01", "2024-12-31")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/closing_prices"
    params: dict[str, Any] = {}
    if from_date:
        params["from_date"] = normalize_date(from_date)
    if to_date:
        params["to_date"] = normalize_date(to_date)
    if volume_from_all_exchanges:
        params["volume_from_all_exchanges"] = "true"

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_close_price(
    exchange: str,
    ticker: str,
    from_date: str | date | datetime | None = None,
    to_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get closing price data for a stock.

    This is an alias for get_price() - both return OHLCV data.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        from_date: Start date for historical data.
        to_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with OHLCV data.

    Example:
        >>> df = ortex.get_close_price("NASDAQ", "AAPL")
    """
    return get_price(exchange, ticker, from_date, to_date, api_key=api_key)


# =============================================================================
# Stock Data Functions
# =============================================================================


def get_free_float(
    exchange: str,
    ticker: str,
    from_date: str | date | datetime,
    to_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get free float data for a stock.

    Free float represents the number of shares available for public trading.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        from_date: Start date (required).
        to_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with free float data.

    Example:
        >>> df = ortex.get_free_float("NYSE", "F", "2024-01-01")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/free_float"
    params: dict[str, Any] = {"from_date": normalize_date(from_date)}
    if to_date:
        params["to_date"] = normalize_date(to_date)

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


def get_shares_outstanding(
    exchange: str,
    ticker: str,
    from_date: str | date | datetime,
    to_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get shares outstanding data for a stock.

    This uses the free_float endpoint which includes shares outstanding.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        from_date: Start date (required).
        to_date: End date for historical data.
        api_key: Optional API key override.

    Returns:
        DataFrame with shares outstanding data.

    Example:
        >>> df = ortex.get_shares_outstanding("NYSE", "F", "2024-01-01")
    """
    return get_free_float(exchange, ticker, from_date, to_date, api_key=api_key)


# =============================================================================
# Fundamentals Functions
# =============================================================================


def get_income_statement(
    exchange: str,
    ticker: str,
    period: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get income statement data.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        period: Reporting period (e.g., "2024Q3" for Q3 2024, "2024" for annual).
        api_key: Optional API key override.

    Returns:
        DataFrame with income statement data.

    Example:
        >>> df = ortex.get_income_statement("NYSE", "F", "2024Q3")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/fundamentals/income"
    params: dict[str, Any] = {"period": period}

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


def get_balance_sheet(
    exchange: str,
    ticker: str,
    period: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get balance sheet data.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        period: Reporting period (e.g., "2024Q3" for Q3 2024).
        api_key: Optional API key override.

    Returns:
        DataFrame with balance sheet data.

    Example:
        >>> df = ortex.get_balance_sheet("NYSE", "F", "2024Q3")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/fundamentals/balance"
    params: dict[str, Any] = {"period": period}

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


def get_cash_flow(
    exchange: str,
    ticker: str,
    period: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get cash flow statement data.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        period: Reporting period (e.g., "2024Q3" for Q3 2024).
        api_key: Optional API key override.

    Returns:
        DataFrame with cash flow data.

    Example:
        >>> df = ortex.get_cash_flow("NYSE", "F", "2024Q3")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/fundamentals/cash"
    params: dict[str, Any] = {"period": period}

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


def get_financial_ratios(
    exchange: str,
    ticker: str,
    period: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get financial ratios.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        period: Reporting period (e.g., "2024Q3" for Q3 2024).
        api_key: Optional API key override.

    Returns:
        DataFrame with financial ratios.

    Example:
        >>> df = ortex.get_financial_ratios("NYSE", "F", "2024Q3")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/fundamentals/ratios"
    params: dict[str, Any] = {"period": period}

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


def get_fundamentals_summary(
    exchange: str,
    ticker: str,
    period: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get fundamentals summary.

    Returns a comprehensive summary of key fundamental metrics.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        period: Reporting period (e.g., "2024Q3" for Q3 2024).
        api_key: Optional API key override.

    Returns:
        DataFrame with fundamentals summary.

    Example:
        >>> df = ortex.get_fundamentals_summary("NYSE", "F", "2024Q3")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/fundamentals/summary"
    params: dict[str, Any] = {"period": period}

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


def get_valuation(
    exchange: str,
    ticker: str,
    period: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get valuation metrics.

    Args:
        exchange: Exchange code (e.g., "NYSE", "NASDAQ").
        ticker: Stock ticker symbol.
        period: Reporting period (e.g., "2024Q3" for Q3 2024).
        api_key: Optional API key override.

    Returns:
        DataFrame with valuation metrics.

    Example:
        >>> df = ortex.get_valuation("NYSE", "F", "2024Q3")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/fundamentals/valuation"
    params: dict[str, Any] = {"period": period}

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


# =============================================================================
# European Short Interest Functions
# =============================================================================


def get_eu_short_positions(
    exchange: str,
    ticker: str,
    date_val: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get EU regulatory short positions.

    Returns disclosed short positions from EU regulatory filings.

    Args:
        exchange: Exchange code (e.g., "XETR" for Germany).
        ticker: Stock ticker symbol.
        date_val: Date for positions. If None, returns latest.
        api_key: Optional API key override.

    Returns:
        DataFrame with EU short position data.

    Example:
        >>> df = ortex.get_eu_short_positions("XETR", "SAP")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/european_short_interest_filings/open_positions_at"
    params: dict[str, Any] = {}
    if date_val:
        params["date"] = normalize_date(date_val)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_eu_short_positions_history(
    exchange: str,
    ticker: str,
    from_date: str | date | datetime,
    to_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get EU regulatory short positions history.

    Returns short interest changes over a time period from EU filings.

    Args:
        exchange: Exchange code (e.g., "XETR" for Germany).
        ticker: Stock ticker symbol.
        from_date: Start date.
        to_date: End date.
        api_key: Optional API key override.

    Returns:
        DataFrame with EU short position history.

    Example:
        >>> df = ortex.get_eu_short_positions_history("XETR", "SAP", "2024-01-01")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/european_short_interest_filings/positions_in_range"
    params: dict[str, Any] = {"from_date": normalize_date(from_date)}
    if to_date:
        params["to_date"] = normalize_date(to_date)

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


def get_eu_short_total(
    exchange: str,
    ticker: str,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get total EU regulatory short interest.

    Returns the aggregate short position from EU regulatory filings.

    Args:
        exchange: Exchange code (e.g., "XETR" for Germany).
        ticker: Stock ticker symbol.
        api_key: Optional API key override.

    Returns:
        DataFrame with total EU short interest.

    Example:
        >>> df = ortex.get_eu_short_total("XETR", "SAP")
    """
    client = get_client(api_key)
    exchange = normalize_exchange(exchange)
    ticker = normalize_ticker(ticker)

    endpoint = f"stock/{exchange}/{ticker}/european_short_interest_filings/total_open_positions"

    data = client.get(endpoint)
    return to_dataframe(data)


# =============================================================================
# Market Data Functions
# =============================================================================


def get_earnings(
    from_date: str | date | datetime | None = None,
    to_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get earnings calendar.

    Returns upcoming or historical earnings announcements.

    Args:
        from_date: Start date.
        to_date: End date.
        api_key: Optional API key override.

    Returns:
        DataFrame with earnings data.

    Example:
        >>> df = ortex.get_earnings()  # Upcoming
        >>> df = ortex.get_earnings("2024-12-01", "2024-12-31")  # Historical
    """
    client = get_client(api_key)

    endpoint = "earnings"
    params: dict[str, Any] = {}
    if from_date:
        params["from_date"] = normalize_date(from_date)
    if to_date:
        params["to_date"] = normalize_date(to_date)

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_exchanges(
    country: str | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get list of supported exchanges.

    Args:
        country: Optional country filter (e.g., "United States").
        api_key: Optional API key override.

    Returns:
        DataFrame with exchange information.

    Example:
        >>> df = ortex.get_exchanges()
        >>> df = ortex.get_exchanges("United States")
    """
    client = get_client(api_key)

    endpoint = "generics/exchanges"
    params: dict[str, Any] = {}
    if country:
        params["country_name"] = country

    data = client.get(endpoint, params=params if params else None)
    return to_dataframe(data)


def get_macro_events(
    country: str,
    from_date: str | date | datetime | None = None,
    to_date: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get macroeconomic events calendar.

    Args:
        country: Country ISO-2 code (e.g., "US", "GB", "DE").
        from_date: Start date.
        to_date: End date.
        api_key: Optional API key override.

    Returns:
        DataFrame with macro events.

    Example:
        >>> df = ortex.get_macro_events("US")
        >>> df = ortex.get_macro_events("US", "2024-12-01", "2024-12-15")
    """
    client = get_client(api_key)
    country = country.upper()

    endpoint = "macro_events"
    params: dict[str, Any] = {"country": country}
    if from_date:
        params["from_date"] = normalize_date(from_date)
    if to_date:
        params["to_date"] = normalize_date(to_date)

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


# =============================================================================
# Index Data Functions
# =============================================================================


def get_index_short_availability(
    index: str = "US-S 500",
    date_val: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get short availability data for an index.

    Args:
        index: Index name - "US-S 500", "US-N 100", "UK Top 100", "Europe Top 600".
        date_val: Date for the data. If None, returns latest.
        api_key: Optional API key override.

    Returns:
        DataFrame with index short availability data.

    Example:
        >>> df = ortex.get_index_short_availability("US-S 500")
    """
    client = get_client(api_key)

    endpoint = "index/short_availability"
    params: dict[str, Any] = {"index": index}
    if date_val:
        params["date"] = normalize_date(date_val)

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


def get_index_cost_to_borrow(
    index: str = "US-S 500",
    date_val: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get cost to borrow data for an index.

    Args:
        index: Index name - "US-S 500", "US-N 100", "UK Top 100", "Europe Top 600".
        date_val: Date for the data. If None, returns latest.
        api_key: Optional API key override.

    Returns:
        DataFrame with index cost to borrow data.

    Example:
        >>> df = ortex.get_index_cost_to_borrow("US-S 500")
    """
    client = get_client(api_key)

    endpoint = "index/short_ctb"
    params: dict[str, Any] = {"index": index}
    if date_val:
        params["date"] = normalize_date(date_val)

    data = client.get(endpoint, params=params)
    return to_dataframe(data)


def get_index_days_to_cover(
    index: str = "US-S 500",
    date_val: str | date | datetime | None = None,
    api_key: str | None = None,
) -> pd.DataFrame:
    """Get days to cover data for an index.

    Args:
        index: Index name - "US-S 500", "US-N 100", "UK Top 100", "Europe Top 600".
        date_val: Date for the data. If None, returns latest.
        api_key: Optional API key override.

    Returns:
        DataFrame with index days to cover data.

    Example:
        >>> df = ortex.get_index_days_to_cover("US-S 500")
    """
    client = get_client(api_key)

    endpoint = "index/short_dtc"
    params: dict[str, Any] = {"index": index}
    if date_val:
        params["date"] = normalize_date(date_val)

    data = client.get(endpoint, params=params)
    return to_dataframe(data)
