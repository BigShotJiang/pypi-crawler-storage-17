# Authors & Contributors

This file lists the main contributors to the **Modalyzer** project and their roles.

- **Mehrab Nikoofaraz** – Lead Developer  

- **Amir Shamsaddinlou** – Developer & Tester  

- **Dario De Domenico** – Scientific Supervisor  

- **Monica Longo** – Consultant