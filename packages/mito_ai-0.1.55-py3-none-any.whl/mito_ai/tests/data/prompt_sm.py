# Copyright (c) Saga Inc.
# Distributed under the terms of the GNU Affero General Public License v3.0 License.

prompt_sm = """
Can you create a function that perfoms fizz buzz. It should take an integer n and return a list of strings.
"""