"""
Test suite for fivedreg package.
"""



