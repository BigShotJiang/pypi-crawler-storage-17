from .NN import LightweightNN

__all__ = ['LightweightNN']