# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.10.1
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x02\xd0\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 512 512\x22><!-\
-! Font Awesome \
Pro 6.1.1 by @fo\
ntawesome - http\
s://fontawesome.\
com License - ht\
tps://fontawesom\
e.com/license (C\
ommercial Licens\
e) Copyright 202\
2 Fonticons, Inc\
. --><path d=\x22M6\
4 400C64 408.8 7\
1.16 416 80 416H\
480C497.7 416 51\
2 430.3 512 448C\
512 465.7 497.7 \
480 480 480H80C3\
5.82 480 0 444.2\
 0 400V64C0 46.3\
3 14.33 32 32 32\
C49.67 32 64 46.\
33 64 64V400zM34\
2.6 278.6C330.1 \
291.1 309.9 291.\
1 297.4 278.6L24\
0 221.3L150.6 31\
0.6C138.1 323.1 \
117.9 323.1 105.\
4 310.6C92.88 29\
8.1 92.88 277.9 \
105.4 265.4L217.\
4 153.4C229.9 14\
0.9 250.1 140.9 \
262.6 153.4L320 \
210.7L425.4 105.\
4C437.9 92.88 45\
8.1 92.88 470.6 \
105.4C483.1 117.\
9 483.1 138.1 47\
0.6 150.6L342.6 \
278.6z\x22/></svg>\
\x00\x00\x01\xf7\
<\
svg aria-hidden=\
\x22true\x22 focusable\
=\x22false\x22 data-pr\
efix=\x22fas\x22 data-\
icon=\x22arrow-alt-\
circle-left\x22 cla\
ss=\x22svg-inline--\
fa fa-arrow-alt-\
circle-left fa-w\
-16\x22 role=\x22img\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22 viewBox=\x220 0 \
512 512\x22><path f\
ill=\x22currentColo\
r\x22 d=\x22M256 504C1\
19 504 8 393 8 2\
56S119 8 256 8s2\
48 111 248 248-1\
11 248-248 248zm\
116-292H256v-70.\
9c0-10.7-13-16.1\
-20.5-8.5L121.2 \
247.5c-4.7 4.7-4\
.7 12.2 0 16.9l1\
14.3 114.9c7.6 7\
.6 20.5 2.2 20.5\
-8.5V300h116c6.6\
 0 12-5.4 12-12v\
-64c0-6.6-5.4-12\
-12-12z\x22></path>\
</svg>\
\x00\x00\x02\xdf\
<\
svg aria-hidden=\
\x22true\x22 focusable\
=\x22false\x22 data-pr\
efix=\x22fas\x22 data-\
icon=\x22edit\x22 clas\
s=\x22svg-inline--f\
a fa-edit fa-w-1\
8\x22 role=\x22img\x22 xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
 viewBox=\x220 0 57\
6 512\x22><path fil\
l=\x22currentColor\x22\
 d=\x22M402.6 83.2l\
90.2 90.2c3.8 3.\
8 3.8 10 0 13.8L\
274.4 405.6l-92.\
8 10.3c-12.4 1.4\
-22.9-9.1-21.5-2\
1.5l10.3-92.8L38\
8.8 83.2c3.8-3.8\
 10-3.8 13.8 0zm\
162-22.9l-48.8-4\
8.8c-15.2-15.2-3\
9.9-15.2-55.2 0l\
-35.4 35.4c-3.8 \
3.8-3.8 10 0 13.\
8l90.2 90.2c3.8 \
3.8 10 3.8 13.8 \
0l35.4-35.4c15.2\
-15.3 15.2-40 0-\
55.2zM384 346.2V\
448H64V128h229.8\
c3.2 0 6.2-1.3 8\
.5-3.5l40-40c7.6\
-7.6 2.2-20.5-8.\
5-20.5H48C21.5 6\
4 0 85.5 0 112v3\
52c0 26.5 21.5 4\
8 48 48h352c26.5\
 0 48-21.5 48-48\
V306.2c0-10.7-12\
.9-16-20.5-8.5l-\
40 40c-2.2 2.3-3\
.5 5.3-3.5 8.5z\x22\
></path></svg>\
\x00\x00\x01\xf3\
<\
svg aria-hidden=\
\x22true\x22 focusable\
=\x22false\x22 data-pr\
efix=\x22fas\x22 data-\
icon=\x22arrow-alt-\
circle-right\x22 cl\
ass=\x22svg-inline-\
-fa fa-arrow-alt\
-circle-right fa\
-w-16\x22 role=\x22img\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22 viewBox=\x220 \
0 512 512\x22><path\
 fill=\x22currentCo\
lor\x22 d=\x22M256 8c1\
37 0 248 111 248\
 248S393 504 256\
 504 8 393 8 256\
 119 8 256 8zM14\
0 300h116v70.9c0\
 10.7 13 16.1 20\
.5 8.5l114.3-114\
.9c4.7-4.7 4.7-1\
2.2 0-16.9l-114.\
3-115c-7.6-7.6-2\
0.5-2.2-20.5 8.5\
V212H140c-6.6 0-\
12 5.4-12 12v64c\
0 6.6 5.4 12 12 \
12z\x22></path></sv\
g>\
\x00\x00\x02\xff\
<\
svg aria-hidden=\
\x22true\x22 focusable\
=\x22false\x22 data-pr\
efix=\x22fas\x22 data-\
icon=\x22undo\x22 clas\
s=\x22svg-inline--f\
a fa-undo fa-w-1\
6\x22 role=\x22img\x22 xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
 viewBox=\x220 0 51\
2 512\x22><path fil\
l=\x22currentColor\x22\
 d=\x22M212.333 224\
.333H12c-6.627 0\
-12-5.373-12-12V\
12C0 5.373 5.373\
 0 12 0h48c6.627\
 0 12 5.373 12 1\
2v78.112C117.773\
 39.279 184.26 7\
.47 258.175 8.00\
7c136.906.994 24\
6.448 111.623 24\
6.157 248.532C50\
4.041 393.258 39\
3.12 504 256.333\
 504c-64.089 0-1\
22.496-24.313-16\
6.51-64.215-5.09\
9-4.622-5.334-12\
.554-.467-17.42l\
33.967-33.967c4.\
474-4.474 11.662\
-4.717 16.401-.5\
25C170.76 415.33\
6 211.58 432 256\
.333 432c97.268 \
0 176-78.716 176\
-176 0-97.267-78\
.716-176-176-176\
-58.496 0-110.28\
 28.476-142.274 \
72.333h98.274c6.\
627 0 12 5.373 1\
2 12v48c0 6.627-\
5.373 12-12 12z\x22\
></path></svg>\
\x00\x00\x03|\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 448 512\x22><!-\
-! Font Awesome \
Pro 6.1.1 by @fo\
ntawesome - http\
s://fontawesome.\
com License - ht\
tps://fontawesom\
e.com/license (C\
ommercial Licens\
e) Copyright 202\
2 Fonticons, Inc\
. --><path d=\x22M2\
56 64C256 46.33 \
270.3 32 288 32H\
415.1C415.1 32 4\
15.1 32 415.1 32\
C420.3 32 424.5 \
32.86 428.2 34.4\
3C431.1 35.98 43\
5.5 38.27 438.6 \
41.3C438.6 41.35\
 438.6 41.4 438.\
7 41.44C444.9 47\
.66 447.1 55.78 \
448 63.9C448 63.\
94 448 63.97 448\
 64V192C448 209.\
7 433.7 224 416 \
224C398.3 224 38\
4 209.7 384 192V\
141.3L214.6 310.\
6C202.1 323.1 18\
1.9 323.1 169.4 \
310.6C156.9 298.\
1 156.9 277.9 16\
9.4 265.4L338.7 \
96H288C270.3 96 \
256 81.67 256 64\
V64zM0 128C0 92.\
65 28.65 64 64 6\
4H160C177.7 64 1\
92 78.33 192 96C\
192 113.7 177.7 \
128 160 128H64V4\
16H352V320C352 3\
02.3 366.3 288 3\
84 288C401.7 288\
 416 302.3 416 3\
20V416C416 451.3\
 387.3 480 352 4\
80H64C28.65 480 \
0 451.3 0 416V12\
8z\x22/></svg>\
\x00\x00\x01\xed\
<\
svg aria-hidden=\
\x22true\x22 focusable\
=\x22false\x22 data-pr\
efix=\x22fas\x22 data-\
icon=\x22arrow-alt-\
circle-up\x22 class\
=\x22svg-inline--fa\
 fa-arrow-alt-ci\
rcle-up fa-w-16\x22\
 role=\x22img\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 v\
iewBox=\x220 0 512 \
512\x22><path fill=\
\x22currentColor\x22 d\
=\x22M8 256C8 119 1\
19 8 256 8s248 1\
11 248 248-111 2\
48-248 248S8 393\
 8 256zm292 116V\
256h70.9c10.7 0 \
16.1-13 8.5-20.5\
L264.5 121.2c-4.\
7-4.7-12.2-4.7-1\
6.9 0l-115 114.3\
c-7.6 7.6-2.2 20\
.5 8.5 20.5H212v\
116c0 6.6 5.4 12\
 12 12h64c6.6 0 \
12-5.4 12-12z\x22><\
/path></svg>\
\x00\x00\x02A\
<\
svg aria-hidden=\
\x22true\x22 focusable\
=\x22false\x22 data-pr\
efix=\x22fas\x22 data-\
icon=\x22search\x22 cl\
ass=\x22svg-inline-\
-fa fa-search fa\
-w-16\x22 role=\x22img\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22 viewBox=\x220 \
0 512 512\x22><path\
 fill=\x22currentCo\
lor\x22 d=\x22M505 442\
.7L405.3 343c-4.\
5-4.5-10.6-7-17-\
7H372c27.6-35.3 \
44-79.7 44-128C4\
16 93.1 322.9 0 \
208 0S0 93.1 0 2\
08s93.1 208 208 \
208c48.3 0 92.7-\
16.4 128-44v16.3\
c0 6.4 2.5 12.5 \
7 17l99.7 99.7c9\
.4 9.4 24.6 9.4 \
33.9 0l28.3-28.3\
c9.4-9.4 9.4-24.\
6.1-34zM208 336c\
-70.7 0-128-57.2\
-128-128 0-70.7 \
57.2-128 128-128\
 70.7 0 128 57.2\
 128 128 0 70.7-\
57.2 128-128 128\
z\x22></path></svg>\
\
\x00\x00\x01\xf6\
<\
svg aria-hidden=\
\x22true\x22 focusable\
=\x22false\x22 data-pr\
efix=\x22fas\x22 data-\
icon=\x22arrow-alt-\
circle-down\x22 cla\
ss=\x22svg-inline--\
fa fa-arrow-alt-\
circle-down fa-w\
-16\x22 role=\x22img\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22 viewBox=\x220 0 \
512 512\x22><path f\
ill=\x22currentColo\
r\x22 d=\x22M504 256c0\
 137-111 248-248\
 248S8 393 8 256\
 119 8 256 8s248\
 111 248 248zM21\
2 140v116h-70.9c\
-10.7 0-16.1 13-\
8.5 20.5l114.9 1\
14.3c4.7 4.7 12.\
2 4.7 16.9 0l114\
.9-114.3c7.6-7.6\
 2.2-20.5-8.5-20\
.5H300V140c0-6.6\
-5.4-12-12-12h-6\
4c-6.6 0-12 5.4-\
12 12z\x22></path><\
/svg>\
"

qt_resource_name = b"\
\x00\x09\
\x0alxC\
\x00r\
\x00e\x00s\x00o\x00u\x00r\x00c\x00e\x00s\
\x00\x14\
\x08Y\xc3\xc7\
\x00c\
\x00h\x00a\x00r\x00t\x00-\x00l\x00i\x00n\x00e\x00-\x00s\x00o\x00l\x00i\x00d\x00.\
\x00s\x00v\x00g\
\x00\x1f\
\x0f\xfe\xa9\xe7\
\x00a\
\x00r\x00r\x00o\x00w\x00-\x00a\x00l\x00t\x00-\x00c\x00i\x00r\x00c\x00l\x00e\x00-\
\x00l\x00e\x00f\x00t\x00-\x00s\x00o\x00l\x00i\x00d\x00.\x00s\x00v\x00g\
\x00\x0e\
\x04\xf9\xd4g\
\x00e\
\x00d\x00i\x00t\x00-\x00s\x00o\x00l\x00i\x00d\x00.\x00s\x00v\x00g\
\x00 \
\x03o8\xa7\
\x00a\
\x00r\x00r\x00o\x00w\x00-\x00a\x00l\x00t\x00-\x00c\x00i\x00r\x00c\x00l\x00e\x00-\
\x00r\x00i\x00g\x00h\x00t\x00-\x00s\x00o\x00l\x00i\x00d\x00.\x00s\x00v\x00g\
\x00\x0e\
\x0b\x93\xc9\x07\
\x00u\
\x00n\x00d\x00o\x00-\x00s\x00o\x00l\x00i\x00d\x00.\x00s\x00v\x00g\
\x00$\
\x06R\xd2\xa7\
\x00a\
\x00r\x00r\x00o\x00w\x00-\x00u\x00p\x00-\x00r\x00i\x00g\x00h\x00t\x00-\x00f\x00r\
\x00o\x00m\x00-\x00s\x00q\x00u\x00a\x00r\x00e\x00-\x00s\x00o\x00l\x00i\x00d\x00.\
\x00s\x00v\x00g\
\x00\x1d\
\x04\x1bf\xe7\
\x00a\
\x00r\x00r\x00o\x00w\x00-\x00a\x00l\x00t\x00-\x00c\x00i\x00r\x00c\x00l\x00e\x00-\
\x00u\x00p\x00-\x00s\x00o\x00l\x00i\x00d\x00.\x00s\x00v\x00g\
\x00\x10\
\x03\xdeX'\
\x00s\
\x00e\x00a\x00r\x00c\x00h\x00-\x00s\x00o\x00l\x00i\x00d\x00.\x00s\x00v\x00g\
\x00\x1f\
\x05\x92\xbe\x07\
\x00a\
\x00r\x00r\x00o\x00w\x00-\x00a\x00l\x00t\x00-\x00c\x00i\x00r\x00c\x00l\x00e\x00-\
\x00d\x00o\x00w\x00n\x00-\x00s\x00o\x00l\x00i\x00d\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x09\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\xac\x00\x00\x00\x00\x00\x01\x00\x00\x07\xb2\
\x00\x00\x01p\xd4U\xfb\x07\
\x00\x00\x01\xa2\x00\x00\x00\x00\x00\x01\x00\x00\x12\x1d\
\x00\x00\x01p\xd4U\xfb\x07\
\x00\x00\x01b\x00\x00\x00\x00\x00\x01\x00\x00\x10,\
\x00\x00\x01p\xd4U\xfb\x07\
\x00\x00\x00\x8a\x00\x00\x00\x00\x00\x01\x00\x00\x04\xcf\
\x00\x00\x01p\xd4U\xfb\x07\
\x00\x00\x01\xc8\x00\x00\x00\x00\x00\x01\x00\x00\x14b\
\x00\x00\x01p\xd4U\xfb\x07\
\x00\x00\x01\x14\x00\x00\x00\x00\x00\x01\x00\x00\x0c\xac\
\x00\x00\x01\x81\xb8\xfb5\xdd\
\x00\x00\x00\x18\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x82\x11\xa3\xb8\xd1\
\x00\x00\x00\xf2\x00\x00\x00\x00\x00\x01\x00\x00\x09\xa9\
\x00\x00\x01p\xd4U\xfb\x07\
\x00\x00\x00F\x00\x00\x00\x00\x00\x01\x00\x00\x02\xd4\
\x00\x00\x01p\xd4U\xfb\x07\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
