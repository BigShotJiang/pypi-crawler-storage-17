#!/bin/bash
PYQTDESIGNERPATH=. designer $@
