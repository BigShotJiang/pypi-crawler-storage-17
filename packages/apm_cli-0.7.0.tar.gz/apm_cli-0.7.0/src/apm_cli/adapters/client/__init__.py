"""Client adapters package."""
