# CHANGELOG

<!-- version list -->

## v0.1.2 (2025-12-14)

### Chores

- Minor readme updates
  ([`8ce0024`](https://github.com/adhityaravi/gundog/commit/8ce002417311f0b04443b5bcb00fb1503a3e1885))


## v1.0.0 (2025-12-14)

- Initial Release
