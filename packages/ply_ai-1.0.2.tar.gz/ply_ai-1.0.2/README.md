# Ply-AI
Ply-AI is a hardware-aware Triton accelerator library for NVIDIA GPUs.

## Installation
`pip install ply-AI`

## License
MIT
