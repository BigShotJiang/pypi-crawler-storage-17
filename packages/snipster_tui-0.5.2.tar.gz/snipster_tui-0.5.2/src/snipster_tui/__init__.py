def main() -> None:
    print("Hello from snipster-tui!")
