# Typed Bitteam

> A fully typed, validated async client for the Bitteam API

Use *autocomplete* instead of documentation.

🚧 Under construction.