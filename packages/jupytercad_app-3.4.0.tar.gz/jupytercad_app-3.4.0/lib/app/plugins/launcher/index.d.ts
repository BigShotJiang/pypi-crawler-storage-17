import { JupyterFrontEndPlugin } from '@jupyterlab/application';
declare const launcherPlugin: JupyterFrontEndPlugin<void>;
export default launcherPlugin;
