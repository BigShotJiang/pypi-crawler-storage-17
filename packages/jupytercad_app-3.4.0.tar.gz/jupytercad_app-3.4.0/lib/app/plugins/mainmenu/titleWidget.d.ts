import { Widget } from '@lumino/widgets';
export declare class AppTitle extends Widget {
    constructor();
}
