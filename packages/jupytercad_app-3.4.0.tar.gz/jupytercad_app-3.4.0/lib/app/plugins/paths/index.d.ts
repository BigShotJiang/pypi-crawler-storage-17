import { JupyterFrontEnd, JupyterFrontEndPlugin } from '@jupyterlab/application';
/**
 * The default paths.
 */
declare const paths: JupyterFrontEndPlugin<JupyterFrontEnd.IPaths>;
export default paths;
