#############################
Account Statement CODA Module
#############################

The *Account Statement Coda Module* implements the import of `CODA
<http://downloads.tryton.org/standards/coda-2.6.pdf>`_ files as statements.

.. toctree::
   :maxdepth: 2

   releases
