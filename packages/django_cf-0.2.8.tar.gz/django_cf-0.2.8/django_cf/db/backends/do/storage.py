storage = None

def set_storage(db):
    global storage
    storage = db

def get_storage():
    return storage
