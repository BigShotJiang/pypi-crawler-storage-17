VENDOR_ALIASES: dict[str, str] = {}
