# Architecture Decision Records

The NATS ADR documents have moved to their [own repository](https://github.com/nats-io/nats-architecture-and-design/)
