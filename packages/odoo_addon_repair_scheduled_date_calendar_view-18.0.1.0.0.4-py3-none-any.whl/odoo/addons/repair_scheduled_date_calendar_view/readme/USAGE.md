Use the calendar view to see the scheduled repair orders.
You can specify the duration of any order by modifying
the "Planned Duration" field or by resizing the calendar element.
