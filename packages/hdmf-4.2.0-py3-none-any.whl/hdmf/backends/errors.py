"""Module for I/O backend errors"""


class UnsupportedOperation(ValueError):
    pass
