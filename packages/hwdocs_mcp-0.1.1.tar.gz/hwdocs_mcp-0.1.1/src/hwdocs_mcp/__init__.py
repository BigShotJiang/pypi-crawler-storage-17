"""hwdocs-mcp: MCP server for hardware documentation search and management."""

__version__ = "0.1.1"
