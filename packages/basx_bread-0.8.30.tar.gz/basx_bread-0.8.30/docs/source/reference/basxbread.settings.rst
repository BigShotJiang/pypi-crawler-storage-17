basxbread.settings package
==========================

.. automodule:: basxbread.settings
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

basxbread.settings.required module
----------------------------------

.. automodule:: basxbread.settings.required
   :members:
   :undoc-members:
   :show-inheritance:
