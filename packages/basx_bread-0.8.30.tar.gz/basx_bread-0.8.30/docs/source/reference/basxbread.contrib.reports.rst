basxbread.contrib.reports package
=================================

.. automodule:: basxbread.contrib.reports
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

basxbread.contrib.reports.models module
---------------------------------------

.. automodule:: basxbread.contrib.reports.models
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.reports.urls module
-------------------------------------

.. automodule:: basxbread.contrib.reports.urls
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.reports.views module
--------------------------------------

.. automodule:: basxbread.contrib.reports.views
   :members:
   :undoc-members:
   :show-inheritance:
