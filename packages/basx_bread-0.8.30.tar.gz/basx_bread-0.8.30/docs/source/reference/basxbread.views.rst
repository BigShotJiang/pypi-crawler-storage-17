basxbread.views package
=======================

.. automodule:: basxbread.views
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

basxbread.views.add module
--------------------------

.. automodule:: basxbread.views.add
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.views.administration module
-------------------------------------

.. automodule:: basxbread.views.administration
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.views.auth module
---------------------------

.. automodule:: basxbread.views.auth
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.views.browse module
-----------------------------

.. automodule:: basxbread.views.browse
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.views.delete module
-----------------------------

.. automodule:: basxbread.views.delete
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.views.edit module
---------------------------

.. automodule:: basxbread.views.edit
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.views.error module
----------------------------

.. automodule:: basxbread.views.error
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.views.globalpreferences module
----------------------------------------

.. automodule:: basxbread.views.globalpreferences
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.views.read module
---------------------------

.. automodule:: basxbread.views.read
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.views.userprofile module
----------------------------------

.. automodule:: basxbread.views.userprofile
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.views.util module
---------------------------

.. automodule:: basxbread.views.util
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.views.wizard module
-----------------------------

.. automodule:: basxbread.views.wizard
   :members:
   :undoc-members:
   :show-inheritance:
