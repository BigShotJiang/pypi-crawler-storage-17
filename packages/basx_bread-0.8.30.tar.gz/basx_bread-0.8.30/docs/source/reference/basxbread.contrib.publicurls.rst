basxbread.contrib.publicurls package
====================================

.. automodule:: basxbread.contrib.publicurls
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

basxbread.contrib.publicurls.models module
------------------------------------------

.. automodule:: basxbread.contrib.publicurls.models
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.publicurls.urls module
----------------------------------------

.. automodule:: basxbread.contrib.publicurls.urls
   :members:
   :undoc-members:
   :show-inheritance:
