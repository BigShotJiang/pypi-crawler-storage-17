basxbread.contrib.document\_templates package
=============================================

.. automodule:: basxbread.contrib.document_templates
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

basxbread.contrib.document\_templates.models module
---------------------------------------------------

.. automodule:: basxbread.contrib.document_templates.models
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.document\_templates.urls module
-------------------------------------------------

.. automodule:: basxbread.contrib.document_templates.urls
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.document\_templates.views module
--------------------------------------------------

.. automodule:: basxbread.contrib.document_templates.views
   :members:
   :undoc-members:
   :show-inheritance:
