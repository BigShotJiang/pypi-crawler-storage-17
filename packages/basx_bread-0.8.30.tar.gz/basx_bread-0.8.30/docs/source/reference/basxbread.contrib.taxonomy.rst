basxbread.contrib.taxonomy package
==================================

.. automodule:: basxbread.contrib.taxonomy
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

basxbread.contrib.taxonomy.models module
----------------------------------------

.. automodule:: basxbread.contrib.taxonomy.models
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.taxonomy.urls module
--------------------------------------

.. automodule:: basxbread.contrib.taxonomy.urls
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.taxonomy.views module
---------------------------------------

.. automodule:: basxbread.contrib.taxonomy.views
   :members:
   :undoc-members:
   :show-inheritance:
