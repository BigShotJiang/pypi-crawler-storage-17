# mdtests with external dependencies

This directory contains mdtests that make use of external packages. See the mdtest `README.md` for
more information.
