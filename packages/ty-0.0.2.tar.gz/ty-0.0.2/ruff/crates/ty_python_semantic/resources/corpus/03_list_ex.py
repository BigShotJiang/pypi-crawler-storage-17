[a, *b, *d, a, c]
