match x:
    case 1:
        pass
    case _ as y:
        pass
