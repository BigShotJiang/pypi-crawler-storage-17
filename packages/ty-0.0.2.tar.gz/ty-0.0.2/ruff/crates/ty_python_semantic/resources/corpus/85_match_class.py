match x:
    case bool(z):
        pass
