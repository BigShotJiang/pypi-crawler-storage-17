(
    x,
    a if b else c
)
