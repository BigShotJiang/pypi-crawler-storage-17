for _ in range(1):

    def b():
        x: int

        break
