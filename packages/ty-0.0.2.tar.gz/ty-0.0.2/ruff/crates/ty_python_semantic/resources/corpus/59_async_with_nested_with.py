async def foo():
    async with a:
        with b:
            pass
