def foo():
    a.b = 1
