assert a
assert b, "foo"
