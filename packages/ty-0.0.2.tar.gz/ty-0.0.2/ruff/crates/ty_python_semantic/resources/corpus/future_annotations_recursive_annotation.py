from __future__ import annotations

class MyClass:
    type: type = str
