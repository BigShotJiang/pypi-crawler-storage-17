from typing import Any

def name_2[T: Any](x: T):
    try:
        pass
    except x:
        pass

