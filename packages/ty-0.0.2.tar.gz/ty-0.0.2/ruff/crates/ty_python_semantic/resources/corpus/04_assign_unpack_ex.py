a, *b = c
*a, b = c
a, *b, c, d = e
[a, *b, c] = d
