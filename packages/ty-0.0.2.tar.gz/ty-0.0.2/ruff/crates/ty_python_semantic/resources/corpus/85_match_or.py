match 0:
    case 0 | 1:
        x = True
    case 2 | 3 | 4:
        x = False
