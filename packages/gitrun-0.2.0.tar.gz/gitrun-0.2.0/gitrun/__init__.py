"""
gitrun - تشغيل سكربتات بايثون مباشرة من GitHub/GitLab
"""

__version__ = "0.2.0"
__author__ = "RACHIDHEZLA"
__email__ = "rachid470@gmail.com"

from gitrun.core import GitRunner

__all__ = ["GitRunner"]
