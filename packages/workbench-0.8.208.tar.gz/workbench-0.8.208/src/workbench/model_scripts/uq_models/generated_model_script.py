# Model: XGBoost for point predictions + MAPIE UQ Harness for conformalized intervals
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split

import json
import argparse
import joblib
import os
import numpy as np
import pandas as pd

# Shared model script utilities
from model_script_utils import (
    check_dataframe,
    match_features_case_insensitive,
    convert_categorical_types,
    decompress_features,
    input_fn,
    output_fn,
    compute_regression_metrics,
    print_regression_metrics,
)

# UQ Harness for uncertainty quantification
from uq_harness import (
    train_uq_models,
    save_uq_models,
    load_uq_models,
    predict_intervals,
    compute_confidence,
)

# Template Placeholders
TEMPLATE_PARAMS = {
    "target": "solubility",
    "features": ['molwt', 'mollogp', 'molmr', 'heavyatomcount', 'numhacceptors', 'numhdonors', 'numheteroatoms', 'numrotatablebonds', 'numvalenceelectrons', 'numaromaticrings', 'numsaturatedrings', 'numaliphaticrings', 'ringcount', 'tpsa', 'labuteasa', 'balabanj', 'bertzct'],
    "compressed_features": [],
    "train_all_data": False,
    "hyperparameters": {'training_config': {'max_epochs': 150}, 'model_config': {'layers': '128-64-32'}},
}


if __name__ == "__main__":
    # Template Parameters
    target = TEMPLATE_PARAMS["target"]
    features = TEMPLATE_PARAMS["features"]
    orig_features = features.copy()
    compressed_features = TEMPLATE_PARAMS["compressed_features"]
    train_all_data = TEMPLATE_PARAMS["train_all_data"]
    hyperparameters = TEMPLATE_PARAMS["hyperparameters"] or {}
    validation_split = 0.2

    # Script arguments for input/output directories
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", type=str, default=os.environ.get("SM_MODEL_DIR", "/opt/ml/model"))
    parser.add_argument("--train", type=str, default=os.environ.get("SM_CHANNEL_TRAIN", "/opt/ml/input/data/train"))
    parser.add_argument(
        "--output-data-dir", type=str, default=os.environ.get("SM_OUTPUT_DATA_DIR", "/opt/ml/output/data")
    )
    args = parser.parse_args()

    # Read the training data into DataFrames
    training_files = [os.path.join(args.train, file) for file in os.listdir(args.train) if file.endswith(".csv")]
    print(f"Training Files: {training_files}")

    # Combine files and read them all into a single pandas dataframe
    all_df = pd.concat([pd.read_csv(file, engine="python") for file in training_files])

    # Check if the dataframe is empty
    check_dataframe(all_df, "training_df")

    # Features/Target output
    print(f"Target: {target}")
    print(f"Features: {str(features)}")

    # Convert any features that might be categorical to 'category' type
    all_df, category_mappings = convert_categorical_types(all_df, features)

    # If we have compressed features, decompress them
    if compressed_features:
        print(f"Decompressing features {compressed_features}...")
        all_df, features = decompress_features(all_df, features, compressed_features)

    # Do we want to train on all the data?
    if train_all_data:
        print("Training on ALL of the data")
        df_train = all_df.copy()
        df_val = all_df.copy()

    # Does the dataframe have a training column?
    elif "training" in all_df.columns:
        print("Found training column, splitting data based on training column")
        df_train = all_df[all_df["training"]]
        df_val = all_df[~all_df["training"]]
    else:
        # Just do a random training Split
        print("WARNING: No training column found, splitting data with random state=42")
        df_train, df_val = train_test_split(all_df, test_size=validation_split, random_state=42)
    print(f"FIT/TRAIN: {df_train.shape}")
    print(f"VALIDATION: {df_val.shape}")

    # Extract sample weights if present
    if "sample_weight" in df_train.columns:
        sample_weights = df_train["sample_weight"]
        print(f"Using sample weights: min={sample_weights.min():.2f}, max={sample_weights.max():.2f}, mean={sample_weights.mean():.2f}")
    else:
        sample_weights = None
        print("No sample weights found, training with equal weights")

    # Prepare features and targets for training
    X_train = df_train[features]
    X_validate = df_val[features]
    y_train = df_train[target]
    y_validate = df_val[target]

    # ==========================================
    # Train XGBoost for point predictions
    # ==========================================
    print("\nTraining XGBoost for point predictions...")
    print(f"  Hyperparameters: {hyperparameters}")
    xgb_model = XGBRegressor(enable_categorical=True, **hyperparameters)
    xgb_model.fit(X_train, y_train, sample_weight=sample_weights)

    # Evaluate XGBoost performance
    y_pred_xgb = xgb_model.predict(X_validate)
    xgb_metrics = compute_regression_metrics(y_validate, y_pred_xgb)

    print(f"\nXGBoost Point Prediction Performance:")
    print_regression_metrics(xgb_metrics)

    # ==========================================
    # Train UQ models using the harness
    # ==========================================
    uq_models, uq_metadata = train_uq_models(X_train, y_train, X_validate, y_validate)

    print(f"\nOverall Model Performance Summary:")
    print_regression_metrics(xgb_metrics)

    # ==========================================
    # Save all models
    # ==========================================
    # Save the trained XGBoost model
    joblib.dump(xgb_model, os.path.join(args.model_dir, "xgb_model.joblib"))

    # Save UQ models using the harness
    save_uq_models(uq_models, uq_metadata, args.model_dir)

    # Save the feature list
    with open(os.path.join(args.model_dir, "feature_columns.json"), "w") as fp:
        json.dump(features, fp)

    # Save category mappings if any
    if category_mappings:
        with open(os.path.join(args.model_dir, "category_mappings.json"), "w") as fp:
            json.dump(category_mappings, fp)

    # Save model configuration
    model_config = {
        "model_type": "XGBoost_MAPIE_UQ",
        "confidence_levels": uq_metadata["confidence_levels"],
        "n_features": len(features),
        "target": target,
        "validation_metrics": {
            "xgb_rmse": float(xgb_metrics["rmse"]),
            "xgb_mae": float(xgb_metrics["mae"]),
            "xgb_r2": float(xgb_metrics["r2"]),
            "n_validation": len(df_val),
        },
    }
    with open(os.path.join(args.model_dir, "model_config.json"), "w") as fp:
        json.dump(model_config, fp, indent=2)

    print(f"\nModel training complete!")
    print(f"Saved XGBoost model and {len(uq_models)} UQ models to {args.model_dir}")


#
# Inference Section
#
def model_fn(model_dir) -> dict:
    """Load XGBoost and all UQ models from the specified directory."""

    # Load model configuration
    with open(os.path.join(model_dir, "model_config.json")) as fp:
        config = json.load(fp)

    # Load XGBoost regressor
    xgb_path = os.path.join(model_dir, "xgb_model.joblib")
    xgb_model = joblib.load(xgb_path)

    # Load UQ models using the harness
    uq_models, uq_metadata = load_uq_models(model_dir)

    # Load category mappings if they exist
    category_mappings = {}
    category_path = os.path.join(model_dir, "category_mappings.json")
    if os.path.exists(category_path):
        with open(category_path) as fp:
            category_mappings = json.load(fp)

    return {
        "xgb_model": xgb_model,
        "uq_models": uq_models,
        "uq_metadata": uq_metadata,
        "category_mappings": category_mappings,
    }


def predict_fn(df, models) -> pd.DataFrame:
    """Make predictions using XGBoost for point estimates and UQ harness for intervals.

    Args:
        df (pd.DataFrame): The input DataFrame
        models (dict): Dictionary containing XGBoost and UQ models

    Returns:
        pd.DataFrame: DataFrame with predictions and conformalized intervals
    """
    # Grab our feature columns (from training)
    model_dir = os.environ.get("SM_MODEL_DIR", "/opt/ml/model")
    with open(os.path.join(model_dir, "feature_columns.json")) as fp:
        model_features = json.load(fp)

    # Match features in a case-insensitive manner
    matched_df = match_features_case_insensitive(df, model_features)

    # Apply categorical mappings if they exist
    if models.get("category_mappings"):
        matched_df, _ = convert_categorical_types(matched_df, model_features, models["category_mappings"])

    # Get features for prediction
    X = matched_df[model_features]

    # Get XGBoost point predictions
    df["prediction"] = models["xgb_model"].predict(X)

    # Get prediction intervals using UQ harness
    df = predict_intervals(df, X, models["uq_models"], models["uq_metadata"])

    # Compute confidence scores
    df = compute_confidence(
        df,
        median_interval_width=models["uq_metadata"]["median_interval_width"],
        lower_q="q_10",
        upper_q="q_90",
    )

    return df
