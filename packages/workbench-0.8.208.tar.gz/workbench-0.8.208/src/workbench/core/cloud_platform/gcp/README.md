# GCP Platform Specific Code
This directory holds code that's specific to the Google Cloud Platform (GCP).