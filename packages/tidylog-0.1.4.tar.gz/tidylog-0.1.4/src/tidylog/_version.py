"""Version information for tidylog."""

__version__ = "0.1.4"
