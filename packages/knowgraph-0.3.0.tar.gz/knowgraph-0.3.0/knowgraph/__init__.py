"""Static KnowGraph System - File-based Graph Retrieval-Augmented Generation.

A production-grade library for converting Git repositories into queryable
knowledge graphs with explainable reasoning paths.
"""

__version__ = "0.3.0"
__author__ = "Yunus Güngör"
__license__ = "MIT"

# Public API will be defined as components are implemented
__all__: list[str] = []
