"""Sindri command group for project setup."""

from sindri.commands.sindri.sindri_group import SindriGroup

__all__ = ["SindriGroup"]

