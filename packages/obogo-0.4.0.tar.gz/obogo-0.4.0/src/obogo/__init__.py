from .tree import reader as create_tree_from_obo
