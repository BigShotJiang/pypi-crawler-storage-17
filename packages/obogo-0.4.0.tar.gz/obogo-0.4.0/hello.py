def main():
    print("Hello from obogo!")


if __name__ == "__main__":
    main()
