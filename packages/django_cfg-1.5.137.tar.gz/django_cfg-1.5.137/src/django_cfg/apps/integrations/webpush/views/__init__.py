"""
Views for Web Push module.
"""

from .api import WebPushViewSet

__all__ = ["WebPushViewSet"]
