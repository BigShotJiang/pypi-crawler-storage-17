from .model_withweights import Model_Evaluator

__all__ = ["Model_Evaluator", "__version__"]

__version__ = "0.0.2"
