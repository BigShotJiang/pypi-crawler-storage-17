OPENAI_EXCLUDED_FIELDS = {"meta", "content_parsed"}
