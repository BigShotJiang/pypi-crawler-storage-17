import os
import sys

from yaspin import yaspin
from yaspin.spinners import Spinners
from pytubefix import YouTube
from pytubefix.cli import on_progress
from termcolor import colored
from moviepy.video.io.ffmpeg_tools import ffmpeg_merge_video_audio

from pyutube.utils import (
    console,
    error_console,
    ask_resolution,
    CANCEL_PREFIX
)
























class VideoService:
    def __init__(self, url: str, quality: str, path: str) -> None:
        self.url = url
        self.quality = quality
        self.path = path

    # =========================
    # Search
    # =========================
    def search_process(self) -> YouTube:
        try:
            video = self.__video_search()
        except Exception as error:
            error_console.print(f"❗ Error: {error}")
            sys.exit(1)

        if not video:
            error_console.print("❗ No stream available for the URL.")
            sys.exit(1)

        return video

    @yaspin(
        text=colored("Searching for the video", "green"),
        color="green",
        spinner=Spinners.point,
    )
    def __video_search(self) -> YouTube:
        return YouTube(
            self.url,
            use_oauth=True,
            allow_oauth_cache=True,
            on_progress_callback=on_progress,
        )

    # =========================
    # 🎯 FORCED itag 18
    # =========================
    def get_selected_stream(self, video, is_audio: bool = False):
        """
        Always return itag 18 (video + audio)
        """

        stream = video.streams.get_by_itag(18)

        if not stream:
            error_console.print("❗ itag 18 (360p progressive) not available.")
            sys.exit(1)

        # لا يوجد صوت منفصل
        return stream, None, "360p"

    # =========================
    # ✅ Compatibility with DownloadService
    # =========================
    def get_video_streams(self, video, is_audio: bool = False):
        """
        DownloadService expects this method
        """
        stream, audio, _ = self.get_selected_stream(video, is_audio)
        return stream, audio