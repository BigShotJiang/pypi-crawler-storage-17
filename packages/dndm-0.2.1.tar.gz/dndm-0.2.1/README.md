This is an early release of list of dnd tools.
These are the following commands:

Roll a dice: roll <dice_number> [repeat]

Change the save path: svc <path>

Create a character: chr

Regenerates a pdf from a previously made character: regen <name>

Please note that the chr command will walk you through the character setup. 

Please report any errors to psydameousharm@gmail.com