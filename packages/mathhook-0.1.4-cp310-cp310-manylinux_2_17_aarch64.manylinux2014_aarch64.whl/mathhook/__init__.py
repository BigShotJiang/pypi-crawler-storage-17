from .mathhook import *

__doc__ = mathhook.__doc__
if hasattr(mathhook, "__all__"):
    __all__ = mathhook.__all__