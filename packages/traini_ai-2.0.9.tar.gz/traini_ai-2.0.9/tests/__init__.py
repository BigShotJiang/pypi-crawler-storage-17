"""Tests for Dog Emotion SDK"""
