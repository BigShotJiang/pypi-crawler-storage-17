"""log_exc module for CVXlab package."""
