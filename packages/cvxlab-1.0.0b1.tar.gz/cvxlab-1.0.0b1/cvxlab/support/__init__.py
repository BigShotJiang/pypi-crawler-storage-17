"""support module for CVXlab package."""
