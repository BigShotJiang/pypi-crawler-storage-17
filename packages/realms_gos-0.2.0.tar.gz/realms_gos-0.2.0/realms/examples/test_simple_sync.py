from kybra import ic


def sync_task():
    ic.print('HELLO FROM NEW CODE SYNC USING IC.PRINT')
    logger.info('HELLO FROM NEW CODE SYNC USING LOGGER')

sync_task()
_result = 'OK'
