<script>
  import PassportVerification from '$lib/extensions/passport_verification/PassportVerification.svelte';
</script>

<svelte:head>
  <title>Passport Verification - Realm</title>
</svelte:head>

<PassportVerification />
