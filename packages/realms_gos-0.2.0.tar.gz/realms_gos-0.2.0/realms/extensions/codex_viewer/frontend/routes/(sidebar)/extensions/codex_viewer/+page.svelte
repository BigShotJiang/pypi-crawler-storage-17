<script lang="ts">
  import CodexViewer from '$lib/extensions/codex_viewer/CodexViewer.svelte';
</script>

<CodexViewer />
