import ProposalList from './ProposalList.svelte';

export const metadata = {
  "name": "voting",
  "version": "1.0.0",
  "description": "Governance voting system for submitting and voting on proposals to execute Python code",
  "author": "Smart Social Contracts",
  "permissions": [],
  "profiles": [
    "member",
    "admin"
  ],
  "categories": [
    "public_services"
  ],
  "icon": "users_group",
  "doc_url": "https://github.com/smart-social-contracts/realms/tree/main/extensions/voting",
  "url_path": null,
  "show_in_sidebar": true
};

export default ProposalList;
