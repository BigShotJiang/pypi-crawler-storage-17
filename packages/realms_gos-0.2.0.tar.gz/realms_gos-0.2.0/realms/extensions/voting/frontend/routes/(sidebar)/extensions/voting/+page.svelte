<script>
  import Voting from '$lib/extensions/voting/Voting.svelte';
</script>

<svelte:head>
  <title>Voting - Realm</title>
</svelte:head>

<Voting />
