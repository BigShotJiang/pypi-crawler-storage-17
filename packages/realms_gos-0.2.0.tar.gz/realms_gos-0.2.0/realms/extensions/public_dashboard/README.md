# Public Dashboard

Public dashboard with analytics and statistics for the realm.

## Features
- Analytics dashboard with charts
- User metrics tracking
- Organization analytics
- Asset statistics
- Real-time data updates
- Multi-language support

**Category:** Public Services  
**Access:** Members and Admins  
**Version:** 1.0.0
