<script>
  import PublicDashboard from '$lib/extensions/public_dashboard/PublicDashboard.svelte';
</script>

<svelte:head>
  <title>Public Dashboard - Realm</title>
</svelte:head>

<PublicDashboard />
