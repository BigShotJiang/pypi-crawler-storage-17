# Notifications

Real-time notifications and alerts system.

## Features
- Real-time notifications
- Mark as read/unread
- Create custom notifications
- Alert categories
- Multi-language support
- Notification history

**Category:** Other  
**Access:** Members and Admins  
**Version:** 1.0.0
