export { default as default } from './VaultManager.svelte';
export { default as VaultManager } from './VaultManager.svelte';
