<script>
  import MarketPlace from '$lib/extensions/market_place/MarketPlace.svelte';
</script>

<svelte:head>
  <title>Market Place - Realm</title>
</svelte:head>

<MarketPlace />
