"""
AI assistance extension for Realm backend
"""
