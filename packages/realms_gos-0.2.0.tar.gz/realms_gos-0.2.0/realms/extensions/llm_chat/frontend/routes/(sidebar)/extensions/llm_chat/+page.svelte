<script>
  import LLMChat from '$lib/extensions/llm_chat/LLMChat.svelte';
</script>

<svelte:head>
  <title>AI Assistant - Realm</title>
</svelte:head>

<LLMChat />
