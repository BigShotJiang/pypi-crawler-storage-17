# LLM Chat

AI-powered assistant for governance and legal questions.

## Features
- AI-powered assistance
- Conversational interface
- Context-aware responses
- Multi-language support
- Real-time chat

**Category:** Other  
**Access:** Members and Admins  
**Version:** 0.1.0
