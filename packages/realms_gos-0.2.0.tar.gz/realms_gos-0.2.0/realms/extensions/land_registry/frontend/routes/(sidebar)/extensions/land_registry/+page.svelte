<script>
  import LandRegistry from '$lib/extensions/land_registry/LandRegistry.svelte';
</script>

<svelte:head>
  <title>Land Registry - Realm</title>
</svelte:head>

<LandRegistry />
