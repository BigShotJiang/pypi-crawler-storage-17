# Test Bench

Development testing and debugging tools.

## Features
- Development testing tools
- Debugging utilities
- Token transfer testing
- Vault read operations
- Admin debugging interface

**Category:** Other  
**Access:** Admins only  
**Version:** 0.1.0  
**Sidebar:** Hidden  
**Status:** Disabled
