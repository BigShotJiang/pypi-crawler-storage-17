<script lang="ts">
	import TaskMonitor from '$lib/extensions/task_monitor/TaskMonitor.svelte';
</script>

<TaskMonitor />
