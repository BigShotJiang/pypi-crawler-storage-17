<script>
  import JusticeLitigation from '$lib/extensions/justice_litigation/JusticeLitigation.svelte';
</script>

<svelte:head>
  <title>Justice Litigation - Realm</title>
</svelte:head>

<JusticeLitigation />
