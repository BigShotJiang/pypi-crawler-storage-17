#!/usr/bin/env bash
# Admin Dashboard Test Runner
# Uses shared testing framework
bash ../_shared/testing/scripts/run_tests.sh "$@"
