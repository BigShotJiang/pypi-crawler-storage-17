#!/usr/bin/env bash
# Admin Dashboard Linter Runner
# Uses shared testing framework
bash ../_shared/testing/scripts/run_linters.sh "$@"
