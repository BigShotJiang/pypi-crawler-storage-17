<script lang="ts">
	import AdminDashboard from '$lib/extensions/admin_dashboard/AdminDashboard.svelte';
</script>

<AdminDashboard />
