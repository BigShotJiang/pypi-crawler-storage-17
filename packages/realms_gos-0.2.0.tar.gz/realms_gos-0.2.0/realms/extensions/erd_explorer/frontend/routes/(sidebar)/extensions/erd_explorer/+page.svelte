<script>
  import ERDExplorer from '$lib/extensions/erd_explorer/ERDExplorer.svelte';
</script>

<svelte:head>
  <title>ERD Explorer - Realm</title>
</svelte:head>

<ERDExplorer />
