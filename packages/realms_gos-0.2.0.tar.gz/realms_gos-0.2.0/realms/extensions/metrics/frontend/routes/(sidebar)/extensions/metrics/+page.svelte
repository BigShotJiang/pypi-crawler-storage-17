<script>
  import Metrics from '$lib/extensions/metrics/Metrics.svelte';
</script>

<svelte:head>
  <title>Metrics - Realm</title>
</svelte:head>

<Metrics />
