# Member Dashboard

Personal dashboard for members to manage government services and documents.

## Features
- Document management
- Service request tracking
- Profile management
- Notifications integration
- Multi-language support

**Category:** Public Services  
**Access:** Members and Admins  
**Version:** 1.0.0
