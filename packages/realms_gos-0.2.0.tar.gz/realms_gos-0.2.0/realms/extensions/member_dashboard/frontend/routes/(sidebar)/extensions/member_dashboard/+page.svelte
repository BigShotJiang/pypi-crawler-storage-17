<script>
  import MemberDashboard from '$lib/extensions/member_dashboard/MemberDashboard.svelte';
</script>

<svelte:head>
  <title>Member Dashboard - Realm</title>
</svelte:head>

<MemberDashboard />
