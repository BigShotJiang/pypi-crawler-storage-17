#!/usr/bin/env bash
# Member Dashboard Test Runner
# Uses shared testing framework
bash ../_shared/testing/scripts/run_tests.sh "$@"
