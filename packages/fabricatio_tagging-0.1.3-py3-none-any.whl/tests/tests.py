"""Tests for the tagging."""
