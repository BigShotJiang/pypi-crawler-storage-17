"""An extension of fabricatio, provide capalability to tag on data."""
