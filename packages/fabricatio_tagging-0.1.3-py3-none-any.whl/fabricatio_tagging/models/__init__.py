"""Models defined in fabricatio-tagging."""
