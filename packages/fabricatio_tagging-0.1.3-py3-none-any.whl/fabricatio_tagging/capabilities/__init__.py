"""Capabilities defined in fabricatio-tagging."""
