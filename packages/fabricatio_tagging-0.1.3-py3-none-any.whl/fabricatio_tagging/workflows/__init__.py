"""Workflows defined in fabricatio-tagging."""
