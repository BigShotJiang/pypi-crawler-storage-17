from . import test_purchase_address
from . import test_purchase_buy_rule
