try:
    import cPickle
except ImportError:
    import pickle as cPickle
