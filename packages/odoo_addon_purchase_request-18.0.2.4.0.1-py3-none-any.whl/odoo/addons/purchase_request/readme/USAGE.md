Purchase requests are accessible through a new menu entry 'Purchase
Requests', and also from the 'Purchase' menu.

Users can access the list of Purchase Requests or Purchase Request
Lines.

It is possible to filter requests by its approval status.
