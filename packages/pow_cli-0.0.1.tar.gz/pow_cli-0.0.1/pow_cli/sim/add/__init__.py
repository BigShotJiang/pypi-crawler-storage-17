from .local_assets import add_local_assets

__all__ = ["add_local_assets"]
