# TODO

add init command for initial project for both sim and ros

```bash
# init project both sim and ros,
# call 'pow sim init' and 'pow ros init' under the hood
pow init

pow init --type [sim, ros, both]
pow init -t [sim, ros, both]
```
