import nistrng
print(dir(nistrng))
