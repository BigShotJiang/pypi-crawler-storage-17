from opsmith.cloud_providers.base import CloudProviderRegistry

CLOUD_PROVIDER_REGISTRY = CloudProviderRegistry()
