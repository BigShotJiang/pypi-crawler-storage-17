__version__ = "2025.12.19"
__prog__ = "webscout"
