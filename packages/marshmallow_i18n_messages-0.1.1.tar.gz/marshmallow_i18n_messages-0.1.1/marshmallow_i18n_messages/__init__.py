from .patch_marshmallow import add_i18n_to_marshmallow

__all__ = (
    "add_i18n_to_marshmallow",
)