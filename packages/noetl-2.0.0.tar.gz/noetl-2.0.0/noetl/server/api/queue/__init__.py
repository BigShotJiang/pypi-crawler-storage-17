"""Queue API removed; only placeholder router is exported."""

from .endpoint import router

__all__ = ["router"]
