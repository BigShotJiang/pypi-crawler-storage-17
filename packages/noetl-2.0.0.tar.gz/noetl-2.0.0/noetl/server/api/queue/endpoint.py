"""Queue API removed; router placeholder only."""
from fastapi import APIRouter

router = APIRouter(tags=["Queue"])
