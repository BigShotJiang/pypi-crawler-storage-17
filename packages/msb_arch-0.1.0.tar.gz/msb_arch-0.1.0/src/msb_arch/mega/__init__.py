# msb/mega/__init__.py
from .manipulator import Manipulator
__all__ = ["Manipulator"]