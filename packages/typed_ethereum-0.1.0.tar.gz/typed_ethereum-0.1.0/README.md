# Typed Ethereum

> A fully typed, validated async client for the Ethereum API

Use *autocomplete* instead of documentation.

🚧 Under construction.