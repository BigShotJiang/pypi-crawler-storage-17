"""
### Typed Ethereum
> A fully typed, validated async client for the Ethereum API

- Details
"""