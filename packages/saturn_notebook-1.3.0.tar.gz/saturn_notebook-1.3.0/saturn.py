#!/usr/bin/env python3

import saturn_notebook.__main__
saturn_notebook.__main__.main()
