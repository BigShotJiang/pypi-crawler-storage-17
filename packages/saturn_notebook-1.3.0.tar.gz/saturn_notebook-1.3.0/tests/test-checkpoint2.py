a = 5

#chk>{{{
#chk>gANDIEfymvjN9EowcCGj+XNtin7uihFyNxXkbW2Myny7GZzJcQAugAN9cQAoWAwAAABfX2J1aWx0aW5z
#chk>X19xAWNidWlsdGlucwpfX2RpY3RfXwpYAQAAAGFxAksFdS4=
#chk>}}}

print(a)
#o> 5
