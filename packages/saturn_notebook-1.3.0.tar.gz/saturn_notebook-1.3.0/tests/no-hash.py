a = 2

#---#

# This cell is inserted later and would invalidate the saved b below, but it's
# marked as non-hashable, so it doesn't.  The result illustrates one of the
# dangers of this label. It's emphatically not the intended use of these.
#no-hash#

a = 8
print(a)

#o> 8
#---#

b = a + 5
#var> b
#var>{{{
#var>gANDIDrzs7RJGOyYO7X1G5KGXWTmjGieO1aVZMbtXcMbfyl2cQAugANLBy4=
#var>}}}

#---#

print(b)
#o> 7
