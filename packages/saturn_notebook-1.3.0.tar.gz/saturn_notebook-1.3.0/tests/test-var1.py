import time

#---#

print("Evaluating")
a = 5
time.sleep(5)
print("Got a=",a)

#var> a

print(a)

#chk>

print(a + 5)
