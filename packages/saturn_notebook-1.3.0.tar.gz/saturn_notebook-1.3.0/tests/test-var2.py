import time

#---#

print("Evaluating")
a = 5
time.sleep(5)
print("Got a=",a)

#var> a
#var>{{{
#var>gANDIAAsgJFS4sAE025TaR2frmmDHCiXGlX6OHv5JlLaUAWRcQAugANLBS4=
#var>}}}
#o> Evaluating
#o> Got a= 5

print(a)

#o> 5
#chk>{{{
#chk>gANDIJKLas9byFEdZYuqEwXzwM30bIY8j9+SEZnfdw8vBUDEcQAugAN9cQAoWAwAAABfX2J1aWx0aW5z
#chk>X19xAWNidWlsdGlucwpfX2RpY3RfXwpYBAAAAHRpbWVxAmNkaWxsLl9kaWxsCl9pbXBvcnRfbW9kdWxl
#chk>CnEDWAQAAAB0aW1lcQSFcQVScQZYAQAAAGFxB0sFdS4=
#chk>}}}

print(a + 5)
#o> 10
