import sys

#---#

print("Hello")

#---#

sys.exit(0)

#---#

print("Past the end")
