a = 5

#chk>

print(a)
#o> 5
