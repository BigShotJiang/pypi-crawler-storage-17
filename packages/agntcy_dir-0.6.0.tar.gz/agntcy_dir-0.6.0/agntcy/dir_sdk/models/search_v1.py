# Copyright AGNTCY Contributors (https://github.com/agntcy)
# SPDX-License-Identifier: Apache-2.0

from agntcy.dir.search.v1.record_query_pb2 import *
from agntcy.dir.search.v1.record_query_pb2_grpc import *
from agntcy.dir.search.v1.search_service_pb2 import *
from agntcy.dir.search.v1.search_service_pb2_grpc import *
