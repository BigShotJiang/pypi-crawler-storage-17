"""Speech generation integration test module."""
