# SPDX-FileCopyrightText: 2025-present lelili2021 <lelili@bytedance.com>
#
# SPDX-License-Identifier: MIT
__version__ = "1.2.0"
