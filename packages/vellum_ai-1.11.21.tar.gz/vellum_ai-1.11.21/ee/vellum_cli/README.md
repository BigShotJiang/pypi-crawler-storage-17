# Vellum CLI

<!-- TODO: To be generated from the generator repo and shared with docs -->
