from .commands import skeema as skeema_click_command

__all__ = [
    'skeema_click_command',
]
