## 16.0.1.0.0

Due to the changes on 16, we will generate two moves on leasings, one
for the invoice, and another one for the change from long to short term.
