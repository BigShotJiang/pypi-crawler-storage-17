"""Metadata deduced from git at build time."""

id: str
short_id: str

id = "185bd6dcb6442bf4c38065522cdeb25ba204dd89"
short_id = "185bd6d"
