"""
Allow running the package with: python -m fcm_send
"""

from fcm_send.cli import main

if __name__ == "__main__":
    main()

