from . import (
    contract_address_change,
    contract_iban_change,
    contract_mobile_tariff_change,
    contract_one_shot_request,
    create_lead_from_partner,
)
