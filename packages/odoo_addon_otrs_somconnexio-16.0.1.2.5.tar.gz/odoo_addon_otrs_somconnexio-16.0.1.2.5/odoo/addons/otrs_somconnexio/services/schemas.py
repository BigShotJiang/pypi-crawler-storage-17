S_CONTRACT_IBAN_CHANGE_CREATE_TICKET_ID = {
    "ticket_id": {"type": "string", "required": False},
}

S_CONTRACT_CREATE_TICKET_NUMBER = {
    "ticket_number": {"type": "string", "required": True},
}
