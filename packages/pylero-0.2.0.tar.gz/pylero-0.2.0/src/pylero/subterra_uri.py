from __future__ import absolute_import, division, print_function, unicode_literals

from pylero.base_polarion import BasePolarion


# Unknown what this class object is supposed to do. Will determine during
# more intensive testing
class SubterraURI(BasePolarion):
    def __init__(self):
        pass


class ArrayOfSubterraURI(BasePolarion):
    def __init__(self):
        pass
