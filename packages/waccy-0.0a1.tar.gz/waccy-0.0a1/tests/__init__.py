"""Test suite for WACCY."""

