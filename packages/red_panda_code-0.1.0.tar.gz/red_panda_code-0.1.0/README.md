## Introduction
Welcome to Red Panda Code! Red Panda Code is a programming language made to make simple 2D games (see syntax.rpc).

## Making files
To make a Red Panda Code file, make filename.rpc. The file extension for Red Panda Code is rpc. 

## Pypi
This project is probably on Pypi when you see this, under the same name as here.

## Issues
Make an issue if you find a bug!

## Download from pypi
To download and use this, you should just be able to type <code>pip install red-panda-code</code>.

## Thanks for using
Pypi site: