## Welcome to Red Panda!
Welcome to the Red Panda Code Language! Red Panda Code is a language based on python to make 2D games with simple syntax. Go to the github (https://github.com/Lunar-Bytes/Red-Panda-Code/tree/main) to see the syntax. 

## How to use
To use Red Panda Code use <code>import red-panda-code</code> or <code>import redpanda</code> (i don't know what one).

## Thanks for trying
Thanks for trying if you use! Report any issues on the github.