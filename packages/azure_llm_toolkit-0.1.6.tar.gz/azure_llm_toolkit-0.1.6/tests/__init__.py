"""Tests for azure-llm-toolkit."""
