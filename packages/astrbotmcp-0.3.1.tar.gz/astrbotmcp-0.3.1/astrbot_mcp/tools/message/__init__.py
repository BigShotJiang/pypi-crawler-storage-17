from .direct import send_platform_message_direct
from .webchat import send_platform_message

__all__ = ["send_platform_message", "send_platform_message_direct"]