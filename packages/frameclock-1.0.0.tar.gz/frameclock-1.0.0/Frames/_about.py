__title__ = "frameclock"
__description__ = "A lightweight Python frame counter and limiter library for small projects and simulations."
__version__ = "1.0.0"
__author__ = "Your Name"
__author_email__ = "youremail@example.com"
__license__ = "MIT"
__url__ = "https://github.com/NeoZett/Frames"  # Update if hosted
__copyright__ = "2025, Your Name"