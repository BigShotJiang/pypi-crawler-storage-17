"""lmapp - Local LLM Made Simple"""

__version__ = "0.3.5"
__author__ = "lmapp Contributors"
__license__ = "MIT"
