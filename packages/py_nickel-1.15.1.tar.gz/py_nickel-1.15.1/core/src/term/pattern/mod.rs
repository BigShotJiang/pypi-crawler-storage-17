//! Pattern matching and destructuring of Nickel values.

pub mod compile;
