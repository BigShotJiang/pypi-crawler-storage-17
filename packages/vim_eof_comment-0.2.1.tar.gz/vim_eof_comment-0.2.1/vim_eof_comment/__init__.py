# -*- coding: utf-8 -*-
# Copyright (c) 2025 Guennadi Maximov C. All Rights Reserved.
"""
Ensure EOF Vim comments.

Copyright (c) 2025 Guennadi Maximov C. All Rights Reserved.
"""
from .types.version import version_info

version: str = str(version_info)

# vim: set ts=4 sts=4 sw=4 et ai si sta:
