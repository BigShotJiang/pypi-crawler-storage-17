MARKER_ATTRIBUTE_NAME = "_preprocessed_for_attachments"
