fscan.utils.dtutils module
--------------------------

This module contains functions for handling ``datetime`` and ``datetimedelta`` objects as well as conversions.

API
^^^

.. automodule:: fscan.utils.dtutils
   :members:
   :show-inheritance:
