postProcess
-----------

Can be run from the command line using

.. code-block:: bash

    postProcess <arguments>

This will run the post processing steps of Fscan: creating plots for Summary Pages, peak finding, comb finding, converting ASCII data into npz files.

.. automodule:: fscan.post
   :members:
   :show-inheritance:
