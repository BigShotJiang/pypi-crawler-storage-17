fscan.plot.linecount module
---------------------------

Can be run from the command line using

.. code-block:: bash

    FscanLineCountPlot <arguments>

The output will be two static plots showing line count history and the line count density heatmap plot.

API
^^^

.. automodule:: fscan.plot.linecount
   :members:
   :show-inheritance:
