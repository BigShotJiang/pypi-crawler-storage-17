fscan.plot.finetoothplot module
-------------------------------

Can be run from the command line using

.. code-block:: bash

    FscanFineToothPlot <arguments>

The output will be an interactive bokeh plot.

API
^^^

.. automodule:: fscan.plot.finetoothplot
   :members:
   :show-inheritance:
