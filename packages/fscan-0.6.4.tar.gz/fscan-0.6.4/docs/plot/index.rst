fscan.plot
==========

The ``fscan.plot`` subpackage contains necessary code to create the spectra, spectrograms, coherence, line-history, and persistency plots for display on Fscan Summary Pages.

.. toctree::
    :maxdepth: 1

    finetoothplot
    linecount
    static
