from cicerone import settings


def test_version():
    assert settings.VERSION == "0.1.0"
