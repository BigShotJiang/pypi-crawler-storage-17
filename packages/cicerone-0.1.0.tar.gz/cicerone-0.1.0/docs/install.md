# 🏗️ Install

## With pipx (Python)

```sh
pip install cicerone
```

## With uv (Python)

```sh
uv add cicerone
```
