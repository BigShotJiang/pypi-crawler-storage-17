"""
Network configuration helpers for AgentBox sandboxes.
"""

"""
CIDR range that represents all traffic.
"""
ALL_TRAFFIC = "0.0.0.0/0"
