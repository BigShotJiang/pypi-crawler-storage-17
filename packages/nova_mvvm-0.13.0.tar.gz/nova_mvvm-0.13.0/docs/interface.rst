
.. automodule:: nova.mvvm.interface
   :members:
