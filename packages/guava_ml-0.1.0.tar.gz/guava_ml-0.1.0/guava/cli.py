from . import __version__

def main():
    print(f"guava version {__version__}")