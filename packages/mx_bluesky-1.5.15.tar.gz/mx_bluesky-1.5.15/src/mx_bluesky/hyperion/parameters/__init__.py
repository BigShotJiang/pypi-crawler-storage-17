"""This module handles the translation between externally supplied parameters and the
internal parameter model."""
