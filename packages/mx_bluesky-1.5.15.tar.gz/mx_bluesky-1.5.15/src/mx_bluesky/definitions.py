import os

# Change once Python<3.12 is dropped - see https://github.com/DiamondLightSource/mx-bluesky/issues/798
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
