"""This is a module so that one can access the test data variables stored in
hyperion.external_interaction.tests.conftest.TestData"""
