_enum_ref_title
===============

This is a reference :ref:`test-exc-label`.

This is a second reference :ref:`some text <test-exc-label>`.
