_enum_ref_notitle
=================

This is a reference :ref:`text-exc-notitle`.

This is a second reference :ref:`some text <text-exc-notitle>`.
