_enum_duplicate_label
=====================

.. exercise:: duplicate directive 1
	:label: dup

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.


.. exercise:: duplicate directive 2
	:label: dup

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
