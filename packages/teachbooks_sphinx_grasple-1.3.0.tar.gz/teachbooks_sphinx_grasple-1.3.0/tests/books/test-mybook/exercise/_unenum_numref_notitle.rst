_unenum_numref_notitle
======================

This is a reference :numref:`unen-exc-notitle`.

This is a second reference :numref:`some text %s <unen-exc-notitle>`.

This is a third reference :numref:`some text {number} <unen-exc-notitle>`.

This is a fourth reference :numref:`some text {name} <unen-exc-notitle>`.
