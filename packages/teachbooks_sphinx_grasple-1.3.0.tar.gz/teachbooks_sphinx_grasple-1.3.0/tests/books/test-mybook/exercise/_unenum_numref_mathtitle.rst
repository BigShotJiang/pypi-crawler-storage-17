_unenum_numref_mathtitle
========================

This is a reference :numref:`unen-exc-label-math`.

This is a second reference :numref:`some text %s <unen-exc-label-math>`.

This is a third reference :numref:`some text {number} <unen-exc-label-math>`.

This is a fourth reference :numref:`some text {name} <unen-exc-label-math>`.
