_unenum_ref_title
=================

This is a reference :ref:`unen-exc-label`.

This is a second reference :ref:`some text <unen-exc-label>`.
