This module contains modified parts of the requests module (https://github.com/psf/requests).
The modules original license is included in LICENSE.
Changes made to the original source are listed in NOTICE, along with original NOTICE.