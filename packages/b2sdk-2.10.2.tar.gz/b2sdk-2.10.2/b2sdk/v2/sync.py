######################################################################
#
# File: b2sdk/v2/sync.py
#
# Copyright 2022 Backblaze Inc. All Rights Reserved.
#
# License https://www.backblaze.com/using_b2_code.html
#
######################################################################
from __future__ import annotations

from b2sdk.v3 import B2Path

B2SyncPath = B2Path
