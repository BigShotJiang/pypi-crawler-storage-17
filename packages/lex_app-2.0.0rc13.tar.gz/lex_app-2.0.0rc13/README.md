LEX App Documentation - Previously known as DPAG :)
