from lex.core.tasks.celery_dispatcher import CeleryTaskDispatcher

__all__ = ['CeleryTaskDispatcher']
