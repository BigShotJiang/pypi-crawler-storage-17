# Installation

To install ESSsans and all of its dependencies, use

`````{tab-set}
````{tab-item} pip
```sh
pip install esssans
```
````
````{tab-item} conda
```sh
conda install -c conda-forge esssans
```
````
`````
