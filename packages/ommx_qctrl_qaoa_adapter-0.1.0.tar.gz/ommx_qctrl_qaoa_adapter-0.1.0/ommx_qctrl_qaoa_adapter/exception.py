class OMMXQctrlQAOAAdapterError(Exception):
    """Domain specific error for the Q-CTRL QAOA adapter."""
