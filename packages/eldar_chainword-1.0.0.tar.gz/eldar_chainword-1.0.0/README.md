# Eldar Chain Word Game

CLI Chain Word Game (Şəhər-Şəhər / Last-letter-first-letter game)

## Install
```bash
pip install eldar-chainword
