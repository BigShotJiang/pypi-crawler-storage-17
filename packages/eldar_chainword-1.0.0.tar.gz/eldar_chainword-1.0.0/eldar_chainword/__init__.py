from .game import ChainWordGame

