=========
Numerical
=========

.. currentmodule:: pydiverse.transform.ColExpr
.. autosummary::
    :toctree: _generated/
    :nosignatures:
    :template: short_title.rst

    __pow__
    abs
    ceil
    exp
    floor
    is_inf
    is_nan
    is_not_inf
    is_not_nan
    log
    round
