=======================
Miscellaneous functions
=======================

.. currentmodule:: pydiverse.transform
.. autosummary::
    :toctree: _generated/
    :nosignatures:
    :template: short_title.rst

    verb
    backend
    is_sql_backed
    transfer_col_references
