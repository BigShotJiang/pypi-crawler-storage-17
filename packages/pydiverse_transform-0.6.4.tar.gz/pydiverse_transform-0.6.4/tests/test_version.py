# Copyright (c) QuantCo and pydiverse contributors 2025-2025
# SPDX-License-Identifier: BSD-3-Clause


def test_version():
    import pydiverse.transform as pdt

    print(f"pdt.__version__ = \n{pdt.__version__}\n")
