"""
Setup script for pycontroldae
This file is kept for backward compatibility.
All configuration is in pyproject.toml
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
