from portal_tool.tool import app


def main():
    app()


if __name__ == "__main__":
    main()
