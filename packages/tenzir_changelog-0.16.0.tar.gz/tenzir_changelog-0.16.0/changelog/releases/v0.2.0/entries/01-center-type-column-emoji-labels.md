---
title: Center type column emoji labels
type: change
authors:
- mavam
- codex
created: 2025-10-21
---

Render entry types with aligned emoji icons, and gate the project banner behind an opt-in `--banner` flag.
