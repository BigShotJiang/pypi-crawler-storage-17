"""Version information for henriqueslab-updater."""

__version__ = "1.2.0"
