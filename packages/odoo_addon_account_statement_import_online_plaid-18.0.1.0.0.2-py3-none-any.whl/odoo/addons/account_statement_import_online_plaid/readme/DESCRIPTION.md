This module provides online bank statements from Plaid.com, supporting
both Sandbox and Production environments.
