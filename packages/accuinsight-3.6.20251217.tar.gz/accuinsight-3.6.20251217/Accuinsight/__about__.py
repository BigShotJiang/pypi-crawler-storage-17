"""Contains meta-information about the modeler package.
"""

__all__ = ("__version__", "__author__", "__url__")

__version__ = "3.6.20251217"

__author__ = "Twolinecloud"

__url__ = ""

