from Accuinsight.__about__ import __author__, __url__, __version__


def modelerInfo():
    return ("mlcc information: version: %s, author: %s, url: %s" \
            % (__version__, __author__, __url__))
