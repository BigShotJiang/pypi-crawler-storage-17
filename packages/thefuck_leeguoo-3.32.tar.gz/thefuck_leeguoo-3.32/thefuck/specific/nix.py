from thefuck.utils import which

nix_available = bool(which('nix'))
