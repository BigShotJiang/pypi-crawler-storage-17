#MediLink_Azure.py

import requests
import json
import os

# Define the Azure AD tenant ID and client ID
TENANT_ID = 'your-tenant-id'
CLIENT_ID = 'your-client-id'

# Define the Azure AD endpoint


