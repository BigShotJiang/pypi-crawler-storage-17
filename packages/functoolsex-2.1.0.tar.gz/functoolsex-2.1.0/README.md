# functools-ex

I do not think this project is necessary.

# Ignore these
```bash
# doc test
python -m doctest functoolsex/func.py

# edit tag in setup.py
git tag v0.0.1
rm dist/functoolsex-*
python setup.py sdist bdist_wheel
twine upload dist/*
```
