from query_patterns.cli.runner.sqlalchemy import SQLAlchemyRunner


class SQLModelRunner(SQLAlchemyRunner):
    pass
