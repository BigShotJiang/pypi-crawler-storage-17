# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

from ._version import __version__ as version  # noqa

__all__ = [
    "version",
]
