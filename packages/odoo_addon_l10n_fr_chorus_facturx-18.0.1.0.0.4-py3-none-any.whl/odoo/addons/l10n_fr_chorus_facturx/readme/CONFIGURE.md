Refer to the README of the module *l10n_fr_chorus_account*.
