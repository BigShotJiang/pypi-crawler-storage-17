<!-- DOCTOC SKIP -->
# Changelog

## [1.1.1](https://github.com/City-of-Helsinki/django-logger-extra/compare/v1.1.0...v1.1.1) (2025-12-18)


### Bug Fixes

* Default to str in json serialization ([f56b71c](https://github.com/City-of-Helsinki/django-logger-extra/commit/f56b71c3ff5829cb8d80d7b020780177c13bad21))

## [1.1.0](https://github.com/City-of-Helsinki/django-logger-extra/compare/v1.0.0...v1.1.0) (2025-11-20)


### Features

* Add formatters for gunicorn ([f7a5eb9](https://github.com/City-of-Helsinki/django-logger-extra/commit/f7a5eb958e118e56a2f7a062aa211f4f2627f8cf))


### Documentation

* Use double quotes in README code blocks ([199358c](https://github.com/City-of-Helsinki/django-logger-extra/commit/199358c069582255d466a0e9b73ba3895d359878))

## [1.0.0](https://github.com/City-of-Helsinki/django-logger-extra/compare/v0.1.0...v1.0.0) (2025-11-13)


### Dependencies

* Update python and django version support ([c1eccc4](https://github.com/City-of-Helsinki/django-logger-extra/commit/c1eccc4bf013839c9084da0706ba34a1c208de90))
