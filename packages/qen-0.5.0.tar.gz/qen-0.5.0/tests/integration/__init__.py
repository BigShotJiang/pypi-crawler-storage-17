"""Integration tests using REAL GitHub API - NO MOCKS."""
