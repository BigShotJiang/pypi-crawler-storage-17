from __future__ import annotations

from .client import CrowdStrikeAidrClient

__all__ = ("CrowdStrikeAidrClient",)
