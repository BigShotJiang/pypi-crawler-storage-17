# PLEASE DO NOT MODIFY THIS FILE MANUALLY.
# This file re-exports everything from the connector-sdk-types package for backwards compatibility.
# Any time someone changes the OpenAPI spec, this file needs to be regenerated.

from connector_sdk_types.generated.models.create_account_entitlement import CreateAccountEntitlement

__all__ = [
    "CreateAccountEntitlement",
]
