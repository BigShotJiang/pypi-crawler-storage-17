
url = "http://127.0.0.1"
port = "8081"
connected = False
api_key = None
verify = True # This can be a boolean or a path to a CA bundle file (in case of self-signed certificate it's required)

# Is filled in the initModel
client = None
ca = None
cacheLoc = ""
session = None
