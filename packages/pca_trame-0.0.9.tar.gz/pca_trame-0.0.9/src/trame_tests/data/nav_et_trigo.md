# Navigation et Trigonométrie



## Une histoire de triangles



trignale example vent bateau positions + vecteurs (courants ) etc etc jusque triangulation 



attam:trames/alidade/batiment_guepard.jpg


## Suivre un cap


Encore plus de contenu


- abc
- clafg
- adef

## Se repérer



```bash
ls
```

```python
lambda x: x
```

```
idk
```

```yaml
ping: pong
```




| Month    | Savings |
| -------- | ------- |
| January  | $250    |
| February | $80     |
| March    | $420    |



some paragrpah

followed by this one


### Footnotes


FIRST EXAMPLE

This statement needs a source.[^5]

[^5]: Find more info [here](https://example.com).


SECOND EXAMPLE

This topic covers several points.[^7]

[^7]: Points to consider: 

    - First point 
    - Second point

</div>



THIRD EXAMPLE

This is a statement.[^6]

[^6]: This footnote contains *italic*, **bold**, and `code` text.



### Works Cited

- Smith, John. *Title of the Work*. Publisher, 2020.
- lalalala



