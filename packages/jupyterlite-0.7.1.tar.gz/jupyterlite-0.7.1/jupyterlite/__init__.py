"""JupyterLite metapackage"""

__version__ = "0.7.1"
