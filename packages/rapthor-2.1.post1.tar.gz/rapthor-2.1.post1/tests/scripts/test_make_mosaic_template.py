from rapthor.scripts.make_mosaic_template import main


def test_make_mosaic_template():
    """
    Test the main function of the make_mosaic_template script.
    """
    # # Define test parameters
    # input_image_list = ["test_image1.fits", "test_image2.fits"]
    # vertices_file_list = ["test_vertices1.txt", "test_vertices2.txt"]
    # output_image = "test_mosaic_template.fits"
    # skip = False
    # padding = 1.1
    # main(input_image_list, vertices_file_list, output_image, skip=skip, padding=padding)
    pass
