"""
Tests for the regrid_image script.
"""

from rapthor.scripts.regrid_image import main


def test_main():
    # # Define test parameters
    # input_image = "test_input.fits"
    # template_image = "test_template.fits"
    # vertices_file = "test_vertices.txt"
    # output_image = "test_output.fits"
    # skip = False
    # main(input_image, template_image, vertices_file, output_image, skip)
    # # Check if output_image is created or processed correctly
    pass
