import pytest
from rapthor.scripts.concat_ms import (concat_freq_command, concat_ms,
                                       concat_time_command, main)


def test_concat_ms():
    """
    Test the concat_ms function.
    """
    #     # Define test parameters
    #     msfiles = ["test1.ms", "test2.ms"]
    #     output_file = "output.ms"
    #     data_colname = "DATA"
    #     concat_property = "frequency"
    #     overwrite = False
    #     concat_ms(msfiles, output_file, data_colname, concat_property, overwrite)
    pass


def test_concat_freq_command():
    """
    Test the concat_freq_command function.
    """
    #     # Define test parameters
    #     msfiles = ["test1.ms", "test2.ms"]
    #     output_file = "output.ms"
    #     data_colname = "DATA"
    #     make_dummies = True
    #     concat_freq_command(msfiles, data_colname, output_file, make_dummies)
    pass


def test_concat_time_command():
    """
    Test the concat_time_command function.
    """
    #     # Define test parameters
    #     msfiles = ["test1.ms", "test2.ms"]
    #     output_file = "output.ms"
    #     concat_time_command(msfiles, output_file)
    pass


def test_main():
    #     """
    #     Test the main function of the concat_ms script.
    #     """
    #     main()
    pass
