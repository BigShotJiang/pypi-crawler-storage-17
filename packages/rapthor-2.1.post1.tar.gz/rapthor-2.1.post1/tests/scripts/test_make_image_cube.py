"""
Test for the make_image_cube script.
"""

from rapthor.scripts.make_image_cube import main


def test_main():
    """
    Test the main function of the make_image_cube script.
    """
    # # Define test parameters
    # input_image_filenames = ["image1.fits", "image2.fits"]
    # output_image_filename = "output_cube.fits"
    # output_beams_filename = "output_beams.txt"
    # output_frequencies_filename = "output_frequencies.txt"
    # main(input_image_filenames, output_image_filename, output_beams_filename=output_beams_filename,
    #      output_frequencies_filename=output_frequencies_filename)
    pass