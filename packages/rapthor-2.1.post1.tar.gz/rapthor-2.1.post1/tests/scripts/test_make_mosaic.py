"""
Test for the make_mosaic script.
"""

from rapthor.scripts.make_mosaic import main


def test_make_mosaic():
    """
    Test the main function of the make_mosaic script.
    """
    # # Define test parameters
    # input_image_list = ["test_image1.fits", "test_image2.fits"]
    # template_image = "test_template.fits"
    # output_image = "test_mosaic_output.fits"
    # skip = False
    # main(input_image_list, template_image, output_image, skip=skip)
    pass
