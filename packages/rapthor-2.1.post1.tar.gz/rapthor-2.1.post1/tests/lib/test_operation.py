"""
Test cases for the `rapthor.lib.operation` module.
"""

from rapthor.lib.operation import Operation


class TestOperation:
    """
    Test cases for the `Operation` class in the `rapthor.lib.operation` module.
    """

    def test_set_parset_parameters(self):
        pass

    def test_set_input_parameters(self):
        pass

    def test_setup(self):
        pass

    def test_finalize(self):
        pass

    def test_is_done(self):
        pass

    def test_run(self):
        pass
