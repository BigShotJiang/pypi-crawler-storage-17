"""
Test cases for the `rapthor.lib.modifystate` module.
"""

from pathlib import Path

from rapthor.modifystate import run


def test_run():
    """
    Test the run function of the modifystate module.
    """
    # parset_file = Path(__file__).parent / "resources" / "test.parset"
    # run(parset_file)
    pass
