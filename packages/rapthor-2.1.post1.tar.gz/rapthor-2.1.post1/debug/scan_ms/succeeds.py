import casacore.tables as pt
import shapely.geometry
tab = pt.table('/project/rapthor/Data/rapthor/N6946/N6946.ms')
