#!/bin/bash

id
. venv/bin/activate
cd /project/rapthor/Share/rapthor/N6946
rapthor -v rapthor.parset

