docker build -t rapthor-debug .
