The parset module
=================

The parset module defines various functions used to handle the Rapthor parset.

.. automodule:: rapthor.lib.parset
   :members:
