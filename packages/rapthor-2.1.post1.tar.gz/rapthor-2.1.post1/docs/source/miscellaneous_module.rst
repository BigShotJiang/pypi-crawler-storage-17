The miscellaneous module
========================

The miscellaneous module defines various miscellaneous functions used in Rapthor.

.. automodule:: rapthor.lib.miscellaneous
   :members:
