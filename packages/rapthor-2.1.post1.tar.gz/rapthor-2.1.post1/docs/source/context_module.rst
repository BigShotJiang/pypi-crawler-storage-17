The context module
==================

The context module defines various context managers used in Rapthor.

.. automodule:: rapthor.lib.context
   :members:
