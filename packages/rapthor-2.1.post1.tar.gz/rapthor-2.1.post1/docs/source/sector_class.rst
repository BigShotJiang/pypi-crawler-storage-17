The Sector class
================

The Sector class is used to manage imaging parameters for an image.

.. autoclass:: rapthor.lib.sector.Sector
   :members:
