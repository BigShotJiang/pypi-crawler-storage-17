The Observation class
=====================

The Observation class is used to handle the attributes and parameters of a measurement set.

.. autoclass:: rapthor.lib.observation.Observation
   :members:
