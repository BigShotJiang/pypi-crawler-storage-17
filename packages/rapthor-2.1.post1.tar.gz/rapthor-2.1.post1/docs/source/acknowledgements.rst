.. _acknowledgements:

Acknowledgements
================

Rapthor was developed by David Rafferty, Marcel Loose, Andre Offringa, Arend G. Dijkstra, Tammo Jan Dijkema, Mark de Wever, Frits Sweijen, and Sarod Yatawatta.
