.. _help:

Getting Help
============

Bugs that are encountered during a rapthor run can be reported on the `Rapthor GitLab issues page <https://git.astron.nl/RD/rapthor/-/issues>`_.
