The cluster module
==================

The cluster module contains various functions related to compute clusters (and also single machines).

.. automodule:: rapthor.lib.cluster
   :members:
