.. _future_work:

Issues and feature requests
===========================

Please see the `Rapthor GitLab issues page <https://git.astron.nl/RD/rapthor/-/issues>`_ for a current list of issues and feature requests.
