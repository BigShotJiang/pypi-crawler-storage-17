The Field class
===============

The Field class is used to manage the overall state and parameters of observed field, including observations, images, calibration solutions, etc.

.. autoclass:: rapthor.lib.field.Field
   :members:
