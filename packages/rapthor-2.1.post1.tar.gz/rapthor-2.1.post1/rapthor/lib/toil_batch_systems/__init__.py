from . import toil_batch_system_slurm_static

