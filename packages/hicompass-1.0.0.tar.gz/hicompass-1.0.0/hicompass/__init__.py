"""Hi-Compass: Cell-type-specific chromatin interaction prediction."""

__version__ = '1.0.0'