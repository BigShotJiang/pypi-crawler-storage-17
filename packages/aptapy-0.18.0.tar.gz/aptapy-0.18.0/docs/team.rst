.. _team:

Contributors
============

.. list-table:: Contributors
   :header-rows: 1
   :widths: 30 15 20

   * - Name (affiliation)
     - GitHub
     - Email
   * - `Luca Baldini <https://osiris.df.unipi.it/~baldini>`_ (University and INFN, Pisa)
     - `@lucabaldini <https://github.com/lucabaldini>`_
     - `luca.baldini@pi.infn.it <mailto:luca.baldini@pi.infn.it>`_
   * - Augusto Cattafesta (University and INFN, Pisa)
     - `@augustocattafesta <https://github.com/augustocattafesta>`_
     - `a.cattafesta@studenti.unipi.it <mailto:a.cattafesta@studenti.unipi.it>`_