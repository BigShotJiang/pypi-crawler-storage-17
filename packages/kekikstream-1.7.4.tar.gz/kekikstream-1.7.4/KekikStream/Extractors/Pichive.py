# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Extractors.ContentX import ContentX

class Pichive(ContentX):
    name     = "Pichive"
    main_url = "https://pichive.online"