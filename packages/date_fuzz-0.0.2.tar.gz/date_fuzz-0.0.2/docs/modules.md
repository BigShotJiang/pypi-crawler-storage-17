::: date_fuzz.find_dates
::: date_fuzz.strip_dates
