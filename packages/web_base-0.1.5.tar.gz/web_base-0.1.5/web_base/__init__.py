from web_base.config import ElementsPressents, WebBase

__author__ = 'MatheusLPolidoro'
__version__ = '0.1.5'
__all__ = ['WebBase', 'ElementsPressents']
