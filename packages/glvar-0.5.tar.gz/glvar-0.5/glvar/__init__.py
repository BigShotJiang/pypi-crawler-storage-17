"""glvar - Fetch variables from GitLab and inject into environment for local commands."""

from .cli import __version__

__all__ = ["__version__"]
