"""Allow running as `python -m glvar`."""

from glvar.cli import main

if __name__ == "__main__":
    main()
