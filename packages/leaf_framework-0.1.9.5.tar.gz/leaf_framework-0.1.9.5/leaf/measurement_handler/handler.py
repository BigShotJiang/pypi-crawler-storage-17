from influxobject import InfluxPoint

'''
Unused for now.
'''
class MeasurementHandler:
    def __init__(self):
        pass

    def add_measurement(self,term,value):
        pass