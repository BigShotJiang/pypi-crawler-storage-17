"""
SCATE (Semantically Compositional Annotation for TEmporal expressions) module.

This module contains the neural parser implementation.
"""

__all__ = []
