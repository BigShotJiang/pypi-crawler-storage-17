class DelugeWebClientError(Exception):
    """Handles all expected exceptions"""
