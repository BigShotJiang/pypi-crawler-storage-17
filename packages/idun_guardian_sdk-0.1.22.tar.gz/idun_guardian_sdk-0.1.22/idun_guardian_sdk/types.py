from enum import Enum, auto


class FileTypes(Enum):
    EEG = auto()
    IMU = auto()
    IMPEDANCE = auto()
