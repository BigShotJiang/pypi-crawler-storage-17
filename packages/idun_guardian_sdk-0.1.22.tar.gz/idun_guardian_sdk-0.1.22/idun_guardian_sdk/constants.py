PLATFORM = "SDK_PYTON"
LOG_FORMAT = "[%(levelname)s] %(asctime)s: %(message)s"
