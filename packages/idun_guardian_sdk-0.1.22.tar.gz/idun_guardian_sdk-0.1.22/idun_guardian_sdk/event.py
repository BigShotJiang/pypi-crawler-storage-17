from abc import ABC


class Event(ABC):
    pass
