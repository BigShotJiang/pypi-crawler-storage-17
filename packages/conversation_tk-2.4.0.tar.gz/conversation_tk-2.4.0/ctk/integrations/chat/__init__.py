"""
Chat interface for CTK.
"""

from ctk.integrations.chat.tui import ChatTUI

__all__ = ['ChatTUI']
