"""A Python telnet client library."""

from __future__ import annotations

from .client import TelnetClient

__all__ = ["TelnetClient"]
__version__ = "1.0.0"
