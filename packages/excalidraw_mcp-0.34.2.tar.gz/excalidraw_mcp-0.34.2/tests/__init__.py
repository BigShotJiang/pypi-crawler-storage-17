"""Test package for Excalidraw MCP server."""
