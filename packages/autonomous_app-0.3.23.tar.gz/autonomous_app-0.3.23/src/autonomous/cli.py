def createapp():
    print("app created")
