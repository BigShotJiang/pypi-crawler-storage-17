# Version of the InsightSolver API client library
__version__ = "0.1.83"