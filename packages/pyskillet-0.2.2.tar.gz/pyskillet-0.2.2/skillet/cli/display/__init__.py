"""Display components for CLI."""

from .live import LiveDisplay

__all__ = ["LiveDisplay"]
