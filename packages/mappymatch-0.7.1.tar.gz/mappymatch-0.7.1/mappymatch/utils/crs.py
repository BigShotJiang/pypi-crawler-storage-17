from pyproj import CRS

LATLON_CRS = CRS(4326)
XY_CRS = CRS(3857)
