class MapException(Exception):
    """
    An exception for any errors that occur with the MapInterface
    """

    pass
