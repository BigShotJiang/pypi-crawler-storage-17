"""
Copyright (c) 2023, Zscaler Inc.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"""

from zscaler.request_executor import RequestExecutor
from zscaler.zeasm.organizations import OrganizationsAPI
from zscaler.zeasm.findings import FindingsAPI
from zscaler.zeasm.lookalike_domains import LookALikeDomainsAPI


class ZEASMService:
    """ZEASM Service client, exposing various ZEASM APIs"""

    def __init__(self, request_executor: RequestExecutor) -> None:
        self._request_executor = request_executor

    @property
    def organizations(self) -> OrganizationsAPI:
        """
        The interface object for the :ref:`ZEASM Organization interface <zeasm-organizations>`.

        """
        return OrganizationsAPI(self._request_executor)

    @property
    def findings(self) -> FindingsAPI:
        """
        The interface object for the :ref:`ZEASM Findings interface <zeasm-findings>`.

        """
        return FindingsAPI(self._request_executor)

    @property
    def lookalike_domains(self) -> LookALikeDomainsAPI:
        """
        The interface object for the :ref:`ZEASM LookALike Domains interface <zeasm-lookalike_domains>`.

        """
        return LookALikeDomainsAPI(self._request_executor)
