# Main contributors

The main contributors are:

- Pierre Augier (LEGI, CNRS, UGA)
- Cyrille Bonamy (LEGI, CNRS, UGA)
- Ashwin Vishnu (KTH)
- Antoine Campagne (LEGI, CNRS, UGA)
- Pierre Blanc-Fatin (LEGI, UGA)
