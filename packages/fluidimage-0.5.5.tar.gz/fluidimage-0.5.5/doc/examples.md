# Examples

```{toctree}
---
maxdepth: 2
---
examples/preproc
examples/piv_try_params
examples/piv_parallel
examples/piv_cluster
examples/bos_parallel
examples/optflow_try_params
examples/optflow_parallel
examples/piv_as_real/README
examples/pivchallenge/README
```

See also
<https://foss.heptapod.net/fluiddyn/fluidimage/tree/branch/default/doc/examples>.
