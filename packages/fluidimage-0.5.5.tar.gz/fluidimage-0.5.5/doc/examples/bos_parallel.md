# BOS computation

This minimal example presents how to carry out a simple BOS computation. See also the
documentation of the class {class}`fluidimage.bos.Topology` and the work defined in the
subpackage {mod}`fluidimage.works.piv`.

```{literalinclude} bos_parallel.py
```
