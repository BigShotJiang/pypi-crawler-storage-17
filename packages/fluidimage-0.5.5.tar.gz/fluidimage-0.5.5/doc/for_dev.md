# Contribute to Fluidimage

```{toctree}
---
maxdepth: 1
---
CONTRIBUTING.md
Advice for FluidDyn developers <http://fluiddyn.readthedocs.io/en/latest/advice_developers.html>
overview_orga_package
build-from-source
related_codes
to_do
```
