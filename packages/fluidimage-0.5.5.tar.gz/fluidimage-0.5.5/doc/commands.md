# Commands

Fluidimage provides few useful commands:

- `fluidimage-monitor`: monitor Fluidimage computations.
- `fluidimviewer`: visualize images.
- `fluidpivviewer`: visualize PIV fields.
- `fluidimage-mean`: compute the mean of images.
