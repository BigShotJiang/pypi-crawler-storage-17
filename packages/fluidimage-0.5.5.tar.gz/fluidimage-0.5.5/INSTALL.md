# Install Fluidimage

You can either install without compilation (see
https://fluidimage.readthedocs.io/en/latest/install.html) or install from source with
compilation (see https://fluidimage.readthedocs.io/en/latest/build-from-source.html)
