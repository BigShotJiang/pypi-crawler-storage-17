"""Topology launcher (:mod:`fluidimage.gui.launcher`)
=====================================================

.. autosummary::
   :toctree:

   main

"""
