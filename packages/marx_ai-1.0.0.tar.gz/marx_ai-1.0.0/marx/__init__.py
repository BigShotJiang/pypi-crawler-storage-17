"""Marx: Automated multi-agent code review tool for GitHub PRs."""

__version__ = "1.0.0"
