# HealthSecure

**Runtime sensitive data exposure detection for APIs and LLM outputs**

Detect when sensitive data (medical, financial, credentials, personal identifiers) leaks into API responses or LLM outputs before it reaches end users.

---

## What This Product Does

HealthSecure analyzes API responses and LLM outputs **locally** to detect sensitive data exposure:

- **Medical data**: diagnoses, treatments, patient information
- **Financial data**: credit cards, account numbers, payment information
- **Credentials**: API keys, tokens, passwords, secrets
- **Personal identifiers**: email addresses, phone numbers

The SDK extracts classification metadata (not raw data) and sends it to the backend for risk assessment. **No raw sensitive data ever leaves your environment.**

---

## What It Does NOT Do

❌ **No raw data ingestion** - Raw data is analyzed locally and never transmitted

❌ **No compliance guarantees** - This is a detection tool, not a compliance certification

❌ **No schema understanding** - Works with unknown JSON schemas via heuristic detection

❌ **No ML models** - Deterministic keyword and pattern matching

❌ **No data storage** - No persistence of any kind

---

## How Detection Works

```
Raw Data (Local) → Extract Signal → Send to Backend → Risk Assessment
     ↓                    ↓                ↓                ↓
  JSON/Text      Classification      Signal Payload    HIGH/MEDIUM/LOW
              Metadata Only         (No Raw Data)
```

1. **Local Extraction**: SDK analyzes raw data locally using keyword matching and pattern detection
2. **Signal Generation**: Only classification metadata is extracted (data classes, identifier presence, confidence)
3. **Risk Assessment**: Backend evaluates risk based on signal metadata
4. **Trust Boundary**: Raw data is deleted before transmission

---

## 5-Minute Quickstart

### Installation

**From PyPI (v0.1.0a1 - Alpha Release):**

```bash
pip install healthsecure
```

**From TestPyPI (for testing):**

```bash
pip install --index-url https://test.pypi.org/simple/ healthsecure
```

**From source:**

```bash
git clone <repo>
cd healthsecure
pip install -e .
```

### Basic Usage

```python
from datetime import datetime, timezone
from healthsecure import HealthSecureClient, SignalPayload, extract_from_json

# Your raw API response (or LLM output)
raw_api_response = {
    "message": "API token leaked: sk_live_ABC123",
    "status": "error"
}

# Extract signal locally (raw data never leaves your environment)
classes, identifiers, confidence = extract_from_json(raw_api_response)

# Delete raw data
del raw_api_response

# Create signal payload
signal = SignalPayload(
    signal_type="OUTPUT_EXPOSURE",
    source="api_response",
    detected_data_classes=list(classes) if classes else ["personal"],
    identifiers_present=identifiers,
    confidence=confidence,
    region="EU",
    environment="production",
    timestamp=datetime.now(timezone.utc)
)

# Send to backend for risk assessment
client = HealthSecureClient(
    api_key="your-api-key",
    base_url="http://localhost:8000"  # or production URL
)

result = client.analyze_signal(signal)
print(f"Risk Level: {result.risk_level}")
print(f"Affected Data Classes: {result.affected_data_classes}")
```

### Example Output

```
Risk Level: HIGH
Signal: SENSITIVE_DATA_EXPOSED
Affected Data Classes: ['credentials']
Context: {'source': 'api_response', 'environment': 'production', 'region': 'EU'}
Explanation: Sensitive data detected in a production response.
```

### Real-World Example: Unknown JSON Schema

```python
# Works with any JSON structure - no schema required
unknown_response = {
    "x1": "Paid via credit card 4111 1111 1111 1111",
    "x2": "contact: abc@company.com",
    "x9": "API token leaked: sk_test_xxx"
}

classes, identifiers, confidence = extract_from_json(unknown_response)
# Detects: ['financial', 'credentials'], identifiers=True
```

### Killer Demo: Safe LLM Wrapper

**Instant relevance for AI teams** - Wrap your LLM calls to detect sensitive data leakage:

```python
from healthsecure import safe_llm_call

# Wrap any LLM call
response, risk = safe_llm_call(
    "Patient John Doe (john@hospital.com) was diagnosed with HIV"
)

if risk == "HIGH":
    print("⚠️  Sensitive data detected! Blocking response.")
    # Block or sanitize response
else:
    print("✅ Response safe to return")
```

**See full example**: `example-app/safe_llm_call.py`

This wrapper:
- ✅ Analyzes LLM output locally (no raw data leaves your environment)
- ✅ Returns risk level (LOW/MEDIUM/HIGH)
- ✅ Works with any LLM (OpenAI, Anthropic, etc.)
- ✅ <30 lines of code

---

## Detection Limits

### Heuristic-Based Detection

HealthSecure uses **keyword matching and pattern detection**, not machine learning or schema understanding:

- ✅ **High-confidence signals**: Detects obvious sensitive data (credit cards, API keys, medical terms)
- ⚠️ **Best-effort coverage**: May miss context-dependent or obfuscated data
- ⚠️ **False positives possible**: Generic terms may trigger false alarms
- ⚠️ **No semantic understanding**: Cannot distinguish between "patient" (medical) and "patient" (waiting)

### Supported Data Classes

- **Medical**: 9 keywords (hiv, cancer, diabetes, diagnosis, treatment, medical, patient, disease, diagnosed)
- **Financial**: 9 keywords (credit, debit, card, iban, account, payment, paid, transaction, billing)
- **Credentials**: 8 keywords (token, api_key, apikey, secret, password, auth, bearer, sk_)
- **Personal Identifiers**: Email addresses (regex), phone numbers (regex)

### What Gets Detected

✅ Credit card numbers (pattern matching)  
✅ API keys (pattern matching: sk_, pk_, api_)  
✅ Email addresses (regex)  
✅ Medical keywords in text  
✅ Financial keywords in text  
✅ Credential keywords in text  

### What May Be Missed

⚠️ Encrypted or encoded data  
⚠️ Context-dependent sensitive information  
⚠️ Industry-specific terminology not in keyword set  
⚠️ Structured data in non-standard formats  

---

## API Reference

### `extract_from_json(payload: Dict[str, Any]) -> Tuple[Set[str], bool, float]`

Analyze raw JSON locally. Returns:
- `detected_classes`: Set of data classes found (medical, financial, credentials)
- `identifiers_present`: Boolean indicating if personal identifiers were detected
- `confidence`: Float (0.0-1.0) indicating detection confidence

### `extract_from_text(text: str) -> Tuple[Set[str], bool, float]`

Analyze raw text (e.g., LLM output). Same return format as `extract_from_json`.

### `HealthSecureClient.analyze_signal(payload: SignalPayload) -> SignalResponse`

Send signal to backend for risk assessment. Returns risk level (LOW/MEDIUM/HIGH) and explanation.

---

## Risk Assessment Logic

- **HIGH Risk**: 
  - Credentials detected in production (inherently high-risk)
  - Medical/biometric/children data + identifiers in production
  
- **MEDIUM Risk**: 
  - Identifiers present with other sensitive data
  - Sensitive data in staging/development
  
- **LOW Risk**: 
  - No identifiers, no high-risk classes

---

## Requirements

- Python >= 3.9
- requests >= 2.31.0
- pydantic >= 2.0.0

---

## Stability & Contracts

**v1 contracts are frozen** - See [STABILITY.md](STABILITY.md) for:
- Locked signal schema
- Frozen risk policy table
- Documented extractor limitations
- Versioning strategy

---

## License

[Your License Here]

---

## Support

For issues, questions, or contributions, please [open an issue](link-to-issues).
