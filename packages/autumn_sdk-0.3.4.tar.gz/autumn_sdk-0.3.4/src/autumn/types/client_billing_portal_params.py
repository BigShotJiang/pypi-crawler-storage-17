# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["ClientBillingPortalParams"]


class ClientBillingPortalParams(TypedDict, total=False):
    query_return_url: Annotated[str, PropertyInfo(alias="return_url")]
    """URL to redirect to when back button is clicked in the billing portal"""

    configuration_id: str
    """Stripe billing portal configuration ID.

    Create configurations in your Stripe dashboard.
    """

    body_return_url: Annotated[str, PropertyInfo(alias="return_url")]
    """URL to redirect to when back button is clicked in the billing portal"""
