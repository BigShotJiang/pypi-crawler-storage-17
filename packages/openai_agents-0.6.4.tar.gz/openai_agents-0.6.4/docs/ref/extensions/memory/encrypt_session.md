# `EncryptedSession`

::: agents.extensions.memory.encrypt_session.EncryptedSession
