# Shared module - shared utilities

