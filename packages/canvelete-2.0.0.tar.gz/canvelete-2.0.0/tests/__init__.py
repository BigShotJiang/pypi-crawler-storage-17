"""Test suite for Canvelete Python SDK."""
