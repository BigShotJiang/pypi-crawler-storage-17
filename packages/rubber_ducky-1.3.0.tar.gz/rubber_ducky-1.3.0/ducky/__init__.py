from .ducky import ducky, main

__all__ = ["ducky", "main"]
