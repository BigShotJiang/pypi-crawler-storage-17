"""
utils module
"""
import os
from pathlib import Path

RULES_FOLDER = Path(os.path.abspath(__file__)).parent
