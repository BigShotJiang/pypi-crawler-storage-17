__doc__ = """
Directory where the data are prepared as input for the AMPL optimization.
"""