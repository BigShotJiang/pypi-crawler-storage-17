"""
MisTIC

An algorithm to reassign transcripts 
"""

from MisTIC.mistic_class import mistic