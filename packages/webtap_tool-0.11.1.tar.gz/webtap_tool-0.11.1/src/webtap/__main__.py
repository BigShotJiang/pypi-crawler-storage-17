"""Entry point for python -m webtap."""

from webtap import main

if __name__ == "__main__":
    main()
