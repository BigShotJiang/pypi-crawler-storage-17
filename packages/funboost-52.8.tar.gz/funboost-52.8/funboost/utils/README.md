# 这里的utils功能是从已有项目复制出来的，大部分没用到，不要管这里。

# 最主要的是要看base_consumer.py,框架90%逻辑流程在 AbstractConsumer