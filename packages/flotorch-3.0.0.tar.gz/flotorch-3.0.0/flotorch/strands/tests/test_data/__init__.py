"""Test data package for Strands tests."""

