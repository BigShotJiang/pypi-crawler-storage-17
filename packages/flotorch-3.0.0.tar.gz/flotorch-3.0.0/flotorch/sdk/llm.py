from typing import List, Dict, Tuple,Optional, Tuple, Union, Any

from flotorch.sdk.utils.llm_utils import invoke, async_invoke, parse_llm_response, LLMResponse
from flotorch.sdk.logger.global_logger import get_logger
from flotorch.sdk.logger.utils.models import (
    Error, ObjectCreation, LLMRequest, LLMResponse
)
logger = get_logger()

class FlotorchLLM:
    def __init__(self, model_id: str, api_key: str, base_url: str):
        self.model_id = model_id
        self.api_key = api_key
        self.base_url = base_url
        
        # Log object creatio
        logger.info(
            ObjectCreation(
            class_name="FlotorchLLM",
            extras = {"base_url": base_url, "model_id": model_id}
            )
        )
    
    def invoke(
        self,
        messages: List[Dict[str, str]], 
        tools: Optional[List[Dict]] = None, 
        response_format=None, 
        extra_body: Optional[Dict] = None, 
        **kwargs
    ) -> Union[LLMResponse, Tuple[LLMResponse, Any]]:

        #log llm_request
        logger.info(
                LLMRequest(model=self.model_id, messages=messages, tools=tools)
            )
        try:
            # Extract return_headers before passing to invoke
            return_headers = kwargs.pop('return_headers', False)
            response = invoke(messages, self.model_id, self.api_key, self.base_url, tools=tools, response_format=response_format, extra_body=extra_body, return_headers=return_headers, **kwargs)
            if return_headers:
                response_body, response_headers = response
            else:
                response_body = response

            parsed_response = parse_llm_response(response_body)
            # Log response details
            tool_calls = response_body.get('choices', [{}])[0].get('message', {}).get('tool_calls', [])
            usage = response_body.get('usage', {})
            
            # Determine if this is likely a final response (no tool calls and has content)
            is_final_response = bool(not tool_calls and parsed_response.content.strip())
            logger.info(
                LLMResponse(
                    model=self.model_id,
                    content=parsed_response.content,
                    tool_calls=tool_calls,
                    usage=usage,
                    is_final_response=is_final_response,
                ))
            
            if return_headers:
                return parsed_response, response_headers
            else:
                return parsed_response
        except Exception as e:
            logger.error(
                Error(operation="FlotorchLLM.invoke", error=e)
            )
            raise

    async def ainvoke(
        self, 
        messages: List[Dict[str, str]],
        tools: Optional[List[Dict]] = None,
        response_format=None, 
        extra_body: Optional[Dict] = None,
        **kwargs
    ) -> Union[LLMResponse, Tuple[LLMResponse, Any]]:
        """
        Invoke LLM with individual parameters instead of a complete payload.
        Creates the payload internally from the provided parameters.
        """
        # Log request details
        logger.info(
            LLMRequest(model=self.model_id, messages=messages, tools=tools, request_type='async')
        )
        try:
            # Extract return_headers before passing to async_invoke
            return_headers = kwargs.pop('return_headers', False)
            
            # Use the utility function that handles payload creation
            response = await async_invoke(messages, self.model_id, self.api_key, self.base_url, tools=tools, response_format=response_format, extra_body=extra_body, return_headers=return_headers, **kwargs)
            if return_headers:
                response_body, response_headers = response
            else:
                response_body = response
            
            parsed_response = parse_llm_response(response_body)
            # Log response details
            tool_calls = response_body.get('choices', [{}])[0].get('message', {}).get('tool_calls', [])
            usage = response_body.get('usage', {})
            
            # Determine if this is likely a final response (no tool calls and has content)
            is_final_response = bool(not tool_calls and parsed_response.content.strip())
            logger.info(
                LLMResponse(
                    model=self.model_id,
                    content=parsed_response.content,
                    tool_calls=tool_calls,
                    usage=usage,
                    is_final_response=is_final_response,
                    request_type='async',
                )
            )
            
            if return_headers:
                return parsed_response, response_headers
            else:
                return parsed_response
        except Exception as e:
            logger.error(Error(operation="FLotorchLLM.ainvoke", error=e))
            raise