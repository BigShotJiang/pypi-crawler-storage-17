<p align="center"><img width="50%" src="docs/logo.png" /></p>

# Mononoqe

`mononoqe` is a simple python library to mix Neural Network and Quantum computing.
