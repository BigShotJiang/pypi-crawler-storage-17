# topdogalerts/evaluation/__init__.py
"""
Trigger evaluation module for topdogalerts.
"""
from .evaluator import evaluate

__all__ = ["evaluate"]
