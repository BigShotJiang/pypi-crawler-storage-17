# ovos-utterance-normalizer

normalizes utterances before intent parsing

additionally, encoding errors are handled via [python-ftfy](https://github.com/rspeer/python-ftfy)

enabled by default in [mycroft.conf](https://github.com/OpenVoiceOS/ovos-config/blob/dev/ovos_config/mycroft.conf#L129)
