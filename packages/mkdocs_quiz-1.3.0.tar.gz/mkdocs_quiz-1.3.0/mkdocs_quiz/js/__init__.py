"""JavaScript resources for MkDocs Quiz Plugin."""
