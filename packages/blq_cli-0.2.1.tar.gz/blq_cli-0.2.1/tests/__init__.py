"""Tests for blq-cli package."""
