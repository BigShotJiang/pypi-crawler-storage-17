"""Exceptions for the Earthscale client."""


class EarthscaleClientError(Exception):
    """Base exception for Earthscale client errors.

    This is the base class for all exceptions raised by the Earthscale client.
    All other client exceptions inherit from this class.
    """

    def __init__(self, message: str, error_class: str | None = None):
        self.message = message
        self.error_class = error_class
        super().__init__(message)


class AuthenticationError(EarthscaleClientError):
    """Raised when authentication fails.

    This exception is raised when the client cannot authenticate with the
    Earthscale API, such as when invalid credentials are provided or when
    the refresh token has expired.
    """

    pass


class NotFoundError(EarthscaleClientError):
    """Raised when a resource is not found.

    This exception is raised when the client requests a resource that does not
    exist, such as a dataset with a non-existent ID.
    """

    pass


class ValidationFailedError(EarthscaleClientError):
    """Raised when validation fails.

    This exception is raised when the client or server validation fails,
    such as when invalid parameters are provided to an API endpoint.
    """

    pass


class TokenRefreshRequired(EarthscaleClientError):
    """Raised when a token refresh is required.

    This exception is raised when the authentication token has expired and
    needs to be refreshed before making further API requests.
    """

    pass


class VersionIncompatibleError(EarthscaleClientError):
    """Raised when the client version is incompatible with the server.

    This exception is raised when the client's API version is not supported
    by the server, indicating that the client needs to be updated.
    """

    pass


class ForbiddenError(EarthscaleClientError):
    """Raised when the user is not allowed to access the resource."""

    pass
