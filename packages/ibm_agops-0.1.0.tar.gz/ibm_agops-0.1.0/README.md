# ibm_agops

A minimal package.

## Installation

```bash
pip install ibm_agops
```

## Usage

```python
from ibm_agops import hello

print(hello())
```

