"""
SIA Package Initializer
----------------------
Modules:

1. NTT  — Entity / Object modeling
2. CHI  — Chemical analysis toolkit
3. ELS  — Enterprise Logic Studio (ABAP Interpreter) - Version 4.1
"""

# =====================================================
# Existing NTT Module
# =====================================================

from .ntt import ntt


# =====================================================
# Existing CHI Module
# =====================================================

from .chi import chi as ChiClass
chi = ChiClass(verbose=False)


# =====================================================
# SIA Enterprise Logic Studio (ABAP Interpreter) - Version 4.1
# =====================================================

try:
    # Import the complete ELS module (Version 4.1)
    from .els import (
        # Main API
        run,
        run_file,
        repl,
        safe_run,
        
        # Core components
        tokenize_abap,
        FullParser,
        RuntimeEnv,
        execute_program,
        
        # Helper functions
        load_sql_table,
        register_class,
        set_object_attr,
        get_object_attr,
        
        # Type system
        ABAPType,
        TypedVariable,
        
        # Selection options (NEW in 4.1)
        SelectionOption,
    )
    
    # Re-export with consistent naming
    els_run = run
    els_run_file = run_file
    els_repl = repl
    els_safe_run = safe_run
    els_tokenize_abap = tokenize_abap
    els_FullParser = FullParser
    els_RuntimeEnv = RuntimeEnv
    els_execute_program = execute_program
    els_load_sql_table = load_sql_table
    els_register_class = register_class
    els_set_object_attr = set_object_attr
    els_get_object_attr = get_object_attr
    els_ABAPType = ABAPType
    els_TypedVariable = TypedVariable
    
    # New in 4.1
    els_SelectionOption = SelectionOption
    
    # Optional debug flag (future extension-safe)
    els_debug = False

    def els_debug_print(*args, **kwargs):
        """Debug print helper (safe even if unused)"""
        if els_debug:
            print(*args, **kwargs)

except ImportError as e:
    print(f"[SIA] ELS interpreter not loaded: {e}")
    
    # Create placeholder functions for all exports
    def els_run(*args, **kwargs):
        raise ImportError("ELS interpreter missing. Add els.py to the sia folder.")
    
    def els_run_file(*args, **kwargs):
        raise ImportError("ELS interpreter missing. Add els.py to the sia folder.")
    
    def els_repl(*args, **kwargs):
        raise ImportError("ELS interpreter missing. Add els.py to the sia folder.")
    
    def els_safe_run(*args, **kwargs):
        print("[ELS] Interpreter missing.")
        return None
    
    # Placeholders for core components
    els_tokenize_abap = None
    els_FullParser = None
    els_RuntimeEnv = None
    els_execute_program = None
    
    # Placeholders for helper functions
    els_load_sql_table = None
    els_register_class = None
    els_set_object_attr = None
    els_get_object_attr = None
    
    # Placeholders for type system
    els_ABAPType = None
    els_TypedVariable = None
    
    # Placeholder for SelectionOption
    els_SelectionOption = None
    
    els_debug = False
    
    def els_debug_print(*args, **kwargs):
        pass

except Exception as e:
    print(f"[SIA] Unexpected error loading ELS: {e}")
    # Same fallbacks as above
    def els_run(*args, **kwargs):
        raise ImportError(f"ELS interpreter failed to load: {e}")
    
    def els_run_file(*args, **kwargs):
        raise ImportError(f"ELS interpreter failed to load: {e}")
    
    def els_repl(*args, **kwargs):
        raise ImportError(f"ELS interpreter failed to load: {e}")
    
    def els_safe_run(*args, **kwargs):
        print(f"[ELS] Interpreter failed to load: {e}")
        return None
    
    # Placeholders for core components
    els_tokenize_abap = None
    els_FullParser = None
    els_RuntimeEnv = None
    els_execute_program = None
    
    # Placeholders for helper functions
    els_load_sql_table = None
    els_register_class = None
    els_set_object_attr = None
    els_get_object_attr = None
    
    # Placeholders for type system
    els_ABAPType = None
    els_TypedVariable = None
    els_SelectionOption = None
    
    els_debug = False
    
    def els_debug_print(*args, **kwargs):
        pass


# =====================================================
# Package-level convenience functions
# =====================================================

def abap(code: str, params: dict = None) -> str:
    """Convenience function to run ABAP code"""
    return els_run(code, params)


def abap_file(filename: str, params: dict = None) -> str:
    """Convenience function to run ABAP from file"""
    return els_run_file(filename, params)


# =====================================================
# Convenience class for ABAP Development
# =====================================================

class ABAPDeveloper:
    """Convenience class for ABAP development and testing"""
    
    def __init__(self, debug: bool = False):
        self.debug = debug
        self.env = None
        self.last_output = ""
    
    def execute(self, code: str, params: dict = None) -> str:
        """Execute ABAP code and store result"""
        self.last_output = abap(code, params)
        if self.debug:
            print(f"=== Output ===\n{self.last_output}")
        return self.last_output
    
    def test(self, code: str, expected_output: str, params: dict = None) -> bool:
        """Test if ABAP code produces expected output"""
        result = self.execute(code, params)
        success = result.strip() == expected_output.strip()
        
        if self.debug:
            if success:
                print("✓ Test PASSED")
            else:
                print(f"✗ Test FAILED\nExpected: {expected_output}\nGot: {result}")
        
        return success
    
    def load_sample_data(self):
        """Load sample data for testing (employees, departments)"""
        # This would need access to RuntimeEnv internally
        print("Sample data loaded for ABAP exercises")
    
    def interactive(self):
        """Start interactive ABAP REPL"""
        els_repl()


# =====================================================
# Public API
# =====================================================

__all__ = [
    # Core modules
    "ntt",
    "chi",
    
    # Main ABAP Interpreter API
    "els_run",
    "els_run_file",
    "els_repl",
    "els_safe_run",
    
    # Core components
    "els_tokenize_abap",
    "els_FullParser",
    "els_RuntimeEnv",
    "els_execute_program",
    
    # Helper functions
    "els_load_sql_table",
    "els_register_class",
    "els_set_object_attr",
    "els_get_object_attr",
    
    # Type system
    "els_ABAPType",
    "els_TypedVariable",
    
    # Selection options (NEW in 4.1)
    "els_SelectionOption",
    
    # Debug
    "els_debug",
    "els_debug_print",
    
    # Package-level conveniences
    "abap",
    "abap_file",
    
    # Developer tools (NEW)
    "ABAPDeveloper",
]