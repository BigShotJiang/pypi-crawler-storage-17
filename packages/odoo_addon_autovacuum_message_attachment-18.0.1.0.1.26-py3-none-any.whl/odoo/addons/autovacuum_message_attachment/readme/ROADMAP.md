You have to be careful with rules regarding attachment deletion because
Odoo find the attachment to delete with their name. Odoo will find all
attachments containing the substring configured on the rule, so you have
to be specific enough on the other criterias (concerned models...) to
avoid unwanted attachment deletion.
