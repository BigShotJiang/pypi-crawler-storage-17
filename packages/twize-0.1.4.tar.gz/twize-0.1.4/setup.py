from setuptools import setup, find_packages

setup(
    name="twize",
    version="0.1.4",
    author="IZERE HIRWA Roger",
    author_email="roger@hdev.rw",
    description="A package for multi-linear regression with Markdown-formatted output.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/hirwaroger/twize",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "pandas",
        "matplotlib",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.0",
)
