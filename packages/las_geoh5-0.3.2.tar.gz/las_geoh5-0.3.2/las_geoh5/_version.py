# Version placeholder that will be replaced during substitution
__version__ = "0.3.2"
