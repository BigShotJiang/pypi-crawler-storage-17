import os
import sys
from typing import Any, Dict
from urllib.parse import urlparse
from uuid import UUID, uuid4

import chromadb
from chromadb.api.models.Collection import Collection
from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from loguru import logger

from .vectorstore_loader_abstract import VectorstoreLoaderAbstract

load_dotenv()


logger.remove()
log_level = os.getenv("RAGOPS_LOG_LEVEL", os.getenv("LOG_LEVEL", "ERROR"))
logger.add(
    sys.stderr,
    level=log_level,
    enqueue=True,
    backtrace=False,
    diagnose=False,
)


class ChromaVectorstoreLoader(VectorstoreLoaderAbstract):
    def __init__(
        self,
        collection_name: str,
        embeddings: Embeddings,
        database_uri: str = "http://localhost:8000",
    ) -> None:
        self.collection_name = collection_name
        self.collection = None
        self.embeddings = embeddings

        # Parse database URI to extract host and port
        parsed = urlparse(database_uri)
        host = parsed.hostname or "localhost"
        port = parsed.port or 8000

        self.client = chromadb.HttpClient(
            host=host, port=port, settings=chromadb.Settings(allow_reset=True)
        )

        # Async client will be initialized lazily
        self._async_client = None
        self._host = host
        self._port = port

    async def _get_async_client(self):
        """Lazily initialize async client."""
        if self._async_client is None:
            self._async_client = await chromadb.AsyncHttpClient(
                host=self._host,
                port=self._port,
                settings=chromadb.Settings(allow_reset=True),
            )
        return self._async_client

    def _ensure_collection(self, name: str) -> Collection:
        """Create or get existing collection."""
        try:
            collection = self.client.get_collection(name=name)
            logger.info(f"Using existing ChromaDB collection: {name}")
        except Exception:
            collection = self.client.create_collection(
                name=name, metadata={"description": "RAG document chunks"}
            )
            logger.info(f"Created ChromaDB collection: {name}")
        return collection

    async def _aensure_collection(self, name: str) -> Collection:
        """Create or get existing collection (async version)."""
        client = await self._get_async_client()
        try:
            collection = await client.get_collection(name=name)
            logger.info(f"Using existing ChromaDB collection: {name}")
        except Exception:
            collection = await client.create_collection(
                name=name, metadata={"description": "RAG document chunks"}
            )
            logger.info(f"Created ChromaDB collection: {name}")
        return collection

    def load_data(self, text: str, **kwargs: Any) -> Any:
        """
        Loads a document or split chunks into ChromaDB.
        """
        self.collection = self._ensure_collection(self.collection_name)
        split_doc = kwargs.get("split_doc", False)
        document_id = kwargs.get("document_id") or str(uuid4())
        user_metadata = kwargs.get("metadata", {})

        if split_doc:
            chunks = [c.strip() for c in text.split("\n\n") if c.strip()]
        else:
            chunks = [text.strip()]

        # Generate embeddings
        embeddings = self.embeddings.embed_documents(chunks)

        ids = []
        documents = []
        metadatas = []
        embeddings_list = []

        for idx, (chunk_text, vector) in enumerate(zip(chunks, embeddings)):
            doc_id = f"{document_id}_{idx}"
            ids.append(doc_id)
            documents.append(chunk_text)

            metadata = user_metadata.copy() if user_metadata else {}
            metadata.update(
                {
                    "document_id": document_id,
                    "chunk_index": idx,
                    "page_number": metadata.get("page_number", 0),
                    "category": metadata.get("category", "other"),
                    "additional_info": str(metadata.get("additional_info", {})),
                    "source_document_category": metadata.get(
                        "source_document_category", ""
                    ),
                }
            )

            # Add filename if provided
            if filename := user_metadata.get("filename"):
                metadata["filename"] = filename
            metadatas.append(metadata)
            embeddings_list.append(vector)

        # Add documents to collection
        self.collection.add(
            ids=ids,
            documents=documents,
            metadatas=metadatas,
            embeddings=embeddings_list,
        )

        logger.info(f"Inserted {len(ids)} chunks into ChromaDB")
        return ids

    def load_text(self, text: str, **kwargs: Dict[str, Any]) -> Dict[str, str]:
        """
        Load a single text chunk into ChromaDB.
        """
        ids = self.load_data(text, split_doc=False, **kwargs)
        return {"ids": ids}

    @staticmethod
    def sanitize_vector(vector: list[float], precision: int = 10) -> list[float]:
        result: list[float] = []
        for x in vector:
            if not isinstance(x, (int, float)):
                raise ValueError(f"Non-numeric value in vector: {x} ({type(x)})")
            if x != x or x in (float("inf"), float("-inf")):
                raise ValueError(f"Invalid value: {x}")
            dec = float(format(float(x), f".{precision}f"))
            result.append(dec)
        return result

    # @staticmethod
    # def _clean_text(text: str) -> str:
    #     # Remove JSON syntax: braces, brackets, quotes, colons, commas
    #     text = re.sub(r'[{}\[\]":]', "", text)
    #     # Remove escape sequences
    #     text = re.sub(r"\\[nrt\\]", " ", text)
    #     # Normalize whitespace
    #     text = re.sub(r"\s+", " ", text)
    #     return text.strip()

    def load_documents(
        self,
        task_id: UUID,
        documents: list[Document],
    ) -> list[str]:
        """
        Process and load a list of documents into ChromaDB.
        """
        self.collection = self._ensure_collection(self.collection_name)
        embeddings = self.embeddings.embed_documents(
            [doc.page_content for doc in documents]
        )
        # Prepare data for ChromaDB
        ids = []
        documents_list = []
        metadatas = []
        embeddings_list = []
        for idx, (doc, vector) in enumerate(zip(documents, embeddings)):
            doc_id = f"{doc.metadata.get('document_id')}_{idx}"
            ids.append(doc_id)
            documents_list.append(doc.page_content)
            metadata = {
                "document_id": doc.metadata.get("document_id"),
                "page_number": doc.metadata.get("page_number", 0),
                "category": doc.metadata.get("category", "other"),
                "chunk_index": idx,
                "additional_info": str(doc.metadata.get("additional_info", {})),
                "source_document_category": doc.metadata.get(
                    "source_document_category", ""
                ),
            }

            # Add filename if provided
            if filename := doc.metadata.get("filename"):
                metadata["filename"] = filename
            metadatas.append(metadata)
            embeddings_list.append(vector)
        # Load into ChromaDB
        if ids:
            logger.info(f"Loading {len(ids)} chunks into ChromaDB.")
            self.collection.add(
                ids=ids,
                documents=documents_list,
                metadatas=metadatas,
                embeddings=embeddings_list,
            )
        return ids

    async def aload_documents(self, task_id: UUID, documents: list[Any]) -> list[str]:
        """
        Process and load a list of documents into ChromaDB.
        """
        self.collection = await self._aensure_collection(self.collection_name)
        embeddings = await self.embeddings.aembed_documents(
            [doc.page_content for doc in documents]
        )
        # Prepare data for ChromaDB
        ids = []
        documents_list = []
        metadatas = []
        embeddings_list = []
        for idx, (doc, vector) in enumerate(zip(documents, embeddings)):
            doc_id = f"{doc.metadata.get('document_id')}_{idx}"
            ids.append(doc_id)
            documents_list.append(doc.page_content)
            metadata = {
                "document_id": doc.metadata.get("document_id"),
                "page_number": doc.metadata.get("page_number", 0),
                "category": doc.metadata.get("category", "other"),
                "chunk_index": idx,
                "additional_info": str(doc.metadata.get("additional_info", {})),
                "source_document_category": doc.metadata.get(
                    "source_document_category", ""
                ),
            }

            # Add filename if provided
            if filename := doc.metadata.get("filename"):
                metadata["filename"] = filename
            metadatas.append(metadata)
            embeddings_list.append(vector)
        # Load into ChromaDB using async client
        if ids:
            logger.info(f"Loading {len(ids)} chunks into ChromaDB.")
            # Get async client and collection
            client = await self._get_async_client()
            collection = await client.get_collection(name=self.collection_name)
            await collection.add(
                ids=ids,
                documents=documents_list,
                metadatas=metadatas,
                embeddings=embeddings_list,
            )
        return ids

    def delete_document_from_vectorstore(
        self, document_id: str | None = None, filename: str | None = None
    ) -> bool:
        """
        Delete document and associated filenames from ChromaDB.
        """
        try:
            if document_id:
                # Delete by document_id
                where_clause = {"document_id": document_id}
            elif filename:
                # Delete by filename
                where_clause = {"filename": filename}
            else:
                raise ValueError("No document_id or filename provided")
            # Get documents to delete first
            results = self.collection.get(where=where_clause)
            if results["ids"]:
                self.collection.delete(ids=results["ids"])
                logger.info(f"Deleted {len(results['ids'])} documents from ChromaDB")
                return True
            return False
        except Exception as e:
            logger.error(f"Error deleting data from ChromaDB: {e}")
            return False

    # Category Embedding Methods (for category-aware retrieval reranking)
    #  --------------

    async def get_all_unique_categories(self) -> list[str]:
        """
        Get all unique source_document_category values in the collection.
        #TODO: I Think I borked the collection naming. Didn't consider multiple doc collections in same runtime.
        Returns:
            List of unique category strings.
        """
        client = await self._get_async_client()
        collection = await client.get_collection(name=self.collection_name)

        categories: set[str] = set()
        batch_size = 100
        offset = 0

        while True:
            results = await collection.get(
                limit=batch_size,
                offset=offset,
                include=["metadatas"],
            )

            if not results["ids"]:
                break

            for metadata in results["metadatas"]:
                category = metadata.get("source_document_category")
                if category:
                    categories.add(category)

            if len(results["ids"]) < batch_size:
                break
            offset += batch_size

        logger.info(
            f"Found {len(categories)} unique categories in '{self.collection_name}'"
        )
        return list(categories)

    async def fetch_chunks_with_vectors_by_category(
        self, category: str, limit: int = 3000
    ) -> list[list[float]]:
        """
        Fetch embedding vectors for chunks with the given category.

        Args:
            category: The source_document_category to filter by.
            limit: Maximum number of chunks to fetch (default 3000).

        Returns:
            List of embedding vectors.
        """
        client = await self._get_async_client()
        collection = await client.get_collection(name=self.collection_name)

        vectors: list[list[float]] = []
        batch_size = min(100, limit)
        offset = 0

        while len(vectors) < limit:
            results = await collection.get(
                where={"source_document_category": category},
                limit=batch_size,
                offset=offset,
                include=["embeddings"],
            )

            if not results["ids"]:
                break

            for embedding in results["embeddings"]:
                if len(vectors) >= limit:
                    break
                if embedding:
                    vectors.append(embedding)

            if len(results["ids"]) < batch_size:
                break
            offset += batch_size

        logger.info(
            f"Fetched {len(vectors)} vectors for category '{category}' "
            f"from '{self.collection_name}'"
        )
        return vectors

    async def store_category_embeddings(
        self, category_embeddings: dict[str, list[float]]
    ) -> None:
        """
        Store category embeddings in a separate {collection}_categories collection.

        Args:
            category_embeddings: Dict mapping category name to embedding vector.
        """
        if not category_embeddings:
            return

        categories_collection = f"{self.collection_name}_categories"

        # Ensure the categories collection exists
        client = await self._get_async_client()
        try:
            collection = await client.get_collection(name=categories_collection)
        except Exception:
            collection = await client.create_collection(
                name=categories_collection,
                metadata={"description": "Category embeddings for reranking"},
            )
            logger.info(
                f"Created ChromaDB categories collection: {categories_collection}"
            )

        # Prepare data
        ids = []
        embeddings_list = []
        metadatas = []

        for category_name, embedding in category_embeddings.items():
            ids.append(f"category_{category_name}")
            embeddings_list.append(self.sanitize_vector(embedding))
            metadatas.append({"category_name": category_name})

        # Upsert data
        await collection.upsert(
            ids=ids,
            embeddings=embeddings_list,
            metadatas=metadatas,
        )
        logger.info(
            f"Stored {len(ids)} category embeddings in '{categories_collection}'"
        )
