from abc import ABC
from abc import abstractmethod
from typing import Any
from uuid import UUID


class VectorstoreLoaderAbstract(ABC):
    @abstractmethod
    def load_text(self, text: str, **kwargs: dict[str, Any]) -> dict[str, str]: ...

    @abstractmethod
    def load_documents(self, task_id: UUID, documents: list[Any]) -> list[str]: ...

    @abstractmethod
    async def aload_documents(
        self, task_id: UUID, documents: list[Any]
    ) -> list[str]: ...

    @abstractmethod
    def delete_document_from_vectorstore(
        self, document_id: str | None = None, filename: str | None = None
    ) -> bool: ...

    @staticmethod
    def _sanitize_vector(vector: list[float], precision: int = 10) -> list[float]:
        result: list[float] = []
        for x in vector:
            if not isinstance(x, (int, float)):
                raise ValueError(f"Non-numeric value in vector: {x} ({type(x)})")
            if x != x or x in (float("inf"), float("-inf")):
                raise ValueError(f"Invalid value: {x}")
            dec = float(format(float(x), f".{precision}f"))
            result.append(dec)
        return result
