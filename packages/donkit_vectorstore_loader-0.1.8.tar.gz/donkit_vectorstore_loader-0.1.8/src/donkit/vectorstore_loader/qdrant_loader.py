import os
import re
import sys
from typing import Any
from urllib.parse import urlparse
from uuid import NAMESPACE_URL
from uuid import UUID
from uuid import uuid4
from uuid import uuid5
import warnings

from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from loguru import logger
from qdrant_client import QdrantClient, AsyncQdrantClient
from qdrant_client import models
from qdrant_client.models import TextIndexType

from .vectorstore_loader_abstract import VectorstoreLoaderAbstract


load_dotenv()


logger.remove()
log_level = os.getenv("RAGOPS_LOG_LEVEL", os.getenv("LOG_LEVEL", "ERROR"))
logger.add(
    sys.stderr,
    level=log_level,
    enqueue=True,
    backtrace=False,
    diagnose=False,
)


def parse_qdrant_url(url: str) -> tuple[str, int, bool]:
    if "://" not in url:
        url = f"http://{url}"
    parsed = urlparse(url)
    host = parsed.hostname or "localhost"
    port = parsed.port or 6333
    use_https = parsed.scheme == "https"
    return host, port, use_https


class QdrantVectorstoreLoader(VectorstoreLoaderAbstract):
    def __init__(
        self,
        collection_name: str,
        embeddings: Embeddings,
        database_uri: str = "http://localhost:6333",
    ) -> None:
        self.collection_name = collection_name
        self.embeddings = embeddings
        host, port, use_https = parse_qdrant_url(database_uri)

        # Sync client for sync operations
        self.client = QdrantClient(
            host=host,
            port=port,
            https=use_https,
        )

        # Async client for async operations
        self.async_client = AsyncQdrantClient(
            host=host,
            port=port,
            https=use_https,
        )

        self.dimension = None

    def _detect_dimension(self) -> int | None:
        """Detect vector dimension from embeddings."""
        try:
            test_vector = self.embeddings.embed_query("test")
        except Exception:
            return None
        dimension = len(test_vector)
        logger.info(f"Detected embedding dimension: {dimension}")
        return dimension

    async def _adetect_dimension(self) -> int:
        """Detect vector dimension from embeddings (async version)."""
        test_vector = await self.embeddings.aembed_query("test")
        dimension = len(test_vector)
        logger.info(f"Detected embedding dimension: {dimension}")
        return dimension

    def _ensure_collection(self, name: str, vector_dim: int | None = None) -> None:
        """Create or get existing collection."""
        if not self.dimension:
            vector_dim = self._detect_dimension()
            self.dimension = vector_dim
        try:
            self.client.get_collection(collection_name=name)
            logger.info(f"Using existing Qdrant collection: {name}")
        except Exception:
            # Collection doesn't exist, create it
            self.client.create_collection(
                collection_name=name,
                vectors_config=models.VectorParams(
                    size=vector_dim or self.dimension,
                    distance=models.Distance.COSINE,
                ),
            )
            logger.info(f"Created Qdrant collection: {name}")

            # Create indexes
            try:
                self.client.create_payload_index(
                    collection_name=name,
                    field_name="text",
                    field_schema=models.TextIndexParams(
                        type=TextIndexType.TEXT,
                        tokenizer=models.TokenizerType.WORD,
                        min_token_len=2,
                        max_token_len=20,
                        lowercase=True,
                    ),
                )
                self.client.create_payload_index(
                    collection_name=name,
                    field_name="document_id",
                    field_schema="keyword",
                )
                self.client.create_payload_index(
                    collection_name=name,
                    field_name="filename",
                    field_schema="keyword",
                )
                self.client.create_payload_index(
                    collection_name=name,
                    field_name="source_document_category",
                    field_schema="keyword",
                )
            except Exception as e:
                logger.warning(f"Error creating indexes: {e}")

    async def _aensure_collection(
        self, name: str, vector_dim: int | None = None
    ) -> None:
        """Create or get existing collection (async version)."""
        if not self.dimension or not vector_dim:
            vector_dim = await self._adetect_dimension()
            self.dimension = vector_dim
        try:
            await self.async_client.get_collection(collection_name=name)
            logger.info(f"Using existing Qdrant collection: {name}")
        except Exception:
            # Collection doesn't exist, create it
            await self.async_client.create_collection(
                collection_name=name,
                vectors_config=models.VectorParams(
                    size=vector_dim or self.dimension,
                    distance=models.Distance.COSINE,
                ),
            )
            logger.info(f"Created Qdrant collection: {name}")

            # Create indexes
            try:
                await self.async_client.create_payload_index(
                    collection_name=name,
                    field_name="text",
                    field_schema=models.TextIndexParams(
                        type=TextIndexType.TEXT,
                        tokenizer=models.TokenizerType.WORD,
                        min_token_len=2,
                        max_token_len=20,
                        lowercase=True,
                    ),
                )
                await self.async_client.create_payload_index(
                    collection_name=name,
                    field_name="document_id",
                    field_schema="keyword",
                )
                await self.async_client.create_payload_index(
                    collection_name=name,
                    field_name="filename",
                    field_schema="keyword",
                )
                await self.async_client.create_payload_index(
                    collection_name=name,
                    field_name="source_document_category",
                    field_schema="keyword",
                )
            except Exception as e:
                logger.warning(f"Error creating indexes: {e}")

    def load_text(self, text: str, **kwargs: dict[str, Any]) -> dict[str, str]:
        """
        Load a single text chunk into Qdrant.
        """
        document_id = kwargs.get("document_id") or str(uuid4())
        user_metadata = kwargs.get("metadata", {})

        # Generate embedding
        embeddings = self.embeddings.embed_documents([text.strip()])

        point_id = uuid5(NAMESPACE_URL, f"{document_id}_0")
        payload = {
            "text": text.strip(),
            "document_id": document_id,
            "chunk_index": 0,
            "page_number": user_metadata.get("page_number", 0),
            "category": user_metadata.get("category", "other"),
            "additional_info": str(user_metadata.get("additional_info", {})),
            "source_document_category": user_metadata.get("source_document_category"),
        }

        # Add filename if provided
        if filename := user_metadata.get("filename"):
            payload["filename"] = filename

        point = models.PointStruct(
            id=str(point_id),
            vector=self._sanitize_vector(embeddings[0]),
            payload=payload,
        )

        self.client.upsert(
            collection_name=self.collection_name,
            points=[point],
        )

        logger.info(f"Inserted text into Qdrant collection '{self.collection_name}'")
        return {"ids": [str(point_id)]}

    @staticmethod
    def _sanitize_vector(vector: list[float], precision: int = 10) -> list[float]:
        result: list[float] = []
        for x in vector:
            if not isinstance(x, (int, float)):
                raise ValueError(f"Non-numeric value in vector: {x} ({type(x)})")
            if x != x or x in (float("inf"), float("-inf")):
                raise ValueError(f"Invalid value: {x}")
            dec = float(format(float(x), f".{precision}f"))
            result.append(dec)
        return result

    @staticmethod
    def _clean_text(text: str) -> str:
        # Remove JSON syntax: braces, brackets, quotes, colons, commas
        text = re.sub(r'[{}\[\]":]', "", text)
        # Remove escape sequences
        text = re.sub(r"\\[nrt\\]", " ", text)
        # Normalize whitespace
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    def load_documents(
        self,
        task_id: UUID,
        documents: list[Document],
    ) -> list[str]:
        """
        Process and load a list of documents into Qdrant.
        """
        warnings.warn(
            "This method is deprecated. Use aload_documents instead.",
            DeprecationWarning,
        )
        if not documents:
            return []

        self._ensure_collection(self.collection_name)

        # Generate embeddings
        embeddings = self.embeddings.embed_documents(
            [doc.page_content for doc in documents]
        )

        # Prepare points for Qdrant
        points = []
        ids = []
        for idx, (doc, vector) in enumerate(zip(documents, embeddings)):
            point_id = uuid5(
                NAMESPACE_URL, f"{doc.metadata.get('document_id') or uuid4()}_{idx}"
            )
            ids.append(str(point_id))

            payload = {
                "text": doc.page_content,
                "document_id": doc.metadata.get("document_id"),
                "page_number": doc.metadata.get("page_number", 0),
                "category": doc.metadata.get("category", "other"),
                "chunk_index": idx,
                "additional_info": str(doc.metadata.get("additional_info", {})),
                "source_document_category": doc.metadata.get(
                    "source_document_category"
                ),
            }

            # Add filename if provided
            if filename := doc.metadata.get("filename"):
                payload["filename"] = filename

            points.append(
                models.PointStruct(
                    id=str(point_id),
                    vector=self._sanitize_vector(vector),
                    payload=payload,
                )
            )

        # Load into Qdrant
        if points:
            logger.info(f"Loading {len(points)} chunks into Qdrant.")
            self.client.upsert(
                collection_name=self.collection_name,
                points=points,
            )

        return ids

    async def aload_documents(self, task_id: UUID, documents: list[Any]) -> list[str]:
        """
        Process and load a list of documents into Qdrant (async version).
        """
        if not documents:
            return []
        await self._aensure_collection(self.collection_name)

        # Generate embeddings asynchronously
        embeddings = await self.embeddings.aembed_documents(
            [doc.page_content for doc in documents]
        )
        # Prepare points for Qdrant
        points = []
        ids = []
        for idx, (doc, vector) in enumerate(zip(documents, embeddings)):
            point_id = uuid5(
                NAMESPACE_URL, f"{doc.metadata.get('document_id') or uuid4()}_{idx}"
            )
            ids.append(str(point_id))

            payload = {
                "text": doc.page_content,
                "document_id": doc.metadata.get("document_id"),
                "page_number": doc.metadata.get("page_number", 0),
                "category": doc.metadata.get("category", "other"),
                "chunk_index": idx,
                "additional_info": str(doc.metadata.get("additional_info", {})),
                "source_document_category": doc.metadata.get(
                    "source_document_category"
                ),
            }

            # Add filename if provided
            if filename := doc.metadata.get("filename"):
                payload["filename"] = filename

            points.append(
                models.PointStruct(
                    id=str(point_id),
                    vector=self._sanitize_vector(vector),
                    payload=payload,
                )
            )

        # Load into Qdrant using async client
        if points:
            logger.info(f"Loading {len(points)} chunks into Qdrant.")
            await self.async_client.upsert(
                collection_name=self.collection_name,
                points=points,
            )

        return ids

    def delete_document_from_vectorstore(
        self, document_id: str | None = None, filename: str | None = None
    ) -> bool:
        """
        Delete document from Qdrant.
        """
        try:
            if document_id:
                # Delete by document_id
                self.client.delete(
                    collection_name=self.collection_name,
                    points_selector=models.FilterSelector(
                        filter=models.Filter(
                            must=[
                                models.FieldCondition(
                                    key="document_id",
                                    match=models.MatchValue(value=document_id),
                                )
                            ]
                        )
                    ),
                )
            elif filename:
                # Delete by filename
                self.client.delete(
                    collection_name=self.collection_name,
                    points_selector=models.FilterSelector(
                        filter=models.Filter(
                            must=[
                                models.FieldCondition(
                                    key="filename",
                                    match=models.MatchValue(value=filename),
                                )
                            ]
                        )
                    ),
                )
            else:
                raise ValueError("No document_id or filename provided")

            logger.info(
                f"Deleted document from Qdrant collection '{self.collection_name}'"
            )
            return True
        except Exception as e:
            logger.error(f"Error deleting data from Qdrant: {e}")
            return False

    # ========================================================================
    # Category Embedding Methods (for category-aware retrieval reranking)
    # ========================================================================

    async def get_all_unique_categories(self) -> list[str]:
        """
        Get all unique source_document_category values in the collection.

        Returns:
            List of unique category strings.
        """
        categories: set[str] = set()
        offset = None
        batch_size = 100

        while True:
            result = await self.async_client.scroll(
                collection_name=self.collection_name,
                limit=batch_size,
                offset=offset,
                with_payload=["source_document_category"],
                with_vectors=False,
            )
            points, next_offset = result

            for point in points:
                category = point.payload.get("source_document_category")
                if category:
                    categories.add(category)

            if next_offset is None:
                break
            offset = next_offset

        logger.info(
            f"Found {len(categories)} unique categories in '{self.collection_name}'"
        )
        return list(categories)

    async def fetch_chunks_with_vectors_by_category(
        self, category: str, limit: int = 3000
    ) -> list[list[float]]:
        """
        Fetch embedding vectors for chunks with the given category.

        Args:
            category: The source_document_category to filter by.
            limit: Maximum number of chunks to fetch (default 3000).

        Returns:
            List of embedding vectors.
        """
        vectors: list[list[float]] = []
        offset = None
        batch_size = min(100, limit)

        while len(vectors) < limit:
            result = await self.async_client.scroll(
                collection_name=self.collection_name,
                scroll_filter=models.Filter(
                    must=[
                        models.FieldCondition(
                            key="source_document_category",
                            match=models.MatchValue(value=category),
                        )
                    ]
                ),
                limit=batch_size,
                offset=offset,
                with_payload=False,
                with_vectors=True,
            )
            points, next_offset = result

            for point in points:
                if len(vectors) >= limit:
                    break
                if point.vector:
                    vectors.append(point.vector)

            if next_offset is None or len(vectors) >= limit:
                break
            offset = next_offset

        logger.info(
            f"Fetched {len(vectors)} vectors for category '{category}' "
            f"from '{self.collection_name}'"
        )
        return vectors

    async def store_category_embeddings(
        self, category_embeddings: dict[str, list[float]]
    ) -> None:
        """
        Store category embeddings in a separate {collection}_categories collection.

        Args:
            category_embeddings: Dict mapping category name to embedding vector.
        """
        if not category_embeddings:
            return

        categories_collection = f"{self.collection_name}_categories"

        # Ensure the categories collection exists
        sample_vector = next(iter(category_embeddings.values()))
        vector_dim = len(sample_vector)
        await self._aensure_collection(categories_collection, vector_dim=vector_dim)

        # Prepare points
        points = []
        for category_name, embedding in category_embeddings.items():
            point_id = uuid5(NAMESPACE_URL, f"category_{category_name}")
            points.append(
                models.PointStruct(
                    id=str(point_id),
                    vector=self._sanitize_vector(embedding),
                    payload={"category_name": category_name},
                )
            )

        # Upsert points
        await self.async_client.upsert(
            collection_name=categories_collection,
            points=points,
        )
        logger.info(
            f"Stored {len(points)} category embeddings in '{categories_collection}'"
        )
