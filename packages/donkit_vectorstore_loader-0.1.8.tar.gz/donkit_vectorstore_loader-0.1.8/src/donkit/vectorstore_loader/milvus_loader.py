import os
import re
import sys
from typing import Any
from uuid import UUID, uuid4
import warnings

from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from loguru import logger
from pymilvus import MilvusClient, DataType, AsyncMilvusClient

from .vectorstore_loader_abstract import VectorstoreLoaderAbstract


load_dotenv()


logger.remove()
log_level = os.getenv("RAGOPS_LOG_LEVEL", os.getenv("LOG_LEVEL", "ERROR"))
logger.add(
    sys.stderr,
    level=log_level,
    enqueue=True,
    backtrace=False,
    diagnose=False,
)


class MilvusVectorstoreLoader(VectorstoreLoaderAbstract):
    def __init__(
        self,
        collection_name: str,
        embeddings: Embeddings,
        database_uri: str = "http://localhost:19530",
    ) -> None:
        self.collection_name = collection_name
        self.embeddings = embeddings

        # Sync client for sync operations
        self.client = MilvusClient(
            uri=database_uri,
        )

        # Async client for async operations
        self.async_client = AsyncMilvusClient(
            uri=database_uri,
        )

        self.dimension = self._detect_dimension()
        self.collection = None

    def _detect_dimension(self) -> int | None:
        """Detect vector dimension from embeddings."""
        try:
            test_vector = self.embeddings.embed_query("test")
        except Exception:
            return None
        dimension = len(test_vector)
        logger.info(f"Detected embedding dimension: {dimension}")
        return dimension

    async def _adetect_dimension(self) -> int:
        """Detect vector dimension from embeddings (async version)."""
        test_vector = await self.embeddings.aembed_query("test")
        dimension = len(test_vector)
        logger.info(f"Detected embedding dimension: {dimension}")
        return dimension

    def _ensure_collection(self, name: str):
        """Create or get existing collection."""
        if self.client.has_collection(name):
            logger.info(f"Using existing Milvus collection: {name}")
        else:
            # Create collection with schema
            schema = self.client.create_schema(
                auto_id=False,
                enable_dynamic_field=True,
            )
            schema.add_field(
                field_name="id",
                datatype=DataType.VARCHAR,
                max_length=256,
                is_primary=True,
            )
            schema.add_field(
                field_name="vector", datatype=DataType.FLOAT_VECTOR, dim=self.dimension
            )
            schema.add_field(
                field_name="text", datatype=DataType.VARCHAR, max_length=65535
            )
            schema.add_field(
                field_name="document_id", datatype=DataType.VARCHAR, max_length=256
            )
            schema.add_field(field_name="chunk_index", datatype=DataType.INT64)
            schema.add_field(field_name="page_number", datatype=DataType.INT64)
            schema.add_field(
                field_name="category", datatype=DataType.VARCHAR, max_length=256
            )
            schema.add_field(
                field_name="additional_info", datatype=DataType.VARCHAR, max_length=2048
            )
            schema.add_field(
                field_name="filename", datatype=DataType.VARCHAR, max_length=512
            )
            schema.add_field(
                field_name="source_document_category",
                datatype=DataType.VARCHAR,
                max_length=512,
            )

            # Create index
            index_params = self.client.prepare_index_params()
            index_params.add_index(
                field_name="vector",
                index_type="IVF_FLAT",
                metric_type="IP",
                params={"nlist": 128},
            )

            self.client.create_collection(
                collection_name=name,
                schema=schema,
                index_params=index_params,
            )
            logger.info(f"Created Milvus collection: {name}")

        return name

    async def _aensure_collection(self, name: str):
        """Create or get existing collection (async version)."""
        if not self.dimension:
            self.dimension = await self._adetect_dimension()

        if await self.async_client.has_collection(name):
            logger.info(f"Using existing Milvus collection: {name}")
        else:
            # Create collection with schema using sync client (schema/index are not async)
            schema = self.client.create_schema(
                auto_id=False,
                enable_dynamic_field=True,
            )
            schema.add_field(
                field_name="id",
                datatype=DataType.VARCHAR,
                max_length=256,
                is_primary=True,
            )
            schema.add_field(
                field_name="vector", datatype=DataType.FLOAT_VECTOR, dim=self.dimension
            )
            schema.add_field(
                field_name="text", datatype=DataType.VARCHAR, max_length=65535
            )
            schema.add_field(
                field_name="document_id", datatype=DataType.VARCHAR, max_length=256
            )
            schema.add_field(field_name="chunk_index", datatype=DataType.INT64)
            schema.add_field(field_name="page_number", datatype=DataType.INT64)
            schema.add_field(
                field_name="category", datatype=DataType.VARCHAR, max_length=256
            )
            schema.add_field(
                field_name="additional_info", datatype=DataType.VARCHAR, max_length=2048
            )
            schema.add_field(
                field_name="filename", datatype=DataType.VARCHAR, max_length=512
            )
            schema.add_field(
                field_name="source_document_category",
                datatype=DataType.VARCHAR,
                max_length=512,
            )

            # Create index using sync client
            index_params = self.client.prepare_index_params()
            index_params.add_index(
                field_name="vector",
                index_type="IVF_FLAT",
                metric_type="IP",
                params={"nlist": 128},
            )

            await self.async_client.create_collection(
                collection_name=name,
                schema=schema,
                index_params=index_params,
            )
            logger.info(f"Created Milvus collection: {name}")

        return name

    def load_text(self, text: str, **kwargs: dict[str, Any]) -> dict[str, list[str]]:
        """
        Load a single text chunk into Milvus.
        """
        self._ensure_collection(self.collection_name)
        document_id = kwargs.get("document_id") or str(uuid4())
        user_metadata = kwargs.get("metadata", {})

        # Generate embedding
        embeddings = self.embeddings.embed_documents([text.strip()])

        doc_id = f"{document_id}_0"
        data = [
            {
                "id": doc_id,
                "vector": self._sanitize_vector(embeddings[0]),
                "text": text.strip(),
                "document_id": document_id,
                "chunk_index": 0,
                "page_number": user_metadata.get("page_number", 0),
                "category": user_metadata.get("category", "other"),
                "additional_info": str(user_metadata.get("additional_info", {})),
                "filename": user_metadata.get("filename", ""),
                "source_document_category": user_metadata.get(
                    "source_document_category", ""
                ),
            }
        ]

        self.client.insert(
            collection_name=self.collection_name,
            data=data,
        )

        logger.info(f"Inserted text into Milvus collection '{self.collection_name}'")
        return {"ids": [doc_id]}

    @staticmethod
    def _clean_text(text: str) -> str:
        # Remove JSON syntax: braces, brackets, quotes, colons, commas
        text = re.sub(r'[{}\[\]":]', "", text)
        # Remove escape sequences
        text = re.sub(r"\\[nrt\\]", " ", text)
        # Normalize whitespace
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    def load_documents(
        self,
        task_id: UUID,
        documents: list[Document],
    ) -> list[str]:
        """
        Process and load a list of documents into Milvus.
        """
        warnings.warn(
            "This method is deprecated. Use aload_documents instead.",
            DeprecationWarning,
        )
        if not documents:
            return []
        self._ensure_collection(self.collection_name)
        # Generate embeddings
        embeddings = self.embeddings.embed_documents(
            [doc.page_content for doc in documents]
        )

        # Prepare data for Milvus
        data = []
        ids = []
        for idx, (doc, vector) in enumerate(zip(documents, embeddings)):
            doc_id = f"{doc.id}_{idx}"
            ids.append(doc_id)

            data.append(
                {
                    "id": doc_id,
                    "vector": self._sanitize_vector(vector),
                    "text": doc.page_content,
                    "document_id": doc.metadata.get("document_id"),
                    "chunk_index": idx,
                    "page_number": doc.metadata.get("page_number", 0),
                    "category": doc.metadata.get("category", "other"),
                    "additional_info": str(doc.metadata.get("additional_info", {})),
                    "filename": doc.metadata.get("filename", ""),
                    "source_document_category": doc.metadata.get(
                        "source_document_category", ""
                    ),
                }
            )

        # Load into Milvus
        if data:
            logger.info(f"Loading {len(data)} chunks into Milvus.")
            self.client.insert(
                collection_name=self.collection_name,
                data=data,
            )

        return ids

    async def aload_documents(self, task_id: UUID, documents: list[Any]) -> list[str]:
        """
        Process and load a list of documents into Milvus (async version).
        """
        if not documents:
            return []
        await self._aensure_collection(self.collection_name)
        # Generate embeddings asynchronously
        embeddings = await self.embeddings.aembed_documents(
            [doc.page_content for doc in documents]
        )

        # Prepare data for Milvus
        data = []
        ids = []
        for idx, (doc, vector) in enumerate(zip(documents, embeddings)):
            doc_id = f"{doc.metadata.get('document_id') or doc.id}_{idx}"
            ids.append(doc_id)

            data.append(
                {
                    "id": doc_id,
                    "vector": self._sanitize_vector(vector),
                    "text": doc.page_content,
                    "document_id": doc.metadata.get("document_id"),
                    "chunk_index": idx,
                    "page_number": doc.metadata.get("page_number", 0),
                    "category": doc.metadata.get("category", "other"),
                    "additional_info": str(doc.metadata.get("additional_info", {})),
                    "filename": doc.metadata.get("filename", ""),
                    "source_document_category": doc.metadata.get(
                        "source_document_category", ""
                    ),
                }
            )

        # Load into Milvus using async client
        if data:
            logger.info(f"Loading {len(data)} chunks into Milvus.")
            await self.async_client.insert(
                collection_name=self.collection_name,
                data=data,
            )

        return ids

    def delete_document_from_vectorstore(
        self, document_id: str | None = None, filename: str | None = None
    ) -> bool:
        """
        Delete document from Milvus.
        """
        try:
            if document_id:
                filter_expr = f'document_id == "{document_id}"'
            elif filename:
                filter_expr = f'filename == "{filename}"'
            else:
                raise ValueError("No document_id or filename provided")

            self.client.delete(
                collection_name=self.collection_name,
                filter=filter_expr,
            )

            logger.info(
                f"Deleted document from Milvus collection '{self.collection_name}'"
            )
            return True
        except Exception as e:
            logger.error(f"Error deleting data from Milvus: {e}")
            return False

    # ========================================================================
    # Category Embedding Methods (for category-aware retrieval reranking)
    # ========================================================================

    async def get_all_unique_categories(self) -> list[str]:
        """
        Get all unique source_document_category values in the collection.

        Returns:
            List of unique category strings.
        """
        categories: set[str] = set()
        batch_size = 1000
        offset = 0

        while True:
            results = await self.async_client.query(
                collection_name=self.collection_name,
                filter="",
                output_fields=["source_document_category"],
                limit=batch_size,
                offset=offset,
            )

            if not results:
                break

            for item in results:
                category = item.get("source_document_category")
                if category:
                    categories.add(category)

            if len(results) < batch_size:
                break
            offset += batch_size

        logger.info(
            f"Found {len(categories)} unique categories in '{self.collection_name}'"
        )
        return list(categories)

    async def fetch_chunks_with_vectors_by_category(
        self, category: str, limit: int = 3000
    ) -> list[list[float]]:
        """
        Fetch embedding vectors for chunks with the given category.

        Args:
            category: The source_document_category to filter by.
            limit: Maximum number of chunks to fetch (default 3000).

        Returns:
            List of embedding vectors.
        """
        vectors: list[list[float]] = []
        batch_size = min(1000, limit)
        offset = 0

        while len(vectors) < limit:
            results = await self.async_client.query(
                collection_name=self.collection_name,
                filter=f'source_document_category == "{category}"',
                output_fields=["vector"],
                limit=batch_size,
                offset=offset,
            )

            if not results:
                break

            for item in results:
                if len(vectors) >= limit:
                    break
                if vector := item.get("vector"):
                    vectors.append(vector)

            if len(results) < batch_size:
                break
            offset += batch_size

        logger.info(
            f"Fetched {len(vectors)} vectors for category '{category}' "
            f"from '{self.collection_name}'"
        )
        return vectors

    async def store_category_embeddings(
        self, category_embeddings: dict[str, list[float]]
    ) -> None:
        """
        Store category embeddings in a separate {collection}_categories collection.

        Args:
            category_embeddings: Dict mapping category name to embedding vector.
        """
        if not category_embeddings:
            return

        categories_collection = f"{self.collection_name}_categories"

        # Ensure the categories collection exists
        sample_vector = next(iter(category_embeddings.values()))
        vector_dim = len(sample_vector)

        if not await self.async_client.has_collection(categories_collection):
            # Create collection with schema
            schema = self.async_client.create_schema(
                auto_id=False,
                enable_dynamic_field=True,
            )
            schema.add_field(
                field_name="id",
                datatype=DataType.VARCHAR,
                max_length=256,
                is_primary=True,
            )
            schema.add_field(
                field_name="vector",
                datatype=DataType.FLOAT_VECTOR,
                dim=vector_dim,
            )
            schema.add_field(
                field_name="category_name",
                datatype=DataType.VARCHAR,
                max_length=512,
            )

            # Create index
            index_params = self.async_client.prepare_index_params()
            index_params.add_index(
                field_name="vector",
                index_type="IVF_FLAT",
                metric_type="IP",
                params={"nlist": 128},
            )

            await self.async_client.create_collection(
                collection_name=categories_collection,
                schema=schema,
                index_params=index_params,
            )
            logger.info(
                f"Created Milvus categories collection: {categories_collection}"
            )

        # Prepare data
        data = []
        for category_name, embedding in category_embeddings.items():
            data.append(
                {
                    "id": f"category_{category_name}",
                    "vector": self._sanitize_vector(embedding),
                    "category_name": category_name,
                }
            )

        # Upsert data
        await self.async_client.upsert(
            collection_name=categories_collection,
            data=data,
        )
        logger.info(
            f"Stored {len(data)} category embeddings in '{categories_collection}'"
        )
