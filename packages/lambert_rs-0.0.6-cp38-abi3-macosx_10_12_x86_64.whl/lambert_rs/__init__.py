from .lambert_rs import *

__doc__ = lambert_rs.__doc__
if hasattr(lambert_rs, "__all__"):
    __all__ = lambert_rs.__all__