<div align="center">

# pushikoo-pusher-onebot

OneBot Pusher adapter for Pushikoo.

[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/Pushikoo/pushikoo-pusher-onebot/package.yml)](https://github.com/Pushikoo/pushikoo-pusher-onebot/actions)
[![Python](https://img.shields.io/pypi/pyversions/pushikoo-pusher-onebot)](https://pypi.org/project/pushikoo-pusher-onebot)
[![PyPI version](https://badge.fury.io/py/pushikoo-pusher-onebot.svg)](https://pypi.org/project/pushikoo-pusher-onebot)
[![License](https://img.shields.io/github/license/Pushikoo/pushikoo-pusher-onebot.svg)](https://pypi.org/project/pushikoo-pusher-onebot/)

</div>
