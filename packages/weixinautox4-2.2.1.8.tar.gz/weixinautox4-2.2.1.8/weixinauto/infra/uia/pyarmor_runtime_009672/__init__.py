# Pyarmor 9.2.0 (basic), 009672, 2025-12-17T15:21:36.197881
from .pyarmor_runtime import __pyarmor__
