# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteNotifyPolicyRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'topic_urn': 'str',
        'notify_policy_id': 'str'
    }

    attribute_map = {
        'topic_urn': 'topic_urn',
        'notify_policy_id': 'notify_policy_id'
    }

    def __init__(self, topic_urn=None, notify_policy_id=None):
        r"""DeleteNotifyPolicyRequest

        The model defined in huaweicloud sdk

        :param topic_urn: Topic的唯一的资源标识，可通过[查询主题列表](smn_api_51004.xml)获取该标识。
        :type topic_urn: str
        :param notify_policy_id: 通知策略ID。
        :type notify_policy_id: str
        """
        
        

        self._topic_urn = None
        self._notify_policy_id = None
        self.discriminator = None

        self.topic_urn = topic_urn
        self.notify_policy_id = notify_policy_id

    @property
    def topic_urn(self):
        r"""Gets the topic_urn of this DeleteNotifyPolicyRequest.

        Topic的唯一的资源标识，可通过[查询主题列表](smn_api_51004.xml)获取该标识。

        :return: The topic_urn of this DeleteNotifyPolicyRequest.
        :rtype: str
        """
        return self._topic_urn

    @topic_urn.setter
    def topic_urn(self, topic_urn):
        r"""Sets the topic_urn of this DeleteNotifyPolicyRequest.

        Topic的唯一的资源标识，可通过[查询主题列表](smn_api_51004.xml)获取该标识。

        :param topic_urn: The topic_urn of this DeleteNotifyPolicyRequest.
        :type topic_urn: str
        """
        self._topic_urn = topic_urn

    @property
    def notify_policy_id(self):
        r"""Gets the notify_policy_id of this DeleteNotifyPolicyRequest.

        通知策略ID。

        :return: The notify_policy_id of this DeleteNotifyPolicyRequest.
        :rtype: str
        """
        return self._notify_policy_id

    @notify_policy_id.setter
    def notify_policy_id(self, notify_policy_id):
        r"""Sets the notify_policy_id of this DeleteNotifyPolicyRequest.

        通知策略ID。

        :param notify_policy_id: The notify_policy_id of this DeleteNotifyPolicyRequest.
        :type notify_policy_id: str
        """
        self._notify_policy_id = notify_policy_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteNotifyPolicyRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
