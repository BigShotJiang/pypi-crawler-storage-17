"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION-utf8.txt
at project source root.
"""

DESCRIPTION = (
    "Relabel coherently a set of 2-dimensional images into a 3-dimensional image."
)
