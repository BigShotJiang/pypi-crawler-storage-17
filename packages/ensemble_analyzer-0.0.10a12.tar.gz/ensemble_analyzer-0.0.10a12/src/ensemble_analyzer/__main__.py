from ensemble_analyzer.launch import main

if __name__ == '__main__':
    
    main()