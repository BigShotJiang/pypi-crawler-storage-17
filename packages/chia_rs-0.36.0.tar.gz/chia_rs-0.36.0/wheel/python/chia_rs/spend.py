from chia_rs import SpendConditions

Spend = SpendConditions
