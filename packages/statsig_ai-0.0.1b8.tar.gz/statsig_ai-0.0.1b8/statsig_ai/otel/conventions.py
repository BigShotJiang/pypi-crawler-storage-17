STATSIG_ATTR_SPAN_TYPE = "statsig.span.type"


class StatsigSpanType:
    GEN_AI = "gen_ai"
