from typing import Optional, TypedDict


class AIEvalGradeData(TypedDict, total=False):
    session_id: Optional[str]
