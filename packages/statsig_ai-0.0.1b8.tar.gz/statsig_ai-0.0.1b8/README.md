> ⚠️ **Beta Notice**
>
> This SDK is currently in **beta**. All APIs are **experimental** and subject to change.
> Please review the [release notes](https://github.com/statsig-io/statsig-ai-python/releases) for any **breaking changes** before upgrading.

## Statsig Python AI SDK

Statsig is the on-stop data platform for product development. We help you move faster with feature gates (feature flags), experiments, and the world's most powerful stats engine. If you're new to Statsig, check out our product and create an account at [statsig.com](https://www.statsig.com/?ref=gh_ai).

The AI SDK provides convenient hooks for developers working with LLMs to iterate on their promps, run evals to test their efficacy, add observability to LLM usage.

<h1 align="center">
	<a href="https://statsig.com/?ref=gh_ai">
		<img src="https://github.com/statsig-io/js-client-monorepo/assets/95646168/ae5499ed-20ff-4584-bf21-8857f800d485" />
	</a>
    <div />
	<a href="https://statsig.com/?ref=gh_ai">Statsig</a>
</h1>

<p align="center">
	<a href="https://github.com/statsig-io/statsig-ai-python/blob/main/LICENSE">
        	<img src="https://img.shields.io/badge/license-ISC-blue.svg?colorA=1b2528&colorB=ccfbc7&style=for-the-badge">
    	</a>
	<a href="https://pypi.org/project/statsig-ai/">
        	<img src="https://img.shields.io/pypi/v/statsig-ai.svg?colorA=1b2528&colorB=b2d3ff&style=for-the-badge">
    	</a>
	<a href="https://statsig.com/community?ref=gh_ai">
        	<img src="https://img.shields.io/badge/slack-statsig-brightgreen.svg?logo=slack&colorA=1b2528&colorB=FFF8BA&style=for-the-badge">
    	</a>
</p>

## Getting Started

Read through the [Documentation](https://docs.statsig.com/ai-evals/python?ref=gh_ai) to see code samples and how to get started.

## Running Examples

The `examples/` directory contains working examples demonstrating various features of the SDK.

### Prerequisites

Set up your environment variables:
```bash
export STATSIG_API_KEY="your-statsig-api-key"
export OPENAI_API_KEY="your-openai-api-key"  # For OpenAI wrapper examples
```

### Running an Example

```bash
python examples/ai_wrappers/wrap_openai.py
```

Available examples:
- `examples/ai_wrappers/wrap_openai.py` - Demonstrates wrapping OpenAI clients with Statsig telemetry (sync/async, streaming/non-streaming)

## Community

If you need any assistance or just have a question, feel free to reach out to us on [Slack](https://statsig.com/community?ref=gh_jsm).