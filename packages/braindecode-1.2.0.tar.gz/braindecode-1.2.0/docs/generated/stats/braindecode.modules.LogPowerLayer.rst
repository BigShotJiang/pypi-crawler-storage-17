﻿braindecode.modules.LogPowerLayer
=================================

.. currentmodule:: braindecode.modules

.. autodata:: LogPowerLayer