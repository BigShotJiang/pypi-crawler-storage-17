﻿braindecode.augmentation.functional.channels_shuffle
====================================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: channels_shuffle

.. include:: braindecode.augmentation.functional.channels_shuffle.examples

.. raw:: html

    <div style='clear:both'></div>