﻿braindecode.preprocessing.SetEEGReference
=========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: SetEEGReference
   
   
   
   
      
   
      
   
   

.. include:: braindecode.preprocessing.SetEEGReference.examples

.. raw:: html

    <div style='clear:both'></div>