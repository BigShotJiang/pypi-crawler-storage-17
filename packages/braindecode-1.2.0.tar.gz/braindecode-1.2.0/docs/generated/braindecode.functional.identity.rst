﻿braindecode.functional.identity
===============================

.. currentmodule:: braindecode.functional

.. autofunction:: identity

.. include:: braindecode.functional.identity.examples

.. raw:: html

    <div style='clear:both'></div>