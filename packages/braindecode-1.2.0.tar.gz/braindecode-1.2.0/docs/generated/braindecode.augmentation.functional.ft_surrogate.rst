﻿braindecode.augmentation.functional.ft_surrogate
================================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: ft_surrogate

.. include:: braindecode.augmentation.functional.ft_surrogate.examples

.. raw:: html

    <div style='clear:both'></div>