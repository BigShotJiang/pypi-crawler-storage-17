﻿braindecode.datasets.BaseDataset
================================

.. currentmodule:: braindecode.datasets

.. autoclass:: BaseDataset
   
   
   
   
      
   
      
         
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: set_description

   
   
   

.. include:: braindecode.datasets.BaseDataset.examples

.. raw:: html

    <div style='clear:both'></div>