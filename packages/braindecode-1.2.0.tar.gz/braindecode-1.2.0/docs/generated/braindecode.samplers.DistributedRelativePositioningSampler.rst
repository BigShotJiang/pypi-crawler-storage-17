﻿braindecode.samplers.DistributedRelativePositioningSampler
==========================================================

.. currentmodule:: braindecode.samplers

.. autoclass:: DistributedRelativePositioningSampler
   
   
   
   
      
   
      
         
      
   
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: presample

   
   
   

.. include:: braindecode.samplers.DistributedRelativePositioningSampler.examples

.. raw:: html

    <div style='clear:both'></div>