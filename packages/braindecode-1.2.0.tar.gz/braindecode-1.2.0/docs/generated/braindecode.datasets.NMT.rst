﻿braindecode.datasets.NMT
========================

.. currentmodule:: braindecode.datasets

.. autoclass:: NMT
   
   
   
   
      
   
      
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.datasets.NMT.examples

.. raw:: html

    <div style='clear:both'></div>