﻿braindecode.visualization.plot_confusion_matrix
===============================================

.. currentmodule:: braindecode.visualization

.. autofunction:: plot_confusion_matrix

.. include:: braindecode.visualization.plot_confusion_matrix.examples

.. raw:: html

    <div style='clear:both'></div>