﻿braindecode.modules.aggregate_probas
====================================

.. currentmodule:: braindecode.modules

.. autofunction:: aggregate_probas

.. include:: braindecode.modules.aggregate_probas.examples

.. raw:: html

    <div style='clear:both'></div>