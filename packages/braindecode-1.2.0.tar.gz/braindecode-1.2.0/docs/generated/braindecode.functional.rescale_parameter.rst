﻿braindecode.functional.rescale_parameter
========================================

.. currentmodule:: braindecode.functional

.. autofunction:: rescale_parameter

.. include:: braindecode.functional.rescale_parameter.examples

.. raw:: html

    <div style='clear:both'></div>