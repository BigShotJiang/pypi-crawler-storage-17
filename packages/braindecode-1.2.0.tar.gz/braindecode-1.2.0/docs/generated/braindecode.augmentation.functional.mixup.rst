﻿braindecode.augmentation.functional.mixup
=========================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: mixup

.. include:: braindecode.augmentation.functional.mixup.examples

.. raw:: html

    <div style='clear:both'></div>