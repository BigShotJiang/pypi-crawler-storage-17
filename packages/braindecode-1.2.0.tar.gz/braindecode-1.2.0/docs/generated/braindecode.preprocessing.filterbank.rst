﻿braindecode.preprocessing.filterbank
====================================

.. currentmodule:: braindecode.preprocessing

.. autofunction:: filterbank

.. include:: braindecode.preprocessing.filterbank.examples

.. raw:: html

    <div style='clear:both'></div>