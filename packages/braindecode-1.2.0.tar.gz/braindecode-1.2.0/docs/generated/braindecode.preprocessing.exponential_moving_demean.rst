﻿braindecode.preprocessing.exponential_moving_demean
===================================================

.. currentmodule:: braindecode.preprocessing

.. autofunction:: exponential_moving_demean

.. include:: braindecode.preprocessing.exponential_moving_demean.examples

.. raw:: html

    <div style='clear:both'></div>