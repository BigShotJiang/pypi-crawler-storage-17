﻿braindecode.functional.drop_path
================================

.. currentmodule:: braindecode.functional

.. autofunction:: drop_path

.. include:: braindecode.functional.drop_path.examples

.. raw:: html

    <div style='clear:both'></div>