﻿braindecode.datasets.create_from_mne_raw
========================================

.. currentmodule:: braindecode.datasets

.. autofunction:: create_from_mne_raw

.. include:: braindecode.datasets.create_from_mne_raw.examples

.. raw:: html

    <div style='clear:both'></div>