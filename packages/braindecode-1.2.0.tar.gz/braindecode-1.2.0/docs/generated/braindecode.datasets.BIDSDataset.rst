﻿braindecode.datasets.BIDSDataset
================================

.. currentmodule:: braindecode.datasets

.. autoclass:: BIDSDataset
   
   
   
   
      
   
      
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.datasets.BIDSDataset.examples

.. raw:: html

    <div style='clear:both'></div>