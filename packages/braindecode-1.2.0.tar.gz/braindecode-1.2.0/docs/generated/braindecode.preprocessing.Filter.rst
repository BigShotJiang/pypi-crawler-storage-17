﻿braindecode.preprocessing.Filter
================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: Filter
   
   
   
   
      
   
      
   
   

.. include:: braindecode.preprocessing.Filter.examples

.. raw:: html

    <div style='clear:both'></div>