﻿braindecode.augmentation.functional.identity
============================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: identity

.. include:: braindecode.augmentation.functional.identity.examples

.. raw:: html

    <div style='clear:both'></div>