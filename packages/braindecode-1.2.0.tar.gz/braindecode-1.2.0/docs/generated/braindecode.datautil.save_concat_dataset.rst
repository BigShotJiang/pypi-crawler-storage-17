﻿braindecode.datautil.save_concat_dataset
========================================

.. currentmodule:: braindecode.datautil

.. autofunction:: save_concat_dataset

.. include:: braindecode.datautil.save_concat_dataset.examples

.. raw:: html

    <div style='clear:both'></div>