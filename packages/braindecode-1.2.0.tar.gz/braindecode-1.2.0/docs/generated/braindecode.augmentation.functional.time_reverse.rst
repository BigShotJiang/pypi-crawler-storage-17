﻿braindecode.augmentation.functional.time_reverse
================================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: time_reverse

.. include:: braindecode.augmentation.functional.time_reverse.examples

.. raw:: html

    <div style='clear:both'></div>