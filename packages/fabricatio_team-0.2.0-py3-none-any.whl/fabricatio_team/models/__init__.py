"""Models defined in fabricatio-team."""
