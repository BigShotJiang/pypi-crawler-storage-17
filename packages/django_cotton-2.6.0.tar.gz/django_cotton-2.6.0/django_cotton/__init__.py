from django_cotton.utils import render_component

__all__ = ["render_component"]
