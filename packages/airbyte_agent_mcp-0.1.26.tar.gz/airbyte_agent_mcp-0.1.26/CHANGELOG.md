# Changelog

## [0.1.26] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 0bfa6500
- SDK version: 0.1.0

## [0.1.25] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: ea5a02a3
- SDK version: 0.1.0

## [0.1.24] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: f13dee0a
- SDK version: 0.1.0

## [0.1.23] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: d79da1e7
- SDK version: 0.1.0

## [0.1.22] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 0e48ca4e
- SDK version: 0.1.0

## [0.1.21] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 06e7d5c6
- SDK version: 0.1.0

## [0.1.20] - 2025-12-13
- Updated airbyte-agent-mcp package
- Source commit: 1ab72bd8
- SDK version: 0.1.0

## [0.1.19] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: dc79dc8b
- SDK version: 0.1.0

## [0.1.18] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 380e7c20
- SDK version: 0.1.0

## [0.1.17] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 1f622906
- SDK version: 0.1.0

## [0.1.16] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 8cd69753
- SDK version: 0.1.0

## [0.1.15] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 9f7f8a98
- SDK version: 0.1.0

## [0.1.14] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 5cc8eaa0
- SDK version: 0.1.0

## [0.1.13] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: dfe01f50
- SDK version: 0.1.0

## [0.1.12] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: 8c06aa10
- SDK version: 0.1.0

## [0.1.11] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: 11427ac3
- SDK version: 0.1.0

## [0.1.10] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: bdd5df6d
- SDK version: 0.1.0

## [0.1.9] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: ec3dcc78
- SDK version: 0.1.0

## [0.1.8] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: 334e113b
- SDK version: 0.1.0

## [0.1.7] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: 30c77ce6
- SDK version: 0.1.0

## [0.1.6] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: 92482e66
- SDK version: 0.1.0

## [0.1.5] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.4] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.3] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.2] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.1] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.0] - 2025-12-09
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0
