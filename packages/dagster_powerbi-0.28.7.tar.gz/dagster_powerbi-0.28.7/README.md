# dagster-powerbi

The docs for `dagster-powerbi ` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-powerbi).
