"""Metadata deduced from git at build time."""

id: str
short_id: str

id = "c16cd9cbf8d69719067040cf6c170a41c696c05d"
short_id = "c16cd9c"
