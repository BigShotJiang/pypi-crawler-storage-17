from lqs.client.client import RESTClient, RESTClientConfig
