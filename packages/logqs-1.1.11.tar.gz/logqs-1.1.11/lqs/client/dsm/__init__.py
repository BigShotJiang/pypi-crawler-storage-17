from lqs.client.dsm.dsm import DataStoreManager
