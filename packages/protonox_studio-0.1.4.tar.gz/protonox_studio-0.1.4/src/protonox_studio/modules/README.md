# Módulos Protonox Studio

Cada subcarpeta representa un módulo enchufable. Añade aquí el código especializado:
- `resize-pro/`: redimensionado con Auto-Snap y Golden Ratio.
- `move-pro/`: movimiento con drop zones inteligentes.
- `style-editor/`: edición de estilos y tokens.
- `grid-intelligence/`: overlays de grid y baseline.
- `ai-nudge/`: sugerencias contextuales en tiempo real.
