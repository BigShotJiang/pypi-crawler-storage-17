"""Module namespace for Protonox Studio plug-ins."""
