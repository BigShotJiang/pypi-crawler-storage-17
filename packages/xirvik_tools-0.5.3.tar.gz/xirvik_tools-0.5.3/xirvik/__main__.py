"""Entry point for ``python -m`` invocation."""
from __future__ import annotations

from xirvik.commands import xirvik as main

main()
