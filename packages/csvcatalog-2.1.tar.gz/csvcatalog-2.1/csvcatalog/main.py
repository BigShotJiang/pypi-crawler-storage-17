from .app import app


def main():
    """main entry point for the csv catalog cli tool"""
    app()


if __name__ == "__main__":
    main()
