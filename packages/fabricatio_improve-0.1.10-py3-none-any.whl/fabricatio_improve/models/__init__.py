"""Models defined in fabricatio-improve."""
