"""MCP Server for Imdb146"""
