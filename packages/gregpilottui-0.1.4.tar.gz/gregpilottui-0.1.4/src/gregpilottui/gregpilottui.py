from .app import GregPilotTUI

def app():
    gp = GregPilotTUI()
    gp.run()