BitCash is a fork of Ofek's Bit.

Maintainers
-----------

- Teran McKinney (former)

- Corentin Mercier (@merc1er)

Contributors
------------

- Shawn A. Wilson aka "lannocc" for Alpha Griffin

- Thomas Martin aka "Gz75y45ms3kc"

- Nicolai Skye (@nicolaiskye)

- Yashasvi S. Ranawat (@yashasvi-ranawat)
