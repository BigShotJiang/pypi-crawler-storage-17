## General

In Inventory Settings, you must have activated the option: *Check Empty
Tray*
