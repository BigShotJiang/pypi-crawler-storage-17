When a tray is released, and the system thinks it is empty, it prompts
the user to actually check that it is empty or not. In any case, an
inventory adjustment is done stating the situation: posted to zero if
the tray is actually empty, and set to draft is it is not empty.
