<div align="center">

# pushikoo-pusher-dingtalk

DingTalk custom bot pusher for Pushikoo.

[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/Pushikoo/pushikoo-pusher-dingtalk/package.yml)](https://github.com/Pushikoo/pushikoo-pusher-dingtalk/actions)
[![Python](https://img.shields.io/pypi/pyversions/pushikoo-pusher-dingtalk)](https://pypi.org/project/pushikoo-pusher-dingtalk)
[![PyPI version](https://badge.fury.io/py/pushikoo-pusher-dingtalk.svg)](https://pypi.org/project/pushikoo-pusher-dingtalk)
[![License](https://img.shields.io/github/license/Pushikoo/pushikoo-pusher-dingtalk.svg)](https://pypi.org/project/pushikoo-pusher-dingtalk/)

</div>
