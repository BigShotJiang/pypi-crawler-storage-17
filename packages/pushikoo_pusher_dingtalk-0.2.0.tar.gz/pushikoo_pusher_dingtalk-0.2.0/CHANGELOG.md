# Changelog

## [0.2.0](https://github.com/Pushikoo/pushikoo-pusher-dingtalk/compare/v0.1.1...v0.2.0) (2025-12-18)


### Features

* Introduce DingTalk pusher with configuration models for OSS and webhook, and a basic flow test. ([7090e2e](https://github.com/Pushikoo/pushikoo-pusher-dingtalk/commit/7090e2ef7caaf30ec72f418dce240d83e06f622a))

## [0.1.1](https://github.com/Pushikoo/pushikoo-pusher-dingtalk/compare/v0.1.0...v0.1.1) (2025-12-18)


### Miscellaneous Chores

* deps ([228a346](https://github.com/Pushikoo/pushikoo-pusher-dingtalk/commit/228a34668e042885602eec991215b03a7df2e8a2))

## 0.1.0 (2025-12-18)


### Features

* Implement DingTalk pusher adapter with OSS image upload and update dependencies. ([c94c33c](https://github.com/Pushikoo/pushikoo-pusher-dingtalk/commit/c94c33cec84db22d366c142c15047f27a90ddbe2))

## 0.1.0 (2025-12-13)


### Features

* v0 ([fe7bb7b](https://github.com/Pushikoo/pushikoo-adapter-testpusher/commit/fe7bb7b8cd0d2a87f9984ae8d7c8e98db557417b))
