from mosamatic2.ui.widgets.dialogs.dialog import Dialog


class HelpDialog(Dialog):
    def clear(self):
        pass

    def set_text(self, text):
        pass