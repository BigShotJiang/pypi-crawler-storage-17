from mosamatic2.ui.widgets.panels.defaultpanel import DefaultPanel


class Visualization(DefaultPanel):
    def __init__(self):
        super(Visualization, self).__init__()