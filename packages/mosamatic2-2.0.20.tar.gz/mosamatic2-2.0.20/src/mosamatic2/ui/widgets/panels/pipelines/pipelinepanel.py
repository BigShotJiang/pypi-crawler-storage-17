from mosamatic2.ui.widgets.panels.defaultpanel import DefaultPanel


class PipelinePanel(DefaultPanel):
    def __init__(self):
        super(PipelinePanel, self).__init__()