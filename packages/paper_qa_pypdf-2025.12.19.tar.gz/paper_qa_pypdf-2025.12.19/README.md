# paper-qa-pypdf

<!-- pyml disable-num-lines 6 line-length -->

[![GitHub](https://img.shields.io/badge/GitHub-black?logo=github&logoColor=white)](https://github.com/Future-House/paper-qa/tree/main/packages/paper-qa-pypdf)
[![PyPI version](https://badge.fury.io/py/paper-qa-pypdf.svg)](https://badge.fury.io/py/paper-qa-pypdf)
[![tests](https://github.com/Future-House/paper-qa/actions/workflows/tests.yml/badge.svg)](https://github.com/Future-House/paper-qa)
![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)
![PyPI Python Versions](https://img.shields.io/pypi/pyversions/paper-qa-pypdf)

PDF reading code backed by
[PyPDF](https://github.com/py-pdf/pypdf).

To also parse images or take full-page screenshots,
use the `media` extra: `pip install paper-qa-pypdf[media]`.
This is backed by [pypdfium2](https://github.com/pypdfium2-team/pypdfium2).

From there, to also support grouping images into figures or parsing tables,
use the `enhanced` extra: `pip install paper-qa-pypdf[enhanced]`.
This is backed by [pdfplumber](https://github.com/jsvine/pdfplumber).
