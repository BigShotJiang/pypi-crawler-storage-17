"""
Version of vpc
"""

__version__ = '0.32.0'
