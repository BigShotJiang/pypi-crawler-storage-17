from optymus.methods.second_order._newton_raphson import newton_raphson

__all__ = [
    "newton_raphson",
]
