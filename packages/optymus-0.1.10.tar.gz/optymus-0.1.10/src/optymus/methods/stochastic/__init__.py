from optymus.methods.stochastic._sgd import StochasticGradientDescent, sgd

__all__ = [
    "StochasticGradientDescent",
    "sgd",
]
