"""Unit tests for local-ai."""
