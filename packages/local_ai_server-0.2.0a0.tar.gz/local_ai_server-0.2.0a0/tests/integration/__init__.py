"""Integration tests for local-ai."""
