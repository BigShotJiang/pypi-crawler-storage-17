"""Tests for local-ai."""
