"""Entry point for python -m local_ai."""

from local_ai.cli.main import app

if __name__ == "__main__":
    app()
