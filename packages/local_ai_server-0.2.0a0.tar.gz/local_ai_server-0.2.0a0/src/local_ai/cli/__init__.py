"""CLI module for local-ai."""
