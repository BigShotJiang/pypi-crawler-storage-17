class Scripted(object):

    DATA04 = ""
    DATA01 = "http://"
    DATA02 = "https://"
    DATA03 = "RECORDED/blocked.txt"
