from dbt.tests.adapter.empty.test_empty import BaseTestEmpty, BaseTestEmptyInlineSourceRef


class TestSparkEmpty(BaseTestEmpty):
    pass


class TestSparkEmptyInlineSourceRef(BaseTestEmptyInlineSourceRef):
    pass
