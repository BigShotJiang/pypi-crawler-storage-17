Add property fields:

1.  Go to Contacts and create or edit any record.
2.  Click ⚙ Add Properties ‣ Field Type, select the type and add a default value if
    needed. To make the fields appear in kanban views, check View in Kanban as well.
    To validate and close the property creation window, click anywhere.
3.  The properties that will be displayed will be different for
    Individual or Company.

Delete property fields:

1. Click the pencil icon next to the targeted property, then click Delete ‣ Delete.
