This module adds the use of properties in partners (different for
companies and individuals).
