# Credits

## Development Lead

- Jan-Erik Rediger <jrediger@mozilla.com>
- Alessio Placitelli <aplacitelli@mozilla.com>

## Contributors

See [the full list of contributors](https://github.com/mozilla/glean_parser/graphs/contributors).

## Acknowledgements

This package was created with
[Cookiecutter](https://github.com/audreyr/cookiecutter) and the
[audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage)
project template.
