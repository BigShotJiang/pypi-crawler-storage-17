__version__ = "2025.12.17"
__prog__ = "webscout"
