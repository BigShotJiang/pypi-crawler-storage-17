# stub to support existing import paths
from ..generated.aio.secrets import *  # NOQA
