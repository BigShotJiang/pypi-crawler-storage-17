"""Tests for a11y-agent MCP server."""
