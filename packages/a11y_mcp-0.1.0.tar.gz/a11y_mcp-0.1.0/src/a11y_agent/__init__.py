"""
a11y-agent: MCP server for accessibility testing with Cloudflare bypass.

Uses Camoufox (anti-detect browser) and axe-core for accessibility audits
on websites protected by Cloudflare.
"""

__version__ = "0.1.0"
