from mipcandy.__entry__ import __entry__


if __name__ == "__main__":
    __entry__()
