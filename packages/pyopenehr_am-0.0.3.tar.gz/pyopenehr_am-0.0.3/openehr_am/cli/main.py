from openehr_am.cli.app import app


def main() -> None:
    app(prog_name="openehr-am")
