"""Command-line interface for openehr_am."""
