"""Project metadata for openehr_am.

Keep this module small and dependency-free.
"""

__version__ = "0.0.3"

__all__ = ["__version__"]
