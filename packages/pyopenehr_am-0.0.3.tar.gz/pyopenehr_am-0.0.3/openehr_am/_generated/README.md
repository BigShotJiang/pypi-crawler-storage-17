# Generated code (do not edit)

This directory contains generated parser code.

- Files here are **generated** and are committed to the repository.
- Do **not** edit files in this directory by hand.
- To regenerate, follow: `docs/dev/parsers.md`.
