# Glossary

- **ADL2**: Archetype Definition Language (v2)
- **ODIN**: Object Data Instance Notation (used in ADL sections and BMM
  persistence)
- **AOM2**: Archetype Object Model (semantic representation)
- **BMM**: Basic Meta-Model (RM schema persistence)
- **RM**: Reference Model (types like COMPOSITION, OBSERVATION, etc.)
- **OPT2**: Operational Template (compiled form for runtime use)
