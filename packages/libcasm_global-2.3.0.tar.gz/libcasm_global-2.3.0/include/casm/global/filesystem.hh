#ifndef CASM_global_filesystem
#define CASM_global_filesystem

#include <filesystem>

namespace CASM {

namespace fs = std::filesystem;

}

#endif
