..
    DO NOT DELETE! This causes _autosummary to generate stub files

Reference (libcasm)
===================

.. autosummary::
    :toctree: _autosummary
    :template: custom-module-template.rst
    :recursive:

    libcasm.casmglobal
    libcasm.counter
