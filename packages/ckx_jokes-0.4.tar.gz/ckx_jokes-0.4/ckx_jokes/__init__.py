from .server import jokes_server

server = jokes_server().run()
