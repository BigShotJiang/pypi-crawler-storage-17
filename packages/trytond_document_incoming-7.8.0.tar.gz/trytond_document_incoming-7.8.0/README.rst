########################
Document Incoming Module
########################

The *Document Incoming Module* collects and process incoming documents.

.. toctree::
   :maxdepth: 2

   usage
   configuration
   design
   reference
   releases
