A Physical Optics simulator in Python.

Initial beta version by EMerge Software. Updates will follow.