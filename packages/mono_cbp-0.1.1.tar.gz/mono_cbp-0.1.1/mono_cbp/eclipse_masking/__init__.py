"""Eclipse masking module for mono-cbp."""

from .masker import EclipseMasker

__all__ = ["EclipseMasker"]
