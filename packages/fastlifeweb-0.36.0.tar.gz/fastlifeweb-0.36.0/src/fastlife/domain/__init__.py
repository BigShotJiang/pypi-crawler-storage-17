"""Framework core domain."""
