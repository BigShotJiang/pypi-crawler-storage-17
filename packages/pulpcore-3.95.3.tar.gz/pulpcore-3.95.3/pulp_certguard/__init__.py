default_app_config = "pulp_certguard.app.PulpCertGuardPluginAppConfig"
