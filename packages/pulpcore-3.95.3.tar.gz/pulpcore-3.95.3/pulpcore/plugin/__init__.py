# plugins declare that they are a pulp plugin by subclassing PulpPluginAppConfig
from pulpcore.app.apps import PulpPluginAppConfig
