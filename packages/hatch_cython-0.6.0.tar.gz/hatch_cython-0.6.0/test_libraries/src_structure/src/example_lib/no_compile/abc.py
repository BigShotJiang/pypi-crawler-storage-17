def test_nocompile():
    return 41
