def normal_func(a: int, b: int):
    return a + b
