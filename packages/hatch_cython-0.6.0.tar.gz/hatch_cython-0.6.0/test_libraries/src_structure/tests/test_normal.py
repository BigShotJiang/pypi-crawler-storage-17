from example_lib.normal import normal_func


def test_normal():
    assert normal_func(1, 2) == 3
