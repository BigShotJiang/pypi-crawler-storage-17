def did_compile():
    return "did" in __file__
