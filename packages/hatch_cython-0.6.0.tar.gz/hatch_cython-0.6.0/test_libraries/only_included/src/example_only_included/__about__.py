# SPDX-FileCopyrightText: 2024-present joshua-auchincloss <joshua.auchincloss@proton.me>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
