from src.example_only_included.did import did_compile


def test_compilation():
    assert did_compile()
