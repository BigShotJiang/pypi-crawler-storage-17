# SPDX-FileCopyrightText: 2023-present joshua-auchincloss <joshua.auchincloss@proton.me>
#
# SPDX-License-Identifier: MIT
from hatch_cython.hooks import hatch_register_build_hook
from hatch_cython.plugin import CythonBuildHook
