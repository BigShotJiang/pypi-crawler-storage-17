################################
Account Stock Anglo-Saxon Module
################################

The *Account Stock Anglo-Saxon Module* adds the ability to use the anglo-saxon
accounting method for stock valuation.

.. toctree::
   :maxdepth: 2

   design
   releases
