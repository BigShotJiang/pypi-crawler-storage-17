# Tools - Copilot Instructions

## Architecture

- Only the `database` module may have direct SQLAlchemy dependencies.
