# Bibliography

::: texsmith.core.bibliography

::: texsmith.core.bibliography.collection

::: texsmith.core.bibliography.doi

::: texsmith.core.bibliography.issues

::: texsmith.core.bibliography.parsing
