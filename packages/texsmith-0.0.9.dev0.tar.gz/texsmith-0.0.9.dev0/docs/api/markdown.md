# Markdown Conversion

::: texsmith.adapters.markdown

::: texsmith.extensions

::: texsmith.extensions.missing_footnotes
