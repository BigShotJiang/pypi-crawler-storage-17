from __future__ import annotations

from .plugin import LatexPlugin


__all__ = ["LatexPlugin"]
