"""Built-in templates shipped with TeXSmith."""

__all__ = []
