"""Font utilities used by TexSmith's core rendering pipeline."""

__all__ = []
