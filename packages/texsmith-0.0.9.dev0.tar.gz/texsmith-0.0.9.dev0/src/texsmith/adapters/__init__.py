"""Integration layer for TexSmith adapters."""

from __future__ import annotations


__all__ = []
