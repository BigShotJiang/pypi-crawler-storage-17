"""Validation tests for VCF parsing accuracy and format compliance."""
