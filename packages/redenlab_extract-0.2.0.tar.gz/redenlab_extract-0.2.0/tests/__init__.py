"""
Tests for RedenLab ML SDK
"""
