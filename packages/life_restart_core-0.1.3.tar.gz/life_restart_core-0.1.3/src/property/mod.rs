//! Property state management module

mod state;

#[cfg(test)]
mod property_tests;

pub use state::*;
