"""Utility modules for pydocstruct"""
from __future__ import annotations

from pydocstruct.utils.file_utils import get_file_extension

__all__ = ["get_file_extension"]
