"""Core modules for pydocstruct"""
from __future__ import annotations

from pydocstruct.core.chunker import Chunker
from pydocstruct.core.document import Document
from pydocstruct.core.loader import BaseLoader

__all__ = ["Chunker", "Document", "BaseLoader"]
