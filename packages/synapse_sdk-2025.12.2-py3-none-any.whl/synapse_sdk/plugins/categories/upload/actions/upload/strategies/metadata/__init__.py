# Metadata strategy implementations
