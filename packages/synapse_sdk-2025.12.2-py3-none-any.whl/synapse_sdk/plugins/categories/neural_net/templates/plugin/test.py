def test(run):
    return 'this is neural net test!'
