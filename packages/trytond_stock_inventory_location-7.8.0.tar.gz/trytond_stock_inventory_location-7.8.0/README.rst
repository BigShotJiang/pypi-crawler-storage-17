Stock Inventory Location Module
###############################

The Stock Inventory Location Module add a new wizard *Create
Inventories* under the *Inventories* sub-menu.

This wizard first asks the user to select the locations, the products
and the categories of product that he wants to create inventories for
and opens them in a new tab.
