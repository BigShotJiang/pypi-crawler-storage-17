from .morse import Morse

__all__ = ["Morse"]
__version__ = "0.1.0"
