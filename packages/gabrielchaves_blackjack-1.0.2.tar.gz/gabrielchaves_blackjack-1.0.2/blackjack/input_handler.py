"""
Input Handler module - Filtered input system for clean user interaction.
"""

import sys
import platform
from prompt_toolkit import Application
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import Layout
from prompt_toolkit.layout.containers import Window
from prompt_toolkit.layout.controls import DummyControl


def get_simple_input(prompt: str, valid_chars: str) -> str:
    """
    Fallback simple input for environments where special input doesn't work.
    
    Args:
        prompt: Message to display to user
        valid_chars: String containing all valid characters
    
    Returns:
        str: The validated input character (uppercase)
    """
    valid_chars = valid_chars.upper()
    
    while True:
        response = input(prompt).strip().upper()
        
        # Ignore paste events (multi-character input)
        if len(response) > 1:
            print("✖ Pasting is not allowed. Please enter a single valid character.")
            continue
        
        if response and response[0] in valid_chars:
            return response[0]
        
        print(f"✖ Invalid input. Please enter one of: {', '.join(valid_chars)}")


def _get_input_windows(valid_chars: str) -> str:
    """Windows implementation using msvcrt."""
    import msvcrt
    
    while True:
        char = msvcrt.getch()
        
        # Handle special keys
        if char in (b'\x03', b'\x1b'):  # Ctrl+C or ESC
            print()
            raise KeyboardInterrupt
        
        try:
            char_str = char.decode('utf-8').upper()
        except:
            continue
        
        # Ignore paste events (multi-character input)
        if len(char_str) > 1:
            print("✖ Pasting is not allowed. Please enter a single valid character.")
            continue
        
        if char_str in valid_chars:
            print(char_str)  # Echo the valid character
            return char_str


def _get_input_unix(valid_chars: str) -> str:
    """Unix/Linux/Mac implementation using termios."""
    import tty
    import termios
    
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    
    try:
        tty.setraw(fd)
        while True:
            char = sys.stdin.read(1)
            
            # Handle Ctrl+C
            if char == '\x03':
                print()
                raise KeyboardInterrupt
            
            char_upper = char.upper()
            
            # Ignore paste events (multi-character input)
            if len(char_upper) > 1:
                print("✖ Pasting is not allowed. Please enter a single valid character.")
                continue
            
            if char_upper in valid_chars:
                # Restore terminal and echo character
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                print(char_upper)
                return char_upper
            
            # Ignore invalid characters (no echo)
            
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def get_filtered_input(prompt: str, valid_chars: str, use_simple: bool = False) -> str:
    """
    Get input from user, only accepting specific characters.
    
    Args:
        prompt: Message to display to user
        valid_chars: String containing all valid characters (e.g., "12345Q")
        use_simple: If True, use simple input() instead of character-by-character
    
    Returns:
        str: The validated input character (uppercase)
    """
    if use_simple:
        return get_simple_input(prompt, valid_chars)
    
    try:
        valid_chars = valid_chars.upper()
        print(prompt, end='', flush=True)
        
        if platform.system() == "Windows":
            return _get_input_windows(valid_chars)
        else:
            return _get_input_unix(valid_chars)
    except (ImportError, AttributeError):
        # Fallback to simple input if special libraries not available
        print()  # New line after prompt
        return get_simple_input("", valid_chars)
    
    
def wait_for_enter(prompt: str = "Press ENTER to start playing...") -> None:
    """
    Wait for the user to press ENTER only.
    Blocks all other input, including pasted content.
    Plain console, no extra messages.
    """
    print(prompt, end='', flush=True)

    kb = KeyBindings()

    # Apenas ENTER sai
    @kb.add("enter")
    def _(event):
        print()  # quebra de linha
        event.app.exit()

    # Ignora todas as outras teclas, incluindo colagens
    @kb.add("<any>")
    def _(event):
        event.app.current_buffer.reset()

    # Layout mínimo, evita o texto "No layout specified..."
    layout = Layout(Window(content=DummyControl()))

    app = Application(
        key_bindings=kb,
        layout=layout,
        full_screen=False,
    )

    app.run()
