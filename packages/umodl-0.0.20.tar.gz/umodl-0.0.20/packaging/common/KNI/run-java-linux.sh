java -cp kni.jar:jna.jar KNIRecodeFile data/ModelingIris.kdic SNB_Iris \
    data/Iris.txt R_Iris_java.txt