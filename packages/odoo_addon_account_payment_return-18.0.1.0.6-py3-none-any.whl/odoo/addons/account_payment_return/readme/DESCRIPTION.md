This module implements customer receivables returns and allows to send
related reconciled account move lines back to a state where the debt is
still open, and letting history of it.

This module can be extended adding importers that automatically fills
the full returned payment record.
