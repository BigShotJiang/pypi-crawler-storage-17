"""
.. include:: ../../README.md
"""

from .ezinput_jupyter import EZInputJupyter
from .ezinput_prompt import EZInputPrompt
from .ezinput import EZInput
