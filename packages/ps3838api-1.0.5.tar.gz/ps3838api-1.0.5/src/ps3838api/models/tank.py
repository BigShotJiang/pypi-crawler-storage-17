from typing import TypedDict


class EventInfo(TypedDict):
    leagueId: int
    eventId: int
