from .sensapex import UMP, SensapexDevice, UMError


__version__ = "1.504.1"  # don't forget pyproject.toml and changelog
