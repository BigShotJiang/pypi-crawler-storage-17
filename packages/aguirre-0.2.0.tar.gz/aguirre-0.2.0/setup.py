#
# Dummy file for installation tools that expect it.
# All configuration is in setup.cfg.
#
from setuptools import setup
if __name__ == "__main__":
    setup()
