class ConfigurationAPI:
    pass
