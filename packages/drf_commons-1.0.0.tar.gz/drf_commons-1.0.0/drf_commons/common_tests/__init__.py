"""
Shared testing utilities for DRF Commons library.

Provides common testing infrastructure used across all DRF Commons app test suites.
"""

__version__ = "1.0.0"
