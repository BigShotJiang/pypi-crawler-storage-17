"""
Tests for views package.

This package contains tests for view functionality:
- test_base: Tests for base viewset classes
"""
