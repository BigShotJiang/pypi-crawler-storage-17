"""
Django REST Framework Common Utilities.

A collection of reusable utilities and components for Django REST Framework applications.
"""

__version__ = "1.0.0"