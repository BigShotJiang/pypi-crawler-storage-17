"""
Library-level integration tests.

Tests cross-component interactions and library installation.
"""