"""
Tests for import_from_file service.

This package contains tests for file import functionality:
- test_service: Tests for FileImportService class
"""
