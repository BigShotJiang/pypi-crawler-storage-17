default_app_config = "django_prochat.apps.DjangoProchatConfig"
