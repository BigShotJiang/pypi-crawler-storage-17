from typing import Optional, Union

import attrs

from web_poet.mixins import SelectableMixin, UrlShortcutsMixin
from web_poet.page_inputs.browser import BrowserResponse
from web_poet.page_inputs.http import HttpResponse
from web_poet.page_inputs.url import ResponseUrl


@attrs.define
class AnyResponse(SelectableMixin, UrlShortcutsMixin):
    """A container that holds either :class:`~.BrowserResponse` or :class:`~.HttpResponse`."""

    response: Union[BrowserResponse, HttpResponse]

    @property
    def url(self) -> ResponseUrl:
        """URL of the response."""
        return self.response.url

    @property
    def text(self) -> str:
        """Text or HTML contents of the response."""
        return self.response.text

    @property
    def status(self) -> Optional[int]:
        """The int status code of the HTTP response, if available."""
        return self.response.status

    def _selector_input(self) -> str:
        return self.text
