"""
Django CFG Commands API

Built-in API for executing Django management commands.
"""
