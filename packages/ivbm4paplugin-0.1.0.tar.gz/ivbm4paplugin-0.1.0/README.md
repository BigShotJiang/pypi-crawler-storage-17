# Plugin napari — Segmentation Cellpose (DIC) et application du masque sur Shift Brillouin

Ce plugin **napari** prend en entrée des images **DIC** et **Shift Brillouin**.  
Il segmente automatiquement la **zone d’intérêt (cellule)** à partir de l’image **DIC** avec **Cellpose** (modèle **cyto3** fine-tuné spécifiquement sur le DIC), puis **applique le masque** obtenu sur l’image de **shift**.

## Fonctionnalités
- Sélection d’une image **DIC** (pour la segmentation) et d’une image **Shift Brillouin** (pour l’application du masque).
- Segmentation automatique via **Cellpose** (cyto3 fine-tuné DIC).
- Création d’une couche **Labels/Masque** dans napari.
- Création d’une couche **Shift masqué** (shift restreint à la cellule).

## Structure du dépôt (plugin)
- `src/ivBM4PAPLUGIN/_widget.py` : widget napari (UI)
- `src/ivBM4PAPLUGIN/segmentation.py` : segmentation (Cellpose)
- `src/ivBM4PAPLUGIN/processing.py` : application du masque / post-traitements
- `src/ivBM4PAPLUGIN/napari.yaml` : déclaration du plugin (nom, commandes, widget)

## Prérequis
- Dépendances Python typiques :
  - `napari`
  - `cellpose`
  - `numpy`
  - `scikit-image`
  - `torch`

> Pour connaître exactement les versions/dépendances utilisées dans ton projet, regarde les `pyproject.toml` (dans `napari-plugin/` et éventuellement `napari-env/`).

## Installation (recommandée en mode développement)
Depuis la racine du plugin :

```bash
python -m pip install -U pip
python -m pip install -e .
```

## Lancer napari
```bash
napari
```

## Utilisation
1. Ouvre napari.
2. Va dans le menu **Plugins** et sélectionne le widget correspondant au plugin.
   - Le nom exact du widget dépend de `src/ivBM4PAPLUGIN/napari.yaml`.
3. Dans le widget :
   - Sélectionne la couche (ou le fichier) **DIC**.
   - Sélectionne la couche (ou le fichier) **Shift Brillouin**.
   - Sélectionne le modèle à utiliser pour la segmentation.
4. Lance la segmentation :
   - Le plugin produit une couche **Labels/Masque** correspondant à la cellule (ROI).
5. Applique le masque sur le shift :
   - Le plugin ajoute une couche **Shift masqué** (ROI extraite/isolée).

## Hypothèses importantes
- L’image DIC et l’image Shift doivent être **alignées** (même champ) pour que le masque s’applique correctement.
- La qualité dépend des conditions d’acquisition et du fine-tuning du modèle.


![](images/logo.svg)
