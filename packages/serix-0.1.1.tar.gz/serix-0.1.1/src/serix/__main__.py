"""Allow running serix as a module: python -m serix"""

from serix.cli import app

if __name__ == "__main__":
    app()
