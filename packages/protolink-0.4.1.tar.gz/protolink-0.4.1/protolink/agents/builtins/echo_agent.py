from protolink.agents import Agent


class EchoAgent(Agent):
    pass
