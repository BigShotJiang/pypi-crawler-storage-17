from .tools import *


class LocalDatas(base):
    """本地CSV数据"""
    l2601_60 = DataString("l2601_60")
    pp2601_60 = DataString("pp2601_60")
    test = DataString("test")
    v2601_300 = DataString("v2601_300")
    v2601_60 = DataString("v2601_60")


LocalDatas=LocalDatas()