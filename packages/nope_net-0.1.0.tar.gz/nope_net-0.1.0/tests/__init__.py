# Tests for NOPE Python SDK
