"""FreshRSS MCP Server - A Model Context Protocol server for FreshRSS."""

__version__ = "0.1.0"