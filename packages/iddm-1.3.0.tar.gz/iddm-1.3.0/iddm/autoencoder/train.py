#!/usr/bin/env python
# -*- coding:utf-8 -*-

# Copyright 2025 IDDM Authors

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
    @Date   : 2025/7/30 15:33
    @Author : chairc
    @Site   : https://github.com/chairc
"""
import os
import sys
import argparse

import torch

from torch import multiprocessing as mp

sys.path.append(os.path.dirname(sys.path[0]))
from iddm.config.choices import autoencoder_network_choices, optim_choices, autoencoder_loss_func_choices, \
    image_format_choices
from iddm.config.version import get_version_banner
from iddm.model.trainers.autoencoder import AutoencoderTrainer
from iddm.utils.logger import init_logger, get_logger

logger = get_logger(name=__name__)


def main(args):
    """
    Main function
    :param args: Input parameters
    :return: None
    """
    # Init logger
    init_logger(
        is_save_log=True,
        log_path=os.path.join(str(args.result_path), str(args.run_name))
    )
    if args.distributed:
        gpus = torch.cuda.device_count()
        mp.spawn(AutoencoderTrainer(args=args).train, nprocs=gpus)
    else:
        AutoencoderTrainer(args=args).train()


def init_autoencoder_train_args():
    """
    Init autoencoder model training arguments
    :return: args
    """
    # Training model parameters
    # required: Must be set
    # needed: Set as needed
    # recommend: Recommend to set
    parser = argparse.ArgumentParser()
    # =================================Base settings=================================
    # Set the seed for initialization (required)
    parser.add_argument("--seed", "-s", type=int, default=0)
    # Set network
    # Option: vae1
    parser.add_argument("--network", type=str, default="vae", choices=autoencoder_network_choices)
    # File name for initializing the model (required)
    parser.add_argument("--run_name", "-n", type=str, default="autoencoder")
    # Total epoch for training (required)
    parser.add_argument("--epochs", "-e", type=int, default=100)
    # Batch size for training (required)
    parser.add_argument("--batch_size", "-b", type=int, default=8)
    # Number of sub-processes used for data loading (needed)
    # It may consume a significant amount of CPU and memory, but it can speed up the training process.
    parser.add_argument("--num_workers", type=int, default=2)
    # Input image size (required)
    parser.add_argument("--image_size", "-i", type=int, default=512)
    # Set the number of channels in the latent space (needed)
    parser.add_argument("--latent_channels", "-l", type=int, default=8)
    # Dataset path (required)
    # Conditional dataset
    # e.g: cifar10, Each category is stored in a separate folder, and the main folder represents the path.
    # Unconditional dataset
    # All images are placed in a single folder, and the path represents the image folder.
    parser.add_argument("--train_dataset_path", type=str,
                        default="/your/path/Diffusion-Model/datasets/dir/train")
    parser.add_argument("--val_dataset_path", type=str,
                        default="/your/path/Diffusion-Model/datasets/dir/val")
    # Enable automatic mixed precision training (needed)
    # Effectively reducing GPU memory usage may lead to lower training accuracy and results.
    parser.add_argument("--amp", default=False, action="store_true")
    # Set optimizer (needed)
    # Option: adam/adamw/sgd
    parser.add_argument("--optim", type=str, default="adamw", choices=optim_choices)
    # Set loss function
    # Option: mse only
    parser.add_argument("--loss", type=str, default="mse_kl", choices=autoencoder_loss_func_choices)
    # Set activation function (needed)
    # Option: gelu/silu/relu/relu6/lrelu
    parser.add_argument("--act", type=str, default="silu")
    # Learning rate (needed)
    parser.add_argument("--lr", type=float, default=1e-4)
    # Learning rate function (needed)
    # Option: linear/cosine/warmup_cosine
    parser.add_argument("--lr_func", type=str, default="cosine")
    # Saving path (required)
    parser.add_argument("--result_path", type=str, default="/your/path/Diffusion-Model/results")
    # Whether to save weight each training (recommend)
    parser.add_argument("--save_model_interval", default=False, action="store_true")
    # Save model interval and save it every X epochs (needed)
    parser.add_argument("--save_model_interval_epochs", type=int, default=10)
    # Start epoch for saving models (needed)
    # This option saves disk space. If not set, the default is '-1'. If set,
    # it starts saving models from the specified epoch. It needs to be used with '--save_model_interval'
    parser.add_argument("--start_model_interval", type=int, default=-1)
    # Generated image format
    # Recommend to use png for better generation quality.
    # Option: jpg/png
    parser.add_argument("--image_format", type=str, default="png", choices=image_format_choices)
    # Resume interrupted training (needed)
    # 1. Set to 'True' to resume interrupted training and check if the parameter 'run_name' is correct.
    # 2. Set the resume interrupted epoch number. (If not, we would select the last)
    # Note: If the epoch number of interruption is outside the condition of '--start_model_interval',
    # it will not take effect. For example, if the start saving model time is 100 and the interruption number is 50,
    # we cannot set any loading epoch points because we did not save the model.
    # We save the 'ckpt_last.pt' file every training, so we need to use the last saved model for interrupted training
    # If you do not know what epoch the checkpoint is, rename this checkpoint is 'ckpt_last'.pt
    parser.add_argument("--resume", "-r", default=False, action="store_true")
    parser.add_argument("--start_epoch", type=int, default=None)
    # Enable use pretrain model (needed)
    parser.add_argument("--pretrain", default=False, action="store_true")
    # Pretrain model load path (needed)
    parser.add_argument("--pretrain_path", type=str, default="")
    # Set the use GPU in normal training (required)
    parser.add_argument("--use_gpu", type=int, default=0)

    # =================================Enable distributed training (if applicable)=================================
    # Enable distributed training (needed)
    parser.add_argument("--distributed", "-d", default=False, action="store_true")
    # Set the main GPU (required)
    # Default GPU is '0'
    parser.add_argument("--main_gpu", type=int, default=0)
    # Number of distributed nodes (needed)
    # The value of world size will correspond to the actual number of GPUs or distributed nodes being used
    parser.add_argument("--world_size", type=int, default=2)

    return parser.parse_args()


if __name__ == "__main__":
    args = init_autoencoder_train_args()
    # Get version banner
    get_version_banner()
    main(args)
