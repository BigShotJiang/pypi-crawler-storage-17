"""MCP Search Server - Web search, PDF parsing, and content extraction."""

__version__ = "0.1.1"
