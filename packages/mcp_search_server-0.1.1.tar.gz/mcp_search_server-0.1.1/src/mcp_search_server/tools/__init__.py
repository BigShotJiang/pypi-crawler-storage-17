"""Tools for MCP Search Server."""
