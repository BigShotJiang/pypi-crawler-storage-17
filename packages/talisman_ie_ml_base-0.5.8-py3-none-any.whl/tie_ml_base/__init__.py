__all__ = [
    'PROCESSORS'
]

from .huggingface_pipeline.configuration import HF_PROCESSORS

PROCESSORS = HF_PROCESSORS
