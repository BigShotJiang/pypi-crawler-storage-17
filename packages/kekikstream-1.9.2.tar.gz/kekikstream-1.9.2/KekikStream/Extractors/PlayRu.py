# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Extractors.ContentX import ContentX

class PlayRu(ContentX):
    name     = "PlayRu"
    main_url = "https://playru.net"