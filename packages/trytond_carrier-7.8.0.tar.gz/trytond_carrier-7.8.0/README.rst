##############
Carrier Module
##############

The *Carrier Module* adds the concept of carrier.

.. toctree::
   :maxdepth: 2

   design
   releases
