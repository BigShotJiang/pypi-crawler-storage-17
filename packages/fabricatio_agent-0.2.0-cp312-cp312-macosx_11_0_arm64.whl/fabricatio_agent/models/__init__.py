"""Models defined in fabricatio-agent."""
