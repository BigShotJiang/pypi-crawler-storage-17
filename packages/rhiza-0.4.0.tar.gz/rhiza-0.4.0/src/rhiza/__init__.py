"""Utility tools and command-line helpers for the Rhiza project.

This package groups small, user-facing utilities that can be invoked from
the command line or other automation scripts.
"""
