# rhiza-cli
Command line interface for Rhiza
