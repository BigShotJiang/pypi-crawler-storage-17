# Typed Cex

> A fully typed, validated async client for the Cex API

Use *autocomplete* instead of documentation.

🚧 Under construction.