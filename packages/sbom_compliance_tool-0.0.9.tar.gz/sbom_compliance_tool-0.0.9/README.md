# sbom-compliance-tool

Tool to assist your compliance work with SBoM, including

* create a checklist with all license conditions you need to comply with

* check if your outbound license is compatible with all the inbound licenses

