"""Classes and functions for working with document-like objects."""
