"""Various helpers and utilities."""
