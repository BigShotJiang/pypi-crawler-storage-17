from typing import TypedDict


class ICLExample(TypedDict):
    requirement: str
    reasoning: str
    decision: str
