from typing import TypedDict


class ICLExample(TypedDict):
    task_prompt: str
    general_instructions: str
