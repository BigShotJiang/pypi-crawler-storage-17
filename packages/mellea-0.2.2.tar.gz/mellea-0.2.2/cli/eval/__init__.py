"""CLI for test-based evaluation"""
