"""TUI module: Shared Textual components for issue and session viewers."""
