"""Issues module: Local-first issue tracking with GitHub Issues semantics."""
