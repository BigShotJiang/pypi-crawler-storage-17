"""skill-issues: Local-first issue tracking and session memory for Claude Code."""

__version__ = "0.1.0"
