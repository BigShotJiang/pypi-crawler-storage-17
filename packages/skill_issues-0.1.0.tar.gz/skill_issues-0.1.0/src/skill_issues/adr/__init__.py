"""ADR (Architecture Decision Records) skill."""
