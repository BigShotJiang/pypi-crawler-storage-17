# Minimal dummy classes for Sphinx documentation builds
class Dataset:
    """Dummy Dataset class for Sphinx builds."""
    pass


class Variable:
    """Dummy Variable class for Sphinx builds."""
    pass
