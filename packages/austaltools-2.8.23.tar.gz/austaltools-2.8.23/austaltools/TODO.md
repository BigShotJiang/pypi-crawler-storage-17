
  - translate CORINE-classes (242) to LBM-DE classes
  - switch from TAL1002 CORINE to TAL2021 LBM classes
