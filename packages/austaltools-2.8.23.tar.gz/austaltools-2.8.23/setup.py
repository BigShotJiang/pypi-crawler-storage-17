#!/usr/bin/env python3

# import glob
# import os
from setuptools import setup

# v = {}
# v_path = os.path.join(*'austaltools/_version.py'.split('/'))
# with open(v_path) as v_file:
#     exec(v_file.read(), v)

setup()
#     name=v['__title__'],
#     version=v['__version__'],
#     packages=[v['__title__'],
#               v['__title__']+".data"
#               ],
#     package_dir={v['__title__']: v['__title__']},
#     package_data={
#         v['__title__']+".data": ["*.txt", "*.json"],
#     },
#     entry_points={
#         'console_scripts': [
#             'austaltools=austaltools.command_line:main',
#             'austal-input=austaltools.austal_input:main',
#             'configure-austaltools=austaltools.configure_austaltools:main',
#         ],
#     },
#     author=v['__author__'],
#     author_email=v['__author_email__'],
#     license=v['__license__'],
#     url=v['__url__'],
#     install_requires=[
#         "cdsapi",
#         "gdal",
#         "meteolib",
#         "netcdf4",
#         "numpy",
#         "pandas",
#         "pyyaml",
#         "readmet",
#         "requests",
#         "setuptools",
#         "tqdm",
#         "pyyaml",
#         "urllib3",
#     ],
#     description=v['__description__'],
#     long_description=open('README.md').read(),
#     long_description_content_type='text/markdown',
# )
