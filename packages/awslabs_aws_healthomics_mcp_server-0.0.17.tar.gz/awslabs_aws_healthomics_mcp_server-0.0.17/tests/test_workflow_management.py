# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Unit tests for workflow management tools."""

import base64
import botocore.exceptions
import pytest
from awslabs.aws_healthomics_mcp_server.tools.workflow_management import (
    create_workflow,
    create_workflow_version,
    get_workflow,
    list_workflow_versions,
    list_workflows,
)
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch


@pytest.mark.asyncio
async def test_list_workflows_success():
    """Test successful listing of workflows."""
    # Mock response data
    creation_time = datetime.now(timezone.utc)
    mock_response = {
        'items': [
            {
                'id': 'wfl-12345',
                'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
                'name': 'test-workflow-1',
                'description': 'Test workflow 1',
                'status': 'ACTIVE',
                'parameters': {'param1': 'value1'},
                'storageType': 'DYNAMIC',
                'type': 'WDL',
                'creationTime': creation_time,
            },
            {
                'id': 'wfl-67890',
                'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-67890',
                'name': 'test-workflow-2',
                'status': 'ACTIVE',
                'storageType': 'STATIC',
                'storageCapacity': 100,
                'type': 'CWL',
                'creationTime': creation_time,
            },
        ],
        'nextToken': 'next-page-token',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.list_workflows.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await list_workflows(ctx=mock_ctx, max_results=10, next_token=None)

    # Verify client was called correctly
    mock_client.list_workflows.assert_called_once_with(maxResults=10)

    # Verify result structure
    assert 'workflows' in result
    assert 'nextToken' in result
    assert result['nextToken'] == 'next-page-token'
    assert len(result['workflows']) == 2

    # Verify first workflow
    wf1 = result['workflows'][0]
    assert wf1['id'] == 'wfl-12345'
    assert wf1['name'] == 'test-workflow-1'
    assert wf1['description'] == 'Test workflow 1'
    assert wf1['status'] == 'ACTIVE'
    assert wf1['parameters'] == {'param1': 'value1'}
    assert wf1['storageType'] == 'DYNAMIC'
    assert wf1['type'] == 'WDL'
    assert wf1['creationTime'] == creation_time.isoformat()

    # Verify second workflow
    wf2 = result['workflows'][1]
    assert wf2['id'] == 'wfl-67890'
    assert wf2['status'] == 'ACTIVE'
    assert wf2['storageType'] == 'STATIC'
    assert wf2['storageCapacity'] == 100


@pytest.mark.asyncio
async def test_list_workflows_empty_response():
    """Test listing workflows with empty response."""
    mock_response = {'items': []}

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.list_workflows.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await list_workflows(ctx=mock_ctx, max_results=10, next_token=None)

    # Verify empty result
    assert result['workflows'] == []
    assert 'nextToken' not in result


@pytest.mark.asyncio
async def test_list_workflows_with_pagination():
    """Test listing workflows with pagination."""
    mock_response = {
        'items': [{'id': 'wfl-12345', 'name': 'test-workflow'}],
        'nextToken': 'next-page-token',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.list_workflows.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await list_workflows(ctx=mock_ctx, max_results=10, next_token='current-token')

    # Verify pagination parameters
    mock_client.list_workflows.assert_called_once_with(
        maxResults=10, startingToken='current-token'
    )
    assert result['nextToken'] == 'next-page-token'


@pytest.mark.asyncio
async def test_list_workflows_boto_error():
    """Test handling of BotoCoreError in list_workflows."""
    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.list_workflows.side_effect = botocore.exceptions.BotoCoreError()

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        with pytest.raises(botocore.exceptions.BotoCoreError):
            await list_workflows(ctx=mock_ctx, max_results=10, next_token=None)

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'AWS error listing workflows' in mock_ctx.error.call_args[0][0]


@pytest.mark.asyncio
async def test_list_workflows_unexpected_error():
    """Test handling of unexpected errors in list_workflows."""
    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.list_workflows.side_effect = Exception('Unexpected error')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        with pytest.raises(Exception, match='Unexpected error'):
            await list_workflows(ctx=mock_ctx, max_results=10, next_token=None)

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'Unexpected error listing workflows' in mock_ctx.error.call_args[0][0]


@pytest.mark.asyncio
async def test_get_workflow_success():
    """Test successful retrieval of workflow details."""
    # Mock response data
    creation_time = datetime.now(timezone.utc)
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'name': 'test-workflow',
        'status': 'ACTIVE',
        'statusMessage': 'Workflow is ready for execution',
        'type': 'WDL',
        'description': 'Test workflow description',
        'parameterTemplate': {'param1': {'type': 'string'}},
        'creationTime': creation_time,
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.get_workflow.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await get_workflow(ctx=mock_ctx, workflow_id='wfl-12345', export_definition=False)

    # Verify client was called correctly
    mock_client.get_workflow.assert_called_once_with(id='wfl-12345')

    # Verify result contains all expected fields
    assert result['id'] == 'wfl-12345'
    assert result['arn'] == 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345'
    assert result['name'] == 'test-workflow'
    assert result['status'] == 'ACTIVE'
    assert result['statusMessage'] == 'Workflow is ready for execution'
    assert result['type'] == 'WDL'
    assert result['description'] == 'Test workflow description'
    assert result['parameterTemplate'] == {'param1': {'type': 'string'}}
    assert result['creationTime'] == creation_time.isoformat()


@pytest.mark.asyncio
async def test_get_workflow_with_export():
    """Test workflow retrieval with export definition."""
    # Mock response data with presigned URL (as returned by AWS API)
    mock_response = {
        'id': 'wfl-12345',
        'name': 'test-workflow',
        'definition': 'https://s3.amazonaws.com/bucket/workflow-definition.zip?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=...',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.get_workflow.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await get_workflow(ctx=mock_ctx, workflow_id='wfl-12345', export_definition=True)

    # Verify export parameter was passed
    mock_client.get_workflow.assert_called_once_with(id='wfl-12345', export=['DEFINITION'])

    # Verify presigned URL was included in result
    assert result['definition'].startswith('https://s3.amazonaws.com/')
    assert 'X-Amz-Algorithm' in result['definition']


@pytest.mark.asyncio
async def test_get_workflow_without_export():
    """Test workflow retrieval without export definition."""
    # Mock response data without definition field (normal response)
    creation_time = datetime.now(timezone.utc)
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'name': 'test-workflow',
        'status': 'ACTIVE',
        'type': 'WDL',
        'description': 'Test workflow description',
        'parameterTemplate': {'param1': {'type': 'string'}},
        'creationTime': creation_time,
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.get_workflow.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await get_workflow(ctx=mock_ctx, workflow_id='wfl-12345', export_definition=False)

    # Verify export parameter was NOT passed
    mock_client.get_workflow.assert_called_once_with(id='wfl-12345')

    # Verify no definition field in result
    assert 'definition' not in result

    # Verify other fields are present
    assert result['parameterTemplate'] == {'param1': {'type': 'string'}}


@pytest.mark.asyncio
async def test_get_workflow_minimal_response():
    """Test workflow retrieval with minimal response fields."""
    # Mock response with minimal fields
    creation_time = datetime.now(timezone.utc)
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'name': 'test-workflow',
        'status': 'ACTIVE',
        'type': 'WDL',
        'creationTime': creation_time,
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.get_workflow.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await get_workflow(ctx=mock_ctx, workflow_id='wfl-12345', export_definition=False)

    # Verify required fields
    assert result['id'] == 'wfl-12345'
    assert result['status'] == 'ACTIVE'
    assert result['creationTime'] == creation_time.isoformat()

    # Verify optional fields are not present
    assert 'description' not in result
    assert 'parameterTemplate' not in result
    assert 'definition' not in result


@pytest.mark.asyncio
async def test_get_workflow_boto_error():
    """Test handling of BotoCoreError in get_workflow."""
    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.get_workflow.side_effect = botocore.exceptions.BotoCoreError()

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        with pytest.raises(botocore.exceptions.BotoCoreError):
            await get_workflow(ctx=mock_ctx, workflow_id='wfl-12345', export_definition=False)

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'AWS error getting workflow' in mock_ctx.error.call_args[0][0]


@pytest.mark.asyncio
async def test_get_workflow_unexpected_error():
    """Test handling of unexpected errors in get_workflow."""
    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.get_workflow.side_effect = Exception('Unexpected error')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        with pytest.raises(Exception, match='Unexpected error'):
            await get_workflow(ctx=mock_ctx, workflow_id='wfl-12345', export_definition=False)

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'Unexpected error getting workflow' in mock_ctx.error.call_args[0][0]


@pytest.mark.asyncio
async def test_get_workflow_none_timestamp():
    """Test handling of None timestamp in get_workflow."""
    # Mock response with None timestamp
    mock_response = {
        'id': 'wfl-12345',
        'name': 'test-workflow',
        'status': 'ACTIVE',
        'type': 'WDL',
        'creationTime': None,
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.get_workflow.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await get_workflow(ctx=mock_ctx, workflow_id='wfl-12345', export_definition=False)

    # Verify timestamp handling
    assert result['creationTime'] is None


@pytest.mark.asyncio
async def test_get_workflow_with_status_message():
    """Test workflow retrieval with status message."""
    # Mock response with status message
    creation_time = datetime.now(timezone.utc)
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'name': 'test-workflow',
        'status': 'FAILED',
        'statusMessage': 'Workflow validation failed: Invalid WDL syntax',
        'type': 'WDL',
        'creationTime': creation_time,
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.get_workflow.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await get_workflow(ctx=mock_ctx, workflow_id='wfl-12345', export_definition=False)

    # Verify status message is included
    assert result['status'] == 'FAILED'
    assert result['statusMessage'] == 'Workflow validation failed: Invalid WDL syntax'


@pytest.mark.asyncio
async def test_get_workflow_with_container_registry_map():
    """Test workflow retrieval with container registry map."""
    # Mock response with container registry map
    creation_time = datetime.now(timezone.utc)
    container_registry_map = {
        'registryMappings': [
            {'upstreamRegistryUrl': 'registry-1.docker.io', 'ecrRepositoryPrefix': 'docker-hub'},
            {'upstreamRegistryUrl': 'quay.io', 'ecrRepositoryPrefix': 'quay'},
        ]
    }
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'name': 'test-workflow',
        'status': 'ACTIVE',
        'type': 'WDL',
        'description': 'Test workflow with container registry map',
        'parameterTemplate': {'param1': {'type': 'string'}},
        'containerRegistryMap': container_registry_map,
        'creationTime': creation_time,
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.get_workflow.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await get_workflow(ctx=mock_ctx, workflow_id='wfl-12345', export_definition=False)

    # Verify container registry map is included
    assert result['containerRegistryMap'] == container_registry_map
    assert (
        result['containerRegistryMap']['registryMappings'][0]['upstreamRegistryUrl']
        == 'registry-1.docker.io'
    )
    assert (
        result['containerRegistryMap']['registryMappings'][0]['ecrRepositoryPrefix']
        == 'docker-hub'
    )
    assert (
        result['containerRegistryMap']['registryMappings'][1]['upstreamRegistryUrl'] == 'quay.io'
    )
    assert result['containerRegistryMap']['registryMappings'][1]['ecrRepositoryPrefix'] == 'quay'

    # Verify other fields are present
    assert result['id'] == 'wfl-12345'
    assert result['status'] == 'ACTIVE'
    assert result['description'] == 'Test workflow with container registry map'


@pytest.mark.asyncio
async def test_get_workflow_without_container_registry_map():
    """Test workflow retrieval without container registry map."""
    # Mock response without container registry map
    creation_time = datetime.now(timezone.utc)
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'name': 'test-workflow',
        'status': 'ACTIVE',
        'type': 'WDL',
        'description': 'Test workflow without container registry map',
        'parameterTemplate': {'param1': {'type': 'string'}},
        'creationTime': creation_time,
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.get_workflow.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await get_workflow(ctx=mock_ctx, workflow_id='wfl-12345', export_definition=False)

    # Verify container registry map is not present
    assert 'containerRegistryMap' not in result

    # Verify other fields are present
    assert result['id'] == 'wfl-12345'
    assert result['status'] == 'ACTIVE'
    assert result['description'] == 'Test workflow without container registry map'


@pytest.mark.asyncio
async def test_list_workflow_versions_success(mock_omics_client, mock_context):
    """Test successful listing of workflow versions."""
    # Mock response from AWS
    mock_omics_client.list_workflow_versions.return_value = {
        'items': [
            {
                'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/abc123/1.0',
                'id': 'abc123',
                'status': 'ACTIVE',
                'type': 'WDL',
                'name': 'Test Workflow',
                'versionName': '1.0',
                'creationTime': '2023-01-01T00:00:00Z',
            },
            {
                'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/abc123/2.0',
                'id': 'abc123',
                'status': 'ACTIVE',
                'type': 'WDL',
                'name': 'Test Workflow',
                'versionName': '2.0',
                'creationTime': '2023-02-01T00:00:00Z',
            },
        ],
        'nextToken': None,
    }

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_omics_client,
    ):
        # Call the function
        result = await list_workflow_versions(mock_context, workflow_id='abc123', max_results=10)

    # Assertions
    assert 'versions' in result
    assert len(result['versions']) == 2
    assert result['versions'][0]['versionName'] == '1.0'
    assert result['versions'][1]['versionName'] == '2.0'
    assert result['nextToken'] is None


@pytest.mark.asyncio
async def test_list_workflow_versions_with_pagination(mock_omics_client, mock_context):
    """Test listing workflow versions with pagination."""
    # First call response with nextToken
    mock_omics_client.list_workflow_versions.side_effect = [
        {
            'items': [
                {
                    'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/abc123/1.0',
                    'id': 'abc123',
                    'status': 'ACTIVE',
                    'type': 'WDL',
                    'name': 'Test Workflow',
                    'versionName': '1.0',
                    'creationTime': '2023-01-01T00:00:00Z',
                }
            ],
            'nextToken': 'next-page-token',
        },
        {
            'items': [
                {
                    'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/abc123/2.0',
                    'id': 'abc123',
                    'status': 'ACTIVE',
                    'type': 'WDL',
                    'name': 'Test Workflow',
                    'versionName': '2.0',
                    'creationTime': '2023-02-01T00:00:00Z',
                }
            ],
            'nextToken': None,
        },
    ]

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_omics_client,
    ):
        # First call
        result1 = await list_workflow_versions(mock_context, workflow_id='abc123', max_results=1)

        # Second call with next token
        result2 = await list_workflow_versions(
            mock_context, workflow_id='abc123', max_results=1, next_token=result1['nextToken']
        )

    # Assertions for first call
    assert 'versions' in result1
    assert len(result1['versions']) == 1
    assert result1['versions'][0]['versionName'] == '1.0'
    assert result1['nextToken'] == 'next-page-token'

    # Assertions for second call
    assert 'versions' in result2
    assert len(result2['versions']) == 1
    assert result2['versions'][0]['versionName'] == '2.0'
    assert result2['nextToken'] is None


@pytest.mark.asyncio
async def test_list_workflow_versions_empty_result(mock_omics_client, mock_context):
    """Test listing workflow versions with empty result."""
    # Mock empty response
    mock_omics_client.list_workflow_versions.return_value = {
        'items': [],
        'nextToken': None,
    }

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_omics_client,
    ):
        # Call the function
        result = await list_workflow_versions(mock_context, workflow_id='abc123', max_results=10)

    # Assertions
    assert 'versions' in result
    assert len(result['versions']) == 0
    if 'nextToken' in result:
        assert result['nextToken'] is None


@pytest.mark.asyncio
async def test_list_workflow_versions_client_error(mock_omics_client, mock_context):
    """Test handling of client error when listing workflow versions."""
    from botocore.exceptions import ClientError

    # Mock client error
    error_response = {
        'Error': {'Code': 'ResourceNotFoundException', 'Message': 'Workflow not found'}
    }
    mock_omics_client.list_workflow_versions.side_effect = ClientError(
        error_response,  # type: ignore
        'ListWorkflowVersions',
    )

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_omics_client,
    ):
        # Call the function and expect it to raise an exception
        with pytest.raises(ClientError):
            await list_workflow_versions(mock_context, workflow_id='nonexistent-id')

        # Verify error was reported to context
        mock_context.error.assert_called_once()
        assert 'Workflow not found' in mock_context.error.call_args[0][0]


@pytest.mark.asyncio
async def test_list_workflow_versions_general_exception(mock_omics_client, mock_context):
    """Test handling of general exception when listing workflow versions."""
    # Mock general exception
    mock_omics_client.list_workflow_versions.side_effect = Exception('Unexpected error')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_omics_client,
    ):
        # Call the function and expect it to raise an exception
        with pytest.raises(Exception):
            await list_workflow_versions(mock_context, workflow_id='abc123')

        # Verify error was reported to context
        mock_context.error.assert_called_once()
        assert 'Unexpected error listing workflow versions' in mock_context.error.call_args[0][0]


@pytest.mark.asyncio
async def test_create_workflow_success():
    """Test successful workflow creation."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'description': 'Test workflow description',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            description='Test workflow description',
            parameter_template={'param1': {'type': 'string'}},
            container_registry_map=None,
            container_registry_map_uri=None,
        )

    # Verify client was called correctly
    expected_call = mock_client.create_workflow.call_args
    assert expected_call.kwargs['name'] == 'test-workflow'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content'
    assert expected_call.kwargs['description'] == 'Test workflow description'
    assert expected_call.kwargs['parameterTemplate'] == {'param1': {'type': 'string'}}
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['arn'] == 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345'
    assert result['status'] == 'ACTIVE'
    assert result['name'] == 'test-workflow'
    assert result['description'] == 'Test workflow description'


@pytest.mark.asyncio
async def test_create_workflow_minimal():
    """Test workflow creation with minimal required parameters."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
        )

    # Verify client was called with only required parameters
    expected_call = mock_client.create_workflow.call_args
    assert expected_call.kwargs['name'] == 'test-workflow'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content'
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['name'] == 'test-workflow'
    # description should not be in result when it's None in response
    assert result.get('description') is None


@pytest.mark.asyncio
async def test_create_workflow_invalid_base64():
    """Test workflow creation with invalid base64 content."""
    # Mock context
    mock_ctx = AsyncMock()

    with pytest.raises(Exception, match='Invalid base64-encoded string'):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64='invalid base64!',
            description=None,
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'Failed to decode base64' in mock_ctx.error.call_args[0][0]


@pytest.mark.asyncio
async def test_create_workflow_boto_error():
    """Test handling of BotoCoreError in create_workflow."""
    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.side_effect = botocore.exceptions.BotoCoreError()

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with (
        patch(
            'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
            return_value=mock_client,
        ),
        pytest.raises(botocore.exceptions.BotoCoreError),
    ):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'AWS error creating workflow' in mock_ctx.error.call_args[0][0]


@pytest.mark.asyncio
async def test_create_workflow_unexpected_error():
    """Test handling of unexpected errors in create_workflow."""
    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.side_effect = Exception('Unexpected error')

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with (
        patch(
            'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
            return_value=mock_client,
        ),
        pytest.raises(Exception, match='Unexpected error'),
    ):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'Unexpected error creating workflow' in mock_ctx.error.call_args[0][0]


@pytest.mark.asyncio
async def test_create_workflow_with_container_registry_map():
    """Test workflow creation with container registry map."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'description': 'Test workflow with container registry map',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    # Container registry map - using complete structure with all required fields
    container_registry_map = {
        'registryMappings': [
            {
                'upstreamRegistryUrl': 'registry-1.docker.io',
                'ecrRepositoryPrefix': 'docker-hub',
                'upstreamRepositoryPrefix': 'library',
                'ecrAccountId': '123456789012',
            },
            {
                'upstreamRegistryUrl': 'quay.io',
                'ecrRepositoryPrefix': 'quay',
                'upstreamRepositoryPrefix': 'biocontainers',
                'ecrAccountId': '123456789012',
            },
        ]
    }

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            description='Test workflow with container registry map',
            parameter_template={'param1': {'type': 'string'}},
            container_registry_map=container_registry_map,
            container_registry_map_uri=None,
        )

    # Verify client was called correctly with container registry map
    expected_call = mock_client.create_workflow.call_args
    assert expected_call.kwargs['name'] == 'test-workflow'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content'
    assert expected_call.kwargs['description'] == 'Test workflow with container registry map'
    assert expected_call.kwargs['parameterTemplate'] == {'param1': {'type': 'string'}}
    assert expected_call.kwargs['containerRegistryMap'] == container_registry_map
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['arn'] == 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345'
    assert result['status'] == 'ACTIVE'
    assert result['name'] == 'test-workflow'
    assert result['description'] == 'Test workflow with container registry map'


@pytest.mark.asyncio
async def test_create_workflow_without_container_registry_map():
    """Test workflow creation without container registry map."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
        )

    # Verify client was called without container registry map
    expected_call = mock_client.create_workflow.call_args
    assert expected_call.kwargs['name'] == 'test-workflow'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content'
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['name'] == 'test-workflow'


@pytest.mark.asyncio
async def test_create_workflow_with_container_registry_map_uri():
    """Test workflow creation with container registry map URI."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'description': 'Test workflow with container registry map URI',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    # S3 URI for container registry map
    container_registry_map_uri = 's3://my-bucket/registry-mappings.json'

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            description='Test workflow with container registry map URI',
            parameter_template={'param1': {'type': 'string'}},
            container_registry_map=None,
            container_registry_map_uri=container_registry_map_uri,
        )

    # Verify client was called correctly with container registry map URI
    expected_call = mock_client.create_workflow.call_args
    assert expected_call.kwargs['name'] == 'test-workflow'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content'
    assert expected_call.kwargs['description'] == 'Test workflow with container registry map URI'
    assert expected_call.kwargs['parameterTemplate'] == {'param1': {'type': 'string'}}
    assert expected_call.kwargs['containerRegistryMapUri'] == container_registry_map_uri
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['arn'] == 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345'
    assert result['status'] == 'ACTIVE'
    assert result['name'] == 'test-workflow'
    assert result['description'] == 'Test workflow with container registry map URI'


@pytest.mark.asyncio
async def test_create_workflow_invalid_container_registry_map():
    """Test workflow creation with invalid container registry map structure."""
    # Mock context
    mock_ctx = AsyncMock()

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    # Invalid container registry map - missing required fields
    invalid_container_registry_map = {
        'registryMappings': [
            {'upstreamRegistryUrl': 'registry-1.docker.io'}  # Missing required fields
        ]
    }

    # Should raise ValueError due to validation error
    with pytest.raises(ValueError, match='Invalid container registry map structure'):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            container_registry_map=invalid_container_registry_map,
            container_registry_map_uri=None,
        )


@pytest.mark.asyncio
async def test_create_workflow_both_container_registry_params_error():
    """Test workflow creation fails when both container registry parameters are provided."""
    # Mock context
    mock_ctx = AsyncMock()

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    # Container registry map
    container_registry_map = {
        'registryMappings': [
            {'upstreamRegistryUrl': 'registry-1.docker.io', 'ecrRepositoryPrefix': 'docker-hub'}
        ]
    }

    # S3 URI for container registry map
    container_registry_map_uri = 's3://my-bucket/registry-mappings.json'

    with pytest.raises(
        ValueError,
        match='Cannot specify both container_registry_map and container_registry_map_uri parameters',
    ):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            container_registry_map=container_registry_map,
            container_registry_map_uri=container_registry_map_uri,
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert (
        'Cannot specify both container_registry_map and container_registry_map_uri parameters'
        in mock_ctx.error.call_args[0][0]
    )


@pytest.mark.asyncio
async def test_create_workflow_version_success():
    """Test successful workflow version creation."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description='Version 2.0 of test workflow',
            parameter_template={'param1': {'type': 'string'}},
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
        )

    # Verify client was called correctly
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content v2'
    assert expected_call.kwargs['description'] == 'Version 2.0 of test workflow'
    assert expected_call.kwargs['parameterTemplate'] == {'param1': {'type': 'string'}}
    assert expected_call.kwargs['storageType'] == 'DYNAMIC'
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['versionName'] == 'v2.0'
    assert result['status'] == 'ACTIVE'


@pytest.mark.asyncio
async def test_create_workflow_version_with_static_storage():
    """Test workflow version creation with static storage."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            storage_type='STATIC',
            storage_capacity=1000,
            container_registry_map=None,
            container_registry_map_uri=None,
        )

    # Verify client was called with static storage parameters
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content v2'
    assert expected_call.kwargs['storageType'] == 'STATIC'
    assert expected_call.kwargs['storageCapacity'] == 1000
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs


@pytest.mark.asyncio
async def test_create_workflow_version_static_without_capacity():
    """Test workflow version creation with static storage but no capacity."""
    # Mock context
    mock_ctx = AsyncMock()

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with pytest.raises(ValueError, match='Storage capacity is required'):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            storage_type='STATIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()


@pytest.mark.asyncio
async def test_create_workflow_version_invalid_base64():
    """Test workflow version creation with invalid base64 content."""
    # Mock context
    mock_ctx = AsyncMock()

    with pytest.raises(Exception, match='Invalid base64-encoded string'):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64='invalid base64!',
            description=None,
            parameter_template=None,
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'Failed to decode base64' in mock_ctx.error.call_args[0][0]


@pytest.mark.asyncio
async def test_create_workflow_version_boto_error():
    """Test handling of BotoCoreError in create_workflow_version."""
    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.side_effect = botocore.exceptions.BotoCoreError()

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with (
        patch(
            'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
            return_value=mock_client,
        ),
        pytest.raises(botocore.exceptions.BotoCoreError),
    ):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'AWS error creating workflow version' in mock_ctx.error.call_args[0][0]


@pytest.mark.asyncio
async def test_create_workflow_version_with_container_registry_map():
    """Test workflow version creation with container registry map."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    # Container registry map - using complete structure with all required fields
    container_registry_map = {
        'registryMappings': [
            {
                'upstreamRegistryUrl': 'registry-1.docker.io',
                'ecrRepositoryPrefix': 'docker-hub',
                'upstreamRepositoryPrefix': 'library',
                'ecrAccountId': '123456789012',
            },
            {
                'upstreamRegistryUrl': 'quay.io',
                'ecrRepositoryPrefix': 'quay',
                'upstreamRepositoryPrefix': 'biocontainers',
                'ecrAccountId': '123456789012',
            },
        ]
    }

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description='Version 2.0 with container registry map',
            parameter_template={'param1': {'type': 'string'}},
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=container_registry_map,
            container_registry_map_uri=None,
        )

    # Verify client was called correctly with container registry map
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content v2'
    assert expected_call.kwargs['description'] == 'Version 2.0 with container registry map'
    assert expected_call.kwargs['parameterTemplate'] == {'param1': {'type': 'string'}}
    assert expected_call.kwargs['storageType'] == 'DYNAMIC'
    assert expected_call.kwargs['containerRegistryMap'] == container_registry_map
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['versionName'] == 'v2.0'
    assert result['status'] == 'ACTIVE'


@pytest.mark.asyncio
async def test_create_workflow_version_without_container_registry_map():
    """Test workflow version creation without container registry map."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description='Version 2.0 without container registry map',
            parameter_template={'param1': {'type': 'string'}},
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
        )

    # Verify client was called without container registry map
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content v2'
    assert expected_call.kwargs['description'] == 'Version 2.0 without container registry map'
    assert expected_call.kwargs['parameterTemplate'] == {'param1': {'type': 'string'}}
    assert expected_call.kwargs['storageType'] == 'DYNAMIC'
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['versionName'] == 'v2.0'
    assert result['status'] == 'ACTIVE'


@pytest.mark.asyncio
async def test_create_workflow_version_with_static_storage_and_container_registry_map():
    """Test workflow version creation with both static storage and container registry map."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    # Container registry map - using complete structure with all required fields
    container_registry_map = {
        'registryMappings': [
            {
                'upstreamRegistryUrl': 'registry-1.docker.io',
                'ecrRepositoryPrefix': 'docker-hub',
                'upstreamRepositoryPrefix': 'library',
                'ecrAccountId': '123456789012',
            }
        ]
    }

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description='Version 2.0 with static storage and container registry map',
            parameter_template=None,
            storage_type='STATIC',
            storage_capacity=2000,
            container_registry_map=container_registry_map,
            container_registry_map_uri=None,
        )

    # Verify client was called with both static storage and container registry map
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content v2'
    assert (
        expected_call.kwargs['description']
        == 'Version 2.0 with static storage and container registry map'
    )
    assert expected_call.kwargs['storageType'] == 'STATIC'
    assert expected_call.kwargs['storageCapacity'] == 2000
    assert expected_call.kwargs['containerRegistryMap'] == container_registry_map
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['versionName'] == 'v2.0'
    assert result['status'] == 'ACTIVE'


@pytest.mark.asyncio
async def test_create_workflow_version_with_container_registry_map_uri():
    """Test workflow version creation with container registry map URI."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    # S3 URI for container registry map
    container_registry_map_uri = 's3://my-bucket/registry-mappings.json'

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description='Version 2.0 with container registry map URI',
            parameter_template={'param1': {'type': 'string'}},
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=container_registry_map_uri,
        )

    # Verify client was called correctly with container registry map URI
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content v2'
    assert expected_call.kwargs['description'] == 'Version 2.0 with container registry map URI'
    assert expected_call.kwargs['parameterTemplate'] == {'param1': {'type': 'string'}}
    assert expected_call.kwargs['storageType'] == 'DYNAMIC'
    assert expected_call.kwargs['containerRegistryMapUri'] == container_registry_map_uri
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['versionName'] == 'v2.0'
    assert result['status'] == 'ACTIVE'


@pytest.mark.asyncio
async def test_create_workflow_version_both_container_registry_params_error():
    """Test workflow version creation fails when both container registry parameters are provided."""
    # Mock context
    mock_ctx = AsyncMock()

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    # Container registry map
    container_registry_map = {
        'registryMappings': [
            {'upstreamRegistryUrl': 'registry-1.docker.io', 'ecrRepositoryPrefix': 'docker-hub'}
        ]
    }

    # S3 URI for container registry map
    container_registry_map_uri = 's3://my-bucket/registry-mappings.json'

    with pytest.raises(
        ValueError,
        match='Cannot specify both container_registry_map and container_registry_map_uri parameters',
    ):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=container_registry_map,
            container_registry_map_uri=container_registry_map_uri,
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert (
        'Cannot specify both container_registry_map and container_registry_map_uri parameters'
        in mock_ctx.error.call_args[0][0]
    )


# Tests for S3 URI support in create_workflow


@pytest.mark.asyncio
async def test_create_workflow_with_s3_uri():
    """Test successful workflow creation with S3 URI."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'description': 'Test workflow description',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=None,
            description='Test workflow description',
            parameter_template={'param1': {'type': 'string'}},
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri='s3://my-bucket/workflow-definition.zip',
        )

    # Verify client was called correctly with S3 URI
    expected_call = mock_client.create_workflow.call_args
    assert expected_call.kwargs['name'] == 'test-workflow'
    assert expected_call.kwargs['definitionUri'] == 's3://my-bucket/workflow-definition.zip'
    assert expected_call.kwargs['description'] == 'Test workflow description'
    assert expected_call.kwargs['parameterTemplate'] == {'param1': {'type': 'string'}}
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['arn'] == 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345'
    assert result['status'] == 'ACTIVE'
    assert result['name'] == 'test-workflow'
    assert result['description'] == 'Test workflow description'


@pytest.mark.asyncio
async def test_create_workflow_both_definition_sources_error():
    """Test error when both definition_zip_base64 and definition_uri are provided."""
    # Mock context
    mock_ctx = AsyncMock()

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with pytest.raises(
        ValueError, match='Cannot specify both definition_zip_base64 and definition_uri'
    ):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri='s3://my-bucket/workflow-definition.zip',
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert (
        'Cannot specify both definition_zip_base64 and definition_uri'
        in mock_ctx.error.call_args[0][0]
    )


@pytest.mark.asyncio
async def test_create_workflow_no_definition_source_error():
    """Test error when neither definition_zip_base64 nor definition_uri are provided."""
    # Mock context
    mock_ctx = AsyncMock()

    with pytest.raises(
        ValueError, match='Must specify either definition_zip_base64 or definition_uri'
    ):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=None,
            description=None,
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri=None,
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert (
        'Must specify either definition_zip_base64 or definition_uri'
        in mock_ctx.error.call_args[0][0]
    )


@pytest.mark.asyncio
async def test_create_workflow_invalid_s3_uri():
    """Test error when definition_uri is not a valid S3 URI."""
    # Mock context
    mock_ctx = AsyncMock()

    with pytest.raises(ValueError, match='definition_uri must be a valid S3 URI'):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=None,
            description=None,
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri='https://example.com/workflow.zip',
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'definition_uri must be a valid S3 URI' in mock_ctx.error.call_args[0][0]


# Tests for S3 URI support in create_workflow_version


@pytest.mark.asyncio
async def test_create_workflow_version_with_s3_uri():
    """Test successful workflow version creation with S3 URI."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
        'description': 'Test workflow version description',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=None,
            description='Test workflow version description',
            parameter_template={'param1': {'type': 'string'}},
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri='s3://my-bucket/workflow-definition-v2.zip',
        )

    # Verify client was called correctly with S3 URI
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionUri'] == 's3://my-bucket/workflow-definition-v2.zip'
    assert expected_call.kwargs['description'] == 'Test workflow version description'
    assert expected_call.kwargs['parameterTemplate'] == {'param1': {'type': 'string'}}
    assert expected_call.kwargs['storageType'] == 'DYNAMIC'
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['arn'] == 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345'
    assert result['status'] == 'ACTIVE'
    assert result['name'] == 'test-workflow'
    assert result['versionName'] == 'v2.0'
    assert result['description'] == 'Test workflow version description'


@pytest.mark.asyncio
async def test_create_workflow_version_both_definition_sources_error():
    """Test error when both definition_zip_base64 and definition_uri are provided for version creation."""
    # Mock context
    mock_ctx = AsyncMock()

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with pytest.raises(
        ValueError, match='Cannot specify both definition_zip_base64 and definition_uri'
    ):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri='s3://my-bucket/workflow-definition.zip',
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert (
        'Cannot specify both definition_zip_base64 and definition_uri'
        in mock_ctx.error.call_args[0][0]
    )


@pytest.mark.asyncio
async def test_create_workflow_version_no_definition_source_error():
    """Test error when neither definition_zip_base64 nor definition_uri are provided for version creation."""
    # Mock context
    mock_ctx = AsyncMock()

    with pytest.raises(
        ValueError, match='Must specify either definition_zip_base64 or definition_uri'
    ):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=None,
            description=None,
            parameter_template=None,
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri=None,
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert (
        'Must specify either definition_zip_base64 or definition_uri'
        in mock_ctx.error.call_args[0][0]
    )


@pytest.mark.asyncio
async def test_create_workflow_version_invalid_container_registry_map():
    """Test workflow version creation with invalid container registry map structure."""
    # Mock context
    mock_ctx = AsyncMock()

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    # Invalid container registry map (missing required fields)
    invalid_container_registry_map = {
        'registryMappings': [
            {'invalidField': 'invalid-value'}  # Missing required fields
        ]
    }

    with pytest.raises(ValueError, match='Invalid container registry map structure'):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=invalid_container_registry_map,
            container_registry_map_uri=None,
            definition_uri=None,
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'Invalid container registry map structure' in mock_ctx.error.call_args[0][0]


@pytest.mark.asyncio
async def test_create_workflow_version_invalid_s3_uri():
    """Test error when definition_uri is not a valid S3 URI for version creation."""
    # Mock context
    mock_ctx = AsyncMock()

    with pytest.raises(ValueError, match='definition_uri must be a valid S3 URI'):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=None,
            description=None,
            parameter_template=None,
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri='https://example.com/workflow.zip',
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'definition_uri must be a valid S3 URI' in mock_ctx.error.call_args[0][0]


@pytest.mark.asyncio
async def test_create_workflow_version_unexpected_error():
    """Test handling of unexpected errors in create_workflow_version."""
    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.side_effect = Exception('Unexpected error')

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with (
        patch(
            'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
            return_value=mock_client,
        ),
        pytest.raises(Exception, match='Unexpected error'),
    ):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri=None,
        )

    # Verify error was reported to context
    mock_ctx.error.assert_called_once()
    assert 'Unexpected error creating workflow version' in mock_ctx.error.call_args[0][0]


@pytest.mark.asyncio
async def test_create_workflow_s3_uri_minimal():
    """Test workflow creation with S3 URI and minimal parameters."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=None,
            description=None,
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri='s3://my-bucket/workflow-definition.zip',
        )

    # Verify client was called with only required parameters
    expected_call = mock_client.create_workflow.call_args
    assert expected_call.kwargs['name'] == 'test-workflow'
    assert expected_call.kwargs['definitionUri'] == 's3://my-bucket/workflow-definition.zip'
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['name'] == 'test-workflow'
    assert result.get('description') is None


@pytest.mark.asyncio
async def test_create_workflow_version_s3_uri_with_static_storage():
    """Test workflow version creation with S3 URI and STATIC storage."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=None,
            description=None,
            parameter_template=None,
            storage_type='STATIC',
            storage_capacity=100,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri='s3://my-bucket/workflow-definition-v2.zip',
        )

    # Verify client was called with STATIC storage parameters
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionUri'] == 's3://my-bucket/workflow-definition-v2.zip'
    assert expected_call.kwargs['storageType'] == 'STATIC'
    assert expected_call.kwargs['storageCapacity'] == 100
    # path_to_main should not be passed when None
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['versionName'] == 'v2.0'


@pytest.mark.asyncio
async def test_list_workflow_versions_botocore_error():
    """Test handling of BotoCoreError when listing workflow versions."""
    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.list_workflow_versions.side_effect = botocore.exceptions.BotoCoreError()

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        # Call the function and expect it to raise an exception
        with pytest.raises(botocore.exceptions.BotoCoreError):
            await list_workflow_versions(mock_ctx, workflow_id='wfl-12345')

        # Verify error was reported to context
        mock_ctx.error.assert_called_once()
        assert (
            'AWS error listing workflow versions for workflow wfl-12345'
            in mock_ctx.error.call_args[0][0]
        )


# Tests for path_to_main parameter


@pytest.mark.asyncio
async def test_create_workflow_with_path_to_main():
    """Test workflow creation with path_to_main parameter."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'description': 'Test workflow with path_to_main',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            description='Test workflow with path_to_main',
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri=None,
            path_to_main='workflows/main.wdl',
        )

    # Verify client was called correctly with path_to_main
    expected_call = mock_client.create_workflow.call_args
    assert expected_call.kwargs['name'] == 'test-workflow'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content'
    assert expected_call.kwargs['description'] == 'Test workflow with path_to_main'
    assert expected_call.kwargs['main'] == 'workflows/main.wdl'

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['name'] == 'test-workflow'
    assert result['description'] == 'Test workflow with path_to_main'


@pytest.mark.asyncio
async def test_create_workflow_with_path_to_main_s3_uri():
    """Test workflow creation with path_to_main parameter and S3 URI."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'description': 'Test workflow with path_to_main and S3 URI',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=None,
            description='Test workflow with path_to_main and S3 URI',
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri='s3://my-bucket/workflow-definition.zip',
            path_to_main='src/main.cwl',
        )

    # Verify client was called correctly with path_to_main and S3 URI
    expected_call = mock_client.create_workflow.call_args
    assert expected_call.kwargs['name'] == 'test-workflow'
    assert expected_call.kwargs['definitionUri'] == 's3://my-bucket/workflow-definition.zip'
    assert expected_call.kwargs['description'] == 'Test workflow with path_to_main and S3 URI'
    assert expected_call.kwargs['main'] == 'src/main.cwl'

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['name'] == 'test-workflow'
    assert result['description'] == 'Test workflow with path_to_main and S3 URI'


@pytest.mark.asyncio
async def test_create_workflow_with_path_to_main_nextflow():
    """Test workflow creation with path_to_main parameter for Nextflow."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'nextflow-workflow',
        'description': 'Test Nextflow workflow with path_to_main',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'nextflow workflow content').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow(
            mock_ctx,
            name='nextflow-workflow',
            definition_zip_base64=definition_zip_base64,
            description='Test Nextflow workflow with path_to_main',
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri=None,
            path_to_main='pipelines/main.nf',
        )

    # Verify client was called correctly with Nextflow path_to_main
    expected_call = mock_client.create_workflow.call_args
    assert expected_call.kwargs['name'] == 'nextflow-workflow'
    assert expected_call.kwargs['definitionZip'] == b'nextflow workflow content'
    assert expected_call.kwargs['description'] == 'Test Nextflow workflow with path_to_main'
    assert expected_call.kwargs['main'] == 'pipelines/main.nf'

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['name'] == 'nextflow-workflow'


@pytest.mark.asyncio
async def test_create_workflow_version_with_path_to_main():
    """Test workflow version creation with path_to_main parameter."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description='Version 2.0 with path_to_main',
            parameter_template=None,
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri=None,
            path_to_main='workflows/v2/main.wdl',
        )

    # Verify client was called correctly with path_to_main
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content v2'
    assert expected_call.kwargs['description'] == 'Version 2.0 with path_to_main'
    assert expected_call.kwargs['storageType'] == 'DYNAMIC'
    assert expected_call.kwargs['main'] == 'workflows/v2/main.wdl'

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['versionName'] == 'v2.0'


@pytest.mark.asyncio
async def test_create_workflow_version_with_path_to_main_s3_uri():
    """Test workflow version creation with path_to_main parameter and S3 URI."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=None,
            description='Version 2.0 with path_to_main and S3 URI',
            parameter_template=None,
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri='s3://my-bucket/workflow-definition-v2.zip',
            path_to_main='src/v2/main.cwl',
        )

    # Verify client was called correctly with path_to_main and S3 URI
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionUri'] == 's3://my-bucket/workflow-definition-v2.zip'
    assert expected_call.kwargs['description'] == 'Version 2.0 with path_to_main and S3 URI'
    assert expected_call.kwargs['storageType'] == 'DYNAMIC'
    assert expected_call.kwargs['main'] == 'src/v2/main.cwl'

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['versionName'] == 'v2.0'


@pytest.mark.asyncio
async def test_create_workflow_version_with_path_to_main_static_storage():
    """Test workflow version creation with path_to_main parameter and static storage."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description='Version 2.0 with path_to_main and static storage',
            parameter_template=None,
            storage_type='STATIC',
            storage_capacity=500,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri=None,
            path_to_main='workflows/static/main.wdl',
        )

    # Verify client was called correctly with path_to_main and static storage
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content v2'
    assert (
        expected_call.kwargs['description'] == 'Version 2.0 with path_to_main and static storage'
    )
    assert expected_call.kwargs['storageType'] == 'STATIC'
    assert expected_call.kwargs['storageCapacity'] == 500
    assert expected_call.kwargs['main'] == 'workflows/static/main.wdl'

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['versionName'] == 'v2.0'


@pytest.mark.asyncio
async def test_create_workflow_version_with_path_to_main_and_container_registry():
    """Test workflow version creation with path_to_main parameter and container registry map."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    # Container registry map
    container_registry_map = {
        'registryMappings': [
            {
                'upstreamRegistryUrl': 'registry-1.docker.io',
                'ecrRepositoryPrefix': 'docker-hub',
                'upstreamRepositoryPrefix': 'library',
                'ecrAccountId': '123456789012',
            }
        ]
    }

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description='Version 2.0 with path_to_main and container registry',
            parameter_template=None,
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=container_registry_map,
            container_registry_map_uri=None,
            definition_uri=None,
            path_to_main='workflows/containerized/main.wdl',
        )

    # Verify client was called correctly with path_to_main and container registry map
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content v2'
    assert (
        expected_call.kwargs['description']
        == 'Version 2.0 with path_to_main and container registry'
    )
    assert expected_call.kwargs['storageType'] == 'DYNAMIC'
    assert expected_call.kwargs['containerRegistryMap'] == container_registry_map
    assert expected_call.kwargs['main'] == 'workflows/containerized/main.wdl'

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['versionName'] == 'v2.0'


@pytest.mark.asyncio
async def test_create_workflow_with_path_to_main_empty_string():
    """Test workflow creation with empty string path_to_main parameter."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri=None,
            path_to_main='',  # Empty string should be treated as None
        )

    # Verify client was called correctly - empty string should not be passed
    expected_call = mock_client.create_workflow.call_args
    assert expected_call.kwargs['name'] == 'test-workflow'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content'
    # Empty string path_to_main should not be passed to AWS API
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['name'] == 'test-workflow'


@pytest.mark.asyncio
async def test_create_workflow_version_with_path_to_main_empty_string():
    """Test workflow version creation with empty string path_to_main parameter."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            description=None,
            parameter_template=None,
            storage_type='DYNAMIC',
            storage_capacity=None,
            container_registry_map=None,
            container_registry_map_uri=None,
            definition_uri=None,
            path_to_main='',  # Empty string should be treated as None
        )

    # Verify client was called correctly - empty string should not be passed
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['workflowId'] == 'wfl-12345'
    assert expected_call.kwargs['versionName'] == 'v2.0'
    assert expected_call.kwargs['definitionZip'] == b'test workflow content v2'
    assert expected_call.kwargs['storageType'] == 'DYNAMIC'
    # Empty string path_to_main should not be passed to AWS API
    assert 'main' not in expected_call.kwargs

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['versionName'] == 'v2.0'


# Tests for path_to_main validation integration


@pytest.mark.asyncio
async def test_create_workflow_with_invalid_path_to_main_absolute():
    """Test workflow creation fails with absolute path_to_main."""
    mock_ctx = AsyncMock()
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with pytest.raises(ValueError, match='must be a relative path'):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            path_to_main='/absolute/path/main.wdl',
        )

    mock_ctx.error.assert_called_once()


@pytest.mark.asyncio
async def test_create_workflow_with_invalid_path_to_main_traversal():
    """Test workflow creation fails with directory traversal in path_to_main."""
    mock_ctx = AsyncMock()
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with pytest.raises(ValueError, match='cannot contain directory traversal sequences'):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            path_to_main='../main.wdl',
        )

    mock_ctx.error.assert_called_once()


@pytest.mark.asyncio
async def test_create_workflow_with_invalid_path_to_main_extension():
    """Test workflow creation fails with invalid file extension in path_to_main."""
    mock_ctx = AsyncMock()
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with pytest.raises(ValueError, match='must point to a workflow file with extension'):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            path_to_main='workflows/script.py',
        )

    mock_ctx.error.assert_called_once()


@pytest.mark.asyncio
async def test_create_workflow_version_with_invalid_path_to_main_absolute():
    """Test workflow version creation fails with absolute path_to_main."""
    mock_ctx = AsyncMock()
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with pytest.raises(ValueError, match='must be a relative path'):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            storage_type='DYNAMIC',
            path_to_main='/absolute/path/main.wdl',
        )

    mock_ctx.error.assert_called_once()


@pytest.mark.asyncio
async def test_create_workflow_version_with_invalid_path_to_main_traversal():
    """Test workflow version creation fails with directory traversal in path_to_main."""
    mock_ctx = AsyncMock()
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with pytest.raises(ValueError, match='cannot contain directory traversal sequences'):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            storage_type='DYNAMIC',
            path_to_main='workflows/../../../etc/passwd',
        )

    mock_ctx.error.assert_called_once()


@pytest.mark.asyncio
async def test_create_workflow_version_with_invalid_path_to_main_extension():
    """Test workflow version creation fails with invalid file extension in path_to_main."""
    mock_ctx = AsyncMock()
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with pytest.raises(ValueError, match='must point to a workflow file with extension'):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            storage_type='DYNAMIC',
            path_to_main='workflows/config.json',
        )

    mock_ctx.error.assert_called_once()


@pytest.mark.asyncio
async def test_create_workflow_with_path_normalization():
    """Test workflow creation normalizes valid path_to_main."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            path_to_main='./workflows/main.wdl',  # Should be normalized to 'workflows/main.wdl'
        )

    # Verify client was called with normalized path
    expected_call = mock_client.create_workflow.call_args
    assert expected_call.kwargs['main'] == 'workflows/main.wdl'  # Normalized path

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['name'] == 'test-workflow'


@pytest.mark.asyncio
async def test_create_workflow_version_with_path_normalization():
    """Test workflow version creation normalizes valid path_to_main."""
    # Mock response data
    mock_response = {
        'id': 'wfl-12345',
        'arn': 'arn:aws:omics:us-east-1:123456789012:workflow/wfl-12345',
        'status': 'ACTIVE',
        'name': 'test-workflow',
        'versionName': 'v2.0',
    }

    # Mock context and client
    mock_ctx = AsyncMock()
    mock_client = MagicMock()
    mock_client.create_workflow_version.return_value = mock_response

    # Create base64 encoded workflow definition
    definition_zip_base64 = base64.b64encode(b'test workflow content v2').decode('utf-8')

    with patch(
        'awslabs.aws_healthomics_mcp_server.tools.workflow_management.get_omics_client',
        return_value=mock_client,
    ):
        result = await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            storage_type='DYNAMIC',
            path_to_main='./src/pipeline.cwl',  # Should be normalized to 'src/pipeline.cwl'
        )

    # Verify client was called with normalized path
    expected_call = mock_client.create_workflow_version.call_args
    assert expected_call.kwargs['main'] == 'src/pipeline.cwl'  # Normalized path

    # Verify result contains expected fields
    assert result['id'] == 'wfl-12345'
    assert result['versionName'] == 'v2.0'


# Tests for path_to_main validation integration


@pytest.mark.asyncio
async def test_create_workflow_path_to_main_validation_absolute_path():
    """Test that create_workflow rejects absolute paths in path_to_main."""
    mock_ctx = AsyncMock()

    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with pytest.raises(ValueError, match='must be a relative path'):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            path_to_main='/absolute/path/main.wdl',
        )


@pytest.mark.asyncio
async def test_create_workflow_path_to_main_validation_directory_traversal():
    """Test that create_workflow rejects directory traversal in path_to_main."""
    mock_ctx = AsyncMock()

    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with pytest.raises(ValueError, match='cannot contain directory traversal sequences'):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            path_to_main='../main.wdl',
        )


@pytest.mark.asyncio
async def test_create_workflow_path_to_main_validation_invalid_extension():
    """Test that create_workflow rejects invalid file extensions in path_to_main."""
    mock_ctx = AsyncMock()

    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with pytest.raises(ValueError, match='must point to a workflow file with extension'):
        await create_workflow(
            mock_ctx,
            name='test-workflow',
            definition_zip_base64=definition_zip_base64,
            path_to_main='main.txt',
        )


@pytest.mark.asyncio
async def test_create_workflow_version_path_to_main_validation_absolute_path():
    """Test that create_workflow_version rejects absolute paths in path_to_main."""
    mock_ctx = AsyncMock()

    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with pytest.raises(ValueError, match='must be a relative path'):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            storage_type='DYNAMIC',
            path_to_main='/absolute/path/main.wdl',
        )


@pytest.mark.asyncio
async def test_create_workflow_version_path_to_main_validation_directory_traversal():
    """Test that create_workflow_version rejects directory traversal in path_to_main."""
    mock_ctx = AsyncMock()

    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with pytest.raises(ValueError, match='cannot contain directory traversal sequences'):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            storage_type='DYNAMIC',
            path_to_main='workflows/../main.wdl',
        )


@pytest.mark.asyncio
async def test_create_workflow_version_path_to_main_validation_invalid_extension():
    """Test that create_workflow_version rejects invalid file extensions in path_to_main."""
    mock_ctx = AsyncMock()

    definition_zip_base64 = base64.b64encode(b'test workflow content').decode('utf-8')

    with pytest.raises(ValueError, match='must point to a workflow file with extension'):
        await create_workflow_version(
            mock_ctx,
            workflow_id='wfl-12345',
            version_name='v2.0',
            definition_zip_base64=definition_zip_base64,
            storage_type='DYNAMIC',
            path_to_main='main.py',
        )
