"""Main package."""

from ez_ados.client import AzureDevOps

__all__ = ["AzureDevOps"]
