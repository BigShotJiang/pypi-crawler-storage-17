"""Git API module."""
