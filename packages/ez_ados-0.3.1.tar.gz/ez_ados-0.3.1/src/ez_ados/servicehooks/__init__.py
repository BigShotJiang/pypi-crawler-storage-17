"""Service Hooks API module."""
