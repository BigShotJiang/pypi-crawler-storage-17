"""Service Hooks' Subscriptions API models."""
