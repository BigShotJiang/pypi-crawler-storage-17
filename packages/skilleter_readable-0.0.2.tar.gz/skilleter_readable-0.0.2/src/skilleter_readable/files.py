#! /usr/bin/env python3

################################################################################
""" Thingy file handling functions

    Copyright (C) 2017-18 John Skilleter

    High-level file access functions not provided by the Python libraries
"""
################################################################################

import os
import shutil

################################################################################

def backup(filename, extension='bak', copyfile=True, timestamps=True):
    """ Create a backup of a file by copying or renaming it into a file with extension
        .bak, deleting any existing file with that name.

        Copies the file by default, unless copyfile is False
        Sets the timetamps of the backup file to be the same as the original, unless
        timestamps is False."""

    # Do nothing if the file does not exist

    if not os.path.isfile(filename):
        return

    # Split on the dot characters

    filename_comp = filename.split('.')

    # Replace the extension with the specified on (or 'bak' by
    # default) or add it if the filename did not have an extension.

    if len(filename_comp) > 1:
        filename_comp[-1] = extension
    else:
        filename_comp.append(extension)

    backupname = '.'.join(filename_comp)

    # Remove any existing backup file

    if os.path.isfile(backupname):
        os.unlink(backupname)

    # Create the backup by copying or renaming the file, optionally preserving the
    # timestamp of the original file

    if timestamps:
        file_info = os.stat(filename)

    if copyfile:
        shutil.copyfile(filename, backupname)
    else:
        os.rename(filename, backupname)

    if timestamps:
        os.utime(backupname, ns=(file_info.st_atime_ns, file_info.st_mtime_ns))
