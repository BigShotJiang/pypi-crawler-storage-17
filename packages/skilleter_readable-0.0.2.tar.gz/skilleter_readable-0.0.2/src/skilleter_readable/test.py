#!/usr/bin/env python3

print('Importing all modules')
import readable
print('Import successful')
