=======
History
=======

0.0.1 (2018-02-12)
------------------

* First release on PyPI.
