"""
PhaseLab: A framework for phase-coherence analysis across quantum, biological, and dynamical systems.

Built on the Informational Relativity (IR) framework, PhaseLab provides:
- Quantum coherence metrics (R̄, V_φ) for simulation reliability
- CRISPR/CRISPRa guide RNA design pipelines
- Circadian clock modeling for gene therapy dosage optimization
- Protein folding and dynamics coherence assessment (v0.2.0)
- Tissue-specific chromatin accessibility models (v0.2.0)
- Multi-tissue circadian models with inter-tissue coupling (v0.3.0)
- Drug response modeling and chronotherapy optimization (v0.3.0)
- Expanded CRISPR editors: base editing (ABE/CBE) and prime editing (v0.3.0)
- Complete CRISPR toolkit with knockout and CRISPRi (v0.4.0)
- Therapeutic dosage optimization with haploinsufficiency models (v0.4.0)

NEW in v0.5.0:
- Real ATAC-seq BigWig integration for tissue-specific accessibility
- CpG methylation modeling for CRISPRa efficiency prediction
- Nucleosome occupancy prediction (NuPoP-like algorithm)
- Multi-guide synergy modeling for combinatorial CRISPR
- Enhancer targeting for CRISPRa
- AAV serotype selection and delivery modeling
- Immunogenicity prediction for Cas9 and guide RNA
- Comprehensive validation report generation

NEW in v0.6.0:
- ATLAS-Q integration for advanced quantum simulation
- IR measurement grouping (5× variance reduction)
- Real circular statistics coherence (replaces heuristic)
- Coherence-aware VQE optimization
- Optional GPU acceleration via Triton kernels
- Rust backend support for 30-77× faster simulation
- IR-enhanced off-target analysis for CRISPOR integration
- Unified ATLAS-Q coherence across all CRISPR modalities
- Off-target entropy and coherence contrast metrics

NEW in v0.6.1:
- Coherence mode parameter: mode="heuristic" (fast) vs mode="quantum" (VQE)
- Honest coherence weighting: heuristic demoted to tie-breaker (0.05 vs 0.30)
- Two-stage scoring: hard safety gates + soft ranking
- Risk mass metrics: risk_mass_close, risk_mass_exonic, tail_risk_score
- Evidence levels: A/B/C classification for validation status
- Score capping: unvalidated guides capped to prevent misleading rankings

NEW in v0.7.0 - Virtual Assay Stack:
- Biological context layer: ATAC-seq, methylation, histone marks from ENCODE/Roadmap
- ML outcome predictor protocol: adapters for DeepCRISPR, DeepSpCas9, Enformer
- Evidence fusion system: hierarchical score combination with uncertainty
- Score calibration: Platt/isotonic calibration for ML predictions
- Enhanced GO/NO-GO: context-aware coherence thresholds

NEW in v0.8.0 - Claim Levels and Diagnostics:
- ClaimLevel classification: STRONG_COMPUTATIONAL, CONTEXT_DEPENDENT, EXPLORATORY, UNKNOWN
- Layer disagreement detection: diagnostic warnings when ML and context disagree
- Explicit unknown bucket: predictions with insufficient evidence marked as UNKNOWN
- Human-readable claim descriptions for user communication
- Critical disagreement flagging for conflicting evidence

NEW in v0.9.0 - SMS Trials Module (Preclinical Decision Engine):
- CRISPRa RAI1 activation trial for SMS therapeutic development
- CRISPRi modifier gene suppression trials (PER1, CRY1, CLOCK)
- Knockout model validation trials
- Base editing trials for RAI1 variant correction
- Prime editing trials for regulatory motif repair
- Circadian rescue simulation with therapeutic window prediction
- AAV delivery feasibility assessment for CNS targeting
- Complete SMS pipeline orchestrator with GO/NO-GO decisions
- Falsification test framework for validation studies
- Wet lab recommendations and validation priorities

Author: Dylan Vaca
License: MIT
"""

__version__ = "0.9.0"
__author__ = "Dylan Vaca"

from .core.coherence import coherence_score, go_no_go, phase_variance
from .core.constants import E_MINUS_2, FOUR_PI_SQUARED

# Quantum coherence (v0.6.0 - ATLAS-Q enhanced)
from .quantum.coherence import (
    CoherenceResult,
    compute_coherence_from_expectations,
    compute_coherence_from_phases,
    compute_coherence_from_hamiltonian,
)
from .quantum import is_atlas_q_available

# CRISPR coherence utilities (v0.6.0, v0.6.1 adds CoherenceMode)
from .crispr.coherence_utils import (
    CoherenceMode,
    compute_guide_coherence,
    compute_guide_coherence_with_details,
    is_guide_coherent,
    get_coherence_method,
    get_coherence_eligibility_info,
)

# CRISPOR Integration IR-Enhanced Analysis (v0.6.0)
from .integrations.crispor.offtarget_ir import (
    OffTargetSite,
    OffTargetIRAnalysis,
    analyze_offtarget_landscape,
    compute_ir_enhanced_score,
)

# Evidence fusion (v0.7.0) and claim levels (v0.8.0)
from .fusion import (
    ClaimLevel,
    LayerDisagreement,
    EvidenceFusion,
    FusedResult,
    FusionConfig,
)

__all__ = [
    # Core coherence
    "coherence_score",
    "go_no_go",
    "phase_variance",
    "E_MINUS_2",
    "FOUR_PI_SQUARED",
    "__version__",

    # Quantum coherence (v0.6.0)
    "CoherenceResult",
    "compute_coherence_from_expectations",
    "compute_coherence_from_phases",
    "compute_coherence_from_hamiltonian",
    "is_atlas_q_available",

    # CRISPR coherence (v0.6.0, v0.6.1)
    "CoherenceMode",
    "compute_guide_coherence",
    "compute_guide_coherence_with_details",
    "is_guide_coherent",
    "get_coherence_method",
    "get_coherence_eligibility_info",

    # CRISPOR IR-Enhanced (v0.6.0)
    "OffTargetSite",
    "OffTargetIRAnalysis",
    "analyze_offtarget_landscape",
    "compute_ir_enhanced_score",

    # Evidence fusion and claim levels (v0.7.0, v0.8.0)
    "ClaimLevel",
    "LayerDisagreement",
    "EvidenceFusion",
    "FusedResult",
    "FusionConfig",
]
