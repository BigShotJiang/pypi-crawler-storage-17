from .core import extract_docx_recursive

__version__ = "1.0.0"
__all__ = ["extract_docx_recursive"]
