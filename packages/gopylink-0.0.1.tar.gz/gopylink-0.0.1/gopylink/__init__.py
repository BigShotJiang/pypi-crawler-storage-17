"""
gopylink - A placeholder package
"""
