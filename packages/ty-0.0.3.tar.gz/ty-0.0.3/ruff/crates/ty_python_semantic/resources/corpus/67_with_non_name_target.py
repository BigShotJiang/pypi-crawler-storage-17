with foo() as self.bar:
    pass
