def _[T: T[0]](x: T):
    if x:
        pass
