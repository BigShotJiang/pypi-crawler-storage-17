class C:

    def foo(self):
        self

