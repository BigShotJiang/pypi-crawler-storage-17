c = (a, b)
d = {e: 1, f: 2}
fun(a, b, *c, **d)
