x = 0
if x := x + 1:
    pass
