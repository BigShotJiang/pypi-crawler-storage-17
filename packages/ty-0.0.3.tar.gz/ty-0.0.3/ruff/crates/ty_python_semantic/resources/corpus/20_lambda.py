lambda x: y

lambda x: a and b
