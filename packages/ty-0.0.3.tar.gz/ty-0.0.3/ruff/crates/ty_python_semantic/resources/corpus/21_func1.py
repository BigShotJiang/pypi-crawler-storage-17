def foo():
    a
