from __future__ import barry_as_FLUFL

foo.bar: Callable[..., object] = __import__
