del a
del a[0]
del a.b
