def f():
    raise
