x = 0
class A:
    y = 1
match x:
    case A.y as z:
        pass
