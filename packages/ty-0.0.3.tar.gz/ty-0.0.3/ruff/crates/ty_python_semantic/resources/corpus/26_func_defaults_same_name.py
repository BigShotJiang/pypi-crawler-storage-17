def bool(x=bool):
    return x
