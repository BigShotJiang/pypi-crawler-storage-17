a, = x,
a, b = x, y
a, b, c = x, y, z
a, b, c, d = w, x, y, z
a, b = 1, 2
