a == b
a != b
a < b
a <= b
a > b
a >= b
a is b
a is not b
a in b
a not in b
