

winget install Gyan.FFmpeg --source winget --scope user --accept-package-agreements --accept-source-agreements

