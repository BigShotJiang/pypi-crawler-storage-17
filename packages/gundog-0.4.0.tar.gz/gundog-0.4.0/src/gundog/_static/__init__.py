"""Static files for gundog web UI."""
