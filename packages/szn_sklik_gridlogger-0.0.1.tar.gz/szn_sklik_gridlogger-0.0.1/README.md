# szn-sklik-gridlogger

This is a security placeholder package created to prevent dependency confusion attacks.