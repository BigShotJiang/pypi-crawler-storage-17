:::mokkari.exceptions.ApiError
:::mokkari.exceptions.RateLimitError
:::mokkari.exceptions.AuthenticationError
:::mokkari.exceptions.CacheError
