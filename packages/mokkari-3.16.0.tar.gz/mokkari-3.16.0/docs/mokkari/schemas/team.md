:::mokkari.schemas.team.Team
:::mokkari.schemas.team.TeamPost
:::mokkari.schemas.team.TeamPostResponse
