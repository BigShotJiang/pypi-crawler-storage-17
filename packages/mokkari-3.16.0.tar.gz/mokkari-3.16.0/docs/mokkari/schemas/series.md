:::mokkari.schemas.series.AssociatedSeries
:::mokkari.schemas.series.CommonSeries
:::mokkari.schemas.series.BaseSeries
:::mokkari.schemas.series.Series
:::mokkari.schemas.series.SeriesPost
:::mokkari.schemas.series.SeriesPostResponse
