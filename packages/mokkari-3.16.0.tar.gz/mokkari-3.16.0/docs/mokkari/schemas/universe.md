:::mokkari.schemas.universe.Universe
:::mokkari.schemas.universe.UniversePost
:::mokkari.schemas.universe.UniversePostResponse
