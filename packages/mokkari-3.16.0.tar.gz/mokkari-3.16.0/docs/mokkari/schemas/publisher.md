:::mokkari.schemas.publisher.Publisher
:::mokkari.schemas.publisher.PublisherPost
