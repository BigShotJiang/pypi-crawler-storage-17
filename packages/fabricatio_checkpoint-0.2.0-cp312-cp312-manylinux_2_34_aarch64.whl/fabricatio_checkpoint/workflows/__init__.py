"""Workflows defined in fabricatio-checkpoint."""
