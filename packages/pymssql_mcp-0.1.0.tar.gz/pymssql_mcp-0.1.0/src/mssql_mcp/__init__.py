"""MCP server for Microsoft SQL Server databases."""

__version__ = "0.1.0"
