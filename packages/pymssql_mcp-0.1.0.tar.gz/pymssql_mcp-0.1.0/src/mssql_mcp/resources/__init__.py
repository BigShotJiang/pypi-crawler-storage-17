"""MCP resources for SQL Server."""

# Import resource modules to register them with the FastMCP instance
from . import syntax_help

__all__ = ["syntax_help"]
