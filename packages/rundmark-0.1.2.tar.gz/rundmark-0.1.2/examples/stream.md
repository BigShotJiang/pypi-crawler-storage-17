```bash{run="stream ouput test"}
echo sleeping
sleep 3
echo woke up
sleep 1
```

```bash{run}
echo ok
```
