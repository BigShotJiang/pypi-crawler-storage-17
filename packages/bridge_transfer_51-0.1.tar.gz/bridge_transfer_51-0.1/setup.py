
from setuptools import setup
setup(
    name="bridge_transfer_51",
    version="0.1",
    py_modules=["carrier"],
)
