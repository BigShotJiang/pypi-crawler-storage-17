"""Command line interface for ncdlmuse."""
