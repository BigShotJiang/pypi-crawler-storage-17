# About

Medusa is a minimal static site generator using Markdown and Jinja2.
