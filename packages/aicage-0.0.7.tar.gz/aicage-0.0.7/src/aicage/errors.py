class CliError(Exception):
    """Raised for user-facing CLI errors."""
