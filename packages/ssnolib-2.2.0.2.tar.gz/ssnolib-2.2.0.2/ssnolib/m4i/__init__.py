from .variable import NumericalVariable

__all__ = ("NumericalVariable",)
