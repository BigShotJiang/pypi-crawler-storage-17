from .property import Property
from .variable import Variable

__all__ = ("Property", "Variable")
