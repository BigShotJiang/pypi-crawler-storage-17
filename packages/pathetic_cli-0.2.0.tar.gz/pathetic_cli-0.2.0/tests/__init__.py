"""Test suite for pathetic-cli."""
