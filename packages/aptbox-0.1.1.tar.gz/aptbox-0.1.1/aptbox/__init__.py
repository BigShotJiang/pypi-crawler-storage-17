# -*- coding: utf-8 -*-
"""
APT软件包快照与比较工具
"""

__version__ = '0.1.0'