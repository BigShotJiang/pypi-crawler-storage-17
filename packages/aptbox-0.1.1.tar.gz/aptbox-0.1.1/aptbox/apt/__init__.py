# -*- coding: utf-8 -*-
"""
APT交互模块：负责执行apt update操作
"""