"""MARSGuard SDK: High-level client for enforced schema (updated to new schema)."""

from __future__ import annotations
from typing import Optional, Dict, Any
import requests
from .schemas import (
    AppModel,
    ModelSpec,
    AudienceSpec,
    ContentRulesSpec,
    CustomSpec,
    ProjectSpec,
    GenerateGuardrailsRequest,
    DualGuardrailsResponse,
)

class MarsGuardClient:
    """
    Client for interacting with the MARSGuard backend using the new enforced schema.

    Example usage:
        from marsguard.schemas import (
            AppModel, ModelSpec, AudienceSpec, ContentRulesSpec, CustomSpec, ProjectSpec, GenerateGuardrailsRequest
        )
        from marsguard.sdk import MarsGuardClient

        client = MarsGuardClient()
        req = GenerateGuardrailsRequest(
            app=AppModel(name="Patient Support Assistant", context="A customer-facing chatbot for healthcare appointment booking."),
            domain="healthcare",
            model=ModelSpec(provider="openai", name="gpt-4o"),
            project_spec=ProjectSpec(
                relaxation_factor=0.1,
                audience=AudienceSpec(age_factor=30, risk_factor=7.0, trust="medium"),
                content_rules=ContentRulesSpec(max_output_tokens=400, tone="neutral"),
                custom=CustomSpec(text="The assistant must never provide diagnosis or confirm treatment plans.")
            )
        )
        resp = client.generate_guardrails(req)
        print(resp.guardrails)
    """

    _BACKEND_URL = "https://aiguard-gc-8ca54e85-ms-1-244053109441.us-west2.run.app"
    _ENDPOINT = "/guardrails/generate"

    def __init__(self, headers: Optional[Dict[str, str]] = None) -> None:
        """
        Initialize the MarsGuardClient.

        Args:
            headers (Optional[Dict[str, str]]): Additional headers to include in requests.
        """
        self.base_url = self._BACKEND_URL
        self.headers = headers or {"Content-Type": "application/json", "Accept": "application/json"}

    def generate_guardrails(
        self,
        request: GenerateGuardrailsRequest
    ) -> DualGuardrailsResponse:
        """
        Call the /guardrails/generate endpoint with the new enforced schema.

        Args:
            request (GenerateGuardrailsRequest): The request payload (validated/enforced).

        Returns:
            DualGuardrailsResponse: The parsed response from the backend.

        Raises:
            MarsGuardValidationError: If the request or response schema is invalid.
            MarsGuardAPIError: For API errors (non-2xx responses).
            MarsGuardNetworkError: For network/connection errors.

        API Documentation:
            - 200: Returns DualGuardrailsResponse with the generated guardrails.
            - 400: Raises MarsGuardAPIError for invalid input (schema or data error).
            - 401/403: Raises MarsGuardAPIError for authentication/authorization errors.
            - 500: Raises MarsGuardAPIError for backend/server errors.

        Example:
            >>> from marsguard.schemas import AppModel, ModelSpec, AudienceSpec, ContentRulesSpec, CustomSpec, ProjectSpec, GenerateGuardrailsRequest
            >>> from marsguard.sdk import MarsGuardClient
            >>> client = MarsGuardClient()
            >>> req = GenerateGuardrailsRequest(
            ...     app=AppModel(name="Patient Support Assistant", context="A customer-facing chatbot for healthcare appointment booking."),
            ...     domain="healthcare",
            ...     model=ModelSpec(provider="openai", name="gpt-4o"),
            ...     project_spec=ProjectSpec(
            ...         relaxation_factor=0.1,
            ...         audience=AudienceSpec(age_factor=30, risk_factor=7.0, trust="medium"),
            ...         content_rules=ContentRulesSpec(max_output_tokens=400, tone="neutral"),
            ...         custom=CustomSpec(text="The assistant must never provide diagnosis or confirm treatment plans.")
            ...     )
            ... )
            >>> resp = client.generate_guardrails(req)
            >>> print(resp.guardrails)
        """
        from marsguard.exceptions import (
            MarsGuardValidationError,
            MarsGuardAPIError,
            MarsGuardNetworkError,
        )
        if not isinstance(request, GenerateGuardrailsRequest):
            try:
                request = GenerateGuardrailsRequest.model_validate(request)
            except Exception as e:
                raise MarsGuardValidationError(f"Invalid request schema: {e}") from e
        url = f"{self.base_url}{self._ENDPOINT}"
        try:
            # Ensure the request is serialized in the nested format as required
            payload = request.model_dump(by_alias=True, exclude_none=True)
            resp = requests.post(
                url,
                json=payload,
                headers=self.headers,
            )
            if not resp.ok:
                raise MarsGuardAPIError(
                    status_code=resp.status_code,
                    message=resp.reason,
                    response_text=resp.text,
                )
            data = resp.json()
            try:
                return DualGuardrailsResponse.model_validate(data)
            except Exception as e:
                raise MarsGuardValidationError(f"Invalid response schema: {e}") from e
        except requests.RequestException as req_err:
            raise MarsGuardNetworkError(f"Network error: {req_err}") from req_err
