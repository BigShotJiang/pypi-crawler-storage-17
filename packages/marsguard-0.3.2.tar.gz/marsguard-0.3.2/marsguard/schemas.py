"""Typed models for MARSGuard SDK (enforced schema, updated to new schema).

This module defines the Pydantic models used for request and response schemas
when interacting with the MARSGuard backend API.

Each model and field is documented for IDE hover support and user clarity.
"""

from __future__ import annotations
from typing import Any, Dict, Optional
from pydantic import BaseModel, Field

try:
    from pydantic import ConfigDict
    _PydanticV2 = True
except ImportError:
    _PydanticV2 = False

# ---------------------------------------------------------------------------- #
# Request/Response Schemas
# ---------------------------------------------------------------------------- #

class AppModel(BaseModel):
    """
    Represents an application for which guardrails are to be generated.

    Attributes:
        name (str): The name of the application.
        context (Optional[str]): Business context in place of app description.
    """
    name: str
    context: Optional[str] = Field(default=None, description="Business context in place of app description")

    if '_PydanticV2' in globals() and _PydanticV2:
        model_config = ConfigDict(populate_by_name=True, str_strip_whitespace=True)  # type: ignore
    else:
        class Config:
            anystr_strip_whitespace = True
            allow_population_by_field_name = True

class ModelSpec(BaseModel):
    """
    Model specification for the LLM provider and model name.

    Attributes:
        provider (Optional[str]): The name of the LLM provider (default: 'openai').
        name (str): The name or identifier of the model to use.
    """
    provider: Optional[str] = "openai"
    name: str

    if '_PydanticV2' in globals() and _PydanticV2:
        model_config = ConfigDict(populate_by_name=True, str_strip_whitespace=True)  # type: ignore
    else:
        class Config:
            anystr_strip_whitespace = True
            allow_population_by_field_name = True

class AudienceSpec(BaseModel):
    """
    Strongly-typed audience specification for the project.

    Attributes:
        age_factor (Optional[int]): Target audience age (years).
        risk_factor (Optional[float]): 0..10; higher means stricter safety.
        trust (Optional[str]): Audience trust: low|medium|high.
    """
    age_factor: Optional[int] = Field(default=18, description="Target audience age (years)")
    risk_factor: Optional[float] = Field(default=5.0, description="0..10; higher means stricter safety")
    trust: Optional[str] = Field(default="low", description="Audience trust: low|medium|high")

    if '_PydanticV2' in globals() and _PydanticV2:
        model_config = ConfigDict(populate_by_name=True, str_strip_whitespace=True)  # type: ignore
    else:
        class Config:
            anystr_strip_whitespace = True
            allow_population_by_field_name = True

class ContentRulesSpec(BaseModel):
    """
    Content rules specification for the project.

    Attributes:
        max_output_tokens (Optional[int]): Maximum tokens per response.
        tone (Optional[str]): Response tone, e.g., neutral|formal|friendly.
    """
    max_output_tokens: Optional[int] = Field(default=400, description="Maximum tokens per response")
    tone: Optional[str] = Field(default="neutral", description="Response tone, e.g., neutral|formal|friendly")

    if '_PydanticV2' in globals() and _PydanticV2:
        model_config = ConfigDict(populate_by_name=True, str_strip_whitespace=True)  # type: ignore
    else:
        class Config:
            anystr_strip_whitespace = True
            allow_population_by_field_name = True

class CustomSpec(BaseModel):
    """
    Custom organizational policy or rules.

    Attributes:
        text (Optional[str]): Free-text organizational policy or custom rules.
    """
    text: Optional[str] = Field(default=None, description="Free-text organizational policy or custom rules")

    if '_PydanticV2' in globals() and _PydanticV2:
        model_config = ConfigDict(populate_by_name=True, str_strip_whitespace=True)  # type: ignore
    else:
        class Config:
            anystr_strip_whitespace = True
            allow_population_by_field_name = True

class ProjectSpec(BaseModel):
    """
    Project specification for guardrails generation.

    Attributes:
        relaxation_factor (Optional[float]): 0..1 strictness; 1=stricter, 0=looser.
        audience (Optional[AudienceSpec]): Audience specification.
        content_rules (Optional[ContentRulesSpec]): Content rules specification.
        custom (Optional[CustomSpec]): Custom organizational policy or rules.
    """
    relaxation_factor: Optional[float] = Field(default=0.5, description="0..1 strictness; 1=stricter, 0=looser")
    audience: Optional[AudienceSpec] = None
    content_rules: Optional[ContentRulesSpec] = None
    custom: Optional[CustomSpec] = None

    if '_PydanticV2' in globals() and _PydanticV2:
        model_config = ConfigDict(populate_by_name=True, str_strip_whitespace=True, extra="ignore")  # type: ignore
    else:
        class Config:
            anystr_strip_whitespace = True
            allow_population_by_field_name = True
            extra = "ignore"

class GenerateGuardrailsRequest(BaseModel):
    """
    Request schema for the /guardrails/generate endpoint.

    Attributes:
        app (AppModel): The application details.
        domain (str): The domain or industry (e.g., 'insurance', 'healthcare').
        model (ModelSpec): Model specification.
        project_spec (Optional[ProjectSpec]): Optional project-specific configuration.
    """
    app: AppModel
    domain: str = Field(default="insurance", description="Domain e.g., healthcare, insurance, finance, ecommerce, hr, retail, general")
    model: ModelSpec
    project_spec: Optional[ProjectSpec] = None

    if '_PydanticV2' in globals() and _PydanticV2:
        model_config = ConfigDict(populate_by_name=True, str_strip_whitespace=True, extra="ignore")  # type: ignore
    else:
        class Config:
            anystr_strip_whitespace = True
            allow_population_by_field_name = True
            extra = "ignore"

class DualGuardrailsResponse(BaseModel):
    """
    Response schema for the /guardrails/generate endpoint.

    Attributes:
        guardrails (Dict[str, Any]): The summarized/sanitized guardrails.
        expanded_guardrails (Optional[Dict[str, Any]]): The actual/expanded (raw worker-based) guardrails.
    """
    guardrails: Dict[str, Any]
    expanded_guardrails: Optional[Dict[str, Any]] = None

__all__ = [
    "AppModel",
    "ModelSpec",
    "AudienceSpec",
    "ContentRulesSpec",
    "CustomSpec",
    "ProjectSpec",
    "GenerateGuardrailsRequest",
    "DualGuardrailsResponse",
]
