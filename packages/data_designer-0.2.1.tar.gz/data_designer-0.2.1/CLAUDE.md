# In ./CLAUDE.md

@AGENTS.md
