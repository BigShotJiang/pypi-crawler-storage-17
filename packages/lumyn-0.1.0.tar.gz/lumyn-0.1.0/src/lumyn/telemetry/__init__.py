"""Observability helpers (structured logs + optional tracing)."""
