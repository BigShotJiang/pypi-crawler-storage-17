# SPDX-FileCopyrightText: 2023-present MTS PJSC
# SPDX-License-Identifier: Apache-2.0

from fastapi import FastAPI

from syncmaster.server.middlewares.cors import apply_cors_middleware
from syncmaster.server.middlewares.monitoring.metrics import (
    apply_monitoring_metrics_middleware,
)
from syncmaster.server.middlewares.openapi import apply_openapi_middleware
from syncmaster.server.middlewares.request_id import apply_request_id_middleware
from syncmaster.server.middlewares.static_files import apply_static_files
from syncmaster.server.settings import ServerAppSettings as Settings


def apply_middlewares(
    application: FastAPI,
    settings: Settings,
) -> FastAPI:
    """Add middlewares to the application."""

    apply_cors_middleware(application, settings.server.cors)
    apply_monitoring_metrics_middleware(application, settings.server.monitoring)
    apply_request_id_middleware(application, settings.server.request_id)
    apply_openapi_middleware(application, settings.server.openapi)
    apply_static_files(application, settings.server.static_files)

    return application
