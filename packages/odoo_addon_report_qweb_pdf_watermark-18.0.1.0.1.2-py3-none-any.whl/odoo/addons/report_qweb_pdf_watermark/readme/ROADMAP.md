This module depends on support for transparent backgrounds in
Wkhtmltopdf, which has been flaky in the past. This module has been
reported to work with Wkhtmltopdf 0.12.6.
