"""
The __init__ docstr for shapes.ioports module.

.. module:: shapes.ioports

"""

#__all__ = ['iogro']

#import iogro
