# # ===========================================================
# # ⚙️ NeuraPython_ML — Unified Scikit-learn Wrapper
# # Author: Ibrahim Shahid
# # ===========================================================

# import numpy as np
# import pandas as pd
# import joblib

# from sklearn import (
#     datasets, preprocessing, model_selection, metrics,
#     linear_model, tree, neighbors, svm, ensemble, cluster,
#     decomposition
# )

# class NeuraPython_ML:
#     def __init__(self):
#         print("🧠 NeuraPython_ML initialized ")
#         self.models = {}
#         self.scaler = None
#         self.encoder = None

# # -----------------------------------------------------------
# # 📥 DATASET LOADING
# # -----------------------------------------------------------
#     def load_builtin_dataset(self, name="iris"):
#         name = name.lower()
#         if name == "iris": data = datasets.load_iris()
#         elif name == "digits": data = datasets.load_digits()
#         elif name == "wine": data = datasets.load_wine()
#         elif name == "breast_cancer": data = datasets.load_breast_cancer()
#         else: raise ValueError("❌ Unknown dataset name.")
#         return pd.DataFrame(data.data, columns=data.feature_names), data.target

# # -----------------------------------------------------------
# # 🔢 DATA PREPROCESSING
# # -----------------------------------------------------------
#     def normalize(self, X):
#         self.scaler = preprocessing.Normalizer()
#         return self.scaler.fit_transform(X)

#     def standardize(self, X):
#         self.scaler = preprocessing.StandardScaler()
#         return self.scaler.fit_transform(X)

#     def minmax_scale(self, X):
#         self.scaler = preprocessing.MinMaxScaler()
#         return self.scaler.fit_transform(X)

#     def encode_labels(self, y):
#         self.encoder = preprocessing.LabelEncoder()
#         return self.encoder.fit_transform(y)

#     def one_hot_encode(self, X):
#         return preprocessing.OneHotEncoder().fit_transform(X).toarray()

# # -----------------------------------------------------------
# # 📊 TRAIN/TEST SPLIT
# # -----------------------------------------------------------
#     def split(self, X, y, test_size=0.2, random_state=42):
#         return model_selection.train_test_split(X, y, test_size=test_size, random_state=random_state)

# # -----------------------------------------------------------
# # 🤖 MODEL CREATION (Unified Interface)
# # -----------------------------------------------------------
#     def create_model(self, model_name, **kwargs):
#         name = model_name.lower()
#         if name == "linear_regression": model = linear_model.LinearRegression(**kwargs)
#         elif name == "logistic_regression": model = linear_model.LogisticRegression(**kwargs)
#         elif name == "decision_tree": model = tree.DecisionTreeClassifier(**kwargs)
#         elif name == "random_forest": model = ensemble.RandomForestClassifier(**kwargs)
#         elif name == "svm": model = svm.SVC(**kwargs)
#         elif name == "knn": model = neighbors.KNeighborsClassifier(**kwargs)
#         elif name == "gradient_boosting": model = ensemble.GradientBoostingClassifier(**kwargs)
#         elif name == "naive_bayes": 
#             from sklearn.naive_bayes import GaussianNB
#             model = GaussianNB(**kwargs)
#         elif name == "kmeans": model = cluster.KMeans(**kwargs)
#         elif name == "pca": model = decomposition.PCA(**kwargs)
#         else:
#             raise ValueError(f"❌ Unsupported model: {model_name}")
        
#         self.models[model_name] = model
#         print(f"✅ Model '{model_name}' created.")
#         return model

# # -----------------------------------------------------------
# # 🧩 MODEL TRAINING & PREDICTION
# # -----------------------------------------------------------
#     def train(self, model_name, X_train, y_train):
#         model = self.models.get(model_name)
#         if model is None:
#             raise ValueError(f"❌ Model '{model_name}' not found.")
#         model.fit(X_train, y_train)
#         print(f"🚀 Model '{model_name}' trained successfully.")
#         return model

#     def predict(self, model_name, X_test):
#         model = self.models.get(model_name)
#         if model is None:
#             raise ValueError(f"❌ Model '{model_name}' not found.")
#         return model.predict(X_test)

# # -----------------------------------------------------------
# # 📈 MODEL EVALUATION
# # -----------------------------------------------------------
#     def evaluate(self, y_true, y_pred):
#         return {
#             "accuracy": metrics.accuracy_score(y_true, y_pred),
#             "precision": metrics.precision_score(y_true, y_pred, average='weighted', zero_division=0),
#             "recall": metrics.recall_score(y_true, y_pred, average='weighted', zero_division=0),
#             "f1_score": metrics.f1_score(y_true, y_pred, average='weighted', zero_division=0)
#         }

#     def confusion_matrix(self, y_true, y_pred):
#         return metrics.confusion_matrix(y_true, y_pred)

#     def classification_report(self, y_true, y_pred):
#         return metrics.classification_report(y_true, y_pred)

# # -----------------------------------------------------------
# # 🧮 DIMENSIONALITY REDUCTION
# # -----------------------------------------------------------
#     def apply_pca(self, X, n_components=2):
#         pca = decomposition.PCA(n_components=n_components)
#         return pca.fit_transform(X)

# # -----------------------------------------------------------
# # 💾 MODEL SAVING & LOADING
# # -----------------------------------------------------------
#     def save_model(self, model_name, path):
#         model = self.models.get(model_name)
#         if model is None:
#             raise ValueError(f"❌ Model '{model_name}' not found.")
#         joblib.dump(model, path)
#         print(f"💾 Model '{model_name}' saved at {path}")

#     def load_model(self, path, model_name="loaded_model"):
#         model = joblib.load(path)
#         self.models[model_name] = model
#         print(f"📂 Model '{model_name}' loaded from {path}")
#         return model

# # -----------------------------------------------------------
# # 🧠 CROSS VALIDATION & GRID SEARCH
# # -----------------------------------------------------------
#     def cross_validate(self, model, X, y, cv=5):
#         scores = model_selection.cross_val_score(model, X, y, cv=cv)
#         return {"mean": np.mean(scores), "scores": scores}

#     def grid_search(self, model, params, X, y, cv=5):
#         search = model_selection.GridSearchCV(model, params, cv=cv)
#         search.fit(X, y)
#         return search.best_estimator_, search.best_params_, search.best_score_

# # -----------------------------------------------------------
# # 🔍 CLUSTERING UTILITIES
# # -----------------------------------------------------------
#     def kmeans_cluster(self, X, n_clusters=3):
#         model = cluster.KMeans(n_clusters=n_clusters)
#         y_pred = model.fit_predict(X)
#         return model, y_pred

# # -----------------------------------------------------------
# # 🧩 FEATURE SELECTION
# # -----------------------------------------------------------
#     def feature_importances(self, model_name, feature_names=None):
#         model = self.models.get(model_name)
#         if model is None:
#             raise ValueError(f"❌ Model '{model_name}' not found.")
#         if hasattr(model, "feature_importances_"):
#             imp = model.feature_importances_
#             if feature_names is not None:
#                 return dict(zip(feature_names, imp))
#             return imp
#         else:
#             raise AttributeError("⚠️ Model has no feature_importances_ attribute.")

# # -----------------------------------------------------------
# # 🧾 SUMMARY
# # -----------------------------------------------------------
#     def summary(self):
#         print("=== NeuraPython_ML Models ===")
#         for name, model in self.models.items():
#             print(f"• {name}: {type(model).__name__}")
# ===========================================================
# ⚙️ NeuraPython_ML — Enhanced Unified Scikit-learn Wrapper
# Author: Ibrahim Shahid
# ===========================================================

import numpy as np
import pandas as pd
import joblib
from typing import Optional, Union, Tuple, Dict, List

from sklearn import (
    datasets, preprocessing, model_selection, metrics,
    linear_model, tree, neighbors, svm, ensemble, cluster,
    decomposition
)
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer

class NeuraPython_ML:
    def __init__(self, verbose: bool = True):
        """
        Initialize NeuraPython_ML module.
        """
        self.models: Dict[str, object] = {}
        self.scaler: Optional[preprocessing.StandardScaler] = None
        self.encoder: Optional[preprocessing.LabelEncoder] = None
        self.verbose = verbose

    # ===========================================================
    # 📥 DATASET LOADING
    # ===========================================================
    def load_builtin_dataset(self, name: str = "iris") -> Tuple[pd.DataFrame, np.ndarray]:
        """Load common sklearn datasets as DataFrame and target array."""
        name = name.lower()
        if name == "iris": data = datasets.load_iris()
        elif name == "digits": data = datasets.load_digits()
        elif name == "wine": data = datasets.load_wine()
        elif name == "breast_cancer": data = datasets.load_breast_cancer()
        else: raise ValueError("❌ Unknown dataset name.")
        return pd.DataFrame(data.data, columns=data.feature_names), data.target

    # ===========================================================
    # 🔢 DATA PREPROCESSING
    # ===========================================================
    def auto_preprocess(self, X: pd.DataFrame, fit: bool = True) -> Union[ColumnTransformer, np.ndarray]:
        """
        Automatically create and optionally fit/transform preprocessor for numeric and categorical data.
        Returns fitted transformed array if fit=True, else returns preprocessor object.
        """
        numeric_features = X.select_dtypes(include=['int64', 'float64']).columns.tolist()
        categorical_features = X.select_dtypes(include=['object', 'category']).columns.tolist()

        numeric_transformer = preprocessing.StandardScaler()
        categorical_transformer = preprocessing.OneHotEncoder(handle_unknown='ignore', sparse=False)

        preprocessor = ColumnTransformer(
            transformers=[
                ('num', numeric_transformer, numeric_features),
                ('cat', categorical_transformer, categorical_features)
            ]
        )
        if fit:
            return preprocessor.fit_transform(X)
        return preprocessor

    def normalize(self, X: np.ndarray) -> np.ndarray:
        self.scaler = preprocessing.Normalizer()
        return self.scaler.fit_transform(X)

    def standardize(self, X: np.ndarray) -> np.ndarray:
        self.scaler = preprocessing.StandardScaler()
        return self.scaler.fit_transform(X)

    def minmax_scale(self, X: np.ndarray) -> np.ndarray:
        self.scaler = preprocessing.MinMaxScaler()
        return self.scaler.fit_transform(X)

    def encode_labels(self, y: np.ndarray) -> np.ndarray:
        self.encoder = preprocessing.LabelEncoder()
        return self.encoder.fit_transform(y)

    def one_hot_encode(self, X: np.ndarray, sparse: bool = False) -> np.ndarray:
        return preprocessing.OneHotEncoder(sparse=sparse, handle_unknown='ignore').fit_transform(X)

    # ===========================================================
    # 📊 TRAIN/TEST SPLIT
    # ===========================================================
    def split(self, X: np.ndarray, y: np.ndarray, test_size: float = 0.2,
              stratify: Optional[np.ndarray] = None, random_state: int = 42
             ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Train/test split with automatic stratification for classification tasks.
        """
        if stratify is None:
            # Auto-stratify if classification
            stratify = y if len(np.unique(y)) < len(y) / 2 else None
        return model_selection.train_test_split(X, y, test_size=test_size, stratify=stratify, random_state=random_state)

    # ===========================================================
    # 🤖 MODEL CREATION
    # ===========================================================
    def create_model(self, model_name: str, **kwargs) -> object:
        """
        Create and store a model in self.models.
        """
        name = model_name.lower()
        if name == "linear_regression": model = linear_model.LinearRegression(**kwargs)
        elif name == "logistic_regression": model = linear_model.LogisticRegression(**kwargs)
        elif name == "decision_tree": model = tree.DecisionTreeClassifier(**kwargs)
        elif name == "random_forest": model = ensemble.RandomForestClassifier(**kwargs)
        elif name == "svm": model = svm.SVC(**kwargs)
        elif name == "knn": model = neighbors.KNeighborsClassifier(**kwargs)
        elif name == "gradient_boosting": model = ensemble.GradientBoostingClassifier(**kwargs)
        elif name == "naive_bayes": 
            from sklearn.naive_bayes import GaussianNB
            model = GaussianNB(**kwargs)
        elif name == "kmeans": model = cluster.KMeans(**kwargs)
        elif name == "pca": model = decomposition.PCA(**kwargs)
        else:
            raise ValueError(f"❌ Unsupported model: {model_name}")
        
        self.models[model_name] = model
        if self.verbose: print(f"✅ Model '{model_name}' created.")
        return model

    # ===========================================================
    # 🧩 MODEL TRAINING & PREDICTION
    # ===========================================================
    def train(self, model_name: str, X_train: np.ndarray, y_train: np.ndarray) -> object:
        model = self.models.get(model_name)
        if model is None: raise ValueError(f"❌ Model '{model_name}' not found.")
        model.fit(X_train, y_train)
        if self.verbose: print(f"🚀 Model '{model_name}' trained successfully.")
        return model

    def predict(self, model_name: str, X_test: np.ndarray) -> np.ndarray:
        model = self.models.get(model_name)
        if model is None: raise ValueError(f"❌ Model '{model_name}' not found.")
        return model.predict(X_test)

    # ===========================================================
    # 📈 MODEL EVALUATION
    # ===========================================================
    def evaluate_classification(self, y_true: np.ndarray, y_pred: np.ndarray) -> dict:
        return {
            "accuracy": metrics.accuracy_score(y_true, y_pred),
            "precision": metrics.precision_score(y_true, y_pred, average='weighted', zero_division=0),
            "recall": metrics.recall_score(y_true, y_pred, average='weighted', zero_division=0),
            "f1_score": metrics.f1_score(y_true, y_pred, average='weighted', zero_division=0)
        }

    def evaluate_regression(self, y_true: np.ndarray, y_pred: np.ndarray) -> dict:
        return {
            "mse": metrics.mean_squared_error(y_true, y_pred),
            "rmse": np.sqrt(metrics.mean_squared_error(y_true, y_pred)),
            "r2": metrics.r2_score(y_true, y_pred)
        }

    def confusion_matrix(self, y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
        return metrics.confusion_matrix(y_true, y_pred)

    def classification_report(self, y_true: np.ndarray, y_pred: np.ndarray) -> str:
        return metrics.classification_report(y_true, y_pred)

    # ===========================================================
    # 🧮 DIMENSIONALITY REDUCTION
    # ===========================================================
    def apply_pca(self, X: np.ndarray, n_components: int = 2) -> np.ndarray:
        pca = decomposition.PCA(n_components=n_components)
        return pca.fit_transform(X)

    # ===========================================================
    # 💾 MODEL SAVING & LOADING
    # ===========================================================
    def save_model(self, model_name: str, path: str) -> None:
        model = self.models.get(model_name)
        if model is None: raise ValueError(f"❌ Model '{model_name}' not found.")
        joblib.dump(model, path)
        if self.verbose: print(f"💾 Model '{model_name}' saved at {path}")

    def load_model(self, path: str, model_name: str = "loaded_model") -> object:
        model = joblib.load(path)
        self.models[model_name] = model
        if self.verbose: print(f"📂 Model '{model_name}' loaded from {path}")
        return model

    # ===========================================================
    # 🧠 CROSS VALIDATION & HYPERPARAMETER SEARCH
    # ===========================================================
    def cross_validate(self, model: Union[str, object], X: np.ndarray, y: np.ndarray, cv: int = 5, scoring: Optional[str] = None) -> dict:
        if isinstance(model, str):
            model = self.models.get(model)
            if model is None: raise ValueError(f"❌ Model '{model}' not found.")
        scores = model_selection.cross_val_score(model, X, y, cv=cv, scoring=scoring)
        return {"mean": np.mean(scores), "scores": scores}

    def grid_search(self, model: Union[str, object], params: dict, X: np.ndarray, y: np.ndarray, cv: int = 5, scoring: Optional[str] = None) -> Tuple[object, dict, float]:
        if isinstance(model, str):
            model = self.models.get(model)
            if model is None: raise ValueError(f"❌ Model '{model}' not found.")
        search = model_selection.GridSearchCV(model, params, cv=cv, scoring=scoring)
        search.fit(X, y)
        return search.best_estimator_, search.best_params_, search.best_score_

    def randomized_search(self, model: Union[str, object], params: dict, X: np.ndarray, y: np.ndarray, cv: int = 5, n_iter: int = 20, scoring: Optional[str] = None, random_state: int = 42) -> Tuple[object, dict, float]:
        if isinstance(model, str):
            model = self.models.get(model)
            if model is None: raise ValueError(f"❌ Model '{model}' not found.")
        search = model_selection.RandomizedSearchCV(model, params, cv=cv, n_iter=n_iter, scoring=scoring, random_state=random_state)
        search.fit(X, y)
        return search.best_estimator_, search.best_params_, search.best_score_

    # ===========================================================
    # 🔍 CLUSTERING UTILITIES
    # ===========================================================
    def kmeans_cluster(self, X: np.ndarray, n_clusters: int = 3, model_name: Optional[str] = None) -> Tuple[object, np.ndarray]:
        model = cluster.KMeans(n_clusters=n_clusters)
        y_pred = model.fit_predict(X)
        if model_name:
            self.models[model_name] = model
        return model, y_pred

    # ===========================================================
    # 🧩 FEATURE SELECTION
    # ===========================================================
    def feature_importances(self, model_name: str, feature_names: Optional[List[str]] = None) -> Union[np.ndarray, dict]:
        model = self.models.get(model_name)
        if model is None: raise ValueError(f"❌ Model '{model_name}' not found.")
        if hasattr(model, "feature_importances_"):
            imp = model.feature_importances_
        elif hasattr(model, "coef_"):
            imp = np.abs(model.coef_).flatten()
        else:
            raise AttributeError("⚠️ Model has no feature_importances_ or coef_ attribute.")
        if feature_names:
            return dict(zip(feature_names, imp))
        return imp

    # ===========================================================
    # 🧾 SUMMARY
    # ===========================================================
    def summary(self) -> None:
        print("=== NeuraPython_ML Models ===")
        for name, model in self.models.items():
            print(f"• {name}: {type(model).__name__}")
