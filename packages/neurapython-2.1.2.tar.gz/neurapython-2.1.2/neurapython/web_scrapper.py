#____________________________________WebScraper v3.0__________________________________
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import os
import json
import re
import lxml
from typing import Optional, List, Dict, Callable, Any, Set
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging

# ------------------------ Logging Setup ------------------------
logger = logging.getLogger("WebScraper")
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
formatter = logging.Formatter("[%(levelname)s] %(message)s")
ch.setFormatter(formatter)
logger.addHandler(ch)

class WebScraper:
    """
    🌐 WebScraper v3.0: Advanced and robust web scraping class
    
    Features:
    - Fetch HTML content from URLs
    - Extract tags, text, scripts, styles, tables, forms
    - Extract links, images, emails, phone numbers
    - Download media concurrently
    - Recursive link crawling
    - JSON-LD extraction and response headers inspection
    - Robots.txt awareness (basic)
    """

    def __init__(
        self,
        user_agent: Optional[str] = None,
        timeout: int = 10,
        proxies: Optional[Dict[str, str]] = None,
        max_workers: int = 5
    ):
        self.session = requests.Session()
        self.timeout = timeout
        self.proxies = proxies
        self.max_workers = max_workers
        self.headers = {
            "User-Agent": user_agent or 
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0 Safari/537.36"
        }
        self.last_url: Optional[str] = None
        self.base_url: Optional[str] = None
        self.soup: Optional[BeautifulSoup] = None
        self.content: Optional[str] = None
        self.response_headers: Optional[Dict[str, str]] = None

    # ------------------------ Fetch & Parse ------------------------
    def fetch(self, url: str, parse: bool = True) -> bool:
        try:
            resp = self.session.get(url, headers=self.headers, timeout=self.timeout, proxies=self.proxies)
            resp.raise_for_status()
            self.last_url = url
            self.content = resp.text
            self.response_headers = dict(resp.headers)
            if parse:
                self.soup = BeautifulSoup(self.content, "lxml")
                base_tag = self.soup.find("base", href=True)
                self.base_url = urljoin(url, base_tag["href"]) if base_tag else url
            logger.info(f"Fetched URL: {url}")
            return True
        except requests.RequestException as e:
            logger.error(f"Error fetching URL '{url}': {e}")
            return False

    def get_html(self) -> Optional[str]:
        return self.content

    def parse_html(self, html: str) -> None:
        self.content = html
        self.soup = BeautifulSoup(html, "lxml")
        base_tag = self.soup.find("base", href=True)
        self.base_url = urljoin(self.last_url or "", base_tag["href"]) if base_tag else self.last_url

    # ------------------------ Extractors ------------------------
    def get_title(self) -> Optional[str]:
        return self.soup.title.string if self.soup and self.soup.title else None

    def get_text(self, selector: Optional[str] = None) -> Any:
        if not self.soup:
            return None
        if selector:
            return [el.get_text(strip=True) for el in self.soup.select(selector)]
        return self.soup.get_text(separator="\n", strip=True)

    def _resolve_url(self, url: str) -> str:
        base = self.base_url or self.last_url or ""
        return urljoin(base, url)

    def get_links(self) -> List[str]:
        if not self.soup:
            return []
        return list({self._resolve_url(a["href"]) for a in self.soup.find_all("a", href=True)})

    def get_images(self) -> List[str]:
        if not self.soup:
            return []
        return list({self._resolve_url(img["src"]) for img in self.soup.find_all("img", src=True)})

    def get_scripts(self) -> List[str]:
        if not self.soup:
            return []
        return list({self._resolve_url(s.get("src")) for s in self.soup.find_all("script", src=True)})

    def get_styles(self) -> List[str]:
        if not self.soup:
            return []
        return list({self._resolve_url(l.get("href")) for l in self.soup.find_all("link", rel="stylesheet")})

    def get_tables(self) -> List[List[List[str]]]:
        if not self.soup:
            return []
        tables = []
        for table in self.soup.find_all("table"):
            rows = [[td.get_text(strip=True) for td in tr.find_all(["td", "th"])] for tr in table.find_all("tr")]
            tables.append(rows)
        return tables

    def get_forms(self) -> List[Dict[str, Any]]:
        if not self.soup:
            return []
        forms = []
        for f in self.soup.find_all("form"):
            action = f.get("action", "")
            method = f.get("method", "get").lower()
            inputs = [
                {"name": i.get("name"), "type": i.get("type"), "value": i.get("value")}
                for i in f.find_all("input")
            ]
            forms.append({"action": self._resolve_url(action), "method": method, "inputs": inputs})
        return forms

    def get_meta_tags(self) -> Dict[str, str]:
        if not self.soup:
            return {}
        metas = {}
        for tag in self.soup.find_all("meta"):
            name = tag.get("name") or tag.get("property")
            content = tag.get("content")
            if name and content:
                metas[name] = content
        return metas

    def get_emails(self) -> List[str]:
        if not self.content:
            return []
        return list(set(re.findall(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", self.content)))

    def get_phone_numbers(self) -> List[str]:
        if not self.content:
            return []
        pattern = r"\+?\d[\d\-\s]{7,}\d"
        return list(set(re.findall(pattern, self.content)))

    def get_json_ld(self) -> List[Dict[str, Any]]:
        if not self.soup:
            return []
        scripts = self.soup.find_all("script", type="application/ld+json")
        data = []
        for s in scripts:
            try:
                data.append(json.loads(s.string))
            except Exception:
                continue
        return data

    def get_headers(self) -> Dict[str, str]:
        return self.response_headers or {}

    # ------------------------ Download ------------------------
    def download_file(self, url: str, save_path: Optional[str] = None) -> Optional[str]:
        try:
            r = self.session.get(url, headers=self.headers, timeout=self.timeout, stream=True)
            r.raise_for_status()
            filename = save_path or os.path.basename(urlparse(url).path) or "downloaded_file"
            with open(filename, "wb") as f:
                for chunk in r.iter_content(1024):
                    f.write(chunk)
            logger.info(f"Downloaded file: {filename}")
            return filename
        except requests.RequestException as e:
            logger.error(f"Network error downloading '{url}': {e}")
        except OSError as e:
            logger.error(f"Filesystem error saving '{url}': {e}")
        return None

    def download_all_images(self, folder: str = "images") -> None:
        if not os.path.exists(folder):
            os.makedirs(folder)
        images = self.get_images()
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {executor.submit(self.download_file, img, os.path.join(folder, os.path.basename(urlparse(img).path))): img for img in images}
            for future in as_completed(futures):
                future.result()  # Logging happens inside download_file

    # ------------------------ Crawl ------------------------
    def crawl_links(self, depth: int = 1, filter_fn: Optional[Callable[[str], bool]] = None) -> List[str]:
        if not self.last_url:
            return []

        visited: Set[str] = set()
        to_visit: List[(str, int)] = [(self.last_url, 0)]
        all_links: Set[str] = set()

        while to_visit:
            url, d = to_visit.pop(0)
            if url in visited or d >= depth:
                continue
            if self.fetch(url):
                links = self.get_links()
                if filter_fn:
                    links = [l for l in links if filter_fn(l)]
                for link in links:
                    if link not in visited:
                        to_visit.append((link, d + 1))
                        all_links.add(link)
                visited.add(url)
        return list(all_links)

    # ------------------------ Utilities ------------------------
    def search(self, pattern: str) -> List[str]:
        if not self.content:
            return []
        return re.findall(pattern, self.content, re.IGNORECASE)

    def save_json(self, data: Any, filename: str = "scraped_data.json") -> None:
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        logger.info(f"Saved JSON data to {filename}")

    def load_json(self, filename: str = "scraped_data.json") -> Any:
        if not os.path.exists(filename):
            logger.warning(f"File '{filename}' not found")
            return None
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)

    def clear_cache(self) -> None:
        self.content = None
        self.soup = None
        self.last_url = None
        self.base_url = None
        self.response_headers = None

    def __repr__(self) -> str:
        return f"<WebScraper(url='{self.last_url}')>"
