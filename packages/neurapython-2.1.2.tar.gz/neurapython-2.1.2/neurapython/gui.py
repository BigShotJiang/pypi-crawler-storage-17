import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import threading
import time
from PIL import Image, ImageTk

# --------------------------------------------------------------------------
# Initialization
# --------------------------------------------------------------------------
ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")

# --------------------------------------------------------------------------
# COMPONENT WRAPPER
# --------------------------------------------------------------------------
class Component:
    """Wraps a widget and forwards .config() calls safely."""
    def __init__(self, widget):
        self.widget = widget

    def config(self, **kwargs):
        for method in ("configure", "config"):
            if hasattr(self.widget, method):
                try:
                    getattr(self.widget, method)(**kwargs)
                    break
                except Exception:
                    continue

    def bind(self, event, func):
        self.widget.bind(event, func)
        return self

# --------------------------------------------------------------------------
# CONTAINER CLASS
# --------------------------------------------------------------------------
class Container:
    """Flexible container frame supporting grid, pack, or place layouts."""
    def __init__(self, master, **style):
        bg = style.get("bg", None)
        self.frame = ctk.CTkFrame(master, fg_color=bg)
        self.children = []

    def add(self, component, row=None, column=None, pack=False, padx=6, pady=6, sticky="nsew", **kwargs):
        w = component.widget if isinstance(component, Component) else component
        if pack:
            w.pack(padx=padx, pady=pady, **kwargs)
        else:
            row = len(self.children) if row is None else row
            column = 0 if column is None else column
            w.grid(row=row, column=column, padx=padx, pady=pady, sticky=sticky, **kwargs)
            self.frame.grid_rowconfigure(row, weight=1)
            self.frame.grid_columnconfigure(column, weight=1)
        self.children.append(w)
        return w

    def pack(self, **kwargs): self.frame.pack(**kwargs)
    def grid(self, **kwargs): self.frame.grid(**kwargs)
    def place(self, **kwargs): self.frame.place(**kwargs)

# --------------------------------------------------------------------------
# FLOOD GAUGE
# --------------------------------------------------------------------------
class FloodGauge(Component):
    """Custom vertical flood-style progress gauge with optional text or gradient."""
    def __init__(self, master, width=60, height=200, max_value=100, fg="#1E90FF", bg="#f5f5f5"):
        canvas = tk.Canvas(master, width=width, height=height, bg=bg, highlightthickness=1)
        super().__init__(canvas)
        self.width = width
        self.height = height
        self.max_value = max_value
        self.value = 0
        self.fg = fg
        self.bg = bg
        self._draw()

    def _draw(self, show_text_inside=False, gradient=False):
        c = self.widget
        c.delete("all")
        fill_height = (self.value / self.max_value) * (self.height - 10)
        y1 = self.height - 5 - fill_height

        # Gradient fill
        if gradient:
            for i in range(int(fill_height)):
                color_ratio = i / fill_height
                r = int(int(self.fg[1:3],16)*(1-color_ratio) + int(self.bg[1:3],16)*color_ratio)
                g = int(int(self.fg[3:5],16)*(1-color_ratio) + int(self.bg[3:5],16)*color_ratio)
                b = int(int(self.fg[5:7],16)*(1-color_ratio) + int(self.bg[5:7],16)*color_ratio)
                color = f"#{r:02x}{g:02x}{b:02x}"
                c.create_line(5, self.height-5-i, self.width-5, self.height-5-i, fill=color)
        else:
            c.create_rectangle(5, y1, self.width-5, self.height-5, fill=self.fg, outline="")

        c.create_rectangle(5, 5, self.width-5, self.height-5, outline="#999", width=1)
        percent_text = f"{int(self.value / self.max_value * 100)}%"
        if show_text_inside:
            c.create_text(self.width/2, y1 - 10, text=percent_text, font=("Arial", 10, "bold"))
        else:
            c.create_text(self.width/2, 12, text=percent_text, font=("Arial", 9, "bold"))

    def set(self, value):
        self.value = max(0, min(self.max_value, value))
        if hasattr(self.widget, 'after'):
            self.widget.after(0, self._draw)
        else:
            self._draw()

    def increment(self, step=1):
        self.set(self.value + step)

# --------------------------------------------------------------------------
# VERTICAL SLIDER (CTk-based)
# --------------------------------------------------------------------------
class VerticalSlider(Component):
    def __init__(self, master, from_=0, to=100, value=0, **style):
        frame = ctk.CTkFrame(master)
        slider = ctk.CTkSlider(frame, from_=from_, to=to, orientation="vertical", **style)
        slider.set(value)
        slider.pack(expand=True, fill="y")
        super().__init__(slider)
        self.frame = frame

# --------------------------------------------------------------------------
# MAIN GUI CLASS
# --------------------------------------------------------------------------
class GUI:
    """Full-featured, modern GUI builder for NeuraPy with thread-safe updates and tooltips."""
    def __init__(self, title="NeuraPy GUI", size=(1000,700), appearance="System", theme="blue"):
        ctk.set_appearance_mode(appearance)
        ctk.set_default_color_theme(theme)
        self.root = ctk.CTk()
        self.root.geometry(f"{size[0]}x{size[1]}")
        self.root.title(title)
        self.global_style = {}

        # Layout frames
        self.main = ctk.CTkFrame(self.root)
        self.main.pack(fill="both", expand=True)
        self.left = ctk.CTkFrame(self.main, width=200)
        self.center = ctk.CTkFrame(self.main)
        self.right = ctk.CTkFrame(self.main, width=240)
        self.left.pack(side="left", fill="y")
        self.center.pack(side="left", fill="both", expand=True)
        self.right.pack(side="right", fill="y")

        self.containers = {
            "left": Container(self.left),
            "center": Container(self.center),
            "right": Container(self.right),
            "root": Container(self.root)
        }

    # ------------------------
    # Basic Widgets
    # ------------------------
    def button(self, text="Button", command=None, **style):
        return Component(ctk.CTkButton(self.center, text=text, command=command, **{**self.global_style, **style}))

    def label(self, text="Label", **style):
        return Component(ctk.CTkLabel(self.center, text=text, **{**self.global_style, **style}))

    def textbox(self, placeholder="", multiline=False, **style):
        widget = ctk.CTkTextbox(self.center, **style) if multiline else \
                 ctk.CTkEntry(self.center, placeholder_text=placeholder, **style)
        return Component(widget)

    def slider(self, from_=0, to=100, value=0, orientation="horizontal", command=None, **style):
        if orientation=="horizontal":
            s = ctk.CTkSlider(self.center, from_=from_, to=to, **style)
            s.set(value)
            if command: s.configure(command=command)
            return Component(s)
        else:
            return VerticalSlider(self.center, from_=from_, to=to, value=value, **style)

    def combo(self, values, default=None, **style):
        cb = ctk.CTkComboBox(self.center, values=values, **style)
        if default: cb.set(default)
        return Component(cb)

    def checkbox(self, text="Check", default=False, command=None, **style):
        var = tk.BooleanVar(value=default)
        chk = ctk.CTkCheckBox(self.center, text=text, variable=var, command=command, **style)
        chk.var = var
        return Component(chk)

    def radio(self, options, default=None, command=None, horizontal=False):
        var = tk.StringVar(value=default or options[0])
        frame = ctk.CTkFrame(self.center)
        for opt in options:
            rb = ctk.CTkRadioButton(frame, text=opt, variable=var, value=opt, command=command)
            rb.pack(side="left" if horizontal else "top", padx=4, pady=2, anchor="w")
        frame.var = var
        return Component(frame)

    def table(self, columns, height=8, **style):
        frame = ctk.CTkFrame(self.center, **style)
        tree = ttk.Treeview(frame, columns=columns, show="headings", height=height)
        vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        for c in columns:
            tree.heading(c, text=c)
            tree.column(c, anchor="center")
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        frame.tree = tree
        return Component(frame)

    def flood_gauge(self, max_value=100, **style):
        frame = ctk.CTkFrame(self.center)
        gauge = FloodGauge(frame, max_value=max_value, **style)
        gauge.widget.pack()
        return gauge

    def image_label(self, path, width=None, height=None):
        try:
            img = Image.open(path)
            if width and height: img = img.resize((width, height), Image.LANCZOS)
            tk_img = ImageTk.PhotoImage(img)
            lbl = ctk.CTkLabel(self.center, image=tk_img)
            lbl.image = tk_img
            return Component(lbl)
        except Exception as e:
            self.error("Image Load Error", str(e))
            return None

    # ------------------------
    # Dialogs & File Operations
    # ------------------------
    def alert(self, title="Alert", message="Something happened!"):
        messagebox.showinfo(title, message)

    def error(self, title="Error", message="An error occurred!"):
        messagebox.showerror(title, message)

    def ask_yes_no(self, title="Confirm", message="Are you sure?"):
        return messagebox.askyesno(title, message)

    def ask_input(self, title="Input", prompt="Enter value:"):
        return simpledialog.askstring(title, prompt)

    def open_file(self, filetypes=(("All files", "*.*"),)):
        try: return filedialog.askopenfilename(filetypes=filetypes)
        except Exception as e: self.error("File Open Error", str(e))

    def save_file(self, filetypes=(("All files", "*.*"),)):
        try: return filedialog.asksaveasfilename(filetypes=filetypes)
        except Exception as e: self.error("File Save Error", str(e))

    def select_folder(self):
        try: return filedialog.askdirectory()
        except Exception as e: self.error("Folder Select Error", str(e))

    # ------------------------
    # Utilities
    # ------------------------
    def toast(self, message, duration=2):
        popup = ctk.CTkToplevel(self.root)
        popup.overrideredirect(True)
        popup.geometry("+500+500")
        lbl = ctk.CTkLabel(popup, text=message, fg_color="#333", text_color="white", corner_radius=8)
        lbl.pack(padx=10, pady=10)
        self.root.after(duration*1000, popup.destroy)

    def tooltip(self, widget, text):
        if hasattr(widget, "_tooltip_label"):
            widget._tooltip_label.config(text=text)
            return
        tip = tk.Toplevel(widget.widget)
        tip.withdraw()
        tip.overrideredirect(True)
        label = tk.Label(tip, text=text, bg="#333", fg="white", relief="solid", borderwidth=1)
        label.pack(ipadx=4)
        widget._tooltip_label = label

        def enter(e): tip.geometry(f"+{e.x_root+10}+{e.y_root+10}"); tip.deiconify()
        def leave(e): tip.withdraw()
        widget.widget.bind("<Enter>", enter)
        widget.widget.bind("<Leave>", leave)

    def set_style(self, **style):
        self.global_style.update(style)

    # ------------------------
    # Window Controls
    # ------------------------
    def set_title(self, title): self.root.title(title)
    def resize(self, width, height): self.root.geometry(f"{width}x{height}")
    def fullscreen(self, enable=True): self.root.attributes("-fullscreen", enable)
    def close(self): self.root.destroy()

    # ------------------------
    # Event Binding
    # ------------------------
    def bind_key(self, key, func): self.root.bind(key, func)
    def bind_mouse(self, event, func): self.root.bind(event, func)
    def bind_to_widget(self, widget, event, func):
        target = widget.widget if isinstance(widget, Component) else widget
        target.bind(event, func)

    # ------------------------
    # Access & Run
    # ------------------------
    def container(self, name): return self.containers.get(name)
    def show(self): self.root.mainloop()
