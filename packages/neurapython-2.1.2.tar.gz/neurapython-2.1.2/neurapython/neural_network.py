import torch
import tensorflow as tf
import numpy as np
import random
from typing import List, Optional, Union, Callable

try:
    from torchsummary import summary as torch_summary
except ImportError:
    torch_summary = None  # Optional dependency

TensorType = Union[np.ndarray, torch.Tensor, tf.Tensor]

class NeuralNetwork:
    TORCH_ACTIVATIONS = {
        'relu': torch.nn.ReLU,
        'relu6': torch.nn.ReLU6,
        'sigmoid': torch.nn.Sigmoid,
        'tanh': torch.nn.Tanh,
        'leakyrelu': torch.nn.LeakyReLU,
        'gelu': torch.nn.GELU,
        'softmax': torch.nn.Softmax,
    }

    TORCH_LOSSES = {
        'mse': torch.nn.MSELoss,
        'crossentropy': torch.nn.CrossEntropyLoss,
    }

    TORCH_OPTIMIZERS = {
        'adam': torch.optim.Adam,
        'sgd': torch.optim.SGD,
    }

    def __init__(self, backend='torch', device: Optional[str]=None, seed: Optional[int]=42):
        self.backend = backend.lower()
        self.device = device
        self.model = None
        self.loss_fn = None
        self.optimizer = None
        self.seed = seed

        if self.backend not in ['torch', 'tf']:
            raise ValueError("Backend must be 'torch' or 'tf'")

        self._set_seed(seed)
        self._setup_device()
        self._attach_backend()

    # ------------------ Seed & Device ------------------
    def _set_seed(self, seed: Optional[int]):
        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)
            if self.backend == 'torch':
                torch.manual_seed(seed)
                if torch.cuda.is_available():
                    torch.cuda.manual_seed_all(seed)
            elif self.backend == 'tf':
                tf.random.set_seed(seed)

    def _setup_device(self):
        if self.backend == 'torch':
            if self.device is None:
                self.device = 'cuda' if torch.cuda.is_available() else 'cpu'

    # ------------------ Backend attachment ------------------
    def _attach_backend(self):
        if self.backend == 'torch':
            self.tensor_lib = torch
            self.nn = torch.nn
            self.optim = torch.optim
        else:
            self.tensor_lib = tf
            self.nn = tf.keras.layers
            self.optim = tf.keras.optimizers
            self.losses = tf.keras.losses
            self.metrics = tf.keras.metrics

    # ------------------ Tensor creation ------------------
    def tensor(self, data, dtype=None, requires_grad=False):
        if self.backend == 'torch':
            t = torch.tensor(data, dtype=dtype or torch.float32, requires_grad=requires_grad)
            return t.to(self.device)
        else:
            return tf.convert_to_tensor(data, dtype=dtype or tf.float32)

    # ------------------ Sequential model ------------------
    def Sequential(
        self,
        layers_list: List[int],
        activations: Optional[List[str]]=None,
        use_dropout: bool=False,
        dropout_rate: float=0.5,
        batch_norm: bool=False
    ):
        activations = activations or ['relu'] * (len(layers_list)-2) + ['linear']

        if self.backend == 'torch':
            seq_layers = []
            for i in range(len(layers_list)-1):
                seq_layers.append(torch.nn.Linear(layers_list[i], layers_list[i+1]))
                if batch_norm:
                    seq_layers.append(torch.nn.BatchNorm1d(layers_list[i+1]))
                act = activations[i].lower()
                if act != 'linear':
                    if act in self.TORCH_ACTIVATIONS:
                        seq_layers.append(self.TORCH_ACTIVATIONS[act]())
                    else:
                        raise ValueError(f"Unsupported activation '{activations[i]}' for PyTorch")
                if use_dropout:
                    seq_layers.append(torch.nn.Dropout(dropout_rate))
            self.model = torch.nn.Sequential(*seq_layers).to(self.device)
        else:
            self.model = tf.keras.Sequential()
            for i in range(len(layers_list)-1):
                self.model.add(tf.keras.layers.Dense(
                    layers_list[i+1],
                    input_dim=layers_list[i] if i==0 else None,
                    activation=None if activations[i]=='linear' else activations[i]
                ))
                if batch_norm:
                    self.model.add(tf.keras.layers.BatchNormalization())
                if use_dropout:
                    self.model.add(tf.keras.layers.Dropout(dropout_rate))

    # ------------------ Compile ------------------
    def compile(self, optimizer='adam', loss='mse', metrics: Optional[List[str]]=None, lr: float=0.001):
        metrics = metrics or ['accuracy']
        if self.backend == 'torch':
            if isinstance(loss, str):
                if loss.lower() in self.TORCH_LOSSES:
                    self.loss_fn = self.TORCH_LOSSES[loss.lower()]()
                else:
                    raise ValueError(f"Unsupported loss '{loss}' for PyTorch")
            else:
                self.loss_fn = loss

            if isinstance(optimizer, str):
                if optimizer.lower() in self.TORCH_OPTIMIZERS:
                    self.optimizer = self.TORCH_OPTIMIZERS[optimizer.lower()](self.model.parameters(), lr=lr)
                else:
                    raise ValueError(f"Unsupported optimizer '{optimizer}' for PyTorch")
            else:
                self.optimizer = optimizer
        else:
            opt_class = getattr(tf.keras.optimizers, optimizer.capitalize())(learning_rate=lr)
            self.model.compile(optimizer=opt_class, loss=loss, metrics=metrics)

    # ------------------ Fit ------------------
    def fit(self, X: TensorType, y: TensorType, epochs=10, batch_size: int=32, shuffle=True, callbacks: Optional[List]=None):
        if self.backend == 'torch':
            X_tensor, y_tensor = self.tensor(X), self.tensor(y)
            dataset = torch.utils.data.TensorDataset(X_tensor, y_tensor)
            loader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=shuffle)
            for epoch in range(epochs):
                epoch_loss = 0
                for xb, yb in loader:
                    self.optimizer.zero_grad()
                    preds = self.model(xb)
                    loss = self.loss_fn(preds, yb)
                    loss.backward()
                    self.optimizer.step()
                    epoch_loss += loss.item() * xb.size(0)
                print(f"[Torch] Epoch {epoch+1}/{epochs}, Loss: {epoch_loss/len(X_tensor):.4f}")
        else:
            self.model.fit(X, y, epochs=epochs, batch_size=batch_size, shuffle=shuffle, callbacks=callbacks, verbose=1)

    # ------------------ Predict ------------------
    def predict(self, X: TensorType):
        if self.backend == 'torch':
            self.model.eval()
            with torch.no_grad():
                return self.model(self.tensor(X)).cpu().numpy()
        else:
            return self.model.predict(X)

    # ------------------ Evaluate ------------------
    def evaluate(self, X: TensorType, y: TensorType, metrics: Optional[List[Callable]]=None):
        if self.backend == 'torch':
            self.model.eval()
            with torch.no_grad():
                loss = self.loss_fn(self.model(self.tensor(X)), self.tensor(y))
            results = {'loss': loss.item()}
            if metrics:
                for m in metrics:
                    results[m.__name__] = m(self.predict(X), y)
            return results
        else:
            return self.model.evaluate(X, y, verbose=1)

    # ------------------ Save / Load ------------------
    def save(self, path: str):
        if self.backend == 'torch':
            torch.save(self.model.state_dict(), path)
        else:
            self.model.save(path)

    def load(self, path: str):
        if self.backend == 'torch':
            self.model.load_state_dict(torch.load(path, map_location=self.device))
            self.model.to(self.device)
        else:
            self.model = tf.keras.models.load_model(path)

    # ------------------ Summary ------------------
    def summary(self, input_size: Optional[tuple]=None):
        if self.backend == 'torch':
            if torch_summary and input_size is not None:
                torch_summary(self.model, input_size)
            else:
                print(self.model)
        else:
            self.model.summary()

    # ------------------ Dynamic access ------------------
    def __getattr__(self, name):
        try:
            if hasattr(self.tensor_lib, name):
                return getattr(self.tensor_lib, name)
            elif self.backend == 'torch' and hasattr(torch.nn, name):
                return getattr(torch.nn, name)
            elif self.backend == 'tf':
                if hasattr(tf.keras.layers, name):
                    return getattr(tf.keras.layers, name)
                if hasattr(tf.keras.optimizers, name):
                    return getattr(tf.keras.optimizers, name)
                if hasattr(tf.keras.losses, name):
                    return getattr(tf.keras.losses, name)
        except Exception:
            pass
        raise AttributeError(f"'{self.backend}' backend has no attribute '{name}'")
