import platform
import time
import psutil
import numpy as np

# Optional imports (graceful fallback)
try:
    import sounddevice as sd
except ImportError:
    sd = None

try:
    import screen_brightness_control as sbc
except ImportError:
    sbc = None

try:
    import cv2
except ImportError:
    cv2 = None


class UniversalSensors:
    """Cross-platform physical & system sensor abstraction."""

    def __init__(self):
        self.os = platform.system()
        self.boot_time = psutil.boot_time()

    # -------------------------------------------------
    # SENSOR DISCOVERY
    # -------------------------------------------------
    def available_sensors(self):
        return {
            "sound": sd is not None,
            "brightness": sbc is not None,
            "camera": cv2 is not None,
            "battery": hasattr(psutil, "sensors_battery") and psutil.sensors_battery() is not None,
            "temperature": hasattr(psutil, "sensors_temperatures") and bool(psutil.sensors_temperatures()),
            "fans": hasattr(psutil, "sensors_fans") and bool(psutil.sensors_fans()),
        }

    # -------------------------------------------------
    # SOUND SENSOR
    # -------------------------------------------------
    def sound_level(self, duration=1, samplerate=44100):
        if sd is None:
            return None
        try:
            data = sd.rec(
                int(duration * samplerate),
                samplerate=samplerate,
                channels=1,
                dtype=np.float32
            )
            sd.wait()
            return {
                "rms": round(float(np.sqrt(np.mean(data ** 2))), 6),
                "peak": round(float(np.max(np.abs(data))), 6)
            }
        except Exception:
            return None

    # -------------------------------------------------
    # DISPLAY BRIGHTNESS
    # -------------------------------------------------
    def brightness(self):
        if sbc is None:
            return None
        try:
            values = sbc.get_brightness()
            return {"displays": len(values), "levels": values}
        except Exception:
            return None

    # -------------------------------------------------
    # TEMPERATURE SENSOR
    # -------------------------------------------------
    def temperatures(self):
        if not hasattr(psutil, "sensors_temperatures"):
            return None
        temps = psutil.sensors_temperatures()
        if not temps:
            return None
        readings = {}
        for chip, entries in temps.items():
            readings[chip] = [
                {
                    "label": e.label or chip,
                    "current": e.current,
                    "high": e.high,
                    "critical": e.critical
                }
                for e in entries
            ]
        return readings

    # -------------------------------------------------
    # FAN SPEED SENSOR
    # -------------------------------------------------
    def fan_speeds(self):
        if not hasattr(psutil, "sensors_fans"):
            return None
        fans = psutil.sensors_fans()
        if not fans:
            return None
        return {
            name: [{"label": f.label, "rpm": f.current} for f in entries]
            for name, entries in fans.items()
        }

    # -------------------------------------------------
    # BATTERY SENSOR
    # -------------------------------------------------
    def battery(self):
        if not hasattr(psutil, "sensors_battery"):
            return None
        b = psutil.sensors_battery()
        if not b:
            return None
        return {
            "percentage": b.percent,
            "plugged": b.power_plugged,
            "seconds_left": None if b.secsleft < 0 else b.secsleft
        }

    # -------------------------------------------------
    # CPU SENSOR
    # -------------------------------------------------
    def cpu(self):
        return {
            "usage_percent": psutil.cpu_percent(interval=0.5),
            "cores_logical": psutil.cpu_count(logical=True),
            "cores_physical": psutil.cpu_count(logical=False),
            "frequency_mhz": psutil.cpu_freq().current if psutil.cpu_freq() else None
        }

    # -------------------------------------------------
    # MEMORY SENSOR
    # -------------------------------------------------
    def memory(self):
        m = psutil.virtual_memory()
        return {"total": m.total, "used": m.used, "percent": m.percent}

    # -------------------------------------------------
    # DISK SENSOR
    # -------------------------------------------------
    def disk(self):
        usage = psutil.disk_usage("/")
        io = psutil.disk_io_counters()
        return {
            "total": usage.total,
            "used": usage.used,
            "percent": usage.percent,
            "read_bytes": io.read_bytes if io else None,
            "write_bytes": io.write_bytes if io else None
        }

    # -------------------------------------------------
    # NETWORK SENSOR
    # -------------------------------------------------
    def network(self):
        net = psutil.net_io_counters()
        return {"sent": net.bytes_sent, "received": net.bytes_recv}

    # -------------------------------------------------
    # CAMERA AVAILABILITY
    # -------------------------------------------------
    def camera_available(self, index=0):
        if cv2 is None:
            return False
        cap = cv2.VideoCapture(index)
        ok = cap.isOpened()
        cap.release()
        return ok

    # -------------------------------------------------
    # MOTION DETECTION
    # -------------------------------------------------
    def motion_detected(self, index=0, frames=20, threshold=250000):
        if cv2 is None:
            return None
        cap = cv2.VideoCapture(index)
        if not cap.isOpened():
            return None
        ret, prev = cap.read()
        if not ret:
            cap.release()
            return None
        for _ in range(frames):
            ret, curr = cap.read()
            if not ret:
                break
            diff = cv2.absdiff(prev, curr)
            gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
            _, thresh = cv2.threshold(gray, 25, 255, cv2.THRESH_BINARY)
            if np.sum(thresh) > threshold:
                cap.release()
                return True
            prev = curr
        cap.release()
        return False

    # -------------------------------------------------
    # SYSTEM INFO
    # -------------------------------------------------
    def system(self):
        return {
            "os": self.os,
            "hostname": platform.node(),
            "uptime_seconds": int(time.time() - self.boot_time),
            "architecture": platform.machine(),
            "python": platform.python_version()
        }
