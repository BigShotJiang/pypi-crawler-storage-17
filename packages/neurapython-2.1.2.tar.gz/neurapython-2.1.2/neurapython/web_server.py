import os
import sqlite3
import uuid
import logging
from typing import Callable, Optional, Tuple, Any, List
from flask import Flask, request, jsonify, send_file
import matplotlib.pyplot as plt
import io
import base64
from werkzeug.utils import secure_filename

class WebServer:
    """
    🌐 WebServer: Flask-based mini web server wrapper with advanced features:
    - Dynamic route registration
    - SQLite integration
    - JSON API support
    - Secure file uploads and static serving
    - Plotting API with input validation
    """

    def __init__(self, app_name: str = "WebServer"):
        self.app = Flask(app_name)
        self.db_path: Optional[str] = None
        self.registered_routes = set()
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(message)s"
        )

    # -------------------------------
    # Helper Functions
    # -------------------------------
    def _unique_route_name(self, route: str) -> str:
        base = route.strip("/").replace("/", "_") or "root"
        return f"{base}_{uuid.uuid4().hex[:6]}"

    def _db_connect(self) -> sqlite3.Connection:
        if not self.db_path:
            raise ValueError("Database path not set. Use set_database(path) first.")
        return sqlite3.connect(self.db_path)

    # -------------------------------
    # Routing
    # -------------------------------
    def route(self, route: str, methods: Optional[List[str]] = None):
        methods = methods or ["GET"]

        def decorator(func: Callable):
            endpoint_name = self._unique_route_name(route)
            self.app.route(route, endpoint=endpoint_name, methods=methods)(func)
            logging.info(f"Registered route: {route} [{methods}]")
            return func

        return decorator

    # -------------------------------
    # Error Handling
    # -------------------------------
    def error_handler(self, code: int, func: Optional[Callable] = None):
        if func:
            self.app.register_error_handler(code, func)
        else:
            @self.app.errorhandler(code)
            def default_error(e):
                return jsonify({"error": f"{code} Error"}), code

    # -------------------------------
    # Database
    # -------------------------------
    def set_database(self, path: str):
        if not path or not isinstance(path, str):
            raise ValueError("Invalid database path.")
        self.db_path = path
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        logging.info(f"Database set at {path}")

    def execute_query(self, query: str, params: Tuple = ()) -> list:
        conn = self._db_connect()
        cursor = conn.cursor()
        cursor.execute(query, params)
        conn.commit()
        result = cursor.fetchall()
        conn.close()
        return result

    # -------------------------------
    # File Uploads
    # -------------------------------
    def upload_file_route(self, route: str = "/upload", folder: str = "uploads"):
        os.makedirs(folder, exist_ok=True)

        @self.app.route(route, methods=["POST"])
        def upload():
            if 'file' not in request.files:
                return jsonify({"error": "No file part"}), 400

            file = request.files['file']
            if not file.filename:
                return jsonify({"error": "No selected file"}), 400

            safe_name = secure_filename(file.filename)
            path = os.path.join(folder, safe_name)

            if os.path.exists(path):
                return jsonify({"error": "File already exists"}), 409

            file.save(path)
            return jsonify({"success": True, "path": path})

    # -------------------------------
    # Static Files
    # -------------------------------
    def static_file_route(self, route: str = "/file/<path:filename>", folder: str = "static"):
        os.makedirs(folder, exist_ok=True)

        @self.app.route(route, methods=["GET"])
        def serve_file(filename):
            path = os.path.join(folder, filename)
            if os.path.exists(path):
                return send_file(path)
            return jsonify({"error": "File not found"}), 404

    # -------------------------------
    # Plotting API
    # -------------------------------
    def plot_vector_route(self, route: str = "/plot_vector"):
        @self.app.route(route, methods=["POST"])
        def plot_vector():
            try:
                data = request.get_json(force=True)
                vector = data.get("vector", [0, 0])
                origin = data.get("origin", [0, 0])
                color = data.get("color", "r")

                # Input validation
                if (
                    not isinstance(vector, list) or len(vector) != 2 or
                    not all(isinstance(x, (int, float)) for x in vector)
                ):
                    return jsonify({"error": "Invalid vector. Must be list of 2 numbers."}), 400

                if (
                    not isinstance(origin, list) or len(origin) != 2 or
                    not all(isinstance(x, (int, float)) for x in origin)
                ):
                    return jsonify({"error": "Invalid origin. Must be list of 2 numbers."}), 400

                fig, ax = plt.subplots()
                ax.quiver(
                    origin[0], origin[1], vector[0], vector[1],
                    angles='xy', scale_units='xy', scale=1, color=color
                )
                ax.set_xlim(-10, 10)
                ax.set_ylim(-10, 10)
                ax.grid(True)
                ax.axhline(0, color='black', linewidth=0.5)
                ax.axvline(0, color='black', linewidth=0.5)

                buf = io.BytesIO()
                plt.savefig(buf, format='png')
                buf.seek(0)
                encoded = base64.b64encode(buf.read()).decode('utf-8')
                plt.close(fig)
                return jsonify({"image_base64": encoded})
            except Exception as e:
                logging.error(f"Plotting failed: {e}")
                return jsonify({"error": "Malformed request or internal error"}), 400

    # -------------------------------
    # Health Check
    # -------------------------------
    def health_route(self, route: str = "/health"):
        @self.app.route(route)
        def health():
            return jsonify({"status": "online", "message": "Server is healthy"})

    # -------------------------------
    # Server Runner
    # -------------------------------
    def run(self, host: str = "0.0.0.0", port: int = 5200, debug: bool = True):
        logging.info(f"Server starting on {host}:{port}")
        self.app.run(host=host, port=port, debug=debug)
