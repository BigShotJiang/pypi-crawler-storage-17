# statistics_toolkit_v5.py
"""
Statistics (Hybrid Edition v5.0)
Fully refactored, robust, and advanced statistics toolkit.

Author: Ibrahim Shahid
"""

import math
from typing import Optional, Sequence, Tuple, List, Dict, Any, Union
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Optional libraries
try:
    from scipy import stats
    from scipy.stats import gaussian_kde
except Exception:
    stats = None
    gaussian_kde = None

try:
    import statsmodels.api as sm
    import statsmodels.tsa.api as tsa
    from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
except Exception:
    sm = None
    tsa = None
    plot_acf = None
    plot_pacf = None

try:
    import seaborn as sns
except Exception:
    sns = None

ArrayLike = Union[Sequence[float], np.ndarray, pd.Series]

# -------------------- Decorator --------------------
def requires_data(func):
    """Decorator to ensure self.data is set."""
    def wrapper(self, *args, **kwargs):
        if self.data is None:
            raise ValueError(f"No data set. Call `set_data()` before using `{func.__name__}`.")
        return func(self, *args, **kwargs)
    return wrapper

# -------------------- Main Class --------------------
class Statistics:
    """Advanced statistics and plotting toolkit."""

    def __init__(self, data: Optional[ArrayLike] = None, name: Optional[str] = None):
        self.name = name or 'series'
        self.data: Optional[pd.Series] = None
        if data is not None:
            self.set_data(data)

    # -------------------- Data Handling --------------------
    @staticmethod
    def _to_series(data: ArrayLike) -> pd.Series:
        if isinstance(data, pd.Series):
            return data.dropna().reset_index(drop=True)
        if isinstance(data, pd.DataFrame):
            raise ValueError("Expected 1-D data; use a column or multi-variate methods.")
        arr = np.asarray(data).flatten()
        return pd.Series(arr).replace([np.inf, -np.inf], np.nan).dropna().reset_index(drop=True)

    def set_data(self, data: ArrayLike):
        self.data = self._to_series(data)
        return self

    def as_array(self) -> np.ndarray:
        if self.data is None:
            raise ValueError("No data set")
        return self.data.to_numpy()

    # -------------------- Descriptive Stats --------------------
    @requires_data
    def mean(self) -> float:
        return float(self.data.mean())

    @requires_data
    def median(self) -> float:
        return float(self.data.median())

    @requires_data
    def mode(self) -> List[float]:
        m = self.data.mode()
        return list(m.values) if not m.empty else []

    @requires_data
    def variance(self, ddof: int = 1) -> float:
        return float(self.data.var(ddof=ddof))

    @requires_data
    def std(self, ddof: int = 1) -> float:
        return float(self.data.std(ddof=ddof))

    @requires_data
    def coefficient_of_variation(self) -> float:
        mean = self.mean()
        return float(self.std() / mean) if mean != 0 else float('nan')

    @requires_data
    def skewness(self) -> float:
        if stats:
            return float(stats.skew(self.as_array(), nan_policy='omit'))
        return float(self.data.skew())

    @requires_data
    def kurtosis(self) -> float:
        if stats:
            return float(stats.kurtosis(self.as_array(), fisher=True, nan_policy='omit'))
        return float(self.data.kurt())

    # -------------------- Outliers --------------------
    @requires_data
    def z_scores(self) -> np.ndarray:
        x = self.as_array()
        return (x - np.mean(x)) / np.std(x, ddof=1)

    @requires_data
    def outliers_zscore(self, threshold: float = 3.0) -> np.ndarray:
        zs = self.z_scores()
        return self.as_array()[np.abs(zs) > threshold]

    @requires_data
    def outliers_iqr(self, factor: float = 1.5) -> np.ndarray:
        q1, q3 = self.data.quantile([0.25, 0.75])
        iqr = q3 - q1
        return self.data[(self.data < q1 - factor * iqr) | (self.data > q3 + factor * iqr)].to_numpy()

    # -------------------- Percentiles --------------------
    @requires_data
    def percentile(self, p: float) -> float:
        return float(np.nanpercentile(self.as_array(), p))

    @requires_data
    def quantiles(self, q: Sequence[float] = (0.25, 0.5, 0.75)) -> Dict[str, float]:
        qv = np.quantile(self.as_array(), q)
        return {f'q{int(p*100)}': float(v) for p, v in zip(q, qv)}

    # -------------------- Distribution --------------------
    @requires_data
    def fit_normal(self) -> Dict[str, float]:
        x = self.as_array()
        return {'mu': float(np.mean(x)), 'sigma': float(np.std(x, ddof=1))}

    @requires_data
    def ks_test_normal(self) -> Dict[str, float]:
        if not stats:
            raise RuntimeError("scipy required for ks_test_normal")
        params = self.fit_normal()
        d, p = stats.kstest(self.as_array(), 'norm', args=(params['mu'], params['sigma']))
        return {'d_stat': float(d), 'p_value': float(p)}

    # -------------------- Regression --------------------
    @staticmethod
    def ols(x: ArrayLike, y: ArrayLike, add_constant: bool = True) -> Dict[str, Any]:
        X = np.atleast_2d(x).T if np.ndim(x) == 1 else np.asarray(x)
        Y = np.asarray(y)
        if add_constant:
            if sm:
                X = sm.add_constant(X)
            else:
                X = np.column_stack((np.ones(len(X)), X))
        beta = np.linalg.lstsq(X, Y, rcond=None)[0]
        yhat = X @ beta
        residuals = Y - yhat
        s2 = np.var(residuals, ddof=X.shape[1])
        se = np.sqrt(np.diag(s2 * np.linalg.pinv(X.T @ X)))
        return {'beta': beta, 'yhat': yhat, 'residuals': residuals, 'se': se}

    # -------------------- Time Series --------------------
    @staticmethod
    def rolling_mean(series: ArrayLike, window: int = 5, center: bool = False) -> pd.Series:
        s = pd.Series(series)
        return s.rolling(window=window, center=center).mean().reindex(s.index)

    @staticmethod
    def ewma(series: ArrayLike, span: int = 12) -> pd.Series:
        s = pd.Series(series)
        return s.ewm(span=span, adjust=False).mean().reindex(s.index)

    @staticmethod
    def acf(series: ArrayLike, nlags: int = 40) -> Tuple[np.ndarray, np.ndarray]:
        s = pd.Series(series).dropna()
        if tsa:
            vals = tsa.stattools.acf(s, nlags=nlags)
            lags = np.arange(len(vals))
            return lags, vals
        # fallback
        return np.arange(nlags+1), np.array([s.autocorr(lag=i) for i in range(nlags+1)])

    # -------------------- Spectral Analysis --------------------
    @staticmethod
    def fourier(series: ArrayLike, dt: float = 1.0) -> Dict[str, np.ndarray]:
        x = np.asarray(series)
        n = len(x)
        fft_vals = np.fft.rfft(x)
        freqs = np.fft.rfftfreq(n, d=dt)
        psd = np.abs(fft_vals)**2 / n
        return {'freqs': freqs, 'fft': fft_vals, 'psd': psd}

    # -------------------- Plotting --------------------
    @staticmethod
    def _ensure_ax(ax: Optional[plt.Axes] = None) -> Tuple[plt.Figure, plt.Axes]:
        if ax is None:
            fig, ax = plt.subplots(figsize=(8, 5))
            return fig, ax
        return ax.figure, ax

    @requires_data
    def plot_histogram(self, bins: int = 30, ax: Optional[plt.Axes] = None, kde: bool = True, **kwargs) -> plt.Axes:
        fig, ax = self._ensure_ax(ax)
        data = self.as_array()
        ax.hist(data, bins=bins, alpha=0.6, color='skyblue', edgecolor='black', **kwargs)
        if kde:
            x = np.linspace(np.min(data), np.max(data), 300)
            if gaussian_kde:
                ax.plot(x, gaussian_kde(data)(x) * len(data) * (x[1]-x[0]), color='red', lw=2)
            else:
                # fallback: normalized histogram already drawn
                pass
        ax.set_title(f'Histogram - {self.name}')
        return ax

    @requires_data
    def plot_kde(self, ax: Optional[plt.Axes] = None, **kwargs) -> plt.Axes:
        fig, ax = self._ensure_ax(ax)
        data = self.as_array()
        x = np.linspace(np.min(data), np.max(data), 300)
        if sns:
            sns.kdeplot(data, ax=ax, fill=True, **kwargs)
        elif gaussian_kde:
            ax.plot(x, gaussian_kde(data)(x), color='green', lw=2)
        else:
            counts, bins = np.histogram(data, bins=30, density=True)
            ax.bar((bins[:-1]+bins[1:])/2, counts, width=np.diff(bins), alpha=0.5)
        ax.set_title(f'KDE - {self.name}')
        return ax

    @requires_data
    def plot_box(self, ax: Optional[plt.Axes] = None, **kwargs) -> plt.Axes:
        fig, ax = self._ensure_ax(ax)
        ax.boxplot(self.as_array(), vert=True, patch_artist=True, **kwargs)
        ax.set_title(f'Boxplot - {self.name}')
        return ax

    @requires_data
    def plot_time_series(self, times: Optional[Sequence[Any]] = None, ax: Optional[plt.Axes] = None, label: Optional[str] = None) -> plt.Axes:
        fig, ax = self._ensure_ax(ax)
        x_vals = times if times else np.arange(len(self.data))
        ax.plot(x_vals, self.as_array(), marker='o', linestyle='-', label=label)
        if label: ax.legend()
        ax.set_title(f'Time Series - {self.name}')
        return ax

    @requires_data
    def plot_spectrum(self, ax: Optional[plt.Axes] = None, dt: float = 1.0) -> plt.Axes:
        sp = self.fourier(self.as_array(), dt=dt)
        fig, ax = self._ensure_ax(ax)
        ax.plot(sp['freqs'], sp['psd'], color='purple', lw=2)
        ax.set_title('Power Spectral Density')
        return ax

    def show(self):
        plt.show()
