from PIL import Image, ImageTk
import matplotlib.pyplot as plt
import pygame
from moviepy.video.io.VideoFileClip import VideoFileClip  # Updated import
import tkinter as tk
from tkinter import filedialog
import threading
import os
import platform
import warnings
import cv2

class Media:
    def __init__(self, raise_errors: bool = False, log_errors: bool = False):
        pygame.init()
        pygame.mixer.init()
        self.audio_playing = False
        self.audio_paused = False
        self.video_playing = False
        self.video_paused = False
        self.video_thread = None
        self.current_clip = None
        self.raise_errors = raise_errors
        self.log_errors = log_errors

        if platform.system() == "Darwin":
            warnings.warn("MoviePy uses Pygame backend; window focus may behave differently on macOS.")

    # -------------------------------
    # Cleanup
    # -------------------------------
    def cleanup(self):
        self.stop_audio()
        self.stop_video()
        pygame.quit()

    # -------------------------------
    # Image Display
    # -------------------------------
    def image(self, path_of_image: str, width: int = 500, height: int = 500,
              title: str = "NeuraPy Image", maintain_aspect: bool = True,
              use_matplotlib: bool = False):
        if not os.path.exists(path_of_image):
            self._handle_error(f"Image not found: {path_of_image}")
            return

        img = Image.open(path_of_image)
        if maintain_aspect:
            img.thumbnail((width, height))
        else:
            img = img.resize((width, height))

        if use_matplotlib:
            plt.imshow(img)
            plt.axis('off')
            plt.title(title)
            plt.show()
        else:
            root = tk.Tk()
            root.title(title)
            tk_img = ImageTk.PhotoImage(img)
            label = tk.Label(root, image=tk_img)
            label.pack()
            tk.Button(root, text="Close", command=root.destroy).pack()
            threading.Thread(target=root.mainloop, daemon=True).start()

    # -------------------------------
    # Audio Controls
    # -------------------------------
    def audio(self, path_of_audio: str, loop: bool = False):
        if not os.path.exists(path_of_audio):
            self._handle_error(f"Audio not found: {path_of_audio}")
            return

        def play_music():
            try:
                pygame.mixer.music.load(path_of_audio)
                pygame.mixer.music.play(-1 if loop else 0)
                self.audio_playing = True
                self.audio_paused = False
                while self.audio_playing:
                    pygame.time.Clock().tick(10)
            except Exception as e:
                self._handle_error(f"Audio Error: {e}")

        threading.Thread(target=play_music, daemon=True).start()

    def pause_audio(self):
        if self.audio_playing and not self.audio_paused:
            pygame.mixer.music.pause()
            self.audio_paused = True

    def resume_audio(self):
        if self.audio_playing and self.audio_paused:
            pygame.mixer.music.unpause()
            self.audio_paused = False

    def stop_audio(self):
        pygame.mixer.music.stop()
        self.audio_playing = False
        self.audio_paused = False

    def set_volume(self, volume: float):
        if 0.0 <= volume <= 1.0:
            pygame.mixer.music.set_volume(volume)
        else:
            self._handle_error("Volume must be between 0.0 and 1.0")

    def is_audio_playing(self) -> bool:
        return self.audio_playing and not self.audio_paused

    # -------------------------------
    # Video Playback
    # -------------------------------
    def video(self, path_of_video: str, width: int = None, height: int = 480, maintain_aspect: bool = True):
        if not os.path.exists(path_of_video):
            self._handle_error(f"Video not found: {path_of_video}")
            return

        def play_clip():
            try:
                clip = VideoFileClip(path_of_video)
                if maintain_aspect and width:
                    clip = clip.resize(width=width)
                else:
                    clip = clip.resize(height=height)
                self.current_clip = clip
                self.video_playing = True
                self.video_paused = False

                ctrl_root = tk.Tk()
                ctrl_root.title("Video Controls")

                def pause_resume():
                    self.video_paused = not self.video_paused

                def stop_video():
                    self.stop_video()
                    ctrl_root.destroy()

                tk.Button(ctrl_root, text="Pause/Resume", command=pause_resume).pack()
                tk.Button(ctrl_root, text="Stop", command=stop_video).pack()
                threading.Thread(target=ctrl_root.mainloop, daemon=True).start()

                for frame in clip.iter_frames(fps=clip.fps, with_times=False):
                    if not self.video_playing:
                        break
                    while self.video_paused:
                        pygame.time.wait(50)
                    frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
                    cv2.imshow("Video", frame_bgr)
                    if cv2.waitKey(int(1000/clip.fps)) & 0xFF == ord('q'):
                        self.stop_video()
                        break
                cv2.destroyAllWindows()
            except Exception as e:
                self._handle_error(f"Video Error: {e}")
            finally:
                self.video_playing = False
                self.video_paused = False

        self.video_thread = threading.Thread(target=play_clip, daemon=True)
        self.video_thread.start()

    def stop_video(self):
        self.video_playing = False
        self.video_paused = False
        if self.current_clip:
            try:
                self.current_clip.close()
            except Exception:
                pass
        if self.video_thread and self.video_thread.is_alive():
            self.video_thread.join()
        cv2.destroyAllWindows()

    def is_video_playing(self) -> bool:
        return self.video_playing and not self.video_paused

    # -------------------------------
    # File Picker
    # -------------------------------
    def pick_file(self, file_type: str = "all") -> str:
        root = tk.Tk()
        root.withdraw()
        file_types = {
            "image": [("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")],
            "audio": [("Audio Files", "*.mp3;*.wav;*.ogg")],
            "video": [("Video Files", "*.mp4;*.avi;*.mov;*.mkv")],
            "all": [("All Files", "*.*")]
        }
        file_path = filedialog.askopenfilename(filetypes=file_types.get(file_type, file_types["all"]))
        return file_path if file_path else ""

    # -------------------------------
    # Error Handling
    # -------------------------------
    def _handle_error(self, msg: str):
        if self.log_errors:
            with open("media_errors.log", "a") as f:
                f.write(msg + "\n")
        if self.raise_errors:
            raise RuntimeError(msg)
        else:
            print(f"[Media Error] {msg}")
