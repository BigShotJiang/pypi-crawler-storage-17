from pushikoo_getter_gh.main import GithubGetter

__all__ = ["GithubGetter"]
