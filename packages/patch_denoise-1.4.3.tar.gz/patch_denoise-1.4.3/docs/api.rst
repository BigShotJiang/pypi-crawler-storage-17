API Reference
=============

.. autosummary::
    :toctree: _autosummary
    :template: custom-module-template.rst
    :recursive:

    patch_denoise
