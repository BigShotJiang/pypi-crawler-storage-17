"""Simple data simulation for testing purposes."""
