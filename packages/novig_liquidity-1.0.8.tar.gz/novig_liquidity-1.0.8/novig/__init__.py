from .novig_base import Novig

__all__ = ["Novig"]

