"""Version information for henriqueslab-updater."""

__version__ = "1.1.3"
