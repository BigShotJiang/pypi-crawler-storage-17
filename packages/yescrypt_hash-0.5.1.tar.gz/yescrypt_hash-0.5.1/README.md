
yescrypt_hash (v0.5)
===========================

Python module for GlobalBoost's Yescrypt hashing.


Install
-------

Python >=3.8 is required as well as gcc.

    $ pip install .


Test
-------

After installation, test hash.

    $ python test.py

Credits
-------

* Module written by @mendozg https://github.com/mendozg/yescrypt-hash


