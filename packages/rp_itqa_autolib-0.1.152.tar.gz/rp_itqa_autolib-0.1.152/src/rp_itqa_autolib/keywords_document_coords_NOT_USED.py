"""
----------------------------------------------------------------------------------
 Author:  Frank Runfola
 Created: 15/23/25
----------------------------------------------------------------------------------
"""
import sys
import time

from ctypes.wintypes import tagPOINT
import random
import re
import pywinauto.keyboard
import pywinauto.mouse
import pyautogui
import pywinauto
import RPA.Windows as rpawin
import typing
import datetime
import calendar

from random import randrange
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
from time import gmtime, strftime
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows
from pywinauto import timings
from pywinauto import findbestmatch
from pywinauto.application import Application
from datetime import datetime

DELIMITER_LEN = 30
AlteraWindow = "Altera Gateway" 
_static_win = None
suspectedCancerManagedService = True

dict = {
    "TonyStark":  ["Genius", "Billionarie",  "Playboy"],  
    "SteveRogers": ["Super Soldier", "Captain America", "Avenger"],
    "BruceBanner": ["Genius", "Hulk", "Avenger"],
    "NatashaRomanoff": ["Black Widow", "Avenger"],
    "ClintBarton": ["Hawkeye", "Avenger"]
}

def Get_Altera_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if AlteraWindow in proc.name: 
            app = app.connect(process=proc.process_id).window(handle=proc.handle)
            app.click_input()
            break
    return app,proc

def Focus_Structured_Notes_Entry_Window():
    app, proc = Get_Structured_Notes_Entry()
    app.set_focus()

def Get_Structured_Notes_Entry():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if "Structured Notes Entry" in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id)
            app = app.window(handle=proc.handle)
            break
    return app,proc

def Click_Section_Item_Py(Name,X,Y):
    logger.console(f"   Click_Section_Item_Py() ...[Py]")
    
    X = int(X)
    Y = int(Y)

    logger.console(f"      (Name='{Name}'  X='{X}' Y='{Y}') ...[Py]")

    try:
        logger.console(f"      CLICK '{Name}' coords=({X},{Y}) ...[py]\n")
        pywinauto.mouse.move(coords=(X,Y))
        time.sleep(2)
        pywinauto.mouse.click(coords=(X,Y))

    except Exception as e:
        logger.console(f"      **ERROR** in 'Click_Section_Item_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")


def Click_Performance_Status_Not_Required_This_Visit_Py():
    logger.console(f"   Click_Performance_Status_Not_Required_This_Visit_Py() ...[Py]")

    try:
        logger.console("      PRESS 'TAB' presses=4 ... [py]")
        pyautogui.press(f"TAB", presses=4)
        logger.console("      PRESS 'RIGHT' presses=2 ... [py]")
        pyautogui.press(f"RIGHT", presses=2)
        logger.console("      PRESS 'SPACE' ... [py]\n")
        pyautogui.press(f"SPACE")
        time.sleep(2)
        
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Click_Performance_Status_Not_Required_This_Visit_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")
    
def Type_Visit_Reason_Text_Py(reason):
    logger.console(f"   Type_Visit_Reason_Text_Py() (reason={reason})...[Py]")
    try:
        logger.console(f"      PRESS 'TAB' presses=1 ... [py]")
        pyautogui.press(f"TAB", presses=1)
        logger.console(f"      PRESS KEYS 'CTRL+A' (prepare overwrite) ...[py]")
        pywinauto.keyboard.send_keys(keys='^a^c') # Modifier for CTRL+A 
        logger.console(f"      TYPE '{reason}' ...[py]\n")
        pywinauto.keyboard.send_keys(reason)

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Type_Visit_Reason_Text_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")
    
def Type_History_of_Present_Illness_Text_Py(text):
    logger.console(f"   Type_History_of_Present_Illness_Text_Py() (text={text})...[Py]")

    try:
        logger.console(f"      CLICK 'History_of_Present_Illness' coords=({564},{677}) ...[py]")
        pywinauto.mouse.move(coords=(564,677))
        time.sleep(2)
        pywinauto.mouse.click(coords=(564,677))
        time.sleep(2)
        logger.console(f"      PRESS KEYS 'CTRL+A' (prepare overwrite) ...[py]")
        pywinauto.keyboard.send_keys(keys='^a^c') # Modifier for CTRL+A 
        logger.console(f"      type '{text}' ...[py]\n")
        pywinauto.keyboard.send_keys(text)
        time.sleep(2)

    except Exception as e:
        logger.console(f"\n       **ERROR** in 'Type_History_of_Present_Illness_Text_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")
    
def Assessment_And_Plan_Type_Text_Py(Field,Text,X,Y):
    logger.console(f"   Assessment_And_Plan_Type_Text_Py() ...[Py]")
    
    X = int(X)
    Y = int(Y)

    logger.console(f"      (Field='{Field}  Text='{Text}'  X='{X}' Y='{Y}') ...[Py]")
    
    try:
        Focus_Structured_Notes_Entry_Window()
        logger.console(f"      CLICK '{Field}' coords=({X},{Y}) ...[py]")
        pywinauto.mouse.move(coords=(X,Y))
        time.sleep(1)
        pywinauto.mouse.click(coords=(X,Y))
        time.sleep(1)
        logger.console(f"      PRESS KEYS 'CTRL+A' (prepare overwrite) ...[py]")
        pywinauto.keyboard.send_keys(keys='^a^c') # Modifier for CTRL+A 
        logger.console(f"      TYPE '{Text}' ...[py]")
        pywinauto.keyboard.send_keys(Text)
        time.sleep(1)
        #Click off free text area for next step PAGE DOWN
        logger.console(f"      CLICK OFF '{Field}' coords=({1550},{561}) ...[py]\n")
        pywinauto.mouse.move(coords=(1600,561))
        time.sleep(2)
        pywinauto.mouse.click(coords=(1600,561))
        time.sleep(1)

    except Exception as e:
        logger.console(f"\n     **ERROR** in 'Assessment_And_Plan_Type_Text_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")

def Known_Or_Suspected_Cancer_Managed_By_Your_Service_Py(X_click,Y_click,X_nameExist,Y_nameExist):
    logger.console(f"   Known_Or_Suspected_Cancer_Managed_By_Your_Service_Py() ...[Py]")
    X_click = int(X_click)#524, 636
    Y_click = int(Y_click)#888, 552
    logger.console(f"      (X_click='{X_click}  Y_click='{Y_click}'  X_nameExist='{X_nameExist}' Y_nameExist='{Y_nameExist}') ...[Py]")

    X_nameExist = int(X_nameExist) #636
    Y_nameExist = int(Y_nameExist) #552

    try:
        ####################################
        ## Page Down to bottom part of pane
        ####################################
        time.sleep(3)
        logger.console(f"      PRESS 'pagedown' 4*...[py]")
        pyautogui.press(keys="PAGEDOWN",presses=4)
        time.sleep(2)
        
        #######################################
        # READ ELEMENT TEXT WITH COORDINATES
        #######################################
        valueFound = Get_Text_At_Point(X_nameExist, Y_nameExist)  # READ ELEMENT TEXT WITH COORDINATES
        valueFound = valueFound[0:60]
        
        logger.console(f"      element Name at tagPOINT({X_nameExist},{Y_nameExist}) = '{valueFound}'") 
        cancerFieldExists = valueFound in 'Does this patient currently have a known or suspected cancer that is being managed'

        ########################################################################
        ## SKIP IF SUSPECTED CANCER PANE DOESN'T EXIST
        ########################################################################
        if cancerFieldExists:
            logger.console(f"      \"Suspected cancer managed\" menu pane EXISTS ...[py]")
            logger.console(f"      CLICK 'unknown/work-up in progress' (3rd RadioButton) coords=({X_click},{Y_click}) ...[py]\n")
            pywinauto.mouse.move(coords=(X_click ,Y_click)) # 488,888
            time.sleep(2)
            pywinauto.mouse.click(coords=(X_click, Y_click)) # 488,888
        else:
            suspectedCancerManagedService = False
            logger.console(f"      \"Suspected cancer managed\" menu pane ***DOES NOT EXIST***. (SKIPPING) ...[py]\n")

    except Exception as e:  # CAN'T FIND  uspected cancer managed by your service - this probably is not an error
        suspectedCancerManagedService = False
        logger.console(f"      (Error={e} [Py]\n")
        logger.console(f"      ..\"suspected cancer managed by your service\" menu pane DOES NOT EXIST. (SKIPPING) ...[py]\n")


def Select_AppTrainee_Statement_Discussed_With_Py(Name,X,Y):
    logger.console(f"   Select_AppTrainee_Statement_Discussed_With_Py() (x={X}, y={Y}) ...[Py]")

    X = int(X)
    Y = int(Y)

    try:
        Focus_Structured_Notes_Entry_Window()
        logger.console(f"      CLICK '{Name}' coords=({X},{Y}) ...[py]\n")
        pywinauto.mouse.move(coords=(X,Y))
        time.sleep(2)
        pywinauto.mouse.click(coords=(X,Y))

    except Exception as e:
        logger.console(f"      **ERROR** in 'Select_AppTrainee_Statement_Discussed_With_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")
    
def Select_Ready_For_Attending_To_Yes_Py(Name,X,Y):
    logger.console(f"   Select_AppTrainee_Statement_Discussed_With_Py() (x={X}, y={Y}) ...[Py]")

    X = int(X)
    Y = int(Y)

    try:
        Focus_Structured_Notes_Entry_Window()
        logger.console(f"      CLICK '{Name}' coords=({X},{Y}) ...[py]\n")
        pywinauto.mouse.move(coords=(X,Y))
        time.sleep(2)
        pywinauto.mouse.click(coords=(X,Y))

    except Exception as e:
        logger.console(f"      **ERROR** in 'Select_Ready_For_Attending_To_Yes_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")    
    

def Enter_App_Time_Spent_Py(time_spent,X,Y):
    X = int(X)
    Y= int(Y)
    logger.console(f"   Enter_App_Time_Spent_Py() (x={X}, y={Y}) ...[Py]")
    try:
        logger.console(f"       Click 'App Time Spent' (coords=({X},{Y})) ...[Py]")
        pywinauto.mouse.move(coords=(X,Y))
        time.sleep(2)
        pywinauto.mouse.click(coords=(X,Y))
        logger.console(f"       TYPE '{time_spent}' ...[Py]\n")
        pyautogui.typewrite(time_spent)
        
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Enter_App_Time_Spent_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Verify_Document_Has_Date_Of_Today_Edit_Click_Modify_Py(docName):
    logger.console(f"   Verify_Document_Has_Date_Of_Today_Edit_Click_Modify_Py() ...[Py]")
    logger.console(f"      (docName='{docName}') ...[Py]")
    
    #VERIFY DOCUMENT DATE IS TODAY
    currMonth = calendar.month_abbr[datetime.now().month] # get 3 char month to match EHR
    currDateCheck = datetime.now().strftime(f"%d-{currMonth}-%Y") #Outputs 29-May-20225
    logger.console(f"      currDateCheck = {currDateCheck} ...[Py]")

    try:
        app, proc = Get_Altera_App()
        app = app.window(handle=proc.handle)
        app.set_focus()
        dlg = app.child_window(auto_id="ScmApplicationHost",control_type="Custom", found_index=0)
        dlgClrTab = dlg.child_window(auto_id="ClrTabHost", class_name="ClrTabHost",control_type="Custom")
        dlg = dlgClrTab.child_window(class_name="WindowsFormsHost", control_type="Pane", found_index=0)
        dlg = dlg.child_window(class_name_re="WindowsForms.*", control_type="Pane", found_index=0)
        dlg = dlg.child_window(auto_id="windowDockingArea11", control_type="Pane")
        dlg = dlg.child_window(auto_id="dockableWindow5", control_type="Pane")
        dlg = dlg.child_window(auto_id="Report", control_type="Pane")
        dlg = dlg.child_window(auto_id="ReportFormat", control_type="Pane")
        dlg = dlg.child_window(auto_id="reportUltraGrid", control_type="Table")#dlg.print_control_identifiers()
        dlg = dlg.child_window(title="DateTable", control_type="Table")
        dlg = dlg.child_window(title="DateTable row 1", control_type="Custom")
        dlg = dlg.child_window(title="DateDocuments", control_type="Table")
        row = dlg.child_window(title="DateDocuments row 1", control_type="Custom")
        dateDlg = row.child_window(title="Date", control_type="DataItem")  #,found_index=2
        nameDlg = row.child_window(title="Document Name", control_type="DataItem")  #,found_index=2
        dateFound = str(dateDlg.legacy_properties()['Value'])
        nameFound = str(nameDlg.legacy_properties()['Value'])
        logger.console(f"      Document Date = {dateFound}")
        logger.console(f"      Document Name = {nameFound}\n")

        if dateFound == currDateCheck:
            logger.console(f"      (dateFound='{dateFound}' MATCHES currDateCheck='{currDateCheck}') PASS ...[py]")
            if nameFound == docName:
                logger.console(f"      (nameFound='{nameFound}' MATCHES docName='{docName}') PASS ...[py]")
                logger.console(f"      Double Click Document ...[py]\n")
                nameDlg.click_input(double=True)
            else:
                logger.console(f"      (nameFound='{nameFound}' *DOES NOT MATCH* docName='{docName}') FAIL!! ...[py]")
                raise Exception(f"Document not found")
        else:
            logger.console(f"      (dateFound='{dateFound}' *DOES NOT MATCH* currDateCheck='{currDateCheck}') FAIL!! ...[py]")
            raise Exception(f"Document not found")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Verify_Document_Has_Date_Of_Today_Edit_Click_Modify_Py' [Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        raise Exception(f"Error={e}")
    
    finally:
         logger.console(f"")



###############################################
###############################################
#            VERIFY
###############################################
###############################################

def Get_Text_At_Point(X,Y):
    X = int(X)
    Y = int(Y)

    pywinauto.mouse.move(coords=(X,Y))
    time.sleep(3)
    
    point = tagPOINT(X,Y)
    elem = pywinauto.uia_defines.IUIA().iuia.ElementFromPoint(point) # Assessment and Pan Free text
    element = pywinauto.uia_element_info.UIAElementInfo(elem)
    valueFound = element.rich_text
    logger.console(f"      valueFound = '{valueFound}'")
    return valueFound



def Verify_Field_Data_Match_Py(fieldName, textVerify,X,Y):
    logger.console(f"   Verify_Field_Data_Match_Py() ...[Py]")
    logger.console(f"      (textVerify='{textVerify}', fieldName='{fieldName}', X='{X}', Y='{Y}') ...[Py]")
  
    try:
        ## SKIP VERIFY IF SUSPECTED CANCER PANE DOESN'T EXIST
        if 'Suspected' in fieldName:
            if suspectedCancerManagedService is False:
                logger.console(f"      ..\"suspected cancer managed by service\" menu pane DOES NOT EXIST. (SKIPPING VERIFICATION) ...[py]\n")
                return
        Focus_Structured_Notes_Entry_Window()
        valueFound = Get_Text_At_Point(X,Y)  # READ ELEMENT TEXT WITH COORDINATES
        match = textVerify == valueFound

        if match:
            logger.console(f"         PASS ('valueFound='{valueFound}' EQUALS 'textVerify='{textVerify}') ...[py]\n")
        else:
            logger.console(f"         FAIL ('valueFound='{valueFound}' NOT EQUALS 'textVerify='{textVerify}') ...[py]\n")
            raise Exception(f"text is '{valueFound}', it should be '{textVerify}'")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Verify_Field_Data_Match_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")



def Get_Current_Date_DDMMMYYYY_Dashes():
    #VERIFY DOCUMENT DATE IS TODAY
    currMonth = calendar.month_abbr[datetime.now().month] # get 3 char month to match EHR
    currDateCheck = datetime.now().strftime(f"%d-{currMonth}-%Y") #Outputs 29-May-20225
    logger.console(f"   currDateCheck = {currDateCheck}...\n")
    return currDateCheck
#########################################
#            MAINS
#########################################
if __name__ == '__main__':
    logger.console(f"\nBEGIN MAIN....\n")
    
    #Click_Section_Item_Py("Assessment & Plan") 
    #Click_Patient_Readiness_Py("Patient ready for Attending")
    #Hover_Over_Doc_Info_And_Click_First_CoSigner_Checkbox_Py(1947,100)
    #Enter_App_Time_Spent_Py("5")
    #Select_AppTrainee_Statement_Discussed_With_Py()
    #Click_Is_Note_Ready_For_Attending_Yes_Py()
    #Verify_Red_Check_Mark_Displays_For_Clinic_Notes_Py()
    #Verify_Document_Has_Date_Of_Today_Edit_Click_Modify_Py()
    #Verify_Document_Data_Py()
    #Click_Performance_Status_Not_Required_This_Visit_Py()
    #Type_Visit_Reason_Text_Py("This is a test")
    #Type_History_of_Present_Illness_Text_Py("Blah")
    #Assessment_And_Plan_Type_Text_Py("blah")

    ##########################################################
    #                    VERIFY
    ##########################################################
    #-----------------------------------
    #            Provide note
    #-----------------------------------
    #Performance_Status_Not_Required_This_Visit_Verify_Py()
    #Visit("VisitReasonText")
    #History_Of_Present_Illness_Text_Verify_Py("IllnessHistoryText")
    #-----------------------------------
    #         Assessment & Plan
    #-----------------------------------
    #Assessment_And_Plan_Type_Text_Verify_Py('AssessmentAndPlanText')
    #Known_Or_Suspected_Cancer_Managed_By_Your_Service_Py()
    #-----------------------------------
    #            Attestation
    #-----------------------------------
    #Enter_Time_Spent_Verify_Py("5")
    #Select_AppTrainee_Statement_Discussed_With_Verify_Py()
    #Click_Is_Note_Ready_For_Attending_Yes_Verify_Py()

    #Enter_Attending_Time_Spent_Py ("5",703,212)
    #Get_Breast_Medicine_Tab_Dlg("Assessment & Plan")s
    #Known_Or_Suspected_Cancer_Managed_By_Your_Service_Py()
    #Focus_Structured_Notes_Entry_Window()
    Known_Or_Suspected_Cancer_Managed_By_Your_Service_Py(239,768,387,739)