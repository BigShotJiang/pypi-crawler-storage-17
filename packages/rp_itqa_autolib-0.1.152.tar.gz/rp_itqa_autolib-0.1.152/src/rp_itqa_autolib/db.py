
"""
----------------------------------------------------------------------------------
 Author:  Andrew Bowman, Frank Runfola
 Created: 07/01/2023
----------------------------------------------------------------------------------


Requires the ODBC Driver 17 for SQL Server AND pyodbc

https://learn.microsoft.com/en-us/sql/connect/python/pyodbc/step-3-proof-of-concept-connecting-to-sql-using-pyodbc?view=sql-server-ver16#prerequisites

I tried using 18 but for some reason it didn't work, 17 did.
You might have to play with it.

NOTE: check order_queue.py for methods that actually use the database :)
"""


import pyodbc
from robot.api import logger

CONNECTION_STRING = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER=jenkinsappprd01;DATABASE=AthenaAutoDB;Trusted_Connection=yes;'

class DB:
    """
    Singleton for connecting to the database
    """
    def __init__(self, connection_string=CONNECTION_STRING):
        self.conn = pyodbc.connect(connection_string)

    def queryAll(self, sql: str):
        cursor = self.conn.cursor()
        cursor.execute(sql)
        return cursor.fetchall()
    
    def queryOne(self, sql: str):
        cursor = self.conn.cursor()
        cursor.execute(sql)
        return cursor.fetchone()

    def update(self, sql: str):
        cursor = self.conn.cursor()
        cursor.execute(sql)
        self.conn.commit()

    def close(self):
        self.conn.close()


_db = None
def _get_db():
    """
    Gets the database object
    :return: the database object
    """
    global _db
    if _db is None:
        _db = DB(CONNECTION_STRING)
    return _db

def query(sql: str):
    """
    Queries the database
    :param sql: the sql to query
    :return: the results of the query
    """
    logger.console(f'{sql}')
    resultList = _get_db().queryAll(sql)
    logger.console(f'   SQL rows returned = {len(resultList)}\n')
    return resultList

def queryOne(sql: str):
    """
    Queries the database
    :param sql: the sql to query
    :return: the results of the query
    """
    logger.console(f'{sql}\n')
    result = _get_db().queryOne(sql)
    return result

def update(sql: str):
    """
    Updates the database
    :param sql: the sql to update
    """
    _get_db().update(sql)

if __name__ == '__main__':
    print(CONNECTION_STRING)
    db = DB(CONNECTION_STRING)
    print(db.queryAll('SELECT * FROM fw.TestCase'))
    db.close()
