"""
----------------------------------------------------------------------------------
 Author:
 Created:
----------------------------------------------------------------------------------
"""

import sys

from random import randrange
import random
import re

import pyautogui
import pywinauto
import RPA.Windows as rpawin
import typing
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
import pywinauto.base_wrapper
import pywinauto.controls
import pywinauto.element_info
import pywinauto.mouse
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows
from pywinauto import timings
from pywinauto import findbestmatch
from pywinauto.application import Application

AlteraWindow = "Altera Gateway"
_static_win = None

def Verify_Banner_Admit_Date_Py(dateToVerify):
    logger.console(f"   Verify_Banner_Admit_Date_Py (Search '{dateToVerify}') ...[Py]")

    try:
        dlg = Get_Standard_Patient_Header()
        dlg = dlg.child_window(auto_id="FirstAdditionalLineRTF",control_type="Document")
        dlgText = dlg.window_text().strip() #texts()
        dlgText1 = str(dlgText).replace("\n","")
        bannerText = str(dlgText1)[0:35].strip()
        dateToVerify = str(dateToVerify)
        logger.console(f"      bannerTextUpper = '{bannerText}'   dateToVerify = '{dateToVerify}' [Py]")
        
        if dateToVerify in bannerText:
            logger.console(f"      PASS - '{dateToVerify}' IS FOUND in Banner Text\n") 
            found = str(True)
        else:
            logger.console(f"      FAIL - '{dateToVerify}' NOT FOUND in Banner Text\n")
            raise Exception(f"FAIL - '{dateToVerify}' NOT FOUND in Banner Text")
            
    except Exception as e:
        logger.console(f"   **ERROR** in 'Verify_Banner_Admit_Date_Py' [Py]")
        logger.console(f"   (Error={e} [Py]\n")
        raise Exception(f"{e}")

def Verify_Banner_Birth_Sex_Py(birthSexVerify):
    logger.console(f"   Verify Banner Birth Sex Py (Search '{birthSexVerify}') ...[Py]")

    try:
        dlg = Get_Standard_Patient_Header()
        dlg = dlg.child_window(auto_id="SecondAdditionalLineRTF",control_type="Document")
        dlgText = dlg.window_text().strip() #texts()
        dlgText1 = str(dlgText).replace("\n","")
        bannerText = str(dlgText1)[0:35].strip()
        logger.console(f"      bannerText = '{bannerText}'   birthSexVerify = '{birthSexVerify}' [Py]")
        
        if birthSexVerify in bannerText:
            logger.console(f"      PASS - '{birthSexVerify}' IS FOUND in Banner Text\n") 
            found = str(True)
        else:
            logger.console(f"      FAIL - '{birthSexVerify}' NOT FOUND in Banner Text")
            raise Exception(f"FAIL - '{birthSexVerify}' NOT FOUND in Banner Text")
            
    except Exception as e:
        logger.console(f"   **ERROR** in 'Verify_Banner_Birth_Sex_Py' [Py]")
        logger.console(f"   (Error={e} [Py]\n")
        raise Exception(f"{e}")

def Verify_Banner_Birth_Date_In_Upper_Right_Corner_Py(birthDateVerify):
    logger.console(f"   Verify_Banner_Birth_Date_In_Upper_Right_Corner_Py (Search '{birthDateVerify}') ...[Py]")
    logger.console(f"      ***THIS STEP IS NOT AUTOMATABLE*** (Birthdate data is NOT exposed to Automation)\n")
    #***THIS STEP IS NOT AUTOMATABLE*** 
    #***THIS STEP IS NOT AUTOMATABLE*** 
    #***THIS STEP IS NOT AUTOMATABLE*** 
    '''try:
        dlg = Get_Standard_Patient_Header()
        #dlg = dlg.child_window()
        dlgText = dlg.window_text() #texts() 
        bannerText = str(dlgText).strip()
        birthDateVerify = str(birthDateVerify)
        logger.console(f"      bannerText = '{bannerText}'   birthDateVerify = '{birthDateVerify}' [Py]")
        
        if birthDateVerify in bannerText:
            logger.console(f"      PASS - '{birthDateVerify}' IS FOUND in Banner Text\n") 
            found = str(True)
        else:
            logger.console(f"      FAIL - '{birthDateVerify}' NOT FOUND in Banner Text")
            logger.console(f"      ***THIS STEP IS NOT AUTOMATABLE*** (Birthdate data is NOT exposed to Automation)\n")
            #raise Exception(f"Error= FAIL - '{birthDateVerify}' NOT FOUND in Banner Text")
            
    except Exception as e:
        logger.console(f"   **ERROR** in 'Verify_Banner_Birth_Date_In_Upper_Right_Corner_Py'")
        logger.console(f"   (Error={e} [Py]\n")
        raise Exception(f"{e}")'''

def Verify_Banner_Legal_Sex_In_Upper_Right_Corner_Py(legalSexVerify):
    logger.console(f"   Verify_Banner_Legal_Sex_In_Upper_Right_Corner_Py (Search '{legalSexVerify}') ...[Py]")

    try:
        dlg = Get_Standard_Patient_Header()
        dlg = dlg.child_window(auto_id="PatientGender")
        dlgText = dlg.window_text() #texts() 
        bannerText = str(dlgText).strip()
        legalSexVerify = str(legalSexVerify)
        logger.console(f"      haystack = '{bannerText}'   needle = '{legalSexVerify}' [Py]")
        
        if legalSexVerify in bannerText:
            logger.console(f"      PASS - '{legalSexVerify}' IS FOUND in Banner Text\n") 
            found = str(True)
        else:
            logger.console(f"      FAIL - '{legalSexVerify}' NOT FOUND in Banner Text\n")
            raise Exception(f"Error= FAIL - '{legalSexVerify}' NOT FOUND in Banner Text")
            
    except Exception as e:
        logger.console(f"   **ERROR** in 'Verify_Banner_Legal_Sex_In_Upper_Right_Corner_Py' [Py]")
        logger.console(f"   (Error={e} [Py]\n")
        raise Exception(f"{e}")

def Get_Banner_Legal_Sex_In_Upper_Right_Corner_Py():
    try:
        dlg = Get_Standard_Patient_Header()
        dlg = dlg.child_window(auto_id="PatientGender", control_type="Text")
        legalSex = str(dlg.window_text()).strip() #texts()
        legalSexUp = legalSex.upper()
        logger.console(f"      legalSexUp='{legalSexUp}'\n")
        return legalSexUp
    
    except Exception as e:
        logger.console(f"   **ERROR** in 'Get_Banner_Legal_Sex_In_Upper_Right_Corner_Py' [Py]")
        logger.console(f"   (Error={e} [Py]\n")
        raise Exception(f"{e}")


#################################################################################
#                   HELPERS
#################################################################################
def Get_Standard_Patient_Header():
    app,proc= Get_Altera_App()
    dlg = app.window(handle=proc.handle)
    dlg = dlg.child_window(class_name="ScmApplicationHost", control_type="Custom", found_index=0)     #dlg = dlg.children()
    dlg = dlg.child_window(auto_id="_patientHeader", control_type="Custom")  #dlg.print_control_identifiers()
    dlg = dlg.child_window(class_name="StandardPatientHeader", control_type="Custom")
    
    return dlg

def Get_Altera_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if AlteraWindow in proc.name:
            app = app.connect(process=proc.process_id,handle=proc.handle)
            break
    return app,proc

def Get_ContactInfoAddEdit_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if "Contact Information Add/Edit"  in proc.name:
            app = app.connect(process=proc.process_id,handle=proc.handle)
            break
    return app,proc

def Close_Contact_Info_Add_Edit_Window():
    app,proc = Get_ContactInfoAddEdit_App()
    dlg = app.window(handle=proc.handle)
    dlg = dlg.TitleBar
    dlg = dlg.Close #(auto_id="Close",control_type="Button")
    dlg.click_input()


def panelHostCtrl(app:Application, proc:any):
    dlg = app.window(handle=proc.handle)
    dlg= dlg.child_window(title_re=f"{AlteraWindow}.*", control_type="Window", found_index=0)
    dlg.print_control_identifiers(depth=1,filename="__out__1.txt")
    dlg= dlg.child_window(auto_id="ScmApplicationHost", control_type="Custom", found_index=0)
    dlg.print_control_identifiers(depth=2,filename="__out__2.txt")
    dlg = dlg.child_window(auto_id="ClrTabHost", control_type="Custom")    #dlg = dlg.children
    dlg = dlg.child_window(auto_id="_this", control_type="Custom")
    dlg = dlg.child_window(auto_id="_panelHostCtrl", control_type="Custom")
    
    return dlg



     
###############################################
#                    MAIN
###############################################
if __name__ == '__main__':
    logger.console(f"\nBEGIN MAIN....\n")
    #Verify_Banner_Admit_Date_Py('09-Jun-2025')
    #Verify_Banner_Legal_Sex_In_Upper_Right_Corner_Py("Female")
    #Verify_Banner_Birth_Sex_Py("Male")
    #Verify_Banner_Birth_Date_In_Upper_Right_Corner_Py("01-Jan-1985")
    #Close_Contact_Info_Add_Edit_Window()
    #Get_Date_DDMMMYYYY_Dashes_Py(getTomorrow=True)
    #Verify_Banner_Admit_Date_Py('BLAH')
    #Verify_Banner_Birth_Sex_Py('BLAH')

    

  
