# aquilax/__main__.py

from .index import main

if __name__ == "__main__":
    main()
