
from importlib.metadata import version

from .geometry import PlanarInductor

__version__ = version('kicoil')
