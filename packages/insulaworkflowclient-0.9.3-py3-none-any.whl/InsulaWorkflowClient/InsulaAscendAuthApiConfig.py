import os

from .InsulaAuthorizationApiConfig import InsulaAuthorizationApiConfig


class InsulaAscendAuthApiConfig(InsulaAuthorizationApiConfig):
  def __init__(self):
    self.__token_type: str = 'Bearer'

  def get_authorization_header(self):
    access_token = os.environ['INSULA_API_ACCESS_TOKEN']
    return f'{self.__token_type} {access_token}'
