# easyspec
The easiest way to do long-slit spectroscopy

# Install
Please folow the GitHub tutorial for installation:
https://github.com/ranieremenezes/easyspec/tree/main
