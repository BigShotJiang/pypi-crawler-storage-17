### [0.38.6](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.38.5...v0.38.6) (2024-08-03)


### Bug Fixes

* updates github action and broken test ([#1009](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/1009)) ([d7d61bb](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/d7d61bb1556dca8eb07c3ae52816d2ba01e170c4))


### [0.38.5](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.38.4...v0.38.5) (2024-06-10)


### Continuous Integration

* removes pydantic upper bound ([#972](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/972)) ([648f6c6](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/648f6c6fabf8d6c9ac7cc24e76e70245771c059c))


### [0.38.4](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.38.3...v0.38.4) (2024-06-10)


### [0.38.3](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.38.2...v0.38.3) (2024-06-08)


### [0.38.2](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.38.1...v0.38.2) (2024-06-07)


### [0.38.1](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.38.0...v0.38.1) (2024-06-06)


## [0.38.0](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.12...v0.38.0) (2024-05-31)


### Features

* contributor guidelines ([#942](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/942)) ([114c454](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/114c454a912984ab81824d9a3185a3ee4b86c454))


### [0.37.12](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.11...v0.37.12) (2024-05-31)


### [0.37.11](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.10...v0.37.11) (2024-05-31)


### [0.37.10](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.9...v0.37.10) (2024-05-30)


### [0.37.9](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.8...v0.37.9) (2024-05-30)


### [0.37.8](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.7...v0.37.8) (2024-05-30)


### [0.37.7](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.6...v0.37.7) (2024-05-30)


### [0.37.6](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.5...v0.37.6) (2024-05-28)


### Bug Fixes

* Dictionary Key Access ([#947](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/947)) ([cc631eb](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/cc631eba24fb1dc3860575ffa487a17dbb3fdce9))


### [0.37.5](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.4...v0.37.5) (2024-05-22)


### [0.37.4](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.3...v0.37.4) (2024-05-22)


### [0.37.3](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.2...v0.37.3) (2024-05-21)


### Bug Fixes

* removes old test ([#944](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/944)) ([a7605e7](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/a7605e77a1046ed1bfc16259cd2d90a78262e280))


### [0.37.2](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.1...v0.37.2) (2024-05-18)


### [0.37.1](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.37.0...v0.37.1) (2024-05-18)


## [0.37.0](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.36.1...v0.37.0) (2024-05-16)


### Features

* changed moniter to speaker in title for Speaker ([#938](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/938)) ([15a4b8e](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/15a4b8e317e771f7a16648754f9c4f4cdaf56a5d))


### [0.36.1](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.36.0...v0.36.1) (2024-05-16)


## [0.36.0](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.35.2...v0.36.0) (2024-05-09)


### Features

* moves data description enums ([#930](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/930)) ([20d315e](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/20d315ead86d370604816fea9193716bd47ddb91))


### [0.35.2](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.35.1...v0.35.2) (2024-05-09)


### [0.35.1](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.35.0...v0.35.1) (2024-05-09)


## [0.35.0](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.34.4...v0.35.0) (2024-05-07)


### Features

* uses aind-data-schema-models package ([#919](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/919)) ([fc56b0b](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/fc56b0b17283cd6dd7ec83c2f589f779a080c5b4))


### [0.34.4](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.34.3...v0.34.4) (2024-05-06)


### [0.34.3](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.34.2...v0.34.3) (2024-05-06)


### [0.34.2](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.34.1...v0.34.2) (2024-05-03)


### [0.34.1](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.34.0...v0.34.1) (2024-05-02)


## [0.34.0](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.33.10...v0.34.0) (2024-05-01)


### Features

* added optional software list to stream ([#907](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/907)) ([685579e](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/685579e66737b2319ca1251058b886566f108efa))
* added optiopnal list of Software to acquisition ([#906](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/906)) ([8dd4e9c](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/8dd4e9cb8850644894ff1ae7caf06f50d7a755b2))


### [0.33.10](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.33.9...v0.33.10) (2024-04-26)


### [0.33.9](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.33.8...v0.33.9) (2024-04-24)


### [0.33.8](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.33.7...v0.33.8) (2024-04-23)


### [0.33.7](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.33.6...v0.33.7) (2024-04-10)


### Bug Fixes

* removes erd tests from local cov ([#887](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/887)) ([feb4cf3](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/feb4cf30486176d6dd34a5d4309252d46ddc5de4))


### [0.33.6](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.33.5...v0.33.6) (2024-04-09)


### Continuous Integration

* adds a step with git pull run in workflows ([#886](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/886)) ([0b21921](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/0b2192122d17144fffc35ad7f04dc63df060e7e4))


### [0.33.5](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.33.4...v0.33.5) (2024-04-05)


### Documentation

* add autodoc pydantic to readthdocs build ([#880](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/880)) ([a93f4b9](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/a93f4b9272d34ddf4518cdb266ac54e06527549a))


### [0.33.4](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.33.3...v0.33.4) (2024-04-05)


### [0.33.3](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.33.2...v0.33.3) (2024-04-03)


### Documentation

* add github workflow for publishing changelogs ([#873](https://github.com/AllenNeuralDynamics/aind-data-schema/issues/873)) ([a60648e](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/a60648e513786b8a3130c8f096e431b844e03112))


### [0.19.0](https://github.com/AllenNeuralDynamics/aind-data-schema/compare/v0.19.0...v0.31.17) (2023-12-08)


### Features

* upgrades pydantic to v2 ([#608](https://github.com/AllenNeuralDynamics/aind-data-schema/pull/608)) ([a123e7e](https://github.com/AllenNeuralDynamics/aind-data-schema/commit/a123e7ee215f292f14ab712c38fa5c933f3fc172))