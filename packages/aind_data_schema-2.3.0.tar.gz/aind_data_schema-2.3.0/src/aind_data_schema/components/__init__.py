""" Component schemas that are used in multiple core schemas"""
