# Atlas

## Model definitions

### AtlasName

Atlas names

| Name | Value |
|------|-------|
| `CCF` | `CCF` |
| `CUSTOM` | `CUSTOM` |


