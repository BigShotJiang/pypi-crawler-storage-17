class ScraperStructureChanged(Exception):
    """Custom exception for when the scraper detects an HTML structure change."""

    pass
