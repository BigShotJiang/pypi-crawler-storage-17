"""Tests for arcade-mcp-server package."""
