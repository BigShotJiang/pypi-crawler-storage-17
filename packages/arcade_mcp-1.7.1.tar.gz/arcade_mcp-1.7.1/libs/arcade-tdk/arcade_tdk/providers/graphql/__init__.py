from .error_adapter import GraphQLErrorAdapter

__all__ = ["GraphQLErrorAdapter"]
