from arcade_tdk.providers.slack.error_adapter import SlackErrorAdapter

__all__ = ["SlackErrorAdapter"]
