from typing import Annotated

from arcade_mcp_server import tool


@tool
def greet(name: Annotated[str, "The name of the person to greet"]) -> str:
    """Greet a person by name."""
    return f"Hello, {name}!"
