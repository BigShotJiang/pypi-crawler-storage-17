# Typed Modetrade

> A fully typed, validated async client for the Modetrade API

Use *autocomplete* instead of documentation.

🚧 Under construction.