# File: src/iotopen_bridge/__main__.py
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from .cli.main import main

if __name__ == "__main__":
    main()
