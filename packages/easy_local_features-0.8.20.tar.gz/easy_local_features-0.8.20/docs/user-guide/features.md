# Features overview

Methods are grouped by type:

- Detect+Describe: alike, aliked, d2net, deal, delf, disk, r2d2, superpoint, orb, xfeat
- Descriptor-only: sosnet, tfeat
- End-to-end: roma

See the API pages for details and configurations.
