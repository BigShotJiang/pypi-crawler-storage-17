# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2025/10/11 11:01
# Description:

from .data import DataService, D