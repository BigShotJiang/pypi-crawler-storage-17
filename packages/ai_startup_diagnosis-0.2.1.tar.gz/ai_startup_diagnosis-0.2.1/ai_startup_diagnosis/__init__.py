"""AI Startup Diagnosis - A FastAPI package for AI-powered startup readiness analysis."""

__version__ = "0.2.1"

