"""Utility functions for AI Startup Diagnosis."""

