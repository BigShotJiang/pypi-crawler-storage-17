"""Data models for AI Startup Diagnosis."""

