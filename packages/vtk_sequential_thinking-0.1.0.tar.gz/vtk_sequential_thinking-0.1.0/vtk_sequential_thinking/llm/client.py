"""
Multi-provider LLM client with tool calling support.

Unified interface for OpenAI, Anthropic, Google, and local models.
Supports tool/function calling for agentic workflows.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable

from vtk_sequential_thinking.config import AppConfig, LLMConfig, LLMProvider

logger = logging.getLogger(__name__)


@dataclass
class Tool:
    """Definition of a tool the LLM can call.

    Attributes:
        name: Tool name (e.g., "get_class_info")
        description: What the tool does
        parameters: JSON schema for parameters
        handler: Function to execute when tool is called
    """
    name: str
    description: str
    parameters: dict[str, Any]
    handler: Callable[..., Any]


@dataclass
class ToolCall:
    """A tool call made by the LLM.

    Attributes:
        id: Unique ID for this call
        name: Tool name
        arguments: Arguments passed to the tool
    """
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class ToolResult:
    """Result of executing a tool.

    Attributes:
        tool_call_id: ID of the tool call this is a result for
        content: Result content (will be JSON serialized)
    """
    tool_call_id: str
    content: Any


@dataclass
class GenerationResult:
    """Result of a generation with potential tool calls.

    Attributes:
        content: Text content (if any)
        tool_calls: List of tool calls (if any)
        stop_reason: Why generation stopped
    """
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    stop_reason: str = "end_turn"

class LLMClient:
    """
    Unified LLM client supporting multiple providers.

    All communication uses structured JSON for consistency.
    """

    def __init__(self, config: LLMConfig | None = None, app_config: AppConfig | None = None):
        """
        Initialize LLM client.

        Args:
            config: LLM configuration. If None, loads from app_config or environment.
            app_config: Application configuration. Used if config is None.
        """
        if config is None:
            if app_config is None:
                from vtk_sequential_thinking.config import load_config
                app_config = load_config()
            config = app_config.llm

        self.config = config
        self._client = self._init_client()

    def _init_client(self) -> Any:
        """Initialize the provider-specific client."""
        if self.config.provider == LLMProvider.OPENAI:
            from openai import OpenAI
            return OpenAI(
                api_key=self.config.api_key,
                base_url=self.config.api_base,
            )
        elif self.config.provider == LLMProvider.ANTHROPIC:
            from anthropic import Anthropic
            return Anthropic(api_key=self.config.api_key)
        elif self.config.provider == LLMProvider.GOOGLE:
            import google.generativeai as genai
            genai.configure(api_key=self.config.api_key)
            return genai.GenerativeModel(self.config.model)
        else:  # LOCAL - OpenAI-compatible API
            from openai import OpenAI
            return OpenAI(
                api_key=self.config.api_key or "local",
                base_url=self.config.api_base,
            )

    def generate(
        self,
        prompt: str,
        system: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> str:
        """
        Generate a response from the LLM.

        Args:
            prompt: User prompt
            system: Optional system prompt
            temperature: Override default temperature
            max_tokens: Override default max tokens

        Returns:
            Generated text response
        """
        temp = temperature if temperature is not None else self.config.temperature
        tokens = max_tokens if max_tokens is not None else self.config.max_tokens

        if self.config.provider == LLMProvider.ANTHROPIC:
            return self._generate_anthropic(prompt, system, temp, tokens)
        elif self.config.provider == LLMProvider.GOOGLE:
            return self._generate_google(prompt, system, temp, tokens)
        else:  # OPENAI or LOCAL
            return self._generate_openai(prompt, system, temp, tokens)

    def _generate_openai(
        self,
        prompt: str,
        system: str | None,
        temperature: float,
        max_tokens: int,
    ) -> str:
        """Generate using OpenAI API."""
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = self._client.chat.completions.create(
            model=self.config.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content

    def _generate_anthropic(
        self,
        prompt: str,
        system: str | None,
        temperature: float,
        max_tokens: int,
    ) -> str:
        """Generate using Anthropic API."""
        kwargs = {
            "model": self.config.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [{"role": "user", "content": prompt}],
        }
        if system:
            kwargs["system"] = system

        response = self._client.messages.create(**kwargs)
        return response.content[0].text

    def _generate_google(
        self,
        prompt: str,
        system: str | None,
        temperature: float,
        max_tokens: int,
    ) -> str:
        """Generate using Google Gemini API."""
        full_prompt = f"{system}\n\n{prompt}" if system else prompt

        response = self._client.generate_content(
            full_prompt,
            generation_config={
                "temperature": temperature,
                "max_output_tokens": max_tokens,
            },
        )
        return response.text

    def generate_json(
        self,
        prompt: str,
        system: str | None = None,
        temperature: float | None = None,
    ) -> dict[str, Any]:
        """
        Generate a JSON response from the LLM.

        Args:
            prompt: User prompt (should request JSON output)
            system: Optional system prompt
            temperature: Override default temperature

        Returns:
            Parsed JSON response as dict

        Raises:
            ValueError: If response is not valid JSON
        """
        from vtk_sequential_thinking.llm.json_protocol import JSONProtocol

        response = self.generate(prompt, system, temperature)
        protocol = JSONProtocol()
        return protocol.extract_json(response)

    def generate_with_tools(
        self,
        prompt: str,
        tools: list[Tool],
        system: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        max_iterations: int = 10,
    ) -> GenerationResult:
        """
        Generate with tool calling support.

        The LLM can call tools during generation. This method handles the
        tool call loop automatically, executing tools and feeding results
        back to the LLM until it produces a final response.

        Args:
            prompt: User prompt
            tools: List of Tool definitions
            system: Optional system prompt
            temperature: Override default temperature
            max_tokens: Override default max tokens
            max_iterations: Maximum tool call iterations

        Returns:
            GenerationResult with final content and tool call history
        """
        temp = temperature if temperature is not None else self.config.temperature
        tokens = max_tokens if max_tokens is not None else self.config.max_tokens

        if self.config.provider == LLMProvider.ANTHROPIC:
            return self._generate_with_tools_anthropic(
                prompt, tools, system, temp, tokens, max_iterations
            )
        elif self.config.provider in (LLMProvider.OPENAI, LLMProvider.LOCAL):
            return self._generate_with_tools_openai(
                prompt, tools, system, temp, tokens, max_iterations
            )
        else:
            # Google doesn't have great tool support yet, fall back to no tools
            logger.warning("Tool calling not supported for Google provider, generating without tools")
            content = self._generate_google(prompt, system, temp, tokens)
            return GenerationResult(content=content)

    def _generate_with_tools_anthropic(
        self,
        prompt: str,
        tools: list[Tool],
        system: str | None,
        temperature: float,
        max_tokens: int,
        max_iterations: int,
    ) -> GenerationResult:
        """Generate with tools using Anthropic API."""
        import json

        # Convert tools to Anthropic format
        anthropic_tools = [
            {
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.parameters,
            }
            for tool in tools
        ]

        # Build tool lookup
        tool_handlers = {tool.name: tool.handler for tool in tools}

        messages = [{"role": "user", "content": prompt}]
        all_tool_calls: list[ToolCall] = []

        for iteration in range(max_iterations):
            kwargs: dict[str, Any] = {
                "model": self.config.model,
                "max_tokens": max_tokens,
                "temperature": temperature,
                "messages": messages,
                "tools": anthropic_tools,
            }
            if system:
                kwargs["system"] = system

            response = self._client.messages.create(**kwargs)

            # Check if we got tool calls
            tool_use_blocks = [b for b in response.content if b.type == "tool_use"]

            if not tool_use_blocks:
                # No tool calls, extract text and return
                text_content = "".join(
                    b.text for b in response.content if hasattr(b, "text")
                )
                return GenerationResult(
                    content=text_content,
                    tool_calls=all_tool_calls,
                    stop_reason=response.stop_reason or "end_turn",
                )

            # Execute tool calls
            tool_results = []
            for block in tool_use_blocks:
                tool_call = ToolCall(
                    id=block.id,
                    name=block.name,
                    arguments=block.input,
                )
                all_tool_calls.append(tool_call)

                # Execute the tool
                handler = tool_handlers.get(block.name)
                if handler:
                    try:
                        result = handler(**block.input)
                        result_content = json.dumps(result) if not isinstance(result, str) else result
                    except Exception as e:
                        logger.error(f"Tool {block.name} failed: {e}")
                        result_content = json.dumps({"error": str(e)})
                else:
                    result_content = json.dumps({"error": f"Unknown tool: {block.name}"})

                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": result_content,
                })

            # Add assistant message with tool use and tool results
            messages.append({"role": "assistant", "content": response.content})
            messages.append({"role": "user", "content": tool_results})

        # Max iterations reached
        logger.warning(f"Max iterations ({max_iterations}) reached in tool loop")
        return GenerationResult(
            content="",
            tool_calls=all_tool_calls,
            stop_reason="max_iterations",
        )

    def _generate_with_tools_openai(
        self,
        prompt: str,
        tools: list[Tool],
        system: str | None,
        temperature: float,
        max_tokens: int,
        max_iterations: int,
    ) -> GenerationResult:
        """Generate with tools using OpenAI API."""
        import json

        # Convert tools to OpenAI format
        openai_tools = [
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters,
                },
            }
            for tool in tools
        ]

        # Build tool lookup
        tool_handlers = {tool.name: tool.handler for tool in tools}

        messages: list[dict[str, Any]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        all_tool_calls: list[ToolCall] = []

        for iteration in range(max_iterations):
            response = self._client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                tools=openai_tools,
            )

            message = response.choices[0].message

            if not message.tool_calls:
                # No tool calls, return content
                return GenerationResult(
                    content=message.content or "",
                    tool_calls=all_tool_calls,
                    stop_reason=response.choices[0].finish_reason or "stop",
                )

            # Add assistant message
            messages.append(message.model_dump())

            # Execute tool calls
            for tc in message.tool_calls:
                tool_call = ToolCall(
                    id=tc.id,
                    name=tc.function.name,
                    arguments=json.loads(tc.function.arguments),
                )
                all_tool_calls.append(tool_call)

                # Execute the tool
                handler = tool_handlers.get(tc.function.name)
                if handler:
                    try:
                        result = handler(**json.loads(tc.function.arguments))
                        result_content = json.dumps(result) if not isinstance(result, str) else result
                    except Exception as e:
                        logger.error(f"Tool {tc.function.name} failed: {e}")
                        result_content = json.dumps({"error": str(e)})
                else:
                    result_content = json.dumps({"error": f"Unknown tool: {tc.function.name}"})

                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": result_content,
                })

        # Max iterations reached
        logger.warning(f"Max iterations ({max_iterations}) reached in tool loop")
        return GenerationResult(
            content="",
            tool_calls=all_tool_calls,
            stop_reason="max_iterations",
        )
