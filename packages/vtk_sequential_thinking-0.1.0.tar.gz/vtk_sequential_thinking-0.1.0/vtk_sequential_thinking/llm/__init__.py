"""
LLM communication layer.

Provides unified interface for multiple LLM providers with JSON protocol
and tool calling support.
"""

from vtk_sequential_thinking.llm.client import (
    GenerationResult,
    LLMClient,
    Tool,
    ToolCall,
    ToolResult,
)
from vtk_sequential_thinking.llm.json_protocol import JSONProtocol

__all__ = [
    "GenerationResult",
    "JSONProtocol",
    "LLMClient",
    "Tool",
    "ToolCall",
    "ToolResult",
]
