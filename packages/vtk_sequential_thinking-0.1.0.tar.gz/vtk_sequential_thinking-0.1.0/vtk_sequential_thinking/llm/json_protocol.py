"""
JSON Protocol for LLM communication.

Handles encoding requests and decoding responses as structured JSON.
All LLM communication uses this protocol for consistency.

Tool calling is embedded in the JSON protocol:
- Request includes available_tools with name, description, parameters
- Response can be {"tool_calls": [...]} to request tool execution
- Client executes tools and sends results back as JSON
- Loop continues until final response (no tool_calls)
"""

import json
import re
from dataclasses import dataclass
from typing import Any, Callable, Type, TypeVar

from pydantic import BaseModel, ValidationError

T = TypeVar("T", bound=BaseModel)


@dataclass
class ToolDefinition:
    """Definition of a tool available to the LLM.

    Attributes:
        name: Tool name (e.g., "search_vtk_classes")
        description: What the tool does
        parameters: JSON schema for parameters
        handler: Function to execute when tool is called
    """
    name: str
    description: str
    parameters: dict[str, Any]
    handler: Callable[..., Any]

    def to_schema(self) -> dict[str, Any]:
        """Convert to JSON schema for inclusion in prompts."""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters,
        }


@dataclass
class ToolCallRequest:
    """A tool call requested by the LLM in its JSON response."""
    name: str
    arguments: dict[str, Any]


@dataclass
class ToolCallResult:
    """Result of executing a tool call."""
    name: str
    arguments: dict[str, Any]
    result: Any


class JSONProtocol:
    """
    Encode/decode structured JSON for LLM communication.

    Handles:
    - Encoding Pydantic models to JSON strings
    - Extracting JSON from LLM responses (including markdown fences)
    - Decoding JSON to Pydantic models with validation
    """

    def encode_request(self, request: BaseModel) -> str:
        """
        Encode a Pydantic model to JSON string for LLM prompt.

        Args:
            request: Pydantic model to encode

        Returns:
            JSON string representation
        """
        return request.model_dump_json(indent=2)

    def encode_dict(self, data: dict[str, Any]) -> str:
        """
        Encode a dictionary to JSON string.

        Args:
            data: Dictionary to encode

        Returns:
            JSON string representation
        """
        return json.dumps(data, indent=2)

    def decode_response(self, raw: str, model: Type[T]) -> T:
        """
        Decode LLM response JSON to Pydantic model.

        Args:
            raw: Raw LLM response text
            model: Pydantic model class to decode into

        Returns:
            Validated Pydantic model instance

        Raises:
            ValueError: If JSON extraction or validation fails
        """
        try:
            data = self.extract_json(raw)

            # Handle case where LLM returns just a list instead of full object
            # If model expects 'tasks' field and we got a list, wrap it
            if isinstance(data, list):
                # Check if model has a 'tasks' field
                if hasattr(model, 'model_fields') and 'tasks' in model.model_fields:
                    data = {
                        "tasks": data,
                        "output_type": "interactive",  # Default
                        "reasoning": "Wrapped from list response"
                    }

            return model.model_validate(data)
        except ValidationError as e:
            print(f"Validation error: {e}")
            raise ValueError(f"Failed to validate response: {e}")

    def decode_or_tool_calls(
        self,
        raw: str,
        model: Type[T],
    ) -> tuple[T | None, list[ToolCallRequest] | None, dict[str, Any]]:
        """Decode an LLM response that may contain tool calls.

        Returns the validated model when the response is final, otherwise returns
        the parsed tool calls.

        Args:
            raw: Raw LLM response text
            model: Pydantic model class to decode into when response is final

        Returns:
            Tuple of (validated_model_or_none, tool_calls_or_none, raw_data_dict)

        Raises:
            ValueError: If JSON extraction fails or validation fails when no tool calls
        """
        data = self.extract_json(raw)
        tool_calls = self.parse_tool_calls(data)
        if tool_calls is not None:
            return None, tool_calls, data

        try:
            # Mirror decode_response() behavior for list-only outputs
            if isinstance(data, list):
                if hasattr(model, "model_fields") and "tasks" in model.model_fields:
                    data = {
                        "tasks": data,
                        "output_type": "interactive",
                        "reasoning": "Wrapped from list response",
                    }

            if isinstance(data, dict):
                if (
                    hasattr(model, "model_fields")
                    and "tasks" in model.model_fields
                    and "tasks" not in data
                    and isinstance(data.get("class_names"), list)
                    and all(isinstance(item, str) for item in data.get("class_names", []))
                ):
                    data = {
                        "tasks": data["class_names"],
                        "output_type": "interactive",
                        "reasoning": "Wrapped from class_names response",
                    }

            return model.model_validate(data), None, data
        except ValidationError as e:
            keys = list(data.keys()) if isinstance(data, dict) else None
            raise ValueError(f"Failed to validate response (keys={keys}): {e}")

    def extract_json(self, text: str) -> dict[str, Any]:
        """
        Extract JSON from text, handling markdown fences.

        Handles formats:
        - Plain JSON: {"key": "value"}
        - Markdown fenced: ```json\n{"key": "value"}\n```
        - Markdown fenced without language: ```\n{"key": "value"}\n```

        Args:
            text: Text potentially containing JSON

        Returns:
            Parsed JSON as dictionary

        Raises:
            ValueError: If no valid JSON found
        """
        text = text.strip()

        # Try to extract from markdown code fence
        fence_patterns = [
            r"```json\s*\n?(.*?)\n?```",  # ```json ... ```
            r"```\s*\n?(.*?)\n?```",       # ``` ... ```
        ]

        for pattern in fence_patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                json_str = match.group(1).strip()
                try:
                    return json.loads(json_str)
                except json.JSONDecodeError:
                    continue

        # Try to find JSON object directly
        # Look for outermost { } pair
        brace_start = text.find("{")
        if brace_start != -1:
            # Find matching closing brace
            depth = 0
            for i, char in enumerate(text[brace_start:], brace_start):
                if char == "{":
                    depth += 1
                elif char == "}":
                    depth -= 1
                    if depth == 0:
                        json_str = text[brace_start:i + 1]
                        try:
                            return json.loads(json_str)
                        except json.JSONDecodeError:
                            break

        # Try to find JSON array
        bracket_start = text.find("[")
        if bracket_start != -1:
            depth = 0
            for i, char in enumerate(text[bracket_start:], bracket_start):
                if char == "[":
                    depth += 1
                elif char == "]":
                    depth -= 1
                    if depth == 0:
                        json_str = text[bracket_start:i + 1]
                        try:
                            return json.loads(json_str)
                        except json.JSONDecodeError:
                            break

        # Last resort: try parsing entire text as JSON
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            print(f"Failed to extract JSON from: {text[:200]}...")
            raise ValueError(f"No valid JSON found in response: {e}")

    def format_for_prompt(self, data: dict[str, Any], indent: int = 2) -> str:
        """
        Format data as JSON for inclusion in a prompt.

        Args:
            data: Data to format
            indent: Indentation level

        Returns:
            Formatted JSON string
        """
        return json.dumps(data, indent=indent, ensure_ascii=False)

    def parse_tool_calls(self, data: dict[str, Any]) -> list[ToolCallRequest] | None:
        """
        Check if response contains tool calls and parse them.

        Handles multiple formats:
        - {"tool_calls": [{"name": ..., "arguments": ...}]}
        - {"name": ..., "arguments": ...}  (single tool call)
        - {"name": ..., "parameters": ...} (single tool call)

        Args:
            data: Parsed JSON response

        Returns:
            List of ToolCallRequest if tool_calls present, None otherwise
        """
        # Check for tool_calls array
        if "tool_calls" in data:
            tool_calls = data["tool_calls"]
            if isinstance(tool_calls, list) and len(tool_calls) > 0:
                return [
                    ToolCallRequest(
                        name=tc.get("name", ""),
                        arguments=(
                            tc.get("arguments", {})
                            if "arguments" in tc
                            else tc.get("parameters", {})
                        ),
                    )
                    for tc in tool_calls
                    if isinstance(tc, dict) and "name" in tc
                ]

        # Check for single tool call format (name + arguments/parameters at top level)
        if "name" in data and ("arguments" in data or "parameters" in data):
            # Make sure this isn't a final result that happens to have these keys
            # Final results have "tasks" key
            if "tasks" not in data:
                return [
                    ToolCallRequest(
                        name=data["name"],
                        arguments=data.get("arguments", data.get("parameters", {})),
                    )
                ]

        return None

    def execute_tool_calls(
        self,
        tool_calls: list[ToolCallRequest],
        tools: list[ToolDefinition],
    ) -> list[ToolCallResult]:
        """
        Execute tool calls and return results.

        Args:
            tool_calls: List of tool calls to execute
            tools: Available tool definitions with handlers

        Returns:
            List of ToolCallResult with execution results
        """
        tool_map = {t.name: t for t in tools}
        results = []

        for tc in tool_calls:
            if tc.name not in tool_map:
                results.append(ToolCallResult(
                    name=tc.name,
                    arguments=tc.arguments,
                    result={"error": f"Unknown tool: {tc.name}"},
                ))
                continue

            tool = tool_map[tc.name]
            try:
                result = tool.handler(**tc.arguments)
                results.append(ToolCallResult(
                    name=tc.name,
                    arguments=tc.arguments,
                    result=result,
                ))
            except Exception as e:
                results.append(ToolCallResult(
                    name=tc.name,
                    arguments=tc.arguments,
                    result={"error": str(e)},
                ))

        return results

    def build_tool_results_message(self, results: list[ToolCallResult]) -> str:
        """
        Build JSON message with tool results to send back to LLM.

        Args:
            results: List of tool call results

        Returns:
            JSON string with tool results and instructions
        """
        return json.dumps({
            "tool_results": [
                {
                    "name": r.name,
                    "arguments": r.arguments,
                    "result": r.result,
                }
                for r in results
            ],
            "instructions": "Use these tool results to complete your response. Respond with ONLY a JSON object. If you need more tool calls, respond with {\"tool_calls\": [...]}. Otherwise respond with your final JSON result.",
        }, indent=2)

    def add_tools_to_request(
        self,
        request: dict[str, Any],
        tools: list[ToolDefinition],
    ) -> dict[str, Any]:
        """
        Add tool definitions to a request.

        Args:
            request: The request dictionary
            tools: Available tools

        Returns:
            Request with tools added
        """
        if tools:
            request["available_tools"] = [t.to_schema() for t in tools]
            request["tool_instructions"] = {
                "usage": "To use a tool, respond with JSON containing tool_calls array",
                "format": {"tool_calls": [{"name": "tool_name", "arguments": {"arg": "value"}}]},
                "after_tools": "After receiving tool_results, respond with your final JSON answer",
            }
        return request
