"""
VTK Sequential Thinking

RAG-based VTK Python code generation with prompt clarification,
task decomposition, and sequential code generation.

Public API:
- ClarificationSession: Evaluate and clarify user prompts
- DecompositionSession: Break prompts into VTK pipeline tasks
- GenerationSession: Generate VTK code step-by-step
- LLMClient: LLM client for API calls
- MCPClient: MCP client for VTK API access
- RAGClient: RAG client for VTK documentation retrieval
"""

__version__ = "0.1.0"

from vtk_sequential_thinking.config import AppConfig, load_config
from vtk_sequential_thinking.llm import LLMClient
from vtk_sequential_thinking.mcp import MCPClient
from vtk_sequential_thinking.prompt_clarification import Session as ClarificationSession
from vtk_sequential_thinking.rag import RAGClient
from vtk_sequential_thinking.sequential_generation import Session as GenerationSession
from vtk_sequential_thinking.task_decomposition import Session as DecompositionSession

__all__ = [
    "__version__",
    "AppConfig",
    "ClarificationSession",
    "DecompositionSession",
    "GenerationSession",
    "LLMClient",
    "RAGClient",
    "MCPClient",
    "load_config",
]
