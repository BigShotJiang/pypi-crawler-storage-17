"""
Configuration management for VTK Sequential Thinking.

Loads configuration from .env file and provides typed access.
"""

import os
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from dotenv import load_dotenv


class LLMProvider(Enum):
    """Supported LLM providers"""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    LOCAL = "local"


@dataclass
class LLMConfig:
    """LLM provider configuration"""
    provider: LLMProvider
    model: str
    api_key: str
    temperature: float = 0.1
    max_tokens: int = 4000
    api_base: str | None = None


@dataclass
class RAGConfig:
    """RAG retrieval configuration for code examples.

    API documentation is accessed via vtkapi-mcp tools instead.
    """
    qdrant_url: str = "http://localhost:6333"
    code_collection: str = "vtk_code"
    dense_model: str | None = None  # Uses vtk-rag default if None
    sparse_model: str | None = None  # Uses vtk-rag default if None
    top_k: int = 5
    use_hybrid: bool = True
    min_visibility_score: float = 0.0


@dataclass
class MCPConfig:
    """MCP server configuration for VTK API access."""
    api_docs_path: Path
    max_tool_iterations: int = 10


@dataclass
class AppConfig:
    """Application configuration for VTK code generation.

    Use load_config() to create instances - it populates all fields from environment.
    """
    llm: LLMConfig
    rag: RAGConfig
    mcp: MCPConfig
    app_name: str = "VTK Sequential Thinking"
    app_purpose: str = "Generate VTK Python code for scientific visualization"


def load_config(env_path: Path | None = None) -> AppConfig:
    """
    Load configuration from .env file.

    Args:
        env_path: Optional path to .env file. If None, searches current directory.

    Returns:
        AppConfig with values from environment
    """
    # Load .env file
    if env_path:
        load_dotenv(env_path)
    else:
        load_dotenv()

    # Determine LLM provider
    provider_str = os.getenv("LLM_PROVIDER", "anthropic").lower()
    try:
        provider = LLMProvider(provider_str)
    except ValueError:
        provider = LLMProvider.ANTHROPIC

    # Get provider-specific settings
    if provider == LLMProvider.OPENAI:
        llm_config = LLMConfig(
            provider=provider,
            model=os.getenv("OPENAI_MODEL", "gpt-4"),
            api_key=os.getenv("OPENAI_API_KEY", ""),
            temperature=float(os.getenv("OPENAI_TEMPERATURE", "0.1")),
            max_tokens=int(os.getenv("OPENAI_MAX_TOKENS", "4000")),
            api_base=os.getenv("OPENAI_API_BASE"),
        )
    elif provider == LLMProvider.ANTHROPIC:
        llm_config = LLMConfig(
            provider=provider,
            model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-20250514"),
            api_key=os.getenv("ANTHROPIC_API_KEY", ""),
            temperature=float(os.getenv("ANTHROPIC_TEMPERATURE", "0.1")),
            max_tokens=int(os.getenv("ANTHROPIC_MAX_TOKENS", "4000")),
        )
    elif provider == LLMProvider.GOOGLE:
        llm_config = LLMConfig(
            provider=provider,
            model=os.getenv("GOOGLE_MODEL", "gemini-pro"),
            api_key=os.getenv("GOOGLE_API_KEY", ""),
            temperature=float(os.getenv("GOOGLE_TEMPERATURE", "0.1")),
            max_tokens=int(os.getenv("GOOGLE_MAX_TOKENS", "4000")),
        )
    else:  # LOCAL
        llm_config = LLMConfig(
            provider=provider,
            model=os.getenv("LOCAL_MODEL", "llama2"),
            api_key=os.getenv("LOCAL_API_KEY", ""),
            temperature=float(os.getenv("LOCAL_TEMPERATURE", "0.1")),
            max_tokens=int(os.getenv("LOCAL_MAX_TOKENS", "4000")),
            api_base=os.getenv("LOCAL_API_BASE", "http://localhost:11434"),
        )

    # MCP configuration
    mcp_config = MCPConfig(
        api_docs_path=Path(os.getenv("VTK_API_DOCS_PATH", "data/vtk-python-docs.jsonl")),
        max_tool_iterations=int(os.getenv("MCP_MAX_TOOL_ITERATIONS", "10")),
    )

    # RAG configuration (code examples only - API docs via vtkapi-mcp)
    rag_config = RAGConfig(
        qdrant_url=os.getenv("QDRANT_URL", "http://localhost:6333"),
        code_collection=os.getenv("QDRANT_CODE_COLLECTION", "vtk_code"),
        dense_model=os.getenv("RAG_DENSE_MODEL"),
        sparse_model=os.getenv("RAG_SPARSE_MODEL"),
        top_k=int(os.getenv("RAG_TOP_K", "5")),
        use_hybrid=os.getenv("RAG_USE_HYBRID", "true").lower() == "true",
        min_visibility_score=float(os.getenv("RAG_MIN_VISIBILITY", "0.0")),
    )

    return AppConfig(
        llm=llm_config,
        rag=rag_config,
        mcp=mcp_config,
    )
