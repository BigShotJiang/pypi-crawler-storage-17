"""
RAG client for VTK code example retrieval.

Wraps vtk-rag package to search the vtk_code collection for code examples.
API documentation is accessed via vtkapi-mcp tools instead.
"""

from typing import Any

from vtk_rag.retrieval import Retriever as VTKRetriever

from vtk_sequential_thinking.config import AppConfig, load_config
from vtk_sequential_thinking.rag.models import (
    RetrievalConfig,
    SearchResult,
)
from vtk_sequential_thinking.rag.ranking import ResultRanker


class RAGClient:
    """Client for VTK code example retrieval.

    Searches the vtk_code collection for code examples showing VTK usage patterns.
    API documentation should be accessed via vtkapi-mcp tools instead.

    Example:
        ```python
        from vtk_sequential_thinking.rag import RAGClient

        client = RAGClient()
        results = client.search_code("create sphere visualization")
        for r in results:
            print(f"{r.class_name}: {r.synopsis}")
        ```
    """

    def __init__(self, app_config: AppConfig | None = None) -> None:
        """Initialize the RAG client.

        Args:
            app_config: Application configuration (loads from env if None)
        """
        self.config = app_config or load_config()

        # Initialize vtk-rag retriever
        self._retriever = VTKRetriever(
            qdrant_url=self.config.rag.qdrant_url,
            dense_model=self.config.rag.dense_model,
            sparse_model=self.config.rag.sparse_model,
        )

        # Initialize ranker with config
        self.retrieval_config = RetrievalConfig(
            top_k=self.config.rag.top_k,
            use_hybrid=self.config.rag.use_hybrid,
            min_visibility_score=self.config.rag.min_visibility_score,
        )
        self._ranker = ResultRanker(self.retrieval_config)

    @property
    def ranker(self) -> ResultRanker:
        """Access the result ranker."""
        return self._ranker

    def search_code(
        self,
        query: str,
        top_k: int | None = None,
        filters: dict[str, Any] | None = None,
    ) -> list[SearchResult]:
        """Search for code examples.

        Args:
            query: Search query
            top_k: Number of results (uses config if None)
            filters: Additional filters

        Returns:
            List of ranked SearchResult objects
        """
        top_k = top_k or self.retrieval_config.top_k

        # Build filters
        search_filters = filters or {}
        if self.retrieval_config.min_visibility_score > 0:
            search_filters["visibility_score"] = {
                "gte": self.retrieval_config.min_visibility_score
            }

        # Search using vtk-rag
        raw_results = self._retriever.search_code(
            query=query,
            limit=top_k * 2,  # Get more for ranking
            filters=search_filters if search_filters else None,
            hybrid=self.retrieval_config.use_hybrid,
        )

        # Convert to SearchResult
        results = [SearchResult.from_vtk_rag(r) for r in raw_results]

        # Rank and filter
        return self._ranker.filter_and_rank(results, top_k=top_k)
