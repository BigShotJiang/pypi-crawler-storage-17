"""
Result ranking and filtering for RAG retrieval.

Simple ranking based on:
- Semantic similarity score (from vector search)
- Visibility score (from chunk metadata)
"""

from vtk_sequential_thinking.rag.models import RetrievalConfig, SearchResult


class ResultRanker:
    """Ranks and filters retrieval results.

    Uses semantic similarity scores from the vector search,
    with optional visibility score boosting.
    """

    def __init__(self, config: RetrievalConfig | None = None) -> None:
        """Initialize the ranker.

        Args:
            config: Retrieval configuration (uses defaults if None)
        """
        self.config = config or RetrievalConfig()

    def rank(self, results: list[SearchResult]) -> list[SearchResult]:
        """Rank results by applying quality boosts and sorting.

        Args:
            results: List of search results to rank

        Returns:
            Sorted list with boosted_score set
        """
        for result in results:
            result.boosted_score = self._calculate_boosted_score(result)

        # Sort by boosted score descending
        return sorted(results, key=lambda r: r.boosted_score or 0.0, reverse=True)

    def filter_and_rank(
        self,
        results: list[SearchResult],
        top_k: int | None = None,
    ) -> list[SearchResult]:
        """Filter and rank results.

        Args:
            results: List of search results
            top_k: Number of results to return (uses config if None)

        Returns:
            Filtered and ranked results
        """
        top_k = top_k or self.config.top_k

        # Apply filters
        filtered = self._apply_filters(results)

        # Rank
        ranked = self.rank(filtered)

        # Return top_k
        return ranked[:top_k]

    def _calculate_boosted_score(self, result: SearchResult) -> float:
        """Calculate boosted score for a result.

        Args:
            result: Search result to score

        Returns:
            Boosted score (just visibility boost now)
        """
        score = result.score

        # Visibility boost (subtle) - higher visibility examples are more useful
        if result.visibility_score > 0.7:
            score *= 1.05  # +5% for high visibility

        return score

    def _apply_filters(self, results: list[SearchResult]) -> list[SearchResult]:
        """Apply configured filters to results.

        Args:
            results: Results to filter

        Returns:
            Filtered results
        """
        filtered = results

        # Filter by minimum visibility score
        if self.config.min_visibility_score > 0:
            filtered = [
                r for r in filtered
                if r.visibility_score >= self.config.min_visibility_score
            ]

        return filtered
