"""
Data models for RAG retrieval.

Defines search results and retrieval configuration.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class SearchResult(BaseModel):
    """Result from a RAG search.

    Attributes:
        chunk_id: Unique identifier for the chunk
        content: The actual content text
        score: Relevance score (0.0-1.0)
        content_type: Content type (currently always "code")
        class_name: VTK class name if applicable
        module: VTK module name
        synopsis: Brief description
        metadata: Additional metadata
        boosted_score: Score after quality boosting
    """
    chunk_id: str
    content: str
    score: float
    content_type: str = "code"
    class_name: str = ""
    module: str = ""
    synopsis: str = ""
    title: str = ""
    function_name: str = ""
    roles: list[str] = Field(default_factory=list)
    visibility_score: float = 0.5
    metadata: dict[str, Any] = Field(default_factory=dict)
    boosted_score: float | None = None

    @classmethod
    def from_vtk_rag(cls, result: Any) -> SearchResult:
        """Create SearchResult from vtk-rag SearchResult.

        Args:
            result: vtk_rag.retrieval.SearchResult object

        Returns:
            SearchResult instance
        """
        content_type = "code"

        # Get roles as list
        roles = getattr(result, "roles", [])
        if isinstance(roles, str):
            roles = [roles] if roles else []

        return cls(
            chunk_id=getattr(result, "chunk_id", "") or getattr(result, "example_id", ""),
            content=getattr(result, "content", "") or getattr(result, "description", ""),
            score=getattr(result, "score", 0.0),
            content_type=content_type,
            class_name=getattr(result, "class_name", "") or "",
            module=getattr(result, "module", "") or "",
            synopsis=getattr(result, "synopsis", "") or "",
            title=getattr(result, "title", "") or "",
            function_name=getattr(result, "function_name", "") or "",
            roles=roles,
            visibility_score=getattr(result, "visibility_score", 0.5) or 0.5,
            metadata=getattr(result, "metadata", {}) or {},
        )


class RetrievalConfig(BaseModel):
    """Configuration for retrieval operations.

    Attributes:
        top_k: Number of results to return
        use_hybrid: Use hybrid search (dense + sparse)
        min_visibility_score: Minimum visibility score filter
    """
    top_k: int = 5
    use_hybrid: bool = True
    min_visibility_score: float = 0.0
