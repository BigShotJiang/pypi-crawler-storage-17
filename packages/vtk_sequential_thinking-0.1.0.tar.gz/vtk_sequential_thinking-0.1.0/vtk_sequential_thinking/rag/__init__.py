"""
RAG (Retrieval Augmented Generation) interface for VTK Sequential Thinking.

Wraps vtk-rag package for VTK code example retrieval with quality boosting
and ranking.

Public API:
- RAGClient: Main client for retrieval operations
- SearchResult: Result from a search operation
- RetrievalConfig: Retrieval configuration
- ResultRanker: Ranking and filtering for retrieval results
"""

from vtk_sequential_thinking.rag.client import RAGClient
from vtk_sequential_thinking.rag.models import RetrievalConfig, SearchResult
from vtk_sequential_thinking.rag.ranking import ResultRanker

__all__ = [
    "RAGClient",
    "SearchResult",
    "RetrievalConfig",
    "ResultRanker",
]
