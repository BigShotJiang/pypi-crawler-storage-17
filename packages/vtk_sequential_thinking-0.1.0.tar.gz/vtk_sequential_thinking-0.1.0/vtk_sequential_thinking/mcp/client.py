"""VTK API client via MCP server.

Wraps vtkapi-mcp as a proper MCP server for class validation and suggestions.
"""

from __future__ import annotations

import json
import sys
from typing import Any

from mcp import StdioServerParameters

from vtk_sequential_thinking.config import AppConfig, load_config
from vtk_sequential_thinking.mcp.persistent_client import PersistentMCPClient


class MCPClient:
    """Client for VTK API queries via MCP.

    Wraps all vtkapi-mcp tools:
    - validate_class: Check if a class name is valid
    - get_class_info: Get full class documentation
    - get_class_doc: Get class docstring
    - get_class_synopsis: Get brief class summary
    - search_classes: Search for classes by name/keyword
    - get_class_role: Get class role (source, filter, mapper, etc.)
    - get_class_action_phrase: Get action phrase describing what class does
    - get_class_visibility: Get visibility/exposure level
    - get_method_info: Get method signature and details
    - get_method_doc: Get method docstring
    - get_module_classes: List all classes in a module
    - validate_import: Validate import statements
    """

    def __init__(self, app_config: AppConfig | None = None) -> None:
        """Initialize the VTK API client.

        Args:
            app_config: Application configuration (loads from env if None)
        """
        self.config = app_config or load_config()

        if not self.config.mcp.api_docs_path.exists():
            raise FileNotFoundError(
                f"VTK API docs not found at {self.config.mcp.api_docs_path}"
            )

        self._server = StdioServerParameters(
            command=sys.executable,
            args=["-m", "vtkapi_mcp", "--api-docs", str(self.config.mcp.api_docs_path)],
        )
        self._client = PersistentMCPClient(self._server)
        self._cache: dict[str, dict[str, Any]] = {}
        self.max_tool_iterations = self.config.mcp.max_tool_iterations

    def validate_class(self, class_name: str) -> bool:
        """Check if a VTK class name is valid.

        Args:
            class_name: The class name to validate (e.g., "vtkContourFilter")

        Returns:
            True if valid, False otherwise
        """
        info = self.get_class_info(class_name)
        if info is None:
            return False
        # MCP returns found=False for non-existent classes, or no 'error' key for valid ones
        if "found" in info:
            return info["found"]
        return "class_name" in info and "error" not in info

    def get_class_info(self, class_name: str) -> dict[str, Any] | None:
        """Get full class info from MCP.

        Args:
            class_name: The class name to look up

        Returns:
            Dict with class info, or None if not found
        """
        if class_name in self._cache:
            return self._cache[class_name]

        try:
            result = self._client.call_tool("vtk_get_class_info", {"class_name": class_name})
            if result and result.content:
                info = json.loads(result.content[0].text)
                self._cache[class_name] = info
                return info
        except Exception:
            pass
        return None

    def search_classes(self, query: str, limit: int = 5) -> list[str]:
        """Search for classes matching a query.

        Args:
            query: Search query (e.g., partial class name)
            limit: Maximum number of results

        Returns:
            List of matching class names
        """
        try:
            result = self._client.call_tool(
                "vtk_search_classes",
                {"query": query, "limit": limit}
            )
            if result and result.content:
                payload = json.loads(result.content[0].text)
                # MCP returns list of {class_name, module, description}
                if isinstance(payload, list):
                    return [item["class_name"] for item in payload if "class_name" in item]
                # Fallback for dict format
                return payload.get("classes", [])
        except Exception:
            pass
        return []

    def get_class_role(self, class_name: str) -> str | None:
        """Get class role (e.g., 'source', 'filter', 'mapper').

        Args:
            class_name: The class name to look up

        Returns:
            Role string or None
        """
        try:
            result = self._client.call_tool("vtk_get_class_role", {"class_name": class_name})
            if result and result.content:
                payload = json.loads(result.content[0].text)
                return payload.get("role")
        except Exception:
            pass
        return None

    def get_class_action_phrase(self, class_name: str) -> str | None:
        """Get action phrase describing what a class does.

        Args:
            class_name: The class name to look up

        Returns:
            Action phrase (e.g., "creates a sphere") or None
        """
        try:
            result = self._client.call_tool("vtk_get_class_action_phrase", {"class_name": class_name})
            if result and result.content:
                payload = json.loads(result.content[0].text)
                return payload.get("action_phrase")
        except Exception:
            pass
        return None

    def get_class_visibility(self, class_name: str) -> str | None:
        """Get visibility/exposure level of a class.

        Args:
            class_name: The class name to look up

        Returns:
            Visibility level or None
        """
        try:
            result = self._client.call_tool("vtk_get_class_visibility", {"class_name": class_name})
            if result and result.content:
                payload = json.loads(result.content[0].text)
                return payload.get("visibility")
        except Exception:
            pass
        return None

    def get_method_info(self, class_name: str, method_name: str) -> dict[str, str] | None:
        """Get information about a specific method of a class.

        Args:
            class_name: The class name
            method_name: The method name

        Returns:
            Dict with method info or None
        """
        try:
            result = self._client.call_tool(
                "vtk_get_method_info",
                {"class_name": class_name, "method_name": method_name}
            )
            if result and result.content:
                return json.loads(result.content[0].text)
        except Exception:
            pass
        return None

    def get_method_doc(self, class_name: str, method_name: str) -> str | None:
        """Get docstring for a specific method.

        Args:
            class_name: The class name
            method_name: The method name

        Returns:
            Method docstring or None
        """
        try:
            result = self._client.call_tool(
                "vtk_get_method_doc",
                {"class_name": class_name, "method_name": method_name}
            )
            if result and result.content:
                payload = json.loads(result.content[0].text)
                return payload.get("doc")
        except Exception:
            pass
        return None

    def get_module_classes(self, module: str) -> list[str]:
        """Get all classes in a module.

        Args:
            module: The module name (e.g., "vtkFiltersSources")

        Returns:
            List of class names in the module
        """
        try:
            result = self._client.call_tool("vtk_get_module_classes", {"module": module})
            if result and result.content:
                payload = json.loads(result.content[0].text)
                return payload.get("classes", [])
        except Exception:
            pass
        return []

    def get_class_doc(self, class_name: str) -> str | None:
        """Get the class documentation string.

        Args:
            class_name: The class name to look up

        Returns:
            Class docstring or None
        """
        try:
            result = self._client.call_tool("vtk_get_class_doc", {"class_name": class_name})
            if result and result.content:
                payload = json.loads(result.content[0].text)
                return payload.get("doc")
        except Exception:
            pass
        return None

    def get_class_synopsis(self, class_name: str) -> str | None:
        """Get a brief synopsis/summary of what a class does.

        Args:
            class_name: The class name to look up

        Returns:
            Brief synopsis or None
        """
        try:
            result = self._client.call_tool("vtk_get_class_synopsis", {"class_name": class_name})
            if result and result.content:
                payload = json.loads(result.content[0].text)
                return payload.get("synopsis")
        except Exception:
            pass
        return None

    def validate_import(self, import_statement: str) -> dict[str, Any] | None:
        """Validate if a VTK import statement is correct.

        Args:
            import_statement: The import statement to validate
                (e.g., "from vtkmodules.vtkFiltersSources import vtkSphereSource")

        Returns:
            Dict with validation result and suggestions, or None on error
        """
        try:
            result = self._client.call_tool(
                "vtk_validate_import",
                {"import_statement": import_statement}
            )
            if result and result.content:
                return json.loads(result.content[0].text)
        except Exception:
            pass
        return None

    def close(self) -> None:
        """Close the MCP client connection."""
        self._client.close()

    def get_tool_definitions(self) -> list:
        """Get tool definitions for LLM tool calling.

        Returns:
            List of ToolDefinition objects for JSON protocol
        """
        from vtk_sequential_thinking.llm.json_protocol import ToolDefinition

        return [
            # === Validation Tools ===
            ToolDefinition(
                name="validate_vtk_class",
                description="Check if a VTK class name exists. Returns {valid: true/false}.",
                parameters={
                    "type": "object",
                    "properties": {
                        "class_name": {
                            "type": "string",
                            "description": "VTK class name (e.g., 'vtkContourFilter')",
                        },
                    },
                    "required": ["class_name"],
                },
                handler=lambda class_name: {"valid": self.validate_class(class_name)},
            ),
            ToolDefinition(
                name="validate_vtk_classes_batch",
                description="Validate multiple VTK class names at once. Returns {results: {class_name: valid, ...}} for each class.",
                parameters={
                    "type": "object",
                    "properties": {
                        "class_names": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of VTK class names to validate (e.g., ['vtkContourFilter', 'vtkPolyDataMapper'])",
                        },
                    },
                    "required": ["class_names"],
                },
                handler=lambda class_names: {
                    "results": {name: self.validate_class(name) for name in class_names}
                },
            ),
            ToolDefinition(
                name="validate_vtk_import",
                description="Validate a VTK import statement. Returns validation result with suggestions if invalid.",
                parameters={
                    "type": "object",
                    "properties": {
                        "import_statement": {
                            "type": "string",
                            "description": "Import statement (e.g., 'from vtkmodules.vtkFiltersSources import vtkSphereSource')",
                        },
                    },
                    "required": ["import_statement"],
                },
                handler=lambda import_statement: self.validate_import(import_statement) or {"error": "Validation failed"},
            ),

            # === Class Information Tools ===
            ToolDefinition(
                name="get_vtk_class_info",
                description="Get full class info including module path for imports, methods, and description.",
                parameters={
                    "type": "object",
                    "properties": {
                        "class_name": {
                            "type": "string",
                            "description": "VTK class name (e.g., 'vtkContourFilter')",
                        },
                    },
                    "required": ["class_name"],
                },
                handler=lambda class_name: self.get_class_info(class_name) or {"error": f"Class {class_name} not found"},
            ),
            ToolDefinition(
                name="get_vtk_class_synopsis",
                description="Get brief one-line summary of what a class does. Useful for comparing multiple classes.",
                parameters={
                    "type": "object",
                    "properties": {
                        "class_name": {
                            "type": "string",
                            "description": "VTK class name (e.g., 'vtkContourFilter')",
                        },
                    },
                    "required": ["class_name"],
                },
                handler=lambda class_name: {"synopsis": self.get_class_synopsis(class_name)} if self.get_class_synopsis(class_name) else {"error": f"Class {class_name} not found"},
            ),
            ToolDefinition(
                name="get_vtk_class_doc",
                description="Get full class documentation string.",
                parameters={
                    "type": "object",
                    "properties": {
                        "class_name": {
                            "type": "string",
                            "description": "VTK class name (e.g., 'vtkContourFilter')",
                        },
                    },
                    "required": ["class_name"],
                },
                handler=lambda class_name: {"doc": self.get_class_doc(class_name)} if self.get_class_doc(class_name) else {"error": f"Class {class_name} not found"},
            ),
            ToolDefinition(
                name="get_vtk_class_role",
                description="Get class role: 'source', 'reader', 'filter', 'mapper', 'actor', 'writer', etc. Useful for understanding pipeline position.",
                parameters={
                    "type": "object",
                    "properties": {
                        "class_name": {
                            "type": "string",
                            "description": "VTK class name (e.g., 'vtkContourFilter')",
                        },
                    },
                    "required": ["class_name"],
                },
                handler=lambda class_name: {"role": self.get_class_role(class_name)} if self.get_class_role(class_name) else {"error": f"Class {class_name} not found"},
            ),

            # === Method Information Tools ===
            ToolDefinition(
                name="get_vtk_method_info",
                description="Get method signature, parameters, and description. Use to understand how to call a method.",
                parameters={
                    "type": "object",
                    "properties": {
                        "class_name": {
                            "type": "string",
                            "description": "VTK class name (e.g., 'vtkContourFilter')",
                        },
                        "method_name": {
                            "type": "string",
                            "description": "Method name (e.g., 'SetValue', 'SetInputConnection')",
                        },
                    },
                    "required": ["class_name", "method_name"],
                },
                handler=lambda class_name, method_name: self.get_method_info(class_name, method_name) or {"error": f"Method {method_name} not found on {class_name}"},
            ),
            ToolDefinition(
                name="get_vtk_method_doc",
                description="Get full method documentation string.",
                parameters={
                    "type": "object",
                    "properties": {
                        "class_name": {
                            "type": "string",
                            "description": "VTK class name (e.g., 'vtkContourFilter')",
                        },
                        "method_name": {
                            "type": "string",
                            "description": "Method name (e.g., 'SetValue')",
                        },
                    },
                    "required": ["class_name", "method_name"],
                },
                handler=lambda class_name, method_name: {"doc": self.get_method_doc(class_name, method_name)} if self.get_method_doc(class_name, method_name) else {"error": f"Method {method_name} not found on {class_name}"},
            ),

            # === Search and Discovery Tools ===
            ToolDefinition(
                name="search_vtk_classes",
                description="Search for VTK classes by keyword. Returns list of matching class names with brief descriptions.",
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query (e.g., 'contour', 'reader', 'image')",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum results (default: 10)",
                            "default": 10,
                        },
                    },
                    "required": ["query"],
                },
                handler=lambda query, limit=10: {"classes": self.search_classes(query, limit=limit)},
            ),
            ToolDefinition(
                name="get_vtk_module_classes",
                description="List all classes in a VTK module. Use to explore what's available.",
                parameters={
                    "type": "object",
                    "properties": {
                        "module": {
                            "type": "string",
                            "description": "Module name (e.g., 'vtkFiltersCore', 'vtkIOXML')",
                        },
                    },
                    "required": ["module"],
                },
                handler=lambda module: {"classes": self.get_module_classes(module)} if self.get_module_classes(module) else {"error": f"Module {module} not found"},
            ),
        ]
