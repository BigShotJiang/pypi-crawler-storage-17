"""Persistent MCP client that maintains a single stdio session across multiple tool calls."""

from __future__ import annotations

import asyncio
import atexit
import threading
from concurrent.futures import Future
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.types import CallToolResult


class PersistentMCPClient:
    """Thin wrapper that keeps a single MCP stdio session alive across calls."""

    def __init__(self, server: StdioServerParameters) -> None:
        """Initialize the client and start the MCP session in a background thread.

        Args:
            server: MCP server parameters for stdio communication.
        """
        self._server = server
        self._loop = asyncio.new_event_loop()
        self._ready = threading.Event()
        self._closed = threading.Event()
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        self._ready.wait()
        atexit.register(self.close)

    def _run_loop(self) -> None:
        """Entry point for the background thread."""
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._loop_main())
        self._loop.close()

    async def _loop_main(self) -> None:
        """Main coroutine: start MCP session, process requests, clean up."""
        self._queue: asyncio.Queue[tuple[str | None, dict | None, Future[CallToolResult | None]]] = asyncio.Queue()
        self._stdio_cm = stdio_client(self._server)
        read, write = await self._stdio_cm.__aenter__()
        try:
            self._session_cm = ClientSession(read, write)
            self._session = await self._session_cm.__aenter__()
            await self._session.initialize()
            self._ready.set()

            while True:
                name, payload, future = await self._queue.get()
                if name is None:
                    if future:
                        future.set_result(None)
                    break
                try:
                    result = await self._session.call_tool(name, payload)
                except Exception as exc:
                    future.set_exception(exc)
                else:
                    future.set_result(result)
        finally:
            if hasattr(self, "_session_cm"):
                await self._session_cm.__aexit__(None, None, None)
            await self._stdio_cm.__aexit__(None, None, None)
            self._closed.set()

    def call_tool(self, name: str, arguments: dict[str, Any]) -> CallToolResult:
        """Call an MCP tool and return the result (blocks until complete)."""
        if self._closed.is_set():
            raise RuntimeError("MCP client is closed")
        result_future: Future[CallToolResult] = Future()
        asyncio.run_coroutine_threadsafe(
            self._queue.put((name, arguments, result_future)), self._loop
        ).result()
        return result_future.result()

    def close(self) -> None:
        """Shut down the MCP session and join the background thread."""
        if self._closed.is_set():
            return
        sentinel_done: Future[None] = Future()
        asyncio.run_coroutine_threadsafe(
            self._queue.put((None, None, sentinel_done)), self._loop
        ).result()
        sentinel_done.result()
        self._thread.join()
        self._closed.set()
