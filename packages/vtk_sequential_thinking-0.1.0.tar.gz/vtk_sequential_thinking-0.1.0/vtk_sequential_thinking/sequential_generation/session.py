"""
Session management for sequential generation.

Provides the main Session class for VTK code generation workflow.
Receives Task objects from task_decomposition and generates code for each task.
"""

from __future__ import annotations

from vtk_sequential_thinking.config import AppConfig, load_config
from vtk_sequential_thinking.llm.client import LLMClient
from vtk_sequential_thinking.mcp import MCPClient
from vtk_sequential_thinking.rag import RAGClient
from vtk_sequential_thinking.sequential_generation.code_assembler import CodeAssembler
from vtk_sequential_thinking.sequential_generation.generator import Generator
from vtk_sequential_thinking.sequential_generation.models import (
    PipelineResult,
    TaskResult,
)
from vtk_sequential_thinking.task_decomposition.models import Task


class Session:
    """Session for VTK code generation.

    Receives Task objects from task_decomposition and generates code for each task,
    tracking variables and data types between tasks.

    Example:
        ```python
        from vtk_sequential_thinking.sequential_generation import Session

        # Generate code from tasks (tasks come from task_decomposition)
        session = Session.from_config()
        result = session.generate(tasks=tasks, original_prompt="...")
        print(result.code)
        ```
    """

    def __init__(
        self,
        llm_client: LLMClient | None = None,
        mcp_client: MCPClient | None = None,
        rag_client: RAGClient | None = None,
        config: AppConfig | None = None,
        enable_validation: bool = True,
    ) -> None:
        """Initialize the session.

        Args:
            llm_client: LLM client for generation (creates one if None)
            mcp_client: MCP client for VTK API access (creates one if None)
            rag_client: RAG client for retrieval (creates one if None)
            config: Application configuration (loads from env if None)
            enable_validation: Whether to enable code validation
        """
        self.config = config or load_config()
        self.llm_client = llm_client or LLMClient(app_config=self.config)
        self.mcp_client = mcp_client or MCPClient(app_config=self.config)
        self.rag_client = rag_client or RAGClient(app_config=self.config)

        self.enable_validation = enable_validation

        # Initialize generator
        self.generator = Generator(
            llm_client=self.llm_client,
            mcp_client=self.mcp_client,
            rag_client=self.rag_client,
        )

    @classmethod
    def from_config(
        cls,
        config: AppConfig | None = None,
        llm_client: LLMClient | None = None,
        mcp_client: MCPClient | None = None,
        rag_client: RAGClient | None = None,
    ) -> Session:
        """Create session from configuration.

        Args:
            config: Application configuration (loads from env if None)
            llm_client: Optional shared LLM client
            mcp_client: Optional shared MCP client
            rag_client: Optional shared RAG client

        Returns:
            Configured Session instance
        """
        config = config or load_config()
        return cls(
            llm_client=llm_client,
            mcp_client=mcp_client,
            rag_client=rag_client,
            config=config,
        )

    def generate(
        self,
        tasks: list[Task],
        original_prompt: str = "",
    ) -> PipelineResult:
        """Generate VTK code from tasks.

        Receives tasks from task_decomposition and generates code for each,
        tracking variables and data types between tasks.

        Args:
            tasks: List of Task objects from task_decomposition
            original_prompt: The original user prompt

        Returns:
            PipelineResult with assembled code and proper imports
        """
        assembler = CodeAssembler(mcp_client=self.mcp_client)
        task_results: list[TaskResult] = []

        for i, task in enumerate(tasks):
            try:
                task_result = self.generator.generate(task)
            except Exception as e:
                print(f"Task code generation failed: {e}")
                task_result = TaskResult(
                    code=f"# Error generating code for task: {task.description}\n# {e}",
                    understanding=f"Generation failed: {e}",
                    variables=[],
                    vtk_classes_used=[],
                )

            assembler.add_snippet(
                code=task_result.code,
                variables=task_result.variables,
                vtk_classes_used=task_result.vtk_classes_used,
            )

            task_results.append(task_result)

        # Assemble final code with proper imports
        final_code = assembler.assemble()

        return PipelineResult(
            query=original_prompt,
            code=final_code,
            task_results=task_results,
        )
