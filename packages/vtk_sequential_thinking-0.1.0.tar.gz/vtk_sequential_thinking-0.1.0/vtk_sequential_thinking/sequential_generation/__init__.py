"""
Sequential Generation for VTK Code Generation.

Receives Task objects from task_decomposition, generates code for each task,
tracks variables and data types between tasks, and assembles a complete program.
"""

from vtk_sequential_thinking.sequential_generation.code_assembler import CodeAssembler
from vtk_sequential_thinking.sequential_generation.models import (
    PipelineResult,
    TaskResult,
    VariableInfo,
)
from vtk_sequential_thinking.sequential_generation.session import Session

__all__ = [
    "CodeAssembler",
    "PipelineResult",
    "Session",
    "TaskResult",
    "VariableInfo",
]
