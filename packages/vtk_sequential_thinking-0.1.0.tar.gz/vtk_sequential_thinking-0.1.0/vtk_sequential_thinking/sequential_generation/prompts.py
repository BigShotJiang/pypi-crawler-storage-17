"""
Prompt templates for sequential pipeline.

Centralized prompts for Task-based code generation.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from vtk_sequential_thinking.llm.json_protocol import ToolDefinition
    from vtk_sequential_thinking.task_decomposition.models import Task


# =============================================================================
# CODE GENERATION PROMPTS
# =============================================================================

GENERATION_SYSTEM_PROMPT = """You are a VTK Python expert generating code for a specific task.

CRITICAL RULES:
1. Generate ONLY the code for this specific task - NO IMPORTS
2. Use the input variable from context if provided
3. Create descriptive variable names
4. Connect to the pipeline using SetInputConnection/GetOutputPort

TOOL USAGE:
You have access to VTK API tools. Use them to:
- Verify classes not in the pre-validated list (validate_vtk_class)
- Get method signatures before calling them (get_vtk_method_info)
- Search for classes if unsure (search_vtk_classes)
- Get class synopsis to understand what a class does (get_vtk_class_synopsis)

To call a tool, respond with:
{{"tool_calls": [{{"name": "tool_name", "arguments": {{"arg": "value"}}}}]}}

When done with tools, respond with final JSON:
{{
    "understanding": "Brief explanation of what this code does",
    "code": "The Python code for this task (NO IMPORTS)",
    "variables": [
        {{
            "name": "variable_name",
            "vtk_class": "vtkClassName",
            "output_type": "vtkDataType (e.g., vtkPolyData)",
            "output_port": true
        }}
    ],
    "vtk_classes_used": ["List", "of", "ALL", "VTK", "classes", "used", "in", "code"]
}}"""

GENERATION_PROMPT = """Task {task_id}: {description}
Task Type: {task_type}
Depends On: {depends_on}

PRE-VALIDATED VTK CLASSES (already verified, safe to use):
{validated_classes}

Input from dependent tasks:
{depends_on_info}

Use this input variable: {input_variable}
Input data type: {input_type}

RAG examples (code retrieved from VTK corpus matching this task's query):
{rag_examples}

Generate the code for this task. Use tools if needed to verify new vtk classes or
vtk class methods."""


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_prompt(
    task: "Task",
    task_outputs: dict[str, dict[str, Any]],
    rag_examples: list[dict[str, Any]],
    tools: list["ToolDefinition"],
    conversation: list[str],
) -> str:
    """Build full user prompt for task code generation.

    On first call (empty conversation), builds the initial request with tools.
    On subsequent calls, joins conversation history into full prompt.

    Args:
        task: Task to generate code for
        task_outputs: Dict of task_id -> output info from previous tasks
        rag_examples: List of RAG result dicts from corpus query
        tools: Tool definitions from MCP client
        conversation: Conversation history (mutated - initial request appended on first call)

    Returns:
        Full prompt string to send to LLM
    """
    # Build initial request on first call
    if not conversation:
        input_variable, input_type, depends_on_info = _build_dependency_info(task, task_outputs)
        user_prompt = GENERATION_PROMPT.format(
            task_id=task.id,
            description=task.description,
            task_type=task.task_type,
            depends_on=", ".join(task.depends_on) if task.depends_on else "None",
            validated_classes=_format_validated_classes(task),
            depends_on_info=depends_on_info,
            input_variable=input_variable or "N/A (create your own source)",
            input_type=input_type or "N/A",
            rag_examples=format_rag_examples(rag_examples),
        )

        request_dict: dict[str, Any] = {
            "request": user_prompt,
            "available_tools": _format_tools(tools),
        }
        conversation.append(json.dumps(request_dict, indent=2))

    return "\n\n".join(conversation)


def _format_tools(tools: list["ToolDefinition"]) -> list[dict[str, Any]]:
    """Format tool definitions for prompt.

    Args:
        tools: Tool definitions from MCP client

    Returns:
        List of tool dicts with name, description, parameters
    """
    return [
        {
            "name": tool.name,
            "description": tool.description,
            "parameters": tool.parameters,
        }
        for tool in tools
    ]


def _format_validated_classes(task: "Task") -> str:
    """Format validated VTK classes for prompt.

    Args:
        task: Task containing vtk_classes list

    Returns:
        Comma-separated string of classes or "None"
    """
    return ", ".join(task.vtk_classes) if task.vtk_classes else "None"


def _build_dependency_info(
    task: "Task",
    task_outputs: dict[str, dict[str, Any]],
) -> tuple[str, str, str]:
    """Build dependency information for prompt.

    Args:
        task: Task to build dependency info for
        task_outputs: Dict of task_id -> output info from previous tasks

    Returns:
        Tuple of (input_variable, input_type, depends_on_info)
    """
    dependent_outputs = [
        {"task_id": dep_id, **task_outputs[dep_id]}
        for dep_id in task.depends_on
        if dep_id in task_outputs
    ]

    if dependent_outputs:
        primary_dep = dependent_outputs[0]
        input_variable = primary_dep.get("output_variable", "")
        input_type = primary_dep.get("output_type", "")
        depends_on_info = "\n".join([
            f"  - {d['task_id']}: output_variable={d.get('output_variable', 'unknown')}, type={d.get('output_type', 'unknown')}"
            for d in dependent_outputs
        ])
    else:
        input_variable = ""
        input_type = ""
        depends_on_info = "  None (this is the first task)"

    return input_variable, input_type, depends_on_info


def format_rag_examples(rag_results: list[dict[str, Any]], max_examples: int = 5) -> str:
    """Format RAG retrieval results for prompt.

    Args:
        rag_results: List of RAG result dicts from corpus query
        max_examples: Maximum number of examples to include

    Returns:
        Formatted examples string
    """
    if not rag_results:
        return "No examples found"

    lines = []
    for result in rag_results[:max_examples]:
        class_name = result.get("class_name", "unknown")
        content = result.get("content", "")
        lines.append(f"Example ({class_name}):\n{content}")

    return "\n\n".join(lines)
