"""
Code generator for sequential pipeline.

Generates VTK code using JSON protocol with tool calling for VTK API verification.
"""

from __future__ import annotations

import json
from typing import Any

from vtk_sequential_thinking.llm.json_protocol import JSONProtocol
from vtk_sequential_thinking.sequential_generation.models import TaskResult
from vtk_sequential_thinking.sequential_generation.prompts import (
    GENERATION_SYSTEM_PROMPT,
    build_prompt,
)
from vtk_sequential_thinking.task_decomposition.models import Task


class Generator:
    """Generates VTK code with tool-based verification.

    Uses JSON protocol with VTK API tools for class/method verification.
    Tools are provided via mcp_client.get_tool_definitions().
    """

    def __init__(
        self,
        llm_client: Any,
        mcp_client: Any,
        rag_client: Any,
    ) -> None:
        """Initialize the code generator.

        Args:
            llm_client: LLM client for code generation
            mcp_client: MCP client for VTK API tools (provides tools and max_tool_iterations)
            rag_client: RAG client for code examples retrieval
        """
        self.llm_client = llm_client
        self.mcp_client = mcp_client
        self.rag_client = rag_client
        self.protocol = JSONProtocol()
        self.tools = mcp_client.get_tool_definitions()

        # Track task outputs for dependency resolution
        self.task_outputs: dict[str, dict[str, Any]] = {}

    def generate(self, task: Task) -> TaskResult:
        """Generate code for a task.

        Retrieves code examples via RAG, builds prompts, runs tool loop, returns result.
        Uses internally tracked task_outputs for dependency context.

        Args:
            task: Task to generate code for

        Returns:
            TaskResult with code, understanding, variables, and vtk_classes_used
        """
        rag_examples, chunk_ids = self._retrieve_rag_examples(task.search_query)
        conversation: list[str] = []

        for iteration in range(self.mcp_client.max_tool_iterations):
            response = self.llm_client.generate(
                prompt=build_prompt(
                    task, self.task_outputs, rag_examples, self.tools, conversation
                ),
                system=GENERATION_SYSTEM_PROMPT,
                temperature=0.1,
            )

            try:
                result, tool_calls, data = self.protocol.decode_or_tool_calls(
                    response, TaskResult
                )
            except ValueError as e:
                raise ValueError(f"Failed to parse JSON on iteration {iteration}: {e}")

            if tool_calls is None:
                if result.variables:
                    result = result.model_copy(
                        update={
                            "variables": [
                                v.model_copy(update={"task_id": task.id})
                                for v in result.variables
                            ],
                            "chunk_ids_used": chunk_ids,
                        }
                    )
                else:
                    result = result.model_copy(update={"chunk_ids_used": chunk_ids})

                self.task_outputs[task.id] = {
                    "output_variable": result.variables[0].name if result.variables else "",
                    "output_type": result.variables[0].output_type if result.variables else "",
                    "vtk_classes": result.vtk_classes_used,
                }
                return result

            # Add LLM's tool call request to conversation
            conversation.append(f"LLM response:\n{json.dumps(data, indent=2)}")

            # Execute tool calls
            results = self.protocol.execute_tool_calls(tool_calls, self.tools)

            # Add tool results to conversation
            tool_results_json = self.protocol.build_tool_results_message(results)
            conversation.append(f"Tool results:\n{tool_results_json}")

        raise ValueError(f"Max tool iterations ({self.mcp_client.max_tool_iterations}) exceeded")

    def _retrieve_rag_examples(self, search_query: str) -> tuple[list[dict[str, Any]], list[str]]:
        """Retrieve code examples via RAG.

        Args:
            search_query: Query string for RAG search

        Returns:
            Tuple of (rag_examples list, chunk_ids list)
        """
        if not search_query:
            return [], []

        results = self.rag_client.search_code(search_query)
        rag_examples = [
            {
                "chunk_id": r.chunk_id,
                "content": r.content,
                "class_name": r.class_name,
                "synopsis": r.synopsis,
                "roles": r.roles,
            }
            for r in results
        ]
        chunk_ids = [r.chunk_id for r in results if r.chunk_id]
        return rag_examples, chunk_ids
