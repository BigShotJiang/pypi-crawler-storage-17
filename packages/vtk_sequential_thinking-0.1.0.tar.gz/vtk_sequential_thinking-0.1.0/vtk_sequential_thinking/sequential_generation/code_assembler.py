"""
Code assembler for sequential pipeline.

Assembles code snippets from multiple tasks into a complete VTK program.
Handles:
- Import generation via MCP (modular imports only)
- Required rendering imports for interactive visualizations
- Variable tracking across tasks
"""

from __future__ import annotations

from typing import Any

from vtk_sequential_thinking.sequential_generation.models import VariableInfo

# Required imports for interactive rendering
_RENDERING_IMPORTS = [
    "import vtkmodules.vtkRenderingOpenGL2  # Required for OpenGL rendering",
    "import vtkmodules.vtkInteractionStyle  # Required for interactor styles",
]


class CodeAssembler:
    """Assembles code snippets into a complete VTK program.

    Handles import consolidation, variable tracking, and code formatting.
    Uses MCP client to look up correct module paths for imports.
    """

    def __init__(self, mcp_client: Any) -> None:
        """Initialize the code assembler.

        Args:
            mcp_client: MCP client for VTK class module lookups (required)
        """
        self.mcp_client = mcp_client
        self.variables: list[VariableInfo] = []
        self.code_snippets: list[str] = []
        self.vtk_classes: set[str] = set()

    def add_snippet(
        self,
        code: str,
        variables: list[VariableInfo] | None = None,
        vtk_classes_used: list[str] | None = None,
    ) -> None:
        """Add a code snippet from a task.

        Args:
            code: The code snippet (without imports)
            variables: Variables created by this snippet (already have task_id set)
            vtk_classes_used: VTK classes used (already validated via MCP during generation)
        """
        self.code_snippets.append(code)
        if variables:
            self.variables.extend(variables)
        if vtk_classes_used:
            self.vtk_classes.update(vtk_classes_used)

    def assemble(self) -> str:
        """Assemble all snippets into a complete program.

        Returns:
            Complete VTK Python program with imports at top
        """
        all_code = "\n\n".join(self.code_snippets)

        # Check if rendering imports needed (OpenGL backend and interactor styles)
        has_rendering = any(cls in self.vtk_classes for cls in
            ["vtkRenderWindow", "vtkRenderWindowInteractor"])

        import_lines = []

        if has_rendering:
            import_lines.extend(_RENDERING_IMPORTS)
            import_lines.append("")  # Blank line

        # Build imports grouped by module using MCP
        by_module: dict[str, list[str]] = {}
        for cls in sorted(self.vtk_classes):
            module = self._get_module_for_class(cls)
            if module:
                if module not in by_module:
                    by_module[module] = []
                by_module[module].append(cls)

        # Generate import statements
        for module in sorted(by_module.keys()):
            classes = sorted(set(by_module[module]))
            import_lines.append(f"from {module} import {', '.join(classes)}")

        # Combine imports and code
        imports_section = "\n".join(import_lines)

        # Clean up code - remove any stray imports that might be in snippets
        clean_code = self._remove_imports_from_code(all_code)

        return f"{imports_section}\n\n{clean_code.strip()}\n"

    def _get_module_for_class(self, class_name: str) -> str | None:
        """Get the module path for a VTK class via MCP.

        Args:
            class_name: VTK class name

        Returns:
            Module path (e.g., 'vtkmodules.vtkFiltersSources') or None
        """
        if not self.mcp_client:
            return None

        try:
            class_info = self.mcp_client.get_class_info(class_name)
            if class_info and "module" in class_info:
                module = class_info["module"]
                # Ensure it has vtkmodules prefix
                if not module.startswith("vtkmodules."):
                    module = f"vtkmodules.{module}"
                return module
        except Exception:
            pass
        return None

    def _remove_imports_from_code(self, code: str) -> str:
        """Remove import statements from code body.

        Args:
            code: Code that may contain imports

        Returns:
            Code with imports removed
        """
        lines = code.split("\n")
        result = []

        for line in lines:
            stripped = line.strip()
            if stripped.startswith("import ") or stripped.startswith("from "):
                continue
            result.append(line)

        return "\n".join(result)
