"""
Data models for sequential pipeline.

Defines the core data structures for task-based code generation.
The pipeline receives Task objects from task_decomposition and generates
code snippets that are assembled into a complete program.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class VariableInfo(BaseModel):
    """Information about a variable in the generated code.

    Tracks variables across task boundaries for proper pipeline connections.

    Attributes:
        name: Variable name (e.g., "reader", "mapper", "actor")
        vtk_class: VTK class type (e.g., "vtkSTLReader", "vtkPolyDataMapper")
        output_type: Output data type (e.g., "vtkPolyData", "vtkUnstructuredGrid")
        output_port: Whether this has an output port for pipeline connection
        task_id: ID of the task that created this variable
    """
    name: str
    vtk_class: str
    output_type: str = ""
    output_port: bool = True
    task_id: str = ""


class TaskResult(BaseModel):
    """Result from generating code for a single task.

    This is the output model from CodeGenerator.generate_task().
    The LLM returns this structure directly in JSON.
    """
    code: str
    understanding: str
    variables: list[VariableInfo]
    vtk_classes_used: list[str]
    chunk_ids_used: list[str] = Field(default_factory=list)


class PipelineResult(BaseModel):
    """Complete pipeline result.

    Attributes:
        query: Original user query
        code: Final assembled code
        task_results: List of per-task generation results
        validation_passed: Whether final validation passed
    """
    query: str
    code: str
    task_results: list["TaskResult"] = Field(default_factory=list)
    validation_passed: bool = True
