"""
CLI for VTK Sequential Thinking.

Commands:
    evaluate  - Evaluate a prompt for clarity without generating code
    query     - Submit a prompt for VTK code generation (interactive clarification)
    decompose - Decompose a synthesized prompt into VTK pipeline tasks
    generate  - Generate VTK Python code from a saved decomposition JSON
    pipeline  - Full pipeline: clarify prompt, decompose into tasks, then generate code
    tools     - List available VTK API tools
    version   - Show version information
"""

import time
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table

from vtk_sequential_thinking import (
    ClarificationSession,
    DecompositionSession,
    GenerationSession,
    LLMClient,
    MCPClient,
    __version__,
    load_config,
)
from vtk_sequential_thinking.prompt_clarification.clarifier import Clarifier
from vtk_sequential_thinking.prompt_clarification.models import (
    CATEGORIES,
    ClarifyingQuestion,
)
from vtk_sequential_thinking.prompt_clarification.models import (
    SessionResponse as ClarificationSessionResponse,
)
from vtk_sequential_thinking.task_decomposition import TaskAddition, TaskModification
from vtk_sequential_thinking.task_decomposition.models import (
    DecompositionResult,
    Task,
)
from vtk_sequential_thinking.task_decomposition.models import (
    SessionResponse as DecompositionSessionResponse,
)

app = typer.Typer(
    name="vtk-st",
    help="VTK Sequential Thinking - RAG-based VTK code generation",
    add_completion=False,
)
console = Console()


@app.command()
def evaluate(
    prompt: str = typer.Argument(..., help="Prompt to evaluate for clarity"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
 ) -> None:
    """
    Evaluate a prompt for clarity without generating code.

    Analyzes the prompt and reports if it has sufficient detail for VTK code generation.
    """
    config = load_config()
    llm_client = LLMClient(app_config=config)
    clarifier = Clarifier(llm_client=llm_client, config=config)

    with console.status("Evaluating prompt clarity..."):
        result = clarifier.evaluate(prompt)

    if json_output:
        console.print(result.model_dump_json(indent=2))
        return

    # Rich output
    status = "[green]✓ CLEAR[/green]" if result.is_clear else "[yellow]⚠ NEEDS CLARIFICATION[/yellow]"

    console.print(Panel(
        f"[bold]Prompt:[/bold] {prompt}\n\n"
        f"[bold]Status:[/bold] {status}\n"
        f"[bold]Confidence:[/bold] {result.confidence:.0%}\n\n"
        f"[bold]Reasoning:[/bold] {result.reasoning}",
        title="Prompt Clarity Evaluation",
    ))

    if not result.is_clear and result.clarifying_questions:
        table = Table(title="Clarifying Questions")
        table.add_column("ID", style="cyan")
        table.add_column("Question", style="white")
        table.add_column("Category", style="green")
        table.add_column("Importance", style="yellow")

        for q in result.clarifying_questions:
            table.add_row(q.id, q.question, q.category, q.importance)

        console.print(table)


@app.command()
def query(
    prompt: str = typer.Argument(..., help="VTK code generation prompt"),
    interactive: bool = typer.Option(True, "--interactive/--no-interactive", "-i/-n", help="Interactive clarification mode"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    timing: bool = typer.Option(False, "--timing", "-t", help="Show timing information"),
 ) -> None:
    """
    Submit a prompt for VTK code generation.

    Asks clarifying questions one at a time, then synthesizes a final prompt.
    """
    config = load_config()

    t0 = time.perf_counter()
    llm_client = LLMClient(app_config=config)
    t_client = time.perf_counter() - t0

    if timing:
        console.print(f"[dim]LLM client init: {t_client*1000:.0f}ms[/dim]")

    while True:  # Outer loop for restart capability
        session = ClarificationSession.from_config(config, llm_client=llm_client)

        t0 = time.perf_counter()
        with console.status("Evaluating prompt..."):
            response = session.submit_prompt(prompt)
        t_eval = time.perf_counter() - t0

        if timing:
            console.print(f"[dim]Evaluate LLM call: {t_eval*1000:.0f}ms[/dim]")

        if response.status == "clear":
            _output_result(response, json_output, "Prompt is clear!")
            return

        if not interactive:
            if json_output:
                console.print(response.model_dump_json(indent=2))
            else:
                console.print("[yellow]Prompt needs clarification but running in non-interactive mode.[/yellow]")
                console.print(f"Missing: {', '.join(response.clarity_result.missing_details)}")
            raise typer.Exit(1)

        # Show initial evaluation
        console.print(Panel(
            f"[bold]Your prompt:[/bold] {prompt}\n\n"
            f"[yellow]I need to ask a few questions to clarify your request.[/yellow]",
            title="Clarification Needed",
        ))

        # Ask questions one at a time
        restart_requested = False
        while response.status in ("needs_clarification", "skipped") and response.questions:
            question = response.questions[0]  # Get first pending question

            # Ask the question
            answer = _ask_question(question)

            # Process the answer
            with console.status("Processing..."):
                response = session.answer_question(question.id, answer)

            if response.status == "restart":
                console.print("\n[yellow]Let's start over.[/yellow]\n")
                restart_requested = True
                break
            elif response.status == "skipped":
                console.print(f"[dim]Noted: No {question.category} specified.[/dim]")

        if restart_requested:
            continue  # Restart the outer loop

        # All questions answered - synthesize and confirm
        t0 = time.perf_counter()
        with console.status("Synthesizing your request..."):
            response = session.synthesize()
        t_synth = time.perf_counter() - t0

        if timing:
            console.print(f"[dim]Synthesize LLM call: {t_synth*1000:.0f}ms[/dim]")

        # Show synthesized prompt and ask for confirmation
        console.print(Panel(
            f"[bold]Synthesized prompt:[/bold]\n\n{response.synthesized_prompt}",
            title="✓ Your Request",
            border_style="green",
        ))

        if Confirm.ask("Is this correct?", default=True):
            _output_result(response, json_output, "Ready for code generation!")
            return
        else:
            if Confirm.ask("Would you like to start over?", default=True):
                console.print("\n[yellow]Let's start over.[/yellow]\n")
                continue  # Restart
            else:
                console.print("[yellow]Exiting.[/yellow]")
                raise typer.Exit(1)


def _ask_question(question: ClarifyingQuestion) -> str:
    """Ask a single clarifying question with pretty panel formatting."""
    # Styling based on importance
    is_required = question.importance == "required"
    border_style = "red" if is_required else "dim"
    importance_badge = "[red](required)[/red]" if is_required else "[dim](optional)[/dim]"

    # Build panel content
    content_lines = [question.question]

    # Always add a hint
    if question.example_answer:
        content_lines.append(f"\n[dim]Example: {question.example_answer}[/dim]")
    else:
        # Use hints from CATEGORIES (single source of truth)
        category_info = CATEGORIES.get(question.category, {})
        hint = category_info.get("hint", "")
        if hint:
            content_lines.append(f"\n[dim]{hint}[/dim]")

    if not is_required:
        content_lines.append("\n[dim italic]Press Enter to skip[/dim italic]")

    content = "\n".join(content_lines)

    # Display the panel
    category_title = question.category.upper()
    console.print()
    console.print(Panel(
        content,
        title=f"{category_title} {importance_badge}",
        border_style=border_style,
        padding=(0, 2),
    ))

    # Get answer
    while True:
        if is_required:
            answer = Prompt.ask("Your answer")
        else:
            answer = Prompt.ask("Your answer", default="")

        answer = answer.strip()
        if not is_required or answer:
            return answer


def _output_result(response: ClarificationSessionResponse, json_output: bool, message: str) -> None:
    """Output the final result."""
    if json_output:
        console.print(response.model_dump_json(indent=2))
    else:
        final_prompt = response.synthesized_prompt or response.prompt
        console.print(Panel(
            f"[green]{message}[/green]\n\n"
            f"[bold]Final prompt:[/bold]\n{final_prompt}",
            title="✓ Ready for Code Generation",
        ))


def _print_tasks_table(response: DecompositionSessionResponse, title: str = "VTK Pipeline Tasks") -> None:
    """Print tasks as a rich table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan")
    table.add_column("Type", style="green")
    table.add_column("Description", style="white")
    table.add_column("VTK Classes", style="yellow")
    table.add_column("Depends On", style="dim")
    table.add_column("From Prompt", style="dim")

    for task in response.tasks:
        table.add_row(
            task.id,
            task.task_type,
            task.description,
            ", ".join(task.vtk_classes) if task.vtk_classes else "-",
            ", ".join(task.depends_on) if task.depends_on else "-",
            "✓" if task.from_prompt else "(inferred)",
        )

    console.print(table)


def _print_decomposition_result(response: DecompositionSessionResponse, prompt: str) -> None:
    """Print final decomposition result with pretty formatting."""
    console.print()
    console.print(Panel(
        f"[green]✓ Decomposition Complete[/green]\n\n"
        f"[bold]Prompt:[/bold] {prompt}\n"
        f"[bold]Output Type:[/bold] {response.output_type}\n"
        f"[bold]Refinements:[/bold] {response.refinement_count}\n"
        f"[bold]Tasks:[/bold] {len(response.tasks)}",
        title="✓ Ready for Code Generation",
        border_style="green",
    ))

    # Task table
    _print_tasks_table(response, "Final Tasks")

    # Dependency graph as visual tree
    console.print()
    console.print(Panel(
        _build_dependency_tree(response.tasks),
        title="Pipeline Flow",
        border_style="dim",
    ))


def _build_dependency_tree(tasks: list[Task]) -> str:
    """Build a visual dependency tree."""
    lines = []
    for task in tasks:
        vtk = f"[yellow]{', '.join(task.vtk_classes)}[/yellow]" if task.vtk_classes else ""
        deps = f"[dim]← {', '.join(task.depends_on)}[/dim]" if task.depends_on else "[dim](start)[/dim]"
        lines.append(f"[cyan]{task.id}[/cyan] [{task.task_type}] {deps}")
        lines.append(f"    {task.description}")
        if vtk:
            lines.append(f"    {vtk}")
    return "\n".join(lines)

@app.command()
def decompose(
    prompt: str = typer.Argument(..., help="Synthesized prompt to decompose into tasks"),
    interactive: bool = typer.Option(True, "--interactive/--no-interactive", "-i/-n", help="Interactive refinement mode"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
 ) -> None:
    """
    Decompose a prompt into VTK pipeline tasks.

    Takes a synthesized prompt and breaks it into ordered tasks for code generation.
    In interactive mode, allows iterative refinement of tasks before finalizing.
    """
    config = load_config()
    llm_client = LLMClient(app_config=config)
    mcp_client = MCPClient(app_config=config)
    session = DecompositionSession.from_config(config, llm_client=llm_client, mcp_client=mcp_client)

    # Initial decomposition
    with console.status("Decomposing prompt into tasks..."):
        response = session.decompose(prompt)

    # Non-interactive mode: just output and exit
    if not interactive or json_output:
        if json_output:
            import json
            tasks_json = [t.model_dump() for t in response.tasks]
            console.print(json.dumps({
                "status": response.status,
                "output_type": response.output_type,
                "tasks": tasks_json,
                "is_finalized": False,
            }, indent=2))
        else:
            # Use same pretty output as interactive mode
            _print_decomposition_result(response, prompt)
        return

    # Interactive mode with refinement
    console.print(Panel(
        f"[bold]Prompt:[/bold] {prompt}\n\n"
        f"[bold]Output Type:[/bold] {response.output_type}",
        title="Task Decomposition",
    ))
    _print_tasks_table(response, f"Initial Tasks ({len(response.tasks)})")

    # Refinement loop
    while True:
        console.print()
        console.print(Panel(
            "[bold]Options:[/bold]\n"
            "  [cyan]m <task_id>[/cyan] - Modify a task (e.g., 'm t3')\n"
            "  [cyan]a <task_id>[/cyan] - Add a task after (e.g., 'a t1')\n"
            "  [cyan]f[/cyan] - Finalize and complete\n"
            "  [cyan]q[/cyan] - Quit without finalizing",
            title="Refine Tasks",
            border_style="dim",
        ))

        choice = Prompt.ask("Choice", default="f").lower().strip()

        if choice == "f":
            break
        elif choice == "q":
            console.print("[yellow]Exiting without finalizing.[/yellow]")
            raise typer.Exit(0)
        elif choice.startswith("m "):
            task_id = choice[2:].strip()
            task = next((t for t in response.tasks if t.id == task_id), None)
            if not task:
                console.print(f"[red]Task {task_id} not found.[/red]")
                continue

            console.print(f"\n[bold]Current:[/bold] {task.description}")
            feedback = Prompt.ask("Modification")
            if not feedback:
                continue

            with console.status("Refining..."):
                response = session.refine(
                    modifications=[TaskModification(task_id=task_id, feedback=feedback)]
                )

            _print_tasks_table(response, f"After Modification (refinement #{response.refinement_count})")

        elif choice.startswith("a "):
            depends_on = choice[2:].strip()
            task = next((t for t in response.tasks if t.id == depends_on), None)
            if not task:
                console.print(f"[red]Task {depends_on} not found.[/red]")
                continue

            console.print(f"\n[bold]Adding after:[/bold] {task.description}")
            description = Prompt.ask("New task description")
            if not description:
                continue

            with console.status("Refining..."):
                response = session.refine(
                    additions=[TaskAddition(description=description, depends_on=depends_on)]
                )

            _print_tasks_table(response, f"After Addition (refinement #{response.refinement_count})")
        else:
            console.print("[red]Invalid choice.[/red] Use 'm <id>', 'a <id>', 'f', or 'q'.")

    # Finalize
    with console.status("Finalizing..."):
        response = session.finalize()

    _print_decomposition_result(response, prompt)


@app.command()
def generate(
    tasks_json: Path = typer.Argument(
        ..., exists=True, dir_okay=False, help="Path to JSON from 'vtk-st decompose --json'"
    ),
    out: Path = typer.Option(Path("code.py"), "--out", "-o", help="Write generated code to a file"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
 ) -> None:
    """Generate VTK Python code from a decomposition JSON file."""
    config = load_config()
    llm_client = LLMClient(app_config=config)
    mcp_client = MCPClient(app_config=config)

    import json

    payload = json.loads(tasks_json.read_text(encoding="utf-8"))
    tasks_payload = payload.get("tasks", payload)
    prompt = payload.get("synthesized_prompt", payload.get("prompt", ""))

    if not isinstance(tasks_payload, list):
        raise typer.BadParameter(
            "JSON must be a list of tasks or an object containing a 'tasks' list"
        )

    decomp: DecompositionResult = DecompositionResult.model_validate(
        {
            "tasks": tasks_payload,
            "output_type": payload.get("output_type", "interactive"),
            "reasoning": payload.get("reasoning", "Loaded from JSON"),
        }
    )

    gen_session = GenerationSession.from_config(
        config,
        llm_client=llm_client,
        mcp_client=mcp_client,
    )
    with console.status("Generating code from tasks..."):
        result = gen_session.generate(tasks=decomp.tasks, original_prompt=prompt)

    out.write_text(result.code, encoding="utf-8")

    if json_output:
        console.print(
            json.dumps(
                {
                    "out": str(out),
                    "code": result.code,
                    "task_results": [tr.model_dump() for tr in result.task_results],
                },
                indent=2,
            )
        )
    else:
        console.print(Panel(result.code, title="Generated Code", border_style="green"))
        console.print(f"[dim]Wrote code to: {out}[/dim]")


@app.command()
def pipeline(
    prompt: str = typer.Argument(..., help="VTK code generation prompt"),
    interactive: bool = typer.Option(True, "--interactive/--no-interactive", "-i/-n", help="Interactive mode"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    out: Path = typer.Option(Path("code.py"), "--out", "-o", help="Write generated code to a file"),
 ) -> None:
    """
    Full pipeline: clarify prompt, decompose into tasks, then generate code.

    Writes the generated code to a file (default: code.py).
    """
    config = load_config()
    llm_client = LLMClient(app_config=config)
    mcp_client = MCPClient(app_config=config)

    # =========================================================================
    # PHASE 1: Prompt Clarification
    # =========================================================================
    console.print(Panel("[bold]Phase 1: Prompt Clarification[/bold]", border_style="blue"))

    while True:  # Outer loop for restart capability
        session = ClarificationSession.from_config(config, llm_client=llm_client)

        with console.status("Evaluating prompt..."):
            response = session.submit_prompt(prompt)

        if response.status == "clear":
            synthesized_prompt = response.prompt
            console.print(Panel(
                f"[green]✓ Prompt is already clear![/green]\n\n{synthesized_prompt}",
                title="Synthesized Prompt",
                border_style="green",
            ))
            break

        if not interactive:
            console.print("[yellow]Prompt needs clarification but running in non-interactive mode.[/yellow]")
            console.print(f"Missing: {', '.join(response.clarity_result.missing_details)}")
            raise typer.Exit(1)

        # Show initial evaluation
        console.print(Panel(
            f"[bold]Your prompt:[/bold] {prompt}\n\n"
            f"[yellow]I need to ask a few questions to clarify your request.[/yellow]",
            title="Clarification Needed",
        ))

        # Ask questions one at a time
        restart_requested = False
        while response.status in ("needs_clarification", "skipped") and response.questions:
            question = response.questions[0]
            answer = _ask_question(question)

            with console.status("Processing..."):
                response = session.answer_question(question.id, answer)

            if response.status == "restart":
                console.print("\n[yellow]Let's start over.[/yellow]\n")
                restart_requested = True
                break
            elif response.status == "skipped":
                console.print(f"[dim]Noted: No {question.category} specified.[/dim]")

        if restart_requested:
            continue

        # Synthesize
        with console.status("Synthesizing your request..."):
            response = session.synthesize()

        console.print(Panel(
            f"[bold]Synthesized prompt:[/bold]\n\n{response.synthesized_prompt}",
            title="✓ Your Request",
            border_style="green",
        ))

        if Confirm.ask("Is this correct?", default=True):
            synthesized_prompt = response.synthesized_prompt
            break
        else:
            if Confirm.ask("Would you like to start over?", default=True):
                console.print("\n[yellow]Let's start over.[/yellow]\n")
                continue
            else:
                console.print("[yellow]Exiting.[/yellow]")
                raise typer.Exit(1)

    # =========================================================================
    # PHASE 2: Task Decomposition
    # =========================================================================
    console.print()
    console.print(Panel("[bold]Phase 2: Task Decomposition[/bold]", border_style="blue"))

    decomp_session = DecompositionSession.from_config(
        config, llm_client=llm_client, mcp_client=mcp_client
    )

    with console.status("Decomposing prompt into tasks..."):
        response = decomp_session.decompose(synthesized_prompt)

    # Non-interactive: generate code, then output and exit
    if not interactive or json_output:
        gen_session = GenerationSession.from_config(
            config,
            llm_client=llm_client,
            mcp_client=mcp_client,
        )
        with console.status("Generating code from tasks..."):
            pipeline_result = gen_session.generate(
                tasks=response.tasks,
                original_prompt=synthesized_prompt,
            )

        out.write_text(pipeline_result.code, encoding="utf-8")

        if json_output:
            import json

            tasks_json = [t.model_dump() for t in response.tasks]
            payload: dict = {
                "synthesized_prompt": synthesized_prompt,
                "output_type": response.output_type,
                "tasks": tasks_json,
                "is_finalized": False,
            }
            payload["code"] = pipeline_result.code
            payload["task_results"] = [tr.model_dump() for tr in pipeline_result.task_results]
            payload["out"] = str(out)
            console.print(json.dumps(payload, indent=2))
        else:
            _print_decomposition_result(response, synthesized_prompt)
            console.print()
            console.print(Panel(
                pipeline_result.code,
                title="Generated Code",
                border_style="green",
            ))
            console.print(f"[dim]Wrote code to: {out}[/dim]")
        return

    # Interactive refinement
    console.print(Panel(
        f"[bold]Prompt:[/bold] {synthesized_prompt}\n\n"
        f"[bold]Output Type:[/bold] {response.output_type}",
        title="Task Decomposition",
    ))
    _print_tasks_table(response, f"Initial Tasks ({len(response.tasks)})")

    # Refinement loop
    while True:
        console.print()
        console.print(Panel(
            "[bold]Options:[/bold]\n"
            "  [cyan]m <task_id>[/cyan] - Modify a task (e.g., 'm t3')\n"
            "  [cyan]a <task_id>[/cyan] - Add a task after (e.g., 'a t1')\n"
            "  [cyan]f[/cyan] - Finalize and complete\n"
            "  [cyan]q[/cyan] - Quit without finalizing",
            title="Refine Tasks",
            border_style="dim",
        ))

        choice = Prompt.ask("Choice", default="f").lower().strip()

        if choice == "f":
            break
        elif choice == "q":
            console.print("[yellow]Exiting without finalizing.[/yellow]")
            raise typer.Exit(0)
        elif choice.startswith("m "):
            task_id = choice[2:].strip()
            task = next((t for t in response.tasks if t.id == task_id), None)
            if not task:
                console.print(f"[red]Task {task_id} not found.[/red]")
                continue

            console.print(f"\n[bold]Current:[/bold] {task.description}")
            feedback = Prompt.ask("Modification")
            if not feedback:
                continue

            with console.status("Refining..."):
                response = decomp_session.refine(
                    modifications=[TaskModification(task_id=task_id, feedback=feedback)]
                )

            _print_tasks_table(response, f"After Modification (refinement #{response.refinement_count})")

        elif choice.startswith("a "):
            depends_on = choice[2:].strip()
            task = next((t for t in response.tasks if t.id == depends_on), None)
            if not task:
                console.print(f"[red]Task {depends_on} not found.[/red]")
                continue

            console.print(f"\n[bold]Adding after:[/bold] {task.description}")
            description = Prompt.ask("New task description")
            if not description:
                continue

            with console.status("Refining..."):
                response = decomp_session.refine(
                    additions=[TaskAddition(description=description, depends_on=depends_on)]
                )

            _print_tasks_table(response, f"After Addition (refinement #{response.refinement_count})")
        else:
            console.print("[red]Invalid choice.[/red] Use 'm <id>', 'a <id>', 'f', or 'q'.")

    # Finalize
    with console.status("Finalizing..."):
        response = decomp_session.finalize()

    _print_decomposition_result(response, synthesized_prompt)

    # =========================================================================
    # PHASE 3: Code Generation
    # =========================================================================
    console.print()
    console.print(Panel("[bold]Phase 3: Code Generation[/bold]", border_style="blue"))

    gen_session = GenerationSession.from_config(
        config,
        llm_client=llm_client,
        mcp_client=mcp_client,
    )

    with console.status("Generating code from tasks..."):
        pipeline_result = gen_session.generate(
            tasks=response.tasks,
            original_prompt=synthesized_prompt,
        )

    out.write_text(pipeline_result.code, encoding="utf-8")

    console.print()
    console.print(Panel(
        pipeline_result.code,
        title="Generated Code",
        border_style="green",
    ))
    console.print(f"[dim]Wrote code to: {out}[/dim]")

    console.print()
    console.print(Panel(
        "[green]✓ Pipeline complete![/green]\n\n"
        "Generated code has been written.",
        title="✓ Ready for Code Generation",
        border_style="green",
    ))


@app.command()
def tools() -> None:
    """List available VTK API tools for LLM decomposition."""
    config = load_config()
    mcp_client = MCPClient(app_config=config)
    tool_defs = mcp_client.get_tool_definitions()

    table = Table(title="VTK API Tools")
    table.add_column("Name", style="cyan")
    table.add_column("Description", style="white")
    table.add_column("Parameters", style="dim")

    for tool in tool_defs:
        params = ", ".join(tool.parameters.get("required", []))
        table.add_row(tool.name, tool.description, params)

    console.print(table)
    console.print(f"\n[dim]Total: {len(tool_defs)} tools[/dim]")


@app.command()
def version() -> None:
    """Show version information."""
    console.print(f"vtk-sequential-thinking v{__version__}")


@app.callback()
def main() -> None:
    """
    VTK Sequential Thinking - RAG-based VTK code generation.

    Evaluates prompts for clarity and generates VTK Python code.
    """
    pass


if __name__ == "__main__":
    app()
