"""
Prompt clarification.

Evaluates if prompts have sufficient detail for VTK code generation.
Asks clarifying questions and synthesizes a complete prompt.

Flow:
1. Session.submit_prompt() - evaluate clarity, get questions
2. Session.answer_question() - answer questions one at a time
3. Session.synthesize() - combine answers into final prompt
"""

from vtk_sequential_thinking.prompt_clarification.clarifier import Clarifier
from vtk_sequential_thinking.prompt_clarification.models import (
    CATEGORIES,
    CATEGORY_NAMES,
    CategoryType,
    ClarifyingQuestion,
    ClarityResult,
    ConversationState,
    QuestionAnswer,
    SessionResponse,
)
from vtk_sequential_thinking.prompt_clarification.session import Session

__all__ = [
    # Session and Clarifier
    "Clarifier",
    "Session",
    # Models
    "ClarifyingQuestion",
    "ClarityResult",
    "ConversationState",
    "QuestionAnswer",
    "SessionResponse",
    # Category definitions
    "CATEGORIES",
    "CATEGORY_NAMES",
    "CategoryType",
]
