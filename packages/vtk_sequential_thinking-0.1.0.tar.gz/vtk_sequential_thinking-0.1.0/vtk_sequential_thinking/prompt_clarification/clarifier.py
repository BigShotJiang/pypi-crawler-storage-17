"""
Clarifier for prompt clarity evaluation and synthesis.

Two LLM handlers:
- evaluate(): Determines if a prompt has sufficient detail
- synthesize(): Combines original prompt with answers into a complete prompt
"""

from vtk_sequential_thinking.config import AppConfig, load_config
from vtk_sequential_thinking.llm.client import LLMClient
from vtk_sequential_thinking.llm.json_protocol import JSONProtocol
from vtk_sequential_thinking.prompt_clarification.models import (
    ClarityResult,
    QuestionAnswer,
    SynthesisResult,
)
from vtk_sequential_thinking.prompt_clarification.prompts import (
    CLARITY_SYSTEM_PROMPT,
    SYNTHESIS_SYSTEM_PROMPT,
    build_clarity_prompt,
    build_synthesis_prompt,
)


class Clarifier:
    """
    Evaluate prompt clarity and synthesize prompts.

    Two LLM handlers:
    - evaluate(): Check if prompt has sufficient detail
    - synthesize(): Combine original prompt with answers
    """

    def __init__(
        self,
        llm_client: LLMClient | None = None,
        config: AppConfig | None = None,
    ):
        """
        Initialize the clarifier.

        Args:
            llm_client: LLM client for API calls. If None, creates from config.
            config: Application configuration. If None, loads from environment.
        """
        self.config = config or load_config()
        self.llm = llm_client or LLMClient(app_config=self.config)
        self.protocol = JSONProtocol()

    # =========================================================================
    # LLM Handlers
    # =========================================================================

    def evaluate(self, prompt: str) -> ClarityResult:
        """
        Evaluate prompt clarity.

        Args:
            prompt: The user's prompt to evaluate

        Returns:
            ClarityResult with is_clear, confidence, and clarifying_questions
        """
        try:
            response = self.llm.generate(
                prompt=build_clarity_prompt(prompt),
                system=CLARITY_SYSTEM_PROMPT,
                temperature=0.1,
            )

            result = self.protocol.decode_response(response, ClarityResult)
            return result

        except Exception as e:
            print(f"Evaluation failed: {e}")
            raise

    def synthesize(
        self,
        original_prompt: str,
        answered_questions: list[QuestionAnswer],
    ) -> str:
        """
        Synthesize the original prompt with clarifying answers.

        Args:
            original_prompt: The original user prompt
            answered_questions: QuestionAnswer objects with category, answer, needs_discovery

        Returns:
            Synthesized prompt string
        """
        if not answered_questions:
            return original_prompt

        try:
            response = self.llm.generate(
                prompt=build_synthesis_prompt(original_prompt, answered_questions),
                system=SYNTHESIS_SYSTEM_PROMPT,
                temperature=0.1,
            )

            result = self.protocol.decode_response(response, SynthesisResult)
            return result.synthesized_prompt

        except Exception as e:
            print(f"Synthesis failed: {e}")
            raise
