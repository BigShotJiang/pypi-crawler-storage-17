"""LLM prompts for clarity and synthesis.

System prompts are built from four components:
1. ROLE: The LLM's persona and task
2. INFORMATION: Domain-specific knowledge needed for the task
3. EXAMPLES: Few-shot examples showing expected input/output
4. RESPONSE_FORMAT: JSON schema for structured output

All communication with the LLM is JSON serialized to strings.

Public API:
- build_clarity_system_prompt(): Assembles clarity evaluation system prompt
- build_synthesis_system_prompt(): Assembles synthesis system prompt
- build_clarity_prompt(): Formats user data for clarity evaluation
- build_synthesis_prompt(): Formats user data for synthesis
"""

import json

from vtk_sequential_thinking.prompt_clarification.models import CATEGORIES, QuestionAnswer

# =============================================================================
# Clarity Evaluation Components
# =============================================================================

_CLARITY_ROLE = {
    "persona": "expert evaluator for VTK (Visualization Toolkit) Python code generation prompts",
    "task": "determine if a user's prompt has sufficient detail to generate correct, complete VTK Python code",
    "communication": "all input and output is JSON"
}

_CLARITY_INFORMATION = {
    "categories": {
        "INPUT": {
            "required": True,
            "depends_on": None,
            "condition": None,
            "description": "Data source - file path or generated source (e.g., 'brain.vti', 'mesh.stl', 'sphere source')"
        },
        "FILTERS": {
            "required": True,
            "depends_on": None,
            "condition": None,
            "description": "VTK processing/visualization (e.g., 'isosurface at 128', 'smooth mesh', 'volume render')"
        },
        "OUTPUT": {
            "required": True,
            "depends_on": None,
            "condition": None,
            "description": "What to produce: 'display interactively', 'save as PNG', 'write to STL'"
        },
        "FIELDS": {
            "required": True,
            "depends_on": "INPUT",
            "condition": "Only if input file has selectable arrays (VTK, CSV, MHA). NOT for STL, OBJ, PLY, or sources.",
            "description": "Which data arrays to use (e.g., 'pressure array', 'X,Y,Z columns'). Accept 'I don't know' for discovery."
        },
        "PROPERTIES": {
            "required": False,
            "depends_on": "OUTPUT",
            "condition": "Only if OUTPUT requires rendering (interactive or image)",
            "description": "Appearance AND annotations: colors, opacity, scalar bars, text labels, axes"
        },
        "SCENE": {
            "required": False,
            "depends_on": "OUTPUT",
            "condition": "Only if OUTPUT requires rendering (interactive or image)",
            "description": "Camera, lighting, widgets (e.g., 'view from above', 'add headlight', 'isometric view')"
        }
    },
    "question_structure": {
        "id": "Unique ID (q1, q2, ...)",
        "question": "Question text",
        "category": "input | fields | filters | properties | scene | output",
        "importance": "required | optional",
        "depends_on": "null OR question ID that must be answered first",
        "condition": "null OR condition for when this question applies (evaluated against previous answers)",
        "example_answer": "Example of a good answer"
    },
    "question_flow": [
        "1. Ask INPUT, FILTERS, OUTPUT first (no dependencies, required)",
        "2. After INPUT answered: ask FIELDS if input has arrays (depends_on INPUT, condition: has arrays)",
        "3. After OUTPUT answered: ask PROPERTIES and SCENE if rendering (depends_on OUTPUT, condition: rendering, optional)"
    ],
    "rendering_keywords": ["interactive", "display", "window", "screenshot", "image", "png", "jpg", "render"],
    "array_file_formats": [".vti", ".vtp", ".vtu", ".vts", ".vtr", ".vtk", ".csv", ".mha", ".mhd", ".nrrd"],
    "geometry_only_formats": [".stl", ".obj", ".ply", ".off"]
}

_CLARITY_EXAMPLES = [
    # CLEAR examples - have all required categories
    {
        "prompt": "How can I read LakeGininderra.csv with vtkDelimitedTextReader and visualize it as a 3D path using vtkTableToPolyData? Use X(m), Y(m), Z(m) columns for coordinates and color by Elevation(m) column.",
        "evaluation": {
            "is_clear": True,
            "confidence": 0.95,
            "reasoning": "INPUT: LakeGininderra.csv. FIELDS: X(m), Y(m), Z(m) for coords, Elevation(m) for color. FILTERS: vtkTableToPolyData conversion. PROPERTIES: color by elevation. OUTPUT: implied interactive display.",
            "missing_details": [],
            "clarifying_questions": []
        }
    },
    {
        "prompt": "How can I read headMesh.stl and use image stencil operation to convert the mesh into a binary volume (255 inside, 0 outside), then save as MetaImage file?",
        "evaluation": {
            "is_clear": True,
            "confidence": 0.95,
            "reasoning": "INPUT: headMesh.stl (no fields needed for STL). FILTERS: image stencil voxelization. OUTPUT: MetaImage file (no rendering needed).",
            "missing_details": [],
            "clarifying_questions": []
        }
    },
    {
        "prompt": "How can I read tetra.vtu and visualize with MistyRose faces, visible edges with line width 2, and save a screenshot?",
        "evaluation": {
            "is_clear": True,
            "confidence": 0.93,
            "reasoning": "INPUT: tetra.vtu. FILTERS: display unstructured grid. PROPERTIES: MistyRose color, edges visible, line width 2. OUTPUT: screenshot (rendering required).",
            "missing_details": [],
            "clarifying_questions": []
        }
    },
    # UNCLEAR examples - missing required categories
    {
        "prompt": "How can I read a VTK file?",
        "evaluation": {
            "is_clear": False,
            "confidence": 0.90,
            "reasoning": "Missing specific INPUT filename, no FILTERS specified, no OUTPUT specified.",
            "missing_details": ["input", "filters", "output"],
            "clarifying_questions": [
                {
                    "id": "q1",
                    "question": "What is the specific filename and format?",
                    "category": "input",
                    "importance": "required",
                    "depends_on": None,
                    "condition": None,
                    "example_answer": "mesh.vtp, volume.vti, or data.csv"
                },
                {
                    "id": "q2",
                    "question": "What filters or visualization technique do you want to apply?",
                    "category": "filters",
                    "importance": "required",
                    "depends_on": None,
                    "condition": None,
                    "example_answer": "Extract isosurface at value 100, volume render, or apply smoothing filter"
                },
                {
                    "id": "q3",
                    "question": "What should the output be?",
                    "category": "output",
                    "importance": "required",
                    "depends_on": None,
                    "condition": None,
                    "example_answer": "Save to STL file, display interactively, or save screenshot"
                },
                {
                    "id": "q4",
                    "question": "Which data fields/columns/arrays should be used?",
                    "category": "fields",
                    "importance": "required",
                    "depends_on": "q1",
                    "condition": "Only if input file has selectable fields (CSV, VTK with arrays)",
                    "example_answer": "Use 'pressure' array for coloring, or X,Y,Z columns for coordinates"
                },
                {
                    "id": "q5",
                    "question": "What colors, appearance, or annotations do you want?",
                    "category": "properties",
                    "importance": "optional",
                    "depends_on": "q3",
                    "condition": "Only if output requires rendering (interactive or image)",
                    "example_answer": "Blue color, add scalar bar, opacity 0.8"
                },
                {
                    "id": "q6",
                    "question": "Any camera, lighting, or widget settings?",
                    "category": "scene",
                    "importance": "optional",
                    "depends_on": "q3",
                    "condition": "Only if output requires rendering (interactive or image)",
                    "example_answer": "View from above, add headlight, isometric view"
                }
            ]
        }
    },
    {
        "prompt": "How can I read brain.mha and create an isosurface?",
        "evaluation": {
            "is_clear": False,
            "confidence": 0.75,
            "reasoning": "INPUT: brain.mha (good). FILTERS: isosurface but missing isovalue. OUTPUT: not specified.",
            "missing_details": ["filters", "output"],
            "clarifying_questions": [
                {
                    "id": "q1",
                    "question": "What isovalue should be used for the isosurface?",
                    "category": "filters",
                    "importance": "required",
                    "depends_on": None,
                    "condition": None,
                    "example_answer": "128, or the tissue boundary value"
                },
                {
                    "id": "q2",
                    "question": "What should the output be?",
                    "category": "output",
                    "importance": "required",
                    "depends_on": None,
                    "condition": None,
                    "example_answer": "Display interactively, save as STL, or save screenshot"
                },
                {
                    "id": "q3",
                    "question": "What color and appearance should the isosurface have?",
                    "category": "properties",
                    "importance": "optional",
                    "depends_on": "q2",
                    "condition": "Only if output requires rendering (interactive or image)",
                    "example_answer": "Skin-colored with smooth shading, add scalar bar"
                },
                {
                    "id": "q4",
                    "question": "Any camera or lighting preferences?",
                    "category": "scene",
                    "importance": "optional",
                    "depends_on": "q2",
                    "condition": "Only if output requires rendering (interactive or image)",
                    "example_answer": "Isometric view, add headlight"
                }
            ]
        }
    },
    {
        "prompt": "Read data.csv and visualize it",
        "evaluation": {
            "is_clear": False,
            "confidence": 0.80,
            "reasoning": "INPUT: data.csv (good). FIELDS: not specified (required for CSV). FILTERS: 'visualize' is vague. OUTPUT: not specified.",
            "missing_details": ["fields", "filters", "output"],
            "clarifying_questions": [
                {
                    "id": "q1",
                    "question": "Which columns should be used and for what purpose?",
                    "category": "fields",
                    "importance": "required",
                    "depends_on": None,
                    "condition": None,
                    "example_answer": "X,Y,Z columns for 3D coordinates, Temperature for coloring"
                },
                {
                    "id": "q2",
                    "question": "What filters or visualization technique should be applied?",
                    "category": "filters",
                    "importance": "required",
                    "depends_on": None,
                    "condition": None,
                    "example_answer": "As a 3D scatter plot, or connected line path"
                },
                {
                    "id": "q3",
                    "question": "What should the output be?",
                    "category": "output",
                    "importance": "required",
                    "depends_on": None,
                    "condition": None,
                    "example_answer": "Interactive window or save screenshot"
                },
                {
                    "id": "q4",
                    "question": "What colors, appearance, or annotations do you want?",
                    "category": "properties",
                    "importance": "optional",
                    "depends_on": "q3",
                    "condition": "Only if output requires rendering (interactive or image)",
                    "example_answer": "Color by temperature, add scalar bar"
                },
                {
                    "id": "q5",
                    "question": "Any camera, lighting, or widget settings?",
                    "category": "scene",
                    "importance": "optional",
                    "depends_on": "q3",
                    "condition": "Only if output requires rendering (interactive or image)",
                    "example_answer": "View from above, zoom to fit"
                }
            ]
        }
    }
]


_CLARITY_RESPONSE_FORMAT = {
    "is_clear": "boolean",
    "confidence": "float 0.0-1.0",
    "reasoning": "brief explanation string",
    "missing_details": ["list of missing category names"],
    "clarifying_questions": [
        {
            "id": "unique question id (q1, q2, ...)",
            "question": "the question text",
            "category": "input|fields|filters|properties|scene|output",
            "importance": "required|optional",
            "depends_on": "null or q_id that must be answered first",
            "condition": "null or condition for this question to apply",
            "example_answer": "example of a good answer"
        }
    ]
}


def build_clarity_system_prompt() -> str:
    """Assemble the clarity evaluation system prompt as JSON."""
    return json.dumps({
        "role": _CLARITY_ROLE,
        "information": _CLARITY_INFORMATION,
        "examples": _CLARITY_EXAMPLES,
        "response_format": _CLARITY_RESPONSE_FORMAT
    }, indent=2)


# Pre-built for efficiency (components are static)
CLARITY_SYSTEM_PROMPT = build_clarity_system_prompt()


# =============================================================================
# Synthesis Components
# =============================================================================

_SYNTHESIS_ROLE = {
    "persona": "expert at synthesizing VTK Python code generation prompts from user answers",
    "task": "given an original (possibly vague) prompt and user answers to clarifying questions, synthesize a single, clear, detailed prompt that captures the complete intent",
    "communication": "all input and output is JSON"
}

_SYNTHESIS_INFORMATION = {
    "input_format": {
        "original_prompt": "The user's original (possibly vague) prompt",
        "answers": {
            "category_name": "User's answer text, or 'answer [NEEDS_DISCOVERY]' if user doesn't know"
        }
    },
    "category_order": ["input", "fields", "filters", "properties", "scene", "output"],
    "categories": {name: info["description"] for name, info in CATEGORIES.items()},
    "rules": [
        "Synthesize a natural, single request from original prompt + answers",
        "Include specific file names, values, colors from answers",
        "Don't add VTK class names unless user mentioned them",
        "Don't add details user didn't provide",
        "Keep it concise but complete",
        "Skipped optional categories (properties, scene) should not appear in output"
    ],
    "discovery_handling": {
        "marker": "[NEEDS_DISCOVERY]",
        "meaning": "User doesn't know what options are available",
        "action": "Include instruction to list/discover options at runtime",
        "example": {
            "answer": "I don't know what arrays are available [NEEDS_DISCOVERY]",
            "synthesis": "...list available data arrays so I can choose which one to use..."
        }
    }
}

# No examples for synthesis (straightforward task)
_SYNTHESIS_EXAMPLES = None

_SYNTHESIS_RESPONSE_FORMAT = {
    "synthesized_prompt": "the synthesized prompt text string",
    "needs_discovery": ["list of category names needing runtime discovery"]
}


def build_synthesis_system_prompt() -> str:
    """Assemble the synthesis system prompt as JSON."""
    prompt_dict = {
        "role": _SYNTHESIS_ROLE,
        "information": _SYNTHESIS_INFORMATION,
        "response_format": _SYNTHESIS_RESPONSE_FORMAT
    }
    # Only include examples if present
    if _SYNTHESIS_EXAMPLES:
        prompt_dict["examples"] = _SYNTHESIS_EXAMPLES
    return json.dumps(prompt_dict, indent=2)


# Pre-built for efficiency (components are static)
SYNTHESIS_SYSTEM_PROMPT = build_synthesis_system_prompt()


# =============================================================================
# Prompt Builders
# =============================================================================


def build_clarity_prompt(prompt: str) -> str:
    return json.dumps({"prompt": prompt}, indent=2)


def build_synthesis_prompt(
    original: str,
    answered_questions: list[QuestionAnswer],
) -> str:
    answers = {}
    for qa in answered_questions:
        key = qa.category if qa.category else qa.question_id
        if qa.needs_discovery:
            answers[key] = f"{qa.answer} [NEEDS_DISCOVERY]"
        else:
            answers[key] = qa.answer

    return json.dumps({
        "original_prompt": original,
        "answers": answers
    }, indent=2)
