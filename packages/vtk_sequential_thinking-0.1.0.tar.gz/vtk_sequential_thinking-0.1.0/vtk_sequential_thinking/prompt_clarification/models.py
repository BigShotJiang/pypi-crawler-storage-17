"""
Pydantic models for conversation and prompt clarity evaluation.

All structured data uses these models for validation and serialization.
"""

from typing import Literal

from pydantic import BaseModel, Field

# =============================================================================
# Category Definitions - Single Source of Truth
# =============================================================================

CATEGORIES: dict[str, dict[str, str | bool]] = {
    "input": {
        "description": "Data source (file path or generated source)",
        "hint": "e.g., brain.vti, mesh.stl, data.csv",
        "required": True,
    },
    "fields": {
        "description": "Arrays, columns, or fields to use from input",
        "hint": "e.g., 'pressure' array, X/Y/Z columns",
        "required": False,  # conditional on input type
    },
    "filters": {
        "description": "VTK processing filters and visualization techniques",
        "hint": "e.g., isosurface at 128, smooth mesh",
        "required": True,
    },
    "properties": {
        "description": "Visualization properties AND standalone actors (annotations like scalar bars, text, axes)",
        "hint": "e.g., blue color, opacity 0.8, add scalar bar, show axes",
        "examples": ["vtkProperty", "vtkScalarBarActor", "vtkTextActor", "vtkAxesActor", "vtkCubeAxesActor"],
        "required": False,
    },
    "scene": {
        "description": "Scene configuration - camera, lighting, and widgets (properties of the renderer)",
        "hint": "e.g., view from above, isometric view, add headlight, zoom to fit",
        "examples": ["vtkCamera", "vtkLight", "vtkOrientationMarkerWidget"],
        "required": False,
    },
    "output": {
        "description": "What to produce (display, save file, screenshot)",
        "hint": "e.g., display interactively, save as PNG",
        "required": True,
    },
}

# Type alias for category literals - derived from CATEGORIES keys
# Order: input → fields → filters → properties → scene → output
CategoryType = Literal["input", "fields", "filters", "properties", "scene", "output"]

# Helper to get category names as a list
CATEGORY_NAMES: list[str] = list(CATEGORIES.keys())


# =============================================================================
# Pydantic Models
# =============================================================================

class ClarifyingQuestion(BaseModel):
    """A question to clarify missing details in a user's prompt.

    Questions are organized by category and may have dependencies on other
    questions. For example, a fields question might depend on the input
    question being answered first to know what file format is being used.

    Categories are defined in CATEGORIES dict above. To add/modify categories,
    update CATEGORIES and the CategoryType Literal.
    """

    id: str = Field(
        ...,
        description="Unique identifier (e.g., 'q1', 'q2') used to track answers and dependencies"
    )
    question: str = Field(
        ...,
        description="The question text to display to the user"
    )
    category: CategoryType = Field(
        ...,
        description="Category of the question - see CATEGORIES for valid values"
    )
    importance: Literal["required", "optional"] = Field(
        default="required",
        description="'required' questions must be answered or session restarts; 'optional' can be skipped"
    )
    depends_on: str | None = Field(
        default=None,
        description="ID of question that must be answered first. Used for follow-on questions like asking about data arrays after knowing the file type"
    )
    condition: str | None = Field(
        default=None,
        description="Condition expression for when this question applies (e.g., 'if input has arrays', 'if rendering'). Evaluated against previous answers"
    )
    example_answer: str | None = Field(
        default=None,
        description="Example of a good answer to help guide the user (e.g., 'brain.vti', 'use pressure array')"
    )


class ClarityResult(BaseModel):
    """Result of evaluating whether a prompt has sufficient detail for code generation.

    Returned by Clarifier.evaluate() after analyzing a user's prompt.
    If is_clear=False, contains questions to ask for clarification.
    """

    is_clear: bool = Field(
        ...,
        description="True if the prompt has enough detail to generate VTK code without guessing"
    )
    confidence: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="How confident the evaluator is in this assessment (0.0=uncertain, 1.0=certain)"
    )
    missing_details: list[str] = Field(
        default_factory=list,
        description="Categories that are missing or unclear: input, fields, filters, properties, scene, output"
    )
    clarifying_questions: list[ClarifyingQuestion] = Field(
        default_factory=list,
        description="Questions to ask the user to fill in missing details. Empty if is_clear=True"
    )
    reasoning: str = Field(
        default="",
        description="Human-readable explanation of why the prompt is clear or what's missing"
    )


class SynthesisResult(BaseModel):
    """Result from synthesizing a prompt with clarifying answers."""

    synthesized_prompt: str = Field(
        ...,
        description="The synthesized prompt text string"
    )
    needs_discovery: list[str] = Field(
        default_factory=list,
        description="Categories that require runtime discovery"
    )


class SessionResponse(BaseModel):
    """Response from a Session after submitting a prompt or answering questions.

    The status field indicates what to do next:
    - 'clear': Prompt is ready for code generation
    - 'needs_clarification': Ask the questions in the questions field
    - 'ready_to_synthesize': All questions answered, call synthesize()
    - 'synthesized': Final synthesized prompt is in synthesized_prompt
    - 'restart': Required question was skipped, caller should restart session
    - 'skipped': Optional question was skipped (informational, check questions for next)
    """

    status: Literal["clear", "needs_clarification", "ready_to_synthesize", "synthesized", "restart", "skipped"] = Field(
        ...,
        description="'clear'=ready, 'needs_clarification'=ask questions, 'ready_to_synthesize'=call synthesize(), 'synthesized'=done, 'restart'=start over, 'skipped'=optional skipped"
    )
    prompt: str = Field(
        ...,
        description="The original user prompt being evaluated"
    )
    questions: list[ClarifyingQuestion] | None = Field(
        default=None,
        description="Pending questions to ask the user. First question in list should be asked next"
    )
    synthesized_prompt: str | None = Field(
        default=None,
        description="The final synthesized prompt combining original + all answers. Only set when status='synthesized'"
    )
    clarity_result: ClarityResult | None = Field(
        default=None,
        description="Full evaluation result from the initial clarity check. Useful for debugging"
    )


class QuestionAnswer(BaseModel):
    """Records a user's answer to a clarifying question.

    Tracks both the answer text and whether the user indicated they don't know
    (e.g., "I don't know what arrays are in the file"), which triggers runtime
    discovery code generation.
    """

    question_id: str = Field(
        ...,
        description="ID of the question this answers (matches ClarifyingQuestion.id)"
    )
    category: str = Field(
        default="",
        description="Category of the question (input, fields, filters, properties, scene, output) for grouping answers"
    )
    answer: str = Field(
        ...,
        description="The user's answer text, or '[skipped]' if optional question was skipped"
    )
    needs_discovery: bool = Field(
        default=False,
        description="True if user said 'I don't know', 'list them', etc. Code generator will include array discovery logic"
    )


class ConversationState(BaseModel):
    """Full state of an ongoing clarification conversation.

    Tracks the original prompt, all questions (including follow-ups), and which have
    been answered. Used by Session to manage the iterative Q&A flow.
    """

    original_prompt: str = Field(
        ...,
        description="The user's original prompt before any clarification"
    )
    current_prompt: str = Field(
        ...,
        description="Current prompt text (equals original until synthesis, then equals synthesized)"
    )
    all_questions: list[ClarifyingQuestion] = Field(
        default_factory=list,
        description="All questions from initial evaluation, including those with dependencies. Used to find follow-up questions after answers"
    )
    pending_questions: list[ClarifyingQuestion] = Field(
        default_factory=list,
        description="Questions waiting to be asked. First item is the next question. Shrinks as questions are answered"
    )
    answered_questions: list[QuestionAnswer] = Field(
        default_factory=list,
        description="All answers collected so far. Used to synthesize the final prompt"
    )
    is_complete: bool = Field(
        default=False,
        description="True when all required questions answered and prompt has been synthesized"
    )
    clarity_history: list[ClarityResult] = Field(
        default_factory=list,
        description="History of clarity evaluations (typically just one, but supports re-evaluation)"
    )
