"""
Session.

Manages multi-turn clarification dialogue for prompt clarity evaluation.

Public API:
    session = Session.from_config()

    # 1. Submit prompt for evaluation
    response = session.submit_prompt("Read a VTK file")
    # Returns: status="clear" or status="needs_clarification"

    # 2. Answer questions one at a time
    while response.status in ("needs_clarification", "skipped"):
        question = response.questions[0]
        response = session.answer_question(question.id, user_answer)
        # Returns: status="needs_clarification", "ready_to_synthesize", "skipped", or "restart"
        if response.status == "restart":
            break  # Required question skipped, restart session

    # 3. Synthesize final prompt from answers
    if response.status == "ready_to_synthesize":
        response = session.synthesize()
        # Returns: status="synthesized", synthesized_prompt="..."
        print(response.synthesized_prompt)
"""


from vtk_sequential_thinking.config import AppConfig, load_config
from vtk_sequential_thinking.llm.client import LLMClient
from vtk_sequential_thinking.prompt_clarification.clarifier import Clarifier
from vtk_sequential_thinking.prompt_clarification.models import (
    ClarifyingQuestion,
    ClarityResult,
    ConversationState,
    QuestionAnswer,
    SessionResponse,
)


class Session:
    """
    Manage multi-turn clarification dialogue.

    Orchestrates prompt clarity evaluation:
    - Submits prompt to clarifier for evaluation
    - Answers required/optional questions if needed, one at a time
    - Synthesizes prompt from all answers

    See module docstring for usage example.
    """

    def __init__(
        self,
        llm_client: LLMClient | None = None,
        clarifier: Clarifier | None = None,
        config: AppConfig | None = None,
    ):
        """
        Initialize session.

        Args:
            llm_client: LLM client for API calls. If None, creates one.
                        Pass this to reuse a client across activities.
            clarifier: Clarifier for evaluation and synthesis. If None, creates one.
            config: Application configuration. If None, loads from environment.
        """
        self.config = config or load_config()

        # Use provided client or create one
        self.llm_client = llm_client or LLMClient(app_config=self.config)

        self.clarifier = clarifier or Clarifier(
            llm_client=self.llm_client, config=self.config
        )

        # Session state
        self.state: ConversationState | None = None

    @classmethod
    def from_config(
        cls,
        config: AppConfig | None = None,
        llm_client: LLMClient | None = None,
    ) -> "Session":
        """
        Create a session from configuration.

        Args:
            config: Application configuration. If None, loads from environment.
            llm_client: LLM client to reuse. If None, creates one.

        Returns:
            Configured Session
        """
        return cls(llm_client=llm_client, config=config)

    def submit_prompt(self, prompt: str) -> SessionResponse:
        """
        Submit a prompt for evaluation.

        Args:
            prompt: The user's prompt

        Returns:
            SessionResponse with status='clear' or 'needs_clarification'
        """
        # Initialize state
        self.state = ConversationState(
            original_prompt=prompt,
            current_prompt=prompt,
        )

        # Evaluate clarity
        clarity_result = self.clarifier.evaluate(prompt)
        self.state.clarity_history.append(clarity_result)

        if clarity_result.is_clear:
            self.state.is_complete = True
            return SessionResponse(
                status="clear",
                prompt=prompt,
                clarity_result=clarity_result,
            )

        # Get initial clarifying questions (no dependencies)
        questions = self._get_immediate_questions(clarity_result)
        self.state.pending_questions = questions
        self.state.all_questions = clarity_result.clarifying_questions  # Store all for followups

        return SessionResponse(
            status="needs_clarification",
            prompt=prompt,
            questions=questions,
            clarity_result=clarity_result,
        )

    def answer_question(self, question_id: str, answer: str) -> SessionResponse:
        """
        Answer a single clarifying question.

        Must be called after submit_prompt(). Use question IDs from
        response.questions.

        Args:
            question_id: ID of the question being answered
            answer: The user's answer (empty string means skip)

        Returns:
            SessionResponse with status:
            - 'needs_clarification': More questions to ask
            - 'ready_to_synthesize': All questions answered
            - 'skipped': Optional question skipped (check questions for next)
            - 'restart': Required question skipped, caller should restart
        """
        # Find the question
        question = next(
            (q for q in self.state.pending_questions if q.id == question_id),
            None
        )

        # Handle empty answer
        if not answer.strip():
            if question.importance == "required":
                return SessionResponse(
                    status="restart",
                    prompt=self.state.current_prompt,
                )
            else:
                # Optional question skipped - note it
                self.state.answered_questions.append(
                    QuestionAnswer(
                        question_id=question_id,
                        category=question.category,
                        answer=f"[skipped - no {question.category} specified]"
                    )
                )
                self._remove_from_pending(question_id)
                self._add_followups()
                return SessionResponse(
                    status="skipped",
                    prompt=self.state.current_prompt,
                    questions=self.state.pending_questions if self.state.pending_questions else None,
                )

        # Check if user doesn't know the answer (needs runtime discovery)
        needs_discovery = self._is_unknown_answer(answer)

        # Record the answer
        self.state.answered_questions.append(
            QuestionAnswer(
                question_id=question_id,
                category=question.category,
                answer=answer,
                needs_discovery=needs_discovery,
            )
        )

        # Remove from pending
        self._remove_from_pending(question_id)

        # Check for follow-up questions
        self._add_followups()

        # Return current state
        if self.state.pending_questions:
            return SessionResponse(
                status="needs_clarification",
                prompt=self.state.current_prompt,
                questions=self.state.pending_questions,
            )
        else:
            return SessionResponse(
                status="ready_to_synthesize",
                prompt=self.state.current_prompt,
            )

    def _remove_from_pending(self, question_id: str) -> None:
        """Remove a question from pending list."""
        self.state.pending_questions = [
            q for q in self.state.pending_questions
            if q.id != question_id
        ]

    def _is_unknown_answer(self, answer: str) -> bool:
        """
        Check if the answer indicates the user doesn't know.

        These answers should trigger runtime discovery code generation.

        Args:
            answer: The user's answer text

        Returns:
            True if the answer indicates unknown/discovery needed
        """
        answer_lower = answer.lower().strip()

        unknown_phrases = [
            "i don't know",
            "i dont know",
            "don't know",
            "dont know",
            "unknown",
            "not sure",
            "no idea",
            "list them",
            "show me",
            "show options",
            "let me choose",
            "let me pick",
            "what's available",
            "whats available",
            "what are the options",
            "discover",
            "find out",
            "?",  # Just a question mark
        ]

        return any(phrase in answer_lower for phrase in unknown_phrases)

    def _add_followups(self) -> None:
        """Add any applicable follow-up questions to pending."""
        if not self.state.clarity_history:
            return

        answered_ids = [qa.question_id for qa in self.state.answered_questions]
        answers_dict = {qa.question_id: qa.answer for qa in self.state.answered_questions}

        latest_clarity = self.state.clarity_history[-1]
        followups = self._get_followup_questions(
            latest_clarity, answered_ids, answers_dict
        )

        # Add new followups to pending (avoid duplicates)
        pending_ids = {q.id for q in self.state.pending_questions}
        for fq in followups:
            if fq.id not in pending_ids and fq.id not in answered_ids:
                self.state.pending_questions.append(fq)

    def _get_immediate_questions(self, clarity_result: ClarityResult) -> list[ClarifyingQuestion]:
        """Get only the first-level questions (no dependencies)."""
        return [
            q for q in clarity_result.clarifying_questions
            if q.depends_on is None
        ]

    def _get_followup_questions(
        self,
        clarity_result: ClarityResult,
        answered_ids: list[str],
        answers: dict[str, str],
    ) -> list[ClarifyingQuestion]:
        """Get follow-up questions based on answers given."""
        followups = []

        for q in clarity_result.clarifying_questions:
            # Skip if no dependency or already answered
            if q.depends_on is None or q.id in answered_ids:
                continue

            # Check if dependency is answered
            if q.depends_on not in answered_ids:
                continue

            # Check condition if present
            if q.condition and not self._evaluate_condition(q.condition, answers):
                continue

            followups.append(q)

        return followups

    def _evaluate_condition(self, condition: str, answers: dict[str, str]) -> bool:
        """Evaluate if a question's condition is met based on previous answers."""
        condition_lower = condition.lower()
        answers_text = " ".join(answers.values()).lower()

        # Files that DON'T have selectable arrays (geometry only)
        geometry_only_formats = [".stl", ".obj", ".ply", ".off"]

        # Files that DO have arrays (need fields category)
        array_formats = [".vti", ".vtp", ".vtu", ".vts", ".vtr", ".vtk", ".csv",
                        ".mha", ".mhd", ".nrrd", ".nii", ".dcm"]

        # Check for fields conditions
        if "array" in condition_lower or "field" in condition_lower or "multiple" in condition_lower:
            has_arrays = any(fmt in answers_text for fmt in array_formats)
            is_geometry_only = any(fmt in answers_text for fmt in geometry_only_formats)
            is_source = any(term in answers_text for term in ["source", "sphere", "cone", "cube", "cylinder"])

            if is_geometry_only or is_source:
                return False
            return has_arrays

        # Check for rendering conditions
        if "rendering" in condition_lower or "interactive" in condition_lower:
            return any(term in answers_text for term in
                      ["interactive", "display", "window", "screenshot", "image", "png", "jpg", "render"])

        # Check for file output conditions
        if "file output" in condition_lower:
            return any(term in answers_text for term in
                      ["save", "write", "export"]) and not any(term in answers_text for term in
                      ["screenshot", "image", "png", "jpg", "display", "interactive"])

        # Default: include the question
        return True

    def synthesize(self) -> SessionResponse:
        """
        Synthesize the final prompt from all answers.

        Uses LLM to create a natural, complete prompt from the user's
        answers. Must be called after submit_prompt() and answering questions.

        Returns:
            SessionResponse with status='synthesized' and synthesized_prompt set
        """
        synthesized = self.clarifier.synthesize(
            self.state.original_prompt,
            self.state.answered_questions,
        )
        self.state.current_prompt = synthesized
        self.state.is_complete = True

        return SessionResponse(
            status="synthesized",
            prompt=self.state.original_prompt,
            synthesized_prompt=synthesized,
        )
