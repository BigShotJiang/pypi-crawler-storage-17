"""
Pydantic models for task decomposition.

Decomposes synthesized prompts into VTK pipeline tasks for code generation.
"""

from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

# =============================================================================
# Task Type Definitions - Single Source of Truth
# =============================================================================

TASK_TYPES: dict[str, dict[str, str]] = {
    "input": {
        "description": "Data source - file reader or procedural geometry source",
        "hint": "e.g., read brain.vti, load mesh.stl, create sphere source",
        "visibility": "explicit",
    },
    "filters": {
        "description": "Filters that transform, analyze, or process data",
        "hint": "e.g., isosurface at 128, smooth mesh, clip with plane",
        "visibility": "explicit",
    },
    "properties": {
        "description": "All actors - both mapper+actor pipelines AND standalone actors with internal mappers. Includes vtkPolyDataMapper+vtkActor, vtkScalarBarActor, vtkTextActor, vtkAxesActor. Properties control appearance (color, opacity, etc.)",
        "hint": "e.g., blue color, opacity 0.8, scalar bar, text label",
        "visibility": "implicit",  # Inferred - users don't mention mappers/actors directly
    },
    "renderer": {
        "description": "Create vtkRenderer and add all actors to it. Just the renderer - no window or interactor.",
        "hint": "e.g., create renderer, add actors, set background color",
        "visibility": "implicit",  # Inferred from output type
    },
    "scene": {
        "description": "Scene properties of the renderer - camera positioning (vtkCamera), lighting (vtkLight), widgets. These are properties/children of the renderer.",
        "hint": "e.g., set camera position, add headlight, adjust view angle",
        "visibility": "explicit",
    },
    "infrastructure": {
        "description": "Render window and interactor - vtkRenderWindow displays the renderer, vtkRenderWindowInteractor handles user input. This comes LAST (before output). interactor.Start() blocks.",
        "hint": "e.g., create window, start interactor, set window size",
        "visibility": "implicit",  # Inferred from output type
    },
    "output": {
        "description": "Write data or image to file",
        "hint": "e.g., save as PNG, write to STL, export as VTK",
        "visibility": "explicit",
    },
}

# Type alias for task type literals (order matches pipeline flow)
# Order: input → filters → properties → renderer → scene → infrastructure → output
TaskType = Literal["input", "filters", "properties", "renderer", "scene", "infrastructure", "output"]


# =============================================================================
# Output Type - determines which tasks are needed
# =============================================================================

OutputType = Literal["interactive", "image", "file", "none"]

# Mapping from output type to required task types (beyond explicit ones)
OUTPUT_REQUIRED_TASKS: dict[OutputType, list[TaskType]] = {
    "interactive": ["properties", "renderer", "infrastructure"],
    "image": ["properties", "renderer", "infrastructure", "output"],
    "file": ["output"],
    "none": [],
}


# =============================================================================
# Pydantic Models
# =============================================================================

class Task(BaseModel):
    """A single task in the VTK pipeline decomposition.

    Tasks are ordered and may have dependencies. Each task maps to
    a retrieval query for RAG-based code generation.
    """

    id: str = Field(
        ...,
        description="Unique identifier (e.g., 't1', 't2') for dependency tracking"
    )
    task_type: TaskType = Field(
        ...,
        description="Type of task - see TASK_TYPES for valid values"
    )
    description: str = Field(
        ...,
        description="Human-readable description of what this task accomplishes"
    )
    search_query: str = Field(
        ...,
        description="Query string for RAG retrieval to find relevant VTK examples"
    )
    depends_on: list[str] = Field(
        default_factory=list,
        description="List of task IDs that must complete before this task"
    )
    vtk_classes: list[str] = Field(
        default_factory=list,
        description="Suggested VTK classes for this task (hints for code generation)"
    )
    from_prompt: bool = Field(
        default=True,
        description="True if explicitly from user prompt, False if inferred (e.g., properties, renderer)"
    )


class DecompositionResult(BaseModel):
    """Result of decomposing a prompt into VTK pipeline tasks.

    Returned by the Decomposer after LLM analysis.
    """

    tasks: list[Task] = Field(
        ...,
        description="Ordered list of tasks forming the VTK pipeline"
    )
    output_type: OutputType = Field(
        ...,
        description="Detected output type - determines implicit tasks needed"
    )
    reasoning: str = Field(
        ...,
        description="LLM's reasoning for the decomposition"
    )

    @field_validator("tasks", mode="before")
    @classmethod
    def _coerce_tasks(cls, v: Any) -> Any:
        if not isinstance(v, list) or not v:
            return v

        if not all(isinstance(item, str) for item in v):
            return v

        def infer_task_type(name: str) -> TaskType:
            lowered = name.lower()
            if "reader" in lowered or "source" in lowered:
                return "input"
            if "renderer" in lowered:
                return "renderer"
            if "renderwindow" in lowered or "interactor" in lowered:
                return "infrastructure"
            if "mapper" in lowered or "actor" in lowered:
                return "properties"
            return "filters"

        coerced: list[dict[str, Any]] = []
        for idx, vtk_class in enumerate(v, start=1):
            task_type = infer_task_type(vtk_class)
            coerced.append(
                {
                    "id": f"t{idx}",
                    "task_type": task_type,
                    "description": f"Use {vtk_class}",
                    "search_query": vtk_class,
                    "depends_on": [f"t{idx - 1}"] if idx > 1 else [],
                    "vtk_classes": [vtk_class],
                    "from_prompt": False,
                }
            )

        return coerced


class TaskModification(BaseModel):
    """A modification to an existing task."""

    task_id: str = Field(
        ...,
        description="ID of the task to modify (e.g., 't3')"
    )
    feedback: str = Field(
        ...,
        description="What to change about this task"
    )


class TaskAddition(BaseModel):
    """A new task to add to the decomposition."""

    description: str = Field(
        ...,
        description="Description of the new task to add"
    )
    depends_on: str | None = Field(
        default=None,
        description="Optional: task ID this new task depends on"
    )


class RefinementRequest(BaseModel):
    """Request to refine the task decomposition.

    Contains modifications to existing tasks and/or new tasks to add.
    All changes are analyzed together to produce a reordered task list.
    """

    modifications: list[TaskModification] = Field(
        default_factory=list,
        description="Modifications to existing tasks"
    )
    additions: list[TaskAddition] = Field(
        default_factory=list,
        description="New tasks to add"
    )


class DecompositionState(BaseModel):
    """Internal state for decomposition session.

    Tracks the decomposition process and allows for iterative refinement.
    """

    original_prompt: str = Field(
        ...,
        description="The synthesized prompt being decomposed"
    )
    result: DecompositionResult | None = Field(
        default=None,
        description="Current decomposition result (None until decompose() called)"
    )
    is_complete: bool = Field(
        default=False,
        description="True when decomposition is finalized"
    )
    refinement_count: int = Field(
        default=0,
        description="Number of refinement iterations applied"
    )
    refinement_history: list[RefinementRequest] = Field(
        default_factory=list,
        description="History of refinement requests"
    )


class SessionResponse(BaseModel):
    """Response from the decomposition session.

    Returned to callers after decomposition operations.
    """

    status: Literal["pending", "complete"] = Field(
        ...,
        description="Current session status"
    )
    prompt: str = Field(
        ...,
        description="The prompt being decomposed"
    )
    tasks: list[Task] = Field(
        default_factory=list,
        description="Decomposed tasks (empty until complete)"
    )
    output_type: OutputType | None = Field(
        default=None,
        description="Detected output type"
    )
    refinement_count: int = Field(
        default=0,
        description="Number of refinements applied to reach this result"
    )
    is_finalized: bool = Field(
        default=False,
        description="True when decomposition is finalized and ready for code generation"
    )
