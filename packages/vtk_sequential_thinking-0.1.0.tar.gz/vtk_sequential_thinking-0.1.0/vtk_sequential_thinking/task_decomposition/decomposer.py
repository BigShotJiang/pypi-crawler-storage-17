"""Decomposer for breaking prompts into VTK pipeline tasks.

The Decomposer is the LLM interface for task decomposition.
It handles communication with the LLM and parsing responses.
Uses VTK API tools to search for and validate VTK class names.

All communication is JSON-based:
- Request includes available_tools
- Response can be {"tool_calls": [...]} or final result
- Tool calls are executed and results sent back as JSON
- Loop continues until final result

Usage:
    decomposer = Decomposer()  # Uses defaults from config
    result = decomposer.decompose("Read brain.vti and display interactively")

    # Or with explicit clients:
    decomposer = Decomposer(llm_client=llm_client, mcp_client=mcp_client)
"""

import json

from vtk_sequential_thinking.config import AppConfig, load_config
from vtk_sequential_thinking.llm.client import LLMClient
from vtk_sequential_thinking.llm.json_protocol import JSONProtocol
from vtk_sequential_thinking.mcp import MCPClient
from vtk_sequential_thinking.task_decomposition.models import (
    DecompositionResult,
    Task,
    TaskAddition,
    TaskModification,
)
from vtk_sequential_thinking.task_decomposition.prompts import (
    DECOMPOSITION_SYSTEM_PROMPT,
    build_decomposition_prompt,
    build_refinement_prompt,
)


class Decomposer:
    """LLM interface for decomposing prompts into VTK pipeline tasks.

    Handles:
    - Building JSON request prompts with embedded tool definitions
    - Calling the LLM and processing tool call responses in a loop
    - Parsing and validating final JSON responses

    Each method contains its own tool calling loop.
    """

    def __init__(
        self,
        llm_client: LLMClient | None = None,
        mcp_client: MCPClient | None = None,
        config: AppConfig | None = None,
    ):
        """Initialize the Decomposer.

        Args:
            llm_client: LLM client for API calls. If None, creates from config.
            mcp_client: MCP client for VTK API tools. If None, creates from config.
            config: Application configuration. If None, loads from environment.
        """
        self.config = config or load_config()
        self.llm_client = llm_client or LLMClient(app_config=self.config)
        self.mcp_client = mcp_client or MCPClient(app_config=self.config)
        self.protocol = JSONProtocol()
        self.tools = self.mcp_client.get_tool_definitions()

    def decompose(self, prompt: str) -> DecompositionResult:
        """Decompose a prompt into VTK pipeline tasks.

        Uses VTK API tools to search for and validate class names.
        All communication is JSON-based with tool calls embedded in responses.

        Args:
            prompt: The prompt to decompose

        Returns:
            DecompositionResult with ordered tasks

        Raises:
            ValueError: If LLM response cannot be parsed or validated
        """
        conversation: list[str] = []

        for iteration in range(self.mcp_client.max_tool_iterations):
            response = self.llm_client.generate(
                prompt=build_decomposition_prompt(prompt, self.tools, conversation),
                system=DECOMPOSITION_SYSTEM_PROMPT,
                temperature=0.3,
            )

            try:
                result, tool_calls, data = self.protocol.decode_or_tool_calls(
                    response, DecompositionResult
                )
            except ValueError as e:
                raise ValueError(f"Failed to parse JSON on iteration {iteration}: {e}")

            if tool_calls is None:
                return result

            # Add LLM's tool call request to conversation
            conversation.append(f"LLM response:\n{json.dumps(data, indent=2)}")

            # Execute tool calls
            results = self.protocol.execute_tool_calls(tool_calls, self.tools)

            # Add tool results to conversation
            tool_results_json = self.protocol.build_tool_results_message(results)
            conversation.append(f"Tool results:\n{tool_results_json}")

        raise ValueError(f"Max tool iterations ({self.mcp_client.max_tool_iterations}) exceeded")

    def refine(
        self,
        original_prompt: str,
        current_tasks: list[Task],
        modifications: list[TaskModification],
        additions: list[TaskAddition],
    ) -> DecompositionResult:
        """Refine an existing decomposition based on modifications and additions.

        Uses VTK API tools to search for and validate class names for new/modified tasks.
        All communication is JSON-based with tool calls embedded in responses.

        Args:
            original_prompt: The original prompt
            current_tasks: Current list of tasks
            modifications: Tasks to modify with feedback
            additions: New tasks to add

        Returns:
            Updated DecompositionResult with reordered tasks

        Raises:
            ValueError: If LLM response cannot be parsed or validated
        """
        conversation: list[str] = []
        current_tasks_dicts = [t.model_dump() for t in current_tasks]
        modifications_dicts = [m.model_dump() for m in modifications]
        additions_dicts = [a.model_dump() for a in additions]

        for iteration in range(self.mcp_client.max_tool_iterations):
            response = self.llm_client.generate(
                prompt=build_refinement_prompt(
                    original_prompt, current_tasks_dicts, modifications_dicts,
                    additions_dicts, self.tools, conversation
                ),
                system=DECOMPOSITION_SYSTEM_PROMPT,
                temperature=0.3,
            )

            try:
                result, tool_calls, data = self.protocol.decode_or_tool_calls(
                    response, DecompositionResult
                )
            except ValueError as e:
                raise ValueError(f"Failed to parse JSON on iteration {iteration}: {e}")

            if tool_calls is None:
                return result

            # Add LLM's tool call request to conversation
            conversation.append(f"LLM response:\n{json.dumps(data, indent=2)}")

            # Execute tool calls
            results = self.protocol.execute_tool_calls(tool_calls, self.tools)

            # Add tool results to conversation
            tool_results_json = self.protocol.build_tool_results_message(results)
            conversation.append(f"Tool results:\n{tool_results_json}")

        raise ValueError(f"Max tool iterations ({self.mcp_client.max_tool_iterations}) exceeded")
