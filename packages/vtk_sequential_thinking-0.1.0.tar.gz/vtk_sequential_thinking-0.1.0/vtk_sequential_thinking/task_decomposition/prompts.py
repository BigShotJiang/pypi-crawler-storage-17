"""LLM prompts for task decomposition.

All communication is pure JSON - complete request/response records.
Tool calling is embedded in the JSON protocol (available_tools in request,
tool_calls in response).

Two operations:
1. Decomposition: prompt → tasks
2. Refinement: current_tasks + modifications + additions → updated_tasks

Public API:
- build_decomposition_prompt(prompt): Complete JSON request for decomposition
- build_refinement_prompt(...): Complete JSON request for refinement
"""

import json

from vtk_sequential_thinking.task_decomposition.models import TASK_TYPES

# =============================================================================
# Shared Knowledge (included in both prompts)
# =============================================================================

_VTK_KNOWLEDGE = {
    "pipeline_architecture": {
        "sources_readers": "Produce data (vtkSphereSource, vtkSTLReader, vtkXMLImageDataReader)",
        "filters": "Process/transform data (vtkContourFilter, vtkSmoothPolyDataFilter, vtkClipPolyData)",
        "mappers": "Convert data to graphics primitives (vtkPolyDataMapper, vtkDataSetMapper)",
        "actors": "All actors including standalone ones (vtkActor, vtkScalarBarActor, vtkTextActor, vtkAxesActor)",
        "renderer": "Manage the scene (vtkRenderer) - actors are added here",
        "scene": "Camera and lighting (vtkCamera, vtkLight) - properties of the renderer",
        "infrastructure": "Display and interaction (vtkRenderWindow, vtkRenderWindowInteractor)",
        "writers": "Save data or images to files (vtkSTLWriter, vtkPNGWriter)"
    },
    "task_types": {name: info["description"] for name, info in TASK_TYPES.items()},
    "task_type_distinctions": {
        "properties": "ALL actors - both mapper+actor pipelines (vtkPolyDataMapper+vtkActor) AND standalone actors with internal mappers (vtkScalarBarActor, vtkTextActor, vtkAxesActor). These are added to renderer.",
        "renderer": "Just vtkRenderer creation - add all actors from properties tasks. Set background color.",
        "scene": "Camera positioning (vtkCamera), lighting (vtkLight), widgets. These are properties of the renderer, not actors.",
        "infrastructure": "vtkRenderWindow + vtkRenderWindowInteractor. This comes LAST (before output). The interactor.Start() blocks, so nothing runs after it."
    },
    "task_ordering": [
        "1. input (always first)",
        "2. filters (processing, in pipeline order)",
        "3. properties (ALL actors - mapper+actor AND standalone actors like scalar bar)",
        "4. renderer (create vtkRenderer, add all actors)",
        "5. scene (camera, lights - optional)",
        "6. infrastructure (vtkRenderWindow + vtkRenderWindowInteractor - LAST before output)",
        "7. output (if saving to file)"
    ],
    "output_type_inference": {
        "interactive": "'display interactively', 'show in window', 'visualize'",
        "image": "'save as PNG', 'screenshot', 'capture image'",
        "file": "'save as VTK', 'write to STL', 'export data'",
        "none": "no output mentioned - just process data"
    },
    "implicit_tasks": {
        "interactive": ["properties", "renderer", "infrastructure"],
        "image": ["properties", "renderer", "infrastructure", "output"],
        "file": ["output"],
        "none": []
    }
}

# =============================================================================
# Task Schema (shared between decomposition and refinement)
# =============================================================================

_TASK_SCHEMA = {
    "id": "string (t1, t2, ...)",
    "task_type": "input | filters | properties | renderer | scene | infrastructure | output",
    "description": "what this task accomplishes",
    "search_query": "action-oriented query for RAG retrieval (no class names)",
    "depends_on": ["list of task ids this depends on"],
    "vtk_classes": ["suggested VTK classes"],
    "from_prompt": "true if explicit in prompt, false if inferred"
}

_RESPONSE_SCHEMA = {
    "tasks": [_TASK_SCHEMA],
    "output_type": "interactive | image | file | none",
    "reasoning": "explanation of the decomposition or refinement"
}


# =============================================================================
# Decomposition Examples
# =============================================================================

_DECOMPOSITION_EXAMPLES = [
    {
        "input": {
            "prompt": "Read brain.vti, create an isosurface at value 128, and display interactively with blue color"
        },
        "output": {
            "tasks": [
                {"id": "t1", "task_type": "input", "description": "Read VTK ImageData file brain.vti", "search_query": "read .vti XML image data file", "depends_on": [], "vtk_classes": ["vtkXMLImageDataReader"], "from_prompt": True},
                {"id": "t2", "task_type": "filters", "description": "Create isosurface at value 128", "search_query": "create isosurface contour from volume data", "depends_on": ["t1"], "vtk_classes": ["vtkContourFilter"], "from_prompt": True},
                {"id": "t3", "task_type": "properties", "description": "Create mapper and actor with blue color", "search_query": "map polydata to graphics and set actor color", "depends_on": ["t2"], "vtk_classes": ["vtkPolyDataMapper", "vtkActor", "vtkProperty"], "from_prompt": False},
                {"id": "t4", "task_type": "renderer", "description": "Create renderer and add actor", "search_query": "create renderer and add actors", "depends_on": ["t3"], "vtk_classes": ["vtkRenderer"], "from_prompt": False},
                {"id": "t5", "task_type": "infrastructure", "description": "Create render window and interactor", "search_query": "create render window and interactor for interactive display", "depends_on": ["t4"], "vtk_classes": ["vtkRenderWindow", "vtkRenderWindowInteractor"], "from_prompt": False}
            ],
            "output_type": "interactive",
            "reasoning": "Read .vti file, apply contour, display interactively. Blue color is a properties task. Interactive requires properties, renderer, and infrastructure."
        }
    },
    {
        "input": {
            "prompt": "Load mesh.stl, smooth it, and save as mesh_smooth.vtk"
        },
        "output": {
            "tasks": [
                {"id": "t1", "task_type": "input", "description": "Load STL mesh file", "search_query": "read STL mesh file", "depends_on": [], "vtk_classes": ["vtkSTLReader"], "from_prompt": True},
                {"id": "t2", "task_type": "filters", "description": "Smooth the mesh surface", "search_query": "smooth polydata mesh surface", "depends_on": ["t1"], "vtk_classes": ["vtkSmoothPolyDataFilter"], "from_prompt": True},
                {"id": "t3", "task_type": "output", "description": "Write smoothed mesh to VTK file", "search_query": "write polydata to .vtk file", "depends_on": ["t2"], "vtk_classes": ["vtkPolyDataWriter"], "from_prompt": True}
            ],
            "output_type": "file",
            "reasoning": "Read STL, smooth, write to file. No visualization needed - just file output. No properties or renderer required."
        }
    },
    {
        "input": {
            "prompt": "Create a sphere, clip it with a plane, and save a screenshot as sphere.png"
        },
        "output": {
            "tasks": [
                {"id": "t1", "task_type": "input", "description": "Create sphere geometry source", "search_query": "generate sphere geometry", "depends_on": [], "vtk_classes": ["vtkSphereSource"], "from_prompt": True},
                {"id": "t2", "task_type": "filters", "description": "Clip sphere with a plane", "search_query": "clip polydata with plane", "depends_on": ["t1"], "vtk_classes": ["vtkClipPolyData", "vtkPlane"], "from_prompt": True},
                {"id": "t3", "task_type": "properties", "description": "Create mapper and actor for clipped sphere", "search_query": "map polydata to graphics for rendering", "depends_on": ["t2"], "vtk_classes": ["vtkPolyDataMapper", "vtkActor"], "from_prompt": False},
                {"id": "t4", "task_type": "renderer", "description": "Create renderer and add actor", "search_query": "create renderer and add actors", "depends_on": ["t3"], "vtk_classes": ["vtkRenderer"], "from_prompt": False},
                {"id": "t5", "task_type": "infrastructure", "description": "Create render window for offscreen rendering", "search_query": "create render window for offscreen rendering", "depends_on": ["t4"], "vtk_classes": ["vtkRenderWindow"], "from_prompt": False},
                {"id": "t6", "task_type": "output", "description": "Save screenshot as PNG", "search_query": "capture render window to PNG image file", "depends_on": ["t5"], "vtk_classes": ["vtkWindowToImageFilter", "vtkPNGWriter"], "from_prompt": True}
            ],
            "output_type": "image",
            "reasoning": "Create sphere source, clip with plane, render to image. Image output requires properties, renderer, infrastructure, and output tasks."
        }
    }
]


# =============================================================================
# Refinement Examples
# =============================================================================

_REFINEMENT_EXAMPLES = [
    {
        "input": {
            "current_tasks": [
                {"id": "t1", "task_type": "input", "description": "Read volume.vti", "depends_on": [], "vtk_classes": ["vtkXMLImageDataReader"]},
                {"id": "t2", "task_type": "filters", "description": "Create contour at 135", "depends_on": ["t1"], "vtk_classes": ["vtkContourFilter"]},
                {"id": "t3", "task_type": "properties", "description": "Mapper and actor for contour", "depends_on": ["t2"], "vtk_classes": ["vtkPolyDataMapper", "vtkActor"]},
                {"id": "t4", "task_type": "renderer", "description": "Create renderer and add actors", "depends_on": ["t3"], "vtk_classes": ["vtkRenderer"]},
                {"id": "t5", "task_type": "infrastructure", "description": "Render window and interactor", "depends_on": ["t4"], "vtk_classes": ["vtkRenderWindow", "vtkRenderWindowInteractor"]}
            ],
            "modifications": [
                {"task_id": "t3", "feedback": "Add scalar bar and set opacity to 0.8"}
            ],
            "additions": [
                {"description": "Add outline box around the volume", "depends_on": "t1"}
            ]
        },
        "analysis": {
            "modification_t3": "Opacity is a properties task (modify t3). Scalar bar is a standalone actor - also a properties task (new task).",
            "addition_outline": "Outline filter is filters type, needs its own properties task."
        },
        "output": {
            "tasks": [
                {"id": "t1", "task_type": "input", "description": "Read volume.vti", "search_query": "read .vti XML image data file", "depends_on": [], "vtk_classes": ["vtkXMLImageDataReader"], "from_prompt": True},
                {"id": "t2", "task_type": "filters", "description": "Create outline filter for bounding box", "search_query": "create outline bounding box around data", "depends_on": ["t1"], "vtk_classes": ["vtkOutlineFilter"], "from_prompt": True},
                {"id": "t3", "task_type": "filters", "description": "Create contour at 135", "search_query": "create isosurface contour from volume data", "depends_on": ["t1"], "vtk_classes": ["vtkContourFilter"], "from_prompt": True},
                {"id": "t4", "task_type": "properties", "description": "Mapper and actor for outline", "search_query": "map polydata to graphics for rendering", "depends_on": ["t2"], "vtk_classes": ["vtkPolyDataMapper", "vtkActor"], "from_prompt": False},
                {"id": "t5", "task_type": "properties", "description": "Mapper and actor for contour with opacity 0.8", "search_query": "map polydata to graphics and set opacity", "depends_on": ["t3"], "vtk_classes": ["vtkPolyDataMapper", "vtkActor", "vtkProperty"], "from_prompt": False},
                {"id": "t6", "task_type": "properties", "description": "Scalar bar showing color mapping", "search_query": "create scalar bar actor for color legend", "depends_on": ["t5"], "vtk_classes": ["vtkScalarBarActor"], "from_prompt": True},
                {"id": "t7", "task_type": "renderer", "description": "Create renderer and add all actors", "search_query": "create renderer and add actors", "depends_on": ["t4", "t5", "t6"], "vtk_classes": ["vtkRenderer"], "from_prompt": False},
                {"id": "t8", "task_type": "infrastructure", "description": "Render window and interactor", "search_query": "create render window and interactor for interactive display", "depends_on": ["t7"], "vtk_classes": ["vtkRenderWindow", "vtkRenderWindowInteractor"], "from_prompt": False}
            ],
            "output_type": "interactive",
            "reasoning": "Modified t5 to add opacity (property). Added outline filter (t2) with its own properties task (t4). Scalar bar (t6) is a properties task (standalone actor). Renderer (t7) adds ALL actors. Infrastructure (t8) comes LAST."
        }
    }
]


# =============================================================================
# System Prompt (shared)
# =============================================================================

DECOMPOSITION_SYSTEM_PROMPT = """You are a VTK pipeline decomposition expert.

Your task is to break down user requests into ordered VTK pipeline tasks.
You communicate using JSON and have access to VTK API tools for class validation.

IMPORTANT: Always use the available tools to validate VTK class names.
Do NOT guess class names - use search_vtk_classes to find them and
validate_vtk_classes_batch to verify they exist.

Respond with valid JSON matching the response_format schema."""


# =============================================================================
# Decomposition Prompt
# =============================================================================

def build_decomposition_prompt(
    prompt: str,
    tools: list[dict],
    conversation: list[str],
) -> str:
    """Build full prompt for decomposition.

    On first call (empty conversation), builds the initial request with tools.
    On subsequent calls, joins conversation history into full prompt.

    Args:
        prompt: The synthesized prompt to decompose
        tools: Tool definitions from MCP client
        conversation: Conversation history (mutated - initial request appended on first call)

    Returns:
        Full prompt string to send to LLM
    """
    if not conversation:
        request = {
            "action": "decompose",
            "input": {
                "prompt": prompt
            },
            "knowledge": _VTK_KNOWLEDGE,
            "examples": _DECOMPOSITION_EXAMPLES,
            "instructions": {
                "task": "Decompose the prompt into ordered VTK pipeline tasks",
                "steps": [
                    "1. Identify data sources (readers, sources) → input tasks",
                    "2. Identify processing operations (filters) → filters tasks",
                    "3. Identify scene requirements (camera, lighting) → scene tasks",
                    "4. Identify output requirements (save to file) → output tasks",
                    "5. Determine output_type from prompt (interactive, image, file, none)",
                    "6. Add implicit tasks based on output_type (properties, renderer, infrastructure)",
                    "7. Order tasks by pipeline flow: input → filters → properties → renderer → scene → infrastructure → output",
                    "8. For each task, use search_vtk_classes to find appropriate VTK classes",
                    "9. Collect all VTK class names and use validate_vtk_classes_batch to verify them all at once",
                    "10. Generate search_query for each task (action-oriented, no class names)"
                ],
                "vtk_class_validation": "IMPORTANT: Always use the available tools to validate VTK class names. Do NOT guess class names from memory - use search_vtk_classes to find them and validate_vtk_classes_batch to verify they all exist in a single call.",
                "mark_implicit": "Set from_prompt=false for inferred tasks (properties, renderer, infrastructure)"
            },
            "response_format": _RESPONSE_SCHEMA
        }
        if tools:
            request["available_tools"] = [
                {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters,
                }
                for tool in tools
            ]
        conversation.append(json.dumps(request, indent=2))

    return "\n\n".join(conversation)


# =============================================================================
# Refinement Prompt
# =============================================================================

def build_refinement_prompt(
    original_prompt: str,
    current_tasks: list[dict],
    modifications: list[dict],
    additions: list[dict],
    tools: list[dict],
    conversation: list[str],
) -> str:
    """Build full prompt for refinement.

    On first call (empty conversation), builds the initial request with tools.
    On subsequent calls, joins conversation history into full prompt.

    Args:
        original_prompt: The original synthesized prompt
        current_tasks: Current task list as dicts
        modifications: List of {task_id, feedback} for tasks to modify
        additions: List of {description, depends_on} for new tasks
        tools: Tool definitions from MCP client
        conversation: Conversation history (mutated - initial request appended on first call)

    Returns:
        Full prompt string to send to LLM
    """
    if not conversation:
        request = {
            "action": "refine",
            "input": {
                "original_prompt": original_prompt,
                "current_tasks": current_tasks,
                "modifications": modifications,
                "additions": additions
            },
            "knowledge": _VTK_KNOWLEDGE,
            "examples": _REFINEMENT_EXAMPLES,
            "instructions": {
                "task": "Refine the task decomposition based on modifications and additions",
                "analysis": [
                    "For each modification/addition, determine:",
                    "- Is it a property change to an existing task? (e.g., opacity → modify properties task)",
                    "- Is it a new actor? (e.g., scalar bar, text label → new 'properties' task)",
                    "- Is it a scene change? (e.g., camera position, lighting → 'scene' task)",
                    "- Does a new filters task need its own properties task?"
                ],
                "execution": [
                    "1. Apply property changes to existing tasks",
                    "2. Create new tasks with appropriate type and dependencies",
                    "3. Scalar bar actors depend on the properties task whose lookup table they reference",
                    "4. For new/modified tasks, use search_vtk_classes to find appropriate VTK classes",
                    "5. Collect all VTK class names and use validate_vtk_classes_batch to verify them all at once",
                    "6. Reorder all tasks by pipeline flow: input → filters → properties → renderer → scene → infrastructure → output",
                    "7. Assign new sequential IDs (t1, t2, ...)"
                ],
                "vtk_class_validation": "IMPORTANT: Always use the available tools to validate VTK class names. Do NOT guess class names from memory - use search_vtk_classes to find them and validate_vtk_classes_batch to verify they all exist in a single call."
            },
            "response_format": _RESPONSE_SCHEMA
        }
        if tools:
            request["available_tools"] = [
                {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters,
                }
                for tool in tools
            ]
        conversation.append(json.dumps(request, indent=2))

    return "\n\n".join(conversation)
