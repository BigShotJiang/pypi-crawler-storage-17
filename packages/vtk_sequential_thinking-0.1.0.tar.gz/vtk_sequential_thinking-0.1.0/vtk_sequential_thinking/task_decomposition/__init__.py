"""
Task decomposition for VTK pipeline code generation.

Decomposes synthesized prompts into ordered VTK pipeline tasks.
Each task maps to a RAG retrieval query for code generation.
"""

from vtk_sequential_thinking.task_decomposition.decomposer import Decomposer
from vtk_sequential_thinking.task_decomposition.models import (
    TASK_TYPES,
    DecompositionResult,
    OutputType,
    RefinementRequest,
    SessionResponse,
    Task,
    TaskAddition,
    TaskModification,
    TaskType,
)
from vtk_sequential_thinking.task_decomposition.session import Session

__all__ = [
    "Decomposer",
    "DecompositionResult",
    "OutputType",
    "RefinementRequest",
    "Session",
    "SessionResponse",
    "Task",
    "TaskAddition",
    "TaskModification",
    "TaskType",
    "TASK_TYPES",
]
