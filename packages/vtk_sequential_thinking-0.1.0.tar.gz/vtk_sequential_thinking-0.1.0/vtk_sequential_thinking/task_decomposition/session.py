"""Session for orchestrating task decomposition.

Usage:
    session = Session.from_config(config)

    # 1. Decompose prompt into tasks
    response = session.decompose("Read brain.vti and display interactively")

    # 2. Refine until satisfied
    while not satisfied:
        response = session.refine(modifications, additions)

    # 3. Finalize and use tasks
    response = session.finalize()
    for task in response.tasks:
        print(f"{task.id}: {task.description}")
"""

from vtk_sequential_thinking.config import AppConfig, load_config
from vtk_sequential_thinking.llm.client import LLMClient
from vtk_sequential_thinking.mcp import MCPClient
from vtk_sequential_thinking.task_decomposition.decomposer import Decomposer
from vtk_sequential_thinking.task_decomposition.models import (
    OUTPUT_REQUIRED_TASKS,
    DecompositionResult,
    DecompositionState,
    RefinementRequest,
    SessionResponse,
    Task,
    TaskAddition,
    TaskModification,
)


class Session:
    """Orchestrates the task decomposition workflow.

    Manages state and coordinates with the Decomposer to break
    prompts into VTK pipeline tasks.
    """

    def __init__(
        self,
        llm_client: LLMClient | None = None,
        mcp_client: MCPClient | None = None,
        decomposer: Decomposer | None = None,
        config: AppConfig | None = None,
    ):
        """Initialize the session.

        Args:
            llm_client: LLM client for API calls. If None, creates one.
                        Pass this to reuse a client across activities.
            mcp_client: MCP client for VTK API. If None, creates one.
                        Pass this to reuse across activities.
            decomposer: Decomposer for LLM communication. If None, creates one.
            config: Application configuration. If None, loads from environment.
        """
        self.config = config or load_config()
        llm_client = llm_client or LLMClient(app_config=self.config)
        mcp_client = mcp_client or MCPClient(app_config=self.config)
        self.decomposer = decomposer or Decomposer(
            llm_client=llm_client,
            mcp_client=mcp_client,
            config=self.config,
        )
        self.state: DecompositionState | None = None

    @classmethod
    def from_config(
        cls,
        config: AppConfig | None = None,
        llm_client: LLMClient | None = None,
        mcp_client: MCPClient | None = None,
    ) -> "Session":
        """Create a Session from configuration.

        Args:
            config: Application configuration. If None, loads from environment.
            llm_client: LLM client to reuse. If None, creates one.
            mcp_client: MCP client to reuse. If None, creates one.

        Returns:
            Configured Session instance
        """
        return cls(config=config, llm_client=llm_client, mcp_client=mcp_client)

    def decompose(self, prompt: str) -> SessionResponse:
        """Decompose a prompt into VTK pipeline tasks.

        Must be called first. Call refine() to iterate, then finalize().

        Args:
            prompt: The prompt to decompose

        Returns:
            SessionResponse with status and tasks
        """
        # Initialize state
        self.state = DecompositionState(original_prompt=prompt)

        # Call decomposer
        result = self.decomposer.decompose(prompt)

        # Validate and potentially add missing implicit tasks
        result = self._ensure_implicit_tasks(result)

        # Validate task ordering
        result = self._validate_ordering(result)

        # Update state
        self.state.result = result

        return SessionResponse(
            status="complete",
            prompt=prompt,
            tasks=result.tasks,
            output_type=result.output_type,
        )

    def refine(
        self,
        modifications: list[TaskModification] | None = None,
        additions: list[TaskAddition] | None = None,
    ) -> SessionResponse:
        """Refine the current decomposition with modifications and additions.

        All changes are analyzed together and the LLM produces a complete,
        reordered task list from input to output based on dependencies.

        Must be called after decompose(). Raises if no decomposition exists.

        Args:
            modifications: Tasks to modify (task_id + feedback)
            additions: New tasks to add (description + optional depends_on)

        Returns:
            SessionResponse with updated, reordered tasks
        """
        modifications = modifications or []
        additions = additions or []

        # Create refinement request for history
        refinement = RefinementRequest(
            modifications=modifications,
            additions=additions,
        )

        # Call decomposer to refine - single LLM call with all changes
        result = self.decomposer.refine(
            original_prompt=self.state.original_prompt,
            current_tasks=self.state.result.tasks,
            modifications=modifications,
            additions=additions,
        )

        # Validate and fix ordering
        result = self._ensure_implicit_tasks(result)
        result = self._validate_ordering(result)

        # Update state
        self.state.result = result
        self.state.refinement_count += 1
        self.state.refinement_history.append(refinement)

        return SessionResponse(
            status="complete",
            prompt=self.state.original_prompt,
            tasks=result.tasks,
            output_type=result.output_type,
            refinement_count=self.state.refinement_count,
        )

    def finalize(self) -> SessionResponse:
        """Finalize the decomposition and mark it complete.

        After finalization, no more refinements can be made.
        The tasks are ready for code generation.

        Must be called after decompose(). Raises if no decomposition exists.

        Returns:
            SessionResponse with finalized tasks
        """
        self.state.is_complete = True

        return SessionResponse(
            status="complete",
            prompt=self.state.original_prompt,
            tasks=self.state.result.tasks,
            output_type=self.state.result.output_type,
            refinement_count=self.state.refinement_count,
            is_finalized=True,
        )

    def _ensure_implicit_tasks(self, result: DecompositionResult) -> DecompositionResult:
        """Ensure all implicit tasks for the output type are present.

        If the LLM missed any required implicit tasks (properties, renderer, etc.),
        this method adds them.

        Args:
            result: The decomposition result from the LLM

        Returns:
            Updated result with any missing implicit tasks added
        """
        required_types = OUTPUT_REQUIRED_TASKS.get(result.output_type, [])
        existing_types = {task.task_type for task in result.tasks}

        missing_types = [t for t in required_types if t not in existing_types]

        if not missing_types:
            return result

        # Add missing tasks
        tasks = list(result.tasks)
        next_id = len(tasks) + 1

        for task_type in missing_types:
            # Find the last task to depend on
            last_task_id = tasks[-1].id if tasks else None

            task = self._create_implicit_task(
                task_id=f"t{next_id}",
                task_type=task_type,
                depends_on=[last_task_id] if last_task_id else [],
            )
            tasks.append(task)
            next_id += 1

        return DecompositionResult(
            tasks=tasks,
            output_type=result.output_type,
            reasoning=result.reasoning + f" (Added missing implicit tasks: {missing_types})",
        )

    def _create_implicit_task(
        self,
        task_id: str,
        task_type: str,
        depends_on: list[str],
    ) -> Task:
        """Create an implicit task that wasn't in the LLM response.

        Args:
            task_id: ID for the new task
            task_type: Type of task to create
            depends_on: Task dependencies

        Returns:
            New Task instance
        """
        templates = {
            "properties": {
                "description": "Create mapper and actor for visualization",
                "search_query": "map polydata to graphics for rendering",
                "vtk_classes": ["vtkPolyDataMapper", "vtkActor", "vtkProperty"],
            },
            "renderer": {
                "description": "Create renderer and add actors",
                "search_query": "create renderer and add actors",
                "vtk_classes": ["vtkRenderer"],
            },
            "infrastructure": {
                "description": "Create render window and interactor",
                "search_query": "create render window and interactor for interactive display",
                "vtk_classes": ["vtkRenderWindow", "vtkRenderWindowInteractor"],
            },
            "output": {
                "description": "Write output to file",
                "search_query": "write data to file",
                "vtk_classes": [],
            },
        }

        template = templates.get(task_type, {
            "description": f"Perform {task_type}",
            "search_query": f"perform {task_type} operation",
            "vtk_classes": [],
        })

        return Task(
            id=task_id,
            task_type=task_type,
            description=template["description"],
            search_query=template["search_query"],
            depends_on=depends_on,
            vtk_classes=template["vtk_classes"],
            from_prompt=False,
        )

    def _validate_ordering(self, result: DecompositionResult) -> DecompositionResult:
        """Validate and fix task ordering if needed.

        Ensures tasks follow VTK pipeline order:
        1. input
        2. filters
        3. properties (ALL actors - mapper+actor AND standalone like scalar bar)
        4. renderer (create vtkRenderer, add actors)
        5. scene (camera, lights - properties of renderer)
        6. infrastructure (vtkRenderWindow + vtkRenderWindowInteractor - LAST)
        7. output

        Args:
            result: The decomposition result

        Returns:
            Result with corrected ordering if needed
        """
        # Define priority order
        type_priority = {
            "input": 0,
            "filters": 1,
            "properties": 2,
            "renderer": 3,
            "scene": 4,
            "infrastructure": 5,
            "output": 6,
        }

        # Sort tasks by priority, preserving order within same priority
        sorted_tasks = sorted(
            result.tasks,
            key=lambda t: (type_priority.get(t.task_type, 99), t.id)
        )

        # Reassign IDs and dependencies
        id_mapping: dict[str, str] = {}
        reordered_tasks: list[Task] = []

        for i, task in enumerate(sorted_tasks):
            new_id = f"t{i + 1}"
            id_mapping[task.id] = new_id

            # Update dependencies to use new IDs
            new_depends = [id_mapping.get(d, d) for d in task.depends_on if d in id_mapping]

            # If no dependencies but not first task, depend on previous
            if not new_depends and i > 0:
                new_depends = [f"t{i}"]

            reordered_tasks.append(Task(
                id=new_id,
                task_type=task.task_type,
                description=task.description,
                search_query=task.search_query,
                depends_on=new_depends,
                vtk_classes=task.vtk_classes,
                from_prompt=task.from_prompt,
            ))

        return DecompositionResult(
            tasks=reordered_tasks,
            output_type=result.output_type,
            reasoning=result.reasoning,
        )

    def reset(self) -> None:
        """Reset the session state."""
        self.state = None
