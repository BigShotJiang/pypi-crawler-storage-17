#!/bin/bash
# VTK Sequential Thinking Pipeline - Setup Script
# Creates virtual environment and installs dependencies using uv
#
# Usage:
#   ./setup.sh          # Interactive mode (asks for each component)
#   ./setup.sh --all    # Install everything without prompts

set -e  # Exit on error

# Check for --all flag
INSTALL_ALL=false
if [[ "$1" == "--all" ]]; then
    INSTALL_ALL=true
fi

echo "========================================="
echo "VTK Sequential Thinking Pipeline Setup"
echo "========================================="
echo ""
if [ "$INSTALL_ALL" = true ]; then
    echo "Mode: Install ALL dependencies"
else
    echo "Mode: Interactive (selective installation)"
fi
echo ""

# Check if uv is installed
if ! command -v uv &> /dev/null; then
    echo "Error: uv is required but not installed."
    echo "Install uv: curl -LsSf https://astral.sh/uv/install.sh | sh"
    exit 1
fi

echo "Using uv version: $(uv --version)"

# Check if virtual environment already exists
if [ -d ".venv" ]; then
    echo "Virtual environment already exists. Use it or delete it first."
    echo "To use existing: source .venv/bin/activate"
    echo "To delete: rm -rf .venv"
    exit 1
fi

# Create virtual environment with uv
echo ""
echo "Creating virtual environment with uv..."
uv venv .venv

# Activate virtual environment
echo ""
echo "Activating virtual environment..."
source .venv/bin/activate
echo "✓ Virtual environment activated"

# Install core package with dependencies
echo ""
echo "Installing vtk-sequential-thinking package..."
uv pip install -e ".[dev]"
echo "✓ Core package installed"

# Install LLM providers
echo ""
if [ "$INSTALL_ALL" = true ]; then
    REPLY="y"
else
    read -p "Install LLM providers (OpenAI, Anthropic, Google)? (y/n) " -n 1 -r
    echo ""
fi
if [[ $REPLY =~ ^[Yy]$ ]] || [ "$INSTALL_ALL" = true ]; then
    echo "Installing LLM provider SDKs..."
    uv pip install openai anthropic google-generativeai
    echo "✓ LLM providers installed"
else
    echo "Skipping LLM providers. Install later with: uv pip install openai anthropic google-generativeai"
fi

# Optional: Install evaluation dependencies
echo ""
if [ "$INSTALL_ALL" = true ]; then
    REPLY="y"
else
    read -p "Install evaluation dependencies (requires VTK)? (y/n) " -n 1 -r
    echo ""
fi
if [[ $REPLY =~ ^[Yy]$ ]] || [ "$INSTALL_ALL" = true ]; then
    echo "Installing evaluation dependencies..."
    uv pip install -e ".[eval]"
    echo "✓ Evaluation dependencies installed"
else
    echo "Skipping evaluation. Install later with: uv pip install -e \".[eval]\""
fi

# Optional: Install visual testing dependencies
echo ""
if [ "$INSTALL_ALL" = true ]; then
    REPLY="y"
else
    read -p "Install visual testing dependencies (VTK + image processing)? (y/n) " -n 1 -r
    echo ""
fi
if [[ $REPLY =~ ^[Yy]$ ]] || [ "$INSTALL_ALL" = true ]; then
    echo "Installing visual testing dependencies..."
    uv pip install -e ".[visual]"
    echo "✓ Visual testing dependencies installed"
else
    echo "Skipping visual testing. Install later with: uv pip install -e \".[visual]\""
fi

# Optional: Install RAG dependencies
echo ""
if [ "$INSTALL_ALL" = true ]; then
    REPLY="y"
else
    read -p "Install RAG dependencies (Qdrant, sentence-transformers)? (y/n) " -n 1 -r
    echo ""
fi
if [[ $REPLY =~ ^[Yy]$ ]] || [ "$INSTALL_ALL" = true ]; then
    echo "Installing RAG dependencies..."
    uv pip install -e ".[rag]"
    echo "✓ RAG dependencies installed"
else
    echo "Skipping RAG. Install later with: uv pip install -e \".[rag]\""
fi

echo ""
echo "========================================="
echo "Setup Complete!"
echo "========================================="
echo ""
echo "To activate the virtual environment in the future, run:"
echo "  source .venv/bin/activate"
echo ""
echo "To deactivate when done:"
echo "  deactivate"
echo ""
echo "Next steps:"
echo "  1. Configure LLM: cp .env.example .env (then edit with your API key)"
echo "  2. Start Qdrant: docker run -d -p 6333:6333 qdrant/qdrant"
echo "  3. Index your data: (see README.md for indexing instructions)"
echo "  4. Run CLI: vtk-st --help"
echo ""
echo "Quick install all dependencies (non-interactive):"
echo "  ./setup.sh --all"
echo ""
echo "See README.md for full documentation."
echo ""
