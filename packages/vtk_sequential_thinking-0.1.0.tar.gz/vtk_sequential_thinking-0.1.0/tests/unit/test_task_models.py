from __future__ import annotations

from vtk_sequential_thinking.task_decomposition.models import DecompositionResult


def test_decomposition_result_coerces_tasks_from_class_name_list() -> None:
    result = DecompositionResult.model_validate(
        {
            "tasks": ["vtkSphereSource", "vtkPolyDataMapper"],
            "output_type": "interactive",
            "reasoning": "test",
        }
    )

    assert len(result.tasks) == 2
    assert result.tasks[0].id == "t1"
    assert result.tasks[0].vtk_classes == ["vtkSphereSource"]
    assert result.tasks[1].depends_on == ["t1"]
