from __future__ import annotations

from vtk_sequential_thinking.llm.json_protocol import JSONProtocol
from vtk_sequential_thinking.task_decomposition.models import DecompositionResult


def test_extract_json_from_markdown_fence() -> None:
    proto = JSONProtocol()
    raw = """```json
{"a": 1, "b": [2, 3]}
```"""
    assert proto.extract_json(raw) == {"a": 1, "b": [2, 3]}


def test_parse_tool_calls_accepts_parameters_alias() -> None:
    proto = JSONProtocol()
    data = {"name": "search_vtk_classes", "parameters": {"query": "vtkSphereSource"}}
    calls = proto.parse_tool_calls(data)
    assert calls is not None
    assert len(calls) == 1
    assert calls[0].name == "search_vtk_classes"
    assert calls[0].arguments == {"query": "vtkSphereSource"}


def test_decode_or_tool_calls_wraps_class_names() -> None:
    proto = JSONProtocol()
    raw = '{"class_names": ["vtkSphereSource", "vtkPolyDataMapper"]}'

    model, tool_calls, data = proto.decode_or_tool_calls(raw, DecompositionResult)
    assert tool_calls is None
    assert data["tasks"] == ["vtkSphereSource", "vtkPolyDataMapper"]
    assert data["output_type"] == "interactive"
    assert data["reasoning"] == "Wrapped from class_names response"
    assert model is not None
    assert model.output_type == "interactive"
    assert len(model.tasks) == 2
    assert model.tasks[0].vtk_classes == ["vtkSphereSource"]
