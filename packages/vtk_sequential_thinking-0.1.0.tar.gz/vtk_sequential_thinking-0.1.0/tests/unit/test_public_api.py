from __future__ import annotations


def test_public_api_imports() -> None:
    from vtk_sequential_thinking import (
        ClarificationSession,
        DecompositionSession,
        GenerationSession,
        LLMClient,
        MCPClient,
        RAGClient,
        load_config,
    )

    assert ClarificationSession is not None
    assert DecompositionSession is not None
    assert GenerationSession is not None
    assert LLMClient is not None
    assert MCPClient is not None
    assert RAGClient is not None
    assert load_config is not None


def test_renamed_modules_importable() -> None:
    import vtk_sequential_thinking.prompt_clarification as prompt_clarification
    import vtk_sequential_thinking.sequential_generation as sequential_generation

    assert prompt_clarification is not None
    assert sequential_generation is not None
