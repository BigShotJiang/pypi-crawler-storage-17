from __future__ import annotations

from typer.testing import CliRunner

from vtk_sequential_thinking.cli import app


def test_cli_help_smoke() -> None:
    runner = CliRunner()
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0

    # Basic smoke assertions: ensure core commands are present.
    assert "evaluate" in result.stdout
    assert "query" in result.stdout
    assert "decompose" in result.stdout
    assert "generate" in result.stdout
    assert "pipeline" in result.stdout
