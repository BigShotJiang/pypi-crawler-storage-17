from __future__ import annotations

import json

from typer.testing import CliRunner

import vtk_sequential_thinking.cli as cli
from vtk_sequential_thinking.prompt_clarification.models import ClarityResult


def test_cli_evaluate_json(monkeypatch) -> None:
    class DummyLLMClient:
        def __init__(self, *args, **kwargs) -> None:
            pass

    class DummyClarifier:
        def __init__(self, *args, **kwargs) -> None:
            pass

        def evaluate(self, prompt: str) -> ClarityResult:
            return ClarityResult(
                is_clear=True,
                confidence=1.0,
                missing_details=[],
                clarifying_questions=[],
                reasoning="ok",
            )

    monkeypatch.setattr(cli, "LLMClient", DummyLLMClient)
    monkeypatch.setattr(cli, "Clarifier", DummyClarifier)

    runner = CliRunner()
    result = runner.invoke(cli.app, ["evaluate", "hello", "--json"])
    assert result.exit_code == 0

    payload = json.loads(result.stdout)
    assert payload["is_clear"] is True


def test_cli_generate_writes_file(monkeypatch, tmp_path) -> None:
    class DummyLLMClient:
        def __init__(self, *args, **kwargs) -> None:
            pass

    class DummyMCPClient:
        def __init__(self, *args, **kwargs) -> None:
            pass

    class DummyPipelineResult:
        def __init__(self) -> None:
            self.code = "print('hi')\n"
            self.task_results = []

    class DummyGenerationSession:
        @classmethod
        def from_config(cls, *args, **kwargs):
            return cls()

        def generate(self, *args, **kwargs):
            return DummyPipelineResult()

    monkeypatch.setattr(cli, "LLMClient", DummyLLMClient)
    monkeypatch.setattr(cli, "MCPClient", DummyMCPClient)
    monkeypatch.setattr(cli, "GenerationSession", DummyGenerationSession)

    tasks_json = tmp_path / "tasks.json"
    tasks_json.write_text(
        json.dumps(
            {
                "tasks": [
                    {
                        "id": "t1",
                        "task_type": "input",
                        "description": "Use vtkSphereSource",
                        "search_query": "vtkSphereSource",
                        "depends_on": [],
                        "vtk_classes": ["vtkSphereSource"],
                        "from_prompt": True,
                    }
                ],
                "synthesized_prompt": "make a sphere",
                "output_type": "interactive",
                "reasoning": "test",
            }
        ),
        encoding="utf-8",
    )

    out = tmp_path / "code.py"

    runner = CliRunner()
    result = runner.invoke(cli.app, ["generate", str(tasks_json), "--out", str(out), "--json"])
    assert result.exit_code == 0
    assert out.read_text(encoding="utf-8") == "print('hi')\n"
