"""Numerics Module. This module contains numerical methods and utilities used in Geomfum."""
