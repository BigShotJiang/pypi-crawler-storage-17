"""Module containing metrics to calculate distances on a PointCloud. For the moment, only Euclidean distances are supported, which are for general shapes."""
