#!/usr/bin/env python3
"""
Setup script for dot-enrichment package.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text() if readme_file.exists() else ""

# Read requirements
requirements_file = Path(__file__).parent / "requirements.txt"
requirements = []
if requirements_file.exists():
    requirements = [
        line.strip()
        for line in requirements_file.read_text().splitlines()
        if line.strip() and not line.startswith("#")
    ]

setup(
    name="alphaloops-dot-enrichment",
    version="0.1.3",
    description="DOT number enrichment utilities for freight/insurance data",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="AlphaLoop",
    author_email="dev@alphaloop.com",
    url="https://bits.featrix.com/alphaloop/dot-enrichment",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=requirements,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    license="Proprietary",
    keywords="dot freight insurance enrichment data",
)

