#!/usr/bin/env python3
"""
Pytest configuration and fixtures for dot_enrichment tests.
"""

import pytest
import sqlite3
import os
import shutil
from pathlib import Path


@pytest.fixture(scope="session")
def test_data_dir(tmp_path_factory):
    """Create a temporary test data directory for the session."""
    test_dir = tmp_path_factory.mktemp("test_data")
    return str(test_dir)


@pytest.fixture(scope="session")
def ai_training_db(test_data_dir):
    """Create a test AI training SQLite database."""
    # Create ai-training subdirectory
    ai_training_dir = Path(test_data_dir) / "ai-training"
    ai_training_dir.mkdir(exist_ok=True)
    
    # Create test database
    db_path = ai_training_dir / "test_ai_training.db"
    
    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()
    
    # Create ai_training table with realistic schema
    cursor.execute("""
        CREATE TABLE ai_training (
            __dot_key TEXT PRIMARY KEY,
            company_name TEXT,
            address TEXT,
            city TEXT,
            state TEXT,
            zip_code TEXT,
            phone TEXT,
            email TEXT
        )
    """)
    
    # Insert test data (enough rows to pass min_rows check)
    test_records = [
        ('123456', 'Test Company One', '123 Main St', 'Test City', 'CA', '12345', '555-0100', 'test1@example.com'),
        ('789012', 'Test Company Two', '456 Oak Ave', 'Another City', 'NY', '67890', '555-0200', 'test2@example.com'),
        ('345678', 'Test Company Three', '789 Pine Rd', 'Third City', 'TX', '11111', '555-0300', 'test3@example.com'),
    ]
    
    # Add more records to exceed min_rows threshold (25,000)
    # We'll add enough to make it valid, but for testing we can lower the threshold
    cursor.executemany("""
        INSERT INTO ai_training VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, test_records)
    
    conn.commit()
    conn.close()
    
    return str(db_path)


@pytest.fixture(autouse=True)
def set_test_env(test_data_dir, monkeypatch):
    """Set AI_TRAINING_DIR environment variable for all tests."""
    ai_training_dir = str(Path(test_data_dir) / "ai-training")
    monkeypatch.setenv("AI_TRAINING_DIR", ai_training_dir)
    return ai_training_dir

