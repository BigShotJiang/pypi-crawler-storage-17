#!/usr/bin/env python3
"""
Tests for alphaloops_scrape_server module.

Run with: pytest tests/test_alphaloops_scrape_server.py
"""

import pytest
from unittest.mock import patch, MagicMock
import json
import pandas as pd

# Import functions to test
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from alphaloops_scrape_server import (
    lookup_company_names_to_websites,
    chunk_domains,
    query_scrape,
    fetch_domain_data,
    extract_llm_summary_fields,
    enrich_domains,
    lookup_dot_to_domains,
)


class TestChunkDomains:
    """Test domain chunking functionality."""
    
    def test_chunk_domains_basic(self):
        """Test basic chunking."""
        domains = ["a.com", "b.com", "c.com", "d.com", "e.com"]
        chunks = list(chunk_domains(domains, chunk_size=2))
        assert len(chunks) == 3
        assert chunks[0] == ["a.com", "b.com"]
        assert chunks[1] == ["c.com", "d.com"]
        assert chunks[2] == ["e.com"]
    
    def test_chunk_domains_exact_size(self):
        """Test chunking with exact size."""
        domains = ["a.com", "b.com", "c.com", "d.com"]
        chunks = list(chunk_domains(domains, chunk_size=2))
        assert len(chunks) == 2
        assert all(len(chunk) == 2 for chunk in chunks)
    
    def test_chunk_domains_empty(self):
        """Test chunking empty list."""
        chunks = list(chunk_domains([], chunk_size=10))
        assert len(chunks) == 0


class TestLookupCompanyNamesToWebsites:
    """Test company name to website lookup."""
    
    def test_lookup_empty_list(self):
        """Test with empty list."""
        result = lookup_company_names_to_websites([])
        assert result == {}
    
    @patch('alphaloops_scrape_server.requests.post')
    def test_lookup_success(self, mock_post):
        """Test successful lookup."""
        mock_response = MagicMock()
        mock_response.json.return_value = [
            {
                'original_query': {'name': 'Acme Corp'},
                'website': 'https://acme.com',
                'status': 'found',
                'website_seems_sane': True
            },
            {
                'original_query': {'name': 'Widget Inc'},
                'website': 'https://widget.com',
                'status': 'found',
                'website_seems_sane': True
            }
        ]
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response
        
        result = lookup_company_names_to_websites(["Acme Corp", "Widget Inc"])
        assert len(result) == 2
        assert result["Acme Corp"] == "https://acme.com"
        assert result["Widget Inc"] == "https://widget.com"
    
    @patch('alphaloops_scrape_server.requests.post')
    def test_lookup_filters_insane_websites(self, mock_post):
        """Test that insane websites are filtered out."""
        mock_response = MagicMock()
        mock_response.json.return_value = [
            {
                'original_query': {'name': 'Acme Corp'},
                'website': 'https://acme.com',
                'status': 'found',
                'website_seems_sane': True
            },
            {
                'original_query': {'name': 'Bad Corp'},
                'website': 'https://bad.com',
                'status': 'found',
                'website_seems_sane': False  # Filtered out
            }
        ]
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response
        
        result = lookup_company_names_to_websites(["Acme Corp", "Bad Corp"])
        assert len(result) == 1
        assert "Acme Corp" in result
        assert "Bad Corp" not in result
    
    @patch('alphaloops_scrape_server.requests.post')
    def test_lookup_new_status(self, mock_post):
        """Test handling of 'new' status."""
        mock_response = MagicMock()
        mock_response.json.return_value = [
            {
                'original_query': {'name': 'New Corp'},
                'website': None,
                'status': 'new',
                'website_seems_sane': True
            }
        ]
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response
        
        result = lookup_company_names_to_websites(["New Corp"])
        assert len(result) == 0  # 'new' status means not available yet
    
    @patch('alphaloops_scrape_server.requests.post')
    def test_lookup_exception(self, mock_post):
        """Test exception handling."""
        mock_post.side_effect = Exception("Network error")
        
        result = lookup_company_names_to_websites(["Acme Corp"])
        assert result == {}


class TestQueryScrape:
    """Test query_scrape function."""
    
    @patch('alphaloops_scrape_server.requests.get')
    def test_query_scrape_success(self, mock_get):
        """Test successful query."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = [
            {'domain': 'example.com', 'llm-json-summary': {'business_name': 'Example Corp'}}
        ]
        mock_get.return_value = mock_response
        
        result = query_scrape("example.com")
        assert len(result) == 1
        assert result[0]['domain'] == 'example.com'
    
    @patch('alphaloops_scrape_server.requests.get')
    def test_query_scrape_404(self, mock_get):
        """Test 404 handling."""
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_get.return_value = mock_response
        
        with pytest.raises(FileNotFoundError):
            query_scrape("nonexistent.com")
    
    @patch('alphaloops_scrape_server.requests.get')
    def test_query_scrape_503_retry(self, mock_get):
        """Test 503 retry logic."""
        # First attempt: 503, second attempt: success
        mock_response_503 = MagicMock()
        mock_response_503.status_code = 503
        
        mock_response_200 = MagicMock()
        mock_response_200.status_code = 200
        mock_response_200.json.return_value = [{'domain': 'example.com'}]
        
        mock_get.side_effect = [mock_response_503, mock_response_200]
        
        with patch('alphaloops_scrape_server.time.sleep'):  # Mock sleep to speed up test
            result = query_scrape("example.com")
            assert len(result) == 1
    
    @patch('alphaloops_scrape_server.requests.get')
    def test_query_scrape_json_decode_error(self, mock_get):
        """Test JSON decode error with NaN fix."""
        import json as json_module
        from requests.exceptions import JSONDecodeError
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.text = '[{"domain": "example.com", "value": NaN}]'
        # First call to json() raises JSONDecodeError
        mock_response.json.side_effect = JSONDecodeError("msg", "doc", 0)
        mock_get.return_value = mock_response
        
        # Mock json.loads to succeed after NaN fix
        with patch('alphaloops_scrape_server.json.loads') as mock_loads:
            mock_loads.return_value = [{'domain': 'example.com'}]
            result = query_scrape("example.com")
            assert len(result) == 1
            # Verify json.loads was called with fixed text
            assert mock_loads.called
    
    @patch('alphaloops_scrape_server.requests.get')
    def test_query_scrape_connection_error_retry(self, mock_get):
        """Test connection error retry."""
        from requests.exceptions import ConnectionError
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = [{'domain': 'example.com'}]
        
        mock_get.side_effect = [ConnectionError("Connection failed"), mock_response]
        
        with patch('alphaloops_scrape_server.time.sleep'):
            result = query_scrape("example.com")
            assert len(result) == 1
    
    @patch('alphaloops_scrape_server.requests.get')
    def test_query_scrape_timeout_retry(self, mock_get):
        """Test timeout retry."""
        from requests.exceptions import Timeout
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = [{'domain': 'example.com'}]
        
        mock_get.side_effect = [Timeout("Request timeout"), mock_response]
        
        with patch('alphaloops_scrape_server.time.sleep'):
            result = query_scrape("example.com")
            assert len(result) == 1


class TestFetchDomainData:
    """Test fetch_domain_data function."""
    
    @patch('alphaloops_scrape_server.query_scrape')
    def test_fetch_domain_data_success(self, mock_query):
        """Test successful domain data fetch."""
        # Mock query_scrape to return the data
        mock_query.return_value = [
            {
                'domain': 'example.com',
                'llm-json-summary': {
                    'business_name': 'Example Corp',
                    'business_is_logistics_related': True
                }
            },
            {
                'domain': 'test.com',
                'llm-json-summary': None  # No data
            }
        ]
        
        # Suppress print statements and logging
        with patch('alphaloops_scrape_server.print'), patch('alphaloops_scrape_server.logging'):
            result = fetch_domain_data(['example.com', 'test.com', 'missing.com'])
        
        # Verify query_scrape was called with comma-separated domains
        assert mock_query.called
        call_args = mock_query.call_args[0][0] if mock_query.call_args else None
        assert 'example.com' in call_args or call_args == 'example.com,test.com,missing.com'
        
        assert 'example.com' in result
        assert result['example.com']['status'] == 'success'
        assert result['example.com']['data']['business_name'] == 'Example Corp'
        
        assert 'test.com' in result
        assert result['test.com']['status'] == 'no_data'
        
        assert 'missing.com' in result
        assert result['missing.com']['status'] == 'not_found'
    
    @patch('alphaloops_scrape_server.query_scrape')
    def test_fetch_domain_data_404(self, mock_query):
        """Test 404 handling."""
        mock_query.side_effect = FileNotFoundError("not found")
        
        result = fetch_domain_data(['example.com'])
        assert result['example.com']['status'] == 'not_found'
    
    @patch('alphaloops_scrape_server.query_scrape')
    def test_fetch_domain_data_exception(self, mock_query):
        """Test exception handling."""
        mock_query.side_effect = Exception("API error")
        
        result = fetch_domain_data(['example.com'])
        assert result['example.com']['status'] == 'error'
        assert 'error' in result['example.com']


class TestExtractLLMSummaryFields:
    """Test extract_llm_summary_fields function."""
    
    def test_extract_basic_fields(self):
        """Test extracting basic fields."""
        summary = {
            'business_name': 'Acme Corp',
            'business_is_logistics_related': True,
            'services': ['A', 'B', 'C']
        }
        
        result = extract_llm_summary_fields(summary)
        assert result['business_name'] == 'Acme Corp'
        assert result['business_is_logistics_related'] is True
        assert result['services'] == 'A, B, C'
    
    def test_extract_sub_logistics(self):
        """Test extracting sub-logistics nested dict."""
        summary = {
            'sub-logistics': {
                'trucking': True,
                'warehousing': False
            }
        }
        
        result = extract_llm_summary_fields(summary)
        assert result['sub_logistics_trucking'] is True
        assert result['sub_logistics_warehousing'] is False
    
    def test_extract_nested_dict(self):
        """Test extracting nested dict (non sub-*)."""
        summary = {
            'other_dict': {'key': 'value'}
        }
        
        result = extract_llm_summary_fields(summary)
        assert 'other_dict' in result
        assert isinstance(result['other_dict'], str)  # Should be JSON string
    
    def test_extract_empty(self):
        """Test with empty summary."""
        result = extract_llm_summary_fields({})
        assert result == {}
    
    def test_extract_none(self):
        """Test with None."""
        result = extract_llm_summary_fields(None)
        assert result == {}


class TestEnrichDomains:
    """Test enrich_domains function."""
    
    @patch('alphaloops_scrape_server.fetch_domain_data')
    def test_enrich_domains_success(self, mock_fetch):
        """Test successful domain enrichment."""
        mock_fetch.return_value = {
            'example.com': {
                'status': 'success',
                'data': {
                    'business_name': 'Example Corp',
                    'business_is_logistics_related': True
                }
            },
            'test.com': {
                'status': 'not_found',
                'data': None
            }
        }
        
        with patch('alphaloops_scrape_server.time.sleep'):  # Mock sleep
            result = enrich_domains(['example.com', 'test.com'])
        
        assert len(result) == 2
        assert result[0]['domain'] == 'example.com'
        assert result[0]['enrichment_status'] == 'success'
        assert result[0]['business_name'] == 'Example Corp'
        
        assert result[1]['domain'] == 'test.com'
        assert result[1]['enrichment_status'] == 'not_found'
    
    @patch('alphaloops_scrape_server.fetch_domain_data')
    def test_enrich_domains_chunking(self, mock_fetch):
        """Test that domains are chunked correctly."""
        mock_fetch.return_value = {
            'example.com': {'status': 'success', 'data': {}}
        }
        
        domains = ['a.com'] * 30  # More than CHUNK_SIZE (25)
        
        with patch('alphaloops_scrape_server.time.sleep'):
            result = enrich_domains(domains)
        
        # Should be called multiple times (once per chunk)
        assert mock_fetch.call_count >= 2
        assert len(result) == 30


class TestLookupDotToDomains:
    """Test lookup_dot_to_domains function."""
    
    def test_lookup_empty_list(self):
        """Test with empty list."""
        result = lookup_dot_to_domains([])
        assert result == {}
    
    def test_lookup_invalid_dots(self):
        """Test with invalid DOT numbers."""
        result = lookup_dot_to_domains([None, "", "invalid", "123.4"])
        assert result == {}
    
    def test_lookup_normalizes_dots(self):
        """Test that DOT numbers are normalized."""
        with patch('alphaloops_scrape_server.requests.get') as mock_get:
            mock_response = MagicMock()
            mock_response.json.return_value = {
                'dot_to_domains': {'123456': 'example.com'}
            }
            mock_response.raise_for_status.return_value = None
            mock_get.return_value = mock_response
            
            # Test with various formats
            result = lookup_dot_to_domains(["123456.0", "00123456", "123456"])
            # Should deduplicate and normalize
            assert mock_get.call_count >= 1
    
    @patch('alphaloops_scrape_server.requests.get')
    def test_lookup_success(self, mock_get):
        """Test successful lookup."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'dot_to_domains': {
                '123456': 'example.com',
                '789012': 'test.com'
            }
        }
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        result = lookup_dot_to_domains(['123456', '789012'])
        assert len(result) == 2
        assert result['123456'] == 'example.com'
        assert result['789012'] == 'test.com'
    
    @patch('alphaloops_scrape_server.requests.get')
    def test_lookup_batching(self, mock_get):
        """Test that requests are batched."""
        mock_response = MagicMock()
        mock_response.json.return_value = {'dot_to_domains': {}}
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        # Create 30 DOTs (more than batch size of 25)
        dots = [str(i).zfill(6) for i in range(30)]
        lookup_dot_to_domains(dots)
        
        # Should make at least 2 API calls (batched)
        assert mock_get.call_count >= 2
    
    @patch('alphaloops_scrape_server.requests.get')
    def test_lookup_exception_handling(self, mock_get):
        """Test exception handling."""
        mock_get.side_effect = Exception("Network error")
        
        result = lookup_dot_to_domains(['123456'])
        assert result == {}


class TestPrepareESRandomCarriersDataset:
    """Test prepare_es_random_carriers_dataset function."""
    
    @patch('alphaloops_scrape_server.enrich_dot_dataframe')
    @patch('alphaloops_scrape_server.get_latest_ai_training_sqlite')
    def test_prepare_es_dataset_success(self, mock_get_db, mock_enrich):
        """Test successful ES dataset preparation."""
        import sqlite3
        import tempfile
        import os
        
        from alphaloops_scrape_server import prepare_es_random_carriers_dataset
        
        # Create temporary database
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            # Create test database
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE ai_training (
                    __dot_key TEXT PRIMARY KEY,
                    company_name TEXT,
                    address TEXT,
                    city TEXT,
                    state TEXT
                )
            """)
            # Insert test records
            for i in range(10):
                cursor.execute(
                    "INSERT INTO ai_training VALUES (?, ?, ?, ?, ?)",
                    (f'12345{i}', f'Company {i}', f'{i} Main St', 'City', 'CA')
                )
            conn.commit()
            conn.close()
            
            # Mock database path
            mock_get_db.return_value = db_path
            
            # Mock enrichment to return enriched DataFrame
            mock_enriched_df = pd.DataFrame({
                'dot_number': ['123450', '123451'],
                'company_name': ['Company 0', 'Company 1'],
                'address': ['0 Main St', '1 Main St'],
                'insp_total': [10, 20],
                'unsafe_driving': [1, 2]
            })
            mock_enrich.return_value = mock_enriched_df
            
            # Suppress print statements
            with patch('alphaloops_scrape_server.print'):
                result = prepare_es_random_carriers_dataset(num_carriers=5)
            
            # Verify database was accessed
            assert mock_get_db.called
            
            # Verify enrichment was called correctly
            mock_enrich.assert_called_once()
            call_kwargs = mock_enrich.call_args[1]
            assert call_kwargs['enrich_ai_training'] is False
            assert call_kwargs['enrich_csa'] is True
            assert call_kwargs['min_csa_success_rate'] == 0.0
            
            # Verify result structure
            assert isinstance(result, pd.DataFrame)
            assert 'dot_number' in result.columns
            
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    @patch('alphaloops_scrape_server.enrich_dot_dataframe')
    @patch('alphaloops_scrape_server.get_latest_ai_training_sqlite')
    def test_prepare_es_dataset_removes_label(self, mock_get_db, mock_enrich):
        """Test that is_bad_account column is removed."""
        import sqlite3
        import tempfile
        import os
        
        from alphaloops_scrape_server import prepare_es_random_carriers_dataset
        
        # Create temporary database
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE ai_training (
                    __dot_key TEXT PRIMARY KEY,
                    company_name TEXT
                )
            """)
            cursor.execute("INSERT INTO ai_training VALUES ('123456', 'Test Company')")
            conn.commit()
            conn.close()
            
            mock_get_db.return_value = db_path
            
            # Mock enrichment to return DataFrame WITH is_bad_account
            mock_enriched_df = pd.DataFrame({
                'dot_number': ['123456'],
                'company_name': ['Test Company'],
                'is_bad_account': [1]  # Should be removed
            })
            mock_enrich.return_value = mock_enriched_df
            
            with patch('alphaloops_scrape_server.print'):
                result = prepare_es_random_carriers_dataset(num_carriers=1)
            
            # Verify is_bad_account was removed
            assert 'is_bad_account' not in result.columns
            assert 'dot_number' in result.columns
            assert 'company_name' in result.columns
            
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    @patch('alphaloops_scrape_server.enrich_dot_dataframe')
    @patch('alphaloops_scrape_server.get_latest_ai_training_sqlite')
    def test_prepare_es_dataset_csa_enrichment_failure(self, mock_get_db, mock_enrich):
        """Test that CSA enrichment failure doesn't stop the process."""
        import sqlite3
        import tempfile
        import os
        
        from alphaloops_scrape_server import prepare_es_random_carriers_dataset
        
        # Create temporary database
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE ai_training (
                    __dot_key TEXT PRIMARY KEY,
                    company_name TEXT
                )
            """)
            cursor.execute("INSERT INTO ai_training VALUES ('123456', 'Test Company')")
            conn.commit()
            conn.close()
            
            mock_get_db.return_value = db_path
            
            # Mock enrichment to raise exception
            mock_enrich.side_effect = Exception("CSA enrichment failed")
            
            with patch('alphaloops_scrape_server.print'):
                # Should not raise exception, should continue
                result = prepare_es_random_carriers_dataset(num_carriers=1)
            
            # Should still return a DataFrame (without CSA data)
            assert isinstance(result, pd.DataFrame)
            assert 'dot_number' in result.columns
            
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    @patch('alphaloops_scrape_server.get_latest_ai_training_sqlite')
    def test_prepare_es_dataset_missing_dot_key_column(self, mock_get_db):
        """Test error when database missing __dot_key column."""
        import sqlite3
        import tempfile
        import os
        
        from alphaloops_scrape_server import prepare_es_random_carriers_dataset
        
        # Create temporary database WITHOUT __dot_key
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE ai_training (
                    company_name TEXT
                )
            """)
            cursor.execute("INSERT INTO ai_training VALUES ('Test Company')")
            conn.commit()
            conn.close()
            
            mock_get_db.return_value = db_path
            
            with patch('alphaloops_scrape_server.print'):
                with pytest.raises(ValueError, match="missing __dot_key column"):
                    prepare_es_random_carriers_dataset(num_carriers=1)
            
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    @patch('alphaloops_scrape_server.enrich_dot_dataframe')
    @patch('alphaloops_scrape_server.get_latest_ai_training_sqlite')
    def test_prepare_es_dataset_custom_num_carriers(self, mock_get_db, mock_enrich):
        """Test with custom number of carriers."""
        import sqlite3
        import tempfile
        import os
        
        from alphaloops_scrape_server import prepare_es_random_carriers_dataset
        
        # Create temporary database with many records
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE ai_training (
                    __dot_key TEXT PRIMARY KEY,
                    company_name TEXT
                )
            """)
            # Insert 20 records
            for i in range(20):
                cursor.execute(
                    "INSERT INTO ai_training VALUES (?, ?)",
                    (f'12345{i}', f'Company {i}')
                )
            conn.commit()
            conn.close()
            
            mock_get_db.return_value = db_path
            
            # Mock enrichment
            mock_enriched_df = pd.DataFrame({
                'dot_number': [f'12345{i}' for i in range(10)],
                'company_name': [f'Company {i}' for i in range(10)]
            })
            mock_enrich.return_value = mock_enriched_df
            
            with patch('alphaloops_scrape_server.print'):
                result = prepare_es_random_carriers_dataset(num_carriers=10)
            
            # Verify enrichment was called with correct DataFrame
            call_args = mock_enrich.call_args[0]
            assert len(call_args[0]) == 10  # Should have 10 rows
            
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

