#!/usr/bin/env python3
"""
Tests for dot_enrichment package.

Run with: pytest tests/
"""

import pytest
import pandas as pd
import sqlite3
import tempfile
import os
from pathlib import Path
from unittest.mock import patch, MagicMock

from dot_enrichment import (
    enrich_dot_dataframe,
    enrich_with_ai_training,
    enrich_with_csa_scores,
    normalize_dot_cell,
    normalize_dot_series,
    detect_dot_column,
    fetch_missing_dots_from_api,
)


class TestNormalizeDotCell:
    """Test DOT number normalization functions."""
    
    def test_normalize_valid_dot(self):
        """Test normalizing valid DOT numbers."""
        assert normalize_dot_cell("123456") == "123456"
        assert normalize_dot_cell("00123456") == "123456"
        assert normalize_dot_cell("0") == "0"
        assert normalize_dot_cell(123456) == "123456"
        assert normalize_dot_cell(123456.0) == "123456"
    
    def test_normalize_with_commas(self):
        """Test normalizing DOT numbers with commas."""
        assert normalize_dot_cell("1,234,567") == "1234567"
        assert normalize_dot_cell("123,456") == "123456"
    
    def test_normalize_with_whitespace(self):
        """Test normalizing DOT numbers with whitespace."""
        assert normalize_dot_cell("  123456  ") == "123456"
        assert normalize_dot_cell("\t123456\n") == "123456"
    
    def test_normalize_decimal_zero(self):
        """Test normalizing DOT numbers with .0 decimal."""
        assert normalize_dot_cell("123456.0") == "123456"
        assert normalize_dot_cell("123456.00") == "123456"
        assert normalize_dot_cell("123456.000") == "123456"
    
    def test_normalize_invalid(self):
        """Test that invalid DOT numbers return None."""
        assert normalize_dot_cell("123.4") is None  # Non-zero decimal
        assert normalize_dot_cell("ABC123") is None  # Contains letters
        assert normalize_dot_cell("") is None  # Empty string
        assert normalize_dot_cell(None) is None  # None value
        assert normalize_dot_cell("nan") is None  # NaN string
    
    def test_normalize_series(self):
        """Test normalizing a pandas Series."""
        series = pd.Series(["123456", "789012", "001234", None, "invalid"])
        result = normalize_dot_series(series)
        assert result.iloc[0] == "123456"
        assert result.iloc[1] == "789012"
        assert result.iloc[2] == "1234"
        assert result.iloc[3] is None
        assert result.iloc[4] is None


class TestDetectDotColumn:
    """Test DOT column detection."""
    
    def test_detect_dot_number(self):
        """Test detecting 'dot_number' column."""
        df = pd.DataFrame({"dot_number": [1, 2, 3], "other": [4, 5, 6]})
        assert detect_dot_column(df) == "dot_number"
    
    def test_detect_dot_variants(self):
        """Test detecting various DOT column name variants."""
        variants = ["DOT Number", "DOT number", "dotnumber", "DOT", "USDOT"]
        for variant in variants:
            df = pd.DataFrame({variant: [1, 2, 3]})
            assert detect_dot_column(df) == variant
    
    def test_detect_featrix_meta(self):
        """Test detecting __featrix_meta_dot_number column."""
        df = pd.DataFrame({"__featrix_meta_dot_number": [1, 2, 3]})
        assert detect_dot_column(df) == "__featrix_meta_dot_number"
    
    def test_detect_no_dot_column(self):
        """Test when no DOT column exists."""
        df = pd.DataFrame({"other": [1, 2, 3]})
        assert detect_dot_column(df) == ""


class TestEnrichWithAITraining:
    """Test AI training enrichment."""
    
    def test_enrich_missing_dot_column(self):
        """Test that missing DOT column raises ValueError."""
        df = pd.DataFrame({"other": [1, 2, 3]})
        with pytest.raises(ValueError, match="DOT column"):
            enrich_with_ai_training(df, dot_column="dot_number")
    
    def test_enrich_invalid_enrichment_rate(self):
        """Test that invalid enrichment rate raises ValueError."""
        df = pd.DataFrame({"dot_number": ["123456"]})
        with pytest.raises(ValueError, match="min_enrichment_rate"):
            enrich_with_ai_training(df, min_enrichment_rate=1.5)
    
    def test_enrich_no_valid_dots(self):
        """Test that empty DOT list raises ValueError."""
        df = pd.DataFrame({"dot_number": [None, None]})
        with pytest.raises(ValueError, match="No valid DOT numbers"):
            enrich_with_ai_training(df)
    
    @patch('dot_enrichment.dot_enrichment.get_latest_ai_training_sqlite')
    def test_enrich_with_mock_database(self, mock_get_db):
        """Test enrichment with a mocked SQLite database."""
        # Create a temporary SQLite database
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            # Create test database with ai_training table
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE ai_training (
                    __dot_key TEXT PRIMARY KEY,
                    company_name TEXT,
                    address TEXT,
                    city TEXT,
                    state TEXT
                )
            """)
            cursor.execute("""
                INSERT INTO ai_training VALUES 
                ('123456', 'Test Company', '123 Main St', 'Test City', 'CA')
            """)
            conn.commit()
            conn.close()
            
            # Mock the database path function
            mock_get_db.return_value = db_path
            
            # Create test DataFrame
            df = pd.DataFrame({"dot_number": ["123456", "789012"]})
            
            # Mock API fallback to return empty (no API calls)
            with patch('dot_enrichment.dot_enrichment.fetch_missing_dots_from_api') as mock_api:
                mock_api.return_value = pd.DataFrame()
                
                # Should raise RuntimeError because enrichment rate is too low
                with pytest.raises(RuntimeError, match="Enrichment rate"):
                    enrich_with_ai_training(df, min_enrichment_rate=0.80)
        
        finally:
            # Clean up
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def test_enrich_with_test_data_dir(self, ai_training_db, test_data_dir):
        """REAL TEST: Test enrichment using the actual test database - NO MOCKS."""
        from dot_enrichment import aitraining_helpers
        from dot_enrichment.aitraining_helpers import get_latest_ai_training_sqlite as real_get_db
        
        # Create test DataFrame with DOTs that exist in test database
        df = pd.DataFrame({"dot_number": ["123456", "789012", "999999"]})
        
        # Patch the module constant to point to test directory
        original_dir = aitraining_helpers.AI_TRAINING_DIR
        ai_training_dir = str(Path(test_data_dir) / "ai-training")
        
        # Create a wrapper that calls the REAL function with lower min_rows
        def get_db_with_low_threshold():
            return real_get_db(training_dir=ai_training_dir, min_rows=1)
        
        try:
            # Point the helper to our test directory
            aitraining_helpers.AI_TRAINING_DIR = ai_training_dir
            
            # Patch to use REAL function but with test directory and low threshold
            with patch('dot_enrichment.dot_enrichment.get_latest_ai_training_sqlite', side_effect=get_db_with_low_threshold):
                # NO API MOCK - but disable API fallback so we don't make real API calls
                # This is a REAL database test, just without external API calls
                result = enrich_with_ai_training(
                    df,
                    dot_column='dot_number',
                    min_enrichment_rate=0.50,  # Lower threshold for test (2/3 = 66%)
                    use_api_fallback=False  # Disable API to avoid real calls
                )
            
            # Verify enrichment worked - REAL database query results
            assert 'company_name' in result.columns
            assert len(result) == 3  # All 3 rows should be present
            
            # Check that matching DOTs were enriched
            row_123456 = result[result['dot_number'] == '123456'].iloc[0]
            assert row_123456['company_name'] == 'Test Company One'
            assert row_123456['address'] == '123 Main St'
            assert row_123456['city'] == 'Test City'
            assert row_123456['state'] == 'CA'
            
            row_789012 = result[result['dot_number'] == '789012'].iloc[0]
            assert row_789012['company_name'] == 'Test Company Two'
            assert row_789012['address'] == '456 Oak Ave'
            
            # 999999 should NOT be enriched (not in database)
            row_999999 = result[result['dot_number'] == '999999'].iloc[0]
            assert pd.isna(row_999999['company_name'])
            
            # Verify we got additional columns from the database
            expected_cols = ['company_name', 'address', 'city', 'state', 'zip_code', 'phone', 'email']
            for col in expected_cols:
                assert col in result.columns, f"Missing column: {col}"
            
        finally:
            # Restore original directory
            aitraining_helpers.AI_TRAINING_DIR = original_dir
    
    def test_get_latest_ai_training_sqlite_with_test_dir(self, ai_training_db, test_data_dir):
        """REAL TEST: Test that get_latest_ai_training_sqlite actually finds the test database."""
        from dot_enrichment.aitraining_helpers import get_latest_ai_training_sqlite
        
        # Use test data directory with lower min_rows requirement
        ai_training_dir = str(Path(test_data_dir) / "ai-training")
        
        # REAL database lookup - no mocks
        db_path = get_latest_ai_training_sqlite(training_dir=ai_training_dir, min_rows=1)
        
        # Verify database was found and matches our test database
        assert db_path == ai_training_db
        assert os.path.exists(db_path)
        
        # Verify it's actually a valid database with data
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM ai_training")
        row_count = cursor.fetchone()[0]
        conn.close()
        
        assert row_count == 3  # We inserted 3 test records
    
    def test_full_enrichment_pipeline_real_database(self, ai_training_db, test_data_dir):
        """REAL INTEGRATION TEST: Full enrichment pipeline with actual database queries."""
        from dot_enrichment import aitraining_helpers
        from dot_enrichment.aitraining_helpers import get_latest_ai_training_sqlite as real_get_db
        
        # Create test DataFrame
        df = pd.DataFrame({
            "dot_number": ["123456", "789012", "345678", "999999"],
            "policy_id": ["P1", "P2", "P3", "P4"]
        })
        
        # Patch the module constant to use test directory
        original_dir = aitraining_helpers.AI_TRAINING_DIR
        ai_training_dir = str(Path(test_data_dir) / "ai-training")
        
        # Create a wrapper that calls the REAL function with lower min_rows
        def get_db_with_low_threshold():
            return real_get_db(training_dir=ai_training_dir, min_rows=1)
        
        try:
            aitraining_helpers.AI_TRAINING_DIR = ai_training_dir
            
            # Patch to use REAL function but with test directory
            with patch('dot_enrichment.dot_enrichment.get_latest_ai_training_sqlite', side_effect=get_db_with_low_threshold):
                # REAL enrichment - connects to actual database, performs real SQL queries
                result = enrich_with_ai_training(
                    df,
                    dot_column='dot_number',
                    min_enrichment_rate=0.60,  # 3 out of 4 match = 75%
                    use_api_fallback=False
                )
            
            # Verify the enrichment actually happened
            assert len(result) == 4
            assert 'policy_id' in result.columns  # Original column preserved
            
            # Verify all matching DOTs got enriched with REAL data
            enriched_count = result['company_name'].notna().sum()
            assert enriched_count == 3, f"Expected 3 enriched rows, got {enriched_count}"
            
            # Verify specific data from database
            assert result[result['dot_number'] == '123456']['company_name'].iloc[0] == 'Test Company One'
            assert result[result['dot_number'] == '789012']['company_name'].iloc[0] == 'Test Company Two'
            assert result[result['dot_number'] == '345678']['company_name'].iloc[0] == 'Test Company Three'
            
            # Verify unmatched DOT is not enriched
            assert pd.isna(result[result['dot_number'] == '999999']['company_name'].iloc[0])
            
            # Verify we got all database columns
            db_columns = ['company_name', 'address', 'city', 'state', 'zip_code', 'phone', 'email']
            for col in db_columns:
                assert col in result.columns
            
        finally:
            aitraining_helpers.AI_TRAINING_DIR = original_dir


class TestEnrichWithCSAScores:
    """Test CSA scores enrichment."""
    
    def test_enrich_csa_missing_dot_column(self):
        """Test that missing DOT column raises ValueError."""
        df = pd.DataFrame({"other": [1, 2, 3]})
        with pytest.raises(ValueError, match="DOT column"):
            enrich_with_csa_scores(df, dot_column="dot_number")
    
    def test_enrich_csa_invalid_success_rate(self):
        """Test that invalid success rate raises ValueError."""
        df = pd.DataFrame({"dot_number": ["123456"]})
        with pytest.raises(ValueError, match="min_success_rate"):
            enrich_with_csa_scores(df, min_success_rate=1.5)
    
    @patch('dot_enrichment.dot_enrichment.fetch_csa_scores_by_dots')
    def test_enrich_csa_with_mock_data(self, mock_fetch_csa):
        """Test CSA enrichment with mocked Supabase data."""
        # Mock CSA data
        mock_csa_df = pd.DataFrame({
            'dot_number': ['123456'],
            'insp_total': [10],
            'unsafe_driving': [2],
            'crash_indicator': [1]
        })
        mock_fetch_csa.return_value = mock_csa_df
        
        # Create test DataFrame
        df = pd.DataFrame({"dot_number": ["123456", "789012"]})
        
        # Should raise RuntimeError because success rate is too low
        with pytest.raises(RuntimeError, match="CSA join success rate"):
            enrich_with_csa_scores(df, min_success_rate=0.75)
        
        # Test with lower success rate requirement
        result = enrich_with_csa_scores(df, min_success_rate=0.40)
        assert len(result) == 2
        assert 'insp_total' in result.columns
    
    @pytest.mark.integration
    def test_enrich_csa_real_supabase_api(self):
        """REAL TEST: Actually hit Supabase API and fetch real CSA scores."""
        import os
        from dot_enrichment.supabase_helpers import get_anon_key, fetch_csa_scores_by_dots
        
        # CRASH if no Supabase key is available - integration tests REQUIRE credentials
        try:
            anon_key = get_anon_key()
        except ValueError as e:
            raise RuntimeError(
                f"REAL INTEGRATION TEST FAILED: SUPABASE_ANON_KEY not available. "
                f"Set SUPABASE_ANON_KEY environment variable to run integration tests. "
                f"Original error: {e}"
            ) from e
        
        # Use a real DOT number that likely exists in Supabase
        # Using a common DOT number format
        test_dots = ['123456', '789012', '345678']
        
        # REAL API CALL - this will actually hit Supabase
        print(f"\n[REAL TEST] Fetching CSA scores from Supabase for {len(test_dots)} DOTs...")
        csa_df = fetch_csa_scores_by_dots(test_dots, anon_key=anon_key)
        
        # Verify we got real data back
        if len(csa_df) > 0:
            print(f"[REAL TEST] Retrieved {len(csa_df)} CSA records from Supabase")
            assert 'dot_number' in csa_df.columns or 'insp_total' in csa_df.columns
            # Verify it has CSA score columns
            assert len(csa_df.columns) > 1  # Should have multiple columns
            
            # Now test the full enrichment with real data
            df = pd.DataFrame({"dot_number": test_dots})
            result = enrich_with_csa_scores(
                df,
                dot_column='dot_number',
                min_success_rate=0.0  # Accept any success rate for real test
            )
            
            assert len(result) == len(test_dots)
            # If we got data, verify columns were added
            if 'insp_total' in result.columns:
                enriched_count = result['insp_total'].notna().sum()
                print(f"[REAL TEST] Enriched {enriched_count}/{len(result)} rows with CSA scores")
        else:
            print(f"[REAL TEST] No CSA scores found for test DOTs (this is OK)")
            # Still test that the function works even with no data
            df = pd.DataFrame({"dot_number": test_dots})
            result = enrich_with_csa_scores(
                df,
                dot_column='dot_number',
                min_success_rate=0.0
            )
            assert len(result) == len(test_dots)
    
    @pytest.mark.integration
    @pytest.mark.slow
    def test_enrich_csa_real_supabase_large_batch(self):
        """REAL TEST: Fetch a large batch from Supabase to prove it's actually hitting the API."""
        import os
        import time
        from dot_enrichment.supabase_helpers import get_anon_key, fetch_csa_scores_by_dots
        
        # CRASH if no Supabase key is available - integration tests REQUIRE credentials
        try:
            anon_key = get_anon_key()
        except ValueError as e:
            raise RuntimeError(
                f"REAL INTEGRATION TEST FAILED: SUPABASE_ANON_KEY not available. "
                f"Set SUPABASE_ANON_KEY environment variable to run integration tests. "
                f"Original error: {e}"
            ) from e
        
        # Generate a list of DOT numbers to test with
        # Using sequential DOTs that might exist
        test_dots = [str(i).zfill(6) for i in range(1000, 1500)]  # 500 DOTs
        
        print(f"\n[REAL TEST] Fetching CSA scores from Supabase for {len(test_dots)} DOTs...")
        print("[REAL TEST] This will take time as it actually hits the Supabase API...")
        
        start_time = time.time()
        
        # REAL API CALL - this will actually hit Supabase and take time
        csa_df = fetch_csa_scores_by_dots(test_dots, anon_key=anon_key, batch_size=500)
        
        elapsed_time = time.time() - start_time
        
        print(f"[REAL TEST] Retrieved {len(csa_df)} CSA records in {elapsed_time:.2f} seconds")
        print(f"[REAL TEST] This proves we're hitting the REAL Supabase API (not mocked)")
        
        # Verify we got data structure back
        assert isinstance(csa_df, pd.DataFrame)
        
        # If we got results, verify they have the expected structure
        if len(csa_df) > 0:
            print(f"[REAL TEST] Sample columns: {list(csa_df.columns)[:5]}")
            # Verify it has DOT-related columns
            assert len(csa_df.columns) > 0
            
            # Verify we can actually use this data
            df = pd.DataFrame({"dot_number": test_dots[:10]})  # Test with subset
            result = enrich_with_csa_scores(
                df,
                dot_column='dot_number',
                min_success_rate=0.0
            )
            assert len(result) == 10
        else:
            print(f"[REAL TEST] No CSA scores found (this is OK - DOTs may not exist)")


class TestEnrichDotDataFrame:
    """Test main enrichment function."""
    
    def test_enrich_missing_dot_column(self):
        """Test that missing DOT column raises ValueError."""
        df = pd.DataFrame({"other": [1, 2, 3]})
        with pytest.raises(ValueError, match="DOT column"):
            enrich_dot_dataframe(df, dot_column="dot_number")
    
    def test_enrich_no_enrichment_options(self):
        """Test that disabling both enrichment options still adds derived features by default."""
        df = pd.DataFrame({"dot_number": ["123456", "789012"]})
        result = enrich_dot_dataframe(df, enrich_ai_training=False, enrich_csa=False)
        assert len(result) == len(df)
        # Derived features should still be added by default (32 derived features + 1 original column)
        derived_cols = [col for col in result.columns if col.startswith('derived_')]
        assert len(derived_cols) == 32
        assert 'dot_number' in result.columns
        
    def test_enrich_no_enrichment_and_no_derived(self):
        """Test that disabling all options returns original DataFrame."""
        df = pd.DataFrame({"dot_number": ["123456", "789012"]})
        result = enrich_dot_dataframe(
            df, 
            enrich_ai_training=False, 
            enrich_csa=False, 
            add_derived_features=False
        )
        assert len(result) == len(df)
        assert list(result.columns) == list(df.columns)


class TestPackageImport:
    """Test that the package can be imported correctly."""
    
    def test_import_main_functions(self):
        """Test that main functions can be imported."""
        from dot_enrichment import (
            enrich_dot_dataframe,
            enrich_with_ai_training,
            enrich_with_csa_scores,
        )
        assert callable(enrich_dot_dataframe)
        assert callable(enrich_with_ai_training)
        assert callable(enrich_with_csa_scores)
    
    def test_import_utilities(self):
        """Test that utility functions can be imported."""
        from dot_enrichment import (
            normalize_dot_cell,
            normalize_dot_series,
            detect_dot_column,
        )
        assert callable(normalize_dot_cell)
        assert callable(normalize_dot_series)
        assert callable(detect_dot_column)
    
    def test_import_version(self):
        """Test that package version is accessible."""
        import dot_enrichment
        assert hasattr(dot_enrichment, '__version__')
        assert dot_enrichment.__version__ == "0.1.2"


class TestFetchMissingDotsFromAPI:
    """Test API fallback functionality."""
    
    @patch('dot_enrichment.data_utils.requests.post')
    def test_fetch_missing_dots_success(self, mock_post):
        """Test successful API fetch."""
        # Mock successful API response
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'success': True,
            'data': [{
                'company_name': 'Test Company',
                'address': '123 Main St',
                'city': 'Test City',
                'state': 'CA'
            }]
        }
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response
        
        result = fetch_missing_dots_from_api(['123456'])
        assert len(result) == 1
        assert 'company_name' in result.columns
        assert '__dot_key' in result.columns
    
    @patch('dot_enrichment.data_utils.requests.post')
    def test_fetch_missing_dots_empty(self, mock_post):
        """Test API fetch with no results."""
        # Mock API response with no data
        mock_response = MagicMock()
        mock_response.json.return_value = {'success': False, 'data': []}
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response
        
        result = fetch_missing_dots_from_api(['123456'])
        assert len(result) == 0
    
    def test_fetch_missing_dots_empty_list(self):
        """Test API fetch with empty DOT list."""
        result = fetch_missing_dots_from_api([])
        assert len(result) == 0
    
    @patch('dot_enrichment.data_utils.requests.post')
    def test_fetch_missing_dots_exception_handling(self, mock_post):
        """Test exception handling in fetch_missing_dots_from_api."""
        # Mock exception during API call
        mock_post.side_effect = Exception("Network error")
        
        result = fetch_missing_dots_from_api(['123456'])
        assert len(result) == 0
    
    def test_normalize_dot_cell_exception_handling(self):
        """Test exception handling in normalize_dot_cell."""
        # Test with object that raises exception when converted to string
        class BadValue:
            def __str__(self):
                raise Exception("Cannot convert")
        
        result = normalize_dot_cell(BadValue())
        assert result is None


class TestAITrainingHelpers:
    """Test AI training helper functions."""
    
    def test_get_latest_ai_training_sqlite_none_training_dir(self):
        """Test that None training_dir uses default."""
        from dot_enrichment.aitraining_helpers import get_latest_ai_training_sqlite
        
        # Should use default AI_TRAINING_DIR when None
        with pytest.raises((FileNotFoundError, ValueError)):
            get_latest_ai_training_sqlite(training_dir=None, min_rows=1)
    
    def test_get_latest_ai_training_sqlite_missing_directory(self):
        """Test error when directory doesn't exist."""
        from dot_enrichment.aitraining_helpers import get_latest_ai_training_sqlite
        
        with pytest.raises(FileNotFoundError, match="does not exist"):
            get_latest_ai_training_sqlite(training_dir="/nonexistent/path", min_rows=1)
    
    def test_get_latest_ai_training_sqlite_no_db_files(self, tmp_path):
        """Test error when no SQLite files exist."""
        from dot_enrichment.aitraining_helpers import get_latest_ai_training_sqlite
        
        # Create empty directory
        empty_dir = str(tmp_path / "empty")
        os.makedirs(empty_dir, exist_ok=True)
        
        with pytest.raises(FileNotFoundError, match="No SQLite files found"):
            get_latest_ai_training_sqlite(training_dir=empty_dir, min_rows=1)
    
    def test_get_latest_ai_training_sqlite_insufficient_rows(self, tmp_path):
        """Test warning when database has insufficient rows."""
        from dot_enrichment.aitraining_helpers import get_latest_ai_training_sqlite
        
        # Create database with only 1 row
        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE ai_training (
                __dot_key TEXT PRIMARY KEY,
                company_name TEXT
            )
        """)
        cursor.execute("INSERT INTO ai_training VALUES ('123', 'Test')")
        conn.commit()
        conn.close()
        
        # Should raise ValueError because min_rows=1000 is not met
        with pytest.raises(ValueError, match="No SQLite database with valid ai_training table"):
            get_latest_ai_training_sqlite(training_dir=str(tmp_path), min_rows=1000)
    
    def test_get_latest_ai_training_sqlite_invalid_database(self, tmp_path):
        """Test handling of invalid database files."""
        from dot_enrichment.aitraining_helpers import get_latest_ai_training_sqlite
        
        # Create a file that's not a valid SQLite database
        invalid_db = tmp_path / "invalid.db"
        invalid_db.write_text("not a database")
        
        # Should try to open it, fail, and raise ValueError
        with pytest.raises(ValueError, match="No SQLite database with valid ai_training table"):
            get_latest_ai_training_sqlite(training_dir=str(tmp_path), min_rows=1)


class TestSupabaseHelpers:
    """Test Supabase helper functions."""
    
    def test_get_anon_key_provided_key(self):
        """Test using provided key parameter."""
        from dot_enrichment.supabase_helpers import get_anon_key
        
        result = get_anon_key(provided_key="test-key-123")
        assert result == "test-key-123"
    
    def test_get_anon_key_env_not_found(self, monkeypatch):
        """Test warning when .env file not found."""
        from dot_enrichment.supabase_helpers import get_anon_key
        
        # Remove any existing env vars and ensure they're not set
        monkeypatch.delenv("SUPABASE_ANON_KEY", raising=False)
        monkeypatch.delenv("SUPABASE_PUBLIC_KEY", raising=False)
        monkeypatch.delenv("ANON_KEY", raising=False)
        monkeypatch.delenv("PUBLIC_KEY", raising=False)
        
        # Also unset them in os.environ to be sure
        import os
        for key in ["SUPABASE_ANON_KEY", "SUPABASE_PUBLIC_KEY", "ANON_KEY", "PUBLIC_KEY"]:
            os.environ.pop(key, None)
        
        # Mock os.path.exists to return False for .env file
        with patch('dot_enrichment.supabase_helpers.os.path.exists', return_value=False):
            with patch('dot_enrichment.supabase_helpers.load_dotenv'):  # Mock load_dotenv
                with pytest.raises(ValueError, match="Anon key not found"):
                    get_anon_key(env_path="/nonexistent/.env")
    
    def test_fetch_csa_scores_empty_dot_numbers(self):
        """Test fetch_csa_scores_by_dots with empty list."""
        from dot_enrichment.supabase_helpers import fetch_csa_scores_by_dots
        
        result = fetch_csa_scores_by_dots([])
        assert len(result) == 0
        assert isinstance(result, pd.DataFrame)
    
    @patch('dot_enrichment.supabase_helpers.requests.get')
    def test_fetch_csa_scores_batch_exception(self, mock_get):
        """Test exception handling in batch processing."""
        from dot_enrichment.supabase_helpers import fetch_csa_scores_by_dots
        
        # Mock exception for first batch, success for second
        mock_response = MagicMock()
        mock_response.json.return_value = [{'dot_number': '789012', 'insp_total': 5}]
        mock_response.raise_for_status.return_value = None
        
        mock_get.side_effect = [Exception("Network error"), mock_response]
        
        result = fetch_csa_scores_by_dots(['123456', '789012'], anon_key="test-key", batch_size=1)
        # Should continue processing and return results from successful batch
        assert len(result) >= 0  # May be empty if all batches fail


class TestDotEnrichmentEdgeCases:
    """Test edge cases and error paths in dot_enrichment."""
    
    @patch('dot_enrichment.dot_enrichment.get_latest_ai_training_sqlite')
    def test_enrich_with_ai_training_no_database(self, mock_get_db):
        """Test error when database cannot be located."""
        mock_get_db.return_value = None
        
        df = pd.DataFrame({"dot_number": ["123456"]})
        with pytest.raises(RuntimeError, match="Could not locate"):
            enrich_with_ai_training(df)
    
    @patch('dot_enrichment.dot_enrichment.get_latest_ai_training_sqlite')
    def test_enrich_with_ai_training_missing_dot_key_column(self, mock_get_db, tmp_path):
        """Test error when database missing __dot_key column."""
        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE ai_training (
                company_name TEXT,
                address TEXT
            )
        """)
        cursor.execute("INSERT INTO ai_training VALUES ('Test', '123 Main')")
        conn.commit()
        conn.close()
        
        mock_get_db.return_value = str(db_path)
        
        df = pd.DataFrame({"dot_number": ["123456"]})
        # The error gets caught by generic exception handler, so check for RuntimeError
        with pytest.raises(RuntimeError, match="ai_training enrichment failed"):
            enrich_with_ai_training(df)
    
    @patch('dot_enrichment.dot_enrichment.get_latest_ai_training_sqlite')
    def test_enrich_with_ai_training_no_matching_records(self, mock_get_db, tmp_path):
        """Test error when no matching records found."""
        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE ai_training (
                __dot_key TEXT PRIMARY KEY,
                company_name TEXT
            )
        """)
        cursor.execute("INSERT INTO ai_training VALUES ('999999', 'Other Company')")
        conn.commit()
        conn.close()
        
        mock_get_db.return_value = str(db_path)
        
        df = pd.DataFrame({"dot_number": ["123456"]})
        with pytest.raises(RuntimeError, match="No matching records found"):
            enrich_with_ai_training(df, use_api_fallback=False)
    
    @patch('dot_enrichment.dot_enrichment.get_latest_ai_training_sqlite')
    def test_enrich_with_ai_training_passthrough_columns(self, mock_get_db, tmp_path):
        """Test passthrough column renaming logic."""
        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE ai_training (
                __dot_key TEXT PRIMARY KEY,
                company_name TEXT,
                address TEXT
            )
        """)
        cursor.execute("INSERT INTO ai_training VALUES ('123456', 'Test Company', '123 Main')")
        conn.commit()
        conn.close()
        
        mock_get_db.return_value = str(db_path)
        
        # Create DataFrame with conflicting column name
        df = pd.DataFrame({
            "dot_number": ["123456"],
            "address": ["Original Address"]  # Conflicts with ai_training.address
        })
        
        result = enrich_with_ai_training(
            df,
            min_enrichment_rate=0.50,
            use_api_fallback=False
        )
        
        # Should have passthrough_ prefix for conflicts
        assert 'address' in result.columns or 'passthrough_address' in result.columns
    
    @patch('dot_enrichment.dot_enrichment.get_latest_ai_training_sqlite')
    def test_enrich_with_ai_training_missing_sample_column(self, mock_get_db, tmp_path):
        """Test error when expected column missing after merge."""
        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE ai_training (
                __dot_key TEXT PRIMARY KEY
            )
        """)
        cursor.execute("INSERT INTO ai_training VALUES ('123456')")
        conn.commit()
        conn.close()
        
        mock_get_db.return_value = str(db_path)
        
        df = pd.DataFrame({"dot_number": ["123456"]})
        # This should raise RuntimeError because no sample column exists
        with pytest.raises(RuntimeError):
            enrich_with_ai_training(df, use_api_fallback=False)
    
    @patch('dot_enrichment.dot_enrichment.get_latest_ai_training_sqlite')
    @patch('dot_enrichment.dot_enrichment.fetch_missing_dots_from_api')
    def test_enrich_with_ai_training_api_fallback(self, mock_api, mock_get_db, tmp_path):
        """Test API fallback functionality."""
        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE ai_training (
                __dot_key TEXT PRIMARY KEY,
                company_name TEXT
            )
        """)
        cursor.execute("INSERT INTO ai_training VALUES ('123456', 'DB Company')")
        conn.commit()
        conn.close()
        
        mock_get_db.return_value = str(db_path)
        
        # Mock API to return data for missing DOT
        mock_api_df = pd.DataFrame({
            '__dot_key': ['789012'],
            'company_name': ['API Company'],
            'address': ['API Address']
        })
        mock_api.return_value = mock_api_df
        
        df = pd.DataFrame({"dot_number": ["123456", "789012"]})
        result = enrich_with_ai_training(
            df,
            min_enrichment_rate=0.50,
            use_api_fallback=True
        )
        
        assert len(result) == 2
        assert 'company_name' in result.columns
    
    @patch('dot_enrichment.dot_enrichment.get_latest_ai_training_sqlite')
    @patch('dot_enrichment.dot_enrichment.fetch_missing_dots_from_api')
    def test_enrich_with_ai_training_api_fallback_exception(self, mock_api, mock_get_db, tmp_path):
        """Test API fallback exception handling."""
        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE ai_training (
                __dot_key TEXT PRIMARY KEY,
                company_name TEXT
            )
        """)
        cursor.execute("INSERT INTO ai_training VALUES ('123456', 'DB Company')")
        conn.commit()
        conn.close()
        
        mock_get_db.return_value = str(db_path)
        mock_api.side_effect = Exception("API error")
        
        df = pd.DataFrame({"dot_number": ["123456", "789012"]})
        # Should continue without API data
        result = enrich_with_ai_training(
            df,
            min_enrichment_rate=0.50,
            use_api_fallback=True
        )
        
        assert len(result) == 2
    
    def test_enrich_with_csa_no_valid_dots(self):
        """Test CSA enrichment with no valid DOTs."""
        df = pd.DataFrame({"dot_number": [None, None]})
        result = enrich_with_csa_scores(df)
        assert len(result) == 2
    
    @patch('dot_enrichment.dot_enrichment.fetch_csa_scores_by_dots')
    def test_enrich_with_csa_no_dot_column_in_response(self, mock_fetch_csa):
        """Test CSA enrichment when response has no DOT column."""
        mock_csa_df = pd.DataFrame({
            'insp_total': [10],
            'unsafe_driving': [2]
        })
        mock_fetch_csa.return_value = mock_csa_df
        
        df = pd.DataFrame({"dot_number": ["123456"]})
        with pytest.raises(RuntimeError, match="No DOT column found"):
            enrich_with_csa_scores(df)
    
    @patch('dot_enrichment.dot_enrichment.fetch_csa_scores_by_dots')
    def test_enrich_with_csa_dot_column_detection(self, mock_fetch_csa):
        """Test CSA enrichment DOT column detection fallback."""
        mock_csa_df = pd.DataFrame({
            'dot_number_alt': ['123456'],
            'insp_total': [10]
        })
        mock_fetch_csa.return_value = mock_csa_df
        
        df = pd.DataFrame({"dot_number": ["123456"]})
        # Should detect dot_number_alt as DOT column
        result = enrich_with_csa_scores(df, min_success_rate=0.0)
        assert len(result) == 1
    
    @patch('dot_enrichment.dot_enrichment.fetch_csa_scores_by_dots')
    def test_enrich_with_csa_exception_handling(self, mock_fetch_csa):
        """Test exception handling in CSA enrichment."""
        mock_fetch_csa.side_effect = Exception("API error")
        
        df = pd.DataFrame({"dot_number": ["123456"]})
        with pytest.raises(RuntimeError, match="CSA enrichment failed"):
            enrich_with_csa_scores(df)
    
    @patch('dot_enrichment.dot_enrichment.enrich_with_ai_training')
    @patch('dot_enrichment.dot_enrichment.enrich_with_csa_scores')
    def test_enrich_dot_dataframe_ai_training_only(self, mock_csa, mock_ai):
        """Test enrich_dot_dataframe with only AI training enabled."""
        mock_ai.return_value = pd.DataFrame({"dot_number": ["123456"], "company_name": ["Test"]})
        
        df = pd.DataFrame({"dot_number": ["123456"]})
        result = enrich_dot_dataframe(df, enrich_ai_training=True, enrich_csa=False)
        
        mock_ai.assert_called_once()
        mock_csa.assert_not_called()
    
    @patch('dot_enrichment.dot_enrichment.enrich_with_ai_training')
    @patch('dot_enrichment.dot_enrichment.enrich_with_csa_scores')
    def test_enrich_dot_dataframe_csa_only(self, mock_csa, mock_ai):
        """Test enrich_dot_dataframe with only CSA enabled."""
        mock_csa.return_value = pd.DataFrame({"dot_number": ["123456"], "insp_total": [10]})
        
        df = pd.DataFrame({"dot_number": ["123456"]})
        result = enrich_dot_dataframe(df, enrich_ai_training=False, enrich_csa=True)
        
        mock_csa.assert_called_once()
        mock_ai.assert_not_called()


class TestNullifyZeroValues:
    """Test zero value nullification functionality."""
    
    @patch('dot_enrichment.dot_enrichment.get_latest_ai_training_sqlite')
    def test_nullify_zero_values_after_enrichment(self, mock_get_db, tmp_path):
        """Test that zero values are nullified for specified fields after ai_training enrichment."""
        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE ai_training (
                __dot_key TEXT PRIMARY KEY,
                company_name TEXT,
                drivers INTEGER,
                owned_trucks INTEGER,
                total_accidents INTEGER,
                annual_revenue REAL,
                avg_truck_age_years REAL
            )
        """)
        # Insert record with some zeros (should be nullified) and some non-zero values
        cursor.execute("""
            INSERT INTO ai_training VALUES 
            ('123456', 'Test Company', 0, 10, 0, 0.0, 5.5)
        """)
        conn.commit()
        conn.close()
        
        mock_get_db.return_value = str(db_path)
        
        df = pd.DataFrame({"dot_number": ["123456"]})
        
        with patch('dot_enrichment.dot_enrichment.fetch_missing_dots_from_api') as mock_api:
            mock_api.return_value = pd.DataFrame()
            
            result = enrich_with_ai_training(
                df,
                min_enrichment_rate=0.50,
                use_api_fallback=False
            )
        
        # Verify zero values were nullified
        assert pd.isna(result['drivers'].iloc[0]), "drivers should be null (was 0)"
        assert pd.isna(result['total_accidents'].iloc[0]), "total_accidents should be null (was 0)"
        assert pd.isna(result['annual_revenue'].iloc[0]), "annual_revenue should be null (was 0.0)"
        
        # Verify non-zero values were preserved
        assert result['owned_trucks'].iloc[0] == 10, "owned_trucks should be 10"
        assert result['avg_truck_age_years'].iloc[0] == 5.5, "avg_truck_age_years should be 5.5"
        assert result['company_name'].iloc[0] == 'Test Company', "company_name should be preserved"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

