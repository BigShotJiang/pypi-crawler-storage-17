#!/usr/bin/env python3
"""
Tests for derived_features module.

Run with: pytest tests/test_derived_features.py -v
"""

import pytest
import pandas as pd
import numpy as np
from dot_enrichment.derived_features import add_derived_and_prune


class TestAddDerivedAndPrune:
    """Test add_derived_and_prune function."""
    
    def test_basic_derived_features_creation(self):
        """Test that derived features are created from basic inputs."""
        df = pd.DataFrame({
            'dot_number': ['123456', '789012'],
            'total_accidents': [5, 10],
            'power_units': [10, 20],
            'drivers': [15, 30],
            'truck_units': [8, 16],
            'mcs_mileage': [1_000_000, 2_000_000],
        })
        
        result_df, dropped_cols = add_derived_and_prune(
            df,
            drop_threshold=0.98,
            inplace=False,
            drop_redundant=True
        )
        
        # Check that derived features were created
        derived_cols = [col for col in result_df.columns if col.startswith('derived_')]
        assert len(derived_cols) > 0, "No derived features were created"
        
        # Check specific derived features
        assert 'derived_accidents_per_power_unit' in result_df.columns
        assert 'derived_accidents_per_driver' in result_df.columns
        assert 'derived_miles_per_power_unit' in result_df.columns
        
        # Verify calculations
        assert result_df['derived_accidents_per_power_unit'].iloc[0] == 0.5  # 5/10
        assert result_df['derived_accidents_per_power_unit'].iloc[1] == 0.5  # 10/20
        assert result_df['derived_accidents_per_driver'].iloc[0] == 5/15
        assert result_df['derived_miles_per_power_unit'].iloc[0] == 100_000  # 1M/10
    
    def test_inspection_derived_features(self):
        """Test inspection and OOS-related derived features."""
        df = pd.DataFrame({
            'driver_oos_insp_total': [2, 4],
            'driver_insp_total': [20, 40],
            'vehicle_oos_insp_total': [3, 6],
            'vehicle_insp_total': [25, 50],
            'total_inspections': [45, 90],
            'power_units': [10, 20],
        })
        
        result_df, _ = add_derived_and_prune(df, drop_redundant=False)
        
        # Check OOS rates
        assert 'derived_driver_oos_rate' in result_df.columns
        assert 'derived_vehicle_oos_rate' in result_df.columns
        assert result_df['derived_driver_oos_rate'].iloc[0] == 0.1  # 2/20
        assert result_df['derived_vehicle_oos_rate'].iloc[0] == 0.12  # 3/25
        
        # Check inspections per power unit
        assert 'derived_insp_per_power_unit' in result_df.columns
        assert result_df['derived_insp_per_power_unit'].iloc[0] == 4.5  # 45/10
    
    def test_drop_redundant_columns(self):
        """Test that redundant columns are dropped when fill rates are high."""
        df = pd.DataFrame({
            'total_accidents': [5, 10, 15],
            'power_units': [10, 20, 30],
            'drivers': [15, 30, 45],
        })
        
        result_df, dropped_cols = add_derived_and_prune(
            df,
            drop_threshold=0.98,
            drop_redundant=True
        )
        
        # Check that source columns were dropped
        assert len(dropped_cols) > 0, "No columns were dropped"
        assert 'total_accidents' in dropped_cols
        assert 'power_units' in dropped_cols
        assert 'drivers' in dropped_cols
        
        # But derived features should exist
        assert 'derived_accidents_per_power_unit' in result_df.columns
        assert 'derived_accidents_per_driver' in result_df.columns
    
    def test_keep_all_columns_when_drop_redundant_false(self):
        """Test that all columns are kept when drop_redundant=False."""
        df = pd.DataFrame({
            'total_accidents': [5, 10],
            'power_units': [10, 20],
            'drivers': [15, 30],
        })
        
        result_df, dropped_cols = add_derived_and_prune(
            df,
            drop_redundant=False
        )
        
        # No columns should be dropped
        assert len(dropped_cols) == 0, "Columns were dropped when drop_redundant=False"
        
        # Original columns should still exist
        assert 'total_accidents' in result_df.columns
        assert 'power_units' in result_df.columns
        assert 'drivers' in result_df.columns
        
        # Derived features should also exist
        assert 'derived_accidents_per_power_unit' in result_df.columns
    
    def test_handles_missing_columns_gracefully(self):
        """Test that function handles missing source columns gracefully."""
        # DataFrame with only some columns
        df = pd.DataFrame({
            'total_accidents': [5, 10],
            # Missing power_units, drivers, etc.
        })
        
        result_df, dropped_cols = add_derived_and_prune(df, drop_redundant=False)
        
        # Should still create derived features, but they'll be NaN where inputs are missing
        assert 'derived_accidents_per_power_unit' in result_df.columns
        assert 'derived_accidents_per_driver' in result_df.columns
        
        # These should be NaN because source columns are missing
        assert pd.isna(result_df['derived_accidents_per_power_unit'].iloc[0])
        assert pd.isna(result_df['derived_accidents_per_driver'].iloc[0])
    
    def test_safe_division_handles_zeros(self):
        """Test that division by zero is handled safely."""
        df = pd.DataFrame({
            'total_accidents': [5, 10, 0],
            'power_units': [10, 0, 20],  # Zero in second row
        })
        
        result_df, _ = add_derived_and_prune(df, drop_redundant=False)
        
        # First row should calculate normally
        assert result_df['derived_accidents_per_power_unit'].iloc[0] == 0.5
        
        # Second row should be NaN (division by zero)
        assert pd.isna(result_df['derived_accidents_per_power_unit'].iloc[1])
        
        # Third row should calculate normally
        assert result_df['derived_accidents_per_power_unit'].iloc[2] == 0.0
    
    def test_violation_rate_features(self):
        """Test violation rate derived features."""
        df = pd.DataFrame({
            'unsafe_driv_insp_w_viol': [5, 10],
            'driver_insp_total': [50, 100],
            'hos_driv_insp_w_viol': [3, 6],
            'veh_maint_insp_w_viol': [4, 8],
            'vehicle_insp_total': [40, 80],
            'contr_subst_insp_w_viol': [1, 2],
        })
        
        result_df, _ = add_derived_and_prune(df, drop_redundant=False)
        
        assert 'derived_unsafe_driving_violation_rate' in result_df.columns
        assert 'derived_hos_violation_rate' in result_df.columns
        assert 'derived_vehicle_maintenance_violation_rate' in result_df.columns
        assert 'derived_contr_subst_violation_rate' in result_df.columns
        
        # Check calculations
        assert result_df['derived_unsafe_driving_violation_rate'].iloc[0] == 0.1  # 5/50
        assert result_df['derived_hos_violation_rate'].iloc[0] == 0.06  # 3/50
        assert result_df['derived_vehicle_maintenance_violation_rate'].iloc[0] == 0.1  # 4/40
    
    def test_flag_features(self):
        """Test flag-based derived features."""
        df = pd.DataFrame({
            'free_domain': [1, 0, np.nan],
            'business_is_b2b': [1, 1, 0],
            'total_involuntary_revocations': [0, 1, 5],
        })
        
        result_df, _ = add_derived_and_prune(df, drop_redundant=False)
        
        assert 'derived_has_free_domain_flag' in result_df.columns
        assert 'derived_b2b_flag' in result_df.columns
        assert 'derived_is_revoked_ever' in result_df.columns
        
        # Check flag calculations
        assert result_df['derived_has_free_domain_flag'].iloc[0] == 1
        assert result_df['derived_has_free_domain_flag'].iloc[1] == 0
        assert pd.isna(result_df['derived_has_free_domain_flag'].iloc[2])
        
        assert result_df['derived_is_revoked_ever'].iloc[0] == 0
        assert result_df['derived_is_revoked_ever'].iloc[1] == 1
        assert result_df['derived_is_revoked_ever'].iloc[2] == 1
    
    def test_geo_derived_features(self):
        """Test geography-based derived features."""
        df = pd.DataFrame({
            'radius_90pct_miles': [400, 100, 25],
            'max_distance_miles': [500, 300, 50],
            'distinct_states_served': [15, 8, 2],
        })
        
        result_df, _ = add_derived_and_prune(df, drop_redundant=False)
        
        assert 'derived_longhaul_flag' in result_df.columns
        assert 'derived_is_nationwide_carrier' in result_df.columns
        assert 'derived_is_local_carrier' in result_df.columns
        
        # Check flags
        assert result_df['derived_longhaul_flag'].iloc[0] == 1  # radius > 300
        assert result_df['derived_longhaul_flag'].iloc[2] == 0  # radius < 300
        
        assert result_df['derived_is_nationwide_carrier'].iloc[0] == 1  # > 10 states
        assert result_df['derived_is_nationwide_carrier'].iloc[1] == 0  # <= 10 states
        
        assert result_df['derived_is_local_carrier'].iloc[2] == 1  # radius < 50
        assert result_df['derived_is_local_carrier'].iloc[0] == 0  # radius >= 50
    
    def test_inplace_modification(self):
        """Test that inplace=True modifies the original DataFrame."""
        df = pd.DataFrame({
            'total_accidents': [5, 10],
            'power_units': [10, 20],
        })
        
        original_id = id(df)
        result_df, _ = add_derived_and_prune(df, inplace=True, drop_redundant=False)
        
        # Should return the same DataFrame object
        assert id(result_df) == original_id
        assert 'derived_accidents_per_power_unit' in df.columns
    
    def test_copy_when_not_inplace(self):
        """Test that inplace=False creates a copy."""
        df = pd.DataFrame({
            'total_accidents': [5, 10],
            'power_units': [10, 20],
        })
        
        original_cols = list(df.columns)
        result_df, _ = add_derived_and_prune(df, inplace=False, drop_redundant=False)
        
        # Original DataFrame should be unchanged
        assert list(df.columns) == original_cols
        assert 'derived_accidents_per_power_unit' not in df.columns
        
        # Result should have derived features
        assert 'derived_accidents_per_power_unit' in result_df.columns


class TestDerivedFeatureResilience:
    """Test that derived features are resilient to errors."""
    
    def test_continues_on_individual_feature_failure(self):
        """Test that if one feature fails, others still get computed."""
        # This is tested implicitly by the missing columns test
        # But let's be explicit about resilience
        df = pd.DataFrame({
            'total_accidents': [5, 10],
            'power_units': [10, 20],
            # Missing many other columns
        })
        
        result_df, _ = add_derived_and_prune(df, drop_redundant=False)
        
        # Should have created features that can be computed
        derived_cols = [col for col in result_df.columns if col.startswith('derived_')]
        
        # Even though many source columns are missing, we should still create
        # all 32 derived feature columns (they'll just have NaN values)
        assert len(derived_cols) == 32, f"Expected 32 derived features, got {len(derived_cols)}"
        
        # Features that can be computed should have values
        assert 'derived_accidents_per_power_unit' in result_df.columns
        assert result_df['derived_accidents_per_power_unit'].notna().any()
        
        # Features that can't be computed should be NaN
        assert 'derived_driver_oos_rate' in result_df.columns
        assert result_df['derived_driver_oos_rate'].isna().all()


class TestDerivedFeatureIntegration:
    """Test that derived features are properly integrated into enrichment pipeline."""
    
    def test_all_32_derived_features_created(self):
        """Test that all 32 expected derived features are created."""
        # Create a comprehensive test DataFrame with all possible source columns
        df = pd.DataFrame({
            'total_accidents': [10],
            'power_units': [20],
            'truck_units': [15],
            'drivers': [25],
            'mcs_mileage': [1_000_000],
            'accidents_last_year': [3],
            'driver_oos_insp_total': [5],
            'driver_insp_total': [50],
            'vehicle_oos_insp_total': [3],
            'vehicle_insp_total': [40],
            'total_inspections': [90],
            'insp_total': [90],
            'sleeper_cabs': [12],
            'day_cabs': [8],
            'drivers_added_24m': [5],
            'intrastate_drivers': [10],
            'max_distance_miles': [500],
            'radius_from_hq_90pct_miles': [300],
            'distinct_states_served': [15],
            'radius_95pct_miles': [400],
            'free_domain': [1],
            'business_is_b2b': [1],
            'contract_authority_age': [10],
            'broker_authority_age': [5],
            'total_involuntary_revocations': [0],
            'unsafe_driv_insp_w_viol': [5],
            'hos_driv_insp_w_viol': [3],
            'veh_maint_insp_w_viol': [4],
            'contr_subst_insp_w_viol': [2],
            'ia_driver_oos_last_90_days': [2],
            'ia_driver_oos_total': [10],
            'ia_vehicle_oos_last_90_days': [1],
            'ia_vehicle_oos_total': [8],
            'ia_inspections_last_90_days': [15],
            'ia_inspections_last_180_days': [25],
            'ia_inspections_last_year': [40],
            'radius_90pct_miles': [350],
        })
        
        result_df, _ = add_derived_and_prune(df, drop_redundant=False)
        
        # Count derived features
        derived_cols = [col for col in result_df.columns if col.startswith('derived_')]
        
        # We expect 32 derived features (based on the implementation)
        expected_derived_features = [
            'derived_accidents_per_power_unit',
            'derived_accidents_per_truck_unit',
            'derived_accidents_per_driver',
            'derived_accidents_per_million_miles',
            'derived_accidents_last_year_per_million_miles',
            'derived_driver_oos_rate',
            'derived_vehicle_oos_rate',
            'derived_insp_per_power_unit',
            'derived_oos_events_per_inspection',
            'derived_inspection_to_accident_ratio',
            'derived_sleeper_to_daycab_ratio',
            'derived_pct_sleeper_units',
            'derived_driver_growth_rate_24m',
            'derived_drivers_per_power_unit',
            'derived_intrastate_driver_ratio',
            'derived_miles_per_power_unit',
            'derived_max_radius_minus_hq_radius',
            'derived_operational_density_ratio',
            'derived_has_free_domain_flag',
            'derived_b2b_flag',
            'derived_authority_age_gap',
            'derived_is_revoked_ever',
            'derived_unsafe_driving_violation_rate',
            'derived_hos_violation_rate',
            'derived_vehicle_maintenance_violation_rate',
            'derived_contr_subst_violation_rate',
            'derived_recent_driver_oos_ratio',
            'derived_recent_vehicle_oos_ratio',
            'derived_inspection_recency_index',
            'derived_longhaul_flag',
            'derived_is_nationwide_carrier',
            'derived_is_local_carrier',
        ]
        
        assert len(derived_cols) == len(expected_derived_features), \
            f"Expected {len(expected_derived_features)} derived features, got {len(derived_cols)}"
        
        # Check that all expected features are present
        for feature in expected_derived_features:
            assert feature in result_df.columns, f"Missing expected feature: {feature}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

