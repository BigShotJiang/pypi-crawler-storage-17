# alphaloops-dot-enrichment

A Python package for enriching DataFrames with DOT (Department of Transportation) numbers using:
- **ai_training SQLite database** - Company data (name, address, etc.)
- **CSA safety scores** - From Supabase database
- **API fallback** - Fetch missing DOTs from freight API

## Installation

Install from the private package index:

```bash
pip3 install alphaloops-dot-enrichment --index-url https://bits.featrix.com/alphaloops/simple/
```

Or add to your `requirements.txt`:

```
--index-url https://bits.featrix.com/alphaloops/simple/
alphaloops-dot-enrichment>=0.1.0
```

## Quick Start

```python
import pandas as pd
from dot_enrichment import enrich_dot_dataframe

# Create DataFrame with DOT numbers
df = pd.DataFrame({'dot_number': ['123456', '789012']})

# Enrich with both ai_training and CSA scores
enriched_df = enrich_dot_dataframe(df)

print(enriched_df.columns)  # See all enriched columns
```

## Usage Guide

### Basic Usage

The main function `enrich_dot_dataframe()` handles everything automatically:

```python
import pandas as pd
from dot_enrichment import enrich_dot_dataframe

# Your DataFrame must have a DOT number column
df = pd.DataFrame({
    'dot_number': ['123456', '789012', '345678'],
    'other_data': ['value1', 'value2', 'value3']
})

# Enrich with default settings (both ai_training + CSA)
enriched_df = enrich_dot_dataframe(df)

# The enriched DataFrame now has additional columns from:
# - ai_training database (company_name, address, city, state, etc.)
# - CSA scores (insp_total, unsafe_driving, crash_indicator, etc.)
```

### Custom Column Names

If your DOT column has a different name:

```python
df = pd.DataFrame({
    'DOT Number': ['123456', '789012'],  # Different column name
    'other': ['a', 'b']
})

# Specify the column name
enriched_df = enrich_dot_dataframe(df, dot_column='DOT Number')

# Or auto-detect it
from dot_enrichment import detect_dot_column
dot_col = detect_dot_column(df)  # Returns 'DOT Number'
enriched_df = enrich_dot_dataframe(df, dot_column=dot_col)
```

### Normalizing DOT Numbers

The package automatically normalizes DOT numbers, but you can do it manually:

```python
from dot_enrichment import normalize_dot_series, normalize_dot_cell

# Normalize a Series
df['dot_number'] = normalize_dot_series(df['dot_number'])

# Normalize a single value
normalized = normalize_dot_cell("00123456")  # Returns "123456"
normalized = normalize_dot_cell("1,234,567")  # Returns "1234567"
normalized = normalize_dot_cell("123456.0")  # Returns "123456"
```

### Enrichment Options

Control which enrichments to apply:

```python
# Only enrich with ai_training data (no CSA scores)
enriched_df = enrich_dot_dataframe(
    df,
    enrich_ai_training=True,
    enrich_csa=False
)

# Only enrich with CSA scores (no ai_training)
enriched_df = enrich_dot_dataframe(
    df,
    enrich_ai_training=False,
    enrich_csa=True
)

# Customize enrichment rate requirements
enriched_df = enrich_dot_dataframe(
    df,
    min_ai_enrichment_rate=0.90,  # Require 90% success rate
    min_csa_success_rate=0.80,     # Require 80% CSA join success
    use_api_fallback=True          # Fetch missing DOTs from API
)
```

### Individual Enrichment Functions

Use individual functions for more control:

```python
from dot_enrichment import enrich_with_ai_training, enrich_with_csa_scores

# Step 1: Enrich with ai_training data
df = enrich_with_ai_training(
    df,
    dot_column='dot_number',
    min_enrichment_rate=0.80,
    use_api_fallback=True
)

# Step 2: Add CSA scores
df = enrich_with_csa_scores(
    df,
    dot_column='dot_number',
    min_success_rate=0.75
)
```

### Error Handling

The package raises exceptions if enrichment fails:

```python
from dot_enrichment import enrich_dot_dataframe
import pandas as pd

df = pd.DataFrame({'dot_number': ['123456']})

try:
    enriched_df = enrich_dot_dataframe(df, min_ai_enrichment_rate=0.95)
except ValueError as e:
    # Invalid parameters (e.g., missing column, invalid rate)
    print(f"Invalid input: {e}")
except RuntimeError as e:
    # Enrichment failed (e.g., rate too low, database not found)
    print(f"Enrichment failed: {e}")
```

### Common Patterns

**Pattern 1: Enrich existing DataFrame**

```python
# You have a DataFrame with DOT numbers
df = load_your_data()  # Your function

# Enrich it
df = enrich_dot_dataframe(df)

# Continue with your workflow
df.to_csv('enriched_output.csv')
```

**Pattern 2: Handle missing DOTs gracefully**

```python
# Lower the requirements if you expect some DOTs to be missing
enriched_df = enrich_dot_dataframe(
    df,
    min_ai_enrichment_rate=0.50,  # Accept 50% success
    min_csa_success_rate=0.50,
    use_api_fallback=True  # Try API for missing ones
)
```

**Pattern 3: Pre-normalize DOT numbers**

```python
from dot_enrichment import normalize_dot_series

# Clean up DOT numbers before enrichment
df['dot_number'] = normalize_dot_series(df['dot_number'])

# Remove invalid DOTs
df = df[df['dot_number'].notna()]

# Now enrich
df = enrich_dot_dataframe(df)
```

**Pattern 4: Check enrichment results**

```python
df = enrich_dot_dataframe(df)

# Check how many rows were enriched
ai_enriched = df['company_name'].notna().sum() if 'company_name' in df.columns else 0
csa_enriched = df['insp_total'].notna().sum() if 'insp_total' in df.columns else 0

print(f"AI Training: {ai_enriched}/{len(df)} rows enriched")
print(f"CSA Scores: {csa_enriched}/{len(df)} rows enriched")
```

## Complete API Reference

### Package: `dot_enrichment`

#### Main Enrichment Functions

##### `enrich_dot_dataframe(df, dot_column='dot_number', enrich_ai_training=True, enrich_csa=True, min_ai_enrichment_rate=0.80, min_csa_success_rate=0.75, use_api_fallback=True)`

Complete DOT enrichment pipeline. This is the main function to use for enriching DataFrames.

**Parameters:**
- `df` (pd.DataFrame): DataFrame with DOT numbers to enrich
- `dot_column` (str): Name of DOT column (default: 'dot_number')
- `enrich_ai_training` (bool): Enable ai_training enrichment (default: True)
- `enrich_csa` (bool): Enable CSA scores enrichment (default: True)
- `min_ai_enrichment_rate` (float): Minimum ai_training success rate 0.0-1.0 (default: 0.80)
- `min_csa_success_rate` (float): Minimum CSA join success rate 0.0-1.0 (default: 0.75)
- `use_api_fallback` (bool): Fetch missing DOTs from API (default: True)

**Returns:** `pd.DataFrame` - Enriched DataFrame with all enrichment columns added

**Raises:**
- `ValueError`: Invalid parameters or missing DOT column
- `RuntimeError`: Enrichment failed or rates too low

**Example:**
```python
import pandas as pd
from dot_enrichment import enrich_dot_dataframe

df = pd.DataFrame({'dot_number': ['123456', '789012']})
enriched = enrich_dot_dataframe(df)
# Returns DataFrame with company data and CSA scores added
```

##### `enrich_with_ai_training(df, dot_column='dot_number', min_enrichment_rate=0.80, use_api_fallback=True)`

Enrich DataFrame with ai_training SQLite database data only.

**Parameters:**
- `df` (pd.DataFrame): DataFrame with DOT numbers
- `dot_column` (str): Name of DOT column (default: 'dot_number')
- `min_enrichment_rate` (float): Minimum success rate 0.0-1.0 (default: 0.80)
- `use_api_fallback` (bool): Fetch missing DOTs from API (default: True)

**Returns:** `pd.DataFrame` - DataFrame with ai_training columns added (company_name, address, city, state, etc.)

**Raises:**
- `ValueError`: Invalid parameters or missing DOT column
- `RuntimeError`: Enrichment failed or rate too low

##### `enrich_with_csa_scores(df, dot_column='dot_number', min_success_rate=0.75)`

Enrich DataFrame with CSA safety scores from Supabase only.

**Parameters:**
- `df` (pd.DataFrame): DataFrame with DOT numbers
- `dot_column` (str): Name of DOT column (default: 'dot_number')
- `min_success_rate` (float): Minimum join success rate 0.0-1.0 (default: 0.75)

**Returns:** `pd.DataFrame` - DataFrame with CSA score columns added (insp_total, unsafe_driving, crash_indicator, etc.)

**Raises:**
- `ValueError`: Invalid parameters or missing DOT column
- `RuntimeError`: Join success rate too low

#### Utility Functions

##### `normalize_dot_cell(value) -> Optional[str]`

Normalize a single DOT number value. Handles various formats and edge cases.

**Parameters:**
- `value` (Any): DOT number value (string, int, float, etc.)

**Returns:** `Optional[str]` - Normalized DOT number or None if invalid

**Normalization Rules:**
- Removes leading zeros: `"00123456"` → `"123456"`
- Removes commas: `"1,234,567"` → `"1234567"`
- Removes trailing `.0`: `"123456.0"` → `"123456"`
- Strips whitespace
- Returns `None` for invalid formats (non-digits, non-zero decimals)

**Examples:**
```python
normalize_dot_cell("123456")      # → "123456"
normalize_dot_cell("00123456")    # → "123456"
normalize_dot_cell("1,234,567")   # → "1234567"
normalize_dot_cell("123456.0")    # → "123456"
normalize_dot_cell("123.4")       # → None (invalid decimal)
normalize_dot_cell("ABC123")      # → None (contains letters)
normalize_dot_cell(None)          # → None
```

##### `normalize_dot_series(series) -> pd.Series`

Normalize DOT numbers in a pandas Series.

**Parameters:**
- `series` (pd.Series): Series containing DOT numbers

**Returns:** `pd.Series` - Series with normalized DOT numbers

**Example:**
```python
import pandas as pd
from dot_enrichment import normalize_dot_series

series = pd.Series(["123456", "001234", "789012.0", None, "invalid"])
normalized = normalize_dot_series(series)
# Returns: ["123456", "1234", "789012", None, None]
```

##### `detect_dot_column(df) -> str`

Auto-detect DOT column name in DataFrame.

**Parameters:**
- `df` (pd.DataFrame): DataFrame to search

**Returns:** `str` - Column name if found, empty string if not found

**Detects:** `dot_number`, `DOT Number`, `DOT number`, `dotnumber`, `DOT`, `USDOT`, `USDOTNumber`, `dot_normalized`, `__featrix_meta_dot_number`

**Example:**
```python
df = pd.DataFrame({'DOT Number': [1, 2, 3]})
col = detect_dot_column(df)  # Returns: "DOT Number"
```

##### `fetch_missing_dots_from_api(dot_numbers) -> pd.DataFrame`

Fetch company data for DOT numbers from API fallback.

**Parameters:**
- `dot_numbers` (List[str]): List of normalized DOT numbers

**Returns:** `pd.DataFrame` - DataFrame with company data for successfully fetched DOTs

**Example:**
```python
from dot_enrichment import fetch_missing_dots_from_api

dots = ["123456", "789012"]
api_df = fetch_missing_dots_from_api(dots)
# Returns DataFrame with company data from API
```

##### `get_latest_ai_training_sqlite(training_dir=None, min_rows=25000) -> str`

Find the latest valid SQLite database file in AI training directory.

**Parameters:**
- `training_dir` (str, optional): Path to AI training directory (default: `/data/stuff/ai-training/`)
- `min_rows` (int): Minimum rows required in ai_training table (default: 25000)

**Returns:** `str` - Path to the latest valid database file

**Raises:**
- `FileNotFoundError`: Directory doesn't exist or no SQLite files found
- `ValueError`: No database with valid ai_training table found

**Example:**
```python
from dot_enrichment import get_latest_ai_training_sqlite

db_path = get_latest_ai_training_sqlite()
# Returns: "/data/stuff/ai-training/latest.db"
```

##### `fetch_csa_scores_by_dots(dot_numbers, supabase_url=None, anon_key=None, env_path=None, batch_size=500) -> pd.DataFrame`

Fetch CSA safety scores from Supabase for given DOT numbers.

**Parameters:**
- `dot_numbers` (List[str]): List of DOT numbers to fetch
- `supabase_url` (str, optional): Supabase project URL (default: configured URL)
- `anon_key` (str, optional): Supabase anon key (default: from environment)
- `env_path` (str, optional): Path to .env file (default: `/root/.env`)
- `batch_size` (int): Number of DOTs per batch (default: 500)

**Returns:** `pd.DataFrame` - DataFrame with CSA safety scores

**Raises:**
- `ValueError`: If anon key cannot be found
- `RuntimeError`: If all batches fail

**Example:**
```python
from dot_enrichment import fetch_csa_scores_by_dots

dots = ["123456", "789012"]
csa_df = fetch_csa_scores_by_dots(dots)
# Returns DataFrame with CSA scores
```

##### `get_anon_key(env_path=None, provided_key=None) -> str`

Get Supabase anon key from environment or .env file.

**Parameters:**
- `env_path` (str, optional): Path to .env file (default: `/root/.env`)
- `provided_key` (str, optional): Key provided directly

**Returns:** `str` - Supabase anon key

**Raises:**
- `ValueError`: If key not found

**Example:**
```python
from dot_enrichment import get_anon_key

key = get_anon_key()
# Returns Supabase anon key from environment
```

### Package: `alphaloops_scrape_server`

Domain and company enrichment utilities using Featrix cache APIs.

#### Constants

- `COMPANY_NAME_TO_WEBSITE_API`: URL for company name to website lookup API
- `FEATRIX_CACHE_API`: Base URL for Featrix scrape cache API
- `DOT_TO_DOMAIN_API`: URL for DOT number to domain lookup API
- `CHUNK_SIZE`: Number of domains to process per batch (default: 25)
- `MAX_RETRIES`: Maximum retry attempts (default: 10)
- `RETRY_DELAY`: Initial retry delay in seconds (default: 30)
- `DEFAULT_INPUT_DIR`: Default input directory path
- `DEFAULT_OUTPUT_DIR`: Default output directory path

#### Functions

##### `lookup_company_names_to_websites(company_names) -> dict`

Look up websites for company names using the company-name-to-website API.

**Parameters:**
- `company_names` (List[str]): List of company names to look up

**Returns:** `dict[str, str]` - Mapping of company name → website URL
- Only includes companies where website was found and validated
- Empty dict if no names provided or lookup fails

**Example:**
```python
from alphaloops_scrape_server import lookup_company_names_to_websites

companies = ["Acme Corp", "Widget Inc"]
websites = lookup_company_names_to_websites(companies)
# Returns: {"Acme Corp": "https://acme.com", "Widget Inc": "https://widget.com"}
```

**Notes:**
- Uses POST request to COMPANY_NAME_TO_WEBSITE_API
- Filters results by 'website_seems_sane' flag
- Status 'new' indicates lookup is being processed (not yet available)

##### `lookup_dot_to_domains(dot_numbers) -> dict`

Look up domains for DOT numbers using the dot-to-domain API.

**Parameters:**
- `dot_numbers` (List): List of DOT numbers (can be strings, ints, floats)
  - Examples: `["123456", 789012, "345678.0"]`

**Returns:** `dict[str, str]` - Mapping of DOT number → domain
- Empty dict if no valid DOTs or lookup fails

**Example:**
```python
from alphaloops_scrape_server import lookup_dot_to_domains

dots = ["123456", "789012", "345678.0"]
domains = lookup_dot_to_domains(dots)
# Returns: {"123456": "example.com", "789012": "another.com"}
```

**Notes:**
- Automatically normalizes DOT numbers (removes decimals, cleans format)
- Deduplicates input DOTs
- Batches requests (25 DOTs per API call)
- Uses GET request to DOT_TO_DOMAIN_API

##### `enrich_domains(domains) -> list`

Main function: Enrich all domains with company information using Featrix cache API.

**Parameters:**
- `domains` (List[str]): List of domains to enrich

**Returns:** `List[dict]` - List of enriched domain records
- Each record has: `domain`, `enrichment_status`, `enrichment_timestamp`
- Successful records include all flattened LLM summary fields
- Failed records include `enrichment_error` if applicable

**Example:**
```python
from alphaloops_scrape_server import enrich_domains

domains = ["example.com", "test.com", "demo.com"]
enriched = enrich_domains(domains)
# Returns: [
#     {
#         "domain": "example.com",
#         "enrichment_status": "success",
#         "enrichment_timestamp": "2025-11-15T21:00:00",
#         "business_name": "Example Corp",
#         "business_is_logistics_related": True,
#         ...
#     },
#     ...
# ]
```

**Notes:**
- Processes domains in chunks (CHUNK_SIZE domains per chunk)
- Provides detailed progress logging
- Adds 2 second delay between chunks
- Returns consistent schema for all domains (empty fields for failures)

**Status Values:**
- `success`: Data found and processed successfully
- `no_data`: Domain found but no LLM summary available
- `not_found`: Domain not found in cache
- `error`: Request failed or error occurred

##### `query_scrape(query_string) -> list`

Query Featrix scrape cache API for domain data.

**Parameters:**
- `query_string` (str): Comma-separated domain list (e.g., `"example.com,test.com"`)

**Returns:** `List[dict]` - List of domain data dictionaries from cache

**Raises:**
- `FileNotFoundError`: If domains not found in cache (404 response)
- `Exception`: For other HTTP errors or network issues

**Example:**
```python
from alphaloops_scrape_server import query_scrape

data = query_scrape("example.com,test.com")
# Returns: [{"domain": "example.com", "llm-json-summary": {...}}, ...]
```

**Notes:**
- Automatically retries on 503 errors (up to 5 times with exponential backoff)
- Handles JSON decode errors (NaN → null conversion)
- Retries on connection errors and timeouts
- 60 second timeout per request

##### `fetch_domain_data(domain_chunk) -> dict`

Fetch enrichment data for a chunk of domains.

**Parameters:**
- `domain_chunk` (List[str]): List of domains to fetch (typically 10-25 domains)

**Returns:** `dict[str, dict]` - Domain data keyed by domain name
- Each value has keys: `status`, `data`, `raw_item`
- Status values: `success`, `no_data`, `not_found`, `error`

**Example:**
```python
from alphaloops_scrape_server import fetch_domain_data

data = fetch_domain_data(["example.com", "test.com"])
# Returns: {
#   "example.com": {
#     "status": "success",
#     "data": {"business_name": "Example Corp", ...},
#     "raw_item": {...}
#   },
#   "test.com": {"status": "not_found", "data": None, "raw_item": None}
# }
```

##### `extract_llm_summary_fields(llm_summary) -> dict`

Flatten llm-json-summary dictionary into feature columns.

**Parameters:**
- `llm_summary` (dict): LLM summary dictionary from Featrix cache

**Returns:** `dict[str, any]` - Flattened dictionary with normalized keys
- Hyphens converted to underscores
- Lists converted to comma-separated strings
- Nested 'sub-*' dicts flattened with underscore notation
- Other dicts converted to JSON strings

**Example:**
```python
from alphaloops_scrape_server import extract_llm_summary_fields

summary = {
    "business_name": "Acme Corp",
    "sub-logistics": {"trucking": True, "warehousing": False},
    "services": ["A", "B", "C"]
}
fields = extract_llm_summary_fields(summary)
# Returns: {
#     "business_name": "Acme Corp",
#     "sub_logistics_trucking": True,
#     "sub_logistics_warehousing": False,
#     "services": "A, B, C"
# }
```

##### `chunk_domains(domains, chunk_size=CHUNK_SIZE) -> generator`

Split domains into chunks for batch processing.

**Parameters:**
- `domains` (List[str]): List of domains to chunk
- `chunk_size` (int): Size of each chunk (default: CHUNK_SIZE)

**Returns:** `generator` - Yields lists of domains, each of size chunk_size (last may be smaller)

**Example:**
```python
from alphaloops_scrape_server import chunk_domains

domains = ["a.com", "b.com", "c.com", "d.com", "e.com"]
for chunk in chunk_domains(domains, chunk_size=2):
    print(chunk)
# Output:
# ['a.com', 'b.com']
# ['c.com', 'd.com']
# ['e.com']
```

##### `prepare_es_random_carriers_dataset(num_carriers=3000) -> pd.DataFrame`

Prepare a dataset of random carriers for ES training (without labels).

**Parameters:**
- `num_carriers` (int): Number of random carriers to sample (default: 3000)

**Returns:** `pd.DataFrame` - DataFrame with random carriers, enriched with ai_training and CSA scores, ready for ES training (no is_bad_account)

**Example:**
```python
from alphaloops_scrape_server import prepare_es_random_carriers_dataset

# Prepare dataset with 3000 random carriers
es_df = prepare_es_random_carriers_dataset(num_carriers=3000)

# Dataset includes:
# - All columns from ai_training database (company_name, address, city, state, etc.)
# - CSA safety scores (insp_total, unsafe_driving, crash_indicator, etc.)
# - Normalized dot_number column
# - No is_bad_account label column (removed if present)

print(f"Prepared {len(es_df)} carriers with {len(es_df.columns)} columns")
```

**Notes:**
- Samples random carriers from ai_training SQLite database using `ORDER BY RANDOM()`
- Automatically normalizes DOT numbers
- Enriches with CSA scores (skips AI training enrichment since data already comes from ai_training)
- Removes `is_bad_account` label column if present (ES training should not have labels)
- Requires access to ai_training database (uses `get_latest_ai_training_sqlite()`)
- CSA enrichment failures are logged but don't stop the process

### Complete Workflow Examples

#### Example 1: DOT → Domain → Enrichment Pipeline

```python
import pandas as pd
from dot_enrichment import enrich_dot_dataframe
from alphaloops_scrape_server import lookup_dot_to_domains, enrich_domains

# Step 1: Start with DOT numbers
df = pd.DataFrame({'dot_number': ['123456', '789012']})

# Step 2: Enrich with DOT data (company info + CSA scores)
enriched_df = enrich_dot_dataframe(df)

# Step 3: Get domains for DOTs
dots = enriched_df['dot_number'].tolist()
dot_to_domain = lookup_dot_to_domains(dots)

# Step 4: Enrich domains with website data
domains = list(dot_to_domain.values())
domain_enriched = enrich_domains(domains)

# Step 5: Combine results
# enriched_df has DOT-level data
# domain_enriched has domain-level data
```

#### Example 2: Company Name → Website → Domain Enrichment

```python
from alphaloops_scrape_server import lookup_company_names_to_websites, enrich_domains

# Step 1: Look up websites for company names
companies = ["Acme Corp", "Widget Inc"]
websites = lookup_company_names_to_websites(companies)

# Step 2: Extract domains from websites
domains = [url.replace("https://", "").replace("http://", "").split("/")[0] 
           for url in websites.values()]

# Step 3: Enrich domains
enriched = enrich_domains(domains)
```

#### Example 3: Error Handling

```python
from dot_enrichment import enrich_dot_dataframe
import pandas as pd

df = pd.DataFrame({'dot_number': ['123456']})

try:
    enriched = enrich_dot_dataframe(df, min_ai_enrichment_rate=0.95)
except ValueError as e:
    # Invalid parameters
    print(f"Invalid input: {e}")
except RuntimeError as e:
    # Enrichment failed
    print(f"Enrichment failed: {e}")
    # Fallback: try with lower requirements
    enriched = enrich_dot_dataframe(df, min_ai_enrichment_rate=0.50)
```

## Requirements

- Python >= 3.8
- pandas >= 1.5.0
- requests >= 2.28.0
- python-dotenv >= 0.19.0

## Configuration

### AI Training Database

By default, looks for SQLite databases in `/data/stuff/ai-training/`. 

The database must have:
- An `ai_training` table
- A `__dot_key` column (normalized DOT numbers)
- At least 25,000 rows (configurable)

**Override the directory:**
```python
import os
os.environ['AI_TRAINING_DIR'] = '/path/to/your/ai-training/'

# Or pass directly to helper function
from dot_enrichment import get_latest_ai_training_sqlite
db_path = get_latest_ai_training_sqlite(training_dir='/custom/path')
```

### Supabase Configuration

Set `SUPABASE_ANON_KEY` in your environment or `.env` file.

**Option 1: Environment variable**
```bash
export SUPABASE_ANON_KEY="your-key-here"
```

**Option 2: .env file**
```bash
# /root/.env (default) or custom path
SUPABASE_ANON_KEY=your-key-here
```

**Option 3: Pass directly**
```python
from dot_enrichment import fetch_csa_scores_by_dots
csa_df = fetch_csa_scores_by_dots(
    ['123456'],
    anon_key='your-key-here'
)
```

### API Fallback

The API fallback uses: `https://freight-api.runalphaloops.com/functions/v1/ai-dot-number`

No authentication required. Automatically called when `use_api_fallback=True`.

## Troubleshooting

### "DOT column 'dot_number' not found in DataFrame"

**Solution:** Specify the correct column name or use `detect_dot_column()`:
```python
from dot_enrichment import detect_dot_column
dot_col = detect_dot_column(df)
if dot_col:
    df = enrich_dot_dataframe(df, dot_column=dot_col)
```

### "Enrichment rate X% below minimum required Y%"

**Solution:** Lower the `min_ai_enrichment_rate` or enable API fallback:
```python
df = enrich_dot_dataframe(df, min_ai_enrichment_rate=0.50, use_api_fallback=True)
```

### "Could not locate ai_training SQLite database"

**Solution:** Check that the database directory exists and contains SQLite files:
```python
from dot_enrichment import get_latest_ai_training_sqlite
try:
    db_path = get_latest_ai_training_sqlite()
    print(f"Found database: {db_path}")
except FileNotFoundError as e:
    print(f"Database not found: {e}")
```

### "Anon key not found" (CSA enrichment)

**Solution:** Set the Supabase anon key:
```bash
export SUPABASE_ANON_KEY="your-key"
```

### DOT numbers not matching

**Solution:** Ensure DOT numbers are normalized:
```python
from dot_enrichment import normalize_dot_series
df['dot_number'] = normalize_dot_series(df['dot_number'])
```

## Testing

Run the test suite:

```bash
# Install test dependencies
pip3 install pytest pytest-mock

# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_dot_enrichment.py -v

# Run specific test
pytest tests/test_dot_enrichment.py::TestEnrichWithAITraining::test_enrich_with_test_data_dir -v
```

### Test Data Directory

Tests automatically create a temporary test data directory with:
- `test_data/ai-training/test_ai_training.db` - Mock SQLite database with test DOT records
- Environment variable `AI_TRAINING_DIR` is automatically set for tests

The test fixtures in `tests/conftest.py` handle test data setup automatically. You don't need to manually create test data - it's created and cleaned up automatically by pytest.

### Real Integration Tests

The test suite includes **REAL integration tests** that actually hit databases and APIs:

**Real Database Tests:**
- `test_enrich_with_test_data_dir` - Connects to real SQLite database
- `test_get_latest_ai_training_sqlite_with_test_dir` - Real database lookup
- `test_full_enrichment_pipeline_real_database` - Full end-to-end with real DB

**Real Supabase API Tests:**
- `test_enrich_csa_real_supabase_api` - Actually hits Supabase API
- `test_enrich_csa_real_supabase_large_batch` - Fetches large batches (slow)

**⚠️ IMPORTANT:** Integration tests **REQUIRE** credentials and will **FAIL** if not provided (they don't skip).

To run real Supabase tests, set `SUPABASE_ANON_KEY`:
```bash
export SUPABASE_ANON_KEY="your-key-here"
pytest tests/ -v -m integration
```

To skip slow/integration tests (run only unit tests):
```bash
# Skip integration tests
pytest tests/ -v -m "not integration"

# Skip slow tests  
pytest tests/ -v -m "not slow"
```

**Integration tests will crash with clear error messages if credentials are missing** - this ensures you know immediately if something is misconfigured.

## Development

### Building the Package

```bash
python3 -m build
```

This creates `dist/` directory with wheel and source distribution files.

### Publishing to Private Index

Build and publish:

```bash
make build
make publish
```

Or manually:

```bash
python3 -m build
scp dist/* bits:/var/www/html/alphaloops/
```

The package will then be available at:
```
https://bits.featrix.com/alphaloops/simple/alphaloops-dot-enrichment/
```

### Project Structure

```
dot_enrichment/
├── __init__.py              # Package exports
├── dot_enrichment.py        # Main enrichment functions
├── data_utils.py           # DOT normalization utilities
├── aitraining_helpers.py   # SQLite database helpers
└── supabase_helpers.py     # Supabase API helpers

tests/
└── test_dot_enrichment.py  # Test suite
```

## Examples

### Example 1: Basic Enrichment

```python
import pandas as pd
from dot_enrichment import enrich_dot_dataframe

df = pd.DataFrame({
    'dot_number': ['123456', '789012'],
    'policy_id': ['P1', 'P2']
})

enriched = enrich_dot_dataframe(df)
print(enriched[['dot_number', 'company_name', 'insp_total']])
```

### Example 2: Custom Column Name

```python
df = pd.DataFrame({
    'DOT': ['123456', '789012'],
    'other': ['a', 'b']
})

enriched = enrich_dot_dataframe(df, dot_column='DOT')
```

### Example 3: Only AI Training Data

```python
enriched = enrich_dot_dataframe(
    df,
    enrich_ai_training=True,
    enrich_csa=False
)
# Only company data, no CSA scores
```

### Example 4: Handle Errors Gracefully

```python
try:
    enriched = enrich_dot_dataframe(df, min_ai_enrichment_rate=0.95)
except RuntimeError as e:
    print(f"Enrichment failed: {e}")
    # Fallback: try with lower requirements
    enriched = enrich_dot_dataframe(df, min_ai_enrichment_rate=0.50)
```

## License

Copyright 2025 by AlphaLoops, Inc. Confidential and Proprietary.
