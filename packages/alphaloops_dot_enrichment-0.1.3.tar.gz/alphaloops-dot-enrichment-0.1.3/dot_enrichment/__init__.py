"""
DOT Number Enrichment Package

A Python package for enriching DataFrames with DOT numbers using:
- ai_training SQLite database (company data)
- CSA safety scores from Supabase
- API fallback for missing DOTs
"""

from .dot_enrichment import (
    enrich_dot_dataframe,
    enrich_with_ai_training,
    enrich_with_csa_scores
)

from .data_utils import (
    normalize_dot_cell,
    normalize_dot_series,
    detect_dot_column,
    fetch_missing_dots_from_api,
    fetch_dot_enrichment,
    enrich_merge
)

from .aitraining_helpers import get_latest_ai_training_sqlite
from .supabase_helpers import fetch_csa_scores_by_dots, get_anon_key

__version__ = "0.1.3"
__all__ = [
    "enrich_dot_dataframe",
    "enrich_with_ai_training",
    "enrich_with_csa_scores",
    "normalize_dot_cell",
    "normalize_dot_series",
    "detect_dot_column",
    "fetch_missing_dots_from_api",
    "fetch_dot_enrichment",
    "enrich_merge",
    "get_latest_ai_training_sqlite",
    "fetch_csa_scores_by_dots",
    "get_anon_key",
]

