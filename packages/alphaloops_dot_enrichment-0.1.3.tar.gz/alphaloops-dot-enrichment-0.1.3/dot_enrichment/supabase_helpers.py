#!/usr/bin/env python3
"""
Helper functions for fetching CSA safety scores from Supabase.
"""

import os
import requests
import pandas as pd
import logging
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# Default configuration
DEFAULT_SUPABASE_URL = "https://avxupbfwypysogmxbgwn.supabase.co"
DEFAULT_ENV_PATH = "/root/.env"


def get_anon_key(env_path=DEFAULT_ENV_PATH, provided_key=None):
    """
    Get Supabase anon key from .env file or provided key.
    
    Args:
        env_path: Path to .env file (default: /root/.env)
        provided_key: Key provided directly
        
    Returns:
        str: Supabase anon key
        
    Raises:
        ValueError: If key not found
    """
    if provided_key:
        logger.debug("Using anon key from provided parameter")
        return provided_key
    
    # Try current directory .env first, then default path
    env_paths = [
        os.path.join(os.getcwd(), '.env'),  # Workspace root
        env_path,  # Default path
    ]
    
    env_loaded = False
    for path in env_paths:
        logger.debug(f"Checking for .env file at {path}")
        if os.path.exists(path):
            load_dotenv(path)
            logger.debug(f"Loaded .env file: {path}")
            env_loaded = True
            break
    
    if not env_loaded:
        logger.warning(f"Environment file not found in {env_paths}")
    
    # Try common environment variable names
    key_names = ['SUPABASE_ANON_KEY', 'SUPABASE_PUBLIC_KEY', 'ANON_KEY', 'PUBLIC_KEY']
    
    for key_name in key_names:
        key_value = os.getenv(key_name)
        if key_value:
            logger.debug(f"Found anon key as {key_name}")
            return key_value
    
    raise ValueError(f"Anon key not found. Please provide key parameter or add SUPABASE_ANON_KEY to .env file in workspace root or {env_path}")


def fetch_csa_scores_by_dots(dot_numbers, supabase_url=DEFAULT_SUPABASE_URL, anon_key=None, env_path=DEFAULT_ENV_PATH, batch_size=500):
    """
    Fetch CSA safety scores from Supabase for given DOT numbers (batched to avoid URL limits).
    
    Args:
        dot_numbers: List of DOT numbers to fetch
        supabase_url: Supabase project URL
        anon_key: Supabase anon key (if None, loads from env)
        env_path: Path to .env file
        batch_size: Number of DOTs to fetch per request (default 500)
        
    Returns:
        pd.DataFrame: CSA safety scores for the given DOTs
        
    Raises:
        ValueError: If anon key cannot be found
        RuntimeError: If all batches fail
    """
    if not dot_numbers:
        return pd.DataFrame()
    
    if not anon_key:
        anon_key = get_anon_key(env_path)
    
    headers = {
        'apikey': anon_key,
        'Authorization': f'Bearer {anon_key}',
        'Content-Type': 'application/json'
    }
    
    # Normalize DOT numbers to strings
    dot_list = [str(d).strip() for d in dot_numbers]
    
    logger.info(f"Fetching CSA scores for {len(dot_list)} DOT numbers (batched in {batch_size})")
    
    # Batch requests to avoid URL length limits
    all_dfs = []
    total_fetched = 0
    num_batches = (len(dot_list) - 1) // batch_size + 1
    
    for i in range(0, len(dot_list), batch_size):
        batch_num = i // batch_size + 1
        batch = dot_list[i:i+batch_size]
        
        # Supabase uses 'in' filter for WHERE IN queries
        dots_str = ','.join(f'"{d}"' for d in batch)
        
        url = f"{supabase_url}/rest/v1/csa_safety_scores"
        params = {
            'select': '*',
            'dot_number': f'in.({dots_str})'
        }
        
        try:
            response = requests.get(url, headers=headers, params=params, timeout=60)
            response.raise_for_status()
            
            data = response.json()
            batch_count = len(data) if data else 0
            total_fetched += batch_count
            
            logger.debug(f"Batch {batch_num}/{num_batches}: {batch_count} records (total so far: {total_fetched})")
            
            if data:
                all_dfs.append(pd.DataFrame(data))
        except Exception as e:
            logger.warning(f"Batch {batch_num}/{num_batches} failed: {e}")
            continue
    
    if all_dfs:
        # Filter out empty DataFrames before concatenating to avoid FutureWarning
        non_empty_dfs = [df for df in all_dfs if not df.empty]
        if non_empty_dfs:
            df = pd.concat(non_empty_dfs, ignore_index=True)
            logger.info(f"Total CSA records retrieved: {len(df)} from {num_batches} batches")
            return df
        else:
            logger.warning("No non-empty CSA scores retrieved from any batch")
            return pd.DataFrame()
    else:
        logger.warning("No CSA scores retrieved from any batch")
        return pd.DataFrame()

