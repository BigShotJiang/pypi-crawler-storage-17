# derived_features.py

from typing import Tuple, List
import numpy as np
import pandas as pd
import logging

logger = logging.getLogger(__name__)


def _safe_div(num: pd.Series, den: pd.Series) -> pd.Series:
    """
    Null-safe division:
    - If num or den is NaN -> NaN
    - If den == 0 or NaN -> NaN
    """
    num = num.astype("float64")
    den = den.astype("float64")
    return pd.Series(
        np.where(
            num.notna() & den.notna() & (den != 0),
            num / den,
            np.nan,
        ),
        index=num.index,
    )


def _get_col_or_nan(df: pd.DataFrame, col_name: str) -> pd.Series:
    """Get a column from DataFrame or return NaN series if missing."""
    if col_name in df.columns:
        return df[col_name]
    else:
        return pd.Series(index=df.index, dtype="float64")


def _safe_add_feature(df: pd.DataFrame, feature_name: str, compute_func, feature_description: str = None) -> bool:
    """
    Safely add a derived feature to the DataFrame with error handling.
    
    Args:
        df: DataFrame to add feature to
        feature_name: Name of the derived feature to add
        compute_func: Function that computes the feature value (takes no args, accesses df via closure)
        feature_description: Optional description for logging
        
    Returns:
        True if feature was successfully added, False if there was an error
    """
    try:
        df[feature_name] = compute_func()
        return True
    except Exception as e:
        desc = feature_description or feature_name
        logger.warning(f"Failed to compute {desc}: {e}")
        # Add a NaN column as placeholder
        df[feature_name] = pd.Series(index=df.index, dtype="float64")
        return False


def add_derived_and_prune(
    df: pd.DataFrame,
    drop_threshold: float = 0.98,
    inplace: bool = False,
    drop_redundant: bool = True,
) -> Tuple[pd.DataFrame, List[str]]:
    """
    Add derived_* ratio/combination features and optionally drop raw columns
    that are safely redundant, based on fill rates.

    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe with original FMCSA / carrier columns.
    drop_threshold : float, optional
        If the fill rate of a derived feature is at least
        `drop_threshold * min(fill of its raw inputs)`,
        then the raw inputs are considered safe to drop.
        Default: 0.98 (i.e., derived is ≥ 98% as full as the raw).
    inplace : bool, optional
        If True, modify df in place and return it.
        If False, work on a copy.
    drop_redundant : bool, optional
        If True, drop redundant raw columns based on fill rates.
        If False, keep all columns (useful for training downstream models).
        Default: True.

    Returns
    -------
    df_out : pd.DataFrame
        DataFrame with derived_* columns added and optionally some raw columns dropped.
    dropped_columns : List[str]
        List of raw column names that were actually dropped (empty if drop_redundant=False).
    """

    if not inplace:
        df = df.copy()

    # ============================================================
    # 1. CREATE DERIVED FEATURES (all prefixed with derived_)
    #    ALWAYS create all features - fill with NaN if source columns missing
    #    Use error handling to ensure one failing feature doesn't break all others
    # ============================================================
    
    features_created = 0
    features_failed = 0

    # --- Accident normalization ---
    if _safe_add_feature(df, "derived_accidents_per_power_unit",
                         lambda: _safe_div(_get_col_or_nan(df, "total_accidents"), _get_col_or_nan(df, "power_units"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_accidents_per_truck_unit",
                         lambda: _safe_div(_get_col_or_nan(df, "total_accidents"), _get_col_or_nan(df, "truck_units"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_accidents_per_driver",
                         lambda: _safe_div(_get_col_or_nan(df, "total_accidents"), _get_col_or_nan(df, "drivers"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_accidents_per_million_miles",
                         lambda: _safe_div(_get_col_or_nan(df, "total_accidents"), _get_col_or_nan(df, "mcs_mileage") / 1_000_000)):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_accidents_last_year_per_million_miles",
                         lambda: _safe_div(_get_col_or_nan(df, "accidents_last_year"), _get_col_or_nan(df, "mcs_mileage") / 1_000_000)):
        features_created += 1
    else:
        features_failed += 1

    # --- Inspection & OOS ratios ---
    if _safe_add_feature(df, "derived_driver_oos_rate",
                         lambda: _safe_div(_get_col_or_nan(df, "driver_oos_insp_total"), _get_col_or_nan(df, "driver_insp_total"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_vehicle_oos_rate",
                         lambda: _safe_div(_get_col_or_nan(df, "vehicle_oos_insp_total"), _get_col_or_nan(df, "vehicle_insp_total"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_insp_per_power_unit",
                         lambda: _safe_div(_get_col_or_nan(df, "total_inspections"), _get_col_or_nan(df, "power_units"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_oos_events_per_inspection",
                         lambda: _safe_div(_get_col_or_nan(df, "driver_oos_insp_total") + _get_col_or_nan(df, "vehicle_oos_insp_total"), _get_col_or_nan(df, "total_inspections"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_inspection_to_accident_ratio",
                         lambda: _safe_div(_get_col_or_nan(df, "insp_total"), _get_col_or_nan(df, "total_accidents"))):
        features_created += 1
    else:
        features_failed += 1

    # --- Driver / equipment / mix ---
    if _safe_add_feature(df, "derived_sleeper_to_daycab_ratio",
                         lambda: _safe_div(_get_col_or_nan(df, "sleeper_cabs"), _get_col_or_nan(df, "day_cabs"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_pct_sleeper_units",
                         lambda: _safe_div(_get_col_or_nan(df, "sleeper_cabs"), _get_col_or_nan(df, "power_units"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_driver_growth_rate_24m",
                         lambda: _safe_div(_get_col_or_nan(df, "drivers_added_24m"), _get_col_or_nan(df, "drivers"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_drivers_per_power_unit",
                         lambda: _safe_div(_get_col_or_nan(df, "drivers"), _get_col_or_nan(df, "power_units"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_intrastate_driver_ratio",
                         lambda: _safe_div(_get_col_or_nan(df, "intrastate_drivers"), _get_col_or_nan(df, "drivers"))):
        features_created += 1
    else:
        features_failed += 1

    # --- Mileage / radius / exposure ---
    if _safe_add_feature(df, "derived_miles_per_power_unit",
                         lambda: _safe_div(_get_col_or_nan(df, "mcs_mileage"), _get_col_or_nan(df, "power_units"))):
        features_created += 1
    else:
        features_failed += 1

    def _compute_radius_diff():
        max_dist = _get_col_or_nan(df, "max_distance_miles")
        radius_hq = _get_col_or_nan(df, "radius_from_hq_90pct_miles")
        return max_dist - radius_hq
    
    if _safe_add_feature(df, "derived_max_radius_minus_hq_radius", _compute_radius_diff):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_operational_density_ratio",
                         lambda: _safe_div(_get_col_or_nan(df, "distinct_states_served"), _get_col_or_nan(df, "radius_95pct_miles"))):
        features_created += 1
    else:
        features_failed += 1

    # --- Authority / business combos (flags kept separate from drop logic) ---
    def _compute_free_domain_flag():
        free_domain = _get_col_or_nan(df, "free_domain")
        return np.where(free_domain.notna(), (free_domain == 1).astype("Int64"), pd.NA)
    
    if _safe_add_feature(df, "derived_has_free_domain_flag", _compute_free_domain_flag):
        features_created += 1
    else:
        features_failed += 1

    def _compute_b2b_flag():
        business_b2b = _get_col_or_nan(df, "business_is_b2b")
        return np.where(business_b2b.notna(), (business_b2b == 1).astype("Int64"), pd.NA)
    
    if _safe_add_feature(df, "derived_b2b_flag", _compute_b2b_flag):
        features_created += 1
    else:
        features_failed += 1

    def _compute_authority_age_gap():
        contract_age = _get_col_or_nan(df, "contract_authority_age")
        broker_age = _get_col_or_nan(df, "broker_authority_age")
        return (contract_age - broker_age).abs()
    
    if _safe_add_feature(df, "derived_authority_age_gap", _compute_authority_age_gap):
        features_created += 1
    else:
        features_failed += 1

    def _compute_revoked_flag():
        revocations = _get_col_or_nan(df, "total_involuntary_revocations")
        return np.where(revocations.notna(), (revocations > 0).astype("Int64"), pd.NA)
    
    if _safe_add_feature(df, "derived_is_revoked_ever", _compute_revoked_flag):
        features_created += 1
    else:
        features_failed += 1

    # --- Violation rates ---
    if _safe_add_feature(df, "derived_unsafe_driving_violation_rate",
                         lambda: _safe_div(_get_col_or_nan(df, "unsafe_driv_insp_w_viol"), _get_col_or_nan(df, "driver_insp_total"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_hos_violation_rate",
                         lambda: _safe_div(_get_col_or_nan(df, "hos_driv_insp_w_viol"), _get_col_or_nan(df, "driver_insp_total"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_vehicle_maintenance_violation_rate",
                         lambda: _safe_div(_get_col_or_nan(df, "veh_maint_insp_w_viol"), _get_col_or_nan(df, "vehicle_insp_total"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_contr_subst_violation_rate",
                         lambda: _safe_div(_get_col_or_nan(df, "contr_subst_insp_w_viol"), _get_col_or_nan(df, "driver_insp_total"))):
        features_created += 1
    else:
        features_failed += 1

    # --- Recency ratios / combos ---
    if _safe_add_feature(df, "derived_recent_driver_oos_ratio",
                         lambda: _safe_div(_get_col_or_nan(df, "ia_driver_oos_last_90_days"), _get_col_or_nan(df, "ia_driver_oos_total"))):
        features_created += 1
    else:
        features_failed += 1

    if _safe_add_feature(df, "derived_recent_vehicle_oos_ratio",
                         lambda: _safe_div(_get_col_or_nan(df, "ia_vehicle_oos_last_90_days"), _get_col_or_nan(df, "ia_vehicle_oos_total"))):
        features_created += 1
    else:
        features_failed += 1

    def _compute_inspection_recency_index():
        ia_90 = _get_col_or_nan(df, "ia_inspections_last_90_days")
        ia_180 = _get_col_or_nan(df, "ia_inspections_last_180_days")
        ia_year = _get_col_or_nan(df, "ia_inspections_last_year")
        return ia_90 * 3 + ia_180 * 2 + ia_year
    
    if _safe_add_feature(df, "derived_inspection_recency_index", _compute_inspection_recency_index):
        features_created += 1
    else:
        features_failed += 1

    # --- Geo flags (not used for drop logic; lossy thresholds) ---
    def _compute_longhaul_flag():
        radius_90 = _get_col_or_nan(df, "radius_90pct_miles")
        max_dist = _get_col_or_nan(df, "max_distance_miles")
        has_geo_data = radius_90.notna() | max_dist.notna()
        return np.where(has_geo_data, ((radius_90 > 300) | (max_dist > 400)).astype("Int64"), pd.NA)
    
    if _safe_add_feature(df, "derived_longhaul_flag", _compute_longhaul_flag):
        features_created += 1
    else:
        features_failed += 1

    def _compute_nationwide_carrier_flag():
        states_served = _get_col_or_nan(df, "distinct_states_served")
        return np.where(states_served.notna(), (states_served > 10).astype("Int64"), pd.NA)
    
    if _safe_add_feature(df, "derived_is_nationwide_carrier", _compute_nationwide_carrier_flag):
        features_created += 1
    else:
        features_failed += 1

    def _compute_local_carrier_flag():
        radius_90 = _get_col_or_nan(df, "radius_90pct_miles")
        return np.where(radius_90.notna(), (radius_90 < 50).astype("Int64"), pd.NA)
    
    if _safe_add_feature(df, "derived_is_local_carrier", _compute_local_carrier_flag):
        features_created += 1
    else:
        features_failed += 1
    
    # Log summary of feature creation
    total_expected = 32  # We expect 32 derived features
    if features_failed > 0:
        logger.warning(f"Created {features_created}/{total_expected} derived features ({features_failed} failed)")
    else:
        logger.debug(f"Successfully created all {features_created} derived features")

    # ============================================================
    # 2. BUILD MAPPING: derived_feature -> raw columns used
    #    Only for ratio-like features where it's reasonable
    #    to consider dropping raw columns.
    # ============================================================

    derived_map = {
        "derived_accidents_per_power_unit": ["total_accidents", "power_units"],
        "derived_accidents_per_truck_unit": ["total_accidents", "truck_units"],
        "derived_accidents_per_driver": ["total_accidents", "drivers"],
        "derived_accidents_per_million_miles": ["total_accidents", "mcs_mileage"],
        "derived_accidents_last_year_per_million_miles": [
            "accidents_last_year",
            "mcs_mileage",
        ],
        "derived_driver_oos_rate": ["driver_oos_insp_total", "driver_insp_total"],
        "derived_vehicle_oos_rate": ["vehicle_oos_insp_total", "vehicle_insp_total"],
        "derived_insp_per_power_unit": ["total_inspections", "power_units"],
        "derived_oos_events_per_inspection": [
            "driver_oos_insp_total",
            "vehicle_oos_insp_total",
            "total_inspections",
        ],
        "derived_inspection_to_accident_ratio": ["insp_total", "total_accidents"],
        "derived_sleeper_to_daycab_ratio": ["sleeper_cabs", "day_cabs"],
        "derived_pct_sleeper_units": ["sleeper_cabs", "power_units"],
        "derived_driver_growth_rate_24m": ["drivers_added_24m", "drivers"],
        "derived_drivers_per_power_unit": ["drivers", "power_units"],
        "derived_intrastate_driver_ratio": ["intrastate_drivers", "drivers"],
        "derived_miles_per_power_unit": ["mcs_mileage", "power_units"],
        "derived_operational_density_ratio": [
            "distinct_states_served",
            "radius_95pct_miles",
        ],
        "derived_unsafe_driving_violation_rate": [
            "unsafe_driv_insp_w_viol",
            "driver_insp_total",
        ],
        "derived_hos_violation_rate": ["hos_driv_insp_w_viol", "driver_insp_total"],
        "derived_vehicle_maintenance_violation_rate": [
            "veh_maint_insp_w_viol",
            "vehicle_insp_total",
        ],
        "derived_contr_subst_violation_rate": [
            "contr_subst_insp_w_viol",
            "driver_insp_total",
        ],
        "derived_recent_driver_oos_ratio": [
            "ia_driver_oos_last_90_days",
            "ia_driver_oos_total",
        ],
        "derived_recent_vehicle_oos_ratio": [
            "ia_vehicle_oos_last_90_days",
            "ia_vehicle_oos_total",
        ],
        # Note: we intentionally DO NOT map flags / thresholds here
        # (e.g., derived_longhaul_flag, derived_is_local_carrier, etc.)
        # to avoid auto-dropping more informative raw columns.
    }

    # ============================================================
    # 3. FILL RATES & "SAFE TO DROP" DECISION
    # ============================================================

    fill = df.notna().mean()
    safe_to_drop: List[str] = []

    for dcol, raw_cols in derived_map.items():
        # Only consider if the derived column exists
        if dcol not in df.columns:
            continue

        # All raw columns must be present
        present_raw = [c for c in raw_cols if c in df.columns]
        if len(present_raw) != len(raw_cols):
            continue

        derived_fill = float(fill.get(dcol, np.nan))
        raw_fill = fill[present_raw]

        if raw_fill.empty:
            continue

        min_raw_fill = float(raw_fill.min())

        # If derived is almost as complete as the weakest raw input,
        # we treat the raw inputs as redundant for modeling.
        if (
            not np.isnan(derived_fill)
            and not np.isnan(min_raw_fill)
            and derived_fill >= drop_threshold * min_raw_fill
        ):
            safe_to_drop.extend(present_raw)

    safe_to_drop = sorted(set(safe_to_drop))

    # Actually drop them (ignore if some don't exist) only if drop_redundant is True
    if drop_redundant:
        df.drop(columns=safe_to_drop, inplace=True, errors="ignore")
    else:
        # If not dropping, return empty list
        safe_to_drop = []

    return df, safe_to_drop
