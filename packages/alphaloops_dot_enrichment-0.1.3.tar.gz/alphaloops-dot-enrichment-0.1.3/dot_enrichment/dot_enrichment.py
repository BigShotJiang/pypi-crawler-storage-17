#!/usr/bin/env python3
"""
DOT Number Enrichment Module

Reusable functions for enriching DataFrames with DOT numbers using:
1. ai_training SQLite database (company data)
2. CSA safety scores from Supabase
3. API fallback for missing DOTs

Usage:
    from dot_enrichment import enrich_dot_dataframe
    
    df = pd.DataFrame({'dot_number': ['123456', '789012']})
    enriched_df = enrich_dot_dataframe(df, min_enrichment_rate=0.80)
"""

import pandas as pd
import sqlite3
import logging
from typing import Optional, List
from .data_utils import normalize_dot_series, fetch_missing_dots_from_api, enrich_merge
from .aitraining_helpers import get_latest_ai_training_sqlite
from .supabase_helpers import fetch_csa_scores_by_dots
from .derived_features import add_derived_and_prune

logger = logging.getLogger(__name__)

# Fields that should be nullified if value is 0 (0 means "no data" not "actually zero")
ZERO_TO_NULL_FIELDS = [
    'accidents_l',
    'annual_revenue',
    'avg_truck_age_years',
    'bipd_effective_primary_maximum',
    'bipd_excess_maximum',
    'bipd_excess_underlying',
    'bipd_full_security_b1_maximum',
    'bipd_full_security_b2_maximum',
    'bipd_nocl',
    'bipd_primary_maximum',
    'bipd_required_amount',
    'bipd_total_coverage',
    'broker_authority_age',
    'bus_units',
    'common_authority_age',
    'contract_authority_age',
    'day_cabs',
    'distinct_states_served',
    'drivers',
    'drivers_added_24m',
    'engines_caterpillar',
    'engines_cummins',
    'engines_detroit',
    'engines_international',
    'engines_mack',
    'engines_other',
    'engines_paccar',
    'engines_volvo',
    'estimated_employees',
    'founded_year',
    'ia_driver_oos_l',
    'ia_driver_oos_total',
    'ia_driver_viol_total',
    'ia_drug_arrests_l',
    'ia_drug_arrests_total',
    'ia_hazmat_violations_l',
    'ia_hazmat_violations_total',
    'ia_inspections_l',
    'ia_inspections_total',
    'ia_size_weight_enf_l',
    'ia_size_weight_enf_total',
    'ia_traffic_enf_l',
    'ia_traffic_enf_total',
    'ia_vehicle_oos_l',
    'ia_vehicle_oos_total',
    'ia_vehicle_viol_total',
    'intr',
    'max_bipd_amount',
    'max_distance_miles',
    'max_excess_bipd_amount',
    'max_excess_bipd_underlying',
    'max_primary_bipd_amount',
    'max_primary_bipd_underlying',
    'mcs_mileage',
    'mcs_year',
    'min_bipd_amount',
    'min_excess_bipd_amount',
    'min_excess_bipd_underlying',
    'min_primary_bipd_amount',
    'min_primary_bipd_underlying',
    'owned_trail',
    'owned_trucks',
    'power_units',
    'radius_90pct_miles',
    'radius_95pct_miles',
    'radius_from_hq_90pct_miles',
    'recent_mileage',
    'row_number',
    'sleeper_cabs',
    'total_accidents',
    'total_accidents_fatalities',
    'total_accidents_hazmat',
    'total_accidents_injuries',
    'total_accidents_tow_away',
    'total_funding',
    'total_inspections',
    'total_trailers',
    'trailer_dropdeck',
    'trailer_dryvan',
    'trailer_dump',
    'trailer_flatbed',
    'trailer_flatbed_tag',
    'trailer_hopper',
    'trailer_lowboy',
    'trailer_other',
    'trailer_reefer',
    'trailer_tank',
    'truck_units',
    'trucks_added_24m'
]


def _nullify_zero_values(df: pd.DataFrame) -> pd.DataFrame:
    """
    Set specified fields to null if their value is 0.
    
    For these fields, 0 typically means "no data" rather than "actually zero",
    so we nullify them to avoid confusion.
    
    Args:
        df: DataFrame to process
        
    Returns:
        DataFrame with zero values nullified for specified fields
    """
    df = df.copy()
    
    for field in ZERO_TO_NULL_FIELDS:
        if field in df.columns:
            # Replace 0 and 0.0 with NaN (null) for this column
            mask = (df[field] == 0) | (df[field] == 0.0)
            df.loc[mask, field] = pd.NA
    
    return df


def enrich_with_ai_training(
    df: pd.DataFrame,
    dot_column: str = 'dot_number',
    min_enrichment_rate: float = 0.80,
    use_api_fallback: bool = True
) -> pd.DataFrame:
    """
    Enrich DataFrame with ai_training data from SQLite database.
    
    Args:
        df: DataFrame with DOT numbers to enrich
        dot_column: Name of the DOT number column (default: 'dot_number')
        min_enrichment_rate: Minimum enrichment rate required (0.0-1.0, default: 0.80)
        use_api_fallback: If True, fetch missing DOTs from API (default: True)
        
    Returns:
        Enriched DataFrame with ai_training columns added
        
    Raises:
        ValueError: If dot_column is missing or database schema is invalid
        RuntimeError: If enrichment fails or enrichment rate is too low
    """
    if dot_column not in df.columns:
        raise ValueError(f"DOT column '{dot_column}' not found in DataFrame")
    
    if not (0.0 <= min_enrichment_rate <= 1.0):
        raise ValueError(f"min_enrichment_rate must be between 0.0 and 1.0, got {min_enrichment_rate}")
    
    df = df.copy()
    df[dot_column] = normalize_dot_series(df[dot_column])
    
    # Get unique DOTs
    input_dots = df[dot_column].dropna().astype(str).unique().tolist()
    if not input_dots:
        raise ValueError("No valid DOT numbers found in DataFrame")
    
    logger.info(f"Enriching {len(input_dots)} unique DOTs with ai_training data")
    
    try:
        # Load ai_training SQLite database
        db_path = get_latest_ai_training_sqlite()
        if not db_path:
            raise RuntimeError("Could not locate ai_training SQLite database")
        
        logger.debug(f"Using database: {db_path}")
        
        conn = sqlite3.connect(db_path)
        
        # Query matching records
        placeholders = ','.join(['?' for _ in input_dots])
        query = f"SELECT * FROM ai_training WHERE __dot_key IN ({placeholders})"
        ai_df = pd.read_sql_query(query, conn, params=input_dots)
        conn.close()
        
        logger.info(f"Found {len(ai_df)} matching ai_training records")
        
        # Prepare for join
        if '__dot_key' not in ai_df.columns:
            raise ValueError("SQLite database missing __dot_key column")
        
        if len(ai_df) == 0:
            raise RuntimeError(f"No matching records found in ai_training database for {len(input_dots)} DOTs")
        
        # Create dot_number column in ai_df for join
        ai_df_clean = ai_df.drop_duplicates(subset=['__dot_key'], keep='first').copy()
        ai_df_clean[dot_column] = ai_df_clean['__dot_key']
        
        # Drop __dot_key to avoid conflicts
        ai_df_clean = ai_df_clean.drop(columns=['__dot_key'])
        
        # Use enrich_merge to merge while filling nulls (no _x/_y suffixes)
        df = enrich_merge(df, ai_df_clean, on=dot_column, how='left')
        
        # Nullify zero values for fields where 0 means "no data" not "actually zero"
        df = _nullify_zero_values(df)
        
        # Check enrichment rate
        sample_col = [c for c in ai_df.columns if c not in ['__dot_key', dot_column]][0]
        if sample_col not in df.columns:
            raise RuntimeError(f"Expected column '{sample_col}' not found after merge")
        
        unmatched_mask = df[sample_col].isna()
        unmatched_dots = df.loc[unmatched_mask, dot_column].dropna().unique().tolist()
        
        # Try API fallback for unmatched DOTs
        if unmatched_dots and use_api_fallback:
            logger.info(f"Found {len(unmatched_dots)} unmatched DOTs, attempting API fallback")
            
            try:
                api_df = fetch_missing_dots_from_api(unmatched_dots)
                
                if len(api_df) > 0:
                    # Prepare API data for merge (drop __dot_key and dot_number to avoid conflicts)
                    api_cols_to_merge = [c for c in api_df.columns if c not in ['__dot_key', dot_column]]
                    api_merge_df = api_df[['__dot_key'] + api_cols_to_merge].copy()
                    api_merge_df = api_merge_df.drop_duplicates(subset=['__dot_key'], keep='first')
                    
                    # Merge API data for unmatched rows
                    df = df.merge(
                        api_merge_df,
                        how='left',
                        left_on=dot_column,
                        right_on='__dot_key',
                        suffixes=('', '_api')
                    )
                    if '__dot_key' in df.columns:
                        df = df.drop(columns=['__dot_key'])
                    
                    # Check how many got enriched from API
                    api_enriched = df.loc[unmatched_mask, sample_col].notna().sum() if sample_col in df.columns else 0
                    logger.info(f"API enrichment: {api_enriched}/{len(unmatched_dots)} unmatched DOTs enriched")
            except Exception as api_err:
                logger.warning(f"API fallback failed: {api_err}")
                # Continue without API data
        
        # Final enrichment check
        total_dots = df[dot_column].notna().sum()
        final_unmatched = df[sample_col].isna().sum()
        enrichment_rate = (total_dots - final_unmatched) / total_dots if total_dots > 0 else 0
        
        logger.info(f"Final enrichment rate: {enrichment_rate*100:.1f}% ({total_dots - final_unmatched}/{total_dots} DOTs enriched)")
        
        if enrichment_rate < min_enrichment_rate:
            raise RuntimeError(
                f"Enrichment rate {enrichment_rate*100:.1f}% below minimum required {min_enrichment_rate*100:.1f}%. "
                f"Only {total_dots - final_unmatched}/{total_dots} DOTs enriched. {final_unmatched} DOTs could not be enriched."
            )
        
        logger.info(f"Enrichment completed: {len(df)} rows, {len(df.columns)} columns")
        return df
        
    except (ValueError, RuntimeError):
        raise
    except Exception as e:
        raise RuntimeError(f"ai_training enrichment failed: {e}") from e


def enrich_with_csa_scores(
    df: pd.DataFrame,
    dot_column: str = 'dot_number',
    min_success_rate: float = 0.75
) -> pd.DataFrame:
    """
    Enrich DataFrame with CSA safety scores.
    
    Args:
        df: DataFrame with DOT numbers to enrich
        dot_column: Name of the DOT number column (default: 'dot_number')
        min_success_rate: Minimum join success rate required (0.0-1.0, default: 0.75)
        
    Returns:
        Enriched DataFrame with CSA score columns added
        
    Raises:
        ValueError: If dot_column is missing
        RuntimeError: If CSA join success rate is too low
    """
    if dot_column not in df.columns:
        raise ValueError(f"DOT column '{dot_column}' not found in DataFrame")
    
    if not (0.0 <= min_success_rate <= 1.0):
        raise ValueError(f"min_success_rate must be between 0.0 and 1.0, got {min_success_rate}")
    
    df = df.copy()
    
    # Get unique DOTs
    input_dots = df[dot_column].dropna().astype(str).unique().tolist()
    if not input_dots:
        logger.warning("No valid DOT numbers found for CSA enrichment")
        return df
    
    logger.info(f"Enriching {len(input_dots)} unique DOTs with CSA safety scores")
    
    try:
        csa_df = fetch_csa_scores_by_dots(input_dots)
        
        if len(csa_df) == 0:
            logger.warning("No CSA scores found")
            return df
        
        logger.info(f"Retrieved {len(csa_df)} CSA records")
        
        # Detect CSA DOT column
        csa_dot_col = 'dot_number' if 'dot_number' in csa_df.columns else None
        if not csa_dot_col:
            dot_cols = [c for c in csa_df.columns if 'dot' in c.lower()]
            csa_dot_col = dot_cols[0] if dot_cols else None
        
        if not csa_dot_col:
            raise RuntimeError("No DOT column found in CSA data")
        
        logger.debug(f"Using CSA DOT column: {csa_dot_col}")
        
        # Normalize both sides for join
        csa_df['__featrix_csa_dot_key'] = normalize_dot_series(csa_df[csa_dot_col])
        df[dot_column] = normalize_dot_series(df[dot_column])
        
        csa_df = csa_df.drop_duplicates(subset=['__featrix_csa_dot_key'], keep='first')
        
        # Prepare CSA data for merge
        csa_merge_df = csa_df.drop(columns=[csa_dot_col], errors='ignore')
        
        # Use enrich_merge to merge while filling nulls (no _x/_y suffixes)
        before_cols = len(df.columns)
        df = enrich_merge(df, csa_merge_df, left_on=dot_column, right_on='__featrix_csa_dot_key', how='left')
        df = df.drop(columns=['__featrix_csa_dot_key'], errors='ignore')
        
        logger.info(f"Added {len(df.columns) - before_cols} CSA columns")
        
        # Check join success rate
        csa_enriched = df['insp_total'].notna().sum() if 'insp_total' in df.columns else 0
        success_rate = csa_enriched / len(df) if len(df) > 0 else 0
        
        logger.info(f"CSA join success: {csa_enriched}/{len(df)} rows ({success_rate*100:.1f}%)")
        
        if success_rate < min_success_rate:
            raise RuntimeError(
                f"CSA join success rate {success_rate*100:.1f}% below minimum required {min_success_rate*100:.1f}%. "
                f"Only {csa_enriched}/{len(df)} rows enriched."
            )
        
        return df
        
    except (ValueError, RuntimeError):
        raise
    except Exception as e:
        raise RuntimeError(f"CSA enrichment failed: {e}") from e


def enrich_dot_dataframe(
    df: pd.DataFrame,
    dot_column: str = 'dot_number',
    enrich_ai_training: bool = True,
    enrich_csa: bool = True,
    min_ai_enrichment_rate: float = 0.80,
    min_csa_success_rate: float = 0.75,
    use_api_fallback: bool = True,
    add_derived_features: bool = True,
    drop_threshold: float = 0.98,
    drop_redundant: bool = True
) -> pd.DataFrame:
    """
    Complete DOT enrichment: ai_training + CSA scores + derived features.
    
    This is the main function to use for enriching a DataFrame with DOT numbers.
    It combines both ai_training and CSA enrichment in the correct order,
    then adds derived features (ratios, combinations) and optionally prunes
    redundant raw columns.
    
    Args:
        df: DataFrame with DOT numbers to enrich
        dot_column: Name of the DOT number column (default: 'dot_number')
        enrich_ai_training: Whether to enrich with ai_training data (default: True)
        enrich_csa: Whether to enrich with CSA scores (default: True)
        min_ai_enrichment_rate: Minimum ai_training enrichment rate (default: 0.80)
        min_csa_success_rate: Minimum CSA join success rate (default: 0.75)
        use_api_fallback: Fetch missing DOTs from API (default: True)
        add_derived_features: Whether to add derived features and prune (default: True)
        drop_threshold: Threshold for dropping redundant columns (default: 0.98)
        drop_redundant: Whether to drop redundant raw columns (default: True).
            Set to False when training downstream models to keep all features.
        
    Returns:
        Enriched DataFrame with all enrichment columns and derived features added
        
    Raises:
        ValueError: If dot_column is missing or parameters are invalid
        RuntimeError: If enrichment fails or rates are too low
        
    Example:
        >>> import pandas as pd
        >>> from dot_enrichment import enrich_dot_dataframe
        >>> 
        >>> df = pd.DataFrame({'dot_number': ['123456', '789012']})
        >>> enriched_df = enrich_dot_dataframe(df)
    """
    if dot_column not in df.columns:
        raise ValueError(f"DOT column '{dot_column}' not found in DataFrame")
    
    df = df.copy()
    
    # Step 1: Enrich with ai_training
    if enrich_ai_training:
        df = enrich_with_ai_training(
            df,
            dot_column=dot_column,
            min_enrichment_rate=min_ai_enrichment_rate,
            use_api_fallback=use_api_fallback
        )
    
    # Step 2: Enrich with CSA scores
    if enrich_csa:
        df = enrich_with_csa_scores(
            df,
            dot_column=dot_column,
            min_success_rate=min_csa_success_rate
        )
    
    # Step 3: Add derived features and optionally prune redundant columns
    if add_derived_features:
        if drop_redundant:
            logger.info("Adding derived features and pruning redundant columns...")
        else:
            logger.info("Adding derived features (keeping all columns)...")
        
        df, dropped_cols = add_derived_and_prune(
            df, 
            drop_threshold=drop_threshold, 
            inplace=False,
            drop_redundant=drop_redundant
        )
        
        # Count derived features that were added
        derived_cols = [col for col in df.columns if col.startswith('derived_')]
        
        if dropped_cols:
            logger.info(f"Added {len(derived_cols)} derived features and dropped {len(dropped_cols)} redundant columns: {dropped_cols[:5]}{'...' if len(dropped_cols) > 5 else ''}")
        else:
            logger.info(f"Added {len(derived_cols)} derived features (no columns dropped)")
        
        if len(derived_cols) == 0:
            logger.warning("WARNING: No derived features were added! This may indicate an issue with the input data.")
    
    logger.info(f"Final enriched data: {len(df)} rows, {len(df.columns)} columns")
    return df

