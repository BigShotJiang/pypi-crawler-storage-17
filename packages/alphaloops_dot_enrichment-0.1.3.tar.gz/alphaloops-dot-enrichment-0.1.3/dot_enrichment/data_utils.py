#!/usr/bin/env python3
"""
Shared data utilities for DOT number handling.

Centralized DOT helpers to ensure consistent behavior across the codebase.
"""

import re
from typing import Any, Optional, List
import pandas as pd
import requests
import logging

logger = logging.getLogger(__name__)


def normalize_dot_cell(value: Any) -> Optional[str]:
    """Normalize a DOT number safely.

    Rules:
    - Allow digits with optional commas and whitespace
    - Allow a trailing ".0" (or ".00..") and drop the decimal part
    - Reject any other decimal (e.g., 123.4)
    - Reject alphanumerics; do NOT blindly strip all non-digits
    """
    try:
        if value is None or (isinstance(value, float) and pd.isna(value)):
            return None
        s = str(value).strip()
        if not s or s.lower() == 'nan':
            return None
        s = s.replace(',', '')
        if re.fullmatch(r"\d+", s):
            return s.lstrip('0') or '0'
        m = re.fullmatch(r"(\d+)\.0+", s)
        if m:
            return m.group(1).lstrip('0') or '0'
        return None
    except Exception:
        return None


def normalize_dot_series(series: pd.Series) -> pd.Series:
    """Apply normalize_dot_cell to a pandas Series."""
    return series.apply(normalize_dot_cell)


def detect_dot_column(df: pd.DataFrame) -> str:
    """Detect a DOT column name in df.

    Tolerant to variants like 'DOT Number', 'DOT number', 'dotnumber', 'DOT', 'USDOT', 'dot_normalized'.
    Returns the column name if found, else empty string.
    """
    for col in df.columns:
        norm = re.sub(r"[^a-z0-9]", "", str(col).lower())
        if norm in {"dotnumber", "dot", "usdot", "usdotnumber", "dotnormalized"}:
            return col
    # Also check for __featrix_meta_dot_number
    if "__featrix_meta_dot_number" in df.columns:
        return "__featrix_meta_dot_number"
    return ""


def fetch_dot_enrichment(dot_number: str) -> Optional[dict]:
    """Fetch enrichment data for a single DOT number from the freight API.
    
    Args:
        dot_number: DOT number (will be normalized automatically)
        
    Returns:
        dict: Enrichment data for the DOT number, or None if not found/failed
        
    Example:
        >>> from dot_enrichment.data_utils import fetch_dot_enrichment
        >>> data = fetch_dot_enrichment("123456")
        >>> if data:
        ...     print(data.get('company_name'))
    """
    api_url = "https://freight-api.runalphaloops.com/functions/v1/ai-dot-number"
    
    # Normalize the DOT number
    normalized_dot = normalize_dot_cell(dot_number)
    if not normalized_dot:
        logger.warning(f"Invalid DOT number format: {dot_number}")
        return None
    
    try:
        payload = {"dot_number": normalized_dot}
        resp = requests.post(
            api_url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=30
        )
        resp.raise_for_status()
        api_response = resp.json()
        
        if api_response.get('success') and api_response.get('data'):
            record = api_response['data'][0]
            # Ensure dot_number is set correctly
            record['dot_number'] = normalized_dot
            # Normalize to __dot_key format for consistency
            record['__dot_key'] = normalized_dot
            logger.info(f"Successfully fetched enrichment data for DOT {normalized_dot}")
            return record
        else:
            logger.warning(f"API returned no data for DOT {normalized_dot}")
            return None
    except Exception as e:
        logger.warning(f"Failed to fetch DOT {normalized_dot} from API: {e}")
        return None


def fetch_missing_dots_from_api(dot_numbers: List[str]) -> pd.DataFrame:
    """Fetch company data for DOT numbers that weren't found in local SQLite database.
    
    Args:
        dot_numbers: List of DOT numbers (normalized) to fetch from API
        
    Returns:
        DataFrame with company data for successfully fetched DOTs, empty DataFrame if none found
    """
    if not dot_numbers:
        return pd.DataFrame()
    
    api_url = "https://freight-api.runalphaloops.com/functions/v1/ai-dot-number"
    fetched_records = []
    
    logger.info(f"Fetching {len(dot_numbers)} missing DOTs from API")
    
    for i, dot in enumerate(dot_numbers, 1):
        try:
            payload = {"dot_number": dot}
            resp = requests.post(api_url, json=payload, headers={"Content-Type": "application/json"}, timeout=30)
            resp.raise_for_status()
            api_response = resp.json()
            
            if api_response.get('success') and api_response.get('data'):
                record = api_response['data'][0]
                # Ensure dot_number is set correctly
                record['dot_number'] = dot
                # Normalize to __dot_key format for consistency
                record['__dot_key'] = normalize_dot_cell(dot)
                fetched_records.append(record)
                if i % 10 == 0 or i == len(dot_numbers):
                    logger.debug(f"Fetched {i}/{len(dot_numbers)} DOTs from API")
            else:
                logger.warning(f"API returned no data for DOT {dot}")
        except Exception as e:
            logger.warning(f"Failed to fetch DOT {dot} from API: {e}")
            continue
    
    if fetched_records:
        api_df = pd.DataFrame(fetched_records)
        logger.info(f"Successfully fetched {len(api_df)} DOTs from API")
        return api_df
    else:
        logger.warning("No DOTs could be fetched from API")
        return pd.DataFrame()


def enrich_merge(
    df: pd.DataFrame,
    enrichment_df: pd.DataFrame,
    on: Optional[str] = None,
    left_on: Optional[str] = None,
    right_on: Optional[str] = None,
    how: str = 'left',
    inplace: bool = False
) -> pd.DataFrame:
    """
    Merge two DataFrames while enriching (filling nulls) rather than duplicating columns.
    
    This function prevents the creation of _x/_y suffix columns that pandas normally creates
    when merging DataFrames with duplicate column names. Instead, it:
    1. Identifies columns that exist in both DataFrames
    2. Fills null values in the original columns with values from the enrichment DataFrame
    3. Keeps only one copy of each column (no duplicates, no suffixes)
    
    This is ideal for enrichment workflows where you want to improve data quality by
    filling in missing values without creating column pollution.
    
    Args:
        df: Base DataFrame to enrich
        enrichment_df: DataFrame containing enrichment data
        on: Column name to join on (if same in both DataFrames)
        left_on: Column name in df to join on
        right_on: Column name in enrichment_df to join on
        how: Type of merge ('left', 'right', 'inner', 'outer'). Default: 'left'
        inplace: If True, modify df in place. If False, return a copy. Default: False
        
    Returns:
        Enriched DataFrame with duplicate columns merged (nulls filled from enrichment)
        
    Raises:
        ValueError: If neither 'on' nor both 'left_on'/'right_on' are provided
        
    Example:
        >>> import pandas as pd
        >>> from dot_enrichment.data_utils import enrich_merge
        >>> 
        >>> # Original data with some nulls
        >>> df = pd.DataFrame({
        ...     'id': [1, 2, 3],
        ...     'name': ['Alice', None, 'Charlie'],
        ...     'age': [25, 30, None]
        ... })
        >>> 
        >>> # Enrichment data with better values
        >>> enrichment = pd.DataFrame({
        ...     'id': [2, 3, 4],
        ...     'name': ['Bob', 'Charlie', 'David'],
        ...     'age': [30, 35, 40],
        ...     'city': ['NYC', 'LA', 'SF']
        ... })
        >>> 
        >>> # Enrich: fills nulls in 'name' and 'age', adds 'city' column
        >>> result = enrich_merge(df, enrichment, on='id')
        >>> # Result has: name=['Alice', 'Bob', 'Charlie'], age=[25, 30, 35], city=[None, 'NYC', 'LA']
    """
    # Validate join parameters
    if on is None and (left_on is None or right_on is None):
        raise ValueError("Must provide either 'on' or both 'left_on' and 'right_on'")
    
    if not inplace:
        df = df.copy()
        enrichment_df = enrichment_df.copy()
    
    # Determine join keys
    left_key = on if on is not None else left_on
    right_key = on if on is not None else right_on
    
    # Identify duplicate columns (excluding join keys)
    existing_cols = set(df.columns)
    enrichment_cols = set(enrichment_df.columns)
    
    if on is not None:
        duplicate_cols = [c for c in enrichment_cols if c in existing_cols and c != on]
    else:
        duplicate_cols = [c for c in enrichment_cols if c in existing_cols and c not in (left_key, right_key)]
    
    # Temporarily rename duplicate columns in enrichment_df to avoid pandas suffix creation
    if duplicate_cols:
        logger.debug(f"Enriching {len(duplicate_cols)} existing columns: {duplicate_cols[:5]}{'...' if len(duplicate_cols) > 5 else ''}")
        rename_map = {col: f'__enrich_temp_{col}' for col in duplicate_cols}
        enrichment_df = enrichment_df.rename(columns=rename_map)
    
    # Perform merge (no suffixes needed since we renamed duplicates)
    if on is not None:
        df = df.merge(enrichment_df, on=on, how=how)
    else:
        df = df.merge(enrichment_df, left_on=left_key, right_on=right_key, how=how)
        # Drop the right join key if it's different from left
        if right_key != left_key and right_key in df.columns:
            df = df.drop(columns=[right_key])
    
    # Enrich existing columns: fill nulls with values from enrichment
    if duplicate_cols:
        for col in duplicate_cols:
            temp_col = f'__enrich_temp_{col}'
            if temp_col in df.columns:
                # Fill nulls in original column with enrichment values
                df[col] = df[col].fillna(df[temp_col])
                # Drop temporary column
                df = df.drop(columns=[temp_col])
    
    return df

