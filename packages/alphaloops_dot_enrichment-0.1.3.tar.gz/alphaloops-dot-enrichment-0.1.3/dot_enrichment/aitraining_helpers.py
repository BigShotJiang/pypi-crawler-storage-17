#!/usr/bin/env python3
"""
Helper functions for locating AI training database files.
"""

import sqlite3
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

# Default AI training directory
AI_TRAINING_DIR = "/data/stuff/ai-training/"


def get_latest_ai_training_sqlite(training_dir: str = None, min_rows: int = 25000):
    """
    Find the newest SQLite database file in the AI training directory with ai_training table.
    
    Iterates through database files by modification time (newest first) until finding one
    with a valid ai_training table containing sufficient data.
    
    Args:
        training_dir: Path to AI training directory (default: /data/stuff/ai-training/)
        min_rows: Minimum number of rows required in ai_training table (default: 25000)
    
    Returns:
        str: Path to the latest valid AI training SQLite database
        
    Raises:
        FileNotFoundError: If directory doesn't exist or no SQLite files found
        ValueError: If no database with valid ai_training table found
    """
    if training_dir is None:
        training_dir = AI_TRAINING_DIR
    
    training_path = Path(training_dir)
    
    if not training_path.exists():
        raise FileNotFoundError(f"AI training directory does not exist: {training_dir}")
    
    # Find all SQLite files
    db_files = list(training_path.glob("*.db")) + list(training_path.glob("*.sqlite"))
    
    if not db_files:
        raise FileNotFoundError(f"No SQLite files found in {training_dir}")
    
    # Sort by modification time (newest first)
    db_files_sorted = sorted(db_files, key=lambda f: f.stat().st_mtime, reverse=True)
    
    logger.info(f"Found {len(db_files_sorted)} SQLite file(s) in {training_dir}")
    
    # Try each database file until we find one with ai_training table
    for idx, db_file in enumerate(db_files_sorted, 1):
        logger.debug(f"Checking database {idx}/{len(db_files_sorted)}: {db_file.name}")
        
        try:
            conn = sqlite3.connect(str(db_file))
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM ai_training")
            row_count = cursor.fetchone()[0]
            conn.close()
            
            logger.debug(f"Database contains {row_count:,} rows in ai_training table")
            
            if row_count < min_rows:
                logger.warning(f"Database has only {row_count:,} rows (expected >{min_rows:,}), trying next...")
                continue
            
            logger.info(f"Database validation passed: {db_file.name} ({row_count:,} rows)")
            return str(db_file)
            
        except sqlite3.Error as e:
            logger.warning(f"Database check failed for {db_file.name}: {e}, trying next...")
            continue
    
    # No valid database found
    raise ValueError(f"No SQLite database with valid ai_training table (min {min_rows:,} rows) found in {training_dir}")

