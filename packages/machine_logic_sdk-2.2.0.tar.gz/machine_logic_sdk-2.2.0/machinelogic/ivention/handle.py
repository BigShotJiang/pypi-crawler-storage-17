"""
Module containg a callback handle.
"""


class Handle:
    """
    Represents a handle to a callback
    """

    def __init__(self, handle: int):
        self._handle = handle
