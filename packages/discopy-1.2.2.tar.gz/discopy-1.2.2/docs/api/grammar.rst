grammar
=======

.. automodule:: discopy.grammar

.. autosummary::
    :template: module.rst
    :toctree: ../_api

    discopy.grammar.thue
    discopy.grammar.cfg
    discopy.grammar.categorial
    discopy.grammar.pregroup
    discopy.grammar.dependency
