drawing
=======

.. automodule:: discopy.drawing

.. autosummary::
    :template: module.rst
    :toctree: ../_api

    discopy.drawing.drawing
    discopy.drawing.backend
