semantics
=========

DisCoPy's computational core: categories of functions, matrices and tensors.

.. autosummary::
    :template: module.rst
    :toctree: ../_api

    discopy.python
    discopy.matrix
    discopy.tensor
    discopy.stream
    discopy.interaction
