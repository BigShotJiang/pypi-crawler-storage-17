quantum
=======

.. automodule:: discopy.quantum

.. autosummary::
    :template: module.rst
    :toctree: ../_api

    discopy.quantum.channel
    discopy.quantum.circuit
    discopy.quantum.gates
    discopy.quantum.ansatze
    discopy.quantum.zx
    discopy.quantum.tk
    discopy.quantum.pennylane
