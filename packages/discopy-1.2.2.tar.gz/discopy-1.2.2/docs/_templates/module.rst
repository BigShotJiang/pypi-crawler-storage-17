{{ objname | escape | underline}}

.. automodule:: {{ fullname }}
