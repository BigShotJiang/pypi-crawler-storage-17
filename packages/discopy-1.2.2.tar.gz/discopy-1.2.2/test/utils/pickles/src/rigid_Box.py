from discopy.rigid import *

pick = Box('f', Ty('x', 'x'), Ty('y'))