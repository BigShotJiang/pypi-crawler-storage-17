# 0.6
# from discopy.matrix import Matrix, PRO
#
#
# pick = Matrix(PRO(2), PRO(3), [1, 2, 3, 4, 5, 6])

# 1.2
from discopy.matrix import Matrix


pick = Matrix([1, 2, 3, 4, 5, 6], 2, 3)
