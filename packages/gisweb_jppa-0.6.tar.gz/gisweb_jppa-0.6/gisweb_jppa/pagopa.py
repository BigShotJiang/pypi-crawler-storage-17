from datetime import datetime, timedelta
import json
import uuid
import httpx
import jwt
from typing import Any, Optional
from gisweb_pagopa_schema.schemas import ISettingsPagoPa, IChiaveDebito, PagamentoCreate, PagamentoUpdate, IDebito, IEsito, ISoggetto
from pydantic import BaseModel, Field, model_validator

class LoginResponse(BaseModel):
    descrizione_errore: str | None = Field(None, alias="descrizioneErrore")
    esito: str | None = None
    token: str | None = None
    
class PagopaCredentials(BaseModel):
    pagopa_user: str | None = None
    pagopa_password: str | None = None
    pagopa_print_password: str | None = None
    
class DatoAccertamento(BaseModel):
    codiceAccertamento:str
    descrizioneAccertamento:str
    importoAccertamento:str
    annoAccertamento:str
    
class DettaglioDovuto(BaseModel):
    idDeb:str
    idPos:str
    causaleDebito:str
    codiceIpaCreditore:str
    codiceTipoDebito:str
    datiAccertamento: list[DatoAccertamento] = Field(default_factory=list)
    gruppo:int=1
    importoDebito:float | None = None
    ordinamento:int=1
    dataInizioValidita:str | None = None  #=DateToString(Now(), format="%Y-%m-%dT%H:%M:%S.000Z")
    dataFineValidita:str | None = None
    dataLimitePagabilita:str | None = None
    
class DatiContribuente(BaseModel):
    codiceIdentificativoUnivoco: str
    tipoIdentificativoUnivoco: str
    cap: str | None = None
    civico: str | None = None
    cognome: str | None = None
    email: str | None = None
    indirizzo: str | None = None
    localita: str | None = None
    nazione: str | None = None
    nome: str | None = None
    provincia: str | None = None
    ragioneSociale: str | None
    
    
    
    
    
class PagoPaClient:
    
    _config: ISettingsPagoPa
    _token: str
    _credential: PagopaCredentials

    def __init__(self, config: ISettingsPagoPa):
        self._config = config
        self._token = ""
        self._client = httpx.AsyncClient()
        
    def setCredential(self, creds):
        self._credential = creds
        
    async def _login(self):
        config = self._config
        req = dict(
            idMessaggio=str(uuid.uuid4()),
            identificativoEnte=config.codiceIpa,
            username=self._credential.pagopa_user,
            password=self._credential.pagopa_password,
        )
        
        data = await self._post(
            "/login",
            req,
            auth=False,  # niente token durante il login
        )

        res = LoginResponse.model_validate(data)
        if not res.token:
            raise Exception(f"Login fallita: {res.descrizione_errore}")

        self._token = res.token


    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self._token:
            h["Authorization"] = f"Bearer {self._token}"
        return h
    
    async def _request(self, method, path, json=None, auth=True):
        url = f"{self._config.wsUrl}{path}"

        # Prima chiamata: se auth richiesto e token presente
        import pdb;pdb.set_trace()
        headers = {}
        if auth and self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        
        resp = await self._client.request(method, url, json=json, headers=headers)

        # Se 401 → token scaduto o mancante → login → retry
        if resp.status_code == 401 and auth:
            await self._login()

            headers = {"Authorization": f"Bearer {self._token}"}

            # Retry definitivo
            resp = await self._client.request(method, url, json=json, headers=headers)

            if resp.status_code == 401:
                raise Exception("Autenticazione Maggioli fallita anche dopo il login.")

        resp.raise_for_status()
        return resp.json() if resp.content else None

    
    async def _post(self, path: str, json=None, auth=True):
        return await self._request("POST", path, json=json, auth=auth)

    async def _patch(self, path: str, json=None, auth=True):
        return await self._request("PATCH", path, json=json, auth=auth)

    async def aclose(self):
        await self._client.aclose()
        
 
    async def creaAvvisoPagamento(self, soggetto: ISoggetto, debito: IDebito, testXml:bool=True):
        
        return {"pippo":"ok"}
    
    
    
    
 
 
    async def infoPagamento(self, deb:IChiaveDebito):
        
        config = self._config
        payload=dict(
            chiaveDebitoDto=dict(
                codiceTipoDebito=deb.codice,
                iDeb=deb.iddeb,
                iPos=deb.idpos
            ),
            codIpaRichiedente= config.codiceIpa,
            codiceServizio= config.codiceServizio
        ) 
        
        data = await self._post(path="/pagamenti/v2/infoPerDovuto", json=payload)

        return data
 
  
    async def notificaPagamento(self, data: Any) -> PagamentoUpdate | None:
        """
        Faccio solo il parser della notifica per trasformarla in un oggetto che rispetta l'iterfaccia del pagamento
        
        :param self: Description
        :param payload: Description
        :type payload: dict[str, Any]
        """
        
        if data.get("listaInfoPagamentoTelematicoDto") and len(data.get("listaInfoPagamentoTelematicoDto"))>0:
            res = data.get("listaInfoPagamentoTelematicoDto")[0]
            return PagamentoUpdate(
                iddeb=data.get("chiaveDebitoDto").get("iDeb"),
                idpos=data.get("chiaveDebitoDto").get("iPos"),
                stato=res.get("statoTecnicoPagamento"),
                esito=res.get("esitoRichiestaPagamento"),
                pagato=res.get("importoTotalePagato"),
                data_pagamento=datetime.strptime(str(res.get("dataPagamento")) , '%Y-%m-%d').date(),
            )
        
        
    
 
 
 
    def getDovuto(self, soggetto: ISoggetto, debito: IDebito,):
        

        codiceIpa = config.get("codiceIpa")
        codiceServizio = config.get("codiceServizio")
        codiceTipoDebito = self.getCodiceTipoDebito()

        rows = doc.getItem('elenco_importi_dg', []) + \
            doc.getItem('elenco_importi_aggiuntivi_dg', [])
        list_idx = [codtrans[i:i+2]
                    for i in range(0, len(codtrans), 2) if codtrans[i:i+2] != '00']
        anno = int(DateToString(Now(), format='%Y'))

        for row in rows:
            codimp = row[0]
            if codimp in list_idx:
                causale = row[2][:140]
                # le scadenze dovrebbero essere tutte uguali dato un codtrans
                scadenza = row[5] if row[4]=='data' else row[4] #le scadenze dovrebbero essere tutte uguali dato un codtrans
                importo = round(row[3], 2)
                codice = row[6] if len(row)==8 else ''
                tipoPag = codice or row[1]
                tot_importo = tot_importo + importo
                tot_causale.append(causale)
                if codimp in list_idx and importo > 0:
                    importi.append(dict(codiceAccertamento=tipoPag, descrizioneAccertamento=causale, importoAccertamento=importo, annoAccertamento=anno))
                    if row[-1] and row[-1] not in azioni:
                        azioni.append(row[-1])

        dettaglio = dict(
            causaleDebito=(",".join(tot_causale))[:138],
            codiceIpaCreditore=codiceIpa,
            codiceTipoDebito=codiceTipoDebito,
            datiAccertamento=importi,
            gruppo=1,
            idDeb=str(uuid.uuid4()),
            importoDebito=tot_importo,
            ordinamento=1, 
            dataInizioValidita=DateToString(Now(), format="%Y-%m-%dT%H:%M:%S.000Z")
        )
        # se la scadenza è una data valida la imposto
        try:
            dettaglio['dataFineValidita']=DateToString(StringToDate(scadenza, format="%d/%m/%Y"), format="%Y-%m-%dT%H:%M:%S.000Z")
            if config.get('pagabile_oltre_scadenza')!="SI":
                dettaglio['dataLimitePagabilita']=DateToString(StringToDate(scadenza, format="%d/%m/%Y"), format="%Y-%m-%dT%H:%M:%S.000Z")

        except:
            scadenza_default=DateToString(Now() + 60,  format="%Y-%m-%dT%H:%M:%S.000Z")
            dettaglio['dataFineValidita']=scadenza_default
            dettaglio['dataLimitePagabilita']=scadenza_default
        
        data=dict(
            codiceIPA=codiceIpa, 
            codiceServizio=codiceServizio, 
            dovuto=dict(
                contestoDovuto="MONOBENEFICIARIO",
                dettaglioDovuto=[dettaglio],
                testataDovuto=dict(
                    datiContribuente=self.getContribuente(),
                    dettaglioPosizione=dettaglio.get("causaleDebito"),
                    idPos="%s_%s_%s" % (dbId, docId, codtrans)
                )
            )
        )
        return data

 
 
 
 
 
 
 
 
 
 
 
    # ------------------------------
    # AvvisiPagamento: infoPerNumeroAvviso
    # ------------------------------
    async def info_per_numero_avviso(
        self,
        cod_ipa: str,
        codice_servizio: str,
        numero_avviso: str,
    ):
        req = dict(
            cod_ipa_richiedente=cod_ipa,
            codice_servizio=codice_servizio,
            numero_avviso_dto={"numeroAvviso": numero_avviso},
        )

        data = await self._post(
            "/avvisiPagamento/v2/infoPerNumeroAvviso",
            req,
        )

        return data
    
    
    
    
    
    





    
    
    async def info_per_iuv(
        self,
        numero_avviso: str,
        cod_ipa: str="c_e463",
        codice_servizio: str="GISWEB",
    ):
        payload  = {
            "codIpaRichiedente": cod_ipa,
            "codiceIpaCreditore": cod_ipa,
            "codiceServizio": codice_servizio,
            "iuv": numero_avviso
        }
        data = await self._post("/pagamenti/v2/infoPerIuv", payload)
        return data
    
