# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

poetry update
poetry build
poetry publish

casini venv
per attivare quello giusto:
source $(poetry env info --path)/bin/activate

poetry env info -p
rm -rf `poetry env info -p`
poetry env use python

