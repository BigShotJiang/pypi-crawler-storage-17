from .license import LicenseTable
from .licenseassignment import LicenseAssignmentTable
from .licensetype import LicenseTypeTable