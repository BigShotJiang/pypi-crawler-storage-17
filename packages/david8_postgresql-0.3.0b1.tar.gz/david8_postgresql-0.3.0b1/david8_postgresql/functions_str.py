from david8.core.fn_generator import SeparatedArgsFnFactory as _SeparatedArgsFnFactory

concat = _SeparatedArgsFnFactory(name='concat', separator=' || ')
