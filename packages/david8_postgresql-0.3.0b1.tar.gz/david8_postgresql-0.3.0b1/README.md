# david8_postgresql

`david8_postgresql` is [PostgreSQL](https://www.postgresql.org/) dialect for [david8](https://github.com/d-ganchar/david8)

See [Wiki](https://github.com/d-ganchar/david8_postgresql/wiki)