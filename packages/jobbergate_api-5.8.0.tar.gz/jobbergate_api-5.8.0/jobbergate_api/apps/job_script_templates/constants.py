"""Describe constants for the job script templates module."""

WORKFLOW_FILE_NAME = "jobbergate.py"
