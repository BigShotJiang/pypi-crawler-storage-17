#!/usr/bin/python
# -*-coding: utf-8 -*-

from .fontawesome_mapping import icons
from .icongrid import Waffle, TextLegend, TextLegendHandler
