"""Browser automation module with Cloudflare bypass."""

from .manager import BrowserConfig, BrowserManager

__all__ = ["BrowserManager", "BrowserConfig"]
