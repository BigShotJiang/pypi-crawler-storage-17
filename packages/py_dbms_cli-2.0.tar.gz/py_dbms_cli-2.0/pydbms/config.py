#config options for pydbms

from .Global import pydbms_path
from .dependencies import json, os

DEFAULT_CONFIG = {
    "show_banner": True
}

def create_config():
    path = pydbms_path("config.json")

    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=4)

def load_config():
    path = pydbms_path("config.json")

    try:
        with open(path, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        create_config()
        return DEFAULT_CONFIG.copy()

def save_config(config):
    path = pydbms_path("config.json")

    with open(path, "w") as f:
        json.dump(config, f, indent=4)
