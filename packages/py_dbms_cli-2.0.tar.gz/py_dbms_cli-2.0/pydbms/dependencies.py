#Dependencies imports

import mysql.connector as mysql
import sqlparse
import pwinput
import time
import sys
from rich.console import Console
from rich.text import Text
from rich.panel import Panel
from rich import box
import pyfiglet
from rich.table import Table
from rich.align import Align
from rich.rule import Rule
import re
import os
import json