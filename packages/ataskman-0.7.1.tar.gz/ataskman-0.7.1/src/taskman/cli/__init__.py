"""CLI subpackage for taskman.

Contains the interactive CLI entrypoints and helpers.
"""

