"""
### Typed Btcmarkets
> A fully typed, validated async client for the Btcmarkets API

- Details
"""