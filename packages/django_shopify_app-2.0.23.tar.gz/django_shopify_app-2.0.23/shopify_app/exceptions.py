class ShopifyRequestException(Exception):
    pass
