"""FastShell - A FastAPI-like framework for building interactive shell applications."""

from .app import FastShell

__version__ = "0.1.0"
__all__ = ["FastShell"]