# V1WorkflowNodeView

WorkflowNodeView specifies the level of detail to include in the response.   - WORKFLOW_NODE_VIEW_UNSPECIFIED: Unspecified view.  - WORKFLOW_NODE_VIEW_BASIC: Basic view. Lacks large data fields. TODO: describe what fields are omitted.  - WORKFLOW_NODE_VIEW_FULL: Full view. Contains all fields.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


