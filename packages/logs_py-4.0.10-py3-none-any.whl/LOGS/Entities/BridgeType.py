from enum import Enum


class BridgeType(Enum):
    Unknown = "Unknown"
    Client = "Client"
    SFTP = "SFTP"
