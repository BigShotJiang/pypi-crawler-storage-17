## v0.5.2 (2025-02-10)

### Fix

- ci fix

## v0.5.1 (2025-02-10)

### Fix

- added primal range parameter. WARNING DO NOT USE

## v0.5.0 (2025-02-01)

### Fix

- removed pesky notebooks

## v0.4.0 (2025-02-01)

### Feat

- **fit**: improved modularity for passing fit parameters

## v0.1.0 (2025-01-20)
