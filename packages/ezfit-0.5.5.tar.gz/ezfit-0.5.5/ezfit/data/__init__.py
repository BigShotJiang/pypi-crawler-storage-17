"""Package data files for ezfit."""
