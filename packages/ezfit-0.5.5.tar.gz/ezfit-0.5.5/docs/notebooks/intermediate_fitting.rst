Intermediate Fitting Tutorial
==============================

This tutorial explores different optimization methods and when to use them.

.. note::

   This tutorial is also available as a Jupyter notebook: :download:`02_intermediate_fitting.ipynb <../../notebooks/02_intermediate_fitting.ipynb>`

.. include:: ../../notebooks/02_intermediate_fitting.ipynb
   :parser: myst_nb.docutils_
