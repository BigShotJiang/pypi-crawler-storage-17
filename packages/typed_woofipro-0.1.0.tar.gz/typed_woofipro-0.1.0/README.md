# Typed Woofipro

> A fully typed, validated async client for the Woofipro API

Use *autocomplete* instead of documentation.

🚧 Under construction.