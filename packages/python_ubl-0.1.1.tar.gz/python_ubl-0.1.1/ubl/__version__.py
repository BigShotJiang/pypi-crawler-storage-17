"""Version information for the UBL library."""

__version__ = "0.1.0"
