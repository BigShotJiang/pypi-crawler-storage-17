# API

```{eval-rst}
.. module:: genoray

.. autoclass:: VCF

.. autoclass:: PGEN

.. autoclass:: SparseVar

.. autoclass:: SparseGenotypes
```

## `genoray.exprs`

```{eval-rst}
.. automodule:: genoray.exprs
    :exclude-members: IndexSchema
```