import warnings

from kognic.io.resources.scene.file_data import FileData  # noqa: F401

warnings.warn("This has been moved to kognic.io.resources.scene and will be removed in the future", DeprecationWarning, stacklevel=2)
