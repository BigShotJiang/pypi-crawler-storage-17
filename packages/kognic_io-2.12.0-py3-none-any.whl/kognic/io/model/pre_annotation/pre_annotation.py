from kognic.io.model.base_serializer import BaseSerializer


class CreatedPreAnnotation(BaseSerializer):
    id: str
