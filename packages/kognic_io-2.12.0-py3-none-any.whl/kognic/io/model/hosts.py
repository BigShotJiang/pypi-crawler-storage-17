DEFAULT_INPUT_API_HOST = "https://input.app.kognic.com"
DEFAULT_ORDER_EXECUTION_API_HOST = "https://order-execution.app.kognic.com"
DEFAULT_ANNOTATION_INTEGRATION_API_HOST = "https://annotation-integration.app.kognic.com"
DEFAULT_WORKSPACE_API_HOST = "https://workspace.app.kognic.com"
