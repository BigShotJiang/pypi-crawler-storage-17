import warnings

from kognic.io.model.scene.invalidated_reason import SceneInvalidatedReason as InvalidatedReasonInput  # noqa: F401

warnings.warn("This has been moved to kognic.io.model.scene and will be removed in the future", DeprecationWarning, stacklevel=2)
