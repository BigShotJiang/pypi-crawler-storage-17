"""
CLI module for AgentCube.
"""