"""
SEM Image Thresholding and Analysis Module

This module provides functionality for batch processing of SEM images,
including thresholding, particle detection, image fusion, and data visualization.
"""

import os
import cv2
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
import csv
import pandas as pd
from scipy.interpolate import griddata
from typing import Optional, List, Dict, Tuple, Union
from PIL import Image


class SEMThresholdProcessor:
    """
    A comprehensive processor for SEM image thresholding and analysis.
    
    This class provides methods for:
    - Single image thresholding and particle detection
    - Batch processing of image directories
    - Image fusion from multiple detectors
    - CSV data consolidation and visualization
    """
    
    def __init__(self, 
                 threshold: int = 128,
                 min_size: int = 50,
                 image_size_um: float = 5.0,
                 save_results: bool = True,
                 verbose: bool = False):
        """
        Initialize the SEM threshold processor.
        
        Args:
            threshold: Threshold value for binarization (0-255)
            min_size: Minimum particle size in pixels²
            image_size_um: Image size in micrometers (for area calculations)
            save_results: Whether to save CSV results
            verbose: Whether to print progress information
        """
        self.threshold = threshold
        self.min_size = min_size
        self.image_size_um = image_size_um
        self.save_results = save_results
        self.verbose = verbose
        
        # Validate parameters
        if not 0 <= threshold <= 255:
            raise ValueError("Threshold must be between 0 and 255")
        if min_size < 0:
            raise ValueError("Minimum size must be non-negative")
        if image_size_um <= 0:
            raise ValueError("Image size must be positive")
    
    def _log(self, message: str) -> None:
        """Print message if verbose mode is enabled."""
        if self.verbose:
            print(message)
    
    def process_single_image(self, 
                           image_path: str, 
                           show_result: bool = False) -> Optional[Dict]:
        """
        Apply thresholding to a single SEM image and detect particles.
        
        Args:
            image_path: Path to the image file
            show_result: Whether to display the result
            
        Returns:
            Dictionary containing processing results or None if error
        """
        # Validate threshold
        if not 0 <= self.threshold <= 255:
            self._log("Error: Threshold must be between 0 and 255")
            return None
        
        # Load image
        try:
            image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
            if image is None:
                self._log(f"Error: Could not load image {image_path}")
                return None
        except Exception as e:
            self._log(f"Error loading image: {e}")
            return None
        
        # Apply smoothing
        kernel_size = 1
        image_smooth = cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)
        
        # Apply thresholding
        _, binary_image = cv2.threshold(image_smooth, self.threshold, 255, cv2.THRESH_BINARY)
        
        # Find contours
        contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Filter contours by size
        detected_particles = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > self.min_size:
                detected_particles.append({
                    'area': area,
                    'contour': contour
                })
        
        # Create visualization
        colored_image = binary_image.copy()
        original_with_contours = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        
        # Fill detected areas
        for particle in detected_particles:
            cv2.fillPoly(original_with_contours, [particle['contour']], (0, 255, 0))
        
        # Display results if requested
        if show_result:
            self._display_results(image, image_smooth, binary_image, 
                                colored_image, original_with_contours, detected_particles)
        
        # # Save contour image
        # base_name = os.path.splitext(os.path.basename(image_path))[0]
        # contour_filename = f"{base_name}_contours.tiff"
        # contour_path = os.path.join(os.path.dirname(image_path), contour_filename)
        # cv2.imwrite(contour_path, original_with_contours)
        
        # Save CSV results if requested
        if self.save_results:
            self._save_csv_results(image_path, detected_particles, binary_image)
        
        return {
            'binary_image': binary_image,
            'colored_image': colored_image,
            'detected_particles': detected_particles,
            'contour_image': original_with_contours,
        }
    
    def _display_results(self, original, smooth, binary, colored, contours, particles):
        """Display processing results in a matplotlib figure."""
        fig, axes = plt.subplots(2, 4, figsize=(24, 10))
        
        # Original image
        axes[0, 0].imshow(original, cmap='gray')
        axes[0, 0].set_title(f'Original Image\nSize: {original.shape}')
        axes[0, 0].axis('off')
        
        # Smoothed image
        axes[0, 1].imshow(smooth, cmap='gray')
        axes[0, 1].set_title(f'Smoothed Image\n(Gaussian {1}x{1})')
        axes[0, 1].axis('off')
        
        # Binary image
        axes[0, 2].imshow(binary, cmap='gray')
        axes[0, 2].set_title(f'Binary Image (threshold={self.threshold})')
        axes[0, 2].axis('off')
        
        # Mask
        axes[0, 3].imshow(colored, cmap='gray')
        axes[0, 3].set_title(f'Mask: pixels > threshold\n({len(particles)} particles)')
        axes[0, 3].axis('off')
        
        # Binary with contours
        verification_image = cv2.cvtColor(binary, cv2.COLOR_GRAY2RGB)
        for particle in particles:
            cv2.drawContours(verification_image, [particle['contour']], -1, (0, 255, 0), 3)
        axes[1, 0].imshow(verification_image)
        axes[1, 0].set_title('Verification: white areas + green contours')
        axes[1, 0].axis('off')
        
        # Original with filled areas
        axes[1, 1].imshow(contours)
        axes[1, 1].set_title('Filled areas on original image')
        axes[1, 1].axis('off')
        
        # Histogram comparison
        axes[1, 2].hist(original.ravel(), bins=256, range=[0, 256], alpha=0.5, 
                       color='blue', label='Original')
        axes[1, 2].set_title('Intensity Histogram')
        axes[1, 2].set_xlabel('Intensity')
        axes[1, 2].set_ylabel('Frequency')
        axes[1, 2].legend()
        
        # Statistics
        axes[1, 3].text(0.1, 0.9, f'Particles detected: {len(particles)}', 
                       transform=axes[1, 3].transAxes, fontsize=12)
        axes[1, 3].text(0.1, 0.8, f'Threshold: {self.threshold}', 
                       transform=axes[1, 3].transAxes, fontsize=12)
        axes[1, 3].text(0.1, 0.7, f'Min size: {self.min_size} px²', 
                       transform=axes[1, 3].transAxes, fontsize=12)
        axes[1, 3].axis('off')
        
        plt.tight_layout()
        plt.show()
    
    def _save_csv_results(self, image_path: str, particles: List[Dict], binary_image: np.ndarray) -> None:
        """Save processing results to CSV file."""
        try:
            # Create mask for detected particles
            mask_particles = np.zeros_like(binary_image, dtype=np.uint8)
            for particle in particles:
                cv2.fillPoly(mask_particles, [particle['contour']], 200)
            
            # Calculate statistics
            num_particles = len(particles)
            total_area_pixels = int(np.count_nonzero(mask_particles == 200))
            avg_area_pixels = total_area_pixels / num_particles if num_particles > 0 else 0
            
            # Calculate areas in µm²
            height, width = binary_image.shape
            pixel_area_um2 = (self.image_size_um ** 2) / (height * width)
            
            total_area_um2 = total_area_pixels * pixel_area_um2
            avg_area_um2 = avg_area_pixels * pixel_area_um2
            total_area_percentage = (total_area_pixels / (height * width)) * 100
            
            # Calculate density (particles/µm²)
            surface_area_um2 = self.image_size_um ** 2
            density = num_particles / surface_area_um2 if surface_area_um2 > 0 else 0
            
            # Create CSV filename
            base_name = os.path.splitext(os.path.basename(image_path))[0]
            csv_filename = f"{base_name}_results.csv"
            csv_path = os.path.join(os.path.dirname(image_path), csv_filename)
            
            # Write CSV
            with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = ['Filename', 'Density', 'Avg_area_um2', 
                             'Total_area_percentage', 'Num_particles', 'Total_area_um2']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                writer.writerow({
                    'Filename': os.path.basename(image_path),
                    'Density': density,
                    'Avg_area_um2': avg_area_um2,
                    'Total_area_percentage': total_area_percentage,
                    'Num_particles': num_particles,
                    'Total_area_um2': total_area_um2
                })
            
            self._log(f"Results saved to: {csv_filename}")
            
        except Exception as e:
            self._log(f"Error saving CSV: {e}")
    
    def process_merged_tiff_directory(self, 
                                    parent_directory: str, 
                                    coordinates_df: pd.DataFrame,
                                    image_type: int,
                                    number_type: int,
                                    scale: str,
                                    show_results: bool = False) -> List[str]:
        """
        Process specific images in a merged TIFF file based on coordinates and settings.
        
        This function finds the merged TIFF file, opens it, and processes only
        the pages that correspond to the coordinates and image type settings,
        using the same logic as on_click functionality.
        
        Args:
            parent_directory: Path to directory containing the merged TIFF
            coordinates_df: DataFrame with X, Y coordinates (same as used in on_click)
            image_type: Image type index (same as used in on_click)
            number_type: Number of image types (same as used in on_click)
            show_results: Whether to display results for each image
            
        Returns:
            List of processed filenames
        """
        all_results = []
        
        self._log(f"Scanning directory for merged TIFF: {parent_directory}")
        
        # Find merged TIFF file
        merged_tiff_files = []
        for root, dirs, files in os.walk(parent_directory):
            # Look for TIFF files that might be merged (not starting with specific patterns)
            tiff_files = [f for f in files if f.lower().endswith(('.tiff', '.tif'))]
            
            for file in tiff_files:

                # Check if it's a potential merged file
                file_path = os.path.join(root, file)
                try:
                    # Try to open and check if it has multiple pages
                    with Image.open(file_path) as img:
                        if hasattr(img, 'n_frames') and img.n_frames > 1:
                            merged_tiff_files.append(file_path)
                            self._log(f"Found merged TIFF with {img.n_frames} pages: {file}")
                except Exception as e:
                    self._log(f"Could not check file {file}: {e}")
                    continue
        
        if not merged_tiff_files:
            self._log("No merged TIFF files found in directory.")
            return all_results
        
        # Process each merged TIFF file
        for merged_file_path in merged_tiff_files:
            self._log(f"\n{'='*60}")
            self._log(f"PROCESSING MERGED TIFF: {merged_file_path}")
            self._log(f"{'='*60}")
            
            try:
                with Image.open(merged_file_path) as img:
                    total_pages = img.n_frames if hasattr(img, 'n_frames') else 1
                    self._log(f"Total pages in merged TIFF: {total_pages}")
                    
                    directory_results = []
                    
                    # Calculate which pages to process based on coordinates and settings
                    # Same logic as in on_click: result = self.image_type + (closest_idx * self_number_type)
                    pages_to_process = []
                    
                    for idx in range(len(coordinates_df)):
                        # Calculate the page index using the same formula as on_click
                        page_index = image_type + (idx * number_type)
                        
                        # Check if this page index is valid for the TIFF
                        if 0 <= page_index < total_pages:
                            pages_to_process.append({
                                'page_index': page_index,
                                'coordinate_idx': idx,
                                'x': coordinates_df.iloc[idx]['X'],
                                'y': coordinates_df.iloc[idx]['Y']
                            })
                    
                    self._log(f"Will process {len(pages_to_process)} pages out of {total_pages} total pages")
                    
                    # Process only the calculated pages
                    for page_info in pages_to_process:
                        page_index = page_info['page_index']
                        coord_idx = page_info['coordinate_idx']
                        x_coord = page_info['x']
                        y_coord = page_info['y']
                        
                        try:
                            # Seek to the specific page
                            img.seek(page_index)
                            
                            # Convert PIL image to numpy array for processing
                            img_array = np.array(img)
                            
                            self._log(f"Processing page {page_index + 1}/{total_pages} (coord {coord_idx}: {x_coord:.1f}, {y_coord:.1f})")
                            
                            # Process the image using the same method as process_single_image
                            result = self._process_image_array(img_array, show_result=show_results)
                            
                            if result is not None:
                                particles = result['detected_particles']
                                binary_image = result['binary_image']
                                
                                # Calculate statistics for this page
                                mask_particles = np.zeros_like(binary_image, dtype=np.uint8)
                                for particle in particles:
                                    cv2.fillPoly(mask_particles, [particle['contour']], 200)
                                
                                num_particles = len(particles)
                                total_area_pixels = int(np.count_nonzero(mask_particles == 200))
                                avg_area_pixels = total_area_pixels / num_particles if num_particles > 0 else 0
                                
                                # Calculate areas in µm²
                                height, width = binary_image.shape
                                pixel_area_um2 = (self.image_size_um ** 2) / (height * width)
                                
                                total_area_um2 = total_area_pixels * pixel_area_um2
                                avg_area_um2 = avg_area_pixels * pixel_area_um2
                                total_area_percentage = (total_area_pixels / (height * width)) * 100
                                
                                # Calculate density
                                surface_area_um2 = self.image_size_um ** 2
                                density = num_particles / surface_area_um2 if surface_area_um2 > 0 else 0
                                
                                # Generate filename for this page with scale and coordinates
                                page_filename = f"{scale}_{x_coord:.1f}_{y_coord:.1f}.tiff"
                                
                                # Save processed image
                                if self.save_results:
                                    output_dir = os.path.dirname(merged_file_path)
                                    processed_path = os.path.join(output_dir, page_filename)
                                    
                                    # Save the processed image (with contours)
                                    processed_img = Image.fromarray(result['processed_image'])
                                    processed_img.save(processed_path)
                                    
                                    self._log(f"Processed image saved: {processed_path}")
                                
                                # Add to directory results
                                directory_results.append({
                                    'Filename': page_filename,
                                    'Page_Index': page_index + 1,
                                    'Density': density,
                                    'Avg_area_um2': avg_area_um2,
                                    'Total_area_percentage': total_area_percentage,
                                    'Num_particles': num_particles,
                                    'Total_area_um2': total_area_um2
                                })
                                
                                all_results.append(page_filename)
                            
                        except Exception as e:
                            self._log(f"Error processing page {page_index + 1}: {e}")
                            continue
                    
                    # Save consolidated CSV for this merged TIFF
                    if directory_results:
                        output_dir = os.path.dirname(merged_file_path)
                        csv_path = os.path.join(output_dir, "merged_threshold_results.csv")
                        
                        with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
                            fieldnames = ['Filename', 'Page_Index', 'Density', 'Avg_area_um2', 
                                         'Total_area_percentage', 'Num_particles', 'Total_area_um2']
                            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                            
                            writer.writeheader()
                            for result in directory_results:
                                writer.writerow(result)
                        
                        self._log(f"Consolidated CSV saved: {csv_path}")
                    
                    self._log(f"Pages processed from merged TIFF: {len(directory_results)}")
            
            except Exception as e:
                self._log(f"Error processing merged TIFF {merged_file_path}: {e}")
                continue
        
        self._log(f"\n{'='*60}")
        self._log(f"MERGED TIFF PROCESSING SUMMARY")
        self._log(f"{'='*60}")
        self._log(f"Total pages processed: {len(all_results)}")
        
        return all_results
        
    def _process_image_array(self, img_array: np.ndarray, show_result: bool = False) -> Optional[Dict]:
        """
        Process a numpy array image using the same method as process_single_image.
        
        Args:
            img_array: Numpy array of the image
            show_result: Whether to display results
            
        Returns:
            Dictionary with processing results or None if failed
        """
        try:
            # Convert to grayscale if needed (same as process_single_image)
            if len(img_array.shape) == 3:
                if img_array.shape[2] == 4:  # RGBA
                    gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
                elif img_array.shape[2] == 3:  # RGB
                    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
                else:
                    gray = img_array[:, :, 0]
            else:
                gray = img_array
            
            # Apply smoothing
            image_smooth = cv2.GaussianBlur(gray, (3, 3), 0)
            
            # Apply thresholding
            _, binary_image = cv2.threshold(image_smooth, self.threshold, 255, cv2.THRESH_BINARY)
            
            # Find contours
            contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # Filter contours by size
            detected_particles = []
            for contour in contours:
                area = cv2.contourArea(contour)
                if area > self.min_size:
                    detected_particles.append({
                        'area': area,
                        'contour': contour
                    })
            
            # Create visualization: show contours on original image
            original_with_contours = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
            
            # Draw contours on original image
            for particle in detected_particles:
                cv2.fillPoly(original_with_contours, [particle['contour']], (0, 255, 0))  # Green fill
            
            # Show result if requested
            if show_result:
                cv2.imshow('Processed Image', original_with_contours)
                cv2.waitKey(0)
                cv2.destroyAllWindows()
            
            return {
                'detected_particles': detected_particles,
                'binary_image': binary_image,
                'processed_image': original_with_contours
            }
            
        except Exception as e:
            self._log(f"Error processing image array: {e}")
            return None
        
    def _normalize_filename_for_comparison(self, filename: str) -> str:
        """
        Normalize filename for comparison by converting numbers like 1.0 to 1, -0.0 to 0, etc.
        
        Args:
            filename: Filename string to normalize
            
        Returns:
            Normalized filename string
        """
        import re
        
        # Convert to string and lowercase
        normalized = str(filename).strip().lower()
        
        # Normalize numbers: convert 1.0 to 1, -0.0 to 0, etc.
        def normalize_number(match):
            num_str = match.group(0)
            try:
                num = float(num_str)
                # Convert to int if it's a whole number, otherwise keep as float
                if num.is_integer():
                    return str(int(num))
                else:
                    return str(num)
            except ValueError:
                return num_str
        
        # Match numbers in the filename (including negative numbers)
        normalized = re.sub(r'-?\d+\.?\d*', normalize_number, normalized)
        
        return normalized
    
    def consolidate_csv_files(self, parent_directory: str) -> Optional[str]:
        """
        Consolidate all 'merged_threshold_results.csv' files found in parent directory and subdirectories
        into a single consolidated CSV file. Duplicates are overwritten (1.0 and 1 are considered the same).
        
        Args:
            parent_directory: Path to parent directory
            
        Returns:
            Path to created consolidated CSV file or None if error
        """
        self._log(f"Consolidating merged_threshold_results.csv files in: {parent_directory}")
        
        # Dictionary to store results by normalized filename (to handle duplicates)
        results_dict = {}  # key: normalized_filename, value: row data
        
        # Walk through all subdirectories
        for root, dirs, files in os.walk(parent_directory):
            self._log(f"\nScanning directory: {root}")
            
            # Look for 'merged_threshold_results.csv' files
            for file in files:
                if file == "merged_threshold_results.csv":
                    csv_path = os.path.join(root, file)
                    self._log(f"  Found: {csv_path}")
                    
                    try:
                        # Read CSV file
                        df = pd.read_csv(csv_path)
                        
                        # Process each row
                        for _, row in df.iterrows():
                            # Get filename
                            filename = str(row.get('Filename', ''))
                            
                            # Normalize filename for comparison (1.0 -> 1, -0.0 -> 0, etc.)
                            normalized_filename = self._normalize_filename_for_comparison(filename)
                            
                            # Split filename into X and Y
                            if '_' in filename and (filename.endswith('.tiff') or filename.endswith('.tif')):
                                # Remove extension
                                name_without_ext = filename.replace('.tiff', '').replace('.tif', '')
                                # Split by underscore
                                parts = name_without_ext.split('_')
                                if len(parts) >= 3:
                                    # Format: scale_X_Y or 1.0_X_Y
                                    x_coord = parts[-2]  # Second to last
                                    y_coord = parts[-1]  # Last
                                elif len(parts) == 2:
                                    x_coord = parts[1]
                                    y_coord = ''
                                else:
                                    x_coord = name_without_ext
                                    y_coord = ''
                            else:
                                x_coord = filename
                                y_coord = ''
                            
                            # Create row data
                            row_data = {
                                'X': x_coord,
                                'Y': y_coord,
                                'Density': row.get('Density', ''),
                                'Avg_area_um2': row.get('Avg_area_um2', ''),
                                'Total_area_percentage': row.get('Total_area_percentage', ''),
                                'Num_particles': row.get('Num_particles', ''),
                                'Total_area_um2': row.get('Total_area_um2', '')
                            }
                            
                            # Store or overwrite (if duplicate, latest file wins)
                            results_dict[normalized_filename] = row_data
                            self._log(f"    Processed: {filename} (normalized: {normalized_filename})")
                                
                    except Exception as e:
                        self._log(f"  Error reading {csv_path}: {e}")
        
        if not results_dict:
            self._log("No 'merged_threshold_results.csv' files found!")
            return None
        
        # Create consolidated CSV file
        consolidated_filename = "consolidated_results.csv"
        consolidated_path = os.path.join(parent_directory, consolidated_filename)
        
        try:
            with open(consolidated_path, 'w', newline='', encoding='utf-8') as csvfile:
                # Define columns (with X and Y separated)
                fieldnames = ['X', 'Y', 'Density', 'Avg_area_um2', 
                             'Total_area_percentage', 'Num_particles', 'Total_area_um2']
                
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                
                # Write all data (duplicates already handled)
                for row_data in results_dict.values():
                    writer.writerow(row_data)
            
            self._log(f"\n{'='*60}")
            self._log(f"CONSOLIDATION COMPLETE")
            self._log(f"{'='*60}")
            self._log(f"Consolidated file created: {consolidated_path}")
            self._log(f"Total unique rows: {len(results_dict)}")
            self._log(f"(Duplicates overwritten - 1.0 and 1 are considered the same)")
            
            return consolidated_path
            
        except Exception as e:
            self._log(f"Error creating consolidated file: {e}")
            return None
    
    def plot_sem_data(self, 
                     parent_directory: str, 
                     show_results: bool = True) -> List[str]:
        """
        Plot density and total area data from consolidated CSV files
        found in parent directory and subdirectories.
        
        Args:
            parent_directory: Path to parent directory
            show_results: Whether to display plots with matplotlib
            
        Returns:
            List of paths to processed CSV files
        """
        processed_files = []
        
        self._log(f"\n{'='*60}")
        self._log(f"SEM DATA PLOTTING")
        self._log(f"{'='*60}")
        self._log(f"Parent directory: {parent_directory}")
        
        # Walk through all subdirectories
        for root, dirs, files in os.walk(parent_directory):
            # Look for 'consolidated_results.csv' files
            for file in files:
                if file == "consolidated_results.csv":
                    csv_path = os.path.join(root, file)
                    self._log(f"\nProcessing: {csv_path}")
                    
                    try:
                        # Load data
                        data_frame = pd.read_csv(csv_path)
                        self._log(f"  Data loaded: {len(data_frame)} points")
                        
                        # Check that required columns exist
                        required_columns = ['X', 'Y', 'Density', 'Total_area_percentage']
                        missing_columns = [col for col in required_columns if col not in data_frame.columns]
                        
                        if missing_columns:
                            self._log(f"  ⚠️  Missing columns: {missing_columns}")
                            continue
                        
                        # Create Mapping directory if it doesn't exist
                        mapping_dir = os.path.join(root, "Mapping")
                        os.makedirs(mapping_dir, exist_ok=True)
                        
                        # Grid parameters
                        step = 0.5
                        x_min, x_max = data_frame['X'].min(), data_frame['X'].max()
                        y_min, y_max = data_frame['Y'].min(), data_frame['Y'].max()
                        
                        # Extend limits slightly for better interpolation
                        x_range = x_max - x_min
                        y_range = y_max - y_min
                        x_min -= x_range * 0.1
                        x_max += x_range * 0.1
                        y_min -= y_range * 0.1
                        y_max += y_range * 0.1
                        
                        # Generate regular grid
                        x = np.arange(x_min, x_max + step, step)
                        y = np.arange(y_min, y_max + step, step)
                        grid_x, grid_y = np.meshgrid(x, y)
                        
                        # Columns to plot
                        plot_columns = ['Density', 'Total_area_percentage']
                        file_names = ['Density', 'Total_area_percentage']
                        
                        # Process each column
                        for i, column in enumerate(plot_columns):
                            self._log(f"  Plotting {column}...")
                            
                            # Interpolate on grid
                            grid_z = griddata(
                                (data_frame['X'], data_frame['Y']),
                                data_frame[column],
                                (grid_x, grid_y),
                                method='linear',
                                fill_value=np.nan
                            )
                            
                            # Create DataFrame to save grid
                            grid_data = pd.DataFrame({
                                'X': grid_x.flatten(),
                                'Y': grid_y.flatten(),
                                'Z': grid_z.flatten()
                            })
                            
                            # Pivot for display
                            grid_z_pivot = grid_data.pivot(index='Y', columns='X', values='Z')
                            
                            # Save grid
                            grid_path = os.path.join(mapping_dir, f'{file_names[i]}_grid.csv')
                            grid_z_pivot.to_csv(grid_path)
                            
                            # Create plot
                            fig, ax = plt.subplots(figsize=(10, 8))
                            
                            # Plot with interpolation
                            img = ax.imshow(
                                grid_z_pivot,
                                extent=(x_min, x_max, y_min, y_max),
                                origin='lower',
                                cmap='Spectral_r',
                                aspect='equal'
                            )
                            
                            # Add original data points
                            scatter = ax.scatter(
                                data_frame['X'],
                                data_frame['Y'],
                                c=data_frame[column],
                                s=50,
                                edgecolors='black',
                                linewidth=0.5,
                                cmap='Spectral_r',
                                alpha=0.8
                            )
                            
                            # Customize appearance
                            cbar = plt.colorbar(img, ax=ax, shrink=1)
                            cbar.ax.tick_params(labelsize=20)
                            
                            ax.set_xlabel('X (cm)', fontsize=24)
                            ax.set_ylabel('Y (cm)', fontsize=24)
                            ax.tick_params(axis='both', labelsize=20)
                            
                            # Title
                            column_title = "Density (particles/µm²)" if column == "Density" else "Total Area (%)"
                            ax.set_title(f"{column_title} - {os.path.basename(root)}", fontsize=16)
                            
                            # Grid
                            ax.grid(True, alpha=0.3)
                            
                            # Save plot
                            plot_path = os.path.join(mapping_dir, f"{file_names[i]}.png")
                            plt.savefig(plot_path, bbox_inches='tight', dpi=300)
                            
                            if show_results:
                                plt.show()
                            else:
                                plt.close(fig)
                            
                            self._log(f"    Saved: {plot_path}")
                        
                        processed_files.append(csv_path)
                        
                    except Exception as e:
                        self._log(f"  ❌ Error processing {csv_path}: {e}")
                        continue
        
        self._log(f"\n{'='*60}")
        self._log(f"PLOTTING COMPLETE")
        self._log(f"{'='*60}")
        self._log(f"Files processed: {len(processed_files)}")
        
        return processed_files


# Example usage
if __name__ == "__main__":
    # Initialize processor
    processor = SEMThresholdProcessor(
        threshold=200,
        min_size=0,
        image_size_um=5.0,
        save_results=True,
        verbose=True
    )
    
    # Example directory
    parent_dir = r"C:\Users\TM273821\Desktop\SEM\TEst_brute\1"
    
    # Process directory
    # results = processor.process_directory(parent_dir, show_results=False)
    
    # Consolidate CSV files
    # consolidated_path = processor.consolidate_csv_files(parent_dir)
    
    # Plot data
    # plot_files = processor.plot_sem_data(parent_dir, show_results=False)