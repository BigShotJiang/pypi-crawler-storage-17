"""Module for tool detection (COMPLUS4T, KRONOS, SP tools (SP1, SP2, SP3, SP4, etc.), SICA)"""

import os
import re
import glob
import shutil


def check_complus4t_in_dirname(dirname):
    """Check if COMPLUS4T is present in KLARF files in the directory."""
    if not dirname or not os.path.exists(dirname):
        return False
    
    try:
        files = [f for f in os.listdir(dirname) 
                if f.endswith('.001') and os.path.isfile(os.path.join(dirname, f))]
        
        for file in files:
            file_path = os.path.join(dirname, file)
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    if 'COMPLUS4T' in content:
                        return True
            except Exception as e:
                pass  # Error reading file
    except Exception as e:
        pass  # Error listing files
    
    return False


def check_kronos_in_dirname(dirname):
    """Check if KRONOS is present in KLARF files in the directory and subdirectories (only checks first 10 lines)."""
    if not dirname or not os.path.exists(dirname):
        return False
    
    try:
        # Search in parent directory and all subdirectories
        files = []
        
        # Check parent directory
        all_items = os.listdir(dirname)
        for item in all_items:
            item_path = os.path.join(dirname, item)
            if os.path.isfile(item_path) and item.endswith('.001'):
                files.append(item_path)
            elif os.path.isdir(item_path):
                # Search in subdirectory
                try:
                    sub_items = os.listdir(item_path)
                    for sub_item in sub_items:
                        sub_item_path = os.path.join(item_path, sub_item)
                        if os.path.isfile(sub_item_path) and sub_item.endswith('.001'):
                            files.append(sub_item_path)
                except Exception:
                    pass
        
        if not files:
            return False
        
        for file_path in files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    # Only read first 10 lines
                    for i, line in enumerate(f):
                        if i >= 10:  # Stop after 10 lines
                            break
                        if 'KRONOS' in line:
                            return True
            except Exception:
                pass
    except Exception:
        pass
    
    return False


def check_sp3_in_dirname(dirname):
    """Check if any SP tool (SP1, SP2, SP3, SP4, etc.) is present in KLARF files in the directory and subdirectories."""
    if not dirname or not os.path.exists(dirname):
        return False
    
    import re
    # Pattern to match SP followed by one or more digits (SP1, SP2, SP3, SP4, etc.)
    sp_pattern = re.compile(r'SP\d+', re.IGNORECASE)
    
    try:
        # Search in parent directory and all subdirectories
        files = []
        all_items = os.listdir(dirname)
        
        for item in all_items:
            item_path = os.path.join(dirname, item)
            if os.path.isfile(item_path) and item.endswith('.001'):
                files.append(item_path)
            elif os.path.isdir(item_path):
                # Search in subdirectory
                try:
                    sub_items = os.listdir(item_path)
                    for sub_item in sub_items:
                        sub_item_path = os.path.join(item_path, sub_item)
                        if os.path.isfile(sub_item_path) and sub_item.endswith('.001'):
                            files.append(sub_item_path)
                except Exception:
                    pass
        
        if not files:
            return False
        
        for file_path in files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    # Read first 10 lines (SP tools should be in early lines)
                    lines = f.readlines()[:10]
                    for i, line in enumerate(lines, 1):
                        line_stripped = line.strip()
                        if sp_pattern.search(line_stripped):
                            return True
            except Exception:
                pass
    except Exception:
        pass
    
    return False


def is_sica_format(content):
    """Check if content matches SICA format (WaferID "waferIDnumberXX" or Slot XX)."""
    # Check for SICA format: WaferID "waferIDnumber23" (must contain "waferIDnumber" or "waferidnumber")
    # AND Slot XX must be present
    # Pattern 1: WaferID with "waferIDnumber" or "waferidnumber" (case insensitive)
    waferid_pattern = re.search(r'WaferID\s+"[^"]*(?:waferIDnumber|waferidnumber)\d+[^"]*"', content, re.IGNORECASE)
    slot_pattern = re.search(r'Slot\s+\d+', content)
    
    # Both patterns must be present for SICA format
    if waferid_pattern and slot_pattern:
        return True
    
    # Also check for InspectionStationID with SICA (more specific)
    # Only if SICA appears on the same line as InspectionStationID
    if 'InspectionStationID' in content:
        lines = content.split('\n')
        for line in lines:
            if 'InspectionStationID' in line:
                # Check if SICA appears in the same line (case insensitive)
                if 'SICA' in line.upper():
                    return True
    
    return False


def check_sica_in_dirname(dirname):
    """Check if SICA is present in KLARF files in the directory and subdirectories."""
    if not dirname or not os.path.exists(dirname):
        return False
    
    try:
        # Search in parent directory and all subdirectories
        files = []
        all_items = os.listdir(dirname)
        
        for item in all_items:
            item_path = os.path.join(dirname, item)
            if os.path.isfile(item_path) and item.endswith('.001'):
                files.append(item_path)
            elif os.path.isdir(item_path):
                # Search in subdirectory
                try:
                    sub_items = os.listdir(item_path)
                    for sub_item in sub_items:
                        sub_item_path = os.path.join(item_path, sub_item)
                        if os.path.isfile(sub_item_path) and sub_item.endswith('.001'):
                            files.append(sub_item_path)
                except Exception:
                    pass
        
        if not files:
            return False
        
        # Check each file for SICA format
        for file_path in files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    # Only check for SICA format (specific check, not just 'SICA' in content)
                    if is_sica_format(content):
                        print(f"[DEBUG SICA] SICA format detected in: {os.path.basename(file_path)}")
                        return True
            except Exception:
                pass
    except Exception:
        pass
    
    return False


def organize_sica_files_automatically(dirname):
    """Organize SICA files automatically when SICA is detected (same as SP3)."""
    from PyQt5.QtWidgets import QMessageBox
    from semapp.Processing.klarf_reader import extract_wafer_ids_from_sp3, organize_sp3_files
    
    try:
        print("\n" + "="*60)
        print("SICA DETECTED - Organizing files automatically")
        print("="*60)
        
        # Extract wafer IDs and create directories (uses same function as SP3)
        wafer_ids = extract_wafer_ids_from_sp3(dirname)
        
        if wafer_ids:
            print(f"Found {len(wafer_ids)} wafer IDs: {wafer_ids}")
            
            # Organize files into subdirectories (uses same function as SP3)
            moved_files = organize_sp3_files(dirname)
            
            print("\n" + "="*60)
            print("SICA FILE ORGANIZATION COMPLETED")
            print("="*60)
            
            # Show completion message
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setText(f"SICA files organized: {len(wafer_ids)} wafer directories created")
            msg.setWindowTitle("SICA Organization Complete")
            msg.exec_()
        else:
            print("No wafer IDs found in SICA files")
            
    except Exception as e:
        print(f"Error during SICA organization: {e}")
        import traceback
        traceback.print_exc()
        
        # Show error message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during SICA organization: {str(e)}")
        msg.setWindowTitle("SICA Organization Error")
        msg.exec_()


def organize_complus4t_files_automatically(dirname):
    """Organize COMPLUS4T files automatically when COMPLUS4T is detected."""
    from PyQt5.QtWidgets import QMessageBox
    from semapp.Processing.klarf_reader import extract_positions
    
    try:
        print("\n" + "="*60)
        print("COMPLUS4T DETECTED - Creating folders and mapping files automatically")
        print("="*60)
        
        if not dirname or not os.path.exists(dirname):
            print("Directory not found")
            return
        
        # Find all .001 files in parent directory
        klarf_files = glob.glob(os.path.join(dirname, '*.001'))
        
        if not klarf_files:
            print("No .001 files found in parent directory")
            return
        
        print(f"Found {len(klarf_files)} .001 file(s) to process")
        
        # Extract all wafer IDs from COMPLUS4T files
        wafer_ids = []
        recipe_path = None
        
        for klarf_file in klarf_files:
            try:
                with open(klarf_file, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    if 'COMPLUS4T' in content:
                        recipe_path = klarf_file
                        # Extract all wafer IDs
                        pattern = r'WaferID\s+"@(\d+)"'
                        matches = re.findall(pattern, content)
                        for match in matches:
                            wafer_id = int(match)
                            if wafer_id not in wafer_ids and 1 <= wafer_id <= 26:
                                wafer_ids.append(wafer_id)
            except Exception as e:
                print(f"Error reading {klarf_file}: {e}")
                continue
        
        if not wafer_ids:
            print("No wafer IDs found in COMPLUS4T files")
            return
        
        wafer_ids = sorted(wafer_ids)
        print(f"Found {len(wafer_ids)} wafer IDs: {wafer_ids}")
        
        if not recipe_path:
            print("No COMPLUS4T .001 file found")
            return
        
        # Create folders and extract mapping for each wafer
        created_count = 0
        for wafer_id in wafer_ids:
            try:
                # Create subdirectory for this wafer ID (always create, even if no defects)
                wafer_folder = os.path.join(dirname, str(wafer_id))
                os.makedirs(wafer_folder, exist_ok=True)
                
                # Extract positions for this wafer (this will create mapping.csv in the folder)
                coordinates = extract_positions(recipe_path, wafer_id=wafer_id)
                
                if coordinates is not None and len(coordinates) > 0:
                    print(f"  ✓ Wafer {wafer_id}: {len(coordinates)} defects, mapping.csv created")
                    created_count += 1
                else:
                    print(f"  ⚠ Wafer {wafer_id}: No defects found, folder created anyway")
                    created_count += 1  # Count folder creation even if no defects
            except Exception as e:
                print(f"  ✗ Error processing wafer {wafer_id}: {e}")
                import traceback
                traceback.print_exc()
                continue
        
        print("\n" + "="*60)
        print(f"COMPLUS4T ORGANIZATION COMPLETED: {created_count} wafer folders created with mapping.csv")
        print("="*60)
        
        # Show completion message
        if created_count > 0:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setText(f"COMPLUS4T files organized: {created_count} wafer directories created with mapping.csv")
            msg.setWindowTitle("COMPLUS4T Organization Complete")
            msg.exec_()
            
    except Exception as e:
        print(f"Error during COMPLUS4T organization: {e}")
        import traceback
        traceback.print_exc()
        
        # Show error message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during COMPLUS4T organization: {str(e)}")
        msg.setWindowTitle("COMPLUS4T Organization Error")
        msg.exec_()


def organize_sp3_files_automatically(dirname):
    """Organize SP3 files automatically when SP3 is detected."""
    from PyQt5.QtWidgets import QMessageBox
    from semapp.Processing.klarf_reader import extract_wafer_ids_from_sp3, organize_sp3_files
    
    try:
        print("\n" + "="*60)
        print("SP3 DETECTED - Organizing files automatically")
        print("="*60)
        
        # Extract wafer IDs and create directories
        wafer_ids = extract_wafer_ids_from_sp3(dirname)
        
        if wafer_ids:
            print(f"Found {len(wafer_ids)} wafer IDs: {wafer_ids}")
            
            # Organize files into subdirectories
            moved_files = organize_sp3_files(dirname)
            
            print("\n" + "="*60)
            print("SP3 FILE ORGANIZATION COMPLETED")
            print("="*60)
            
            # Show completion message
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setText(f"SP3 files organized: {len(wafer_ids)} wafer directories created")
            msg.setWindowTitle("SP3 Organization Complete")
            msg.exec_()
        else:
            print("No wafer IDs found in SP3 files")
            
    except Exception as e:
        print(f"Error during SP3 organization: {e}")
        import traceback
        traceback.print_exc()
        
        # Show error message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during SP3 organization: {str(e)}")
        msg.setWindowTitle("SP3 Organization Error")
        msg.exec_()


def organize_kronos_files_automatically(dirname):
    """Organize KRONOS files automatically when KRONOS is detected."""
    from PyQt5.QtWidgets import QMessageBox
    
    try:
        print("\n" + "="*60)
        print("KRONOS DETECTED - Organizing files automatically")
        print("="*60)
        
        if not dirname or not os.path.exists(dirname):
            print("Directory not found")
            return
        
        # Find all .001 files in parent directory
        klarf_files = glob.glob(os.path.join(dirname, '*.001'))
        
        if not klarf_files:
            print("No .001 files found in parent directory")
            return
        
        print(f"Found {len(klarf_files)} .001 files to process")
        
        moved_count = 0
        
        for klarf_file in klarf_files:
            try:
                # Check if it's a KRONOS file
                is_kronos = False
                slot_number = None
                tiff_filename = None
                
                with open(klarf_file, 'r', encoding='utf-8', errors='ignore') as f:
                    for line in f:
                        line_stripped = line.strip()
                        
                        # Check for KRONOS
                        if 'KRONOS' in line_stripped or re.search(r'WaferID\s+"Read Failed\.(\d+)"', line_stripped):
                            is_kronos = True
                        
                        # Extract slot number (e.g., "Slot 11;")
                        if line_stripped.startswith("Slot"):
                            slot_match = re.search(r'Slot\s+(\d+)', line_stripped)
                            if slot_match:
                                slot_number = int(slot_match.group(1))
                                print(f"Found slot number: {slot_number} in {os.path.basename(klarf_file)}")
                        
                        # Extract TiffFileName (e.g., 'TiffFileName "AsGa_FAV_2X_WIW_200_2X_REVIEW_03151011.tif";')
                        if line_stripped.startswith("TiffFileName"):
                            tiff_match = re.search(r'TiffFileName\s+"([^"]+)"', line_stripped)
                            if tiff_match:
                                tiff_filename = tiff_match.group(1)
                                print(f"Found TiffFileName: {tiff_filename} in {os.path.basename(klarf_file)}")
                
                # Only process if it's KRONOS and we found slot number
                if is_kronos and slot_number is not None:
                    # Create subdirectory with slot number
                    slot_dir = os.path.join(dirname, str(slot_number))
                    if not os.path.exists(slot_dir):
                        os.makedirs(slot_dir)
                        print(f"Created subdirectory: {slot_dir}")
                    
                    # Move KLARF file to subdirectory
                    klarf_dest = os.path.join(slot_dir, os.path.basename(klarf_file))
                    if not os.path.exists(klarf_dest):
                        shutil.move(klarf_file, klarf_dest)
                        print(f"Moved KLARF file: {os.path.basename(klarf_file)} -> {slot_dir}")
                        moved_count += 1
                    else:
                        print(f"KLARF file already exists in {slot_dir}, skipping move")
                    
                    # Move corresponding TIFF file if found
                    if tiff_filename:
                        # Try to find the TIFF file in parent directory
                        tiff_source = os.path.join(dirname, tiff_filename)
                        if os.path.exists(tiff_source):
                            tiff_dest = os.path.join(slot_dir, tiff_filename)
                            if not os.path.exists(tiff_dest):
                                shutil.move(tiff_source, tiff_dest)
                                print(f"Moved TIFF file: {tiff_filename} -> {slot_dir}")
                                moved_count += 1
                            else:
                                print(f"TIFF file already exists in {slot_dir}, skipping move")
                        else:
                            # Try with .tif extension if .tiff not found
                            tiff_source_tif = os.path.join(dirname, tiff_filename.replace('.tiff', '.tif'))
                            if os.path.exists(tiff_source_tif):
                                tiff_dest = os.path.join(slot_dir, os.path.basename(tiff_source_tif))
                                if not os.path.exists(tiff_dest):
                                    shutil.move(tiff_source_tif, tiff_dest)
                                    print(f"Moved TIFF file: {os.path.basename(tiff_source_tif)} -> {slot_dir}")
                                    moved_count += 1
                                else:
                                    print(f"TIFF file already exists in {slot_dir}, skipping move")
                            else:
                                print(f"Warning: TIFF file not found: {tiff_filename}")
                    else:
                        print(f"Warning: TiffFileName not found in {os.path.basename(klarf_file)}")
                else:
                    if not is_kronos:
                        print(f"Skipping {os.path.basename(klarf_file)} (not KRONOS)")
                    elif slot_number is None:
                        print(f"Skipping {os.path.basename(klarf_file)} (slot number not found)")
            
            except Exception as e:
                print(f"Error processing {os.path.basename(klarf_file)}: {e}")
                import traceback
                traceback.print_exc()
                continue
        
        print("\n" + "="*60)
        print(f"KRONOS FILE ORGANIZATION COMPLETED: {moved_count} files moved")
        print("="*60)
        
        # Show completion message
        if moved_count > 0:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setText(f"KRONOS files organized: {moved_count} files moved to slot subdirectories")
            msg.setWindowTitle("KRONOS Organization Complete")
            msg.exec_()
        
    except Exception as e:
        print(f"Error during KRONOS organization: {e}")
        import traceback
        traceback.print_exc()
        
        # Show error message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during KRONOS organization: {str(e)}")
        msg.setWindowTitle("KRONOS Organization Error")
        msg.exec_()


def launch_detection_automatically(dirname):
    """Launch detection automatically when KRONOS is detected."""
    from semapp.Processing.detection import Detection
    from PyQt5.QtWidgets import QMessageBox
    
    try:
        print("\n" + "="*60)
        print("KRONOS DETECTED - Launching automatic detection")
        print("="*60)
        
        # Initialize detector
        detector = Detection(dirname=dirname)
        
        # Find all subdirectories (1, 2, 3, etc.)
        subdirs = [d for d in os.listdir(dirname) 
                  if os.path.isdir(os.path.join(dirname, d)) and d.isdigit()]
        subdirs.sort(key=lambda x: int(x))
        
        if not subdirs:
            print("No numbered subdirectories found")
            return
        
        print(f"Found {len(subdirs)} subdirectories to process")
        
        # Process each subdirectory
        for subdir in subdirs:
            subdir_path = os.path.join(dirname, subdir)
            csv_path = os.path.join(subdir_path, "detection_results.csv")
            
            # Skip if already processed
            if os.path.exists(csv_path):
                print(f"Skipping {subdir} (already has detection_results.csv)")
                continue
            
            print(f"\nProcessing subdirectory: {subdir}")
            
            # Find TIFF files in subdirectory
            tiff_files = []
            for root, dirs, files in os.walk(subdir_path):
                for file in files:
                    if file.lower().endswith(('.tif', '.tiff')):
                        tiff_files.append(os.path.join(root, file))
            
            if not tiff_files:
                print(f"No TIFF files found in {subdir}")
                continue
            
            # Accumulate all results for this subdirectory
            all_results = {}
            
            # Process each TIFF file
            for tiff_file in tiff_files:
                print(f"  Processing: {os.path.basename(tiff_file)}")
                file_results = detector.detect_numbers_in_tiff(tiff_file, verbose=False)
                
                # Store results with file path as key
                all_results[tiff_file] = file_results
            
            # Save all results to CSV in the subdirectory (once per subdirectory)
            if all_results:
                detector.save_results_to_csv(all_results, csv_path)
                total_pages = sum(len(r) if isinstance(r, list) else 1 for r in all_results.values())
                print(f"  Saved {total_pages} results from {len(all_results)} files to {csv_path}")
            
            print(f"Completed processing {subdir}")
        
        print("\n" + "="*60)
        print("AUTOMATIC DETECTION COMPLETED")
        print("="*60)
        
        # Show completion message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText(f"Automatic detection completed for {len(subdirs)} subdirectories")
        msg.setWindowTitle("Detection Complete")
        msg.exec_()
        
    except Exception as e:
        print(f"Error during automatic detection: {e}")
        import traceback
        traceback.print_exc()
        
        # Show error message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during detection: {str(e)}")
        msg.setWindowTitle("Detection Error")
        msg.exec_()
