import os
import pathlib

BIN_PATH = pathlib.Path(os.path.join(os.path.dirname(__file__), 'bin'))