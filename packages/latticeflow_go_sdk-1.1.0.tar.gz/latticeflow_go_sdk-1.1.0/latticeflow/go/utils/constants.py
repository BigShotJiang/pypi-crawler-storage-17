from __future__ import annotations


SDK_PACKAGE_NAME = "latticeflow-go-sdk"
DEFAULT_PLACEHOLDER_VERSION = "0.0.0.dev0"
API_KEY_HEADER = "X-LatticeFlow-API-Key"
CLIENT_VERSION_HEADER = "X-LatticeFlow-Client-Version"
