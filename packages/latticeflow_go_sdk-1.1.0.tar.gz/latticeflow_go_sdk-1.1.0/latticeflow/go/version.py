__version__ = 'standard'
git_version = '0bf8bbd90ef900ce636576b93a35d26641da65cc'
