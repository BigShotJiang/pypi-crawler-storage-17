class Disconnection(Exception):
    pass
