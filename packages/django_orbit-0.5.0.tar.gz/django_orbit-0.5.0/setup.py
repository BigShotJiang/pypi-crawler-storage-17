"""
Django Orbit - Setup Script (Legacy)

This file is maintained for backwards compatibility.
The primary configuration is in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
