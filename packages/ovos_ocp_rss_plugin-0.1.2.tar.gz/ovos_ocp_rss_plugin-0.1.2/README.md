# OCP RSS Plugin

allows OCP to play rss feeds, the plugin will extract the first playable stream