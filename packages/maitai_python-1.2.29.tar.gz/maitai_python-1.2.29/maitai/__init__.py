from maitai._maitai import Maitai
from maitai._maitai_async import MaitaiAsync

AsyncOpenAI = MaitaiAsync
OpenAI = Maitai

AsyncMaitai = MaitaiAsync
