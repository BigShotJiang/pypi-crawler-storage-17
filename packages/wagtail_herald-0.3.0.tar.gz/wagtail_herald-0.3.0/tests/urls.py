"""
URL configuration for tests.
"""

urlpatterns: list[str] = []
