from mure.core import delete as delete
from mure.core import get as get
from mure.core import head as head
from mure.core import patch as patch
from mure.core import post as post
from mure.core import put as put
