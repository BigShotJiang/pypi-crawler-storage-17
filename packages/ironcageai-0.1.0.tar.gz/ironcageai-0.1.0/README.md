# Module :: ironcageai

AI and machine learning utilities built on the ironcage framework

<!--
### Basic use-case

```python
from ironcageai import f1

def main():
  f1()
```

### To add to your project

```bash
uv add ironcageai
```

### Try out from the repository

```shell
git clone <repository>
cd <repository>
uv sync
uv run python -m ironcageai
```
-->

### Sample

<!-- Add usage examples here -->
