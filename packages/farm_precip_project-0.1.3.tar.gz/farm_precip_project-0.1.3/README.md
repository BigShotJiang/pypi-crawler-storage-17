# FarmPrecipProject

We use moisture level data, and yearly income data across states to determine how different states are impacted by different moisture levels.
This analysis is turned into a package that can be installed and replicated by others.
We also included a streamlit app for a live dashboard.
Find out more on our [website](https://acodea23.github.io/FarmPrecipProject/)
