"""
PyWATS MCP Server - Model Context Protocol server for WATS API.

Allows AI assistants to interact with WATS manufacturing test data.
"""

__version__ = "0.1.0"
