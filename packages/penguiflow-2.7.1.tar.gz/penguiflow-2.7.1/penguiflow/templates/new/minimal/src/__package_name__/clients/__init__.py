"""Client stubs for {{ project_name }}."""
