"""Client stubs for external services."""
