"""Tests for lighthouse template."""
