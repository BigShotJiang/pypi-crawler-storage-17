# My Text Package

This package contains a text file uploaded to PyPI.