#! /usr/bin/env python3
# -*- coding: utf-8 -*-
"""
# File          : log
# Author        : Sun YiFan-Movoid
# Time          : 2024/7/31 0:41
# Description   : 
"""


class DebugLog:
    pass
