APP_NAME = "gui_library"
