# Base Python Project Structure

This python project is a template for creating new python projects with my preferences baked into the project.
