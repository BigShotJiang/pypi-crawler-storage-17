.. _check_finish:

Check finish of a control event
=================================

Coming soon... 
