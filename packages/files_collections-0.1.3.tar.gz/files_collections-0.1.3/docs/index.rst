FCollections
============

.. toctree::
    :caption: Files Collection

    install
    getting_started
    custom

.. toctree::
    :caption: Implementations

    implementations/catalog
    implementations/l2_lr_ssh
    implementations/l3_lr_ssh

.. toctree::
    :caption: Utilities

    auxiliary

.. toctree::
    :caption: Advanced
    :maxdepth: 1

    api
    changelog
