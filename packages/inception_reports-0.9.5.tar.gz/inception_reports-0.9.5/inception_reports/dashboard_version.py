# This file is auto-generated. Do not edit manually.
DASHBOARD_VERSION = "0.9.5"