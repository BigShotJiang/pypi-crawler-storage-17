"""Honeybee Grasshopper Core Component Source Code."""
