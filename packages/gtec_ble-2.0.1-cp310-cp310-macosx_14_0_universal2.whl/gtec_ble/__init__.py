# get version
from .__version__ import __version__

# allow lazy loading
from .amplifier import Amplifier
