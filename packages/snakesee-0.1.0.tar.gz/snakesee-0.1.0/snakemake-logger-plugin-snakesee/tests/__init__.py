"""Tests for snakemake-logger-plugin-snakesee."""
