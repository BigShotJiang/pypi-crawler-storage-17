"""Integration tests for snakesee with real Snakemake workflows."""
