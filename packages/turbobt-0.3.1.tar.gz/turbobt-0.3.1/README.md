# turbobt
A next generation Bittensor SDK, for Python 3.

# Releasing

Building and deploying to pypi is done via Gtihub Actions. To release a new version do:

```
git tag vX.Y.Z
git push origin vX.Y.Z
```
