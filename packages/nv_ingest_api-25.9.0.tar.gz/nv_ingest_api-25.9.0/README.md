# nv-ingest-api

Provides a common set of

- Pythonic Objects
- Common Functions
- Utilities
- Core Logic

Implemented in pure Python that can be imported and used directly or used as part of future frameworks and runtimes.
