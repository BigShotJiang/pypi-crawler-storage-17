# ##################################################################
# 
# Copyright 2021 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Saroop Samra (Saroop.Samra@teradata.com)
# Secondary Owner: 
# 
# ################################################################## 

version = "20.00.00.07"
