# -*- coding: utf-8 -*-
'''
Copyright © 2024 by Teradata.
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Primary Owner: Saroop Samra (saroop.samra@teradata.com)
Secondary Owner: 
'''


from teradatamlwidgets.feature_store.UiImpl import _UiImpl


class Ui:
    """
    The teradatamlwidgets Interactive Feature Store UI.
    """

    def __init__(
        self,
        default_database="", 
        connection=None):
        """
        DESCRIPTION:
            Constructor for teradatamlwidgets Interactive AutoML UI.

        PARAMETERS:
            
            connection: 
                Optional Argument. 
                Specifies the specific connection; could be teradataml based (i.e. TeradatamlConnection instance) or another platform.

            default_database: 
                Optional Argument. 
                Specifies the default database. 
                Types: str

        RETURNS:
            Instance of the UI class.

        RAISES:
            None.

        EXAMPLE:
        >>> from teradatamlwidgets.auto_ml.Ui import * 
        >>> ui=Ui(task="Classification", training_table="titanic_training", predict_table="titanic_testing")

        """
        
        self._ui_impl=_UiImpl(
                        default_database=default_database, 
                        connection=connection)

    def get_data(self, process_id=None, entity=None, features=None,
                 dataset_name=None, as_of=None, include_historic_records=False):
        """
        DESCRIPTION:
            Returns teradataml DataFrame which has entities and feature values.
            Method generates dataset from following -
            * process_id
            * entity and features
            * dataset_name

        PARAMETERS:
            process_id:
                Optional Argument.
                Either "process_id", "entity" and "features", "dataset_name" is mandatory.
                Specifies the process id of an existing feature process.
                Types: str

            entity:
                Optional Argument.
                Specifies the name of the Entity or Object of Entity
                to be considered in the dataset.
                Types: str or Entity.

            features:
                Optional Argument.
                Specifies the names of Features and the corresponding feature version
                to be included in the dataset.
                Notes:
                     * Key is the name of the feature and value is the version of the
                       feature.
                     * Look at FeatureCatalog.list_feature_versions() to get the list of
                       features and their versions.
                Types: dict

            dataset_name:
                Optional Argument.
                Specifies the dataset name.
                Types: str

            as_of:
                Optional Argument.
                Specifies the time to retrieve the Feature Values instead of
                retrieving the latest values.
                Notes:
                    * Applicable only when "process_id" is passed to the function.
                    * Ignored when "dataset_name" is passed.
                Types: str or datetime.datetime

            include_historic_records:
                Optional Argument.
                Specifies whether to include historic data in the dataset.
                Note:
                    * If "as_of" is specified, then the "include_historic_records" argument is ignored.
                Default Value: False.
                Types: bool.


        RETURNS:
            teradataml DataFrame.

        RAISES:
            TeradataMLException
        """
        return self._ui_impl._get_data(process_id=process_id, entity=entity, features=features,
                 dataset_name=dataset_name, as_of=as_of, include_historic_records=include_historic_records)
    

