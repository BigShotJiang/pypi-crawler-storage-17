# -*- coding: utf-8 -*-
'''
Copyright © 2024 by Teradata.
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Primary Owner: Saroop Samra (saroop.samra@teradata.com)
Secondary Owner: 
'''

import os
import sys
import json
from pathlib import Path
import ipywidgets as widgets
import IPython
from IPython.display import clear_output, HTML, Javascript, display
import pandas as pd
from teradataml import *
from teradataml.dataframe.dataframe import execute_sql
from teradataml import FeatureStore
from teradataml.common.utils import UtilFuncs
from teradatamlwidgets.custom_destroy_button import *
from teradatamlwidgets.base_ui import _BaseUi
import traceback

class _UiImpl(_BaseUi):
    def __init__(self,
        default_database = "",
        connection = None):
        """
        DESCRIPTION:
            Constructor for private class that implements teradatamlwidgets Feature Store UI.

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """

        self.fs = None
        self._javascript_callbacks_enabled = True

        self._df_current_data_table = None
        self.mind_map_output = widgets.Output(layout=widgets.Layout(width='100%', height='50%'))
            
        _BaseUi.__init__(self, default_database=default_database, connection=connection)
        if self._connection.is_logged_in():
            try:
                self._show_display(self._loading_bar, True)
                self.repo_arr = (FeatureStore.list_repos()).get_values()
                self.flattened_list = self.repo_arr.flatten().tolist()
                self._create_ui()
                self._open_ui()
            except Exception as e:
                self._show_error_message(str(e))
                self.last_error = traceback.format_exc()

    def _handle_js_event(self, event):
        """
        DESCRIPTION:
            Private function that extracts relevant information from the event dictionary.

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        self.event = event
        event_type = event.get('type', 'Unknown Event')
        key_info = event.get('key', 'N/A')
        button_info = event.get('button', 'N/A')
        x_coord = event.get('x', 'N/A')
        y_coord = event.get('y', 'N/A')
        self.status_widget.clear_output(wait=True)
        
        identifier = event.get('target').get('id')
        if identifier.startswith("btn_"):
            if identifier == "btn_add_feature_process":
                self._on_show_feature_clicked()
            elif identifier == "btn_add_data_catalog":
                self._on_show_data_catalog_clicked()
            elif identifier == "btn_back_td_fs":
                self._on_home_clicked()
            return

        self.status_widget.clear_output(wait=True)
        
        if not identifier.startswith("span_"):
            with self.status_widget:
                print("")
            return

        # eg span_Mar_fs_1754239091_054635_feature-box
        index_end = identifier.rindex("_")
        node_type = identifier[index_end+1:]
        index = identifier.index("_fs_")
        feature_store_id = identifier[index+1:index_end]
        name = identifier[5:index]

        with self.status_widget:
            IPython.display.display(self._loading_bar)
        
        df = None
        try:
            if node_type == "fp-box":
                df = self._get_data(process_id=name)
            elif node_type == "feature-box":
                feature_catalog = FeatureCatalog(repo=self.repo.value, data_domain=self.initial_data_domain.value)
                df = feature_catalog.list_feature_versions()
            elif node_type == "dataset-box":
                df = self._get_data(dataset_name=name)
            else:
                df = DataFrame(name)
        except:
            df = None
        self._df_current_data_table = df
        if df is not None:
            html_value = df.to_pandas().to_html(index=False)
            html_value = html_value.replace('<tr style="text-align: right;">', '<tr>')
            html_value = html_value.replace('class="dataframe"', 'style="width:100%; border-collapse: collapse; border:none;"')
            html_value = html_value.replace('border="1"', '')
            html_value = html_value.replace('<th>', '<th style="min-width:250px;border:none;text-align: left;">')
            html_value = html_value.replace('<td>', '<td style="border:none;">')
            html_value = html_value.replace('<tr>', '<tr style="min-width:250px;border-bottom: 1px solid black; border-bottom-color: #dcdcdc;">')
        else:
             html_value = ""

        self.explore_eda_button = widgets.Button(
                    description='Explore Further',
                    disabled=False,
                    tooltip='Explore the data further',
                    layout= widgets.Layout(border = '2px solid green'),
                    style={'button_color' : 'green', 'text_color' : 'white'}
                )
        show_table_ui = False
        if show_table_ui or df is None:
            table_ui = widgets.HTML(html_value)
        self.status_widget.clear_output(wait=True)
        try:
            with self.status_widget:
                if show_table_ui or df is None:
                    IPython.display.display(table_ui)
                elif df is not None:
                    IPython.display.display(df)
                # print("Name=", name, "Type=", node_type, "ID=", feature_store_id) 
        except Exception as e:
            return

    def _update_mind_map_ui(self):
        """
        DESCRIPTION:
            Private function that updates the mind map based on the Event.

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        if self._javascript_callbacks_enabled:
            from ipyevents import Event

            self.html = self.fs._get_mind_map_html()

            indexStart = self.html.index("<script>")
            
            self.js = self.html[indexStart:];
            self.html = self.html[:indexStart];

            # Show the extra UI buttons
            exta_ui_css = ".extra_ui { display : inline; background-color:lightgray;\n border: 3px solid lightgray; }\n"
            exta_ui_css += ".extra_ui:hover {background-color:lightgray;\n border: 3px solid purple !important; }\n"
            self.html = self.html.replace(".extra_ui { display : none; }", exta_ui_css)

            IPython.display.clear_output(wait=True)

            self.mind_map_ui = widgets.HTML(self.html)
            self.status_widget = widgets.Output()
            
            with self._widget_output:
                IPython.display.display(self.mind_map_ui, self.status_widget, IPython.display.HTML(self.js))
            
            self.js_event = Event(source=self.mind_map_ui, watched_events=['click'])
            self.js_event.on_dom_event(lambda event: self._handle_js_event(event))
            
            
        else:
            with self.mind_map_output:
                clear_output()
                self.fs.mind_map()

    def _show_mindmap_page(self):
        """
        DESCRIPTION:
            Private function that sets the current UI to the home page mind map UI. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        self.current_ui = self.homepage_map_ui
        self._show_display(self.homepage_map_ui, True)
        self._update_mind_map_ui()

    def _open_ui(self):
        """
        DESCRIPTION:
            Private function that opens the teradatamlwidgets Feature Store UI. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        self._show_display(self.current_ui, True)

    def _on_open_clicked(self):
        """
        DESCRIPTION:
            Private function that is called when the open button is clicked. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        try:
            self._show_display(self._loading_bar, True)
            self.fs = FeatureStore(repo=self.repo.value, data_domain=self.initial_data_domain.value)
            self.fs.setup()
            self._create_main_ui()
            self._show_mindmap_page()
        except Exception as e:
            self.current_ui = self.feature_store_ui
            self._show_error_message(str(e))
            self.last_error = traceback.format_exc()

    def _on_create_repo_clicked(self):
        """
        DESCRIPTION:
            Private function that is called when the create new repo button is clicked. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        try:
            self.repo_name = widgets.Text(
                placeholder='Type a repo name',
                description='Repo Name:',
                disabled=False,
                style = {'description_width': 'initial'},
                tooltip="Specifies the repository name."
            )
            self.data_domain_name = widgets.Text(
                placeholder='Type a data domain name',
                description='Data Domain:',
                disabled=False,
                style = {'description_width': 'initial'},
                tooltip="Specifies the data domain to which FeatureStore points to."
            )
            self.check = widgets.Checkbox(
                value=False,
                description='Check Existence of DB objects',
                disabled=False,
                indent=False,
                tooltip="Specifies whether to check the existence of all the DB objects or not."
            )
            self.perm_size = widgets.Text(
                placeholder='Type a data domain name',
                description='Perm Size:',
                value="10e9",
                disabled=False,
                style = {'description_width': 'initial'},
                tooltip="Specifies the number of bytes to allocate to FeatureStore repo for permanent space."
            )
            self.spool_size = widgets.Text(
                placeholder='Type a data domain name',
                description='Spool Size:',
                value="10e8",
                disabled=False,
                style = {'description_width': 'initial'},
                tooltip="Specifies the number of bytes to allocate to FeatureStore repo for spool space."
            )
            self.grant_access = widgets.Text(
                placeholder='Enter user to grant access to',
                description='Grant Access:',
                value="",
                disabled=False,
                style = {'description_width': 'initial'},
                tooltip="Grants read_write access to user on repository."
            )
            self.run_repo_button = widgets.Button(
                    description='Run',
                    disabled=False,
                    tooltip='Run new Feature Store repo',
                    layout= widgets.Layout(border = '2px solid green'),
                    style={'button_color' : 'green', 'text_color' : 'white'}
                )
            self.run_repo_button.on_click(lambda x : self._on_run_repo_clicked())
            
            back_button = widgets.Button(
                    icon="solid fa-lg arrow-left",
                    disabled=False,
                    tooltip='Return back to previous screen',
                    layout= widgets.Layout(width='40px', height='30px', border = '2px solid #e3eaf2'),
                    style={'button_color' : '#f7fafd', 'text_color' : 'black'}
                )
            back_button.on_click(lambda x : self._on_home_clicked())

            self._show_display(self._loading_bar, True)
            self.top_widgets = widgets.HBox([back_button])
            self.bottom_widgets = widgets.HBox([widgets.VBox([self.repo_name, self.data_domain_name, self.check, self.run_repo_button]), widgets.VBox([self.perm_size, self.spool_size, self.grant_access])])
            self.new_repo_ui = widgets.VBox([self.top_widgets, self.bottom_widgets])
            #self.current_ui = self.new_repo_ui
            self._show_display(self.new_repo_ui, True)
        except Exception as e:
            self.current_ui = self.new_repo_ui
            self._show_error_message(str(e))
            self.last_error = traceback.format_exc()

    def _on_run_repo_clicked(self):
        """
        DESCRIPTION:
            Private function that runs the code to create new repo. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        try:
            if self.data_domain_name.value != "":
                fs = FeatureStore(self.repo_name.value, data_domain=self.data_domain_name.value)
                fs.setup(perm_size = self.perm_size.value, spool_size = self.spool_size.value)

            else:
                fs = FeatureStore(self.repo_name.value)
                fs.setup(perm_size = self.perm_size.value, spool_size = self.spool_size.value)


            # if parameter for granting access is not empty then grant read_write access to that user
            if self.grant_access.value != "":
                fs.grant.read_write(self.grant_access.value)

            self._on_home_clicked()

        except Exception as e:
            self.current_ui = self.new_repo_ui
            self._show_error_message(str(e))
            self.last_error = traceback.format_exc()

    def _create_ui(self):
        """
        DESCRIPTION:
            Private function that creates the first page of UI with repo and data domain. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        self.repo = widgets.Combobox(
            placeholder='Select a repo',
            options=self.flattened_list,
            description='Repo:',
            ensure_option=True,
            disabled=False
        )
        #try:
        #    table_name = UtilFuncs._extract_table_name(self.df._table_name)
        #except:
        #    table_name = ""

        self.initial_data_domain = widgets.Text(
            value="",
            placeholder='Type something',
            description='Data Domain:',
            style = {'description_width': 'initial'},
            disabled=False   
        )
        self.open_button = widgets.Button(
            description='Open',
            disabled=False,
            layout= widgets.Layout(width='auto', height='30px', border = '2px solid #e3eaf2'),
            style={'button_color' : '#f7fafd', 'text_color' : 'black'},
            tooltip='Open Feature Store'
        )
        self.create_repo_button = widgets.Button(
            description='Create New',
            disabled=False,
            layout= widgets.Layout(width='auto', height='30px', border = '2px solid #e3eaf2'),
            style={'button_color' : '#f7fafd', 'text_color' : 'black'},
            tooltip='Create new Feature Store repo'
        )

        self.left_feature_store_ui = widgets.VBox([self.repo, self.initial_data_domain])
        self.feature_store_ui = widgets.HBox([self.left_feature_store_ui, widgets.VBox([self.open_button, self.create_repo_button])])
        self.open_button.on_click(lambda x : self._on_open_clicked())
        self.create_repo_button.on_click(lambda x : self._on_create_repo_clicked())
        self.current_ui = self.feature_store_ui

    def _on_home_clicked(self):
        """
        DESCRIPTION:
            Private function that is called when the home button is clicked, which takes UI back to previous screen. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        self._show_current_ui(self.feature_store_ui, True)

    def _on_feature_run_clicked(self):
        """
        DESCRIPTION:
            Private function that is called when the Feature Process run button is clicked, which creates a FeatureProcess. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        try:
            self._show_display(self._loading_bar, True)
            if self.fp_description.value != '':
                fp = FeatureProcess(repo=self.repo.value, 
                    data_domain=self.data_domain.value, 
                    object=DataFrame(self.data_source.value), 
                    features=list(self.fp_features.value), 
                    entity=self.fp_entity.value,
                    description=self.fp_description.value)
            else:
                fp = FeatureProcess(repo=self.repo.value, 
                    data_domain=self.data_domain.value, 
                    object=DataFrame(self.data_source.value), 
                    features=list(self.fp_features.value), 
                    entity=self.fp_entity.value)
            fp.run()
            self._show_mindmap_page()
        except Exception as e:
            self.current_ui = self.feature_ui
            self._show_error_message(str(e))
            self.last_error = traceback.format_exc()

    def _on_data_frame_change(self, change):
        """
        DESCRIPTION:
            Private function that is called when the dataframe parameter is updated, which accordingly sets the feature and entity column options. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        if change.get("name") != "value":
            return
        try:
            # for view it should not put in "DataFrame()"
            input_str = self.data_source.value
            self.df = DataFrame(input_str)
            
            self.fp_features.options = self.df.columns
            self.fp_features.value = [self.df.columns[0]]

            self.fp_entity.options = self.df.columns
            self.fp_entity.value = self.df.columns[0]

            self.data_source.layout.border = '' 
            
        except Exception as e:
            self.data_source.layout.border = '2px solid red' 
            return

    def _format_table_html(self, html_value):
        html_value = html_value.replace('<tr style="text-align: right;">', '<tr>')
        html_value = html_value.replace('class="dataframe"', 'style="width:100%; border-collapse: collapse; border:none;"')
        html_value = html_value.replace('border="1"', '')
        html_value = html_value.replace('<th>', '<th style="min-width:250px;border:none;text-align: left;">')
        html_value = html_value.replace('<td>', '<td style="border:none;">')
        html_value = html_value.replace('<tr>', '<tr style="min-width:250px;border-bottom: 1px solid black; border-bottom-color: #dcdcdc;">')
        return html_value

    def _update_feature_stack(self, selected_index):
        """
        DESCRIPTION:
            Private function that updates the feature process button stack. 

        PARAMETERS:
            selected_index
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        try:
            self.features_stack.selected_index = selected_index
            for index in range(len(self.feature_buttons)):
                if index == selected_index:
                    self.feature_buttons[index].layout = widgets.Layout(height='50px', border_bottom='4px #c76aa0 solid')
                else:
                    self.feature_buttons[index].layout = widgets.Layout(height='50px')
            if selected_index == 0 and self.df_feature_list is None:
                self._show_display(self._loading_bar, True)
                self.df_feature_list = self.fs.list_features()
                df = self.df_feature_list.to_pandas()
                keyword = self.features_search_text_ui.value
                if keyword != "" and len(self.features_search_tag.value)>0:
                    contains_keyword_in_row = None
                    for column_name in self.features_search_tag.value:
                        if contains_keyword_in_row is None:
                            contains_keyword_in_row = df[column_name].str.contains(keyword, case=False, na=False)
                        else:
                            contains_keyword_in_row = contains_keyword_in_row | df[column_name].str.contains(keyword, case=False, na=False)
                    df = df[contains_keyword_in_row]
                html_value = df.to_html(index=False)
                html_value = self._format_table_html(html_value)
                self.features_html_ui.value = html_value
                self._show_display(self.feature_ui, True)

            elif selected_index == 1 and self.df_entities_list is None:
                self._show_display(self._loading_bar, True)
                self.df_entities_list = self.fs.list_entities()
                df = self.df_entities_list.to_pandas()
                keyword = self.entities_search_text_ui.value
                if keyword != "" and len(self.entities_search_tag.value)>0:
                    contains_keyword_in_row = None
                    for column_name in self.entities_search_tag.value:
                        if contains_keyword_in_row is None:
                            contains_keyword_in_row = df[column_name].str.contains(keyword, case=False, na=False)
                        else:
                            contains_keyword_in_row = contains_keyword_in_row | df[column_name].str.contains(keyword, case=False, na=False)
                    df = df[contains_keyword_in_row]
                html_value = df.to_html(index=False)
                html_value = self._format_table_html(html_value)
                self.entities_html_ui.value = html_value
                self._show_display(self.feature_ui, True)

        except Exception as e:
            self._show_error_mind_map(str(e))
            self.last_error = traceback.format_exc()

    def _on_create_view_clicked(self):
        """
        DESCRIPTION:
            Private function that creates a new view. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """     
        try:
            self._show_display(self._loading_bar, True)

            # Execute the query
            query = "CREATE VIEW " + self.view_name.value + " AS " + self.view_query.value 

            if ";" not in query:
                query += ";"

            result_df = execute_sql(query)
            
            self.data_source.value = self.view_name.value
            change = {}
            change['name'] = 'value'
            self._on_data_frame_change(change)

            self._show_display(self.feature_ui, True)
        except Exception as e:
            self.current_ui = self.create_view_ui
            self._show_error_message(str(e))
            self.last_error = traceback.format_exc()

    def _show_create_view_page(self):
        """
        DESCRIPTION:
            Private function that is called when user wants to create a view. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        try:
            self.view_name = widgets.Text(
                value="",
                disabled=False,
                placeholder='Enter view name',
                layout= widgets.Layout(width="95%")
            )

            self.view_query = widgets.Textarea(
                value="",
                disabled=False,
                placeholder='Enter query e.g.\nSELECT * FROM Customer',
                layout= widgets.Layout(width="95%", height="200px")
            )

            self.create_view = widgets.Button(
                description='Create',
                button_style='success', # 'success', 'info', 'warning', 'danger' or ''
                disabled=False,
                tooltip='Create the view'
            )

            self.create_view.on_click(lambda x : self._on_create_view_clicked())

            self.cancel_create = widgets.Button(
                description='Cancel',
                disabled=False,
                button_style='', # 'success', 'info', 'warning', 'danger' or ''
                tooltip='Cancel create view and return'
            )

            self.cancel_create.on_click(lambda x : self._on_show_feature_clicked())

            self.create_view_ui = widgets.VBox([ self.view_name, self.view_query, widgets.HBox([self.create_view, self.cancel_create])])
            self._show_display(self.create_view_ui, True)

        except Exception as e:
            self._show_error_message(str(e))
            self.last_error = traceback.format_exc() 


    def _make_search_table_ui(self, default_options, all_options):
        """
        DESCRIPTION:
            Private function that is common code for the search box UI for all the tables.

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            The UI elements: search_table_ui, search_text_ui, do_search_ui, html_ui, column_tags
        """
        html_ui = widgets.HTML("")
        search_text_ui = widgets.Text(
            value='',
            description='Search',
            placeholder='',
            layout= widgets.Layout(width="40%"))
        do_search_ui = widgets.Button(
            icon="solid search",
            disabled=False,
            layout= widgets.Layout(width='35px', height='30px', border = '2px solid #e3eaf2'),
            style={'button_color' : '#f7fafd', 'text_color' : 'black'},
            tooltip='Search'
        )
        column_tags = widgets.TagsInput(
            value=default_options,
            allowed_tags=all_options,
            layout= widgets.Layout(width='500px', border = '2px solid #e3eaf2'),
            allow_duplicates=False
        )
        do_search_ui.on_click(lambda x : update_feature_search())
        search_table_ui = widgets.VBox([widgets.HBox([search_text_ui, do_search_ui, column_tags]), html_ui])
        return search_table_ui, search_text_ui, do_search_ui, html_ui, column_tags

    def _on_show_feature_clicked(self):
        """
        DESCRIPTION:
            Private function that is called when feature process button is clicked, showing the UI for Features, Entities, Create. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        try:
            # If there is value for initial data domain
            if self.initial_data_domain.value != '':
                self.df = DataFrame(self.initial_data_domain.value)

                self.fp_features = widgets.SelectMultiple(
                    options=self.df.columns,
                    value=[self.df.columns[0]],
                    disabled=False
                )
                self.fp_entity = widgets.Select(
                    options=self.df.columns,
                    value=self.df.columns[0],
                    disabled=False
                )
                self.data_domain = widgets.Text(
                    description='Data Domain',
                    value=self.initial_data_domain.value,
                    disabled=True,
                    layout= widgets.Layout(width="95%")
                )
            # If there is no value for initial data domain
            else:
                self.fp_features = widgets.SelectMultiple(
                    disabled=False
                )
                self.fp_entity = widgets.Select(
                    disabled=False
                )
                self.data_domain = widgets.Text(
                    description='Data Domain',
                    value=self.initial_data_domain.value,
                    disabled=False,
                    layout= widgets.Layout(width="95%")
                )
            
            self._show_display(self._loading_bar, True)

            #table_name = UtilFuncs._extract_table_name(self.df._table_name)

            
            self.data_source = widgets.Text(
                value="",
                description='Data Source',
                disabled=False,
                layout= widgets.Layout(width="95%")
            )

            self.run_feature_button = widgets.Button(
                description='Run',
                disabled=False,
                tooltip='Run Feature Process',
                layout= widgets.Layout(border = '2px solid #c76aa0'),
                style={'button_color' : '#f2d6e6', 'text_color' : 'black'}
            )

            self.create_view_button = widgets.Button(
                description='Create View...',
                disabled=False,
                layout= widgets.Layout(border = '2px solid #c76aa0'),
                style={'button_color' : '#f2d6e6', 'text_color' : 'black'},
                tooltip='Allows you to create new view'
            )
            self.create_view_button.on_click(lambda x : self._show_create_view_page())
            
            self.run_feature_button.on_click(lambda x : self._on_feature_run_clicked())

            self.data_source.observe(lambda change : self._on_data_frame_change(change))


            self.fp_description = widgets.Text(
                value='',
                description='Description',
                placeholder='',
                layout= widgets.Layout(width="95%")
            )

            contents = widgets.HBox([
                widgets.VBox([widgets.Label("Features:"), self.fp_features]), 
                widgets.VBox([widgets.Label("Entity:"), self.fp_entity])])

            self.add_feature_ui = widgets.VBox([self.data_domain, self.data_source, self.fp_description, contents, widgets.HBox([self.run_feature_button]) ])


            self.df_feature_list = None
            self.features_ui, self.features_search_text_ui, do_search_ui, self.features_html_ui, self.features_search_tag = self._make_search_table_ui(default_options= ['column_name', 'description', 'tags'], all_options = ['column_name', 'description', 'tags', 'data_type', 'feature_type', 'status', 'creation_time', 'modified_time', 'group_name'])
            def update_feature_search():
                """
                DESCRIPTION:
                    Private function that is called to update to a filtered list for features.

                PARAMETERS:
                    None.
                
                RAISES:
                    None.

                RETURNS:
                    None.
                """
                self.df_feature_list = None
                self._update_feature_stack(0)
            do_search_ui.on_click(lambda x : update_feature_search())
            
            self.df_entities_list = None
            self.entities_ui, self.entities_search_text_ui, do_search_ui, self.entities_html_ui, self.entities_search_tag = self._make_search_table_ui(default_options= ['description', 'entity_column'], all_options = ['description', 'creation_time', 'modified_time', 'entity_column'])
            def update_entities_search():
                """
                DESCRIPTION:
                    Private function that is called to update to a filtered list for entities.

                PARAMETERS:
                    None.
                
                RAISES:
                    None.

                RETURNS:
                    None.
                """
                self.df_entities_list = None
                self._update_feature_stack(1)
            do_search_ui.on_click(lambda x : update_entities_search())


            back_button = widgets.Button(
                icon="solid home",
                disabled=False,
                tooltip='Return back to previous screen',
                layout= widgets.Layout(width='50px', height='50px', border = '2px solid #e3eaf2'),
                style={'button_color' : '#f7fafd', 'text_color' : 'black'}
            )
            back_button.on_click(lambda x : self._show_mindmap_page())

            self.feature_buttons = []

            self.feature_buttons.append(widgets.Button(
                description='Features',
                disabled=False,
                style={'button_color' : 'transparent', 'font_weight' : 'bold'},
                layout= widgets.Layout(height='50px'),
                tooltip='View Features'
            ))
            self.feature_buttons.append(widgets.Button(
                description='Entities',
                disabled=False,
                style={'button_color' : 'transparent', 'font_weight' : 'bold'},
                layout= widgets.Layout(height='50px'),
                tooltip='View Entities'
            ))
            self.feature_buttons.append(widgets.Button(
                description='Create',
                disabled=False,
                style={'button_color' : 'transparent', 'font_weight' : 'bold'},
                layout= widgets.Layout(height='50px'),
                tooltip='Add Feature Process'
            ))

            self.feature_buttons[0].on_click(lambda x : self._update_feature_stack(0))
            self.feature_buttons[1].on_click(lambda x : self._update_feature_stack(1))
            self.feature_buttons[2].on_click(lambda x : self._update_feature_stack(2))
            
            selected_index = self.features_stack.selected_index if hasattr(self, 'features_stack') else 0
            self.features_stack = widgets.Stack([self.features_ui, self.entities_ui, self.add_feature_ui], selected_index = selected_index)
            self.feature_ui = widgets.VBox([ widgets.HBox([back_button, self.feature_buttons[0], self.feature_buttons[1], self.feature_buttons[2]]), self.features_stack])
            self._update_feature_stack(selected_index)

            self._show_display(self.feature_ui, True)
        except Exception as e:
            self._show_error_mind_map(str(e))
            self.last_error = traceback.format_exc()

    def _on_data_source_change(self, change):
        """
        DESCRIPTION:
            Private function that is called when the data source is changes, which updates the feature options. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        if change.get("name") != "value":
            return

        # Update the Entity Columns
        try:
            data_source_index = self.data_id_options.options.index(self.data_id_options.value)
            entity_df_name = self.grouped_data["data_plus_id"][data_source_index].split('"')[1]
            entity_df = DataFrame(entity_df_name)
        except:
            entity_df = self.df
        self.entity.options = entity_df.columns
        self.entity.value = entity_df.columns[0]
    
        # 1) pull the raw cell
        raw = self.grouped_data.loc[
            self.grouped_data["data_plus_id"] == change["new"],
            "feature_names"].iloc[0]
    
        # 2) normalize to a flat list of strings
        items = []
        if isinstance(raw, str):
            items = [tok.strip() for tok in raw.split(",") if tok.strip()]
    
        elif isinstance(raw, list):
            # each element might be a string of items or an atomic item
            for elt in raw:
                if isinstance(elt, str) and "," in elt:
                    # split comma-strings inside a list
                    items += [tok.strip() for tok in elt.split(",") if tok.strip()]
                else:
                    # plain item
                    items.append(str(elt))
        else:
            # fallback: single value
            items = [str(raw)]
    
        # 3) update the widget with unique items
        unique_items = sorted(set(items))  # optional: sort alphabetically
        self.feature_options.options = unique_items
        self.feature_options.value   = unique_items[0] if unique_items else None
        

    def _on_data_run_clicked(self):
        """
        DESCRIPTION:
            Private function that is called when the Dataset Catalog run button is clicked. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        try:
            self._show_display(self._loading_bar, True)
            process_id = self.data_id_options.value
            start = process_id.find('(')
            end = process_id.find(')', start)
            
            if start != -1 and end != -1:
                result = process_id[start+1:end]
                
            # CODE TO ADD NEW DATA CATALOG
            dc = self.fs.get_dataset_catalog()
            if self.dc_description.value != '':
                dataset_params = dc.build_dataset(entity=self.entity.value, 
                                                  selected_features={self.feature_options.value: result},
                                                  view_name=self.view_name.value,
                                                  description=self.dc_description.value)
            else:
                dataset_params = dc.build_dataset(entity=self.entity.value, 
                                                  selected_features={self.feature_options.value: result},
                                                  view_name=self.view_name.value)
            self._show_mindmap_page()
        except Exception as e:
            self.current_ui = self.dataset_catalog_ui
            self._show_error_message(str(e))
            self.last_error = traceback.format_exc()

    def _update_dataset_catalog_stack(self, selected_index):
        """
        DESCRIPTION:
            Private function that updates the dataset catalog button stack. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        try:
            self.dataset_catalog_stack.selected_index = selected_index
            for index in range(len(self.dataset_catalog_buttons)):
                if index == selected_index:
                    self.dataset_catalog_buttons[index].layout = widgets.Layout(height='50px', border_bottom='4px #6ac7a0 solid')
                else:
                    self.dataset_catalog_buttons[index].layout = widgets.Layout(height='50px')
            if selected_index == 0 and self.dc_dataset_list is None:
                self._show_display(self._loading_bar, True)
                dc = self.fs.get_dataset_catalog()
                self.dc_dataset_list = dc.list_datasets()
                df = self.dc_dataset_list.to_pandas()
                keyword = self.dc_datasets_search_text_ui.value
                if keyword != "" and len(self.datasets_search_tag.value)>0:
                    contains_keyword_in_row = None
                    for column_name in self.datasets_search_tag.value:
                        if contains_keyword_in_row is None:
                            contains_keyword_in_row = df[column_name].str.contains(keyword, case=False, na=False)
                        else:
                            contains_keyword_in_row = contains_keyword_in_row | df[column_name].str.contains(keyword, case=False, na=False)
                    df = df[contains_keyword_in_row]
                html_value = df.to_html(index=False)
                html_value = self._format_table_html(html_value)
                self.dc_datasets_html_ui.value = html_value
                self._show_display(self.dataset_catalog_ui, True)
            elif selected_index == 1 and self.dc_entities_list is None:
                self._show_display(self._loading_bar, True)
                dc = self.fs.get_dataset_catalog()
                self.dc_entities_list = dc.list_entities()
                df = self.dc_entities_list.to_pandas()
                keyword = self.dc_entities_search_text_ui.value
                if keyword != "" and len(self.dc_entities_search_tag.value)>0:
                    contains_keyword_in_row = None
                    for column_name in self.dc_entities_search_tag.value:
                        if contains_keyword_in_row is None:
                            contains_keyword_in_row = df[column_name].str.contains(keyword, case=False, na=False)
                        else:
                            contains_keyword_in_row = contains_keyword_in_row | df[column_name].str.contains(keyword, case=False, na=False)
                    df = df[contains_keyword_in_row]
                html_value = df.to_html(index=False)
                html_value = self._format_table_html(html_value)
                self.dc_entities_html_ui.value = html_value
                self._show_display(self.dataset_catalog_ui, True)
            elif selected_index == 2 and self.dc_features_list is None:
                self._show_display(self._loading_bar, True)
                dc = self.fs.get_dataset_catalog()
                self.dc_features_list = dc.list_features()
                df = self.dc_features_list.to_pandas()
                keyword = self.dc_features_search_text_ui.value
                if keyword != "" and len(self.dc_features_search_tag.value)>0:
                    contains_keyword_in_row = None
                    for column_name in self.dc_features_search_tag.value:
                        if contains_keyword_in_row is None:
                            contains_keyword_in_row = df[column_name].str.contains(keyword, case=False, na=False)
                        else:
                            contains_keyword_in_row = contains_keyword_in_row | df[column_name].str.contains(keyword, case=False, na=False)
                    df = df[contains_keyword_in_row]
                html_value = df.to_html(index=False)
                html_value = self._format_table_html(html_value)
                self.dc_features_html_ui.value = html_value
                self._show_display(self.dataset_catalog_ui, True)

        except Exception as e:
            self._show_error_mind_map(str(e))
            self.last_error = traceback.format_exc()

    def _show_error_mind_map(self, message):
        """
        DESCRIPTION:
            Private function that shows error and then goes back to mind map UI.

        PARAMETERS:
            message: Message to show
            Type Str
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        html = widgets.HTML("<h5>" + message + "</h5>")
        button = widgets.Button(
            description='Close',
            disabled=False
        )
        button.on_click(lambda x: self._show_mindmap_page())
        error_ui = widgets.VBox([html, button])
        self._show_current_ui(error_ui, True)

    def _on_show_data_catalog_clicked(self):
        """
        DESCRIPTION:
            Private function that is called when the Dataset Catalog button is clicked, which sets up the UI with Datasets, Features, Entities and Create. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        self._show_display(self._loading_bar, True)

        self.df = DataFrame(self.initial_data_domain.value)
            
        list_processes = self.fs.list_feature_processes()
        specific_columns_df = list_processes.select(["data_source","process_id", "feature_names"])
        new_df = specific_columns_df.assign(data_plus_id = specific_columns_df.data_source + ' (' + specific_columns_df.process_id + ')')
        pandas_df = new_df.to_pandas()
        self.grouped_data = pandas_df.groupby('data_plus_id')['feature_names'].apply(list).reset_index()
        try:
            self.grouped_data_options = self.grouped_data["data_plus_id"].to_list()
            self.grouped_data_value = self.grouped_data["data_plus_id"].iloc[0]
        except Exception as e:
            self._show_error_mind_map("No features available")
            return
        try:

            self.view_name = widgets.Text(
                value='',
                description='View Name',
                placeholder='',
                disabled=False,
                layout= widgets.Layout(width="80%")
            )
            self.dc_description = widgets.Text(
                value='',
                description='Description',
                placeholder='',
                layout= widgets.Layout(width="80%")
            )
            
            try:
                data_source_index = 0
                entity_df_name = self.grouped_data["data_plus_id"][data_source_index].split('"')[1]
                entity_df = DataFrame(entity_df_name)
            except:
                entity_df = self.df

            self.entity = widgets.Select(
                options=entity_df.columns,
                value = entity_df.columns[0],
                disabled=False
            )

            self.data_id_options = widgets.Select(
                options= self.grouped_data_options,
                value= self.grouped_data_value
            )
            self.feature_options = widgets.Select(
                options= []
            )
            
            self.data_id_options.observe(lambda change : self._on_data_source_change(change))
            self._on_data_source_change({"name": "value", "new": self.data_id_options.value})
           
            self.run_data_button = widgets.Button(
                description='Run',
                disabled=False,
                button_style='success', # 'success', 'info', 'warning', 'danger' or ''
                tooltip='Run Data Catalog',
                layout= widgets.Layout(border = '2px solid #6ac7a0'),
                style={'button_color' : '#d6f5e3', 'text_color' : 'black'}
            )

            self.run_data_button.on_click(lambda x: self._on_data_run_clicked())
   
            contents = widgets.HBox([
                widgets.VBox([widgets.Label("Entity:"), self.entity],
                layout= widgets.Layout(margin="0%")), 
                widgets.VBox([widgets.Label("Data Source:"), self.data_id_options]), 
                widgets.VBox([widgets.Label("Feature Options:"), self.feature_options])])


            self.add_catalog_ui = widgets.VBox([self.view_name, self.dc_description, contents, self.run_data_button])
            
            self.dc_dataset_list = None
            self.dc_datasets_ui, self.dc_datasets_search_text_ui, do_search_ui, self.dc_datasets_html_ui, self.datasets_search_tag = self._make_search_table_ui(default_options= ['data_domain', 'name', 'entity_name','description'], all_options = ['data_domain', 'name', 'entity_name','description','valid_start','valid_end'])
            def update_dc_datasets_search():
                """
                DESCRIPTION:
                    Private function that is called to update to a filtered list for datasets. 

                PARAMETERS:
                    None.
                
                RAISES:
                    None.

                RETURNS:
                    None.
                """
                self.dc_dataset_list = None
                self._update_dataset_catalog_stack(0)
            do_search_ui.on_click(lambda x : update_dc_datasets_search())

            self.dc_entities_list = None
            self.dc_entities_ui, self.dc_entities_search_text_ui, do_search_ui, self.dc_entities_html_ui, self.dc_entities_search_tag = self._make_search_table_ui(default_options= ['data_domain', 'name', 'entity_name', 'description'], all_options = ['data_domain', 'name', 'entity_name', 'description'])
            def update_dc_entities_search():
                """
                DESCRIPTION:
                    Private function that is called to update to a filtered list for dataset catalog entities.

                PARAMETERS:
                    None.
                
                RAISES:
                    None.

                RETURNS:
                    None.
                """
                self.dc_entities_list = None
                self._update_dataset_catalog_stack(1)
            do_search_ui.on_click(lambda x : update_dc_entities_search())

            self.dc_features_list = None
            self.dc_features_ui, self.dc_features_search_text_ui, do_search_ui, self.dc_features_html_ui, self.dc_features_search_tag = self._make_search_table_ui(default_options= ['data_domain', 'feature_name', 'feature_view'], all_options = ['data_domain', 'feature_id', 'feature_name', 'feature_view'])
            def update_dc_features_search():
                """
                DESCRIPTION:
                    Private function that is called to update to a filtered list for dataset catalog features.

                PARAMETERS:
                    None.
                
                RAISES:
                    None.

                RETURNS:
                    None.
                """
                self.dc_features_list = None
                self._update_dataset_catalog_stack(2)
            do_search_ui.on_click(lambda x : update_dc_features_search())

            back_button = widgets.Button(
                icon="solid home",
                disabled=False,
                tooltip='Return back to previous screen',
                layout= widgets.Layout(width='50px', height='50px', border = '2px solid #e3eaf2'),
                style={'button_color' : '#f7fafd', 'text_color' : 'black'}
            )
            back_button.on_click(lambda x : self._show_mindmap_page())

            self.dataset_catalog_buttons = []

            self.dataset_catalog_buttons.append(widgets.Button(
                description='Datasets',
                disabled=False,
                style={'button_color' : 'transparent', 'font_weight' : 'bold'},
                layout= widgets.Layout(height='50px'),
                tooltip='View Datasets'
            ))
            self.dataset_catalog_buttons.append(widgets.Button(
                description='Entities',
                disabled=False,
                style={'button_color' : 'transparent', 'font_weight' : 'bold'},
                layout= widgets.Layout(height='50px'),
                tooltip='View Entities'
            ))
            self.dataset_catalog_buttons.append(widgets.Button(
                description='Features',
                disabled=False,
                style={'button_color' : 'transparent', 'font_weight' : 'bold'},
                layout= widgets.Layout(height='50px'),
                tooltip='View Features'
            ))
            self.dataset_catalog_buttons.append(widgets.Button(
                description='Create',
                disabled=False,
                style={'button_color' : 'transparent', 'font_weight' : 'bold'},
                layout= widgets.Layout(height='50px'),
                tooltip='Add Dataset Catalog'
            ))

            self.dataset_catalog_buttons[0].on_click(lambda x : self._update_dataset_catalog_stack(0))
            self.dataset_catalog_buttons[1].on_click(lambda x : self._update_dataset_catalog_stack(1))
            self.dataset_catalog_buttons[2].on_click(lambda x : self._update_dataset_catalog_stack(2))
            self.dataset_catalog_buttons[3].on_click(lambda x : self._update_dataset_catalog_stack(3))
            
            self.dataset_catalog_stack = widgets.Stack([self.dc_datasets_ui, self.dc_entities_ui, self.dc_features_ui, self.add_catalog_ui], selected_index = 0)
            self.dataset_catalog_ui = widgets.VBox([ widgets.HBox([back_button, self.dataset_catalog_buttons[0], self.dataset_catalog_buttons[1], self.dataset_catalog_buttons[2], self.dataset_catalog_buttons[3]]), self.dataset_catalog_stack])
            self._update_dataset_catalog_stack(0)


            self._show_current_ui(self.dataset_catalog_ui, True)
            
        except Exception as e:
            self._show_error_mind_map(str(e))
            self.last_error = traceback.format_exc()

    def _create_main_ui(self):
        """
        DESCRIPTION:
            Private function that is called to create the main ui, including the mind map. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        self.home_button = widgets.Button(
            icon="solid home",
            disabled=False,
            tooltip='Return back to previous screen',
            layout= widgets.Layout(width='4%', height='50px', border = '2px solid #e3eaf2'),
            style={'button_color' : '#f7fafd', 'text_color' : 'black', 'font-size':'2em'}
        )

        self.home_button.on_click(lambda x : self._on_home_clicked())

        self.show_feature_ui_button = widgets.Button(
            description='Feature',
            disabled=False,
            tooltip='Run Feature Process',
            layout= widgets.Layout(width='48%', height='50px', border = '2px solid #c76aa0'),
            style={'button_color' : '#f2d6e6', 'text_color' : 'black'}
        )
        
        self.show_feature_ui_button.on_click(lambda x : self._on_show_feature_clicked())

        self.show_data_catalog_ui_button = widgets.Button(
            description='Dataset Catalog',
            disabled=False,
            tooltip='Run Data Catalog',
            layout= widgets.Layout(width='48%', height='50px', border = '2px solid #6ac7a0'),
            style={'button_color' : '#d6f5e3', 'text_color' : 'black'}
        )

        self.show_data_catalog_ui_button.on_click(lambda x : self._on_show_data_catalog_clicked())

        if not self._javascript_callbacks_enabled:
            button_widgets = [self.home_button, self.show_feature_ui_button, self.show_data_catalog_ui_button]
            self.homepage_map_ui = widgets.VBox([widgets.HBox(button_widgets), self.mind_map_output])
        else:
            self.homepage_map_ui = self.mind_map_output
        self.current_ui = self.homepage_map_ui

    def _show_current_ui(self, ui, clear):
        """
        DESCRIPTION:
            Private function that is specifies what is the current UI. 

        PARAMETERS:
            None.
        
        RAISES:
            None.

        RETURNS:
            None.
        """
        self.current_ui = ui
        self._show_display(self.current_ui, clear)


    def _get_data(self, process_id=None, entity=None, features=None,
                 dataset_name=None, as_of=None, include_historic_records=False):
        """
        DESCRIPTION:
            Returns teradataml DataFrame which has entities and feature values.
            Method generates dataset from following -
            * process_id
            * entity and features
            * dataset_name

        PARAMETERS:
            process_id:
                Optional Argument.
                Either "process_id", "entity" and "features", "dataset_name" is mandatory.
                Specifies the process id of an existing feature process.
                Types: str

            entity:
                Optional Argument.
                Specifies the name of the Entity or Object of Entity
                to be considered in the dataset.
                Types: str or Entity.

            features:
                Optional Argument.
                Specifies the names of Features and the corresponding feature version
                to be included in the dataset.
                Notes:
                     * Key is the name of the feature and value is the version of the
                       feature.
                     * Look at FeatureCatalog.list_feature_versions() to get the list of
                       features and their versions.
                Types: dict

            dataset_name:
                Optional Argument.
                Specifies the dataset name.
                Types: str

            as_of:
                Optional Argument.
                Specifies the time to retrieve the Feature Values instead of
                retrieving the latest values.
                Notes:
                    * Applicable only when "process_id" is passed to the function.
                    * Ignored when "dataset_name" is passed.
                Types: str or datetime.datetime

            include_historic_records:
                Optional Argument.
                Specifies whether to include historic data in the dataset.
                Note:
                    * If "as_of" is specified, then the "include_historic_records" argument is ignored.
                Default Value: False.
                Types: bool.


        RETURNS:
            teradataml DataFrame.

        RAISES:
            TeradataMLException
        """
        if (process_id is None) and (entity is None) and (features is None) and (dataset_name is None):
            return self._df_current_data_table
        else: 
            return self.fs.get_data(process_id=process_id, entity=entity, features=features,
                     dataset_name=dataset_name, as_of=as_of, include_historic_records=include_historic_records)
        


