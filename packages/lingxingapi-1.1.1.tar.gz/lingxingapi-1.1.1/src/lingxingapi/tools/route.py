# -*- coding: utf-8 -*-

# fmt: off
# 工具数据 ----------------------------------------------------------------------------------------------------------------------
# https://apidoc.lingxing.com/#/docs/Tools/GetKeywordList
MONITOR_KEYWORDS: str = "/erp/sc/routing/tool/toolKeywordRank/getKeywordList"
# https://apidoc.lingxing.com/#/docs/Tools/CompetitiveMonitorList
MONITOR_ASINS: str = "/basicOpen/tool/competitiveMonitor/list"
