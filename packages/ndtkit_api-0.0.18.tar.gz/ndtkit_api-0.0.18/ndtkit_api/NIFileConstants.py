from .ndtkit_socket_connection import gateway

USER_CONFIGURATION_DIRECTORY = gateway.jvm.agi.ndtkit.api.NIFileConstants.USER_CONFIGURATION
