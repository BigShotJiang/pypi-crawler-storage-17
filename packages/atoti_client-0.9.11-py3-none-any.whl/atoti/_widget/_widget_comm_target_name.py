# Keep this file in sync with widgetCommTargetName.ts.

WIDGET_COMM_TARGET_NAME = "atoti-widget"
