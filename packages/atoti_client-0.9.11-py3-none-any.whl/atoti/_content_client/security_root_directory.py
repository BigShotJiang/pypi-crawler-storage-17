SECURITY_ROOT_DIRECTORY = "/atoti/security"
"""The Content Server directory under which files related to Atoti Python SDK security are stored."""
