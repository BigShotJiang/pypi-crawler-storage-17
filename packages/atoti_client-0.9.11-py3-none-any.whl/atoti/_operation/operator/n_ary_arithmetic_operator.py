from typing import Literal, TypeAlias

NAryArithmeticOperator: TypeAlias = Literal["+", "//", "%", "*", "**", "-", "/"]
