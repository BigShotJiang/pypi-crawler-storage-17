from typing import TypeAlias

ContextValue: TypeAlias = bool | int | float | str
