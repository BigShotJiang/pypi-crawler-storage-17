JAVA_INT_RANGE = range(-(2 ** (32 - 1)), 2 ** (32 - 1))
