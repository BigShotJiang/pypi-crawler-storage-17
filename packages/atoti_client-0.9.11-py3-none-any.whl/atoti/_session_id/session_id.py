from typing import NewType

SessionId = NewType("SessionId", str)
