..
    DO NOT DELETE! This causes _autosummary to generate stub files

Reference (libcasm-xtal)
========================

.. autosummary::
    :toctree: _autosummary
    :template: custom-module-template.rst
    :recursive:

    libcasm.xtal
