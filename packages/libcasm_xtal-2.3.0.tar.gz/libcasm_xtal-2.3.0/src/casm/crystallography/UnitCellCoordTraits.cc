#include "casm/crystallography/UnitCellCoordTraits.hh"

namespace CASM {
const std::string traits<xtal::UnitCellCoord>::name = "UnitCellCoord";
}
