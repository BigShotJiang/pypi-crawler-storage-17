#ifndef DoFDecl_HH
#define DoFDecl_HH

#include <string>

namespace CASM {
typedef std::string DoFKey;
}

#endif
