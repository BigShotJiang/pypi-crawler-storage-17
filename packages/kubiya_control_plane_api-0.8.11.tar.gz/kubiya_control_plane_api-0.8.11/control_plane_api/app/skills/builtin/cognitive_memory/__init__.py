"""Cognitive Memory skill module"""
from control_plane_api.app.skills.builtin.cognitive_memory.skill import CognitiveMemorySkill

__all__ = ["CognitiveMemorySkill"]
