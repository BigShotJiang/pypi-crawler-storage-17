Bible Canonical Context of a bible book / chapter / passage.
How is this book / chapter / passage connected or linked with other books in the Bible?
What is the canonical context of this given book / chapter / passage in light of the whole canon of the bible?
How does this book / chapter / passage fit into the larger Biblical story in light of the whole canon of the bible?
                               
Please answer all relevant questions pertaining to the following book / chapter / passage with concrete examples:

# Book / Chapter / Passage
