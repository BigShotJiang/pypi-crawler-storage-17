# Typed Btcalpha

> A fully typed, validated async client for the Btcalpha API

Use *autocomplete* instead of documentation.

🚧 Under construction.