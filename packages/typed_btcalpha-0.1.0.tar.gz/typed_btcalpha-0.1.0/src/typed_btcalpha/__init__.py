"""
### Typed Btcalpha
> A fully typed, validated async client for the Btcalpha API

- Details
"""