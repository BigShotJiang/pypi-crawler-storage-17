from datahub.entrypoints import main

if __name__ == "__main__":
    main(prog_name="python3 -m datahub")
