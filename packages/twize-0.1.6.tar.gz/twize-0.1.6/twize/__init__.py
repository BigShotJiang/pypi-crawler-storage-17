from .Ibiki import Ibiki
def ibiki():
    return Ibiki()
__all__ = ['Ibiki', 'ibiki']
