"""
WheelNext Variant Provider for Ascend CANN"
"""
__version__ = "0.0.2"
__description__ = "A WheelNext Variant Provider for Ascend CANN"
__all__ = ["__version__", "__description__"]