DEFAULT_CONFIG = {
    "dsfr_base_enabled": [
        False,
        "Check integration with dsfr_base plugin from mkdocs-dsfr",
    ],
    "site_url": [
        "",
        "URL of generated site. Value is generated from config with dsfr_base plugin from mkdocs-dsfr",
    ],
}
