"""Tool Registry service (stdlib HTTP server MVP)."""
