# openpyxl_table_formatter

A simple package to help export pandas DataFrame to Excel files.

Currently available themes:
![Themes](https://github.com/arkadiuszhryc/openpyxl_table_formatter/blob/main/table_themes.png)

## Instalation

- with pip:
`pip install openpyxl-table-formatter`

- with uv:
`uv add openpyxl-table-formatter`
