#!/bin/bash
chatterlang_script --script Step_2_IndexStories.script