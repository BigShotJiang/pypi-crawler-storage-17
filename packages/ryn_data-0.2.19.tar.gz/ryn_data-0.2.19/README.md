# Data Ingestion SDK

This SDK provides simple functions to download, validate, and store datasets from HuggingFace, Kaggle, OpenML, and S3.