"""
Command-line interface for ScriptPlan.
"""

from scriptplan.cli.main import ScriptPlan, create_parser, main

__all__ = ["ScriptPlan", "create_parser", "main"]
