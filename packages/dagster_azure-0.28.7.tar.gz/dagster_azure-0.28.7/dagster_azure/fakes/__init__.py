from dagster_azure.fakes.fake_adls2_resource import (
    FakeADLS2Resource as FakeADLS2Resource,
    FakeADLS2ServiceClient as FakeADLS2ServiceClient,
    fake_adls2_resource as fake_adls2_resource,
)
