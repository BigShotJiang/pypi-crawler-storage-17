# Minfx

Neptune just announced the shutdown of its services.

Drop-in Replacement: just change

```
import neptune
```
to
```
import minfx.neptune as neptune
```

We will later publish how to generate new API token and sign up to the service.

