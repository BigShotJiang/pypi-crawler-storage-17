"""
MinFX.

This package provides core functionality for the minfx system.
"""

__version__ = "0.3.0"
__author__ = "Minfx Technologies, s.r.o."
__email__ = "contact@minfx.ai"

# Package level imports can be added here as the package grows
# Neptune is available as minfx.neptune
