"""CLI script for interacting with the ContainerL environment."""

#!/usr/bin/env python3
from containerl.cli import main

if __name__ == "__main__":
    main()
