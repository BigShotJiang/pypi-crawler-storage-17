# SPDX-License-Identifier: Apache-2.0
# File: src/iotopen_bridge/bridge/__init__.py
