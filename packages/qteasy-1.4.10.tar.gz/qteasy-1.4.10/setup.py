# ======================================
# File:     setup.py
# Author:   Jackie PENG
# Contact:  jackie.pengzhao@gmail.com
# Created:  2023-01-23
# Desc:
#   QTEASY setup file
# ======================================

from setuptools import setup

setup()
