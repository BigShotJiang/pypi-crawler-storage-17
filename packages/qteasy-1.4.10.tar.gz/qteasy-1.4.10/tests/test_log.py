# coding=utf-8
# ======================================
# File:     test_log.py
# Author:   Jackie PENG
# Contact:  jackie.pengzhao@gmail.com
# Created:  2020-02-12
# Desc:
#   Unittest for all qteasy log related
#   functionalities.
# ======================================
import unittest


class TestLog(unittest.TestCase):
    def test_init(self):
        pass


if __name__ == '__main__':
    unittest.main()