# coding=utf-8
# ======================================
# File:     test_akshare.py
# Author:   Jackie PENG
# Contact:  jackie.pengzhao@gmail.com
# Created:  2025-02-02
# Desc:
#   Unittest for all akshare data
#   acquiring APIs.
# ======================================

import unittest


class TestAKShare(unittest.TestCase):

    def test_akshare(self):
        # raise NotImplementedError
        pass


if __name__ == '__main__':
    unittest.main()