from .qrek_python import *

__doc__ = qrek_python.__doc__
if hasattr(qrek_python, "__all__"):
    __all__ = qrek_python.__all__