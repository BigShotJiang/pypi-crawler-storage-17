Display Functions
=================

Functions for printing variables, parameters, and solutions.

Printing
--------

.. autofunction:: cvxpy_or.print_variable

.. autofunction:: cvxpy_or.print_parameter

.. autofunction:: cvxpy_or.print_solution

Tables
------

.. autofunction:: cvxpy_or.variable_table

.. autofunction:: cvxpy_or.parameter_table

Summary
-------

.. autofunction:: cvxpy_or.solution_summary
