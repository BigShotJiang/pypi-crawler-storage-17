Aggregation Functions
=====================

Functions for aggregating expressions over index dimensions.

sum_by
------

.. autofunction:: cvxpy_or.sum_by

mean_by
-------

.. autofunction:: cvxpy_or.mean_by

min_by
------

.. autofunction:: cvxpy_or.min_by

max_by
------

.. autofunction:: cvxpy_or.max_by

count_by
--------

.. autofunction:: cvxpy_or.count_by

group_keys
----------

.. autofunction:: cvxpy_or.group_keys
