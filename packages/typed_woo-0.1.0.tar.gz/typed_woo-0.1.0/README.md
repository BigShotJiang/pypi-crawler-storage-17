# Typed Woo

> A fully typed, validated async client for the Woo API

Use *autocomplete* instead of documentation.

🚧 Under construction.