"""
### Typed Bitget
> A fully typed, validated async client for the Bitget API

- Details
"""