# Typed Bitget

> A fully typed, validated async client for the Bitget API

Use *autocomplete* instead of documentation.

🚧 Under construction.