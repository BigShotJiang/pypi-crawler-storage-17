"""Constants"""

UTF8 = 'utf-8'
