"""
FortiOS Log Memory API Module
"""

from .memory import Memory

__all__ = ["Memory"]
