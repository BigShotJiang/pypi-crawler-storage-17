# flake8: noqa

# import apis into api package
from chickenstats_api.api.chicken_nhl_api import ChickenNhlApi
from chickenstats_api.api.game_stats_api import GameStatsApi
from chickenstats_api.api.lines_api import LinesApi
from chickenstats_api.api.login_api import LoginApi
from chickenstats_api.api.play_by_play_api import PlayByPlayApi
from chickenstats_api.api.season_stats_api import SeasonStatsApi
from chickenstats_api.api.stats_api import StatsApi
from chickenstats_api.api.team_stats_api import TeamStatsApi
from chickenstats_api.api.users_api import UsersApi

