"""
FlaxKV2 主模块入口点
"""

from flaxkv2.cli import main

if __name__ == "__main__":
    main() 