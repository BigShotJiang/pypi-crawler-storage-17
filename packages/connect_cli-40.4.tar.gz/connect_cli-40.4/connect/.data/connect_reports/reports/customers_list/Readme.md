# Customers report

This report provides a view of all customers available at your account.

Report accepts to limit the output by:

* creation date of account
* Type of tier
