# Requests Report at line item level
This report provides a view of all transactions received for a given period of time
The generated report will provide a row for each item on the request.
Report accepts to limit the output by:
* List of products
* Type of request
* Status of the request
* List of marketplaces
* List of hubs