"""Models defined in fabricatio-character."""
