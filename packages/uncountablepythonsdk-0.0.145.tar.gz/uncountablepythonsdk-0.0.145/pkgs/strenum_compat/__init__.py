from .strenum_compat import StrEnum

__all__ = ["StrEnum"]
