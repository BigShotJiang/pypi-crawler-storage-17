class InferenceError(Exception):
    pass

class ModelLoadError(Exception):
    pass

class ModelNotRegisteredError(Exception):
    pass