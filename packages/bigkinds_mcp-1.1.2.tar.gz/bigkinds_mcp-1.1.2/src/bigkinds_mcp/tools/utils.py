"""유틸리티 MCP Tools."""

from datetime import datetime
from zoneinfo import ZoneInfo

# 한국 시간대
KST = ZoneInfo("Asia/Seoul")

# BigKinds 언론사 코드 (주요 언론사)
PROVIDER_CODES = {
    "01100001": "경향신문",
    "01100101": "국민일보",
    "01100201": "내일신문",
    "01100301": "동아일보",
    "01100401": "문화일보",
    "01100501": "서울신문",
    "01100601": "세계일보",
    "01100701": "조선일보",
    "01100801": "중앙일보",
    "01100901": "한겨레",
    "01101001": "한국일보",
    "01101101": "매일경제",
    "01101201": "한국경제",
    "01200101": "디지털타임스",
    "01200201": "전자신문",
    "02100101": "YTN",
    "02100201": "MBC",
    "02100301": "KBS",
    "02100401": "SBS",
    "02100501": "JTBC",
    "02100601": "채널A",
    "02100701": "TV조선",
    "02100801": "MBN",
}

# 역매핑 (이름 -> 코드)
PROVIDER_NAME_TO_CODE = {v: k for k, v in PROVIDER_CODES.items()}

# BigKinds 카테고리 코드
CATEGORY_CODES = {
    "정치": "정치",
    "경제": "경제",
    "사회": "사회",
    "문화": "문화",
    "국제": "국제",
    "지역": "지역",
    "스포츠": "스포츠",
    "IT_과학": "IT/과학",
}


def get_current_korean_time() -> dict:
    """
    현재 한국 시간(KST)을 조회합니다.

    날짜/시간 기반 검색 시 참조용으로 사용합니다.
    BigKinds API는 한국 시간대(KST, UTC+9) 기준으로 동작합니다.

    Returns:
        현재 한국 시간 정보:
            - datetime: ISO 8601 형식 (YYYY-MM-DDTHH:MM:SS+09:00)
            - date: 날짜 (YYYY-MM-DD)
            - time: 시간 (HH:MM:SS)
            - year: 연도
            - month: 월
            - day: 일
            - weekday: 요일 (한글)
            - hour: 시
            - minute: 분
            - timezone: 시간대 정보

    Example:
        검색 기간 설정 시 오늘 날짜 확인:
        >>> time_info = get_current_korean_time()
        >>> today = time_info["date"]  # "2025-12-15"
    """
    now = datetime.now(KST)

    weekdays = ["월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"]

    return {
        "datetime": now.isoformat(),
        "date": now.strftime("%Y-%m-%d"),
        "time": now.strftime("%H:%M:%S"),
        "year": now.year,
        "month": now.month,
        "day": now.day,
        "weekday": weekdays[now.weekday()],
        "hour": now.hour,
        "minute": now.minute,
        "timezone": {
            "name": "Asia/Seoul",
            "abbreviation": "KST",
            "offset": "+09:00",
            "description": "Korea Standard Time",
        },
    }


def find_category(
    query: str,
    category_type: str = "all",
) -> dict:
    """
    언론사 또는 카테고리 코드를 검색합니다.

    BigKinds 검색 시 providers나 categories 파라미터에 사용할 값을 찾습니다.

    Args:
        query: 검색어 (예: "경향", "한겨레", "경제", "IT")
        category_type: 검색 대상
            - "all" (기본값): 언론사와 카테고리 모두 검색
            - "provider": 언론사만 검색
            - "category": 카테고리만 검색

    Returns:
        검색 결과:
            - providers: 매칭된 언론사 목록 [{code, name}]
            - categories: 매칭된 카테고리 목록 [{code, name}]
            - query: 검색어
            - total_matches: 총 매칭 수

    Example:
        >>> find_category("한겨레")
        {"providers": [{"code": "01100901", "name": "한겨레"}], "categories": [], ...}

        >>> find_category("경제")
        {"providers": [{"code": "01101101", "name": "매일경제"}, ...], "categories": [{"code": "경제", "name": "경제"}], ...}
    """
    query_lower = query.lower()
    results = {
        "providers": [],
        "categories": [],
        "query": query,
        "total_matches": 0,
    }

    # 언론사 검색
    if category_type in ("all", "provider"):
        for code, name in PROVIDER_CODES.items():
            if query_lower in name.lower() or query_lower in code:
                results["providers"].append({"code": code, "name": name})

    # 카테고리 검색
    if category_type in ("all", "category"):
        for code, display_name in CATEGORY_CODES.items():
            if query_lower in code.lower() or query_lower in display_name.lower():
                results["categories"].append({"code": code, "name": display_name})

    results["total_matches"] = len(results["providers"]) + len(results["categories"])

    return results


def list_providers() -> dict:
    """
    사용 가능한 모든 언론사 코드 목록을 반환합니다.

    Returns:
        언론사 목록:
            - providers: 모든 언론사 [{code, name}]
            - total: 총 언론사 수
            - groups: 그룹별 분류 (신문, 방송 등)

    Example:
        검색 시 특정 언론사만 필터링하려면:
        >>> providers = list_providers()
        >>> search_news(keyword="AI", providers=["경향신문", "한겨레"], ...)
    """
    providers = [{"code": code, "name": name} for code, name in sorted(PROVIDER_CODES.items(), key=lambda x: x[1])]

    # 그룹별 분류
    newspapers = [p for p in providers if p["code"].startswith("011")]
    broadcasters = [p for p in providers if p["code"].startswith("02")]
    tech_papers = [p for p in providers if p["code"].startswith("012")]

    return {
        "providers": providers,
        "total": len(providers),
        "groups": {
            "newspapers": {"name": "종합일간지", "count": len(newspapers), "items": newspapers},
            "tech_papers": {"name": "전문지", "count": len(tech_papers), "items": tech_papers},
            "broadcasters": {"name": "방송사", "count": len(broadcasters), "items": broadcasters},
        },
    }


def list_categories() -> dict:
    """
    사용 가능한 모든 카테고리 코드 목록을 반환합니다.

    Returns:
        카테고리 목록:
            - categories: 모든 카테고리 [{code, name}]
            - total: 총 카테고리 수

    Example:
        검색 시 특정 카테고리만 필터링하려면:
        >>> categories = list_categories()
        >>> search_news(keyword="AI", categories=["경제", "IT_과학"], ...)
    """
    categories = [{"code": code, "name": name} for code, name in sorted(CATEGORY_CODES.items())]

    return {
        "categories": categories,
        "total": len(categories),
    }
