"""BigKinds MCP Server - Korean news search and article scraping."""

__version__ = "1.0.0"
