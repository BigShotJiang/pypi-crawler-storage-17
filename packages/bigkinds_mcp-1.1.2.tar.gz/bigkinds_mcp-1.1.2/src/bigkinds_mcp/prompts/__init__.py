"""MCP Prompts for BigKinds."""

from . import analysis
