"""뉴스 분석용 MCP Prompts."""

from __future__ import annotations


def news_analysis_prompt(
    keyword: str,
    start_date: str,
    end_date: str,
    analysis_type: str = "summary",
) -> str:
    """
    뉴스 분석을 위한 프롬프트를 생성합니다.

    Args:
        keyword: 분석할 키워드
        start_date: 분석 시작일 (YYYY-MM-DD)
        end_date: 분석 종료일 (YYYY-MM-DD)
        analysis_type: 분석 유형
            - summary: 주요 내용 요약
            - sentiment: 감성 분석
            - trend: 트렌드 분석
            - comparison: 언론사별 보도 비교

    Returns:
        분석 프롬프트
    """
    analysis_instructions = {
        "summary": """
## 분석 지침: 주요 내용 요약
1. 핵심 이슈 3-5개를 식별하세요.
2. 각 이슈별로 주요 내용을 2-3문장으로 요약하세요.
3. 전체적인 동향을 한 문단으로 정리하세요.
""",
        "sentiment": """
## 분석 지침: 감성 분석
1. 기사들의 전반적인 논조(긍정/중립/부정)를 파악하세요.
2. 긍정적/부정적 보도의 비율을 추정하세요.
3. 주요 긍정/부정 키워드를 추출하세요.
4. 시간에 따른 감성 변화가 있다면 분석하세요.
""",
        "trend": """
## 분석 지침: 트렌드 분석
1. 기사 수의 시간별 추이를 파악하세요.
2. 주요 이벤트와 기사 수 증가의 상관관계를 분석하세요.
3. 새롭게 등장한 관련 키워드나 주제를 식별하세요.
4. 향후 예상되는 트렌드를 제시하세요.
""",
        "comparison": """
## 분석 지침: 언론사별 보도 비교
1. 언론사별 보도 건수와 비중을 파악하세요.
2. 언론사별 보도 논조의 차이점을 분석하세요.
3. 동일 사안에 대한 프레이밍 차이를 비교하세요.
4. 보도의 다양성과 균형성을 평가하세요.
""",
    }

    instruction = analysis_instructions.get(analysis_type, analysis_instructions["summary"])

    return f"""# 뉴스 분석 요청

## 분석 대상
- **키워드**: {keyword}
- **기간**: {start_date} ~ {end_date}
- **분석 유형**: {analysis_type}

## 진행 단계

### 1단계: 데이터 수집
먼저 `search_news` 도구로 관련 기사를 검색하세요:
```
search_news(
    keyword="{keyword}",
    start_date="{start_date}",
    end_date="{end_date}",
    page_size=50,
    sort_by="both"
)
```

### 2단계: 기사 수 확인
전체 기사 수와 트렌드를 파악하세요:
```
get_article_count(
    keyword="{keyword}",
    start_date="{start_date}",
    end_date="{end_date}"
)
```

### 3단계: 상세 분석
주요 기사 3-5개를 선별하여 상세 내용을 조회하세요:
```
get_article(news_id="...", include_full_content=True)
```

### 4단계: 분석 수행
{instruction}

## 결과 형식
분석 결과를 다음 형식으로 정리해주세요:

### 개요
(1-2문장의 전체 요약)

### 주요 발견
1. ...
2. ...
3. ...

### 상세 분석
(분석 유형에 따른 상세 내용)

### 결론 및 시사점
(핵심 인사이트 정리)
"""


def trend_report_prompt(
    keyword: str,
    days: int = 7,
) -> str:
    """
    트렌드 리포트 생성을 위한 프롬프트를 생성합니다.

    Args:
        keyword: 분석할 키워드
        days: 분석 기간 (일 단위, 기본 7일)

    Returns:
        트렌드 리포트 프롬프트
    """
    return f"""# 트렌드 리포트 생성

## 분석 대상
- **키워드**: {keyword}
- **기간**: 최근 {days}일

## 진행 단계

### 1단계: 현재 날짜 확인
먼저 한국 시간 기준 현재 날짜를 확인하세요:
```
get_current_korean_time()
```

### 2단계: 오늘의 이슈 확인
오늘의 주요 이슈를 확인하세요:
```
get_today_issues()
```

### 3단계: 키워드 검색
지정된 키워드로 최근 기사를 검색하세요:
```
search_news(
    keyword="{keyword}",
    start_date="(현재 날짜에서 {days}일 전)",
    end_date="(현재 날짜)",
    sort_by="date",
    page_size=30
)
```

### 4단계: 기사 수 트렌드 분석
```
get_article_count(
    keyword="{keyword}",
    start_date="(현재 날짜에서 {days}일 전)",
    end_date="(현재 날짜)"
)
```

### 5단계: 주요 기사 분석
가장 최신 또는 중요한 기사 3개를 상세 조회하세요.

## 리포트 형식

### {keyword} 트렌드 리포트

**생성일**: (현재 날짜)
**분석 기간**: 최근 {days}일

#### 1. 핵심 요약
(3줄 이내의 핵심 내용)

#### 2. 주요 수치
- 총 기사 수: N건
- 일평균 기사 수: N건
- 최다 보도일: YYYY-MM-DD (N건)

#### 3. 주요 이슈 Top 5
1. ...
2. ...
3. ...
4. ...
5. ...

#### 4. 언론사별 보도 현황
(주요 언론사의 보도 동향)

#### 5. 향후 전망
(예상되는 트렌드 또는 주목할 포인트)
"""


def issue_briefing_prompt(date: str | None = None) -> str:
    """
    일일 이슈 브리핑을 위한 프롬프트를 생성합니다.

    Args:
        date: 브리핑 날짜 (YYYY-MM-DD). None이면 오늘

    Returns:
        이슈 브리핑 프롬프트
    """
    date_instruction = f'date="{date}"' if date else ""

    return f"""# 일일 이슈 브리핑

## 분석 대상
- **날짜**: {date if date else "오늘"}

## 진행 단계

### 1단계: 날짜 확인
현재 한국 시간을 확인하세요:
```
get_current_korean_time()
```

### 2단계: 인기 이슈 조회
오늘/지정일의 인기 이슈를 조회하세요:
```
get_today_issues({date_instruction})
```

### 3단계: 주요 이슈별 상세 검색
상위 5개 이슈에 대해 각각 상세 검색하세요:
```
search_news(keyword="(이슈 키워드)", start_date="...", end_date="...", page_size=10)
```

### 4단계: 대표 기사 조회
각 이슈별로 가장 중요한 기사 1개씩 상세 조회하세요.

## 브리핑 형식

### 일일 이슈 브리핑

**날짜**: {date if date else "(오늘 날짜)"}

---

#### TOP 1: (이슈 제목)
- **보도량**: N건
- **핵심 내용**: (2-3문장)
- **주요 언론사**: ...

#### TOP 2: (이슈 제목)
- **보도량**: N건
- **핵심 내용**: (2-3문장)
- **주요 언론사**: ...

(... TOP 5까지 반복 ...)

---

### 오늘의 한 줄 요약
(가장 중요한 이슈 한 문장으로 요약)
"""
