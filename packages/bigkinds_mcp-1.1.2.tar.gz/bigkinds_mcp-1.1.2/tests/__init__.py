"""Tests for BigKinds MCP Server."""
