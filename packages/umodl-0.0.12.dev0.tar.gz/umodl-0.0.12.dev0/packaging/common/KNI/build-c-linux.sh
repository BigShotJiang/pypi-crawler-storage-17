gcc -o KNIRecodeFile cpp/KNIRecodeFile.c -I /usr/include/ -lKhiopsNativeInterface -ldl
gcc -o KNIRecodeMTFiles cpp/KNIRecodeMTFiles.c -I /usr/include/ -lKhiopsNativeInterface -ldl