"""Synthesizers for sequential data."""

from sdv.sequential.par import PARSynthesizer

__all__ = ('PARSynthesizer',)
