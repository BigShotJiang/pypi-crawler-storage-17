"""
Database tools package for MCP server.
"""