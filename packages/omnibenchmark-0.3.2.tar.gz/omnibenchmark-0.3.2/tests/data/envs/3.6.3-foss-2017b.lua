-- 3.6.3-foss-2017b.lua

help([[
    This is a dummy module for demonstration purposes.
]])

whatis("Name: 3.6.3-foss-2017b")
whatis("Version: 1.0")
whatis("Category: Testing")
whatis("Description: A dummy module for testing purposes.")
