# Configuration tests module
