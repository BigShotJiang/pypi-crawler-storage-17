::: mkdocs-click
    :module: omnibenchmark.cli.main
    :command: cli
    :prog_name: ob
    :list_subcommands: True
    :depth: 1
