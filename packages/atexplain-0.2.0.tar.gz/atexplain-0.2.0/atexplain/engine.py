import atexit

_explanation_text = """
Это демонстрационное объяснение.

Здесь может быть:
- описание логики
- подсказки
- или текст от разработчика библиотеки
"""

def _ask_explanation():
    print("\nВам нужно объяснение работы кода? (да/нет)")
    answer = input(">>> ").strip().lower()

    if answer in ("да", "yes", "y"):
        print("\n📘 ОБЪЯСНЕНИЕ КОДА:\n")
        print(_explanation_text)
    else:
        print("\nОк. Завершение программы.")

# 🔥 РЕГИСТРАЦИЯ ФУНКЦИИ НА КОНЕЦ ПРОГРАММЫ
atexit.register(_ask_explanation)