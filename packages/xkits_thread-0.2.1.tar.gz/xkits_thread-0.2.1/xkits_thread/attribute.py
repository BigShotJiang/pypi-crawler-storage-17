# coding:utf-8

__project__ = "xkits-thread"
__version__ = "0.2.1"
__urlhome__ = "https://github.com/bondbox/xthreads/"
__description__ = "Thread module"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
