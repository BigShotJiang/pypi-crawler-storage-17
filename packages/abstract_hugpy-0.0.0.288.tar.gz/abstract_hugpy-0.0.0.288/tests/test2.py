
from imports import *

if __name__ == "__main__":
    video_url = "https://www.youtube.com/watch?v=Kazx0cLoB6A&t"

    # Example: pull your raw pipeline dict
    info = get_pipeline_data(video_id="Kazx0cLoB6A", key="extractfields")
    input(info)

