.. _installation:

Installation
------------

``pycarta`` can be installed using pip,::

    pip install pycarta

or, for those with access, from the
`pycarta repository <https://gitlab.com/contextualize/pycarta>`_
