from mantarix_web.fastapi import *
