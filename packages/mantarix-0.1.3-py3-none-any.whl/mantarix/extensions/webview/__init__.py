from mantarix.core.webview import (
    WebView,
    WebviewConsoleMessageEvent,
    WebviewJavaScriptEvent,
    WebviewLogLevelSeverity,
    WebviewRequestMethod,
    WebviewScrollEvent,
)