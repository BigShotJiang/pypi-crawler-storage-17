from mantarix.core.printer import (
    Printer,
    PrinterPageFormat,
    PrinterOutputType,
    PrinterDevice
)