from .flute import *

__doc__ = flute.__doc__
if hasattr(flute, "__all__"):
    __all__ = flute.__all__