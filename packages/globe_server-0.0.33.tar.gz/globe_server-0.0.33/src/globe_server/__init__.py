"""Globe Server Backend Package"""

__version__ = "0.1.0"
__author__ = "Edward Catley"
__description__ = "Globe Server Backend - Webserver control of Globe"
