"""Vicoa integrations package."""
