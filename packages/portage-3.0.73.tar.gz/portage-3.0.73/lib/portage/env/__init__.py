# Copyright: 2007 Gentoo Foundation
# License: GPL2
