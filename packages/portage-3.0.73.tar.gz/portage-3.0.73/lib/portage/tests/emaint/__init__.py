# Copyright 2025 Gentoo Authors
# Distributed under the terms of the GNU General Public License v2
