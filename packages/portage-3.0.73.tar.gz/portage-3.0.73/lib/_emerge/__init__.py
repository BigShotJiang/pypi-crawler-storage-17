# Copyright 2009 Gentoo Foundation
# Distributed under the terms of the GNU General Public License v2
