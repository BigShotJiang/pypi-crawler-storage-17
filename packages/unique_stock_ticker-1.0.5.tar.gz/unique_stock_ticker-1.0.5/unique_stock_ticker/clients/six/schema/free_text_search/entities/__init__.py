from unique_stock_ticker.clients.six.schema.free_text_search.entities.response import (
    EntityMatchingDescription,
)

__all__ = ["EntityMatchingDescription"]
