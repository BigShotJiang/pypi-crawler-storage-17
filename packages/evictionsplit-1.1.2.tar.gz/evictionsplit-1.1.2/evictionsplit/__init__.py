"""Evictionsplit app"""

# pylint: disable = invalid-name
default_app_config = "evictionsplit.apps.EvictionSplitConfig"

__version__ = "1.1.2"
