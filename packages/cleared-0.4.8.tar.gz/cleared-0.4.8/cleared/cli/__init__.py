"""CLI module for Cleared data de-identification framework."""

from .main import app

__all__ = ["app"]
