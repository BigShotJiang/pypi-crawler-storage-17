"""Linting rules organized by category."""
