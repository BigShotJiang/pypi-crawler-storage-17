"""Command-line interface for FastPubSub."""
