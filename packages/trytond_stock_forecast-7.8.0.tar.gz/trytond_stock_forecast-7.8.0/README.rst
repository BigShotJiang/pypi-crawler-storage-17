##############
Stock Forecast
##############

The *Stock Forecast Module* provides a simple way to represent predicted future demands.
This allows the supply system to take this expected demand into account.

.. toctree::
   :maxdepth: 2

   design
   releases
