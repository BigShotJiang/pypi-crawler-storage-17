# Typed Wavesexchange

> A fully typed, validated async client for the Wavesexchange API

Use *autocomplete* instead of documentation.

🚧 Under construction.