"""
### Typed Wavesexchange
> A fully typed, validated async client for the Wavesexchange API

- Details
"""