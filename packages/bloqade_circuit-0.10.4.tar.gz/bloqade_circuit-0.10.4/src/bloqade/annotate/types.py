from kirin import types


class Detector:
    pass


class Observable:
    pass


DetectorType = types.PyClass(Detector)
ObservableType = types.PyClass(Observable)
