from . import logical as logical
