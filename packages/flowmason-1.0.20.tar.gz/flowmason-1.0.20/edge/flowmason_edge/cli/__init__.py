"""
CLI for FlowMason Edge.
"""
