# Distributed Deductive System Sorts
