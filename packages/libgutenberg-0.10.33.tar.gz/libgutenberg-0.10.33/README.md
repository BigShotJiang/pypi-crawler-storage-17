# libgutenberg
Common files used by Project Gutenberg python projects.

# installation

`pipenv install libgutenberg`

or 

`pip install libgutenberg`


If you're connection to a postgress database

`pipenv install psycopg2-binary'