from django.apps import AppConfig


class Config(AppConfig):
    name = "browser_check"
    default_auto_field = "django.db.models.AutoField"
