"""
Application to work with documents.
"""
