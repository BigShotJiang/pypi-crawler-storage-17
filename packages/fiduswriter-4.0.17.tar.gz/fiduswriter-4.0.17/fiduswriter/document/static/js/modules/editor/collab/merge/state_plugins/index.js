export {clipboardPlugin} from "./clipboard"
export {diffPlugin} from "./diff"
