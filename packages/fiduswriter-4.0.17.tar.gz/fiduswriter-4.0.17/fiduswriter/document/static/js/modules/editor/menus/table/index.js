export {tableMenuModel} from "./model"
