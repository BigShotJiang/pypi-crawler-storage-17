export {imageMenuModel} from "./model"
