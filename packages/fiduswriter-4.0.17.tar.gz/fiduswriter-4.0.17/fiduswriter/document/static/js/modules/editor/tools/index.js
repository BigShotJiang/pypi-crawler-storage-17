export {WordCountDialog} from "./word_count"
export {KeyBindingsDialog} from "./key_bindings"
export {SearchReplaceDialog} from "./search_replace"
