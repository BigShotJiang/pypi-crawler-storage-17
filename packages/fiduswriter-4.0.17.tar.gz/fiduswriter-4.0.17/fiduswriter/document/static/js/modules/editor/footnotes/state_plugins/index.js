export {accessRightsPlugin} from "./access_rights"
