/** The current Fidus Writer document version.
 * The importer will not import from a higher version and the exporter
 * will include this number in all exports.
 */
export const FW_DOCUMENT_VERSION = "3.5"
