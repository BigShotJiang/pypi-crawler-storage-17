export {HTMLPaste} from "./html"
export {TextPaste} from "./text"
