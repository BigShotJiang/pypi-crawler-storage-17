// Placeholder for editor plugins
