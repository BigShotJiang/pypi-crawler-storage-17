# EndpointType

The type of connection used to send data to the endpoint. **Note**: When using the `splunk-hec` 'type', the `EndpointType` must be `http`.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


