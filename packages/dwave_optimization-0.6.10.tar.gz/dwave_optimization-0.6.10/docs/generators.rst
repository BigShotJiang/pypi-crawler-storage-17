.. _optimization_generators:

================
Model Generators
================

.. automodule:: dwave.optimization.generators
    :members:
