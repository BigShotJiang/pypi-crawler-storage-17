:orphan:

.. _optimization_cpp:

=======
C++ API
=======

dwave::optimization
-------------------

.. doxygennamespace:: dwave::optimization
    :project: dwave-optimization
    :content-only:
    :members:
