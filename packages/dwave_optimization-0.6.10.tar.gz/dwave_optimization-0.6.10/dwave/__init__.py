# Placeholder __init__.py required for the Cython build.
# This file is not installed as part of the wheel.
# See https://github.com/dwavesystems/dwave-optimization/issues/304
