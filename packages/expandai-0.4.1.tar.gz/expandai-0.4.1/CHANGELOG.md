# Changelog

## 0.4.1 (2025-12-17)

Full Changelog: [v0.4.0...v0.4.1](https://github.com/expandai/expandai-python/compare/v0.4.0...v0.4.1)

### Chores

* **internal:** add missing files argument to base client ([80aa980](https://github.com/expandai/expandai-python/commit/80aa9803b6dd99238ac129a98a0ee81bda70ecbf))
* speedup initial import ([50d5af4](https://github.com/expandai/expandai-python/commit/50d5af411e8c08b287c94f3b2ad7510e4db18fc5))


### Refactors

* **internal:** switch from rye to uv ([a8cc129](https://github.com/expandai/expandai-python/commit/a8cc129877055286b68920f67610c3db9cd2d897))

## 0.4.0 (2025-12-12)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/expandai/expandai-python/compare/v0.3.0...v0.4.0)

### Features

* **api:** api update ([4a17994](https://github.com/expandai/expandai-python/commit/4a17994db4684c58c617d82cbdc72500053dd8fd))

## 0.3.0 (2025-12-11)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/expandai/expandai-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** manual updates ([7436ecd](https://github.com/expandai/expandai-python/commit/7436ecd6117dda7d9c014a16175574b6d1e1b674))

## 0.2.0 (2025-12-10)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/expandai/expandai-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** manual updates ([54ca7dc](https://github.com/expandai/expandai-python/commit/54ca7dcd73b3b3ef7adbd3338a1115b3c90701d2))
* **api:** manual updates ([eafd153](https://github.com/expandai/expandai-python/commit/eafd153d748899ece1ce0ce7a26bd4069c7c4a58))
* **api:** manual updates ([8b94d53](https://github.com/expandai/expandai-python/commit/8b94d533f83356d7a4df76f28183e63c728cd76b))
* **api:** manual updates ([66ab470](https://github.com/expandai/expandai-python/commit/66ab4704370ae20d44bd3e25662eff96a39ac9e4))
* **api:** manual updates ([cf780b8](https://github.com/expandai/expandai-python/commit/cf780b8770b01a20d744f0a700a663e849476a30))
* **api:** manual updates ([33f9136](https://github.com/expandai/expandai-python/commit/33f9136c489884fbd67e6aca32992a90b2cf2009))
* **api:** manual updates ([77abf09](https://github.com/expandai/expandai-python/commit/77abf091a0756efa01e7f14fc5b1262dd091320f))
* **api:** manual updates ([b2fdc87](https://github.com/expandai/expandai-python/commit/b2fdc8766f274055ee6120fc448083b2d7ccfd9b))


### Chores

* update SDK settings ([244ff20](https://github.com/expandai/expandai-python/commit/244ff209b55ca271e66136fd357032887b536be5))
* update SDK settings ([190a4f2](https://github.com/expandai/expandai-python/commit/190a4f2fb911eca265a8ec49330781d8e8b0fb64))

## 0.1.0 (2025-12-10)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/expandai/expand-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([bf0bc0a](https://github.com/expandai/expand-python/commit/bf0bc0a9712be08018360c00de3bc208807c5823))
* **api:** api update ([9e4c98b](https://github.com/expandai/expand-python/commit/9e4c98b687c091a7e52d8a9d69fe9a5c2f7e6b75))
* **api:** api update ([a157740](https://github.com/expandai/expand-python/commit/a157740d97db44a7253f974f75c68ed6b5bafd37))
* **api:** api update ([29978dd](https://github.com/expandai/expand-python/commit/29978dd86bdd385e4cb719edadbf0564d2135a40))
* **api:** manual updates ([6595d0a](https://github.com/expandai/expand-python/commit/6595d0afc221d67cdae33a2f267627621c97f9c9))
* **api:** manual updates ([fc001f8](https://github.com/expandai/expand-python/commit/fc001f8c3ed73d4b18e672a215cf50458957472c))
* **api:** manual updates ([eb63b72](https://github.com/expandai/expand-python/commit/eb63b72d4b0dabb38c4bf27f515e88b6d29f9eee))
* **api:** manual updates ([7c515fd](https://github.com/expandai/expand-python/commit/7c515fdf3b33df17360767a24a370f2133a6dce6))
* **api:** manual updates ([0949ab1](https://github.com/expandai/expand-python/commit/0949ab104210fe3e0134126e39be80ac1d27a46b))


### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([73884f5](https://github.com/expandai/expand-python/commit/73884f5c4c1ff9264e45831db168da92827e77b5))


### Chores

* add missing docstrings ([26721fe](https://github.com/expandai/expand-python/commit/26721feec88fdbbce9240f35ba9a71db89440b4c))
* **docs:** use environment variables for authentication in code snippets ([b4f4f02](https://github.com/expandai/expand-python/commit/b4f4f02fa65e35d7819db9803a6b366f935254d3))
* update lockfile ([17586da](https://github.com/expandai/expand-python/commit/17586daa8da3b9c4c3ad3324de3cfa8986146c07))
