"""
Simple utility to store custom encodings as CAR files

This script allows you to take any custom tokenizer/encoder output (tensors + metadata)
and store them directly as CAR files using carlib's existing storage infrastructure.

Usage:
    from carlib.store_custom_encoding import store_encoding, load_encoding
    
    # Your custom encodings
    tokens = torch.randint(0, 1000, (32, 100))  # Example: tokenizer output
    embeddings = torch.randn(32, 100, 512)     # Example: encoder embeddings
    
    # Store as CAR file
    store_encoding(
        data={'tokens': tokens, 'embeddings': embeddings},
        output_path='./my_encoding.car',
        metadata={'model': 'my_tokenizer', 'vocab_size': 1000}
    )
    
    # Load back
    data, metadata = load_encoding('./my_encoding.car')
"""

import torch
import os
from typing import Dict, Any, Optional, Tuple
from .processors.utils import CARHandler


def store_encoding(
    data: Dict[str, torch.Tensor],
    output_path: str,
    metadata: Optional[Dict[str, Any]] = None,
    optimize_dtypes: bool = True,
    compress: bool = False,
    compression_level: int = 6
) -> str:
    """
    Store custom encoding tensors as CAR file.
    
    Args:
        data: Dictionary of tensors to store (e.g., {'tokens': tensor, 'embeddings': tensor})
        output_path: Path where to save the CAR file
        metadata: Optional metadata dictionary
        optimize_dtypes: Whether to optimize tensor dtypes for storage efficiency
        compress: Whether to apply gzip compression
        compression_level: Compression level 1-9
    
    Returns:
        Path to the saved CAR file
    
    Example:
        >>> import torch
        >>> from carlib.store_custom_encoding import store_encoding
        >>> 
        >>> # Your custom tokenizer outputs
        >>> tokens = torch.randint(0, 1000, (32, 100))
        >>> 
        >>> # Store as CAR file
        >>> store_encoding(
        ...     data={'tokens': tokens},
        ...     output_path='./my_tokens.car',
        ...     metadata={'tokenizer': 'my_custom_tokenizer', 'vocab_size': 1000}
        ... )
        './my_tokens.car'
    """
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else '.', exist_ok=True)
    
    # Prepare metadata
    if metadata is None:
        metadata = {}
    
    enhanced_metadata = {
        "media_type": "custom",
        "format": "custom_encoding",
        "created_at": __import__('datetime').datetime.now().isoformat(),
        **metadata
    }
    
    # Convert tensors to CAR format using existing infrastructure
    car_data = CARHandler.np_to_car(
        data_dict=data,
        metadata=enhanced_metadata,
        compress=compress,
        compression_level=compression_level,
        optimize_dtypes=optimize_dtypes
    )
    
    # Write to file
    with open(output_path, 'wb') as f:
        f.write(car_data)
    
    # Calculate and report file size
    file_size = os.path.getsize(output_path)
    print(f"✅ Saved custom encoding: {output_path}")
    print(f"   File size: {file_size / (1024 * 1024):.1f}MB")
    
    # Report tensor info
    for key, tensor in data.items():
        print(f"   {key}: {list(tensor.shape)} ({tensor.dtype})")
    
    return output_path


def load_encoding(car_path: str, restore_original_dtype: bool = True) -> Tuple[Dict[str, torch.Tensor], Dict[str, Any]]:
    """
    Load custom encoding from CAR file.
    
    Args:
        car_path: Path to CAR file
        restore_original_dtype: Whether to restore original tensor dtypes
    
    Returns:
        Tuple of (tensor_data, metadata)
    
    Example:
        >>> from carlib.store_custom_encoding import load_encoding
        >>> 
        >>> # Load back your tensors
        >>> data, metadata = load_encoding('./my_tokens.car')
        >>> tokens = data['tokens']
        >>> print(f"Loaded tokens: {tokens.shape}")
        >>> print(f"Tokenizer: {metadata.get('tokenizer')}")
    """
    
    with open(car_path, 'rb') as f:
        car_data = f.read()
    
    data, metadata = CARHandler.car_to_np(car_data, restore_original_dtype=restore_original_dtype)
    
    print(f"📄 Loaded custom encoding: {car_path}")
    for key, tensor in data.items():
        if hasattr(tensor, 'shape'):  # Check if it's a tensor
            print(f"   {key}: {list(tensor.shape)} ({tensor.dtype})")
    
    return data, metadata


def get_encoding_info(car_path: str) -> Dict[str, Any]:
    """
    Get metadata and basic info about a CAR file without loading the tensors.
    
    Args:
        car_path: Path to CAR file
    
    Returns:
        Metadata dictionary
    
    Example:
        >>> from carlib.store_custom_encoding import get_encoding_info
        >>> 
        >>> info = get_encoding_info('./my_tokens.car')
        >>> print(f"Format: {info.get('format')}")
        >>> print(f"Created: {info.get('created_at')}")
    """
    
    with open(car_path, 'rb') as f:
        car_data = f.read()
    
    return CARHandler.get_car_metadata(car_data)


def verify_encoding(car_path: str) -> bool:
    """
    Verify the integrity of a CAR file.
    
    Args:
        car_path: Path to CAR file
    
    Returns:
        True if file is valid, False otherwise
    
    Example:
        >>> from carlib.store_custom_encoding import verify_encoding
        >>> 
        >>> if verify_encoding('./my_tokens.car'):
        ...     print("File is valid!")
        ... else:
        ...     print("File is corrupted!")
    """
    
    try:
        with open(car_path, 'rb') as f:
            car_data = f.read()
        return CARHandler.verify_car_integrity(car_data)
    except Exception:
        return False


# Convenience function for batch operations
def store_multiple_encodings(
    encoding_list: list,
    base_path: str = "./encodings",
    optimize_dtypes: bool = True,
    compress: bool = False
) -> list:
    """
    Store multiple encodings in batch.
    
    Args:
        encoding_list: List of (data_dict, metadata_dict, filename) tuples
        base_path: Base directory for output files
        optimize_dtypes: Whether to optimize tensor dtypes
        compress: Whether to apply compression
    
    Returns:
        List of saved file paths
    
    Example:
        >>> encodings = [
        ...     ({'tokens': torch.randint(0, 100, (10, 20))}, {'model': 'v1'}, 'encoding_1'),
        ...     ({'tokens': torch.randint(0, 100, (15, 25))}, {'model': 'v2'}, 'encoding_2'),
        ... ]
        >>> paths = store_multiple_encodings(encodings)
    """
    
    os.makedirs(base_path, exist_ok=True)
    saved_paths = []
    
    for data, metadata, filename in encoding_list:
        if not filename.endswith('.car'):
            filename += '.car'
        
        output_path = os.path.join(base_path, filename)
        
        try:
            path = store_encoding(
                data=data,
                output_path=output_path,
                metadata=metadata,
                optimize_dtypes=optimize_dtypes,
                compress=compress
            )
            saved_paths.append(path)
        except Exception as e:
            print(f"❌ Failed to save {filename}: {e}")
            saved_paths.append(None)
    
    return saved_paths


if __name__ == "__main__":
    # Example usage
    import torch
    
    print("🔧 Custom Encoding Storage Example")
    
    # Create example custom encoding data
    tokens = torch.randint(0, 1000, (32, 100))  # Example: tokenizer output
    embeddings = torch.randn(32, 100, 256)      # Example: encoder embeddings
    
    data = {
        'tokens': tokens,
        'embeddings': embeddings
    }
    
    metadata = {
        'model': 'my_custom_tokenizer',
        'vocab_size': 1000,
        'embedding_dim': 256,
        'description': 'Example custom encoding'
    }
    
    # Store as CAR file
    output_path = './example_encoding.car'
    saved_path = store_encoding(data, output_path, metadata)
    
    # Load back and verify
    loaded_data, loaded_metadata = load_encoding(saved_path)
    
    print(f"\n📊 Verification:")
    print(f"   Original tokens shape: {tokens.shape}")
    print(f"   Loaded tokens shape: {loaded_data['tokens'].shape}")
    print(f"   Tokens match: {torch.equal(tokens, loaded_data['tokens'])}")
    print(f"   Model: {loaded_metadata.get('model')}")
    
    # Clean up example file
    os.remove(saved_path)
    print(f"\n🧹 Cleaned up example file")