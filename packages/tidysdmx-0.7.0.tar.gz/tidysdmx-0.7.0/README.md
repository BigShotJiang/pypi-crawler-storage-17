<div align="center">
    <img src="https://img.shields.io/badge/status-work_in_progress-orange" alt="Work in progress" />
    <h1>⚠️ Work in progress</h1>
    <p><strong>This package is under active development. APIs, interfaces, and behavior may change without notice. Use with caution.</strong></p>
</div>

> ⚠️ **Work in progress:** This project is under active development. Expect breaking changes and incomplete features. Contributions and feedback are welcome.

# tidysdmx

A toolbox to work with SDMX data

## Installation

```bash
$ pip install tidysdmx
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`tidysdmx` was created by DECGT team at the World Bank. It is licensed under the terms of the MIT license.

## Credits

`tidysdmx` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
