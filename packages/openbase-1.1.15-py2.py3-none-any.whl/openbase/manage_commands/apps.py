from django.apps import AppConfig


class ManageCommandsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "openbase.manage_commands"
