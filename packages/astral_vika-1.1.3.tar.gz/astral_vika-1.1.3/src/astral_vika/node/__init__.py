"""
维格表节点模块

兼容原vika.py库的node模块
"""
from .node_manager import NodeManager, Node


__all__ = [
    'NodeManager',
    'Node'
]
