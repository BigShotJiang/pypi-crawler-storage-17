# Control Plane OpenAPI MCP Prompts
from .api_script_prompt import *