"""Core components for OpenAPI processing."""
