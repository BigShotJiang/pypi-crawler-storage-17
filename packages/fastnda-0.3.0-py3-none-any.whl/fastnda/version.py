"""Version information automatically updated by bumpver."""

__version__ = "0.3.0"
