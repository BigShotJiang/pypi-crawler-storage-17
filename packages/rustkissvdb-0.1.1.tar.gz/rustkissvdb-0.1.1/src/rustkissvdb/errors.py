class RustKissVDBError(RuntimeError):
    """Error base para el SDK."""
