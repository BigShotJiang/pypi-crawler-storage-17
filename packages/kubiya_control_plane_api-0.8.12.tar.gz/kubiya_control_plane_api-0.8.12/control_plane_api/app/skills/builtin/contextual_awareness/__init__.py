"""Contextual Awareness Skill - Access Context Graph API for real-time context"""
from .skill import ContextualAwarenessSkill

__all__ = ["ContextualAwarenessSkill"]
