#!/usr/bin/env python
# Legacy setup.py for backward compatibility
# Primary config is in pyproject.toml
from setuptools import setup
setup()
