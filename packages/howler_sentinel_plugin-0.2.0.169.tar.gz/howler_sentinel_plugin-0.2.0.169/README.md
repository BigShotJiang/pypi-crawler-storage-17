# Howler Sentinel Plugin

This plugin contains modules for Microsoft Sentinel integration in Howler.
