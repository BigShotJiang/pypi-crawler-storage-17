# aws-mp-utils
Utility functions and CLI for working with AWS Marketplace-Catalog APIs
