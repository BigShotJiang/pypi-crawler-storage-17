================
element-manifest
================

Writes a manifest file that is the full list of elements that were used to
build the image. The file path can be overridden by setting
$DIB\_ELEMENT\_MANIFEST\_PATH, and defaults to
/etc/dib-manifests/element-manifest.
