================
Block Device MBR
================

This provides the default legacy block-device configuration for the
"vm" element.  This configures a single partition and is suitable for
a MBR based bootloader.
