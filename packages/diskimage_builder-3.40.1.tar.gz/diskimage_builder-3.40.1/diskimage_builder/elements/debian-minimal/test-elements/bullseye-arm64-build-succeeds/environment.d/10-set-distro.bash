export DIB_RELEASE=bullseye
