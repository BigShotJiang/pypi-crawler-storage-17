Verify we can build a debian-minimal stable image.
