======
ELRepo
======

Enables ELRepo, a community based repository for Enterprise Linux Packages with a focus
on drivers for hardware such as network interface cards. RHEL/CentOS versions pior to 8
are not supported.

* ``DIB_ELREPO_KERNEL`` Whether elrepo-kernel repository containing kernel-ml packages
  should be enabled (1) or disabled. Default is disabled (0).
