# Using 037 because that matches the current Fedora package
export DRACUT_VERSION=037
