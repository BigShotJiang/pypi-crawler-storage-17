ubuntu-common
=============

This element holds configuration and scripts that are common for all
Ubuntu images.
