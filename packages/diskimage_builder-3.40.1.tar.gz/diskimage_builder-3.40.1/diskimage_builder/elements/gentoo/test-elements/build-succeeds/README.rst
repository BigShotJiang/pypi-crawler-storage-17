Test that we can successfully build a gentoo image.
