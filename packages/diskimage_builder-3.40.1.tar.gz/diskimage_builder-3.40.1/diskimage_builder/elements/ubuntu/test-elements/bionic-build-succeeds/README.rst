Verify we can build a ubuntu image.

Note this test includes the vm element to test the bootloader install,
and specifies to output a .qcow2
