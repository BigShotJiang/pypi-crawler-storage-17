# For the openstack-ci-mirrors element
export DISTRO_NAME=ubuntu
