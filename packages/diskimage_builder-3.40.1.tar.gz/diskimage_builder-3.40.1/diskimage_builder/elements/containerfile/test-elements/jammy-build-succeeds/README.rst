Verify we can build an image from a containerfile.

