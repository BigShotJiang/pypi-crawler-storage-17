Verify a AlmaLinux 10 aarch64 image
