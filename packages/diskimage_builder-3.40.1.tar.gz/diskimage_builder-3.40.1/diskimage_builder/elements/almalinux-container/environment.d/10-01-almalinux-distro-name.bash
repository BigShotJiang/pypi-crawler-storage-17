export DISTRO_NAME=almalinux
export DIB_RELEASE=${DIB_RELEASE:-10} # always the most recent major
export EFI_BOOT_DIR="EFI/almalinux"
export DIB_YUM_MINIMAL_CREATE_INTERFACES=0
