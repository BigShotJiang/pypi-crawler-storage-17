===================
almalinux-container
===================

Create a minimal image based on AlmaLinux container image

This element sets the ``DISTRO_NAME`` var to 'almalinux'. The release
of AlmaLinux to be installed can be controlled through the ``DIB_RELEASE``
variable, which defaults the latest supported release.
