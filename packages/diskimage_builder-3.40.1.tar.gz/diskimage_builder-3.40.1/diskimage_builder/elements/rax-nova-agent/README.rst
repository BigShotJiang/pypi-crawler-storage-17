==============
rax-nova-agent
==============
Images for Rackspace Cloud currently require nova-agent to get networking
information.

Many of the things here are adapted from:

https://developer.rackspace.com/blog/bootstrap-your-qcow-images-for-the-rackspace-public-cloud/
