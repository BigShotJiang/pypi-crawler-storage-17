================
rocky-container
================

Create a minimal image based on Rocky Linux container image

This element sets the ``DISTRO_NAME`` var to 'rocky'. The release of
rocky to be installed can be controlled through the ``DIB_RELEASE``
variable, which defaults the latest supported release.
