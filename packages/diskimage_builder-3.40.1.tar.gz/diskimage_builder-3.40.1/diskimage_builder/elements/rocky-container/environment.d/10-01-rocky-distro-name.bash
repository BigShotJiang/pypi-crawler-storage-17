export DISTRO_NAME=rocky
export DIB_RELEASE=${DIB_RELEASE:-9} # always the most recent major
export EFI_BOOT_DIR="EFI/rocky"
export DIB_YUM_MINIMAL_CREATE_INTERFACES=0
