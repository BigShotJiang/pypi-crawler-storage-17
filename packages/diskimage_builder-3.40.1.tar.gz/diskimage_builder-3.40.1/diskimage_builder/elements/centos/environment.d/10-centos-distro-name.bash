export DISTRO_NAME=centos
export DIB_RELEASE=${DIB_RELEASE:-9-stream}
export EFI_BOOT_DIR="EFI/centos"
export YUM=dnf
