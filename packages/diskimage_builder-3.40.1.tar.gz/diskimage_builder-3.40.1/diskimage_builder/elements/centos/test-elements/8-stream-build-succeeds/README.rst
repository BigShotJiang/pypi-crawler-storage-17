Centos Stream 8 test
