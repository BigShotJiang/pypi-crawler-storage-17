==
vm
==
Sets up a partitioned disk (rather than building just one filesystem with no
partition table).
