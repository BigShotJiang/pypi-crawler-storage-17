Verify we can build a fedora-minimal image.
