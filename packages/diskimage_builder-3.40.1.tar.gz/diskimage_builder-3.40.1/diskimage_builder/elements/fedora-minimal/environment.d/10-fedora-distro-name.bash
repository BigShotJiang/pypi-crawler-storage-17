export DISTRO_NAME=fedora
export DIB_RELEASE=${DIB_RELEASE:-32}
export EFI_BOOT_DIR="EFI/fedora"
