rpm-distro
----------

Base element for distributions based on RPM.
