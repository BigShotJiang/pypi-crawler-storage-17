Verify we can build an openSUSE image.
