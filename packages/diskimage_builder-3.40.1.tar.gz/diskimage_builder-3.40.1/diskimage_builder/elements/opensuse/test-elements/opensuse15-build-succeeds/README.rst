Verify we can build an openSUSE Leap 15.5 image.
