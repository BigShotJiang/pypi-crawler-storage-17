====================
openstack-ci-mirrors
====================

This element contains various settings to setup mirrors for openstack
ci gate testing in a generic fashion.  It is intended to be used as a
dependency of testing elements that run in the gate.  It should do
nothing outside that environment.
