==============
dracut-network
==============

This element was removed in the Pike cycle. Please consider using the
dracut-regenerate element instead.
