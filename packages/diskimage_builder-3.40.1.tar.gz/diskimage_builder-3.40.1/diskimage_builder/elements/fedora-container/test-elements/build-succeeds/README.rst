Verify we can build a fedora-container image.
