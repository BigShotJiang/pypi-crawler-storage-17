=====================
nm-dhcp-ib-interfaces
=====================
Add InfiniBand connection profile to run DHCP for InfiniBand interfaces

As it's not implemented yet to create default connection profiles for
InfiniBand interfaces in NetworkManager, we are providing a wildcard
InfiniBand connection profile to allow it to run DHCP for InfiniBand
interfaces.
