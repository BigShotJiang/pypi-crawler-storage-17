=====================
cleanup-kernel-initrd
=====================
Remove unused kernel/initrd from the image.
