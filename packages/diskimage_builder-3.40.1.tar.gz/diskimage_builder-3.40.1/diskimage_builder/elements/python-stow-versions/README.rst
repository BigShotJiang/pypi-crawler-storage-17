====================
python-stow-versions
====================

Element that installs latest minor releases of python
