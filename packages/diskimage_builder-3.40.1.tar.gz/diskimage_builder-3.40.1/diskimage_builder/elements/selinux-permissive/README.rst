==================
selinux-permissive
==================
Puts selinux into permissive mode by writing SELINUX=permissive
to /etc/selinux/config

Enable this element when debugging selinux issues.
