================
opensuse-minimal
================

This element will build a minimal openSUSE image. It requires 'zypper' to be
installed on the host.

These images should be considered experimental. There are currently only x86_64
images.

Environment Variables
---------------------

DIB_RELEASE
  :Required: No
  :Default: 15.1
  :Description: Set the desired openSUSE release.
