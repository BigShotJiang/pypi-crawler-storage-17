Verify we can build a ubuntu-minimal image.
