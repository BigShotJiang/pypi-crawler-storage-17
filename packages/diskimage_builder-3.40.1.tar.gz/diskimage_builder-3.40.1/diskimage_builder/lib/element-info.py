import sys

from diskimage_builder.element_dependencies import main


if __name__ == "__main__":
    sys.exit(main())
