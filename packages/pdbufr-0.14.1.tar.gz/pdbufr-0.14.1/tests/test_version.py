import pdbufr


def test_version() -> None:
    assert pdbufr.__version__ != "999"
