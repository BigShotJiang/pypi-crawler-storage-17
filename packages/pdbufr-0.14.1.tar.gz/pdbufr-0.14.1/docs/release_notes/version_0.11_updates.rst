
Version 0.11 Updates
/////////////////////////


Version 0.11.0
===============

- added the ability to pass a :ref:`message list object <message-list-object>` to :func:`read_bufr` (`#61 <https://github.com/ecmwf/pdbufr/pull/61>`_)
- use micromamba instead of conda to set up ci environments
