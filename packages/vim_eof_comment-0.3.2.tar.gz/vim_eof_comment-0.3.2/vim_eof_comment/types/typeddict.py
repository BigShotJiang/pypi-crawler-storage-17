# -*- coding: utf-8 -*-
# Copyright (c) 2025 Guennadi Maximov C. All Rights Reserved.
"""
Custom vim-eof-comment ``TypedDict`` objects.

Copyright (c) 2025 Guennadi Maximov C. All Rights Reserved.
"""
from typing import Any, Dict, List, TextIO, TypedDict

from argcomplete.completers import DirectoriesCompleter


class ParserSpec(TypedDict):
    """
    Stores the spec for ``argparse`` operations in a constant value.

    This is a ``TypedDict``-like object.

    Attributes
    ----------
    opts : List[str]
        A list containing all the relevant iterations of the same option.
    kwargs : Dict[str, str]
        Extra arguments for ``argparse.ArgumentParser``.
    completer : argcomplete.DirectoriesCompleter, optional, default=None
        An optional ``argcomplete`` completer object.

    Parameters
    ----------
    opts : List[str]
        A list containing all the relevant iterations of the same option.
    kwargs : Dict[str, str]
        Extra arguments for ``argparse.ArgumentParser``.
    completer : argcomplete.DirectoriesCompleter, optional, default=None
        An optional ``argcomplete`` completer object.
    """

    opts: List[str]
    kwargs: Dict[str, Any]
    completer: DirectoriesCompleter | None


class CommentMap(TypedDict):
    """A ``TypedDict`` container."""

    level: int


class IndentMap(TypedDict):
    """A ``TypedDict`` container."""

    level: int
    expandtab: bool

    def __str__(self) -> str:
        """
        Return string representation.

        Returns
        -------
        str
            The string representation for ``IndentMap``.
        """
        return "{" + f"level={self.level}, expandtab={self.expandtab}" + "}"

    def __repr__(self) -> str:
        """
        Return string representation.

        Returns
        -------
        str
            The string representation for ``IndentMap``.
        """
        return self.__str__()


class IndentHandler(TypedDict):
    """A ``TypedDict`` container."""

    ext: str
    level: str
    expandtab: bool


class IOWrapperBool(TypedDict):
    """A ``TypedDict`` container."""

    file: TextIO
    has_nwl: bool


class LineBool(TypedDict):
    """A ``TypedDict`` container."""

    line: str
    has_nwl: bool


class BatchPathDict(TypedDict):
    """A ``TypedDict`` container."""

    file: TextIO
    ext: str


class BatchPairDict(TypedDict):
    """A ``TypedDict`` container."""

    fpath: str
    ext: str


class EOFCommentSearch(TypedDict):
    """A ``TypedDict`` container."""

    state: IOWrapperBool
    lang: str
    match: bool

# vim: set ts=4 sts=4 sw=4 et ai si sta:
