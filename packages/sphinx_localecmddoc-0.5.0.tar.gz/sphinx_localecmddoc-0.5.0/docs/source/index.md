:::{include} ../../README.md
:::

:::{toctree}
:maxdepth: 3
:caption: Contents
Main page <self>
configuration
Contribution <contribution>
API documentation <apidocs/localecmddoc/localecmddoc>
Example <functions/index>
:::




