from openklant_client.client import OpenKlantClient

__all__ = ["OpenKlantClient"]
