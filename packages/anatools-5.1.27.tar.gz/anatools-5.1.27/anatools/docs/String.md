A string that can be passed to multiple nodes
* "String" - the string