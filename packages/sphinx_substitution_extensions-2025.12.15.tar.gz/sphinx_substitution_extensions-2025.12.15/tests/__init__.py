"""
Tests for the substitution extension.
"""
