Please see [Developer Guidelines](https://docs.plone.org/develop/coredev/docs/guidelines.html)
