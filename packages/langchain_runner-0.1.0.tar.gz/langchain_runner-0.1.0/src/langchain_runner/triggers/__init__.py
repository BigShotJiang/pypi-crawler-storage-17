"""Trigger definitions for langchain-runner."""

from langchain_runner.triggers.base import Trigger

__all__ = ["Trigger"]
