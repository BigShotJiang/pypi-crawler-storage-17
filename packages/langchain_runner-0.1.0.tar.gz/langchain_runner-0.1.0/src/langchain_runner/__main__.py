"""Allow running as python -m langchain_runner."""

from langchain_runner.cli import main

if __name__ == "__main__":
    main()
