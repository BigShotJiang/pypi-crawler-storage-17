"""
WebSocket routes for WASM Web Interface.
"""

from wasm.web.websockets.router import router

__all__ = ["router"]
