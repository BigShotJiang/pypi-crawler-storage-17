"""
API routes for WASM Web Interface.
"""

from wasm.web.api.router import router

__all__ = ["router"]
