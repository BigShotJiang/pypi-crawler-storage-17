import numpy as np
np.seterr(divide='ignore')
