Convert invoices to Peppol XML using the Odoo's account_edi_ubl_cii module.
