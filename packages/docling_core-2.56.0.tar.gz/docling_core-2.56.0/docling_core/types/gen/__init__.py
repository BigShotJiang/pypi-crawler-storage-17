"""Package for models defined by the Generic type."""
