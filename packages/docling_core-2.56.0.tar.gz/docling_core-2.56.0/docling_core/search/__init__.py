"""Package for models and utility functions for search database mappings."""
