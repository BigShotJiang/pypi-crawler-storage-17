"""
Coach Language Server Protocol Implementation

Provides LSP server for IDE integration (VS Code, JetBrains, etc.)
"""

__version__ = "1.0.0"
