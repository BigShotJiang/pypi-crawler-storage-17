# Copyright (C) 2024 Floating Rock Studio Ltd
"""Core functionality modules for fr_env_resolver."""
