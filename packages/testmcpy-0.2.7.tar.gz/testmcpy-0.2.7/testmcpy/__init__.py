"""
testmcpy - MCP Testing Framework

A comprehensive testing framework for validating LLM tool calling
capabilities with MCP (Model Context Protocol) services.
"""

__version__ = "0.2.0"
__author__ = "testmcpy Contributors"
