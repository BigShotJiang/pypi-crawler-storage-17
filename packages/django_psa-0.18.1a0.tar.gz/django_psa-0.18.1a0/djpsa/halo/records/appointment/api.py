from djpsa.halo.api import HaloAPIClient


class AppointmentAPI(HaloAPIClient):
    endpoint = 'Appointment'
