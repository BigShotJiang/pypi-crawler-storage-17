from djpsa.halo.api import HaloAPIClient


class TicketTypeAPI(HaloAPIClient):
    endpoint = 'TicketType'
