from djpsa.halo.api import HaloAPIClient


class StatusAPI(HaloAPIClient):
    endpoint = 'Status'
