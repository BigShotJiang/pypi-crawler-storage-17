from djpsa.halo.api import HaloAPIClient


class TicketAPI(HaloAPIClient):
    endpoint = 'Tickets'
