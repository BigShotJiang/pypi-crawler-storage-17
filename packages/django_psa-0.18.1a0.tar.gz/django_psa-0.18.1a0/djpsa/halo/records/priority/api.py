
from djpsa.halo.api import HaloAPIClient


class PriorityAPI(HaloAPIClient):
    endpoint = 'Priority'
