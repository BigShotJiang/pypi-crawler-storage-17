from djpsa.halo.api import HaloAPIClient


class ActionAPI(HaloAPIClient):
    endpoint = 'Actions'
