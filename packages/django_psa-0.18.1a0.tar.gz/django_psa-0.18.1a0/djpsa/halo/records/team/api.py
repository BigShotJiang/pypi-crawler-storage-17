from djpsa.halo.api import HaloAPIClient


class TeamAPI(HaloAPIClient):
    endpoint = 'Team'
