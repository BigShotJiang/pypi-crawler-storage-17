from djpsa.halo.api import HaloAPIClient


class SLAAPI(HaloAPIClient):
    endpoint = 'SLA'
