import enum


class Interaction(enum.Enum):
    unary = 'unary'
    stream = 'stream'
