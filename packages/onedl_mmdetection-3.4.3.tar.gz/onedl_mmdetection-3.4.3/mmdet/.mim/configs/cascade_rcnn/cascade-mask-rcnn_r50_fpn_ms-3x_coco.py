_base_ = [
    '../common/ms_3x_coco-instance.py',
    '../_base_/models/cascade-mask-rcnn_r50_fpn.py'
]
