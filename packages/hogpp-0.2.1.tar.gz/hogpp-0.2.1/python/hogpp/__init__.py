from ._hogpp import IntegralHOGDescriptor

__all__ = ('IntegralHOGDescriptor',)

__author__ = 'Sergiu Deitsch'
__version__ = '0.2.1'
