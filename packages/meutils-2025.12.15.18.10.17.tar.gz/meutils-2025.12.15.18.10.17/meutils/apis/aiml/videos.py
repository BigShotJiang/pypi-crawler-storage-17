#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : videos
# @Time         : 2025/11/5 18:01
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  : todo https://docs.aimlapi.com/api-references/video-models/minimax/hailuo-02

from meutils.pipe import *
from openai import AsyncOpenAI
from meutils.schemas.video_types import SoraVideoRequest, Video
from meutils.io.files_utils import to_base64, to_url_fal

"""
model
undefined · enum
Possible values: alibaba/wan2.5-i2v-preview
prompt
string · min: 1 · max: 800
The text description of the scene, subject, or action to generate in the video.

image_url
string · uri
A direct link to an online image or a Base64-encoded local image that will serve as the visual base or the first frame for the video.

resolution
string · enum
An enumeration where the short side of the video frame determines the resolution.

Default: 720p
Possible values: 480p720p1080p
duration
integer · enum
The length of the output video in seconds.

Possible values: 510
negative_prompt
string
The description of elements to avoid in the generated video.

enable_prompt_expansion
boolean
Whether to enable prompt expansion.

Default: true
seed
integer
Varying the seed integer is a way to get different results for the same other request parameters. Using the same value for an identical request will produce similar results. If unspecified, a random number is chosen.
"""


class Tasks(object):

    def __init__(self, base_url: Optional[str] = None, api_key: str = None):
        base_url = "https://api.aimlapi.com/v2"
        self.client = AsyncOpenAI(base_url=base_url, api_key=api_key)

    async def create(self, request: SoraVideoRequest):
        payload = {
            "model": request.model,
            "prompt": request.prompt,

            **(request.metadata or {})
        }

        if request.seconds:
            payload["duration"] = int(request.seconds)

        if request.resolution:
            payload['resolution'] = request.resolution

        if request.ratio:
            payload["aspect_ratio"] = request.ratio

        if image_urls := request.input_reference:
            payload['model'] = request.model.replace("text-to-video", "image-to-video").replace("t2v", "i2v")

            # if len(image_urls) > 1:
            #     payload["image_list"] = image_urls
            # else:
            #     payload["image_url"] = image_urls[0]

            payload["image_url"] = image_urls[0]
            payload["image_list"] = image_urls
            # https://aimlapi.com/models/veo-3-1-reference-to-video
            # 模型区分 参考图 首尾帧
            # if any( i in request.model for i in {"veo"}):


        else:
            payload['model'] = request.model.replace("image-to-video", "text-to-video").replace("i2v", "t2v")

        # 首尾帧
        if request.first_frame_image:
            payload["image_url"] = request.first_frame_image
            payload["first_frame_image"] = request.first_frame_image

        if request.last_frame_image:
            payload["last_image_url"] = request.last_frame_image

        if request.video:
            payload["video_url"] = request.video
            if request.model.endswith('edit'):  # kling
                payload['model'] = "klingai/video-o1-video-to-video-edit"
            else:
                payload['model'] = "klingai/video-o1-video-to-video-reference"

        logany(bjson(payload))

        response = await self.client.post(
            path="/video/generations",
            body=payload,
            cast_to=object
        )
        """
        {
    "id": "9913239d-4fa8-47ea-b51d-d313e29caba5:alibaba/wan2.5-i2v-preview",
    "status": "queued",
    "meta": {
        "usage": {
            "tokens_used": 105000
        }
    }
    
    {
    "generation_id": "339995387916622:minimax/hailuo-02",
    "status": "queued",
    "meta": {
        "usage": {
            "tokens_used": 588000
        }
    }
}
}
        """

        logger.debug(bjson(response))

        return response

    async def get(self, task_id: str):
        response = await self.client.get(
            path=f"/video/generations?generation_id={task_id}",
            cast_to=object
        )
        """
        {
    "id": "9913239d-4fa8-47ea-b51d-d313e29caba5:alibaba/wan2.5-i2v-preview",
    "status": "completed",
    "video": {
        "url": "https://cdn.aimlapi.com/alpaca/1d/dd/20251107/30b07d9c/42740107-9913239d-4fa8-47ea-b51d-d313e29caba5.mp4?Expires=1762593280&OSSAccessKeyId=LTAI5tBLUzt9WaK89DU8aECd&Signature=Guk6apyEnKeuniLv0mcBJhkHO%2FI%3D"
    }
}

        """
        logger.debug(bjson(response))

        video = Video(
            id=task_id,
            status=response,
            video_url=(response.get("video") or {}).get("url"),

            error=response.get("error")
        )

        # logger.debug(bjson(video))

        return video


if __name__ == "__main__":
    api_key = "603051fc1d7e49e19de2c67521d4a30e"
    # a63443199c3e42ea90003e0261ccb246
    api_key = "a63443199c3e42ea90003e0261ccb246"

    model = "alibaba/wan2.5-i2v-preview"
    model = "minimax/hailuo-02_1080P"
    model = "kling-video-o1"
    # model = "kling-video-o1-video-to-video-edit" => "klingai/video-o1-video-to-video-edit"

    model = "klingai/video-o1-reference-to-video"

    #         "model": "klingai/video-o1-video-to-video-reference",
    #         "model": "klingai/video-o1-video-to-video-edit",

    data = {
        "model": model,
        "prompt": '''Mona Lisa nervously puts on glasses with her hands and asks her off-screen friend to the left: ‘Do they suit me?’ She then tilts her head slightly to one side and then the other, so the unseen friend can better judge.''',
        "input_reference": "https://s2-111386.kwimgs.com/bs2/mmu-aiplatform-temp/kling/20240620/1.jpeg",
        # "resolution": "480p",
        "seconds": "10",
    }

    data = {
        "model": model,
        "prompt": "A graceful ballerina dancing outside a circus tent on green grass, with colorful wildflowers swaying around her as she twirls and poses in the meadow.",
        "input_reference": [
            "https://storage.googleapis.com/falserverless/example_inputs/veo31-r2v-input-1.png",
            # "https://storage.googleapis.com/falserverless/example_inputs/veo31-r2v-input-2.png",
            # "https://storage.googleapis.com/falserverless/example_inputs/veo31-r2v-input-3.png"
        ]
    }
    data = {
        "model": model,
        "prompt": "A powerful, matte black jeep, its robust frame contrasting with the lush green surroundings, navigates a winding jungle road, kicking up small clouds of dust and loose earth from its tires.",
        "video": "https://storage.googleapis.com/falserverless/example_inputs/krea_wan_14b_v2v_input.mp4"
    }

    # {
    #     "model": "klingai/video-o1-image-to-video",
    #     "prompt": "A jellyfish in the ocean",
    #     "image_url": "https://upload.wikimedia.org/wikipedia/commons/3/35/Maldivesfish2.jpg",
    # }
    # {
    #     "model": "klingai/video-o1-video-to-video-edit",
    #     "prompt": "A powerful, matte black jeep, its robust frame contrasting with the lush green surroundings, navigates a winding jungle road, kicking up small clouds of dust and loose earth from its tires.",
    #     "video_url": "https://storage.googleapis.com/falserverless/example_inputs/krea_wan_14b_v2v_input.mp4"
    # }
    #

    # }

    # {
    #     "model": "klingai/video-v2-6-pro-image-to-video",
    #     "prompt": "A jellyfish in the ocean",
    #     "image_url": "https://upload.wikimedia.org/wikipedia/commons/3/35/Maldivesfish2.jpg",
    # }
    #
    #
    # {
    #     "model": "klingai/video-v2-6-pro-text-to-video",
    #     "prompt": "A DJ on the stand is playing, around a World War II battlefield, lots of explosions, thousands of dancing soldiers, between tanks shooting, barbed wire fences, lots of smoke and fire, black and white old video: hyper realistic, photorealistic, photography, super detailed, very sharp, on a very white background"
    # }

    request = SoraVideoRequest(**data)

    logger.debug(bjson(request))

    #    "id": ,

    tasks = Tasks(api_key=api_key)
    # arun(tasks.create(request))

    # task_id = "9913239d-4fa8-47ea-b51d-d313e29caba5:alibaba/wan2.5-i2v-preview"
    task_id = "0693467d-bdde-4cca-9c1e-32f30be02d9d:klingai/video-o1-video-to-video-reference"

    arun(tasks.get(task_id))
