"""NATS protocol implementation.

Contains the low-level handling of the NATS protocol, including
message parsing, command encoding, and type definitions.
"""
