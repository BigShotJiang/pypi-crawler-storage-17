# test for main module
from test_utils import *

def test_main():
    assert True