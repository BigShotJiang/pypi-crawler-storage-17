"""Sendly SDK Resources"""

from .messages import AsyncMessagesResource, MessagesResource

__all__ = ["MessagesResource", "AsyncMessagesResource"]
