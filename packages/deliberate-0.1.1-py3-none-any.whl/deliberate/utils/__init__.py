"""Utility helpers for Deliberate."""
