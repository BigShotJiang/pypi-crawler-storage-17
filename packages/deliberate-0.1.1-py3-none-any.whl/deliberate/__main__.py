"""Entry point for python -m deliberate."""

from deliberate.cli import app

if __name__ == "__main__":
    app()
