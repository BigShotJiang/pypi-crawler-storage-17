# THIS FILE WAS GENERATED AUTOMATICALLY
# BY: poem-plugins "git" plugin
# NEVER EDIT THIS FILE MANUALLY

version_info = (1, 0, 14)
__version__ = "1.0.14"
