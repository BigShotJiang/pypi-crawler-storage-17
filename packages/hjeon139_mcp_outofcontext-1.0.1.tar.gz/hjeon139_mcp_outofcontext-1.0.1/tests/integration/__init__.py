"""Integration tests for MCP server.

These tests validate end-to-end functionality including MCP protocol communication,
storage layer operations, and complete workflows.
"""
