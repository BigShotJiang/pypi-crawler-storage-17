"""Scripts directory for development utilities."""
