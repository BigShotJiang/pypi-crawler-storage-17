"""Storage layer for context management."""

from .mdc_storage import MDCStorage

__all__ = ["MDCStorage"]
