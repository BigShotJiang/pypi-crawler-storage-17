"""Out of context project."""

__version__ = "1.0.1"
