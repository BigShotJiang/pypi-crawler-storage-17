"""Kryten Shell widgets package."""

from kryten_shell.widgets.command_input import CommandInput

__all__ = ["CommandInput"]
