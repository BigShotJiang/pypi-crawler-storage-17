Once this module is installed you can search project per analytic
account code from any list that point to a project (name search).
