This module add related Analytic account code ( related field
analytic_account_code) on project model.

The name of the project in related model display the analytic account
code (using name_get) and you can search projects by the analytic
account code (name_search) from any list ( ie: collecting timesheets).

Add analytic account code in project kanban card view and add group by
and search by account analytic.
