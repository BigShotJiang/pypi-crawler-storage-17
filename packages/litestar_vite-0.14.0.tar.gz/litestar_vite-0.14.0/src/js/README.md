# Litestar Vite Plugin

**Notice** This is experimental software

## What is this?

This is a library for Litestar and Vite that makes integration between the the two easier.

For details on usage, use the `litestar-vite` [plugin](https://github.com/cofin/litestar-vite)

## Credit

The team at Laravel have done an incredible job at making it easier to use common JS/TS frameworks with the framework.

This plugin is more than a little inspired by the worker here [Laravel's Vite Integration](https://github.com/laravel/vite-plugin)
