#!/usr/bin/env python3

"""Module command line entry point."""

import amg

if __name__ == "__main__":
    amg.cl_main()
