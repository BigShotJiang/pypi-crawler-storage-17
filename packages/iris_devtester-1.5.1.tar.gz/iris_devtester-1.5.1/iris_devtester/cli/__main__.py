"""CLI entry point for python -m iris_devtester.cli execution."""

from .import main

if __name__ == "__main__":
    main()
