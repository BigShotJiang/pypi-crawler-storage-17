from .svm_landmine import SvmLandmine

__all__ = [
    'SvmLandmine',
]
