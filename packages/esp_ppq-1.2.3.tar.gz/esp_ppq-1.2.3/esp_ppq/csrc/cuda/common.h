# include <cmath>
# include <iostream>
# include <vector>

using std::vector;
using int64 = long long;
