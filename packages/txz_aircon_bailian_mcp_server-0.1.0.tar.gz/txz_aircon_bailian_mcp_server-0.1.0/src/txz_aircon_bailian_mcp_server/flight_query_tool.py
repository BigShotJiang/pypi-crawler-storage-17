import requests
def get_hotel_info(api_key, hotel_id):
    url = f"https://api.ctrip.com/hotel/{hotel_id}"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"


    }
    response = requests.get(url, headers=headers)
    if response.status_code == 200:

        return response.json()

    else:

        print(f"Error: {response.status_code}")

        return None



api_key = "你的API Key"

hotel_id = "123456"

hotel_info = get_hotel_info(api_key, hotel_id)

if hotel_info:

    print(hotel_info)
