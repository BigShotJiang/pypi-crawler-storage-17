"""Metadata deduced from git at build time."""

id: str
short_id: str

id = ""
short_id = ""
