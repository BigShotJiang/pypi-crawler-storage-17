# HelpDesk Report
This report provides a view of all tickets received and emmited from your account.

Report accepts to limit the output by:

* Ticket creation date
* Ticket status