class SheetNotFoundError(Exception):
    pass
