AVAILABLE_REPORTS = """
# Available reports


| ID | Name |
|:--------|:--------|
"""
