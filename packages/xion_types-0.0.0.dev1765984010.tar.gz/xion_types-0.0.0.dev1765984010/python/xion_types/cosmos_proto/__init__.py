"""Stub for cosmos_proto - not used in Python protobuf"""
