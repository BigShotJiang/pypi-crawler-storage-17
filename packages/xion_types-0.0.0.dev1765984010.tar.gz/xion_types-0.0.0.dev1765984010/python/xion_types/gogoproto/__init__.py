"""Stub for gogoproto - not used in Python protobuf"""
