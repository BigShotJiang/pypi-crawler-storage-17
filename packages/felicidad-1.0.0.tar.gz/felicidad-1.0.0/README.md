"""

# 🥳 felicidad

> Tu dosis diaria de felicidad programática

[![PyPI version](https://badge.fury.io/py/felicidad.svg)](https://badge.fury.io/py/felicidad)
[![Python Version](https://img.shields.io/pypi/pyversions/felicidad.svg)](https://pypi.org/project/felicidad/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 🎄 ¡Ahora con modo especial de Navidad! 🎄

¿Cansado de bugs? ¿Estresado por los deadlines? ¿Necesitas un momento de alegría en tu día de código?

**felicidad** es una librería de Python que te ayuda a mantener el ánimo alto mientras programas. Porque todos merecemos un poco de felicidad, incluso en medio de un stack trace.

## 🚀 Instalación

```bash
pip install felicidad
```

## 📖 Uso

### Desde la línea de comandos

```bash
felicidad
```

### Como librería en Python

```python
from felicidad import Happiness

h = Happiness()

# Ver tu nivel de felicidad
h.get_level()

# Recibir una afirmación positiva
h.affirmation()

# Escuchar un chiste
h.joke()

# Modo especial de Navidad 🎄
h.christmas()

# Y mucho más...
```

## ✨ Características

- 📊 **Medidor de felicidad**: Visualiza tu nivel de ánimo con una barra de progreso
- 💭 **Afirmaciones positivas**: Mensajes motivacionales para programadores
- 💡 **Consejos del día**: Tips para mantener tu bienestar mientras codeas
- 😄 **Chistes de programación**: Porque la risa es la mejor medicina
- 🧘 **Mini meditaciones**: Pausas guiadas de 10 segundos
- 🙏 **Ejercicio de gratitud**: Agradece las pequeñas cosas del mundo dev
- 🎨 **Arte ASCII**: Visuales alegres en tu terminal
- 🏥 **Checkup completo**: Evaluación integral de tu estado de ánimo
- 🎄 **Modo Navidad**: Especial para las fiestas decembrinas

## 🎄 Modo Navidad

Durante diciembre, `felicidad` se viste de fiesta con:

- Árbol de Navidad en ASCII
- Mensajes navideños especiales
- Villancico del programador
- Regalos de código bajo el árbol
- Boost navideño extra de felicidad
- Activa con "🎄", "navidad" o "christmas"

## 📝 Ejemplo de uso

```python
from felicidad import Happiness

h = Happiness()
h.get_level()        # Muestra: 🥳 NIVEL DE FELICIDAD: 85%
h.affirmation()      # "¡Eres un desarrollador increíble!"
h.joke()             # Cuenta un chiste de programación
h.christmas()        # 🎄 Activa el modo navideño
```

## 🤝 Contribuir

Las contribuciones son bienvenidas. Por favor:

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📜 Licencia

Este proyecto está bajo la Licencia MIT - mira el archivo [LICENSE](LICENSE) para más detalles.

## 😎 Autor

Creado por [XzLuizem](https://github.com/XzLuizem)

## 🌟 ¿Te gustó?

Si este proyecto te hizo sonreír, dale una ⭐ en GitHub y compártelo con otros desarrolladores que necesiten un poco de felicidad.

---

**Nota**: Esta librería es un proyecto de humor y bienestar. No reemplaza ayuda profesional si estás experimentando problemas serios de salud mental. Si necesitas ayuda, por favor busca un profesional.

```python
>>> pip install felicidad
>>> from felicidad import Happiness
>>> h = Happiness()
>>> h.christmas()
🎄✨ MODO NAVIDAD ACTIVADO ✨🎄
```

¡Feliz código y felices fiestas! 🎄💻✨
"""
