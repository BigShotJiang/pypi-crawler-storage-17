"""
felicidad - Tu dosis diaria de felicidad programática
pip install felicidad
"""

__version__ = "1.0.0"
__author__ = "XzLuizem"
__email__ = "luism.jim7@gmail.com"

from .core import Happiness

__all__ = ["Happiness"]
