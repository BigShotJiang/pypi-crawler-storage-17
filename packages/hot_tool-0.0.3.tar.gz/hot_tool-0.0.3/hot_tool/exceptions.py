class HotToolImplementationNotFoundError(Exception):
    pass


class HotMultipleToolImplementationsFoundError(Exception):
    pass
