Matchings
=========

.. automodule:: mapof.core.matchings
    :members:

