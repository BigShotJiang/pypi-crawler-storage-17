Initial Positions
=================

.. automodule:: mapof.core.embedding.initial_positions
    :members:

