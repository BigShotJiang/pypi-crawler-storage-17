Embed
=====

.. automodule:: mapof.core.embedding.embed
    :members:

