.. _installation:

Installation
============

Mapof is hosted on `PyPI <https://pypi.org/project/mapof/>`_ you can thus
easily install it by using:

.. code-block:: shell

    pip3 install mapof

The source code is hosted on `GitHub repository <https://github.com/science-for-democracy/mapof>`_
as well.
