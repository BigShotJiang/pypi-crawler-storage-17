Code Reference
==============


.. toctree::
    :hidden:

    embedding/index
    features/index
    distances/index
    objects/index
    persistence/index
    matchings
    printing
    utils

