Family Object
=============

.. automodule:: mapof.core.objects.Family
    :members:

