.. _quickstart:

Quick Start
===========

Organisation of the package
---------------------------

To be updated.