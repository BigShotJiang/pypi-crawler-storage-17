Features
========

.. toctree::
    :maxdepth: 2

    common
    distortion
    mallows
    monotonicity
    stability
