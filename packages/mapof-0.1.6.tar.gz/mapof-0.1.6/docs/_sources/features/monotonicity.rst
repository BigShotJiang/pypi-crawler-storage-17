Monotonicity
============

.. automodule:: mapof.core.features.monotonicity
    :members:

