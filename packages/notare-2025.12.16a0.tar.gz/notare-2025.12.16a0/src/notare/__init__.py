"""music_score_sk - swiss knife CLI utilities for music score files."""

__all__ = ["__version__"]
__version__ = "0.1.0"
