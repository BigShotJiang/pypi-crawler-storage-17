# ------------ Constants for Testing ------------
DEFAULT_HOST = 'http://localhost:8080'
DEFAULT_NETWORK_ID = 1001
SEVEN_DAYS_S = 7 * 24 * 60 * 60
