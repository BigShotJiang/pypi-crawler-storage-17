// See COPYRIGHT.md for copyright information

export function ViewerOptions() {
    this.showPrefixes = true;
    this.language = null;
}
