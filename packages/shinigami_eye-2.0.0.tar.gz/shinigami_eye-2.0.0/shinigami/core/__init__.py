"""Core package initialization"""

__all__ = []
