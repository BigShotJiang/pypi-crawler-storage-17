"""
SHINIGAMI-EYE (神死眼)
All-Seeing Cybersecurity Framework
"""

__version__ = "2.0.0"
__author__ = "Mauro"
__email__ = "maauro.rs@gmail.com"
