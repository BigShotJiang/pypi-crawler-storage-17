"""LLaCIE: an LLM-based clinical information extraction toolkit.

This package provides numerous modules to support the above functionality
but the primary interface is CLI-based and lives in scripts/llacie.py"""