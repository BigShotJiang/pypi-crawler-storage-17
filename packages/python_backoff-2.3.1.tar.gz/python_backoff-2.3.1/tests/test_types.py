from backoff.types import Details


assert Details  # type: ignore[truthy-function]
