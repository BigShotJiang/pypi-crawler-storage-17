from ._typing import Details

__all__ = [
    "Details",
]
