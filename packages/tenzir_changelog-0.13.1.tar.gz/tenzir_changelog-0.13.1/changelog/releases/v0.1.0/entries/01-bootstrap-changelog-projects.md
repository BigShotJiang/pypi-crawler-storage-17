---
title: Bootstrap changelog projects interactively
type: feature
authors:
- codex
created: 2025-10-21
---

Ship the `tenzir-changelog bootstrap` command to scaffold a changelog workspace, prompting for project metadata, guessing the default GitHub repository, and preparing config and directories for immediate use.
