from .core import ComponentBase


class LazyLLMValidateBase(ComponentBase):
    pass
