from .pp_ocr import OCRDeploy

__all__ = [
    'OCRDeploy'
]
