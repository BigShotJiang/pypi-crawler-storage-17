# Copyright (c) 2023 Varun Sharma
#
# SPDX-License-Identifier: MIT

__version__ = "0.4.0"

from .sphinx_datatables import setup
