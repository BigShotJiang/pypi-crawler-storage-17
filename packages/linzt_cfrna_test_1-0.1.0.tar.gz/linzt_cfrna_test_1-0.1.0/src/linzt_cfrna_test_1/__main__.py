from linzt_cfrna_test_1 import main

main()
