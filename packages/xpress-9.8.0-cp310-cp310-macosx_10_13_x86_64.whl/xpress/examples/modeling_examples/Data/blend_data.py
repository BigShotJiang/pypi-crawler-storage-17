# Data file for 'blend.py'
COST = [85, 93]
AVAIL = [60, 45]
GRADE = [2.1, 6.3]
