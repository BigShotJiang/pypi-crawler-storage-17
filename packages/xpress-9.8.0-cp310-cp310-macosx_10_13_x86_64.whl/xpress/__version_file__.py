# Version of the Python interface (must match that of the Xpress Optimizer Library)
__version_library__ = '46.01.01'
__version__ = '9.8.0'
