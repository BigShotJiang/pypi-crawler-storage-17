"""Tests for GAM MCP Server."""
