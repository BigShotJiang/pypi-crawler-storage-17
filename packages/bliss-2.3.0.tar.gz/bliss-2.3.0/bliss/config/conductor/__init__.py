"""
.. autosummary::
   :toctree:

   client
   connection
   protocol
"""
