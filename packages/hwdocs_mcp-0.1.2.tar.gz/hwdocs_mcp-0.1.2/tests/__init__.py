"""Tests for hwdocs-mcp."""
