"""Base test classes for standard testing.

To learn how to use these, see the guide on
[integrating standard tests](https://docs.langchain.com/oss/python/contributing/standard-tests-langchain).
"""
