### pytest-embedded-arduino

pytest embedded service for Arduino project

Extra Functionalities:

```{eval-rst}
.. tabs::

   .. group-tab:: `pytest-embedded-serial-esp` activated

        - `app`: Parse Arduino's build directory and gather more information.
        - `serial`: Auto flash the built binary into the target board at the beginning when running test cases.

   .. group-tab:: `pytest-embedded-serial-esp` NOT activated

        - `app`: Parse Arduino's build directory and gather more information.
```
