"""Low-level format parsers for model files."""
