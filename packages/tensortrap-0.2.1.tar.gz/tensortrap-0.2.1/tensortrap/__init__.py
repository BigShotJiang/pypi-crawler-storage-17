"""TensorTrap - Security scanner for AI/ML model files."""

__version__ = "0.2.0"
