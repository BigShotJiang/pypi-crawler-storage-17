"""Entry point for python -m tensortrap."""

from tensortrap.cli import app

if __name__ == "__main__":
    app()
