API Reference
-------------

icalendar.attr
++++++++++++++

.. automodule:: icalendar.attr
   :members:

icalendar.alarms
++++++++++++++++

.. automodule:: icalendar.alarms
   :members:

icalendar.cal
+++++++++++++

.. automodule:: icalendar.cal
   :members:

icalendar.caselessdict
++++++++++++++++++++++

.. automodule:: icalendar.caselessdict
   :members:

icalendar.cli
+++++++++++++

.. automodule:: icalendar.cli
   :members:

icalendar.enums
+++++++++++++++

.. automodule:: icalendar.enums
   :members:

icalendar.error
+++++++++++++++

.. automodule:: icalendar.error
   :members:

icalendar.param
+++++++++++++++

.. automodule:: icalendar.param
   :members:

icalendar.parser
++++++++++++++++

.. automodule:: icalendar.parser
   :members:

icalendar.parser_tools
++++++++++++++++++++++

.. automodule:: icalendar.parser_tools
   :members:

icalendar.prop
++++++++++++++

.. automodule:: icalendar.prop
   :members:

icalendar.tools
+++++++++++++++

.. automodule:: icalendar.tools
   :members:

icalendar.timezone
++++++++++++++++++

.. automodule:: icalendar.timezone
   :members:

.. automodule:: icalendar.timezone.tzid
   :members:

.. automodule:: icalendar.timezone.tzp
   :members:

icalendar.version
+++++++++++++++++

.. automodule:: icalendar.version
   :members:
