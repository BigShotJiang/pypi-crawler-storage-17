# Typed Bitmart

> A fully typed, validated async client for the Bitmart API

Use *autocomplete* instead of documentation.

🚧 Under construction.