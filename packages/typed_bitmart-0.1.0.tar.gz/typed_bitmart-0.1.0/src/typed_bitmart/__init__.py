"""
### Typed Bitmart
> A fully typed, validated async client for the Bitmart API

- Details
"""