"""
FastDjango test suite.
"""
