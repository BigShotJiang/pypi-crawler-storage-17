
DEFAULT_ENDPOINT_CONFIG = {
    "model": "fara-7b",
    "base_url": "http://127.0.0.1:1234/v1",
    "api_key": "not-needed",
}
