# USER_AGENT_TEMPLATE = "Mozilla/5.0 (Linux; Android %s; %s) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%s.0.0.0 Mobile Safari/537.36"

ANDROID_CLIENT_ID = "HIOMIAS39CA9DICTA7JIO64LQKQJF5AGIK74G9ITJKLNEDAOH5FHS5G1JI7FOEGD"

ANDROID_CLIENT_SECRET = (
    "V9M870DE342BGHFRUJ5FTCGCUA1482AN0DI8C5TFI9ULMA89H10N60NOP8I4JMVS"
)

# Используется для прямой авторизации. Этот способ мной не используется, так как
# для отображения капчи все равно нужен webview.
# K811HJNKQA8V1UN53I6PN1J1CMAD2L1M3LU6LPAU849BCT031KDSSM485FDPJ6UF

# Кривой формат, который используют эти долбоебы
INVALID_ISO8601_FORMAT = "%Y-%m-%dT%H:%M:%S%z"
