Recipes
=======

Here are some useful recipes I use.

.. toctree::
   :caption: Recipes
   :maxdepth: 1

   1. Exploring graph properties <recipes/recipe_1>
