Utilities
=========
