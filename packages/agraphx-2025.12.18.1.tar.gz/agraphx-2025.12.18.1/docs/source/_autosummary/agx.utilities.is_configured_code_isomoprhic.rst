agx.utilities.is\_configured\_code\_isomoprhic
==============================================

.. currentmodule:: agx.utilities

.. autofunction:: is_configured_code_isomoprhic