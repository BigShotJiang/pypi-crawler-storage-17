agx.Node
========

.. currentmodule:: agx

.. autoclass:: Node
   :members:
   :inherited-members:
   :undoc-members:
   :show-inheritance:


   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Node.id
      ~Node.type_id
      ~Node.num_connections
   
   