agx.NodeType
============

.. currentmodule:: agx

.. autoclass:: NodeType
   :members:
   :inherited-members:
   :undoc-members:
   :show-inheritance:


   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~NodeType.type_id
      ~NodeType.num_connections
   
   