agx.Configuration
=================

.. currentmodule:: agx

.. autoclass:: Configuration
   :members:
   :inherited-members:
   :undoc-members:
   :show-inheritance:


   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Configuration.get_hashable_idx_dict
      ~Configuration.get_node_dictionary
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Configuration.idx
      ~Configuration.node_types
      ~Configuration.node_idx_dict
   
   