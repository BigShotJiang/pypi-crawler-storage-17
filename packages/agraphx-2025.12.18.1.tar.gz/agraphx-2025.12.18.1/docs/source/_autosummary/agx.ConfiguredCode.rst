agx.ConfiguredCode
==================

.. currentmodule:: agx

.. autoclass:: ConfiguredCode
   :members:
   :inherited-members:
   :undoc-members:
   :show-inheritance:


   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~ConfiguredCode.get_graph
      ~ConfiguredCode.is_isomorphic
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ConfiguredCode.topology_code
      ~ConfiguredCode.configuration
   
   