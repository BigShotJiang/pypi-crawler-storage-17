"""utilities package."""

from agx._internal.utilities import is_configured_code_isomoprhic

__all__ = ["is_configured_code_isomoprhic"]
