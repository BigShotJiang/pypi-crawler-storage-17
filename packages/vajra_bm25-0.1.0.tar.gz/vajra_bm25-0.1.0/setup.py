"""Backward-compatible setup.py - all configuration in pyproject.toml"""
from setuptools import setup

setup()
