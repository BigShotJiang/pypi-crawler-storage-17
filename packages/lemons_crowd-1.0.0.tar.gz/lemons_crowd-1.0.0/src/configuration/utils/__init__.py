"""Utils subpackage provides basic useful functions, constants definitions and custom typing definitions."""
