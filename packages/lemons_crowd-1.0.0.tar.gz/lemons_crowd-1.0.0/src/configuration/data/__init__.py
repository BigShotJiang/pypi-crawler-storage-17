"""Data subpackage provides the module datafactory to prepare the data for a later use within the app."""
