"""Models subpackage contains the main classes definition used to create the crowd and agents within it."""
