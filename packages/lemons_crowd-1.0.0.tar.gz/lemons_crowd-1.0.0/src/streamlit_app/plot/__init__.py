"""Plot subpackage provides the module plot containing plot functions necessary to display crowd and data information."""
