"""Tabs subpackage provides functions for creating tabs in the app."""
