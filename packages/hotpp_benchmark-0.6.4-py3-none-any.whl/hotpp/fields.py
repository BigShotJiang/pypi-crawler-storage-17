PRESENCE = "_presence"
PRESENCE_PROB = "_presence_prob"
LABELS_LOGITS = "_labels_logits"
