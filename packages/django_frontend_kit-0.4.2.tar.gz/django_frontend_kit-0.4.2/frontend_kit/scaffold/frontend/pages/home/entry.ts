alert("Django frontend works");

