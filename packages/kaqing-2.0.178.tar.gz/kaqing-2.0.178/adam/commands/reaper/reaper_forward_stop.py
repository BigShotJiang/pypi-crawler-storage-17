from adam.commands.command import Command
from adam.commands.reaper.reaper_forward_session import ReaperForwardSession
from adam.commands.reaper.utils_reaper import Reapers
from adam.repl_state import ReplState, RequiredState
from adam.utils import log2

class ReaperForwardStop(Command):
    COMMAND = 'reaper forward stop'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ReaperForwardStop, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ReaperForwardStop.COMMAND

    def required(self):
        return RequiredState.CLUSTER

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        with self.validate(args, state) as (args, state):
            if not Reapers.pod_name(state):
                return state

            ReaperForwardSession.is_forwarding = False
            ReaperForwardSession.stopping.set()
            log2("Stopped reaper forward session.")

            return state

    def completion(self, state: ReplState):
        return super().completion(state)

    def help(self, _: ReplState):
        return f'{ReaperForwardStop.COMMAND}\t stop port-forward to reaper'