from adam.commands.postgres.utils_postgres import pg_table_names
from adam.repl_state import ReplState
from adam.sql.sql_completer import SqlCompleter

def psql_completions(state: ReplState):
    return {
        '\h': None,
        '\d': None,
        '\dt': None,
        '\du': None
    } | SqlCompleter(lambda: pg_table_names(state)).completions_for_nesting()