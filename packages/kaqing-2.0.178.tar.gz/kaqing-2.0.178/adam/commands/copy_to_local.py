from functools import partial
import click
import pyperclip

from adam.commands import validate_args
from adam.commands.command import Command, InvalidArgumentsException
from adam.commands.command_helpers import ClusterOrPodCommandHelper
from adam.commands.cli_commands import CliCommands
from adam.commands.devices.devices import Devices
from adam.repl_state import ReplState, RequiredState
from adam.utils import tabulize, log, log2
from adam.utils_k8s.pods import Pods

class CopyToLocal(Command):
    COMMAND = 'cp'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(CopyToLocal, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return CopyToLocal.COMMAND

    def required(self):
        return [RequiredState.CLUSTER_OR_POD, RequiredState.APP_APP, ReplState.P]

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        with self.validate(args, state) as (args, state):
            with validate_args(args, state, name='file'):
                Pods.download_file(state.pod, 'cassandra', state.namespace, args[0], args[1] if len(args) > 1 else None)

                return state

    def completion(self, state: ReplState):
        if super().completion(state):
            return Devices.device(state).cat_completion(CopyToLocal.COMMAND, state, default={})

        return {}

    def help(self, _: ReplState):
        return f'{CopyToLocal.COMMAND} from-file [to-file]\t copy file from pod to local'