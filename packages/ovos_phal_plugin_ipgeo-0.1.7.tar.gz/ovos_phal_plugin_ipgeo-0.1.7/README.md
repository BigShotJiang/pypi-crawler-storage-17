# PHAL plugin - IPGeo

Autoconfigure default location based on ip address via [ip-api.com](https://ip-api.com)

> **This will not overwrite** user defined configuration, only populates values if missing

`City`, `regionName` and `country` will be also be localized to your language if possible

Supported langs: `"en", "de", "es", "pt", "fr", "ja", "zh", "ru"`