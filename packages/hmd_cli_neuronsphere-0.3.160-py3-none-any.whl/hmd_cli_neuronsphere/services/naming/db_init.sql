CREATE USER hmd_ms_naming WITH PASSWORD 'hmd_ms_naming';

CREATE DATABASE hmd_ms_naming;

GRANT ALL PRIVILEGES ON DATABASE hmd_ms_naming TO hmd_ms_naming;