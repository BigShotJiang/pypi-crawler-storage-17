# part of copr backend
# skvidal@fedoraproject.org - seth vidal
# (c) copyright Red Hat, Inc 2012
# gplv2+

__version__ = "0.1"
__author__ = "Seth Vidal"
