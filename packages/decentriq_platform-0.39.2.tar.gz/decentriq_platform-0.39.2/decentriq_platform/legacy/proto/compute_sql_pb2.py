from ...proto.compute_sql_pb2 import *
