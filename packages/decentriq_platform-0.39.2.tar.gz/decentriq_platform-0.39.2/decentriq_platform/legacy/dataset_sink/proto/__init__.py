from .dataset_sink_pb2 import (
    AllFiles,
    DatasetSinkWorkerConfiguration,
    FileSelection,
    RawFile,
    SingleFile,
    SinkInput,
    ZipFile,
)
