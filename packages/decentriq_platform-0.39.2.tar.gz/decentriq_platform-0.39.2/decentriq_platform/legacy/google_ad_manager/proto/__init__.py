from .google_ad_manager_pb2 import (
    GoogleAdManagerWorkerConfiguration,
    RawFile,
    SingleFile,
    SinkInput,
    ZipFile,
)
