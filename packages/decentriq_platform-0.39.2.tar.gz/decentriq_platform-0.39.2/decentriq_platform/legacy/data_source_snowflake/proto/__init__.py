from .data_source_snowflake_pb2 import (
    DataSourceSnowflakeWorkerConfiguration,
    SnowflakeSource,
)
