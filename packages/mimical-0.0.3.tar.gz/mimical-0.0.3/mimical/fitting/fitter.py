import numpy as np
import matplotlib.pyplot as plt
import petrofit as pf
from astropy.convolution.utils import discretize_model
import corner
from nautilus import Sampler
import time
import os
from astropy.modeling import models
import pandas as pd

from .prior_handler import priorHandler
from ..plotting import Plotter

from ..utils import filter_set

dir_path = os.getcwd()
if not os.path.isdir(dir_path + "/mimical"):
    os.system('mkdir ' + dir_path + "/mimical")
    os.system('mkdir ' + dir_path + "/mimical/plots")
    os.system('mkdir ' + dir_path + "/mimical/posteriors")



class mimical(object):
    """ Bayesian Observer of Galaxies - Fit.
    Fits multi-filter images of galaxies simultaeneously using Petrofit and Nautilus
    by specifying either an individual filter dependency for model parameters or
    a user-specified order polynomial. By default a Sersic profile is used however any
    Astropy model can be specified.

    Parameters
    ----------

    id : str
        An ID for the fitting run. Only really used for output files.

    images : array
        A 3D array of image data with slices for each filter. Each image
        must be the same shape.

    filt_list : list - str
        A list of path strings to the filter transmission curve files, relative
        to the current working directory. Must be in ascending order with effective wavelength.

    psfs : array
        A 3D array of normalised PSF images with slices for each filter. Each PSF image
        must be the same shape, and the same shape as the data images.

    astropy_model : array
        Astropy Fittable2DModel used to model the image data. The subsequent prior must include
        only and all parameters in the astropy_model.parameters variable, as well as a 'psf_pa' parameter.

    user_prior : dict
        The user specified prior which set out the priors for the model parameters
        and passes information about whether to let these vary for each filter or
        whether they follow an order-specified polynomial relationship.
    """


    def __init__(self, id, images, filt_list, psfs, user_prior, astropy_model=models.Sersic2D(), pool=None):
        
        self.id = id

        print(f"Fitting object {id}")
        self.images = images
        self.psfs = psfs
        self.user_prior = user_prior
        self.astropy_model = astropy_model

        # Using the filter files, find the name of the filters and the effective wavelengths.
        self.filter_names = [x.split('/')[-1] for x in filt_list]
        self.wavs = filter_set([dir_path+'/'+x for x in filt_list]).eff_wavs / 1e4

        # Initiate the prior handler object, used to parse and translate priors and parameters.
        self.prior_handler = priorHandler(user_prior, self.filter_names, self.wavs)

        # Translate user specified prior into a prior parseable by nautlius.
        self.fitter_prior = self.prior_handler.translate()
        print(f"Fitting with parameters: {self.fitter_prior.keys}")

        self.t0 = time.time()
        self.calls = 0

        self.pool = pool




    def lnlike(self, param_dict):
        """ Returns the log-likelihood for a given parameter vector. """

        # Translate parameter vector into model parameters in each filter.
        pars = self.prior_handler.revert(param_dict, self.wavs)

        # Define empty arrays for models and rms images.
        models = np.zeros_like(self.images)
        rms = np.zeros_like(self.images)
    
        # Loop over filters
        for i in range(len(self.wavs)):
            # Update the model and evaluate over a pixel grid.
            self.convolved_models[i].parameters = pars[i]
            model = discretize_model(model=self.convolved_models[i], 
                                     x_range=[0,self.images[i].shape[1]], 
                                     y_range=[0,self.images[i].shape[0]], 
                                     mode='center')

            # If, for whatever reason, the model has NaNs, set to zero and blow up errors.
            if np.isnan(np.sum(model)):
                models[i] = np.zeros_like(model)
                rms[i] = np.zeros_like(model) + 1e99

            # Else, append to respective arrays.
            else:
                models[i] = model
                rms[i] = param_dict['rms'] + (param_dict['rms_sersic']*np.sqrt(np.abs(model)))
                #rms[i] += 1.483 * median_abs_deviation(self.images[i].flatten())


        # Broadcast the 3D data and model arrays and sum through the resulting 3D log-likelihood array.
        log_like_array = np.log((1/(np.sqrt(2*np.pi*(rms**2))))) + ((-(self.images - models)**2) / (2*(rms**2)))
        log_like = np.sum(log_like_array.flatten())

        # Print calls
        self.calls+=1
        if not self.calls % 100:
            #print('Time % 100: ' + str(time.time()-self.t0))
            self.t0 = time.time()

        return(log_like)




    def fit(self):
        """ Runs the Nautlius sampler to fit models, and processes its output. """

        # Define empty models for each filter
        sersic_model = self.astropy_model
        self.convolved_models = []
        for i in range(len(self.wavs)):
            self.convolved_models.append(pf.PSFConvolvedModel2D(sersic_model, psf=self.psfs[i], oversample=(self.images.shape[2]/2, self.images.shape[1]/2, 15, 10)))

        # Check that the user specified prior contains the same parameters as the user specified model.
        if list(self.convolved_models[0].param_names) != list(self.user_prior.keys()):
            raise Exception("Prior labels do not match model parameters.")
        

        if os.path.isfile(dir_path+'/bogout/posteriors' + f'/{self.id}.txt'):
            samples = pd.read_csv(dir_path+'/bogout/posteriors' + f'/{self.id}.txt', delimiter=' ').to_numpy()
        
        else:
            # Run sampler
            t0 = time.time()
            #sampler = Sampler(self.fitter_prior, self.lnlike, n_live=400, filepath= dir_path+'/bogout'+f'/{self.id}.hdf5', resume=True, pool=self.pool)
            sampler = Sampler(self.fitter_prior, self.lnlike, n_live=400, pool=self.pool)
            sampler.run(verbose=True, timeout=2700)
            print(f"Sampling time (minutes): {(time.time()-t0)/60}")

            # Sample the posterior information
            points, log_w, log_l = sampler.posterior()

            # Plot and save the corner plot
            corner.corner(points, weights=np.exp(log_w), bins=20, labels=np.array(self.fitter_prior.keys), color='purple', plot_datapoints=False, range=np.repeat(0.999, len(self.fitter_prior.keys)))
            plt.savefig(dir_path+'/bogout/plots' + f'/corner_{self.id}.pdf', bbox_inches='tight')

            # Sample an appropriately weighted posterior for representative samples.
            n_post = 10000
            indices = np.random.choice(np.arange(points.shape[0]), size = n_post, p=np.exp(log_w))
            samples = points[indices]
            samples_df = pd.DataFrame(data=samples, columns=self.fitter_prior.keys)
            samples_df.to_csv(dir_path+'/bogout/posteriors' + f'/{self.id}.txt', sep=' ', index=False)


        # Plot and save the median-parameter fit
        Plotter().plot_median(self.images, self.wavs, self.convolved_models, samples, list(self.fitter_prior.keys), self.prior_handler)
        plt.savefig(dir_path+'/bogout/plots' + f'/{self.id}_best_model.pdf', bbox_inches='tight')

        # Return the median-parameter model
        fit_dic = dict(zip((np.array((list(self.fitter_prior.keys)))+"_50").tolist(), np.median(samples, axis=0).tolist()))

        print("Finished.")
        print(" ")

        return fit_dic
   
