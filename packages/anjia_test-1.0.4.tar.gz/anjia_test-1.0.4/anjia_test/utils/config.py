import os
import json
from pathlib import Path

# 1. 基础配置（极简）
CONFIG_FILENAME = "anjia_config.json"  # 本地配置文件名（当前目录）
# 内置默认配置（用户要修改的字段）
DEFAULT_CONFIG = {
    "log_level": "info",
    "camera_name": "",
    "xpath_first_camera_name": "(//android.view.View)[19]/*[1]",
    "xpath_preview_area": '//*[@resource-id="camera"]',
    "xpath_play_btn": "(//android.widget.Image)[9]"
}
# 全局配置实例（加载后直接用）
CONFIG = {}

# 2. 核心加载函数（无热更新、无多线程）
def load_config():
    """加载配置：首次运行生成文件，后续读取本地文件，无热更新"""
    global CONFIG
    config_path = Path.cwd() / CONFIG_FILENAME  # 配置文件在当前工作目录

    # 首次运行：自动生成默认配置文件
    if not config_path.exists():
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_CONFIG, f, indent=4, ensure_ascii=False)
        print(f"✅ 已在当前目录生成配置文件：{config_path}")
        CONFIG = DEFAULT_CONFIG.copy()
    # 非首次运行：读取本地配置文件
    else:
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                local_config = json.load(f)
            # 合并配置（本地文件缺失字段时，用默认值兜底）
            CONFIG = DEFAULT_CONFIG.copy()
            CONFIG.update(local_config)
            print(f"✅ 已加载本地配置文件：{config_path}")
        # 配置文件格式错误时，用默认值并提示
        except json.JSONDecodeError:
            print(f"❌ 配置文件{config_path}格式错误，使用默认配置")
            CONFIG = DEFAULT_CONFIG.copy()

# 3. 初始化（运行时自动加载）
load_config()