"""Entry point for running agent server as module."""

from .server import main

if __name__ == '__main__':
    main()
