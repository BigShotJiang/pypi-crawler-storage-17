FIXME:
For the time being we also have a few python scripts - until they are refactored a bit so they can live in the starbash-recipes github tree.