from __init__ import *

algopython_init()

move_smartivo_square(1,1)
light(2,1,10,'blue')
light(1,1,10,'red')
light(2,1,10,'blue')
move('A',1,10,1)
move('B',1,10,1)
# move('A',1,10,1)
# hand_motion_detection()
# light(1,1,10,'red')
# light(2,1,10,'blue')

algopython_exit()
