# Typed Bullish

> A fully typed, validated async client for the Bullish API

Use *autocomplete* instead of documentation.

🚧 Under construction.