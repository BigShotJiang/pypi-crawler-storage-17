"""
### Typed Bullish
> A fully typed, validated async client for the Bullish API

- Details
"""