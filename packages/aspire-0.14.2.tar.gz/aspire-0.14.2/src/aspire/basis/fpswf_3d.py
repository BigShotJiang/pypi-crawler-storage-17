from aspire.basis.pswf_3d import PSWFBasis3D


class FPSWFBasis3D(PSWFBasis3D):
    pass
