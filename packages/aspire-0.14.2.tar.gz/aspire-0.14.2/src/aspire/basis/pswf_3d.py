from aspire.basis import Basis


class PSWFBasis3D(Basis):
    pass
