2025-11-10 Version: 2.2.2
- Update API GetAccount: add response parameters Body.Account.SecureMobilePhone.


2025-11-10 Version: 2.2.2
- Update API GetAccount: add response parameters Body.Account.SecureMobilePhone.


2025-11-10 Version: 2.2.2
- Update API GetAccount: add response parameters Body.Account.SecureMobilePhone.


2025-08-19 Version: 2.2.1
- Generated python 2022-04-19 for ResourceDirectoryMaster.

2025-03-19 Version: 2.2.0
- Support API SetMemberDisplayNameSyncStatus.


2025-02-12 Version: 2.1.1
- Update API GetResourceDirectory: update response param.
- Update API ListControlPolicies: add param Tag.
- Update API ListControlPolicies: update response param.


2025-01-16 Version: 2.1.0
- Support API UpdatePayerForAccount.
- Update API ListAccounts: add param MaxResults.
- Update API ListAccounts: add param NextToken.
- Update API ListAccounts: update response param.


2024-09-29 Version: 2.0.5
- Update API ListFoldersForParent: add param Tag.
- Update API ListFoldersForParent: update response param.


2024-09-29 Version: 2.0.5
- Update API ListFoldersForParent: add param Tag.
- Update API ListFoldersForParent: update response param.


2024-08-15 Version: 2.0.4
- Update API CreateControlPolicy: add param Tag.
- Update API CreateFolder: add param Tag.


2024-05-06 Version: 2.0.3
- Update API GetAccount: update response param.


2024-03-14 Version: 2.0.2
- Update API CreateResourceAccount: add param DryRun.
- Update API EnableResourceDirectory: add param DryRun.
- Update API ListAccounts: update response param.
- Update API ListAccountsForParent: update response param.
- Update API UpdateAccount: add param DryRun.


2023-12-18 Version: 2.0.1
- Generated python 2022-04-19 for ResourceDirectoryMaster.

2023-08-23 Version: 2.0.0
- Generated python 2022-04-19 for ResourceDirectoryMaster.

2023-08-21 Version: 1.1.0
- Generated python 2022-04-19 for ResourceDirectoryMaster.

2023-08-06 Version: 1.0.4
- Generated python 2022-04-19 for ResourceDirectoryMaster.

2023-07-26 Version: 1.0.3
- Support for inviting account to a specified folder.
- The invitation link supports folder authentication.

2023-05-04 Version: 1.0.2
- Support for inviting account to a specified folder.
- The invitation link supports folder authentication.

2023-04-12 Version: 1.0.1
- Contact OpenAPI.

2023-02-16 Version: 1.0.0
- SyncResourceOperation supported ResourceIdType.

