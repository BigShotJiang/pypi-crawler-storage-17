"""
Honest Anchor - git commit for your IP

Timestamp your files to Bitcoin in seconds.
Prove prior art. Forever.

© 2025 Stellanium Ltd. All rights reserved.
"""

__version__ = "0.1.2"
__author__ = "Stellanium Ltd"
