from setuptools import setup, find_packages

def readme():
  with open('README.md', 'r') as f:
    return f.read()

setup(
  name='babanovtex_external',
  version='0.0.2',
  author='babanov1403',
  author_email='an1mepacan@yandex.ru',
  description='hello world',
  long_description=readme(),
  long_description_content_type='text/markdown',
  url='https://github.com/babanov1403/babanovtex-external',
  packages=find_packages(),
  install_requires=[''],
  classifiers=[
    'Programming Language :: Python :: 3.14',
    'License :: OSI Approved :: MIT License',
    'Operating System :: OS Independent'
  ],
  keywords='pdf tex latex',
  project_urls={
    'GitHub': 'https://github.com/babanov1403/babanovtex-external'
  },
  python_requires='>=3.6'
)