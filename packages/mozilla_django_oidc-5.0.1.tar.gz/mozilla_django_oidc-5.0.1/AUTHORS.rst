=======
Credits
=======

Development Lead
----------------

* Tasos Katsoulas <akatsoulas@mozilla.com>
* John Giannelos <jgiannelos@mozilla.com>

Contributors
------------

* Will Kahn-Greene (`@willkg <https://github.com/willkg>`_)
* Peter Bengtsson (`@peterbe <https://github.com/peterbe>`_)
* Jannis Leidel (`@jezdez <https://github.com/jezdez>`_)
* Jonathan Claudius (`@claudijd <https://github.com/claudijd>`_)
* Patrick Uiterwijk (`@puiterwijk <https://github.com/puiterwijk>`_)
* Dustin J. Mitchell (`@djmitche <https://github.com/djmitche>`_)
* Giorgos Logiotatidis (`@glogiotatidis <https://github.com/glogiotatidis>`_)
* Olle Jonsson (`@olleolleolle <https://github.com/olleolleolle>`_)
* `@GermanoGuerrini <https://github.com/GermanoGuerrini>`_
* John Paulett (`@johnpaulett <https://github.com/johnpaulett>`_)
* Andreas Lutro (`@anlutro <https://github.com/anlutro>`_)
* `@Algogator <https://github.com/Algogator>`_
* Rob Hudson (`@robhudson <https://github.com/robhudson>`_)
* Garand Tyson (`@SirTyson <https://github.com/SirTyson>`_)
* Justin Azoff (`@JustinAzoff <https://github.com/JustinAzoff>`_)
* Antti Palola (`@anttipalola <https://github.com/anttipalola>`_)
* Bono de Visser (`@kerrermanisNL <https://github.com/kerrermanisNL>`_)
* Chris Brantley (`@chrisbrantley <https://github.com/chrisbrantley>`_)
* Ryan Johnson (`@escattone <https://github.com/escattone>`_)
