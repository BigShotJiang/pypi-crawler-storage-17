sphinx-build -M html docs docs/_build
