.. _installation:

Installation
============

nova-galaxy can be easily installed using pip. It is recommended to install nova-galaxy within a virtual environment to avoid conflicts with other Python packages.

.. code-block:: bash

   pip install nova-galaxy
