.. _core_concepts:

Core Concepts
==============

nova-galaxy revolves around several key concepts that facilitate interaction with Galaxy:

.. toctree::
   :maxdepth: 1

   data_stores
   datasets
   tools
   interactive_tools
   workflows
   outputs
   parameters
   tool_runner
