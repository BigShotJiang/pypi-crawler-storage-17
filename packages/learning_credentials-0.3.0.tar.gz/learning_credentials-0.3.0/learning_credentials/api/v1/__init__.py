"""Learning Credentials API v1 package."""
