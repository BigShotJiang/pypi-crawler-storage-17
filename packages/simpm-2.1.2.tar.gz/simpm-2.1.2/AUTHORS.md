## Authors and Contributors

- **Naimeh Sadeghi** – Lead developer and maintainer  
  Website: <https://wp.kntu.ac.ir/sadeghi/> 
  GitHub: <https://github.com/NaimaSadeghi>  
  Email: sadeghi@kntu.ac.ir, naima.sadeghi@gmail.com

- **Pedram Elmi** – Core contributor  
  GitHub: <https://github.com/PedramElmi>  
  Email: pedram.elmi@gmail.com