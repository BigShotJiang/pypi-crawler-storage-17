"""Tests for frameshift library."""
