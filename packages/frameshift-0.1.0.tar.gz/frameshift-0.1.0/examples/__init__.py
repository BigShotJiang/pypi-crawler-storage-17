"""Example scripts for Frameshift library."""
