"""Tests for abstract backend interfaces."""

import pytest
from dataclasses import dataclass
from typing import Optional


class TestBackendDataModels:
    """Test backend-agnostic data models."""

    def test_session_info_creation(self):
        """Test SessionInfo dataclass creation."""
        from swarm_orchestrator.backends.base import SessionInfo

        info = SessionInfo(
            name="test-session",
            status="running",
            ready=False,
        )
        assert info.name == "test-session"
        assert info.status == "running"
        assert info.ready is False
        assert info.worktree_path is None
        assert info.branch is None

    def test_session_info_with_optional_fields(self):
        """Test SessionInfo with all fields populated."""
        from swarm_orchestrator.backends.base import SessionInfo

        info = SessionInfo(
            name="test-session",
            status="completed",
            ready=True,
            worktree_path="/path/to/worktree",
            branch="feature/test",
        )
        assert info.worktree_path == "/path/to/worktree"
        assert info.branch == "feature/test"

    def test_diff_result_creation(self):
        """Test DiffResult dataclass creation."""
        from swarm_orchestrator.backends.base import DiffResult

        result = DiffResult(
            files=["src/foo.py", "tests/test_foo.py"],
            content="diff --git a/src/foo.py\n+new line",
            stats={"added": 10, "deleted": 5},
        )
        assert len(result.files) == 2
        assert "src/foo.py" in result.files
        assert result.stats["added"] == 10

    def test_diff_result_empty(self):
        """Test DiffResult with no changes."""
        from swarm_orchestrator.backends.base import DiffResult

        result = DiffResult(files=[], content="", stats={})
        assert result.files == []
        assert result.content == ""


class TestWorktreeBackend:
    """Test WorktreeBackend abstract interface."""

    def test_cannot_instantiate_directly(self):
        """WorktreeBackend is abstract and cannot be instantiated."""
        from swarm_orchestrator.backends.base import WorktreeBackend

        with pytest.raises(TypeError, match="abstract"):
            WorktreeBackend()

    def test_concrete_implementation_must_implement_all_methods(self):
        """A concrete implementation must implement all abstract methods."""
        from swarm_orchestrator.backends.base import WorktreeBackend

        class IncompleteBackend(WorktreeBackend):
            pass

        with pytest.raises(TypeError, match="abstract"):
            IncompleteBackend()

    def test_concrete_implementation_works(self):
        """A complete concrete implementation can be instantiated."""
        from swarm_orchestrator.backends.base import (
            WorktreeBackend,
            SessionInfo,
            DiffResult,
        )

        class MockWorktreeBackend(WorktreeBackend):
            def create_worktree(
                self, name: str, content: str, base_branch: Optional[str] = None
            ) -> SessionInfo:
                return SessionInfo(name=name, status="created", ready=False)

            def delete_worktree(self, name: str, force: bool = False) -> bool:
                return True

            def get_session_info(self, name: str) -> Optional[SessionInfo]:
                return SessionInfo(name=name, status="running", ready=False)

            def list_sessions(self, filter_type: str = "all") -> list[SessionInfo]:
                return []

            def get_diff(self, name: str) -> DiffResult:
                return DiffResult(files=[], content="", stats={})

            def merge(self, name: str, commit_message: str) -> bool:
                return True

        backend = MockWorktreeBackend()
        result = backend.create_worktree("test", "content")
        assert result.name == "test"
        assert result.status == "created"


class TestAgentBackend:
    """Test AgentBackend abstract interface."""

    def test_cannot_instantiate_directly(self):
        """AgentBackend is abstract and cannot be instantiated."""
        from swarm_orchestrator.backends.base import AgentBackend

        with pytest.raises(TypeError, match="abstract"):
            AgentBackend()

    def test_concrete_implementation_works(self):
        """A complete concrete implementation can be instantiated."""
        from swarm_orchestrator.backends.base import AgentBackend, SessionInfo

        class MockAgentBackend(AgentBackend):
            def spawn_agent(
                self,
                session_name: str,
                prompt: str,
                agent_type: str = "claude",
            ) -> SessionInfo:
                return SessionInfo(name=session_name, status="running", ready=False)

            def wait_for_completion(
                self,
                session_names: list[str],
                timeout: Optional[int] = None,
                callback=None,
            ) -> dict[str, SessionInfo]:
                return {name: SessionInfo(name=name, status="done", ready=True) for name in session_names}

            def send_message(self, session_name: str, message: str) -> bool:
                return True

            def stop_agent(self, session_name: str, force: bool = False) -> bool:
                return True

        backend = MockAgentBackend()
        result = backend.spawn_agent("test-agent", "do something")
        assert result.name == "test-agent"
        assert result.status == "running"


class TestLLMBackend:
    """Test LLMBackend abstract interface."""

    def test_cannot_instantiate_directly(self):
        """LLMBackend is abstract and cannot be instantiated."""
        from swarm_orchestrator.backends.base import LLMBackend

        with pytest.raises(TypeError, match="abstract"):
            LLMBackend()

    def test_concrete_implementation_works(self):
        """A complete concrete implementation can be instantiated."""
        from swarm_orchestrator.backends.base import LLMBackend

        class MockLLMBackend(LLMBackend):
            def decompose(self, query: str, context: Optional[str] = None) -> str:
                return '{"is_atomic": true, "subtasks": []}'

            def explore(self, query: str) -> str:
                return "Exploration results"

            def call(self, prompt: str, max_tokens: int = 4096) -> str:
                return "Response"

        backend = MockLLMBackend()
        result = backend.decompose("implement feature X")
        assert "is_atomic" in result


class TestBackendConfig:
    """Test BackendConfig dataclass."""

    def test_config_creation(self):
        """Test BackendConfig dataclass creation."""
        from swarm_orchestrator.backends.base import BackendConfig

        config = BackendConfig(
            worktree_backend="schaltwerk",
            agent_backend="claude_code",
            llm_backend="anthropic_api",
        )
        assert config.worktree_backend == "schaltwerk"
        assert config.agent_backend == "claude_code"
        assert config.llm_backend == "anthropic_api"

    def test_config_with_options(self):
        """Test BackendConfig with custom options."""
        from swarm_orchestrator.backends.base import BackendConfig

        config = BackendConfig(
            worktree_backend="schaltwerk",
            agent_backend="claude_code",
            llm_backend="anthropic_api",
            worktree_options={"config_path": "/custom/path"},
            agent_options={"skip_permissions": True},
            llm_options={"model": "claude-sonnet-4-20250514"},
        )
        assert config.worktree_options["config_path"] == "/custom/path"
        assert config.agent_options["skip_permissions"] is True
        assert config.llm_options["model"] == "claude-sonnet-4-20250514"


class TestInterfaceContracts:
    """Test that interfaces define clear contracts."""

    def test_worktree_backend_has_docstrings(self):
        """WorktreeBackend methods should have docstrings."""
        from swarm_orchestrator.backends.base import WorktreeBackend

        assert WorktreeBackend.create_worktree.__doc__ is not None
        assert WorktreeBackend.delete_worktree.__doc__ is not None
        assert WorktreeBackend.get_diff.__doc__ is not None
        assert WorktreeBackend.merge.__doc__ is not None

    def test_agent_backend_has_docstrings(self):
        """AgentBackend methods should have docstrings."""
        from swarm_orchestrator.backends.base import AgentBackend

        assert AgentBackend.spawn_agent.__doc__ is not None
        assert AgentBackend.wait_for_completion.__doc__ is not None
        assert AgentBackend.send_message.__doc__ is not None

    def test_llm_backend_has_docstrings(self):
        """LLMBackend methods should have docstrings."""
        from swarm_orchestrator.backends.base import LLMBackend

        assert LLMBackend.decompose.__doc__ is not None
        assert LLMBackend.explore.__doc__ is not None
        assert LLMBackend.call.__doc__ is not None
