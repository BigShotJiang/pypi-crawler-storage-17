"""
Abstract base classes for swarm-orchestrator backends.

Defines contracts for:
- WorktreeBackend: Isolation/worktree management
- AgentBackend: AI agent execution
- LLMBackend: LLM API calls
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Optional


@dataclass
class SessionInfo:
    """
    Backend-agnostic session/worktree information.

    Represents the state of an isolated development session,
    regardless of the underlying implementation.
    """

    name: str
    status: str
    ready: bool
    worktree_path: Optional[str] = None
    branch: Optional[str] = None


@dataclass
class DiffResult:
    """
    Backend-agnostic diff result.

    Contains the changes made in a session/worktree.
    """

    files: list[str]
    content: str
    stats: dict[str, Any] = field(default_factory=dict)


@dataclass
class BackendConfig:
    """
    Configuration for backend selection and options.

    Allows specifying which backends to use and their configuration.
    """

    worktree_backend: str
    agent_backend: str
    llm_backend: str
    worktree_options: dict[str, Any] = field(default_factory=dict)
    agent_options: dict[str, Any] = field(default_factory=dict)
    llm_options: dict[str, Any] = field(default_factory=dict)


class WorktreeBackend(ABC):
    """
    Abstract interface for worktree/isolation backends.

    Implementations provide isolated development environments
    (git worktrees, Docker containers, VMs, etc.).
    """

    @abstractmethod
    def create_worktree(
        self,
        name: str,
        content: str,
        base_branch: Optional[str] = None,
    ) -> SessionInfo:
        """
        Create an isolated worktree/environment for an agent.

        Args:
            name: Unique identifier for the worktree
            content: Initial spec/prompt content
            base_branch: Branch to create worktree from

        Returns:
            SessionInfo with worktree details
        """
        ...

    @abstractmethod
    def delete_worktree(self, name: str, force: bool = False) -> bool:
        """
        Delete a worktree and clean up resources.

        Args:
            name: Worktree identifier
            force: Force deletion even with uncommitted changes

        Returns:
            True if deletion succeeded
        """
        ...

    @abstractmethod
    def get_session_info(self, name: str) -> Optional[SessionInfo]:
        """
        Get current status of a worktree.

        Args:
            name: Worktree identifier

        Returns:
            SessionInfo or None if not found
        """
        ...

    @abstractmethod
    def list_sessions(self, filter_type: str = "all") -> list[SessionInfo]:
        """
        List all worktrees/sessions.

        Args:
            filter_type: Filter by status ("all", "active", "completed")

        Returns:
            List of SessionInfo
        """
        ...

    @abstractmethod
    def get_diff(self, name: str) -> DiffResult:
        """
        Get the diff/changes made in a worktree.

        Args:
            name: Worktree identifier

        Returns:
            DiffResult with changed files and content
        """
        ...

    @abstractmethod
    def merge(self, name: str, commit_message: str) -> bool:
        """
        Merge worktree changes back to the base branch.

        Args:
            name: Worktree identifier
            commit_message: Commit message for merge

        Returns:
            True if merge succeeded
        """
        ...


class AgentBackend(ABC):
    """
    Abstract interface for AI agent execution backends.

    Implementations handle spawning and managing AI coding agents
    (Claude Code, Aider, OpenDevin, etc.).
    """

    @abstractmethod
    def spawn_agent(
        self,
        session_name: str,
        prompt: str,
        agent_type: str = "claude",
    ) -> SessionInfo:
        """
        Spawn an AI agent in a session.

        Args:
            session_name: Session/worktree to run in
            prompt: Task prompt for the agent
            agent_type: Type of agent to spawn

        Returns:
            SessionInfo with agent status
        """
        ...

    @abstractmethod
    def wait_for_completion(
        self,
        session_names: list[str],
        timeout: Optional[int] = None,
        callback: Optional[Callable[[str, SessionInfo], None]] = None,
    ) -> dict[str, SessionInfo]:
        """
        Wait for agents to complete their work.

        Args:
            session_names: Sessions to wait for
            timeout: Maximum wait time in seconds
            callback: Called when each agent completes

        Returns:
            Dict mapping session name to final status
        """
        ...

    @abstractmethod
    def send_message(self, session_name: str, message: str) -> bool:
        """
        Send a follow-up message to a running agent.

        Args:
            session_name: Session to message
            message: Message content

        Returns:
            True if message was sent
        """
        ...

    @abstractmethod
    def stop_agent(self, session_name: str, force: bool = False) -> bool:
        """
        Stop a running agent.

        Args:
            session_name: Session to stop
            force: Force stop even if agent is busy

        Returns:
            True if agent was stopped
        """
        ...


class LLMBackend(ABC):
    """
    Abstract interface for LLM provider backends.

    Implementations handle LLM API calls for task decomposition,
    exploration, and other orchestrator needs.
    """

    @abstractmethod
    def decompose(self, query: str, context: Optional[str] = None) -> str:
        """
        Decompose a task into subtasks using LLM.

        Args:
            query: Task to decompose
            context: Optional context from exploration

        Returns:
            JSON string with decomposition result
        """
        ...

    @abstractmethod
    def explore(self, query: str) -> str:
        """
        Explore codebase/context using LLM.

        Args:
            query: What to explore

        Returns:
            Exploration results as string
        """
        ...

    @abstractmethod
    def call(self, prompt: str, max_tokens: int = 4096) -> str:
        """
        Make a raw LLM call.

        Args:
            prompt: Prompt to send
            max_tokens: Maximum response tokens

        Returns:
            LLM response text
        """
        ...
