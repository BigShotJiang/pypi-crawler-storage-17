"""
Backend interfaces for swarm-orchestrator.

This module defines abstract interfaces for:
- WorktreeBackend: Worktree/isolation management (create, delete, diff, merge)
- AgentBackend: Agent execution (spawn, wait, message)
- LLMBackend: LLM calls (decompose, explore)

These interfaces decouple the orchestrator from specific implementations,
enabling support for different backends (Schaltwerk, Docker, etc.).
"""

from .base import (
    WorktreeBackend,
    AgentBackend,
    LLMBackend,
    SessionInfo,
    DiffResult,
    BackendConfig,
)

__all__ = [
    "WorktreeBackend",
    "AgentBackend",
    "LLMBackend",
    "SessionInfo",
    "DiffResult",
    "BackendConfig",
]
