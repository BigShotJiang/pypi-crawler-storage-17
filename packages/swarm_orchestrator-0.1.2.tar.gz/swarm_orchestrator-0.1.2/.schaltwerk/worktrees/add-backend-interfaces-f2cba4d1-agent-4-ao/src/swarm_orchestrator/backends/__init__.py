"""
Abstract backend interfaces for the swarm orchestrator.

This module defines the contracts for:
- WorktreeBackend: Worktree/isolation management (create, delete, merge)
- AgentBackend: Agent execution (spawn, wait, send message)
- LLMBackend: LLM provider calls (decompose, explore)

These abstractions allow the orchestrator to work with different implementations:
- Schaltwerk (macOS worktrees)
- Docker containers
- Git branches only
- Different AI agents (Claude Code, other coding agents)
- Different LLM providers (Anthropic, OpenAI, local models)
"""

from .base import (
    # Data models
    SessionInfo,
    DiffResult,
    AgentStatus,
    DecompositionRequest,
    DecompositionResponse,
    # Abstract backends
    WorktreeBackend,
    AgentBackend,
    LLMBackend,
)

__all__ = [
    # Data models
    "SessionInfo",
    "DiffResult",
    "AgentStatus",
    "DecompositionRequest",
    "DecompositionResponse",
    # Abstract backends
    "WorktreeBackend",
    "AgentBackend",
    "LLMBackend",
]
