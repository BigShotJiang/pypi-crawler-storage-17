"""
Abstract base classes defining backend contracts.

These interfaces decouple the orchestrator from specific implementations,
enabling support for different worktree managers, agent runners, and LLM providers.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional


# =============================================================================
# Backend-Agnostic Data Models
# =============================================================================


@dataclass
class SessionInfo:
    """
    Backend-agnostic session/worktree information.

    Represents a code isolation context where an agent works,
    regardless of whether it's a git worktree, Docker container, or branch.
    """

    name: str
    branch: str
    status: str
    worktree_path: Optional[str] = None
    created_at: Optional[str] = None
    ready_to_merge: bool = False


@dataclass
class DiffResult:
    """
    Backend-agnostic diff result.

    Contains the changes made by an agent, usable for voting and merging.
    """

    content: str
    files: list[str] = field(default_factory=list)
    added: int = 0
    deleted: int = 0


@dataclass
class AgentStatus:
    """
    Status of an agent execution.

    Tracks agent lifecycle from spawning through completion.
    """

    agent_id: str
    state: str  # spawned, running, completed, failed
    exit_code: Optional[int] = None
    output: Optional[str] = None


@dataclass
class DecompositionRequest:
    """
    Request for task decomposition.

    Sent to LLM backend to break down a complex task.
    """

    query: str
    exploration_context: Optional[dict[str, Any]] = None


@dataclass
class DecompositionResponse:
    """
    Response from task decomposition.

    Contains the breakdown of a task into subtasks.
    """

    is_atomic: bool
    subtasks: list[dict[str, Any]]
    reasoning: str = ""


# =============================================================================
# Abstract Backend Interfaces
# =============================================================================


class WorktreeBackend(ABC):
    """
    Abstract interface for worktree/isolation management.

    Implementations handle creating isolated code contexts where agents work,
    getting diffs of their changes, and merging results.

    Example implementations:
    - SchaltwerkBackend: Uses Schaltwerk MCP for git worktrees (macOS)
    - DockerBackend: Uses Docker containers for isolation
    - BranchBackend: Uses git branches only (no worktrees)
    """

    @abstractmethod
    def create_worktree(
        self,
        name: str,
        branch: str,
        base_branch: Optional[str] = None,
    ) -> SessionInfo:
        """
        Create a new isolated worktree/session for an agent.

        Args:
            name: Unique session identifier
            branch: Branch name to create
            base_branch: Base branch to fork from (default: main/master)

        Returns:
            SessionInfo with creation details
        """
        pass

    @abstractmethod
    def delete_worktree(self, name: str, force: bool = False) -> None:
        """
        Delete a worktree/session.

        Args:
            name: Session name to delete
            force: Force deletion even with uncommitted changes
        """
        pass

    @abstractmethod
    def get_session(self, name: str) -> Optional[SessionInfo]:
        """
        Get information about a specific session.

        Args:
            name: Session name

        Returns:
            SessionInfo or None if not found
        """
        pass

    @abstractmethod
    def list_sessions(self, filter_type: str = "all") -> list[SessionInfo]:
        """
        List all sessions.

        Args:
            filter_type: Filter by status (all, active, reviewed)

        Returns:
            List of SessionInfo objects
        """
        pass

    @abstractmethod
    def get_diff(self, session_name: str) -> DiffResult:
        """
        Get the diff/changes for a session.

        Args:
            session_name: Session to get diff for

        Returns:
            DiffResult with changes
        """
        pass

    @abstractmethod
    def merge(
        self,
        session_name: str,
        commit_message: str,
        mode: str = "squash",
    ) -> None:
        """
        Merge a session's changes to the parent branch.

        Args:
            session_name: Session to merge
            commit_message: Commit message for the merge
            mode: Merge mode (squash, rebase)
        """
        pass


class AgentBackend(ABC):
    """
    Abstract interface for agent execution.

    Implementations handle spawning coding agents, waiting for completion,
    and communicating with running agents.

    Example implementations:
    - ClaudeCodeBackend: Spawns Claude Code via Schaltwerk
    - OpenCodeBackend: Uses OpenCode agents
    - SubprocessBackend: Generic subprocess-based agents
    """

    @abstractmethod
    def spawn(
        self,
        session_name: str,
        prompt: str,
        agent_type: str = "default",
    ) -> AgentStatus:
        """
        Spawn an agent to work on a task.

        Args:
            session_name: Session/worktree for the agent
            prompt: Task prompt for the agent
            agent_type: Type of agent to spawn

        Returns:
            AgentStatus with initial state
        """
        pass

    @abstractmethod
    def wait_for_completion(
        self,
        agent_ids: list[str],
        timeout: Optional[int] = None,
    ) -> dict[str, AgentStatus]:
        """
        Wait for agents to complete their work.

        Args:
            agent_ids: List of agent IDs to wait for
            timeout: Maximum seconds to wait (None = no timeout)

        Returns:
            Dict mapping agent_id to final AgentStatus
        """
        pass

    @abstractmethod
    def send_message(self, session_name: str, message: str) -> None:
        """
        Send a message to a running agent.

        Args:
            session_name: Session name of the agent
            message: Message to send
        """
        pass

    @abstractmethod
    def get_status(self, session_name: str) -> AgentStatus:
        """
        Get current status of an agent.

        Args:
            session_name: Session name to check

        Returns:
            Current AgentStatus
        """
        pass


class LLMBackend(ABC):
    """
    Abstract interface for LLM provider calls.

    Implementations handle task decomposition and codebase exploration
    using different LLM providers.

    Example implementations:
    - AnthropicBackend: Uses Anthropic API
    - ClaudeCLIBackend: Uses Claude Code CLI
    - OpenAIBackend: Uses OpenAI API
    """

    @abstractmethod
    def decompose(self, request: DecompositionRequest) -> DecompositionResponse:
        """
        Decompose a task into subtasks.

        Args:
            request: DecompositionRequest with query and context

        Returns:
            DecompositionResponse with subtasks
        """
        pass

    @abstractmethod
    def explore(self, query: str) -> dict[str, Any]:
        """
        Explore the codebase for relevant context.

        Args:
            query: Task description to explore for

        Returns:
            Dict with exploration findings (code_insights, web_findings, etc.)
        """
        pass
