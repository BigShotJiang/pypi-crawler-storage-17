"""
Tests for abstract backend interfaces.

Verifies that:
1. Abstract base classes cannot be instantiated directly
2. Abstract methods raise NotImplementedError
3. Backend-agnostic data models work correctly
"""

import pytest
from abc import ABC

from swarm_orchestrator.backends import (
    WorktreeBackend,
    AgentBackend,
    LLMBackend,
    SessionInfo,
    DiffResult,
    AgentStatus,
    DecompositionRequest,
    DecompositionResponse,
)


class TestSessionInfo:
    """Tests for SessionInfo dataclass."""

    def test_create_session_info(self):
        """SessionInfo can be created with required fields."""
        info = SessionInfo(
            name="test-session",
            branch="feature-branch",
            status="running",
        )
        assert info.name == "test-session"
        assert info.branch == "feature-branch"
        assert info.status == "running"

    def test_session_info_optional_fields(self):
        """SessionInfo has sensible defaults for optional fields."""
        info = SessionInfo(name="s", branch="b", status="running")
        assert info.worktree_path is None
        assert info.created_at is None
        assert info.ready_to_merge is False

    def test_session_info_with_all_fields(self):
        """SessionInfo can be created with all fields."""
        info = SessionInfo(
            name="test",
            branch="branch",
            status="reviewed",
            worktree_path="/path/to/worktree",
            created_at="2024-01-01T00:00:00Z",
            ready_to_merge=True,
        )
        assert info.worktree_path == "/path/to/worktree"
        assert info.ready_to_merge is True


class TestDiffResult:
    """Tests for DiffResult dataclass."""

    def test_create_diff_result(self):
        """DiffResult can be created with required fields."""
        result = DiffResult(content="+new line\n-old line")
        assert result.content == "+new line\n-old line"

    def test_diff_result_with_files(self):
        """DiffResult can include file list."""
        result = DiffResult(
            content="diff content",
            files=["a.py", "b.py"],
        )
        assert result.files == ["a.py", "b.py"]

    def test_diff_result_stats(self):
        """DiffResult can include stats."""
        result = DiffResult(
            content="",
            added=10,
            deleted=5,
        )
        assert result.added == 10
        assert result.deleted == 5


class TestAgentStatus:
    """Tests for AgentStatus dataclass."""

    def test_create_agent_status(self):
        """AgentStatus can be created with required fields."""
        status = AgentStatus(agent_id="agent-0", state="running")
        assert status.agent_id == "agent-0"
        assert status.state == "running"

    def test_agent_status_with_output(self):
        """AgentStatus can include output."""
        status = AgentStatus(
            agent_id="agent-0",
            state="completed",
            exit_code=0,
            output="Success",
        )
        assert status.exit_code == 0
        assert status.output == "Success"


class TestDecompositionModels:
    """Tests for LLM backend decomposition models."""

    def test_decomposition_request(self):
        """DecompositionRequest can be created."""
        req = DecompositionRequest(query="Add a feature")
        assert req.query == "Add a feature"

    def test_decomposition_request_with_context(self):
        """DecompositionRequest can include exploration context."""
        req = DecompositionRequest(
            query="Add a feature",
            exploration_context={"files": ["a.py"]},
        )
        assert req.exploration_context == {"files": ["a.py"]}

    def test_decomposition_response(self):
        """DecompositionResponse can be created."""
        resp = DecompositionResponse(
            is_atomic=True,
            subtasks=[{"id": "task-1", "title": "Task 1"}],
        )
        assert resp.is_atomic is True
        assert len(resp.subtasks) == 1


class TestWorktreeBackendInterface:
    """Tests for WorktreeBackend abstract base class."""

    def test_cannot_instantiate_directly(self):
        """WorktreeBackend cannot be instantiated directly."""
        with pytest.raises(TypeError, match="Can't instantiate abstract class"):
            WorktreeBackend()

    def test_is_abstract_base_class(self):
        """WorktreeBackend is an ABC."""
        assert issubclass(WorktreeBackend, ABC)

    def test_concrete_implementation_can_be_created(self):
        """A concrete implementation of WorktreeBackend can be created."""

        class ConcreteWorktree(WorktreeBackend):
            def create_worktree(self, name, branch, base_branch=None):
                return SessionInfo(name=name, branch=branch, status="created")

            def delete_worktree(self, name, force=False):
                pass

            def get_session(self, name):
                return None

            def list_sessions(self, filter_type="all"):
                return []

            def get_diff(self, session_name):
                return DiffResult(content="")

            def merge(self, session_name, commit_message, mode="squash"):
                pass

        backend = ConcreteWorktree()
        assert isinstance(backend, WorktreeBackend)


class TestAgentBackendInterface:
    """Tests for AgentBackend abstract base class."""

    def test_cannot_instantiate_directly(self):
        """AgentBackend cannot be instantiated directly."""
        with pytest.raises(TypeError, match="Can't instantiate abstract class"):
            AgentBackend()

    def test_is_abstract_base_class(self):
        """AgentBackend is an ABC."""
        assert issubclass(AgentBackend, ABC)

    def test_concrete_implementation_can_be_created(self):
        """A concrete implementation of AgentBackend can be created."""

        class ConcreteAgent(AgentBackend):
            def spawn(self, session_name, prompt, agent_type="default"):
                return AgentStatus(agent_id=session_name, state="spawned")

            def wait_for_completion(self, agent_ids, timeout=None):
                return {aid: AgentStatus(agent_id=aid, state="completed") for aid in agent_ids}

            def send_message(self, session_name, message):
                pass

            def get_status(self, session_name):
                return AgentStatus(agent_id=session_name, state="unknown")

        backend = ConcreteAgent()
        assert isinstance(backend, AgentBackend)


class TestLLMBackendInterface:
    """Tests for LLMBackend abstract base class."""

    def test_cannot_instantiate_directly(self):
        """LLMBackend cannot be instantiated directly."""
        with pytest.raises(TypeError, match="Can't instantiate abstract class"):
            LLMBackend()

    def test_is_abstract_base_class(self):
        """LLMBackend is an ABC."""
        assert issubclass(LLMBackend, ABC)

    def test_concrete_implementation_can_be_created(self):
        """A concrete implementation of LLMBackend can be created."""

        class ConcreteLLM(LLMBackend):
            def decompose(self, request):
                return DecompositionResponse(is_atomic=True, subtasks=[])

            def explore(self, query):
                return {"summary": ""}

        backend = ConcreteLLM()
        assert isinstance(backend, LLMBackend)


class TestAbstractMethodsRaiseNotImplemented:
    """Test that calling abstract methods directly raises appropriate errors."""

    def test_worktree_methods_are_abstract(self):
        """Verify WorktreeBackend has the expected abstract methods."""
        # Check that the abstract methods are defined
        assert hasattr(WorktreeBackend, "create_worktree")
        assert hasattr(WorktreeBackend, "delete_worktree")
        assert hasattr(WorktreeBackend, "get_session")
        assert hasattr(WorktreeBackend, "list_sessions")
        assert hasattr(WorktreeBackend, "get_diff")
        assert hasattr(WorktreeBackend, "merge")

    def test_agent_methods_are_abstract(self):
        """Verify AgentBackend has the expected abstract methods."""
        assert hasattr(AgentBackend, "spawn")
        assert hasattr(AgentBackend, "wait_for_completion")
        assert hasattr(AgentBackend, "send_message")
        assert hasattr(AgentBackend, "get_status")

    def test_llm_methods_are_abstract(self):
        """Verify LLMBackend has the expected abstract methods."""
        assert hasattr(LLMBackend, "decompose")
        assert hasattr(LLMBackend, "explore")
