"""
Tests for backend abstract base classes.

Verifies that:
1. Abstract methods raise NotImplementedError when called
2. Data classes can be instantiated with proper defaults
3. Interface contracts are well-defined
"""

import pytest
from swarm_orchestrator.backends import (
    SessionState,
    SessionInfo,
    DiffResult,
    BackendConfig,
    DecomposeResult,
    ExploreResult,
    WorktreeBackend,
    AgentBackend,
    LLMBackend,
)


class TestSessionState:
    """Tests for SessionState enum."""

    def test_all_states_defined(self):
        """Verify all expected states exist."""
        assert SessionState.SPEC.value == "spec"
        assert SessionState.RUNNING.value == "running"
        assert SessionState.COMPLETED.value == "completed"
        assert SessionState.REVIEWED.value == "reviewed"
        assert SessionState.FAILED.value == "failed"

    def test_state_count(self):
        """Ensure no unexpected states added."""
        assert len(SessionState) == 5


class TestSessionInfo:
    """Tests for SessionInfo data class."""

    def test_minimal_init(self):
        """SessionInfo can be created with required fields only."""
        info = SessionInfo(
            name="test-session",
            state=SessionState.RUNNING,
            branch="feature-branch",
        )
        assert info.name == "test-session"
        assert info.state == SessionState.RUNNING
        assert info.branch == "feature-branch"
        assert info.ready_to_merge is False
        assert info.worktree_path is None

    def test_full_init(self):
        """SessionInfo can be created with all fields."""
        info = SessionInfo(
            name="test-session",
            state=SessionState.REVIEWED,
            branch="feature-branch",
            ready_to_merge=True,
            worktree_path="/path/to/worktree",
            created_at="2025-01-01T00:00:00",
            last_activity="2025-01-02T00:00:00",
        )
        assert info.ready_to_merge is True
        assert info.worktree_path == "/path/to/worktree"


class TestDiffResult:
    """Tests for DiffResult data class."""

    def test_default_init(self):
        """DiffResult has sensible defaults."""
        diff = DiffResult()
        assert diff.files == []
        assert diff.content == ""
        assert diff.stats == {}

    def test_custom_init(self):
        """DiffResult can be customized."""
        diff = DiffResult(
            files=["src/foo.py", "tests/test_foo.py"],
            content="+new line\n-old line",
            stats={"added": 10, "deleted": 5},
        )
        assert len(diff.files) == 2
        assert "+new line" in diff.content
        assert diff.stats["added"] == 10


class TestBackendConfig:
    """Tests for BackendConfig data class."""

    def test_defaults(self):
        """BackendConfig has sensible defaults."""
        config = BackendConfig()
        assert config.timeout == 600
        assert config.poll_interval == 10
        assert config.config_path is None

    def test_custom_config(self):
        """BackendConfig can be customized."""
        config = BackendConfig(
            timeout=300,
            poll_interval=5,
            config_path="/custom/path.json",
        )
        assert config.timeout == 300
        assert config.poll_interval == 5
        assert config.config_path == "/custom/path.json"


class TestDecomposeResult:
    """Tests for DecomposeResult data class."""

    def test_minimal_init(self):
        """DecomposeResult with required fields."""
        result = DecomposeResult(subtasks=[], is_atomic=True)
        assert result.subtasks == []
        assert result.is_atomic is True
        assert result.reasoning == ""

    def test_with_subtasks(self):
        """DecomposeResult with subtasks."""
        result = DecomposeResult(
            subtasks=[{"id": "task-1", "title": "First"}],
            is_atomic=False,
            reasoning="Split for complexity",
        )
        assert len(result.subtasks) == 1
        assert result.is_atomic is False


class TestExploreResult:
    """Tests for ExploreResult data class."""

    def test_defaults(self):
        """ExploreResult has sensible defaults."""
        result = ExploreResult()
        assert result.context_summary == ""
        assert result.code_insights == []
        assert result.web_findings == []

    def test_with_findings(self):
        """ExploreResult with findings."""
        result = ExploreResult(
            context_summary="Found relevant patterns",
            code_insights=[{"file": "src/main.py", "desc": "entry point"}],
            web_findings=[{"url": "https://docs.example.com"}],
        )
        assert result.context_summary == "Found relevant patterns"
        assert len(result.code_insights) == 1
        assert len(result.web_findings) == 1


class ConcreteWorktreeBackend(WorktreeBackend):
    """Concrete implementation that calls super() to test NotImplementedError."""

    def create_session(self, name, content, base_branch=None):
        return super().create_session(name, content, base_branch)

    def delete_session(self, name, force=False):
        return super().delete_session(name, force)

    def get_session(self, name):
        return super().get_session(name)

    def list_sessions(self, state_filter=None):
        return super().list_sessions(state_filter)

    def get_diff(self, name):
        return super().get_diff(name)

    def merge_session(self, name, commit_message, mode="squash"):
        return super().merge_session(name, commit_message, mode)

    def mark_reviewed(self, name):
        return super().mark_reviewed(name)


class TestWorktreeBackend:
    """Tests for WorktreeBackend abstract class."""

    def test_create_session_raises(self):
        """create_session raises NotImplementedError."""
        backend = ConcreteWorktreeBackend()
        with pytest.raises(NotImplementedError):
            backend.create_session("test", "content")

    def test_delete_session_raises(self):
        """delete_session raises NotImplementedError."""
        backend = ConcreteWorktreeBackend()
        with pytest.raises(NotImplementedError):
            backend.delete_session("test")

    def test_get_session_raises(self):
        """get_session raises NotImplementedError."""
        backend = ConcreteWorktreeBackend()
        with pytest.raises(NotImplementedError):
            backend.get_session("test")

    def test_list_sessions_raises(self):
        """list_sessions raises NotImplementedError."""
        backend = ConcreteWorktreeBackend()
        with pytest.raises(NotImplementedError):
            backend.list_sessions()

    def test_get_diff_raises(self):
        """get_diff raises NotImplementedError."""
        backend = ConcreteWorktreeBackend()
        with pytest.raises(NotImplementedError):
            backend.get_diff("test")

    def test_merge_session_raises(self):
        """merge_session raises NotImplementedError."""
        backend = ConcreteWorktreeBackend()
        with pytest.raises(NotImplementedError):
            backend.merge_session("test", "commit message")

    def test_mark_reviewed_raises(self):
        """mark_reviewed raises NotImplementedError."""
        backend = ConcreteWorktreeBackend()
        with pytest.raises(NotImplementedError):
            backend.mark_reviewed("test")


class ConcreteAgentBackend(AgentBackend):
    """Concrete implementation that calls super() to test NotImplementedError."""

    def spawn_agent(self, session_name, prompt, agent_type="claude"):
        return super().spawn_agent(session_name, prompt, agent_type)

    def wait_for_completion(self, session_names, callback=None, timeout=None):
        return super().wait_for_completion(session_names, callback, timeout)

    def send_message(self, session_name, message):
        return super().send_message(session_name, message)

    def cancel_agent(self, session_name):
        return super().cancel_agent(session_name)


class TestAgentBackend:
    """Tests for AgentBackend abstract class."""

    def test_spawn_agent_raises(self):
        """spawn_agent raises NotImplementedError."""
        backend = ConcreteAgentBackend()
        with pytest.raises(NotImplementedError):
            backend.spawn_agent("session", "prompt")

    def test_wait_for_completion_raises(self):
        """wait_for_completion raises NotImplementedError."""
        backend = ConcreteAgentBackend()
        with pytest.raises(NotImplementedError):
            backend.wait_for_completion(["session"])

    def test_send_message_raises(self):
        """send_message raises NotImplementedError."""
        backend = ConcreteAgentBackend()
        with pytest.raises(NotImplementedError):
            backend.send_message("session", "hello")

    def test_cancel_agent_raises(self):
        """cancel_agent raises NotImplementedError."""
        backend = ConcreteAgentBackend()
        with pytest.raises(NotImplementedError):
            backend.cancel_agent("session")


class ConcreteLLMBackend(LLMBackend):
    """Concrete implementation that calls super() to test NotImplementedError."""

    def decompose(self, query, exploration_context=None):
        return super().decompose(query, exploration_context)

    def explore(self, query, timeout=None):
        return super().explore(query, timeout)


class TestLLMBackend:
    """Tests for LLMBackend abstract class."""

    def test_decompose_raises(self):
        """decompose raises NotImplementedError."""
        backend = ConcreteLLMBackend()
        with pytest.raises(NotImplementedError):
            backend.decompose("build a feature")

    def test_explore_raises(self):
        """explore raises NotImplementedError."""
        backend = ConcreteLLMBackend()
        with pytest.raises(NotImplementedError):
            backend.explore("where is auth handled?")


class TestModuleExports:
    """Test that all classes are properly exported."""

    def test_imports_from_package(self):
        """All expected classes can be imported from backends package."""
        from swarm_orchestrator.backends import (
            SessionState,
            SessionInfo,
            DiffResult,
            BackendConfig,
            DecomposeResult,
            ExploreResult,
            WorktreeBackend,
            AgentBackend,
            LLMBackend,
        )
        # If we get here, imports succeeded
        assert True
