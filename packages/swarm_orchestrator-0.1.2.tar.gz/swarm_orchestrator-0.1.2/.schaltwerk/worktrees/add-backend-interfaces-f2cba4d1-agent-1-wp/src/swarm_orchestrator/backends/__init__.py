"""
Backend interfaces for swarm orchestrator.

This package provides abstract base classes that define the contracts for:
- WorktreeBackend: Worktree/isolation management
- AgentBackend: Agent execution
- LLMBackend: LLM operations (decompose, explore)

Implementations can be swapped to support different platforms and providers.
"""

from .base import (
    # Enums
    SessionState,
    # Data classes
    SessionInfo,
    DiffResult,
    BackendConfig,
    DecomposeResult,
    ExploreResult,
    # Abstract backends
    WorktreeBackend,
    AgentBackend,
    LLMBackend,
)

__all__ = [
    # Enums
    "SessionState",
    # Data classes
    "SessionInfo",
    "DiffResult",
    "BackendConfig",
    "DecomposeResult",
    "ExploreResult",
    # Abstract backends
    "WorktreeBackend",
    "AgentBackend",
    "LLMBackend",
]
