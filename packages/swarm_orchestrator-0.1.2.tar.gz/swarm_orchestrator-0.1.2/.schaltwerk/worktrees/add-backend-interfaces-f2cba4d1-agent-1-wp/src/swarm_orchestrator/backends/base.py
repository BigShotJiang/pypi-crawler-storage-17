"""
Abstract base classes for swarm orchestrator backends.

This module defines the contracts for:
- WorktreeBackend: Worktree/isolation management (create, delete, diff, merge)
- AgentBackend: Agent execution (spawn, wait, send message)
- LLMBackend: LLM operations (decompose, explore)

These interfaces decouple the orchestrator from specific implementations
like Schaltwerk or Claude Code, enabling alternative backends.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Optional


class SessionState(Enum):
    """State of an agent session."""
    SPEC = "spec"
    RUNNING = "running"
    COMPLETED = "completed"
    REVIEWED = "reviewed"
    FAILED = "failed"


@dataclass
class SessionInfo:
    """Backend-agnostic session information."""
    name: str
    state: SessionState
    branch: str
    ready_to_merge: bool = False
    worktree_path: Optional[str] = None
    created_at: Optional[str] = None
    last_activity: Optional[str] = None


@dataclass
class DiffResult:
    """Backend-agnostic diff result."""
    files: list[str] = field(default_factory=list)
    content: str = ""
    stats: dict = field(default_factory=dict)


@dataclass
class BackendConfig:
    """Configuration for backend initialization."""
    timeout: int = 600
    poll_interval: int = 10
    config_path: Optional[str] = None


class WorktreeBackend(ABC):
    """
    Abstract interface for worktree/isolation management.

    Implementations handle creating isolated workspaces for agents,
    retrieving diffs, and merging results back to the main branch.

    Example implementations:
    - SchaltwerkWorktreeBackend: Uses Schaltwerk for git worktrees
    - DockerWorktreeBackend: Uses Docker containers for isolation
    - LocalWorktreeBackend: Uses local git worktrees directly
    """

    @abstractmethod
    def create_session(
        self,
        name: str,
        content: str,
        base_branch: Optional[str] = None,
    ) -> SessionInfo:
        """
        Create a new isolated session/worktree.

        Args:
            name: Unique session identifier
            content: Initial content/spec for the session
            base_branch: Branch to create session from (default: main)

        Returns:
            SessionInfo with created session details
        """
        raise NotImplementedError

    @abstractmethod
    def delete_session(self, name: str, force: bool = False) -> bool:
        """
        Delete a session and its worktree.

        Args:
            name: Session identifier
            force: Force deletion even with uncommitted changes

        Returns:
            True if deletion succeeded
        """
        raise NotImplementedError

    @abstractmethod
    def get_session(self, name: str) -> Optional[SessionInfo]:
        """
        Get information about a specific session.

        Args:
            name: Session identifier

        Returns:
            SessionInfo or None if not found
        """
        raise NotImplementedError

    @abstractmethod
    def list_sessions(self, state_filter: Optional[SessionState] = None) -> list[SessionInfo]:
        """
        List all sessions, optionally filtered by state.

        Args:
            state_filter: Only return sessions in this state

        Returns:
            List of SessionInfo objects
        """
        raise NotImplementedError

    @abstractmethod
    def get_diff(self, name: str) -> DiffResult:
        """
        Get the diff for a session compared to its base.

        Args:
            name: Session identifier

        Returns:
            DiffResult with changed files and content
        """
        raise NotImplementedError

    @abstractmethod
    def merge_session(
        self,
        name: str,
        commit_message: str,
        mode: str = "squash",
    ) -> bool:
        """
        Merge a session back to its parent branch.

        Args:
            name: Session identifier
            commit_message: Message for the merge commit
            mode: Merge mode ("squash" or "reapply")

        Returns:
            True if merge succeeded
        """
        raise NotImplementedError

    @abstractmethod
    def mark_reviewed(self, name: str) -> bool:
        """
        Mark a session as reviewed and ready to merge.

        Args:
            name: Session identifier

        Returns:
            True if marking succeeded
        """
        raise NotImplementedError


class AgentBackend(ABC):
    """
    Abstract interface for agent execution.

    Implementations handle spawning AI agents, waiting for completion,
    and communicating with running agents.

    Example implementations:
    - SchaltwerkAgentBackend: Spawns Claude Code via Schaltwerk
    - SubprocessAgentBackend: Spawns agents as local subprocesses
    - RemoteAgentBackend: Connects to remote agent servers
    """

    @abstractmethod
    def spawn_agent(
        self,
        session_name: str,
        prompt: str,
        agent_type: str = "claude",
    ) -> str:
        """
        Spawn an agent to work on a session.

        Args:
            session_name: Session/worktree to work in
            prompt: Initial prompt/task for the agent
            agent_type: Type of agent to spawn

        Returns:
            Agent identifier (may differ from session_name)
        """
        raise NotImplementedError

    @abstractmethod
    def wait_for_completion(
        self,
        session_names: list[str],
        callback: Optional[Callable[[str, SessionInfo], None]] = None,
        timeout: Optional[int] = None,
    ) -> dict[str, SessionInfo]:
        """
        Wait for agents to complete their work.

        Args:
            session_names: Sessions to wait for
            callback: Called when each session completes
            timeout: Max seconds to wait (None = use default)

        Returns:
            Dict mapping session name to final status

        Raises:
            TimeoutError: If timeout exceeded
        """
        raise NotImplementedError

    @abstractmethod
    def send_message(self, session_name: str, message: str) -> bool:
        """
        Send a message to a running agent.

        Args:
            session_name: Target session
            message: Message content

        Returns:
            True if message was sent
        """
        raise NotImplementedError

    @abstractmethod
    def cancel_agent(self, session_name: str) -> bool:
        """
        Cancel/stop a running agent.

        Args:
            session_name: Session to cancel

        Returns:
            True if cancellation succeeded
        """
        raise NotImplementedError


@dataclass
class DecomposeResult:
    """Result of task decomposition."""
    subtasks: list[dict]
    is_atomic: bool
    reasoning: str = ""


@dataclass
class ExploreResult:
    """Result of codebase exploration."""
    context_summary: str = ""
    code_insights: list[dict] = field(default_factory=list)
    web_findings: list[dict] = field(default_factory=list)


class LLMBackend(ABC):
    """
    Abstract interface for LLM operations.

    Implementations handle task decomposition and codebase exploration
    using different LLM providers.

    Example implementations:
    - ClaudeCliBackend: Uses claude CLI (Max/Pro subscription)
    - AnthropicApiBackend: Uses Anthropic API directly
    - OpenAIBackend: Uses OpenAI models
    """

    @abstractmethod
    def decompose(
        self,
        query: str,
        exploration_context: Optional[ExploreResult] = None,
    ) -> DecomposeResult:
        """
        Decompose a task into subtasks.

        Args:
            query: Task description to decompose
            exploration_context: Optional exploration findings

        Returns:
            DecomposeResult with subtasks
        """
        raise NotImplementedError

    @abstractmethod
    def explore(
        self,
        query: str,
        timeout: Optional[int] = None,
    ) -> ExploreResult:
        """
        Explore the codebase for context relevant to a query.

        Args:
            query: Task/question to explore for
            timeout: Max seconds for exploration

        Returns:
            ExploreResult with findings
        """
        raise NotImplementedError
