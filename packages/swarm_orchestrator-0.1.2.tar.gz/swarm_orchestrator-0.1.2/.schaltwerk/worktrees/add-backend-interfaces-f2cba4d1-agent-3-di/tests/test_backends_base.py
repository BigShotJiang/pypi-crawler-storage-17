"""
Tests for abstract backend interfaces.

Verifies:
- Abstract classes are properly defined with required methods
- Abstract methods raise NotImplementedError when called directly
- Data models (SessionInfo, DiffResult) work correctly
"""

import pytest
from dataclasses import dataclass

from swarm_orchestrator.backends import (
    WorktreeBackend,
    AgentBackend,
    LLMBackend,
    SessionInfo,
    DiffResult,
    BackendConfig,
)


class TestSessionInfo:
    """Tests for SessionInfo data model."""

    def test_create_session_info(self):
        """SessionInfo can be created with required fields."""
        info = SessionInfo(
            name="test-session",
            status="running",
            branch="feature-branch",
        )
        assert info.name == "test-session"
        assert info.status == "running"
        assert info.branch == "feature-branch"
        assert info.worktree_path is None
        assert info.ready_to_merge is False

    def test_session_info_all_fields(self):
        """SessionInfo supports all optional fields."""
        info = SessionInfo(
            name="test",
            status="completed",
            branch="main",
            worktree_path="/tmp/worktree",
            ready_to_merge=True,
            created_at="2024-01-01T00:00:00Z",
            last_activity="2024-01-01T01:00:00Z",
        )
        assert info.worktree_path == "/tmp/worktree"
        assert info.ready_to_merge is True
        assert info.created_at == "2024-01-01T00:00:00Z"
        assert info.last_activity == "2024-01-01T01:00:00Z"

    def test_session_info_from_dict(self):
        """SessionInfo can be created from dict."""
        data = {
            "name": "session-1",
            "status": "running",
            "branch": "dev",
            "ready_to_merge": True,
        }
        info = SessionInfo.from_dict(data)
        assert info.name == "session-1"
        assert info.status == "running"
        assert info.branch == "dev"
        assert info.ready_to_merge is True


class TestDiffResult:
    """Tests for DiffResult data model."""

    def test_create_diff_result(self):
        """DiffResult can be created with required fields."""
        result = DiffResult(files_changed=["a.py", "b.py"])
        assert result.files_changed == ["a.py", "b.py"]
        assert result.content == ""
        assert result.stats == {}

    def test_diff_result_with_stats(self):
        """DiffResult supports statistics."""
        result = DiffResult(
            files_changed=["x.py"],
            content="+def foo(): pass",
            stats={"added": 1, "deleted": 0},
        )
        assert result.content == "+def foo(): pass"
        assert result.stats["added"] == 1


class TestBackendConfig:
    """Tests for BackendConfig data model."""

    def test_create_config(self):
        """BackendConfig can be created."""
        config = BackendConfig(timeout=300)
        assert config.timeout == 300

    def test_config_with_extra(self):
        """BackendConfig supports extra settings."""
        config = BackendConfig(timeout=60, extra={"api_key": "secret"})
        assert config.extra["api_key"] == "secret"


class TestWorktreeBackendAbstract:
    """Tests for WorktreeBackend abstract interface."""

    def test_cannot_instantiate_directly(self):
        """WorktreeBackend cannot be instantiated directly."""
        with pytest.raises(TypeError, match="abstract"):
            WorktreeBackend()

    def test_concrete_must_implement_all_methods(self):
        """Concrete classes must implement all abstract methods."""

        class PartialImpl(WorktreeBackend):
            def create_session(self, name, content, base_branch=None):
                return SessionInfo(name=name, status="created", branch="main")

        with pytest.raises(TypeError, match="abstract"):
            PartialImpl()

    def test_concrete_implementation_works(self):
        """A complete concrete implementation can be instantiated."""

        class FakeWorktreeBackend(WorktreeBackend):
            def create_session(self, name, content, base_branch=None):
                return SessionInfo(name=name, status="created", branch=base_branch or "main")

            def get_session(self, name):
                return SessionInfo(name=name, status="running", branch="main")

            def list_sessions(self, filter_type="all"):
                return []

            def get_diff(self, session_name):
                return DiffResult(files_changed=[])

            def merge_session(self, session_name, commit_message, mode="squash"):
                return True

            def delete_session(self, session_name, force=False):
                return True

        backend = FakeWorktreeBackend()
        session = backend.create_session("test", "content")
        assert session.name == "test"
        assert session.status == "created"


class TestAgentBackendAbstract:
    """Tests for AgentBackend abstract interface."""

    def test_cannot_instantiate_directly(self):
        """AgentBackend cannot be instantiated directly."""
        with pytest.raises(TypeError, match="abstract"):
            AgentBackend()

    def test_concrete_implementation_works(self):
        """A complete concrete implementation can be instantiated."""

        class FakeAgentBackend(AgentBackend):
            def spawn_agent(self, session_name, prompt, agent_type="default"):
                return {"started": True}

            def wait_for_completion(self, session_names, timeout=None, callback=None):
                return {name: SessionInfo(name=name, status="completed", branch="main")
                        for name in session_names}

            def send_message(self, session_name, message):
                return True

            def get_agent_output(self, session_name):
                return ""

        backend = FakeAgentBackend()
        result = backend.spawn_agent("sess", "prompt")
        assert result["started"] is True


class TestLLMBackendAbstract:
    """Tests for LLMBackend abstract interface."""

    def test_cannot_instantiate_directly(self):
        """LLMBackend cannot be instantiated directly."""
        with pytest.raises(TypeError, match="abstract"):
            LLMBackend()

    def test_concrete_implementation_works(self):
        """A complete concrete implementation can be instantiated."""

        class FakeLLMBackend(LLMBackend):
            def decompose(self, query, context=None):
                return {"is_atomic": True, "subtasks": []}

            def explore(self, query):
                return {"insights": [], "summary": ""}

        backend = FakeLLMBackend()
        result = backend.decompose("test query")
        assert result["is_atomic"] is True


class TestBackendDocstrings:
    """Tests that interfaces have proper documentation."""

    def test_worktree_backend_has_docstrings(self):
        """WorktreeBackend methods have docstrings."""
        assert WorktreeBackend.create_session.__doc__ is not None
        assert WorktreeBackend.get_session.__doc__ is not None
        assert WorktreeBackend.get_diff.__doc__ is not None
        assert WorktreeBackend.merge_session.__doc__ is not None

    def test_agent_backend_has_docstrings(self):
        """AgentBackend methods have docstrings."""
        assert AgentBackend.spawn_agent.__doc__ is not None
        assert AgentBackend.wait_for_completion.__doc__ is not None

    def test_llm_backend_has_docstrings(self):
        """LLMBackend methods have docstrings."""
        assert LLMBackend.decompose.__doc__ is not None
        assert LLMBackend.explore.__doc__ is not None
