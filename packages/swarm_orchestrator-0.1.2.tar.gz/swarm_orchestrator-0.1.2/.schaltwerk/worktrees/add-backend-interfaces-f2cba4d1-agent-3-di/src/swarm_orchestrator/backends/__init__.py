"""
Backend interfaces for swarm orchestrator.

This package provides abstract interfaces for:
- WorktreeBackend: Worktree/isolation management
- AgentBackend: Agent execution
- LLMBackend: LLM interactions

These abstractions decouple the orchestrator from specific implementations.
"""

from .base import (
    WorktreeBackend,
    AgentBackend,
    LLMBackend,
    SessionInfo,
    DiffResult,
    BackendConfig,
)

__all__ = [
    "WorktreeBackend",
    "AgentBackend",
    "LLMBackend",
    "SessionInfo",
    "DiffResult",
    "BackendConfig",
]
