"""
Abstract base classes for swarm orchestrator backends.

This module defines the contracts for:
- WorktreeBackend: Worktree/isolation management (create, merge, diff)
- AgentBackend: Agent execution (spawn, wait, communicate)
- LLMBackend: LLM interactions (decompose, explore)

These abstractions allow the orchestrator to work with different
implementations (Schaltwerk, Docker, AWS, etc.) without tight coupling.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Optional


@dataclass
class SessionInfo:
    """
    Backend-agnostic session information.

    Represents the state of an isolated work session, regardless of
    whether it's implemented via git worktrees, containers, or VMs.
    """

    name: str
    status: str
    branch: str
    worktree_path: Optional[str] = None
    ready_to_merge: bool = False
    created_at: Optional[str] = None
    last_activity: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "SessionInfo":
        """Create SessionInfo from a dictionary."""
        return cls(
            name=data.get("name", ""),
            status=data.get("status", ""),
            branch=data.get("branch", ""),
            worktree_path=data.get("worktree_path"),
            ready_to_merge=data.get("ready_to_merge", False),
            created_at=data.get("created_at"),
            last_activity=data.get("last_activity"),
        )


@dataclass
class DiffResult:
    """
    Backend-agnostic diff result.

    Contains the changes made in a session, regardless of how
    the isolation is implemented.
    """

    files_changed: list[str]
    content: str = ""
    stats: dict[str, int] = field(default_factory=dict)


@dataclass
class BackendConfig:
    """
    Configuration for backends.

    Provides a common way to pass settings to any backend implementation.
    """

    timeout: int = 600
    extra: dict[str, Any] = field(default_factory=dict)


class WorktreeBackend(ABC):
    """
    Abstract interface for worktree/isolation management.

    Implementations handle creating isolated environments for agents,
    tracking changes, and merging results. Examples include:
    - SchaltwerkBackend: Git worktrees via Schaltwerk MCP
    - DockerBackend: Container-based isolation
    - LocalBackend: Direct file system operations
    """

    @abstractmethod
    def create_session(
        self,
        name: str,
        content: str,
        base_branch: Optional[str] = None,
    ) -> SessionInfo:
        """
        Create a new isolated session for an agent.

        Args:
            name: Unique identifier for the session
            content: Initial prompt/spec content
            base_branch: Branch to base the session on (default: main)

        Returns:
            SessionInfo with the created session's details
        """
        pass

    @abstractmethod
    def get_session(self, name: str) -> Optional[SessionInfo]:
        """
        Get the current state of a session.

        Args:
            name: Session identifier

        Returns:
            SessionInfo if found, None otherwise
        """
        pass

    @abstractmethod
    def list_sessions(self, filter_type: str = "all") -> list[SessionInfo]:
        """
        List all sessions, optionally filtered.

        Args:
            filter_type: Filter by status ("all", "active", "completed")

        Returns:
            List of SessionInfo objects
        """
        pass

    @abstractmethod
    def get_diff(self, session_name: str) -> DiffResult:
        """
        Get the changes made in a session.

        Args:
            session_name: Session to get diff for

        Returns:
            DiffResult containing changed files and content
        """
        pass

    @abstractmethod
    def merge_session(
        self,
        session_name: str,
        commit_message: str,
        mode: str = "squash",
    ) -> bool:
        """
        Merge session changes back to the base branch.

        Args:
            session_name: Session to merge
            commit_message: Message for the merge commit
            mode: Merge strategy ("squash" or "reapply")

        Returns:
            True if merge succeeded, False otherwise
        """
        pass

    @abstractmethod
    def delete_session(self, session_name: str, force: bool = False) -> bool:
        """
        Delete a session and its associated resources.

        Args:
            session_name: Session to delete
            force: Force deletion even with uncommitted changes

        Returns:
            True if deletion succeeded
        """
        pass


class AgentBackend(ABC):
    """
    Abstract interface for agent execution.

    Implementations handle spawning AI agents, waiting for completion,
    and communication. Examples include:
    - ClaudeCodeBackend: Claude Code CLI agents
    - OpenCodeBackend: OpenCode agents
    - GenericLLMBackend: API-based agents
    """

    @abstractmethod
    def spawn_agent(
        self,
        session_name: str,
        prompt: str,
        agent_type: str = "default",
    ) -> dict[str, Any]:
        """
        Spawn an AI agent in the given session.

        Args:
            session_name: Session where agent will work
            prompt: Initial prompt/instructions for the agent
            agent_type: Type of agent to spawn (backend-specific)

        Returns:
            Dict with spawn result (at minimum: {"started": bool})
        """
        pass

    @abstractmethod
    def wait_for_completion(
        self,
        session_names: list[str],
        timeout: Optional[int] = None,
        callback: Optional[Callable[[str, SessionInfo], None]] = None,
    ) -> dict[str, SessionInfo]:
        """
        Wait for agents to complete their work.

        Args:
            session_names: Sessions to wait for
            timeout: Maximum seconds to wait (None = no timeout)
            callback: Called when each session completes

        Returns:
            Dict mapping session name to final SessionInfo
        """
        pass

    @abstractmethod
    def send_message(self, session_name: str, message: str) -> bool:
        """
        Send a message to a running agent.

        Args:
            session_name: Target session
            message: Message content

        Returns:
            True if message was delivered
        """
        pass

    @abstractmethod
    def get_agent_output(self, session_name: str) -> str:
        """
        Get the output/logs from an agent.

        Args:
            session_name: Session to get output from

        Returns:
            Agent's output as a string
        """
        pass


class LLMBackend(ABC):
    """
    Abstract interface for LLM interactions.

    Implementations handle task decomposition and codebase exploration.
    Examples include:
    - ClaudeCLIBackend: Uses claude CLI (Max/Pro subscription)
    - AnthropicAPIBackend: Direct Anthropic API calls
    - OpenAIBackend: OpenAI API integration
    """

    @abstractmethod
    def decompose(
        self,
        query: str,
        context: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """
        Decompose a task into subtasks.

        Args:
            query: The task to decompose
            context: Optional exploration context or hints

        Returns:
            Dict with decomposition result:
            {
                "is_atomic": bool,
                "subtasks": list[dict],
                "reasoning": str (optional)
            }
        """
        pass

    @abstractmethod
    def explore(self, query: str) -> dict[str, Any]:
        """
        Explore a codebase to gather context for a task.

        Args:
            query: The task/question to explore

        Returns:
            Dict with exploration findings:
            {
                "insights": list[dict],
                "summary": str
            }
        """
        pass
