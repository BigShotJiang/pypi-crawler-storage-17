"""Codevid - Generate video tutorials from automated tests."""

__version__ = "1.0.5"
