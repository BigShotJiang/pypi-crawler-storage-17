"""
GraphQL API tests.
"""
