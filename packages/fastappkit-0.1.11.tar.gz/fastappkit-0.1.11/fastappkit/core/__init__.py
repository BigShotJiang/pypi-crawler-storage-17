"""Core runtime module for app loading and registry."""

from __future__ import annotations
