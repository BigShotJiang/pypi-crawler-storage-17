"""
Test fixtures and sample data for testing.

This module contains sample Metabase API responses and test data.
"""
