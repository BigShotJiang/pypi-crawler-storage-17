#%%
from src.icclogger import log,LOGGER
from src.icclogger.colors import ConsoleColors
@log()
def test():
    # LOGGER.info(f"{ConsoleColors.R} red")
    # LOGGER.info(f"{ConsoleColors.G} green")
    # LOGGER.info(f"{ConsoleColors.C} cyan")
    # LOGGER.info(f"{ConsoleColors.W} white")
    # LOGGER.info(f"{ConsoleColors.Y} yellow")
    # LOGGER.info(f"{ConsoleColors.P} purple")
    # LOGGER.info(f"{ConsoleColors.GR} dark grey")
    # LOGGER.info(f"{ConsoleColors.BR} bright red")
    # LOGGER.info(f"{ConsoleColors.BG} bright green")
    # LOGGER.info(f"{ConsoleColors.BY} bright yellow")
    # LOGGER.info(f"{ConsoleColors.BBLUE} bright blue")
    # LOGGER.info(f"{ConsoleColors.BP} bright purple")
    # LOGGER.info(f"{ConsoleColors.BC} bright cyan")
    # LOGGER.info(f"{ConsoleColors.BW} bright white")

    return

test()
