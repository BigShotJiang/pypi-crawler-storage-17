class ConsoleColors:
    R = '\033[31m'  # red
    G = '\033[32m'  # green
    C = '\033[36m'  # cyan
    W = '\033[0m'   # white
    Y = '\033[33m'  # yellow
    P = '\033[35m'  # purple
    GR = '\033[90m' # dark grey
    BR = '\033[91m'
    BG = '\033[92m'
    BY = '\033[93m'
    BBLUE = '\033[94m'
    BP = '\033[95m'
    BC = '\033[96m'
    BW = '\033[97m'
