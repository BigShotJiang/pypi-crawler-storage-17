Test that the internal action .is_alive is correct.
To run this test :
```bash
    python3 run_test.py
```

It will first test a case where the other agent is not online. 
Then it will spawn a second agent and check that it is online.