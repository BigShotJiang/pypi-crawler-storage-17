# Uniquant

- Curent Version: [v1.0.0](https://github.com/Broo-DevX-Coder/Uniquant/wiki/v1.0.0)
- Repository URL: [To Github](https://github.com/Broo-DevX-Coder/Uniquant)
- Docs URL: [To wikis](https://github.com/Broo-DevX-Coder/Uniquant/wiki)
- Python PyPi : [To PyPi](https://pypi.org/project/uniquant/)
- DOCs: [To DOCs](https://github.com/Broo-DevX-Coder/Uniquant/wiki/DOCs)

---

## Disclaimer

> **UniQuant is an open-source project developed solely for educational and experimental purposes.**  
> Any use of this library for unethical or illegal purposes is strictly prohibited, including but not limited to:  
> - Engaging in pump-and-dump schemes or buying tokens that are questionable under Islamic law (Shariah)  
> - Utilizing this library for futures trading, leveraged trading, or other high-risk financial instruments  
> - Employing this tool in unregulated or illegal markets  
>   
> The author assumes no responsibility for misuse or violations of legal, ethical, or religious standards.  
> Users must ensure compliance with all local laws, exchange policies, and religious guidelines.

---

## Overview

**Uniquant** is an asynchronous Python library that provides a unified, high-performance interface to interact with multiple cryptocurrency trading platforms. Built with `asyncio` and `aiohttp`, it currently supports **Binance Spot** public REST APIs, enabling developers to build scalable, non-blocking applications for market data retrieval.

The library abstracts platform-specific complexities into a clean, consistent API—ideal for research, data analysis, or prototyping—while adhering to asynchronous best practices.

> **Note**: Private API support and additional exchanges are planned for future releases (see [Roadmap](https://github.com/Broo-DevX-Coder/Uniquant/wiki/Roadmap)).

---

## Features

- Asynchronous, non-blocking I/O using `asyncio` and `aiohttp`
- Unified API design for cross-exchange compatibility (currently **Binance Spot public endpoints only**)
- Lightweight with minimal dependencies
- Type hints for improved developer experience and IDE support
- Automatic rate-limit handling (basic)

---

## Technologies & Dependencies

- **Python**: 3.9 or higher
- **Core Libraries**:
  - `asyncio` (built-in)
  - `aiohttp` (for async HTTP requests)
  - `websockets` (for real time connections and messages -system of exchanges-)
---

## Installation

Install Uniquant via `pip`:

```bash
pip install uniquant
```

Or from source:

```bash
git clone https://github.com/Broo-DevX-Coder/Uniquant
cd uniquant
pip install -e .
```

> Ensure you are using Python 3.9+.

---

## Usage

### Public Market Data (Binance Spot)

```python
from uniquant.Platforms.Binance.Public import PublicSymbols,OneSymbole # You can to chow any sepported exchange
from uniquant.main.utils import QueueStream,STABLECOINS_USD # These are just utils from lib
import aiohttp

async def main():
    OBJ = PublicSymbols(symbol="BTCUSDT")
    await OBJ.start(aiohttp.ClientSession()) # This function is very imporetant to initialyze sessions, you can set a costimize aiohttp.ClientSession for them
    async for ob in OBJ.orderbook_stream(limit=int): # this is a small exemple to get async-generator of orderbook
      print(ob)

asyncio.run(main())
```

> All sepported exchanges objects and functions are same
> **Important**: You can to see all docs of use in [wiki DOCs](https://github.com/Broo-DevX-Coder/Uniquant/wiki/DOCs)

---

### Supported Exchanges (Last Version)

| Exchange Name | API Docs Link                                            | Private API Supported? | Last Version Upgraded |
|---------------|----------------------------------------------------------|------------------------|-----------------------|
| Binance Spot  | [docs](https://binance-docs.github.io/apidocs/spot/en/)  | Not yet supported      | 1.0.0                 |

### Version History

| Version | Release Date   | Changelog / Wiki Link                     |
|---------|----------------|-------------------------------------------|
| 1.0.0   | 2025-12-10     | [Wiki: v1.0.0](https://github.com/Broo-DevX-Coder/Uniquant/wiki/v1.0.0) — Improved error handling, type hints, async session reuse |

> Future versions will incrementally add private API support, additional exchanges, and WebSocket connectivity.

---

## License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.

---

## Maintainer

For questions, bug reports, or feature requests, please [open an issue](INSERT URL/issues) in the repository.

Maintainer: Broo-Dev-X
Contact: [broodevx@gmail.com] *(optional)*

---

> **Remember**: Always use this library responsibly and in full compliance with applicable laws, exchange terms of service, and ethical standards.