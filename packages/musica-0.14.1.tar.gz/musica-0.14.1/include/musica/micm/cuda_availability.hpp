#pragma once

namespace musica
{
  bool IsCudaAvailable();
}  // namespace musica