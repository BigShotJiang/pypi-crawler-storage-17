.. _api-ref:

MUSICA API
==========

Welcome to the MUSICA API documentation. Below, you can find links to the documentation for both the C++ and Python APIs.


.. toctree::
   :maxdepth: 1
   :caption: Contents:

   C++
   python
  