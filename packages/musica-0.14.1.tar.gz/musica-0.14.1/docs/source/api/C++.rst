MUSICA C++ API
==============

.. doxygennamespace:: musica
   :members:
