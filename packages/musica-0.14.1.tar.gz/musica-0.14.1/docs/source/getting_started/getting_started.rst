###############
Getting Started
###############

Hello, and welcome to MUSICA! Here, we will be covering some basic usages of the MUSICA library.

The MUSICA-Fotran API provides access to the MUSICA library within a fortran program. Similarly, the MUSICA-Python API makes the library available within a Python program. 
Simple usage examples for either API are included below:

.. toctree::
   :maxdepth: 1
   :caption: Contents:



   fortran
   python
