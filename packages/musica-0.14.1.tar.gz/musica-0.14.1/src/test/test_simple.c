#include <musica/version.hpp>

#include <stdio.h>

int main()
{
  printf("Musica version: %s\n", GetMusicaVersion());
  return 0;
}