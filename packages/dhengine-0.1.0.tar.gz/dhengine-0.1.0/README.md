# DhEngine

DhEngine is a lightweight Python game engine built on top of pygame.

It provides:
- Window, Clock, and Event management
- Sprites, Groups, and Scenes
- Physics, Camera, UI, Audio, Assets
- ECS, Tilemaps, Animations, and Effects

Created by Ayaan Dhalait.
