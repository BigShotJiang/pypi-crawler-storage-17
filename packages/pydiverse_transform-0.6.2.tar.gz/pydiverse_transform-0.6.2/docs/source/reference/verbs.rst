=====
Verbs
=====

.. currentmodule:: pydiverse.transform
.. autosummary::
    :toctree: _generated/
    :nosignatures:
    :template: short_title.rst

    alias
    arrange
    ast_repr
    build_query
    collect
    drop
    export
    filter
    full_join
    group_by
    inner_join
    join
    left_join
    mutate
    name
    rename
    select
    show
    show_query
    slice_head
    summarize
    ungroup
