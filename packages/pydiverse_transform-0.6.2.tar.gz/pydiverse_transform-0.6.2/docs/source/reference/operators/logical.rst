=======
Logical
=======

.. currentmodule:: pydiverse.transform.ColExpr
.. autosummary::
    :toctree: _generated/
    :nosignatures:
    :template: short_title.rst

    __and__
    __invert__
    __or__
    __xor__
    any
    all
    is_in
    is_not_null
    is_null
    fill_null
    map
