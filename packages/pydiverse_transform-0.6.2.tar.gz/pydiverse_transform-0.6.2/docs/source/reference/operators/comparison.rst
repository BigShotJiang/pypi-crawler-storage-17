==========
Comparison
==========

.. currentmodule:: pydiverse.transform.ColExpr
.. autosummary::
    :toctree: _generated/
    :nosignatures:
    :template: short_title.rst

    __eq__
    __ge__
    __gt__
    __le__
    __lt__
    __ne__
    is_inf
    is_nan
    is_not_inf
    is_not_nan
    is_not_null
    is_null
