==========
Arithmetic
==========

.. currentmodule:: pydiverse.transform.ColExpr
.. autosummary::
    :toctree: _generated/
    :nosignatures:
    :template: short_title.rst

    __add__
    __sub__
    __mul__
    __truediv__
    __neg__
    __pos__
    __floordiv__
    __mod__
