"""SAP Business Data Cloud MCP Server."""

__version__ = "0.1.0"
