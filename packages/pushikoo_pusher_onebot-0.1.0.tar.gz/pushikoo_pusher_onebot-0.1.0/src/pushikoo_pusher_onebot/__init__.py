from pushikoo_pusher_onebot.main import OneBot

__all__ = ["OneBot"]
