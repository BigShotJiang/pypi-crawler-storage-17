######################################
Account Invoice Line Standalone Module
######################################

The *Account Invoice Line Standalone Module* allows creating invoice lines that
are not linked to an invoice.

.. toctree::
   :maxdepth: 2

   design
   releases
