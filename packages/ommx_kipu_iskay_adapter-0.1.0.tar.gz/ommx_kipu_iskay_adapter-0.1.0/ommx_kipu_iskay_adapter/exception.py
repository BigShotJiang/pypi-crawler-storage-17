class OMMXKipuIskayAdapterError(Exception):
    """Domain specific error for the Kipu Iskay adapter."""

    pass
