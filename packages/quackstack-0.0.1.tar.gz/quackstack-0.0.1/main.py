def main():
    print("Hello from quackstack-template!")


if __name__ == "__main__":
    main()
