from .instrument import Instrument

__all__ = ["Instrument"]
