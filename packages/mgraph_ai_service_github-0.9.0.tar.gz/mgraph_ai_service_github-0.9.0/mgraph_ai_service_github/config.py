SERVICE_NAME                             = 'mgraph_ai_service_github'
FAST_API__TITLE                          = "MGraph-AI Service GitHub"
FAST_API__DESCRIPTION                    = "Base template for MGraph-AI microservices"
LAMBDA_DEPENDENCIES__SERVICE__GITHUB     = ['osbot-fast-api-serverless==v1.32.0',
                                            'pynacl==1.6.1']

DEPLOY__GITHUB__REPO__OWNER              = 'the-cyber-boardroom'
DEPLOY__GITHUB__REPO__NAME               = 'MGraph-AI__Service__GitHub'

ENV_VAR__GIT_HUB__ACCESS_TOKEN           = 'GIT_HUB__ACCESS_TOKEN'
ENV_VAR__TESTS__GITHUB__REPO_NAME        = 'TESTS__GITHUB__REPO_NAME'
ENV_VAR__TESTS__GITHUB__REPO_OWNER       = 'TESTS__GITHUB__REPO_OWNER'
ENV_VAR__SERVICE__AUTH__PRIVATE_KEY      = 'SERVICE__AUTH__PRIVATE_KEY'
ENV_VAR__SERVICE__AUTH__PUBLIC_KEY       = 'SERVICE__AUTH__PUBLIC_KEY'

