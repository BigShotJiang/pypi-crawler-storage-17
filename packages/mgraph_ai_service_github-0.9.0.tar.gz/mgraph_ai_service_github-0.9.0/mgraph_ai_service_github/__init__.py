package_name = 'mgraph_ai_service_github'
path         = __path__[0]