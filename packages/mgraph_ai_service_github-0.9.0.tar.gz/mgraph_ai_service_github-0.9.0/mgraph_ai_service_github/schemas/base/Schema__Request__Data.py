from osbot_utils.type_safe.Type_Safe import Type_Safe


class Schema__Request__Data(Type_Safe):                                         # Base class for operation-specific request data
    pass                                                                        # Empty base - subclasses add operation-specific fields
