# proximity_lock_system/__init__.py
__version__ = "2.1.0"
