# Icons

This directory contains SVG icons for the DocFind GUI.

Icons can be replaced with custom SVG files:
- search.svg
- index.svg
- stop.svg
- export.svg
- settings.svg
- folder-plus.svg
- file-open.svg

The GUI will work without these icons (using text labels instead).
