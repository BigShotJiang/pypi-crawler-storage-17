"""Tests for docfind."""
