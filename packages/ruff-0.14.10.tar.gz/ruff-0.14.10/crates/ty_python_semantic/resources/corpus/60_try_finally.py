try:
    a
finally:
    b
