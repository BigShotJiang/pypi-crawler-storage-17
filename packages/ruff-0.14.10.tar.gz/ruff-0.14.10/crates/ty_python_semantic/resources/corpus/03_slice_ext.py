arr[a:b, c:d]
