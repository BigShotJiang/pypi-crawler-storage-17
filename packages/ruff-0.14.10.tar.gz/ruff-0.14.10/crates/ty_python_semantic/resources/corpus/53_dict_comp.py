{x: 1 for x in s}
{j: j*j for i in range(4) for j in [i+1]}
