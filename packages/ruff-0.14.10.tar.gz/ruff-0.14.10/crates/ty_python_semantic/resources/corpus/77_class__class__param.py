class Outer:
    def x(self):
        def f(__class__):
            __class__
