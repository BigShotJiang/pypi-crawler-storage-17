try:
    type name_4 = name_1
finally:
    from .. import name_3

try:
    pass
except* 0:
    pass
else:
    def name_1() -> name_4:
        pass

    @name_1
    def name_3():
        pass
finally:
    try:
        pass
    except* 0:
        assert name_3
    finally:

        @name_3
        class name_1:
            pass
