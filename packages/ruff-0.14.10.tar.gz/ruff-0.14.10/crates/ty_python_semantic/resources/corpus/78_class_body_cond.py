class C:
    if a:
        pass
    else:
        pass
