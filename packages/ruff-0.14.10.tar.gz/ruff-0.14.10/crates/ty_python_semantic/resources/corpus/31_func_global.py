a = 0

def foo():
    global a
    a = 1
