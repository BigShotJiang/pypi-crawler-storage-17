# szn-search-mlops-sasanka-manager

This is a security placeholder package created to prevent dependency confusion attacks.