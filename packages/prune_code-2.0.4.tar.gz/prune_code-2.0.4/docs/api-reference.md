# API Reference

The library API is small by design. The primary integration point is the distiller class and configuration loader.

## Distiller
::: prune_code.distiller

## Configuration
::: prune_code.config

## Sampling
::: prune_code.sampling
