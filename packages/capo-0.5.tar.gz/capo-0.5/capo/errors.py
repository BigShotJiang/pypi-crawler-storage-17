# -*- coding: utf-8 -*-
"""Capo errors."""


class CapoValidationError(Exception):
    """Base class for validation errors in Capo."""

    pass
