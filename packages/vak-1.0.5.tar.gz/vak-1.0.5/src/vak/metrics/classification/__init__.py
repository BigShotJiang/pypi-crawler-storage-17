from .classification import Accuracy

__all__ = [
    "Accuracy",
]
