(reference-index)=

# Reference

```{toctree}
:caption: 'Contents:'
:maxdepth: 2

cli
config
filenames
spect_file_format
```
