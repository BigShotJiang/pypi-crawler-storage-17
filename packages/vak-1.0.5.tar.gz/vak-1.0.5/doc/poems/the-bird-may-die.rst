The Bird May Die
================

by `Forough Farrokhzad <http://farrokhzadpoems.com/>`_

| I feel sad,
| I feel blue.
|
| I go outside and rub my cold fingers-
| on the sleek shell of the silent night.
|
| I see that all lights of contact are dark,
| All lanes to relate us- are blocked.
|
| Nobody will introduce me to the sun,
| Nobody will take me- to the gathering of doves.
|
| Keep the flight in mind,
| The bird may die.

Translation: Maryam Dilmaghani, September 2006, Montreal
