What Does the Bird Care?
========================

by `Hanoch Levin <https://en.wikipedia.org/wiki/Hanoch_Levin>`_

| The tree is tall, the tree is green
| The sea is salty, the sea is deep
| If the sea is deep, what does the tree care?
| What does the sea care that the tree is green?
|
| the tree is tall, the tree is green
| A beautiful bird, she will fly far away
| If the bird flies, what does the tree care?
| What does the bird care that the tree is green?
|
| The sea is salty, the sea is deep
| A beautiful bird, she will fly far away
| If the bird flies away, what does the sea care?
| What does the bird care that the sea is deep?
|
| A man sings songs because the tree is green
| A man sings songs because the sea is deep
| If the bird flies, he won't sing any more songs
| What does the bird care if he sings or is silent?
