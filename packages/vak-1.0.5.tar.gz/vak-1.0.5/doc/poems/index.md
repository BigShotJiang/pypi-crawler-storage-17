(poems-index)=

# Poems

```{toctree}
the-bird-may-die
what-does-the-bird-care
unknown-bird
```
