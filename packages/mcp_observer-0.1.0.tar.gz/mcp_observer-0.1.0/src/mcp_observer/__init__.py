"""
MCP Observer - A package for observing and tracking MCP tool calls.
"""

from .observer import *

__version__ = "0.1.0"
__all__ = ["MCPObserver"]
