from .provider import ConfigProviderDependency, ConfigProviderInput

__all__ = [
    "ConfigProviderDependency",
    "ConfigProviderInput",
]
