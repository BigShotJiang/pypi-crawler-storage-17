"""merge

Revision ID: d04592473df7
Revises: 4b0128c49210, e812d42bc34f
Create Date: 2023-09-06 23:39:31.535254

"""

# revision identifiers, used by Alembic.
revision = "d04592473df7"
down_revision = ("4b0128c49210", "e812d42bc34f")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
