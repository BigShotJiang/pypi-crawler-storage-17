"""Merge migration

Revision ID: 65c4a109bbc7
Revises: 0262e50e90e0, 5e88398bc340
Create Date: 2019-12-16 01:42:44.316419

"""

# revision identifiers, used by Alembic.
revision = "65c4a109bbc7"
down_revision = ("0262e50e90e0", "5e88398bc340")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
