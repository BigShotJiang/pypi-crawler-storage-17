"""merge

Revision ID: 97f6c80c8aa5
Revises: e421c02cf9e4, 25e903510fa1
Create Date: 2020-09-28 18:00:35.664882

"""

# revision identifiers, used by Alembic.
revision = "97f6c80c8aa5"
down_revision = ("e421c02cf9e4", "25e903510fa1")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
