"""
Setup script for TokenVault SDK.

This file is provided for backward compatibility.
The package is configured using pyproject.toml.
"""

from setuptools import setup

setup()
