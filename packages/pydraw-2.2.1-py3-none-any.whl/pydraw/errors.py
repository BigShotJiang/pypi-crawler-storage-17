class InvalidArgumentError(ValueError):
    pass


class UnsupportedError(NameError):
    pass


class PydrawError(NameError):
    pass
