"""
Test Tests: Tests methods in the Text class
"""