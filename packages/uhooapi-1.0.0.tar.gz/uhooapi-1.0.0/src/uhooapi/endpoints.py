"""API Endpoint constants for uHoo."""

API_URL_BASE = "https://api.uhooinc.com/integration"
GENERATE_TOKEN = "generatetoken"
DEVICE_DATA = "getdata"
DEVICE_LIST = "getdeviceslist"
