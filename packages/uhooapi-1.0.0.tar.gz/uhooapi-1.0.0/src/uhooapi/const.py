import logging

APP_VERSION: int = 1
LOGGER = logging.getLogger(__package__)
