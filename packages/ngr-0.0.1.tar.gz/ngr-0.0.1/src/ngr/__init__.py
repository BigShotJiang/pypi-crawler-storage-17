"""Python interface for the NGR (Next Generation Reporting) R package.

This initial version only reserves the `ngr` name on PyPI and prepares the
package structure. Functionality will be implemented progressively to mirror
NGR's R API.
"""

__all__ = []
__version__ = "0.0.1"