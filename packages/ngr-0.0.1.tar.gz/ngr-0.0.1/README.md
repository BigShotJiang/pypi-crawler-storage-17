# ngr (Python)

Python interface for the **NGR** (Next Generation Reporting) R package.

Este subproyecto contiene la implementación en Python, instalable vía `pip`,
que irá replicando progresivamente la API del paquete NGR en R.

Para información general del proyecto consulta el README principal en `../README.md`.
