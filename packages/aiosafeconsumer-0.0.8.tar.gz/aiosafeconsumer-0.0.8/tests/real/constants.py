ENCODING = "utf-8"

FIELD_TRANSLATION = [
    ("_time", "ev_time"),
    ("_type", "ev_type"),
    ("_source", "ev_source"),
]
