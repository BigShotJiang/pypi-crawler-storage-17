from typing import TypeVar

DataType = TypeVar("DataType")
TargetDataType = TypeVar("TargetDataType")
