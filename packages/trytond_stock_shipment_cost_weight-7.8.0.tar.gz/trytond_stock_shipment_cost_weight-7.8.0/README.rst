#################################
Stock Shipment Cost Weight Module
#################################

The *Stock Shipment Cost Weight Module* adds "By Weight" as allocation method of
shipment cost on the carrier.

.. toctree::
   :maxdepth: 2

   releases
