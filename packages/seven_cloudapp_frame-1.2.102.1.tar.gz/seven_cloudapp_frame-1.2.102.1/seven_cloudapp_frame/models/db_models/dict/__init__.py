# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2022-09-27 09:01:54
@LastEditTime: 2022-09-27 09:02:46
@LastEditors: HuangJianYi
@Description: 
"""
__all__=["dict_info_model"]