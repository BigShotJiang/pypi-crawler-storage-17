<a name="0.8"></a>

# [0.8]() (2025-12-16)

Rename from `bbquiz` to `quizml`


<a name="0.7"></a>

# [0.7]() (2025-12-11)

Migration from strictyaml to ruamel. Also, we now have with user-definable
schema using jsonschema.

* more consistent and better consistency with error reporting
* slightly better testing
* more CLI arguments, with `-t` 


<a name="0.6"></a>

# [0.6]() (2025-02-08)

new MCQ syntax with `-x:` and `-o:` style.

<a name="0.5"></a>

# [0.5]() (2025-01-10)

first release


