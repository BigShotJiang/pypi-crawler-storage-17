#!/usr/bin/python

from quizml.cli import main

if __name__=="__main__":
    main()
