#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HOS ME命令模块
"""

# 导出所有命令类，方便外部导入
__all__ = []
