# SPDX-FileCopyrightText: 2020 EACG GmbH
#
# SPDX-License-Identifier: Apache-2.0

if __name__ == '__main__':
    from .cli import main
    main()