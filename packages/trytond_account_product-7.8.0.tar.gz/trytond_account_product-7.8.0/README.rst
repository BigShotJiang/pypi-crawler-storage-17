######################
Account Product Module
######################

The *Account Product Module* allows products to be associated with accounting
properties such as taxes and expense or revenue accounts.
It allows these properties to be easily managed using accounting categories.

.. toctree::
   :maxdepth: 2

   usage
   design
   releases
