# cmov

A Python library for creating composable video animations and scenes.

Built on [fmov](https://github.com/dylandibeneditto/fmov)