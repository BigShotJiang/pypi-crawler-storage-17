=====================
Tryton Desktop Client
=====================

Tryton is a Graphical User Interface to Tryton based on GTK__ and Python__.

__ http://www.gtk.org
__ http://www.python.org

Contents
========

.. toctree::
   :maxdepth: 2

   installation
   usage
   glossary
   releases
