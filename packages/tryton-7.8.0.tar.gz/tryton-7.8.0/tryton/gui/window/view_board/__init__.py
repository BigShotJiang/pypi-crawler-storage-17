# This file is part of Tryton.  The COPYRIGHT file at the top level of
# this repository contains the full copyright notices and license terms.
from .view_board import ViewBoard

__all__ = [ViewBoard]
