from .component import Component


class Moderator(Component):
    pass