from __future__ import annotations

from beadsflow.entrypoints.cli import main

raise SystemExit(main())
