from . import models
from . import res_partner
from . import mail_thread
from . import mail_autosubscribe
from . import mail_template
