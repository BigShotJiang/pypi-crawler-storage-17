- Consider implementing domain-based autosubscription rules. This was
  considered during first development but it wasn't a requirement at the
  time. If pursuit, this has to be done carefully to avoid affecting
  performance.
