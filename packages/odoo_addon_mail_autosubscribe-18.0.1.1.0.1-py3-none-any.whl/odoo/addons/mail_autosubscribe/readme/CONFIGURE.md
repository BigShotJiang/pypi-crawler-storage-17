Go to Configuration \> Technical \> Automation \> Autosubscribe Models
and configure the models for which you want the feature to work.

Then, on each partner, you can check the company documents subscriptions
in the field In copy of.

This feature can be disabled on specific templates, if required, by
disabling the Autosubscribe followers field.
