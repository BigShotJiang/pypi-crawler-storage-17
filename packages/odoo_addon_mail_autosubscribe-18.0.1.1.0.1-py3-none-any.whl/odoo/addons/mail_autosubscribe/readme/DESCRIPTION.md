This module allows you to configure partners that will be automatically
in copy of their company's business documents.

For example, you can configure an accountant to be in copy of all
invoices sent for a given commercial partner, regardless of the
invoicing address.
