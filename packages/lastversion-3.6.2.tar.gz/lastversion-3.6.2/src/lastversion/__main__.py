"""Used to run the package as a script with `python -m lastversion`."""

from lastversion import cli

cli.main()
