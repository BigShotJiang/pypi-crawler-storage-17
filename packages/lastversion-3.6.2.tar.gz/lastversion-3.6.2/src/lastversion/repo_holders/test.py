from lastversion.repo_holders.base import BaseProjectHolder


class TestProjectHolder(BaseProjectHolder):
    REPO_IS_HOLDER = True
