# docs/

Safety patterns and design documentation for iron_cage_safety.

## Organization

- `patterns.md` - PII detection patterns and strategies
- Future ADRs will be added as needed

## Purpose

This directory contains persistent development knowledge not suitable for code comments.
