# iron_safety/src - File Responsibility Table

| File | Responsibility |
|------|----------------|
| lib.rs | PII detection for multi-agent system outputs |
