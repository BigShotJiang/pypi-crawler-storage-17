# iron_runtime_state/src - File Responsibility Table

| File | Responsibility |
|------|----------------|
| lib.rs | Type-safe state management for Iron Cage runtime |
