# iron_runtime/src - File Responsibility Table

| File | Responsibility |
|------|----------------|
| lib.rs | Core runtime for protected AI agent execution |
