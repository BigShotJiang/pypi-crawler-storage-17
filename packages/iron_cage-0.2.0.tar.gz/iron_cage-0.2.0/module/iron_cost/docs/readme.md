# docs/

Budget strategies and design documentation for iron_cage_cost.

## Organization

- `strategies.md` - Budget allocation and enforcement strategies
- Future ADRs will be added as needed

## Purpose

This directory contains persistent development knowledge not suitable for code comments.
