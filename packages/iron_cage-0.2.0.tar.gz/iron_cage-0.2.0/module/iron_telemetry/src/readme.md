# iron_telemetry/src - File Responsibility Table

| File | Responsibility |
|------|----------------|
| lib.rs | Centralized structured logging and tracing for Iron Runtime |
