# iron_reliability/src - File Responsibility Table

| File | Responsibility |
|------|----------------|
| lib.rs | Circuit breaker pattern for preventing cascading failures |
