# docs/

Reliability patterns and design documentation for iron_cage_reliability.

## Organization

- `patterns.md` - Circuit breaker patterns and fault tolerance strategies
- Future ADRs will be added as needed

## Purpose

This directory contains persistent development knowledge not suitable for code comments.
