# docs/

Architecture and design documentation for iron_cage_types.

## Organization

- `architecture.md` - Type system design and rationale
- Future ADRs will be added as needed

## Purpose

This directory contains persistent development knowledge not suitable for code comments.
