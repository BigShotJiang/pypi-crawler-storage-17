# iron_types/src - File Responsibility Table

| File | Responsibility |
|------|----------------|
| lib.rs | Foundational types for Iron Runtime |
| ids.rs | Type-safe entity identifiers with validation |
