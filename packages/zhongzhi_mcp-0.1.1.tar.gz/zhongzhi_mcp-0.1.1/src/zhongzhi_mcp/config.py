import os

# Zhongzhi API Configuration
BASE_URL = "https://tm.ipphdata.com/api"
USERNAME = "jingke_7F9A"
PASSWORD = "3D8K2P4R"

# Endpoints
LOGIN_ENDPOINT = "/loginInterface.ipd"

# Customized Endpoints (Preferred)
SEARCH_ENDPOINT = "/interface/searchCustom.ipd"
DETAIL_ENDPOINT = "/interface/detailCustom.ipd"

# Other Endpoints
PLEDGE_ENDPOINT = "/pledge.ipd"
BALANCE_ENDPOINT = "/interface/remains.ipd"
IMAGE_SEARCH_ENDPOINT = "/imageSearch.ipd"
IMAGE_SEARCH_AGG_ENDPOINT = "/imageSearchAggregation.ipd"
SENSITIVE_WORD_ENDPOINT = "/sensitiveWord.ipd"
