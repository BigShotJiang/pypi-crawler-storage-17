# Pyarmor 9.2.0 (basic), 009672, 2025-12-18T12:10:43.263871
from .pyarmor_runtime import __pyarmor__
