"""MiniCC 核心服务层（面向 tools / runtime），通过事件总线与 TUI 解耦。"""

