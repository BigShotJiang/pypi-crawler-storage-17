"""MiniCC CLI 入口（`python -m minicc`）。"""

from minicc.cli import main

if __name__ == "__main__":
    main()
