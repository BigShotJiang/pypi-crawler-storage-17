# -*- coding: utf-8 -*-

def response_ok(url, request):
    return {
            'status_code': 200,
            'content': ''
            }

