# Lab

A minimal Python package.

## Installation

```bash
pip install vlab
```

## Usage

```python
import vlab

print(vlab.hello())
```
