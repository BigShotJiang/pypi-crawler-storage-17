"""vlab - A minimal Python package."""

__version__ = "0.1.0"

def hello():
    """Say hello from valb."""
    return "Hello from vlab!"
