ManageTranslations = "plone.app.multilingual: Manage Translations"
