Credits
=======

plone.app.multilingual has been developed based on LinguaPlone by:

Design and development --
  Iskra_ (Ramon Navarro Bosch, Victor Fernandez de Alba)

.. _Iskra: http://www.iskra.cat

Additional funding/sponsorship:
  Hitotsubashi University in Tokyo, Centre for New European studies
  (Jonathan Lewis)

Also many thanks to

Jan-Carel Brand:
   For language independent field implementation on AT

Anne Walter:
   For pushing for a initial working version

Thomas Massmann, Martijn Pieters, Martin Aspeli, David Glick
