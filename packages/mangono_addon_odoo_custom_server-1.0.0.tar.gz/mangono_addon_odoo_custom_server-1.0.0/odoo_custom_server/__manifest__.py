# -*- coding: utf-8 -*-
{
    "name": "Server Odoo mangono",
    "summary": """Custom server Odoo for mangono""",
    "description": """""",
    "author": "mangono",
    "website": "https://mangono.fr/",
    "category": "Uncategorized",
    "version": "1.0.0",
    "depends": ["base"],
    "auto_install": False,
    "data": [],
    "installable": False,
    "license": "AGPL-3",
}
