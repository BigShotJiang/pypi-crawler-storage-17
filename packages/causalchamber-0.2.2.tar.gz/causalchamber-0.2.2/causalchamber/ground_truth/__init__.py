from .main import latex_name, graph
