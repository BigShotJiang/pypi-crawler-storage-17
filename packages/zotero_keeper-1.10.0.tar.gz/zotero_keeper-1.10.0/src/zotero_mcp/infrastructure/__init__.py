"""Infrastructure Layer - External services and repository implementations"""
