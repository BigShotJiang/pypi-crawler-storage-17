"""Unit tests for domain entities."""
