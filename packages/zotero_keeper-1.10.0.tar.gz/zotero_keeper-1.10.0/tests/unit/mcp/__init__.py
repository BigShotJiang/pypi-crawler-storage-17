"""Unit tests for MCP tools."""
