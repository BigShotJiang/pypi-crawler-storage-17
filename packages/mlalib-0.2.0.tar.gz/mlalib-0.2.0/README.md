# mlalib

A lightweight library built by MLA for engineering and exploring machine intelligence.

## Installation

```bash
pip install mlalib

