"""
For the love of simulating intelligence.
"""
__version__ = "0.1.0"
__author__ = "MLA"
