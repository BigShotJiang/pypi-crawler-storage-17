"""
teledigest: LLM-driven Telegram bot that aggregates channel messages
and produces automated daily digests
"""

__version__ = "0.1.0"
