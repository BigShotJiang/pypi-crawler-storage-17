def e(number:int)->int:
    """e(number)
    Return ``1000 ** number``."""
    return 1000**number
    
def d(a:int, b:int, r=3): 
    """d(a, b, r=3)
    Divide ``a`` by ``b`` and keep ``r`` decimal digits."""
    return round(a/b, r)


def il(n: int, bl: bool = False):
    """il(n, bl=False)
    Return the *-illion* name corresponding to ``n``.
    If ``bl`` is True, return ``1000 ** n`` instead."""
    if n < 0:
        return -1

    if n == 0:
        name = "one"
    elif n == 1:
        name = "thousand"
    elif n == 2:
        name = "million"
    elif 10 <= n <= 19:
        special = {
        10: "decillion",
        11: "undecillion",
        12: "duodecillion",
        13: "tredecillion",
        14: "quattuordecillion",
        15: "quindecillion",
        16: "sexdecillion",
        17: "septendecillion",
        18: "octodecillion",
        19: "novemdecillion",
        }
        name = special[n]

    else:
        base = {
            3: "billion", 4: "trillion", 5: "quadrillion",
            6: "quintillion", 7: "sextillion",
            8: "septillion", 9: "octillion",
            10: "nonillion", 11: "decillion",
        }
 

        if n in base:
            name = base[n]
        else:
            units = ["", "un", "duo", "tre", "quattuor",
                     "quin", "sex", "septen", "octo", "novem"]

            tens = ["", "", "vigint", "trigint", "quadragint",
                    "quinquagint", "sexagint", "septuagint",
                    "octogint", "nonagint"]

            hundreds = ["", "cent", "ducent", "trecent",
                        "quadringent", "quingent", "sescent",
                        "septingent", "octingent", "nongent"]

            if n >= 1000:
                k, r = divmod(n, 1000)
                name = il(k).replace("illion", "illinillion")
                if r:
                    name = il(r).replace("illion", "") + name
            else:
                u = n % 10
                t = (n // 10) % 10
                h = (n // 100) % 10
                name = units[u] + tens[t] + hundreds[h] + "illion"

    if bl:
        return 1000**n
    return name

def illionify(n,r=3):
    """illionify(n, r=3)
    Convert a large integer into *-illion* long form.
    """
    if n < 1000:
        return n
    k = (len(str(n)) - 1) // 3
    a = il(k,True)
    return f"{d(n,a,r)} {il(k)}"





