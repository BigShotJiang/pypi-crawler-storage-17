"""A lightweight file uploader input for Django and Amazon S3."""

from . import _version

__version__ = _version.version
VERSION = _version.version_tuple
