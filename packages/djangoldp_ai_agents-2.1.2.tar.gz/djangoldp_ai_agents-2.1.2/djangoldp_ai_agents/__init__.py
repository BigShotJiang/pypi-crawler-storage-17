__version__ = "2.1.2"
name = "djangoldp_ai_agents"
