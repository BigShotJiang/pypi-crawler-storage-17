from django.apps import AppConfig


class AgentRecommendationConfig(AppConfig):
    name = "agent_recommendation"
    verbose_name = "AI Agent - Recommendation"
