from django.apps import AppConfig


class AgentDSDSummarizeConfig(AppConfig):
    name = "agent_dsd_summarize"
    verbose_name = "AI Agent - DSD summarize"
