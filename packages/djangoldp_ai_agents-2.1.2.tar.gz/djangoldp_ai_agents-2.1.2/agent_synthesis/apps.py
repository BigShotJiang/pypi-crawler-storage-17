from django.apps import AppConfig


class AgentSynthesisConfig(AppConfig):
    name = "agent_synthesis"
    verbose_name = "AI Agent - Synthesis"
