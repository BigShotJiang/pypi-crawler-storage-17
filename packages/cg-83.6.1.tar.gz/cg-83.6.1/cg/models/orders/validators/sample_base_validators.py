def snake_case(value: str):
    return value.lower().replace(" ", "_")
