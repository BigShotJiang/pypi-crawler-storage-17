# xmpy框架的CTA策略模块

## 说明
针对单标的CTA类量化策略设计的应用模块，用于实现CTA策略从代码开发、参数优化到自动交易的全流程业务功能。

## 安装
### 直接使用pip命令：
pip install xmpy_ctastrategy

### 或者下载源代码后，解压后在cmd中运行：
pip install .