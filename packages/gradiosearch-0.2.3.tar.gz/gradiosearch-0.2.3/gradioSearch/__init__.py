"""
gradioSearch - A CLI tool for searching FAISS vector databases with Gradio GUI
"""

__version__ = "0.2.3"
