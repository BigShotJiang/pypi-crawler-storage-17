from memori.storage.adapters.mongodb._adapter import Adapter

__all__ = ["Adapter"]
