# Photosortman

A simple photo sorting and basic quality analysis tool with game controller support.

## Description

Photosortman helps you quickly sort through large photo collections by categorizing them as Best, Standard, or Bad. It features with basic quality analysis to detect blur, brightness, and composition issues, making photo management efficient and fun.

With full game controller support and a cyberpunk-themed interface, sorting photos feels like playing a game!

## Features

- **Quick Photo Sorting**: Categorize photos into Best, Standard, or Bad with keyboard or controller
- **Basic Quality Analysis**: Automatic blur detection, brightness analysis, and quality scoring
- **Game Controller Support**: Full Xbox/PlayStation controller integration with customizable button mapping
- **Dual Themes**: Switch between Cyberpunk and Casual themes
- **GPU Acceleration**: Optional CUDA support for faster analysis
- **Flexible Operations**: Choose between copying or moving files
- **Sound Effects**: Audio feedback for actions (can be toggled)

## Installation

### Requirements

- Python 3.12 or higher
- PyQt6
- pygame (for controller support)
- OpenCV (for image analysis)
- Optional: CUDA-capable GPU for acceleration

### Setup

1. Clone the repository:
```bash
git clone https://github.com/raniaamina/photosortman.git
cd photosortman
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Linux/Mac
# or
venv\Scripts\activate  # On Windows
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Run the application:
```bash
python photoman.py
# or
bash run.sh
```

## Usage

### Basic Workflow

1. **Select Folder**: Click "Select Folder" or press Y on controller to choose your photo directory
2. **Navigate**: Use Left/Right triggers or arrow keys to browse photos
3. **Categorize**: Press A (Best), X (Standard), or B (Bad) to sort photos
4. **Analyze**: Click "Start Analysis" to run AI quality detection
5. **Done**: Photos are automatically organized into category folders

### Keyboard Shortcuts

- **Arrow Left/Right**: Navigate photos
- **1**: Mark as Best
- **2**: Mark as Standard  
- **3**: Mark as Bad

### Controller Mapping

> **Note for PlayStation Controller Users:**  
> PS controllers use different trigger axis indices than Xbox controllers. If your triggers don't work correctly for navigation:
> 1. Open "🎮 Remap Controller" in Settings
> 2. Remap "Previous Photo" to your L2 trigger
> 3. Remap "Next Photo" to your R2 trigger
> 4. Click "Save"

#### Default Controls

**Navigation:**
- **LT (Left Trigger)**: Previous photo
- **RT (Right Trigger)**: Next photo

**Categorization:**
- **A Button**: Best
- **X Button**: Standard
- **B Button**: Bad

**Actions:**
- **Y Button**: Select folder
- **Start**: Start quality analysis
- **Select**: Toggle sound

**LB Combos (Hold LB + D-Pad):**
- **LB + D-Pad Up**: Decrease CPU workers
- **LB + D-Pad Down**: Increase CPU workers
- **LB + D-Pad Left**: Toggle sound
- **LB + D-Pad Right**: Toggle GPU mode

**RB Combos (Hold RB + D-Pad):**
- **RB + D-Pad Up**: Toggle copy/move mode
- **RB + D-Pad Down**: Toggle theme
- **RB + D-Pad Left**: Open controller remapping
- **RB + D-Pad Right**: Show about dialog

**D-Pad Navigation:**
- **D-Pad Up/Down**: Navigate thumbnail list
- **D-Pad Left/Right**: Previous/Next photo

### Custom Controller Mapping

You can customize all controller buttons **using only your controller**:

1. Open "🎮 Remap Controller" in the settings panel (or press RB + D-Pad Left)
2. **Navigate** with **LT** (previous) / **RT** (next) to select an action
3. Press **A** to start remapping the highlighted action
4. Press the desired button/combo on your controller
5. If duplicate detected, press **A** (Yes) or **B** (No)
6. Press **RB+A** to save, or **RB+B** to cancel

**Remap Dialog Controls:**
- **LT**: Navigate to previous action
- **RT**: Navigate to next action
- **A**: Trigger remap for highlighted action
- **RB+A**: Save and close
- **RB+B**: Cancel and close

**All 21 Remappable Actions:**
- Navigation (2): Previous Photo, Next Photo
- Categorization (3): Best, Standard, Bad
- Actions (3): Select Folder, Start Analysis, Toggle Sound
- LB Combos (4): CPU Workers -, CPU Workers +, Toggle Sound, Toggle GPU
- RB Combos (5): About, Reconnect, Close Dialog, Toggle Copy, Toggle Theme
- D-Pad Navigation (4): Navigate Up, Down, Left, Right

The dialog supports:
- Single buttons (A, B, X, Y, etc.)
- Triggers (LT, RT)
- D-Pad directions
- **Combo buttons** (LB/RB + any button/trigger/D-pad)


### Reconnecting Controllers

If you connect a controller after the app has started, you don't need to restart:

1. Connect your controller and power it on
2. Click the **🔄 Reconnect** button next to the controller status in Settings
3. The app will scan and connect to your controller automatically
4. A notification will confirm successful connection

This feature is especially useful when:
- Your controller disconnects during use
- You want to switch to a different controller
- You start the app before turning on your controller

## Settings

- **GPU Mode**: Enable CUDA acceleration (requires NVIDIA GPU)
- **Copy Mode**: Copy files instead of moving them
- **CPU Workers**: Adjust parallel processing threads
- **Sound**: Enable/disable audio feedback
- **Theme**: Switch between Cyberpunk and Casual themes

## Credits

**Developed by Rania Amina**

Built with PyQt6 & Python

## License

GPL v3 - Free and open source software

---

**GitHub**: [github.com/raniaamina/photosortman](https://github.com/raniaamina/photosortman)
