"""Models defined in fabricatio-thinking."""
