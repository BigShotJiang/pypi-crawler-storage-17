"""Capabilities defined in fabricatio-thinking."""
