from memori.storage.adapters.django._adapter import Adapter

__all__ = ["Adapter"]
