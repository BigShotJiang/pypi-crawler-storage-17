******
Design
******

The *Account Move Line Grouping Module* adds some new concepts and extends some
existing concepts.

.. _model-account.move.line.group:

Account Move Line Group
=======================

*Account Move Line Group* groups `Account Move Lines
<account:model-account.move.line>` per move, account and party among others.
