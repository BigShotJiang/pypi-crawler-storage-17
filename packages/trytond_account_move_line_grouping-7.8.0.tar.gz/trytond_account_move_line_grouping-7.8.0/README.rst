#################################
Account Move Line Grouping Module
#################################

The *Account Move Line Grouping Module* adds a view that displays move lines
grouped.

.. toctree::
   :maxdepth: 2

   design
   releases
