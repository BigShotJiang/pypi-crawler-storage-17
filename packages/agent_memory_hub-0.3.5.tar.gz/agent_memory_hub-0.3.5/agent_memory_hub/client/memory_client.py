"""
Public facing Memory Client.
"""

from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from agent_memory_hub.config.alloydb_config import AlloyDBConfig
    from agent_memory_hub.config.redis_config import RedisConfig

from agent_memory_hub.config.regions import DEFAULT_REGION
from agent_memory_hub.control_plane.region_guard import RegionGuard
from agent_memory_hub.models.base import BaseMemory
from agent_memory_hub.routing.memory_router import MemoryRouter
from agent_memory_hub.utils.telemetry import get_tracer


class MemoryClient:
    """
    Client for accessing agent memory with region governance.
    """

    def __init__(
        self,
        agent_id: str,
        session_id: str,
        region: str = DEFAULT_REGION,
        region_restricted: bool = True,
        backend: str = "adk",
        ttl_seconds: Optional[int] = None,
        alloydb_config: Optional["AlloyDBConfig"] = None,
        redis_config: Optional["RedisConfig"] = None,
        environment: str = "prod",
    ):
        """
        Initialize the MemoryClient.

        Args:
            agent_id: Unique identifier for the agent.
            session_id: Unique identifier for the session.
            region: The cloud region where memory should be stored/retrieved.
            region_restricted: If True, enforces strict region checks.
            backend: Storage backend ("adk" for GCS, "alloydb" for AlloyDB).
            ttl_seconds: Time-to-live in seconds (None = no expiry).
            alloydb_config: AlloyDB configuration (required if backend="alloydb").
            redis_config: Redis configuration (optional if backend="redis").
            environment: Environment context (e.g., "prod", "dev") for resource naming.
        """
        if not agent_id:
            raise ValueError("agent_id cannot be empty")
        if not session_id:
            raise ValueError("session_id cannot be empty")
        self.agent_id = agent_id
        self.session_id = session_id
        self.region = region
        self.region_restricted = region_restricted
        self.backend = backend
        self.ttl_seconds = ttl_seconds
        self.environment = environment
        self._tracer = get_tracer()

        if region_restricted:
            self._guard = RegionGuard(region)
            self._router = MemoryRouter(
                region_guard=self._guard,
                backend=backend,
                ttl_seconds=ttl_seconds,
                alloydb_config=alloydb_config,
                redis_config=redis_config,
                environment=environment,
            )
        else:
            # Fallback or less strict mode not fully implemented in spec, 
            # assuming guard is always used but maybe with relaxed checks if requested.
            # For now, we strictly follow the requested design where region is passed.
            self._guard = RegionGuard(region)
            self._router = MemoryRouter(
                region_guard=self._guard,
                backend=backend,
                ttl_seconds=ttl_seconds,
                alloydb_config=alloydb_config,
                redis_config=redis_config,
                environment=environment,
            )

    def write(self, value: Any, key: str = "default") -> None:
        """
        Write a value to the memory store.

        Args:
            value: The data to store.
            key: specific key or context for the memory (e.g., 'episodic', 'semantic').
        """
        with self._tracer.start_as_current_span("MemoryClient.write") as span:
            span.set_attribute("agent.id", self.agent_id)
            span.set_attribute("session.id", self.session_id)
            span.set_attribute("region", self.region)
            span.set_attribute("memory.key", key)
            
            # Composite key could include agent_id to namespace it
            composite_key = f"{self.agent_id}/{key}"
            self._router.write(self.session_id, composite_key, value)

    def write_model(self, memory_model: "BaseMemory") -> None:
        """
        Write a semantic memory model to the store.
        
        Args:
            memory_model: Pydantic model instance (EpisodicMemory, SemanticMemory, etc.)
        """
        # Ensure agent_id matches client if not set (though model has default)
        if hasattr(memory_model, "agent_id") and not memory_model.agent_id:
             memory_model.agent_id = self.agent_id
             
        # Use model ID or content hash as key? 
        # For now, we use a predictable key scheme: type/id
        key = f"{memory_model.__class__.__name__.lower()}/{memory_model.id}"
        
        # Serialize to dict
        value = memory_model.to_dict()
        
        with self._tracer.start_as_current_span("MemoryClient.write_model") as span:
            span.set_attribute("memory.type", memory_model.__class__.__name__)
            span.set_attribute("memory.id", memory_model.id)
            
            self.write(value, key=key)

    def recall(self, key: str = "default") -> Optional[Any]:
        """
        Recall a value from the memory store.

        Args:
            key: The key used during write.

        Returns:
            The stored value or None if not found.
        """
        with self._tracer.start_as_current_span("MemoryClient.recall") as span:
            span.set_attribute("agent.id", self.agent_id)
            span.set_attribute("session.id", self.session_id)
            span.set_attribute("region", self.region)
            span.set_attribute("memory.key", key)
            
            composite_key = f"{self.agent_id}/{key}"
            return self._router.read(self.session_id, composite_key)

