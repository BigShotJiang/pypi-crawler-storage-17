__version__ = "0.0.7"

from slack_message import messages as slack_msg
