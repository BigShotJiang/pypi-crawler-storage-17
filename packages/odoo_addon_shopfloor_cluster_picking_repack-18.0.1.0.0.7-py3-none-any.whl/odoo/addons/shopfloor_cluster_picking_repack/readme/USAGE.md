Go to the "cluster picking" scenario and check "Pack pickings".
