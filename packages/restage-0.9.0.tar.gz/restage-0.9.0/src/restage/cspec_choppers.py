from __future__ import annotations


def calculate(order: float, time: float, energy: float, names: list[str] | None = None):
    raise NotImplementedError('CSPEC chopper calculations not implemented yet')
