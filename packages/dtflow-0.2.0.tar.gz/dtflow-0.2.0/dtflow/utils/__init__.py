"""工具函数"""
from .display import display_data, print_stats

__all__ = ['display_data', 'print_stats']
