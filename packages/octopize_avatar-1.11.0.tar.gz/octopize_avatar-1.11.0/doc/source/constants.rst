Constants
=========

Runtime constants and helper enumerations.

.. automodule:: avatars.constants
   :members:
   :undoc-members:
   :no-index:
