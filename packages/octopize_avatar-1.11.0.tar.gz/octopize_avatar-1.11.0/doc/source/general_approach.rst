.. Deprecated placeholder (merged into api_reference.rst). Excluded via conf.py.

Deprecated - use api_reference.rst instead
==========================================

Content merged into the consolidated ``Detailed doc`` page.
