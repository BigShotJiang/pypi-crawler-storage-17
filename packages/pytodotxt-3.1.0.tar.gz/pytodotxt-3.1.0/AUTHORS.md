# Authors

For the time being, this project is authored by

 - Robert Labudda (https://vonshednob.cc/pytodotxt)

Gratitude goes to these individuals for their contribution:

 - Sander Voerman (https://github.com/sandervoerman)
 - Markus Katharina Brechtel (https://github.com/chaotika)
 - purarue (https://github.com/purarue)
 - Sylvain303 (https://github.com/Sylvain303)
 - gal064 (https://github.com/gal064)

