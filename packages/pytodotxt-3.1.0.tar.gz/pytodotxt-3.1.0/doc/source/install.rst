Installing
==========

The easiest way to install pytodotxt is through `PyPi
<https://pypi.org/projects/pytodotxt/>`_::

  pip install pytodotxt

If you’d rather download the source from the authoritative website, visit
https://vonshednob.cc/pytodotxt/releases.html and get the signed source
tarball from there.

