"""AutoProfiler: automated exploratory data analysis."""

from .profiler import profile

__all__ = ["profile"]
__version__ = "0.1.0"
