echo "Use this script to set up your environment"
