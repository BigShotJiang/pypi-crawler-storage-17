echo "Starting example setup"
source venv/bin/activate || echo "make basf2 work again"
export MY_PYTHON_PATH=$(which python3)
echo "Done with example setup"
