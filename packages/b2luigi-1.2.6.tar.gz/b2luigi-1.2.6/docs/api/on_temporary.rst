.. _`api-on-temporary-label`:

Temporary File Context Manager
------------------------------

.. autofunction:: b2luigi.on_temporary_files

.. autoclass:: b2luigi.core.temporary_wrapper.TemporaryFileContextManager
    :members: __enter__
    :show-inheritance:
