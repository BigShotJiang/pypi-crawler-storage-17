basf2\_helper package
=====================

.. automodule:: b2luigi.basf2_helper.targets
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: b2luigi.basf2_helper.tasks
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: b2luigi.basf2_helper.utils
    :members:
    :undoc-members:
    :show-inheritance:
