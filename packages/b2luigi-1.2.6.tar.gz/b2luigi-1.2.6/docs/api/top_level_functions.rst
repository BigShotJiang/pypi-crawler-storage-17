.. _`api-top-level-functions-label`:

Top-Level Function
------------------

.. autofunction:: b2luigi.process
