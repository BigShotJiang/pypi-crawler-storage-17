.. _`api-targets-label`:

Target
======

.. automodule:: b2luigi.core.target
   :members:
   :undoc-members:
   :show-inheritance:
