.. _settings-label:

Settings
--------

.. automodule:: b2luigi.core.settings
   :members:
   :show-inheritance:
