Public Belle II Repository
==========================

By contributing to this repository you
  * affirm that your contribution to the Belle II software complies with the Belle II code of conduct (see https://public.belle2.org/downloads/belle2_bylaws.pdf),
  * grant the members of the Belle II collaboration the right to use and modify your contribution,
  * grant the Belle II collaboration the right to distribute your contribution under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the license (GPLv3), or (at your option) any later version; a copy of the license is distributed in the [`LICENSE` file](https://github.com/belle2/b2luigi/blob/main/LICENSE),
  * provide the contribution "as is" without warranty.
