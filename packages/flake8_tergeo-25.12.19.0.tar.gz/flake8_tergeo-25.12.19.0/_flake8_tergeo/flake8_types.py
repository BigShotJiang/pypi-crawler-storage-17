"""Types for flake8 checks and plugins."""

from __future__ import annotations
