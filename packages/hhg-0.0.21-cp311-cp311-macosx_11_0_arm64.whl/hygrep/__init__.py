"""hygrep - Hybrid file search with semantic + keyword matching."""

from pathlib import Path

__version__ = (Path(__file__).parent / "VERSION").read_text().strip()
