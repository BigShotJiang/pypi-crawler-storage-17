"""Python toolbox of Ambient Digital containing an abundance of useful tools and gadgets."""

__version__ = "12.6.6"
