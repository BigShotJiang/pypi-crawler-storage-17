Authors
=======

FauxFactory is written and maintained by Og Maciel and various
contributors.

Development Lead
----------------

- Og Maciel `@omaciel <https://github.com/omaciel/>`_

Contributors
------------

- Corey Welton `@cswiii <https://github.com/cswiii/>`_
- Elyézer Rezende `@elyezer <https://github.com/elyezer/>`_
- Gilad Shefer `@gshefer <https://github.com/gshefer/>`_
- Jacob Callahan `@JacobCallahan <https://github.com/JacobCallahan>`_
- James Laska `@jlaska <https://github.com/jlaska>`_
- Jefferson Fausto Vaz `@faustovaz <https://github.com/faustovaz/>`_
- Jeremy Audet `@Ichimonji10 <https://github.com/Ichimonji10/>`_
- Jonathan Edwards `@apense <https://github.com/apense/>`_
- Kedar Bidarkar  `@kbidarkar <https://github.com/kbidarkar/>`_
- Pavel Zagalsky `@pavelzag <https://github.com/pavelzag/>`_
- Renzo Nuccitelli `@renzon <https://github.com/renzon>`_
- Sachin Ghai `@sghai <https://github.com/sghai/>`_
- Milan Falešník `@mfalesni <https://github.com/mfalesni/>`_
- Nikhil Dhandre `@digitronik <https://github.com/digitronik/>`_
- Mike Shriver `@mshriver <https://github.com/mshriver/>`_
- Lisa Walker `@liwalker-rh <https://github.com/liwalker-rh/>`_
