"""
Module for processing Grype scan results and loading them into RegScale.
"""
