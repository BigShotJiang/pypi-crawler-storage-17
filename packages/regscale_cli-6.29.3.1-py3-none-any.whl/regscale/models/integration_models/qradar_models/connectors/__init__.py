"""QRadar connector models for RegScale."""
