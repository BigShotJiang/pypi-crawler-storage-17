# cellmap-utils

[![PyPI - Version](https://img.shields.io/pypi/v/cellmap-utils.svg)](https://pypi.org/project/cellmap-utils)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/cellmap-utils.svg)](https://pypi.org/project/cellmap-utils)


[Documentation page](https://yuriyzubov.github.io/cellmap-utils/)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install cellmap-utils
```

