::: cellmap_utils.zarr.metadata
::: cellmap_utils.zarr.node
::: cellmap_utils.zarr.roi
::: cellmap_utils.zarr.store
::: cellmap_utils.zarr.validate