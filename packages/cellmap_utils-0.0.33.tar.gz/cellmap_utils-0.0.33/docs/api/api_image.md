::: cellmap_utils.image.info
