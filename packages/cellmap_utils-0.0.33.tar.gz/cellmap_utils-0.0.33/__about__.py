# SPDX-FileCopyrightText: 2024-present U.N. Owen <zubov452@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.15"
