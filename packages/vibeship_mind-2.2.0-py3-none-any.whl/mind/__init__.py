"""Mind - File-based memory system for AI coding assistants."""

__version__ = "2.1.2"
