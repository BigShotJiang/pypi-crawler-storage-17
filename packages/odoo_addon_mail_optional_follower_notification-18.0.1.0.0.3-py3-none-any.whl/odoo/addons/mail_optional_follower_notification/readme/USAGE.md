To use this module, you need to use the checkbox near "Followers of the
document and" on mail.compose.message:

This field it's initialized to true to keep the standard behavior.

![](static/description/optional_follower_001.png)

![](static/description/optional_follower_002.png)

![](static/description/optional_follower_003.png)
