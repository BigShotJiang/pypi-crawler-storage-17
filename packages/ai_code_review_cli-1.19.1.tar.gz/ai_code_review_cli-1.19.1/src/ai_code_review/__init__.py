"""AI-powered code review tool for GitLab Merge Requests."""

__version__ = "0.1.0"
__author__ = "Juanje Ojeda"
__email__ = "juanje@redhat.com"
