# RAM loadable binaries

* The RAM loadable binaries have been generated against [ESP-IDF v5.4.1](https://github.com/espressif/esp-idf/tree/v5.4.1/)

* The source code can be found at the [Firmware source code feature branch](https://github.com/espressif/esp-cryptoauthlib/tree/feature/add_firmware_source_code).
