"""Test configuration file management.

This package provides ConfigFile subclasses for creating and managing
test infrastructure files like conftest.py and test skeleton files.
"""
