"""The pytest entry point."""
import akida.cli
import sys


if __name__ == "__main__":
    sys.exit(akida.cli.main())
