#pragma once

#include "infra/exports.h"

namespace akida {

AKIDASHAREDLIB_EXPORT const char* version();

}  // namespace akida
