from .spi_flash import Flash

"""
External SPI Master memory direct access base address
"""
SPI_MASTER_MEMORY = 0x8000_0000
