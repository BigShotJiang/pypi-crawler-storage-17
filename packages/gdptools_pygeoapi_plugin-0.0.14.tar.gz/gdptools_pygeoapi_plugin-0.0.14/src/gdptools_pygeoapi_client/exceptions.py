"""Custom exceptions for the GDP PyGeoAPI client."""


class GDPClientError(Exception):
    """Base exception for all GDP client errors."""

    pass


class GDPPayloadError(GDPClientError):
    """Raised when there is an issue constructing a request payload."""

    pass


class GDPJobError(GDPClientError):
    """Raised when a job fails or returns an unexpected status."""

    def __init__(
        self, message: str, job_id: str | None = None, status: str | None = None
    ):
        """Initialize GDPJobError.

        Args:
            message: Error message.
            job_id: The job ID that failed.
            status: The job status when the error occurred.
        """
        super().__init__(message)
        self.job_id = job_id
        self.status = status


class GDPTimeoutError(GDPClientError):
    """Raised when a job exceeds the maximum polling time."""

    def __init__(
        self, message: str, job_id: str | None = None, elapsed: float | None = None
    ):
        """Initialize GDPTimeoutError.

        Args:
            message: Error message.
            job_id: The job ID that timed out.
            elapsed: Time elapsed before timeout (seconds).
        """
        super().__init__(message)
        self.job_id = job_id
        self.elapsed = elapsed


class GDPHTTPError(GDPClientError):
    """Raised when an HTTP request fails."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response_body: str | None = None,
    ):
        """Initialize GDPHTTPError.

        Args:
            message: Error message.
            status_code: HTTP status code.
            response_body: Response body snippet.
        """
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body
