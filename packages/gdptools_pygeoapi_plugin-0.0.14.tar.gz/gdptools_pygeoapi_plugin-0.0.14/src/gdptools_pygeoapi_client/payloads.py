"""Payload builders for GDP PyGeoAPI processes."""

from __future__ import annotations

import json
from typing import Any

import geopandas as gpd


# =============================================================================
# ClimateR Catalog Payloads
# =============================================================================


def build_weights_climr_payload(
    cat_dict: dict[str, Any],
    gdf: gpd.GeoDataFrame,
    shape_crs: int | str,
    shape_poly_idx: str,
    wght_gen_proj: int | str,
    start_date: str,
    end_date: str,
) -> dict[str, Any]:
    """Build the payload for the GDP-CalcWeightsClimr process.

    Args:
        cat_dict: Catalog dictionary from climateR-catalogs parquet file.
        gdf: GeoDataFrame containing user polygons.
        shape_crs: EPSG code or proj string for the feature CRS.
        shape_poly_idx: Column name for polygon identifiers.
        wght_gen_proj: EPSG code for weight generation (equal-area recommended).
        start_date: Start date in YYYY-MM-DD format.
        end_date: End date in YYYY-MM-DD format.

    Returns:
        Dictionary payload ready to be sent as JSON.
    """
    # Ensure CRS is set on the GeoDataFrame
    if gdf.crs is None:
        gdf = gdf.set_crs(shape_crs)

    return {
        "inputs": {
            "cat_dict": json.dumps(cat_dict),
            "shape_file": gdf.to_json(),
            "shape_crs": json.dumps(shape_crs),
            "shape_poly_idx": shape_poly_idx,
            "wght_gen_proj": json.dumps(wght_gen_proj),
            "start_date": start_date,
            "end_date": end_date,
        }
    }


def build_agg_climr_payload(
    cat_dict: dict[str, Any],
    weights_json: str,
    gdf: gpd.GeoDataFrame,
    shape_crs: int | str,
    shape_poly_idx: str,
    start_date: str,
    end_date: str,
) -> dict[str, Any]:
    """Build the payload for the GDP-CalcAggClimr process.

    Args:
        cat_dict: Catalog dictionary from climateR-catalogs parquet file.
        weights_json: JSON string of the weights DataFrame.
        gdf: GeoDataFrame containing user polygons.
        shape_crs: EPSG code or proj string for the feature CRS.
        shape_poly_idx: Column name for polygon identifiers.
        start_date: Start date in YYYY-MM-DD format.
        end_date: End date in YYYY-MM-DD format.

    Returns:
        Dictionary payload ready to be sent as JSON.
    """
    # Ensure CRS is set on the GeoDataFrame
    if gdf.crs is None:
        gdf = gdf.set_crs(shape_crs)

    return {
        "inputs": {
            "cat_dict": json.dumps(cat_dict),
            "weights": weights_json,
            "shape_file": gdf.to_json(),
            "shape_crs": json.dumps(shape_crs),
            "shape_poly_idx": shape_poly_idx,
            "start_date": start_date,
            "end_date": end_date,
        }
    }


# =============================================================================
# NHGF STAC Catalog Payloads
# =============================================================================


def build_weights_stac_payload(
    collection_id: str,
    variables: list[str],
    gdf: gpd.GeoDataFrame,
    shape_crs: int | str,
    shape_poly_idx: str,
    wght_gen_proj: int | str,
    start_date: str,
    end_date: str,
) -> dict[str, Any]:
    """Build the payload for the GDP-CalcWeightsStac process.

    Args:
        collection_id: STAC collection ID (e.g., 'conus404', 'terraclim').
        variables: List of variable names to extract.
        gdf: GeoDataFrame containing user polygons.
        shape_crs: EPSG code or proj string for the feature CRS.
        shape_poly_idx: Column name for polygon identifiers.
        wght_gen_proj: EPSG code for weight generation (equal-area recommended).
        start_date: Start date in YYYY-MM-DD format.
        end_date: End date in YYYY-MM-DD format.

    Returns:
        Dictionary payload ready to be sent as JSON.
    """
    # Ensure CRS is set on the GeoDataFrame
    if gdf.crs is None:
        gdf = gdf.set_crs(shape_crs)

    return {
        "inputs": {
            "collection_id": collection_id,
            "variables": json.dumps(variables),
            "shape_file": gdf.to_json(),
            "shape_crs": json.dumps(shape_crs),
            "shape_poly_idx": shape_poly_idx,
            "wght_gen_proj": json.dumps(wght_gen_proj),
            "start_date": start_date,
            "end_date": end_date,
        }
    }


def build_agg_stac_payload(
    collection_id: str,
    variables: list[str],
    weights_json: str,
    gdf: gpd.GeoDataFrame,
    shape_crs: int | str,
    shape_poly_idx: str,
    start_date: str,
    end_date: str,
) -> dict[str, Any]:
    """Build the payload for the GDP-CalcAggStac process.

    Args:
        collection_id: STAC collection ID (e.g., 'conus404', 'terraclim').
        variables: List of variable names to aggregate.
        weights_json: JSON string of the weights DataFrame.
        gdf: GeoDataFrame containing user polygons.
        shape_crs: EPSG code or proj string for the feature CRS.
        shape_poly_idx: Column name for polygon identifiers.
        start_date: Start date in YYYY-MM-DD format.
        end_date: End date in YYYY-MM-DD format.

    Returns:
        Dictionary payload ready to be sent as JSON.
    """
    # Ensure CRS is set on the GeoDataFrame
    if gdf.crs is None:
        gdf = gdf.set_crs(shape_crs)

    return {
        "inputs": {
            "collection_id": collection_id,
            "variables": json.dumps(variables),
            "weights": weights_json,
            "shape_file": gdf.to_json(),
            "shape_crs": json.dumps(shape_crs),
            "shape_poly_idx": shape_poly_idx,
            "start_date": start_date,
            "end_date": end_date,
        }
    }
