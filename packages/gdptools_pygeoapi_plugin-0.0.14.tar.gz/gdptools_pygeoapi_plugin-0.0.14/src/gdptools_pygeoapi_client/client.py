"""Main GDP Client class for interacting with pygeoapi processes."""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import geopandas as gpd
import pandas as pd
import requests

from gdptools_pygeoapi_client.cache import WeightsCache
from gdptools_pygeoapi_client.exceptions import GDPHTTPError, GDPPayloadError
from gdptools_pygeoapi_client.payloads import (
    build_agg_climr_payload,
    build_agg_stac_payload,
    build_weights_climr_payload,
    build_weights_stac_payload,
)
from gdptools_pygeoapi_client.polling import (
    extract_job_id,
    get_job_results,
    poll_until_complete,
)

LOGGER = logging.getLogger(__name__)

# Default endpoints
DEFAULT_PROD_URL = "https://api.water.usgs.gov/gdp/pygeoapi"
DEFAULT_LOCAL_URL = "http://localhost:5001/api/gdp/pygeoapi"

# Process names - ClimateR catalog
PROCESS_CALC_WEIGHTS_CLIMR = "GDP-CalcWeightsClimr"
PROCESS_CALC_AGG_CLIMR = "GDP-CalcAggClimr"

# Process names - NHGF STAC catalog
PROCESS_CALC_WEIGHTS_STAC = "GDP-CalcWeightsStac"
PROCESS_CALC_AGG_STAC = "GDP-CalcAggStac"


class GDPClient:
    """Client for interacting with GDP pygeoapi processes.

    Supports two data source types:
    - ClimateR catalog (OpenDAP): Use `calc_weights_climr()` and `calc_agg_climr()`
    - NHGF STAC catalog (Zarr): Use `calc_weights_stac()` and `calc_agg_stac()`

    Example (ClimateR):
        >>> client = GDPClient()
        >>> weights = client.calc_weights_climr(
        ...     gdf=my_geodataframe,
        ...     cat_dict=catalog_dict,
        ...     shape_crs=4326,
        ...     shape_poly_idx="poly_idx",
        ...     wght_gen_proj=6931,
        ...     start_date="1980-01-01",
        ...     end_date="1980-12-31",
        ... )
        >>> agg_results = client.calc_agg_climr(
        ...     gdf=my_geodataframe,
        ...     weights=weights,
        ...     cat_dict=catalog_dict,
        ...     shape_crs=4326,
        ...     shape_poly_idx="poly_idx",
        ...     start_date="1980-01-01",
        ...     end_date="1980-12-31",
        ... )

    Example (STAC):
        >>> client = GDPClient()
        >>> weights = client.calc_weights_stac(
        ...     gdf=my_geodataframe,
        ...     collection_id="conus404",
        ...     variables=["PWAT"],
        ...     shape_crs=4326,
        ...     shape_poly_idx="huc12",
        ...     wght_gen_proj=6931,
        ...     start_date="1999-01-01",
        ...     end_date="1999-01-07",
        ... )
        >>> agg_results = client.calc_agg_stac(
        ...     gdf=my_geodataframe,
        ...     weights=weights,
        ...     collection_id="conus404",
        ...     variables=["PWAT"],
        ...     shape_crs=4326,
        ...     shape_poly_idx="huc12",
        ...     start_date="1999-01-01",
        ...     end_date="1999-01-07",
        ... )
    """

    def __init__(
        self,
        base_url: str = DEFAULT_PROD_URL,
        timeout: float = 600.0,
        poll_interval: float = 2.0,
        use_cache: bool = True,
        cache_dir: Path | str | None = None,
    ):
        """Initialize the GDP Client.

        Args:
            base_url: The pygeoapi server base URL. Defaults to production.
            timeout: Maximum time to wait for job completion (seconds).
            poll_interval: Time between status polls (seconds).
            use_cache: Whether to cache computed weights locally.
            cache_dir: Directory for weight cache. Defaults to ~/.cache/gdptools_pygeoapi_client/
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.poll_interval = poll_interval
        self.use_cache = use_cache

        # Initialize session for connection pooling
        self._session = requests.Session()

        # Initialize cache
        self._cache = WeightsCache(cache_dir) if use_cache else None

        LOGGER.info(f"GDPClient initialized with base_url={self.base_url}")

    def __repr__(self) -> str:
        """Return string representation."""
        return f"GDPClient(base_url={self.base_url!r}, use_cache={self.use_cache})"

    def _submit_job(self, process_name: str, payload: dict[str, Any]) -> str:
        """Submit an async job and return the job ID.

        Args:
            process_name: The pygeoapi process name.
            payload: The request payload.

        Returns:
            The job ID.

        Raises:
            GDPHTTPError: If the submission fails.
            GDPPayloadError: If no job ID is returned.
        """
        url = f"{self.base_url}/processes/{process_name}/execution"
        headers = {"Prefer": "respond-async"}

        LOGGER.debug(f"Submitting job to {url}")
        response = self._session.post(url, headers=headers, json=payload)

        if response.status_code >= 400:
            raise GDPHTTPError(
                f"Job submission failed: {response.status_code}",
                status_code=response.status_code,
                response_body=response.text[:500],
            )

        job_id = extract_job_id(response)
        if not job_id:
            raise GDPPayloadError(
                f"No job ID returned. Status={response.status_code}, Body={response.text[:200]}"
            )

        LOGGER.info(f"Submitted {process_name} job: {job_id}")
        return job_id

    # =========================================================================
    # ClimateR Catalog Methods
    # =========================================================================

    def calc_weights_climr(
        self,
        gdf: gpd.GeoDataFrame,
        cat_dict: dict[str, Any],
        shape_crs: int | str,
        shape_poly_idx: str,
        wght_gen_proj: int | str,
        start_date: str,
        end_date: str,
        *,
        use_cache: bool | None = None,
    ) -> pd.DataFrame:
        """Calculate grid-to-polygon intersection weights using ClimateR catalog.

        Args:
            gdf: GeoDataFrame containing user polygons.
            cat_dict: Catalog dictionary from climateR-catalogs parquet file.
            shape_crs: EPSG code or proj string for the feature CRS.
            shape_poly_idx: Column name for polygon identifiers.
            wght_gen_proj: EPSG code for weight generation (equal-area recommended).
            start_date: Start date in YYYY-MM-DD format.
            end_date: End date in YYYY-MM-DD format.
            use_cache: Override instance-level cache setting for this call.

        Returns:
            DataFrame containing the computed weights.
        """
        # Determine if we should use cache
        should_cache = use_cache if use_cache is not None else self.use_cache
        gdf_json = gdf.to_json()

        # Check cache first
        if should_cache and self._cache is not None:
            cached = self._cache.get(
                gdf_json, cat_dict, shape_poly_idx, wght_gen_proj, start_date, end_date
            )
            if cached is not None:
                return cached

        # Build payload
        payload = build_weights_climr_payload(
            cat_dict=cat_dict,
            gdf=gdf,
            shape_crs=shape_crs,
            shape_poly_idx=shape_poly_idx,
            wght_gen_proj=wght_gen_proj,
            start_date=start_date,
            end_date=end_date,
        )

        # Submit and wait
        job_id = self._submit_job(PROCESS_CALC_WEIGHTS_CLIMR, payload)
        poll_until_complete(
            self.base_url,
            job_id,
            timeout=self.timeout,
            poll_interval=self.poll_interval,
            session=self._session,
        )

        # Fetch results
        results = get_job_results(self.base_url, job_id, session=self._session)
        weights = pd.DataFrame.from_dict(results)

        # Drop redundant index column if present
        if "index" in weights.columns:
            weights = weights.drop(columns=["index"])

        # Cache results
        if should_cache and self._cache is not None:
            self._cache.put(
                weights,
                gdf_json,
                cat_dict,
                shape_poly_idx,
                wght_gen_proj,
                start_date,
                end_date,
            )

        return weights

    def calc_agg_climr(
        self,
        gdf: gpd.GeoDataFrame,
        weights: pd.DataFrame,
        cat_dict: dict[str, Any],
        shape_crs: int | str,
        shape_poly_idx: str,
        start_date: str,
        end_date: str,
    ) -> pd.DataFrame:
        """Run area-weighted aggregation using ClimateR catalog.

        Args:
            gdf: GeoDataFrame containing user polygons.
            weights: DataFrame of weights from calc_weights_climr().
            cat_dict: Catalog dictionary from climateR-catalogs parquet file.
            shape_crs: EPSG code or proj string for the feature CRS.
            shape_poly_idx: Column name for polygon identifiers.
            start_date: Start date in YYYY-MM-DD format.
            end_date: End date in YYYY-MM-DD format.

        Returns:
            DataFrame containing aggregated results with columns:
            index, time, units, varname, and polygon value columns.
        """
        # Build payload
        weights_json = weights.to_json()
        payload = build_agg_climr_payload(
            cat_dict=cat_dict,
            weights_json=weights_json,
            gdf=gdf,
            shape_crs=shape_crs,
            shape_poly_idx=shape_poly_idx,
            start_date=start_date,
            end_date=end_date,
        )

        # Submit and wait
        job_id = self._submit_job(PROCESS_CALC_AGG_CLIMR, payload)
        poll_until_complete(
            self.base_url,
            job_id,
            timeout=self.timeout,
            poll_interval=self.poll_interval,
            session=self._session,
        )

        # Fetch results
        results = get_job_results(self.base_url, job_id, session=self._session)

        # Convert to DataFrame with proper ordering
        df = pd.DataFrame.from_dict(results, orient="index")
        df = df.sort_index(key=lambda x: x.astype(int))

        # Reorder columns for consistency
        cols_to_front = ["time", "units", "varname"]
        existing_front = [c for c in cols_to_front if c in df.columns]
        other_cols = [c for c in df.columns if c not in cols_to_front]
        df = df[existing_front + other_cols]

        return df.reset_index(drop=True)

    def calc_weights_batch_climr(
        self,
        gdfs: list[gpd.GeoDataFrame],
        cat_dict: dict[str, Any],
        shape_crs: int | str,
        shape_poly_idx: str,
        wght_gen_proj: int | str,
        start_date: str,
        end_date: str,
        *,
        max_workers: int = 4,
    ) -> list[pd.DataFrame]:
        """Calculate weights for multiple GeoDataFrames in parallel (ClimateR).

        Args:
            gdfs: List of GeoDataFrames to process.
            cat_dict: Catalog dictionary describing remote datasets.
            shape_crs: EPSG code or proj string for the feature CRS.
            shape_poly_idx: Column name for polygon identifiers.
            wght_gen_proj: EPSG code for weight generation.
            start_date: Start date in YYYY-MM-DD format.
            end_date: End date in YYYY-MM-DD format.
            max_workers: Maximum number of parallel workers.

        Returns:
            List of DataFrames, one per input GeoDataFrame (in same order).
        """
        results: list[pd.DataFrame | None] = [None] * len(gdfs)

        def process_gdf(idx: int, gdf: gpd.GeoDataFrame) -> tuple[int, pd.DataFrame]:
            weights = self.calc_weights_climr(
                gdf=gdf,
                cat_dict=cat_dict,
                shape_crs=shape_crs,
                shape_poly_idx=shape_poly_idx,
                wght_gen_proj=wght_gen_proj,
                start_date=start_date,
                end_date=end_date,
            )
            return idx, weights

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(process_gdf, i, gdf): i for i, gdf in enumerate(gdfs)
            }

            for future in as_completed(futures):
                idx, weights = future.result()
                results[idx] = weights
                LOGGER.info(f"Completed weights calculation {idx + 1}/{len(gdfs)}")

        # Type narrowing - all should be DataFrames now
        return [r for r in results if r is not None]

    # =========================================================================
    # NHGF STAC Catalog Methods
    # =========================================================================

    def calc_weights_stac(
        self,
        gdf: gpd.GeoDataFrame,
        collection_id: str,
        variables: list[str],
        shape_crs: int | str,
        shape_poly_idx: str,
        wght_gen_proj: int | str,
        start_date: str,
        end_date: str,
        *,
        use_cache: bool | None = None,
    ) -> pd.DataFrame:
        """Calculate grid-to-polygon intersection weights using NHGF STAC catalog.

        Args:
            gdf: GeoDataFrame containing user polygons.
            collection_id: STAC collection ID (e.g., 'conus404', 'terraclim').
            variables: List of variable names to extract (e.g., ['PWAT', 'T2']).
            shape_crs: EPSG code or proj string for the feature CRS.
            shape_poly_idx: Column name for polygon identifiers.
            wght_gen_proj: EPSG code for weight generation (equal-area recommended).
            start_date: Start date in YYYY-MM-DD format.
            end_date: End date in YYYY-MM-DD format.
            use_cache: Override instance-level cache setting for this call.

        Returns:
            DataFrame containing the computed weights.
        """
        # Determine if we should use cache
        should_cache = use_cache if use_cache is not None else self.use_cache
        gdf_json = gdf.to_json()

        # Build a cache key dict from STAC params
        cache_key_dict = {"collection_id": collection_id, "variables": variables}

        # Check cache first
        if should_cache and self._cache is not None:
            cached = self._cache.get(
                gdf_json,
                cache_key_dict,
                shape_poly_idx,
                wght_gen_proj,
                start_date,
                end_date,
            )
            if cached is not None:
                return cached

        # Build payload
        payload = build_weights_stac_payload(
            collection_id=collection_id,
            variables=variables,
            gdf=gdf,
            shape_crs=shape_crs,
            shape_poly_idx=shape_poly_idx,
            wght_gen_proj=wght_gen_proj,
            start_date=start_date,
            end_date=end_date,
        )

        # Submit and wait
        job_id = self._submit_job(PROCESS_CALC_WEIGHTS_STAC, payload)
        poll_until_complete(
            self.base_url,
            job_id,
            timeout=self.timeout,
            poll_interval=self.poll_interval,
            session=self._session,
        )

        # Fetch results
        results = get_job_results(self.base_url, job_id, session=self._session)
        weights = pd.DataFrame.from_dict(results)

        # Drop redundant index column if present
        if "index" in weights.columns:
            weights = weights.drop(columns=["index"])

        # Cache results
        if should_cache and self._cache is not None:
            self._cache.put(
                weights,
                gdf_json,
                cache_key_dict,
                shape_poly_idx,
                wght_gen_proj,
                start_date,
                end_date,
            )

        return weights

    def calc_agg_stac(
        self,
        gdf: gpd.GeoDataFrame,
        weights: pd.DataFrame,
        collection_id: str,
        variables: list[str],
        shape_crs: int | str,
        shape_poly_idx: str,
        start_date: str,
        end_date: str,
    ) -> pd.DataFrame:
        """Run area-weighted aggregation using NHGF STAC catalog.

        Args:
            gdf: GeoDataFrame containing user polygons.
            weights: DataFrame of weights from calc_weights_stac().
            collection_id: STAC collection ID (e.g., 'conus404', 'terraclim').
            variables: List of variable names to aggregate.
            shape_crs: EPSG code or proj string for the feature CRS.
            shape_poly_idx: Column name for polygon identifiers.
            start_date: Start date in YYYY-MM-DD format.
            end_date: End date in YYYY-MM-DD format.

        Returns:
            DataFrame containing aggregated results with columns:
            index, time, units, varname, and polygon value columns.
        """
        # Build payload
        weights_json = weights.to_json()
        payload = build_agg_stac_payload(
            collection_id=collection_id,
            variables=variables,
            weights_json=weights_json,
            gdf=gdf,
            shape_crs=shape_crs,
            shape_poly_idx=shape_poly_idx,
            start_date=start_date,
            end_date=end_date,
        )

        # Submit and wait
        job_id = self._submit_job(PROCESS_CALC_AGG_STAC, payload)
        poll_until_complete(
            self.base_url,
            job_id,
            timeout=self.timeout,
            poll_interval=self.poll_interval,
            session=self._session,
        )

        # Fetch results
        results = get_job_results(self.base_url, job_id, session=self._session)

        # Convert to DataFrame with proper ordering
        df = pd.DataFrame.from_dict(results, orient="index")
        df = df.sort_index(key=lambda x: x.astype(int))

        # Reorder columns for consistency
        cols_to_front = ["time", "units", "varname"]
        existing_front = [c for c in cols_to_front if c in df.columns]
        other_cols = [c for c in df.columns if c not in cols_to_front]
        df = df[existing_front + other_cols]

        return df.reset_index(drop=True)

    def calc_weights_batch_stac(
        self,
        gdfs: list[gpd.GeoDataFrame],
        collection_id: str,
        variables: list[str],
        shape_crs: int | str,
        shape_poly_idx: str,
        wght_gen_proj: int | str,
        start_date: str,
        end_date: str,
        *,
        max_workers: int = 4,
    ) -> list[pd.DataFrame]:
        """Calculate weights for multiple GeoDataFrames in parallel (STAC).

        Args:
            gdfs: List of GeoDataFrames to process.
            collection_id: STAC collection ID.
            variables: List of variable names.
            shape_crs: EPSG code or proj string for the feature CRS.
            shape_poly_idx: Column name for polygon identifiers.
            wght_gen_proj: EPSG code for weight generation.
            start_date: Start date in YYYY-MM-DD format.
            end_date: End date in YYYY-MM-DD format.
            max_workers: Maximum number of parallel workers.

        Returns:
            List of DataFrames, one per input GeoDataFrame (in same order).
        """
        results: list[pd.DataFrame | None] = [None] * len(gdfs)

        def process_gdf(idx: int, gdf: gpd.GeoDataFrame) -> tuple[int, pd.DataFrame]:
            weights = self.calc_weights_stac(
                gdf=gdf,
                collection_id=collection_id,
                variables=variables,
                shape_crs=shape_crs,
                shape_poly_idx=shape_poly_idx,
                wght_gen_proj=wght_gen_proj,
                start_date=start_date,
                end_date=end_date,
            )
            return idx, weights

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(process_gdf, i, gdf): i for i, gdf in enumerate(gdfs)
            }

            for future in as_completed(futures):
                idx, weights = future.result()
                results[idx] = weights
                LOGGER.info(f"Completed weights calculation {idx + 1}/{len(gdfs)}")

        # Type narrowing - all should be DataFrames now
        return [r for r in results if r is not None]

    # =========================================================================
    # Cache Management
    # =========================================================================

    def clear_cache(self) -> int:
        """Clear the local weights cache.

        Returns:
            Number of cached files removed.
        """
        if self._cache is None:
            return 0
        return self._cache.clear()

    def list_cached_weights(self) -> list[Path]:
        """List all cached weight files.

        Returns:
            List of paths to cached weight files.
        """
        if self._cache is None:
            return []
        return self._cache.list_cached()

    def close(self) -> None:
        """Close the HTTP session."""
        self._session.close()

    def __enter__(self) -> "GDPClient":
        """Context manager entry."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Context manager exit."""
        self.close()
