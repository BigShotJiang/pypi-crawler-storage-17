"""Job polling utilities for async pygeoapi processes."""

from __future__ import annotations

import logging
import time
from typing import Any

import requests
from requests.exceptions import ConnectionError, Timeout

from gdptools_pygeoapi_client.exceptions import (
    GDPHTTPError,
    GDPJobError,
    GDPTimeoutError,
)

LOGGER = logging.getLogger(__name__)

# Retry configuration for transient connection errors
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 1.0  # seconds

# Job status constants (pygeoapi OGC API Processes)
STATUS_ACCEPTED = "accepted"
STATUS_RUNNING = "running"
STATUS_SUCCESSFUL = "successful"
STATUS_FAILED = "failed"
STATUS_DISMISSED = "dismissed"

TERMINAL_STATUSES = {STATUS_SUCCESSFUL, STATUS_FAILED, STATUS_DISMISSED}
ACTIVE_STATUSES = {STATUS_ACCEPTED, STATUS_RUNNING}


def _retry_request(
    func: callable,
    *args: Any,
    max_retries: int = MAX_RETRIES,
    backoff_base: float = RETRY_BACKOFF_BASE,
    **kwargs: Any,
) -> requests.Response:
    """Execute a request function with retry logic for transient errors.

    Uses exponential backoff: 1s, 2s, 4s for retries.

    Args:
        func: The request function to call.
        *args: Positional arguments for the function.
        max_retries: Maximum number of retry attempts.
        backoff_base: Base delay for exponential backoff.
        **kwargs: Keyword arguments for the function.

    Returns:
        The response from the successful request.

    Raises:
        The last exception if all retries fail.
    """
    last_exception = None
    for attempt in range(max_retries + 1):
        try:
            return func(*args, **kwargs)
        except (ConnectionError, Timeout, OSError) as e:
            last_exception = e
            if attempt < max_retries:
                delay = backoff_base * (2**attempt)
                LOGGER.warning(
                    f"Request failed (attempt {attempt + 1}/{max_retries + 1}): {e}. "
                    f"Retrying in {delay:.1f}s..."
                )
                time.sleep(delay)
            else:
                LOGGER.error(f"Request failed after {max_retries + 1} attempts: {e}")
    raise last_exception


def extract_job_id(response: requests.Response) -> str | None:
    """Extract job ID from the Location header of an async response.

    Args:
        response: The HTTP response from job submission.

    Returns:
        The job ID string, or None if not found.
    """
    location = response.headers.get("Location") or response.headers.get("location")
    if not location:
        return None
    # Location header format: .../jobs/{job_id}
    return location.rstrip("/").split("/")[-1]


def get_job_status(
    base_url: str, job_id: str, session: requests.Session | None = None
) -> dict[str, Any]:
    """Fetch the current status document for a job.

    Includes automatic retry logic for transient connection errors.

    Args:
        base_url: The pygeoapi base URL.
        job_id: The job identifier.
        session: Optional requests session for connection pooling.

    Returns:
        The job status document as a dictionary.

    Raises:
        GDPHTTPError: If the request fails after retries.
        ConnectionError: If all retry attempts fail.

    Note:
        The ?f=json parameter is required to get fresh status from some
        pygeoapi deployments that have aggressive caching.
    """
    url = f"{base_url}/jobs/{job_id}?f=json"
    requester = session or requests
    response = _retry_request(requester.get, url)

    if response.status_code >= 400:
        raise GDPHTTPError(
            f"Failed to get job status: {response.status_code}",
            status_code=response.status_code,
            response_body=response.text[:500],
        )

    return response.json()


def get_job_results(
    base_url: str, job_id: str, session: requests.Session | None = None
) -> dict[str, Any]:
    """Fetch the results of a completed job.

    Includes automatic retry logic for transient connection errors.

    Args:
        base_url: The pygeoapi base URL.
        job_id: The job identifier.
        session: Optional requests session for connection pooling.

    Returns:
        The job results as a dictionary.

    Raises:
        GDPHTTPError: If the request fails after retries.
        ConnectionError: If all retry attempts fail.
    """
    url = f"{base_url}/jobs/{job_id}/results?f=json"
    requester = session or requests
    response = _retry_request(requester.get, url)

    if response.status_code >= 400:
        raise GDPHTTPError(
            f"Failed to get job results: {response.status_code}",
            status_code=response.status_code,
            response_body=response.text[:500],
        )

    return response.json()


def _check_results_available(
    base_url: str, job_id: str, session: requests.Session | None = None
) -> bool:
    """Check if job results are available (workaround for status update bug).

    Some pygeoapi deployments have a bug where the job status never updates
    from 'accepted' to 'successful', but results are still available.

    Args:
        base_url: The pygeoapi base URL.
        job_id: The job identifier.
        session: Optional requests session.

    Returns:
        True if results appear to be available, False otherwise.
    """
    try:
        url = f"{base_url}/jobs/{job_id}/results?f=json"
        requester = session or requests
        response = requester.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            # Results are available if we get a non-empty dict/list
            if isinstance(data, dict) and len(data) > 0:
                return True
            if isinstance(data, list) and len(data) > 0:
                return True
    except Exception:  # noqa: BLE001
        LOGGER.debug("Failed to check results availability for job %s", job_id)
    return False


# How often to check for results as a fallback (seconds)
RESULTS_CHECK_INTERVAL = 30.0


def poll_until_complete(
    base_url: str,
    job_id: str,
    timeout: float = 600.0,
    poll_interval: float = 2.0,
    session: requests.Session | None = None,
) -> dict[str, Any]:
    """Poll a job until it reaches a terminal state.

    Args:
        base_url: The pygeoapi base URL.
        job_id: The job identifier.
        timeout: Maximum time to wait in seconds (default: 600s = 10 min).
        poll_interval: Time between polls in seconds (default: 2s).
        session: Optional requests session for connection pooling.

    Returns:
        The final job status document.

    Raises:
        GDPTimeoutError: If the job doesn't complete within the timeout.
        GDPJobError: If the job fails or is dismissed.

    Note:
        Includes a workaround for a pygeoapi bug where job status may not
        update properly. Periodically checks if results are available even
        when status shows 'accepted' or 'running'.
    """
    start_time = time.monotonic()
    last_results_check = 0.0

    while True:
        elapsed = time.monotonic() - start_time
        if elapsed > timeout:
            raise GDPTimeoutError(
                f"Job {job_id} did not complete within {timeout}s",
                job_id=job_id,
                elapsed=elapsed,
            )

        status_doc = get_job_status(base_url, job_id, session=session)
        status = status_doc.get("status", "unknown")

        LOGGER.debug(f"Job {job_id} status: {status} (elapsed: {elapsed:.1f}s)")

        if status == STATUS_SUCCESSFUL:
            return status_doc

        if status == STATUS_FAILED:
            message = status_doc.get("message", "Job failed with no message")
            raise GDPJobError(
                f"Job {job_id} failed: {message}",
                job_id=job_id,
                status=status,
            )

        if status == STATUS_DISMISSED:
            raise GDPJobError(
                f"Job {job_id} was dismissed",
                job_id=job_id,
                status=status,
            )

        if status not in ACTIVE_STATUSES:
            LOGGER.warning(f"Job {job_id} has unexpected status: {status}")

        # Workaround: Periodically check if results are available despite status
        # This handles a bug where status never updates from 'accepted'
        if elapsed - last_results_check >= RESULTS_CHECK_INTERVAL:
            last_results_check = elapsed
            if _check_results_available(base_url, job_id, session):
                LOGGER.info(
                    f"Job {job_id} results available despite status={status}. "
                    "This indicates a server-side status update bug."
                )
                # Return a synthetic status doc indicating completion
                status_doc["status"] = STATUS_SUCCESSFUL
                status_doc["_results_available_workaround"] = True
                return status_doc

        time.sleep(poll_interval)
