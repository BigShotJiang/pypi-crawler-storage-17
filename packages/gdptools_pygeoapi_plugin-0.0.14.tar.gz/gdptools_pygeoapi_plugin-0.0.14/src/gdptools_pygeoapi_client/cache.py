"""Local file caching for computed weights."""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path
from typing import Any

import pandas as pd

LOGGER = logging.getLogger(__name__)

DEFAULT_CACHE_DIR = Path.home() / ".cache" / "gdptools_pygeoapi_client"


def _compute_cache_key(
    gdf_json: str,
    cat_dict: dict[str, Any],
    shape_poly_idx: str,
    wght_gen_proj: int | str,
    start_date: str,
    end_date: str,
) -> str:
    """Compute a deterministic cache key from input parameters.

    Args:
        gdf_json: GeoJSON string of the GeoDataFrame.
        cat_dict: Catalog dictionary.
        shape_poly_idx: Polygon identifier column.
        wght_gen_proj: Weight generation projection.
        start_date: Start date.
        end_date: End date.

    Returns:
        A hex digest string suitable for use as a filename.
    """
    # Create a deterministic string representation of inputs
    key_parts = [
        gdf_json,
        json.dumps(cat_dict, sort_keys=True),
        shape_poly_idx,
        str(wght_gen_proj),
        start_date,
        end_date,
    ]
    key_string = "|".join(key_parts)

    # Use SHA256 for a collision-resistant hash
    return hashlib.sha256(key_string.encode("utf-8")).hexdigest()[:16]


class WeightsCache:
    """File-based cache for computed weights DataFrames."""

    def __init__(self, cache_dir: Path | str | None = None):
        """Initialize the weights cache.

        Args:
            cache_dir: Directory to store cached weights. Defaults to
                       ~/.cache/gdptools_pygeoapi_client/
        """
        if cache_dir is None:
            self.cache_dir = DEFAULT_CACHE_DIR
        else:
            self.cache_dir = Path(cache_dir)

        # Ensure cache directory exists
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        LOGGER.debug(f"Weights cache initialized at {self.cache_dir}")

    def _get_cache_path(self, cache_key: str) -> Path:
        """Get the file path for a cache key."""
        return self.cache_dir / f"weights_{cache_key}.parquet"

    def get(
        self,
        gdf_json: str,
        cat_dict: dict[str, Any],
        shape_poly_idx: str,
        wght_gen_proj: int | str,
        start_date: str,
        end_date: str,
    ) -> pd.DataFrame | None:
        """Retrieve cached weights if available.

        Args:
            gdf_json: GeoJSON string of the GeoDataFrame.
            cat_dict: Catalog dictionary.
            shape_poly_idx: Polygon identifier column.
            wght_gen_proj: Weight generation projection.
            start_date: Start date.
            end_date: End date.

        Returns:
            The cached weights DataFrame, or None if not cached.
        """
        cache_key = _compute_cache_key(
            gdf_json, cat_dict, shape_poly_idx, wght_gen_proj, start_date, end_date
        )
        cache_path = self._get_cache_path(cache_key)

        if cache_path.exists():
            LOGGER.info(f"Cache hit for weights: {cache_key}")
            try:
                return pd.read_parquet(cache_path)
            except Exception as e:
                LOGGER.warning(f"Failed to read cached weights: {e}")
                return None

        LOGGER.debug(f"Cache miss for weights: {cache_key}")
        return None

    def put(
        self,
        weights: pd.DataFrame,
        gdf_json: str,
        cat_dict: dict[str, Any],
        shape_poly_idx: str,
        wght_gen_proj: int | str,
        start_date: str,
        end_date: str,
    ) -> Path:
        """Store weights in the cache.

        Args:
            weights: The weights DataFrame to cache.
            gdf_json: GeoJSON string of the GeoDataFrame.
            cat_dict: Catalog dictionary.
            shape_poly_idx: Polygon identifier column.
            wght_gen_proj: Weight generation projection.
            start_date: Start date.
            end_date: End date.

        Returns:
            The path to the cached file.
        """
        cache_key = _compute_cache_key(
            gdf_json, cat_dict, shape_poly_idx, wght_gen_proj, start_date, end_date
        )
        cache_path = self._get_cache_path(cache_key)

        LOGGER.info(f"Caching weights: {cache_key}")
        weights.to_parquet(cache_path, index=False)

        return cache_path

    def clear(self) -> int:
        """Clear all cached weights.

        Returns:
            Number of cache files removed.
        """
        count = 0
        for cache_file in self.cache_dir.glob("weights_*.parquet"):
            cache_file.unlink()
            count += 1

        LOGGER.info(f"Cleared {count} cached weight files")
        return count

    def list_cached(self) -> list[Path]:
        """List all cached weight files.

        Returns:
            List of paths to cached weight files.
        """
        return list(self.cache_dir.glob("weights_*.parquet"))
