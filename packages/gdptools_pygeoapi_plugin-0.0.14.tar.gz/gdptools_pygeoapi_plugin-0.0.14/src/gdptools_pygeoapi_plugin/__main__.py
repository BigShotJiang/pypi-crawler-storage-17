"""Command-line interface."""

import click


@click.command()
@click.version_option()
def main() -> None:
    """Gdptools Pygeoapi Plugin."""


if __name__ == "__main__":
    main(prog_name="gdptools-pygeoapi-plugin")  # pragma: no cover
