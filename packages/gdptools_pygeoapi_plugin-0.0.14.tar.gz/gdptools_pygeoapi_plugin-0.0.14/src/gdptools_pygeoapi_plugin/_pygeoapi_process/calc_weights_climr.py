"""Calculate weights using ClimateR catalog data."""

import json
import logging
from typing import Any
from typing import Dict
from typing import Tuple

import geopandas as gpd
from gdptools import ClimRCatData
from gdptools import WeightGen
from pygeoapi.process.base import BaseProcessor

from ._validators import ensure_feature_collection
from ._validators import parse_iso_date
from ._validators import parse_json_object
from ._validators import ProcessorException
from ._validators import require_field

LOGGER = logging.getLogger(__name__)

PROCESS_METADATA = {
    "version": "0.1.0",
    "id": "calc_weights_climr",
    "title": "Calculate weights using ClimateR catalog",
    "description": (
        "Generate grid-to-polygon intersection weights for a user supplied "
        "feature collection using ClimateR catalog metadata (OpenDAP)."
    ),
    "jobControlOptions": ["sync-execute", "async-execute"],
    "keywords": ["area-weighted intersections", "gdptools", "opendap", "climater"],
    "links": [
        {
            "type": "text/html",
            "rel": "about",
            "title": "Project documentation",
            "href": "https://gdptools-pygeoapi-plugin.readthedocs.io/en/latest/usage.html#calc-weights-climr-process",
            "hreflang": "en",
        }
    ],
    "inputs": {
        "cat_dict": {
            "title": "Catalog definition",
            "description": (
                "JSON fragment describing one or more remote datasets that "
                "gdptools.ClimRCatData consumes (see example)."
            ),
            "schema": {
                "type": "string",
                "contentMediaType": "application/json",
            },
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "shape_file": {
            "title": "Feature collection",
            "description": "GeoJSON FeatureCollection representing user polygons.",
            "schema": {
                "type": "string",
                "contentMediaType": "application/geo+json",
            },
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "shape_crs": {
            "title": "Feature CRS",
            "description": "EPSG code or proj string describing the feature CRS.",
            "schema": {
                "type": "string",
            },
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "shape_poly_idx": {
            "title": "Feature identifier field",
            "description": "Name of the attribute column that uniquely identifies geometries.",
            "schema": {
                "type": "string",
            },
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "wght_gen_proj": {
            "title": "Weight-generation projection",
            "description": "EPSG code or proj string used for weight calculations (equal-area recommended).",
            "schema": {"type": "string"},
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "start_date": {
            "title": "Start date",
            "description": "Beginning of the extraction period (YYYY-MM-DD).",
            "schema": {"type": "string", "format": "date"},
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "end_date": {
            "title": "End date",
            "description": "End of the extraction period (YYYY-MM-DD).",
            "schema": {"type": "string", "format": "date"},
            "minOccurs": 1,
            "maxOccurs": 1,
        },
    },
    "outputs": {
        "weights": {
            "title": "Weight table",
            "description": "JSON array of weight rows (poly_idx, i, j, weight).",
            "schema": {"type": "object", "contentMediaType": "application/json"},
        }
    },
    "example": {
        "inputs": {
            "cat_dict": (
                '{"aet": {"id": "terraclim", "asset": '
                '"agg_terraclimate_aet_1958_CurrentYear_GLOBE", "URL": '
                '"http://thredds.northwestknowledge.net:8080/thredds/dodsC/agg_terraclimate_aet_1958_CurrentYear_GLOBE.nc", '  # noqa: B950
                '"type": "opendap", "varname": "aet", "variable": "aet", "description": '
                '"water_evaporation_amount", "units": "mm", "model": null, "ensemble": null, '
                '"scenario": "total", "T_name": "time", "duration": "1958-01-01/2021-12-01", '
                '"interval": "1 months", "nT": 768.0, "X_name": "lon", "Y_name": "lat", "X1": '
                '-179.97916666666666, "Xn": 179.97916666666666, "Y1": 89.97916666666667, '
                '"Yn": -89.97916666666664, "resX": 0.041666666666666664, "resY": '
                '0.041666666666666664, "ncols": 8640.0, "nrows": 4320.0, "crs": '
                '"+proj=longlat +a=6378137 +f=0.00335281066474748 +pm=0 +no_defs", '
                '"toptobottom": false, "tiled": ""}, "pet": {"id": "terraclim", "asset": '
                '"agg_terraclimate_pet_1958_CurrentYear_GLOBE", "URL": '
                '"http://thredds.northwestknowledge.net:8080/thredds/dodsC/agg_terraclimate_pet_1958_CurrentYear_GLOBE.nc", '  # noqa: B950
                '"type": "opendap", "varname": "pet", "variable": "pet", "description": '
                '"water_potential_evaporation_amount", "units": "mm", "model": null, '
                '"ensemble": null, "scenario": "total", "T_name": "time", "duration": '
                '"1958-01-01/2021-12-01", "interval": "1 months", "nT": 768.0, "X_name": '
                '"lon", "Y_name": "lat", "X1": -179.97916666666666, "Xn": 179.97916666666666, '
                '"Y1": 89.97916666666667, "Yn": -89.97916666666664, "resX": '
                '0.041666666666666664, "resY": 0.041666666666666664, "ncols": 8640.0, '
                '"nrows": 4320.0, "crs": "+proj=longlat +a=6378137 +f=0.00335281066474748 '
                '+pm=0 +no_defs", "toptobottom": false, "tiled": ""}}'
            ),
            "shape_file": (
                '{"type": "FeatureCollection", "features": [{"id": "0", "type": "Feature", '
                '"properties": {"id": 1, "poly_idx": "1"}, "geometry": {"type": "Polygon", '
                '"coordinates": [[[-70.60141212297273, 41.9262774500321], '
                "[-70.57199544021768, 41.91303994279233], [-70.5867037815952, "
                "41.87626908934851], [-70.61906213262577, 41.889506596588284], "
                "[-70.60141212297273, 41.9262774500321]]]}}]}"
            ),
            "shape_crs": "4326",
            "shape_poly_idx": "poly_idx",
            "wght_gen_proj": "6931",
            "start_date": "1980-01-01",
            "end_date": "1980-12-31",
        }
    },
}


class GDPCalcWeightsClimrProcessor(BaseProcessor):  # type: ignore
    """Generate weights for grid-to-poly aggregation using ClimateR catalog."""

    def __init__(self, processor_def: dict[str, Any]):
        """Initialize Processor.

        Args:
            processor_def (_type_): _description_
        """
        super().__init__(processor_def, PROCESS_METADATA)

    def execute(self, data: Dict[str, Dict[str, Any]]) -> Tuple[str, Dict[str, Any]]:
        """Execute calc_weights_catalog web service."""
        cat_dict = parse_json_object(require_field(data, "cat_dict"), "cat_dict")
        shp_geojson = ensure_feature_collection(
            parse_json_object(require_field(data, "shape_file"), "shape_file"),
            "shape_file",
        )
        shp_crs = str(require_field(data, "shape_crs")).strip()
        shp_poly_idx = str(require_field(data, "shape_poly_idx")).strip()
        wght_gen_proj_raw = str(require_field(data, "wght_gen_proj")).strip()
        start_date = parse_iso_date(require_field(data, "start_date"), "start_date")
        end_date = parse_iso_date(require_field(data, "end_date"), "end_date")
        period = [start_date, end_date]

        if not shp_crs:
            raise ProcessorException("Input 'shape_crs' must be a non-empty string")
        if not shp_poly_idx:
            raise ProcessorException(
                "Input 'shape_poly_idx' must be a non-empty string"
            )
        if not wght_gen_proj_raw:
            raise ProcessorException(
                "Input 'wght_gen_proj' must be a non-empty EPSG code or proj string"
            )

        try:
            wght_gen_proj = int(wght_gen_proj_raw)
        except ValueError:
            wght_gen_proj = wght_gen_proj_raw

        shp_file = gpd.GeoDataFrame.from_features(shp_geojson)
        shp_file.set_crs(shp_crs, inplace=True)
        if shp_poly_idx not in shp_file.columns:
            raise ProcessorException(
                f"Column '{shp_poly_idx}' not found in uploaded feature collection"
            )

        LOGGER.info(f"param_dict: {cat_dict}  type: {type(cat_dict)}\n")
        LOGGER.info(f"shp_file: {shp_file.head()} type: {type(shp_file)}\n")
        LOGGER.info(f"shp_poly_idx: {shp_poly_idx} type: {type(shp_poly_idx)}\n")
        LOGGER.info(f"wght_gen_proj: {wght_gen_proj} type: {type(wght_gen_proj)}\n")

        user_data = ClimRCatData(
            cat_dict=cat_dict,
            f_feature=shp_file,
            id_feature=shp_poly_idx,
            period=period,
        )
        wght_gen = WeightGen(
            user_data=user_data,
            method="serial",
            output_file="",
            weight_gen_crs=wght_gen_proj,
        )

        wghts = wght_gen.calculate_weights(intersections=True)
        # cp = CatParams(**(json.loads(pjson)))
        # cg = CatGrids(**(json.loads(gjson)))
        # wght = calc_weights_catalog2(
        #     params_json=cp,
        #     grid_json=cg,
        #     shp_file=shp_file,
        #     shp_poly_idx=shp_poly_idx,
        #     wght_gen_proj=wght_gen_proj,
        # )
        wghts.reset_index(inplace=True)
        return "application/json", json.loads(wghts.to_json())

    def __repr__(self):  # type: ignore
        """Return representation."""
        return f"<GDPCalcWeightsClimrProcessor> {self.name}"
