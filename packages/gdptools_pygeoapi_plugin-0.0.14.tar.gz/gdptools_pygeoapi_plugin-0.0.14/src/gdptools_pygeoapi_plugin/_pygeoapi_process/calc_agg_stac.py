"""Calculate aggregation using NHGF STAC catalog data."""

import json
import logging
from typing import Any, Dict, Tuple

import geopandas as gpd
import pandas as pd
import pystac
from gdptools import AggGen, NHGFStacData
from pygeoapi.process.base import BaseProcessor

from ._validators import (
    ProcessorException,
    ensure_feature_collection,
    parse_iso_date,
    parse_json_array,
    parse_json_object,
    require_field,
)

LOGGER = logging.getLogger(__name__)

# NHGF STAC catalog URL (served by the same pygeoapi instance)
NHGF_STAC_CATALOG_URL = "https://api.water.usgs.gov/gdp/pygeoapi/stac/stac-collection/"

PROCESS_METADATA = {
    "version": "0.1.0",
    "id": "calc_agg_stac",
    "title": "Run aggregation using NHGF STAC catalog",
    "description": (
        "Apply gdptools aggregation to user polygons using NHGF STAC catalog "
        "metadata and pre-computed weights."
    ),
    "jobControlOptions": ["sync-execute", "async-execute"],
    "keywords": [
        "area-weighted intersections",
        "gdptools",
        "aggregation",
        "stac",
        "nhgf",
    ],
    "links": [
        {
            "type": "text/html",
            "rel": "about",
            "title": "Project documentation",
            "href": "https://gdptools-pygeoapi-plugin.readthedocs.io/en/latest/usage.html#calc-agg-stac-process",
            "hreflang": "en",
        },
        {
            "type": "application/json",
            "rel": "describedby",
            "title": "NHGF STAC Catalog",
            "href": NHGF_STAC_CATALOG_URL,
            "hreflang": "en",
        },
    ],
    "inputs": {
        "collection_id": {
            "title": "STAC Collection ID",
            "description": (
                "The ID of a collection in the NHGF STAC catalog "
                "(e.g., 'conus404', 'terraclim')."
            ),
            "schema": {"type": "string"},
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "variables": {
            "title": "Variable names",
            "description": (
                "JSON array of variable names to extract from the STAC collection "
                '(e.g., \'["PWAT", "T2"]\').'
            ),
            "schema": {
                "type": "string",
                "contentMediaType": "application/json",
            },
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "weights": {
            "title": "Weight table",
            "description": "JSON-exported DataFrame produced by calc_weights_stac.",
            "schema": {
                "type": "string",
                "contentMediaType": "application/json",
            },
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "shape_file": {
            "title": "Feature collection",
            "description": "GeoJSON FeatureCollection for the polygon(s) being aggregated.",
            "schema": {
                "type": "string",
                "contentMediaType": "application/geo+json",
            },
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "shape_crs": {
            "title": "Feature CRS",
            "description": "EPSG code or proj string describing the feature CRS.",
            "schema": {"type": "string"},
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "shape_poly_idx": {
            "title": "Feature identifier field",
            "description": "Name of the column containing the polygon identifier.",
            "schema": {"type": "string"},
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "start_date": {
            "title": "Start date",
            "description": "Beginning of the aggregation window (YYYY-MM-DD).",
            "schema": {"type": "string", "format": "date"},
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "end_date": {
            "title": "End date",
            "description": "End of the aggregation window (YYYY-MM-DD).",
            "schema": {"type": "string", "format": "date"},
            "minOccurs": 1,
            "maxOccurs": 1,
        },
    },
    "outputs": {
        "aggregated_json": {
            "title": "Aggregated result",
            "description": "JSON records (time, varname, units, polygon columns).",
            "schema": {"type": "object", "contentMediaType": "application/json"},
        }
    },
    "example": {
        "inputs": {
            "collection_id": "conus404_daily",
            "variables": '["T2"]',
            "weights": (
                '{"i":{"0":2,"1":1},'
                '"index":{"0":0,"1":1},'
                '"j":{"0":3,"1":3},'
                '"poly_idx":{"0":"1","1":"1"},'
                '"wght":{"0":0.5,"1":0.5}}'
            ),
            "shape_file": (
                '{"type": "FeatureCollection", "features": [{"id": "0", "type": "Feature", '
                '"properties": {"id": 1, "poly_idx": "1"}, "geometry": {"type": "Polygon", '
                '"coordinates": [[[-105.5, 40.0], [-105.0, 40.0], [-105.0, 40.5], '
                "[-105.5, 40.5], [-105.5, 40.0]]]}}]}"
            ),
            "shape_crs": "4326",
            "shape_poly_idx": "poly_idx",
            "start_date": "1999-01-01",
            "end_date": "1999-01-07",
        }
    },
}


def _get_stac_collection(collection_id: str) -> pystac.Collection:
    """Fetch a collection from the NHGF STAC catalog.

    Searches recursively through the catalog tree to find nested collections
    (e.g., 'conus404_daily' is nested under 'conus404').

    Args:
        collection_id: The collection identifier.

    Returns:
        The pystac Collection object.

    Raises:
        ProcessorException: If the collection is not found.
    """
    try:
        catalog = pystac.Catalog.from_file(NHGF_STAC_CATALOG_URL)
    except Exception as e:
        raise ProcessorException(f"Failed to load NHGF STAC catalog: {e}") from e

    # Search recursively for the collection
    def find_collection(parent, target_id, depth=0, max_depth=5):
        """Recursively search for a collection by ID."""
        if depth > max_depth:
            return None
        for child in parent.get_children():
            if child.id == target_id:
                return child
            # Search nested children
            result = find_collection(child, target_id, depth + 1, max_depth)
            if result is not None:
                return result
        return None

    collection = find_collection(catalog, collection_id)
    if collection is not None:
        return collection

    # Collection not found - provide helpful error with available options
    available = [c.id for c in catalog.get_children()]
    raise ProcessorException(
        f"Collection '{collection_id}' not found in NHGF STAC catalog. "
        f"Top-level collections: {available[:10]}... "
        f"(Note: some collections have sub-collections, e.g., 'conus404/conus404_daily')"
    )


class GDPCalcAggStacProcessor(BaseProcessor):  # type: ignore
    """Run area-weighted grid-to-poly aggregation using NHGF STAC catalog."""

    def __init__(self, processor_def: dict[str, Any]):
        """Initialize Processor.

        Args:
            processor_def: Processor definition from pygeoapi config.
        """
        super().__init__(processor_def, PROCESS_METADATA)

    def execute(self, data: Dict[str, Dict[str, Any]]) -> Tuple[str, Dict[str, Any]]:
        """Execute calc_agg_stac web service."""
        collection_id = str(require_field(data, "collection_id")).strip()
        variables_raw = require_field(data, "variables")
        weights_payload = parse_json_object(require_field(data, "weights"), "weights")
        shp_geojson = ensure_feature_collection(
            parse_json_object(require_field(data, "shape_file"), "shape_file"),
            "shape_file",
        )
        shp_crs = str(require_field(data, "shape_crs")).strip()
        shp_poly_idx = str(require_field(data, "shape_poly_idx")).strip()
        start_date = parse_iso_date(require_field(data, "start_date"), "start_date")
        end_date = parse_iso_date(require_field(data, "end_date"), "end_date")
        period = [start_date, end_date]

        # Parse variables list
        variables = parse_json_array(variables_raw, "variables")
        if not variables:
            raise ProcessorException(
                "Input 'variables' must contain at least one variable name"
            )

        if not collection_id:
            raise ProcessorException("Input 'collection_id' must be a non-empty string")
        if not shp_crs:
            raise ProcessorException("Input 'shape_crs' must be a non-empty string")
        if not shp_poly_idx:
            raise ProcessorException(
                "Input 'shape_poly_idx' must be a non-empty string"
            )

        weights = pd.DataFrame.from_dict(weights_payload)
        if weights.empty:
            raise ProcessorException("Input 'weights' produced an empty table")

        shp_file = gpd.GeoDataFrame.from_features(shp_geojson)
        shp_file.set_crs(shp_crs, inplace=True)
        if shp_poly_idx not in shp_file.columns:
            raise ProcessorException(
                f"Column '{shp_poly_idx}' not found in uploaded feature collection"
            )

        LOGGER.info(f"collection_id: {collection_id}")
        LOGGER.info(f"variables: {variables}")
        LOGGER.info(f"weights: {weights.head()} type: {type(weights)}")
        LOGGER.info(f"shp_file: {shp_file.head()} type: {type(shp_file)}")
        LOGGER.info(f"shp_poly_idx: {shp_poly_idx}")
        LOGGER.info(f"start_date: {start_date} type: {type(start_date)}")
        LOGGER.info(f"end_date: {end_date} type: {type(end_date)}")

        # Fetch the STAC collection
        collection = _get_stac_collection(collection_id)
        LOGGER.info(f"Loaded STAC collection: {collection.id}")

        # Create NHGFStacData instance
        user_data = NHGFStacData(
            source_collection=collection,
            source_var=variables,
            target_gdf=shp_file,
            target_id=shp_poly_idx,
            source_time_period=period,
        )

        # Run aggregation
        agg_gen = AggGen(
            user_data=user_data,
            stat_method="masked_mean",
            agg_engine="serial",
            agg_writer="none",
            weights=weights,
        )
        ngdf, nvals = agg_gen.calculate_agg()

        # Build output DataFrame
        for idx, (_key, value) in enumerate(agg_gen.agg_data.items()):
            gdf = ngdf
            # NHGFStacData stores metadata differently than ClimRCatData
            # Access the variable name and units from the data
            varname = _key
            units = getattr(value, "units", "")
            t_coord = value.T_name if hasattr(value, "T_name") else "time"
            time = value.da.coords[t_coord].values

            df_key = pd.DataFrame(data=nvals[_key].values, columns=gdf.index.T.values)

            df_key.insert(0, "units", [units] * df_key.shape[0])
            df_key.insert(0, "varname", [varname] * df_key.shape[0])
            df_key.insert(0, "time", time)

            if idx == 0:
                df = df_key
            else:
                df = pd.concat([df, df_key])

        df.reset_index(inplace=True)
        return "application/json", json.loads(
            df.to_json(date_format="iso", orient="index")
        )

    def __repr__(self) -> str:
        """Return representation."""
        return f"<GDPCalcAggStacProcessor> {self.name}"
