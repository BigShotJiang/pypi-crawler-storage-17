"""GDP pygeoapi process plugins.

This module exports the processor classes for pygeoapi registration.
"""

from gdptools_pygeoapi_plugin._pygeoapi_process.calc_agg_climr import (
    GDPCalcAggClimrProcessor,
)
from gdptools_pygeoapi_plugin._pygeoapi_process.calc_agg_stac import (
    GDPCalcAggStacProcessor,
)
from gdptools_pygeoapi_plugin._pygeoapi_process.calc_weights_climr import (
    GDPCalcWeightsClimrProcessor,
)
from gdptools_pygeoapi_plugin._pygeoapi_process.calc_weights_stac import (
    GDPCalcWeightsStacProcessor,
)

__all__ = [
    "GDPCalcWeightsClimrProcessor",
    "GDPCalcAggClimrProcessor",
    "GDPCalcWeightsStacProcessor",
    "GDPCalcAggStacProcessor",
]
