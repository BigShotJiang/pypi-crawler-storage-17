"""Sample timed processors used for end-to-end smoke tests."""

from __future__ import annotations

import time
from typing import Any
from typing import Callable
from typing import Dict
from typing import Tuple

from pygeoapi.process.base import BaseProcessor

SleepFn = Callable[[int], None]

SYNC_METADATA: Dict[str, Any] = {
    "version": "0.1.0",
    "id": "test_processing",
    "title": "Timed processing function for testing",
    "description": "Simple processing function for timed duration",
    "jobControlOptions": ["sync-execute", "async-execute"],
    "keywords": ["process-testing"],
    "inputs": {
        "process_time": {
            "title": "Processing time in seconds",
            "schema": {"type": "int"},
            "minOccurs": 1,
            "maxOccurs": 1,
        }
    },
    "outputs": {
        "completion_string": {
            "title": "Simple string marking completion",
            "schema": {"type": "object", "contentMediaType": "application/json"},
        }
    },
    "example": {"inputs": {"process_time": "10"}},
}

ASYNC_METADATA: Dict[str, Any] = {
    **SYNC_METADATA,
    "id": "test_processing_async",
    "jobControlOptions": ["async-execute"],
    "keywords": ["process-testing-async-only"],
}


class _BaseTimedProcessor(BaseProcessor):
    """Shared behavior for the timed echo processors."""

    def __init__(
        self,
        processor_def: Dict[str, Any],
        metadata: Dict[str, Any],
        sleep_fn: SleepFn | None = None,
    ) -> None:
        super().__init__(processor_def, metadata)
        self._sleep_fn = sleep_fn or time.sleep

    def execute(self, data: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
        process_time = int(str(data["process_time"]))
        self._sleep_fn(process_time)
        outputs = {"id": "echo", "value": process_time}
        return "application/json", outputs


class GDPTimedProcessTest(_BaseTimedProcessor):  # type: ignore
    """Sync-enabled sample processor relied upon by pygeoapi smoke tests."""

    def __init__(
        self,
        processor_def: Dict[str, Any],
        sleep_fn: SleepFn | None = None,
    ) -> None:
        super().__init__(processor_def, SYNC_METADATA, sleep_fn)

    def __repr__(self) -> str:  # pragma: no cover - tiny helper
        return f"<GDPTimedProcessTest> {self.name}"


class GDPTimedProcessTestAsync(_BaseTimedProcessor):  # type: ignore
    """Async-only variant used for job-control testing."""

    def __init__(
        self,
        processor_def: Dict[str, Any],
        sleep_fn: SleepFn | None = None,
    ) -> None:
        super().__init__(processor_def, ASYNC_METADATA, sleep_fn)

    def __repr__(self) -> str:  # pragma: no cover - tiny helper
        return f"<GDPTimedProcessTestAsync> {self.name}"


__all__ = ["GDPTimedProcessTest", "GDPTimedProcessTestAsync"]
