# GDPTools pygeoapi Processes

This package hosts the pygeoapi process implementations that back the GDPTools
web workflows. Each processor exposes a `PROCESS_METADATA` definition that
pygeoapi reads to self-document the inputs, outputs, and example payloads.
The sections below summarize the intent of each processor and capture the
additional operational context that does not belong in inline code comments.

## `calc_weights_catalog`

Generates the grid-to-polygon weights required before any aggregation can run.
The process constructs a `gdptools.ClimRCatData` object using the submitted
OpenDAP catalog fragment (`cat_dict`) and the caller supplied polygon features.
It then invokes `gdptools.WeightGen` to intersect each polygon against the
remote grid in the requested projection.

### Inputs (calc_weights_catalog)

| Name                      | Purpose                                                                     |
| ------------------------- | --------------------------------------------------------------------------- |
| `cat_dict`                | JSON description of one or more datasets consumable by `ClimRCatData`.      |
| `shape_file`              | GeoJSON `FeatureCollection` that carries the polygons supplied by the user. |
| `shape_crs`               | CRS of the uploaded features. EPSG code or PROJ string.                     |
| `shape_poly_idx`          | Attribute column that uniquely identifies each feature.                     |
| `wght_gen_proj`           | CRS used for the weight calculation step (choose equal-area).               |
| `start_date` / `end_date` | Extraction window applied while initializing `ClimRCatData`.                |

### Output (calc_weights_catalog)

A JSON serialized DataFrame containing one row per polygon/grid cell
intersection with `poly_idx`, `i`, `j`, and `wght` columns. This payload feeds
the `calc_agg_catalog` process.

## `calc_agg_catalog`

Consumes previously generated weights together with a polygon submission to run
a full GDP aggregation through `gdptools.AggGen`. The processor validates the
requested time window and ensures the polygon identifier requested by the user
does exist in the uploaded features before delegating to GDPTools internals.

### Inputs (calc_agg_catalog)

| Name                      | Purpose                                                            |
| ------------------------- | ------------------------------------------------------------------ |
| `cat_dict`                | Same catalog JSON used when weights were generated.                |
| `weights`                 | JSON-exported DataFrame output from `calc_weights_catalog`.        |
| `shape_file`              | GeoJSON `FeatureCollection` with the polygons to aggregate.        |
| `shape_crs`               | CRS of the uploaded features.                                      |
| `shape_poly_idx`          | Attribute column used to join polygons to the precomputed weights. |
| `start_date` / `end_date` | Aggregation window for the desired statistic.                      |

### Output (calc_agg_catalog)

`aggregated_json` — JSON records for each time step containing the aggregated
value alongside the polygon identifiers that participated in the calculation.

## Documentation targets

Both processes link to the Usage page on Read the Docs via the `PROCESS_METADATA`
`links` field. The anchors defined in `docs/usage.md` mirror the section titles
above, so the rendered documentation always lands on the relevant description:

- `https://gdptools-pygeoapi-plugin.readthedocs.io/en/latest/usage.html#calc-weights-catalog-process`
- `https://gdptools-pygeoapi-plugin.readthedocs.io/en/latest/usage.html#calc-agg-catalog-process`

Keep this file updated whenever inputs or behavior change so downstream users
have an authoritative reference directly in the source tree.
