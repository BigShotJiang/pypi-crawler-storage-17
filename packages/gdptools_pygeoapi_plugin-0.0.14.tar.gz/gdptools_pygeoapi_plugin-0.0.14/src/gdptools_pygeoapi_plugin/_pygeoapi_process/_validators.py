"""Helper validation routines for pygeoapi processors."""

from __future__ import annotations

import json
from datetime import datetime
from importlib import import_module
from typing import Any
from typing import Dict

try:  # pragma: no cover - import-time guard for tooling without pygeoapi
    ProcessorException = import_module("pygeoapi.process.base").ProcessorExecuteError
except ModuleNotFoundError:  # pragma: no cover

    class ProcessorException(RuntimeError):
        """Fallback exception when pygeoapi is unavailable."""

        pass


__all__ = [
    "ProcessorException",
    "require_field",
    "parse_json_object",
    "parse_json_array",
    "ensure_feature_collection",
    "parse_iso_date",
]

JsonDict = Dict[str, Any]


def require_field(data: Dict[str, Any], field_name: str) -> Any:
    """Fetch a required input value, raising ProcessorException if missing."""
    try:
        return data[field_name]
    except KeyError as err:  # pragma: no cover - simple guard
        raise ProcessorException(f"Missing required input '{field_name}'") from err


def parse_json_object(value: Any, field_name: str) -> JsonDict:
    """Coerce strings/objects into a JSON dictionary."""
    if isinstance(value, dict):
        return value

    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ProcessorException(
                f"Input '{field_name}' must be valid JSON text"
            ) from exc
        if isinstance(parsed, dict):
            return parsed

    raise ProcessorException(f"Input '{field_name}' must be a JSON object")


def parse_json_array(value: Any, field_name: str) -> list[Any]:
    """Coerce strings/lists into a JSON array."""
    if isinstance(value, list):
        return value

    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ProcessorException(
                f"Input '{field_name}' must be valid JSON text"
            ) from exc
        if isinstance(parsed, list):
            return parsed

    raise ProcessorException(f"Input '{field_name}' must be a JSON array")


def ensure_feature_collection(geojson: JsonDict, field_name: str) -> JsonDict:
    """Ensure a GeoJSON FeatureCollection structure."""
    if geojson.get("type") != "FeatureCollection":
        raise ProcessorException(
            f"Input '{field_name}' must be a GeoJSON FeatureCollection"
        )

    features = geojson.get("features")
    if not isinstance(features, list) or not features:
        raise ProcessorException(
            f"Input '{field_name}' must contain at least one feature"
        )

    return geojson


def parse_iso_date(value: Any, field_name: str) -> str:
    """Return an ISO-8601 date string (YYYY-MM-DD)."""
    value_str = str(value)
    try:
        return datetime.fromisoformat(value_str).date().isoformat()
    except ValueError as exc:
        raise ProcessorException(
            f"Input '{field_name}' must be an ISO date (YYYY-MM-DD)"
        ) from exc
