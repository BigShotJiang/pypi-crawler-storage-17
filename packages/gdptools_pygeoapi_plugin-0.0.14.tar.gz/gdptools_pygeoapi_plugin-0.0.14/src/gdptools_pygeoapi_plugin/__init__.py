"""Top-level package for pygeoapi plugin: Gdptools Pygeoapi Plugin."""

__author__ = "Richard McDonald"
__email__ = "rmcd@usgs.gov"
__version__ = "0.0.14"
