"""Workflows defined in fabricatio-memory."""
