AI_API_URL = "http://localhost:8000/explain-error"
TIMEOUT = 25
MAX_RETRIES = 3
RETRY_DELAY = 4 