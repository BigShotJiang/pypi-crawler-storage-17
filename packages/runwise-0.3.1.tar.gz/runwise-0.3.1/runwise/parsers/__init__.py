"""Parsers for different log formats."""
