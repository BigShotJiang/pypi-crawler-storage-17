qbraid_qir
===========

.. automodule:: qbraid_qir