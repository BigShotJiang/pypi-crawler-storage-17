from mure.cache.core import Cache as Cache
from mure.cache.core import get_storage as get_storage
