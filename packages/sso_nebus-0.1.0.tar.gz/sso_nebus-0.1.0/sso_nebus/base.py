"""Базовый класс для SSO клиентов"""

from typing import Optional, Dict, Any
from urllib.parse import urljoin

import aiohttp
from aiohttp import ClientSession, ClientResponse

from exceptions import (
    APIError,
    AuthenticationError,
    AuthorizationError,
)


class BaseClient:
    """Базовый класс для всех SSO клиентов"""

    def __init__(
        self,
        base_url: str,
        api_version: str = "v1",
        timeout: int = 30,
        session: Optional[ClientSession] = None,
    ):
        """
        Инициализация базового клиента

        Args:
            base_url: Базовый URL API (например, "http://localhost:8000")
            api_version: Версия API (по умолчанию "v1")
            timeout: Таймаут запросов в секундах
            session: Опциональная aiohttp сессия (если не указана, создается новая)
        """
        self.base_url = base_url.rstrip("/")
        self.api_version = api_version
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self._session = session
        self._own_session = session is None

    @property
    def api_base_url(self) -> str:
        """Базовый URL для API endpoints"""
        return urljoin(self.base_url, f"/api/{self.api_version}/")

    @property
    def session(self) -> ClientSession:
        """Получить или создать aiohttp сессию"""
        if self._session is None:
            self._session = aiohttp.ClientSession(timeout=self.timeout)
            self._own_session = True
        elif self._session.closed:
            # Если сессия закрыта, создаем новую
            self._session = aiohttp.ClientSession(timeout=self.timeout)
            self._own_session = True
        return self._session

    async def close(self):
        """Закрыть сессию (если она была создана клиентом)"""
        if self._own_session and self._session and not self._session.closed:
            await self._session.close()

    async def __aenter__(self):
        """Поддержка async context manager"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Закрытие сессии при выходе из context manager"""
        await self.close()

    def _build_url(self, endpoint: str) -> str:
        """Построить полный URL для endpoint"""
        endpoint = endpoint.lstrip("/")
        return urljoin(self.api_base_url, endpoint)

    def _get_headers(self, access_token: Optional[str] = None) -> Dict[str, str]:
        """Получить заголовки для запроса"""
        headers = {"Content-Type": "application/json"}
        if access_token:
            headers["Authorization"] = f"Bearer {access_token}"
        return headers

    async def _handle_response(self, response: ClientResponse) -> Dict[str, Any]:
        """
        Обработать HTTP ответ

        Args:
            response: aiohttp ClientResponse

        Returns:
            Распарсенный JSON ответ

        Raises:
            APIError: При ошибках API
            AuthenticationError: При ошибках аутентификации (401)
            AuthorizationError: При ошибках авторизации (403)
        """
        try:
            data = await response.json()
        except aiohttp.ContentTypeError:
            # Если ответ не JSON, пытаемся получить текст
            text = await response.text()
            data = {"detail": text} if text else {
                "detail": "Неизвестная ошибка"}

        if response.status == 401:
            detail = data.get("detail", "Ошибка аутентификации")
            raise AuthenticationError(detail)

        if response.status == 403:
            detail = data.get("detail", "Ошибка авторизации")
            raise AuthorizationError(detail)

        if not response.ok:
            detail = data.get("detail", f"Ошибка API: {response.status}")
            raise APIError(detail, status_code=response.status)

        return data

    async def _request(
        self,
        method: str,
        endpoint: str,
        access_token: Optional[str] = None,
        json_data: Optional[Dict[str, Any]] = None,
        form_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Выполнить HTTP запрос

        Args:
            method: HTTP метод (GET, POST, etc.)
            endpoint: API endpoint (например, "auth/me")
            access_token: Access token для авторизации (опционально)
            json_data: JSON данные для тела запроса
            form_data: Form data для тела запроса
            params: Query параметры

        Returns:
            Распарсенный JSON ответ
        """
        url = self._build_url(endpoint)
        headers = self._get_headers(access_token)

        # Если form_data, меняем Content-Type
        if form_data:
            headers.pop("Content-Type", None)

        async with self.session.request(
            method=method,
            url=url,
            headers=headers,
            json=json_data,
            data=form_data,
            params=params,
        ) as response:
            return await self._handle_response(response)

    async def get(
        self,
        endpoint: str,
        access_token: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Выполнить GET запрос"""
        return await self._request("GET", endpoint, access_token=access_token, params=params)

    async def post(
        self,
        endpoint: str,
        access_token: Optional[str] = None,
        json_data: Optional[Dict[str, Any]] = None,
        form_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Выполнить POST запрос"""
        return await self._request(
            "POST",
            endpoint,
            access_token=access_token,
            json_data=json_data,
            form_data=form_data,
            params=params,
        )

    async def put(
        self,
        endpoint: str,
        access_token: Optional[str] = None,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Выполнить PUT запрос"""
        return await self._request("PUT", endpoint, access_token=access_token, json_data=json_data, params=params)

    async def delete(
        self,
        endpoint: str,
        access_token: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Выполнить DELETE запрос"""
        return await self._request("DELETE", endpoint, access_token=access_token, params=params)
