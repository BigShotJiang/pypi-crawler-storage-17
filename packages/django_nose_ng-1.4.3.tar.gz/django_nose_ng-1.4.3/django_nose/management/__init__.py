"""django-nose management additions."""
