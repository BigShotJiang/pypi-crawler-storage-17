Actions
#######

Actions are high-level functions that work with a playback.

.. contents::
    :local:

``ytpb.actions.capture``
************************

.. currentmodule:: ytpb.actions.capture
.. automodule:: ytpb.actions.capture

``ytpb.actions.compose``
************************

.. currentmodule:: ytpb.actions.compose
.. automodule:: ytpb.actions.compose

``ytpb.actions.download``
*************************

.. currentmodule:: ytpb.actions.download
.. automodule:: ytpb.actions.download
