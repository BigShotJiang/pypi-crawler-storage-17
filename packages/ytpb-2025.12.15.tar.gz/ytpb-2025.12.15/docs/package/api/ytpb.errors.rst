``ytpb.errors``
###################

.. currentmodule:: ytpb.errors

.. automodule:: ytpb.errors
