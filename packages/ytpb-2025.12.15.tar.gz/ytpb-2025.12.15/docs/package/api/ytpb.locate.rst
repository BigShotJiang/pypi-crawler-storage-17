``ytpb.locate``
###############

.. contents::
   :local:
.. currentmodule:: ytpb.locate

.. automodule:: ytpb.locate
   :ignore-module-all:
