``ytpb.segment``
################

.. contents::
    :local:
.. currentmodule:: ytpb.segment

.. automodule:: ytpb.segment
