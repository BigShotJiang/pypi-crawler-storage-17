.. include:: ../README.rst

.. rubric:: Documentation contents

.. toctree::
   :maxdepth: 2
   :numbered: 3

   why
   quick
   cli
   reference
   package/index

.. toctree::
   :maxdepth: 1

   Questions <questions>
   cookbook
   changelog
   contributing
