# Troubleshooting

## Working with GPG

If you have enabled GPG signing for your commits, you need to ensure that you have the correct private key in your
keychain for the account that the GitHub personal access token was generated from.
