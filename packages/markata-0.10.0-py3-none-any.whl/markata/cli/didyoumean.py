"""
dummy didyoumean page for testing didyoumean suggestions
"""
