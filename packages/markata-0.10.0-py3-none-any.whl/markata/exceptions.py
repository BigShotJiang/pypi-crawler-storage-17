class TooManyPosts(Exception):
    pass


class NoPosts(Exception):
    pass
