"""CLI commands."""

from wldetect.cli.commands import create_lookup, detect, eval, train

__all__ = ["train", "eval", "detect", "create_lookup"]
