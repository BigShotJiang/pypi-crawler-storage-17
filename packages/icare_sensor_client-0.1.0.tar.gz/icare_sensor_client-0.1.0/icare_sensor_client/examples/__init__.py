# Examples for iCare Sensor Client
