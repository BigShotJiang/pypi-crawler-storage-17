"""
Basic usage example for iCare Sensor Client.

This example demonstrates:
- Creating a client instance
- Connecting to the sensor agent
- Checking sensor health
- Sending alerts
- Sending coordinates
- Error handling
"""

from icare_sensor_client import (
    SensorClient,
    SensorClientError,
    SensorNotInitializedError,
    ConnectionError
)


def main():
    """Demonstrate basic client usage with error handling."""
    
    # Configuration
    # Change this to your sensor agent URL
    SENSOR_URL = "http://localhost:8000"
    
    print("=" * 60)
    print("iCare Sensor Client - Basic Usage Example")
    print("=" * 60)
    print()
    
    try:
        # Step 1: Create a client instance
        print(f"1. Connecting to sensor agent at {SENSOR_URL}...")
        client = SensorClient(SENSOR_URL, timeout=10)
        print("   ✓ Client created successfully")
        print()
        
        # Step 2: Get service information
        print("2. Getting service information...")
        info = client.get_info()
        print(f"   ✓ Service: {info.get('service', 'Unknown')}")
        print(f"   ✓ Version: {info.get('version', 'Unknown')}")
        print(f"   ✓ Status: {info.get('status', 'Unknown')}")
        print()
        
        # Step 3: Check sensor health
        print("3. Checking sensor health...")
        health = client.health_check()
        if health.get('ok'):
            print(f"   ✓ Sensor is healthy")
            print(f"   ✓ Sensor ID: {health.get('sensor_id', 'Unknown')}")
        else:
            print(f"   ✗ Sensor health check failed")
        print()
        
        # Step 4: Get sensor status
        print("4. Getting sensor status...")
        status = client.get_status()
        print(f"   ✓ Sensor ID: {status.sensor_id}")
        print(f"   ✓ Stream State: {status.shared_variable} ", end="")
        
        # Interpret stream state
        if status.shared_variable == 0:
            print("(Not streaming)")
        elif status.shared_variable == 1:
            print("(Streaming active)")
        elif status.shared_variable == 2:
            print("(Stream timed out)")
        else:
            print("(Unknown state)")
        
        print(f"   ✓ Reset Scene: {status.reset_scene}")
        print(f"   ✓ Update Available: {status.update_available}")
        print()
        
        # Step 5: Send an alert
        print("5. Sending an alert...")
        alert_response = client.send_alert(
            content="Test alert from example script",
            severity="low",
            source_type="example_script",
            source_id=999
        )
        if alert_response.get('ok'):
            print(f"   ✓ Alert sent successfully")
            print(f"   ✓ Message: {alert_response.get('message', 'No message')}")
        else:
            print(f"   ✗ Alert failed: {alert_response}")
        print()
        
        # Step 6: Send coordinates
        print("6. Sending coordinate data...")
        coords_response = client.send_coordinates(
            patient_coords={"x": 120.5, "y": 180.3, "z": 0.0},
            bed_coords={"x": 50.0, "y": 150.0, "z": 0.0},
            dimension={"width": 500.0, "height": 400.0, "depth": 300.0}
        )
        if coords_response.get('ok'):
            print(f"   ✓ Coordinates sent successfully")
            print(f"   ✓ Message: {coords_response.get('message', 'No message')}")
        else:
            print(f"   ✗ Coordinates failed: {coords_response}")
        print()
        
        # Step 7: Clean up
        print("7. Closing connection...")
        client.close()
        print("   ✓ Connection closed")
        print()
        
        print("=" * 60)
        print("Example completed successfully!")
        print("=" * 60)
        
    except SensorNotInitializedError as e:
        # Handle sensor not initialized error
        print()
        print("ERROR: Sensor is not initialized on the server")
        print(f"Details: {e}")
        print()
        print("Please ensure the sensor is properly initialized before running this example.")
        return 1
        
    except ConnectionError as e:
        # Handle connection errors
        print()
        print(f"ERROR: Unable to connect to sensor agent at {SENSOR_URL}")
        print(f"Details: {e}")
        print()
        print("Please check:")
        print("  - The sensor agent is running")
        print("  - The URL is correct")
        print("  - Network connectivity is available")
        return 1
        
    except SensorClientError as e:
        # Handle other API errors
        print()
        print(f"ERROR: API error occurred")
        print(f"Details: {e}")
        return 1
        
    except Exception as e:
        # Handle unexpected errors
        print()
        print(f"UNEXPECTED ERROR: {type(e).__name__}")
        print(f"Details: {e}")
        return 1
    
    return 0


def context_manager_example():
    """Demonstrate using the client as a context manager."""
    
    print()
    print("=" * 60)
    print("Context Manager Example")
    print("=" * 60)
    print()
    
    SENSOR_URL = "http://localhost:8000"
    
    try:
        # Using 'with' statement ensures automatic cleanup
        with SensorClient(SENSOR_URL) as client:
            print("Client opened (will auto-close when done)")
            
            # Get info
            info = client.get_info()
            print(f"Connected to: {info.get('service', 'Unknown')}")
            
            # Client will be automatically closed when exiting the 'with' block
        
        print("Client automatically closed")
        print()
        
    except Exception as e:
        print(f"Error: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    # Run the main example
    exit_code = main()
    
    # Optionally run the context manager example
    if exit_code == 0:
        exit_code = context_manager_example()
    
    exit(exit_code)
