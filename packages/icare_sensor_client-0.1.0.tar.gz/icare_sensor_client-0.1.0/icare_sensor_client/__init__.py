"""
iCare Sensor Client Package

A Python client library for interacting with the iCare Sensor Communication Agent API.

Example:
    >>> from icare_sensor_client import SensorClient
    >>> client = SensorClient("http://localhost:8000")
    >>> info = client.get_info()
    >>> print(info['service'])
"""

from icare_sensor_client.client import SensorClient, SensorStatus
from icare_sensor_client.exceptions import (
    SensorClientError,
    SensorNotInitializedError,
    ConnectionError
)
from icare_sensor_client.__version__ import __version__

__all__ = [
    'SensorClient',
    'SensorStatus',
    'SensorClientError',
    'SensorNotInitializedError',
    'ConnectionError',
    '__version__',
]
