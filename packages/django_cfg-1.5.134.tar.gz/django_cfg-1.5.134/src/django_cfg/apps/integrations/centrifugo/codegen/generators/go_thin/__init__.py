"""Go thin wrapper generator."""

from .generator import GoThinGenerator

__all__ = ['GoThinGenerator']
