# Example Contract Tests (Stub)

Provider/consumer pact tests live here. Populate once services are defined.
