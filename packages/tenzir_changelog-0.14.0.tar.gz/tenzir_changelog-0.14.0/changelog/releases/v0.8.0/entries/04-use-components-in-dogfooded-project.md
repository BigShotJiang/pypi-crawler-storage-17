---
title: Components in dogfooded project
type: feature
authors:
- mavam
created: 2025-11-10
---

We now use *components* in the dogfooded project to illustrate the feature.

The first two components are `cli` and `python` to differentiate the primary two
usage styles.
