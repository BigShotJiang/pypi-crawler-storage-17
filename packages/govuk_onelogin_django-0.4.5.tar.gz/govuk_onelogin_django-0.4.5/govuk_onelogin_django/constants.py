# Default name used when saving a user record for a new GOV.UK One Login user.
# We need this because GOV.UK One Login will not provide name data without identity verification.
ONE_LOGIN_UNSET_NAME = "one_login_unset"
