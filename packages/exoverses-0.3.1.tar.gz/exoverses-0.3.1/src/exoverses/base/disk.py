class Disk:
    def __init__(self):
        pass
