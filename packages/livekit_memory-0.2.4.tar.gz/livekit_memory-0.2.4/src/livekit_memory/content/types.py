from typing import Literal

DocType = Literal["markdown", "pdf", "text"]
