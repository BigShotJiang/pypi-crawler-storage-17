#import core modules so that they can be imported directly
from __future__ import annotations
from lexsi_sdk.core.xai import XAI

xai = XAI()
