"""
Integration tests for aipartnerupflow

These tests demonstrate real-world usage scenarios with actual database
and executor interactions.
"""

