"""
Utility functions for aipartnerupflow
"""

from aipartnerupflow.core.utils.logger import get_logger

__all__ = [
    "get_logger",
]

