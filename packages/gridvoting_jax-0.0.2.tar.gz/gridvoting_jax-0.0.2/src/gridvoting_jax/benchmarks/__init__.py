"""Benchmarking utilities for gridvoting-jax."""

from .performance import performance

__all__ = ['performance']
