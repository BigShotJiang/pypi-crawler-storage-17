from .settings import *  # noqa

DEBUG = False
