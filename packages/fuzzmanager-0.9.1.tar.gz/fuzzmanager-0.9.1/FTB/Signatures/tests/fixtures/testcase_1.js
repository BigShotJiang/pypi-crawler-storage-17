function test() {
  var a = SIMD.float32x4();
  if (typeof reportCompare === "function")
    reportCompare(true, true);
}
test();
