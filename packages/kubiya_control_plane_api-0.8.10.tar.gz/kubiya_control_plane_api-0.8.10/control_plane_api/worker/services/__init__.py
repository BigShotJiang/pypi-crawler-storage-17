"""Business logic services for worker operations"""
