OuiSPARQL - Backlog
================

Todo or not, that is the question…
