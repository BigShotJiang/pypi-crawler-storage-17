.. include:: ../../README.rst


Table of Contents
-----------------

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Getting Started <getting-started>
   Defining SPARQL Queries <defining-sparql-queries>
   Endpoint Driver Adapters <endpoint-driver-adapters>
   Contributing <contributing>
   API <pydoc/modules>
   Versions <versions>
   Backlog <todo>
