Endpoint Driver Adapters
========================

The currently only builtin SPARQL adapter is `SPARQLWrapper <https://pypi.org/project/SPARQLWrapper>`__.
