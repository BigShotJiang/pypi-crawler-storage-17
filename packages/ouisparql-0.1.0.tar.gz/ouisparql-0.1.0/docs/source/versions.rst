AioSQL - Versions
=================

0.1.1 on 2025-11-18
-------------------

- fork of `aiosql <https://nackjicholson.github.io/aiosql/>`__ and adaptation to SPARQL
