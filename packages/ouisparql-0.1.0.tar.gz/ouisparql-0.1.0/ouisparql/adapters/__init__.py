# standard adapters
from .generic import GenericAdapter
