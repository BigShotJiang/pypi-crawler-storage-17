import pytest
import ouisparql
import utils

from conf_sparql_wrapper import sparql_wrapper
