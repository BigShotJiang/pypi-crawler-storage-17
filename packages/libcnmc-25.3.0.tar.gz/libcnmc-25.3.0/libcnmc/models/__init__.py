from cnmcmodel import CNMCModel

from res_4771 import F1Res4771
from res_4771 import F2Res4771
from res_4771 import F3Res4771
from res_4771 import F4Res4771
from res_4771 import F5Res4771
from res_4771 import F6Res4771
from res_4771 import F7Res4771
from res_4771 import F8Res4771

from res_4131 import F1Res4131
from res_4131 import F2Res4131
from res_4131 import F3Res4131
from res_4131 import F4Res4131
from res_4131 import F5Res4131
from res_4131 import F6Res4131
from res_4131 import F7Res4131
from res_4131 import F8Res4131

from res_4666 import F1Res4666
from res_4666 import F2Res4666
from res_4666 import F3Res4666
from res_4666 import F4Res4666
from res_4666 import F5Res4666
from res_4666 import F6Res4666
from res_4666 import F7Res4666
from res_4666 import F8Res4666