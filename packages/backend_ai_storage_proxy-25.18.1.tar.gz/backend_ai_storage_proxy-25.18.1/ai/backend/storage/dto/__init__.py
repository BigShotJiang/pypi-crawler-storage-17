"""
Storage DTO (Data Transfer Objects) package.
"""
