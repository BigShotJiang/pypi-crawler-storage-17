def c():
  print("This is _c_")