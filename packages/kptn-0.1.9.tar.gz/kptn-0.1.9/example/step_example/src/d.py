def d():
  print("This is _d_")