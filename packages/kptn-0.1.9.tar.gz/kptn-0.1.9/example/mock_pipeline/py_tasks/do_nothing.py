from kptn.util.pipeline_config import PipelineConfig


def do_nothing(pipeline_config: PipelineConfig, item: str) -> list[str]:
    pass
