# Library functions for code generation
