"""
Syunity Core Library
~~~~~~~~~~~~~~~~~~~~

A unified kernel for IoT and Web development.
Designed for Python 3.13 and Paho-MQTT 2.1.0.
"""

__version__ = "0.0.1"