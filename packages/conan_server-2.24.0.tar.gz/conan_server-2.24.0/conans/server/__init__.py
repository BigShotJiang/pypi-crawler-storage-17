from conan.internal import REVISIONS

COMPLEX_SEARCH_CAPABILITY = "complex_search"

SERVER_CAPABILITIES = [COMPLEX_SEARCH_CAPABILITY, REVISIONS]  # Server is always with revisions
