from conan.tools.premake.premake import Premake
from conan.tools.premake.premakedeps import PremakeDeps
from conan.tools.premake.toolchain import PremakeToolchain
