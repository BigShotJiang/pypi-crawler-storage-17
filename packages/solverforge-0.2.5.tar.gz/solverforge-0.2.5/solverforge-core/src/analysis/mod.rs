mod explanation;
mod manager;

pub use explanation::{ConstraintMatch, Indictment, ScoreExplanation};
pub use manager::SolutionManager;
