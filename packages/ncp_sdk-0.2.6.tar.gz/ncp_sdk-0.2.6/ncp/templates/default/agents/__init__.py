"""Agent definitions for {{ project_name }}."""
