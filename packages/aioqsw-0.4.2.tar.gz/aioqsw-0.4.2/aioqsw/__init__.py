"""QNAP QSW library."""
