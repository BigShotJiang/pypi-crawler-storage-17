from importlib.metadata import version

VERSION = version("hhu-python-tasks")
