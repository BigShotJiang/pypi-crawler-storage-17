CREATE TABLE tv_product (
    id UUID PRIMARY KEY,
    data JSONB
);
