Credits to Nicolas Seriot. (See LICENSE file in this folder)

Source: https://github.com/nst/JSONTestSuite/tree/master
