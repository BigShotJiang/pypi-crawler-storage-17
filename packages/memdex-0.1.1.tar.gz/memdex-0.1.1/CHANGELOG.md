# Changelog

## [0.1.1](https://github.com/agent37-com/memdex/compare/memdex-v0.1.0...memdex-v0.1.1) (2025-12-15)


### Bug Fixes

* revert to manifest-based release-please config ([e94c177](https://github.com/agent37-com/memdex/commit/e94c177ecdc2695803b4c5aed0b2f55c35188103))

## [0.1.0](https://github.com/agent37-com/memdex/compare/memdex-v0.0.1...memdex-v0.1.0) (2025-12-15)


### Features

* ignore internal folder ([5dfcdb9](https://github.com/agent37-com/memdex/commit/5dfcdb9d557eb2545a9d44da27e37e2c68c63115))


### Bug Fixes

* force use of github.token to debug auth issue ([0c5670c](https://github.com/agent37-com/memdex/commit/0c5670ca0bc0537e3e64b098ab96c96dd42912de))
* use googleapis/release-please-action to resolve deprecation ([d37310b](https://github.com/agent37-com/memdex/commit/d37310b6f022a12ceffdbb3893dfefa626691753))
