"""memdex package (placeholder)."""


