---
title: Store entry creation dates as Date objects
type: change
authors:
- mavam
- codex
created: 2025-10-21
---

Entry parsing now converts `created` metadata to real dates and emits them for consumers.
