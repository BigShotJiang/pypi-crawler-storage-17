---
title: Streamline release archive layout
type: change
authors:
- mavam
- codex
created: 2025-10-21
---

Release manifests now keep metadata in `manifest.yaml`, store archived entries in `releases/<version>/entries/`, and write release notes to `notes.md` for consistent automation.
