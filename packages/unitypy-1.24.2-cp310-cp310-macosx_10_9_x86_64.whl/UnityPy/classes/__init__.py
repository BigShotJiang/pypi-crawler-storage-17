from .generated import *  # noqa: F403
from .legacy_patch import (
    AudioClip as AudioClip,
)
from .legacy_patch import (
    GameObject as GameObject,
)
from .legacy_patch import (
    Mesh as Mesh,
)
from .legacy_patch import (
    Renderer as Renderer,
)
from .legacy_patch import (
    Shader as Shader,
)
from .legacy_patch import (
    Sprite as Sprite,
)
from .legacy_patch import (
    Texture2D as Texture2D,
)
from .legacy_patch import (
    Texture2DArray as Texture2DArray,
)
from .Object import Object as Object
from .PPtr import PPtr as PPtr
from .UnknownObject import UnknownObject as UnknownObject
