if __name__ == "__main__":
    from UnityPy.cli import main

    main()
