# The runbot (test Odoo) by Mangono

This simple `cli` have only 1 goal, test Odoo the most versatile and Gitlab-CI way.

Your config is directly stored in your `pyproject.tml` and use the [Gitlab CI](https://docs.gitlab.com/ee/ci/variables/predefined_variables.html) env vars.

To see a complete How-to-use guide, go to [this page]().

Here you will only find docs about code, how to contribute, how to test this cli. No high level usage is described here.
