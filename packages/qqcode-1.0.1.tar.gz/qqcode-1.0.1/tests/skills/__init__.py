"""Tests for the skills feature."""
