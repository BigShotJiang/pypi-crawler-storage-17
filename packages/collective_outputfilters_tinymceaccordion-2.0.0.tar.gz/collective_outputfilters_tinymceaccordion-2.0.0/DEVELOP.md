# Develop this package

```
git checkout -b dev main
python3 -m venv ./venv
source venv/bin/activate
pip install mxdev
mxdev -c mx.ini
pip install -r requirements-mxdev.txt

```