.. toctree::
    :maxdepth: 2
    :hidden:

    installation
    basic/index
    user/index
    api/index
    developper/index


