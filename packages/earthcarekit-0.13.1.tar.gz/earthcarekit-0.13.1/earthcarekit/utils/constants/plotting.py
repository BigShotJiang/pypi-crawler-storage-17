from typing import Final

DEFAULT_CMAP: Final[str] = "viridis"
DEFAULT_PROFILE_SHOW_STEPS: bool = True

DEFAULT_COLORBAR_WIDTH: Final[float] = 0.14
