from .rule import Rule

__all__ = ["Rule"]
