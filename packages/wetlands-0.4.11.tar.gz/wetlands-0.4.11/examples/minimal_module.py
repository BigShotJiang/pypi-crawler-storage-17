def sum(x):
    import numpy as np  # type: ignore

    return int(np.sum(x))
