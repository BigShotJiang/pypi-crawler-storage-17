"""Package metadata"""

__version__ = "3.6.0"
__self__ = "dvershinin/lastversion"
