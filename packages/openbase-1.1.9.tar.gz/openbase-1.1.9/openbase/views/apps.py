from django.apps import AppConfig


class ViewsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "openbase.views"