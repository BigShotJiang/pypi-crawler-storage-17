## Modifying Claude Code

Don't change w2.

- `P,{color:"claude"},"🟠")," Welcome to"," ",`
- `aude"},"✻")," Welcome to"," ",wQ.createElement(P,{bold:!0},"Openbase"),"!")`
