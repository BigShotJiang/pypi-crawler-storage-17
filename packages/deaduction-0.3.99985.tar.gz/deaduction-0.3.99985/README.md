# d∃∀duction

## Core team

### Current members
- [Florian Dupeyron](https://github.com/fdmysterious) ;
- [Antoine Leudiere](https://github.com/kryzar) ;
- [Frédéric Le Roux](https://github.com/FredericLeRoux) (BDFL).

### Past members
- [Marguerite Bin](https://github.com/m-bin)

## Contributors
- Jean Christophe Deligny (work on the installation script)
- Camille Lichère (lots of testing, and teaching !)
- Justin Carel (thanks for push_neg_once!)
- Sébastien Julliot (Pyinstaller version)
- Isabelle Dubois (Extensive testing and exercises writing)

## License
This project is licensed under the terms of the GNU General Public License v3.0.
See the [LICENSE.md](LICENSE.md) file for more information.

## Meaning
Along side the reference to the word "deduction", d∃∀duction can also mean :

* d∃∀duction
* ∃xists
* ∀s (a)
* disruptive
* utility
* concatenating
* true
* information
* on
* nuggets.

