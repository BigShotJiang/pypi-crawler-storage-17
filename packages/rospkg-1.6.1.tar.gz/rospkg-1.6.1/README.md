rospkg
-----

Standalone Python library for the ROS package system.

[ROS Packages Users/Developers Guide](http://docs.ros.org/independent/api/rospkg/html/)
