import os

os.environ["AZURE_INFERENCE_ENDPOINT"] = "test"
os.environ["AZURE_INFERENCE_CREDENTIAL"] = "test"
