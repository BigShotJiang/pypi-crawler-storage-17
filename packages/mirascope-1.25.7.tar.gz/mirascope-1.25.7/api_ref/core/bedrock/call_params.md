# mirascope.core.bedrock.call_params

::: mirascope.core.bedrock.call_params
