# mirascope.core.groq.call_params

::: mirascope.core.groq.call_params
