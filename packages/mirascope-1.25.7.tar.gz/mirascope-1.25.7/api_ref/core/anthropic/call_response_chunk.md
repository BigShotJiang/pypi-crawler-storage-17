# mirascope.core.anthropic.call_response_chunk

::: mirascope.core.anthropic.call_response_chunk
