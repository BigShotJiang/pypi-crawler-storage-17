# mirascope.core.openai.call_params

::: mirascope.core.openai.call_params
