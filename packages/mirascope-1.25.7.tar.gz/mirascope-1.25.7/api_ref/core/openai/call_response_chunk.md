# mirascope.core.openai.call_response_chunk

::: mirascope.core.openai.call_response_chunk
