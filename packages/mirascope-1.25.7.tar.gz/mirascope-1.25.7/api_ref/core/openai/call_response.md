# mirascope.core.openai.call_response

::: mirascope.core.openai.call_response
