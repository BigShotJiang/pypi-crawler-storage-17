# mirascope.core.litellm.call_response

::: mirascope.core.litellm.call_response
