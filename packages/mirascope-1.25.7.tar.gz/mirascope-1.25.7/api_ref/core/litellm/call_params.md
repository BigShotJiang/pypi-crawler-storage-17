# mirascope.core.litellm.call_params

::: mirascope.core.litellm.call_params
