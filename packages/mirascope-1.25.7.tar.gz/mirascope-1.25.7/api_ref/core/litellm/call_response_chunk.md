# mirascope.core.litellm.call_response_chunk

::: mirascope.core.litellm.call_response_chunk
