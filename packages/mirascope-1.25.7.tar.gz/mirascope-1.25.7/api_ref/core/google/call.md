# mirascope.core.google.call

::: mirascope.core.google.call
