# mirascope.core.google.call_response

::: mirascope.core.google.call_response
