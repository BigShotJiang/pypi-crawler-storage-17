# mirascope.core.google.call_params

::: mirascope.core.google.call_params
