# mirascope.core.xai.call_response

::: mirascope.core.xai.call_response
