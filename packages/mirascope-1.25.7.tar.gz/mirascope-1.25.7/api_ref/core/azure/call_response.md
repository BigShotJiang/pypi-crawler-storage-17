# mirascope.core.azure.call_response

::: mirascope.core.azure.call_response
