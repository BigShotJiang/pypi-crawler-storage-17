# mirascope.core.base.prompt

::: mirascope.core.base.prompt
