# mirascope.core.base.dynamic_config

::: mirascope.core.base.dynamic_config
