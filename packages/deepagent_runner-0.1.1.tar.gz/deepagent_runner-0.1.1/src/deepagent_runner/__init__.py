"""DeepAgent Runner - A terminal application for running DeepAgent in a workspace."""

__version__ = "0.1.1"

