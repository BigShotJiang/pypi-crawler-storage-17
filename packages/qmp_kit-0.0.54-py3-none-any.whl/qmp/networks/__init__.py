"""
This subpackage provides network structures.
"""
