"""
The qmb package provides tools and algorithms to solve problems related to quantum many-body systems.

For more details, check out the README.md file.
"""

from .version import version, __version__
