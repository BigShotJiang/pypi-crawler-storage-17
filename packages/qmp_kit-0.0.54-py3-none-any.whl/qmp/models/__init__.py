"""
This subpackage contains definitions for models.
"""
