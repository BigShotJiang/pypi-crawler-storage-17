# Extractors (reference)

Enabled by default:

- Detect+Describe: alike, aliked, d2net, deal, delf, disk, r2d2, superpoint, orb, xfeat
- Descriptor-only: sosnet, tfeat
- End-to-end: roma

See the API for class docs and configuration options.
