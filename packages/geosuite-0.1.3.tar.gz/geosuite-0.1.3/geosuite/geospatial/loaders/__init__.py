"""
Data loaders for geospatial sources.
"""

from .demo import create_demo_texas_data

__all__ = ["create_demo_texas_data"]

