# -*- coding: utf-8 -*-
from .warning import warning

__all__ = ["warning"]
