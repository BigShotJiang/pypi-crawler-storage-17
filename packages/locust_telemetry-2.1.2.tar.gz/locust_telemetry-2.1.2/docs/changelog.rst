Changelog
=========

v2.1.1 (2025-12-14)
-------------------

- Update package description
- Update documentation

v2.1.0 (2025-12-14)
-------------------

- Update api.rst

v2.0.2 (2025-12-14)
-------------------

- Updated docs and references in README.md

v2.0.1 (2025-12-14)
-------------------

- Initial release of Locust Telemetry Plugin.
- Master and worker telemetry recorders implemented to collect locust core metrics.
- Contain json telemetry recorder and OpenTelemetry Metrics recorder
- Included docs, example and tests.
