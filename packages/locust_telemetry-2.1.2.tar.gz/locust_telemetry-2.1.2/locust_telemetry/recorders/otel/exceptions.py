class OtelMetricNotRegisteredError(Exception):
    pass


class OtelMetricAlreadyRegisteredError(Exception):
    pass
