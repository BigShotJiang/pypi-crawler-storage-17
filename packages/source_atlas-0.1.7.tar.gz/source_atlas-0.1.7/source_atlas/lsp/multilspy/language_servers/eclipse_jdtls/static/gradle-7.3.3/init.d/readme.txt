You can add .gradle (e.g. test.gradle) init scripts to this directory. Each one is executed at the start of the build.
