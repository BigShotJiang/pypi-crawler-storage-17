[20220322]

H2O92D.f.orig is a source file taken from the SUPCRT92 package without
modification (timestamp: Nov 15, 1991). It is provided here to enable diffs
between it and the H2O92D.f that has been modified for use in CHNOSZ.
