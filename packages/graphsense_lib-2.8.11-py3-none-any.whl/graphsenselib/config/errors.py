class ConfigError(Exception):
    pass
