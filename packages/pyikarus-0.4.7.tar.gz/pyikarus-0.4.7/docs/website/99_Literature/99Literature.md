# Literature

\full_bibliography
