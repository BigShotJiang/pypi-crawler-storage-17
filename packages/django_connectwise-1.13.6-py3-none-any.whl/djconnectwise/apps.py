from django.apps import AppConfig


class DjangoConnectwiseConfig(AppConfig):
    name = 'djconnectwise'
