- Odoo SA \<<info@odoo.com>\>

- Savoir-faire Linux \<<support@savoirfairelinux.com>\>

- Gervais Naoussi \<<gervaisnaoussi@gmail.com>\>

- Maxime Chambreuil \<<mchambreuil@opensourceintegrators.com>\>

- Iván Todorovich \<<ivan.todorovich@gmail.com>\>

- [Tecnativa](https://www.tecnativa.com):

  > - Victor M.M. Torres
  > - Víctor Martínez

- [Guadaltech](https://www.guadaltech.es):

  - Fernando La Chica \<<fernando.lachica@guadaltech.es>\>
- [Heliconia Solutions Pvt. Ltd.](https://www.heliconia.io)
  - Bhavesh Heliconia
