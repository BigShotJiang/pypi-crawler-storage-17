To configure this module, you need to:

1.  Set a valid email address on the company settings.
2.  Go to Knowledge \> Categories.
3.  Create a new page category and set an approver group. Make sure
    users belonging to that group have valid email addresses.
