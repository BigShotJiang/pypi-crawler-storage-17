This module adds a workflow to approve page modifications and show the
approved version by default.
