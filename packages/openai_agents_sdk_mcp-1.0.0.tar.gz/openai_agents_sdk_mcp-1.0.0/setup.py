from setuptools import setup, find_packages

setup(
    name="openai-agents-sdk-mcp",
    packages=find_packages(),
    include_package_data=True,
)
