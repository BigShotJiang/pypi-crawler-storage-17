"""Python evaluator copy (legacy logic copied here for migration).

This directory contains copies of the existing evaluator logic to be
used as an isolated package inside the new architecture. Files are
copies of the original sources and must not be modified here.
"""

__all__ = ["comparison", "execution"]
