class AssignmentLoader:
    """
    Placeholder. Does not affect existing flows.
    """

    pass
