"""Sandbox policy placeholders for the new architecture.

Keep empty/minimal to avoid affecting current behavior.
"""


class SandboxPolicies:
    pass
