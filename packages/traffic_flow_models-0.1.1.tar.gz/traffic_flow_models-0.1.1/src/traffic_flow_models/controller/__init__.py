"""Controller subpackage for traffic_flow_models.

Empty package for consistency with the project layout.
"""

from .alinea import AlineaController

__all__ = ["AlineaController"]
