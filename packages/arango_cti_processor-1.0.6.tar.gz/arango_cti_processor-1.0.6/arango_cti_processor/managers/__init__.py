from .base_manager import RELATION_MANAGERS, STIXRelationManager
# from .cve_attack import CveAttack
from .cwe_capec import CweCapec
from .capec_attack import CapecAttack
from .technique_tactic import TechniqueTactic