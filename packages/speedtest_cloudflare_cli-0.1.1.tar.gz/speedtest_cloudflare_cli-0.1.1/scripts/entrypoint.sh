#!/usr/bin/bash

args_array=("$@")
speedtest-cli "${args_array[@]}"
