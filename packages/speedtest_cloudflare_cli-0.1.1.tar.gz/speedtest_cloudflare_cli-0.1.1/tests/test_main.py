# def test_foo():
#     assert foo("foo") == "foo"
