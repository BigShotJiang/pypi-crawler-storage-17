def add_one(number):
    return number + 1


# sample to trigger workflow
# hopefully changes build idfk
# #v9 test
