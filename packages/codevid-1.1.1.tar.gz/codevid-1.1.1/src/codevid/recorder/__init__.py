"""Screen recording and event capture."""

from codevid.recorder.screen import ScreenRecorder, RecordingConfig

__all__ = ["ScreenRecorder", "RecordingConfig"]
