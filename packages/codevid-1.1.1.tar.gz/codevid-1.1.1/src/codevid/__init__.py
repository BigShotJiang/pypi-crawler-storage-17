"""Codevid - Generate video tutorials from automated tests."""

__version__ = "1.1.1"
