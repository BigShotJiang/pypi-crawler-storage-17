"""Models defined in fabricatio-translate."""
