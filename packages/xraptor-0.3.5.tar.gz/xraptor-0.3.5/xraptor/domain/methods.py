from enum import Enum


class MethodType(Enum):
    POST = "POST"
    GET = "GET"
    SUB = "SUB"
    UNSUB = "UNSUB"
    PUT = "PUT"
