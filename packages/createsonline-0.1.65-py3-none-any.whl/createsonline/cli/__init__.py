﻿# createsonline/cli/__init__.py
from .main import app as cli_app

__all__ = ['cli_app']

