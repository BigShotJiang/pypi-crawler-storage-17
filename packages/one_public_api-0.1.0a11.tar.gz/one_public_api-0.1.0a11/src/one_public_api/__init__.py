from one_public_api.main import app

__all__ = ["app"]
