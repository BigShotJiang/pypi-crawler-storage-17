from enum import Enum, auto


class PlatformType(Enum):
    BASIC = auto()
    ENTERPRISE = auto()
