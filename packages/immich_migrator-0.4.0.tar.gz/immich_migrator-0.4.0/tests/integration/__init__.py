"""Test __init__ for integration tests."""
