# External libraries used in UniCeption

This directory contains external libraries that are used in the UniCeption project. These libraries are not part of the core UniCeption codebase but are required for specific building blocks (such as encoders). The code in this directory is licensed under the same license as the source code from which it was derived, unless otherwise specified.

The open-source BSD-3-Clause License of UniCeption does not apply to these libraries.