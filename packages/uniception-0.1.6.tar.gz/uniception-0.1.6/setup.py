"""Package installation setup."""

from setuptools import setup

setup()
