#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
企业微信webhook消息处理模块

该模块提供了与企业微信webhook相关的功能，包括：
1. 同步和异步消息发送
2. 同步和异步媒体文件上传

支持灵活配置请求参数，并根据需要返回不同格式的结果。
"""
import httpx


def send(
        client: httpx.Client,
        multiple_return_values: bool = False,
        key: str = "",
        **kwargs
):
    """
    同步发送企业微信webhook消息

    @see https://developer.work.weixin.qq.com/document/path/91770

    Args:
        client (httpx.Client): 同步HTTP客户端实例
        multiple_return_values (bool, optional): 是否返回多个值
            - True: 返回元组 (success, response_json, response)
            - False: 仅返回布尔值 success
            默认值为 False
        key (str, optional): 企业微信webhook密钥
        **kwargs: 额外的请求参数，将直接传递给client.request方法
            可覆盖默认的method和url等参数

    Returns:
        Union[Tuple[bool, dict, httpx.Response], bool]:
            - 如果multiple_return_values为True：
              返回三元组 (success, response_json, response)
              - success: 布尔值，表示请求是否成功(errcode为0)
              - response_json: 响应的JSON数据，如果请求失败则返回空字典
              - response: httpx.Response对象
            - 如果multiple_return_values为False：
              仅返回布尔值，表示请求是否成功
    """
    # 设置默认请求方法为POST
    kwargs.setdefault("method", "POST")
    # 设置默认API端点为webhook消息发送接口
    kwargs.setdefault("url", "/cgi-bin/webhook/send")

    # 获取或创建请求参数字典
    params = kwargs.get("params", dict())
    # 添加webhook密钥到请求参数
    params.setdefault("key", key)
    kwargs["params"] = params

    # 发送同步请求
    response = client.request(**kwargs)
    # 解析响应JSON（如果请求成功）
    response_json = response.json() if response.is_success else dict()

    if multiple_return_values:
        # 返回完整结果信息
        return int(response_json.get("errcode", 1)) == 0, response_json, response
    # 仅返回请求是否成功
    return int(response_json.get("errcode", 1)) == 0


async def async_send(
        client: httpx.AsyncClient,
        multiple_return_values: bool = False,
        key: str = "",
        **kwargs
):
    """
    异步发送企业微信webhook消息

    @see https://developer.work.weixin.qq.com/document/path/91770

    Args:
        client (httpx.AsyncClient): 异步HTTP客户端实例
        multiple_return_values (bool, optional): 是否返回多个值
            - True: 返回元组 (success, response_json, response)
            - False: 仅返回布尔值 success
            默认值为 False
        key (str, optional): 企业微信webhook密钥
        **kwargs: 额外的请求参数，将直接传递给client.request方法
            可覆盖默认的method和url等参数

    Returns:
        Union[Tuple[bool, dict, httpx.Response], bool]:
            - 如果multiple_return_values为True：
              返回三元组 (success, response_json, response)
              - success: 布尔值，表示请求是否成功(errcode为0)
              - response_json: 响应的JSON数据，如果请求失败则返回空字典
              - response: httpx.Response对象
            - 如果multiple_return_values为False：
              仅返回布尔值，表示请求是否成功
    """
    # 设置默认请求方法为POST
    kwargs.setdefault("method", "POST")
    # 设置默认API端点为webhook消息发送接口
    kwargs.setdefault("url", "/cgi-bin/webhook/send")

    # 获取或创建请求参数字典
    params = kwargs.get("params", dict())
    # 添加webhook密钥到请求参数
    params.setdefault("key", key)
    kwargs["params"] = params

    # 发送异步请求
    response = await client.request(**kwargs)
    # 解析响应JSON（如果请求成功）
    response_json = response.json() if response.is_success else dict()

    if multiple_return_values:
        # 返回完整结果信息
        return int(response_json.get("errcode", 1)) == 0, response_json, response
    # 仅返回请求是否成功
    return int(response_json.get("errcode", 1)) == 0


def upload_media(
        client: httpx.Client,
        multiple_return_values: bool = False,
        key: str = "",
        file_type: str = "file",
        **kwargs
):
    """
    同步上传媒体文件到企业微信webhook

    @see https://developer.work.weixin.qq.com/document/path/91770#%E6%96%87%E4%BB%B6%E4%B8%8A%E4%BC%A0%E6%8E%A5%E5%8F%A3

    Args:
        client (httpx.Client): 同步HTTP客户端实例
        multiple_return_values (bool, optional): 是否返回多个值
            - True: 返回元组 (media_id, response_json, response)
            - False: 仅返回media_id
            默认值为 False
        key (str, optional): 企业微信webhook密钥
        file_type (str, optional): 媒体文件类型，支持 "file" 或 "voice"
            默认值为 "file"
        **kwargs: 额外的请求参数，将直接传递给client.request方法
            可覆盖默认的method和url等参数

    Returns:
        Union[Tuple[str, dict, httpx.Response], str]:
            - 如果multiple_return_values为True：
              返回三元组 (media_id, response_json, response)
              - media_id: 媒体文件ID，如果请求失败则返回None
              - response_json: 响应的JSON数据，如果请求失败则返回空字典
              - response: httpx.Response对象
            - 如果multiple_return_values为False：
              仅返回media_id
    """
    # 验证并修复文件类型，只允许"file"或"voice"
    file_type = file_type if file_type in ["file", "voice", ] else "file"

    # 设置默认请求方法为POST
    kwargs.setdefault("method", "POST")
    # 设置默认API端点为媒体上传接口
    kwargs.setdefault("url", "/cgi-bin/webhook/upload_media")

    # 获取或创建请求参数字典
    params = kwargs.get("params", dict())
    # 添加webhook密钥到请求参数
    params.setdefault("key", key)
    # 添加文件类型到请求参数
    params.setdefault("type", file_type)
    kwargs["params"] = params

    # 发送同步请求
    response = client.request(**kwargs)
    # 解析响应JSON（如果请求成功）
    response_json = response.json() if response.is_success else dict()
    # 获取媒体文件ID
    media_id = response_json.get("media_id", None)

    if multiple_return_values:
        # 返回完整结果信息
        return media_id, response_json, response
    # 仅返回媒体文件ID
    return media_id


async def async_upload_media(
        client: httpx.AsyncClient,
        multiple_return_values: bool = False,
        key: str = "",
        file_type: str = "file",
        **kwargs
):
    """
    异步上传媒体文件到企业微信webhook

    @see https://developer.work.weixin.qq.com/document/path/91770#%E6%96%87%E4%BB%B6%E4%B8%8A%E4%BC%A0%E6%8E%A5%E5%8F%A3

    Args:
        client (httpx.AsyncClient): 异步HTTP客户端实例
        multiple_return_values (bool, optional): 是否返回多个值
            - True: 返回元组 (media_id, response_json, response)
            - False: 仅返回media_id
            默认值为 False
        key (str, optional): 企业微信webhook密钥
        file_type (str, optional): 媒体文件类型，支持 "file" 或 "voice"
            默认值为 "file"
        **kwargs: 额外的请求参数，将直接传递给client.request方法
            可覆盖默认的method和url等参数

    Returns:
        Union[Tuple[str, dict, httpx.Response], str]:
            - 如果multiple_return_values为True：
              返回三元组 (media_id, response_json, response)
              - media_id: 媒体文件ID，如果请求失败则返回None
              - response_json: 响应的JSON数据，如果请求失败则返回空字典
              - response: httpx.Response对象
            - 如果multiple_return_values为False：
              仅返回media_id
    """
    # 验证并修复文件类型，只允许"file"或"voice"
    file_type = file_type if file_type in ["file", "voice", ] else "file"

    # 设置默认请求方法为POST
    kwargs.setdefault("method", "POST")
    # 设置默认API端点为媒体上传接口
    kwargs.setdefault("url", "/cgi-bin/webhook/upload_media")

    # 获取或创建请求参数字典
    params = kwargs.get("params", dict())
    # 添加webhook密钥到请求参数
    params.setdefault("key", key)
    # 添加文件类型到请求参数
    params.setdefault("type", file_type)
    kwargs["params"] = params

    # 发送异步请求
    response = await client.request(**kwargs)
    # 解析响应JSON（如果请求成功）
    response_json = response.json() if response.is_success else dict()
    # 获取媒体文件ID
    media_id = response_json.get("media_id", None)

    if multiple_return_values:
        # 返回完整结果信息
        return media_id, response_json, response
    # 仅返回媒体文件ID
    return media_id
