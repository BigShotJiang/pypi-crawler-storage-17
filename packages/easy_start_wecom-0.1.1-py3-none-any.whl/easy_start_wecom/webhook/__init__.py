#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
企业微信webhook API客户端模块

该模块提供了与企业微信webhook API交互的客户端功能，
支持同步和异步两种HTTP请求方式，简化webhook消息发送流程。
"""
import httpx


class Api:
    """企业微信webhook API客户端类
    
    该类用于创建和管理企业微信webhook API的HTTP客户端，
    提供同步和异步两种客户端实现，方便调用企业微信webhook相关接口。
    """
    
    def __init__(
            self,
            base_url: str = "https://qyapi.weixin.qq.com",
    ):
        """初始化企业微信webhook API客户端
        
        Args:
            base_url (str, optional): 企业微信API基础URL
                默认值为"https://qyapi.weixin.qq.com"
                如果URL以"/"结尾，会自动移除末尾的斜杠
        """
        # 处理基础URL，确保不以斜杠结尾
        self.base_url = base_url[:-1] if base_url.endswith("/") else base_url

    def client(self, **kwargs):
        """创建并返回同步HTTP客户端
        
        Args:
            **kwargs: 传递给httpx.Client的额外参数
                可覆盖默认配置（base_url, timeout, verify等）
        
        Returns:
            httpx.Client: 配置好的同步HTTP客户端实例
        """
        # 设置默认基础URL
        kwargs.setdefault("base_url", self.base_url)
        # 设置默认超时时间为120秒
        kwargs.setdefault("timeout", 120)
        # 禁用SSL证书验证
        kwargs.setdefault("verify", False)
        return httpx.Client(**kwargs)

    def async_client(self, **kwargs):
        """创建并返回异步HTTP客户端
        
        Args:
            **kwargs: 传递给httpx.AsyncClient的额外参数
                可覆盖默认配置（base_url, timeout, verify等）
        
        Returns:
            httpx.AsyncClient: 配置好的异步HTTP客户端实例
        """
        # 设置默认基础URL
        kwargs.setdefault("base_url", self.base_url)
        # 设置默认超时时间为120秒
        kwargs.setdefault("timeout", 120)
        # 禁用SSL证书验证
        kwargs.setdefault("verify", False)
        return httpx.AsyncClient(**kwargs)