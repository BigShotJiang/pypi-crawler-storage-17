#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
企业微信服务器API客户端模块
该模块提供了与企业微信服务器API交互的功能，支持同步和异步请求方式
"""

import asyncio
from typing import Union

import diskcache
import httpx
import redis


class Api:
    """
    企业微信服务器API客户端类
    用于与企业微信服务器API进行交互，提供获取访问令牌、API域名IP等功能
    """
    
    def __init__(
            self,
            base_url: str = "https://qyapi.weixin.qq.com",
            corpid: str = "",
            corpsecret: str = "",
            cache_config: dict = dict()
    ):
        """
        初始化企业微信服务器API客户端
        
        参数:
            base_url (str): API基础URL，默认值为企业微信官方API地址
            corpid (str): 企业ID
            corpsecret (str): 应用密钥
            cache_config (dict): 缓存配置，用于存储访问令牌
        """
        # 处理URL末尾的斜杠，确保格式统一
        self.base_url = base_url[:-1] if base_url.endswith("/") else base_url
        self.corpid = corpid  # 企业ID
        self.corpsecret = corpsecret  # 应用密钥
        self.access_token = ""  # 访问令牌
        self.cache_config = cache_config if isinstance(cache_config, dict) else dict()
        
        # 设置缓存配置默认值
        self.cache_config.setdefault("key", f"wecom_server_access_token_{self.corpid}")
        self.cache_config.setdefault("expire", 7100)  # 缓存过期时间（秒），比官方7200秒少100秒
        self.cache_config.setdefault("instance", None)  # 缓存实例

    def client(self, **kwargs):
        """
        创建同步HTTP客户端
        
        参数:
            **kwargs: 传递给httpx.Client的额外参数
            
        返回:
            httpx.Client: 配置好的同步HTTP客户端
        """
        kwargs.setdefault("base_url", self.base_url)  # 设置基础URL
        kwargs.setdefault("timeout", 120)  # 设置超时时间为120秒
        kwargs.setdefault("verify", False)  # 不验证SSL证书
        return httpx.Client(**kwargs)

    def async_client(self, **kwargs):
        """
        创建异步HTTP客户端
        
        参数:
            **kwargs: 传递给httpx.AsyncClient的额外参数
            
        返回:
            httpx.AsyncClient: 配置好的异步HTTP客户端
        """
        kwargs.setdefault("base_url", self.base_url)  # 设置基础URL
        kwargs.setdefault("timeout", 120)  # 设置超时时间为120秒
        kwargs.setdefault("verify", False)  # 不验证SSL证书
        return httpx.AsyncClient(**kwargs)

    def gettoken(
            self,
            client: httpx.Client = None,
            multiple_return_values: bool = False,
            **kwargs
    ):
        """
        获取访问令牌

        @see https://developer.work.weixin.qq.com/document/path/91039

        参数:
            client (httpx.Client): HTTP客户端
            multiple_return_values (bool): 是否返回多个值（令牌、响应JSON、响应对象）
            **kwargs: 传递给client.request的额外参数
            
        返回:
            str: 访问令牌（默认）
            tuple: (访问令牌, 响应JSON, 响应对象)（当multiple_return_values=True时）
        """
        kwargs.setdefault("method", "GET")  # 默认使用GET方法
        kwargs.setdefault("url", "/cgi-bin/gettoken")  # 设置获取令牌的API路径
        params = kwargs.get("params", dict())
        params.setdefault("corpid", self.corpid)  # 设置企业ID参数
        params.setdefault("corpsecret", self.corpsecret)  # 设置应用密钥参数
        kwargs["params"] = params
        
        response = client.request(**kwargs)  # 发送请求
        response_json = response.json() if response.is_success else dict()  # 解析响应
        access_token = response_json.get("access_token", None)  # 获取访问令牌
        
        if multiple_return_values:
            return access_token, response_json, response
        return access_token

    async def async_gettoken(
            self,
            client: httpx.AsyncClient = None,
            multiple_return_values: bool = False,
            **kwargs
    ):
        """
        异步获取访问令牌

        @see https://developer.work.weixin.qq.com/document/path/91039

        参数:
            client (httpx.AsyncClient): 异步HTTP客户端
            multiple_return_values (bool): 是否返回多个值（令牌、响应JSON、响应对象）
            **kwargs: 传递给client.request的额外参数
            
        返回:
            str: 访问令牌（默认）
            tuple: (访问令牌, 响应JSON, 响应对象)（当multiple_return_values=True时）
        """
        kwargs.setdefault("method", "GET")  # 默认使用GET方法
        kwargs.setdefault("url", "/cgi-bin/gettoken")  # 设置获取令牌的API路径
        params = kwargs.get("params", dict())
        params.setdefault("corpid", self.corpid)  # 设置企业ID参数
        params.setdefault("corpsecret", self.corpsecret)  # 设置应用密钥参数
        
        response = await client.request(**kwargs)  # 发送异步请求
        response_json = response.json() if response.is_success else dict()  # 解析响应
        access_token = response_json.get("access_token", None)  # 获取访问令牌
        
        if multiple_return_values:
            return access_token, response_json, response
        return access_token

    def get_api_domain_ip(
            self,
            client: httpx.Client = None,
            multiple_return_values: bool = False,
            access_token: str = None,
            **kwargs
    ):
        """
        获取企业微信API域名IP列表

        @see https://developer.work.weixin.qq.com/document/path/92520
        
        参数:
            client (httpx.Client): HTTP客户端
            multiple_return_values (bool): 是否返回多个值（IP列表、响应JSON、响应对象）
            access_token (str): 访问令牌
            **kwargs: 传递给client.request的额外参数
            
        返回:
            list: API域名IP列表（默认）
            tuple: (IP列表, 响应JSON, 响应对象)（当multiple_return_values=True时）
        """
        kwargs.setdefault("method", "GET")  # 默认使用GET方法
        kwargs.setdefault("url", "/cgi-bin/get_api_domain_ip")  # 设置获取API域名IP的路径
        params = kwargs.get("params", dict())
        params.setdefault("access_token", access_token)  # 设置访问令牌参数
        kwargs["params"] = params
        
        response = client.request(**kwargs)  # 发送请求
        response_json = response.json() if response.is_success else dict()  # 解析响应
        ip_list = response_json.get("ip_list", None)  # 获取IP列表
        
        if multiple_return_values:
            return ip_list, response_json, response
        return ip_list

    async def async_get_api_domain_ip(
            self,
            client: httpx.AsyncClient = None,
            multiple_return_values: bool = False,
            access_token: str = None,
            **kwargs
    ):
        """
        异步获取企业微信API域名IP列表

        @see https://developer.work.weixin.qq.com/document/path/92520
        
        参数:
            client (httpx.AsyncClient): 异步HTTP客户端
            multiple_return_values (bool): 是否返回多个值（IP列表、响应JSON、响应对象）
            access_token (str): 访问令牌
            **kwargs: 传递给client.request的额外参数
            
        返回:
            list: API域名IP列表（默认）
            tuple: (IP列表, 响应JSON, 响应对象)（当multiple_return_values=True时）
        """
        kwargs.setdefault("method", "GET")  # 默认使用GET方法
        kwargs.setdefault("url", "/cgi-bin/get_api_domain_ip")  # 设置获取API域名IP的路径
        params = kwargs.get("params", dict())
        params.setdefault("access_token", access_token)  # 设置访问令牌参数
        kwargs["params"] = params

        response = await client.request(**kwargs)  # 发送异步请求
        response_json = response.json() if response.is_success else dict()  # 解析响应
        ip_list = response_json.get("ip_list", None)  # 获取IP列表
        
        if multiple_return_values:
            return ip_list, response_json, response
        return ip_list

    def getcallbackip(
            self,
            client: httpx.Client = None,
            multiple_return_values: bool = False,
            access_token: str = None,
            **kwargs
    ):
        """
        获取企业微信回调IP列表

        @see https://developer.work.weixin.qq.com/document/path/92521
        
        参数:
            client (httpx.Client): HTTP客户端
            multiple_return_values (bool): 是否返回多个值（IP列表、响应JSON、响应对象）
            access_token (str): 访问令牌
            **kwargs: 传递给client.request的额外参数
            
        返回:
            list: 回调IP列表（默认）
            tuple: (IP列表, 响应JSON, 响应对象)（当multiple_return_values=True时）
        """
        kwargs.setdefault("method", "GET")  # 默认使用GET方法
        kwargs.setdefault("url", "/cgi-bin/getcallbackip")  # 设置获取回调IP的路径
        params = kwargs.get("params", dict())
        params.setdefault("access_token", access_token)  # 设置访问令牌参数
        kwargs["params"] = params
        
        response = client.request(**kwargs)  # 发送请求
        response_json = response.json() if response.is_success else dict()  # 解析响应
        ip_list = response_json.get("ip_list", None)  # 获取IP列表
        
        if multiple_return_values:
            return ip_list, response_json, response
        return ip_list

    async def async_getcallbackip(
            self,
            client: httpx.AsyncClient = None,
            multiple_return_values: bool = False,
            access_token: str = None,
            **kwargs
    ):
        """
        异步获取企业微信回调IP列表

        @see https://developer.work.weixin.qq.com/document/path/92521
        
        参数:
            client (httpx.AsyncClient): 异步HTTP客户端
            multiple_return_values (bool): 是否返回多个值（IP列表、响应JSON、响应对象）
            access_token (str): 访问令牌
            **kwargs: 传递给client.request的额外参数
            
        返回:
            list: 回调IP列表（默认）
            tuple: (IP列表, 响应JSON, 响应对象)（当multiple_return_values=True时）
        """
        kwargs.setdefault("method", "GET")  # 默认使用GET方法
        kwargs.setdefault("url", "/cgi-bin/getcallbackip")  # 设置获取回调IP的路径
        params = kwargs.get("params", dict())
        params.setdefault("access_token", access_token)  # 设置访问令牌参数
        kwargs["params"] = params
        
        response = await client.request(**kwargs)  # 发送异步请求
        response_json = response.json() if response.is_success else dict()  # 解析响应
        ip_list = response_json.get("ip_list", None)  # 获取IP列表
        
        if multiple_return_values:
            return ip_list, response_json, response
        return ip_list

    def refresh_token(self, client: httpx.Client = None):
        """
        刷新访问令牌（从缓存获取或重新获取）
        
        参数:
            client (httpx.Client): HTTP客户端
            
        返回:
            str: 有效的访问令牌
        """
        cache_key = self.cache_config.get("key", f"wecom_server_access_token_{self.corpid}")
        cache_inst = self.cache_config.get("instance", None)
        cache_expire = self.cache_config.get("expire", 7100)
        
        # 如果没有缓存实例或缓存实例类型不支持，则直接获取新令牌
        if not isinstance(cache_inst, (diskcache.Cache, redis.Redis, redis.StrictRedis)):
            access_token = self.gettoken(client=client)
        else:
            # 从缓存获取访问令牌
            access_token = cache_inst.get(cache_key, None)
        
        # 验证访问令牌是否有效
        ip_list = self.get_api_domain_ip(client=client, access_token=access_token)
        if not isinstance(ip_list, list) or not len(ip_list):
            # 访问令牌无效，重新获取
            access_token = self.gettoken(client=client)
        
        # 将访问令牌存入缓存
        if isinstance(cache_inst, diskcache.Cache):
            cache_inst.set(cache_key, access_token, expire=cache_expire)
        if isinstance(cache_inst, (redis.Redis, redis.StrictRedis)):
            cache_inst.set(cache_key, access_token, ex=cache_expire)
            
        return access_token

    async def async_refresh_token(self, client: httpx.AsyncClient = None):
        """
        异步刷新访问令牌（从缓存获取或重新获取）
        
        参数:
            client (httpx.AsyncClient): 异步HTTP客户端
            
        返回:
            str: 有效的访问令牌
        """
        cache_key = self.cache_config.get("key", f"wecom_server_access_token_{self.corpid}")
        cache_inst = self.cache_config.get("instance", None)
        cache_expire = self.cache_config.get("expire", 7100)
        
        # 如果没有缓存实例或缓存实例类型不支持，则直接获取新令牌
        if not isinstance(cache_inst, (diskcache.Cache, redis.Redis, redis.StrictRedis)):
            access_token = await self.async_gettoken(client=client)
        else:
            # 从缓存获取访问令牌
            access_token = cache_inst.get(cache_key, None)
        
        # 验证访问令牌是否有效
        ip_list = await self.async_get_api_domain_ip(client=client, access_token=access_token)
        if not isinstance(ip_list, list) or not len(ip_list):
            # 访问令牌无效，重新获取
            access_token = await self.async_gettoken(client=client)
        
        # 将访问令牌存入缓存
        if isinstance(cache_inst, diskcache.Cache):
            cache_inst.set(cache_key, access_token, expire=cache_expire)
        if isinstance(cache_inst, (redis.Redis, redis.StrictRedis)):
            cache_inst.set(cache_key, access_token, ex=cache_expire)
            
        return access_token