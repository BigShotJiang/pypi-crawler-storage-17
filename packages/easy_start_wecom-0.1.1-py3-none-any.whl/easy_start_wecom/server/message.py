#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
企业微信服务器端消息发送模块

该模块提供了与企业微信服务器端消息发送相关的功能，
支持同步和异步两种发送方式，用于向企业微信用户、部门或标签发送消息。
"""
import httpx


def send(
        client: httpx.Client,
        multiple_return_values: bool = True,
        access_token: str = None,
        **kwargs
):
    """
    同步发送企业微信消息

    该函数通过同步HTTP客户端向企业微信API发送消息请求，
    支持灵活配置请求参数，并根据需要返回不同的结果格式。

    @see https://developer.work.weixin.qq.com/document/path/90236

    Args:
        client (httpx.Client): 同步HTTP客户端实例
        multiple_return_values (bool, optional): 是否返回多个值
            - True: 返回元组 (success, response_json, response)
            - False: 仅返回布尔值 success
            默认值为 True
        access_token (str, optional): 企业微信API访问令牌
        **kwargs: 额外的请求参数，将直接传递给client.request方法
            可覆盖默认的method和url等参数

    Returns:
        Union[Tuple[bool, dict, httpx.Response], bool]:
            - 如果multiple_return_values为True：
              返回三元组 (success, response_json, response)
              - success: 布尔值，表示请求是否成功(errcode为0)
              - response_json: 响应的JSON数据，如果请求失败则返回空字典
              - response: httpx.Response对象
            - 如果multiple_return_values为False：
              仅返回布尔值，表示请求是否成功
    """
    # 设置默认请求方法为POST
    kwargs.setdefault("method", "POST")
    # 设置默认API端点为消息发送接口
    kwargs.setdefault("url", "/cgi-bin/message/send")
    
    # 获取或创建请求参数字典
    params = kwargs.get("params", dict())
    # 添加访问令牌到请求参数
    params.setdefault("access_token", access_token)
    kwargs["params"] = params
    
    # 发送同步请求
    response = client.request(**kwargs)
    # 解析响应JSON（如果请求成功）
    response_json = response.json() if response.is_success else dict()
    
    if multiple_return_values:
        # 返回完整结果信息
        return response_json.get("errcode", 1) == 0, response_json, response
    # 仅返回请求是否成功
    return response_json.get("errcode", 1) == 0


async def async_send(
        client: httpx.AsyncClient,
        multiple_return_values: bool = True,
        access_token: str = None,
        **kwargs
):
    """
    异步发送企业微信消息

    @see https://developer.work.weixin.qq.com/document/path/90236

    该函数通过异步HTTP客户端向企业微信API发送消息请求，
    支持灵活配置请求参数，并根据需要返回不同的结果格式。

    Args:
        client (httpx.AsyncClient): 异步HTTP客户端实例
        multiple_return_values (bool, optional): 是否返回多个值
            - True: 返回元组 (success, response_json, response)
            - False: 仅返回布尔值 success
            默认值为 True
        access_token (str, optional): 企业微信API访问令牌
        **kwargs: 额外的请求参数，将直接传递给client.request方法
            可覆盖默认的method和url等参数

    Returns:
        Union[Tuple[bool, dict, httpx.Response], bool]:
            - 如果multiple_return_values为True：
              返回三元组 (success, response_json, response)
              - success: 布尔值，表示请求是否成功(errcode为0)
              - response_json: 响应的JSON数据，如果请求失败则返回空字典
              - response: httpx.Response对象
            - 如果multiple_return_values为False：
              仅返回布尔值，表示请求是否成功
    """
    # 设置默认请求方法为POST
    kwargs.setdefault("method", "POST")
    # 设置默认API端点为消息发送接口
    kwargs.setdefault("url", "/cgi-bin/message/send")
    
    # 获取或创建请求参数字典
    params = kwargs.get("params", dict())
    # 添加访问令牌到请求参数
    params.setdefault("access_token", access_token)
    kwargs["params"] = params
    
    # 发送异步请求
    response = await client.request(**kwargs)
    # 解析响应JSON（如果请求成功）
    response_json = response.json() if response.is_success else dict()
    
    if multiple_return_values:
        # 返回完整结果信息
        return response_json.get("errcode", 1) == 0, response_json, response
    # 仅返回请求是否成功
    return response_json.get("errcode", 1) == 0