#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
企业微信服务器端素材管理模块
该模块提供了与企业微信素材管理相关的API接口，支持同步和异步操作
"""

import httpx


def media_upload(
        client: httpx.Client = None,
        multiple_return_values: bool = False,
        access_token: str = None,
        file_type: str = "file",
        **kwargs
):
    """
    上传临时素材

    @see https://developer.work.weixin.qq.com/document/path/90253
    
    参数:
        client (httpx.Client): HTTP客户端
        multiple_return_values (bool): 是否返回多个值（素材ID、响应JSON、响应对象）
        access_token (str): 访问令牌
        file_type (str): 素材类型，可选值：image(图片)、voice(语音)、video(视频)、file(文件)
        **kwargs: 传递给client.request的额外参数，需包含files参数用于上传文件
        
    返回:
        str: 素材ID（默认）
        tuple: (素材ID, 响应JSON, 响应对象)（当multiple_return_values=True时）
    """
    # 验证素材类型，默认值为file
    file_type = file_type if file_type in ["image", "voice", "video", "file"] else "file"

    kwargs.setdefault("method", "POST")  # 默认使用POST方法
    kwargs.setdefault("url", "/cgi-bin/media/upload")  # 设置上传临时素材的API路径

    params = kwargs.get("params", dict())
    params.setdefault("access_token", access_token)  # 设置访问令牌参数
    params.setdefault("type", file_type)  # 设置素材类型参数
    kwargs["params"] = params

    response = client.request(**kwargs)  # 发送请求
    response_json = response.json() if response.is_success else dict()  # 解析响应
    media_id = response_json.get("media_id", None)  # 获取素材ID

    if multiple_return_values:
        return media_id, response_json, response
    return media_id


async def async_media_upload(
        client: httpx.AsyncClient = None,
        multiple_return_values: bool = False,
        access_token: str = None,
        file_type: str = "file",
        **kwargs
):
    """
    异步上传临时素材
    
    @see https://developer.work.weixin.qq.com/document/path/90253

    参数:
        client (httpx.AsyncClient): 异步HTTP客户端
        multiple_return_values (bool): 是否返回多个值（素材ID、响应JSON、响应对象）
        access_token (str): 访问令牌
        file_type (str): 素材类型，可选值：image(图片)、voice(语音)、video(视频)、file(文件)
        **kwargs: 传递给client.request的额外参数，需包含files参数用于上传文件
        
    返回:
        str: 素材ID（默认）
        tuple: (素材ID, 响应JSON, 响应对象)（当multiple_return_values=True时）
    """
    # 验证素材类型，默认值为file
    file_type = file_type if file_type in ["image", "voice", "video", "file"] else "file"

    kwargs.setdefault("method", "POST")  # 默认使用POST方法
    kwargs.setdefault("url", "/cgi-bin/media/upload")  # 设置上传临时素材的API路径

    params = kwargs.get("params", dict())
    params.setdefault("access_token", access_token)  # 设置访问令牌参数
    params.setdefault("type", file_type)  # 设置素材类型参数
    kwargs["params"] = params

    response = await client.request(**kwargs)  # 发送异步请求
    response_json = response.json() if response.is_success else dict()  # 解析响应
    media_id = response_json.get("media_id", None)  # 获取素材ID

    if multiple_return_values:
        return media_id, response_json, response
    return media_id


def media_uploadimg(
        client: httpx.Client = None,
        multiple_return_values: bool = False,
        access_token: str = None,
        **kwargs
):
    """
    上传图片并返回URL（用于消息中的图片）

    @see https://developer.work.weixin.qq.com/document/path/90256
    
    参数:
        client (httpx.Client): HTTP客户端
        multiple_return_values (bool): 是否返回多个值（图片URL、响应JSON、响应对象）
        access_token (str): 访问令牌
        **kwargs: 传递给client.request的额外参数，需包含files参数用于上传图片
        
    返回:
        str: 图片URL（默认）
        tuple: (图片URL, 响应JSON, 响应对象)（当multiple_return_values=True时）
    """
    kwargs.setdefault("method", "POST")  # 默认使用POST方法
    kwargs.setdefault("url", "/cgi-bin/media/uploadimg")  # 设置上传图片的API路径

    params = kwargs.get("params", dict())
    params.setdefault("access_token", access_token)  # 设置访问令牌参数
    kwargs["params"] = params

    response = client.request(**kwargs)  # 发送请求
    response_json = response.json() if response.is_success else dict()  # 解析响应
    url = response_json.get("url", None)  # 获取图片URL

    if multiple_return_values:
        return url, response_json, response
    return url


async def async_media_uploadimg(
        client: httpx.AsyncClient = None,
        multiple_return_values: bool = False,
        access_token: str = None,
        **kwargs
):
    """
    异步上传图片并返回URL（用于消息中的图片）
    
    @see https://developer.work.weixin.qq.com/document/path/90256

    参数:
        client (httpx.AsyncClient): 异步HTTP客户端
        multiple_return_values (bool): 是否返回多个值（图片URL、响应JSON、响应对象）
        access_token (str): 访问令牌
        **kwargs: 传递给client.request的额外参数，需包含files参数用于上传图片
        
    返回:
        str: 图片URL（默认）
        tuple: (图片URL, 响应JSON, 响应对象)（当multiple_return_values=True时）
    """
    kwargs.setdefault("method", "POST")  # 默认使用POST方法
    kwargs.setdefault("url", "/cgi-bin/media/uploadimg")  # 设置上传图片的API路径

    params = kwargs.get("params", dict())
    params.setdefault("access_token", access_token)  # 设置访问令牌参数
    kwargs["params"] = params

    response = await client.request(**kwargs)  # 发送异步请求
    response_json = response.json() if response.is_success else dict()  # 解析响应
    url = response_json.get("url", None)  # 获取图片URL

    if multiple_return_values:
        return url, response_json, response
    return url
