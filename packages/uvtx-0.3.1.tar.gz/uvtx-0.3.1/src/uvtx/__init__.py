"""uvtx - A Python task runner built for uv."""

__version__ = "0.3.1"
