from .mk import (
    send_whats_msg,
    send_mail,
    send_html_mail,
    send_mail_and_add_your_name,
    generate_otp
    )