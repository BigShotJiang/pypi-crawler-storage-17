"""Initialize the app"""

__version__ = "1.2.2"
__title__ = "Markettracker"
