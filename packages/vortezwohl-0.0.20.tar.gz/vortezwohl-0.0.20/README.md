# *vortezwohl-sdk*

> Useful Python SDKs

## Installation

- With pip

    ```
    pip install -U vortezwohl
    ```

- With uv

    ```
    uv add -U vortezwohl
    ```

- From github

    ```
    pip install -U git+https://github.com/vortezwohl/vortezwohl-sdk.git
    ```
