"""Exceptions for Keepeek SDK."""


class KeepeekError(Exception):
    """Base exception for all Keepeek SDK errors."""


class AuthenticationError(KeepeekError):
    """Raised when authentication fails."""


class AuthorizationError(KeepeekError):
    """Raised when the user doesn't have permission to access a resource."""


class ResourceNotFoundError(KeepeekError):
    """Raised when a requested resource is not found."""


class ValidationError(KeepeekError):
    """Raised when request validation fails."""


class APIError(KeepeekError):
    """Raised when the API returns an error."""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class RateLimitError(KeepeekError):
    """Raised when rate limit is exceeded."""


class APIConnectionError(KeepeekError):
    """Raised when there's a connection error."""
