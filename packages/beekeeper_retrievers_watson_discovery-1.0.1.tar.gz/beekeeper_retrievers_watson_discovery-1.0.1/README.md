# Beekeeper retrievers extension - Watson Discovery

## Installation 

```bash
pip install beekeeper-retrievers-watson-discovery
```
