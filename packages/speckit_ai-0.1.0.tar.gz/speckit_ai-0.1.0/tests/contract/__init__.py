"""Contract tests for speckit - LLM provider interface."""
