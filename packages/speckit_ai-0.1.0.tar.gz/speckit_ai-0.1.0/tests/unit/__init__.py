"""Unit tests for speckit - mocked dependencies."""
