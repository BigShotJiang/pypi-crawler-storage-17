pyterrier_generative
==================================================================================

`pyterrier-generative <https://github.com/Parry-Parry/pyterrier-generative>`__

PyTerrier Integration for Generative Rankers

Getting Started
----------------------------------------------------------------------------------

You can install ``pyterrier-generative`` with pip:

.. code-block:: console
    :caption: Installing ``pyterrier-generative`` with pip

    pip install pyterrier_generative

Basic Usage
----------------------------------------------------------------------------------

TODO

API Documentation
----------------------------------------------------------------------------------

TODO

.. autoclass:: pyterrier_generative.MyAwesomeTransformer
