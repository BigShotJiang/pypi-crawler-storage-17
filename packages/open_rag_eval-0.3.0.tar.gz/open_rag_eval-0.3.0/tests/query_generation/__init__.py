"""Tests for query generation module."""
