# open_rag_eval/utils/constants.py
NO_ANSWER = "NO_ANSWER"
API_ERROR = "API_ERROR"
BERT_SCORE = "bert_score"
ROUGE_SCORE = "rouge_score"
HALLUCINATION_SCORE = "hallucination_score"
CONSISTENCYEVALUATOR = "ConsistencyEvaluator"
CONSISTENCY = "consistency"

# Golden Answer constants
GOLDENANSWEREVALUATOR = "GoldenAnswerEvaluator"
SEMANTIC_SIMILARITY = "semantic_similarity"
FACTUAL_CORRECTNESS = "factual_correctness"
