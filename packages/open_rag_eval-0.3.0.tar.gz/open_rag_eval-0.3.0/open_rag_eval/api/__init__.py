# This package implements a Flask API for the open-rag-eval framework
