See [the contributing guide in the documentation](docs/contribute.md).
