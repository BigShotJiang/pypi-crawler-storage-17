__version__ = "1.1.2"
__all__ = ["get_activity", "generate_activity_md"]

from .github_activity import get_activity, generate_activity_md
