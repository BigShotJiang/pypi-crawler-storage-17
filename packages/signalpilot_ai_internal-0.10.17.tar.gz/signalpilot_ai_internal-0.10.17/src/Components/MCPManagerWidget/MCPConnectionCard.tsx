import * as React from 'react';
import { IMCPServer, IMCPTool } from './types';

interface IMCPConnectionCardProps {
  server: IMCPServer;
  tools: IMCPTool[];
  onConnect: (serverId: string) => Promise<void>;
  onDisconnect: (serverId: string) => Promise<void>;
  onDelete: (serverId: string) => void;
}

export const MCPConnectionCard: React.FC<IMCPConnectionCardProps> = ({
  server,
  tools,
  onConnect,
  onDisconnect,
  onDelete
}) => {
  const [isExpanded, setIsExpanded] = React.useState(false);
  const [isConnecting, setIsConnecting] = React.useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      await onConnect(server.id);
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    setIsConnecting(true);
    try {
      await onDisconnect(server.id);
    } finally {
      setIsConnecting(false);
    }
  };

  const getStatusBadge = () => {
    switch (server.status) {
      case 'connected':
        return (
          <span className="mcp-status-badge mcp-status-connected">
            Connected
          </span>
        );
      case 'connecting':
        return (
          <span className="mcp-status-badge mcp-status-connecting">
            Connecting...
          </span>
        );
      case 'error':
        return <span className="mcp-status-badge mcp-status-error">Error</span>;
      default:
        return (
          <span className="mcp-status-badge mcp-status-disconnected">
            Disconnected
          </span>
        );
    }
  };

  const getTypeBadge = () => {
    const type = server.type || 'command'; // Default to 'command' if not specified
    const typeLabel = type === 'command' ? 'CMD' : type.toUpperCase();
    return <span className="mcp-type-badge">{typeLabel}</span>;
  };

  return (
    <div className="mcp-connection-card">
      <div className="mcp-card-header">
        <div className="mcp-card-title">
          <button
            className="mcp-expand-button"
            onClick={() => setIsExpanded(!isExpanded)}
            aria-label={isExpanded ? 'Collapse' : 'Expand'}
          >
            <span className={`mcp-expand-icon ${isExpanded ? 'expanded' : ''}`}>
              ▶
            </span>
          </button>
          <span className="mcp-server-name">{server.name}</span>
        </div>
        <div className="mcp-card-badges">
          {getTypeBadge()}
          {getStatusBadge()}
        </div>
      </div>

      <div className="mcp-card-info">
        {server.type === 'command' && server.command && (
          <div className="mcp-info-item">
            <span className="mcp-info-label">Command:</span>
            <code className="mcp-info-value">
              {server.command} {server.args?.join(' ')}
            </code>
          </div>
        )}
        {(server.type === 'http' || server.type === 'sse') && server.url && (
          <div className="mcp-info-item">
            <span className="mcp-info-label">URL:</span>
            <code className="mcp-info-value">{server.url}</code>
          </div>
        )}
        {server.status === 'connected' && (
          <div className="mcp-info-item">
            <span className="mcp-info-label">Tools:</span>
            <span className="mcp-info-value">{tools.length} available</span>
          </div>
        )}
        {server.error && (
          <div className="mcp-error-message">Error: {server.error}</div>
        )}
      </div>

      <div className="mcp-card-actions">
        {server.status === 'connected' ? (
          <button
            className="mcp-button mcp-button-secondary"
            onClick={handleDisconnect}
            disabled={isConnecting}
          >
            Disconnect
          </button>
        ) : (
          <button
            className="mcp-button mcp-button-primary"
            onClick={handleConnect}
            disabled={isConnecting || server.status === 'connecting'}
          >
            {isConnecting ? 'Connecting...' : 'Connect'}
          </button>
        )}
        <button
          className="mcp-button mcp-button-danger"
          onClick={() => onDelete(server.id)}
          disabled={server.status === 'connected'}
        >
          Delete
        </button>
      </div>

      {isExpanded && server.status === 'connected' && tools.length > 0 && (
        <div className="mcp-tools-list">
          <h4>Available Tools</h4>
          {tools.map((tool, index) => (
            <div key={index} className="mcp-tool-item">
              <div className="mcp-tool-name">{tool.name}</div>
              {tool.description && (
                <div className="mcp-tool-description">{tool.description}</div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

