import * as React from 'react';
import { ReactWidget } from '@jupyterlab/ui-components';
import { MCPManagerContent } from './MCPManagerContent';

/**
 * A widget for managing MCP server connections
 */
export class MCPManagerWidget extends ReactWidget {
  constructor() {
    super();
    this.id = 'signalpilot-mcp-manager';
    this.title.label = 'MCP Servers';
    this.title.caption = 'Manage MCP Server Connections';
    this.title.closable = true;
    this.addClass('sage-mcp-manager-widget');
  }

  render(): JSX.Element {
    return <MCPManagerContent />;
  }
}

