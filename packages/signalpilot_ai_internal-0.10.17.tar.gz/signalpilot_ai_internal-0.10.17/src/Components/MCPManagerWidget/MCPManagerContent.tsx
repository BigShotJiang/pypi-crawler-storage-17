import * as React from 'react';
import {
  IMCPServer,
  IMCPServerConfig,
  IMCPTool,
  IMCPServerFormData
} from './types';
import { MCPConnectionCard } from './MCPConnectionCard';
import { MCPClientService } from '../../Services/MCPClientService';

interface IMCPManagerContentProps {}

export const MCPManagerContent: React.FC<IMCPManagerContentProps> = () => {
  const [mcpServers, setMcpServers] = React.useState<IMCPServer[]>([]);
  const [serverTools, setServerTools] = React.useState<
    Record<string, IMCPTool[]>
  >({});
  const [configJson, setConfigJson] = React.useState('');
  const [jsonError, setJsonError] = React.useState('');
  const [isAddingServer, setIsAddingServer] = React.useState(false);
  const [loading, setLoading] = React.useState(true);

  const mcpClient = MCPClientService.getInstance();

  // Load servers on mount
  React.useEffect(() => {
    loadServers();
  }, []);

  const loadServers = async () => {
    try {
      setLoading(true);
      const servers = await mcpClient.getServers();
      setMcpServers(servers);

      // Load tools for connected servers
      const toolsMap: Record<string, IMCPTool[]> = {};
      for (const server of servers) {
        if (server.status === 'connected') {
          try {
            const tools = await mcpClient.getTools(server.id);
            toolsMap[server.id] = tools;
          } catch (error) {
            console.error(
              `Error loading tools for server ${server.id}:`,
              error
            );
          }
        }
      }
      setServerTools(toolsMap);
    } catch (error) {
      console.error('Error loading MCP servers:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddServer = async () => {
    try {
      setJsonError('');

      // Parse and validate JSON
      let serverConfig: IMCPServerConfig;
      try {
        serverConfig = JSON.parse(configJson);
      } catch (e) {
        setJsonError('Invalid JSON format');
        return;
      }

      // Validate required fields
      if (!serverConfig.name) {
        setJsonError('Server name is required');
        return;
      }

      // Default to 'command' type if not specified
      const connectionType = serverConfig.type || 'command';
      serverConfig.type = connectionType as any;

      if (connectionType === 'command') {
        if (!serverConfig.command) {
          setJsonError('Command is required for command-based MCP servers');
          return;
        }
      } else if (connectionType === 'http' || connectionType === 'sse') {
        if (!serverConfig.url) {
          setJsonError('URL is required for HTTP/SSE MCP servers');
          return;
        }
      }

      setIsAddingServer(true);

      // Send to backend
      await mcpClient.saveServer(serverConfig);

      // Clear form and reload
      setConfigJson('');
      setJsonError('');
      await loadServers();
    } catch (error) {
      console.error('Error adding MCP server:', error);
      setJsonError(
        error instanceof Error ? error.message : 'Failed to add server'
      );
    } finally {
      setIsAddingServer(false);
    }
  };

  const handleConnect = async (serverId: string) => {
    try {
      console.log(`[MCP Manager] Connecting to server: ${serverId}`);
      
      // Update status to connecting
      setMcpServers(servers =>
        servers.map(s =>
          s.id === serverId ? { ...s, status: 'connecting' as const } : s
        )
      );

      const serverInfo = await mcpClient.connect(serverId);

      console.log(`[MCP Manager] Connected successfully, tools:`, serverInfo.toolCount);

      // Update server status and tools
      setMcpServers(servers =>
        servers.map(s =>
          s.id === serverId
            ? {
                ...s,
                status: 'connected' as const,
                toolCount: serverInfo.toolCount
              }
            : s
        )
      );

      setServerTools(tools => ({
        ...tools,
        [serverId]: serverInfo.tools || []
      }));
    } catch (error) {
      console.error('[MCP Manager] Error connecting to MCP server:', error);
      
      // Extract detailed error message
      const errorMessage = error instanceof Error 
        ? error.message 
        : 'Connection failed';
      
      console.error('[MCP Manager] Full error details:', {
        message: errorMessage,
        error: error
      });
      
      setMcpServers(servers =>
        servers.map(s =>
          s.id === serverId
            ? {
                ...s,
                status: 'error' as const,
                error: errorMessage
              }
            : s
        )
      );
      
      // Show error to user
      alert(`Failed to connect to MCP server:\n\n${errorMessage}\n\nCheck the browser console (F12) for detailed error information.`);
    }
  };

  const handleDisconnect = async (serverId: string) => {
    try {
      await mcpClient.disconnect(serverId);

      // Update server status
      setMcpServers(servers =>
        servers.map(s =>
          s.id === serverId ? { ...s, status: 'disconnected' as const } : s
        )
      );

      // Clear tools
      setServerTools(tools => {
        const newTools = { ...tools };
        delete newTools[serverId];
        return newTools;
      });
    } catch (error) {
      console.error('Error disconnecting from MCP server:', error);
    }
  };

  const handleDelete = async (serverId: string) => {
    if (
      !confirm('Are you sure you want to delete this MCP server configuration?')
    ) {
      return;
    }

    try {
      await mcpClient.deleteServer(serverId);

      // Remove from list
      setMcpServers(servers => servers.filter(s => s.id !== serverId));
      setServerTools(tools => {
        const newTools = { ...tools };
        delete newTools[serverId];
        return newTools;
      });
    } catch (error) {
      console.error('Error deleting MCP server:', error);
      alert(error instanceof Error ? error.message : 'Failed to delete server');
    }
  };

  const exampleConfig = {
    name: 'filesystem',
    type: 'command',
    command: 'npx',
    args: [
      '-y',
      '@modelcontextprotocol/server-filesystem',
      '/path/to/directory'
    ]
  };

  return (
    <div className="mcp-manager-container">
      <div className="mcp-manager-header">
        <h2>MCP Servers</h2>
        <p className="mcp-manager-description">
          Manage Model Context Protocol server connections to extend your
          agent's capabilities.
        </p>
      </div>

      <div className="mcp-config-editor">
        <h3>Add MCP Server</h3>
        <textarea
          className={`mcp-config-textarea ${jsonError ? 'error' : ''}`}
          value={configJson}
          onChange={e => {
            setConfigJson(e.target.value);
            setJsonError('');
          }}
          placeholder={JSON.stringify(exampleConfig, null, 2)}
          rows={8}
        />
        {jsonError && <div className="mcp-error-message">{jsonError}</div>}
        <button
          className="mcp-button mcp-button-primary"
          onClick={handleAddServer}
          disabled={isAddingServer || !configJson.trim()}
        >
          {isAddingServer ? 'Adding...' : 'Add Server'}
        </button>
        <div className="mcp-config-help">
          <details>
            <summary>Configuration Examples</summary>
            <div className="mcp-examples">
              <h4>Command-based (stdio):</h4>
              <pre>
                {JSON.stringify(
                  {
                    name: 'filesystem',
                    type: 'command',
                    command: 'npx',
                    args: [
                      '-y',
                      '@modelcontextprotocol/server-filesystem',
                      '/Users/me/Documents'
                    ]
                  },
                  null,
                  2
                )}
              </pre>

              <h4>HTTP/SSE:</h4>
              <pre>
                {JSON.stringify(
                  {
                    name: 'my-http-server',
                    type: 'http',
                    url: 'http://localhost:8080/sse',
                    token: 'optional-auth-token'
                  },
                  null,
                  2
                )}
              </pre>
            </div>
          </details>
        </div>
      </div>

      <div className="mcp-server-list">
        <h3>Configured Servers</h3>
        {loading ? (
          <div className="mcp-loading">Loading servers...</div>
        ) : mcpServers.length === 0 ? (
          <div className="mcp-empty-state">
            No MCP servers configured. Add one above to get started.
          </div>
        ) : (
          mcpServers.map(server => (
            <MCPConnectionCard
              key={server.id}
              server={server}
              tools={serverTools[server.id] || []}
              onConnect={handleConnect}
              onDisconnect={handleDisconnect}
              onDelete={handleDelete}
            />
          ))
        )}
      </div>
    </div>
  );
};

