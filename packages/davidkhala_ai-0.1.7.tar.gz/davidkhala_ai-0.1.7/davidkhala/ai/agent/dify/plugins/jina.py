from davidkhala.ai.agent.dify.plugins.firecrawl import DataSourceOutput as FirecrawlDataSourceOutput

class DataSourceOutput(FirecrawlDataSourceOutput):
    """so far they are the same"""