from opik import configure
configure()