# davidkhala.ai

- For usage of `azure.ai.agents`, goto https://github.com/davidkhala/azure-utils/tree/main/py
- [openrouter python sdk](https://openrouter.ai/docs/sdks/python) 
