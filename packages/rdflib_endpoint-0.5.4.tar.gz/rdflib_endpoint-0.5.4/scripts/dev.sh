uv run --all-extras uvicorn example.main:app --log-level debug --host localhost --reload
