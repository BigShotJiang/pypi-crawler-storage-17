uv run --all-extras pre-commit run --all --all-files
uv run --all-extras mypy
