__version__ = "2.1.4"
name = "djangoldp_ai_agents"
