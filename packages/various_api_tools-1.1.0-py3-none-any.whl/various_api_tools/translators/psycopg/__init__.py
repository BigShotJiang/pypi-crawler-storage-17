"""Module for concrete translator for psycopg/psycopg2 errors."""
