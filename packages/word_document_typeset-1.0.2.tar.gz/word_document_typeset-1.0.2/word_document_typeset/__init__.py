"""
Word文档文本编辑MCP服务

提供Word文档文本编辑功能的MCP服务器
"""

__version__ = "2.0.0"
__author__ = "Word Document Styling MCP"
__description__ = "Word文档排版MCP服务 - 仅提供Style the Heading工具"