import sys

import cartography.driftdetect.cli

if __name__ == "__main__":
    sys.exit(cartography.driftdetect.cli.main())
