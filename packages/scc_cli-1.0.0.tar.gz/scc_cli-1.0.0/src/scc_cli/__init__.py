"""
SCC - Sandboxed Claude CLI

A command-line tool for safely running Claude Code in Docker sandboxes
with team-specific configurations and worktree management.
"""

__version__ = "1.0.0"
__author__ = "Cagri Cimen"
