# Templates package for SCC
# Contains template files like statusline.sh
