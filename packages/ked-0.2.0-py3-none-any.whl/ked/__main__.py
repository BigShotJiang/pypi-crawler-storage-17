﻿# Also start the app when running as a module via `python -m`.

from . import cli

cli()
