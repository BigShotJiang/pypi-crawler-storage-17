# CobotAR-Protocol
A collection of protobuf messages for the CobotAR-project

Current version: 0.11.4

## Documentation
Find it here: [documentation/README.md](documentation/README.md)

## New version
1. Make changes
2. `make publish bump={patch,minor,major}`
