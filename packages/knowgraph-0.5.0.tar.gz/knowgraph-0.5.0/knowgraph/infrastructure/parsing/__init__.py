"""Parsing infrastructure - Markdown and code analysis."""
