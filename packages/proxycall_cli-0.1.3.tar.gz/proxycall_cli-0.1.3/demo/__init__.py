"""Module de démonstration et CLI ProxyCall."""
