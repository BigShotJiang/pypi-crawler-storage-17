"""Point d'entrée simplifié pour lancer la démo ProxyCall."""
from demo.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
