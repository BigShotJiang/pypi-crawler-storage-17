"""
Compiled evaluator modules.

This directory contains auto-generated compiled evaluators for expression trees.
Modules are created dynamically at runtime by the generator module.
"""

# This package contains dynamically generated Cython modules.
# The modules are generated at runtime based on expression ASTs and compiled in-place.
