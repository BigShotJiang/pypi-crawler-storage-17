#pragma once
#include "tainted_ops/tainted_ops.h"

PyObject*
api_slice_aspect(PyObject* self, PyObject* const* args, Py_ssize_t nargs);
