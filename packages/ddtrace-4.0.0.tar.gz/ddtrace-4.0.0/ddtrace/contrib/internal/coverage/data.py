from copy import copy
import sys


_coverage_data = {}

_original_sys_argv_command = copy(sys.argv)
