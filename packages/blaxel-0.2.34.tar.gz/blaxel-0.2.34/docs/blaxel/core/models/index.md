Module blaxel.core.models
=========================

Functions
---------

`bl_model(model_name, **kwargs)`
: