Module blaxel.core.client.api.workspaces
========================================

Sub-modules
-----------
* blaxel.core.client.api.workspaces.accept_workspace_invitation
* blaxel.core.client.api.workspaces.check_workspace_availability
* blaxel.core.client.api.workspaces.create_workspace
* blaxel.core.client.api.workspaces.decline_workspace_invitation
* blaxel.core.client.api.workspaces.delete_workspace
* blaxel.core.client.api.workspaces.get_workspace
* blaxel.core.client.api.workspaces.invite_workspace_user
* blaxel.core.client.api.workspaces.leave_workspace
* blaxel.core.client.api.workspaces.list_workspace_users
* blaxel.core.client.api.workspaces.list_workspaces
* blaxel.core.client.api.workspaces.remove_workspace_user
* blaxel.core.client.api.workspaces.update_workspace
* blaxel.core.client.api.workspaces.update_workspace_user_role