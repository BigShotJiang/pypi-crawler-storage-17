This module adds security groups fro the Repair App to make it more
configurable and independent of Stock.
