# Package init for autoflatten tests
