//! Utilities for async decompression of data.
pub mod compression;

pub use compression::CompressionCodec;
