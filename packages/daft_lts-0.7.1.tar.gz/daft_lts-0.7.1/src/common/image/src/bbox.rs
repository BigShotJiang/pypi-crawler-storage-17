#[derive(Clone)]
pub struct BBox(pub u32, pub u32, pub u32, pub u32);
