mod counting_writer;
mod iters;
pub mod ops;
use counting_writer::CountingWriter;
pub mod functions;
pub mod series;
