# src/vault_check/__main__.py

from .cli import entry_point


def main():
    entry_point()


if __name__ == "__main__":
    main()
