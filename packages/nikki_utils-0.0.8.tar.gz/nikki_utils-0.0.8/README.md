# nikki-utils
[![PyPI version](https://img.shields.io/pypi/v/nikki-utils)](https://pypi.org/project/nikki-utils/)
![License](https://img.shields.io/pypi/l/nikki-utils?cacheSeconds=0)
![Python versions](https://img.shields.io/pypi/pyversions/nikki-utils)

A set of utils for me to use across multiple Python projects.