*****
Usage
*****

.. _Generate stock quantity issues:

Generate stock quantity issues
==============================

You can define a *Scheduled Action* to generate the `Stock Quantity Issues
<model-stock.quantity.issue>` periodically like the `Generate Stock Quantity
Issues <wizard-stock.quantity.issue.generate>` wizard does.
