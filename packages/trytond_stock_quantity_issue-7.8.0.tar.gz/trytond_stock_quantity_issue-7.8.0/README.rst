###########################
Stock Quantity Issue Module
###########################

The *Stock Quantity Issue Module* helps to solve stock quantity issues.


.. toctree::
   :maxdepth: 2

   usage
   design
   releases
