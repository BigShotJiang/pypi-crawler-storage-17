"""Tests for example policies and utilities."""
