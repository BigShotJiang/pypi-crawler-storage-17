# Rextio

The Rust-Extended I/O for Web.
This project is currently under active development.

Stay tuned at our [GitHub Repository](https://github.com/rextio/rextio)
