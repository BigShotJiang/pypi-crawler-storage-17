print("Did you mean `import django`?")
