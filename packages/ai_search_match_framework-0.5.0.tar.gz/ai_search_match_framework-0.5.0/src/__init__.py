"""AI Search Match Framework - Reusable search, filter, and evaluation workflows."""
__version__ = "0.1.0"
