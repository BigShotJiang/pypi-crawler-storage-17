
``sideshow.db``
===============

.. automodule:: sideshow.db
   :members:
