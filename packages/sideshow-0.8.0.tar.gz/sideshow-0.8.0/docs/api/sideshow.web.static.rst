
``sideshow.web.static``
=======================

.. automodule:: sideshow.web.static
   :members:
