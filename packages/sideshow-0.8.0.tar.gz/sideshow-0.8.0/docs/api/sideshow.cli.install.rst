
``sideshow.cli.install``
========================

.. automodule:: sideshow.cli.install
   :members:
