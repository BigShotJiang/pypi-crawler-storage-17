
``sideshow.orders``
===================

.. automodule:: sideshow.orders
   :members:
