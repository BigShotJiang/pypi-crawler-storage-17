
``sideshow.enum``
=================

.. automodule:: sideshow.enum
   :members:
