
``sideshow.web.views.customers``
================================

.. automodule:: sideshow.web.views.customers
   :members:
