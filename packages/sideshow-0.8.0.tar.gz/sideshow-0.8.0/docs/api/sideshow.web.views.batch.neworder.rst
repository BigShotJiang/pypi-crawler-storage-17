
``sideshow.web.views.batch.neworder``
=====================================

.. automodule:: sideshow.web.views.batch.neworder
   :members:
