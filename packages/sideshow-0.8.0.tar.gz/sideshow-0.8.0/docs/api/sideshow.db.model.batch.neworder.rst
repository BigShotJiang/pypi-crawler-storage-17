
``sideshow.db.model.batch.neworder``
====================================

.. automodule:: sideshow.db.model.batch.neworder
   :members:
