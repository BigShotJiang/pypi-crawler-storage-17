
``sideshow.cli.base``
=====================

.. automodule:: sideshow.cli.base
   :members:
