
``sideshow.batch.neworder``
===========================

.. automodule:: sideshow.batch.neworder
   :members:
