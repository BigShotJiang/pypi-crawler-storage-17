
``sideshow.db.model.stores``
============================

.. automodule:: sideshow.db.model.stores
   :members:
