
``sideshow.web.menus``
======================

.. automodule:: sideshow.web.menus
   :members:
