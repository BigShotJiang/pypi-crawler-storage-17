
``sideshow.cli``
================

.. automodule:: sideshow.cli
   :members:
