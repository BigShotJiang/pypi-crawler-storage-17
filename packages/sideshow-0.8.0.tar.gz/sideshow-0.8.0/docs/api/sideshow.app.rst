
``sideshow.app``
================

.. automodule:: sideshow.app
   :members:
