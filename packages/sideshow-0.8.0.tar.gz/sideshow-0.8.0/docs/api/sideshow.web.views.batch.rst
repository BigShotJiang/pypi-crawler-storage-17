
``sideshow.web.views.batch``
============================

.. automodule:: sideshow.web.views.batch
   :members:
