
``sideshow.batch``
==================

.. automodule:: sideshow.batch
   :members:
