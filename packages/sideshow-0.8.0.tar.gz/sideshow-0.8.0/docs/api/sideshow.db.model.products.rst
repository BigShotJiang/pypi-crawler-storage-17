
``sideshow.db.model.products``
==============================

.. automodule:: sideshow.db.model.products
   :members:
