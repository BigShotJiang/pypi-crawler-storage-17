
``sideshow.web.app``
====================

.. automodule:: sideshow.web.app
   :members:
