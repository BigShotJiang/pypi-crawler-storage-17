
``sideshow.web.views.products``
===============================

.. automodule:: sideshow.web.views.products
   :members:
