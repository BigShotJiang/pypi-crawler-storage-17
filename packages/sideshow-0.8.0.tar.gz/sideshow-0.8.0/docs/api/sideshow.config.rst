
``sideshow.config``
===================

.. automodule:: sideshow.config
   :members:
