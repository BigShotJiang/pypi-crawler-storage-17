
``sideshow``
============

.. automodule:: sideshow
   :members:
