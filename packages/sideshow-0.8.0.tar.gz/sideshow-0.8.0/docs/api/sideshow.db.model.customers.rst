
``sideshow.db.model.customers``
===============================

.. automodule:: sideshow.db.model.customers
   :members:
