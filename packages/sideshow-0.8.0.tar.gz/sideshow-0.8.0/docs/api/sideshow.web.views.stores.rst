
``sideshow.web.views.stores``
=============================

.. automodule:: sideshow.web.views.stores
   :members:
