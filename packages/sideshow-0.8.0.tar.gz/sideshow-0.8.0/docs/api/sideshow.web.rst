
``sideshow.web``
================

.. automodule:: sideshow.web
   :members:
