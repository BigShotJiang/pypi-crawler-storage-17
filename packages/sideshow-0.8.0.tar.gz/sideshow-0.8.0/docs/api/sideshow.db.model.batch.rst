
``sideshow.db.model.batch``
===========================

.. automodule:: sideshow.db.model.batch
   :members:
