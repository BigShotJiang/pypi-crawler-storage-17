# -*- coding: utf-8; -*-
################################################################################
#
#  Sideshow -- Case/Special Order Tracker
#  Copyright © 2024-2025 Lance Edgar
#
#  This file is part of Sideshow.
#
#  Sideshow is free software: you can redistribute it and/or modify it
#  under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Sideshow is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with Sideshow.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Sideshow Views
"""

from wuttaweb.views import essential


def includeme(config):  # pylint: disable=missing-function-docstring

    # core views for wuttaweb
    essential.defaults(
        config,
        **{
            "wuttaweb.views.common": "sideshow.web.views.common",
        },
    )

    # sideshow views
    config.include("sideshow.web.views.stores")
    config.include("sideshow.web.views.customers")
    config.include("sideshow.web.views.products")
    config.include("sideshow.web.views.orders")

    # batch views
    config.include("sideshow.web.views.batch.neworder")
