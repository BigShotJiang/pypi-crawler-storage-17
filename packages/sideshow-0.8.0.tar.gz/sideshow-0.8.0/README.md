
# Sideshow

This is a web app which provides retailers a way to track case/special
orders.

Full docs are at https://rattailproject.org/docs/sideshow/


## Quick Start

Make a virtual environment and install the app:

    python3 -m venv sideshow
    source sideshow/bin/activate
    pip install Sideshow
    sideshow install
