def test_import() -> None:
    import bblean  # noqa
