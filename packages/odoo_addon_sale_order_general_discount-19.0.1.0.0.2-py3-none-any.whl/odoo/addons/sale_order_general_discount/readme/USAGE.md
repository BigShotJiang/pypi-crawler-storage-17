To use this module, you need to:

1.  Create a sale order and set a discount, this discount will be set in
    all lines.
2.  You can set a discount in a partner.
3.  On product you can define if you apply general discount on sale
    order line linked to that product
