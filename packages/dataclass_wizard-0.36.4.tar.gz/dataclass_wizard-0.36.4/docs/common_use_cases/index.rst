Common Use Cases
================

.. toctree::
   :maxdepth: 2
   :glob:

   *
