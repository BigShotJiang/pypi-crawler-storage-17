# Typed Ndax

> A fully typed, validated async client for the Ndax API

Use *autocomplete* instead of documentation.

🚧 Under construction.