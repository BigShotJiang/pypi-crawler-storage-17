"""
### Typed Ndax
> A fully typed, validated async client for the Ndax API

- Details
"""