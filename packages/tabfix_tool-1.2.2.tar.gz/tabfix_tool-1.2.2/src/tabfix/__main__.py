#!/usr/bin/env python3
import sys
from .core import main

if __name__ == "__main__":
    sys.exit(main())
