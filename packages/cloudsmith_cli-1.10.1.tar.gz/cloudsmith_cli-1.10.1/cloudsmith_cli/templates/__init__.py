"""
HTML templates for Cloudsmith CLI interface.
"""
