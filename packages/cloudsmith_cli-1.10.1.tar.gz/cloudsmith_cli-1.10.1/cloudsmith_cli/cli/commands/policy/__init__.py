from .deny import deny_policy as policy_deny
from .license import licence as policy_license
from .vulnerability import vulnerability as policy_vulnerability
