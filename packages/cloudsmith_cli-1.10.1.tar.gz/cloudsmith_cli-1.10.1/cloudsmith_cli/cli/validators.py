"""CLI - Validators."""

import base64
from datetime import datetime

import click
from click.core import ParameterSource

from .types import ExpandPath

CONTEXT_SETTINGS = dict(help_option_names=["-h", "--help"])
BAD_API_HEADERS = ("user-agent", "host")
API_HEADER_TRANSFORMS = {}


class IntOrWildcard(click.ParamType):
    """Custom Click type that accepts integers or '*' wildcard (converted to -1)."""

    name = "integer or *"

    def convert(self, value, param, ctx):
        # Already converted
        if isinstance(value, int):
            return value

        # Handle wildcard
        if value == "*":
            return -1

        # Try to convert to integer
        try:
            return int(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid integer or '*'", param, ctx)


def transform_api_header_authorization(param, value):
    """Transform a username:password value into a base64 string."""
    try:
        username, password = value.split(":", 1)
    except ValueError:
        raise click.BadParameter(
            "Authorization header needs to be Authorization=username:password",
            param=param,
        )

    value = f"{username.strip()}:{password}"
    value = base64.b64encode(bytes(value.encode()))
    return "Basic %s" % value.decode("utf-8")


API_HEADER_TRANSFORMS["Authorization"] = transform_api_header_authorization


def validate_api_headers(param, value):
    """Validate that API headers is a CSV of k=v pairs."""
    # pylint: disable=unused-argument
    if not value:
        return None

    headers = {}
    for kv in value.split(","):
        try:
            k, v = kv.split("=", 1)
            k = k.strip()

            for bad_header in BAD_API_HEADERS:
                if bad_header == k:
                    raise click.BadParameter(
                        f"{bad_header} is not an allowed header",
                        param=param,
                    )

            if k in API_HEADER_TRANSFORMS:
                transform_func = API_HEADER_TRANSFORMS[k]
                v = transform_func(param, v)
        except ValueError:
            raise click.BadParameter(
                "Values need to be a CSV of key=value pairs", param=param
            )

        headers[k] = v

    return headers


def validate_slashes(
    param, value, minimum=2, maximum=None, form=None, allow_blank=False
):
    """Ensure that parameter has slashes and minimum parts."""
    try:
        value = value.split("/")
    except ValueError:
        value = None

    if value:
        if len(value) < minimum:
            value = None
        elif maximum and len(value) > maximum:
            value = None

    if not value:
        form = form or "/".join("VALUE" for _ in range(minimum))
        raise click.BadParameter(f"Must be in the form of {form}", param=param)

    value = [v.strip() for v in value]
    if not allow_blank and not all(value):
        raise click.BadParameter("Individual values cannot be blank", param=param)

    return value


def validate_optional_owner_repo(ctx, param, value):
    """Ensure that owner/repo is formatted correctly, where owner and repo are optional."""
    # pylint: disable=unused-argument
    form = "OWNER/REPO"

    return validate_slashes(
        param, value, minimum=0, maximum=2, form=form, allow_blank=True
    )


def validate_required_owner_optional_repo(ctx, param, value):
    """Ensure that owner/repo is formatted correctly, where owner is required and repo is optional."""
    form = "OWNER[/REPO]"
    return validate_slashes(param, value, minimum=1, maximum=2, form=form)


def validate_owner(ctx, param, value):
    """Ensure that owner is formatted correctly."""
    # pylint: disable=unused-argument
    form = "OWNER"
    return validate_slashes(param, value, minimum=1, maximum=1, form=form)


def validate_owner_repo(ctx, param, value):
    """Ensure that owner/repo is formatted correctly."""
    # pylint: disable=unused-argument
    form = "OWNER/REPO"
    return validate_slashes(param, value, minimum=2, maximum=2, form=form)


def validate_owner_repo_package(ctx, param, value):
    """Ensure that owner/repo/package is formatted correctly."""
    # pylint: disable=unused-argument
    form = "OWNER/REPO/PACKAGE"
    return validate_slashes(param, value, minimum=3, maximum=3, form=form)


def validate_owner_repo_slug_perm(ctx, param, value):
    """Ensure that owner/repo/slug_perm is formatted correctly."""
    # pylint: disable=unused-argument
    form = "OWNER/REPO/SLUG_PERM"
    return validate_slashes(param, value, minimum=3, maximum=3, form=form)


def validate_owner_repo_distro(ctx, param, value):
    """Ensure that owner/repo/distro/version is formatted correctly."""
    # pylint: disable=unused-argument
    form = "OWNER/REPO/DISTRO[/RELEASE]"
    return validate_slashes(param, value, minimum=3, maximum=4, form=form)


def validate_page(ctx, param, value):
    """Ensure that a valid value for page is chosen."""
    # pylint: disable=unused-argument
    if value == 0:
        raise click.BadParameter(
            "Page is not zero-based, please set a value to 1 or higher.", param=param
        )
    return value


def validate_page_size(ctx, param, value):
    """Ensure that a valid value for page size is chosen.

    The IntOrWildcard type already converts '*' to -1 and validates integers.
    """
    # pylint: disable=unused-argument
    if value == 0:
        raise click.BadParameter("Page size must be non-zero or unset.", param=param)
    return value


def enforce_page_all_exclusive(ctx, wildcard_used=False):
    """Order-independent mutual exclusivity check for pagination options.

    Raises click.BadParameter bound to the --page-all option if it was used
    together with explicit --page or --page-size. "Explicit" means supplied
    via command line, environment variable, or prompt (Click ParameterSource).

    Args:
        ctx: Click context
        wildcard_used: If True, validates even if --page-all wasn't explicitly passed
                      (used when --page-size '*' or -1 was used)
    """
    page_all = ctx.params.get("page_all")
    if not page_all and not wildcard_used:
        return

    explicit_sources = {
        src
        for src in (
            ParameterSource.COMMANDLINE,
            ParameterSource.ENVIRONMENT,
            getattr(ParameterSource, "PROMPT", None),
        )
        if src is not None
    }

    page_explicit = ctx.get_parameter_source("page") in explicit_sources
    # When checking wildcard usage, don't count page_size as conflicting with itself
    size_source = ctx.get_parameter_source("page_size")
    size_explicit = size_source in explicit_sources and not (
        wildcard_used and size_source == ParameterSource.COMMANDLINE
    )

    if page_explicit or size_explicit:
        page_all_param = next(
            (p for p in ctx.command.params if p.name == "page_all"), None
        )
        error_msg = "Cannot be used with --page (-p) or --page-size (-l). (--show-all is an alias for --page-all)"
        if wildcard_used:
            error_msg = "Wildcard '*' or -1 in --page-size cannot be used with --page (-p). Use --page-all instead."
        raise click.BadParameter(
            error_msg,
            param=page_all_param,
        )


def validate_optional_timestamp(ctx, param, value):
    """Ensure that a valid value for a timestamp is used."""

    if value:
        try:
            return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(
                hour=0, minute=0, second=0
            )
        except ValueError:
            raise click.BadParameter(
                f"{param.name} must be a valid utc timestamp formatted as `%Y-%m-%dT%H:%M:%SZ` e.g. `2020-12-31T00:00:00Z`",
                param=param,
            )

    return value


def validate_bandwidth_unit(ctx, param, value):
    """Ensure that a valid value for bandwidth unit is used."""

    units = [
        "Byte",
        "Kilobyte",
        "Megabyte",
        "Gigabyte",
        "Terabyte",
        "Petabyte",
        "Exabyte",
        "Zettabyte",
        "Yottabyte",
    ]

    if value:
        for unit in units:
            if value.lower() == unit.lower():
                return unit

        raise click.BadParameter(
            "Bandwidth unit must be one of the allowed values "
            "(Byte, Kilobyte, Megabyte, Gigabyte, Terabyte, Petabyte, "
            "Exabyte, Zettabyte, Yottabyte).",
            param=param,
        )

    return value


def validate_scheduled_reset_period(ctx, param, value):
    """Ensure that a valid value for scheduled reset period is used."""

    periods = [
        "Never Reset",
        "Daily",
        "Weekly",
        "Fortnightly",
        "Monthly",
        "Bi-Monthly",
        "Quarterly",
        "Every 6 months",
        "Annual",
    ]

    if value:
        for period in periods:
            if value.lower() == period.lower():
                return period

        raise click.BadParameter(
            "The refresh token period must be one of the allowed values "
            "(Never reset, Daily, Weekly, Fortnightly, Monthly "
            "Bi-Monthly, Quarterly, Every 6 months, Annual).",
            param=param,
        )

    return value


def validate_extra_files_parameter(ctx, param, value):
    """Validate and resolve paths for all extra files."""

    if not value:
        return []

    path_obj = ExpandPath(
        exists=True,
        dir_okay=False,
        writable=False,
        resolve_path=True,
    )

    files = []
    for v in value:
        for path in v.split(","):
            path = path.strip()
            if not path:
                continue

            try:
                resolved_path = path_obj.convert(path, param, ctx)
                files.append(resolved_path)
            except click.BadParameter as e:
                raise click.BadParameter(f"Invalid file path '{path}': {e}")

    return files
