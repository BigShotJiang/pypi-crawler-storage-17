from django.apps import AppConfig


class DefaultConfig(AppConfig):
    name = "cmShoppingList"
    label = "cmShoppingList"
    verbose_name = "Shopping List"
