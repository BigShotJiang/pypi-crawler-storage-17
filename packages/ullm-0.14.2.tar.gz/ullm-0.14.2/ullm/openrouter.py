from typing import Annotated, Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from .base import (
    RemoteLanguageModel,
    RemoteLanguageModelMetaInfo,
)
from .openai import OpenAICompatibleModel
from .openai_types import (
    OpenAIAssistantMessage,
    OpenAIImagePart,
    OpenAIRequestBody,
    OpenAIResponseBody,
    OpenAIToolCall,
)
from .types import (
    AssistantMessage,
    GenerateConfig,
    ImagePart,
    TextPart,
    ToolCall,
)


class OpenRouterProviderSetting(BaseModel):
    # https://openrouter.ai/docs/features/model-routing
    order: Optional[
        List[
            Literal[
                "OpenAI",
                "Anthropic",
                "HuggingFace",
                "Google",
                "Mancer",
                "Mancer 2",
                "Together",
                "DeepInfra",
                "Azure",
                "Modal",
                "AnyScale",
                "Replicate",
                "Perplexity",
                "Recursal",
                "Fireworks",
                "Mistral",
                "Groq",
                "Cohere",
                "Lepton",
                "OctoAI",
                "Novita",
                "Lynn",
                "Lynn 2",
            ]
        ]
    ] = None
    require_parameters: Optional[bool] = None
    data_collection: Optional[Literal["deny", "allow"]] = None
    allow_fallbacks: Optional[bool] = None


class OpenRouterRequestBody(OpenAIRequestBody):
    # reference: https://openrouter.ai/docs#requests
    # OpenAI 没有的参数
    prompt: Optional[str] = None
    top_k: Optional[Annotated[int, Field(ge=1)]] = None
    repetition_penalty: Optional[Annotated[float, Field(gt=0.0, le=2.0)]] = None
    transforms: Optional[List[Literal["middle-out"]]] = None
    ## models routing
    provider: Optional[OpenRouterProviderSetting] = None
    models: Optional[List[str]] = None
    route: Optional[Literal["fallback"]] = None


class OpenRouterAssistantMessage(OpenAIAssistantMessage):
    # Extra fields from openrouter
    # https://openrouter.ai/docs/features/multimodal/image-generation
    images: Optional[List[OpenAIImagePart]] = None
    # NOTE:
    #   - openai 文档中未观察到 reasoning 相关返回值
    #   - openrouter 返回值中同时有 reasoning 和 reasoning_details
    #     - reasoning: 未在文档中观察到
    #     - reasoning_details: https://openrouter.ai/docs/use-cases/reasoning-tokens#reasoning_details-array-structure
    # TODO: reasoning_details -> reasoning
    reasoning: Optional[Any] = None

    @classmethod
    def from_standard(cls, message: AssistantMessage):
        tool_calls = None
        if message.tool_calls:
            tool_calls = [OpenAIToolCall.from_standard(tc) for tc in message.tool_calls]

        return cls(
            role="assistant", content=message.text, images=message.images, tool_calls=tool_calls
        )

    def to_standard(self) -> AssistantMessage:
        parts: List[TextPart | ImagePart] = []

        if isinstance(self.content, str) and self.content != "":
            parts.append(TextPart(text=self.content))

        # NOTE: Only for OpenRouter: https://openrouter.ai/docs/features/multimodal/image-generation
        if self.images:
            parts.extend(image.to_standard() for image in self.images)

        tool_calls: Optional[List[ToolCall]] = None
        if self.tool_calls:
            tool_calls = [tc.to_standard() for tc in self.tool_calls]

        return AssistantMessage(content=parts, tool_calls=tool_calls)


class OpenRouterResponseChoice(BaseModel):
    finish_reason: Optional[str] = None
    index: int
    message: OpenRouterAssistantMessage


class OpenRouterResponseBody(OpenAIResponseBody):
    choices: Annotated[List[OpenRouterResponseChoice], Field(min_length=1)]


@RemoteLanguageModel.register("openrouter")
class OpenRouterModel(OpenAICompatibleModel):
    # https://openrouter.ai/api/v1/models
    _FULL_SUPPORTED_MODELS = [
        "01-ai/yi-large",
        "aetherwiing/mn-starcannon-12b",
        "agentica-org/deepcoder-14b-preview:free",
        "ai21/jamba-1.6-large",
        "ai21/jamba-1.6-mini",
        "aion-labs/aion-1.0",
        "aion-labs/aion-1.0-mini",
        "aion-labs/aion-rp-llama-3.1-8b",
        "alfredpros/codellama-7b-instruct-solidity",
        "all-hands/openhands-lm-32b-v0.1",
        "alpindale/goliath-120b",
        "alpindale/magnum-72b",
        "amazon/nova-lite-v1",
        "amazon/nova-micro-v1",
        "amazon/nova-pro-v1",
        "anthracite-org/magnum-v2-72b",
        "anthracite-org/magnum-v4-72b",
        "anthropic/claude-2",
        "anthropic/claude-2.0",
        "anthropic/claude-2.0:beta",
        "anthropic/claude-2.1",
        "anthropic/claude-2.1:beta",
        "anthropic/claude-2:beta",
        "anthropic/claude-3-haiku",
        "anthropic/claude-3-haiku:beta",
        "anthropic/claude-3-opus",
        "anthropic/claude-3-opus:beta",
        "anthropic/claude-3-sonnet",
        "anthropic/claude-3-sonnet:beta",
        "anthropic/claude-3.5-haiku",
        "anthropic/claude-3.5-haiku-20241022",
        "anthropic/claude-3.5-haiku-20241022:beta",
        "anthropic/claude-3.5-haiku:beta",
        "anthropic/claude-3.5-sonnet",
        "anthropic/claude-3.5-sonnet-20240620",
        "anthropic/claude-3.5-sonnet-20240620:beta",
        "anthropic/claude-3.5-sonnet:beta",
        "anthropic/claude-3.7-sonnet",
        "anthropic/claude-3.7-sonnet:beta",
        "anthropic/claude-3.7-sonnet:thinking",
        "anthropic/claude-opus-4",
        "anthropic/claude-sonnet-4",
        "arcee-ai/arcee-blitz",
        "arcee-ai/caller-large",
        "arcee-ai/coder-large",
        "arcee-ai/maestro-reasoning",
        "arcee-ai/spotlight",
        "arcee-ai/virtuoso-large",
        "arcee-ai/virtuoso-medium-v2",
        "arliai/qwq-32b-arliai-rpr-v1:free",
        "cognitivecomputations/dolphin-mixtral-8x22b",
        "cognitivecomputations/dolphin3.0-mistral-24b:free",
        "cognitivecomputations/dolphin3.0-r1-mistral-24b:free",
        "cohere/command",
        "cohere/command-a",
        "cohere/command-r",
        "cohere/command-r-03-2024",
        "cohere/command-r-08-2024",
        "cohere/command-r-plus",
        "cohere/command-r-plus-04-2024",
        "cohere/command-r-plus-08-2024",
        "cohere/command-r7b-12-2024",
        "deepseek/deepseek-chat",
        "deepseek/deepseek-chat-v3-0324",
        "deepseek/deepseek-chat-v3-0324:free",
        "deepseek/deepseek-chat:free",
        "deepseek/deepseek-prover-v2",
        "deepseek/deepseek-r1",
        "deepseek/deepseek-r1-0528",
        "deepseek/deepseek-r1-0528-qwen3-8b",
        "deepseek/deepseek-r1-0528-qwen3-8b:free",
        "deepseek/deepseek-r1-0528:free",
        "deepseek/deepseek-r1-distill-llama-70b",
        "deepseek/deepseek-r1-distill-llama-70b:free",
        "deepseek/deepseek-r1-distill-llama-8b",
        "deepseek/deepseek-r1-distill-qwen-1.5b",
        "deepseek/deepseek-r1-distill-qwen-14b",
        "deepseek/deepseek-r1-distill-qwen-14b:free",
        "deepseek/deepseek-r1-distill-qwen-32b",
        "deepseek/deepseek-r1-distill-qwen-7b",
        "deepseek/deepseek-r1:free",
        "deepseek/deepseek-v3-base:free",
        "eleutherai/llemma_7b",
        "eva-unit-01/eva-llama-3.33-70b",
        "eva-unit-01/eva-qwen-2.5-32b",
        "eva-unit-01/eva-qwen-2.5-72b",
        "featherless/qwerky-72b:free",
        "google/gemini-2.0-flash-001",
        "google/gemini-2.0-flash-exp:free",
        "google/gemini-2.0-flash-lite-001",
        "google/gemini-2.5-flash",
        "google/gemini-2.5-flash-lite-preview-06-17",
        "google/gemini-2.5-flash-preview",
        "google/gemini-2.5-flash-preview-05-20",
        "google/gemini-2.5-flash-preview-05-20:thinking",
        "google/gemini-2.5-flash-preview:thinking",
        "google/gemini-2.5-pro",
        "google/gemini-2.5-pro-exp-03-25",
        "google/gemini-2.5-pro-preview",
        "google/gemini-2.5-pro-preview-05-06",
        "google/gemini-flash-1.5",
        "google/gemini-flash-1.5-8b",
        "google/gemini-pro-1.5",
        "google/gemma-2-27b-it",
        "google/gemma-2-9b-it",
        "google/gemma-2-9b-it:free",
        "google/gemma-3-12b-it",
        "google/gemma-3-12b-it:free",
        "google/gemma-3-27b-it",
        "google/gemma-3-27b-it:free",
        "google/gemma-3-4b-it",
        "google/gemma-3-4b-it:free",
        "google/gemma-3n-e4b-it:free",
        "gryphe/mythomax-l2-13b",
        "inception/mercury-coder-small-beta",
        "infermatic/mn-inferor-12b",
        "inflection/inflection-3-pi",
        "inflection/inflection-3-productivity",
        "liquid/lfm-3b",
        "liquid/lfm-40b",
        "liquid/lfm-7b",
        "mancer/weaver",
        "meta-llama/llama-3-70b-instruct",
        "meta-llama/llama-3-8b-instruct",
        "meta-llama/llama-3.1-405b",
        "meta-llama/llama-3.1-405b-instruct",
        "meta-llama/llama-3.1-70b-instruct",
        "meta-llama/llama-3.1-8b-instruct",
        "meta-llama/llama-3.1-8b-instruct:free",
        "meta-llama/llama-3.2-11b-vision-instruct",
        "meta-llama/llama-3.2-11b-vision-instruct:free",
        "meta-llama/llama-3.2-1b-instruct",
        "meta-llama/llama-3.2-1b-instruct:free",
        "meta-llama/llama-3.2-3b-instruct",
        "meta-llama/llama-3.2-90b-vision-instruct",
        "meta-llama/llama-3.3-70b-instruct",
        "meta-llama/llama-3.3-70b-instruct:free",
        "meta-llama/llama-4-maverick",
        "meta-llama/llama-4-maverick:free",
        "meta-llama/llama-4-scout",
        "meta-llama/llama-4-scout:free",
        "meta-llama/llama-guard-2-8b",
        "meta-llama/llama-guard-3-8b",
        "meta-llama/llama-guard-4-12b",
        "microsoft/mai-ds-r1:free",
        "microsoft/phi-3-medium-128k-instruct",
        "microsoft/phi-3-mini-128k-instruct",
        "microsoft/phi-3.5-mini-128k-instruct",
        "microsoft/phi-4",
        "microsoft/phi-4-multimodal-instruct",
        "microsoft/phi-4-reasoning-plus",
        "microsoft/wizardlm-2-8x22b",
        "minimax/minimax-01",
        "minimax/minimax-m1",
        "minimax/minimax-m1:extended",
        "mistralai/codestral-2501",
        "mistralai/devstral-small",
        "mistralai/devstral-small:free",
        "mistralai/magistral-medium-2506",
        "mistralai/magistral-medium-2506:thinking",
        "mistralai/magistral-small-2506",
        "mistralai/ministral-3b",
        "mistralai/ministral-8b",
        "mistralai/mistral-7b-instruct",
        "mistralai/mistral-7b-instruct-v0.1",
        "mistralai/mistral-7b-instruct-v0.2",
        "mistralai/mistral-7b-instruct-v0.3",
        "mistralai/mistral-7b-instruct:free",
        "mistralai/mistral-large",
        "mistralai/mistral-large-2407",
        "mistralai/mistral-large-2411",
        "mistralai/mistral-medium-3",
        "mistralai/mistral-nemo",
        "mistralai/mistral-nemo:free",
        "mistralai/mistral-saba",
        "mistralai/mistral-small",
        "mistralai/mistral-small-24b-instruct-2501",
        "mistralai/mistral-small-24b-instruct-2501:free",
        "mistralai/mistral-small-3.1-24b-instruct",
        "mistralai/mistral-small-3.1-24b-instruct:free",
        "mistralai/mistral-small-3.2-24b-instruct",
        "mistralai/mistral-small-3.2-24b-instruct:free",
        "mistralai/mistral-tiny",
        "mistralai/mixtral-8x22b-instruct",
        "mistralai/mixtral-8x7b-instruct",
        "mistralai/pixtral-12b",
        "mistralai/pixtral-large-2411",
        "moonshotai/kimi-dev-72b:free",
        "moonshotai/kimi-vl-a3b-thinking:free",
        "neversleep/llama-3-lumimaid-70b",
        "neversleep/llama-3-lumimaid-8b",
        "neversleep/llama-3.1-lumimaid-70b",
        "neversleep/llama-3.1-lumimaid-8b",
        "neversleep/noromaid-20b",
        "nothingiisreal/mn-celeste-12b",
        "nousresearch/deephermes-3-llama-3-8b-preview:free",
        "nousresearch/hermes-2-pro-llama-3-8b",
        "nousresearch/hermes-3-llama-3.1-405b",
        "nousresearch/hermes-3-llama-3.1-70b",
        "nousresearch/nous-hermes-2-mixtral-8x7b-dpo",
        "nvidia/llama-3.1-nemotron-70b-instruct",
        "nvidia/llama-3.1-nemotron-ultra-253b-v1",
        "nvidia/llama-3.1-nemotron-ultra-253b-v1:free",
        "nvidia/llama-3.3-nemotron-super-49b-v1",
        "nvidia/llama-3.3-nemotron-super-49b-v1:free",
        "openai/chatgpt-4o-latest",
        "openai/codex-mini",
        "openai/gpt-3.5-turbo-0613",
        "openai/gpt-3.5-turbo-16k",
        "openai/gpt-3.5-turbo-instruct",
        "openai/gpt-4",
        "openai/gpt-4-0314",
        "openai/gpt-4-1106-preview",
        "openai/gpt-4-turbo",
        "openai/gpt-4-turbo-preview",
        "openai/gpt-4.1",
        "openai/gpt-4.1-mini",
        "openai/gpt-4.1-nano",
        "openai/gpt-4.5-preview",
        "openai/gpt-4o",
        "openai/gpt-4o-2024-05-13",
        "openai/gpt-4o-2024-08-06",
        "openai/gpt-4o-2024-11-20",
        "openai/gpt-4o-mini",
        "openai/gpt-4o-mini-2024-07-18",
        "openai/gpt-4o-mini-search-preview",
        "openai/gpt-4o-search-preview",
        "openai/gpt-4o:extended",
        "openai/o1",
        "openai/o1-mini",
        "openai/o1-mini-2024-09-12",
        "openai/o1-preview",
        "openai/o1-preview-2024-09-12",
        "openai/o1-pro",
        "openai/o3",
        "openai/o3-mini",
        "openai/o3-mini-high",
        "openai/o3-pro",
        "openai/o4-mini",
        "openai/o4-mini-high",
        "opengvlab/internvl3-14b",
        "opengvlab/internvl3-2b",
        "openrouter/auto",
        "perplexity/llama-3.1-sonar-large-128k-online",
        "perplexity/llama-3.1-sonar-small-128k-online",
        "perplexity/r1-1776",
        "perplexity/sonar",
        "perplexity/sonar-deep-research",
        "perplexity/sonar-pro",
        "perplexity/sonar-reasoning",
        "perplexity/sonar-reasoning-pro",
        "pygmalionai/mythalion-13b",
        "qwen/qwen-2-72b-instruct",
        "qwen/qwen-2.5-72b-instruct",
        "qwen/qwen-2.5-72b-instruct:free",
        "qwen/qwen-2.5-7b-instruct",
        "qwen/qwen-2.5-coder-32b-instruct",
        "qwen/qwen-2.5-coder-32b-instruct:free",
        "qwen/qwen-2.5-vl-7b-instruct",
        "qwen/qwen-max",
        "qwen/qwen-plus",
        "qwen/qwen-turbo",
        "qwen/qwen-vl-max",
        "qwen/qwen-vl-plus",
        "qwen/qwen2.5-vl-32b-instruct",
        "qwen/qwen2.5-vl-32b-instruct:free",
        "qwen/qwen2.5-vl-72b-instruct",
        "qwen/qwen2.5-vl-72b-instruct:free",
        "qwen/qwen3-14b",
        "qwen/qwen3-14b:free",
        "qwen/qwen3-235b-a22b",
        "qwen/qwen3-235b-a22b:free",
        "qwen/qwen3-30b-a3b",
        "qwen/qwen3-30b-a3b:free",
        "qwen/qwen3-32b",
        "qwen/qwen3-32b:free",
        "qwen/qwen3-8b",
        "qwen/qwen3-8b:free",
        "qwen/qwq-32b",
        "qwen/qwq-32b-preview",
        "qwen/qwq-32b:free",
        "raifle/sorcererlm-8x22b",
        "rekaai/reka-flash-3:free",
        "sao10k/fimbulvetr-11b-v2",
        "sao10k/l3-euryale-70b",
        "sao10k/l3-lunaris-8b",
        "sao10k/l3.1-euryale-70b",
        "sao10k/l3.3-euryale-70b",
        "sarvamai/sarvam-m:free",
        "scb10x/llama3.1-typhoon2-70b-instruct",
        "sentientagi/dobby-mini-unhinged-plus-llama-3.1-8b",
        "shisa-ai/shisa-v2-llama3.3-70b:free",
        "sophosympatheia/midnight-rose-70b",
        "thedrummer/anubis-pro-105b-v1",
        "thedrummer/rocinante-12b",
        "thedrummer/skyfall-36b-v2",
        "thedrummer/unslopnemo-12b",
        "thedrummer/valkyrie-49b-v1",
        "thudm/glm-4-32b",
        "thudm/glm-4-32b:free",
        "thudm/glm-z1-32b",
        "thudm/glm-z1-32b:free",
        "thudm/glm-z1-rumination-32b",
        "tngtech/deepseek-r1t-chimera:free",
        "undi95/remm-slerp-l2-13b",
        "undi95/toppy-m-7b",
        "x-ai/grok-2-1212",
        "x-ai/grok-2-vision-1212",
        "x-ai/grok-3",
        "x-ai/grok-3-beta",
        "x-ai/grok-3-mini",
        "x-ai/grok-3-mini-beta",
        "x-ai/grok-beta",
        "x-ai/grok-vision-beta",
    ]
    _MODEL_PREFIX_MAP = dict(
        [full_model_name.split("/")[::-1] for full_model_name in _FULL_SUPPORTED_MODELS]
    )
    _SUPPORTED_MODELS = sorted(_MODEL_PREFIX_MAP.keys())
    _VISUAL_MODELS = [
        "chatgpt-4o-latest",
        "claude-3-haiku",
        "claude-3-haiku:beta",
        "claude-3-opus",
        "claude-3-opus:beta",
        "claude-3-sonnet",
        "claude-3-sonnet:beta",
        "claude-3.5-haiku",
        "claude-3.5-haiku-20241022",
        "claude-3.5-haiku-20241022:beta",
        "claude-3.5-haiku:beta",
        "claude-3.5-sonnet",
        "claude-3.5-sonnet-20240620",
        "claude-3.5-sonnet-20240620:beta",
        "claude-3.5-sonnet:beta",
        "claude-3.7-sonnet",
        "claude-3.7-sonnet:beta",
        "claude-3.7-sonnet:thinking",
        "claude-opus-4",
        "claude-sonnet-4",
        "codex-mini",
        "gemini-2.0-flash-001",
        "gemini-2.0-flash-exp:free",
        "gemini-2.0-flash-lite-001",
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite-preview-06-17",
        "gemini-2.5-flash-preview",
        "gemini-2.5-flash-preview-05-20",
        "gemini-2.5-flash-preview-05-20:thinking",
        "gemini-2.5-flash-preview:thinking",
        "gemini-2.5-pro",
        "gemini-2.5-pro-exp-03-25",
        "gemini-2.5-pro-preview",
        "gemini-2.5-pro-preview-05-06",
        "gemini-flash-1.5",
        "gemini-flash-1.5-8b",
        "gemini-pro-1.5",
        "gemma-3-12b-it",
        "gemma-3-12b-it:free",
        "gemma-3-27b-it",
        "gemma-3-27b-it:free",
        "gemma-3-4b-it",
        "gemma-3-4b-it:free",
        "gpt-4-turbo",
        "gpt-4.1",
        "gpt-4.1-mini",
        "gpt-4.1-nano",
        "gpt-4.5-preview",
        "gpt-4o",
        "gpt-4o-2024-05-13",
        "gpt-4o-2024-08-06",
        "gpt-4o-2024-11-20",
        "gpt-4o-mini",
        "gpt-4o-mini-2024-07-18",
        "gpt-4o:extended",
        "grok-2-vision-1212",
        "grok-vision-beta",
        "internvl3-14b",
        "internvl3-2b",
        "kimi-vl-a3b-thinking:free",
        "llama-3.2-11b-vision-instruct",
        "llama-3.2-11b-vision-instruct:free",
        "llama-3.2-90b-vision-instruct",
        "llama-4-maverick",
        "llama-4-maverick:free",
        "llama-4-scout",
        "llama-4-scout:free",
        "llama-guard-4-12b",
        "minimax-01",
        "mistral-medium-3",
        "mistral-small-3.1-24b-instruct",
        "mistral-small-3.1-24b-instruct:free",
        "mistral-small-3.2-24b-instruct",
        "mistral-small-3.2-24b-instruct:free",
        "nova-lite-v1",
        "nova-pro-v1",
        "o1",
        "o1-pro",
        "o3",
        "o3-pro",
        "o4-mini",
        "o4-mini-high",
        "phi-4-multimodal-instruct",
        "pixtral-12b",
        "pixtral-large-2411",
        "qwen-2.5-vl-7b-instruct",
        "qwen-vl-max",
        "qwen-vl-plus",
        "qwen2.5-vl-32b-instruct",
        "qwen2.5-vl-32b-instruct:free",
        "qwen2.5-vl-72b-instruct",
        "qwen2.5-vl-72b-instruct:free",
        "sonar",
        "sonar-pro",
        "sonar-reasoning-pro",
        "spotlight",
    ]
    META = RemoteLanguageModelMetaInfo(
        api_url="https://openrouter.ai/api/v1/chat/completions",
        required_config_fields=["api_key"],
        language_models=set(_SUPPORTED_MODELS) - set(_VISUAL_MODELS),
        visual_language_models=_VISUAL_MODELS,
        tool_models=_SUPPORTED_MODELS,
        online_models=[
            "llama-3.1-sonar-large-128k-online",
            "llama-3.1-sonar-small-128k-online",
        ],
    )
    REQUEST_BODY_CLS = OpenRouterRequestBody
    RESPONSE_BODY_CLS = OpenRouterResponseBody

    def _convert_generation_config(
        self, config: GenerateConfig, system: Optional[str] = None
    ) -> Dict[str, Any]:
        model_prefix = self._MODEL_PREFIX_MAP[self.model]
        response_format = None
        if config.response_format:
            response_format = {"type": config.response_format}
            if config.response_format == "json_schema":
                response_format["json_schema"] = config.response_schema.model_dump(
                    mode="json", by_alias=True
                )

        return {
            "model": f"{model_prefix}/{self.model}",
            "frequency_penalty": config.frequency_penalty,
            "max_tokens": config.max_output_tokens or self.config.max_output_tokens,
            "presence_penalty": config.presence_penalty,
            "response_format": response_format,
            "stop": config.stop_sequences or self.config.stop_sequences,
            "temperature": config.temperature or self.config.temperature,
            "top_p": config.top_p or self.config.top_p,
            "top_k": config.top_k or self.config.top_k,
            "repetition_penalty": config.repetition_penalty,
        }
