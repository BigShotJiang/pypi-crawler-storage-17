import sys; sys.path.insert(0, "/home/kamel/Code/git/sftppathlib")
import pytest
from sftppathlib import SFTPPath

SFTPPath.set_authority("tomelet.com", "www")

def test_non_implemented_abstracmethod():
    path = SFTPPath("www")
    with pytest.raises(NotImplementedError):
        path.hardlink_to("hello")


def test_read():
    path = SFTPPath("/www")
    assert path.exists()


def test_alias():
    path = SFTPPath("https://tomelet.com/")
    assert repr(path) == "SFTPPath('https://tomelet.com/')"


def test_read_alias():
    path = SFTPPath("https://tomelet.com/")
    assert path.exists()


def test_iterdir():
    path = SFTPPath("https://tomelet.com/tmp")
    assert len(list(path.iterdir())) > 1
