# Generated domain models

from .BiogasProjectInformation import BiogasProjectInformation, BiogasProjectInformationRepoImpl
from .MechanismTaskPlanning import MechanismTaskPlanning, MechanismTaskPlanningRepoImpl
from .NewEntity import NewEntity, NewEntityRepoImpl
from .dd import dd, ddRepoImpl
from .MechanismCloudAlgorithm import MechanismCloudAlgorithm, MechanismCloudAlgorithmRepoImpl
