echo 6 > /sys/kernel/debug/bluetooth/hci0/conn_min_interval
echo 20 > /sys/kernel/debug/bluetooth/hci0/conn_max_interval
