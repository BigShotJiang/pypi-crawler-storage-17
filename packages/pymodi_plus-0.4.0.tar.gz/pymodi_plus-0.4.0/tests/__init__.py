"""
DO NOT DELETE THIS __init__.py FILE.

The file is required in order to correctly run the command below.
>>> python setup.py test

Setup detects test_suite="tests", as a package.
For tests/ to be recognized as a package, __init__.py is required.
"""
