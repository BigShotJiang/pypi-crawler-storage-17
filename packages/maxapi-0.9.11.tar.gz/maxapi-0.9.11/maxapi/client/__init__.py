from .default import DefaultConnectionProperties

__all__ = [
    "DefaultConnectionProperties",
]
