# Beekeeper monitors extension - watsonx

## Installation 

```bash
pip install beekeeper-monitors-watsonx
```
