The adapter_model.safetensors file here is just a dummy file for tests to pass that will not actually need to load it
