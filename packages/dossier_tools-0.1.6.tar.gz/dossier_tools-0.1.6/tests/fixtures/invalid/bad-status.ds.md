---
schema_version: "1.0.0"
title: "Bad Status"
version: "1.0.0"
status: "invalid_status"
objective: "This dossier has an invalid status enum value"
checksum:
  algorithm: "sha256"
  hash: "65a37634dc669d870fd00150dcb77a6ab4b772622e10cf29def3d3b536da829a"
authors:
  - name: "Test Author"
---

# Bad Status

Invalid enum value.
