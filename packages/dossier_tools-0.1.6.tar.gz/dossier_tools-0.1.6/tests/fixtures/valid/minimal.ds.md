---
schema_version: "1.0.0"
name: "minimal-dossier"
title: "Minimal Dossier"
version: "1.0.0"
status: "stable"
objective: "A minimal dossier with only required fields for testing"
checksum:
  algorithm: "sha256"
  hash: "66e8e8b89e47a1f516c71cbafec51ecc79314aab899a08cb84bc3bbc6b714adc"
authors:
  - name: "Test Author"
---

# Minimal Dossier

This is the body content.
