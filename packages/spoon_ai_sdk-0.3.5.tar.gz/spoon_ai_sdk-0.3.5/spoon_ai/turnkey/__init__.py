"""Turnkey client integration for SpoonAI.

Provides `Turnkey` for secure signing via Turnkey API.
"""

from .client import Turnkey  # noqa: F401


