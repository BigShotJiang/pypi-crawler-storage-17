"""
SuperGemini CLI Module
Command-line interface operations for SuperGemini installation system
"""

from .base import OperationBase

__all__ = [
    'OperationBase',
]