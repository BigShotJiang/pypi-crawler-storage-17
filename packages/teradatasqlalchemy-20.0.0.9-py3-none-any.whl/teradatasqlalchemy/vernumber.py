# Copyright 2025 by Teradata Corporation. All rights reserved.

sVersionNumber = "20.0.0.9"
