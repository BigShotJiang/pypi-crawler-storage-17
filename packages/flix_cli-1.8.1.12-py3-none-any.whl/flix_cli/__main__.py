from .core import __flix_cli__

if __name__ == "__main__":
    __flix_cli__.app()
