"""Shared features for the holoviz-mcp project."""
