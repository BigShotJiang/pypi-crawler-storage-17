import datetime
from typing import Self

from pydantic import BaseModel, RootModel, model_validator

from .util import and_join, use_non_breaking_space


class Address(RootModel):
    root: list[str]

    def __get_lines(self):
        return list(map(use_non_breaking_space, self.root))

    def line(self):
        return ", ".join(self.__get_lines())

    def multiline(self):
        return "\\\\\n".join(self.__get_lines())


class Name(RootModel):
    root: str | list[str]

    def __as_list(self) -> list[str]:
        return [self.root] if isinstance(self.root, str) else self.root

    def full_name(self) -> str:
        return and_join(list(map(use_non_breaking_space, self.__as_list())))

    def short_name(self) -> str:
        return and_join(list(map(lambda name: name.split(" ")[0], self.__as_list())))


class Pronoun(RootModel):
    root: str | None = None

    @model_validator(mode="after")
    def check_three_parts(self) -> Self:
        if self.root is not None and len(self.root.split("/")) != 3:
            raise ValueError("Pronouns must have three parts separated by `/`")
        return self

    def __get_pronoun_part(self, idx: int, default: str) -> str:
        return self.root.split("/")[idx] if self.root else default

    def get_subject(self) -> str:
        return self.__get_pronoun_part(0, "they")

    def get_object(self) -> str:
        return self.__get_pronoun_part(1, "them")

    def get_determiner(self) -> str:
        return self.__get_pronoun_part(2, "their")


class Inviter(BaseModel):
    name: Name
    address: Address
    phone: str
    email: str


class Invitee(BaseModel):
    name: Name
    pronoun: Pronoun = Pronoun()
    relationship: str


class Employer(BaseModel):
    name: Name
    address: Address

    def full_name(self) -> str:
        return self.name.full_name()


class Embassy(BaseModel):
    name: Name
    address: Address

    def full_name(self) -> str:
        return self.name.full_name()


class Trip(BaseModel):
    arrival_date: datetime.date
    departure_date: datetime.date
    reason: str | None = None
    return_reason: str | None = None
    return_country: str | None = None
    financial_support: bool = False


class InvitationConfig(BaseModel):
    inviter: Inviter
    invitee: Invitee
    employer: Employer
    embassy: Embassy
    trip: Trip
