# Resources

- [qpdf manual]
- [PDF 1.7] ISO Specification PDF 32000-1:2008
- [Adobe Supplement to ISO 32000 BaseVersion 1.7 ExtensionLevel 3], Adobe Acrobat 9.0, June 2008, for AESv3
- Other [Adobe extensions] to the PDF specification

For information about copyrights and licenses, including those associated with the
images in this documentation, see the source tree file `.reuse/dep5`.

[adobe extensions]: https://www.adobe.com/devnet/pdf/pdf_reference.html
[adobe supplement to iso 32000 baseversion 1.7 extensionlevel 3]: https://www.adobe.com/content/dam/acom/en/devnet/pdf/adobe_supplement_iso32000.pdf
[pdf 1.7]: https://opensource.adobe.com/dc-acrobat-sdk-docs/standards/pdfstandards/pdf/PDF32000_2008.pdf
[qpdf manual]: https://qpdf.readthedocs.io/
