# Exceptions

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.PdfError
```

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.PasswordError
```

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.ForeignObjectError
```

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.OutlineStructureError
```

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.UnsupportedImageTypeError
```

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.HifiPrintImageNotTranscodableError
```

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.InvalidPdfImageError
```

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.DataDecodingError
```

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.DeletedObjectError
```

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.DependencyError
```

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.PdfParsingError
```

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.JobUsageError
```

```{eval-rst}
.. autoapiexception:: pikepdf.exceptions.ImageDecompressionError
```
