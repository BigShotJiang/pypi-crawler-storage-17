"""Phonexia transcription normalization client.

This module provides a transcription normalization client.
This client can be used to communicate with the transcription normalization server.
"""

import json
import logging
from collections.abc import Iterator
from enum import Enum
from pathlib import Path
from typing import Annotated, Optional, TextIO

import grpc
import typer
from google.protobuf.json_format import MessageToDict, ParseDict
from more_itertools import chunked
from phonexia.grpc.technologies.transcription_normalization.v1.transcription_normalization_pb2 import (
    NormalizeConfig,
    NormalizeRequest,
    NormalizeResponse,
    Segment,
    Word,
)
from phonexia.grpc.technologies.transcription_normalization.v1.transcription_normalization_pb2_grpc import (
    TranscriptionNormalizationStub,
)


class Format(str, Enum):
    JSON = "json"
    TEXT = "text"


def read_json_segments(file: TextIO) -> Iterator[Segment]:
    for seg in json.load(file)["segments"]:
        yield ParseDict(seg, Segment())


def read_txt_segments(file: TextIO) -> Iterator[Segment]:
    for line in file:
        yield Segment(text=line.strip(), words=[Word(text=w) for w in line.strip().split()])


def make_request(
    file: TextIO,
    in_format: Optional[Format],
    language: Optional[str],
) -> Iterator[NormalizeRequest]:
    if not in_format:
        in_format = Format.JSON if Path(file.name).suffix == ".json" else Format.TEXT

    logging.debug(f"Reading {file.name} as {'json' if in_format == Format.JSON else 'txt'} format")

    segments = read_json_segments(file) if in_format == Format.JSON else read_txt_segments(file)
    for segments_chunk in chunked(segments, 1000):
        yield NormalizeRequest(segments=segments_chunk, config=NormalizeConfig(language=language))


def write_result(
    input_text: TextIO, response: NormalizeResponse, output_file: TextIO, out_format: Format
) -> None:
    """Write translation result to output file."""
    logging.info(f"{input_text.name} -> {output_file.name}")
    if out_format == Format.JSON:
        json.dump(
            MessageToDict(
                message=response,
                always_print_fields_with_no_presence=True,
                preserving_proto_field_name=True,
            ),
            output_file,
            indent=2,
            ensure_ascii=False,
        )
    else:
        for segment in response.segments:
            output_file.write(segment.text + "\n")


def normalize(
    channel: grpc.Channel,
    file: TextIO,
    in_format: Optional[Format],
    output_file: Optional[str],
    out_format: Format,
    language: Optional[str],
    metadata: Optional[list[tuple[str, str]]],
) -> None:
    logging.info(f"Normalizing '{file}'")
    stub = TranscriptionNormalizationStub(channel)  # type: ignore[no-untyped-call]
    response_it: Iterator[NormalizeResponse] = stub.Normalize(
        make_request(file, in_format=in_format, language=language),
        metadata=metadata,
    )
    for response in response_it:
        write_result(file, response, output_file, out_format)


class LogLevel(str, Enum):
    """Log levels."""

    CRITICAL = "critical"
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"
    DEBUG = "debug"


def _parse_metadata_callback(
    ctx: typer.Context, metadata_list: Optional[list[str]]
) -> list[tuple[str, str]]:
    if ctx.resilient_parsing or metadata_list is None:
        return []

    params = []
    for item in metadata_list:
        t = tuple(item.split("=", 1))
        if len(t) != 2:
            raise typer.BadParameter(f"Metadata must be in format 'KEY=VALUE': {item}")
        params.append(t)
    return params


app = typer.Typer(context_settings={"help_option_names": ["-h", "--help"]}, no_args_is_help=True)


def handle_grpc_error(e: grpc.RpcError):
    logging.error(f"gRPC call failed with status code: {e.code()}")
    logging.error(f"Error details: {e.details()}")

    if e.code() == grpc.StatusCode.UNAVAILABLE:
        logging.error("Service is unavailable.")
    elif e.code() == grpc.StatusCode.INVALID_ARGUMENT:
        logging.error("Invalid arguments were provided to the RPC.")
    elif e.code() == grpc.StatusCode.DEADLINE_EXCEEDED:
        logging.error("The RPC deadline was exceeded.")
    else:
        logging.error(f"An unexpected error occurred: {e.code()} - {e.details()}")


@app.command()
def cli(
    file: Annotated[
        typer.FileText,
        typer.Argument(
            help="Input file containing text in plain text or JSON format. The format is determined automatically "
            "based on the file extension. Alternatively, it may be forced using --in-format argument. If reading from "
            "standard input and the --in-format argument is not specified, the format is considered as plaintext."
            "Plain text format defines multiple sentences, each on a separate line. The JSON format defines a list "
            "of segments with optional per word segmentation (the output format of Phonexia speech to text technology). "
            'The JSON structure is the following: {"segments": [{"text": "text", "words": [{"text": "word"}]}]}. '
            "Additionally, segmentation timestamps (start_time and end_time) can be added to both segments and words. "
            "If omitted, the client reads text from standard input.",
            lazy=False,
        ),
    ] = "-",
    in_format: Annotated[
        Optional[Format],
        typer.Option(
            "-F",
            "--in-format",
            help="Input format (json, text).",
        ),
    ] = None,
    output: Annotated[
        typer.FileTextWrite,
        typer.Option(
            "-o",
            "--output",
            help="Output file path. If omitted, prints to stdout.",
            lazy=False,
        ),
    ] = "-",
    out_format: Annotated[
        Format,
        typer.Option(
            "-f",
            "--out-format",
            help="Output format (json, text).",
        ),
    ] = Format.JSON,
    language: Annotated[
        Optional[str],
        typer.Option(
            "--language",
            help="Language of the input text. If not specified, some of the functionality (digit conversion, etc.) "
            "will be disabled.",
        ),
    ] = None,
    host: Annotated[
        str,
        typer.Option(
            "-H",
            "--host",
            help="Server address (host:port).",
        ),
    ] = "localhost:8080",
    log_level: Annotated[
        LogLevel,
        typer.Option(
            "-l",
            "--log-level",
            help="Logging level.",
        ),
    ] = LogLevel.ERROR,
    metadata: Annotated[
        Optional[list[str]],
        typer.Option(
            "--metadata",
            metavar="KEY=VALUE",
            help="Custom client metadata.",
            show_default=False,
            callback=_parse_metadata_callback,
        ),
    ] = None,
    plaintext: Annotated[
        bool,
        typer.Option(
            "--plaintext",
            help="Use plain-text HTTP/2 when connecting to server (no TLS).",
        ),
    ] = False,
):
    """Run transcription normalization on an input audio file or standard input."""

    # Setup logging
    logging.basicConfig(
        level=log_level.upper(),
        format="[%(asctime)s.%(msecs)03d] [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    try:
        logging.info(f"Connecting to {host}")
        with (
            grpc.insecure_channel(target=host)
            if plaintext
            else grpc.secure_channel(target=host, credentials=grpc.ssl_channel_credentials())
        ) as channel:
            normalize(
                channel=channel,
                file=file,
                in_format=in_format,
                output_file=output,
                out_format=out_format,
                language=language,
                metadata=metadata,
            )

    except grpc.RpcError as e:
        handle_grpc_error(e)
        raise typer.Exit(1) from None
    except typer.Exit:
        raise
    except ValueError as e:
        logging.error(f"Invalid input: {e}")  # noqa: TRY400
        raise typer.Exit(1) from None
    except Exception:
        logging.exception("Unknown error")
        raise typer.Exit(1) from None


if __name__ == "__main__":
    app()
