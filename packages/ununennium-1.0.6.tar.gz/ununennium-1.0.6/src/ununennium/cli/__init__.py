"""CLI module."""

from ununennium.cli.main import main

__all__ = ["main"]
