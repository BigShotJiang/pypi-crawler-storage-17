"""Losses tests package."""
