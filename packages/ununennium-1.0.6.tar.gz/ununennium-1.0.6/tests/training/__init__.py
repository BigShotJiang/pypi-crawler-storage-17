"""Training tests package."""
