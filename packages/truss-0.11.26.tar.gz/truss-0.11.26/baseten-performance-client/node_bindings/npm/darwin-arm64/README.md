# `@basetenlabs/performance-client-darwin-arm64`

This is the **aarch64-apple-darwin** binary for `@basetenlabs/performance-client`
