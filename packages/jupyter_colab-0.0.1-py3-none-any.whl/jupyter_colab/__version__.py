#
# BSD 3-Clause License

"""Jupyter Colab."""

__version__ = "0.0.1"
