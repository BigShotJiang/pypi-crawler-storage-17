### pytest-embedded-serial-esp

pytest embedded service for testing espressif boards via serial ports

Extra Functionalities:

- `serial`: detect and confirm target and port by `esptool` automatically.
