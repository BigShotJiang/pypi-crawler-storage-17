"""Tests for cpap-py library"""
