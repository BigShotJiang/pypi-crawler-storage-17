# Guess the Number 🎯


Simple terminal-based number guessing game.


## Installation


```bash
pip install guess-the-number