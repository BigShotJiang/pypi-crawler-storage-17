from .game import GuessTheNumber

__all__ = ["GuessTheNumber"]
