class AWSLib():

  ...
  