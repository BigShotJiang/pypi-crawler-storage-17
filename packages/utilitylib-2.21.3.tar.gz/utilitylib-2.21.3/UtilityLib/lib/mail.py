"""
SMTP For email related tasks
With secured credentials from config

Schedule and Email Checks

Include Gmail 2FA auth, Live Mail 2FA auth solutions

Get persistent temporary email and it's content for testing through third party APIs


"""

class MailEntity():
  ...
