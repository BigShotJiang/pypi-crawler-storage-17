# MagPy

A Python bioacoustics analysis application.
