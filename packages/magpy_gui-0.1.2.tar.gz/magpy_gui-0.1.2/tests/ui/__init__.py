"""Tests for UI modules."""
