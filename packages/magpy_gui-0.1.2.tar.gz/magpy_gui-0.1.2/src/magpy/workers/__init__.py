"""MagPy workers - QThread workers for long-running operations."""
