"""Cloud Certificate Renewer - Automated HTTPS certificate renewal tool for cloud services."""  # noqa: E501

__version__ = "0.3.0-beta2"
__author__ = "analyser"
__email__ = "analyser@gmail.com"
