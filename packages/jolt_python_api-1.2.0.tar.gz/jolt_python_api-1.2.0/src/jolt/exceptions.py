class JoltException(Exception):
    """Base exception for Jolt client errors."""
    pass