from pathlib import Path

ENV_FILE = Path("applications/settings/.env")