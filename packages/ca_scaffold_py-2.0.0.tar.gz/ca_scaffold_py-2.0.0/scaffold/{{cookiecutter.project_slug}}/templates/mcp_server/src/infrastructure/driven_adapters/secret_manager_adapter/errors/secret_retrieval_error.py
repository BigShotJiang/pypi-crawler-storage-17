class SecretRetrievalError(Exception):
    """Exception raised when secret retrieval fails."""
