from pathlib import Path

ENV_FILE = Path("src/applications/config/.env.local")
