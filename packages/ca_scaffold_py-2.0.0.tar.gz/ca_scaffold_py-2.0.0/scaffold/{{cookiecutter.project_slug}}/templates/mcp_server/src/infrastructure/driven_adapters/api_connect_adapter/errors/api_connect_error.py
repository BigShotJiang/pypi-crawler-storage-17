class ApiConnectError(Exception):
    """Custom exception for API Connect-related errors."""
