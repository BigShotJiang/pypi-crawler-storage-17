from .basic_information_model import BasicInformation
from .detail_information_model import DetailInformation

__all__ = [
    "BasicInformation",
    "DetailInformation"
]
