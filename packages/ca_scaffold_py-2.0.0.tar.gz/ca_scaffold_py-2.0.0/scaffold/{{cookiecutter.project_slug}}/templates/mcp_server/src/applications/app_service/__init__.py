from src.infrastructure.entry_points.mcp.application import create_application

app = create_application()
