class AioHttpError(Exception):
    """Custom exception for aiohttp-related errors."""
