from project_generator.infrastructure.entry_points.application import create_application

app = create_application()