# This litellm integration is currently not exposed in the documentation.

from .opik_tracker import track_completion

__all__ = ["track_completion"]
