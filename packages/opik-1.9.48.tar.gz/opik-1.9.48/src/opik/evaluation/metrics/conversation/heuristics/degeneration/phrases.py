"""Phrase lists used by the conversation degeneration metric."""

DEFAULT_FALLBACK_PHRASES = [
    "i'm sorry",
    "as an ai language model",
    "i cannot",
    "i'm unable",
    "please provide",
    "i don't have access",
    "i don't understand",
    "could you please clarify",
]
