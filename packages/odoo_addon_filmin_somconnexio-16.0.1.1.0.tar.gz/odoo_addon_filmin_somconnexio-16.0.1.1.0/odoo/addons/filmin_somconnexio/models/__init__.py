from . import contract_contract
from . import contract_line
from . import crm_lead_line
from . import crm_lead
from . import ir_server_action
from . import res_partner
