API Reference
=============

.. autosummary::
   :toctree: .
   :recursive:

   mammos_analysis
   mammos_dft
   mammos_entity
   mammos_mumag
   mammos_spindynamics
   mammos_units
