Data classes
============

``fathomnet-py`` uses native Python dataclasses to model FathomNet entities.

----

.. automodule:: fathomnet.dto
    :members:
    :undoc-members:
