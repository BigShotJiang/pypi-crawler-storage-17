"""Tests for Sindri."""

