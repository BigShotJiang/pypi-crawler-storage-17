#!/bin/bash
# Script to run Sindri Docker container with test project

# Get the directory of this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SINDRI_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# Build Sindri image if not exists
if ! docker images | grep -q "sindri.*latest"; then
    echo "Building Sindri Docker image..."
    cd "$SINDRI_DIR" && docker build -t sindri:latest .
fi

# Run Sindri container with test project
echo "Running Sindri container with test project..."
docker run -it --rm \
    -v "$SCRIPT_DIR:/ws:rw" \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -w /ws \
    -e PYTHONUNBUFFERED=1 \
    sindri:latest \
    "$@"

