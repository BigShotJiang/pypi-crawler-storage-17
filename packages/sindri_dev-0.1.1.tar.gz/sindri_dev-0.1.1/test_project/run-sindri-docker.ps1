# PowerShell script to run Sindri Docker container with test project

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SindriDir = Split-Path -Parent $ScriptDir

# Build Sindri image if not exists
$imageExists = docker images sindri:latest --format "{{.Repository}}:{{.Tag}}" 2>$null
if (-not $imageExists) {
    Write-Host "Building Sindri Docker image..."
    Push-Location $SindriDir
    docker build -t sindri:latest .
    Pop-Location
}

# Run Sindri container with test project
Write-Host "Running Sindri container with test project..."
$argsString = $args -join " "
if ($argsString) {
    docker run -it --rm `
        -v "${ScriptDir}:/ws:rw" `
        -v /var/run/docker.sock:/var/run/docker.sock `
        -w /ws `
        -e PYTHONUNBUFFERED=1 `
        sindri:latest `
        $args
} else {
    docker run -it --rm `
        -v "${ScriptDir}:/ws:rw" `
        -v /var/run/docker.sock:/var/run/docker.sock `
        -w /ws `
        -e PYTHONUNBUFFERED=1 `
        sindri:latest
}

