# Test Project for Sindri

This is a test project designed to test all Sindri functionality using the Sindri Docker container.

## Features

This project includes:

- Python application with main module
- Unit tests with pytest
- Code quality tools (ruff, mypy)
- Docker support (Dockerfile, docker-compose.yml)
- Git repository
- Version management
- All Sindri command groups configured

## Usage with Sindri Docker Container

This project is designed to be used with the Sindri Docker container. The container mounts this project to `/ws` and runs Sindri commands there.

### Option 1: Using Docker Compose

```bash
# Build and run Sindri container with test project
docker-compose -f docker-compose.sindri.yml up --build

# Run specific Sindri command
docker-compose -f docker-compose.sindri.yml run --rm sindri sindri list
docker-compose -f docker-compose.sindri.yml run --rm sindri sindri run test
docker-compose -f docker-compose.sindri.yml run --rm sindri sindri run setup
```

### Option 2: Using Docker Run Scripts

**Linux/Mac:**
```bash
# Run interactive Sindri TUI
./run-sindri-docker.sh

# Run specific command
./run-sindri-docker.sh sindri list
./run-sindri-docker.sh sindri run test
./run-sindri-docker.sh sindri run setup
```

**Windows (PowerShell):**
```powershell
# Run interactive Sindri TUI
.\run-sindri-docker.ps1

# Run specific command
.\run-sindri-docker.ps1 sindri list
.\run-sindri-docker.ps1 sindri run test
.\run-sindri-docker.ps1 sindri run setup
```

### Option 3: Manual Docker Run

```bash
# First, build Sindri image from parent directory
cd ..
docker build -t sindri:latest .

# Then run with test project
cd test_project
docker run -it --rm \
    -v "$(pwd):/ws:rw" \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -w /ws \
    -e PYTHONUNBUFFERED=1 \
    sindri:latest \
    sindri

# Or run specific commands
docker run -it --rm \
    -v "$(pwd):/ws:rw" \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -w /ws \
    -e PYTHONUNBUFFERED=1 \
    sindri:latest \
    sindri list
```

## Testing Sindri Features

The project is configured to test all Sindri command groups:

- **Sindri Group**: Install commands
- **General Group**: Setup, Install
- **Quality Group**: Test, Coverage, Lint, Validate
- **Application Group**: Start, Stop, Restart, Build
- **Docker Group**: Build, Push, Build+Push, Up, Down, Restart
- **Compose Group**: Up, Down, Build, Restart
- **Git Group**: Commit, Push
- **Version Group**: Show, Bump, Tag
- **Custom Commands**: With dependencies, env vars, timeouts

## Project Structure

```
test_project/
├── test_project/              # Main application code
├── tests/                     # Test files
├── Dockerfile                 # Test project Docker image
├── docker-compose.yml         # Test project Docker Compose
├── docker-compose.sindri.yml  # Sindri container with test project
├── run-sindri-docker.sh       # Linux/Mac helper script
├── run-sindri-docker.ps1      # Windows PowerShell helper script
├── pyproject.toml             # Python project configuration
├── sindri.toml                # Sindri configuration
└── README.md                  # This file
```

## Notes

- The Sindri container mounts this project to `/ws` (working directory)
- Docker socket is mounted to enable Docker-in-Docker functionality
- All Sindri commands run inside the container with access to the test project
- The container includes Docker and Docker Compose for testing Docker-related commands

