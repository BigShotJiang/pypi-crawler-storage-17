# Quick Start Guide - Testing Sindri with Docker

This guide shows you how to quickly test Sindri functionality using the Docker container.

## Prerequisites

- Docker installed and running
- Docker Compose installed (optional, for docker-compose method)

## Quick Start

### Method 1: Using Make (Recommended)

```bash
# Build Sindri image and run interactive TUI
make run-sindri

# List all available commands
make list

# Run tests
make test

# Run setup
make setup

# Run any custom command
make run-sindri-cmd CMD="sindri run custom-echo"
```

### Method 2: Using Docker Compose

```bash
# Start interactive Sindri container
docker-compose -f docker-compose.sindri.yml up --build

# Run specific commands
docker-compose -f docker-compose.sindri.yml run --rm sindri sindri list
docker-compose -f docker-compose.sindri.yml run --rm sindri sindri run test
```

### Method 3: Using Helper Scripts

**Linux/Mac:**
```bash
./run-sindri-docker.sh
./run-sindri-docker.sh sindri list
./run-sindri-docker.sh sindri run test
```

**Windows (PowerShell):**
```powershell
.\run-sindri-docker.ps1
.\run-sindri-docker.ps1 sindri list
.\run-sindri-docker.ps1 sindri run test
```

### Method 4: Manual Docker Run

```bash
# First build Sindri image from parent directory
cd ..
docker build -t sindri:latest .
cd test_project

# Run interactive TUI
docker run -it --rm \
    -v "$(pwd):/ws:rw" \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -w /ws \
    -e PYTHONUNBUFFERED=1 \
    sindri:latest

# Run specific command
docker run -it --rm \
    -v "$(pwd):/ws:rw" \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -w /ws \
    -e PYTHONUNBUFFERED=1 \
    sindri:latest sindri list
```

## Testing Different Features

### Test Command Groups

```bash
# Quality commands
make run-sindri-cmd CMD="sindri run test"
make run-sindri-cmd CMD="sindri run cov"
make run-sindri-cmd CMD="sindri run lint"

# Application commands
make run-sindri-cmd CMD="sindri run start"
make run-sindri-cmd CMD="sindri run stop"
make run-sindri-cmd CMD="sindri run build"

# Docker commands (requires Docker socket mount)
make run-sindri-cmd CMD="sindri run docker-build"
make run-sindri-cmd CMD="sindri run docker-up"

# Git commands
make run-sindri-cmd CMD="sindri run git-commit"
make run-sindri-cmd CMD="sindri run git-push"

# Version commands
make run-sindri-cmd CMD="sindri run version-show"
make run-sindri-cmd CMD="sindri run version-bump"
```

### Test Custom Commands

```bash
# Simple command
make run-sindri-cmd CMD="sindri run custom-echo"

# Command with dependencies
make run-sindri-cmd CMD="sindri run custom-chain"

# Command with environment variables
make run-sindri-cmd CMD="sindri run custom-env"

# Command with timeout
make run-sindri-cmd CMD="sindri run custom-timeout"

# Command that fails (for error handling testing)
make run-sindri-cmd CMD="sindri run custom-fail"
```

## Troubleshooting

### Docker Socket Permission Issues (Linux)

If you get permission errors with Docker socket:
```bash
sudo chmod 666 /var/run/docker.sock
# Or add your user to docker group:
sudo usermod -aG docker $USER
# Then log out and log back in
```

### Windows Docker Socket

On Windows, Docker Desktop automatically handles the socket. The path `/var/run/docker.sock` works with Docker Desktop's WSL2 backend.

### Container Can't Find sindri.toml

Make sure you're running from the `test_project` directory and that `sindri.toml` exists there.

### Build Errors

If the Sindri image build fails:
1. Make sure you're in the parent directory when building
2. Check that `pyproject.toml` and `sindri/` directory exist in parent
3. Try: `cd .. && docker build -t sindri:latest .`

