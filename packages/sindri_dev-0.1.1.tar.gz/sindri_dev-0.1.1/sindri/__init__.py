"""Sindri - A project-configurable command palette for common dev workflows."""

__version__ = "0.1.0"

