"""Version command group."""

from sindri.commands.version.version_group import VersionGroup

__all__ = ["VersionGroup"]

