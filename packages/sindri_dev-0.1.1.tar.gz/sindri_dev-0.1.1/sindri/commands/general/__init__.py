"""General commands (setup, install, test, lint, validate, version)."""

from sindri.commands.general.general_group import GeneralGroup

__all__ = ["GeneralGroup"]
