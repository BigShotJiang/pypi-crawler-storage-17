"""PyPI command group."""

from sindri.commands.pypi.pypi_group import PyPIGroup

__all__ = ["PyPIGroup"]

