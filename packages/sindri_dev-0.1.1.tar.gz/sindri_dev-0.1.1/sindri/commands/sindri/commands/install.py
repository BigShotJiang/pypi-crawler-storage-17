"""Sindri install command for project initialization."""

import os
import stat
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict

from sindri.commands.command import Command
from sindri.runner import AsyncExecutionEngine, CommandResult


class SindriInstallCommand(Command):
    """
    Install command that sets up a new project with Sindri.
    
    Actions:
    1. Check if pyproject.toml exists, create if not
    2. Create Python wrapper script 'sindri' for easy Docker access
    3. Create .venv if not exists
    4. Install project in .venv (pip install -e .)
    """

    def __init__(self):
        super().__init__(
            command_id="sindri-install",
            title="Install",
            description="Initialize project with Sindri support",
        )

    async def execute(
        self,
        engine: AsyncExecutionEngine,
        cwd: Path,
        env: Dict[str, str],
        **kwargs: Any,
    ) -> CommandResult:
        """Execute the install command."""
        results = []

        # Step 0: Create .sindri directory if it doesn't exist
        sindri_dir = cwd / ".sindri"
        sindri_dir.mkdir(exist_ok=True)
        
        # Step 0.1: Check if sindri.toml exists, if not call init
        from sindri.config.loader import discover_config
        config_path = discover_config(cwd)
        if not config_path:
            # No config found, call init interactively
            from sindri.cli.interactive_init import interactive_init
            try:
                # Try .sindri/sindri.toml first, then root sindri.toml
                config_file_path = sindri_dir / "sindri.toml"
                interactive_init(config_file_path)
                results.append("✓ Initialized sindri config in .sindri/")
            except Exception as e:
                return CommandResult(
                    command_id=self.command_id,
                    exit_code=1,
                    error=f"Failed to initialize sindri config: {e}",
                )

        # Step 1: Check/create/update pyproject.toml
        pyproject_path = cwd / "pyproject.toml"
        if not pyproject_path.exists():
            result = await self._create_pyproject_toml(cwd, pyproject_path)
            if not result.success:
                return result
            results.append("✓ Created pyproject.toml")
        else:
            # Update existing pyproject.toml to ensure sindri is included
            from sindri.utils.pyproject_updater import update_pyproject_for_sindri
            success, error_msg = update_pyproject_for_sindri(pyproject_path)
            if not success and error_msg:
                # Non-critical error, just log it
                results.append(f"⚠ Could not update pyproject.toml: {error_msg}")
            else:
                results.append("✓ Updated pyproject.toml for Sindri")

        # Step 2: Create Python wrapper script
        wrapper_path = cwd / "sindri"
        result = await self._create_wrapper_script(cwd, wrapper_path)
        if not result.success:
            return result
        results.append("✓ Created sindri wrapper script")

        # Step 3: Create .sindri/venv if not exists
        venv_path = sindri_dir / "venv"
        if not venv_path.exists():
            result = await self._create_venv(cwd, venv_path)
            if not result.success:
                return result
            results.append("✓ Created .sindri/venv")
        else:
            results.append("✓ .sindri/venv already exists")

        # Step 4: Install project in .sindri/venv
        result = await self._install_project(cwd, venv_path)
        if not result.success:
            return result
        results.append("✓ Installed project in .sindri/venv")

        return CommandResult(
            command_id=self.command_id,
            exit_code=0,
            stdout="\n".join(results),
        )

    async def _create_pyproject_toml(
        self, cwd: Path, pyproject_path: Path
    ) -> CommandResult:
        """Create a basic pyproject.toml."""
        from sindri.utils.name_normalizer import normalize_project_name
        
        # Normalize project name to be PEP 508 compliant
        project_name = normalize_project_name(cwd.name)

        pyproject_content = f'''[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "{project_name}"
version = "0.1.0"
description = ""
requires-python = ">=3.11"
dependencies = [
    "sindri",
]

[project.scripts]
sindri = "sindri.cli.main:main"
'''

        try:
            pyproject_path.write_text(pyproject_content, encoding="utf-8")
            return CommandResult(
                command_id=self.command_id,
                exit_code=0,
                stdout="",
            )
        except Exception as e:
            return CommandResult(
                command_id=self.command_id,
                exit_code=1,
                error=f"Failed to create pyproject.toml: {e}",
            )

    async def _create_wrapper_script(
        self, cwd: Path, wrapper_path: Path
    ) -> CommandResult:
        """
        Create Python wrapper script that simplifies Docker usage.
        
        Creates a 'sindri' Python script that wraps the Docker command.
        The script is executable and can be called directly like 'python'.
        """
        # Get absolute path of current directory
        workspace_dir = str(cwd.resolve())

        # Python wrapper script content
        script_content = '''#!/usr/bin/env python3
"""Sindri wrapper script for Docker execution."""

import os
import subprocess
import sys
from pathlib import Path

# Get workspace directory (where this script is located)
SCRIPT_DIR = Path(__file__).resolve().parent
WORKSPACE_DIR = str(SCRIPT_DIR)

# Build Docker command
docker_cmd = [
    "docker",
    "run",
    "--rm",
    "-it",
    "-v", f"{WORKSPACE_DIR}:/ws",
    "sindri:latest",
] + sys.argv[1:]

# Execute Docker command
try:
    sys.exit(subprocess.run(docker_cmd, check=False).returncode)
except KeyboardInterrupt:
    sys.exit(130)
except Exception as e:
    print(f"Error: {e}", file=sys.stderr)
    sys.exit(1)
'''

        try:
            wrapper_path.write_text(script_content, encoding="utf-8")

            # Make executable on Unix
            if os.name != "nt":  # Not Windows
                wrapper_path.chmod(wrapper_path.stat().st_mode | stat.S_IEXEC)

            return CommandResult(
                command_id=self.command_id,
                exit_code=0,
                stdout="",
            )
        except Exception as e:
            return CommandResult(
                command_id=self.command_id,
                exit_code=1,
                error=f"Failed to create wrapper script: {e}",
            )

    async def _create_venv(self, cwd: Path, venv_path: Path) -> CommandResult:
        """Create Python virtual environment in .sindri/venv."""
        import asyncio

        # Ensure .sindri directory exists
        sindri_dir = venv_path.parent
        sindri_dir.mkdir(parents=True, exist_ok=True)

        try:
            process = await asyncio.create_subprocess_exec(
                sys.executable,
                "-m",
                "venv",
                str(venv_path),
                cwd=str(cwd),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            stdout, stderr = await process.communicate()

            if process.returncode != 0:
                return CommandResult(
                    command_id=self.command_id,
                    exit_code=process.returncode,
                    stderr=stderr.decode(),
                    error=f"Failed to create .sindri/venv: {stderr.decode()}",
                )

            return CommandResult(
                command_id=self.command_id,
                exit_code=0,
                stdout="",
            )
        except Exception as e:
            return CommandResult(
                command_id=self.command_id,
                exit_code=1,
                error=f"Failed to create .sindri/venv: {e}",
            )

    async def _install_project(
        self, cwd: Path, venv_path: Path
    ) -> CommandResult:
        """Install project in virtual environment."""
        import asyncio

        # Check if pyproject.toml exists
        pyproject_path = cwd / "pyproject.toml"
        if not pyproject_path.exists():
            return CommandResult(
                command_id=self.command_id,
                exit_code=1,
                error="pyproject.toml not found. Cannot install project.",
            )
        
        # Try to validate pyproject.toml dependencies before installing
        from sindri.utils.validate_dependencies import validate_pyproject_dependencies
        
        is_valid, error_msg, invalid_deps = validate_pyproject_dependencies(pyproject_path)
        if not is_valid and error_msg:
            return CommandResult(
                command_id=self.command_id,
                exit_code=1,
                error=error_msg,
            )

        try:
            # Use python -m pip instead of direct pip call for better compatibility
            python_path = venv_path / "bin" / "python"
            if not python_path.exists():
                python_path = venv_path / "Scripts" / "python.exe"
            
            if not python_path.exists():
                # Fallback to system python
                python_path = Path(sys.executable)

            process = await asyncio.create_subprocess_exec(
                str(python_path),
                "-m",
                "pip",
                "install",
                "-e",
                ".",
                cwd=str(cwd),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            stdout, stderr = await process.communicate()
            stdout_text = stdout.decode("utf-8", errors="replace")
            stderr_text = stderr.decode("utf-8", errors="replace")

            if process.returncode != 0:
                # Provide helpful error message
                error_msg = stderr_text
                if "Invalid URL" in error_msg or "InvalidRequirement" in error_msg:
                    error_msg = (
                        f"Invalid dependency URL found in pyproject.toml or requirements.txt.\n"
                        f"Please check your dependencies for malformed URLs.\n\n"
                        f"Original error:\n{stderr_text}"
                    )
                
                return CommandResult(
                    command_id=self.command_id,
                    exit_code=process.returncode,
                    stdout=stdout_text,
                    stderr=stderr_text,
                    error=error_msg,
                )

            return CommandResult(
                command_id=self.command_id,
                exit_code=0,
                stdout=stdout_text,
            )
        except Exception as e:
            return CommandResult(
                command_id=self.command_id,
                exit_code=1,
                error=f"Failed to install project: {e}",
            )

