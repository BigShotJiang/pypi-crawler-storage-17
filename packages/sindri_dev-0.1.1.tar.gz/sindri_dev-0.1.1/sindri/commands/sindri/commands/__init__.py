"""Sindri command implementations."""

from sindri.commands.sindri.commands.install import SindriInstallCommand

__all__ = ["SindriInstallCommand"]

