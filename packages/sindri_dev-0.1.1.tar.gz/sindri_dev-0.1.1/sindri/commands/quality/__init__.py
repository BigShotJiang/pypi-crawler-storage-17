"""Quality command group."""

from sindri.commands.quality.quality_group import QualityGroup

__all__ = ["QualityGroup"]

