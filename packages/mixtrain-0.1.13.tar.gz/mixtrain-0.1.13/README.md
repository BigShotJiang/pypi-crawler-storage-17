# Mixtrain

**Mixtrain** is a Python SDK and CLI for [mixtrain.ai](https://mixtrain.ai) platform.

## Installation

Using uv

```bash
uv add mixtrain
```
or if you use pip

```bash
pip install mixtrain
```

Refer to https://mixtrain.ai/docs for more details.