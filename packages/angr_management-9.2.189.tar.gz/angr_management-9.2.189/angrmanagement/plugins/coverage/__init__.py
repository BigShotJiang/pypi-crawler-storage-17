from __future__ import annotations

from .coverage import CoveragePlugin

__all__ = ["CoveragePlugin"]
