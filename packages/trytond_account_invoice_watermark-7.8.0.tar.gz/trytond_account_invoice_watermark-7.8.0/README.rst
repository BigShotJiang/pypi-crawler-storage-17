################################
Account Invoice Watermark Module
################################

The *Account Invoice Watermark Module* adds a draft or paid watermark to the
printed invoice.

.. toctree::
   :maxdepth: 2

   usage
   design
   releases
