*****
Usage
*****

.. _Setting watermark on invoice:

Setting watermark on invoice
============================

To let Tryton add the watermark on the invoices, you must set the extension of
the `Invoice Report <account_invoice:report-account.invoice>` to :abbr:`PDF
(Portable Document Format)`.
