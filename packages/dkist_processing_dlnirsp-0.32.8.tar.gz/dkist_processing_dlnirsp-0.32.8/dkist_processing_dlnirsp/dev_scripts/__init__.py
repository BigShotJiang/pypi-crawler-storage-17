"""Modules to allow easy testing of pipeline components by pipeline developers."""
