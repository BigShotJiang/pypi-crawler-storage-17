"""Tools to read dataset and ingest metadata required for science processing."""
