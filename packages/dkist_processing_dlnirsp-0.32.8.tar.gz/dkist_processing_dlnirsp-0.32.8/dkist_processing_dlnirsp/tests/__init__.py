"""Tests and manual end-to-end runner."""
