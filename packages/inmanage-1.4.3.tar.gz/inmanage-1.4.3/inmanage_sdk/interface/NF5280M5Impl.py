# -*- coding:utf-8 -*-

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from inmanage_sdk.interface.CommonM5 import CommonM5


class NF5280M5Impl(CommonM5):
    def getfru(self, client, args):
        pass

    def cpuM1(self):
        pass

    def capabilities(self):
        pass

    def powercontrolM5(self):
        pass

    def memoryM2(self):
        pass

    def none(self):
        pass

    def eventlogM1(self):
        pass
