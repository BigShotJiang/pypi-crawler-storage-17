# -*- coding:utf-8 -*-

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from inmanage_sdk.interface.CommonM5 import CommonM5


class NF5180M5Impl(CommonM5):
    def memoryM2(self):
        pass

    def capabilities(self):
        pass

    def powercontrolM2(self):
        pass
