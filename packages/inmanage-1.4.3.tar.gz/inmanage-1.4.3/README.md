# InManage
inManage is a support tool for ansible.ieisystem.inmanage

## External requirements

Circumstance instruction:
inManage relies on the Ipmitool tool.

Main steps:
* pip install inManage
* yum install ipmitool