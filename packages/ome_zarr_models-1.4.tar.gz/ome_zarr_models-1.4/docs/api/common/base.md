::: ome_zarr_models.base
