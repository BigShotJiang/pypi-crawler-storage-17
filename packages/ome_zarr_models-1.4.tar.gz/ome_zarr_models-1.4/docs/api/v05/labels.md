# Labels

::: ome_zarr_models.v05.labels
