# Image

::: ome_zarr_models.v05.image

## Multiscales metadata

::: ome_zarr_models.v05.multiscales

## Coordinate transformation metadata

::: ome_zarr_models.v05.coordinate_transformations

## Axes metadata

::: ome_zarr_models.v05.axes
