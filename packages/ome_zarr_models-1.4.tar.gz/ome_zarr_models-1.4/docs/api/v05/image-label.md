# Image Label

::: ome_zarr_models.v05.image_label

## Other types

::: ome_zarr_models.v05.image_label_types
