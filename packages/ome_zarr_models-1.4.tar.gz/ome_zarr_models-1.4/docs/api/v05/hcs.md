# High Content Screening

::: ome_zarr_models.v05.hcs

## Plate metadata

::: ome_zarr_models.v05.plate
