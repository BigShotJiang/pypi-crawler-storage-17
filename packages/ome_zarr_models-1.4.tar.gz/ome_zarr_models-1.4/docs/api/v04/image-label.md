# Image Label

::: ome_zarr_models.v04.image_label

## Other types

::: ome_zarr_models.v04.image_label_types
