"""
Common functionality between versions of the OME-Zarr specification.
"""
