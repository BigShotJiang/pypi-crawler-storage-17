class WellGroupNotFoundError(RuntimeError):
    """
    Raised if a well Zarr group is not found.
    """
