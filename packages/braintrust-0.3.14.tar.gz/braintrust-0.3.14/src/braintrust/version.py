VERSION = "0.3.14"

# this will be templated during the build
GIT_COMMIT = "dbbc1894ef31143816e5913676301261bc44aa4c"
