====================
Administrators guide
====================

This guide describes how to build and use an `Ironic Python Agent`_-based image
using the builders provided in the **ironic-python-agent-builder** project.

.. toctree::
   :maxdepth: 2

   dib

.. _Ironic Python Agent: https://docs.openstack.org/ironic-python-agent
