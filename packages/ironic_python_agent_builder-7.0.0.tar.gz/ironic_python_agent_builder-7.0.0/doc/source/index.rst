.. include:: ../../README.rst

Contents:

.. toctree::
   :maxdepth: 2

   install/index
   admin/index
   contributor/index
