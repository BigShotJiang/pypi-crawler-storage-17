=================================
Ironic Python Agent (IPA) Burn In
=================================

This element adds packages needed to run burn-in tasks
to the Ironic Python Agent (IPA) ramdisk.
