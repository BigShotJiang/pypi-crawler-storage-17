antlr4 -Dlanguage=Python3 Solidity.g4
