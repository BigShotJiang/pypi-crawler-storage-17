Solidity Domain for Sphinx
==========================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   formatting
   autodoc
   xrefs

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
