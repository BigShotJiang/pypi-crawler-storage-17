'''
GKBus: High level automotive protocol library
'''

__version__ = '0.4.85'

__all__ = ['__version__']
