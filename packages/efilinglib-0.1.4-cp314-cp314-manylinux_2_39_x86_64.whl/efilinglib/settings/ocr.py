from ..old.info import ArchiveCode

ocr_settings = {
    ArchiveCode.A163: {
       r'{http://www.jpo.go.jp}foreign-language-body':{
           'lang': 'eng',
           'pattern': '*-large.webp',
       }
    }    
}
