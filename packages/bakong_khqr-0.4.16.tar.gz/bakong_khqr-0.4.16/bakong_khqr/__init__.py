from .khqr import KHQR

__all__ = ["KHQR"]