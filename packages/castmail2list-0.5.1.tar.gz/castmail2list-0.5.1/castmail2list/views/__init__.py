"""Global constants"""

from importlib.metadata import version

__version__ = version("castmail2list")
