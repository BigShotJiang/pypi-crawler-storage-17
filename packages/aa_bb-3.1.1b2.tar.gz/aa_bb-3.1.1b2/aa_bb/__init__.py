"""Initialize the app"""

__version__ = "3.1.1b2"
__title__ = "BigBrother"
