"""
Word template engine implemented with python-docx + lxml helpers.
Features:
- Text placeholders {{data.field}}
- Table row loops {{#data.list}} with [field] inside row
- Conditional blocks {{?cond}}...{{/}}
- Image placeholders {{@var}}
"""
import tempfile
import shutil
from typing import Any, Dict
from docx import Document

from utils.text_processor import (
    process_paragraph,
    process_paragraph_blocks,
    process_paragraph_loops,
)
from utils.table_processor import process_table
from utils.image_processor import process_paragraph_images


class WordTemplateEngine:
    def __init__(self, template_path: str):
        self.template_path = template_path

    def render(self, data: Dict[str, Any], output_path: str) -> None:
        # work in temp copy to avoid mutating original
        with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tmp:
            shutil.copyfile(self.template_path, tmp.name)
            tmp_path = tmp.name

        doc = Document(tmp_path)

        # process tables (row loops + inner placeholders)
        for table in doc.tables:
            process_table(table, data)
            for row in table.rows:
                for cell in row.cells:
                    # handle paragraph-level loops and blocks in cells
                    process_paragraph_loops(cell.paragraphs, data)
                    process_paragraph_blocks(cell.paragraphs, data)
                    for para in cell.paragraphs:
                        process_paragraph(para, data)
                        process_paragraph_images(para, data)

        # process body paragraphs: loops -> blocks -> placeholders/images
        process_paragraph_loops(doc.paragraphs, data)
        process_paragraph_blocks(doc.paragraphs, data)
        for para in doc.paragraphs:
            process_paragraph(para, data)
            process_paragraph_images(para, data)

        doc.save(output_path)


def main():
    sample_data = {
        "data": {
            "diagnose": "测试诊断结果",
            "mutationSiteZero": [
                {"gene_transcript": "BRCA1", "value": "c.1234A>G"},
                {"gene_transcript": "TP53", "value": "c.5678C>T"},
            ],
            "conclusion_A": "",
            "image_config": {
                "url": "123.png",
                
            },
            "detectionResult":{
                'data1':[
                {
                "gene":"gene1",
                'rate':'rate1',
                'age':'age1',
                'symptoms':'symptoms1'
            },
            {
                "gene":"gene2",
                'rate':'rate1',
                'age':'age2',
                'symptoms':'symptoms1'
            }
            ],'data2':[
                {
                "gene":"gene3",
                'rate':'rate3',
                'age':'age3',
                'symptoms':'symptoms3'
            }
            ]
            }
        }
    }
    engine = WordTemplateEngine("template.docx")
    engine.render(sample_data, "output.docx")
    print("done")


if __name__ == "__main__":
    main()

