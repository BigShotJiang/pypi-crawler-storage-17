.. index:: core_init
.. _core_init:



Core Init
=========

.. automodule:: iceprod.core