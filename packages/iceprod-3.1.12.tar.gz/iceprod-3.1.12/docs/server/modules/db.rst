.. index:: dbmodule
.. _dbmodule:

Database Module
===============

.. automodule:: iceprod.server.modules.db
   :exclude-members: tables
   