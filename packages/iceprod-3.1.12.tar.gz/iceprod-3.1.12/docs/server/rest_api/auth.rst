REST API - Auth
===============

.. automodule:: iceprod.rest.handlers.auth
