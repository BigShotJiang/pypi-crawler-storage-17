REST API - Pilots
=================

.. automodule:: iceprod.rest.handlers.pilots
