from ..grid import BaseGrid


class Grid(BaseGrid):
    pass
