"""It's the version"""

__version__ = "25.12.16"
