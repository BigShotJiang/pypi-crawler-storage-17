=========
License
=========

``notify-rs`` is licensed under the :choosealicense:`MIT`

.. license-info:: MIT

.. license::
	:py: notify-rs
