====================
:mod:`notify_rs`
====================

.. automodule:: notify_rs

.. TODO:: get annotations from type stubs
