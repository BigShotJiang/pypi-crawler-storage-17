#######################
European Account Module
#######################

The *European Account Module* adds common accounting requirements for European
countries.

.. toctree::
   :maxdepth: 2

   design
   releases
