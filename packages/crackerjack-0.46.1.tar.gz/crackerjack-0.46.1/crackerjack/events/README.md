> Crackerjack Docs: [Main](../../README.md) | [Crackerjack Package](../README.md) | [Events](./README.md)

# Events

Event types, signals, and dispatch-related helpers.

## Related

- [Crackerjack Package](../README.md) - Parent package
- [Monitoring](../monitoring/README.md) - Observability and metrics
- [Core Coordinators](../core/README.md) - Event coordination and orchestration (phase_coordinator, autofix_coordinator, session_coordinator)
