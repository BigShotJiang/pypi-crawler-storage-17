#define KML_NEWLINE                      1
#define KML_END                          2
#define KML_CLOSE                        3
#define KML_OPEN                         4
#define KML_KEYWORD                      5
#define KML_EQ                           6
#define KML_VALUE                        7
#define KML_COORD                        8
