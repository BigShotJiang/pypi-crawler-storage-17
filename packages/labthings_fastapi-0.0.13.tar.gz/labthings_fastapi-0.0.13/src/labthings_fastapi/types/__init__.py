"""Types for use with LabThings.

This module is intended to contain a range of types used by LabThings-FastAPI.
Currently, it only contains an annotated-type work-around for making `numpy`
arrays serialisable with `pydantic`.
"""
