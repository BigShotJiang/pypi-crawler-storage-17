## Quraite Python SDK

### Publishing to Test PyPI

```bash
make update-version v=0.4.0
make build
make publish-test-pypi # enter user name as "__token__" and then enter the key
```