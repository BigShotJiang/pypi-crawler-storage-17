Sky Map Plotting (`ligo.skymap.plot.allsky`)
============================================

.. automodule:: ligo.skymap.plot.allsky
    :members: AutoScaledWCSAxes
    :show-inheritance:
