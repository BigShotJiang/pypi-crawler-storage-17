Command Line Interface Support (`ligo.skymap.tool`)
===================================================

.. automodule:: ligo.skymap.tool
    :members:
    :show-inheritance:
