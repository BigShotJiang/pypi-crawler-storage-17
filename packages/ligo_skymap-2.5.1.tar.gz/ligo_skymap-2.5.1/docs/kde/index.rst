Kernel Density Estimation (`ligo.skymap.kde`)
=============================================

.. automodule:: ligo.skymap.kde
    :members:
    :show-inheritance:
