Multi-Order HEALPix Maps (`ligo.skymap.moc`)
============================================

.. automodule:: ligo.skymap.moc
.. autofunction:: nest2uniq
.. autofunction:: uniq2nest
.. autofunction:: uniq2order
.. autofunction:: uniq2pixarea
.. autofunction:: rasterize
.. autofunction:: bayestar_adaptive_grid
