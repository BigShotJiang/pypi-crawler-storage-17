Fire-and-Forget MCMC Sampling (`ligo.skymap.bayestar.ez_emcee`)
===============================================================

.. automodule:: ligo.skymap.bayestar.ez_emcee
    :members:
    :show-inheritance:
