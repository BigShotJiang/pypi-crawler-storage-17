# Typed Blofin

> A fully typed, validated async client for the Blofin API

Use *autocomplete* instead of documentation.

🚧 Under construction.