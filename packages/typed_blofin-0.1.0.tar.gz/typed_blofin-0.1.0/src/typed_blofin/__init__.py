"""
### Typed Blofin
> A fully typed, validated async client for the Blofin API

- Details
"""