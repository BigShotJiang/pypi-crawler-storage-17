# Backwards compatibility alias - 'date' re-exports everything from 'opendate'
from opendate import *
from opendate import __version__, __all__
