::: cattle_grid.extensions.examples.cache
    options:
        heading_level: 1
        show_submodules: true
