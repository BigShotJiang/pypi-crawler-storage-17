# Command line tool

::: mkdocs-click
    :module: cattle_grid.extensions.__main__
    :command: main
    :prog_name: python -m cattle_grid.extensions
    :depth: 1
    :list_subcommands: True
    :style: table
