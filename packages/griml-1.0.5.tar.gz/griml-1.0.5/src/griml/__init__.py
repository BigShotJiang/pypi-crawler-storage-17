from importlib.metadata import version

__version__ = version("griml")  # Replace with your actual package name
