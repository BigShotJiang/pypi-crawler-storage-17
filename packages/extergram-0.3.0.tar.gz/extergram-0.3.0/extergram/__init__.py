# extergram/__init__.py

from .core import Bot
from .ui import ButtonsDesign
from .utils import Markdown, escape_markdown_v2
from .api_types import Message, CallbackQuery # <<< ИЗМЕНЕНИЕ ЗДЕСЬ

__version__ = "0.3.0"
__author__ = "Ваше Имя"
__email__ = "ваш@email.com"

__all__ = [
    "Bot",
    "ButtonsDesign",
    "Markdown",
    "escape_markdown_v2",
    "Message",
    "CallbackQuery"
]