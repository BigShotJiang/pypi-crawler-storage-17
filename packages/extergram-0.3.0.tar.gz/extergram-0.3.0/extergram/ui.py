# extergram/ui.py

class ButtonsDesign:
    """
    Конструктор для создания встроенных клавиатур.
    """
    def __init__(self, inline_keyboard: list = None):
        self.keyboard = inline_keyboard if inline_keyboard else []

    def add_row(self, *buttons):
        """
        Добавляет ряд кнопок в клавиатуру.
        """
        self.keyboard.append(list(buttons))
        return self

    def to_dict(self):
        """
        Возвращает клавиатуру в виде словаря для API.
        """
        return {"inline_keyboard": self.keyboard}

    @staticmethod
    def create_button(text: str, callback_data: str):
        """
        Создает кнопку для встроенной клавиатуры.
        """
        return {"text": text, "callback_data": callback_data}```

**3. `extergram/utils.py`**

Здесь будут находиться вспомогательные функции, например, для экранирования Markdown.

```python
# extergram/utils.py

import re

def escape_markdown_v2(text: str) -> str:
    """
    Экранирует специальные символы для MarkdownV2.
    """
    escape_chars = r'_*[]()~`>#+-=|{}.!'
    return re.sub(f'([{re.escape(escape_chars)}])', r'\\\1', text)

class Markdown:
    """
    Класс для работы с форматированием MarkdownV2.
    """
    @staticmethod
    def bold(text: str) -> str:
        """
        Форматирует текст жирным шрифтом.
        """
        return f"*{escape_markdown_v2(text)}*"

    @staticmethod
    def italic(text: str) -> str:
        """
        Форматирует текст курсивом.
        """
        return f"_{escape_markdown_v2(text)}_"

    @staticmethod
    def code(text: str) -> str:
        """
        Форматирует текст как встроенный код.
        """
        return f"`{escape_markdown_v2(text)}`"

    @staticmethod
    def pre(text: str, language: str = "") -> str:
        """
        Форматирует текст как блок с кодом.
        """
        return f"```{language}\n{escape_markdown_v2(text)}\n```"

    @staticmethod
    def link(text: str, url: str) -> str:
        """
        Создает гиперссылку.
        """
        return f"[{escape_markdown_v2(text)}]({url})"