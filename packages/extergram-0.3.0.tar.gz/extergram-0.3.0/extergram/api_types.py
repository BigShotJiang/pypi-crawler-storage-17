# extergram/api_types.py

class User:
    def __init__(self, data: dict):
        self.id = data.get('id')
        self.is_bot = data.get('is_bot')
        self.first_name = data.get('first_name')
        self.last_name = data.get('last_name')
        self.username = data.get('username')

class Chat:
    def __init__(self, data: dict):
        self.id = data.get('id')
        self.type = data.get('type')
        self.title = data.get('title')
        self.username = data.get('username')
        self.first_name = data.get('first_name')

class Message:
    def __init__(self, data: dict):
        self.message_id = data.get('message_id')
        self.from_user = User(data['from']) if 'from' in data else None
        self.chat = Chat(data['chat']) if 'chat' in data else None
        self.date = data.get('date')
        self.text = data.get('text')

class CallbackQuery:
    def __init__(self, data: dict):
        self.id = data.get('id')
        self.from_user = User(data['from']) if 'from' in data else None
        self.message = Message(data['message']) if 'message' in data else None
        self.data = data.get('data')

class Update:
    def __init__(self, data: dict):
        self.update_id = data.get('update_id')
        self.message = Message(data['message']) if 'message' in data else None
        self.callback_query = CallbackQuery(data['callback_query']) if 'callback_query' in data else None