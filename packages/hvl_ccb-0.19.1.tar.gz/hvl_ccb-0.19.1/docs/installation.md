```{include} ../INSTALLATION.md
:relative-docs: docs/
:relative-images:
