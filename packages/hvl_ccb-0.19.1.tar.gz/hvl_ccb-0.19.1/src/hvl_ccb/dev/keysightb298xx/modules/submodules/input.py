#  Copyright (c) ETH Zurich, SIS ID and HVL D-ITET
#
import logging

from hvl_ccb.dev.keysightb298xx.comm import KeysightB2985AVisaCommunication
from hvl_ccb.dev.keysightb298xx.modules.submodules.base import _BaseModule
from hvl_ccb.utils.validation import validate_bool

logger = logging.getLogger(__name__)


class _CurrentInput(_BaseModule):
    """
    Class providing access to the settings of the current input.
    """

    def __init__(self, com: KeysightB2985AVisaCommunication) -> None:
        super().__init__(com, ":INP", "input")

    @property
    def is_enabled(self) -> bool:
        """
        Get the state of the input.

        :return: True if the input is enabled, False otherwise.
        """
        return bool(int(self._com.query(f"{self._base_command}:STAT?")))

    @is_enabled.setter
    def is_enabled(self, value: bool) -> None:
        """
        Set the state of the input.

        :param value: True to enable the input, False to disable it.
        """
        validate_bool("input enabled", value, logger)
        logger.info(f"Input enabled: {value}")
        self._com.write(f"{self._base_command}:STAT {int(value)}")

    @property
    def is_zero_corrected(self) -> bool:
        """
        Get the state of the zero correction.

        :return: True if zero correction is enabled, False otherwise.
        """
        return bool(int(self._com.query(f"{self._base_command}:ZCOR:STAT?")))

    @is_zero_corrected.setter
    def is_zero_corrected(self, value: bool) -> None:
        """
        Set the state of the zero correction.

        :param value: True to enable zero correction, False to disable it.
        """
        validate_bool("zero correction", value, logger)
        logger.info(f"Input zero corrected: {value}")
        self._com.write(f"{self._base_command}:ZCOR:STAT {int(value)}")
