#  Copyright (c) ETH Zurich, SIS ID and HVL D-ITET
#
import logging

from aenum import StrEnum

from hvl_ccb.dev.keysightb298xx.comm import KeysightB2985AVisaCommunication
from hvl_ccb.dev.keysightb298xx.modules.submodules.base import _BaseModule

logger = logging.getLogger(__name__)


class FormatElements(StrEnum):
    """
    Enum for the different format elements that can be included in the output buffer.
    """

    VOLTAGE = "VOLT"
    CURRENT = "CURR"
    CHARGE = "CHAR"
    RESISTANCE = "RES"
    TIME = "TIME"
    STATUS = "STAT"
    SOURCE = "SOUR"
    TEMPERATURE = "TEMP"
    HUMIDITY = "HUM"


class _Format(_BaseModule):
    """
    Class providing access to the format the output buffer.
    """

    def __init__(self, com: KeysightB2985AVisaCommunication) -> None:
        super().__init__(com, ":FORM", "format")

    @property
    def format(self) -> list[FormatElements]:
        """
        Get the format of the output buffer.

        :return: list of format elements
        """
        answer_list = self._com.query(f"{self._base_command}:ELEM:SENS?").split(",")
        return [FormatElements(x) for x in answer_list]

    @format.setter
    def format(self, value: list[FormatElements]) -> None:
        """
        Set the format of the output buffer.

        :param value: list of format elements
        """
        format_string = ",".join(FormatElements(x) for x in value)
        logger.info(f"Data format: {value}")
        self._com.write(f"{self._base_command}:ELEM:SENS {format_string}")
