#  Copyright (c) ETH Zurich, SIS ID and HVL D-ITET
#
import logging
from abc import ABC, abstractmethod

from bitstring import BitArray

from hvl_ccb.dev.keysightb298xx.comm import (
    KeysightB2985AVisaCommunication,
    KeysightB2985AVisaCommunicationError,
)
from hvl_ccb.dev.keysightb298xx.modules.submodules.base import _BaseModule

logger = logging.getLogger(__name__)


class _StatusRegisterSmall(_BaseModule, ABC):
    """
    Base class providing functionality for a 8 bit long register
    with its condition and forward enabling.
    """

    def __init__(
        self, com: KeysightB2985AVisaCommunication, base_command: str, name: str
    ) -> None:
        super().__init__(com, base_command, name)

        self._length: int = 8

    @property
    @abstractmethod
    def condition(self) -> BitArray: ...

    @property
    def enable(self) -> BitArray:
        answer = BitArray(
            length=self._length,
            uint=int(self._com.query(f"{self._base_command}E?")),
        )
        answer.reverse()
        return answer

    @enable.setter
    def enable(self, val: BitArray) -> None:
        val.reverse()
        value = val.uint
        logger.info(f"Set {self._name} enable register to: {value}")
        self._com.write(f"{self._base_command}E {value}")

    def _manipulate_register(self, register: property, pos: int, val: bool) -> None:
        old_values = register.fget(self)  # type: ignore[misc]

        new_values: BitArray = old_values

        new_values[pos] = val

        register.fset(self, new_values)  # type: ignore[misc]


class _StatusBitSmallRegister:
    """
    Class to summarize a status bit with en event bit and a forward enable bit.
    """

    def __init__(self, register: _StatusRegisterSmall, bit: int) -> None:
        self._register = register
        self._bit = bit

    @property
    def condition(self) -> bool:
        """
        Get the condition of a status bit.

        :return: True if the status bit is set, False otherwise.
        """
        return self._register.condition[self._bit]

    @property
    def enable(self) -> bool:
        """
        Get the state of the forward enable bit.

        :return: True if the enable bit is enabled, False otherwise.
        """
        return self._register.enable[self._bit]

    @enable.setter
    def enable(self, val: bool) -> None:
        """
        Set the state of the forward enable bit.

        :param val: True to enable the forward enable bit, False to disable it.
        """
        self._register._manipulate_register(
            register=_StatusRegisterSmall.enable,  # type: ignore[arg-type]
            pos=self._bit,
            val=val,
        )


class _StatusRegisterFull(_StatusRegisterSmall):
    """
    Class providing functionality for a 16 bit long register
    with a status, a negative and positive transition filter,
    a event register and forward enabling register.
    """

    def __init__(
        self, com: KeysightB2985AVisaCommunication, base_command: str, name: str
    ) -> None:
        super().__init__(com, base_command, name)
        self._length: int = 16

    @property
    def condition(self) -> BitArray:
        """
        Get the condition of the status register.

        :return: The condition bits.
        """
        answer = BitArray(
            length=self._length,
            uint=int(self._com.query(f"{self._base_command}:COND?")),
        )
        answer.reverse()
        return answer

    @property
    def enable(self) -> BitArray:
        """
        Get the state of the forward enable register.

        :return: The enable bits.
        """
        answer = BitArray(
            length=self._length,
            uint=int(self._com.query(f"{self._base_command}:ENAB?")),
        )
        answer.reverse()
        return answer

    @enable.setter
    def enable(self, val: BitArray) -> None:
        """
        Set the state of the forward enable register.

        :param val: The enable bits to set.
        """
        val.reverse()
        value = val.uint
        logger.info(f"Set {self._name} enable register to: {value}")
        self._com.write(f"{self._base_command}:ENAB {value}")

    @property
    def event(self) -> BitArray:
        """
        Get the state of the event register.

        :return: The event bits.
        """
        answer = BitArray(
            length=self._length,
            uint=int(self._com.query(f"{self._base_command}:EVEN?")),
        )
        answer.reverse()
        return answer

    @property
    def transition_pos(self) -> BitArray:
        """
        Get the state of the positive transition register.

        :return: The positive transition bits.
        """
        answer = BitArray(
            length=self._length,
            uint=int(self._com.query(f"{self._base_command}:PTR?")),
        )
        answer.reverse()
        return answer

    @transition_pos.setter
    def transition_pos(self, val: BitArray) -> None:
        """
        Set the state of the positive transition register.

        :param val: The positive transition bits to set.
        """
        val.reverse()
        value = val.uint
        logger.info(f"Set {self._name} positive transition register to: {value}")
        self._com.write(f"{self._base_command}:PTR {value}")

    @property
    def transition_neg(self) -> BitArray:
        """
        Get the state of the negative transition register.

        :return: The negative transition bits.
        """
        answer = BitArray(
            length=self._length,
            uint=int(self._com.query(f"{self._base_command}:NTR?")),
        )
        answer.reverse()
        return answer

    @transition_neg.setter
    def transition_neg(self, val: BitArray) -> None:
        """
        Set the state of the negative transition register.

        :param val: The negative transition bits to set.
        """
        val.reverse()
        value = val.uint
        logger.info(f"Set {self._name} negative transition register to: {value}")
        self._com.write(f"{self._base_command}:NTR {value}")


class _StatusBitFullRegister(_StatusBitSmallRegister):
    """
    Class to summarize a status bit with a status, a negative and positive
    transition filter, a event and forward enabling.
    """

    def __init__(self, register: _StatusRegisterFull, bit: int) -> None:
        self._register: _StatusRegisterFull = register
        self._bit = bit

    @property
    def enable(self) -> bool:
        """
        Get the state of a forward enable bit.

        :return: The forward enable bit.
        """
        return super().enable

    @enable.setter
    def enable(self, val: bool) -> None:
        """
        Set the state of a forward enable bit.

        :param val: The forward enable bit to set.
        """
        self._register._manipulate_register(
            register=_StatusRegisterFull.enable,  # type: ignore[arg-type]
            pos=self._bit,
            val=val,
        )

    @property
    def event(self) -> bool:
        """
        Get the state of a event bit.

        :return: The event bit.
        """
        return self._register.event[self._bit]

    @property
    def transition_pos(self) -> bool:
        """
        Get the state of a positive transition bit.

        :return: The positive transition bit.
        """
        return self._register.transition_pos[self._bit]

    @transition_pos.setter
    def transition_pos(self, val: bool) -> None:
        """
        Set the state of a positive transition bit.

        :param val: The positive transition bit to set.
        """
        self._register._manipulate_register(
            register=_StatusRegisterFull.transition_pos,  # type: ignore[arg-type]
            pos=self._bit,
            val=val,
        )

    @property
    def transition_neg(self) -> bool:
        """
        Get the state of a negative transition bit.

        :return: The negative transition bit.
        """
        return self._register.transition_neg[self._bit]

    @transition_neg.setter
    def transition_neg(self, val: bool) -> None:
        """
        Set the state of a negative transition bit.

        :param val: The negative transition bit to set.
        """
        self._register._manipulate_register(
            register=_StatusRegisterFull.transition_neg,  # type: ignore[arg-type]
            pos=self._bit,
            val=val,
        )


class _MeasStatusRegister(_StatusRegisterFull):
    """
    Implementation of the measurement status register.

    """

    def __init__(self, com: KeysightB2985AVisaCommunication) -> None:
        super().__init__(com, base_command=":STAT:MEAS", name="measurement_status")
        self._limit_test_summary = _StatusBitFullRegister(self, 0)
        self._sample_buffer_available = _StatusBitFullRegister(self, 1)
        self._sample_buffer_full = _StatusBitFullRegister(self, 2)
        self._trace_buffer_available = _StatusBitFullRegister(self, 3)
        self._trace_buffer_full = _StatusBitFullRegister(self, 4)

    @property
    def limit_test_summary(self) -> _StatusBitFullRegister:
        return self._limit_test_summary

    @property
    def sample_buffer_available(self) -> _StatusBitFullRegister:
        return self._sample_buffer_available

    @property
    def sample_buffer_full(self) -> _StatusBitFullRegister:
        return self._sample_buffer_full

    @property
    def trace_buffer_available(self) -> _StatusBitFullRegister:
        return self._trace_buffer_available

    @property
    def trace_buffer_full(self) -> _StatusBitFullRegister:
        return self._trace_buffer_full


class _QuesStatusRegister(_StatusRegisterFull):
    """
    Implementation of the questionable status register.

    """

    def __init__(self, com: KeysightB2985AVisaCommunication) -> None:
        super().__init__(com, base_command=":STAT:QUES", name="questionable_status")
        self._over_temperature = _StatusBitFullRegister(self, 4)
        self._calibration_result = _StatusBitFullRegister(self, 8)
        self._interlock_open = _StatusBitFullRegister(self, 10)
        self._transient_event_lost = _StatusBitFullRegister(self, 11)
        self._acquire_event_lost = _StatusBitFullRegister(self, 12)

    @property
    def over_temperature(self) -> _StatusBitFullRegister:
        return self._over_temperature

    @property
    def calibration_result(self) -> _StatusBitFullRegister:
        return self._calibration_result

    @property
    def interlock_open(self) -> _StatusBitFullRegister:
        return self._interlock_open

    @property
    def transient_event_lost(self) -> _StatusBitFullRegister:
        return self._transient_event_lost

    @property
    def acquire_event_lost(self) -> _StatusBitFullRegister:
        return self._acquire_event_lost


class _OperStatusRegister(_StatusRegisterFull):
    """
    Implementation of the operation status register.

    """

    def __init__(self, com: KeysightB2985AVisaCommunication) -> None:
        super().__init__(com, base_command=":STAT:OPER", name="operation_status")
        self._test_running = _StatusBitFullRegister(self, 0)
        self._transition_idle = _StatusBitFullRegister(self, 1)
        self._wait_for_transition_trigger = _StatusBitFullRegister(self, 2)
        self._wait_for_transition_arm = _StatusBitFullRegister(self, 3)
        self._acquisition_idle = _StatusBitFullRegister(self, 4)
        self._wait_for_acquisition_trigger = _StatusBitFullRegister(self, 5)
        self._wait_for_acquisition_arm = _StatusBitFullRegister(self, 6)
        self._instrument_locked = _StatusBitFullRegister(self, 13)
        self._program_running = _StatusBitFullRegister(self, 14)

    @property
    def test_running(self) -> _StatusBitFullRegister:
        return self._test_running

    @property
    def transition_idle(self) -> _StatusBitFullRegister:
        return self._transition_idle

    @property
    def wait_for_transition_trigger(self) -> _StatusBitFullRegister:
        return self._wait_for_transition_trigger

    @property
    def wait_for_transition_arm(self) -> _StatusBitFullRegister:
        return self._wait_for_transition_arm

    @property
    def acquisition_idle(self) -> _StatusBitFullRegister:
        return self._acquisition_idle

    @property
    def wait_for_acquisition_trigger(self) -> _StatusBitFullRegister:
        return self._wait_for_acquisition_trigger

    @property
    def wait_for_acquisition_arm(self) -> _StatusBitFullRegister:
        return self._wait_for_acquisition_arm

    @property
    def instrument_locked(self) -> _StatusBitFullRegister:
        return self._instrument_locked

    @property
    def program_running(self) -> _StatusBitFullRegister:
        return self._program_running


class _StandardEventRegister(_StatusRegisterSmall):
    """
    Implementation of the standard event register.

    """

    def __init__(self, com: KeysightB2985AVisaCommunication) -> None:
        super().__init__(com, base_command="*ES", name="standard_event")
        self._operation_complete = _StatusBitSmallRegister(self, 0)
        self._query_error = _StatusBitSmallRegister(self, 2)
        self._device_error = _StatusBitSmallRegister(self, 3)
        self._execution_error = _StatusBitSmallRegister(self, 4)
        self._command_error = _StatusBitSmallRegister(self, 5)
        self._power_on = _StatusBitSmallRegister(self, 7)

    def _manipulate_register(self, register: property, pos: int, val: bool) -> None:  # noqa: ARG002
        msg = "Register configuration cannot be changed"
        raise KeysightB2985AVisaCommunicationError(msg)

    @property
    def condition(self) -> BitArray:
        msg = "This register does not hold any information"
        raise KeysightB2985AVisaCommunicationError(msg)

    @property
    def operation_complete(self) -> _StatusBitSmallRegister:
        return self._operation_complete

    @property
    def query_error(self) -> _StatusBitSmallRegister:
        return self._query_error

    @property
    def device_error(self) -> _StatusBitSmallRegister:
        return self._device_error

    @property
    def execution_error(self) -> _StatusBitSmallRegister:
        return self._execution_error

    @property
    def command_error(self) -> _StatusBitSmallRegister:
        return self._command_error

    @property
    def power_on(self) -> _StatusBitSmallRegister:
        return self._power_on


class _StatusSummary(_StatusRegisterSmall):
    """
    Status summary register.
    """

    def __init__(self, com: KeysightB2985AVisaCommunication) -> None:
        super().__init__(com, "*SR", "status_summary")

        self._condition: BitArray = BitArray(
            length=self._length,
            uint=0,
        )

        self._measurement_status = _StatusBitSmallRegister(self, 0)
        self._error_queue = _StatusBitSmallRegister(self, 2)
        self._questionable_status = _StatusBitSmallRegister(self, 3)
        self._output_buffer = _StatusBitSmallRegister(self, 4)
        self._standard_event_status = _StatusBitSmallRegister(self, 5)
        self._summary = _StatusBitSmallRegister(self, 6)
        self._operation_status = _StatusBitSmallRegister(self, 7)

    def update_status(self) -> None:
        answer = BitArray(
            length=self._length,
            uint=int(self._com.spoll()),
        )
        answer.reverse()
        self._condition = answer

    @property
    def condition(self) -> BitArray:
        return self._condition

    @property
    def measurement_status(self) -> _StatusBitSmallRegister:
        return self._measurement_status

    @property
    def error_queue(self) -> _StatusBitSmallRegister:
        return self._error_queue

    @property
    def questionable_status(self) -> _StatusBitSmallRegister:
        return self._questionable_status

    @property
    def output_buffer(self) -> _StatusBitSmallRegister:
        return self._output_buffer

    @property
    def standard_event_status(self) -> _StatusBitSmallRegister:
        return self._standard_event_status

    @property
    def summary(self) -> _StatusBitSmallRegister:
        return self._summary

    @property
    def operation_status(self) -> _StatusBitSmallRegister:
        return self._operation_status
