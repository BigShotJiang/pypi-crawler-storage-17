#  Copyright (c) ETH Zurich, SIS ID and HVL D-ITET
#
import logging

from aenum import StrEnum

from hvl_ccb.dev.keysightb298xx.modules.submodules.base import _BaseModule
from hvl_ccb.utils.validation import validate_bool

logger = logging.getLogger(__name__)


class OffMode(StrEnum):
    """
    Enum for the different output off modes.
    """

    NORMAL = "NORM"
    ZERO = "ZERO"
    HIZ = "HIZ"


class LowPotential(StrEnum):
    """
    Enum for the different low potential modes.
    """

    FLOATING = "FLO"
    ON_COMMON = "COMM"


class _OutputBase(_BaseModule):
    """
    Base class for the output module.
    """

    @property
    def is_enabled(self) -> bool:
        """
        Get the state of the output.

        :return: True if the output is enabled, False otherwise.
        """
        return bool(int(self._com.query(f"{self._base_command}:STAT?")))

    @is_enabled.setter
    def is_enabled(self, value: bool) -> None:
        """
        Set the state of the output.

        :param value: True to enable the output, False to disable it.
        """
        validate_bool("output", value, logger)
        logger.info(f"Output activated: {value}")
        self._com.write(f"{self._base_command}:STAT {int(value)}")

    @property
    def off_mode(self) -> OffMode:
        """
        Get the off mode of the output.

        :return: The off mode.
        """
        return OffMode(self._com.query(f"{self._base_command}:OFF:MODE?"))

    @off_mode.setter
    def off_mode(self, value: OffMode) -> None:
        """
        Set the off mode of the output.

        :param value: The off mode to set.
        """
        value = OffMode(value)
        logger.info(f"Output off mode: {value}")
        self._com.write(f"{self._base_command}:OFF:MODE {value}")

    @property
    def low_potential(self) -> LowPotential:
        """
        Get the low potential mode of the output.

        :return: The low potential mode.
        """
        return LowPotential(self._com.query(f"{self._base_command}:LOW?"))

    @low_potential.setter
    def low_potential(self, value: LowPotential) -> None:
        """
        Set the low potential mode of the output.

        :param value: The low potential mode to set.
        """
        value = LowPotential(value)
        logger.info(f"Output low potential: {value}")
        self._com.write(f"{self._base_command}:LOW {value}")
