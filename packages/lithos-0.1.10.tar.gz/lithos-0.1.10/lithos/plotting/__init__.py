from .plot_class import CategoricalPlot, LinePlot
