from .categorical_class import CategoricalPlot
from .line_class import LinePlot
