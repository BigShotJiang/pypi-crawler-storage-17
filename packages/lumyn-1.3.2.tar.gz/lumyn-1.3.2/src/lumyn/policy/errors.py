class PolicyError(ValueError):
    pass
