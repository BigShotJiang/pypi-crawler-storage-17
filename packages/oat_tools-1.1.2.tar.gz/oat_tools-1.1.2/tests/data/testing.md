# This

This is a [^foo] markdown file. [^kissa]


[^kissa]: This is a footnote.
[^marsu]: This is another footnote.