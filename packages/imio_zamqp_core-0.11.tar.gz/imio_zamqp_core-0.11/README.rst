.. contents::

Introduction
============

Generic methods to use amqp
