"""Entry point for python -m mcp_airflow_api execution."""
from .mcp_main import main

if __name__ == "__main__":
    main()
