"""MCP Airflow API package."""
from .mcp_main import mcp

__all__ = ["mcp"]
