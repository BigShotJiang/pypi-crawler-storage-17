# -*- coding: utf-8 -*-
"""Nava errors."""


class NavaBaseError(Exception):
    """Nava base error class."""

    pass
