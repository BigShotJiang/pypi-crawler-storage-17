class Style:
    regular = 'bright_white'
    info = 'blue'
    bad = 'red'
    good = 'green'
    mark = 'green bold'
    mark_neutral = 'cyan'
    context = 'magenta'
    suspicious = 'yellow'
