"""
This module used for tests-side Environment description.

Environments could be predefined with services sets and services special variables.

Environment class used as up command param, describes enabled services and it's envs.
"""
