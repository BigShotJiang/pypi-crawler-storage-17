"""
This module specifies the PennyLane Sphinx Theme version with https://semver.org/
using the following format: <major>.<minor>.<patch>[-<pre-release>].
"""

__version__ = "0.26.0"
