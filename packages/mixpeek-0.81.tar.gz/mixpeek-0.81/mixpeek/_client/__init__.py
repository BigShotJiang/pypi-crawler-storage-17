# Custom wrapper - preserved during SDK regeneration
from mixpeek._client.client import Mixpeek

__all__ = ["Mixpeek"]
