# CHANGELOG

<!-- version list -->

## v0.0.2 (2025-12-15)

### Bug Fixes

- Wrong core imports, added tests ([#2](https://github.com/blockanalitica/bakit/pull/2),
  [`487eaef`](https://github.com/blockanalitica/bakit/commit/487eaefe1c6f0dc26a1c3e34db31a25e8e9c187f))

### Chores

- Rename GH action name from TestPyPI to PyPi
  ([`69c43be`](https://github.com/blockanalitica/bakit/commit/69c43be55c359808f4d7f2180377195dfc52848b))


## v0.0.1 (2025-12-15)

- Initial Release
