# Utility functions for the LLM Agent Team framework
