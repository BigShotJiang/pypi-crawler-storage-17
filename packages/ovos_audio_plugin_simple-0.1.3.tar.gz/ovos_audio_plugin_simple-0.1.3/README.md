This plugin was made for old OCP, it only works in ovos <= 0.0.7
__________________
use https://github.com/OpenVoiceOS/ovos-media-plugin-simple with https://github.com/OpenVoiceOS/ovos-media instead
