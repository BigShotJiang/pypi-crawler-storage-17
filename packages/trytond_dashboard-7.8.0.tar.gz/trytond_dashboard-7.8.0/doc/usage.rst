*****
Usage
*****

.. _Open dashboard on login:

Open dashboard on login
=======================

It is possible to have the dashboard open each time you login to Tryton.
You must first define some `Dashboard Actions <model-dashboard.action>` in your
preferences and then select the :guilabel:`Dashboard` in the
:guilabel:`Actions` list.
Now each time you login to Tryton, your personal dashboard is displayed.
