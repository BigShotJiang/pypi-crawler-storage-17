################
Dashboard Module
################

The *Dashboard Module* allows each user to configure a personal dashboard.

.. toctree::
   :maxdepth: 2

   usage
   design
   releases
