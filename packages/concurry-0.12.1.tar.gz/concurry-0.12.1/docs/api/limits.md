# Limits API Reference

::: concurry.core.limit.limit.Limit
    options:
      show_root_heading: true
      show_source: true

::: concurry.core.limit.limit.RateLimit
    options:
      show_root_heading: true
      show_source: true

::: concurry.core.limit.limit.CallLimit
    options:
      show_root_heading: true
      show_source: true

::: concurry.core.limit.limit.ResourceLimit
    options:
      show_root_heading: true
      show_source: true

::: concurry.core.limit.limit_set.LimitSet
    options:
      show_root_heading: true
      show_source: true

::: concurry.core.limit.limit_pool.LimitPool
    options:
      show_root_heading: true
      show_source: true

