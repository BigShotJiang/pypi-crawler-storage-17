"""Tests for synchronization primitives."""
