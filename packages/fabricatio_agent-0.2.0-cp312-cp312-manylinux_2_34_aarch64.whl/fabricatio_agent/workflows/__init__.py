"""Workflows defined in fabricatio-agent."""
