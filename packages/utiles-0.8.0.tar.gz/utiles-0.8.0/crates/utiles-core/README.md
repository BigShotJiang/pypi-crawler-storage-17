# utiles-core ~ web map util(e)ities

Core web-map/spherical-mercator/slippy-map/xyz-tiles utilities library.
