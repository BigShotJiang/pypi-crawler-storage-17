#![expect(clippy::unwrap_used)]
mod core;
mod edges;
