DELETE FROM
    `{table_name}`
WHERE
    {where_statement};
