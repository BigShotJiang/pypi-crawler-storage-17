import os

here = os.path.abspath(os.path.dirname(__file__))

ADD_PARTITION_STATEMENT_FILE = os.path.join(
    here, "add_partition/add_partition_statement.sql"
)
