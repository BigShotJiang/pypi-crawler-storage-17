# Changelog

## [0.1.4] - 2025-12-15
- Updated connector definition (YAML version 1.0.2)
- Source commit: f13dee0a
- SDK version: 0.1.0

## [0.1.3] - 2025-12-15
- Updated connector definition (YAML version 1.0.2)
- Source commit: d79da1e7
- SDK version: 0.1.0

## [0.1.2] - 2025-12-15
- Updated connector definition (YAML version 1.0.2)
- Source commit: 06e7d5c6
- SDK version: 0.1.0

## [0.1.1] - 2025-12-13
- Updated connector definition (YAML version 1.0.2)
- Source commit: 1ab72bd8
- SDK version: 0.1.0

## [0.1.0] - 2025-12-12
- Updated connector definition (YAML version 1.0.2)
- Source commit: 61d98c0a
- SDK version: 0.1.0
