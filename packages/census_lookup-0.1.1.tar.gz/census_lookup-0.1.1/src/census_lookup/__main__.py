"""CLI entry point for census-lookup."""

from census_lookup.cli import cli

if __name__ == "__main__":
    cli()
