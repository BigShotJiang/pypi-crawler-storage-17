"""Utility functions for the vcfcache package.

This package contains various utility modules for validation, logging, and path handling.
"""
