from panoramax_cli.main import app

app()
