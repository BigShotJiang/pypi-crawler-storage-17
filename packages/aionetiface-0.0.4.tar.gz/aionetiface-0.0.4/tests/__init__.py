try:
    from aionetiface.utility.test_init import *
except:
    from aionetiface.utility.test_init import *