"""VAD API 模块"""

from .analyzer import analyze

__all__ = ["analyze"]
