"""VAD package tests"""
