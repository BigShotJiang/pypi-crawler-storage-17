"""LansonAI VAD Tools - Voice Activity Detection package"""

from .api import analyze

__version__ = "0.2.0"
__all__ = ["analyze"]
