"""Tests for BMLibrarian Lite."""
