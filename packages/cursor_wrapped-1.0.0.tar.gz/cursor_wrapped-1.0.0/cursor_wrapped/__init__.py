"""Cursor Wrapped - Your Cursor IDE year in review."""

__version__ = "1.0.0"

