"""Package metadata"""

__version__ = "3.6.1"
__self__ = "dvershinin/lastversion"
