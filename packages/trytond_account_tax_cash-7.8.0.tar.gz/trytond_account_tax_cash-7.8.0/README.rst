#######################
Account Tax Cash Module
#######################

The *Account Tax Cash Module* allows the tax reports to be calculated on a cash
basis.

.. toctree::
   :maxdepth: 2

   design
   releases
