"""HTML dashboards for comprehensive metrics visualization.

Interactive dashboards using bokeh for exploring all metrics.
"""

from __future__ import annotations

__all__ = []
