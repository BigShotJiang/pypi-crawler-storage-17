"""JSON persistence for measurements.

Save and load benchmark measurements to/from JSON files.
"""

from __future__ import annotations
