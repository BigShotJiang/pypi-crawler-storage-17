"""Main entry point for CPU Loader application."""

from cpu_loader.main import run

if __name__ == "__main__":
    run()
