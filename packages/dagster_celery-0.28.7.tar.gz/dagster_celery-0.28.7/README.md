# dagster-celery

The docs for `dagster-celery` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-celery).
