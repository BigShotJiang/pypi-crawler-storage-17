# abductio-core

Core engine for ABDUCTIO.

## Install

From PyPI:

```bash
pip install abductio-core
```

Local path install (for use inside another codebase):

```bash
pip install /path/to/abductio-core
```

Editable install for local development:

```bash
pip install -e /path/to/abductio-core
```

If you host this repo, you can also install directly from VCS:

```bash
pip install git+ssh://<your-host>/<org>/abductio-core.git
```

## Usage

```python
from dataclasses import dataclass, field
from typing import Any, Dict, List

from abductio_core import RootSpec, SessionConfig, SessionRequest, run_session
from abductio_core.application.ports import RunSessionDeps
from abductio_core.domain.audit import AuditEvent


@dataclass
class MemAudit:
    events: List[AuditEvent] = field(default_factory=list)

    def append(self, event: AuditEvent) -> None:
        self.events.append(event)


@dataclass
class NoChildrenDecomposer:
    def decompose(self, target_id: str) -> Dict[str, Any]:
        if ":" in target_id:
            return {"ok": True, "type": "AND", "coupling": 0.80, "children": []}
        return {"ok": True, "feasibility_statement": f"{target_id} feasible"}


@dataclass
class SimpleEvaluator:
    def evaluate(self, node_key: str) -> Dict[str, Any]:
        return {"p": 0.8, "A": 1, "B": 1, "C": 1, "D": 1, "evidence_refs": "ref1"}


request = SessionRequest(
    claim="Example claim",
    roots=[RootSpec("H1", "Mechanism A", "x")],
    config=SessionConfig(tau=0.70, epsilon=0.05, gamma=0.20, alpha=0.40),
    credits=5,
    required_slots=[{"slot_key": "feasibility", "role": "NEC"}],
)

result = run_session(
    request,
    RunSessionDeps(
        evaluator=SimpleEvaluator(),
        decomposer=NoChildrenDecomposer(),
        audit_sink=MemAudit(),
    ),
)

print(result)
```

## License

MIT. See `LICENSE`.
