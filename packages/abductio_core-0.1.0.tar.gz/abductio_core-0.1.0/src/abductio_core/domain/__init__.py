"""Domain layer primitives."""
