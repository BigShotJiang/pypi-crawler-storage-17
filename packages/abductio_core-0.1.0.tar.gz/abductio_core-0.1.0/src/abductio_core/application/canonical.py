from __future__ import annotations

from abductio_core.domain.canonical import canonical_id_for_statement, normalize_statement

__all__ = ["canonical_id_for_statement", "normalize_statement"]
