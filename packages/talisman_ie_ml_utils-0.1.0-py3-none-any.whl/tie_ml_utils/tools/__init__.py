# moved from tie_ml_base.tools
