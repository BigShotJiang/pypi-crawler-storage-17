"""Synchronous HTTP Client for ShipEngine SDK."""
from .client import ShipEngineClient
