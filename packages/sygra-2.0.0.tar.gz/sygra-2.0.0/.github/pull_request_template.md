Please go to the `Preview` tab and select the appropriate sub-template:

* [Feature Template](https://github.com/ServiceNow/SyGra/blob/main/.github/PULL_REQUEST_TEMPLATE/feature_template.md)
* [Issue Template](https://github.com/ServiceNow/SyGra/blob/main/.github/PULL_REQUEST_TEMPLATE/issue_template.md)