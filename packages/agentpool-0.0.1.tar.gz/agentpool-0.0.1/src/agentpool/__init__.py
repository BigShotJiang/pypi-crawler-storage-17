"""agentpool - Multi-agent orchestration framework."""

__version__ = "0.0.1"
