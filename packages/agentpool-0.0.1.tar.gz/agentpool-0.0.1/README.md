# agentpool

Multi-agent orchestration framework for Python.

**Coming soon.** This package is a placeholder for an upcoming release.

## Features (planned)

- Multi-agent orchestration with pools and teams
- LLM-powered agents with tool support
- Streaming and event-driven architecture
- Configuration-driven agent definitions
- Delegation, workers, and pipelines

## Links

- GitHub: https://github.com/phil65/agentpool
