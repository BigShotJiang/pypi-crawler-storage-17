"""
### Typed Myokx
> A fully typed, validated async client for the Myokx API

- Details
"""