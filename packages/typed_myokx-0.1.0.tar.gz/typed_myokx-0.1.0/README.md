# Typed Myokx

> A fully typed, validated async client for the Myokx API

Use *autocomplete* instead of documentation.

🚧 Under construction.