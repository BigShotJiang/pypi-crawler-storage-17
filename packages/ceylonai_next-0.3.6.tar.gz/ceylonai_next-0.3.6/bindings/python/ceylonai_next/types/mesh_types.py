"""Mesh type definitions."""

from ceylonai_next.ceylonai_next import PyMeshRequest, PyMeshResult


# Mesh Request/Result aliases for cleaner Python API
MeshRequest = PyMeshRequest
MeshResult = PyMeshResult
