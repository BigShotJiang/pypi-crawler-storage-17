"""SDMX 3.0 XML reader module."""
