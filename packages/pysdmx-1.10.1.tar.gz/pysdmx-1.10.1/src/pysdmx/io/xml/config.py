"""Parameters configuration for XML writers."""

# Data writing chunksize
CHUNKSIZE = 100000
