"""SDMX 2.1 XML reader module."""
