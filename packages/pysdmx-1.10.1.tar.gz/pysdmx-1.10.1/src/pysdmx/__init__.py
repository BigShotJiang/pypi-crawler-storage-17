"""Your opinionated Python SDMX library."""

__version__ = "1.10.1"
