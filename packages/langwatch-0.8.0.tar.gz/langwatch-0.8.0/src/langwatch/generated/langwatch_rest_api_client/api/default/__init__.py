"""Contains endpoint functions for accessing the API"""
