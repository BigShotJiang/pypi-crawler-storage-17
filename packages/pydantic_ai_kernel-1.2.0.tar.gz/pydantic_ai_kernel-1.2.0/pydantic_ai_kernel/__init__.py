"""An example Jupyter kernel"""

__version__ = "1.2.0"


from .kernel import PydanticAIBaseKernel
from .agent_config import AgentConfig, ModelProviderConfig, ModelConfig
