# Rustic AI LanceDB

[Rustic AI](https://www.rustic.ai/) module to support for [LanceDB](https://lancedb.com/) backend KnowledgeBase
