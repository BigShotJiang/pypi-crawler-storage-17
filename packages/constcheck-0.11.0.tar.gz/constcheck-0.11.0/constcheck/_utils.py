"""
constcheck._utils
=================
"""

from __future__ import annotations

from object_colors import Color as _Color

color = _Color()

color.populate_colors()
