__all__ = ["XML_NS"]

XML_NS = "{http://www.w3.org/XML/1998/namespace}"
