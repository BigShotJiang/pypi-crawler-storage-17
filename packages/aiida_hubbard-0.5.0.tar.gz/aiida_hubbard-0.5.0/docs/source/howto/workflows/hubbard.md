(howto-workflows-hubbard)=

# `SelfConsistentHubbardWorkChain`

*To be added.*
