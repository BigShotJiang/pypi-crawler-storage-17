(howto-workflows-hp-qpoints)=

# `HpParallelizeQpointsWorkChain`

*To be added.*
