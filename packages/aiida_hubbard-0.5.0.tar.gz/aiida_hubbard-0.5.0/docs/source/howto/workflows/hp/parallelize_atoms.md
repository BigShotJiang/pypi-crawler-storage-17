(howto-workflows-hp-atoms)=

# `HpParallelizeAtomsWorkChain`

*To be added.*
