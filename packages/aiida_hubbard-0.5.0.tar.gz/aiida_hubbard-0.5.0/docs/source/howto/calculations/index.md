(howto-calculations)=

# How-to run calculations

```{toctree}
:maxdepth: 1

hp
```
