(topics-calculations-hp)=

# `hp.x`

```{eval-rst}
.. aiida-calcjob:: HpCalculation
    :module: aiida_hubbard.calculations.hp
```
