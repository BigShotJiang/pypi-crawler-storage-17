(topics-calculations)=

# Calculations

```{toctree}
:maxdepth: 1

hp
```
