(topics-workflows-hp-base)=

# `HpBaseWorkChain`

```{eval-rst}
.. aiida-workchain:: HpBaseWorkChain
    :module: aiida_hubbard.workflows.hp.base
```
