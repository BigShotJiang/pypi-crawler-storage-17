(topics-workflows-hp-qpoints)=

# `HpParallelizeQpointsWorkChain`

```{eval-rst}
.. aiida-workchain:: HpParallelizeQpointsWorkChain
    :module: aiida_hubbard.workflows.hp.parallelize_qpoints
```
