(topics-workflows-hp-main)=

# `HpWorkChain`

```{eval-rst}
.. aiida-workchain:: HpWorkChain
    :module: aiida_hubbard.workflows.hp.main
```
