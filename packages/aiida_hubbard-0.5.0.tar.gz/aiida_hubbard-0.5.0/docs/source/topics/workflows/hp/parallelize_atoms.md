(topics-workflows-hp-atoms)=

# `HpParallelizeAtomsWorkChain`

```{eval-rst}
.. aiida-workchain:: HpParallelizeAtomsWorkChain
    :module: aiida_hubbard.workflows.hp.parallelize_atoms
```
