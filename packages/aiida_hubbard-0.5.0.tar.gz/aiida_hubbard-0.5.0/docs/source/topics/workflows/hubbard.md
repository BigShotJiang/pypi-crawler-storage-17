(topics-workflows-hubbard)=

# `SelfConsistentHubbardWorkChain`

```{eval-rst}
.. aiida-workchain:: SelfConsistentHubbardWorkChain
    :module: aiida_hubbard.workflows.hubbard
```
