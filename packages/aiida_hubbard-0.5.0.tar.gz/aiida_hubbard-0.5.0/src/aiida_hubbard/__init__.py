# -*- coding: utf-8 -*-
"""AiiDA plugin for the first-principles calculation of Hubbard parameters."""
__version__ = '0.5.0'
