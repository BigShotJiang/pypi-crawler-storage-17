from text_preparation.importers.tetml.classes import (
    TetmlNewspaperPage,
    TetmlNewspaperIssue,
)
