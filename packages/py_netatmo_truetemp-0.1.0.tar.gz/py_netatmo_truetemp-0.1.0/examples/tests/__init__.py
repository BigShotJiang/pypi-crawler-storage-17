"""Tests for CLI examples."""
