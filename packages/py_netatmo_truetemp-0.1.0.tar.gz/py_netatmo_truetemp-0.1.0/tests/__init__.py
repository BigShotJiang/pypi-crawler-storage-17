"""Tests for py-netatmo-truetemp library."""
