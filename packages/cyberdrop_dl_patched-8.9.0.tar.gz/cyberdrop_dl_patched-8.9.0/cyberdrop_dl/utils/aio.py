"""Async versions of builtins and some path operations"""

from __future__ import annotations

import asyncio
import weakref
from stat import S_ISREG
from typing import TYPE_CHECKING, Final, Generic, TypeVar, cast

if TYPE_CHECKING:
    import pathlib
    from collections.abc import Awaitable, Sequence

_T = TypeVar("_T")


if TYPE_CHECKING:
    from collections.abc import Awaitable, Sequence


async def gather(coros: Sequence[Awaitable[_T]], batch_size: int = 10) -> list[_T]:
    """Like `asyncio.gather`, but creates tasks lazily to minimize event loop overhead.

    This function ensures there are never more than `batch_size` tasks created at any given time.

    If any exception is raised within a task, all currently running tasks
    are cancelled and any renaming task in the queue will be ignored.
    """

    semaphore = asyncio.BoundedSemaphore(batch_size)
    results: list[_T] = cast("list[_T]", [None] * len(coros))

    async def worker(index: int, coro: Awaitable[_T]):
        try:
            result = await coro
            results[index] = result
        finally:
            semaphore.release()

    async with asyncio.TaskGroup() as tg:
        for index, coro in enumerate(coros):
            await semaphore.acquire()
            tg.create_task(worker(index, coro))

    return results


async def stat(path: pathlib.Path):
    return await asyncio.to_thread(path.stat)


async def is_dir(path: pathlib.Path) -> bool:
    return await asyncio.to_thread(path.is_dir)


async def is_file(path: pathlib.Path) -> bool:
    return await asyncio.to_thread(path.is_file)


async def exists(path: pathlib.Path) -> bool:
    return await asyncio.to_thread(path.exists)


async def unlink(path: pathlib.Path, missing_ok: bool = False) -> None:
    return await asyncio.to_thread(path.unlink, missing_ok)


async def get_size(path: pathlib.Path) -> int | None:
    """If path exists and is a file, returns its size. Returns `None` otherwise"""

    # Manually parse stat result to make sure we only use 1 fs call

    try:
        stat_result = await stat(path)
    except (OSError, ValueError):
        return
    else:
        if S_ISREG(stat_result.st_mode):
            return stat_result.st_size


class WeakAsyncLocks(Generic[_T]):
    """A WeakValueDictionary wrapper for asyncio.Locks.

    Unused locks are automatically garbage collected. When trying to retrieve a
    lock that does not exists, a new lock will be created.
    """

    __slots__ = ("__locks",)

    def __init__(self) -> None:
        self.__locks: Final = weakref.WeakValueDictionary[_T, asyncio.Lock]()

    def __getitem__(self, key: _T, /) -> asyncio.Lock:
        lock = self.__locks.get(key)
        if lock is None:
            self.__locks[key] = lock = asyncio.Lock()
        return lock
