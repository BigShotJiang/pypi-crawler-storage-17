from __future__ import annotations

import itertools
from typing import TYPE_CHECKING, ClassVar

from cyberdrop_dl.crawlers.crawler import Crawler, SupportedPaths
from cyberdrop_dl.data_structures.url_objects import AbsoluteHttpURL
from cyberdrop_dl.utils import css
from cyberdrop_dl.utils.utilities import error_handling_wrapper

if TYPE_CHECKING:
    from cyberdrop_dl.data_structures.url_objects import ScrapeItem

PRIMARY_URL = AbsoluteHttpURL("https://postimg.cc")
DOWNLOAD_BUTTON_SELECTOR = "a[id=download]"
API_ENTRYPOINT = AbsoluteHttpURL("https://postimg.cc/json")


class PostImgCrawler(Crawler):
    SUPPORTED_PATHS: ClassVar[SupportedPaths] = {
        "Album": "/gallery/...",
        "Image": "/...",
        "Direct links": "",
    }
    PRIMARY_URL: ClassVar[AbsoluteHttpURL] = PRIMARY_URL
    DOMAIN: ClassVar[str] = "postimg"
    FOLDER_DOMAIN: ClassVar[str] = "PostImg"
    OLD_DOMAINS = ("postimg.org", "postimages.org")

    async def fetch(self, scrape_item: ScrapeItem) -> None:
        if "i.postimg.cc" in scrape_item.url.host:
            return await self.direct_file(scrape_item)
        if "gallery" in scrape_item.url.parts:
            return await self.album(scrape_item)
        await self.image(scrape_item)

    @error_handling_wrapper
    async def album(self, scrape_item: ScrapeItem) -> None:
        data = {"action": "list", "album": scrape_item.url.raw_name, "page": 0}
        title: str = ""
        album_id = scrape_item.url.parts[2]
        for page in itertools.count(1):
            json_resp = await self.request_json(
                API_ENTRYPOINT,
                method="POST",
                data=data | {"page": page},
            )

            if not title:
                title = self.create_title(scrape_item.url.name, album_id)
                scrape_item.setup_as_album(title, album_id=album_id)

            for image in json_resp["images"]:
                link = self.parse_url(image[4])
                filename, ext = self.get_filename_and_ext(image[2])
                new_scrape_item = scrape_item.create_child(link)
                await self.handle_file(link, new_scrape_item, filename, ext)
                scrape_item.add_children()

            if not json_resp["has_page_next"]:
                break

    @error_handling_wrapper
    async def image(self, scrape_item: ScrapeItem) -> None:
        if await self.check_complete_from_referer(scrape_item):
            return

        soup = await self.request_soup(scrape_item.url)

        link_str: str = css.select(soup, DOWNLOAD_BUTTON_SELECTOR, "href")
        link = self.parse_url(link_str).with_query(None)
        filename, ext = self.get_filename_and_ext(link.name)
        await self.handle_file(link, scrape_item, filename, ext)
