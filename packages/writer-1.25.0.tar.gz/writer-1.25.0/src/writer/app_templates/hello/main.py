import writer as wf

# Shows in the log when the app starts
# print("Hello world!")

# Or you can use a logger object
# logger.info("Successful startup")

# You can define functions which can be called from Python code blocks
def my_func():
    return 1

# You can initialize state via code
initial_state = wf.init_state({
    "my_var": 1337,
})