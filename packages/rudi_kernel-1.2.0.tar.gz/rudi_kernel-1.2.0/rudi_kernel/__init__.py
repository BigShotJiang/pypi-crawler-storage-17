"""An example Jupyter kernel"""

__version__ = "1.2.0"


from .kernel import RudiKernel  # noqa: F401
