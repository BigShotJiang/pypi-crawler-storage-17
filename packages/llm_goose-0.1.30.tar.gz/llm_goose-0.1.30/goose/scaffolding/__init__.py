"""Scaffolding module for initializing Goose projects."""

from goose.scaffolding.cli import app

__all__ = ["app"]
