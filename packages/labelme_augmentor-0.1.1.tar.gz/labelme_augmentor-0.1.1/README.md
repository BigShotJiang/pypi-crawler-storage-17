# LabelMe Image Augmentor

一个用于 LabelMe 标注数据集的数据增强工具。支持图像及其对应的 JSON 标注文件同步增强。

## 功能特性

- 支持多种增强方式：
  - 旋转 (Rotation)
  - 翻转 (Flip: 水平/垂直)
  - 缩放 (Scale)
  - 平移 (Translate)
  - 颜色/亮度调整 (Color/Brightness)
- 自动同步更新 LabelMe 格式的 JSON 标注文件
- 正确处理 Rectangle 类型的旋转（转换为包围盒）
- 命令行接口，易于集成

## 安装

```bash
pip install labelme-augmentor
```

## 使用方法

### 命令行工具

```bash
# 基本用法
labelme-augmentor --src_dir /path/to/input --dist_dir /path/to/output --num_aug 3

# 参数说明
# --src_dir: 输入图片和JSON所在的目录
# --dist_dir: 增强后数据的输出目录
# --num_aug: 每个原始图像生成的增强样本数量 (默认: 3)
```

### Python 代码调用

```python
from labelme_augmentor import ImageAugmentor

augmentor = ImageAugmentor(
    input_dir="/path/to/input",
    output_dir="/path/to/output"
)

# 运行增强
augmentor.run_augmentation(num_augmentations=3, random_seed=42)
```

## 依赖

- numpy
- opencv-python

## License

MIT License
