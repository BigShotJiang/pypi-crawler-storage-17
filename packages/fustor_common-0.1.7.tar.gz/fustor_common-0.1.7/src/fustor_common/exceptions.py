class ConfigurationError(Exception):
    """自定义配置错误异常"""
    pass
