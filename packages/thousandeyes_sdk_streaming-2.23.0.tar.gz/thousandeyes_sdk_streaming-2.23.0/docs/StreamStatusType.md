# StreamStatusType

The status of the stream integration. pending: No data is currently being sent to the stream endpoint. failing: Data is being sent but not successfully reaching the stream endpoint. connected: Data is being sent successfully to the stream endpoint.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


