# StreamType

The type of data stream to configure. When using `splunk-hec`:   - `endpointType` must be `http`.   - `exporterConfig.splunkHec.token` must contain the *Splunk HEC Token*.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


