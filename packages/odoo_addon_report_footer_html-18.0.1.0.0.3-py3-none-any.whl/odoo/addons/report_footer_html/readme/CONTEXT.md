This module was developed because sometimes you want to personalize your Report Footer with extra information in some reports.
