To use this module, you need to:

1. Go to a Report that you want to personalize footer.
1. Add some image or HTML to this report on Advanced Properties page.
1. Change Paperformat of this Report and adjust *Bottom Margin (mm)* accordingly.
