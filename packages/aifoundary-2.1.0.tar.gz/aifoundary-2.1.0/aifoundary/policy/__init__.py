"""
Policy-as-code support for Aifoundary.

Allows RAG and agent behavior to be governed
via YAML / JSON policy files.
"""
