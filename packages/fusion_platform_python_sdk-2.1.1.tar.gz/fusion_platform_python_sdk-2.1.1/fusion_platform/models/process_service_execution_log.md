* **id**: The unique identifier for the record.
* **created_at**: When was the record created?
* **updated_at**: When was the record last updated?
* **process_service_execution_id**: The specific execution of the process and service.
* **logged_at**: When was the message logged?
* **message**: The log message.
