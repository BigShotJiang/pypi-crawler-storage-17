"""
This sub-module contains the data models for the SDK.

&copy; [Digital Content Analysis Technology Ltd](https://www.d-cat.co.uk)
"""
