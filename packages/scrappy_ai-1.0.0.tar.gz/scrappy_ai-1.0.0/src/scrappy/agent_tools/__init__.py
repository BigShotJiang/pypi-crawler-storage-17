"""Agent module with tool abstractions."""
