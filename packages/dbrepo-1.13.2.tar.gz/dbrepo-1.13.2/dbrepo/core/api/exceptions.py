class DashboardNotFound(Exception):
    """
    The dashboard could not be found.
    """
    pass
