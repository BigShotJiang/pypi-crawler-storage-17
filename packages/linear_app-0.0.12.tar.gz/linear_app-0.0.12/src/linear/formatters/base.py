"""Base imports and utilities for formatters."""
