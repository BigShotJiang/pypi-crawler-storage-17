from ..ANSI_COLORS import ANSI; C = ANSI()

EX = f"{C.P}|\n  ╰{C.CC}┈{C.OG}➢ {C.G}"


# ---------------- Credits ----------------
def Credits():
    exit(f"""
                     💢  Credit  💢

{C.S} Script Inspired {C.E}{C.G} 🇮🇳 Amazing Scripts 🇮🇳 {C.S}{C.P} @world669 {C.E}

{C.S} Method By {C.E}{C.G} Ali Boss {C.S}{C.P} @p0_usr {C.E}

{C.S} CRCFix {C.E}{C.G} Kirlif' {C.S}{C.P} @SaltSoupGarage {C.E}

{C.S} APKTool {C.E}{C.G} Connor Tumbleson {C.S}{C.P} @iBotPeaches {C.E}

{C.S} APKEditor {C.E}{C.G} REAndroid {C.S}{C.P} @kikfox {C.E}

{C.S} Axml2Xml {C.E}{C.G} AbdurazaaqMohammed {C.S}{C.P} @AbdurazaaqMohammed {C.E}

{C.S} My Channel {C.E}{C.CC} 🇮🇳 ࿗ {C.OG}T̴͢͢e̴͢͢c̴͢͢h̴͢͢n̴͢͢o̴͢͢ {C.B}☣{C.G} I̴͢͢n̴͢͢d̴͢͢i̴͢͢a̴͢͢ {C.CC}࿗ 🇮🇳 {C.S}{C.P} @rktechnoindians {C.E}

{C.S} CREATOR {C.E}{C.G} 𓄂 Ꭱꫝℑ 𓆐 ︻デ═一 ࿗ Я͓̽K͓̽ ࿗ {C.S}{C.P} @RK_TECHNO_INDIA {C.E}


{C.NOTE}{C.Y} Please Maintain Our Credits. 🙏🙏
{C.CC}

                     💢  INSTRUCTION  💢

{C.NOTE} Decompile Directory Set Always {C.G}$HOME ( ~ )
{C.CC}
                     💢 After Patched 💢
{C.G}
{C.S} 1 {C.E}{C.G} AppName_Pairip.apk Save Input Path ( Same Dir. )

{C.S} 2 {C.E}{C.G} If your APK's protected with {C.OG} Flutter + Pairip, {C.G}The script will automatically download libflutter.so, Then you manually replace it with your APK's libflutter.so.

{C.S} 3 {C.E}{C.G} Non-Root User Use 'Multi App / Dual Space / VPhoneGaGa' For UnSigned APK Installation & Save String Logs in {C.Y} /sdcard/MT2/dictionary/{C.PN}[Package_Name].mtd  {C.CC}OR{C.G} ( Root Users don't need clone / virtual, as they are able to directly install UnSigned APK & Save String Logs in {C.Y} /data/data/[Package_Name]/dictionary/{C.PN}[Package_Name].mtd{C.G} )

{C.S} 4 {C.E}{C.G} Now U Can Repair Dex in 2 Ways ( Try any one )

  {EX}{C.CC}1st. {C.C}Auto Translate {C.G}( After Generate .mtd Enter to proceed , 'm' for more info )

  {EX}{C.CC}2nd. {C.C}Manually Translate {C.G}( Translate String With MT in APK's Last classesX.dex & After Translate String, Use -r Additional Flag )

{C.S} 5 {C.E}{C.G} Now Remove libpairipcore.so, Congrats ! Google加固 protection has been completely remove.


{C.NOTE} The purpose of RKPairip is to Restore Strings, not to make a Mod.

{C.CC}{'_' * 61}
    """)