#######################
Carrier Carriage Module
#######################

The *Carrier Carriage Module* extends the support of carrier by adding carriers
before and after the main carrier.

.. toctree::
   :maxdepth: 2

   design
   releases
