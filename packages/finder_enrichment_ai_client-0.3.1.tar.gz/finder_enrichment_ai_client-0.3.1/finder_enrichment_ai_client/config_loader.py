"""
Configuration loader for model mappings.
Loads config.yaml and provides helper functions to map model names to provider-specific IDs.
"""
import os
import yaml
from pathlib import Path
from typing import Dict, Optional


def load_model_config() -> Dict:
    """
    Load the model configuration from config.yaml.
    
    Searches for config.yaml in the following order:
    1. Path specified in CONFIG_PATH environment variable
    2. /app/config.yaml (Docker container standard location)
    3. Relative to module location (for local development)
    
    Returns:
        Dictionary containing the model configuration
        
    Raises:
        FileNotFoundError: If the config file cannot be found
        yaml.YAMLError: If the config file is invalid
    """
    # Priority 1: Environment variable
    if env_path := os.getenv('CONFIG_PATH'):
        config_path = Path(env_path)
        if config_path.exists():
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
    
    # Priority 2: Docker standard location
    docker_path = Path('/app/config.yaml')
    if docker_path.exists():
        with open(docker_path, 'r') as f:
            return yaml.safe_load(f)
    
    # Priority 3: Relative to module (for local development)
    relative_path = Path(__file__).parent.parent.parent.parent / "config.yaml"
    if relative_path.exists():
        with open(relative_path, 'r') as f:
            return yaml.safe_load(f)
    
    # If none found, raise error with all attempted paths
    attempted_paths = [
        os.getenv('CONFIG_PATH', 'CONFIG_PATH env var not set'),
        str(docker_path),
        str(relative_path)
    ]
    raise FileNotFoundError(
        f"Configuration file not found. Tried the following locations:\n" +
        "\n".join(f"  - {path}" for path in attempted_paths) +
        f"\n\nPlease ensure config.yaml exists in one of these locations."
    )


def get_model_config_by_name(model_name: str) -> Optional[Dict]:
    """
    Get the full model configuration for a given model name.
    
    Args:
        model_name: The friendly model name (e.g., "claude-3-5-sonnet")
        
    Returns:
        Dictionary with model configuration including 'name', 'model_id', and 'provider'
        Returns None if model not found
    """
    config = load_model_config()
    
    for model in config.get('models', []):
        if model.get('name') == model_name:
            return model
    
    return None


def get_openrouter_model_id(model_name: str) -> str:
    """
    Look up the OpenRouter model_id for a given model name.
    
    Args:
        model_name: The friendly model name (e.g., "claude-3-5-sonnet")
        
    Returns:
        The OpenRouter model_id (e.g., "anthropic/claude-3.5-sonnet")
        
    Raises:
        ValueError: If the model name is not found in the configuration
    """
    model_config = get_model_config_by_name(model_name)
    
    if not model_config:
        # Provide helpful error message with available models
        config = load_model_config()
        available_models = [m.get('name') for m in config.get('models', []) if m.get('name')]
        raise ValueError(
            f"Model '{model_name}' not found in config.yaml. "
            f"Available models: {', '.join(available_models)}"
        )
    
    model_id = model_config.get('model_id')
    if not model_id:
        raise ValueError(f"Model '{model_name}' found in config but has no model_id")
    
    return model_id


def get_openrouter_base_url() -> str:
    """
    Get the OpenRouter base URL from config.yaml.
    
    Returns:
        The OpenRouter base URL (e.g., "https://openrouter.ai/api/v1")
    """
    config = load_model_config()
    return config.get('openrouter', {}).get('base_url', 'https://openrouter.ai/api/v1')

