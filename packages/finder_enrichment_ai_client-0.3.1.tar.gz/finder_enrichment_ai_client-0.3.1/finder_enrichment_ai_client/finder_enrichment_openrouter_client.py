"""
OpenRouter AI client using direct HTTP requests.
Part of the finder-enrichment-ai-client package for managing AI API calls via OpenRouter.
"""
import os
import json
import logging
from typing import Dict, Any, Optional
import requests

from .config_loader import get_openrouter_model_id, get_openrouter_base_url


logger = logging.getLogger(__name__)


class FinderEnrichmentOpenRouterClient:
    """Client for OpenRouter API that provides access to multiple LLM providers."""
    
    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        """
        Initialize the OpenRouter client.
        
        Args:
            api_key: OpenRouter API key. If None, will check OPENROUTER_API_KEY env var.
            model: Friendly model name (e.g., "claude-3-5-sonnet"). Will be translated to model_id.
        """
        self.api_key = api_key or os.getenv("OPENROUTER_API_KEY")
        self.base_url = os.getenv("OPENROUTER_BASE_URL") or get_openrouter_base_url()
        self.model = model
        
        if not self.api_key:
            raise ValueError(
                "OPENROUTER_API_KEY environment variable is required or pass api_key parameter"
            )
    
    def _get_model_id(self, model: Optional[str] = None) -> str:
        """
        Get the OpenRouter model ID for the given model name.
        
        Args:
            model: Friendly model name. If None, uses self.model.
            
        Returns:
            The OpenRouter model ID (e.g., "anthropic/claude-3.5-sonnet")
        """
        model_name = model or self.model
        if not model_name:
            raise ValueError("No model specified. Pass model parameter or set during initialization.")
        
        return get_openrouter_model_id(model_name)
    
    def generate_content(
        self, 
        prompt: str, 
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 1000
    ) -> Dict[str, Any]:
        """
        Generate content using OpenRouter API.
        
        Args:
            prompt: The input prompt
            model: Friendly model name (will be translated to model_id)
            temperature: Creativity level (0.0 to 2.0)
            max_tokens: Maximum tokens to generate
            
        Returns:
            API response as dictionary with 'text', 'raw_response', 'success', and optional 'error'
        """
        try:
            model_id = self._get_model_id(model)
            
            url = f"{self.base_url}/chat/completions"
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            }
            
            payload = {
                "model": model_id,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "temperature": temperature,
                "max_tokens": max_tokens,
            }
            
            logger.debug(f"Calling OpenRouter API with model: {model or self.model} → {model_id}")
            
            response = requests.post(url, headers=headers, json=payload, timeout=120)
            response.raise_for_status()
            
            result = response.json()
            
            # Extract the generated text
            if "choices" not in result or len(result["choices"]) == 0:
                return {
                    "text": "",
                    "raw_response": result,
                    "success": False,
                    "error": "No choices in OpenRouter response"
                }
            
            choice = result["choices"][0]
            
            # Check if the response was cut off due to max tokens
            if choice.get("finish_reason") == "length":
                logger.warning(
                    f"Response was cut off due to max tokens limit ({max_tokens}). "
                    f"Consider increasing max_tokens."
                )
            
            # Extract the message content
            if "message" not in choice or "content" not in choice["message"]:
                return {
                    "text": "",
                    "raw_response": result,
                    "success": False,
                    "error": "No message content in OpenRouter response"
                }
            
            generated_text = choice["message"]["content"]
            
            if not generated_text:
                return {
                    "text": "",
                    "raw_response": result,
                    "success": False,
                    "error": "Empty response from OpenRouter API"
                }
            
            return {
                "text": generated_text,
                "raw_response": result,
                "success": True
            }
            
        except requests.exceptions.Timeout:
            error_msg = "OpenRouter API request timed out after 120 seconds"
            logger.error(error_msg)
            return {
                "text": "",
                "raw_response": None,
                "success": False,
                "error": error_msg
            }
        except requests.exceptions.HTTPError as e:
            error_detail = str(e)
            response_data = None
            
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"OpenRouter API HTTP error: status={e.response.status_code}")
                
                try:
                    response_data = e.response.json()
                    if 'error' in response_data:
                        api_error = response_data['error']
                        error_message = api_error.get('message', 'Unknown error')
                        logger.error(f"OpenRouter API error: {error_message}")
                        error_detail = f"{str(e)} - {error_message}"
                    else:
                        error_detail = f"{str(e)} - Unexpected response format"
                except json.JSONDecodeError:
                    logger.error(f"OpenRouter API returned non-JSON response: {e.response.text[:200]}...")
                    error_detail = f"{str(e)} - Invalid response format"
            
            return {
                "text": "",
                "raw_response": response_data,
                "success": False,
                "error": error_detail
            }
        except ValueError as e:
            # Model configuration errors
            logger.error(f"Model configuration error: {e}")
            return {
                "text": "",
                "raw_response": None,
                "success": False,
                "error": str(e)
            }
        except Exception as e:
            logger.error(f"Unexpected error calling OpenRouter API: {e}")
            return {
                "text": "",
                "raw_response": None,
                "success": False,
                "error": str(e)
            }
    
    def analyze_image(
        self, 
        image_data: str,
        prompt: str,
        image_content_type: Optional[str] = "image/webp",
        model: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Analyze an image using OpenRouter API (for vision-capable models).
        
        Args:
            image_data: base64 encoded image data
            prompt: Analysis prompt
            image_content_type: MIME type of the image (e.g., "image/webp", "image/jpeg")
            model: Friendly model name (will be translated to model_id)
            
        Returns:
            Analysis result as dictionary with 'text', 'raw_response', 'success', and optional 'error'
        """
        # Validate inputs
        if not image_data:
            return {
                "text": "",
                "raw_response": None,
                "success": False,
                "error": "Image data is empty"
            }
        
        if not prompt:
            return {
                "text": "",
                "raw_response": None,
                "success": False,
                "error": "Prompt is empty"
            }
        
        try:
            model_id = self._get_model_id(model)
            
            url = f"{self.base_url}/chat/completions"
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            }
            
            # OpenRouter uses the standard OpenAI vision format
            payload = {
                "model": model_id,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": prompt
                            },
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:{image_content_type};base64,{image_data}"
                                }
                            }
                        ]
                    }
                ],
                "temperature": 0.0,  # Use deterministic output for image analysis
                "max_tokens": 4096,
            }
            
            logger.debug(
                f"Sending image analysis request to OpenRouter: model={model or self.model} → {model_id}, "
                f"content_type={image_content_type}, image_size={len(image_data)}, prompt_size={len(prompt)}"
            )
            
            response = requests.post(url, headers=headers, json=payload, timeout=120)
            response.raise_for_status()
            
            result = response.json()
            
            # Extract the generated text
            if "choices" not in result or len(result["choices"]) == 0:
                return {
                    "text": "",
                    "raw_response": result,
                    "success": False,
                    "error": "No choices in OpenRouter response"
                }
            
            choice = result["choices"][0]
            
            # Check if the response was cut off
            if choice.get("finish_reason") == "length":
                logger.warning("Response was cut off due to max tokens limit")
            
            # Extract the message content
            if "message" not in choice or "content" not in choice["message"]:
                return {
                    "text": "",
                    "raw_response": result,
                    "success": False,
                    "error": "No message content in OpenRouter response"
                }
            
            generated_text = choice["message"]["content"]
            
            if not generated_text:
                return {
                    "text": "",
                    "raw_response": result,
                    "success": False,
                    "error": "Empty response from OpenRouter API"
                }
            
            return {
                "text": generated_text,
                "raw_response": result,
                "success": True
            }
            
        except requests.exceptions.Timeout:
            error_msg = "OpenRouter API request timed out after 120 seconds"
            logger.error(error_msg)
            return {
                "text": "",
                "raw_response": None,
                "success": False,
                "error": error_msg
            }
        except requests.exceptions.HTTPError as e:
            error_detail = str(e)
            response_data = None
            
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"OpenRouter API HTTP error: status={e.response.status_code}")
                
                try:
                    response_data = e.response.json()
                    if 'error' in response_data:
                        api_error = response_data['error']
                        error_message = api_error.get('message', 'Unknown error')
                        logger.error(f"OpenRouter API error: {error_message}")
                        error_detail = f"{str(e)} - {error_message}"
                    else:
                        error_detail = f"{str(e)} - Unexpected response format"
                except json.JSONDecodeError:
                    logger.error(f"OpenRouter API returned non-JSON response: {e.response.text[:200]}...")
                    error_detail = f"{str(e)} - Invalid response format"
            
            return {
                "text": "",
                "raw_response": response_data,
                "success": False,
                "error": error_detail
            }
        except ValueError as e:
            # Model configuration errors
            logger.error(f"Model configuration error: {e}")
            return {
                "text": "",
                "raw_response": None,
                "success": False,
                "error": str(e)
            }
        except Exception as e:
            logger.error(f"Unexpected error calling OpenRouter API: {e}")
            return {
                "text": "",
                "raw_response": None,
                "success": False,
                "error": str(e)
            }
    
    def set_model(self, model: str):
        """Set the default model to use for API calls."""
        self.model = model
    
    def set_temperature(self, temperature: float):
        """Set the default temperature for content generation."""
        if not 0.0 <= temperature <= 2.0:
            raise ValueError("Temperature must be between 0.0 and 2.0")
        self.temperature = temperature

