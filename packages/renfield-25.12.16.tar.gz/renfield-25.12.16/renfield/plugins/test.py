def ttt():
  print("weeeeeeee")

