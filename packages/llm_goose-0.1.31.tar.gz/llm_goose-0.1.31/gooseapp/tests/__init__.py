"""Tests package for gooseapp."""

from __future__ import annotations
