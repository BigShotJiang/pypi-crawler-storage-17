# CHANGELOG

## [0.1.1] - 2024-01-25

### Fixed

- Fixed type hints to be compatible with older python versions ([#6](https://github.com/BenediktBurger/pymodaq_plugins_basler/issues/6))


## [0.1.0] - 2024-01-25

_Initial version_
