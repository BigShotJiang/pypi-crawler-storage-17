#!/usr/bin/env python
# -*- coding: utf-8 -*-
r"""
@DATE: 2024/6/13 01:36
@File: __init__.py
@IDE: pycharm
@Description:
    dashboard模块，依赖于swanboard
"""
from .watch import watch
