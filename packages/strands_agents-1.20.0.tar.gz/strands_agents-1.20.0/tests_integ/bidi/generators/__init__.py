"""Test data generators for bidirectional streaming integration tests."""
