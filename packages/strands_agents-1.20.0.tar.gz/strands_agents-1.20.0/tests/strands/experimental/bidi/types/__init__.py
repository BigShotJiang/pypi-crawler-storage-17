"""Tests for bidirectional streaming types."""
