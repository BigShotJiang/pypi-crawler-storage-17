# scrcpy client definitions

The scrcpy client HID and inject definitions, which is used to easily develop applications based on scrcpy-server with Python.

This package works with the scrcpy server 3.3.2
