def clamp(v: int, x: int, y: int) -> int:
    return min(max(v, x), y)
