
# Documente Shared

Utilidades para proyectos Documente AI

## Instalación

```bash
make build
```

## Publicación
Publica `documente-shared` en PyPi

```bash
make publish
```