"""
### Typed Timex
> A fully typed, validated async client for the Timex API

- Details
"""