# Typed Timex

> A fully typed, validated async client for the Timex API

Use *autocomplete* instead of documentation.

🚧 Under construction.