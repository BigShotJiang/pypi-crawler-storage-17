"""Генератор интерактивных thinking-сообщений для LLM операций."""

from typing import List


class ThinkingMessagesGenerator:
    """Генератор циклических thinking-сообщений для имитации процесса обдумывания LLM."""

    MESSAGES = [
        "🔍 Анализирую контекст ошибок...",
        "📂 Изучаю структуру репозитория...",
        "🔎 Ищу связанные файлы...",
        "📝 Просматриваю конфигурации...",
        "💭 Обдумываю возможные причины...",
        "🎯 Определяю корневую проблему...",
        "💡 Формулирую рекомендации...",
        "📊 Анализирую зависимости...",
        "🤔 Проверяю связи между компонентами...",
        "🔬 Изучаю детали реализации...",
        "📋 Составляю план решения...",
        "✨ Готовлю финальные выводы...",
    ]

    def __init__(self):
        self._current_index = 0

    def get_next(self) -> str:
        """
        Возвращает следующее thinking-сообщение.

        Returns:
            Следующее сообщение из циклического списка
        """
        message = self.MESSAGES[self._current_index]
        self._current_index = (self._current_index + 1) % len(self.MESSAGES)
        return message

    def reset(self):
        """Сбрасывает счетчик к началу списка."""
        self._current_index = 0

    @classmethod
    def get_all_messages(cls) -> List[str]:
        """
        Возвращает полный список доступных сообщений.

        Returns:
            Список всех thinking-сообщений
        """
        return cls.MESSAGES.copy()
