"""Утилиты для Trisigma CLI."""

from .ssl import get_ssl_cert_paths

__all__ = ["get_ssl_cert_paths"]
