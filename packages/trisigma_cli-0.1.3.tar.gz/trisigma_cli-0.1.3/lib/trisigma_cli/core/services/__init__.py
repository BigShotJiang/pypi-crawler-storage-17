"""Сервисный слой для бизнес-логики."""

from .git_ui_service import GitUIService

__all__ = ['GitUIService']
