class ZoneramaError(Exception):
    """Base exception for Zonerama API errors."""

    pass
