### DOCUMENTATION: https://zonerama.com/services/zpsforandroid/apiservice.asmx
###                https://zonerama.com/services/zpsforandroid/dataservice.asmx


APISERVICE_WSDL_URL = "https://zonerama.com/services/zpsforandroid/apiservice.asmx?WSDL"
DATASERVICE_WSDL_URL = "https://zonerama.com/services/zpsforandroid/dataservice.asmx?WSDL"
