#pragma once

#define module_automaton_load_doc \
	"Load automaton from a file"

PyObject*
module_automaton_load(PyObject* module, PyObject* args);
