def foo(x):
    if x == 0:
        x += 1


foo(0)
