import imported

imported.do_stuff()
