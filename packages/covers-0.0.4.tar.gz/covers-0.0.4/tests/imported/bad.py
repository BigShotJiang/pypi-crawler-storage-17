# this file has a syntax error that prevents compilation.
dev bar():
    pass
