def do_stuff():
    x = 0
    if x >= 0:
        for i in range(10):
            x += i
    return x


def bar():
    pass
