def also_does_stuff():
    x = 1
    for i in range(10):
        x += i
    return x
