def func(N):
    x = 0
    for i in range(N):
        x += i


for i in range(50000):
    func(10000)
