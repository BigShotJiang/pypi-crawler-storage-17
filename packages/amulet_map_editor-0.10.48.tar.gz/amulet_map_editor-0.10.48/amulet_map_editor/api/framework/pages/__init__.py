from .base_page import BasePageUI
from .main_menu import AmuletMainMenu
from .world_page import WorldPageUI
