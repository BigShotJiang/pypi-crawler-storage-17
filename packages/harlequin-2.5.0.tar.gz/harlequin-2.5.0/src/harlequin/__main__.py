from harlequin.cli import harlequin

harlequin()
