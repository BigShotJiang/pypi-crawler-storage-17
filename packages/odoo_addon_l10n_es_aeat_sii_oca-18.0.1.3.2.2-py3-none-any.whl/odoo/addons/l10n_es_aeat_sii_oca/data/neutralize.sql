-- DISABLE SII ON COMPANIES
UPDATE res_company SET sii_test = true;
