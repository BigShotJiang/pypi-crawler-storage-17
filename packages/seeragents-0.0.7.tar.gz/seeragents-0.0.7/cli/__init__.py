"""Seer CLI module."""

