# Authors

Contributors to pyprocessors_chunk_sentences include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
