# Purchase Order Verification - No Match

**Order ID**: {order_id}
**Verification Status**: No items matched

## Summary

- **Overall Status**: {overall_status}
- **Message**: {message}

## Issues

{discrepancies_text}

## Next Steps

{suggested_actions_text}

______________________________________________________________________

**Status**: Cannot proceed - verification failed
