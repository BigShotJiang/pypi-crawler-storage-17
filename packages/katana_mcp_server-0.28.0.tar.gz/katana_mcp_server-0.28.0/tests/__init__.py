"""Tests for katana-mcp-server package."""
