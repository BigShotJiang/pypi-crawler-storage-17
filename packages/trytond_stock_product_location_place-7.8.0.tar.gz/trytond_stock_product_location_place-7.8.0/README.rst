###################################
Stock Product Location Place Module
###################################

The *Stock Product Location Place Module* allows defining the place where each
goods is stored in each location.

.. toctree::
   :maxdepth: 2

   usage
   design
   releases
