*****
Usage
*****

.. _When using product location place:

When using product location place
=================================

The `Product Location Place <model-stock.product.location.place>` must be used
when the place of the product is always the same in the `Location
<stock:model-stock.location>`.
This is simpler than creating a dedicated location for each product.
