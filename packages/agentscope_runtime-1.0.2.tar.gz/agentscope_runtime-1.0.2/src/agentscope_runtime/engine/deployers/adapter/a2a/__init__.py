# -*- coding: utf-8 -*-
from .a2a_protocol_adapter import A2AFastAPIDefaultAdapter
