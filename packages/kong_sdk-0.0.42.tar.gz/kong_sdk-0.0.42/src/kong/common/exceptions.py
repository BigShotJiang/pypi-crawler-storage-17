class DeadlineException(Exception):
    """Exception raised when provided deadline has passed."""
