"""GOV.UK Design System MCP Server."""
__version__ = "0.1.0"