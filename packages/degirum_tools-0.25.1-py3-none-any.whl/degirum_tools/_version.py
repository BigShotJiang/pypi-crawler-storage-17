#
# _version.py: degirum_tools package version
#
# Copyright DeGirum Corporation 2025
# All rights reserved
#

# >>> increment version here vvv
__version_info__ = ("0", "25", "1")
__version__ = ".".join(__version_info__)
