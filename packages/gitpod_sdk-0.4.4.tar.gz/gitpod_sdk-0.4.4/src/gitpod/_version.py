# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "gitpod"
__version__ = "0.4.4"  # x-release-please-version
