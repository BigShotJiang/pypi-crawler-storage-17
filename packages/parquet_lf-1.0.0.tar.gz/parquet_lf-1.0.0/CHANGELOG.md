# 1.0.0 (2025-12-16)


### Features

* add initial project scaffolding for parquet-lf CLI ([7b348b3](https://github.com/mattjmcnaughton/parquet-lf/commit/7b348b390021e9ce0b1690ba4632fb63fb5a4b31))
* add pypi release ([651dd92](https://github.com/mattjmcnaughton/parquet-lf/commit/651dd928d86e4670d1e1a8d1ad912b203f0986d8))
* **cli:** add info command for file inspection ([d4d6c9c](https://github.com/mattjmcnaughton/parquet-lf/commit/d4d6c9c186f2b3233b234dd8dc0643fe3fd7a664))
* implement CSV and NDJSON to Parquet bidirectional conversion ([f30cc58](https://github.com/mattjmcnaughton/parquet-lf/commit/f30cc58b48f4d0b6ce0bdf9d69856801edbf5b6d))
