"""Placeholder test to ensure pytest passes in CI."""


def test_always_pass() -> None:
    """A placeholder test that always passes."""
    assert True
