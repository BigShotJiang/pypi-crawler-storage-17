"""End-to-end tests for parquet-lf CLI."""
