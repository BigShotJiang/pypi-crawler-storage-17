"""Command handlers for parquet-lf CLI."""
