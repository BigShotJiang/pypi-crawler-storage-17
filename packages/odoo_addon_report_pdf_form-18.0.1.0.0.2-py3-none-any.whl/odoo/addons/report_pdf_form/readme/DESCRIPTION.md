This module allows to use PDF files having form field as Odoo reports
to be printed with values being filled from Odoo records.

This module mostly reuses features that were implemented by Odoo in
 sale_pdf_quotation_builder module.