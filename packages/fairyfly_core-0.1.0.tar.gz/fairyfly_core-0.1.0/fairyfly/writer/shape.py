"""Shape Writer.

Note to developers:
Use this module to extend fairyfly's Shape writer for new extensions.
(eg. adding `thmz` to this module adds the method `Shape.to.thmz`)
"""
