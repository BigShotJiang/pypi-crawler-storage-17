from mcap_data_loader.utils.basic import import_string



print(import_string("mcap_data_loader.utils.basic.merge_data_stamped"))