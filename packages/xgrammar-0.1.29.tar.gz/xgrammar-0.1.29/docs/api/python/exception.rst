Exception
==========================

.. currentmodule:: xgrammar.exception

.. autoclass:: DeserializeFormatError
.. autoclass:: DeserializeVersionError
.. autoclass:: InvalidJSONError
.. autoclass:: InvalidStructuralTagError
