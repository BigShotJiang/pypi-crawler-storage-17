﻿xgr.GrammarMatcher
=======================

.. currentmodule:: xgrammar

.. autoclass:: GrammarMatcher
   :no-show-inheritance:
   :special-members: __init__
   :autosummary:

.. autoclass:: BatchGrammarMatcher
   :no-show-inheritance:
   :special-members: __init__
   :autosummary:
