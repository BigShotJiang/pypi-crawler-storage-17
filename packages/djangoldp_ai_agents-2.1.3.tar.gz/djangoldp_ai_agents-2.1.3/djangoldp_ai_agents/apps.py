from django.apps import AppConfig


class DjangoldpAiAgentsConfig(AppConfig):
    name = "djangoldp_ai_agents"
    verbose_name = "AI Agents"
