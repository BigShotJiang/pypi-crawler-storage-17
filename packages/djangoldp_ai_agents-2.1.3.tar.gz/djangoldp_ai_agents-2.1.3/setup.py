#!/usr/bin/env python

from setuptools import find_packages, setup

setup(
    include_package_data=True,
)
