__version__ = "0.0.0"
name = "djangoldp_ai_agents"
