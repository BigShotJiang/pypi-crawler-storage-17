#########################
Authentication SMS Module
#########################

The *Authentication SMS Module* allows users to authenticate using a code
received via `SMS <https://en.wikipedia.org/wiki/Short_Message_Service>`_.

.. toctree::
   :maxdepth: 2

   configuration
   design
   releases
