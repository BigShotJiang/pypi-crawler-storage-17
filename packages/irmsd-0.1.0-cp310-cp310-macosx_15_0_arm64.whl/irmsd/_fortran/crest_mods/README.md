These files are copied 1:1 from the CREST code under the LGPL-3.0 License.
The goal is to keep maximum compatibility and not modify them within the iRMSD project.
