Get MySQL replica (slave) status using SHOW REPLICA STATUS.

Shows replication health including I/O/SQL thread status, master connection details, log positions, and replication lag. No parameters required.
