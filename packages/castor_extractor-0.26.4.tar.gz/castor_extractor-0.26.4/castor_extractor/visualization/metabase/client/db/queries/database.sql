SELECT
    *
FROM
    {schema}.metabase_database
