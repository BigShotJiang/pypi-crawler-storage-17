SetString = set[str]
SetTwoString = set[tuple[str, str]]
