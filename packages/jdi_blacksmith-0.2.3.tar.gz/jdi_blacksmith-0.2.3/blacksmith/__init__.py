"""Blacksmith - Cross-platform development tool installer."""

__version__ = "0.2.3"

