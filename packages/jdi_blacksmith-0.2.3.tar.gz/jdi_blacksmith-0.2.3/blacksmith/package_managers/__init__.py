"""Package manager implementations."""

