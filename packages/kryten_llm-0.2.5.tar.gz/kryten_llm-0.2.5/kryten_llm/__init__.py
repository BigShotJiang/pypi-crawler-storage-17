"""Kryten LLM Service - Chat moderation and filtering."""

__version__ = "0.2.5"
__author__ = "Kryten Robot Team"
__license__ = "MIT"
