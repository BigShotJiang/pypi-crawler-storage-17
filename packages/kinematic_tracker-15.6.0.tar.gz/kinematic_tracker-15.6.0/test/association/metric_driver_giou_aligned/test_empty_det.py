"""."""

import cv2

from kinematic_tracker.association.metric_giou_aligned import MetricGIoUAligned


def test_empty_det(filters: list[cv2.KalmanFilter], driver: MetricGIoUAligned) -> None:
    metric = driver.compute_metric([], filters)
    assert metric.shape == (0, 3)
