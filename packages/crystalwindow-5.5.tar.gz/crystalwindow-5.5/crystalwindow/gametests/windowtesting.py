from crystalwindow import Window

win = Window(800, 600, "Crystal Demo")
win.run()
win.quit()