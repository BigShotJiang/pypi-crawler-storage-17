"""Measurement Framework Package."""


class WrongMessageTypeWarning(RuntimeWarning):
    """Wrong message type received."""

    pass
