"""Artifact resolution and reading utilities."""

from warpdatasets.artifacts.resolver import ArtifactResolver

__all__ = ["ArtifactResolver"]
