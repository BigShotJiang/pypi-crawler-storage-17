"""Catalog module - manifest resolution and caching."""
