"""Manifest store backends."""
