"""Utility module."""
