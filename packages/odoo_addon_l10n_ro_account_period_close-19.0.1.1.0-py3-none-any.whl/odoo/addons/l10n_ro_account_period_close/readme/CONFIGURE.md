- Go to Accounting -\> Adviser -\> Actions -\> Account Period Closing,
  create separate templates for Incomes, Expenses, VAT.
- Income and Expenses templates select "121000" account as debit and
  credit account.
- For VAT template select closing accounts "442600" and "442700" with
  debit account "442400" and credit account "442300", plus check the
  Close debit and credit accounts option.
