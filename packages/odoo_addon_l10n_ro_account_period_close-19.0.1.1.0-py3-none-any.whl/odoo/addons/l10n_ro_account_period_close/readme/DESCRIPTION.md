This module allows you to close incomes, expense, vat between two dates.
