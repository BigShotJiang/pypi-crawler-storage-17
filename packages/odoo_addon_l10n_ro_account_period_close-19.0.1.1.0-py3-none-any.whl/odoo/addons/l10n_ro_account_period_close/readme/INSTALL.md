To install this module, you need to:

- clone the repository <https://github.com/OCA/l10n-romania>
- add the path to this repository in your configuration (addons-path)
- update the module list
- search for "Romania - Account Period Closing" in your addons
- install the module
