- [NextERP Romania](https://www.nexterp.ro):
  - Fekete Mihai \<<feketemihai@nexterp.ro>\>

Do not contact contributors directly about support or help with
technical issues.
