This module defines triggers that creates inspections when stock moves
are done.

It also adds some shortcuts on picking and lots to these inspections.
