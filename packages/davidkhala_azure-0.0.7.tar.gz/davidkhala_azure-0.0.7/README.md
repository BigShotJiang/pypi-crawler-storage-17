
- When using DefaultAzureCredential, make sure you are **NOT** logged in with personal account, otherwise python libraries will fail to get token. 
