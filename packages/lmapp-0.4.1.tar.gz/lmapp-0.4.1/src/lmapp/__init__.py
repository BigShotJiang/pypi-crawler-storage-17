"""lmapp - Local LLM Made Simple"""

__version__ = "0.4.1"
__author__ = "lmapp Contributors"
__license__ = "MIT"
