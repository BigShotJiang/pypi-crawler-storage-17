"""LEAF UI tab components."""
