from setuptools import setup, find_packages
import os

here = os.path.abspath(os.path.dirname(__file__))

with open(os.path.join(here, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name="randomed",
    version="0.1.0",
    description="Production-grade random number generation with multiple PRNG algorithms, cryptographic security, and statistical distributions",
    long_description=long_description,
    long_description_content_type='text/markdown',
    author="Michal Jerney",
    author_email="michal@mrje.com",
    url="https://github.com/michaljerney/randomed",
    project_urls={
        'Documentation': 'https://github.com/michaljerney/randomed',
        'Source': 'https://github.com/michaljerney/randomed',
        'Tracker': 'https://github.com/michaljerney/randomed/issues',
        'Changelog': 'https://github.com/michaljerney/randomed/blob/main/CHANGELOG.md',
    },
    packages=find_packages(exclude=['tests', 'docs', 'examples']),
    python_requires='>=3.7',
    install_requires=[],
    extras_require={
        'dev': ['pytest>=6.0', 'pytest-cov>=2.10', 'black>=21.0', 'flake8>=3.9'],
        'docs': ['sphinx>=3.0', 'sphinx-rtd-theme>=0.5'],
    },
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Intended Audience :: Science/Research',
        'Intended Audience :: Information Technology',
        'Topic :: Scientific/Engineering',
        'Topic :: Scientific/Engineering :: Mathematics',
        'Topic :: Security',
        'Topic :: Security :: Cryptography',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Utilities',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: Implementation :: CPython',
        'Programming Language :: Python :: Implementation :: PyPy',
    ],
    keywords=[
        'random',
        'rng',
        'prng',
        'pseudorandom',
        'cryptography',
        'security',
        'statistics',
        'distributions',
        'monte-carlo',
        'simulation',
        'mersenne-twister',
        'pcg',
        'xorshift',
    ],
    zip_safe=False,
    include_package_data=True,
)
