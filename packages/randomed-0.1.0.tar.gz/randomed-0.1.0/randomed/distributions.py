import math
from typing import List, Tuple, Optional
from .core import MersenneTwister


class Distributions:
    def __init__(self, rng: Optional[MersenneTwister] = None):
        self.rng = rng or MersenneTwister()
    
    def normal(self, mu: float = 0, sigma: float = 1, n: int = 1) -> List[float]:
        return [self.rng.gauss(mu, sigma) for _ in range(n)]
    
    def exponential(self, lambd: float = 1, n: int = 1) -> List[float]:
        return [self.rng.expovariate(lambd) for _ in range(n)]
    
    def gamma(self, alpha: float, beta: float = 1, n: int = 1) -> List[float]:
        return [self.rng.gammavariate(alpha, beta) for _ in range(n)]
    
    def beta(self, alpha: float, beta: float, n: int = 1) -> List[float]:
        return [self.rng.betavariate(alpha, beta) for _ in range(n)]
    
    def lognormal(self, mu: float = 0, sigma: float = 1, n: int = 1) -> List[float]:
        return [self.rng.lognormvariate(mu, sigma) for _ in range(n)]
    
    def poisson(self, lambd: float, n: int = 1) -> List[int]:
        result = []
        for _ in range(n):
            L = math.exp(-lambd)
            k = 0
            p = 1
            while p > L:
                k += 1
                p *= self.rng.uniform(0, 1)
            result.append(k - 1)
        return result
    
    def binomial(self, n: int, p: float, size: int = 1) -> List[int]:
        return [sum(1 for _ in range(n) if self.rng.uniform(0, 1) < p) for _ in range(size)]
    
    def uniform(self, a: float, b: float, n: int = 1) -> List[float]:
        return [self.rng.uniform(a, b) for _ in range(n)]
    
    def choice_weighted(self, choices: List, weights: List[float], n: int = 1) -> List:
        return self.rng.choices(choices, weights=weights, k=n)
    
    def random_walk(self, steps: int, start: float = 0, step_size: float = 1) -> List[float]:
        path = [start]
        current = start
        for _ in range(steps):
            current += self.rng.uniform(-step_size, step_size)
            path.append(current)
        return path
    
    def brownian_motion(self, steps: int, time_unit: float = 0.01) -> List[float]:
        path = [0]
        dt = time_unit
        current = 0
        for _ in range(steps):
            current += self.rng.gauss(0, math.sqrt(dt))
            path.append(current)
        return path
    
    def geometric(self, p: float, n: int = 1) -> List[int]:
        result = []
        for _ in range(n):
            k = 0
            while self.rng.uniform(0, 1) > p:
                k += 1
            result.append(k)
        return result


class TimeSeriesGenerator:
    def __init__(self, rng: Optional[MersenneTwister] = None):
        self.rng = rng or MersenneTwister()
        self.dist = Distributions(self.rng)
    
    def seasonal(self, periods: int, trend_slope: float = 0, noise_scale: float = 0.1) -> List[float]:
        data = []
        for i in range(periods):
            trend = i * trend_slope
            seasonal = math.sin(2 * math.pi * i / 12) * 5
            noise = self.rng.gauss(0, noise_scale)
            data.append(trend + seasonal + noise)
        return data
    
    def arima_like(self, periods: int, p: float = 0.7, d: float = 0.3) -> List[float]:
        data = [self.rng.gauss(0, 1)]
        for _ in range(periods - 1):
            ar_term = p * data[-1]
            ma_term = d * self.rng.gauss(0, 1)
            data.append(ar_term + ma_term)
        return data
