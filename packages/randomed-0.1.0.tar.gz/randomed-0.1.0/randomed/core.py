import random
import math
from typing import List, Tuple, Optional


class MersenneTwister:
    def __init__(self, seed: Optional[int] = None):
        self.rng = random.Random(seed)
    
    def randint(self, a: int, b: int) -> int:
        return self.rng.randint(a, b)
    
    def uniform(self, a: float, b: float) -> float:
        return self.rng.uniform(a, b)
    
    def gauss(self, mu: float, sigma: float) -> float:
        return self.rng.gauss(mu, sigma)
    
    def expovariate(self, lambd: float) -> float:
        return self.rng.expovariate(lambd)
    
    def gammavariate(self, alpha: float, beta: float) -> float:
        return self.rng.gammavariate(alpha, beta)
    
    def betavariate(self, alpha: float, beta: float) -> float:
        return self.rng.betavariate(alpha, beta)
    
    def lognormvariate(self, mu: float, sigma: float) -> float:
        return self.rng.lognormvariate(mu, sigma)
    
    def vonmisesvariate(self, mu: float, kappa: float) -> float:
        return self.rng.vonmisesvariate(mu, kappa)
    
    def choice(self, seq: List) -> any:
        return self.rng.choice(seq)
    
    def choices(self, population: List, weights: Optional[List[float]] = None, k: int = 1) -> List:
        return self.rng.choices(population, weights=weights, k=k)
    
    def sample(self, population: List, k: int) -> List:
        return self.rng.sample(population, k)
    
    def shuffle(self, seq: List) -> None:
        self.rng.shuffle(seq)


class PCG64:
    def __init__(self, seed: Optional[int] = None):
        self.seed = seed if seed is not None else random.getrandbits(64)
        self.state = self.seed
    
    def randint(self, a: int, b: int) -> int:
        self.state = ((self.state * 6364136223846793005) + 1442695040888963407) & ((1 << 64) - 1)
        return a + (self.state % (b - a + 1))
    
    def uniform(self, a: float, b: float) -> float:
        self.state = ((self.state * 6364136223846793005) + 1442695040888963407) & ((1 << 64) - 1)
        return a + ((self.state / (1 << 64)) * (b - a))


class XORShift256:
    def __init__(self, seed: Optional[int] = None):
        if seed is None:
            seed = random.getrandbits(256)
        self.x = seed if seed else 123456789
        self.y = 362436069 ^ (seed >> 32)
        self.z = 521288629
        self.w = 88675123
    
    def next(self) -> int:
        t = self.x ^ (self.x << 11)
        self.x = self.y
        self.y = self.z
        self.z = self.w
        self.w = self.w ^ (self.w >> 19) ^ t ^ (t >> 8)
        return self.w
    
    def randint(self, a: int, b: int) -> int:
        return a + (abs(self.next()) % (b - a + 1))
    
    def uniform(self, a: float, b: float) -> float:
        return a + ((abs(self.next()) / (1 << 32)) * (b - a))
