__version__ = "0.1.0"

from .core import MersenneTwister, PCG64, XORShift256
from .secure import SecureRandom, CryptographicRNG
from .distributions import Distributions, TimeSeriesGenerator
from .utils import Sampling, Optimization, SyntheticDataGenerator

__all__ = [
    'MersenneTwister',
    'PCG64',
    'XORShift256',
    'SecureRandom',
    'CryptographicRNG',
    'Distributions',
    'TimeSeriesGenerator',
    'Sampling',
    'Optimization',
    'SyntheticDataGenerator',
]

_default_mt = MersenneTwister()
_crypto = CryptographicRNG()

def randint(a: int, b: int) -> int:
    return _default_mt.randint(a, b)

def uniform(a: float, b: float) -> float:
    return _default_mt.uniform(a, b)

def choice(seq):
    return _default_mt.choice(seq)

def sample(population, k: int):
    return _default_mt.sample(population, k)

def shuffle(seq):
    _default_mt.shuffle(seq)
    return seq

def gauss(mu: float = 0, sigma: float = 1) -> float:
    return _default_mt.gauss(mu, sigma)

def secure_randint(a: int, b: int) -> int:
    return SecureRandom.randint(a, b)

def secure_token(length: int = 32) -> str:
    return SecureRandom.hex(length)

def secure_password(length: int = 16) -> str:
    return SecureRandom.password(length)

def generate_api_key(prefix: str = "sk") -> str:
    return _crypto.generate_api_key(prefix)

def generate_session_id() -> str:
    return _crypto.generate_session_id()

