import secrets
import string
import hashlib
from typing import Optional


class SecureRandom:
    
    @staticmethod
    def randint(a: int, b: int) -> int:
        return secrets.randbelow(b - a + 1) + a
    
    @staticmethod
    def bytes(length: int) -> bytes:
        return secrets.token_bytes(length)
    
    @staticmethod
    def hex(length: int) -> str:
        return secrets.token_hex(length)
    
    @staticmethod
    def urlsafe(length: int) -> str:
        return secrets.token_urlsafe(length)
    
    @staticmethod
    def password(length: int = 16, 
                 use_digits: bool = True,
                 use_punctuation: bool = True) -> str:
        alphabet = string.ascii_letters
        if use_digits:
            alphabet += string.digits
        if use_punctuation:
            alphabet += string.punctuation
        return ''.join(secrets.choice(alphabet) for _ in range(length))
    
    @staticmethod
    def choice(seq) -> any:
        return secrets.choice(seq)
    
    @staticmethod
    def uuid() -> str:
        import uuid
        return str(uuid.uuid4())
    
    @staticmethod
    def hash_based(data: bytes, length: int = 16) -> str:
        h = hashlib.sha256(secrets.token_bytes(32))
        h.update(data)
        return h.hexdigest()[:length]


class CryptographicRNG:
    def __init__(self):
        self.secure = SecureRandom()
    
    def generate_token(self, prefix: str = "", length: int = 32) -> str:
        token = self.secure.hex(length)
        return f"{prefix}{token}" if prefix else token
    
    def generate_session_id(self) -> str:
        return self.secure.urlsafe(32)
    
    def generate_api_key(self, prefix: str = "sk") -> str:
        return f"{prefix}_{''.join(self.secure.choice(string.ascii_letters + string.digits) for _ in range(40))}"
    
    def generate_password(self, length: int = 16) -> str:
        return self.secure.password(length, use_digits=True, use_punctuation=True)
