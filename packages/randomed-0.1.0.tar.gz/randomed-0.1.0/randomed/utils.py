from typing import List, Callable, Optional
from .core import MersenneTwister
import math


class Sampling:
    
    @staticmethod
    def reservoir_sampling(stream: iter, k: int, rng: Optional[MersenneTwister] = None) -> List:
        if rng is None:
            rng = MersenneTwister()
        
        reservoir = []
        for i, item in enumerate(stream):
            if i < k:
                reservoir.append(item)
            else:
                j = rng.randint(0, i)
                if j < k:
                    reservoir[j] = item
        return reservoir
    
    @staticmethod
    def stratified_sampling(population: List, strata: List[List], k: int, 
                          rng: Optional[MersenneTwister] = None) -> List:
        if rng is None:
            rng = MersenneTwister()
        
        samples = []
        for stratum in strata:
            stratum_size = len(stratum)
            sample_size = max(1, k * stratum_size // len(population))
            samples.extend(rng.sample(stratum, min(sample_size, len(stratum))))
        return samples[:k]


class Distributions:
    
    @staticmethod
    def mixture_model(components: List[Callable], weights: List[float], 
                     n: int = 1, rng: Optional[MersenneTwister] = None) -> List:
        if rng is None:
            rng = MersenneTwister()
        
        result = []
        for _ in range(n):
            component = rng.choices(components, weights=weights, k=1)[0]
            result.append(component())
        return result


class Optimization:
    
    @staticmethod
    def monte_carlo_integration(func: Callable, bounds: List[tuple], 
                              samples: int = 10000, rng: Optional[MersenneTwister] = None) -> float:
        if rng is None:
            rng = MersenneTwister()
        
        total = 0
        volume = 1
        for lower, upper in bounds:
            volume *= (upper - lower)
        
        for _ in range(samples):
            point = [rng.uniform(lower, upper) for lower, upper in bounds]
            total += func(*point)
        
        return (total / samples) * volume
    
    @staticmethod
    def simulated_annealing(objective: Callable, initial_solution, 
                          temperature: float = 1000, cooling_rate: float = 0.95,
                          iterations: int = 1000, rng: Optional[MersenneTwister] = None) -> tuple:
        if rng is None:
            rng = MersenneTwister()
        
        current = initial_solution
        best = current
        current_cost = objective(current)
        best_cost = current_cost
        
        for i in range(iterations):
            neighbor = (current + rng.gauss(0, 1),)
            neighbor_cost = objective(neighbor[0])
            
            delta = neighbor_cost - current_cost
            if delta < 0 or rng.uniform(0, 1) < math.exp(-delta / temperature):
                current = neighbor
                current_cost = neighbor_cost
                
                if current_cost < best_cost:
                    best = current
                    best_cost = current_cost
            
            temperature *= cooling_rate
        
        return best, best_cost


class SyntheticDataGenerator:
    def __init__(self, rng: Optional[MersenneTwister] = None):
        self.rng = rng or MersenneTwister()
    
    def synthetic_dataframe(self, columns: dict, rows: int) -> List[dict]:
        data = []
        for _ in range(rows):
            row = {}
            for col_name, col_type in columns.items():
                if col_type == 'int':
                    row[col_name] = self.rng.randint(0, 1000)
                elif col_type == 'float':
                    row[col_name] = self.rng.uniform(0, 1)
                elif col_type == 'normal':
                    row[col_name] = self.rng.gauss(0, 1)
            data.append(row)
        return data
    
    def synthetic_timeseries(self, length: int, frequency: str = 'H') -> List[dict]:
        from datetime import datetime, timedelta
        
        data = []
        current_time = datetime.now()
        value = 100
        
        for _ in range(length):
            value += self.rng.gauss(0, 5)
            data.append({
                'timestamp': current_time.isoformat(),
                'value': value
            })
            current_time += timedelta(hours=1)
        
        return data
