from biz import demo_biz_add

print("1 + 2 =", demo_biz_add(1, 2))
