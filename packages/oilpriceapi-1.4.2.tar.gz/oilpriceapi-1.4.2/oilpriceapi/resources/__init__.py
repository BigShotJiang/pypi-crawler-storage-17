"""
OilPriceAPI Resources

Resource modules for different API endpoints.
"""
