##############################
Account Statement AEB43 Module
##############################

The *Account Statement AEB43 Module* implements the import of the `Norm 43
<https://downloads.tryton.org/standards/aeb43.pdf>`_ of the Spanish banks
association file as statement.

.. toctree::
   :maxdepth: 2

   releases
