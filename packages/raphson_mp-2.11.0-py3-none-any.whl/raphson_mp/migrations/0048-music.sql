CREATE INDEX idx_track_year ON track(year);
