CREATE TABLE spotify_token (
    access_token TEXT NOT NULL,
    expire_time INTEGER NOT NULL,
    refresh_token TEXT NOT NULL
) STRICT;
