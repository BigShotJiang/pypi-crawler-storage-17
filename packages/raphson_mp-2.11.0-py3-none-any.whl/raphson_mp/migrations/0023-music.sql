-- Add lyrics column

ALTER TABLE track ADD COLUMN lyrics TEXT NULL;
