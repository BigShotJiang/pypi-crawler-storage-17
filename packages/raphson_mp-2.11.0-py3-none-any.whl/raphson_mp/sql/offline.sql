CREATE TABLE history (
    timestamp INTEGER NOT NULL, -- Seconds since UNIX epoch
    track TEXT NOT NULL
) STRICT;

CREATE TABLE content (
    path TEXT NOT NULL UNIQUE PRIMARY KEY,
    music_data BLOB NOT NULL,
    cover_data BLOB NOT NULL,
    lyrics_json TEXT NOT NULL -- no longer used, but a migration to remove this column would be too expensive
) STRICT; -- STRICT mode only for new databases, no migration exists for old databases as it would be too expensive

CREATE TABLE settings (
    base_url TEXT NOT NULL,
    token TEXT NOT NULL
) STRICT;

CREATE TABLE playlists (
    name TEXT NOT NULL UNIQUE
) STRICT;
