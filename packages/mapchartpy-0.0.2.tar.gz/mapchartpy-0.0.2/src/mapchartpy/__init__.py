from .savefile import *
from .save import Save as Map

schema = savefile

__version__ = "0.0.2"
__all__ = [
    "Map"
]