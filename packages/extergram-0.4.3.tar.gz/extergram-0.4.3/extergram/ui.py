# extergram/ui.py

class ButtonsDesign:
    """
    Конструктор для создания встроенных клавиатур.
    """
    def __init__(self, inline_keyboard: list = None):
        self.keyboard = inline_keyboard if inline_keyboard else []

    def add_row(self, *buttons):
        """
        Добавляет ряд кнопок в клавиатуру.
        """
        self.keyboard.append(list(buttons))
        return self

    def to_dict(self):
        """
        Возвращает клавиатуру в виде словаря для API.
        """
        return {"inline_keyboard": self.keyboard}

    @staticmethod
    def create_button(text: str, callback_data: str):
        """
        Создает кнопку для встроенной клавиатуры.
        """
        return {"text": text, "callback_data": callback_data}