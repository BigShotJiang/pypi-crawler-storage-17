# extergram/errors.py

class ExtergramError(Exception):
    """Базовый класс исключений для библиотеки Extergram."""
    pass

class APIError(ExtergramError):
    """Возникает, когда API Telegram возвращает ошибку."""
    def __init__(self, description: str, error_code: int):
        self.description = description
        self.error_code = error_code
        super().__init__(f"[Error {error_code}] {description}")