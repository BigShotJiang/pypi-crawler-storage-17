# extergram/ext/base.py

from ..api_types import Update

class BaseHandler:
    """Базовый класс для всех обработчиков."""
    def __init__(self, callback):
        self.callback = callback

    def check_update(self, update: Update) -> bool:
        """Проверяет, подходит ли обновление для этого обработчика."""
        raise NotImplementedError