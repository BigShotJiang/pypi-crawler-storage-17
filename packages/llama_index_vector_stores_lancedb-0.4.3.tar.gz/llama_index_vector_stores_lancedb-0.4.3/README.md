# LlamaIndex Vector_Stores Integration: Lancedb
