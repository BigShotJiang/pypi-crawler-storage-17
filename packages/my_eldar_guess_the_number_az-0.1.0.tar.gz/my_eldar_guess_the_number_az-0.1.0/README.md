# 🔢 Guess the Number (Ədədi Tap) AZ

Azərbaycan dilində sadə, lakin cəlbedici, terminal əsaslı "Ədədi Tap" oyunu.

## 🚀 Quraşdırma

PyPI-dən quraşdırın:

```bash
pip install guess-the-number-az# 🔢 Guess the Number (Ədədi Tap) AZ

Azərbaycan dilində sadə, lakin cəlbedici, terminal əsaslı "Ədədi Tap" oyunu.

## 🚀 Quraşdırma

PyPI-dən quraşdırın:

```bash
pip install guess-the-number-az