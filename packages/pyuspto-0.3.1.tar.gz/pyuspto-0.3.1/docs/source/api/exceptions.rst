Exceptions
==========

.. automodule:: pyUSPTO.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
