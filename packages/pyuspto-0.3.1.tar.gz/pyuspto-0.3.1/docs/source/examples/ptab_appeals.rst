PTAB Appeals Example
====================

.. literalinclude:: ../../../examples/ptab_appeals_example.py
   :language: python
   :linenos:
