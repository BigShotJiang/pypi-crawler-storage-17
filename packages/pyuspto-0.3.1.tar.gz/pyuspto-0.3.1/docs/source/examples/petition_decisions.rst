Petition Decisions Example
==========================

.. literalinclude:: ../../../examples/petition_decisions_example.py
   :language: python
   :linenos:
