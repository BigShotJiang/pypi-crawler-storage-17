Image File Wrapper Example
==========================

.. literalinclude:: ../../../examples/ifw_example.py
   :language: python
   :linenos:
