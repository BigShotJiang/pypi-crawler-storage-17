PTAB Interferences Example
==========================

.. literalinclude:: ../../../examples/ptab_interferences_example.py
   :language: python
   :linenos:
