from anyscale._private.models.image_uri import ImageURI
from anyscale._private.models.model_base import ModelBase, ModelEnum
