import sys
from transcribe_align_textgrid.cli import main

main(sys.argv[1:])
