"""Tests for darkstrata-credential-check."""
