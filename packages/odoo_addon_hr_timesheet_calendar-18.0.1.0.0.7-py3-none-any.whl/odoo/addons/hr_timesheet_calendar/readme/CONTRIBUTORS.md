\[APSL-Nagarro\](<https://apsl.tech>):
  - Lansana Barry Sow \<<lbarry@apsl.net>\>
  
\[glueckkanja AG\](<https://glueckkanja.com>):
  - Christopher Rogos \<<crogos@gmail.com>\>