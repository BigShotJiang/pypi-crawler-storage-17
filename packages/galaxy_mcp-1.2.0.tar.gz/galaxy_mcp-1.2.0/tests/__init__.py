# Integration tests for Galaxy MCP server
