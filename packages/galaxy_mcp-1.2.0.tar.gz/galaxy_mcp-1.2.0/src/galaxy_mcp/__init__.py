"""Galaxy MCP - Model Context Protocol server for Galaxy bioinformatics platform."""

__version__ = "0.1.0"
__author__ = "Dannon Baker"
__email__ = "dannon.baker@gmail.com"

from .server import *
