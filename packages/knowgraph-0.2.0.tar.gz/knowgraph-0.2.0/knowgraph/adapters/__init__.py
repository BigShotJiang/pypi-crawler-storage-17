"""Adapter layer - Interface adapters for CLI and API."""
