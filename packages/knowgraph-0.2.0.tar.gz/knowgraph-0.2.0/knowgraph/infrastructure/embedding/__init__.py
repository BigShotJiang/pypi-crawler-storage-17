"""Embedding infrastructure - Sparse/Static vector generation."""
