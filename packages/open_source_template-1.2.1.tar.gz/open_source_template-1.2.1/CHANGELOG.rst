=========
Changelog
=========


Version 1.2.0
-------------
* Integrated multi-versioning feature in documentation pages


Version 1.1.0
-------------
* Added `another_dummy_func` to `main.py` that converts an integer to a float.
* Updated this Changelog


Version 1.0.0
----------------

* Initial release.