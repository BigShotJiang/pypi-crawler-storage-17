"""AWS CloudFormation resources."""

# Import s3 module for convenience
from cloudformation_dataclasses.aws import s3

__all__ = ["s3"]
