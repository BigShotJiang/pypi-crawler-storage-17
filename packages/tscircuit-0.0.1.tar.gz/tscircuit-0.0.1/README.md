# tscircuit

tscircuit Python package.

## Installation

```bash
pip install tscircuit
```

## Usage

```python
import tscircuit
```
