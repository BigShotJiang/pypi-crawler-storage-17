"""
uada80 - Ada compiler for Z80/8080.

A full Ada language compiler targeting Z80 processors.
"""

__version__ = "0.2.0"
