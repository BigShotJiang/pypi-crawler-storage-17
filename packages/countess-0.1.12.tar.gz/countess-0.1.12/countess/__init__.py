"""CountESS Project"""

VERSION = "0.1.12"
