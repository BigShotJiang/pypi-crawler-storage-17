"""驗證碼適配器模組"""

from .twocaptcha_adapter import TwoCaptchaAdapter

__all__ = ["TwoCaptchaAdapter"]
