from django.apps import AppConfig


class DotnetidproviderConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_dotnetid"
    label = "dotnetidprovider"
