def main():
    from . import __main__
