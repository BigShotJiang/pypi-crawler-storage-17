import numpy as np

__all__ = ["Γ"]

# keep this for compatibility
Γ = 2 * np.pi * 1.56e6
