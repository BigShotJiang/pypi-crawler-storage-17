# Trampoline Client

Python client for [Trampoline](https://github.com/rlange/trampoline) dynamic reverse proxy.

## Installation

```bash
pip install trampoline-client
```

## Usage

```python
from trampoline_client import TrampolineClient

# Create client that forwards requests to your local server
client = TrampolineClient(
    host="wss://proxy.example.com",
    name="my-service",
    secret="your-secret",
    target="http://localhost:3000"  # Your local server
)

# Start the tunnel
client.start()

# Check if connected
if client.connected:
    print("Tunnel is active!")

# Wait for completion (or use client.stop() to disconnect)
client.join()
```

## Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `host` | Trampoline server WebSocket URL | (required) |
| `name` | Tunnel name to register | (required) |
| `secret` | Authentication secret | `None` |
| `target` | Local server to forward requests to | `http://localhost:80` |
| `daemon` | Run as daemon thread | `True` |

## License

MIT
