# C++ extensions for accellerated similarity calculations
