.. _bblean-user-guide:

.. currentmodule:: bblean

User guide
==========

The bblean *user guide* is a work in progress. Expect updates soon!

.. toctree::
   :maxdepth: 1

   user-guide/notebooks/bitbirch_quickstart.ipynb
   user-guide/parameters.rst
   user-guide/notebooks/bitbirch_best_practices.ipynb
   user-guide/linux_memory_setup.rst
