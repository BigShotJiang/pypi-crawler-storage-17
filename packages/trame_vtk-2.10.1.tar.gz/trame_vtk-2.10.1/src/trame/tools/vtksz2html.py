from trame_vtk.tools.vtksz2html import main

if __name__ == "__main__":
    main()
