from openaleph_search.index.indexes import entities_read_index, entities_write_index

__all__ = ["entities_read_index", "entities_write_index"]
