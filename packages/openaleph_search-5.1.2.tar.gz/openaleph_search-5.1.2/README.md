# openaleph-search

OpenAleph standalone index & search module


## License and Copyright

`openaleph-search`, (C) 2025 [Data and Research Center – DARC](https://dataresearchcenter.org)

`openaleph-search-tagger` is licensed under the AGPLv3 or later license.

The original codebase of `aleph` from which this project is partly derived from is released under the MIT license.

see [NOTICE](./NOTICE) and [LICENSE](./LICENSE)
