__version__ = "0.1.2"

from importlib_resources import files

PACKAGE_ROOT = files(__package__)
