"""Django Ninja AIO CRUD - Rest Framework"""

__version__ = "1.0.5"

from .api import NinjaAIO

__all__ = ["NinjaAIO"]
