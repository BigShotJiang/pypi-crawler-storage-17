# This file is only for providing backwards compatibility.
# As function temp_schema() has been moved to file temp_schema.py.

from exasol.python_extension_common.deployment.temp_schema import temp_schema
