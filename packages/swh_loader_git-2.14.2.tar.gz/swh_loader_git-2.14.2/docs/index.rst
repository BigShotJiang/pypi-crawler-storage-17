.. _swh-loader-git:

.. include:: README.rst

Reference Documentation
-----------------------

.. toctree::
   :maxdepth: 2

.. only:: standalone_package_doc

   Indices and tables
   ------------------

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
