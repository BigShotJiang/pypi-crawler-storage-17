"""Tests for mDNS discovery module."""
