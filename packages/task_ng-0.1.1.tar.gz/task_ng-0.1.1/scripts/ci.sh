#!/usr/bin/env bash
set -e

echo "=== Lint ==="
ruff check src/ tests/

echo ""
echo "=== Format ==="
ruff format --check src/ tests/

echo ""
echo "=== Type Check ==="
mypy src/

echo ""
echo "=== Tests ==="
pytest -v --cov --cov-report=term-missing --cov-report=xml

echo ""
echo "✓ All CI checks passed"
