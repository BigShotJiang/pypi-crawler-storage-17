"""Sync backends package."""

from taskng.sync.backends.git import GitBackend

__all__ = ["GitBackend"]
