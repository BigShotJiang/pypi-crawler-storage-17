Events
======

.. toctree::
   :caption: Submodules and Classes
   :maxdepth: 1

   event_severity
   event_type
