Generate Certificates
=====================

.. command-output:: dt-sdk gencerts --help
