Upload
======

.. command-output:: dt-sdk upload --help
