Build
=====

.. command-output:: dt-sdk build --help
