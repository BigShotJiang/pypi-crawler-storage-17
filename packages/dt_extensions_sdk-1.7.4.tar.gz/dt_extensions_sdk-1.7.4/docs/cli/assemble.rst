Assemble
========

.. command-output:: dt-sdk assemble --help
