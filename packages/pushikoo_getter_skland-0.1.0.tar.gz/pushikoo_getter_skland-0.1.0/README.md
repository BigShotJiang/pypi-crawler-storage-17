<div align="center">

# pushikoo-getter-skland

Skland (森空岛) getter for Pushikoo.

[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/Pushikoo/pushikoo-getter-skland/package.yml)](https://github.com/EvATive7Cloud/pushikoo-getter-skland/actions)
[![Python](https://img.shields.io/pypi/pyversions/pushikoo-getter-skland)](https://pypi.org/project/pushikoo-getter-skland)
[![PyPI version](https://badge.fury.io/py/pushikoo-getter-skland.svg)](https://pypi.org/project/pushikoo-getter-skland)
[![License](https://img.shields.io/github/license/Pushikoo/pushikoo-getter-skland.svg)](https://pypi.org/project/pushikoo-getter-skland/)

</div>
