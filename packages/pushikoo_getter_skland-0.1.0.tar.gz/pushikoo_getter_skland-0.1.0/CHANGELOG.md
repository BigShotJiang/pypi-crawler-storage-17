# Changelog

## 0.1.0 (2025-12-15)


### Features

* add GitHub Actions workflow for automated package release and update project name to pushikoo-getter-skland. ([4334e29](https://github.com/EvATive7Cloud/pushikoo-getter-skland/commit/4334e29580d15c2e44830328d5453c25815157eb))
* v0 ([9e23026](https://github.com/EvATive7Cloud/pushikoo-getter-skland/commit/9e23026a2d1ad1e41ebae9c8d29a52fcdb1cddf0))
