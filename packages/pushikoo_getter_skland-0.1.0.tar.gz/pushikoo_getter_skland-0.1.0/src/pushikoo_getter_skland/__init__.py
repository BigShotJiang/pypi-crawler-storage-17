from pushikoo_getter_skland.main import SklandGetter

__all__ = ["SklandGetter"]
