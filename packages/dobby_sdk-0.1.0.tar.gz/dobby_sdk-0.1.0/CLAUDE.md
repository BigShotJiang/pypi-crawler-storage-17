refer .agents/rules
