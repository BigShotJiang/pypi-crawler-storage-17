"""SQLSaber CLI - Agentic SQL assistant like Claude Code but for SQL."""

from .api import SQLSaber

__all__ = ["SQLSaber"]
