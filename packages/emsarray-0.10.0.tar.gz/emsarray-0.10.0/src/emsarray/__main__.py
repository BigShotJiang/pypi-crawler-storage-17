from emsarray.cli import main

main()
