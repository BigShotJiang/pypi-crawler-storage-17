.. automodule:: vivarium_public_health.results.simple_cause
