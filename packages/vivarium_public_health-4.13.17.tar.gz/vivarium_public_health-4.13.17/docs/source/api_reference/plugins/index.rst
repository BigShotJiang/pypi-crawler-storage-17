===============
Manager Plugins
===============

.. automodule:: vivarium_public_health.plugins

.. toctree::
   :maxdepth: 2
   :glob:

   *
