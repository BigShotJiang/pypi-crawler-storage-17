from edri.dataclass.event import Event, event


@event
class Store(Event):
    pass
