from edri.dataclass.event import Event, event


@event
class Manage(Event):
    pass
