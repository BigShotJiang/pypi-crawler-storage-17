"""Legacy CDM tables package."""

from omop_cdm.dynamic.legacy.legacy import (
    BaseAttributeDefinition,
    BaseCohort,
    BaseCohortAttribute,
    BaseCohortDefinition,
)
