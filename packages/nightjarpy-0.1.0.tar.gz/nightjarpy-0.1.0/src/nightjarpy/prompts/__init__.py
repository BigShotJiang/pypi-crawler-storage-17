from .base import PromptTemplate
from .prompts import (
    COMPILER_AOT_V0_PROMPT,
    INTERPRETER_PYTHON_EAGER_V0_PROMPT,
    INTERPRETER_PYTHON_V0_PROMPT,
)
