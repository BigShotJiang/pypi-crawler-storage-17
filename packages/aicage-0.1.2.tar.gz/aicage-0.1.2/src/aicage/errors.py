__all__ = ["CliError"]


class CliError(Exception):
    """Raised for user-facing CLI errors."""
