from setuptools import setup, find_packages, Extension
import os
import sys

with open("readme.md", "r", encoding="utf-8") as f:
    long_description = f.read()

native_sources = []
ext_modules = []

native_dir = os.path.join("src", "obsidian256", "native")
if os.path.exists(native_dir):
    c_sources = [os.path.join(native_dir, f) for f in os.listdir(native_dir) if f.endswith(".c")]
    if c_sources:
        ext_modules.append(
            Extension(
                "obsidian256.native.obsidian_core",
                sources=c_sources,
                extra_compile_args=["-O3", "-fPIC"] if sys.platform != "win32" else ["/O2"],
            )
        )

setup(
    name="obsidian256",
    version="1.0.0",
    author="mero",
    author_email="",
    description="obsidian-256 advanced encryption algorithm with 3300-bit support",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://t.me/qp4rm",
    project_urls={
        "telegram": "https://t.me/qp4rm",
    },
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    ext_modules=ext_modules if ext_modules else None,
    include_package_data=True,
    package_data={
        "obsidian256": ["native/*.c", "native/*.cpp", "native/*.h"],
    },
    classifiers=[
        "development status :: 5 - production/stable",
        "intended audience :: developers",
        "license :: osi approved :: mit license",
        "operating system :: os independent",
        "programming language :: python :: 3",
        "programming language :: python :: 3.7",
        "programming language :: python :: 3.8",
        "programming language :: python :: 3.9",
        "programming language :: python :: 3.10",
        "programming language :: python :: 3.11",
        "programming language :: python :: 3.12",
        "programming language :: c",
        "programming language :: c++",
        "topic :: security :: cryptography",
    ],
    python_requires=">=3.7",
    install_requires=[],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "build",
            "twine",
        ],
    },
)
