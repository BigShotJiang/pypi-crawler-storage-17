from .virtual_machine import obsidianvm

__all__ = ["obsidianvm"]
