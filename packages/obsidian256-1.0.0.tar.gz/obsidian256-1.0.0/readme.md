# obsidian-256

```
       +---------------------------------------+
       |                                       |
       |         OBSIDIAN-256                  |
       |                                       |
       |         ################              |
       |       ##              ##              |
       |      ##   ##########   ##             |
       |     ##   ##        ##   ##            |
       |     ##   ##   256  ##   ##            |
       |     ##   ##        ##   ##            |
       |      ##   ##########   ##             |
       |       ##              ##              |
       |         ################              |
       |                                       |
       |   encryption algorithm                |
       |   256-bit | 3300-bit                  |
       |                                       |
       +---------------------------------------+
```

symmetric encryption algorithm with 256-bit and 3300-bit support

## developer

**mero** - github: [6x-u](https://github.com/6x-u) - telegram: [@qp4rm](https://t.me/qp4rm)

## version

1.0.0

## installation

```bash
pip install obsidian256
```

## features

- obsidian-256 (256-bit encryption)
- obsidian-3300 (3300-bit encryption)
- virtual machine with 70+ instructions
- native c/c++ implementations
- dynamic s-box
- quantum state permutations
- context-bound keys

---

## usage scripts

### 1. basic encryption

```python
from obsidian256 import obsidian256cipher

cipher = obsidian256cipher()
encrypted = cipher.encrypt(b"secret data")
decrypted = cipher.decrypt(encrypted)
print(decrypted)
```

### 2. decryption with key

```python
from obsidian256 import obsidian256cipher

key = bytes.fromhex("your_key_hex_here")
iv = bytes.fromhex("your_iv_hex_here")

cipher = obsidian256cipher(key=key, iv=iv)
decrypted = cipher.decrypt(encrypted_data)
print(decrypted)
```

### 3. encrypt with password

```python
from obsidian256 import keygenerator, obsidian256cipher

kg = keygenerator()
key, salt = kg.generate_master_key(password="mypassword")

cipher = obsidian256cipher(key=key)
encrypted = cipher.encrypt(b"data")
```

### 4. decrypt with password

```python
from obsidian256 import keygenerator, obsidian256cipher

kg = keygenerator()
key, _ = kg.generate_master_key(password="mypassword", salt=saved_salt)

cipher = obsidian256cipher(key=key)
decrypted = cipher.decrypt(encrypted_data)
```

### 5. 3300-bit encryption

```python
from obsidian256 import obsidian3300

cipher = obsidian3300()
encrypted = cipher.encrypt(b"ultra secure data")
decrypted = cipher.decrypt(encrypted)
```

### 6. context-bound encryption

```python
from obsidian256 import obsidian3300

cipher = obsidian3300(context_bound=True)
encrypted = cipher.encrypt(b"bound to this system")
decrypted = cipher.decrypt(encrypted)
```

### 7. encrypt file

```python
from obsidian256 import obsidian256cipher

cipher = obsidian256cipher()

with open("secret.txt", "rb") as f:
    data = f.read()

encrypted = cipher.encrypt(data)

with open("secret.enc", "wb") as f:
    f.write(cipher.get_key())
    f.write(cipher.get_iv())
    f.write(encrypted)

print("key:", cipher.get_key().hex())
```

### 8. decrypt file

```python
from obsidian256 import obsidian256cipher

with open("secret.enc", "rb") as f:
    key = f.read(32)
    iv = f.read(32)
    encrypted = f.read()

cipher = obsidian256cipher(key=key, iv=iv)
decrypted = cipher.decrypt(encrypted)

with open("secret_decrypted.txt", "wb") as f:
    f.write(decrypted)
```

### 9. encrypt string to hex

```python
from obsidian256 import obsidian256cipher, bytes_to_hex

cipher = obsidian256cipher()
encrypted = cipher.encrypt(b"hello world")

print("encrypted:", bytes_to_hex(encrypted))
print("key:", bytes_to_hex(cipher.get_key()))
print("iv:", bytes_to_hex(cipher.get_iv()))
```

### 10. decrypt from hex

```python
from obsidian256 import obsidian256cipher, hex_to_bytes

key = hex_to_bytes("your_key_hex")
iv = hex_to_bytes("your_iv_hex")
encrypted = hex_to_bytes("encrypted_hex")

cipher = obsidian256cipher(key=key, iv=iv)
decrypted = cipher.decrypt(encrypted)
print(decrypted.decode())
```

### 11. batch encryption

```python
from obsidian256 import obsidian256cipher

cipher = obsidian256cipher()
items = [b"item1", b"item2", b"item3", b"item4", b"item5"]
encrypted_items = [cipher.encrypt(item) for item in items]
```

### 12. batch decryption

```python
from obsidian256 import obsidian256cipher

cipher = obsidian256cipher(key=saved_key, iv=saved_iv)
decrypted_items = [cipher.decrypt(item) for item in encrypted_items]
```

### 13. encrypt python script

```python
from obsidian256 import obsidian256cipher

cipher = obsidian256cipher()

script = '''
print("hello from encrypted script!")
x = 10 + 20
print(f"result: {x}")
'''

encrypted = cipher.encrypt(script.encode())
key = cipher.get_key()
iv = cipher.get_iv()

print("key:", key.hex())
print("iv:", iv.hex())
print("encrypted:", encrypted.hex())
```

### 14. run encrypted python script

```python
from obsidian256 import obsidian256cipher, hex_to_bytes

key = hex_to_bytes("your_key_hex")
iv = hex_to_bytes("your_iv_hex")
encrypted = hex_to_bytes("encrypted_script_hex")

cipher = obsidian256cipher(key=key, iv=iv)
script = cipher.decrypt(encrypted).decode()
exec(script)
```

### 15. encrypt json

```python
from obsidian256 import obsidian256cipher
import json

cipher = obsidian256cipher()

data = {"name": "test", "value": 123, "items": [1, 2, 3]}
json_bytes = json.dumps(data).encode()
encrypted = cipher.encrypt(json_bytes)
```

### 16. decrypt json

```python
from obsidian256 import obsidian256cipher
import json

cipher = obsidian256cipher(key=key, iv=iv)
decrypted = cipher.decrypt(encrypted)
data = json.loads(decrypted.decode())
```

### 17. secure api token storage

```python
from obsidian256 import obsidian256cipher
import base64

class tokenstore:
    def __init__(self):
        self.cipher = obsidian256cipher()
    
    def store(self, token):
        encrypted = self.cipher.encrypt(token.encode())
        return base64.b64encode(encrypted).decode()
    
    def retrieve(self, stored):
        encrypted = base64.b64decode(stored)
        return self.cipher.decrypt(encrypted).decode()

store = tokenstore()
token = store.store("sk-xxxxxxxxxxxx")
original = store.retrieve(token)
```

### 18. database field encryption

```python
from obsidian256 import obsidian256cipher
import base64

class encryptedfield:
    def __init__(self, key):
        self.cipher = obsidian256cipher(key=key)
    
    def encrypt(self, value):
        encrypted = self.cipher.encrypt(value.encode())
        return base64.b64encode(encrypted).decode()
    
    def decrypt(self, encrypted):
        data = base64.b64decode(encrypted)
        return self.cipher.decrypt(data).decode()

key = obsidian256cipher.generate_key()
field = encryptedfield(key)
enc_email = field.encrypt("user@example.com")
dec_email = field.decrypt(enc_email)
```

### 19. stream encryption

```python
from obsidian256 import obsidian256cipher

def encrypt_stream(input_file, output_file, chunk_size=4096):
    cipher = obsidian256cipher()
    
    with open(output_file, "wb") as out:
        out.write(cipher.get_key())
        out.write(cipher.get_iv())
        
        with open(input_file, "rb") as inp:
            while True:
                chunk = inp.read(chunk_size)
                if not chunk:
                    break
                encrypted = cipher.encrypt(chunk)
                out.write(len(encrypted).to_bytes(4, "big"))
                out.write(encrypted)
```

### 20. stream decryption

```python
from obsidian256 import obsidian256cipher

def decrypt_stream(input_file, output_file):
    with open(input_file, "rb") as inp:
        key = inp.read(32)
        iv = inp.read(32)
        cipher = obsidian256cipher(key=key, iv=iv)
        
        with open(output_file, "wb") as out:
            while True:
                size_bytes = inp.read(4)
                if not size_bytes:
                    break
                size = int.from_bytes(size_bytes, "big")
                encrypted = inp.read(size)
                decrypted = cipher.decrypt(encrypted)
                out.write(decrypted)
```

### 21. generate random key

```python
from obsidian256 import obsidian256cipher

key = obsidian256cipher.generate_key()
iv = obsidian256cipher.generate_iv()

print("key:", key.hex())
print("iv:", iv.hex())
```

### 22. key derivation

```python
from obsidian256 import keygenerator

kg = keygenerator()
key, salt = kg.generate_master_key(password="password123")
round_keys = kg.generate_round_keys(key, num_rounds=16)
```

### 23. dynamic s-box

```python
from obsidian256 import dynamicsbox

sbox = dynamicsbox(key=b"my secret key here")
substituted = sbox.substitute(b"data to substitute")
original = sbox.inverse_substitute(substituted)
```

### 24. quantum state

```python
from obsidian256 import quantumstate

qs = quantumstate()
qs.absorb(b"seed data")
qs.permute()
output = qs.squeeze(32)
print("random:", output.hex())
```

### 25. chaos engine

```python
from obsidian256 import chaosengine

ce = chaosengine(seed=12345)
random_values = [ce.generate() for _ in range(10)]
random_bytes = [ce.generate_byte() for _ in range(32)]
```

### 26. context-bound key

```python
from obsidian256 import contextboundkey

cb = contextboundkey()
context = cb.get_context()
bound_key, ctx = cb.derive_bound_key(master_key)
```

### 27. vm basic operations

```python
from obsidian256 import obsidianvm

vm = obsidianvm()
vm.set_register(0, 100)
vm.set_register(1, 50)

program = bytes([
    obsidianvm.op_add, 0, 1,
    obsidianvm.op_halt,
])

vm.load_program(program)
result = vm.run()
print(f"100 + 50 = {result}")
```

### 28. vm assembly

```python
from obsidian256 import obsidianvm

vm = obsidianvm()

source = '''
    movi r0, 1000
    movi r1, 500
    sub r0, r1
    halt
'''

program = vm.assemble(source)
vm.load_program(program)
result = vm.run()
print(f"1000 - 500 = {result}")
```

### 29. vm encryption

```python
from obsidian256 import obsidianvm

vm = obsidianvm()

data = b"hello world"
key = b"0123456789abcdef0123456789abcdef"

vm.load_data(data, 0x1000)
vm.load_data(key, 0x2000)

program = vm.create_encryption_program(0x1000, 0x2000, 0x3000, len(data))
vm.load_program(program)
vm.run()

encrypted = vm.get_data(0x3000, len(data))
print("encrypted:", encrypted.hex())
```

### 30. vm decryption

```python
from obsidian256 import obsidianvm

vm = obsidianvm()

vm.load_data(encrypted, 0x1000)
vm.load_data(key, 0x2000)

program = vm.create_decryption_program(0x1000, 0x2000, 0x3000, len(encrypted))
vm.load_program(program)
vm.run()

decrypted = vm.get_data(0x3000, len(encrypted))
print("decrypted:", decrypted)
```

### 31. vm loop

```python
from obsidian256 import obsidianvm

vm = obsidianvm()

source = '''
    movi r0, 0
    movi r1, 10
loop:
    inc r0
    dec r1
    jnz loop
    halt
'''

program = vm.assemble(source)
vm.load_program(program)
result = vm.run()
print(f"loop result: {result}")
```

### 32. vm syscall

```python
from obsidian256 import obsidianvm

vm = obsidianvm()
message = b"hello from vm"
vm.load_data(message, 0x1000)

program = bytes([
    obsidianvm.op_movi, 0, 0x01, 0x00, 0x00, 0x00,
    obsidianvm.op_movi, 1, 0x01, 0x00, 0x00, 0x00,
    obsidianvm.op_movi, 2, 0x00, 0x10, 0x00, 0x00,
    obsidianvm.op_movi, 3, len(message), 0x00, 0x00, 0x00,
    obsidianvm.op_syscall,
    obsidianvm.op_halt,
])

vm.load_program(program)
vm.run()
print(vm.get_stdout())
```

### 33. encrypt with iv

```python
from obsidian256 import obsidian256cipher

cipher = obsidian256cipher()
encrypted = cipher.encrypt_with_iv(b"data with iv")
decrypted = cipher.decrypt_with_iv(encrypted)
```

### 34. multiple files encryption

```python
from obsidian256 import obsidian256cipher
import os

def encrypt_folder(folder_path, output_folder):
    cipher = obsidian256cipher()
    
    for filename in os.listdir(folder_path):
        filepath = os.path.join(folder_path, filename)
        if os.path.isfile(filepath):
            with open(filepath, "rb") as f:
                data = f.read()
            encrypted = cipher.encrypt(data)
            output_path = os.path.join(output_folder, filename + ".enc")
            with open(output_path, "wb") as f:
                f.write(encrypted)
    
    return cipher.get_key(), cipher.get_iv()
```

### 35. decrypt folder

```python
from obsidian256 import obsidian256cipher
import os

def decrypt_folder(folder_path, output_folder, key, iv):
    cipher = obsidian256cipher(key=key, iv=iv)
    
    for filename in os.listdir(folder_path):
        if filename.endswith(".enc"):
            filepath = os.path.join(folder_path, filename)
            with open(filepath, "rb") as f:
                encrypted = f.read()
            decrypted = cipher.decrypt(encrypted)
            output_path = os.path.join(output_folder, filename[:-4])
            with open(output_path, "wb") as f:
                f.write(decrypted)
```

### 36. secure message exchange

```python
from obsidian256 import obsidian256cipher, bytes_to_hex, hex_to_bytes

class securemessenger:
    def __init__(self):
        self.cipher = obsidian256cipher()
    
    def get_public_info(self):
        return {
            "key": bytes_to_hex(self.cipher.get_key()),
            "iv": bytes_to_hex(self.cipher.get_iv())
        }
    
    def send(self, message):
        encrypted = self.cipher.encrypt(message.encode())
        return bytes_to_hex(encrypted)
    
    def receive(self, encrypted_hex, key_hex, iv_hex):
        key = hex_to_bytes(key_hex)
        iv = hex_to_bytes(iv_hex)
        cipher = obsidian256cipher(key=key, iv=iv)
        encrypted = hex_to_bytes(encrypted_hex)
        return cipher.decrypt(encrypted).decode()
```

### 37. config file encryption

```python
from obsidian256 import obsidian256cipher
import json

def encrypt_config(config_dict, output_path):
    cipher = obsidian256cipher()
    json_data = json.dumps(config_dict).encode()
    encrypted = cipher.encrypt(json_data)
    
    with open(output_path, "wb") as f:
        f.write(cipher.get_key())
        f.write(cipher.get_iv())
        f.write(encrypted)

def decrypt_config(input_path):
    with open(input_path, "rb") as f:
        key = f.read(32)
        iv = f.read(32)
        encrypted = f.read()
    
    cipher = obsidian256cipher(key=key, iv=iv)
    decrypted = cipher.decrypt(encrypted)
    return json.loads(decrypted.decode())
```

### 38. password manager

```python
from obsidian256 import keygenerator, obsidian256cipher
import json
import base64

class passwordmanager:
    def __init__(self, master_password):
        kg = keygenerator()
        self.key, self.salt = kg.generate_master_key(password=master_password)
        self.cipher = obsidian256cipher(key=self.key)
        self.passwords = {}
    
    def add(self, site, password):
        encrypted = self.cipher.encrypt(password.encode())
        self.passwords[site] = base64.b64encode(encrypted).decode()
    
    def get(self, site):
        encrypted = base64.b64decode(self.passwords[site])
        return self.cipher.decrypt(encrypted).decode()
    
    def save(self, filepath):
        data = json.dumps({"salt": base64.b64encode(self.salt).decode(), "passwords": self.passwords})
        with open(filepath, "w") as f:
            f.write(data)
```

### 39. run encrypted file

```python
from obsidian256 import obsidian256cipher, hex_to_bytes

key_hex = "your_32_byte_key_in_hex_format_here"
iv_hex = "your_32_byte_iv_in_hex_format_here"

with open("encrypted_script.bin", "rb") as f:
    encrypted = f.read()

key = hex_to_bytes(key_hex)
iv = hex_to_bytes(iv_hex)

cipher = obsidian256cipher(key=key, iv=iv)
script = cipher.decrypt(encrypted).decode()

exec(script)
```

### 40. save encrypted file to run later

```python
from obsidian256 import obsidian256cipher

cipher = obsidian256cipher()

script = '''
import datetime
print(f"executed at: {datetime.datetime.now()}")
print("this script was encrypted!")
'''

encrypted = cipher.encrypt(script.encode())

with open("encrypted_script.bin", "wb") as f:
    f.write(encrypted)

with open("script_key.txt", "w") as f:
    f.write(f"key: {cipher.get_key().hex()}\n")
    f.write(f"iv: {cipher.get_iv().hex()}\n")

print("script saved!")
print("key:", cipher.get_key().hex())
print("iv:", cipher.get_iv().hex())
```

---

## api reference

### obsidian256cipher

```python
obsidian256cipher(key=None, iv=None)
.encrypt(data) -> bytes
.decrypt(data) -> bytes
.encrypt_with_iv(data) -> bytes
.decrypt_with_iv(data) -> bytes
.get_key() -> bytes
.get_iv() -> bytes
.generate_key() -> bytes
.generate_iv() -> bytes
```

### obsidian3300

```python
obsidian3300(key=None, context_bound=False)
.encrypt(data) -> bytes
.decrypt(data) -> bytes
.get_key() -> bytes
.get_iv() -> bytes
.get_context() -> bytes
```

### obsidianvm

```python
obsidianvm(memory_size=1048576, num_registers=32)
.load_program(program, offset=0)
.load_data(data, offset)
.get_data(offset, length) -> bytes
.set_register(reg, value)
.get_register(reg) -> int
.run(start_address=0) -> int
.step() -> bool
.reset()
.assemble(source) -> bytes
.create_encryption_program(...) -> bytes
.create_decryption_program(...) -> bytes
```

---

## security

```
256-bit key = 2^256 possible keys
brute force at 1 billion/sec = 3.67e+60 years
universe age = 1.4e10 years
```

## compatibility

python 3.7, 3.8, 3.9, 3.10, 3.11, 3.12

## license

mit license

## contact

github: [6x-u](https://github.com/6x-u)
telegram: [@qp4rm](https://t.me/qp4rm)
