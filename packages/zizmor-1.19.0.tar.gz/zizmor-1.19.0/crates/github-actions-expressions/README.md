# github-actions-expressions

[![zizmor](https://img.shields.io/badge/%F0%9F%8C%88-zizmor-white?labelColor=white)](https://zizmor.sh/)
[![CI](https://github.com/zizmorcore/zizmor/actions/workflows/ci.yml/badge.svg)](https://github.com/zizmorcore/zizmor/actions/workflows/ci.yml)
[![Crates.io](https://img.shields.io/crates/v/github-actions-expressions)](https://crates.io/crates/github-actions-expressions)
[![docs.rs](https://img.shields.io/docsrs/github-actions-expressions)](https://docs.rs/github-actions-expressions)
[![GitHub Sponsors](https://img.shields.io/github/sponsors/woodruffw?style=flat&logo=githubsponsors&labelColor=white&color=white)](https://github.com/sponsors/woodruffw)
[![Discord](https://img.shields.io/badge/Discord-%235865F2.svg?logo=discord&logoColor=white)](https://discord.com/invite/PGU3zGZuGG)

`github-actions-expressions` is a parser and library for GitHub Actions expressions.

Key features:

* Faithful parsing of GitHub Actions expressions.
* Span-aware AST nodes.
* Limited support for constant expression evaluation.

See the [documentation] for more details.

This library is part of [zizmor].

[documentation]: https://docs.rs/github-actions-expressions
[zizmor]: https://zizmor.sh
