//! Data models for Dependabot configuration files.

pub mod v2;
