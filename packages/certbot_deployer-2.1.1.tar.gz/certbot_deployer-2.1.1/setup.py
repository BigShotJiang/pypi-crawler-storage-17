"""setup"""

from setuptools import setup  # type:ignore

setup()
