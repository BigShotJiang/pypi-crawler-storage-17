"""
Package metadata
"""

__author__ = "IAS"
__version__ = "2.1.1"
__title__ = "certbot_deployer"
__prog__ = "certbot-deployer"
__license__ = "License :: OSI Approved :: MIT License"
