"""
Example usage of the MARSGuard SDK with the new enforced schema.
This script demonstrates the recommended way to construct a comprehensive ProjectSpec for the SDK.
All values below are dummy placeholders; replace them with your actual project details.

Note:
- The response object (DualGuardrailsResponse) contains two fields:
    - guardrails: The main, summarized/sanitized guardrails.
    - expanded_guardrails: A longer, more descriptive version of the guardrails (more comprehensive, but consumes more tokens).
      Use expanded_guardrails if you want a more detailed output, but be aware of higher token usage.
"""

import logging
from marsguard import (
    MarsGuardClient,
    AppModel,
    ModelSpec,
    AudienceSpec,
    ContentRulesSpec,
    CustomSpec,
    ProjectSpec,
    GenerateGuardrailsRequest,
)

# Configure logging to output to the console
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

if __name__ == "__main__":
    logging.info("Starting MARSGuard SDK example usage script.")

    # Instantiate the MarsGuardClient
    logging.info("Instantiating MarsGuardClient...")
    client = MarsGuardClient()

    # Recommended way to write ProjectSpec using the new schema (dummy values and comments)
    project_spec = ProjectSpec(
        relaxation_factor=0.5,  # 0.0 = strict, 1.0 = relaxed
        audience=AudienceSpec(
            age_factor=30,  # Target audience age (e.g., 18, 25, 50)
            risk_factor=5.0,  # 0..10; higher means stricter safety
            trust="low"  # Audience trust: "low", "medium", or "high"
        ),
        content_rules=ContentRulesSpec(
            max_output_tokens=200,  # Maximum tokens per response
            tone="neutral"  # Response tone, e.g., "neutral", "formal", "friendly"
        ),
        custom=CustomSpec(
            text="Any custom organizational policy or rules here."  # Free-text custom rules
        )
    )

    # Construct the request object using the new enforced schema (dummy values and comments)
    logging.info("Building GenerateGuardrailsRequest object...")
    req = GenerateGuardrailsRequest(
        app=AppModel(
            name="Your App Name",  # Name of your application
            context="Short business context or description of your app"  # Optional: business context
        ),
        domain="your_domain",  # Domain, e.g., "insurance", "healthcare", "finance"
        model=ModelSpec(
            provider="your_provider",  # LLM provider, e.g., "openai"
            name="your_model_name"     # Model name, e.g., "gpt-4o"
        ),
        project_spec=project_spec
    )
    logging.info(f"Request object: {req!r}")

    # Call the backend and handle errors gracefully
    try:
        logging.info("Sending request to backend...")
        resp = client.generate_guardrails(req)
        logging.info("Received response from backend.")
        # Log the guardrails (the main result from the backend)
        logging.info("Guardrails response (summarized):")
        logging.info(resp.guardrails)
        # Log the expanded guardrails (longer, more descriptive, more tokens)
        if resp.expanded_guardrails is not None:
            logging.info("Expanded guardrails (more descriptive, higher token usage):")
            logging.info(resp.expanded_guardrails)
        else:
            logging.info("No expanded guardrails returned.")
    except Exception as e:
        # Log any errors that occur (validation, network, or API errors)
        logging.error(f"Error occurred during guardrails generation: {e}")
