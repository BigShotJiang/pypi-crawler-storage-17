# easydata

**easydata** is a lightweight Python library for simple file-based data reading and writing.  
It is designed to make working with structured text/binary data straightforward and beginner-friendly.

---

## Installation

Install from PyPI:

```bash
pip install easydata

for more information wisit janektech.pl

