def elo(*args, **kwargs):
    raise NotImplementedError("Not yet implemented.")


__all__ = ["elo"]
