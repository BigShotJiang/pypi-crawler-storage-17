import AuthPage from "@features/auth/components/auth-page";

export default function Signup() {
  return <AuthPage type="signup" />;
}
