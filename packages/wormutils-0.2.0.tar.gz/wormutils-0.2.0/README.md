# wormutils

A package for common functions used in other WORM codes.