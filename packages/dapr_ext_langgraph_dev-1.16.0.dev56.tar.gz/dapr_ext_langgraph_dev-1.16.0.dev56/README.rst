dapr-ext-langgraph extension
=======================

|pypi|

.. |pypi| image:: https://badge.fury.io/py/dapr-ext-langgraph.svg
   :target: https://pypi.org/project/dapr-ext-langgraph/

This is the Dapr Checkpointer extension for LangGraph

Installation
------------

::

    pip install dapr-ext-langgraph

References
----------

* `Dapr <https://github.com/dapr/dapr>`_
* `Dapr Python-SDK <https://github.com/dapr/python-sdk>`_
