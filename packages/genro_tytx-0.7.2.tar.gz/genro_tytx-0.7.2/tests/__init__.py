# Copyright 2025 Softwell S.r.l. - Licensed under Apache License 2.0
