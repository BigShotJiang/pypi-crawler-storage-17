::: petropandas.pandas_accessors.PetroPlotsAccessor
    handler: python
    options:
        group_by_category: true
        show_root_heading: true
        show_source: false
        members_order: "source"
