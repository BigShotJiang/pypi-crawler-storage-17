::: petropandas.pandas_accessors.OxidesAccessor
    handler: python
    options:
        group_by_category: true
        show_root_heading: true
        show_source: false
        members_order: "source"

::: petropandas.pandas_accessors.IonsAccessor
    handler: python
    options:
        group_by_category: true
        show_root_heading: true
        show_source: false
        members_order: "source"

::: petropandas.pandas_accessors.ElementsAccessor
    handler: python
    options:
        group_by_category: true
        show_root_heading: true
        show_source: false
        members_order: "source"

::: petropandas.pandas_accessors.REEAccessor
    handler: python
    options:
        group_by_category: true
        show_root_heading: true
        show_source: false
