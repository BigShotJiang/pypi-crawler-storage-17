# stat_386_project

Final group project for stat 386
Link to hosted GitHub Pages site: https://jerm2000.github.io/stat_386_project/
Link to PyPi package: https://pypi.org/project/jerm2000-stat-386-project/#description
