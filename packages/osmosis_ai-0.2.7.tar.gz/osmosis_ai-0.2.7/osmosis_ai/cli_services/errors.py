from __future__ import annotations


class CLIError(Exception):
    """Raised when the CLI encounters a recoverable error."""

    pass
