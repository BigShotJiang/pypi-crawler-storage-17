# Typed Phemex

> A fully typed, validated async client for the Phemex API

Use *autocomplete* instead of documentation.

🚧 Under construction.