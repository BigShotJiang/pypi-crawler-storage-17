"""
### Typed Phemex
> A fully typed, validated async client for the Phemex API

- Details
"""