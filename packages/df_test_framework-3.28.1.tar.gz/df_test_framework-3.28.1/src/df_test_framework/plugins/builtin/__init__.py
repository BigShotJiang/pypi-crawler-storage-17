"""
内置插件

包含：
- monitoring/: 监控插件
- reporting/: 报告插件
"""

__all__: list[str] = []
