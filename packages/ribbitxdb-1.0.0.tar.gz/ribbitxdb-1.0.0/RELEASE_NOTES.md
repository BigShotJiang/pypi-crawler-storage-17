# RibbitXDB v1.0.0 Release Notes

## Initial Release - December 2025

RibbitXDB is a secure and lightweight database engine designed specifically for Python applications. This initial release provides a production-ready SQLite3-compatible database with enhanced security and compression features.

### Key Features

**Security First**
- BLAKE2 cryptographic hashing on every row for data integrity
- Automatic tamper detection
- 32-byte hash digests for maximum security

**Lightweight Storage**
- LZMA compression reduces database file size by up to 70%
- Configurable compression levels (0-9)
- Automatic compression/decompression

**High Performance**
- B-tree indexing for O(log n) lookups
- Page-based storage with intelligent caching
- Efficient memory management

**Developer Friendly**
- SQLite3-compatible API - easy migration
- Zero external dependencies
- Full ACID transaction support
- Context manager support

### What's Included

- Full CRUD operations (CREATE, INSERT, SELECT, UPDATE, DELETE)
- Transaction management with commit/rollback
- Primary key indexing
- Data type support (INTEGER, REAL, TEXT, BLOB, NULL)
- Constraint enforcement (PRIMARY KEY, NOT NULL, UNIQUE)
- Comprehensive documentation and examples

### Installation

```bash
pip install ribbitxdb
```

### Quick Start

```python
import ribbitxdb

conn = ribbitxdb.connect('myapp.rbx')
cursor = conn.cursor()

cursor.execute('''
    CREATE TABLE users (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT UNIQUE
    )
''')

cursor.execute("INSERT INTO users VALUES (1, 'Alice', 'alice@example.com')")
conn.commit()

cursor.execute("SELECT * FROM users")
print(cursor.fetchall())

conn.close()
```

### Use Cases

- Embedded databases for desktop applications
- Microservices data storage
- IoT device data management
- Secure data archival
- Rapid prototyping

### Known Limitations

This initial release focuses on core functionality. Future releases will add:
- JOIN operations
- Aggregate functions (COUNT, SUM, AVG, etc.)
- Subqueries
- Expression support in UPDATE statements
- Query optimization

### License

MIT License - Free for commercial and personal use

### Support

- Website: https://ribbitx.com
- Documentation: https://ribbitx.com/docs
- Issues: https://github.com/ribbitx/ribbitxdb/issues

---

**Thank you for using RibbitXDB!**
