from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ribbitxdb",
    version="1.0.0",
    author="RibbitX Team",
    author_email="contact@ribbitx.com",
    description="A secure and lightweight database engine with BLAKE2 hashing and LZMA compression for Python applications",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://ribbitx.com",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Database",
        "Topic :: Database :: Database Engines/Servers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Security :: Cryptography",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Operating System :: OS Independent",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: POSIX :: Linux",
        "Operating System :: MacOS",
    ],
    python_requires=">=3.8",
    install_requires=[],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
        ],
    },
    keywords="database, sqlite, blake2, lzma, compression, security, lightweight, embedded, nosql",
    project_urls={
        "Homepage": "https://ribbitx.com",
        "Bug Reports": "https://github.com/ribbitx/ribbitxdb/issues",
        "Source": "https://github.com/ribbitx/ribbitxdb",
        "Documentation": "https://ribbitx.com/docs",
    },
)
