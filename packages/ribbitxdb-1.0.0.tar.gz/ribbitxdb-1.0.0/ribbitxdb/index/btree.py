from typing import Any, Optional, List, Tuple
import pickle

class BTreeNode:
    def __init__(self, order: int, is_leaf: bool = True):
        self.order = order
        self.is_leaf = is_leaf
        self.keys: List[Any] = []
        self.values: List[Any] = []
        self.children: List['BTreeNode'] = []
    
    def is_full(self) -> bool:
        return len(self.keys) >= self.order - 1
    
    def insert_non_full(self, key: Any, value: Any):
        i = len(self.keys) - 1
        
        if self.is_leaf:
            self.keys.append(None)
            self.values.append(None)
            
            while i >= 0 and key < self.keys[i]:
                self.keys[i + 1] = self.keys[i]
                self.values[i + 1] = self.values[i]
                i -= 1
            
            self.keys[i + 1] = key
            self.values[i + 1] = value
        else:
            while i >= 0 and key < self.keys[i]:
                i -= 1
            i += 1
            
            if self.children[i].is_full():
                self.split_child(i)
                if key > self.keys[i]:
                    i += 1
            
            self.children[i].insert_non_full(key, value)
    
    def split_child(self, index: int):
        order = self.order
        child = self.children[index]
        new_child = BTreeNode(order, child.is_leaf)
        
        mid = order // 2
        
        new_child.keys = child.keys[mid:]
        child.keys = child.keys[:mid]
        
        if child.is_leaf:
            new_child.values = child.values[mid:]
            child.values = child.values[:mid]
        else:
            new_child.children = child.children[mid:]
            child.children = child.children[:mid]
        
        self.keys.insert(index, child.keys[-1] if child.keys else None)
        self.values.insert(index, None)
        self.children.insert(index + 1, new_child)
    
    def search(self, key: Any) -> Optional[Any]:
        i = 0
        while i < len(self.keys) and key > self.keys[i]:
            i += 1
        
        if i < len(self.keys) and key == self.keys[i]:
            return self.values[i] if self.is_leaf else None
        
        if self.is_leaf:
            return None
        
        return self.children[i].search(key)
    
    def range_search(self, start_key: Any, end_key: Any) -> List[Tuple[Any, Any]]:
        results = []
        
        i = 0
        while i < len(self.keys) and start_key > self.keys[i]:
            i += 1
        
        if not self.is_leaf:
            if i < len(self.children):
                results.extend(self.children[i].range_search(start_key, end_key))
        
        while i < len(self.keys) and self.keys[i] <= end_key:
            if self.keys[i] >= start_key:
                results.append((self.keys[i], self.values[i]))
            i += 1
            
            if not self.is_leaf and i < len(self.children):
                results.extend(self.children[i].range_search(start_key, end_key))
        
        return results

class BTree:
    def __init__(self, order: int = 128):
        self.order = order
        self.root = BTreeNode(order)
    
    def insert(self, key: Any, value: Any):
        if self.root.is_full():
            new_root = BTreeNode(self.order, is_leaf=False)
            new_root.children.append(self.root)
            new_root.split_child(0)
            self.root = new_root
        
        self.root.insert_non_full(key, value)
    
    def search(self, key: Any) -> Optional[Any]:
        return self.root.search(key)
    
    def range_search(self, start_key: Any, end_key: Any) -> List[Tuple[Any, Any]]:
        return self.root.range_search(start_key, end_key)
    
    def serialize(self) -> bytes:
        return pickle.dumps(self.root)
    
    @classmethod
    def deserialize(cls, data: bytes, order: int = 128) -> 'BTree':
        tree = cls(order)
        tree.root = pickle.loads(data)
        return tree
