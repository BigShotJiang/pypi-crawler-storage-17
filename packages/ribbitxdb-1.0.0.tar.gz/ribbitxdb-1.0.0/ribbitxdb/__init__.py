from .connection import connect, Connection
from .cursor import Cursor
from .utils.exceptions import (
    DatabaseError,
    IntegrityError,
    OperationalError,
    ProgrammingError,
    NotSupportedError
)

__version__ = "1.0.0"
__author__ = "RibbitX Team"
__all__ = [
    "connect",
    "Connection",
    "Cursor",
    "DatabaseError",
    "IntegrityError",
    "OperationalError",
    "ProgrammingError",
    "NotSupportedError",
]

PARSE_DECLTYPES = 1
PARSE_COLNAMES = 2
