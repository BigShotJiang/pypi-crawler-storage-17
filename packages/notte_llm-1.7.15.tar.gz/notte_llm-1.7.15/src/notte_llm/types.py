# Re-export from notte_core for backwards compatibility
from notte_core.common.types import TResponseFormat

__all__ = ["TResponseFormat"]
