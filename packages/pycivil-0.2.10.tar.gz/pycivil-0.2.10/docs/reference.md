::: pycivil.EXAStructural.sections
::: pycivil.EXAStructural.templateRCRect.RCTemplRectEC2
    options:
      members:
        - setDimH
        - setDimW
        - solverSLS_NM
      show_root_heading: false
      show_source: false
