class SerdesUsageError(Exception):
    pass


class DeserializationError(Exception):
    pass


class SerializationError(Exception):
    pass
