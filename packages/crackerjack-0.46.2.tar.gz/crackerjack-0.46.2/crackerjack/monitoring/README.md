> Crackerjack Docs: [Main](../../README.md) | [Crackerjack Package](../README.md) | [Monitoring](./README.md)

# Monitoring

Observability, metrics, and health checks.

## Related

- [Crackerjack Package](../README.md) - Parent package
- [Events](../events/README.md) - Event types and signals
- [MCP](../mcp/README.md) - MCP server monitoring and progress tracking
