class ConfigIntegrityError(Exception):
    """Custom exception for configuration integrity issues."""

    pass
