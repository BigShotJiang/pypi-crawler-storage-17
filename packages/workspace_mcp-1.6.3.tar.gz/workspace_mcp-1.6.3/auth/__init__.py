# Make the auth directory a Python package
