# Make the calendar directory a Python package
