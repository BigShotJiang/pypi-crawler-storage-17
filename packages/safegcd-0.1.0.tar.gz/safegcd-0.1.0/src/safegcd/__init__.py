from .core import divstep

__all__ = ["divstep"]
__version__ = "0.1.0"

