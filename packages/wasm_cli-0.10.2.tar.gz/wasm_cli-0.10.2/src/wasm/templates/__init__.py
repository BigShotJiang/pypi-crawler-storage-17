"""Templates package for WASM."""
