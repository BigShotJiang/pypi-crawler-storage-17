import CollectionModel from '@girder/core/models/CollectionModel';

import extendModel from './extendModel';

extendModel(CollectionModel, 'collection');
