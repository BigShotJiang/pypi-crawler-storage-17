# QTrack CLI

A command-line interface tool for uploading JUnit XML reports to tracking services.

## Installation

