Stock Location Sequence Module
##############################

The stock location sequence module adds ordering to location.
