Notebooks
========================================================================================

These example notebooks demonstrate how to use the across-tools library for 
astronomical visibility calculations, ephemeris generation, and footprint analysis.

.. toctree::
   :maxdepth: 1

   Getting Started with across-tools <notebooks/getting_started>
