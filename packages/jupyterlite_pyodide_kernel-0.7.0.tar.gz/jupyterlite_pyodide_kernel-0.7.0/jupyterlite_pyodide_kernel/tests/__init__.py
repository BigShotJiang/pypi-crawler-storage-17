"""tests of jupyterlite pyodide kernel"""
