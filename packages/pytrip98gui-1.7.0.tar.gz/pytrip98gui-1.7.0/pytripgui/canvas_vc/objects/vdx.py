class Vdx:
    """
    This class holds data model for plotting Vdx stuff.
    """
    def __init__(self, ctx, projection_selector):
        self.ctx = ctx
        self.projection_selector = projection_selector
        self.voi_list = []
