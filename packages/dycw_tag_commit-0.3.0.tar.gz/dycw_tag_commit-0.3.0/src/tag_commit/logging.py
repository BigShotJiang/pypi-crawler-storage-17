from __future__ import annotations

from logging import getLogger

LOGGER = getLogger("tag-commits")


__all__ = ["LOGGER"]
