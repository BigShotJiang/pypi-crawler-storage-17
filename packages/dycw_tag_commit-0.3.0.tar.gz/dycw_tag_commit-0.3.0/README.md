# `action-tag-commit`

Tag the latest commit with the version read from [`bump-my-version`](https://github.com/callowayproject/bump-my-version).
