# Typed Huobi

> A fully typed, validated async client for the Huobi API

Use *autocomplete* instead of documentation.

🚧 Under construction.