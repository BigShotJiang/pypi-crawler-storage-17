"""
### Typed Huobi
> A fully typed, validated async client for the Huobi API

- Details
"""