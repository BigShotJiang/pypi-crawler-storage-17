from abc import ABC


class Middleware(ABC):
    pass
