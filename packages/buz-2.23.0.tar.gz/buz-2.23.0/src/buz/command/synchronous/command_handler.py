from abc import ABC, abstractmethod
from typing import Generic, Type, TypeVar

from buz import Handler
from buz.command import Command
from buz.wrapper.async_unsafe import async_unsafe

TCommand = TypeVar("TCommand", bound=Command)


class CommandHandler(Generic[TCommand], Handler[TCommand], ABC):
    def __new__(cls, *args, **kwargs):
        instance = super().__new__(cls)
        original_handle = instance.handle
        instance.handle = async_unsafe()(original_handle)
        return instance

    @classmethod
    @abstractmethod
    def handles(cls) -> Type[TCommand]:
        pass

    @abstractmethod
    def handle(self, command: TCommand) -> None:
        pass
