from abc import ABC, abstractmethod
from typing import Generic, Type, TypeVar

from buz import Handler
from buz.query import Query, QueryResponse
from buz.wrapper.async_unsafe import async_unsafe

TQuery = TypeVar("TQuery", bound=Query)
TQueryResponse = TypeVar("TQueryResponse", bound=QueryResponse)


class QueryHandler(Generic[TQuery, TQueryResponse], Handler[TQuery], ABC):
    def __new__(cls, *args, **kwargs):
        instance = super().__new__(cls)
        original_handle = instance.handle
        instance.handle = async_unsafe()(original_handle)
        return instance

    @classmethod
    @abstractmethod
    def handles(cls) -> Type[TQuery]:
        pass

    @abstractmethod
    def handle(self, query: TQuery) -> TQueryResponse:
        pass
