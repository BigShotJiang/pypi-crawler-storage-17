from enum import Enum


class ConsumerInitialOffsetPosition(Enum):
    BEGINNING = "beginning"
    END = "end"
