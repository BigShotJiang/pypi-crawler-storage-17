import logging
import os
from asyncio import get_running_loop
from functools import wraps
from typing import Callable, Any

from buz.wrapper.synchronous_only_operation_exception import SynchronousOnlyOperationException

logger = logging.getLogger(__name__)


def async_unsafe() -> Callable[[Callable], Callable]:
    """
    Copy-paste from Django source code. If BUZ_SYNC_HANDLERS_FAIL_ON_ASYNC env var is True then an exception is raised to
    prevent event loop from being blocked. If the env var is False, a warning is logged.
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def inner(*args: Any, **kwargs: Any) -> Any:
            try:
                get_running_loop()
            except RuntimeError:
                pass
            else:
                if __get_bool_env("BUZ_SYNC_HANDLERS_FAIL_ON_ASYNC") is True:
                    raise SynchronousOnlyOperationException()

                logger.warning(
                    f"You should not call this from an async context - use a thread or sync_to_async. Class {__get_class_name(func, args)}"
                )

            return func(*args, **kwargs)

        return inner

    return decorator


def __get_bool_env(var_name: str) -> bool:
    """
    >>> get_bool_env("MY_BOOL_VAR")
    False
    >>> os.environ["MY_BOOL_VAR"] = "1"
    >>> get_bool_env("MY_BOOL_VAR")
    True
    >>> os.environ["MY_BOOL_VAR"] = "true"
    >>> get_bool_env("MY_BOOL_VAR")
    True
    >>> os.environ["MY_BOOL_VAR"] = "True"
    >>> get_bool_env("MY_BOOL_VAR")
    True
    >>> os.environ["MY_BOOL_VAR"] = "0"
    >>> get_bool_env("MY_BOOL_VAR")
    False
    >>> os.environ["MY_BOOL_VAR"] = "false"
    >>> get_bool_env("MY_BOOL_VAR")
    False
    """
    return os.environ.get(var_name, "0").lower() in ("true", "1")


def __get_class_name(func: Callable, args: tuple) -> str:
    if hasattr(func, "__self__"):
        return func.__self__.__class__.__name__

    return args[0].__class__.__name__ if len(args) > 0 else "Unknown"
