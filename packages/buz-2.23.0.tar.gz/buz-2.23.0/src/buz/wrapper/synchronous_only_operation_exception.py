class SynchronousOnlyOperationException(Exception):
    def __init__(self):
        super().__init__("You cannot call this from an async context - use a thread or sync_to_async.")
