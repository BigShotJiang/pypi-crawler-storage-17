############################
Document Incoming OCR Module
############################

The *Document Incoming OCR Module* provides the basis to interact with OCR
services.

.. toctree::
   :maxdepth: 2

   usage
   design
   releases
