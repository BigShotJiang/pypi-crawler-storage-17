from enum import Enum

class HealthAntivirusStatus(Enum):
    DISABLED = "disabled"
    OFFLINE = "offline"
    ONLINE = "online"
