from enum import Enum

class Theme(Enum):
    LIGHT = "light"
    DARK = "dark"
