from enum import Enum

class DatabaseType(Enum):
    LEGACY = "legacy"
    TABLESDB = "tablesdb"
