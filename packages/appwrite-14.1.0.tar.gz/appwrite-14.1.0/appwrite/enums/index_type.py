from enum import Enum

class IndexType(Enum):
    KEY = "key"
    FULLTEXT = "fulltext"
    UNIQUE = "unique"
    SPATIAL = "spatial"
