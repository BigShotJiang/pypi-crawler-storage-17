[![Documentation Status](https://readthedocs.org/projects/har2tree/badge/?version=latest)](https://har2tree.readthedocs.io/en/latest/?badge=latest)
[![codecov](https://codecov.io/gh/Lookyloo/har2tree/branch/main/graph/badge.svg)](https://codecov.io/gh/Lookyloo/har2tree)

Har2Tree
========


This package generate a tree out of a HAR dump.


Installation
============

```bash
pip install har2tree
```
