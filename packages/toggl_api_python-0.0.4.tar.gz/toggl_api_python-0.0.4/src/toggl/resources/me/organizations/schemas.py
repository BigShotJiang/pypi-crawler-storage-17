from typing import TypeAlias
from ..._schemas import Organization

GetOrganizationsResponse: TypeAlias = list[Organization]
