from pydantic import BaseModel

class ObjectModelBase(BaseModel):
    id: int