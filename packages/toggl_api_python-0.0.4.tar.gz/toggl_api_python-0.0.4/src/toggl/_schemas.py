from pydantic import BaseModel, Field

class RequestBody(BaseModel):
    pass

class ResponseBase(BaseModel):
    pass

class QueryBase(BaseModel):
    pass

