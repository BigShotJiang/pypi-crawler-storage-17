"""Base classes for artifact builders.

This package provides the abstract Builder base class that all
artifact builders must inherit from.
"""
