"""Command-line interface for pyrig.

This package provides the CLI entry point and subcommands for pyrig.
Commands are automatically discovered from the subcommands module.
"""
