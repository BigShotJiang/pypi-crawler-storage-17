"""Custom SAX Warnings."""


class ExperimentalWarning(Warning):
    """Warning for experimental features."""
