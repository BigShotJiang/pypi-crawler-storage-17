"""Centralized user-facing text for Vexor CLI."""

from __future__ import annotations

class Styles:
    ERROR = "red"
    WARNING = "yellow"
    SUCCESS = "green"
    INFO = "dim"
    TITLE = "bold cyan"
    TABLE_HEADER = "bold magenta"


class Messages:
    APP_HELP = "Vexor – A vector-powered CLI for semantic search over filenames."
    HELP_QUERY = "Text used to semantically match file names."
    HELP_SEARCH_PATH = "Root directory whose cached index will be used."
    HELP_SEARCH_TOP = "Number of results to display."
    HELP_SEARCH_FORMAT = (
        "Output format (rich=table, porcelain=tab-separated for scripts, porcelain-z=NUL-delimited)."
    )
    HELP_INCLUDE_HIDDEN = "Use the index built with hidden files included."
    HELP_INDEX_PATH = "Root directory to scan for indexing."
    HELP_INDEX_INCLUDE = "Include hidden files and directories when building the index."
    HELP_INDEX_CLEAR = "Remove the cached index for the specified path (respecting include-hidden, mode and recursion)."
    HELP_INDEX_SHOW = "Display metadata for the cached index matching the provided options."
    HELP_RECURSIVE = "Recurse into subdirectories (default). Disable to work only on the specified directory."
    HELP_MODE = (
        "Indexing mode (auto=smart default, name=filename, head=head snippet, brief=keyword summary, "
        "full=chunked content, code=python module/function/class chunks, outline=markdown headings) "
        "to control how embeddings are built."
    )
    HELP_EXTENSIONS = "Limit indexing/searching to files whose names end with the provided extensions (repeat --ext for multiple)."
    HELP_RESPECT_GITIGNORE = (
        "Respect .gitignore-style exclude rules when scanning (default). "
        "Use --no-respect-gitignore to include ignored files."
    )
    HELP_DOCTOR = "Check whether the `vexor` command is available on the current PATH."
    HELP_UPDATE = "Check if a newer Vexor release is available online."
    HELP_SET_API_KEY = "Persist an API key in ~/.vexor/config.json."
    HELP_CLEAR_API_KEY = "Remove the stored API key."
    HELP_SET_MODEL = "Set the default embedding model."
    HELP_SET_BATCH = "Set the default batch size (0 = single request)."
    HELP_SET_PROVIDER = "Set the default embedding provider (e.g., gemini or openai)."
    HELP_SET_BASE_URL = "Override the provider's base URL (leave unset for official endpoints)."
    HELP_CLEAR_BASE_URL = "Remove the custom base URL override."
    HELP_SHOW_CONFIG = "Show current configuration."
    HELP_SHOW_INDEX_ALL = "Show metadata for every cached index regardless of path."
    HELP_CLEAR_INDEX_ALL = "Delete all cached indexes stored under ~/.vexor."
    HELP_INSTALL_SKILLS = (
        "Install the bundled `vexor-cli` Agent Skill into an AI assistant skills directory "
        "(targets: claude, codex)."
    )
    HELP_INSTALL_FORCE = "Overwrite the destination skill folder if it already exists."

    ERROR_API_KEY_MISSING = (
        "API key is missing or still set to the placeholder. "
        "Configure it via `vexor config --set-api-key <token>` or an environment variable."
    )
    ERROR_API_KEY_INVALID = "API key appears invalid. Verify the stored token and try again."
    ERROR_GENAI_PREFIX = "Gemini API request failed: "
    ERROR_OPENAI_PREFIX = "OpenAI API request failed: "
    ERROR_NO_EMBEDDINGS = "Embedding API returned no embeddings."
    ERROR_EMPTY_QUERY = "Query text must not be empty."
    ERROR_BATCH_NEGATIVE = "Batch size must be >= 0"
    ERROR_MODE_INVALID = "Unsupported mode '{value}'. Allowed values: {allowed}."
    ERROR_PROVIDER_INVALID = "Unsupported provider '{value}'. Allowed values: {allowed}."
    ERROR_BASE_URL_CONFLICT = "Cannot set and clear the base URL in the same command."
    ERROR_EXTENSIONS_EMPTY = "Provide at least one valid file extension when using --ext."

    INFO_NO_FILES = "No files found in the selected directory."
    INFO_NO_RESULTS = "No matching files found."
    ERROR_INDEX_MISSING = (
        "No cached index found for {path}. Run `vexor index` first."
    )
    INFO_INDEX_SAVED = "Index saved to {path}."
    INFO_INDEX_EMPTY = "Index contains no files."
    INFO_INDEX_UP_TO_DATE = "Index already matches the current directory; nothing to do."
    WARNING_INDEX_STALE = "Cached index for {path} appears outdated; run `vexor index` to refresh."
    INFO_INDEX_RUNNING = "Indexing files under {path}..."
    INFO_INDEX_CLEARED = "Removed {count} cached index entr{plural} for {path}."
    INFO_INDEX_CLEAR_NONE = "No cached index found for {path}."
    ERROR_INDEX_SHOW_CONFLICT = "Cannot use --show together with --clear."
    INFO_INDEX_SHOW_HEADER = "Cached index details for {path}:"
    INFO_INDEX_SHOW_SUMMARY = (
        "Mode: {mode}\n"
        "Model: {model}\n"
        "Include hidden: {hidden}\n"
        "Recursive: {recursive}\n"
        "Respect gitignore: {gitignore}\n"
        "Extensions: {extensions}\n"
        "Files: {files}\n"
        "Embedding dimension: {dimension}\n"
        "Version: {version}\n"
        "Generated at: {generated}"
    )
    INFO_INDEX_ALL_HEADER = "Cached index overview"
    INFO_INDEX_ALL_EMPTY = "No cached indexes found under ~/.vexor."
    INFO_INDEX_ALL_CLEARED = "Removed {count} cached index entr{plural} in total."
    INFO_INDEX_ALL_CLEAR_NONE = "Cache already empty; nothing to remove."
    INFO_API_SAVED = "API key saved."
    INFO_API_CLEARED = "API key cleared."
    INFO_MODEL_SET = "Default model set to {value}."
    INFO_BATCH_SET = "Default batch size set to {value}."
    INFO_PROVIDER_SET = "Default provider set to {value}."
    INFO_BASE_URL_SET = "Base URL override set to {value}."
    INFO_BASE_URL_CLEARED = "Base URL override cleared."
    INFO_CONFIG_EDITING = "Opening config file in editor ({editor}): {path}"
    ERROR_CONFIG_EDITOR_NOT_FOUND = "Unable to determine a text editor. Set $VISUAL or $EDITOR, or install nano/vi."
    ERROR_CONFIG_EDITOR_FAILED = "Editor exited with status {code}."
    ERROR_CONFIG_EDITOR_LAUNCH = "Failed to launch editor: {reason}."
    INFO_CONFIG_SUMMARY = (
        "API key set: {api}\n"
        "Default provider: {provider}\n"
        "Default model: {model}\n"
        "Default batch size: {batch}\n"
        "Custom base URL: {base_url}"
    )
    INFO_SEARCH_RUNNING = "Searching cached index under {path}..."
    INFO_DOCTOR_CHECKING = "Checking if `vexor` is on PATH..."
    INFO_DOCTOR_FOUND = "`vexor` command is available at {path}."
    ERROR_DOCTOR_MISSING = (
        "`vexor` command is not on PATH. Install with pip or add the script directory to PATH."
    )
    INFO_UPDATE_CHECKING = "Checking latest Vexor version..."
    INFO_UPDATE_CURRENT = "You are running Vexor v{current}."
    INFO_UPDATE_AVAILABLE = (
        "New version available: v{latest}. Visit {github} or {pypi} to download the update."
    )
    INFO_UPDATE_UP_TO_DATE = "You already have the latest version (v{latest})."
    ERROR_UPDATE_FETCH = "Unable to fetch latest version information ({reason})."
    ERROR_INSTALL_SKILL_SOURCE = "Unable to locate the bundled skill files ({reason})."
    ERROR_INSTALL_SKILL_EXISTS = (
        "Skill destination already exists: {path}. Use --force to overwrite."
    )

    TABLE_TITLE = "Vexor semantic file search results"
    TABLE_HEADER_INDEX = "#"
    TABLE_HEADER_SIMILARITY = "Similarity"
    TABLE_HEADER_PATH = "File path"
    TABLE_HEADER_LINES = "Lines"
    TABLE_HEADER_PREVIEW = "Preview"
    TABLE_BACKEND_PREFIX = "Backend: "
    TABLE_INDEX_HEADER_ROOT = "Root"
    TABLE_INDEX_HEADER_MODE = "Mode"
    TABLE_INDEX_HEADER_MODEL = "Model"
    TABLE_INDEX_HEADER_HIDDEN = "Hidden"
    TABLE_INDEX_HEADER_RECURSIVE = "Recursive"
    TABLE_INDEX_HEADER_GITIGNORE = "Gitignore"
    TABLE_INDEX_HEADER_EXTENSIONS = "Extensions"
    TABLE_INDEX_HEADER_FILES = "Files"
    TABLE_INDEX_HEADER_GENERATED = "Generated"

    INFO_INSTALL_SKILL_UP_TO_DATE = "Skill already up to date at {path}."
    INFO_INSTALL_SKILL_DONE = "Installed skill to {path}."
