"""
----------------------------------------------------------------------------------
 Author:  Frank Runfola
 Created: 7/10/25
----------------------------------------------------------------------------------
"""
   
import sys
import time
import datetime
from random import randrange
import random
import re
from time import gmtime, strftime
import pyautogui
import pywinauto
import RPA.Windows as rpawin
import typing
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
import pywinauto.base_wrapper
import pywinauto.controls
import pywinauto.element_info
import pywinauto.uia_element_info
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows
from pywinauto import timings
from pywinauto import findbestmatch
from pywinauto.application import Application


DELIMITER_LEN = 30
AlteraWindow = "Altera Gateway"
_static_win = None
   
if __name__ == '__main__':
    logger.console(f"\nBEGIN MAIN....\n")
