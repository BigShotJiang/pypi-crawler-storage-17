"""
----------------------------------------------------------------------------------
 Author:  Frank Runfola
 Created: 15/23/25
----------------------------------------------------------------------------------
"""
   
import sys
import time
import datetime
from random import randrange
import random
import re
from time import gmtime, strftime
import pyautogui
import pywinauto
import RPA.Windows as rpawin
import typing
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
import pywinauto.base_wrapper
import pywinauto.controls
import pywinauto.element_info
import pywinauto.uia_element_info
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows
from pywinauto import timings
from pywinauto import findbestmatch
from pywinauto.application import Application


DELIMITER_LEN = 30
AlteraWindow = "Altera Gateway"
_static_win = None


dict = {
    "TonyStark":  ["Genius", "Billionarie",  "Playboy"],  
    "SteveRogers": ["Super Soldier", "Captain America", "Avenger"],
    "BruceBanner": ["Genius", "Hulk", "Avenger"],
    "NatashaRomanoff": ["Black Widow", "Avenger"],
    "ClintBarton": ["Hawkeye", "Avenger"]
}



def Get_Altera_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if "Altera Gateway" in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id, handle=proc.handle)
            break
        
    if not app:
        raise Exception("Altera Application not found!!!")
    
    return app,proc

def Enter_Flowsheet_Top_3_Rows_Data_Py(X,Y,checkBoxCount):
    try:
        X = int(X)
        Y = int(Y)
        checkBoxCount = int(checkBoxCount)

        logger.console(f"    Enter_Flowsheet_Top_3_Rows_Data_Py(coords=({X},{Y}), checkBoxCount={checkBoxCount}) ...[Py]")
        logger.console(f"       Click 'Rounding_Performed_CheckBox' (coords=({X},{Y})) ...[Py]")
        pywinauto.mouse.move(coords=(X,Y))
        time.sleep(2)
        pywinauto.mouse.click(coords=(X,Y))
        time.sleep(2)
        ##########################################################
        # Click 8 'Rounding Performed' CheckBoxes
        ##########################################################
        for i in range(0, checkBoxCount):
            logger.console(f"       press 'DOWN, SPACE' (Check Box) ...[Py]")
            pyautogui.press("DOWN")
            pyautogui.press("SPACE")
            time.sleep(0.5)
   
        logger.console(f"       press 'ENTER' (Click OK) ...[Py]\n")
        pyautogui.press("ENTER")
        time.sleep(2)

        ##########################################################
        # Enter 'Patient ID band' as 'right wrist'
        ##########################################################
        logger.console(f"       press 'DOWN DOWN, SPACE  ENTER' ('Patient ID band' as 'right wrist') ...[Py]")
        pyautogui.press("DOWN")
        pyautogui.press("DOWN")
        pyautogui.press("SPACE")
        pyautogui.press("ENTER")
        time.sleep(2)

        ##########################################################
        # Enter 'Auto Entered Documentation Reviewed' as 'Yes'
        ##########################################################
        logger.console(f"       press 'DOWN DOWN, SPACE  ENTER' ('Auto Entered Documentation Reviewed' as 'Yes') ...[Py]\n")
        pyautogui.press("DOWN")
        pyautogui.press("DOWN")
        pyautogui.press("SPACE")
        pyautogui.press("ENTER")
        time.sleep(2)

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Enter_Flowsheet_Top_3_Rows_Data_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        logger.console(f"")
        raise Exception(f"\nError={e}\n")


def Enter_Flowsheet_Patient_Acuity_Data_Py(X,Y):
    try:
        X = int(X)
        Y = int(Y)

        logger.console(f"    Enter_Flowsheet_Patient_Acuity_Data_Py(coords=({X},{Y})) ...[Py]")
        logger.console(f"       Click 'Rounding_Performed_CheckBox' (coords=({X},{Y})) ...[Py]")
        pywinauto.mouse.move(coords=(X,Y))
        time.sleep(1.5)
        pywinauto.mouse.click(coords=(X,Y))
        time.sleep(1.5)
        
        logger.console(f"       Click 'Activity Level': '1 assist' ...[Py]")
        Select_Patient_Acuity_Checkbox(downClicks=3)
        time.sleep(1)
        
        logger.console(f"       Click 'Oxy Req': 'room air, stable oxygenation' ...[Py]")
        Select_Patient_Acuity_Checkbox(downClicks=2)
        time.sleep(1)
        
        logger.console(f"       Click 'Tubes and Drains': '1-2 tubes or drains' ...[Py]")
        Select_Patient_Acuity_Checkbox(downClicks=3)
        time.sleep(1)
        
        logger.console(f"       Click 'Mental Status': 'Alert and Oriented' ...[Py]")
        Select_Patient_Acuity_Checkbox(downClicks=2)
        time.sleep(1)
        
        logger.console(f"       Click 'Teaching': 'Standard teaching...' ...[Py]")
        Select_Patient_Acuity_Checkbox(downClicks=2)
        time.sleep(1)
        
        logger.console(f"       Click 'Psychosocial': 'Not Applicable' ...[Py]")
        Select_Patient_Acuity_Checkbox(downClicks=2)
        time.sleep(1)
        
        logger.console(f"       Click 'Medications': '>5 continuous drips' ...[Py]")
        Select_Patient_Acuity_Checkbox(downClicks=7)
        time.sleep(1)
        
        logger.console(f"       Click 'Nursing Interention': 'q4h' ...[Py]")
        Select_Patient_Acuity_Checkbox(downClicks=3)
        time.sleep(1)
        
        logger.console(f"       Click 'Blood Products': '1-2 units' ...[Py]")
        Select_Patient_Acuity_Checkbox(downClicks=3)
        time.sleep(1)
        
        logger.console(f"       Click 'Critical Care Specific Order Sets': 'Not applicable' ...[Py]\n")
        Select_Patient_Acuity_Checkbox(downClicks=2)
        
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Enter_Flowsheet_Patient_Acuity_Data_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        logger.console(f"")
        raise Exception(f"Error={e}")
    

def Select_Patient_Acuity_Checkbox(downClicks):
        for i in range(0, downClicks):
            pyautogui.press("DOWN")
            time.sleep(0.5)
        
        pyautogui.press("SPACE")
        pyautogui.press("ENTER")
        time.sleep(1)


def  Save_Nursing_Universal_Flow_Sheet_Py():
    try:
        logger.console(f"    Save_Nursing_Universal_Flow_Sheet_Py() ...[Py]")
        app, proc = Get_Altera_App()
        app = app.window(handle=proc.handle)
        app.set_focus()
        dlg = app.window(auto_id="ScmApplicationHost",control_type="Custom", found_index=0)
        dlg = dlg.child_window(auto_id="ClrTabHost", class_name="ClrTabHost",control_type="Custom")
        dlg = dlg.child_window(class_name="WindowsFormsHost", control_type="Pane", found_index=0)
        dlg = dlg.child_window(class_name_re="WindowsForms10.*", control_type="Pane", found_index=0)
        dlg = dlg.child_window(auto_id="XAUserControl", control_type="Pane", found_index=0)
        dlg = dlg.child_window(auto_id="FlowsheetMain", control_type="Pane", found_index=0)
        dlg = dlg.child_window(auto_id="pnlFlowsheetHeader", control_type="Pane", found_index=0)
        dlg = dlg.child_window(auto_id="btnSaveFlowsheet", control_type="Button")
        logger.console(f"      Click 'Save' ...[Py]\n")
        dlg.click_input()  #click_input(double=True)
        
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Save_Nursing_Universal_Flow_Sheet_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        logger.console(f"") 
        raise Exception(f"\n Error={e}\n")

if __name__ == '__main__':
    logger.console(f"\nBEGIN MAIN....\n")
    Enter_Flowsheet_Top_3_Rows_Data_Py(400,425,8)
    ##Enter_Flowsheet_Patient_Acuity_Data_Py(797,580)
    #Save_Nursing_Universal_Flow_Sheet_Py()
