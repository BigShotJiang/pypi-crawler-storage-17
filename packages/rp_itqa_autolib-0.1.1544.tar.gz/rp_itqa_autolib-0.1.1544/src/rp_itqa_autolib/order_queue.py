"""
----------------------------------------------------------------------------------
 Author:  Andrew Bowman, Frank Runfola
 Created: 07/01/2023
----------------------------------------------------------------------------------
"""

from robot.api import logger
import typing
from robot.libraries.BuiltIn import BuiltIn
from db import *
import traceback
import os

PatientID = str # ex. 1006794 a.k.a. MRN
VisitNumber = str # a.k.a. Appointment Number
OrderName = str # ex. "17 Beta Estradiol"
OrderType = str # ex. "CT" todo: link a list to this to formalize the domain
OrderToSchedule = tuple[PatientID, VisitNumber, OrderType, OrderName]



# ---------------------------------------------------------------------------------------------------
#    Gets the orders that need to be scheduled.  return: a list of orders that need to be scheduled
# ---------------------------------------------------------------------------------------------------
def get_orders_to_schedule_query_py(order_type: typing.Union[str, None] = None) -> list[OrderToSchedule]:
    q = """
        SELECT MRN, AppointmentNumber, OrderType, OrderName, SearchId, RecordID, Submitted 
        FROM   td.OrdersToSchedule
        WHERE  MRN IS NOT NULL
               AND AppointmentNumber IS NOT NULL
               AND OrderName IS NOT NULL
               AND ActiveTestCase = \'A\'
               AND UPPER(Submitted) <> \'Y\'
               AND TCID LIKE 'O2S_Step1%'"""\

    if order_type is not None:
        q += f'''
               AND OrderType = \'{order_type}\''''
    q += '''
        ORDER BY MRN ASC'''
    result = query(q)
    return result

# ---------------------------------------------------------------------------------------------------
#  Gets the mrns that need to update allergy and healthIssuesed
# ---------------------------------------------------------------------------------------------------
def get_orders_to_schedule_mrns_from_db_py() -> list[OrderToSchedule]:
    # --, AppointmentNumber, OrderType, OrderName, SearchId 
    q = """
        SELECT MRN, COUNT (*) as MRNCount
        FROM   td.OrdersToSchedule
        WHERE  MRN                    IS NOT NULL
                AND AppointmentNumber IS NOT NULL
                AND OrderName         IS NOT NULL
                AND UPPER(Submitted) <> 'Y'
                AND ActiveTestCase = 'A'
                AND TCID LIKE 'O2S_Step1%'
        GROUP BY MRN
        ORDER BY MRN ASC
        """
    result = query(q)
    logger.console(f'   {len(result)} rows returned')
    return result

# ---------------------------------------------------------------------------------------------------
#  Gets the visit nums that need to be validated
# ---------------------------------------------------------------------------------------------------
def get_orders_to_schedule_visit_nums_from_db_py(tcid) -> list[OrderToSchedule]:
    q = """
        SELECT MRN, OrderAppointmentNumber, OrderVisitNumber
        FROM   td.OrdersToSchedule
        WHERE  MRN IS NOT NULL
                AND OrderAppointmentNumber IS NOT NULL
                AND OrderVisitNumber IS NOT NULL
                AND ActiveTestCase = 'A'
                AND TCID LIKE '""" + tcid + """%'
        ORDER BY MRN ASC
        """
    result = query(q)
    return result

# ---------------------------------------------------------------------------------------------------
#  Gets the mrns that need to update allergy and healthIssuesed
# ---------------------------------------------------------------------------------------------------
def update_o2s_record_as_submitted_py(RecordID: int)-> bool:
    u = f"""
        UPDATE  td.OrdersToSchedule
        SET    Submitted = 'Y'
        WHERE  RecordID = {RecordID}
     """
    logger.console(f'{u}')
    updated = False

    try:
        update(u) 
        updated= True
    except  Exception as e:
        print(f'UPDATE ERROR  = {e}')
    finally:
        logger.console(f'   Rows Updated = {updated}')

    return updated


def get_order_name_py(orderId: str) -> str:
    orderName = str.replace(orderId, "<", "")
    orderName = str.replace(orderName, ">", "")
    orderName = orderName.split(';')
    orderName = orderName[0]
    orderName = str.replace(orderName, "name:", "")
    return orderName 


def _locate_order_type_keyword(order_type: OrderType) -> str:
    """
    Search for a keyword that looks like "Do {order_type} order" in the robot files in
    the Tests/singleOrders directory
    :param order_type: An order type, like 'CT', 'MRI', etc.
    :return:
    """
    # get all the filenames in the tests directory at Tests/singleOrders
    # filtered by the .robot files
    fns = [fn for fn in os.listdir('Tests/singleOrders') if fn.endswith('.robot')]

    # remove '.robot'
    fns = [fn[:-len('.robot')] for fn in fns]
    mp = { fn.replace(' ', '').lower(): fn for fn in fns }

    no_spaces_order_type = order_type.replace(' ', '').lower()

    if no_spaces_order_type in mp:
        fn = mp[no_spaces_order_type]
        BuiltIn().import_resource(f'Tests/singleOrders/{fn}.robot')
        kw = f'Do {fn} order'
        BuiltIn().keyword_should_exist(kw)
        return kw

    raise Exception(f'Could not find order type "{order_type}" or "{no_spaces_order_type}" in Tests/singleOrders')


def execute_order_to_schedule(patient_id: typing.Union[PatientID, OrderToSchedule],
                              visit_number: VisitNumber=None,
                              order_type: OrderType=None,
                              order_name: OrderName=None):
    """
    Use `order_type` to find a robot keyword that looks like "Do {order_type} order" and run it with
    the arguments (patient_id, visit_number, order_name)
    :param patient_id: the Patient ID, or MRN
    :param visit_number: The visit number, or appointment number
    :param order_type: Order type; determines which script to run
    :param order_name: Order name, or variable name (ex. "17 Beta Estradiol")
    """
    if isinstance(patient_id, tuple):
        patient_id, visit_number, order_type, order_name = patient_id
    keyword = _locate_order_type_keyword(order_type)
    BuiltIn().run_keyword(keyword, patient_id, visit_number, order_name)




if __name__ == "__main__":
    get_orders_to_schedule_query_py("ct")
