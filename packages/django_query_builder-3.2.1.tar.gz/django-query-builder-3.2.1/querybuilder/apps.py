from django.apps import AppConfig


class QueryBuilderConfig(AppConfig):
    name = 'querybuilder'
    verbose_name = 'Django Query Builder'
