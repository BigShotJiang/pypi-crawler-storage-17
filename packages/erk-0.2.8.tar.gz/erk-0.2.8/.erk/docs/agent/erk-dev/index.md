<!-- AUTO-GENERATED FILE - DO NOT EDIT DIRECTLY -->
<!-- Edit source frontmatter, then run 'erk docs sync' to regenerate. -->

# Erk Dev Documentation

- **[release-process.md](release-process.md)** — releasing a new version of erk, creating version tags, understanding the erk release workflow
- **[testing.md](testing.md)** — writing tests for erk-dev commands, getting context injection errors in erk-dev tests, testing ErkDevContext-based commands
