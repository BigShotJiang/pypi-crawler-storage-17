### fake-driven-testing (v0.2.5)

**Purpose**: Defense-in-depth testing architecture for Python with fake implementations and automatic suggestion hook

**Artifacts**:

- skill: skills/fake-driven-testing/SKILL.md, skills/fake-driven-testing/references/anti-patterns.md, skills/fake-driven-testing/references/gateway-architecture.md, skills/fake-driven-testing/references/patterns.md, skills/fake-driven-testing/references/python-specific.md, skills/fake-driven-testing/references/quick-reference.md, skills/fake-driven-testing/references/testing-strategy.md, skills/fake-driven-testing/references/workflows.md

**Usage**:

- Load `fake-driven-testing` skill
