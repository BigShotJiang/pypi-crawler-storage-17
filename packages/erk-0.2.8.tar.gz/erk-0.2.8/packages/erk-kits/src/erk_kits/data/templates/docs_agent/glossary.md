---
title: Glossary
read_when:
  - "looking up terminology or definitions"
---

# Glossary

Define project-specific terms and concepts here.

## Example Entry

**Term Name**: Brief definition of what this term means in the context of this project.
