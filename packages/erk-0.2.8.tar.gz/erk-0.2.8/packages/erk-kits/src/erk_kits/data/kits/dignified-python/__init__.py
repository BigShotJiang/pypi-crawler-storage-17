"""Unified dignified-python kit with version-specific skills."""
