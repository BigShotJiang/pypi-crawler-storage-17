"""CLI entry point for ccsesh."""

from ccsesh.cli import cli

if __name__ == "__main__":
    cli()
