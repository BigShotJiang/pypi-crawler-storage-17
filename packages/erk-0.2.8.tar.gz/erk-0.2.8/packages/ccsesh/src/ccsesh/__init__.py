"""Claude Code session inspection tools."""
