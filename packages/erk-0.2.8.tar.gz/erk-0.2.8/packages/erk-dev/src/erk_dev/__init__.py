"""Workstack development CLI.

Import from submodules:
- __main__: cli
"""
