# Engineering Workflow

Define your team's development workflow here.

1. **Tickets:** Work starts with a Jira/Linear ticket.
2. **Commits:** Commit messages reference the ticket ID.
3. **Review:** All changes require code review.
4. **Done:** A ticket is 'Done' when tests pass and deployed.

<!-- Customize this workflow to match your team's process -->
