"""Squadron Knowledge - The Context Layer"""
