"""Discord Bridge Skill"""
from squadron.skills.discord_bridge.tool import DiscordTool

__all__ = ["DiscordTool"]
