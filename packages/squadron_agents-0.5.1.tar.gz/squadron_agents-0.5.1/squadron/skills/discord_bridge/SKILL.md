## Discord Bridge Skill

Use this skill to broadcast updates to your Discord community.

- **Trigger:** When you want to share wins or updates publicly.
- **Command:** `squadron broadcast --msg "Just shipped a new feature!"`
