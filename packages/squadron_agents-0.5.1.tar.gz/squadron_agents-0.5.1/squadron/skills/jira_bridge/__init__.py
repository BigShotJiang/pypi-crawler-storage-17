"""Jira Bridge Skill"""
from squadron.skills.jira_bridge.tool import JiraTool

__all__ = ["JiraTool"]
