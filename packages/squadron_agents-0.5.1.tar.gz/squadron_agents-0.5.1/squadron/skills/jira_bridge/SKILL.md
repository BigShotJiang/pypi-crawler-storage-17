## Jira Bridge Skill

Use this skill to update Jira tickets.

- **Trigger:** When you complete a task or need to report a blocker.
- **Command:** `squadron report --ticket [ID] --msg [UPDATE]`
