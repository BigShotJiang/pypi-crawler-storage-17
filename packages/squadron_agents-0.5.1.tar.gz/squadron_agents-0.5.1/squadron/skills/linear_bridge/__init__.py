"""Linear Bridge Skill"""
from squadron.skills.linear_bridge.tool import LinearTool

__all__ = ["LinearTool"]
