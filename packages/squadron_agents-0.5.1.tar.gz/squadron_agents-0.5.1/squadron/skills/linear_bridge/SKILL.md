## Linear Bridge Skill

Use this skill to update Linear issues.

- **Trigger:** When working on tasks tracked in Linear.
- **Command:** `squadron report --linear "PRO-123" --msg "Fixed bug"`
