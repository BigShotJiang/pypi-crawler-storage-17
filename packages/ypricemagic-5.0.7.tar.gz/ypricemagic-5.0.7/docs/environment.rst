Environment Variables
=====================

.. automodule:: y.ENVIRONMENT_VARIABLES
    :members:
    :undoc-members:

.. autodata:: CACHE_TTL
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: CONTRACT_CACHE_TTL
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: GETLOGS_BATCH_SIZE
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: GETLOGS_DOP
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: CHECKSUM_CACHE_MAXSIZE
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: DB_PROVIDER
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: SQLITE_PATH
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: DB_HOST
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: DB_PORT
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: DB_USER
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: DB_PASSWORD
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: DB_DATABASE
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: SKIP_CACHE
    :module: y.ENVIRONMENT_VARIABLES

.. autodata:: SKIP_YPRICEAPI
    :module: y.ENVIRONMENT_VARIABLES
