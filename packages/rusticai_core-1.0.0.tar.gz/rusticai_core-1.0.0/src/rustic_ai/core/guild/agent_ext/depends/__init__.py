from .dependency_resolver import DependencyResolver

__all__ = [
    "DependencyResolver",
]
