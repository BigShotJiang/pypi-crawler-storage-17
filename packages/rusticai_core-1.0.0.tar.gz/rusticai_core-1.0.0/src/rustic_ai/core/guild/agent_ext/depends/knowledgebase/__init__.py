from .backend_resolver import InMemoryKBIndexBackendResolver

__all__ = [
    "InMemoryKBIndexBackendResolver",
]
