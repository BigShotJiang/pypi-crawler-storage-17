
# Welcome to Xplt
A plotting library for [Xsuite](https://github.com/xsuite) and simmilar accelerator physics codes.

```{toctree}
:caption: Contents
:maxdepth: 1

quickstart
usage
api
```
[Version history and changelog](https://github.com/xsuite/xplt/releases)

-----

{ref}`genindex` •
{ref}`modindex` •
{ref}`search`
