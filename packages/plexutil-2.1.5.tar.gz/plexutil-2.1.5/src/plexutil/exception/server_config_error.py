class ServerConfigError(Exception):
    pass
