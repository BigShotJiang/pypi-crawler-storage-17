# HOS可扩展式办公平台

HOS可扩展式办公平台是一个集成了文档生成、模板配置、工作流搭建等功能的办公自动化工具。

## 功能特性

### 核心功能
- **文档生成**：支持单文档生成和批量生成
- **模板配置**：灵活的模板管理系统，支持多种格式
- **工作流搭建**：可视化工作流设计器，支持自定义流程
- **API集成**：支持DeepSeek API和本地Ollama

### 扩展功能
- **会议管理**：会议创建、会议纪要生成
- **任务管理**：任务创建、进度跟踪
- **知识库管理**：知识文档存储和检索

## 安装方法

### 1. 使用pip安装

```bash
pip install hos_office_platform
```

### 2. 从源码安装

```bash
git clone https://github.com/hos-project/hos-office-platform.git
cd hos-office-platform
pip install -e .
```

### 3. 直接运行

```bash
cd hos_office_platform
python app.py
```

## 依赖要求

- Python 3.8+
- Flask 2.0.0+
- pandas 1.5.0+
- python-docx 0.8.11+
- python-pptx 0.6.21+
- pdf2image 1.16.0+
- Pillow 9.0.0+
- pyyaml 6.0+
- requests 2.28.0+

## 使用说明

### 启动服务

```bash
# 使用命令行工具启动
hos-platform

# 或直接运行
python app.py
```

### 访问系统

启动服务后，在浏览器中访问：
```
http://127.0.0.1:5000
```

### 配置API

1. 在系统设置页面配置API密钥
2. 选择API来源（DeepSeek或本地Ollama）
3. 测试连接

### 创建模板

1. 进入模板配置页面
2. 创建新模板或导入现有模板
3. 配置模板内容和格式

### 生成文档

1. 进入文档生成页面
2. 输入提示词
3. 选择模板
4. 点击生成按钮

### 批量生成

1. 进入批量生成标签页
2. 输入或导入批量提示词
3. 选择模板和文件格式
4. 点击批量生成按钮
5. 在任务列表中查看进度

## 项目结构

```
hos_office_platform/
├── static/           # 静态资源
│   ├── css/         # 样式文件
│   └── js/          # JavaScript文件
├── templates/        # HTML模板
├── utils/           # 工具模块
│   ├── api_client.py        # API客户端
│   ├── report_generator.py  # 报告生成器
│   ├── template_manager.py  # 模板管理器
│   └── task_manager.py      # 任务管理器
├── app.py           # 主应用文件
├── requirements.txt # 依赖列表
└── setup.py         # 安装配置
```

## 命令行参数

```bash
# 启动服务，指定端口
hos-platform --port 8080

# 启动服务，启用调试模式
hos-platform --debug

# 显示帮助信息
hos-platform --help
```

## 开发指南

### 本地开发

1. 克隆代码库
2. 安装依赖
3. 启动开发服务器

```bash
pip install -r requirements.txt
python app.py --debug
```

### 代码结构

- **app.py**：主应用，包含路由定义
- **utils/**：工具模块，包含核心功能实现
- **templates/**：HTML模板，使用Jinja2渲染
- **static/**：静态资源，包含CSS和JavaScript

### 添加新功能

1. 在utils/目录下创建新的工具模块
2. 在app.py中添加路由
3. 在templates/中添加HTML模板
4. 在static/js/中添加JavaScript代码

## 测试

### 单元测试

```bash
python -m pytest tests/
```

### 功能测试

1. 启动服务
2. 在浏览器中访问
3. 测试各项功能

## 部署

### 生产环境部署

1. 使用WSGI服务器（如Gunicorn）
2. 配置反向代理（如Nginx）
3. 设置环境变量
4. 启动服务

```bash
# 使用Gunicorn启动
gunicorn -w 4 -b 127.0.0.1:5000 hos_office_platform.app:app
```

### Docker部署

```bash
docker build -t hos-platform .
docker run -d -p 5000:5000 hos-platform
```

## 许可证

MIT License

## 贡献

欢迎提交Issue和Pull Request！

## 联系方式

- 项目地址：https://github.com/hos-project/hos-office-platform
- 邮件：hos@example.com
