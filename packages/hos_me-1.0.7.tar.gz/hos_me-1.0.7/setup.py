from setuptools import setup, find_packages
import os

setup(
    name='HOS-ME',
    version='1.0.7',
    author='HOS Team',
    author_email='hos@example.com',
    description='HOS可扩展式办公平台 - HOS-ME',
    long_description=open('README.md', 'r', encoding='utf-8').read() if os.path.exists('README.md') else '',
    long_description_content_type='text/markdown',
    url='https://github.com/hos-project/hos-me',
    packages=find_packages(),
    include_package_data=True,
    package_data={
        '': ['templates/*', 'static/*/*', 'static/*', 'requirements.txt'],
    },
    install_requires=[
        'Flask>=2.0.0',
        'python-dotenv>=0.20.0',
        'openai>=1.0.0',
        'pandas>=1.5.0',
        'python-docx>=0.8.11',
        'python-pptx>=0.6.21',
        'pdf2image>=1.16.0',
        'Pillow>=9.0.0',
        'pyyaml>=6.0',
        'requests>=2.28.0',
    ],
    entry_points={
        'console_scripts': [
            'hos-me=hos_office_platform.app:main',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: End Users/Desktop',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Office/Business',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
    python_requires='>=3.8',
)
