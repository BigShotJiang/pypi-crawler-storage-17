"""Custom exceptions."""

class MFilesException(Exception):
    """M-Files base exception."""
