set catalog 'foo';
