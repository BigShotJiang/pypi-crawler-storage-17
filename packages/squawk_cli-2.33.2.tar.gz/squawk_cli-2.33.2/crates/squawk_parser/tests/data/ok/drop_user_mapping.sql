-- simple
drop user mapping for user server s;

-- full
drop user mapping if exists for current_role server some_server_name;

