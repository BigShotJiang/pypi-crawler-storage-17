-- missing comma
drop database d with ( force  force );
