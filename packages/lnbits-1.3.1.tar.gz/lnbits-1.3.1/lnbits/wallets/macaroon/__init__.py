from .macaroon import load_macaroon

__all__ = ["load_macaroon"]
