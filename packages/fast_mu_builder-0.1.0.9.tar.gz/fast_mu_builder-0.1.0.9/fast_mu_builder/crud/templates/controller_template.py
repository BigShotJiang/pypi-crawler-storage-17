
from fast_mu_builder.crud.gql_controller import GQLBaseCRUD
from _MODELPACKAGE_ import _MODEL_

'''IMPORTS'''

class _MODEL_Controller(GQLBaseCRUD[_MODEL_, _MODEL_Create, _MODEL_Update]):
    pass