########################
Analytic Purchase Module
########################

The *Analytic Purchase Module* adds analytic accounts to the purchase lines.

.. toctree::
   :maxdepth: 2

   design
   releases
