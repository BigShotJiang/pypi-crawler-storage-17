# Placeholder to mark the z_image_omni package for model auto-discovery.
