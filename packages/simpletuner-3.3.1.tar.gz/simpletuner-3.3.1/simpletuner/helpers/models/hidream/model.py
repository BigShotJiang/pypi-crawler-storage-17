import inspect
import logging
import os

import einops
import torch
from transformers import AutoTokenizer, CLIPTextModelWithProjection, CLIPTokenizer, LlamaForCausalLM, T5EncoderModel

from simpletuner.helpers.models.common import ImageModelFoundation, ModelTypes, PipelineTypes, PredictionTypes
from simpletuner.helpers.training.wrappers import gather_dict_of_tensors_shapes, move_dict_of_tensors_to_device

HiDreamImageTransformer2DModel = None
HiDreamImagePipeline: object = None
HiDreamControlNetPipeline: object = None
from diffusers import AutoencoderKL

from simpletuner.helpers.models.hidream.controlnet import HiDreamControlNetPipeline
from simpletuner.helpers.models.hidream.pipeline import HiDreamImagePipeline
from simpletuner.helpers.models.hidream.transformer import (
    HiDreamImageTransformer2DModel,
    clear_load_balancing_loss,
    get_load_balancing_loss,
)

logger = logging.getLogger(__name__)
from simpletuner.helpers.training.multi_process import should_log

if should_log():
    logger.setLevel(os.environ.get("SIMPLETUNER_LOG_LEVEL", "INFO"))
else:
    logger.setLevel("ERROR")


class HiDream(ImageModelFoundation):
    SUPPORTS_MUON_CLIP = True
    NAME = "HiDream"
    MODEL_DESCRIPTION = "High-quality image generation with MoE architecture"
    ENABLED_IN_WIZARD = True
    PREDICTION_TYPE = PredictionTypes.FLOW_MATCHING
    MODEL_TYPE = ModelTypes.TRANSFORMER
    AUTOENCODER_CLASS = AutoencoderKL
    LATENT_CHANNEL_COUNT = 16
    MAXIMUM_CANVAS_SIZE = 1024**2  # H*W cannot exceed this value.
    DEFAULT_NOISE_SCHEDULER = "flow_unipc"
    # The safe diffusers default value for LoRA training targets.
    DEFAULT_LORA_TARGET = ["to_k", "to_q", "to_v", "to_out.0"]
    SLIDER_LORA_TARGET = ["to_k", "to_q", "to_v", "to_out.0"]
    # Only training the Attention blocks by default seems to help more with HiDream.
    DEFAULT_LYCORIS_TARGET = ["Attention"]
    # Layers used from base in ControlNet model.
    SHARED_MODULE_PREFIXES = [
        "double_stream_blocks.",
        "single_stream_blocks.",
        "x_embedder.",
        "t_embedder.",
        "p_embedder.",
        "pe_embedder.",
    ]

    MODEL_CLASS = HiDreamImageTransformer2DModel
    PIPELINE_CLASSES = {
        PipelineTypes.TEXT2IMG: HiDreamImagePipeline,
        # PipelineTypes.IMG2IMG: None,
        PipelineTypes.CONTROLNET: HiDreamControlNetPipeline,
    }
    MODEL_SUBFOLDER = "transformer"
    # The default model flavor to use when none is specified.
    DEFAULT_MODEL_FLAVOUR = "full"
    HUGGINGFACE_PATHS = {
        "dev": "HiDream-ai/HiDream-I1-Dev",
        "full": "HiDream-ai/HiDream-I1-Full",
        "fast": "HiDream-ai/HiDream-I1-Fast",
    }
    MODEL_LICENSE = "other"

    TEXT_ENCODER_CONFIGURATION = {
        "text_encoder": {
            "name": "CLIP-L/14",
            "tokenizer": CLIPTokenizer,
            "tokenizer_subfolder": "tokenizer",
            "model": CLIPTextModelWithProjection,
        },
        "text_encoder_2": {
            "name": "CLIP-G/14",
            "tokenizer": CLIPTokenizer,
            "subfolder": "text_encoder_2",
            "tokenizer_subfolder": "tokenizer_2",
            "model": CLIPTextModelWithProjection,
        },
        "text_encoder_3": {
            "name": "T5 XXL v1.1",
            "tokenizer": AutoTokenizer,
            "subfolder": "text_encoder_3",
            "tokenizer_subfolder": "tokenizer_3",
            "model": T5EncoderModel,
        },
        "text_encoder_4": {
            "name": "Llama",
            "tokenizer": AutoTokenizer,
            "subfolder": "text_encoder_4",
            "tokenizer_subfolder": "tokenizer_4",
            "model": LlamaForCausalLM,
            "path": "terminusresearch/HiDream-I1-Llama-3.1-8B-Instruct",
            # "required_quantisation_level": "int4_weight_only",
        },
    }

    def controlnet_init(self):
        """Initialize HiDream ControlNet"""
        logger.info("Creating the HiDream controlnet..")
        from simpletuner.helpers.models.hidream.controlnet import HiDreamControlNetModel

        if self.config.controlnet_model_name_or_path:
            logger.info("Loading existing controlnet weights")
            self.controlnet = HiDreamControlNetModel.from_pretrained(self.config.controlnet_model_name_or_path)
        else:
            logger.info("Initializing controlnet weights from base model")
            cn_custom_config = self.config.controlnet_custom_config or {}
            self.controlnet = HiDreamControlNetModel.from_transformer(self.unwrap_model(self.model), **cn_custom_config)
        self.controlnet.train()

    def requires_conditioning_latents(self) -> bool:
        """HiDream ControlNet requires latent inputs instead of pixels."""
        if self.config.controlnet:
            return True
        return False

    def requires_conditioning_validation_inputs(self) -> bool:
        """Whether this model requires conditioning inputs during validation."""
        if self.config.controlnet:
            return True
        return False

    def uses_shared_modules(self) -> bool:
        if self.config.controlnet and self.config.controlnet_custom_config.get("use_shared_modules", False):
            return True
        return False

    def pretrained_load_args(self, pretrained_load_args: dict) -> dict:
        args = super().pretrained_load_args(pretrained_load_args)
        if self.config.hidream_load_balancing_loss_weight is not None and self.config.hidream_load_balancing_loss_weight > 0:
            args["aux_loss_alpha"] = self.config.hidream_load_balancing_loss_weight

        return args

    def _load_pipeline(self, pipeline_type: str = PipelineTypes.TEXT2IMG, load_base_model: bool = True):
        """
        Loads the pipeline class for the model.
        """
        active_pipelines = getattr(self, "pipelines", {})
        if pipeline_type in active_pipelines:
            setattr(
                active_pipelines[pipeline_type],
                self.MODEL_TYPE.value,
                self.model,
            )
            if self.config.controlnet:
                setattr(
                    active_pipelines[pipeline_type],
                    "controlnet",
                    self.controlnet,
                )
            return active_pipelines[pipeline_type]
        pipeline_kwargs = {
            "pretrained_model_name_or_path": self._model_config_path(),
        }
        if not hasattr(self, "PIPELINE_CLASSES"):
            raise NotImplementedError("Pipeline class not defined.")
        if pipeline_type not in self.PIPELINE_CLASSES:
            raise NotImplementedError(f"Pipeline type {pipeline_type} not defined in {self.__class__.__name__}.")
        pipeline_class = self.PIPELINE_CLASSES[pipeline_type]
        if not hasattr(pipeline_class, "from_pretrained"):
            raise NotImplementedError(
                f"Pipeline type {pipeline_type} class {pipeline_class} does not have from_pretrained method."
            )
        signature = inspect.signature(pipeline_class.from_pretrained)
        if "watermarker" in signature.parameters:
            pipeline_kwargs["watermarker"] = None
        if "watermark" in signature.parameters:
            pipeline_kwargs["watermark"] = None
        if load_base_model:
            pipeline_kwargs[self.MODEL_TYPE.value] = self.unwrap_model(model=self.model)
        else:
            pipeline_kwargs[self.MODEL_TYPE.value] = None

        if getattr(self, "vae", None) is not None:
            pipeline_kwargs["vae"] = self.unwrap_model(self.vae)
        elif getattr(self, "AUTOENCODER_CLASS", None) is not None:
            pipeline_kwargs["vae"] = self.get_vae()

        text_encoder_idx = 0
        for (
            text_encoder_attr,
            text_encoder_config,
        ) in self.TEXT_ENCODER_CONFIGURATION.items():
            tokenizer_attr = text_encoder_attr.replace("text_encoder", "tokenizer")
            if self.text_encoders is not None and len(self.text_encoders) >= text_encoder_idx:
                pipeline_kwargs[text_encoder_attr] = self.unwrap_model(self.text_encoders[text_encoder_idx])
                pipeline_kwargs[tokenizer_attr] = self.tokenizers[text_encoder_idx]
            else:
                pipeline_kwargs[text_encoder_attr] = None
                pipeline_kwargs[tokenizer_attr] = None
            text_encoder_idx += 1

        self.load_text_tokenizer()
        pipeline_kwargs["tokenizer_4"] = self.tokenizers[3]

        if self.config.controlnet:
            pipeline_kwargs["controlnet"] = self.controlnet

        logger.debug(f"Initialising {pipeline_class.__name__} with components: {pipeline_kwargs}")
        self.pipelines[pipeline_type] = pipeline_class.from_pretrained(
            **pipeline_kwargs,
        )

        return self.pipelines[pipeline_type]

    def tread_init(self):
        """
        Initialize the TREAD model training method.
        """
        from simpletuner.helpers.training.tread import TREADRouter

        if (
            getattr(self.config, "tread_config", None) is None
            or getattr(self.config, "tread_config", None) is {}
            or getattr(self.config, "tread_config", {}).get("routes", None) is None
        ):
            logger.error("TREAD training requires you to configure the routes in the TREAD config")
            import sys

            sys.exit(1)

        self.unwrap_model(model=self.model).set_router(
            TREADRouter(
                seed=getattr(self.config, "seed", None) or 42,
                device=self.accelerator.device,
            ),
            self.config.tread_config["routes"],
        )

    def _format_text_embedding(self, text_embedding: torch.Tensor):
        """
        Models can optionally format the stored text embedding, eg. in a dict, or
        filter certain outputs from appearing in the file cache.

        self.config:
            text_embedding (torch.Tensor): The embed to adjust.

        Returns:
            torch.Tensor: The adjusted embed. By default, this method does nothing.
        """
        t5_embeds, llama_embeds, pooled_prompt_embeds = text_embedding

        return {
            "t5_prompt_embeds": t5_embeds.squeeze(0).detach().clone().to("cpu"),
            "llama_prompt_embeds": llama_embeds.squeeze(0).detach().clone().to("cpu"),
            "pooled_prompt_embeds": pooled_prompt_embeds.squeeze(0).detach().clone().to("cpu"),
        }

    def convert_text_embed_for_pipeline(self, text_embedding: torch.Tensor) -> dict:
        # Only unsqueeze if it's missing the batch dimension
        t5_embeds = text_embedding["t5_prompt_embeds"]
        llama_embeds = text_embedding["llama_prompt_embeds"]
        pooled_embeds = text_embedding["pooled_prompt_embeds"]

        # Add batch dimension if missing
        if t5_embeds.dim() == 2:  # Shape: [seq, dim]
            t5_embeds = t5_embeds.unsqueeze(0)  # Shape: [1, seq, dim]
        if llama_embeds.dim() == 2:  # Shape: [seq, dim]
            llama_embeds = llama_embeds.unsqueeze(0)  # Shape: [1, seq, dim]
        if pooled_embeds.dim() == 1:  # Shape: [dim]
            pooled_embeds = pooled_embeds.unsqueeze(0)  # Shape: [1, dim]

        return {
            "t5_prompt_embeds": t5_embeds.to(self.accelerator.device),
            "llama_prompt_embeds": llama_embeds.to(self.accelerator.device),
            "pooled_prompt_embeds": pooled_embeds.to(self.accelerator.device),
        }

    def convert_negative_text_embed_for_pipeline(self, text_embedding: torch.Tensor) -> dict:
        # Only unsqueeze if it's missing the batch dimension
        t5_embeds = text_embedding["t5_prompt_embeds"]
        llama_embeds = text_embedding["llama_prompt_embeds"]
        pooled_embeds = text_embedding["pooled_prompt_embeds"]

        # Add batch dimension if missing
        if t5_embeds.dim() == 2:  # Shape: [seq, dim]
            t5_embeds = t5_embeds.unsqueeze(0)  # Shape: [1, seq, dim]
        if llama_embeds.dim() == 2:  # Shape: [seq, dim]
            llama_embeds = llama_embeds.unsqueeze(0)  # Shape: [1, seq, dim]
        if pooled_embeds.dim() == 1:  # Shape: [dim]
            pooled_embeds = pooled_embeds.unsqueeze(0)  # Shape: [1, dim]

        return {
            "negative_t5_prompt_embeds": t5_embeds.to(self.accelerator.device),
            "negative_llama_prompt_embeds": llama_embeds.to(self.accelerator.device),
            "negative_pooled_prompt_embeds": pooled_embeds.to(self.accelerator.device),
        }

    def _encode_prompts(self, prompts: list, is_negative_prompt: bool = False):
        """
        Encode prompts for an HiDream model into a single tensor.

        Args:
            prompts: The list of prompts to encode.

        Returns:
            Text encoder output (raw)
        """
        pipeline = self.pipelines.get(PipelineTypes.TEXT2IMG)
        if pipeline is None:
            pipeline = self.get_pipeline(PipelineTypes.TEXT2IMG, load_base_model=False)
        t5_embeds, llama_embeds, pooled_prompt_embeds = pipeline._encode_prompt(
            prompt=prompts,
            prompt_2=prompts,
            prompt_3=prompts,
            prompt_4=prompts,
            device=self.accelerator.device,
            dtype=self.config.base_weight_dtype,
            num_images_per_prompt=1,
            max_sequence_length=self.config.tokenizer_max_length or 128,
        )
        # verbose declarations are simply for clarity.
        return t5_embeds, llama_embeds, pooled_prompt_embeds

    def collate_prompt_embeds(self, text_encoder_output: dict) -> dict:
        return move_dict_of_tensors_to_device(
            {
                "t5_prompt_embeds": torch.stack([e["t5_prompt_embeds"] for e in text_encoder_output], dim=0),
                "llama_prompt_embeds": torch.stack([e["llama_prompt_embeds"] for e in text_encoder_output], dim=0),
                "pooled_prompt_embeds": torch.stack([e["pooled_prompt_embeds"] for e in text_encoder_output], dim=0),
            },
            self.accelerator.device,
        )

    def model_predict(self, prepared_batch):
        """
        Process a batch through the transformer model.

        Args:
            prepared_batch: Dictionary containing input tensors and embeddings

        Returns:
            Dictionary containing model predictions
        """
        hidden_states_buffer = self._new_hidden_state_buffer()
        logger.debug(f"Prompt embeds: {prepared_batch['text_encoder_output']}")
        logger.debug(
            "Input shapes:"
            f"\n{prepared_batch['noisy_latents'].shape}"
            f"\n{prepared_batch['timesteps'].shape}"
            f"\nT5: {prepared_batch['text_encoder_output']['t5_prompt_embeds'].shape if hasattr(prepared_batch['text_encoder_output']['t5_prompt_embeds'], 'shape') else [x.shape for x in prepared_batch['text_encoder_output']['t5_prompt_embeds']]}"
            f"\nLlama: {prepared_batch['text_encoder_output']['llama_prompt_embeds'].shape if hasattr(prepared_batch['text_encoder_output']['llama_prompt_embeds'], 'shape') else [x.shape for x in prepared_batch['text_encoder_output']['llama_prompt_embeds']]}"
            f"\nCLIP L + G: {prepared_batch['text_encoder_output']['pooled_prompt_embeds'].shape}"
        )

        # Handle non-square images
        if prepared_batch["noisy_latents"].shape[-2] != prepared_batch["noisy_latents"].shape[-1]:
            B, C, H, W = prepared_batch["noisy_latents"].shape
            pH, pW = (
                H // self.unwrap_model(model=self.model).config.patch_size,
                W // self.unwrap_model(model=self.model).config.patch_size,
            )

            img_sizes = torch.tensor([pH, pW], dtype=torch.int64).reshape(-1)
            img_ids = torch.zeros(pH, pW, 3)
            img_ids[..., 1] = img_ids[..., 1] + torch.arange(pH)[:, None]
            img_ids[..., 2] = img_ids[..., 2] + torch.arange(pW)[None, :]
            img_ids = img_ids.reshape(pH * pW, -1)
            img_ids_pad = torch.zeros(self.unwrap_model(model=self.model).max_seq, 3)
            img_ids_pad[: pH * pW, :] = img_ids

            img_sizes = img_sizes.unsqueeze(0).to(prepared_batch["noisy_latents"].device)
            img_ids = img_ids_pad.unsqueeze(0).to(prepared_batch["noisy_latents"].device)
            img_sizes = img_sizes.repeat(B, 1)
            img_ids = img_ids.repeat(B, 1, 1)
        else:
            img_sizes = img_ids = None

        latent_model_input = prepared_batch["noisy_latents"]
        if latent_model_input.shape[-2] != latent_model_input.shape[-1]:
            B, C, H, W = latent_model_input.shape
            patch_size = self.unwrap_model(model=self.model).config.patch_size
            pH, pW = H // patch_size, W // patch_size
            out = torch.zeros(
                (
                    B,
                    C,
                    self.unwrap_model(model=self.model).max_seq,
                    patch_size * patch_size,
                ),
                dtype=latent_model_input.dtype,
                device=latent_model_input.device,
            )
            latent_model_input = einops.rearrange(
                latent_model_input,
                "B C (H p1) (W p2) -> B C (H W) (p1 p2)",
                p1=patch_size,
                p2=patch_size,
            )
            out[:, :, 0 : pH * pW] = latent_model_input
            latent_model_input = out

        # Call the forward method with the updated parameter names
        return {
            "model_prediction": self.model(
                hidden_states=latent_model_input.to(
                    device=self.accelerator.device,
                    dtype=self.config.base_weight_dtype,
                ),
                timesteps=prepared_batch["timesteps"],
                timestep_sign=(
                    prepared_batch.get("twinflow_time_sign") if getattr(self.config, "twinflow_enabled", False) else None
                ),
                t5_hidden_states=prepared_batch["text_encoder_output"]["t5_prompt_embeds"],
                llama_hidden_states=prepared_batch["text_encoder_output"]["llama_prompt_embeds"],
                pooled_embeds=prepared_batch["text_encoder_output"]["pooled_prompt_embeds"],
                img_sizes=img_sizes,
                img_ids=img_ids,
                return_dict=False,
                hidden_states_buffer=hidden_states_buffer,
            )[0]
            * -1,  # the model is trained with inverted velocity :(
            "hidden_states_buffer": hidden_states_buffer,
        }

    def controlnet_predict(self, prepared_batch: dict) -> dict:
        """
        Perform a forward pass with ControlNet for HiDream model.

        Args:
            prepared_batch: Dictionary containing the batch data including conditioning_latents

        Returns:
            Dictionary containing the model prediction
        """
        # ControlNet conditioning - HiDream uses latents instead of pixel values
        controlnet_cond = prepared_batch["conditioning_latents"].to(
            device=self.accelerator.device, dtype=self.config.weight_dtype
        )

        # Handle non-square images for noisy latents
        if prepared_batch["noisy_latents"].shape[-2] != prepared_batch["noisy_latents"].shape[-1]:
            B, C, H, W = prepared_batch["noisy_latents"].shape
            pH, pW = (
                H // self.unwrap_model(model=self.model).config.patch_size,
                W // self.unwrap_model(model=self.model).config.patch_size,
            )

            img_sizes = torch.tensor([pH, pW], dtype=torch.int64).reshape(-1)
            img_ids = torch.zeros(pH, pW, 3)
            img_ids[..., 1] = img_ids[..., 1] + torch.arange(pH)[:, None]
            img_ids[..., 2] = img_ids[..., 2] + torch.arange(pW)[None, :]
            img_ids = img_ids.reshape(pH * pW, -1)
            img_ids_pad = torch.zeros(self.unwrap_model(model=self.model).max_seq, 3)
            img_ids_pad[: pH * pW, :] = img_ids

            img_sizes = img_sizes.unsqueeze(0).to(prepared_batch["noisy_latents"].device)
            img_ids = img_ids_pad.unsqueeze(0).to(prepared_batch["noisy_latents"].device)
            img_sizes = img_sizes.repeat(B, 1)
            img_ids = img_ids.repeat(B, 1, 1)
        else:
            img_sizes = img_ids = None

        # Prepare latent model input (for non-square handling)
        latent_model_input = prepared_batch["noisy_latents"]
        if latent_model_input.shape[-2] != latent_model_input.shape[-1]:
            B, C, H, W = latent_model_input.shape
            patch_size = self.unwrap_model(model=self.model).config.patch_size
            pH, pW = H // patch_size, W // patch_size
            out = torch.zeros(
                (
                    B,
                    C,
                    self.unwrap_model(model=self.model).max_seq,
                    patch_size * patch_size,
                ),
                dtype=latent_model_input.dtype,
                device=latent_model_input.device,
            )
            latent_model_input = einops.rearrange(
                latent_model_input,
                "B C (H p1) (W p2) -> B C (H W) (p1 p2)",
                p1=patch_size,
                p2=patch_size,
            )
            out[:, :, 0 : pH * pW] = latent_model_input
            latent_model_input = out

        # ControlNet forward pass - let the controlnet handle its own preprocessing
        # Pass the raw latents without any special preprocessing
        controlnet_block_samples, controlnet_single_block_samples = self.controlnet(
            hidden_states=prepared_batch["noisy_latents"].to(
                device=self.accelerator.device,
                dtype=self.config.base_weight_dtype,
            ),
            controlnet_cond=controlnet_cond.to(
                device=self.accelerator.device,
                dtype=self.config.base_weight_dtype,
            ),
            timesteps=prepared_batch["timesteps"],
            t5_hidden_states=prepared_batch["text_encoder_output"]["t5_prompt_embeds"],
            llama_hidden_states=prepared_batch["text_encoder_output"]["llama_prompt_embeds"],
            pooled_embeds=prepared_batch["text_encoder_output"]["pooled_prompt_embeds"],
            img_sizes=img_sizes,
            img_ids=img_ids,
            conditioning_scale=1.0,  # You might want to make this configurable
            return_dict=False,
        )

        # Prepare kwargs for the main transformer using the preprocessed latent_model_input
        hidream_transformer_kwargs = {
            "hidden_states": latent_model_input.to(
                device=self.accelerator.device,
                dtype=self.config.base_weight_dtype,
            ),
            "timesteps": prepared_batch["timesteps"],
            "timestep_sign": (
                prepared_batch.get("twinflow_time_sign") if getattr(self.config, "twinflow_enabled", False) else None
            ),
            "t5_hidden_states": prepared_batch["text_encoder_output"]["t5_prompt_embeds"],
            "llama_hidden_states": prepared_batch["text_encoder_output"]["llama_prompt_embeds"],
            "pooled_embeds": prepared_batch["text_encoder_output"]["pooled_prompt_embeds"],
            "img_sizes": img_sizes,
            "img_ids": img_ids,
            "return_dict": False,
        }

        # Add ControlNet outputs to kwargs
        if controlnet_block_samples is not None:
            hidream_transformer_kwargs["controlnet_block_samples"] = [
                sample.to(device=self.accelerator.device, dtype=self.config.weight_dtype)
                for sample in controlnet_block_samples
            ]

        if controlnet_single_block_samples is not None:
            hidream_transformer_kwargs["controlnet_single_block_samples"] = [
                sample.to(device=self.accelerator.device, dtype=self.config.weight_dtype)
                for sample in controlnet_single_block_samples
            ]

        # Forward pass through the transformer with ControlNet residuals
        model_pred = self.model(**hidream_transformer_kwargs)[0]

        return {"model_prediction": model_pred * -1}  # the model is trained with inverted velocity :(

    def get_lora_target_layers(self):
        manual_targets = self._get_peft_lora_target_modules()
        if manual_targets:
            return manual_targets
        if getattr(self.config, "slider_lora_target", False) and self.config.lora_type.lower() == "standard":
            return getattr(self, "SLIDER_LORA_TARGET", None) or self.DEFAULT_SLIDER_LORA_TARGET
        if not self.config.controlnet:
            # If no controlnet, return the default LoRA target layers.
            return self.DEFAULT_LORA_TARGET
        targets = [
            "controlnet_x_embedder",
        ]
        for i in range(len(self.unwrap_model().controlnet_blocks)):
            targets.extend(
                [
                    f"controlnet_blocks.{i}",
                    f"controlnet_single_blocks.{i}",
                ]
            )
        return targets

    def check_user_config(self):
        """
        Checks self.config values against important issues. Optionally implemented in child class.
        """
        if self.config.base_model_precision == "fp8-quanto":
            raise ValueError(
                f"{self.NAME} does not support fp8-quanto. Please use fp8-torchao or int8 precision level instead."
            )
        t5_max_length = 128
        if self.config.tokenizer_max_length is None or self.config.tokenizer_max_length == 0:
            logger.warning(f"Setting T5 XXL tokeniser max length to {t5_max_length} for {self.NAME}.")
            self.config.tokenizer_max_length = t5_max_length
        if int(self.config.tokenizer_max_length) > t5_max_length:
            if not self.config.i_know_what_i_am_doing:
                logger.warning(
                    f"Overriding T5 XXL tokeniser max length to {t5_max_length} for {self.NAME} because `--i_know_what_i_am_doing` has not been set."
                )
                self.config.tokenizer_max_length = t5_max_length
            else:
                logger.warning(
                    f"-!- {self.NAME} supports a max length of {t5_max_length} tokens, but you have supplied `--i_know_what_i_am_doing`, so this limit will not be enforced. -!-"
                )
                logger.warning(
                    f"The model will begin to collapse after a short period of time, if the model you are continuing from has not been tuned beyond {t5_max_length} tokens."
                )

        if self.config.aspect_bucket_alignment != 64:
            logger.warning("MM-DiT requires an alignment value of 64px. Overriding the value of --aspect_bucket_alignment.")
            self.config.aspect_bucket_alignment = 64

        self.config.vae_enable_tiling = True
        self.config.vae_enable_slicing = True

    def custom_model_card_schedule_info(self):
        output_args = []
        if self.config.flow_schedule_auto_shift:
            output_args.append("flow_schedule_auto_shift")
        if self.config.flow_schedule_shift is not None:
            output_args.append(f"shift={self.config.flow_schedule_shift}")
        if self.config.flow_use_beta_schedule:
            output_args.append(f"flow_beta_schedule_alpha={self.config.flow_beta_schedule_alpha}")
            output_args.append(f"flow_beta_schedule_beta={self.config.flow_beta_schedule_beta}")
        if self.config.flow_use_uniform_schedule:
            output_args.append(f"flow_use_uniform_schedule")
        output_str = f" (extra parameters={output_args})" if output_args else " (no special parameters set)"

        return output_str

    def auxiliary_loss(self, model_output, prepared_batch: dict, loss: torch.Tensor, **kwargs):
        loss, base_logs = super().auxiliary_loss(model_output=model_output, prepared_batch=prepared_batch, loss=loss)
        aux_losses = get_load_balancing_loss()
        aux_log_info = base_logs or {}

        if aux_losses:
            # Extract and accumulate the actual loss values (first element of each tuple)
            accumulated_aux_loss = torch.sum(torch.stack([aux_tuple[0] for aux_tuple in aux_losses]))

            # For logging purposes - gather these regardless of whether we add to main loss
            aux_log_info = {
                "total": accumulated_aux_loss.item(),
                "count": len(aux_losses),
                "mean": accumulated_aux_loss.item() / max(1, len(aux_losses)),
                # Extract statistics about expert utilization (the third element)
                "expert_usage_min": min(
                    [torch.min(aux_tuple[2]).item() for aux_tuple in aux_losses],
                    default=0,
                ),
                "expert_usage_max": max(
                    [torch.max(aux_tuple[2]).item() for aux_tuple in aux_losses],
                    default=0,
                ),
                "expert_usage_mean": sum([torch.mean(aux_tuple[2]).item() for aux_tuple in aux_losses])
                / max(1, len(aux_losses)),
            }

            # Only add to the main loss if configured to do so
            if self.config.hidream_use_load_balancing_loss:
                total_loss = loss + accumulated_aux_loss * self.config.hidream_load_balancing_loss_weight
            else:
                total_loss = loss
        else:
            total_loss = loss
            aux_log_info = (aux_log_info or {}) | {"total": 0.0, "count": 0}

        # Always clear the global list after processing to prevent memory buildup
        clear_load_balancing_loss()

        return total_loss, aux_log_info


from simpletuner.helpers.models.registry import ModelRegistry

ModelRegistry.register("hidream", HiDream)
