# DAML-RAG 框架 CHANGELOG

**版本**: v1.4.0  
**更新日期**: 2025-11-07  
**框架状态**: ✅ 生产就绪 - BUILD_BODY核心框架

---

## 📋 框架概述

**DAML-RAG Framework** = Domain-Adaptive Meta-Learning RAG
**定位**: 面向垂直领域的自适应元学习型RAG框架
**核心特性**: 推理时学习 + 双模型协同 + GraphRAG + MCP编排

---

本文档记录了 DAML-RAG 框架 的所有重要变更。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)，
并且项目遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

---

## [未发布]

### 计划中
- 更多领域适配器（金融、法律、教育等）
- 图形化配置界面和管理后台
- 高级监控仪表板和性能分析
- 多语言支持（英文、日文）

---

## [1.4.0] - 2025-11-07 ⭐

### 变更类型
📚 文档 + 🏗️ 架构

### 新增
- ✅ **CHANGELOG管理体系**: 
  - 建立框架级变更日志规范
  - 与BUILD_BODY项目CHANGELOG体系对接
  - 统一版本管理和更新记录
  
- ✅ **BUILD_BODY集成状态**:
  - 框架已在BUILD_BODY项目生产运行
  - MCO服务基于DAML-RAG框架完整实现
  - GraphRAG + 双模型 + MCP编排器全部生产验证

### 文档
- 📚 重构CHANGELOG格式，采用BUILD_BODY规范
- 📚 添加框架概述和核心特性说明
- 📚 记录与BUILD_BODY项目的集成关系

### 影响范围
- 为后续版本更新建立标准化流程
- 方便跨项目版本追踪和管理
- 提升框架可维护性

---

## [1.3.0] - 2025-11-07

### 新增
- 🔬 **Thompson Sampling学习算法**（理论组件）：
  - 从BUILD_BODY项目提取的工具选择学习算法
  - Thompson Sampling + Contextual Bandit 实现
  - 适用于多MCP服务器竞争、工具链A/B测试场景
  - 包含完整的理论文档和实践指南
  - 位置：`daml_rag/learning/tool_learner_thompson.py`
  
### 文档
- 📚 新增 Thompson Sampling 理论组件说明文档
- 📚 详细的适用场景分析和启用条件指南
- 📚 BUILD_BODY项目实践数据参考

### 说明
- ⚠️ 标记为理论组件：当前场景下为过度设计，适用于≥2个MCP服务器且样本量>1000的场景
- ✅ 保留供未来扩展和其他项目参考使用

## [1.2.0] - 2025-11-07

### 新增
- 🎯 **MCP编排器**（MCPOrchestrator）：
  - 基于Kahn拓扑排序的任务编排算法
  - DFS循环依赖检测
  - 异步并行执行（asyncio.gather）
  - TTL缓存机制（避免重复调用）
  - 支持真实MCP调用和Mock模式
  - 完整的执行统计和摘要

### 修复
- 🐛 修复模块化目录遗留问题：
  - 将 `daml-rag-orchestration/mcp_orchestrator.py` 同步到 `daml_rag/orchestration/`
  - 更新模块导出，支持容错导入

### 文档
- 📚 新增 MCPOrchestrator 使用文档和示例
- 📚 更新模块结构说明

## [1.1.0] - 2025-11-07

### 新增
- 🎯 **BGE查询复杂度分类器**：
  - 基于 BAAI/bge-base-zh-v1.5 向量模型的语义相似度分类
  - 智能区分简单查询和复杂查询
  - 支持自定义复杂查询向量库
  - 懒加载 + 向量缓存优化
  - 硬编码关键词兜底策略
  - 领域无关的通用设计

### 改进
- 📊 **模型选择优化**：
  - Teacher-Student 模型智能调度
  - 基于语义相似度的自动模型选择（相似度 > 0.7 使用教师模型）
  - 降低不必要的高成本模型调用

### 技术细节
- 新增模块：`daml_rag.learning.query_classifier`
- 核心类：`QueryComplexityClassifier`
- 数学原理：余弦相似度 + 阈值分类
- 默认模型：BAAI/bge-base-zh-v1.5 (768维中文向量)

## [1.0.0] - 2025-11-05

### 新增
- 🎯 **核心框架**：DAML-RAG 框架 v1.0.0 正式发布
- 🔍 **三层检索架构**：
  - 向量检索层：支持中文向量化模型和语义搜索
  - 知识图谱层：基于 Neo4j 的实体关系推理
  - 规则过滤层：质量评分和异常检测
- 🧠 **推理时学习**：
  - 经验存储和检索
  - 反馈学习机制
  - 自适应策略调整
- ⚡ **智能模型调度**：
  - 教师模型（DeepSeek）+ 学生模型（Ollama）
  - 85% Token 节省，93% 成本降低
  - 基于复杂度的自动模型选择
- 🔌 **领域适配器**：
  - 健身领域适配器（23个专业工具）
  - 医疗领域适配器（诊断、治疗工具）
  - 教育领域适配器（课程设计工具）
  - 自定义领域适配器模板
- 🛠️ **CLI 工具**：
  - `daml-rag init` - 项目初始化
  - `daml-rag dev` - 开发服务器
  - `daml-rag deploy` - 部署工具
  - `daml-rag health` - 健康检查
- ⚙️ **配置管理**：
  - YAML/JSON 配置文件支持
  - 环境变量配置
  - 配置验证和合并
- 📊 **监控系统**：
  - 实时性能指标
  - 查询统计和监控
  - 组件健康检查
- 🛡️ **质量保证**：
  - 知识污染防护
  - 异常检测和信誉系统
  - 自动质量评估

### 技术规格
- **框架语言**：Python 3.8+
- **协议支持**：MCP (Model Context Protocol)
- **数据库**：Neo4j, Qdrant, Redis
- **模型支持**：OpenAI, DeepSeek, Ollama
- **部署方式**：Docker, Kubernetes, 云平台

### 性能指标
- **响应时间**：< 1秒（GraphRAG检索）
- **缓存命中率**：> 60%
- **用户满意度**：4.4/5
- **质量提升**：38%

### 文档和示例
- 📖 完整的 API 文档
- 🚀 快速开始指南
- 💡 健身教练助手示例
- 🔧 自定义适配器开发指南
- 📚 最佳实践文档

### 许可证
- Apache License 2.0 - 商业友好开源协议

---

## 版本说明

### 版本号格式
使用语义化版本控制：`MAJOR.MINOR.PATCH`

- **MAJOR**：不兼容的 API 修改
- **MINOR**：向下兼容的功能性新增
- **PATCH**：向下兼容的问题修正

### 发布周期
- **主版本**：每年 1-2 次
- **次版本**：每季度 1-2 次
- **修订版本**：根据需要随时发布

### 支持政策
- **当前版本**：完全支持，包括新功能和修复
- **前一个主版本**：仅安全修复和关键 bug 修复
- **更早版本**：不再支持

### 升级指南
查看每个版本的详细升级说明：
- [v1.0.0 升级指南](./docs/upgrade/v1.0.0.md)

---

## 贡献者

感谢以下贡献者让 DAML-RAG 框架 变得更好：

- [GitHub Discussions](https://github.com/vivy1024/daml-rag-framework/discussions)
- [GitHub Issues](https://github.com/vivy1024/daml-rag-framework/issues) - 问题反馈
- [Discord 社区](https://discord.gg/KDtg69cy) - 实时讨论
- 邮件：[1765563156@qq.com](mailto:1765563156@qq.com)


完整的贡献者列表：[Contributors](https://github.com/vivy1024/daml-rag-framework/graphs/contributors)

---

## 路线图

### v1.1.0 (计划中)
- [ ] 更多领域适配器（金融、法律等）
- [ ] 图形化配置界面
- [ ] 高级监控仪表板
- [ ] 自动化测试框架

### v1.2.0 (计划中)
- [ ] 多语言支持
- [ ] 分布式部署支持
- [ ] 高级缓存策略
- [ ] 自定义插件系统

### v2.0.0 (远期规划)
- [ ] 图形化工作流编辑器
- [ ] 机器学习模型训练支持
- [ ] 企业级功能
- [ ] 云原生架构

---

## 反馈和支持

- 📧 [邮件支持](mailto:1765563156@qq.com)
- 💬 [GitHub Discussions](https://github.com/vivy1024/daml-rag-framework/discussions)
- 🐛 [问题反馈](https://github.com/vivy1024/daml-rag-framework/issues)
- 📖 [官方文档](https://github.com/vivy1024/daml-rag-framework/tree/main/docs)