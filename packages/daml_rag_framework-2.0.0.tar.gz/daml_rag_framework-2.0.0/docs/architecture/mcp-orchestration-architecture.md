# MCP编排架构

**版本**: v1.0.0  
**更新日期**: 2025-11-06  
**状态**: 🎯 通用架构规范

---

## 📋 文档目的

本文档定义了 DAML-RAG 框架中**MCP工具编排器的通用架构**。它是**领域无关的**，可以适配到任何使用MCP工具的AI应用。

---

## 🎯 核心问题

### 为什么需要编排器？

在多工具AI系统中，单个查询可能需要调用多个MCP工具：

```
用户查询："制定个性化方案"
    ↓
需要调用的工具：
  1. get_user_profile（获取用户信息）
  2. search_knowledge（搜索知识库）
  3. generate_plan（生成方案）
```

**挑战**：
- ❌ **依赖关系**：工具2依赖工具1的结果
- ❌ **执行顺序**：必须先执行工具1，再执行工具2
- ❌ **并行机会**：如果工具2和工具3无依赖，可以并行执行
- ❌ **错误处理**：某个工具失败后如何处理？

**编排器的作用**：
- ✅ 自动识别工具依赖关系
- ✅ 确定合法的执行顺序
- ✅ 最大化并行执行
- ✅ 提供容错机制

---

## 🏗️ 核心架构

### 1. 任务DAG（有向无环图）

```
┌─────────────────────────────────────────────────────┐
│           任务依赖关系（DAG）                          │
├─────────────────────────────────────────────────────┤
│                                                     │
│       Task1: get_context                            │
│         ↓                                           │
│    ┌────┴────┐                                      │
│    ↓         ↓                                      │
│  Task2     Task3                                    │
│  search    analyze                                  │
│    ↓         ↓                                      │
│    └────┬────┘                                      │
│         ↓                                           │
│      Task4: generate                                │
│                                                     │
│  执行顺序：                                           │
│  1. Task1 先执行（无依赖）                            │
│  2. Task2 和 Task3 并行执行（都依赖Task1）             │
│  3. Task4 最后执行（依赖Task2和Task3）                │
└─────────────────────────────────────────────────────┘
```

**数据结构**：
```python
@dataclass
class Task:
    task_id: str           # 任务唯一标识
    tool_name: str         # MCP工具名称
    params: Dict[str, Any] # 工具参数
    depends_on: List[str]  # 依赖的任务ID列表
```

---

### 2. Kahn拓扑排序算法

**理论基础**：
- 论文：Kahn's Algorithm (1962)
- 时间复杂度：O(V + E)，V=节点数，E=边数

**算法步骤**：

```python
def topological_sort(tasks):
    """
    Kahn拓扑排序
    
    输入：任务列表（带依赖关系）
    输出：合法的执行顺序
    """
    # 1. 计算入度（每个任务被多少个任务依赖）
    in_degree = {}
    for task in tasks:
        in_degree[task.task_id] = len(task.depends_on)
    
    # 2. 找到所有入度为0的任务（可以立即执行）
    queue = [task for task in tasks if in_degree[task.task_id] == 0]
    execution_order = []
    
    # 3. 拓扑排序
    while queue:
        # 取出一个入度为0的任务
        current = queue.pop(0)
        execution_order.append(current)
        
        # 减少其后继任务的入度
        for task in tasks:
            if current.task_id in task.depends_on:
                in_degree[task.task_id] -= 1
                # 如果入度变为0，加入队列
                if in_degree[task.task_id] == 0:
                    queue.append(task)
    
    # 4. 检测循环依赖
    if len(execution_order) != len(tasks):
        raise CyclicDependencyError("检测到循环依赖")
    
    return execution_order
```

**示例**：
```python
tasks = [
    Task("task1", "tool1", {}, depends_on=[]),
    Task("task2", "tool2", {}, depends_on=["task1"]),
    Task("task3", "tool3", {}, depends_on=["task1"]),
    Task("task4", "tool4", {}, depends_on=["task2", "task3"])
]

# 拓扑排序结果：
# [task1, task2, task3, task4] 或 [task1, task3, task2, task4]
# （task2和task3顺序可以交换，因为它们无依赖）
```

---

### 3. 异步并行执行

**理论基础**：
- Python asyncio：异步I/O框架
- asyncio.gather：并行执行多个协程

**并行策略**：
```python
async def execute_parallel(tasks):
    """
    并行执行无依赖的任务
    """
    # 1. 按执行层级分组
    levels = group_by_level(tasks)
    
    # levels = {
    #   0: [task1],           # 第0层：无依赖
    #   1: [task2, task3],    # 第1层：依赖第0层
    #   2: [task4]            # 第2层：依赖第1层
    # }
    
    results = {}
    
    # 2. 逐层执行
    for level in sorted(levels.keys()):
        level_tasks = levels[level]
        
        # 3. 同层任务并行执行
        level_results = await asyncio.gather(
            *[execute_task(task, results) for task in level_tasks],
            return_exceptions=True  # 容错：单个任务失败不影响其他任务
        )
        
        # 4. 收集结果
        for task, result in zip(level_tasks, level_results):
            if isinstance(result, Exception):
                results[task.task_id] = {"error": str(result)}
            else:
                results[task.task_id] = result
    
    return results
```

**并行效果示例**：
```
串行执行：task1(1s) → task2(2s) → task3(2s) → task4(1s) = 6秒
并行执行：task1(1s) → [task2(2s) || task3(2s)] → task4(1s) = 4秒
             ↑             ↑ 并行执行 ↑
         节省2秒
```

---

### 4. 依赖图定义

**领域适配器需要定义**：

```python
# 示例：健身领域的工具依赖图
DEPENDENCY_GRAPH = {
    # 基础工具（无依赖）
    "get_user_profile": [],
    "search_knowledge": [],
    
    # 高级工具（依赖基础工具）
    "generate_plan": ["get_user_profile", "search_knowledge"],
    "evaluate_progress": ["get_user_profile"],
    
    # 综合工具（依赖多个工具）
    "create_personalized_program": [
        "get_user_profile",
        "search_knowledge",
        "generate_plan"
    ]
}
```

**依赖图规则**：
1. **禁止循环依赖**：A依赖B，B不能依赖A
2. **传递性自动处理**：A依赖B，B依赖C，编排器自动推导A→C
3. **可选依赖**：某些依赖可以标记为可选（失败不影响执行）

---

## 🔧 高级特性

### 5.1 TTL缓存机制

**问题**：短时间内重复调用同一工具浪费资源

**解决方案**：
```python
class TaskCache:
    """
    TTL（Time-To-Live）缓存
    """
    def __init__(self, ttl_seconds=300):
        self.cache = {}
        self.ttl = ttl_seconds
    
    def get(self, task_id, params):
        """获取缓存结果"""
        cache_key = self._make_key(task_id, params)
        
        if cache_key in self.cache:
            result, timestamp = self.cache[cache_key]
            
            # 检查是否过期
            if time.time() - timestamp < self.ttl:
                return result
            else:
                # 过期，删除缓存
                del self.cache[cache_key]
        
        return None
    
    def set(self, task_id, params, result):
        """设置缓存"""
        cache_key = self._make_key(task_id, params)
        self.cache[cache_key] = (result, time.time())
```

**缓存策略**：
- 默认TTL：300秒（5分钟）
- 缓存键：`task_id + hash(params)`
- 自动过期清理

---

### 5.2 错误处理与容错

**失败隔离**：
```python
async def execute_with_error_handling(task):
    """
    单个任务失败不影响其他任务
    """
    try:
        result = await mcp_client.call_tool(task.tool_name, task.params)
        return {"status": "success", "data": result}
    
    except Exception as e:
        logger.error(f"Task {task.task_id} failed: {e}")
        return {"status": "failed", "error": str(e)}
```

**降级策略**：
```python
# 标记某些任务为"可选"
Task("optional_task", "tool", {}, 
     depends_on=["required_task"],
     optional=True)  # 失败不影响后续任务

# 执行时检查
if task.optional and task.status == "failed":
    logger.warning(f"Optional task {task.task_id} failed, continuing...")
    continue
```

---

### 5.3 循环依赖检测

**算法**：深度优先搜索（DFS）

```python
def detect_cycle(tasks):
    """
    检测循环依赖
    
    算法：DFS + 三色标记
    - 白色（0）：未访问
    - 灰色（1）：正在访问
    - 黑色（2）：已完成访问
    """
    colors = {task.task_id: 0 for task in tasks}
    
    def dfs(task_id):
        if colors[task_id] == 1:
            # 正在访问，发现环
            return True
        
        if colors[task_id] == 2:
            # 已访问
            return False
        
        # 标记为正在访问
        colors[task_id] = 1
        
        # 递归访问依赖
        task = next(t for t in tasks if t.task_id == task_id)
        for dep in task.depends_on:
            if dfs(dep):
                return True
        
        # 标记为已完成
        colors[task_id] = 2
        return False
    
    # 检查所有任务
    for task in tasks:
        if colors[task.task_id] == 0:
            if dfs(task.task_id):
                raise CyclicDependencyError(
                    f"检测到循环依赖，涉及任务: {task.task_id}"
                )
```

---

## 📊 完整执行流程

```
┌─────────────────────────────────────────────────────┐
│           MCP编排器执行流程                           │
├─────────────────────────────────────────────────────┤
│                                                     │
│  Step 1: 意图识别（Intent Recognition）              │
│  ┌──────────────────────────────────────────────┐ │
│  │ 用户查询 → 识别需要的工具列表                    │ │
│  │ "制定增肌计划" → [get_profile, search, plan]  │ │
│  └──────────────────────────────────────────────┘ │
│         ↓                                           │
│  Step 2: DAG构建（Task Decomposition）              │
│  ┌──────────────────────────────────────────────┐ │
│  │ 根据依赖图生成任务DAG                           │ │
│  │ Task1(get_profile) → Task2(search) → Task3   │ │
│  └──────────────────────────────────────────────┘ │
│         ↓                                           │
│  Step 3: 循环检测（Cycle Detection）                │
│  ┌──────────────────────────────────────────────┐ │
│  │ DFS检测循环依赖                                │ │
│  │ 如果存在循环 → 抛出异常                         │ │
│  └──────────────────────────────────────────────┘ │
│         ↓                                           │
│  Step 4: 拓扑排序（Topological Sort）               │
│  ┌──────────────────────────────────────────────┐ │
│  │ Kahn算法确定执行顺序                            │ │
│  │ [Task1] → [Task2, Task3] → [Task4]           │ │
│  └──────────────────────────────────────────────┘ │
│         ↓                                           │
│  Step 5: 并行执行（Parallel Execution）             │
│  ┌──────────────────────────────────────────────┐ │
│  │ 逐层执行，同层并行                              │ │
│  │ asyncio.gather([Task2, Task3])                │ │
│  └──────────────────────────────────────────────┘ │
│         ↓                                           │
│  Step 6: 结果聚合（Result Aggregation）             │
│  ┌──────────────────────────────────────────────┐ │
│  │ 收集所有工具结果                                │ │
│  │ {task1: {...}, task2: {...}, task3: {...}}   │ │
│  └──────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────┘
```

---

## 🎯 可选特性

以下特性可根据领域需求选择性实施：

### 可选1: 智能预加载（适用于用户档案场景）

**适用场景**：
- 需要频繁访问用户档案的领域（如个性化推荐、定制化服务）
- 多个工具都需要相同的用户信息

**实现思路**：
```python
# 在编排开始前预加载用户数据
preloaded_data = None
if context and 'user_id' in context:
    preloaded_data = await get_user_profile(context['user_id'])

# 编排器检测到需要user_profile的任务时，直接使用预加载数据
if preloaded_data:
    # 移除重复的get_user_profile任务
    tasks = [t for t in tasks if t.tool_name != 'get_user_profile']
    # 将预加载数据注入到依赖它的任务中
    for task in tasks:
        if 'get_user_profile' in task.depends_on:
            task.params['preloaded_profile'] = preloaded_data
```

**设计目标**：
- 减少重复MCP调用
- 降低响应延迟
- 保持健壮性（预加载失败时降级到标准流程）

**注意**：此特性不是所有领域都需要，仅在用户档案访问频繁时考虑。

---

### 可选2: 动态任务调整

**适用场景**：
- 运行时根据中间结果动态添加/删除任务
- 需要条件分支的复杂工作流

**实现思路**：
```python
# 根据中间结果动态调整任务
async def execute_with_dynamic_adjustment(tasks):
    results = {}
    
    for task in tasks:
        result = await execute_task(task)
        results[task.task_id] = result
        
        # 根据结果动态调整后续任务
        if task.task_id == "check_condition":
            if result["condition"] == "A":
                # 添加分支A的任务
                tasks.extend(get_branch_a_tasks())
            else:
                # 添加分支B的任务
                tasks.extend(get_branch_b_tasks())
    
    return results
```

**注意**：增加实现复杂度，需权衡收益。

---

## 🔗 相关文档

- **框架总览**: [../theory/框架总览.md](../theory/框架总览.md)
- **English Version**: [mcp-orchestration-architecture-en.md](./mcp-orchestration-architecture-en.md)（待创建）

---

## 📖 参考文献

1. **Kahn's Algorithm**: Kahn, A. B. (1962). "Topological sorting of large networks"
2. **Apache Airflow**: Airbnb Engineering (2014). "Airflow: a workflow management platform"
3. **asyncio**: Python Software Foundation. "asyncio — Asynchronous I/O"

---

**维护者**: DAML-RAG Framework Team  
**最后审查**: 2025-11-06

<div align="center">
<strong>🎯 通用架构 · 🚀 领域无关 · 📊 性能优化</strong>
</div>

