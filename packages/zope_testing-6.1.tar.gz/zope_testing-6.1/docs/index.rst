.. include:: ../README.rst

..
  Yes, we want just an underline for the sections here,
  the include above establishes the title and these need to be
  subordinate to it.


Contents
========

.. toctree::
   :maxdepth: 1

   cleanup
   doctestcase
   formparser
   loggingsupport
   module
   renormalizing
   setupstack
   wait
   api/index
   changes




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
