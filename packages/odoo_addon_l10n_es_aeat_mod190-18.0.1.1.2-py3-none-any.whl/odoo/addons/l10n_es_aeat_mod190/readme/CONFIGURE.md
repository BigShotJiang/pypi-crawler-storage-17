Para poder acceder a los campos sensibles que aparecerán en la declaración 190, necesita unos permisos especiales:

1. Inicie sesión como administrador con privilegios.
1. Vaya a **Configuración** > **Usuarios y Compañías** > **Usuarios**.
1. Seleccione el usuario que necesita acceso.
1. Haga clic en **Editar** y busque la sección **Grupos**.
1. Añada el grupo **Datos Sensibles del Modelo 190 de la AEAT**.
1. Guarde los cambios.
1. Asegúrese de que el usuario cierre sesión y vuelva a iniciarla.
