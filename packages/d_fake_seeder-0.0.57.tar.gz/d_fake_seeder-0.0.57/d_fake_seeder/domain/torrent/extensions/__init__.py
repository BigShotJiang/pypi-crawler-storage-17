"""
BitTorrent Protocol Extensions

This package contains handlers for various BitTorrent protocol extensions (BEPs).
"""
