"""
Core application services for the DFakeSeeder application.

This package contains:
- Logging system (logger.py)
- Translation and internationalization support (translation_manager.py)
"""
