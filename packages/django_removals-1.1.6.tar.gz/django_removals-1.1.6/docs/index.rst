.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   features/changelog.md
