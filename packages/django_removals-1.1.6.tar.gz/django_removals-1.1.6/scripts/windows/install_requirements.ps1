pip install -U uv
uv sync --frozen --extra dev
