Base schema: None

This is a proposed new schema for electrophoresis devices.
