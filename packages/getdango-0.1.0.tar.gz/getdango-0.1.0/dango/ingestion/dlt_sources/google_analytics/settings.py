"""Google analytics source settings and constants"""

START_DATE = "2015-08-14"
