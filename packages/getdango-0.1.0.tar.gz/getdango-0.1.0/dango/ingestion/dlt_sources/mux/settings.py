"""Mux source settings and constants"""

API_BASE_URL = "https://api.mux.com"
DEFAULT_LIMIT = 100
