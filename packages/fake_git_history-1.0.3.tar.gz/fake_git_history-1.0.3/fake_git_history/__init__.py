"""
Fake git history - A python script to create fake git history.
Created by: Md. Almas Ali (https://github.com/Almas-Ali/)
"""

from .cli import __version__

__all__ = ["__version__"]
