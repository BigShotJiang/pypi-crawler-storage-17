This module adds packaging to the product.pricelist.item and allows you
to sell the same product with different packaging and at different
prices.
