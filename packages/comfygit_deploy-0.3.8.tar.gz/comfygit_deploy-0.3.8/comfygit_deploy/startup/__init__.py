"""Startup script generation for deployments."""
