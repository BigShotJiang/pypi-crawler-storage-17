"""AI integration modules."""
