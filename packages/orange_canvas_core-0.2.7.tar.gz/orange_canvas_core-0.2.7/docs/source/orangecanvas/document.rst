=======================
Document (``document``)
=======================

.. automodule:: orangecanvas.document


.. toctree::

   document.schemeedit
   document.quickmenu
   document.interactions
