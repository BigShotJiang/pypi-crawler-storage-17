.. gui:

######################
GUI elements (``gui``)
######################

.. automodule:: orangecanvas.gui

.. toctree::
   :maxdepth: 1

   gui.dock
   gui.dropshadow
   gui.framelesswindow
   gui.lineedit
   gui.quickhelp
   gui.splashscreen
   gui.toolbar
   gui.toolbox
   gui.toolgrid
   gui.tooltree
