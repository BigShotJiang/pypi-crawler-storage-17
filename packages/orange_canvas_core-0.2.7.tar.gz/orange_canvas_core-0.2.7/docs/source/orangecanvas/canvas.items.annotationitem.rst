.. canvas-annotation-item:

=====================================
Annotation Items (``annotationitem``)
=====================================

.. automodule:: orangecanvas.canvas.items.annotationitem

.. autoclass:: Annotation
   :members:
   :member-order: bysource
   :show-inheritance:


.. autoclass:: TextAnnotation
   :members:
   :member-order: bysource
   :show-inheritance:


.. autoclass:: ArrowAnnotation
   :members:
   :member-order: bysource
   :show-inheritance:
