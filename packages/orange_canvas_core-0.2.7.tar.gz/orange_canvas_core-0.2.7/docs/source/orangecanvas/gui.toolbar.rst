======================
Tool Bar (``toolbar``)
======================

.. automodule:: orangecanvas.gui.toolbar

.. autoclass:: orangecanvas.gui.toolbar.DynamicResizeToolBar
   :members:
   :member-order: bysource
   :show-inheritance:
