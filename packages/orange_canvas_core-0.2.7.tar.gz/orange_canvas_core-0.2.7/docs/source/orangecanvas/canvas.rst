===================
Canvas (``canvas``)
===================


.. automodule:: orangecanvas.canvas


.. toctree::

   canvas.scene
   canvas.items.nodeitem
   canvas.items.linkitem
   canvas.items.annotationitem
