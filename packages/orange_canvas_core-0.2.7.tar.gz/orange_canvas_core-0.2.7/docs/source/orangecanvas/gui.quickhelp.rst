==========================
Quick Help (``quickhelp``)
==========================

.. automodule:: orangecanvas.gui.quickhelp

.. autoclass:: orangecanvas.gui.quickhelp.QuickHelp
   :members:
   :member-order: bysource
   :show-inheritance:
