.. Orange Canvas Core documentation master file, created by
   sphinx-quickstart on Thu Jun  4 12:15:21 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Orange Canvas Core's documentation!
==============================================

Contents:

.. toctree::
   :maxdepth: 2

   orangecanvas/overview
   orangecanvas/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

