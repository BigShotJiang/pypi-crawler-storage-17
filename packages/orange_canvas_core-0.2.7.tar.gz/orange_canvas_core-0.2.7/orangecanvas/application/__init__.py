"""
Main Orange Canvas Application and supporting classes.

"""
