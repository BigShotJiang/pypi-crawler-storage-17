import warnings

from orangecanvas.localization import *  # pylint: disable=unused-import

warnings.warn(
    "import 'orangecanvas.localization', not 'orangecanvas.utils.localization'",
    DeprecationWarning)
