import warnings

from orangecanvas.localization.si import *  # pylint: disable=unused-import

warnings.warn(
    "import 'orangecanvas.localization.si', not 'orangecanvas.utils.localization.si'",
    DeprecationWarning)

