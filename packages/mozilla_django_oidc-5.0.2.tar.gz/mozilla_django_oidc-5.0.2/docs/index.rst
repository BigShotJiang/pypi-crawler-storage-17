Welcome to mozilla-django-oidc's documentation!
===============================================

Contents:

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   settings
   xhr
   drf
   contributing
   authors
   history
   source/modules


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
