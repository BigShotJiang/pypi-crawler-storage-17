"""
Agent Kernel Integrations with Facebook Messenger

This package contains the Agent Kernel integration implementations for Facebook Messenger chats.
"""

import importlib.metadata

try:
    __version__ = importlib.metadata.version("agentkernel")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.1.0"

from .messenger_chat import AgentMessengerRequestHandler
