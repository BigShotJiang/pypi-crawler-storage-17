from .printer import enable
enable()