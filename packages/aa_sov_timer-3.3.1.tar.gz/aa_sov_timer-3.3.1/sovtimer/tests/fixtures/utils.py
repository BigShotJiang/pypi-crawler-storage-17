class RequestStub:
    """
    RequestStub
    """

    def __init__(self, user) -> None:
        """
        Init

        :param user:
        :type user:
        """

        self.user = user
