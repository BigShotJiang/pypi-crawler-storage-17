<script setup lang="ts">
import { VPBadge } from 'vitepress/theme';
</script>

<template>
  <VPBadge type="info"> <slot />+ </VPBadge>
</template>
