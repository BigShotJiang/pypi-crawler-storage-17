"""Stub."""

from curioso.app import ReportInfo

__all__ = ["ReportInfo"]
