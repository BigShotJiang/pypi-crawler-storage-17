Stock Lot Module
################

The *Stock Lot Module* allows specific quantities of products to be managed
separately.
This includes providing traceability for these batches of stock and keeping track
of where the stock is and how much is available.


.. toctree::
   :maxdepth: 2

   usage
   design
   releases
