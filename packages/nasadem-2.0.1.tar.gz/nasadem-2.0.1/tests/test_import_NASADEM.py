def test_import_NASADEM():
    import NASADEM
