====================
Changelog (QuarchpyQCS)
====================
QuarchpyQCS
--------
*QuarchpyQCS is the quarch compliance suite server required for QCS.*


Change Log
----------

1.0.0
------
- Initial seperation of Quarch compliance suite from quarchpy