import sys
from .driveTestCode import main
main(sys.argv[1:])