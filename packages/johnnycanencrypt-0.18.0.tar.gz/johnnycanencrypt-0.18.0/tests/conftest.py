from pathlib import Path

BASE_TESTSDIR = Path(__file__).parent
