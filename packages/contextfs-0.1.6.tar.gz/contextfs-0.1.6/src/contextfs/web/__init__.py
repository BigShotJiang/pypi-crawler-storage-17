"""
ContextFS Web UI - Async web server with MCP support.
"""

from contextfs.web.server import create_app

__all__ = ["create_app"]
