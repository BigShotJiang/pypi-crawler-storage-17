from .simple import SimpleTiledServer

__all__ = ["SimpleTiledServer"]
