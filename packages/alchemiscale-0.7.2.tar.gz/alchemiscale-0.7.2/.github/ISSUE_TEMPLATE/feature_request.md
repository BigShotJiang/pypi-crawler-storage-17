---
name: Feature request
about: Tell us about a feature you would like to use that doesn't appear to exist
title: ''
labels: ''
assignees: ''

---

<!-- Tell us about a feature you would like to use that doesn't appear to exist -->

**In broad terms, what are you trying to do?**


**Briefly detail what you have already tried**


**Describe the new feature(s) that would help you to achieve this**
