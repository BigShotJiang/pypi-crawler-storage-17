########
settings
########

.. automodule:: alchemiscale.settings
    :members:
    :show-inheritance:
