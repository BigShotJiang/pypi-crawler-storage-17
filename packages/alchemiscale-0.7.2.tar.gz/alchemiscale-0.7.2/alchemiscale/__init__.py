from .interface import AlchemiscaleClient
from .models import Scope, ScopedKey

from importlib.metadata import version

__version__ = version("alchemiscale")
