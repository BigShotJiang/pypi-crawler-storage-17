import pytest
from copy import copy

import uvicorn

from alchemiscale.settings import get_base_api_settings
from alchemiscale.base.api import get_s3os_depends
from alchemiscale.compute import api, client

from alchemiscale.tests.integration.compute.utils import get_compute_settings_override
from alchemiscale.tests.integration.utils import running_service
from alchemiscale.tests.integration.conftest import get_worker_port_offset


## compute client


@pytest.fixture(scope="module")
def compute_api(n4jstore_settings, s3os_server, compute_api_port):
    def get_s3os_override():
        return s3os_server

    def get_settings_override():
        return get_compute_settings_override(port=compute_api_port)

    overrides = copy(api.app.dependency_overrides)

    api.app.dependency_overrides[get_base_api_settings] = get_settings_override
    api.app.dependency_overrides[get_s3os_depends] = get_s3os_override
    yield api.app
    api.app.dependency_overrides = overrides


def run_server(fastapi_app, settings):
    uvicorn.run(
        fastapi_app,
        host=settings.ALCHEMISCALE_COMPUTE_API_HOST,
        port=settings.ALCHEMISCALE_COMPUTE_API_PORT,
        log_level=settings.ALCHEMISCALE_COMPUTE_API_LOGLEVEL,
    )


@pytest.fixture(scope="module")
def uvicorn_server(compute_api, compute_api_port):
    settings = get_compute_settings_override(port=compute_api_port)
    with running_service(
        run_server,
        port=settings.ALCHEMISCALE_COMPUTE_API_PORT,
        args=(compute_api, settings),
    ):
        yield


@pytest.fixture(scope="module")
def compute_client(
    uvicorn_server,
    compute_api_port,
    compute_identity,
    single_scoped_credentialed_compute,
    compute_service_id,
):
    return client.AlchemiscaleComputeClient(
        api_url=f"http://127.0.0.1:{compute_api_port}/",
        # use the identifier for the single-scoped user who should have access to some things
        identifier=single_scoped_credentialed_compute.identifier,
        # all the test users are based on compute_identity who use the same password
        key=compute_identity["key"],
    )


@pytest.fixture(scope="module")
def compute_client_wrong_credential(uvicorn_server, compute_api_port, compute_identity):
    return client.AlchemiscaleComputeClient(
        api_url=f"http://127.0.0.1:{compute_api_port}/",
        identifier=compute_identity["identifier"],
        key="wrong credential",
    )


@pytest.fixture(scope="module")
def compute_manager_client(
    uvicorn_server,
    compute_api_port,
    compute_identity,
    single_scoped_credentialed_compute,
):
    return client.AlchemiscaleComputeManagerClient(
        api_url=f"http://127.0.0.1:{compute_api_port}/",
        # use the identifier for the single-scoped user who should have access to some things
        identifier=single_scoped_credentialed_compute.identifier,
        # all the test users are based on compute_identity who use the same password
        key=compute_identity["key"],
    )


@pytest.fixture(scope="module")
def manager_client_wrong_credential(uvicorn_server, compute_api_port, compute_identity):
    return client.AlchemiscaleComputeManagerClient(
        api_url=f"http://127.0.0.1:{compute_api_port}/",
        identifier=compute_identity["identifier"],
        key="wrong credential",
    )
