<div class="alert alert-warning p-2 m-2 text-center">
    This widget is not supported by this version of argus.
</div>
