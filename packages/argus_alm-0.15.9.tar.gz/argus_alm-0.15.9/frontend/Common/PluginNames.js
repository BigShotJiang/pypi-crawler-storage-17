export const PLUGIN_NAMES = {
    SCT: "scylla-cluster-tests",
    DRIVER_MATRIX:"driver-matrix-tests",
    SIRENADA:"sirenada",
};
