Django app for semantic search for torque
