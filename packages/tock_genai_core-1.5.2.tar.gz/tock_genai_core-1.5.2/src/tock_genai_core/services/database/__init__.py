# -*- coding: utf-8 -*-
"""Initialisation de module(s)."""

from .opensearch import get_db_client
