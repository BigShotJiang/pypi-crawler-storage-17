###################################
Stock Package Shipping MyGLS Module
###################################

The *Stock Package Shipping MyGLS Module* allows package labels to be generated
for shipments using `MyGLS <https://api.mygls.hu/>`_ webservices.

.. toctree::
   :maxdepth: 2

   design
   releases
