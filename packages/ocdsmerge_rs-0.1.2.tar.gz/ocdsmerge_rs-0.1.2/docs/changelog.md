# Changelog

## 0.1.2 (2025-12-19)

- feat: Add attributes to errors and warnings in Python.

## 0.1.1 (2025-12-19)

- feat: Enable the `arbitrary_precision` feature on the `serde_json` crate.

## 0.1.0 (2025-08-31)

First release.
