# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Extractors.Odnoklassniki import Odnoklassniki

class OkRuHTTP(Odnoklassniki):
    name     = "OkRuHTTP"
    main_url = "http://ok.ru"

class OkRuSSL(Odnoklassniki):
    name     = "OkRuSSL"
    main_url = "https://ok.ru"
