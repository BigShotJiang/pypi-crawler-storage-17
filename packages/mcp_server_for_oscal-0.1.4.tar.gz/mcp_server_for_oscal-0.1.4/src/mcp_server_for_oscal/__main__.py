#!/usr/bin/env python3
"""Entry point for running the OSCAL MCP server as a module."""

from mcp_server_for_oscal.main import main

if __name__ == "__main__":
    main()
