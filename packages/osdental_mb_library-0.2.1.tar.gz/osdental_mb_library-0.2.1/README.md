# osdental-mobile-library

Librería interna para los proyectos móviles de OSDental.
Incluye decoradores y herramientas compartidas.

## Instalación

```bash
pip install osdental-mobile-library
```
