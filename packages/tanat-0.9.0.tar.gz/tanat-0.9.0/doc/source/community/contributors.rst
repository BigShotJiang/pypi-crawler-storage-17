Contributors
==============

Core development team
-------------------------
* Arnaud Duvermy, Inria, AIstroSight
* Thomas Guyet, Inria, AIstroSight


Contributors
-------------
* Mike Rye, Inria, AIstroSight