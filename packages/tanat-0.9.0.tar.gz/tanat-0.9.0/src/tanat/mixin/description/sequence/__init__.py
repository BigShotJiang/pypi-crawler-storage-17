#!/usr/bin/env python3
"""Sequence descriptors."""

from .base import SequenceDescriptor

__all__ = ["SequenceDescriptor"]
