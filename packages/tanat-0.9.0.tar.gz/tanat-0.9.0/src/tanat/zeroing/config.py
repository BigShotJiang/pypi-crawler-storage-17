#!/usr/bin/env python3
"""
Zeroing configuration
"""

# TODO: To be implemented
