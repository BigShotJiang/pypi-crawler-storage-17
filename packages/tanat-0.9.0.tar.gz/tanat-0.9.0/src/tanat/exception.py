#!/usr/bin/env python3
"""
Generic TanaT exceptions.
"""


class TanatException(Exception):
    """
    TanaT base exception class.
    """
