#!/usr/bin/env python3
"""package stub."""
