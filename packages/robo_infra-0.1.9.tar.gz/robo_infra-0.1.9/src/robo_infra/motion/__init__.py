"""Motion planning and kinematics."""
