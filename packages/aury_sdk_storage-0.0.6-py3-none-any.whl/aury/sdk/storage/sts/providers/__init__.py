"""STS Providers."""

from .tencent import TencentSTSProvider

__all__ = [
    "TencentSTSProvider",
]
