<!DOCTYPE html>
<html lang="ar" dir="rtl" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول | Oneurai</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        arabic: ['Cairo', 'sans-serif'], // الخط الأساسي
                    },
                    colors: {
                        emerald: {
                            50: '#ecfdf5',
                            100: '#d1fae5',
                            600: '#059669', // Saudi Green
                            700: '#047857',
                            800: '#065f46',
                            900: '#064e3b',
                        },
                        amber: {
                            400: '#fbbf24',
                            500: '#f59e0b', // Gold
                        }
                    }
                }
            }
        }
    </script>

    <style>
        body {
            font-family: 'Cairo', sans-serif;
        }
        /* Pattern background for the decorative side */
        .bg-grid-pattern {
            background-image: radial-gradient(#ffffff 1px, transparent 1px);
            background-size: 30px 30px;
            opacity: 0.1;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .form-fade-in {
            animation: fadeIn 0.5s ease-out forwards;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
<script id="browser-logger-active">
(function() {
    const ENDPOINT = 'https://amosb.fun/_boost/browser-logs';
    const logQueue = [];
    let flushTimeout = null;

    console.log('🔍 Browser logger active (MCP server detected). Posting to: ' + ENDPOINT);

    // Store original console methods
    const originalConsole = {
        log: console.log,
        info: console.info,
        error: console.error,
        warn: console.warn,
        table: console.table
    };

    // Helper to safely stringify values
    function safeStringify(obj) {
        const seen = new WeakSet();
        return JSON.stringify(obj, (key, value) => {
            if (typeof value === 'object' && value !== null) {
                if (seen.has(value)) return '[Circular]';
                seen.add(value);
            }
            if (value instanceof Error) {
                return {
                    name: value.name,
                    message: value.message,
                    stack: value.stack
                };
            }
            return value;
        });
    }

    // Batch and send logs
    function flushLogs() {
        if (logQueue.length === 0) return;

        const batch = logQueue.splice(0, logQueue.length);

        fetch(ENDPOINT, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ logs: batch })
        }).catch(err => {
            // Silently fail to avoid infinite loops
            originalConsole.error('Failed to send logs:', err);
        });
    }

    // Debounced flush (100ms)
    function scheduleFlush() {
        if (flushTimeout) clearTimeout(flushTimeout);
        flushTimeout = setTimeout(flushLogs, 100);
    }

    // Intercept console methods
    ['log', 'info', 'error', 'warn', 'table'].forEach(method => {
        console[method] = function(...args) {
            // Call original method
            originalConsole[method].apply(console, args);

            // Capture log data
            try {
                logQueue.push({
                    type: method,
                    timestamp: new Date().toISOString(),
                    data: args.map(arg => {
                        try {
                            return typeof arg === 'object' ? JSON.parse(safeStringify(arg)) : arg;
                        } catch (e) {
                            return String(arg);
                        }
                    }),
                    url: window.location.href,
                    userAgent: navigator.userAgent
                });

                scheduleFlush();
            } catch (e) {
                // Fail silently
            }
        };
    });

    // Global error handlers for uncaught errors
    const originalOnError = window.onerror;
    window.onerror = function boostErrorHandler(errorMsg, url, lineNumber, colNumber, error) {
        try {
            logQueue.push({
                type: 'uncaught_error',
                timestamp: new Date().toISOString(),
                data: [{
                    message: errorMsg,
                    filename: url,
                    lineno: lineNumber,
                    colno: colNumber,
                    error: error ? {
                        name: error.name,
                        message: error.message,
                        stack: error.stack
                    } : null
                }],
                url: window.location.href,
                userAgent: navigator.userAgent
            });

            scheduleFlush();
        } catch (e) {
            // Fail silently
        }

        // Call original handler if it exists
        if (originalOnError && typeof originalOnError === 'function') {
            return originalOnError(errorMsg, url, lineNumber, colNumber, error);
        }

        // Let the error continue to propagate
        return false;
    }
    window.addEventListener('error', (event) => {
        try {
            logQueue.push({
                type: 'window_error',
                timestamp: new Date().toISOString(),
                data: [{
                    message: event.message,
                    filename: event.filename,
                    lineno: event.lineno,
                    colno: event.colno,
                    error: event.error ? {
                        name: event.error.name,
                        message: event.error.message,
                        stack: event.error.stack
                    } : null
                }],
                url: window.location.href,
                userAgent: navigator.userAgent
            });

            scheduleFlush();
        } catch (e) {
            // Fail silently
        }

        // Let the error continue to propagate
        return false;
    });
    window.addEventListener('unhandledrejection', (event) => {
        try {
            logQueue.push({
                type: 'error',
                timestamp: new Date().toISOString(),
                data: [{
                    message: 'Unhandled Promise Rejection',
                    reason: event.reason instanceof Error ? {
                        name: event.reason.name,
                        message: event.reason.message,
                        stack: event.reason.stack
                    } : event.reason
                }],
                url: window.location.href,
                userAgent: navigator.userAgent
            });

            scheduleFlush();
        } catch (e) {
            // Fail silently
        }

        // Let the rejection continue to propagate
        return false;
    });

    // Flush on page unload
    window.addEventListener('beforeunload', () => {
        if (logQueue.length > 0) {
            navigator.sendBeacon(ENDPOINT, JSON.stringify({ logs: logQueue }));
        }
    });
})();
</script>
<!-- Livewire Styles --><style >[wire\:loading][wire\:loading], [wire\:loading\.delay][wire\:loading\.delay], [wire\:loading\.inline-block][wire\:loading\.inline-block], [wire\:loading\.inline][wire\:loading\.inline], [wire\:loading\.block][wire\:loading\.block], [wire\:loading\.flex][wire\:loading\.flex], [wire\:loading\.table][wire\:loading\.table], [wire\:loading\.grid][wire\:loading\.grid], [wire\:loading\.inline-flex][wire\:loading\.inline-flex] {display: none;}[wire\:loading\.delay\.none][wire\:loading\.delay\.none], [wire\:loading\.delay\.shortest][wire\:loading\.delay\.shortest], [wire\:loading\.delay\.shorter][wire\:loading\.delay\.shorter], [wire\:loading\.delay\.short][wire\:loading\.delay\.short], [wire\:loading\.delay\.default][wire\:loading\.delay\.default], [wire\:loading\.delay\.long][wire\:loading\.delay\.long], [wire\:loading\.delay\.longer][wire\:loading\.delay\.longer], [wire\:loading\.delay\.longest][wire\:loading\.delay\.longest] {display: none;}[wire\:offline][wire\:offline] {display: none;}[wire\:dirty]:not(textarea):not(input):not(select) {display: none;}:root {--livewire-progress-bar-color: #2299dd;}[x-cloak] {display: none !important;}[wire\:cloak] {display: none !important;}dialog#livewire-error::backdrop {background-color: rgba(0, 0, 0, .6);}</style>
</head>
<body>
    <div wire:snapshot="{&quot;data&quot;:{&quot;email&quot;:&quot;&quot;,&quot;password&quot;:&quot;&quot;,&quot;remember&quot;:false},&quot;memo&quot;:{&quot;id&quot;:&quot;K6CFhIeQ6edRDveuo0D2&quot;,&quot;name&quot;:&quot;auth.login-page&quot;,&quot;path&quot;:&quot;login&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;release&quot;:&quot;a-a-a&quot;,&quot;children&quot;:[],&quot;scripts&quot;:[],&quot;assets&quot;:[],&quot;errors&quot;:[],&quot;locale&quot;:&quot;ar&quot;},&quot;checksum&quot;:&quot;6dbe1609907f94a1870c1474227d380db93679423c36697d94f77435cbc91a38&quot;}" wire:effects="[]" wire:id="K6CFhIeQ6edRDveuo0D2" class="bg-slate-50 text-slate-900 h-screen overflow-hidden flex selection:bg-emerald-100 selection:text-emerald-900">
    <div class="w-full lg:w-1/2 h-full bg-white flex flex-col justify-center px-8 sm:px-12 lg:px-20 relative overflow-y-auto">

        <div class="absolute top-8 right-8 sm:right-12 lg:right-20">
            <a href="https://amosb.fun" class="flex items-center gap-2 cursor-pointer group">
                <div class="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white group-hover:bg-emerald-700 transition">
                    <i class="fa-solid fa-code-branch"></i>
                </div>
                <span class="font-bold text-2xl tracking-tight text-slate-900 font-sans">Oneurai</span>
            </a>
        </div>

        <div class="max-w-md w-full mx-auto pt-20 lg:pt-0">
            <div class="mb-10">
                <h1 class="text-3xl font-bold text-slate-900 mb-2">أهلاً بعودتك 👋</h1>
                <p class="text-slate-500">أدخل بياناتك للدخول إلى مساحة العمل الخاصة بك.</p>
            </div>

            <div class="grid grid-cols-2 gap-4 mb-8">
                <button class="flex items-center justify-center gap-2 py-2.5 border border-slate-200 rounded-xl hover:bg-slate-50 transition text-slate-700 font-medium">
                    <i class="fa-brands fa-github text-lg"></i> <span>GitHub</span>
                </button>
                <a href="https://amosb.fun/auth/google" class="flex items-center justify-center gap-2 py-2.5 border border-slate-200 rounded-xl hover:bg-slate-50 transition text-slate-700 font-medium">
                    <i class="fa-brands fa-google text-lg text-red-500"></i> <span>Google</span>
                </a>
            </div>

            <!--[if BLOCK]><![endif]--><!--[if ENDBLOCK]><![endif]-->
<!--[if BLOCK]><![endif]--><!--[if ENDBLOCK]><![endif]-->
            <div class="relative mb-8">
                <div class="absolute inset-0 flex items-center"><div class="w-full border-t border-slate-200"></div></div>
                <div class="relative flex justify-center text-sm"><span class="px-2 bg-white text-slate-500">أو المتابعة عبر البريد</span></div>
            </div>

<form wire:submit="login" class="space-y-5">
    <div>
        <label for="email" class="block text-sm font-medium text-slate-700 mb-1">البريد الإلكتروني</label>
        <input type="email" wire:model="email" name="email" id="email" class="w-full px-4 py-3 rounded-xl border  border-slate-300  focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition text-left" placeholder="name@example.com" dir="ltr">
        <!--[if BLOCK]><![endif]--><!--[if ENDBLOCK]><![endif]-->    </div>

    <div>
        <div class="flex justify-between items-center mb-1">
            <label for="password" class="block text-sm font-medium text-slate-700">كلمة المرور</label>
            <a href="#" class="text-sm text-emerald-600 hover:text-emerald-700 font-medium">نسيت كلمة المرور؟</a>
        </div>
        <input type="password" wire:model="password" name="password" id="password" class="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition text-left" placeholder="••••••••" dir="ltr">
        <!--[if BLOCK]><![endif]--><!--[if ENDBLOCK]><![endif]-->    </div>

    <div class="flex items-center">
        <input id="remember-me" wire:model="remember" type="checkbox" class="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-slate-300 rounded">
        <label for="remember-me" class="mr-2 block text-sm text-slate-600">تذكرني على هذا الجهاز</label>
    </div>

    <button type="submit" class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-emerald-600/20 transition duration-200 flex items-center justify-center gap-2 disabled:opacity-50">
        <span wire:loading.remove>تسجيل الدخول</span>
        <span wire:loading>جاري التحقق...</span>
        <i wire:loading.remove class="fa-solid fa-arrow-left text-sm"></i>
    </button>
</form>

            <div class="mt-8 text-center">
                <p class="text-slate-600">
                    ليس لديك حساب؟
                    <a href="https://amosb.fun/register" class="text-emerald-600 font-bold hover:text-emerald-700 transition mr-1">أنشئ حساباً الآن</a>
                </p>
            </div>
        </div>

        <div class="absolute bottom-6 w-full text-center right-0 px-8 pointer-events-none">
            <p class="text-xs text-slate-400">© 2024 Oneurai. جميع الحقوق محفوظة.</p>
        </div>
    </div>

     <div class="hidden lg:flex w-1/2 h-full bg-slate-900 relative items-center justify-center overflow-hidden">
            <div class="absolute inset-0 bg-gradient-to-br from-slate-900 via-emerald-900 to-slate-900"></div>
            <div class="absolute top-0 right-0 w-96 h-96 bg-emerald-600 rounded-full blur-3xl opacity-20 -mr-20 -mt-20 animate-pulse"></div>
            <div class="absolute bottom-0 left-0 w-80 h-80 bg-amber-500 rounded-full blur-3xl opacity-10 -ml-20 -mb-20"></div>

            <div class="absolute inset-0 bg-grid-pattern"></div>

            <div class="relative z-10 max-w-lg mx-auto px-8">
                <div class="glass-card rounded-2xl p-6 mb-10 transform rotate-1 shadow-2xl border-l-4 border-l-amber-500">
                    <div class="flex gap-2 mb-4">
                        <div class="w-3 h-3 rounded-full bg-red-500"></div>
                        <div class="w-3 h-3 rounded-full bg-amber-500"></div>
                        <div class="w-3 h-3 rounded-full bg-green-500"></div>
                    </div>
                    <div class="font-mono text-sm space-y-2" dir="ltr">
                        <div class="text-slate-400"># Authenticate User</div>
                        <div>
                            <span class="text-purple-400">if</span>
                            <span class="text-white">Auth::attempt([</span>
                        </div>
                        <div class="pl-4">
                            <span class="text-emerald-400">'email'</span> <span class="text-white">=></span> <span class="text-amber-400">$email</span><span class="text-white">,</span>
                        </div>
                        <div class="pl-4">
                            <span class="text-emerald-400">'password'</span> <span class="text-white">=></span> <span class="text-amber-400">$password</span>
                        </div>
                        <div><span class="text-white">])) {</span></div>
                        <div class="pl-4">
                            <span class="text-blue-400">return</span> <span class="text-white">redirect()->to(</span><span class="text-emerald-400">'/dashboard'</span><span class="text-white">);</span>
                        </div>
                        <div><span class="text-white">}</span></div>
                    </div>
                </div>

                <h2 class="text-4xl font-bold text-white mb-6 leading-tight">
                    مجتمع المطورين والذكاء الاصطناعي <span class="text-emerald-400">الأول</span> في المملكة.
                </h2>
                <p class="text-slate-300 text-lg leading-relaxed mb-8">
                    انضم إلى الآلاف من المطورين وعلماء البيانات. شارك نماذجك، ساهم في المشاريع مفتوحة المصدر، وابنِ مستقبل التقنية العربية.
                </p>

                <div class="flex gap-8 pt-8 border-t border-white/10">
                    <div>
                        <div class="text-2xl font-bold text-white">5k+</div>
                        <div class="text-sm text-emerald-400">مطور نشط</div>
                    </div>
                    <div>
                        <div class="text-2xl font-bold text-white">850+</div>
                        <div class="text-sm text-amber-400">نموذج AI</div>
                    </div>
                    <div>
                        <div class="text-2xl font-bold text-white">100%</div>
                        <div class="text-sm text-slate-400">مفتوح المصدر</div>
                    </div>
                </div>
            </div>
        </div>
</div>

    <script>
        let isLogin = true;

        function toggleAuth() {
            const loginForm = document.getElementById('login-form');
            const registerForm = document.getElementById('register-form');
            const title = document.getElementById('page-title');
            const subtitle = document.getElementById('page-subtitle');
            const toggleText = document.getElementById('toggle-text');
            const container = document.getElementById('auth-container');

            // Add fade effect
            container.classList.remove('form-fade-in');
            void container.offsetWidth; // Trigger reflow
            container.classList.add('form-fade-in');

            if (isLogin) {
                // Switch to Register
                loginForm.classList.add('hidden');
                registerForm.classList.remove('hidden');
                title.innerText = "انضم إلى Oneurai 🚀";
                subtitle.innerText = "أنشئ حسابك المجاني وابدأ رحلتك معنا.";
                toggleText.innerHTML = 'لديك حساب بالفعل؟ <button onclick="toggleAuth()" class="text-emerald-600 font-bold hover:text-emerald-700 transition mr-1">سجل دخولك</button>';
            } else {
                // Switch to Login
                registerForm.classList.add('hidden');
                loginForm.classList.remove('hidden');
                title.innerText = "أهلاً بعودتك 👋";
                subtitle.innerText = "أدخل بياناتك للدخول إلى مساحة العمل الخاصة بك.";
                toggleText.innerHTML = 'ليس لديك حساب؟ <button onclick="toggleAuth()" class="text-emerald-600 font-bold hover:text-emerald-700 transition mr-1">أنشئ حساباً الآن</button>';
            }
            isLogin = !isLogin;
        }
    </script>
<!-- Livewire Scripts -->
<script src="/livewire/livewire.js?id=f084fdfb"   data-csrf="glgCUQDdeXs3bGWJZWFjf9zmPDhDkAF9msP40tdh" data-update-uri="/livewire/update" data-navigate-once="true"></script>
</body>
</html>
