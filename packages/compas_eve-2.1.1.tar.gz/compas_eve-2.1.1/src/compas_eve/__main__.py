import compas_eve

if __name__ == "__main__":
    print("COMPAS EVE v{} is installed!".format(compas_eve.__version__))
