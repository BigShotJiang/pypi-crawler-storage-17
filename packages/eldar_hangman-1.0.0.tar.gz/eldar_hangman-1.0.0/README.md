# 🎮 Hangman Game

Classic Hangman with CLI and color output.

## Install
pip install eldar-hangman

## Play
hangman

## Python usage
from hangman_game import Hangman
game = Hangman()
game.play()
