from .game import Hangman

def main():
    game = Hangman()
    game.play()

if __name__ == "__main__":
    main()
