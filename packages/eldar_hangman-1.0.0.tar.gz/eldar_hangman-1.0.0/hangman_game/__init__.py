from .game import Hangman

__all__ = ["Hangman"]
__version__ = "1.0.0"
