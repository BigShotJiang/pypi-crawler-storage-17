"""Top level code."""

from guiguts.application import main

main()
