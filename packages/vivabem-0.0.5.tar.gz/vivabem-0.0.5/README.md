

# Table of Contents     :toc:

-   [BROKEN LINK: sensors]
    -   [BROKEN LINK: imu]
    -   [BROKEN LINK: heart-rate-monitor]
-   [BROKEN LINK: todo]


# Sensors


## IMU


### Accelerometer


### Gyroscope


### Magnetometer


## Heart Rate Monitor


# @TODO

adjust source parameter in Imu class for vb<sub>touch</sub>
adjust source parameter in Imu class for vb<sub>ef</sub>

