Quantity kinds in aerospace ([TAS][isqx.aerospace.TRUE_AIRSPEED], [CAS][isqx.aerospace.CALIBRATED_AIRSPEED], [geopotential altitude][isqx.aerospace.GEOPOTENTIAL_ALTITUDE] etc.)

::: isqx.aerospace