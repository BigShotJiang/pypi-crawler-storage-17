Definitions for U.S. customary and British imperial units ([feet][isqx.usc.FT], [slugs][isqx.usc.SLUG], [pound force][isqx.usc.LBF] etc.).

The public API is the `isqx.usc` module.

::: isqx.usc