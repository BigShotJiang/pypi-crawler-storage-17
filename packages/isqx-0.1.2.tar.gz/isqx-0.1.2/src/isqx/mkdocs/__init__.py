from pathlib import Path

PATH_PLUGIN = Path(__file__).parent
PATH_PLUGIN_ASSETS = PATH_PLUGIN / "assets"
