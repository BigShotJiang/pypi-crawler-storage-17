class FileSystemAccessError(Exception):
    pass


class RedactionFailedError(Exception):
    pass
