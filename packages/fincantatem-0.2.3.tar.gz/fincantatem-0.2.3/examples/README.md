# Examples

You can run each example by setting the required environment variables and running the corresponding `main.{py,sh}` file.

## Required Environment Variables

```
FI_API_KEY=...
FI_MODEL=...
```
