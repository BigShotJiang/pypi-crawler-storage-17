# szn-sklik-id2-server-proto

This is a security placeholder package created to prevent dependency confusion attacks.