# simplemath-ganesh

A very simple Python math library.

## Install
```bash
pip install simplemath-ganesh
