# Generated from McComp.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,157,462,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,
        7,6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,
        13,2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,
        20,7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,
        26,2,27,7,27,2,28,7,28,1,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,3,1,67,8,
        1,1,1,5,1,70,8,1,10,1,12,1,73,9,1,1,1,3,1,76,8,1,1,1,3,1,79,8,1,
        1,1,3,1,82,8,1,1,1,3,1,85,8,1,1,1,3,1,88,8,1,1,1,3,1,91,8,1,1,1,
        3,1,94,8,1,1,1,3,1,97,8,1,1,1,3,1,100,8,1,1,1,3,1,103,8,1,1,1,3,
        1,106,8,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,117,8,1,1,1,5,
        1,120,8,1,10,1,12,1,123,9,1,1,1,3,1,126,8,1,1,1,3,1,129,8,1,1,1,
        3,1,132,8,1,1,1,3,1,135,8,1,1,1,3,1,138,8,1,1,1,3,1,141,8,1,1,1,
        3,1,144,8,1,1,1,3,1,147,8,1,1,1,3,1,150,8,1,1,1,3,1,153,8,1,1,1,
        3,1,156,8,1,1,1,1,1,3,1,160,8,1,1,2,1,2,1,2,1,3,3,3,166,8,3,1,3,
        3,3,169,8,3,1,3,3,3,172,8,3,1,4,1,4,1,4,1,4,1,5,1,5,1,5,1,5,1,6,
        1,6,1,6,1,6,1,7,1,7,1,7,1,7,5,7,190,8,7,10,7,12,7,193,9,7,3,7,195,
        8,7,1,7,1,7,1,8,3,8,200,8,8,1,8,1,8,1,8,1,8,3,8,206,8,8,3,8,208,
        8,8,1,8,1,8,1,8,1,8,1,8,3,8,215,8,8,3,8,217,8,8,1,8,1,8,1,8,3,8,
        222,8,8,1,8,1,8,1,8,3,8,227,8,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,3,8,
        236,8,8,3,8,238,8,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,
        1,8,3,8,252,8,8,3,8,254,8,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,3,8,
        264,8,8,3,8,266,8,8,3,8,268,8,8,1,9,1,9,1,9,1,10,1,10,1,10,1,11,
        1,11,1,11,1,11,3,11,280,8,11,1,11,3,11,283,8,11,1,12,1,12,1,12,1,
        12,1,12,1,12,1,12,1,12,1,13,1,13,1,13,1,13,3,13,297,8,13,3,13,299,
        8,13,1,14,1,14,1,14,1,15,1,15,1,15,1,16,1,16,1,16,1,17,1,17,1,17,
        1,18,1,18,1,18,1,19,1,19,1,19,1,20,3,20,320,8,20,1,20,1,20,1,20,
        1,20,5,20,326,8,20,10,20,12,20,329,9,20,1,21,1,21,1,21,1,21,1,21,
        1,22,1,22,1,22,1,23,1,23,1,23,1,23,5,23,343,8,23,10,23,12,23,346,
        9,23,1,23,1,23,1,24,1,24,1,24,1,24,1,25,1,25,1,25,1,25,1,25,5,25,
        359,8,25,10,25,12,25,362,9,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,
        1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,5,25,380,8,25,10,25,
        12,25,383,9,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,
        1,25,1,25,1,25,3,25,398,8,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,
        1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,
        1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,
        1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,5,25,
        445,8,25,10,25,12,25,448,9,25,1,26,1,26,1,26,1,27,1,27,1,27,1,27,
        1,27,3,27,458,8,27,1,28,1,28,1,28,0,1,50,29,0,2,4,6,8,10,12,14,16,
        18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,0,6,
        1,0,17,18,3,0,1,1,49,49,53,53,2,0,53,53,144,144,1,0,103,104,1,0,
        105,106,1,0,130,131,527,0,58,1,0,0,0,2,159,1,0,0,0,4,161,1,0,0,0,
        6,165,1,0,0,0,8,173,1,0,0,0,10,177,1,0,0,0,12,181,1,0,0,0,14,185,
        1,0,0,0,16,267,1,0,0,0,18,269,1,0,0,0,20,272,1,0,0,0,22,282,1,0,
        0,0,24,284,1,0,0,0,26,298,1,0,0,0,28,300,1,0,0,0,30,303,1,0,0,0,
        32,306,1,0,0,0,34,309,1,0,0,0,36,312,1,0,0,0,38,315,1,0,0,0,40,319,
        1,0,0,0,42,330,1,0,0,0,44,335,1,0,0,0,46,338,1,0,0,0,48,349,1,0,
        0,0,50,397,1,0,0,0,52,449,1,0,0,0,54,457,1,0,0,0,56,459,1,0,0,0,
        58,59,3,2,1,0,59,60,5,0,0,1,60,1,1,0,0,0,61,62,5,9,0,0,62,63,5,7,
        0,0,63,64,5,144,0,0,64,66,3,6,3,0,65,67,3,44,22,0,66,65,1,0,0,0,
        66,67,1,0,0,0,67,71,1,0,0,0,68,70,3,42,21,0,69,68,1,0,0,0,70,73,
        1,0,0,0,71,69,1,0,0,0,71,72,1,0,0,0,72,75,1,0,0,0,73,71,1,0,0,0,
        74,76,3,52,26,0,75,74,1,0,0,0,75,76,1,0,0,0,76,78,1,0,0,0,77,79,
        3,28,14,0,78,77,1,0,0,0,78,79,1,0,0,0,79,81,1,0,0,0,80,82,5,39,0,
        0,81,80,1,0,0,0,81,82,1,0,0,0,82,84,1,0,0,0,83,85,3,18,9,0,84,83,
        1,0,0,0,84,85,1,0,0,0,85,87,1,0,0,0,86,88,3,32,16,0,87,86,1,0,0,
        0,87,88,1,0,0,0,88,90,1,0,0,0,89,91,3,30,15,0,90,89,1,0,0,0,90,91,
        1,0,0,0,91,93,1,0,0,0,92,94,3,34,17,0,93,92,1,0,0,0,93,94,1,0,0,
        0,94,96,1,0,0,0,95,97,3,4,2,0,96,95,1,0,0,0,96,97,1,0,0,0,97,99,
        1,0,0,0,98,100,3,36,18,0,99,98,1,0,0,0,99,100,1,0,0,0,100,102,1,
        0,0,0,101,103,3,38,19,0,102,101,1,0,0,0,102,103,1,0,0,0,103,105,
        1,0,0,0,104,106,3,20,10,0,105,104,1,0,0,0,105,106,1,0,0,0,106,107,
        1,0,0,0,107,108,5,12,0,0,108,160,1,0,0,0,109,110,5,9,0,0,110,111,
        5,7,0,0,111,112,5,144,0,0,112,113,5,34,0,0,113,114,5,144,0,0,114,
        116,3,6,3,0,115,117,3,44,22,0,116,115,1,0,0,0,116,117,1,0,0,0,117,
        121,1,0,0,0,118,120,3,42,21,0,119,118,1,0,0,0,120,123,1,0,0,0,121,
        119,1,0,0,0,121,122,1,0,0,0,122,125,1,0,0,0,123,121,1,0,0,0,124,
        126,3,52,26,0,125,124,1,0,0,0,125,126,1,0,0,0,126,128,1,0,0,0,127,
        129,3,28,14,0,128,127,1,0,0,0,128,129,1,0,0,0,129,131,1,0,0,0,130,
        132,5,39,0,0,131,130,1,0,0,0,131,132,1,0,0,0,132,134,1,0,0,0,133,
        135,3,18,9,0,134,133,1,0,0,0,134,135,1,0,0,0,135,137,1,0,0,0,136,
        138,3,32,16,0,137,136,1,0,0,0,137,138,1,0,0,0,138,140,1,0,0,0,139,
        141,3,30,15,0,140,139,1,0,0,0,140,141,1,0,0,0,141,143,1,0,0,0,142,
        144,3,34,17,0,143,142,1,0,0,0,143,144,1,0,0,0,144,146,1,0,0,0,145,
        147,3,4,2,0,146,145,1,0,0,0,146,147,1,0,0,0,147,149,1,0,0,0,148,
        150,3,36,18,0,149,148,1,0,0,0,149,150,1,0,0,0,150,152,1,0,0,0,151,
        153,3,38,19,0,152,151,1,0,0,0,152,153,1,0,0,0,153,155,1,0,0,0,154,
        156,3,20,10,0,155,154,1,0,0,0,155,156,1,0,0,0,156,157,1,0,0,0,157,
        158,5,12,0,0,158,160,1,0,0,0,159,61,1,0,0,0,159,109,1,0,0,0,160,
        3,1,0,0,0,161,162,5,24,0,0,162,163,3,40,20,0,163,5,1,0,0,0,164,166,
        3,8,4,0,165,164,1,0,0,0,165,166,1,0,0,0,166,168,1,0,0,0,167,169,
        3,10,5,0,168,167,1,0,0,0,168,169,1,0,0,0,169,171,1,0,0,0,170,172,
        3,12,6,0,171,170,1,0,0,0,171,172,1,0,0,0,172,7,1,0,0,0,173,174,5,
        11,0,0,174,175,5,19,0,0,175,176,3,14,7,0,176,9,1,0,0,0,177,178,5,
        23,0,0,178,179,5,19,0,0,179,180,3,14,7,0,180,11,1,0,0,0,181,182,
        7,0,0,0,182,183,5,19,0,0,183,184,3,14,7,0,184,13,1,0,0,0,185,194,
        5,97,0,0,186,191,3,16,8,0,187,188,5,134,0,0,188,190,3,16,8,0,189,
        187,1,0,0,0,190,193,1,0,0,0,191,189,1,0,0,0,191,192,1,0,0,0,192,
        195,1,0,0,0,193,191,1,0,0,0,194,186,1,0,0,0,194,195,1,0,0,0,195,
        196,1,0,0,0,196,197,5,98,0,0,197,15,1,0,0,0,198,200,5,69,0,0,199,
        198,1,0,0,0,199,200,1,0,0,0,200,201,1,0,0,0,201,207,5,144,0,0,202,
        205,5,113,0,0,203,206,3,50,25,0,204,206,5,1,0,0,205,203,1,0,0,0,
        205,204,1,0,0,0,206,208,1,0,0,0,207,202,1,0,0,0,207,208,1,0,0,0,
        208,268,1,0,0,0,209,210,5,80,0,0,210,216,5,144,0,0,211,214,5,113,
        0,0,212,215,3,50,25,0,213,215,5,1,0,0,214,212,1,0,0,0,214,213,1,
        0,0,0,215,217,1,0,0,0,216,211,1,0,0,0,216,217,1,0,0,0,217,268,1,
        0,0,0,218,222,5,44,0,0,219,220,5,63,0,0,220,222,5,105,0,0,221,218,
        1,0,0,0,221,219,1,0,0,0,222,223,1,0,0,0,223,226,5,144,0,0,224,225,
        5,113,0,0,225,227,7,1,0,0,226,224,1,0,0,0,226,227,1,0,0,0,227,268,
        1,0,0,0,228,229,5,45,0,0,229,237,5,144,0,0,230,235,5,113,0,0,231,
        236,5,144,0,0,232,236,3,46,23,0,233,236,5,49,0,0,234,236,5,1,0,0,
        235,231,1,0,0,0,235,232,1,0,0,0,235,233,1,0,0,0,235,234,1,0,0,0,
        236,238,1,0,0,0,237,230,1,0,0,0,237,238,1,0,0,0,238,268,1,0,0,0,
        239,240,5,46,0,0,240,241,5,144,0,0,241,242,5,113,0,0,242,268,3,50,
        25,0,243,244,5,69,0,0,244,245,5,105,0,0,245,253,5,144,0,0,246,251,
        5,113,0,0,247,252,5,144,0,0,248,252,3,46,23,0,249,252,5,49,0,0,250,
        252,5,1,0,0,251,247,1,0,0,0,251,248,1,0,0,0,251,249,1,0,0,0,251,
        250,1,0,0,0,252,254,1,0,0,0,253,246,1,0,0,0,253,254,1,0,0,0,254,
        268,1,0,0,0,255,256,5,80,0,0,256,257,5,105,0,0,257,265,5,144,0,0,
        258,263,5,113,0,0,259,264,5,144,0,0,260,264,3,46,23,0,261,264,5,
        49,0,0,262,264,5,1,0,0,263,259,1,0,0,0,263,260,1,0,0,0,263,261,1,
        0,0,0,263,262,1,0,0,0,264,266,1,0,0,0,265,258,1,0,0,0,265,266,1,
        0,0,0,266,268,1,0,0,0,267,199,1,0,0,0,267,209,1,0,0,0,267,221,1,
        0,0,0,267,228,1,0,0,0,267,239,1,0,0,0,267,243,1,0,0,0,267,255,1,
        0,0,0,268,17,1,0,0,0,269,270,5,25,0,0,270,271,3,40,20,0,271,19,1,
        0,0,0,272,273,5,13,0,0,273,274,3,40,20,0,274,21,1,0,0,0,275,279,
        5,22,0,0,276,277,5,97,0,0,277,278,5,50,0,0,278,280,5,98,0,0,279,
        276,1,0,0,0,279,280,1,0,0,0,280,283,1,0,0,0,281,283,5,144,0,0,282,
        275,1,0,0,0,282,281,1,0,0,0,283,23,1,0,0,0,284,285,5,97,0,0,285,
        286,3,50,25,0,286,287,5,134,0,0,287,288,3,50,25,0,288,289,5,134,
        0,0,289,290,3,50,25,0,290,291,5,98,0,0,291,25,1,0,0,0,292,299,5,
        4,0,0,293,296,5,20,0,0,294,297,5,4,0,0,295,297,3,22,11,0,296,294,
        1,0,0,0,296,295,1,0,0,0,297,299,1,0,0,0,298,292,1,0,0,0,298,293,
        1,0,0,0,299,27,1,0,0,0,300,301,5,40,0,0,301,302,5,53,0,0,302,29,
        1,0,0,0,303,304,5,10,0,0,304,305,3,40,20,0,305,31,1,0,0,0,306,307,
        5,8,0,0,307,308,3,40,20,0,308,33,1,0,0,0,309,310,5,15,0,0,310,311,
        3,40,20,0,311,35,1,0,0,0,312,313,5,28,0,0,313,314,3,40,20,0,314,
        37,1,0,0,0,315,316,5,14,0,0,316,317,3,40,20,0,317,39,1,0,0,0,318,
        320,3,56,28,0,319,318,1,0,0,0,319,320,1,0,0,0,320,327,1,0,0,0,321,
        322,5,35,0,0,322,326,5,144,0,0,323,324,5,26,0,0,324,326,3,56,28,
        0,325,321,1,0,0,0,325,323,1,0,0,0,326,329,1,0,0,0,327,325,1,0,0,
        0,327,328,1,0,0,0,328,41,1,0,0,0,329,327,1,0,0,0,330,331,5,43,0,
        0,331,332,7,2,0,0,332,333,7,2,0,0,333,334,3,56,28,0,334,43,1,0,0,
        0,335,336,5,6,0,0,336,337,7,2,0,0,337,45,1,0,0,0,338,339,5,101,0,
        0,339,344,3,50,25,0,340,341,5,134,0,0,341,343,3,50,25,0,342,340,
        1,0,0,0,343,346,1,0,0,0,344,342,1,0,0,0,344,345,1,0,0,0,345,347,
        1,0,0,0,346,344,1,0,0,0,347,348,5,102,0,0,348,47,1,0,0,0,349,350,
        5,144,0,0,350,351,5,113,0,0,351,352,3,50,25,0,352,49,1,0,0,0,353,
        354,6,25,-1,0,354,398,5,1,0,0,355,398,5,50,0,0,356,398,5,52,0,0,
        357,359,5,53,0,0,358,357,1,0,0,0,359,362,1,0,0,0,360,358,1,0,0,0,
        360,361,1,0,0,0,361,398,1,0,0,0,362,360,1,0,0,0,363,364,5,144,0,
        0,364,365,5,136,0,0,365,398,3,50,25,24,366,367,5,144,0,0,367,368,
        5,141,0,0,368,398,3,50,25,23,369,370,5,144,0,0,370,371,5,99,0,0,
        371,372,3,50,25,0,372,373,5,100,0,0,373,398,1,0,0,0,374,375,5,144,
        0,0,375,376,5,97,0,0,376,381,3,50,25,0,377,378,5,134,0,0,378,380,
        3,50,25,0,379,377,1,0,0,0,380,383,1,0,0,0,381,379,1,0,0,0,381,382,
        1,0,0,0,382,384,1,0,0,0,383,381,1,0,0,0,384,385,5,98,0,0,385,398,
        1,0,0,0,386,387,5,97,0,0,387,388,3,50,25,0,388,389,5,98,0,0,389,
        398,1,0,0,0,390,391,7,3,0,0,391,398,3,50,25,19,392,398,5,144,0,0,
        393,394,5,112,0,0,394,398,3,50,25,5,395,398,5,22,0,0,396,398,5,33,
        0,0,397,353,1,0,0,0,397,355,1,0,0,0,397,356,1,0,0,0,397,360,1,0,
        0,0,397,363,1,0,0,0,397,366,1,0,0,0,397,369,1,0,0,0,397,374,1,0,
        0,0,397,386,1,0,0,0,397,390,1,0,0,0,397,392,1,0,0,0,397,393,1,0,
        0,0,397,395,1,0,0,0,397,396,1,0,0,0,398,446,1,0,0,0,399,400,10,18,
        0,0,400,401,5,108,0,0,401,445,3,50,25,18,402,403,10,17,0,0,403,404,
        7,4,0,0,404,445,3,50,25,18,405,406,10,16,0,0,406,407,7,3,0,0,407,
        445,3,50,25,17,408,409,10,15,0,0,409,410,5,107,0,0,410,445,3,50,
        25,16,411,412,10,14,0,0,412,413,5,2,0,0,413,445,3,50,25,15,414,415,
        10,13,0,0,415,416,5,3,0,0,416,445,3,50,25,14,417,418,10,11,0,0,418,
        419,5,127,0,0,419,445,3,50,25,12,420,421,10,10,0,0,421,422,5,126,
        0,0,422,445,3,50,25,11,423,424,10,9,0,0,424,425,5,128,0,0,425,445,
        3,50,25,10,426,427,10,8,0,0,427,428,5,129,0,0,428,445,3,50,25,9,
        429,430,10,7,0,0,430,431,5,114,0,0,431,445,3,50,25,8,432,433,10,
        6,0,0,433,434,5,115,0,0,434,445,3,50,25,7,435,436,10,4,0,0,436,437,
        7,5,0,0,437,445,3,50,25,5,438,439,10,3,0,0,439,440,5,137,0,0,440,
        441,3,50,25,0,441,442,5,138,0,0,442,443,3,50,25,4,443,445,1,0,0,
        0,444,399,1,0,0,0,444,402,1,0,0,0,444,405,1,0,0,0,444,408,1,0,0,
        0,444,411,1,0,0,0,444,414,1,0,0,0,444,417,1,0,0,0,444,420,1,0,0,
        0,444,423,1,0,0,0,444,426,1,0,0,0,444,429,1,0,0,0,444,432,1,0,0,
        0,444,435,1,0,0,0,444,438,1,0,0,0,445,448,1,0,0,0,446,444,1,0,0,
        0,446,447,1,0,0,0,447,51,1,0,0,0,448,446,1,0,0,0,449,450,5,41,0,
        0,450,451,5,53,0,0,451,53,1,0,0,0,452,453,5,42,0,0,453,458,5,53,
        0,0,454,455,5,42,0,0,455,456,5,41,0,0,456,458,5,53,0,0,457,452,1,
        0,0,0,457,454,1,0,0,0,458,55,1,0,0,0,459,460,5,47,0,0,460,57,1,0,
        0,0,60,66,71,75,78,81,84,87,90,93,96,99,102,105,116,121,125,128,
        131,134,137,140,143,146,149,152,155,159,165,168,171,191,194,199,
        205,207,214,216,221,226,235,237,251,253,263,265,267,279,282,296,
        298,319,325,327,344,360,381,397,444,446,457
    ]

class McCompParser ( Parser ):

    grammarFileName = "McComp.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'0'", "'>>'", "'<<'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'string'", "'vector'", "'symbol'", 
                     "<INVALID>", "'%include'", "'NULL'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'asm'", "'auto'", "'_Bool'", 
                     "'break'", "'case'", "'char'", "'_Complex'", "'const'", 
                     "'continue'", "'default'", "'do'", "'double'", "'else'", 
                     "'enum'", "'extern'", "'false'", "'float'", "'for'", 
                     "'goto'", "'if'", "'_Imaginary'", "'inline'", "'int'", 
                     "'long'", "'register'", "'return'", "'short'", "'signed'", 
                     "'sizeof'", "'static'", "'struct'", "'switch'", "'true'", 
                     "'typedef'", "'union'", "'unsigned'", "'void'", "'volatile'", 
                     "'while'", "'('", "')'", "'['", "']'", "'{'", "'}'", 
                     "'+'", "'-'", "'*'", "'/'", "'%'", "'^'", "'&'", "'|'", 
                     "'~'", "<INVALID>", "'='", "'<'", "'>'", "'+='", "'-='", 
                     "'*='", "'/='", "'%='", "'^='", "'&='", "'|='", "'<<='", 
                     "'>>='", "'=='", "'!='", "'<='", "'>='", "<INVALID>", 
                     "<INVALID>", "'++'", "'--'", "','", "'->*'", "'->'", 
                     "'?'", "':'", "'::'", "';'", "'.'", "'.*'", "'...'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "Absolute", "At", "Category", "Component", "UserVars", 
                      "Define", "Declare", "Definition", "End", "McDisplay", 
                      "Finally", "Initialize", "Instrument", "Output", "Private", 
                      "Parameters", "Relative", "Rotated", "Previous", "Setting", 
                      "Trace", "Share", "Extend", "Group", "Save", "Jump", 
                      "When", "Next", "Iterate", "Myself", "Copy", "Inherit", 
                      "Split", "Removable", "Cpu", "NoAcc", "Dependency", 
                      "Shell", "Search", "MetaData", "String", "Vector", 
                      "Symbol", "UnparsedBlock", "Include", "Null", "IntegerLiteral", 
                      "CharacterLiteral", "FloatingLiteral", "StringLiteral", 
                      "BooleanLitteral", "UserDefinedLiteral", "MultiLineMacro", 
                      "Directive", "Asm", "Auto", "Bool", "Break", "Case", 
                      "Char", "Complex", "Const", "Continue", "Default", 
                      "Do", "Double", "Else", "Enum", "Extern", "False_", 
                      "Float", "For", "Goto", "If", "Imaginary", "Inline", 
                      "Int", "Long", "Register", "Return", "Short", "Signed", 
                      "Sizeof", "Static", "Struct", "Switch", "True_", "Typedef", 
                      "Union", "Unsigned", "Void", "Volatile", "While", 
                      "LeftParen", "RightParen", "LeftBracket", "RightBracket", 
                      "LeftBrace", "RightBrace", "Plus", "Minus", "Star", 
                      "Div", "Mod", "Caret", "And", "Or", "Tilde", "Not", 
                      "Assign", "Less", "Greater", "PlusAssign", "MinusAssign", 
                      "StarAssign", "DivAssign", "ModAssign", "XorAssign", 
                      "AndAssign", "OrAssign", "LeftShiftAssign", "RightShiftAssign", 
                      "Equal", "NotEqual", "LessEqual", "GreaterEqual", 
                      "AndAnd", "OrOr", "PlusPlus", "MinusMinus", "Comma", 
                      "ArrowStar", "Arrow", "Question", "Colon", "Doublecolon", 
                      "Semi", "Dot", "DotStar", "Ellipsis", "Identifier", 
                      "DecimalLiteral", "OctalLiteral", "HexadecimalLiteral", 
                      "BinaryLiteral", "IntegerSuffix", "UserDefinedIntegerLiteral", 
                      "UserDefinedFloatingLiteral", "UserDefinedStringLiteral", 
                      "UserDefinedCharacterLiteral", "Whitespace", "Newline", 
                      "BlockComment", "LineComment" ]

    RULE_prog = 0
    RULE_component_definition = 1
    RULE_component_trace = 2
    RULE_component_parameter_set = 3
    RULE_component_define_parameters = 4
    RULE_component_set_parameters = 5
    RULE_component_out_parameters = 6
    RULE_component_parameters = 7
    RULE_component_parameter = 8
    RULE_share = 9
    RULE_display = 10
    RULE_component_ref = 11
    RULE_coords = 12
    RULE_reference = 13
    RULE_dependency = 14
    RULE_declare = 15
    RULE_uservars = 16
    RULE_initialise = 17
    RULE_save = 18
    RULE_finally_ = 19
    RULE_multi_block = 20
    RULE_metadata = 21
    RULE_category = 22
    RULE_initializerlist = 23
    RULE_assignment = 24
    RULE_expr = 25
    RULE_shell = 26
    RULE_search = 27
    RULE_unparsed_block = 28

    ruleNames =  [ "prog", "component_definition", "component_trace", "component_parameter_set", 
                   "component_define_parameters", "component_set_parameters", 
                   "component_out_parameters", "component_parameters", "component_parameter", 
                   "share", "display", "component_ref", "coords", "reference", 
                   "dependency", "declare", "uservars", "initialise", "save", 
                   "finally_", "multi_block", "metadata", "category", "initializerlist", 
                   "assignment", "expr", "shell", "search", "unparsed_block" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    Absolute=4
    At=5
    Category=6
    Component=7
    UserVars=8
    Define=9
    Declare=10
    Definition=11
    End=12
    McDisplay=13
    Finally=14
    Initialize=15
    Instrument=16
    Output=17
    Private=18
    Parameters=19
    Relative=20
    Rotated=21
    Previous=22
    Setting=23
    Trace=24
    Share=25
    Extend=26
    Group=27
    Save=28
    Jump=29
    When=30
    Next=31
    Iterate=32
    Myself=33
    Copy=34
    Inherit=35
    Split=36
    Removable=37
    Cpu=38
    NoAcc=39
    Dependency=40
    Shell=41
    Search=42
    MetaData=43
    String=44
    Vector=45
    Symbol=46
    UnparsedBlock=47
    Include=48
    Null=49
    IntegerLiteral=50
    CharacterLiteral=51
    FloatingLiteral=52
    StringLiteral=53
    BooleanLitteral=54
    UserDefinedLiteral=55
    MultiLineMacro=56
    Directive=57
    Asm=58
    Auto=59
    Bool=60
    Break=61
    Case=62
    Char=63
    Complex=64
    Const=65
    Continue=66
    Default=67
    Do=68
    Double=69
    Else=70
    Enum=71
    Extern=72
    False_=73
    Float=74
    For=75
    Goto=76
    If=77
    Imaginary=78
    Inline=79
    Int=80
    Long=81
    Register=82
    Return=83
    Short=84
    Signed=85
    Sizeof=86
    Static=87
    Struct=88
    Switch=89
    True_=90
    Typedef=91
    Union=92
    Unsigned=93
    Void=94
    Volatile=95
    While=96
    LeftParen=97
    RightParen=98
    LeftBracket=99
    RightBracket=100
    LeftBrace=101
    RightBrace=102
    Plus=103
    Minus=104
    Star=105
    Div=106
    Mod=107
    Caret=108
    And=109
    Or=110
    Tilde=111
    Not=112
    Assign=113
    Less=114
    Greater=115
    PlusAssign=116
    MinusAssign=117
    StarAssign=118
    DivAssign=119
    ModAssign=120
    XorAssign=121
    AndAssign=122
    OrAssign=123
    LeftShiftAssign=124
    RightShiftAssign=125
    Equal=126
    NotEqual=127
    LessEqual=128
    GreaterEqual=129
    AndAnd=130
    OrOr=131
    PlusPlus=132
    MinusMinus=133
    Comma=134
    ArrowStar=135
    Arrow=136
    Question=137
    Colon=138
    Doublecolon=139
    Semi=140
    Dot=141
    DotStar=142
    Ellipsis=143
    Identifier=144
    DecimalLiteral=145
    OctalLiteral=146
    HexadecimalLiteral=147
    BinaryLiteral=148
    IntegerSuffix=149
    UserDefinedIntegerLiteral=150
    UserDefinedFloatingLiteral=151
    UserDefinedStringLiteral=152
    UserDefinedCharacterLiteral=153
    Whitespace=154
    Newline=155
    BlockComment=156
    LineComment=157

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def component_definition(self):
            return self.getTypedRuleContext(McCompParser.Component_definitionContext,0)


        def EOF(self):
            return self.getToken(McCompParser.EOF, 0)

        def getRuleIndex(self):
            return McCompParser.RULE_prog

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProg" ):
                return visitor.visitProg(self)
            else:
                return visitor.visitChildren(self)




    def prog(self):

        localctx = McCompParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 58
            self.component_definition()
            self.state = 59
            self.match(McCompParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Component_definitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McCompParser.RULE_component_definition

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ComponentDefineNewContext(Component_definitionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.Component_definitionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Define(self):
            return self.getToken(McCompParser.Define, 0)
        def Component(self):
            return self.getToken(McCompParser.Component, 0)
        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)
        def component_parameter_set(self):
            return self.getTypedRuleContext(McCompParser.Component_parameter_setContext,0)

        def End(self):
            return self.getToken(McCompParser.End, 0)
        def category(self):
            return self.getTypedRuleContext(McCompParser.CategoryContext,0)

        def metadata(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.MetadataContext)
            else:
                return self.getTypedRuleContext(McCompParser.MetadataContext,i)

        def shell(self):
            return self.getTypedRuleContext(McCompParser.ShellContext,0)

        def dependency(self):
            return self.getTypedRuleContext(McCompParser.DependencyContext,0)

        def NoAcc(self):
            return self.getToken(McCompParser.NoAcc, 0)
        def share(self):
            return self.getTypedRuleContext(McCompParser.ShareContext,0)

        def uservars(self):
            return self.getTypedRuleContext(McCompParser.UservarsContext,0)

        def declare(self):
            return self.getTypedRuleContext(McCompParser.DeclareContext,0)

        def initialise(self):
            return self.getTypedRuleContext(McCompParser.InitialiseContext,0)

        def component_trace(self):
            return self.getTypedRuleContext(McCompParser.Component_traceContext,0)

        def save(self):
            return self.getTypedRuleContext(McCompParser.SaveContext,0)

        def finally_(self):
            return self.getTypedRuleContext(McCompParser.Finally_Context,0)

        def display(self):
            return self.getTypedRuleContext(McCompParser.DisplayContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponentDefineNew" ):
                return visitor.visitComponentDefineNew(self)
            else:
                return visitor.visitChildren(self)


    class ComponentDefineCopyContext(Component_definitionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.Component_definitionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Define(self):
            return self.getToken(McCompParser.Define, 0)
        def Component(self):
            return self.getToken(McCompParser.Component, 0)
        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.Identifier)
            else:
                return self.getToken(McCompParser.Identifier, i)
        def Copy(self):
            return self.getToken(McCompParser.Copy, 0)
        def component_parameter_set(self):
            return self.getTypedRuleContext(McCompParser.Component_parameter_setContext,0)

        def End(self):
            return self.getToken(McCompParser.End, 0)
        def category(self):
            return self.getTypedRuleContext(McCompParser.CategoryContext,0)

        def metadata(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.MetadataContext)
            else:
                return self.getTypedRuleContext(McCompParser.MetadataContext,i)

        def shell(self):
            return self.getTypedRuleContext(McCompParser.ShellContext,0)

        def dependency(self):
            return self.getTypedRuleContext(McCompParser.DependencyContext,0)

        def NoAcc(self):
            return self.getToken(McCompParser.NoAcc, 0)
        def share(self):
            return self.getTypedRuleContext(McCompParser.ShareContext,0)

        def uservars(self):
            return self.getTypedRuleContext(McCompParser.UservarsContext,0)

        def declare(self):
            return self.getTypedRuleContext(McCompParser.DeclareContext,0)

        def initialise(self):
            return self.getTypedRuleContext(McCompParser.InitialiseContext,0)

        def component_trace(self):
            return self.getTypedRuleContext(McCompParser.Component_traceContext,0)

        def save(self):
            return self.getTypedRuleContext(McCompParser.SaveContext,0)

        def finally_(self):
            return self.getTypedRuleContext(McCompParser.Finally_Context,0)

        def display(self):
            return self.getTypedRuleContext(McCompParser.DisplayContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponentDefineCopy" ):
                return visitor.visitComponentDefineCopy(self)
            else:
                return visitor.visitChildren(self)



    def component_definition(self):

        localctx = McCompParser.Component_definitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_component_definition)
        self._la = 0 # Token type
        try:
            self.state = 159
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
            if la_ == 1:
                localctx = McCompParser.ComponentDefineNewContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 61
                self.match(McCompParser.Define)
                self.state = 62
                self.match(McCompParser.Component)
                self.state = 63
                self.match(McCompParser.Identifier)
                self.state = 64
                self.component_parameter_set()
                self.state = 66
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==6:
                    self.state = 65
                    self.category()


                self.state = 71
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==43:
                    self.state = 68
                    self.metadata()
                    self.state = 73
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 75
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==41:
                    self.state = 74
                    self.shell()


                self.state = 78
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==40:
                    self.state = 77
                    self.dependency()


                self.state = 81
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==39:
                    self.state = 80
                    self.match(McCompParser.NoAcc)


                self.state = 84
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==25:
                    self.state = 83
                    self.share()


                self.state = 87
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==8:
                    self.state = 86
                    self.uservars()


                self.state = 90
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==10:
                    self.state = 89
                    self.declare()


                self.state = 93
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==15:
                    self.state = 92
                    self.initialise()


                self.state = 96
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==24:
                    self.state = 95
                    self.component_trace()


                self.state = 99
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 98
                    self.save()


                self.state = 102
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==14:
                    self.state = 101
                    self.finally_()


                self.state = 105
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==13:
                    self.state = 104
                    self.display()


                self.state = 107
                self.match(McCompParser.End)
                pass

            elif la_ == 2:
                localctx = McCompParser.ComponentDefineCopyContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 109
                self.match(McCompParser.Define)
                self.state = 110
                self.match(McCompParser.Component)
                self.state = 111
                self.match(McCompParser.Identifier)
                self.state = 112
                self.match(McCompParser.Copy)
                self.state = 113
                self.match(McCompParser.Identifier)
                self.state = 114
                self.component_parameter_set()
                self.state = 116
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==6:
                    self.state = 115
                    self.category()


                self.state = 121
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==43:
                    self.state = 118
                    self.metadata()
                    self.state = 123
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 125
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==41:
                    self.state = 124
                    self.shell()


                self.state = 128
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==40:
                    self.state = 127
                    self.dependency()


                self.state = 131
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==39:
                    self.state = 130
                    self.match(McCompParser.NoAcc)


                self.state = 134
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==25:
                    self.state = 133
                    self.share()


                self.state = 137
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==8:
                    self.state = 136
                    self.uservars()


                self.state = 140
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==10:
                    self.state = 139
                    self.declare()


                self.state = 143
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==15:
                    self.state = 142
                    self.initialise()


                self.state = 146
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==24:
                    self.state = 145
                    self.component_trace()


                self.state = 149
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==28:
                    self.state = 148
                    self.save()


                self.state = 152
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==14:
                    self.state = 151
                    self.finally_()


                self.state = 155
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==13:
                    self.state = 154
                    self.display()


                self.state = 157
                self.match(McCompParser.End)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Component_traceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Trace(self):
            return self.getToken(McCompParser.Trace, 0)

        def multi_block(self):
            return self.getTypedRuleContext(McCompParser.Multi_blockContext,0)


        def getRuleIndex(self):
            return McCompParser.RULE_component_trace

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponent_trace" ):
                return visitor.visitComponent_trace(self)
            else:
                return visitor.visitChildren(self)




    def component_trace(self):

        localctx = McCompParser.Component_traceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_component_trace)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 161
            self.match(McCompParser.Trace)
            self.state = 162
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Component_parameter_setContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def component_define_parameters(self):
            return self.getTypedRuleContext(McCompParser.Component_define_parametersContext,0)


        def component_set_parameters(self):
            return self.getTypedRuleContext(McCompParser.Component_set_parametersContext,0)


        def component_out_parameters(self):
            return self.getTypedRuleContext(McCompParser.Component_out_parametersContext,0)


        def getRuleIndex(self):
            return McCompParser.RULE_component_parameter_set

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponent_parameter_set" ):
                return visitor.visitComponent_parameter_set(self)
            else:
                return visitor.visitChildren(self)




    def component_parameter_set(self):

        localctx = McCompParser.Component_parameter_setContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_component_parameter_set)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 165
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==11:
                self.state = 164
                self.component_define_parameters()


            self.state = 168
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==23:
                self.state = 167
                self.component_set_parameters()


            self.state = 171
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==17 or _la==18:
                self.state = 170
                self.component_out_parameters()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Component_define_parametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Definition(self):
            return self.getToken(McCompParser.Definition, 0)

        def Parameters(self):
            return self.getToken(McCompParser.Parameters, 0)

        def component_parameters(self):
            return self.getTypedRuleContext(McCompParser.Component_parametersContext,0)


        def getRuleIndex(self):
            return McCompParser.RULE_component_define_parameters

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponent_define_parameters" ):
                return visitor.visitComponent_define_parameters(self)
            else:
                return visitor.visitChildren(self)




    def component_define_parameters(self):

        localctx = McCompParser.Component_define_parametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_component_define_parameters)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 173
            self.match(McCompParser.Definition)
            self.state = 174
            self.match(McCompParser.Parameters)
            self.state = 175
            self.component_parameters()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Component_set_parametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Setting(self):
            return self.getToken(McCompParser.Setting, 0)

        def Parameters(self):
            return self.getToken(McCompParser.Parameters, 0)

        def component_parameters(self):
            return self.getTypedRuleContext(McCompParser.Component_parametersContext,0)


        def getRuleIndex(self):
            return McCompParser.RULE_component_set_parameters

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponent_set_parameters" ):
                return visitor.visitComponent_set_parameters(self)
            else:
                return visitor.visitChildren(self)




    def component_set_parameters(self):

        localctx = McCompParser.Component_set_parametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_component_set_parameters)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 177
            self.match(McCompParser.Setting)
            self.state = 178
            self.match(McCompParser.Parameters)
            self.state = 179
            self.component_parameters()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Component_out_parametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Parameters(self):
            return self.getToken(McCompParser.Parameters, 0)

        def component_parameters(self):
            return self.getTypedRuleContext(McCompParser.Component_parametersContext,0)


        def Output(self):
            return self.getToken(McCompParser.Output, 0)

        def Private(self):
            return self.getToken(McCompParser.Private, 0)

        def getRuleIndex(self):
            return McCompParser.RULE_component_out_parameters

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponent_out_parameters" ):
                return visitor.visitComponent_out_parameters(self)
            else:
                return visitor.visitChildren(self)




    def component_out_parameters(self):

        localctx = McCompParser.Component_out_parametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_component_out_parameters)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 181
            _la = self._input.LA(1)
            if not(_la==17 or _la==18):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 182
            self.match(McCompParser.Parameters)
            self.state = 183
            self.component_parameters()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Component_parametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LeftParen(self):
            return self.getToken(McCompParser.LeftParen, 0)

        def RightParen(self):
            return self.getToken(McCompParser.RightParen, 0)

        def component_parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.Component_parameterContext)
            else:
                return self.getTypedRuleContext(McCompParser.Component_parameterContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.Comma)
            else:
                return self.getToken(McCompParser.Comma, i)

        def getRuleIndex(self):
            return McCompParser.RULE_component_parameters

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponent_parameters" ):
                return visitor.visitComponent_parameters(self)
            else:
                return visitor.visitChildren(self)




    def component_parameters(self):

        localctx = McCompParser.Component_parametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_component_parameters)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 185
            self.match(McCompParser.LeftParen)
            self.state = 194
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if ((((_la - 44)) & ~0x3f) == 0 and ((1 << (_la - 44)) & 68753555463) != 0) or _la==144:
                self.state = 186
                self.component_parameter()
                self.state = 191
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==134:
                    self.state = 187
                    self.match(McCompParser.Comma)
                    self.state = 188
                    self.component_parameter()
                    self.state = 193
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 196
            self.match(McCompParser.RightParen)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Component_parameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McCompParser.RULE_component_parameter

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ComponentParameterSymbolContext(Component_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.Component_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Symbol(self):
            return self.getToken(McCompParser.Symbol, 0)
        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)
        def Assign(self):
            return self.getToken(McCompParser.Assign, 0)
        def expr(self):
            return self.getTypedRuleContext(McCompParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponentParameterSymbol" ):
                return visitor.visitComponentParameterSymbol(self)
            else:
                return visitor.visitChildren(self)


    class ComponentParameterDoubleArrayContext(Component_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.Component_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Double(self):
            return self.getToken(McCompParser.Double, 0)
        def Star(self):
            return self.getToken(McCompParser.Star, 0)
        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.Identifier)
            else:
                return self.getToken(McCompParser.Identifier, i)
        def Assign(self):
            return self.getToken(McCompParser.Assign, 0)
        def initializerlist(self):
            return self.getTypedRuleContext(McCompParser.InitializerlistContext,0)

        def Null(self):
            return self.getToken(McCompParser.Null, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponentParameterDoubleArray" ):
                return visitor.visitComponentParameterDoubleArray(self)
            else:
                return visitor.visitChildren(self)


    class ComponentParameterDoubleContext(Component_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.Component_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)
        def Double(self):
            return self.getToken(McCompParser.Double, 0)
        def Assign(self):
            return self.getToken(McCompParser.Assign, 0)
        def expr(self):
            return self.getTypedRuleContext(McCompParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponentParameterDouble" ):
                return visitor.visitComponentParameterDouble(self)
            else:
                return visitor.visitChildren(self)


    class ComponentParameterVectorContext(Component_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.Component_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Vector(self):
            return self.getToken(McCompParser.Vector, 0)
        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.Identifier)
            else:
                return self.getToken(McCompParser.Identifier, i)
        def Assign(self):
            return self.getToken(McCompParser.Assign, 0)
        def initializerlist(self):
            return self.getTypedRuleContext(McCompParser.InitializerlistContext,0)

        def Null(self):
            return self.getToken(McCompParser.Null, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponentParameterVector" ):
                return visitor.visitComponentParameterVector(self)
            else:
                return visitor.visitChildren(self)


    class ComponentParameterIntegerContext(Component_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.Component_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Int(self):
            return self.getToken(McCompParser.Int, 0)
        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)
        def Assign(self):
            return self.getToken(McCompParser.Assign, 0)
        def expr(self):
            return self.getTypedRuleContext(McCompParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponentParameterInteger" ):
                return visitor.visitComponentParameterInteger(self)
            else:
                return visitor.visitChildren(self)


    class ComponentParameterIntegerArrayContext(Component_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.Component_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Int(self):
            return self.getToken(McCompParser.Int, 0)
        def Star(self):
            return self.getToken(McCompParser.Star, 0)
        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.Identifier)
            else:
                return self.getToken(McCompParser.Identifier, i)
        def Assign(self):
            return self.getToken(McCompParser.Assign, 0)
        def initializerlist(self):
            return self.getTypedRuleContext(McCompParser.InitializerlistContext,0)

        def Null(self):
            return self.getToken(McCompParser.Null, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponentParameterIntegerArray" ):
                return visitor.visitComponentParameterIntegerArray(self)
            else:
                return visitor.visitChildren(self)


    class ComponentParameterStringContext(Component_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.Component_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)
        def String(self):
            return self.getToken(McCompParser.String, 0)
        def Assign(self):
            return self.getToken(McCompParser.Assign, 0)
        def Char(self):
            return self.getToken(McCompParser.Char, 0)
        def Star(self):
            return self.getToken(McCompParser.Star, 0)
        def StringLiteral(self):
            return self.getToken(McCompParser.StringLiteral, 0)
        def Null(self):
            return self.getToken(McCompParser.Null, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponentParameterString" ):
                return visitor.visitComponentParameterString(self)
            else:
                return visitor.visitChildren(self)



    def component_parameter(self):

        localctx = McCompParser.Component_parameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_component_parameter)
        self._la = 0 # Token type
        try:
            self.state = 267
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,45,self._ctx)
            if la_ == 1:
                localctx = McCompParser.ComponentParameterDoubleContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 199
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==69:
                    self.state = 198
                    self.match(McCompParser.Double)


                self.state = 201
                self.match(McCompParser.Identifier)
                self.state = 207
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==113:
                    self.state = 202
                    self.match(McCompParser.Assign)
                    self.state = 205
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
                    if la_ == 1:
                        self.state = 203
                        self.expr(0)
                        pass

                    elif la_ == 2:
                        self.state = 204
                        self.match(McCompParser.T__0)
                        pass




                pass

            elif la_ == 2:
                localctx = McCompParser.ComponentParameterIntegerContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 209
                self.match(McCompParser.Int)
                self.state = 210
                self.match(McCompParser.Identifier)
                self.state = 216
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==113:
                    self.state = 211
                    self.match(McCompParser.Assign)
                    self.state = 214
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,35,self._ctx)
                    if la_ == 1:
                        self.state = 212
                        self.expr(0)
                        pass

                    elif la_ == 2:
                        self.state = 213
                        self.match(McCompParser.T__0)
                        pass




                pass

            elif la_ == 3:
                localctx = McCompParser.ComponentParameterStringContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 221
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [44]:
                    self.state = 218
                    self.match(McCompParser.String)
                    pass
                elif token in [63]:
                    self.state = 219
                    self.match(McCompParser.Char)
                    self.state = 220
                    self.match(McCompParser.Star)
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 223
                self.match(McCompParser.Identifier)
                self.state = 226
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==113:
                    self.state = 224
                    self.match(McCompParser.Assign)
                    self.state = 225
                    _la = self._input.LA(1)
                    if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 9570149208162306) != 0)):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()


                pass

            elif la_ == 4:
                localctx = McCompParser.ComponentParameterVectorContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 228
                self.match(McCompParser.Vector)
                self.state = 229
                self.match(McCompParser.Identifier)
                self.state = 237
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==113:
                    self.state = 230
                    self.match(McCompParser.Assign)
                    self.state = 235
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [144]:
                        self.state = 231
                        self.match(McCompParser.Identifier)
                        pass
                    elif token in [101]:
                        self.state = 232
                        self.initializerlist()
                        pass
                    elif token in [49]:
                        self.state = 233
                        self.match(McCompParser.Null)
                        pass
                    elif token in [1]:
                        self.state = 234
                        self.match(McCompParser.T__0)
                        pass
                    else:
                        raise NoViableAltException(self)



                pass

            elif la_ == 5:
                localctx = McCompParser.ComponentParameterSymbolContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 239
                self.match(McCompParser.Symbol)
                self.state = 240
                self.match(McCompParser.Identifier)

                self.state = 241
                self.match(McCompParser.Assign)
                self.state = 242
                self.expr(0)
                pass

            elif la_ == 6:
                localctx = McCompParser.ComponentParameterDoubleArrayContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 243
                self.match(McCompParser.Double)
                self.state = 244
                self.match(McCompParser.Star)
                self.state = 245
                self.match(McCompParser.Identifier)
                self.state = 253
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==113:
                    self.state = 246
                    self.match(McCompParser.Assign)
                    self.state = 251
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [144]:
                        self.state = 247
                        self.match(McCompParser.Identifier)
                        pass
                    elif token in [101]:
                        self.state = 248
                        self.initializerlist()
                        pass
                    elif token in [49]:
                        self.state = 249
                        self.match(McCompParser.Null)
                        pass
                    elif token in [1]:
                        self.state = 250
                        self.match(McCompParser.T__0)
                        pass
                    else:
                        raise NoViableAltException(self)



                pass

            elif la_ == 7:
                localctx = McCompParser.ComponentParameterIntegerArrayContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 255
                self.match(McCompParser.Int)
                self.state = 256
                self.match(McCompParser.Star)
                self.state = 257
                self.match(McCompParser.Identifier)
                self.state = 265
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==113:
                    self.state = 258
                    self.match(McCompParser.Assign)
                    self.state = 263
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [144]:
                        self.state = 259
                        self.match(McCompParser.Identifier)
                        pass
                    elif token in [101]:
                        self.state = 260
                        self.initializerlist()
                        pass
                    elif token in [49]:
                        self.state = 261
                        self.match(McCompParser.Null)
                        pass
                    elif token in [1]:
                        self.state = 262
                        self.match(McCompParser.T__0)
                        pass
                    else:
                        raise NoViableAltException(self)



                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShareContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Share(self):
            return self.getToken(McCompParser.Share, 0)

        def multi_block(self):
            return self.getTypedRuleContext(McCompParser.Multi_blockContext,0)


        def getRuleIndex(self):
            return McCompParser.RULE_share

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitShare" ):
                return visitor.visitShare(self)
            else:
                return visitor.visitChildren(self)




    def share(self):

        localctx = McCompParser.ShareContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_share)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 269
            self.match(McCompParser.Share)
            self.state = 270
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DisplayContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def McDisplay(self):
            return self.getToken(McCompParser.McDisplay, 0)

        def multi_block(self):
            return self.getTypedRuleContext(McCompParser.Multi_blockContext,0)


        def getRuleIndex(self):
            return McCompParser.RULE_display

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDisplay" ):
                return visitor.visitDisplay(self)
            else:
                return visitor.visitChildren(self)




    def display(self):

        localctx = McCompParser.DisplayContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_display)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 272
            self.match(McCompParser.McDisplay)
            self.state = 273
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Component_refContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Previous(self):
            return self.getToken(McCompParser.Previous, 0)

        def LeftParen(self):
            return self.getToken(McCompParser.LeftParen, 0)

        def IntegerLiteral(self):
            return self.getToken(McCompParser.IntegerLiteral, 0)

        def RightParen(self):
            return self.getToken(McCompParser.RightParen, 0)

        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)

        def getRuleIndex(self):
            return McCompParser.RULE_component_ref

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponent_ref" ):
                return visitor.visitComponent_ref(self)
            else:
                return visitor.visitChildren(self)




    def component_ref(self):

        localctx = McCompParser.Component_refContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_component_ref)
        self._la = 0 # Token type
        try:
            self.state = 282
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [22]:
                self.enterOuterAlt(localctx, 1)
                self.state = 275
                self.match(McCompParser.Previous)
                self.state = 279
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==97:
                    self.state = 276
                    self.match(McCompParser.LeftParen)
                    self.state = 277
                    self.match(McCompParser.IntegerLiteral)
                    self.state = 278
                    self.match(McCompParser.RightParen)


                pass
            elif token in [144]:
                self.enterOuterAlt(localctx, 2)
                self.state = 281
                self.match(McCompParser.Identifier)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CoordsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LeftParen(self):
            return self.getToken(McCompParser.LeftParen, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.Comma)
            else:
                return self.getToken(McCompParser.Comma, i)

        def RightParen(self):
            return self.getToken(McCompParser.RightParen, 0)

        def getRuleIndex(self):
            return McCompParser.RULE_coords

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCoords" ):
                return visitor.visitCoords(self)
            else:
                return visitor.visitChildren(self)




    def coords(self):

        localctx = McCompParser.CoordsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_coords)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 284
            self.match(McCompParser.LeftParen)
            self.state = 285
            self.expr(0)
            self.state = 286
            self.match(McCompParser.Comma)
            self.state = 287
            self.expr(0)
            self.state = 288
            self.match(McCompParser.Comma)
            self.state = 289
            self.expr(0)
            self.state = 290
            self.match(McCompParser.RightParen)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReferenceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Absolute(self):
            return self.getToken(McCompParser.Absolute, 0)

        def Relative(self):
            return self.getToken(McCompParser.Relative, 0)

        def component_ref(self):
            return self.getTypedRuleContext(McCompParser.Component_refContext,0)


        def getRuleIndex(self):
            return McCompParser.RULE_reference

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReference" ):
                return visitor.visitReference(self)
            else:
                return visitor.visitChildren(self)




    def reference(self):

        localctx = McCompParser.ReferenceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_reference)
        try:
            self.state = 298
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [4]:
                self.enterOuterAlt(localctx, 1)
                self.state = 292
                self.match(McCompParser.Absolute)
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 2)
                self.state = 293
                self.match(McCompParser.Relative)
                self.state = 296
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [4]:
                    self.state = 294
                    self.match(McCompParser.Absolute)
                    pass
                elif token in [22, 144]:
                    self.state = 295
                    self.component_ref()
                    pass
                else:
                    raise NoViableAltException(self)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DependencyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Dependency(self):
            return self.getToken(McCompParser.Dependency, 0)

        def StringLiteral(self):
            return self.getToken(McCompParser.StringLiteral, 0)

        def getRuleIndex(self):
            return McCompParser.RULE_dependency

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDependency" ):
                return visitor.visitDependency(self)
            else:
                return visitor.visitChildren(self)




    def dependency(self):

        localctx = McCompParser.DependencyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_dependency)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 300
            self.match(McCompParser.Dependency)
            self.state = 301
            self.match(McCompParser.StringLiteral)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclareContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Declare(self):
            return self.getToken(McCompParser.Declare, 0)

        def multi_block(self):
            return self.getTypedRuleContext(McCompParser.Multi_blockContext,0)


        def getRuleIndex(self):
            return McCompParser.RULE_declare

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeclare" ):
                return visitor.visitDeclare(self)
            else:
                return visitor.visitChildren(self)




    def declare(self):

        localctx = McCompParser.DeclareContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_declare)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 303
            self.match(McCompParser.Declare)
            self.state = 304
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UservarsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def UserVars(self):
            return self.getToken(McCompParser.UserVars, 0)

        def multi_block(self):
            return self.getTypedRuleContext(McCompParser.Multi_blockContext,0)


        def getRuleIndex(self):
            return McCompParser.RULE_uservars

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUservars" ):
                return visitor.visitUservars(self)
            else:
                return visitor.visitChildren(self)




    def uservars(self):

        localctx = McCompParser.UservarsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_uservars)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 306
            self.match(McCompParser.UserVars)
            self.state = 307
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InitialiseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Initialize(self):
            return self.getToken(McCompParser.Initialize, 0)

        def multi_block(self):
            return self.getTypedRuleContext(McCompParser.Multi_blockContext,0)


        def getRuleIndex(self):
            return McCompParser.RULE_initialise

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInitialise" ):
                return visitor.visitInitialise(self)
            else:
                return visitor.visitChildren(self)




    def initialise(self):

        localctx = McCompParser.InitialiseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_initialise)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 309
            self.match(McCompParser.Initialize)
            self.state = 310
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SaveContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Save(self):
            return self.getToken(McCompParser.Save, 0)

        def multi_block(self):
            return self.getTypedRuleContext(McCompParser.Multi_blockContext,0)


        def getRuleIndex(self):
            return McCompParser.RULE_save

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSave" ):
                return visitor.visitSave(self)
            else:
                return visitor.visitChildren(self)




    def save(self):

        localctx = McCompParser.SaveContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_save)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 312
            self.match(McCompParser.Save)
            self.state = 313
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Finally_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McCompParser.RULE_finally_

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class FinallyContext(Finally_Context):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.Finally_Context
            super().__init__(parser)
            self.copyFrom(ctx)

        def Finally(self):
            return self.getToken(McCompParser.Finally, 0)
        def multi_block(self):
            return self.getTypedRuleContext(McCompParser.Multi_blockContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFinally" ):
                return visitor.visitFinally(self)
            else:
                return visitor.visitChildren(self)



    def finally_(self):

        localctx = McCompParser.Finally_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_finally_)
        try:
            localctx = McCompParser.FinallyContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 315
            self.match(McCompParser.Finally)
            self.state = 316
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Multi_blockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unparsed_block(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.Unparsed_blockContext)
            else:
                return self.getTypedRuleContext(McCompParser.Unparsed_blockContext,i)


        def Inherit(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.Inherit)
            else:
                return self.getToken(McCompParser.Inherit, i)

        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.Identifier)
            else:
                return self.getToken(McCompParser.Identifier, i)

        def Extend(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.Extend)
            else:
                return self.getToken(McCompParser.Extend, i)

        def getRuleIndex(self):
            return McCompParser.RULE_multi_block

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMulti_block" ):
                return visitor.visitMulti_block(self)
            else:
                return visitor.visitChildren(self)




    def multi_block(self):

        localctx = McCompParser.Multi_blockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_multi_block)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 319
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==47:
                self.state = 318
                self.unparsed_block()


            self.state = 327
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==26 or _la==35:
                self.state = 325
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [35]:
                    self.state = 321
                    self.match(McCompParser.Inherit)
                    self.state = 322
                    self.match(McCompParser.Identifier)
                    pass
                elif token in [26]:
                    self.state = 323
                    self.match(McCompParser.Extend)
                    self.state = 324
                    self.unparsed_block()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 329
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MetadataContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.mime = None # Token
            self.name = None # Token

        def MetaData(self):
            return self.getToken(McCompParser.MetaData, 0)

        def unparsed_block(self):
            return self.getTypedRuleContext(McCompParser.Unparsed_blockContext,0)


        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.Identifier)
            else:
                return self.getToken(McCompParser.Identifier, i)

        def StringLiteral(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.StringLiteral)
            else:
                return self.getToken(McCompParser.StringLiteral, i)

        def getRuleIndex(self):
            return McCompParser.RULE_metadata

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetadata" ):
                return visitor.visitMetadata(self)
            else:
                return visitor.visitChildren(self)




    def metadata(self):

        localctx = McCompParser.MetadataContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_metadata)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 330
            self.match(McCompParser.MetaData)
            self.state = 331
            localctx.mime = self._input.LT(1)
            _la = self._input.LA(1)
            if not(_la==53 or _la==144):
                localctx.mime = self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 332
            localctx.name = self._input.LT(1)
            _la = self._input.LA(1)
            if not(_la==53 or _la==144):
                localctx.name = self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 333
            self.unparsed_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CategoryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Category(self):
            return self.getToken(McCompParser.Category, 0)

        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)

        def StringLiteral(self):
            return self.getToken(McCompParser.StringLiteral, 0)

        def getRuleIndex(self):
            return McCompParser.RULE_category

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCategory" ):
                return visitor.visitCategory(self)
            else:
                return visitor.visitChildren(self)




    def category(self):

        localctx = McCompParser.CategoryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_category)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 335
            self.match(McCompParser.Category)
            self.state = 336
            _la = self._input.LA(1)
            if not(_la==53 or _la==144):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InitializerlistContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._expr = None # ExprContext
            self.values = list() # of ExprContexts

        def LeftBrace(self):
            return self.getToken(McCompParser.LeftBrace, 0)

        def RightBrace(self):
            return self.getToken(McCompParser.RightBrace, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.Comma)
            else:
                return self.getToken(McCompParser.Comma, i)

        def getRuleIndex(self):
            return McCompParser.RULE_initializerlist

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInitializerlist" ):
                return visitor.visitInitializerlist(self)
            else:
                return visitor.visitChildren(self)




    def initializerlist(self):

        localctx = McCompParser.InitializerlistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_initializerlist)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 338
            self.match(McCompParser.LeftBrace)
            self.state = 339
            localctx._expr = self.expr(0)
            localctx.values.append(localctx._expr)
            self.state = 344
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==134:
                self.state = 340
                self.match(McCompParser.Comma)
                self.state = 341
                localctx._expr = self.expr(0)
                localctx.values.append(localctx._expr)
                self.state = 346
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 347
            self.match(McCompParser.RightBrace)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)

        def Assign(self):
            return self.getToken(McCompParser.Assign, 0)

        def expr(self):
            return self.getTypedRuleContext(McCompParser.ExprContext,0)


        def getRuleIndex(self):
            return McCompParser.RULE_assignment

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignment" ):
                return visitor.visitAssignment(self)
            else:
                return visitor.visitChildren(self)




    def assignment(self):

        localctx = McCompParser.AssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_assignment)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 349
            self.match(McCompParser.Identifier)
            self.state = 350
            self.match(McCompParser.Assign)
            self.state = 351
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McCompParser.RULE_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class ExpressionBinaryModContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def Mod(self):
            return self.getToken(McCompParser.Mod, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryMod" ):
                return visitor.visitExpressionBinaryMod(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryLessContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def Less(self):
            return self.getToken(McCompParser.Less, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryLess" ):
                return visitor.visitExpressionBinaryLess(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryGreaterContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def Greater(self):
            return self.getToken(McCompParser.Greater, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryGreater" ):
                return visitor.visitExpressionBinaryGreater(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryLessEqualContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def LessEqual(self):
            return self.getToken(McCompParser.LessEqual, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryLessEqual" ):
                return visitor.visitExpressionBinaryLessEqual(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionArrayAccessContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)
        def LeftBracket(self):
            return self.getToken(McCompParser.LeftBracket, 0)
        def expr(self):
            return self.getTypedRuleContext(McCompParser.ExprContext,0)

        def RightBracket(self):
            return self.getToken(McCompParser.RightBracket, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionArrayAccess" ):
                return visitor.visitExpressionArrayAccess(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryLogicContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)

        def AndAnd(self):
            return self.getToken(McCompParser.AndAnd, 0)
        def OrOr(self):
            return self.getToken(McCompParser.OrOr, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryLogic" ):
                return visitor.visitExpressionBinaryLogic(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionIntegerContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def IntegerLiteral(self):
            return self.getToken(McCompParser.IntegerLiteral, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionInteger" ):
                return visitor.visitExpressionInteger(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryRightShiftContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryRightShift" ):
                return visitor.visitExpressionBinaryRightShift(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionMyselfContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Myself(self):
            return self.getToken(McCompParser.Myself, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionMyself" ):
                return visitor.visitExpressionMyself(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionPreviousContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Previous(self):
            return self.getToken(McCompParser.Previous, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionPrevious" ):
                return visitor.visitExpressionPrevious(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionIdentifierContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionIdentifier" ):
                return visitor.visitExpressionIdentifier(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryNotEqualContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def NotEqual(self):
            return self.getToken(McCompParser.NotEqual, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryNotEqual" ):
                return visitor.visitExpressionBinaryNotEqual(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionStructAccessContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)
        def Dot(self):
            return self.getToken(McCompParser.Dot, 0)
        def expr(self):
            return self.getTypedRuleContext(McCompParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionStructAccess" ):
                return visitor.visitExpressionStructAccess(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionFunctionCallContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self._expr = None # ExprContext
            self.args = list() # of ExprContexts
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)
        def LeftParen(self):
            return self.getToken(McCompParser.LeftParen, 0)
        def RightParen(self):
            return self.getToken(McCompParser.RightParen, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)

        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.Comma)
            else:
                return self.getToken(McCompParser.Comma, i)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionFunctionCall" ):
                return visitor.visitExpressionFunctionCall(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryMDContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)

        def Star(self):
            return self.getToken(McCompParser.Star, 0)
        def Div(self):
            return self.getToken(McCompParser.Div, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryMD" ):
                return visitor.visitExpressionBinaryMD(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionStringContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self._StringLiteral = None # Token
            self.args = list() # of Tokens
            self.copyFrom(ctx)

        def StringLiteral(self, i:int=None):
            if i is None:
                return self.getTokens(McCompParser.StringLiteral)
            else:
                return self.getToken(McCompParser.StringLiteral, i)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionString" ):
                return visitor.visitExpressionString(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionGroupingContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LeftParen(self):
            return self.getToken(McCompParser.LeftParen, 0)
        def expr(self):
            return self.getTypedRuleContext(McCompParser.ExprContext,0)

        def RightParen(self):
            return self.getToken(McCompParser.RightParen, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionGrouping" ):
                return visitor.visitExpressionGrouping(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionExponentiationContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.base = None # ExprContext
            self.exponent = None # ExprContext
            self.copyFrom(ctx)

        def Caret(self):
            return self.getToken(McCompParser.Caret, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionExponentiation" ):
                return visitor.visitExpressionExponentiation(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryLeftShiftContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryLeftShift" ):
                return visitor.visitExpressionBinaryLeftShift(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryGreaterEqualContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def GreaterEqual(self):
            return self.getToken(McCompParser.GreaterEqual, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryGreaterEqual" ):
                return visitor.visitExpressionBinaryGreaterEqual(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionZeroContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionZero" ):
                return visitor.visitExpressionZero(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionUnaryPMContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(McCompParser.ExprContext,0)

        def Plus(self):
            return self.getToken(McCompParser.Plus, 0)
        def Minus(self):
            return self.getToken(McCompParser.Minus, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionUnaryPM" ):
                return visitor.visitExpressionUnaryPM(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionTrinaryLogicContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.test = None # ExprContext
            self.true_ = None # ExprContext
            self.false_ = None # ExprContext
            self.copyFrom(ctx)

        def Question(self):
            return self.getToken(McCompParser.Question, 0)
        def Colon(self):
            return self.getToken(McCompParser.Colon, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionTrinaryLogic" ):
                return visitor.visitExpressionTrinaryLogic(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionFloatContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def FloatingLiteral(self):
            return self.getToken(McCompParser.FloatingLiteral, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionFloat" ):
                return visitor.visitExpressionFloat(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionPointerAccessContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McCompParser.Identifier, 0)
        def Arrow(self):
            return self.getToken(McCompParser.Arrow, 0)
        def expr(self):
            return self.getTypedRuleContext(McCompParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionPointerAccess" ):
                return visitor.visitExpressionPointerAccess(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryEqualContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def Equal(self):
            return self.getToken(McCompParser.Equal, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryEqual" ):
                return visitor.visitExpressionBinaryEqual(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryPMContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McCompParser.ExprContext)
            else:
                return self.getTypedRuleContext(McCompParser.ExprContext,i)

        def Plus(self):
            return self.getToken(McCompParser.Plus, 0)
        def Minus(self):
            return self.getToken(McCompParser.Minus, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryPM" ):
                return visitor.visitExpressionBinaryPM(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionUnaryLogicContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Not(self):
            return self.getToken(McCompParser.Not, 0)
        def expr(self):
            return self.getTypedRuleContext(McCompParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionUnaryLogic" ):
                return visitor.visitExpressionUnaryLogic(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = McCompParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 50
        self.enterRecursionRule(localctx, 50, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 397
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,56,self._ctx)
            if la_ == 1:
                localctx = McCompParser.ExpressionZeroContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 354
                self.match(McCompParser.T__0)
                pass

            elif la_ == 2:
                localctx = McCompParser.ExpressionIntegerContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 355
                self.match(McCompParser.IntegerLiteral)
                pass

            elif la_ == 3:
                localctx = McCompParser.ExpressionFloatContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 356
                self.match(McCompParser.FloatingLiteral)
                pass

            elif la_ == 4:
                localctx = McCompParser.ExpressionStringContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 360
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,54,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 357
                        localctx._StringLiteral = self.match(McCompParser.StringLiteral)
                        localctx.args.append(localctx._StringLiteral) 
                    self.state = 362
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,54,self._ctx)

                pass

            elif la_ == 5:
                localctx = McCompParser.ExpressionPointerAccessContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 363
                self.match(McCompParser.Identifier)
                self.state = 364
                self.match(McCompParser.Arrow)
                self.state = 365
                self.expr(24)
                pass

            elif la_ == 6:
                localctx = McCompParser.ExpressionStructAccessContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 366
                self.match(McCompParser.Identifier)
                self.state = 367
                self.match(McCompParser.Dot)
                self.state = 368
                self.expr(23)
                pass

            elif la_ == 7:
                localctx = McCompParser.ExpressionArrayAccessContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 369
                self.match(McCompParser.Identifier)
                self.state = 370
                self.match(McCompParser.LeftBracket)
                self.state = 371
                self.expr(0)
                self.state = 372
                self.match(McCompParser.RightBracket)
                pass

            elif la_ == 8:
                localctx = McCompParser.ExpressionFunctionCallContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 374
                self.match(McCompParser.Identifier)
                self.state = 375
                self.match(McCompParser.LeftParen)
                self.state = 376
                localctx._expr = self.expr(0)
                localctx.args.append(localctx._expr)
                self.state = 381
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==134:
                    self.state = 377
                    self.match(McCompParser.Comma)
                    self.state = 378
                    localctx._expr = self.expr(0)
                    localctx.args.append(localctx._expr)
                    self.state = 383
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 384
                self.match(McCompParser.RightParen)
                pass

            elif la_ == 9:
                localctx = McCompParser.ExpressionGroupingContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 386
                self.match(McCompParser.LeftParen)
                self.state = 387
                self.expr(0)
                self.state = 388
                self.match(McCompParser.RightParen)
                pass

            elif la_ == 10:
                localctx = McCompParser.ExpressionUnaryPMContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 390
                _la = self._input.LA(1)
                if not(_la==103 or _la==104):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 391
                self.expr(19)
                pass

            elif la_ == 11:
                localctx = McCompParser.ExpressionIdentifierContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 392
                self.match(McCompParser.Identifier)
                pass

            elif la_ == 12:
                localctx = McCompParser.ExpressionUnaryLogicContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 393
                self.match(McCompParser.Not)
                self.state = 394
                self.expr(5)
                pass

            elif la_ == 13:
                localctx = McCompParser.ExpressionPreviousContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 395
                self.match(McCompParser.Previous)
                pass

            elif la_ == 14:
                localctx = McCompParser.ExpressionMyselfContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 396
                self.match(McCompParser.Myself)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 446
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,58,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 444
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,57,self._ctx)
                    if la_ == 1:
                        localctx = McCompParser.ExpressionExponentiationContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.base = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 399
                        if not self.precpred(self._ctx, 18):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 18)")
                        self.state = 400
                        self.match(McCompParser.Caret)
                        self.state = 401
                        localctx.exponent = self.expr(18)
                        pass

                    elif la_ == 2:
                        localctx = McCompParser.ExpressionBinaryMDContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 402
                        if not self.precpred(self._ctx, 17):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 17)")
                        self.state = 403
                        _la = self._input.LA(1)
                        if not(_la==105 or _la==106):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 404
                        localctx.right = self.expr(18)
                        pass

                    elif la_ == 3:
                        localctx = McCompParser.ExpressionBinaryPMContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 405
                        if not self.precpred(self._ctx, 16):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 16)")
                        self.state = 406
                        _la = self._input.LA(1)
                        if not(_la==103 or _la==104):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 407
                        localctx.right = self.expr(17)
                        pass

                    elif la_ == 4:
                        localctx = McCompParser.ExpressionBinaryModContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 408
                        if not self.precpred(self._ctx, 15):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 15)")
                        self.state = 409
                        self.match(McCompParser.Mod)
                        self.state = 410
                        localctx.right = self.expr(16)
                        pass

                    elif la_ == 5:
                        localctx = McCompParser.ExpressionBinaryRightShiftContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 411
                        if not self.precpred(self._ctx, 14):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 14)")
                        self.state = 412
                        self.match(McCompParser.T__1)
                        self.state = 413
                        localctx.right = self.expr(15)
                        pass

                    elif la_ == 6:
                        localctx = McCompParser.ExpressionBinaryLeftShiftContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 414
                        if not self.precpred(self._ctx, 13):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 13)")
                        self.state = 415
                        self.match(McCompParser.T__2)
                        self.state = 416
                        localctx.right = self.expr(14)
                        pass

                    elif la_ == 7:
                        localctx = McCompParser.ExpressionBinaryNotEqualContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 417
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 418
                        self.match(McCompParser.NotEqual)
                        self.state = 419
                        localctx.right = self.expr(12)
                        pass

                    elif la_ == 8:
                        localctx = McCompParser.ExpressionBinaryEqualContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 420
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 421
                        self.match(McCompParser.Equal)
                        self.state = 422
                        localctx.right = self.expr(11)
                        pass

                    elif la_ == 9:
                        localctx = McCompParser.ExpressionBinaryLessEqualContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 423
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 424
                        self.match(McCompParser.LessEqual)
                        self.state = 425
                        localctx.right = self.expr(10)
                        pass

                    elif la_ == 10:
                        localctx = McCompParser.ExpressionBinaryGreaterEqualContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 426
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 427
                        self.match(McCompParser.GreaterEqual)
                        self.state = 428
                        localctx.right = self.expr(9)
                        pass

                    elif la_ == 11:
                        localctx = McCompParser.ExpressionBinaryLessContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 429
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 430
                        self.match(McCompParser.Less)
                        self.state = 431
                        localctx.right = self.expr(8)
                        pass

                    elif la_ == 12:
                        localctx = McCompParser.ExpressionBinaryGreaterContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 432
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 433
                        self.match(McCompParser.Greater)
                        self.state = 434
                        localctx.right = self.expr(7)
                        pass

                    elif la_ == 13:
                        localctx = McCompParser.ExpressionBinaryLogicContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 435
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 436
                        _la = self._input.LA(1)
                        if not(_la==130 or _la==131):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 437
                        localctx.right = self.expr(5)
                        pass

                    elif la_ == 14:
                        localctx = McCompParser.ExpressionTrinaryLogicContext(self, McCompParser.ExprContext(self, _parentctx, _parentState))
                        localctx.test = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 438
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 439
                        self.match(McCompParser.Question)
                        self.state = 440
                        localctx.true_ = self.expr(0)
                        self.state = 441
                        self.match(McCompParser.Colon)
                        self.state = 442
                        localctx.false_ = self.expr(4)
                        pass

             
                self.state = 448
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,58,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class ShellContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Shell(self):
            return self.getToken(McCompParser.Shell, 0)

        def StringLiteral(self):
            return self.getToken(McCompParser.StringLiteral, 0)

        def getRuleIndex(self):
            return McCompParser.RULE_shell

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitShell" ):
                return visitor.visitShell(self)
            else:
                return visitor.visitChildren(self)




    def shell(self):

        localctx = McCompParser.ShellContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_shell)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 449
            self.match(McCompParser.Shell)
            self.state = 450
            self.match(McCompParser.StringLiteral)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SearchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McCompParser.RULE_search

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class SearchPathContext(SearchContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.SearchContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Search(self):
            return self.getToken(McCompParser.Search, 0)
        def StringLiteral(self):
            return self.getToken(McCompParser.StringLiteral, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSearchPath" ):
                return visitor.visitSearchPath(self)
            else:
                return visitor.visitChildren(self)


    class SearchShellContext(SearchContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McCompParser.SearchContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Search(self):
            return self.getToken(McCompParser.Search, 0)
        def Shell(self):
            return self.getToken(McCompParser.Shell, 0)
        def StringLiteral(self):
            return self.getToken(McCompParser.StringLiteral, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSearchShell" ):
                return visitor.visitSearchShell(self)
            else:
                return visitor.visitChildren(self)



    def search(self):

        localctx = McCompParser.SearchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_search)
        try:
            self.state = 457
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,59,self._ctx)
            if la_ == 1:
                localctx = McCompParser.SearchPathContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 452
                self.match(McCompParser.Search)
                self.state = 453
                self.match(McCompParser.StringLiteral)
                pass

            elif la_ == 2:
                localctx = McCompParser.SearchShellContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 454
                self.match(McCompParser.Search)
                self.state = 455
                self.match(McCompParser.Shell)
                self.state = 456
                self.match(McCompParser.StringLiteral)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Unparsed_blockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def UnparsedBlock(self):
            return self.getToken(McCompParser.UnparsedBlock, 0)

        def getRuleIndex(self):
            return McCompParser.RULE_unparsed_block

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnparsed_block" ):
                return visitor.visitUnparsed_block(self)
            else:
                return visitor.visitChildren(self)




    def unparsed_block(self):

        localctx = McCompParser.Unparsed_blockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_unparsed_block)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 459
            self.match(McCompParser.UnparsedBlock)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[25] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 18)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 17)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 16)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 15)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 14)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 13)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 11)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 10)
         

            if predIndex == 8:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 9:
                return self.precpred(self._ctx, 8)
         

            if predIndex == 10:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 11:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 12:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 13:
                return self.precpred(self._ctx, 3)
         




