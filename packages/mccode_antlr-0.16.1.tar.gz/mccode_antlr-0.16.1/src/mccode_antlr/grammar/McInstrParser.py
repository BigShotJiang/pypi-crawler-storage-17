# Generated from McInstr.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,157,499,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,
        7,6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,
        13,2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,
        20,7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,
        26,2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,
        33,7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,
        39,1,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,3,1,89,8,1,1,1,3,1,92,8,1,1,1,
        3,1,95,8,1,1,1,3,1,98,8,1,1,1,3,1,101,8,1,1,1,3,1,104,8,1,1,1,3,
        1,107,8,1,1,1,1,1,3,1,111,8,1,1,1,3,1,114,8,1,1,1,1,1,1,2,1,2,1,
        2,1,2,5,2,122,8,2,10,2,12,2,125,9,2,3,2,127,8,2,1,2,1,2,1,3,3,3,
        132,8,3,1,3,1,3,3,3,136,8,3,1,3,1,3,3,3,140,8,3,1,3,1,3,1,3,3,3,
        145,8,3,1,3,1,3,3,3,149,8,3,1,3,1,3,1,3,3,3,154,8,3,1,3,1,3,3,3,
        158,8,3,1,3,1,3,3,3,162,8,3,3,3,164,8,3,1,4,1,4,1,4,1,5,1,5,1,5,
        1,5,4,5,173,8,5,11,5,12,5,174,3,5,177,8,5,1,6,4,6,180,8,6,11,6,12,
        6,181,1,7,1,7,1,7,1,8,3,8,188,8,8,1,8,3,8,191,8,8,1,8,3,8,194,8,
        8,1,8,1,8,1,8,1,8,1,8,3,8,201,8,8,1,8,3,8,204,8,8,1,8,1,8,3,8,208,
        8,8,1,8,3,8,211,8,8,1,8,3,8,214,8,8,1,8,3,8,217,8,8,1,8,5,8,220,
        8,8,10,8,12,8,223,9,8,1,9,1,9,1,9,1,9,1,9,1,9,3,9,231,8,9,1,10,1,
        10,1,10,1,10,1,10,1,10,3,10,239,8,10,1,11,1,11,1,11,1,11,5,11,245,
        8,11,10,11,12,11,248,9,11,3,11,250,8,11,1,11,1,11,1,12,1,12,1,12,
        1,12,1,12,1,12,1,12,1,12,1,12,3,12,263,8,12,1,13,1,13,1,13,3,13,
        268,8,13,1,14,1,14,1,14,1,15,1,15,1,15,1,15,1,16,1,16,1,16,1,16,
        1,17,1,17,1,17,1,18,4,18,285,8,18,11,18,12,18,286,1,19,1,19,1,19,
        1,19,1,19,1,20,1,20,1,20,1,20,3,20,298,8,20,1,20,1,20,1,20,1,20,
        1,20,3,20,305,8,20,1,20,3,20,308,8,20,1,21,1,21,1,21,1,22,1,22,1,
        22,1,22,3,22,317,8,22,1,22,3,22,320,8,22,1,23,1,23,1,23,1,23,1,23,
        1,23,1,23,1,23,1,24,1,24,1,24,1,24,3,24,334,8,24,3,24,336,8,24,1,
        25,1,25,1,25,1,26,1,26,1,26,1,27,1,27,1,27,1,28,1,28,1,28,1,29,1,
        29,1,29,1,30,1,30,1,30,1,31,3,31,357,8,31,1,31,1,31,1,31,1,31,5,
        31,363,8,31,10,31,12,31,366,9,31,1,32,1,32,1,32,1,32,1,32,1,33,1,
        33,1,33,1,34,1,34,1,34,1,34,5,34,380,8,34,10,34,12,34,383,9,34,1,
        34,1,34,1,35,1,35,1,35,1,35,1,36,1,36,1,36,1,36,1,36,5,36,396,8,
        36,10,36,12,36,399,9,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,
        1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,5,36,417,8,36,10,36,12,36,
        420,9,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,
        1,36,1,36,3,36,435,8,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,
        1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,
        1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,
        1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,5,36,482,
        8,36,10,36,12,36,485,9,36,1,37,1,37,1,37,1,38,1,38,1,38,1,38,1,38,
        3,38,495,8,38,1,39,1,39,1,39,0,1,72,40,0,2,4,6,8,10,12,14,16,18,
        20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,
        64,66,68,70,72,74,76,78,0,7,3,0,1,1,49,49,53,53,1,0,33,34,2,0,30,
        30,32,32,2,0,53,53,144,144,1,0,103,104,1,0,105,106,1,0,130,131,546,
        0,80,1,0,0,0,2,83,1,0,0,0,4,117,1,0,0,0,6,163,1,0,0,0,8,165,1,0,
        0,0,10,168,1,0,0,0,12,179,1,0,0,0,14,183,1,0,0,0,16,187,1,0,0,0,
        18,230,1,0,0,0,20,238,1,0,0,0,22,240,1,0,0,0,24,262,1,0,0,0,26,264,
        1,0,0,0,28,269,1,0,0,0,30,272,1,0,0,0,32,276,1,0,0,0,34,280,1,0,
        0,0,36,284,1,0,0,0,38,288,1,0,0,0,40,307,1,0,0,0,42,309,1,0,0,0,
        44,319,1,0,0,0,46,321,1,0,0,0,48,335,1,0,0,0,50,337,1,0,0,0,52,340,
        1,0,0,0,54,343,1,0,0,0,56,346,1,0,0,0,58,349,1,0,0,0,60,352,1,0,
        0,0,62,356,1,0,0,0,64,367,1,0,0,0,66,372,1,0,0,0,68,375,1,0,0,0,
        70,386,1,0,0,0,72,434,1,0,0,0,74,486,1,0,0,0,76,494,1,0,0,0,78,496,
        1,0,0,0,80,81,3,2,1,0,81,82,5,0,0,1,82,1,1,0,0,0,83,84,5,9,0,0,84,
        85,5,16,0,0,85,86,5,144,0,0,86,88,3,4,2,0,87,89,3,74,37,0,88,87,
        1,0,0,0,88,89,1,0,0,0,89,91,1,0,0,0,90,92,3,76,38,0,91,90,1,0,0,
        0,91,92,1,0,0,0,92,94,1,0,0,0,93,95,3,12,6,0,94,93,1,0,0,0,94,95,
        1,0,0,0,95,97,1,0,0,0,96,98,3,50,25,0,97,96,1,0,0,0,97,98,1,0,0,
        0,98,100,1,0,0,0,99,101,3,52,26,0,100,99,1,0,0,0,100,101,1,0,0,0,
        101,103,1,0,0,0,102,104,3,54,27,0,103,102,1,0,0,0,103,104,1,0,0,
        0,104,106,1,0,0,0,105,107,3,56,28,0,106,105,1,0,0,0,106,107,1,0,
        0,0,107,108,1,0,0,0,108,110,3,10,5,0,109,111,3,58,29,0,110,109,1,
        0,0,0,110,111,1,0,0,0,111,113,1,0,0,0,112,114,3,60,30,0,113,112,
        1,0,0,0,113,114,1,0,0,0,114,115,1,0,0,0,115,116,5,12,0,0,116,3,1,
        0,0,0,117,126,5,97,0,0,118,123,3,6,3,0,119,120,5,134,0,0,120,122,
        3,6,3,0,121,119,1,0,0,0,122,125,1,0,0,0,123,121,1,0,0,0,123,124,
        1,0,0,0,124,127,1,0,0,0,125,123,1,0,0,0,126,118,1,0,0,0,126,127,
        1,0,0,0,127,128,1,0,0,0,128,129,5,98,0,0,129,5,1,0,0,0,130,132,5,
        69,0,0,131,130,1,0,0,0,131,132,1,0,0,0,132,133,1,0,0,0,133,135,5,
        144,0,0,134,136,3,8,4,0,135,134,1,0,0,0,135,136,1,0,0,0,136,139,
        1,0,0,0,137,138,5,113,0,0,138,140,3,72,36,0,139,137,1,0,0,0,139,
        140,1,0,0,0,140,164,1,0,0,0,141,142,5,80,0,0,142,144,5,144,0,0,143,
        145,3,8,4,0,144,143,1,0,0,0,144,145,1,0,0,0,145,148,1,0,0,0,146,
        147,5,113,0,0,147,149,3,72,36,0,148,146,1,0,0,0,148,149,1,0,0,0,
        149,164,1,0,0,0,150,154,5,44,0,0,151,152,5,63,0,0,152,154,5,105,
        0,0,153,150,1,0,0,0,153,151,1,0,0,0,154,155,1,0,0,0,155,157,5,144,
        0,0,156,158,3,8,4,0,157,156,1,0,0,0,157,158,1,0,0,0,158,161,1,0,
        0,0,159,160,5,113,0,0,160,162,7,0,0,0,161,159,1,0,0,0,161,162,1,
        0,0,0,162,164,1,0,0,0,163,131,1,0,0,0,163,141,1,0,0,0,163,153,1,
        0,0,0,164,7,1,0,0,0,165,166,5,106,0,0,166,167,5,53,0,0,167,9,1,0,
        0,0,168,176,5,24,0,0,169,173,3,16,8,0,170,173,3,76,38,0,171,173,
        3,14,7,0,172,169,1,0,0,0,172,170,1,0,0,0,172,171,1,0,0,0,173,174,
        1,0,0,0,174,172,1,0,0,0,174,175,1,0,0,0,175,177,1,0,0,0,176,172,
        1,0,0,0,176,177,1,0,0,0,177,11,1,0,0,0,178,180,3,64,32,0,179,178,
        1,0,0,0,180,181,1,0,0,0,181,179,1,0,0,0,181,182,1,0,0,0,182,13,1,
        0,0,0,183,184,5,48,0,0,184,185,5,53,0,0,185,15,1,0,0,0,186,188,5,
        37,0,0,187,186,1,0,0,0,187,188,1,0,0,0,188,190,1,0,0,0,189,191,5,
        38,0,0,190,189,1,0,0,0,190,191,1,0,0,0,191,193,1,0,0,0,192,194,3,
        26,13,0,193,192,1,0,0,0,193,194,1,0,0,0,194,195,1,0,0,0,195,196,
        5,7,0,0,196,197,3,18,9,0,197,198,5,113,0,0,198,200,3,20,10,0,199,
        201,3,22,11,0,200,199,1,0,0,0,200,201,1,0,0,0,201,203,1,0,0,0,202,
        204,3,28,14,0,203,202,1,0,0,0,203,204,1,0,0,0,204,205,1,0,0,0,205,
        207,3,30,15,0,206,208,3,32,16,0,207,206,1,0,0,0,207,208,1,0,0,0,
        208,210,1,0,0,0,209,211,3,34,17,0,210,209,1,0,0,0,210,211,1,0,0,
        0,211,213,1,0,0,0,212,214,3,42,21,0,213,212,1,0,0,0,213,214,1,0,
        0,0,214,216,1,0,0,0,215,217,3,36,18,0,216,215,1,0,0,0,216,217,1,
        0,0,0,217,221,1,0,0,0,218,220,3,64,32,0,219,218,1,0,0,0,220,223,
        1,0,0,0,221,219,1,0,0,0,221,222,1,0,0,0,222,17,1,0,0,0,223,221,1,
        0,0,0,224,225,5,34,0,0,225,226,5,97,0,0,226,227,5,144,0,0,227,231,
        5,98,0,0,228,231,7,1,0,0,229,231,5,144,0,0,230,224,1,0,0,0,230,228,
        1,0,0,0,230,229,1,0,0,0,231,19,1,0,0,0,232,233,5,34,0,0,233,234,
        5,97,0,0,234,235,3,44,22,0,235,236,5,98,0,0,236,239,1,0,0,0,237,
        239,5,144,0,0,238,232,1,0,0,0,238,237,1,0,0,0,239,21,1,0,0,0,240,
        249,5,97,0,0,241,246,3,24,12,0,242,243,5,134,0,0,243,245,3,24,12,
        0,244,242,1,0,0,0,245,248,1,0,0,0,246,244,1,0,0,0,246,247,1,0,0,
        0,247,250,1,0,0,0,248,246,1,0,0,0,249,241,1,0,0,0,249,250,1,0,0,
        0,250,251,1,0,0,0,251,252,5,98,0,0,252,23,1,0,0,0,253,254,5,144,
        0,0,254,255,5,113,0,0,255,263,3,72,36,0,256,257,5,144,0,0,257,258,
        5,113,0,0,258,263,5,49,0,0,259,260,5,144,0,0,260,261,5,113,0,0,261,
        263,3,68,34,0,262,253,1,0,0,0,262,256,1,0,0,0,262,259,1,0,0,0,263,
        25,1,0,0,0,264,267,5,36,0,0,265,268,1,0,0,0,266,268,3,72,36,0,267,
        265,1,0,0,0,267,266,1,0,0,0,268,27,1,0,0,0,269,270,5,30,0,0,270,
        271,3,72,36,0,271,29,1,0,0,0,272,273,5,5,0,0,273,274,3,46,23,0,274,
        275,3,48,24,0,275,31,1,0,0,0,276,277,5,21,0,0,277,278,3,46,23,0,
        278,279,3,48,24,0,279,33,1,0,0,0,280,281,5,27,0,0,281,282,5,144,
        0,0,282,35,1,0,0,0,283,285,3,38,19,0,284,283,1,0,0,0,285,286,1,0,
        0,0,286,284,1,0,0,0,286,287,1,0,0,0,287,37,1,0,0,0,288,289,5,29,
        0,0,289,290,3,40,20,0,290,291,7,2,0,0,291,292,3,72,36,0,292,39,1,
        0,0,0,293,297,5,22,0,0,294,295,5,97,0,0,295,296,5,50,0,0,296,298,
        5,98,0,0,297,294,1,0,0,0,297,298,1,0,0,0,298,308,1,0,0,0,299,308,
        5,33,0,0,300,304,5,31,0,0,301,302,5,97,0,0,302,303,5,50,0,0,303,
        305,5,98,0,0,304,301,1,0,0,0,304,305,1,0,0,0,305,308,1,0,0,0,306,
        308,5,144,0,0,307,293,1,0,0,0,307,299,1,0,0,0,307,300,1,0,0,0,307,
        306,1,0,0,0,308,41,1,0,0,0,309,310,5,26,0,0,310,311,3,78,39,0,311,
        43,1,0,0,0,312,316,5,22,0,0,313,314,5,97,0,0,314,315,5,50,0,0,315,
        317,5,98,0,0,316,313,1,0,0,0,316,317,1,0,0,0,317,320,1,0,0,0,318,
        320,5,144,0,0,319,312,1,0,0,0,319,318,1,0,0,0,320,45,1,0,0,0,321,
        322,5,97,0,0,322,323,3,72,36,0,323,324,5,134,0,0,324,325,3,72,36,
        0,325,326,5,134,0,0,326,327,3,72,36,0,327,328,5,98,0,0,328,47,1,
        0,0,0,329,336,5,4,0,0,330,333,5,20,0,0,331,334,5,4,0,0,332,334,3,
        44,22,0,333,331,1,0,0,0,333,332,1,0,0,0,334,336,1,0,0,0,335,329,
        1,0,0,0,335,330,1,0,0,0,336,49,1,0,0,0,337,338,5,40,0,0,338,339,
        5,53,0,0,339,51,1,0,0,0,340,341,5,10,0,0,341,342,3,62,31,0,342,53,
        1,0,0,0,343,344,5,8,0,0,344,345,3,62,31,0,345,55,1,0,0,0,346,347,
        5,15,0,0,347,348,3,62,31,0,348,57,1,0,0,0,349,350,5,28,0,0,350,351,
        3,62,31,0,351,59,1,0,0,0,352,353,5,14,0,0,353,354,3,62,31,0,354,
        61,1,0,0,0,355,357,3,78,39,0,356,355,1,0,0,0,356,357,1,0,0,0,357,
        364,1,0,0,0,358,359,5,35,0,0,359,363,5,144,0,0,360,361,5,26,0,0,
        361,363,3,78,39,0,362,358,1,0,0,0,362,360,1,0,0,0,363,366,1,0,0,
        0,364,362,1,0,0,0,364,365,1,0,0,0,365,63,1,0,0,0,366,364,1,0,0,0,
        367,368,5,43,0,0,368,369,7,3,0,0,369,370,7,3,0,0,370,371,3,78,39,
        0,371,65,1,0,0,0,372,373,5,6,0,0,373,374,7,3,0,0,374,67,1,0,0,0,
        375,376,5,101,0,0,376,381,3,72,36,0,377,378,5,134,0,0,378,380,3,
        72,36,0,379,377,1,0,0,0,380,383,1,0,0,0,381,379,1,0,0,0,381,382,
        1,0,0,0,382,384,1,0,0,0,383,381,1,0,0,0,384,385,5,102,0,0,385,69,
        1,0,0,0,386,387,5,144,0,0,387,388,5,113,0,0,388,389,3,72,36,0,389,
        71,1,0,0,0,390,391,6,36,-1,0,391,435,5,1,0,0,392,435,5,50,0,0,393,
        435,5,52,0,0,394,396,5,53,0,0,395,394,1,0,0,0,396,399,1,0,0,0,397,
        395,1,0,0,0,397,398,1,0,0,0,398,435,1,0,0,0,399,397,1,0,0,0,400,
        401,5,144,0,0,401,402,5,136,0,0,402,435,3,72,36,24,403,404,5,144,
        0,0,404,405,5,141,0,0,405,435,3,72,36,23,406,407,5,144,0,0,407,408,
        5,99,0,0,408,409,3,72,36,0,409,410,5,100,0,0,410,435,1,0,0,0,411,
        412,5,144,0,0,412,413,5,97,0,0,413,418,3,72,36,0,414,415,5,134,0,
        0,415,417,3,72,36,0,416,414,1,0,0,0,417,420,1,0,0,0,418,416,1,0,
        0,0,418,419,1,0,0,0,419,421,1,0,0,0,420,418,1,0,0,0,421,422,5,98,
        0,0,422,435,1,0,0,0,423,424,5,97,0,0,424,425,3,72,36,0,425,426,5,
        98,0,0,426,435,1,0,0,0,427,428,7,4,0,0,428,435,3,72,36,19,429,435,
        5,144,0,0,430,431,5,112,0,0,431,435,3,72,36,5,432,435,5,22,0,0,433,
        435,5,33,0,0,434,390,1,0,0,0,434,392,1,0,0,0,434,393,1,0,0,0,434,
        397,1,0,0,0,434,400,1,0,0,0,434,403,1,0,0,0,434,406,1,0,0,0,434,
        411,1,0,0,0,434,423,1,0,0,0,434,427,1,0,0,0,434,429,1,0,0,0,434,
        430,1,0,0,0,434,432,1,0,0,0,434,433,1,0,0,0,435,483,1,0,0,0,436,
        437,10,18,0,0,437,438,5,108,0,0,438,482,3,72,36,18,439,440,10,17,
        0,0,440,441,7,5,0,0,441,482,3,72,36,18,442,443,10,16,0,0,443,444,
        7,4,0,0,444,482,3,72,36,17,445,446,10,15,0,0,446,447,5,107,0,0,447,
        482,3,72,36,16,448,449,10,14,0,0,449,450,5,2,0,0,450,482,3,72,36,
        15,451,452,10,13,0,0,452,453,5,3,0,0,453,482,3,72,36,14,454,455,
        10,11,0,0,455,456,5,127,0,0,456,482,3,72,36,12,457,458,10,10,0,0,
        458,459,5,126,0,0,459,482,3,72,36,11,460,461,10,9,0,0,461,462,5,
        128,0,0,462,482,3,72,36,10,463,464,10,8,0,0,464,465,5,129,0,0,465,
        482,3,72,36,9,466,467,10,7,0,0,467,468,5,114,0,0,468,482,3,72,36,
        8,469,470,10,6,0,0,470,471,5,115,0,0,471,482,3,72,36,7,472,473,10,
        4,0,0,473,474,7,6,0,0,474,482,3,72,36,5,475,476,10,3,0,0,476,477,
        5,137,0,0,477,478,3,72,36,0,478,479,5,138,0,0,479,480,3,72,36,4,
        480,482,1,0,0,0,481,436,1,0,0,0,481,439,1,0,0,0,481,442,1,0,0,0,
        481,445,1,0,0,0,481,448,1,0,0,0,481,451,1,0,0,0,481,454,1,0,0,0,
        481,457,1,0,0,0,481,460,1,0,0,0,481,463,1,0,0,0,481,466,1,0,0,0,
        481,469,1,0,0,0,481,472,1,0,0,0,481,475,1,0,0,0,482,485,1,0,0,0,
        483,481,1,0,0,0,483,484,1,0,0,0,484,73,1,0,0,0,485,483,1,0,0,0,486,
        487,5,41,0,0,487,488,5,53,0,0,488,75,1,0,0,0,489,490,5,42,0,0,490,
        495,5,53,0,0,491,492,5,42,0,0,492,493,5,41,0,0,493,495,5,53,0,0,
        494,489,1,0,0,0,494,491,1,0,0,0,495,77,1,0,0,0,496,497,5,47,0,0,
        497,79,1,0,0,0,58,88,91,94,97,100,103,106,110,113,123,126,131,135,
        139,144,148,153,157,161,163,172,174,176,181,187,190,193,200,203,
        207,210,213,216,221,230,238,246,249,262,267,286,297,304,307,316,
        319,333,335,356,362,364,381,397,418,434,481,483,494
    ]

class McInstrParser ( Parser ):

    grammarFileName = "McInstr.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'0'", "'>>'", "'<<'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'string'", "'vector'", "'symbol'", 
                     "<INVALID>", "'%include'", "'NULL'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'asm'", "'auto'", "'_Bool'", 
                     "'break'", "'case'", "'char'", "'_Complex'", "'const'", 
                     "'continue'", "'default'", "'do'", "'double'", "'else'", 
                     "'enum'", "'extern'", "'false'", "'float'", "'for'", 
                     "'goto'", "'if'", "'_Imaginary'", "'inline'", "'int'", 
                     "'long'", "'register'", "'return'", "'short'", "'signed'", 
                     "'sizeof'", "'static'", "'struct'", "'switch'", "'true'", 
                     "'typedef'", "'union'", "'unsigned'", "'void'", "'volatile'", 
                     "'while'", "'('", "')'", "'['", "']'", "'{'", "'}'", 
                     "'+'", "'-'", "'*'", "'/'", "'%'", "'^'", "'&'", "'|'", 
                     "'~'", "<INVALID>", "'='", "'<'", "'>'", "'+='", "'-='", 
                     "'*='", "'/='", "'%='", "'^='", "'&='", "'|='", "'<<='", 
                     "'>>='", "'=='", "'!='", "'<='", "'>='", "<INVALID>", 
                     "<INVALID>", "'++'", "'--'", "','", "'->*'", "'->'", 
                     "'?'", "':'", "'::'", "';'", "'.'", "'.*'", "'...'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "Absolute", "At", "Category", "Component", "UserVars", 
                      "Define", "Declare", "Definition", "End", "McDisplay", 
                      "Finally", "Initialize", "Instrument", "Output", "Private", 
                      "Parameters", "Relative", "Rotated", "Previous", "Setting", 
                      "Trace", "Share", "Extend", "Group", "Save", "Jump", 
                      "When", "Next", "Iterate", "Myself", "Copy", "Inherit", 
                      "Split", "Removable", "Cpu", "NoAcc", "Dependency", 
                      "Shell", "Search", "MetaData", "String", "Vector", 
                      "Symbol", "UnparsedBlock", "Include", "Null", "IntegerLiteral", 
                      "CharacterLiteral", "FloatingLiteral", "StringLiteral", 
                      "BooleanLitteral", "UserDefinedLiteral", "MultiLineMacro", 
                      "Directive", "Asm", "Auto", "Bool", "Break", "Case", 
                      "Char", "Complex", "Const", "Continue", "Default", 
                      "Do", "Double", "Else", "Enum", "Extern", "False_", 
                      "Float", "For", "Goto", "If", "Imaginary", "Inline", 
                      "Int", "Long", "Register", "Return", "Short", "Signed", 
                      "Sizeof", "Static", "Struct", "Switch", "True_", "Typedef", 
                      "Union", "Unsigned", "Void", "Volatile", "While", 
                      "LeftParen", "RightParen", "LeftBracket", "RightBracket", 
                      "LeftBrace", "RightBrace", "Plus", "Minus", "Star", 
                      "Div", "Mod", "Caret", "And", "Or", "Tilde", "Not", 
                      "Assign", "Less", "Greater", "PlusAssign", "MinusAssign", 
                      "StarAssign", "DivAssign", "ModAssign", "XorAssign", 
                      "AndAssign", "OrAssign", "LeftShiftAssign", "RightShiftAssign", 
                      "Equal", "NotEqual", "LessEqual", "GreaterEqual", 
                      "AndAnd", "OrOr", "PlusPlus", "MinusMinus", "Comma", 
                      "ArrowStar", "Arrow", "Question", "Colon", "Doublecolon", 
                      "Semi", "Dot", "DotStar", "Ellipsis", "Identifier", 
                      "DecimalLiteral", "OctalLiteral", "HexadecimalLiteral", 
                      "BinaryLiteral", "IntegerSuffix", "UserDefinedIntegerLiteral", 
                      "UserDefinedFloatingLiteral", "UserDefinedStringLiteral", 
                      "UserDefinedCharacterLiteral", "Whitespace", "Newline", 
                      "BlockComment", "LineComment" ]

    RULE_prog = 0
    RULE_instrument_definition = 1
    RULE_instrument_parameters = 2
    RULE_instrument_parameter = 3
    RULE_instrument_parameter_unit = 4
    RULE_instrument_trace = 5
    RULE_instrument_metadata = 6
    RULE_instrument_trace_include = 7
    RULE_component_instance = 8
    RULE_instance_name = 9
    RULE_component_type = 10
    RULE_instance_parameters = 11
    RULE_instance_parameter = 12
    RULE_split = 13
    RULE_when = 14
    RULE_place = 15
    RULE_orientation = 16
    RULE_groupref = 17
    RULE_jumps = 18
    RULE_jump = 19
    RULE_jumpname = 20
    RULE_extend = 21
    RULE_component_ref = 22
    RULE_coords = 23
    RULE_reference = 24
    RULE_dependency = 25
    RULE_declare = 26
    RULE_uservars = 27
    RULE_initialise = 28
    RULE_save = 29
    RULE_finally_ = 30
    RULE_multi_block = 31
    RULE_metadata = 32
    RULE_category = 33
    RULE_initializerlist = 34
    RULE_assignment = 35
    RULE_expr = 36
    RULE_shell = 37
    RULE_search = 38
    RULE_unparsed_block = 39

    ruleNames =  [ "prog", "instrument_definition", "instrument_parameters", 
                   "instrument_parameter", "instrument_parameter_unit", 
                   "instrument_trace", "instrument_metadata", "instrument_trace_include", 
                   "component_instance", "instance_name", "component_type", 
                   "instance_parameters", "instance_parameter", "split", 
                   "when", "place", "orientation", "groupref", "jumps", 
                   "jump", "jumpname", "extend", "component_ref", "coords", 
                   "reference", "dependency", "declare", "uservars", "initialise", 
                   "save", "finally_", "multi_block", "metadata", "category", 
                   "initializerlist", "assignment", "expr", "shell", "search", 
                   "unparsed_block" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    Absolute=4
    At=5
    Category=6
    Component=7
    UserVars=8
    Define=9
    Declare=10
    Definition=11
    End=12
    McDisplay=13
    Finally=14
    Initialize=15
    Instrument=16
    Output=17
    Private=18
    Parameters=19
    Relative=20
    Rotated=21
    Previous=22
    Setting=23
    Trace=24
    Share=25
    Extend=26
    Group=27
    Save=28
    Jump=29
    When=30
    Next=31
    Iterate=32
    Myself=33
    Copy=34
    Inherit=35
    Split=36
    Removable=37
    Cpu=38
    NoAcc=39
    Dependency=40
    Shell=41
    Search=42
    MetaData=43
    String=44
    Vector=45
    Symbol=46
    UnparsedBlock=47
    Include=48
    Null=49
    IntegerLiteral=50
    CharacterLiteral=51
    FloatingLiteral=52
    StringLiteral=53
    BooleanLitteral=54
    UserDefinedLiteral=55
    MultiLineMacro=56
    Directive=57
    Asm=58
    Auto=59
    Bool=60
    Break=61
    Case=62
    Char=63
    Complex=64
    Const=65
    Continue=66
    Default=67
    Do=68
    Double=69
    Else=70
    Enum=71
    Extern=72
    False_=73
    Float=74
    For=75
    Goto=76
    If=77
    Imaginary=78
    Inline=79
    Int=80
    Long=81
    Register=82
    Return=83
    Short=84
    Signed=85
    Sizeof=86
    Static=87
    Struct=88
    Switch=89
    True_=90
    Typedef=91
    Union=92
    Unsigned=93
    Void=94
    Volatile=95
    While=96
    LeftParen=97
    RightParen=98
    LeftBracket=99
    RightBracket=100
    LeftBrace=101
    RightBrace=102
    Plus=103
    Minus=104
    Star=105
    Div=106
    Mod=107
    Caret=108
    And=109
    Or=110
    Tilde=111
    Not=112
    Assign=113
    Less=114
    Greater=115
    PlusAssign=116
    MinusAssign=117
    StarAssign=118
    DivAssign=119
    ModAssign=120
    XorAssign=121
    AndAssign=122
    OrAssign=123
    LeftShiftAssign=124
    RightShiftAssign=125
    Equal=126
    NotEqual=127
    LessEqual=128
    GreaterEqual=129
    AndAnd=130
    OrOr=131
    PlusPlus=132
    MinusMinus=133
    Comma=134
    ArrowStar=135
    Arrow=136
    Question=137
    Colon=138
    Doublecolon=139
    Semi=140
    Dot=141
    DotStar=142
    Ellipsis=143
    Identifier=144
    DecimalLiteral=145
    OctalLiteral=146
    HexadecimalLiteral=147
    BinaryLiteral=148
    IntegerSuffix=149
    UserDefinedIntegerLiteral=150
    UserDefinedFloatingLiteral=151
    UserDefinedStringLiteral=152
    UserDefinedCharacterLiteral=153
    Whitespace=154
    Newline=155
    BlockComment=156
    LineComment=157

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def instrument_definition(self):
            return self.getTypedRuleContext(McInstrParser.Instrument_definitionContext,0)


        def EOF(self):
            return self.getToken(McInstrParser.EOF, 0)

        def getRuleIndex(self):
            return McInstrParser.RULE_prog

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProg" ):
                return visitor.visitProg(self)
            else:
                return visitor.visitChildren(self)




    def prog(self):

        localctx = McInstrParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 80
            self.instrument_definition()
            self.state = 81
            self.match(McInstrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Instrument_definitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Define(self):
            return self.getToken(McInstrParser.Define, 0)

        def Instrument(self):
            return self.getToken(McInstrParser.Instrument, 0)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)

        def instrument_parameters(self):
            return self.getTypedRuleContext(McInstrParser.Instrument_parametersContext,0)


        def instrument_trace(self):
            return self.getTypedRuleContext(McInstrParser.Instrument_traceContext,0)


        def End(self):
            return self.getToken(McInstrParser.End, 0)

        def shell(self):
            return self.getTypedRuleContext(McInstrParser.ShellContext,0)


        def search(self):
            return self.getTypedRuleContext(McInstrParser.SearchContext,0)


        def instrument_metadata(self):
            return self.getTypedRuleContext(McInstrParser.Instrument_metadataContext,0)


        def dependency(self):
            return self.getTypedRuleContext(McInstrParser.DependencyContext,0)


        def declare(self):
            return self.getTypedRuleContext(McInstrParser.DeclareContext,0)


        def uservars(self):
            return self.getTypedRuleContext(McInstrParser.UservarsContext,0)


        def initialise(self):
            return self.getTypedRuleContext(McInstrParser.InitialiseContext,0)


        def save(self):
            return self.getTypedRuleContext(McInstrParser.SaveContext,0)


        def finally_(self):
            return self.getTypedRuleContext(McInstrParser.Finally_Context,0)


        def getRuleIndex(self):
            return McInstrParser.RULE_instrument_definition

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrument_definition" ):
                return visitor.visitInstrument_definition(self)
            else:
                return visitor.visitChildren(self)




    def instrument_definition(self):

        localctx = McInstrParser.Instrument_definitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_instrument_definition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 83
            self.match(McInstrParser.Define)
            self.state = 84
            self.match(McInstrParser.Instrument)
            self.state = 85
            self.match(McInstrParser.Identifier)
            self.state = 86
            self.instrument_parameters()
            self.state = 88
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==41:
                self.state = 87
                self.shell()


            self.state = 91
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==42:
                self.state = 90
                self.search()


            self.state = 94
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==43:
                self.state = 93
                self.instrument_metadata()


            self.state = 97
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==40:
                self.state = 96
                self.dependency()


            self.state = 100
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 99
                self.declare()


            self.state = 103
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 102
                self.uservars()


            self.state = 106
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==15:
                self.state = 105
                self.initialise()


            self.state = 108
            self.instrument_trace()
            self.state = 110
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 109
                self.save()


            self.state = 113
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==14:
                self.state = 112
                self.finally_()


            self.state = 115
            self.match(McInstrParser.End)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Instrument_parametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._instrument_parameter = None # Instrument_parameterContext
            self.params = list() # of Instrument_parameterContexts

        def LeftParen(self):
            return self.getToken(McInstrParser.LeftParen, 0)

        def RightParen(self):
            return self.getToken(McInstrParser.RightParen, 0)

        def instrument_parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.Instrument_parameterContext)
            else:
                return self.getTypedRuleContext(McInstrParser.Instrument_parameterContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(McInstrParser.Comma)
            else:
                return self.getToken(McInstrParser.Comma, i)

        def getRuleIndex(self):
            return McInstrParser.RULE_instrument_parameters

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrument_parameters" ):
                return visitor.visitInstrument_parameters(self)
            else:
                return visitor.visitChildren(self)




    def instrument_parameters(self):

        localctx = McInstrParser.Instrument_parametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_instrument_parameters)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 117
            self.match(McInstrParser.LeftParen)
            self.state = 126
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if ((((_la - 44)) & ~0x3f) == 0 and ((1 << (_la - 44)) & 68753555457) != 0) or _la==144:
                self.state = 118
                localctx._instrument_parameter = self.instrument_parameter()
                localctx.params.append(localctx._instrument_parameter)
                self.state = 123
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==134:
                    self.state = 119
                    self.match(McInstrParser.Comma)
                    self.state = 120
                    localctx._instrument_parameter = self.instrument_parameter()
                    localctx.params.append(localctx._instrument_parameter)
                    self.state = 125
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 128
            self.match(McInstrParser.RightParen)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Instrument_parameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McInstrParser.RULE_instrument_parameter

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class InstrumentParameterIntegerContext(Instrument_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.Instrument_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Int(self):
            return self.getToken(McInstrParser.Int, 0)
        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)
        def instrument_parameter_unit(self):
            return self.getTypedRuleContext(McInstrParser.Instrument_parameter_unitContext,0)

        def Assign(self):
            return self.getToken(McInstrParser.Assign, 0)
        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrumentParameterInteger" ):
                return visitor.visitInstrumentParameterInteger(self)
            else:
                return visitor.visitChildren(self)


    class InstrumentParameterDoubleContext(Instrument_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.Instrument_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)
        def Double(self):
            return self.getToken(McInstrParser.Double, 0)
        def instrument_parameter_unit(self):
            return self.getTypedRuleContext(McInstrParser.Instrument_parameter_unitContext,0)

        def Assign(self):
            return self.getToken(McInstrParser.Assign, 0)
        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrumentParameterDouble" ):
                return visitor.visitInstrumentParameterDouble(self)
            else:
                return visitor.visitChildren(self)


    class InstrumentParameterStringContext(Instrument_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.Instrument_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)
        def String(self):
            return self.getToken(McInstrParser.String, 0)
        def instrument_parameter_unit(self):
            return self.getTypedRuleContext(McInstrParser.Instrument_parameter_unitContext,0)

        def Assign(self):
            return self.getToken(McInstrParser.Assign, 0)
        def Char(self):
            return self.getToken(McInstrParser.Char, 0)
        def Star(self):
            return self.getToken(McInstrParser.Star, 0)
        def StringLiteral(self):
            return self.getToken(McInstrParser.StringLiteral, 0)
        def Null(self):
            return self.getToken(McInstrParser.Null, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrumentParameterString" ):
                return visitor.visitInstrumentParameterString(self)
            else:
                return visitor.visitChildren(self)



    def instrument_parameter(self):

        localctx = McInstrParser.Instrument_parameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_instrument_parameter)
        self._la = 0 # Token type
        try:
            self.state = 163
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [69, 144]:
                localctx = McInstrParser.InstrumentParameterDoubleContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 131
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==69:
                    self.state = 130
                    self.match(McInstrParser.Double)


                self.state = 133
                self.match(McInstrParser.Identifier)
                self.state = 135
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==106:
                    self.state = 134
                    self.instrument_parameter_unit()


                self.state = 139
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==113:
                    self.state = 137
                    self.match(McInstrParser.Assign)
                    self.state = 138
                    self.expr(0)


                pass
            elif token in [80]:
                localctx = McInstrParser.InstrumentParameterIntegerContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 141
                self.match(McInstrParser.Int)
                self.state = 142
                self.match(McInstrParser.Identifier)
                self.state = 144
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==106:
                    self.state = 143
                    self.instrument_parameter_unit()


                self.state = 148
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==113:
                    self.state = 146
                    self.match(McInstrParser.Assign)
                    self.state = 147
                    self.expr(0)


                pass
            elif token in [44, 63]:
                localctx = McInstrParser.InstrumentParameterStringContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 153
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [44]:
                    self.state = 150
                    self.match(McInstrParser.String)
                    pass
                elif token in [63]:
                    self.state = 151
                    self.match(McInstrParser.Char)
                    self.state = 152
                    self.match(McInstrParser.Star)
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 155
                self.match(McInstrParser.Identifier)
                self.state = 157
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==106:
                    self.state = 156
                    self.instrument_parameter_unit()


                self.state = 161
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==113:
                    self.state = 159
                    self.match(McInstrParser.Assign)
                    self.state = 160
                    _la = self._input.LA(1)
                    if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 9570149208162306) != 0)):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Instrument_parameter_unitContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Div(self):
            return self.getToken(McInstrParser.Div, 0)

        def StringLiteral(self):
            return self.getToken(McInstrParser.StringLiteral, 0)

        def getRuleIndex(self):
            return McInstrParser.RULE_instrument_parameter_unit

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrument_parameter_unit" ):
                return visitor.visitInstrument_parameter_unit(self)
            else:
                return visitor.visitChildren(self)




    def instrument_parameter_unit(self):

        localctx = McInstrParser.Instrument_parameter_unitContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_instrument_parameter_unit)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 165
            self.match(McInstrParser.Div)
            self.state = 166
            self.match(McInstrParser.StringLiteral)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Instrument_traceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Trace(self):
            return self.getToken(McInstrParser.Trace, 0)

        def component_instance(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.Component_instanceContext)
            else:
                return self.getTypedRuleContext(McInstrParser.Component_instanceContext,i)


        def search(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.SearchContext)
            else:
                return self.getTypedRuleContext(McInstrParser.SearchContext,i)


        def instrument_trace_include(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.Instrument_trace_includeContext)
            else:
                return self.getTypedRuleContext(McInstrParser.Instrument_trace_includeContext,i)


        def getRuleIndex(self):
            return McInstrParser.RULE_instrument_trace

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrument_trace" ):
                return visitor.visitInstrument_trace(self)
            else:
                return visitor.visitChildren(self)




    def instrument_trace(self):

        localctx = McInstrParser.Instrument_traceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_instrument_trace)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 168
            self.match(McInstrParser.Trace)
            self.state = 176
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 286354059559040) != 0):
                self.state = 172 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 172
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [7, 36, 37, 38]:
                        self.state = 169
                        self.component_instance()
                        pass
                    elif token in [42]:
                        self.state = 170
                        self.search()
                        pass
                    elif token in [48]:
                        self.state = 171
                        self.instrument_trace_include()
                        pass
                    else:
                        raise NoViableAltException(self)

                    self.state = 174 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 286354059559040) != 0)):
                        break



        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Instrument_metadataContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def metadata(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.MetadataContext)
            else:
                return self.getTypedRuleContext(McInstrParser.MetadataContext,i)


        def getRuleIndex(self):
            return McInstrParser.RULE_instrument_metadata

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrument_metadata" ):
                return visitor.visitInstrument_metadata(self)
            else:
                return visitor.visitChildren(self)




    def instrument_metadata(self):

        localctx = McInstrParser.Instrument_metadataContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_instrument_metadata)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 179 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 178
                self.metadata()
                self.state = 181 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==43):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Instrument_trace_includeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Include(self):
            return self.getToken(McInstrParser.Include, 0)

        def StringLiteral(self):
            return self.getToken(McInstrParser.StringLiteral, 0)

        def getRuleIndex(self):
            return McInstrParser.RULE_instrument_trace_include

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrument_trace_include" ):
                return visitor.visitInstrument_trace_include(self)
            else:
                return visitor.visitChildren(self)




    def instrument_trace_include(self):

        localctx = McInstrParser.Instrument_trace_includeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_instrument_trace_include)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 183
            self.match(McInstrParser.Include)
            self.state = 184
            self.match(McInstrParser.StringLiteral)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Component_instanceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Component(self):
            return self.getToken(McInstrParser.Component, 0)

        def instance_name(self):
            return self.getTypedRuleContext(McInstrParser.Instance_nameContext,0)


        def Assign(self):
            return self.getToken(McInstrParser.Assign, 0)

        def component_type(self):
            return self.getTypedRuleContext(McInstrParser.Component_typeContext,0)


        def place(self):
            return self.getTypedRuleContext(McInstrParser.PlaceContext,0)


        def Removable(self):
            return self.getToken(McInstrParser.Removable, 0)

        def Cpu(self):
            return self.getToken(McInstrParser.Cpu, 0)

        def split(self):
            return self.getTypedRuleContext(McInstrParser.SplitContext,0)


        def instance_parameters(self):
            return self.getTypedRuleContext(McInstrParser.Instance_parametersContext,0)


        def when(self):
            return self.getTypedRuleContext(McInstrParser.WhenContext,0)


        def orientation(self):
            return self.getTypedRuleContext(McInstrParser.OrientationContext,0)


        def groupref(self):
            return self.getTypedRuleContext(McInstrParser.GrouprefContext,0)


        def extend(self):
            return self.getTypedRuleContext(McInstrParser.ExtendContext,0)


        def jumps(self):
            return self.getTypedRuleContext(McInstrParser.JumpsContext,0)


        def metadata(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.MetadataContext)
            else:
                return self.getTypedRuleContext(McInstrParser.MetadataContext,i)


        def getRuleIndex(self):
            return McInstrParser.RULE_component_instance

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponent_instance" ):
                return visitor.visitComponent_instance(self)
            else:
                return visitor.visitChildren(self)




    def component_instance(self):

        localctx = McInstrParser.Component_instanceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_component_instance)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 187
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==37:
                self.state = 186
                self.match(McInstrParser.Removable)


            self.state = 190
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==38:
                self.state = 189
                self.match(McInstrParser.Cpu)


            self.state = 193
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==36:
                self.state = 192
                self.split()


            self.state = 195
            self.match(McInstrParser.Component)
            self.state = 196
            self.instance_name()
            self.state = 197
            self.match(McInstrParser.Assign)
            self.state = 198
            self.component_type()
            self.state = 200
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==97:
                self.state = 199
                self.instance_parameters()


            self.state = 203
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==30:
                self.state = 202
                self.when()


            self.state = 205
            self.place()
            self.state = 207
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==21:
                self.state = 206
                self.orientation()


            self.state = 210
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==27:
                self.state = 209
                self.groupref()


            self.state = 213
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==26:
                self.state = 212
                self.extend()


            self.state = 216
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==29:
                self.state = 215
                self.jumps()


            self.state = 221
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==43:
                self.state = 218
                self.metadata()
                self.state = 223
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Instance_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McInstrParser.RULE_instance_name

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class InstanceNameCopyIdentifierContext(Instance_nameContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.Instance_nameContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Copy(self):
            return self.getToken(McInstrParser.Copy, 0)
        def LeftParen(self):
            return self.getToken(McInstrParser.LeftParen, 0)
        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)
        def RightParen(self):
            return self.getToken(McInstrParser.RightParen, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstanceNameCopyIdentifier" ):
                return visitor.visitInstanceNameCopyIdentifier(self)
            else:
                return visitor.visitChildren(self)


    class InstanceNameCopyContext(Instance_nameContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.Instance_nameContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Myself(self):
            return self.getToken(McInstrParser.Myself, 0)
        def Copy(self):
            return self.getToken(McInstrParser.Copy, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstanceNameCopy" ):
                return visitor.visitInstanceNameCopy(self)
            else:
                return visitor.visitChildren(self)


    class InstanceNameIdentifierContext(Instance_nameContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.Instance_nameContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstanceNameIdentifier" ):
                return visitor.visitInstanceNameIdentifier(self)
            else:
                return visitor.visitChildren(self)



    def instance_name(self):

        localctx = McInstrParser.Instance_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_instance_name)
        self._la = 0 # Token type
        try:
            self.state = 230
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,34,self._ctx)
            if la_ == 1:
                localctx = McInstrParser.InstanceNameCopyIdentifierContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 224
                self.match(McInstrParser.Copy)
                self.state = 225
                self.match(McInstrParser.LeftParen)
                self.state = 226
                self.match(McInstrParser.Identifier)
                self.state = 227
                self.match(McInstrParser.RightParen)
                pass

            elif la_ == 2:
                localctx = McInstrParser.InstanceNameCopyContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 228
                _la = self._input.LA(1)
                if not(_la==33 or _la==34):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass

            elif la_ == 3:
                localctx = McInstrParser.InstanceNameIdentifierContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 229
                self.match(McInstrParser.Identifier)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Component_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McInstrParser.RULE_component_type

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ComponentTypeIdentifierContext(Component_typeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.Component_typeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponentTypeIdentifier" ):
                return visitor.visitComponentTypeIdentifier(self)
            else:
                return visitor.visitChildren(self)


    class ComponentTypeCopyContext(Component_typeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.Component_typeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Copy(self):
            return self.getToken(McInstrParser.Copy, 0)
        def LeftParen(self):
            return self.getToken(McInstrParser.LeftParen, 0)
        def component_ref(self):
            return self.getTypedRuleContext(McInstrParser.Component_refContext,0)

        def RightParen(self):
            return self.getToken(McInstrParser.RightParen, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponentTypeCopy" ):
                return visitor.visitComponentTypeCopy(self)
            else:
                return visitor.visitChildren(self)



    def component_type(self):

        localctx = McInstrParser.Component_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_component_type)
        try:
            self.state = 238
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [34]:
                localctx = McInstrParser.ComponentTypeCopyContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 232
                self.match(McInstrParser.Copy)
                self.state = 233
                self.match(McInstrParser.LeftParen)
                self.state = 234
                self.component_ref()
                self.state = 235
                self.match(McInstrParser.RightParen)
                pass
            elif token in [144]:
                localctx = McInstrParser.ComponentTypeIdentifierContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 237
                self.match(McInstrParser.Identifier)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Instance_parametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._instance_parameter = None # Instance_parameterContext
            self.params = list() # of Instance_parameterContexts

        def LeftParen(self):
            return self.getToken(McInstrParser.LeftParen, 0)

        def RightParen(self):
            return self.getToken(McInstrParser.RightParen, 0)

        def instance_parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.Instance_parameterContext)
            else:
                return self.getTypedRuleContext(McInstrParser.Instance_parameterContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(McInstrParser.Comma)
            else:
                return self.getToken(McInstrParser.Comma, i)

        def getRuleIndex(self):
            return McInstrParser.RULE_instance_parameters

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstance_parameters" ):
                return visitor.visitInstance_parameters(self)
            else:
                return visitor.visitChildren(self)




    def instance_parameters(self):

        localctx = McInstrParser.Instance_parametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_instance_parameters)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 240
            self.match(McInstrParser.LeftParen)
            self.state = 249
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==144:
                self.state = 241
                localctx._instance_parameter = self.instance_parameter()
                localctx.params.append(localctx._instance_parameter)
                self.state = 246
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==134:
                    self.state = 242
                    self.match(McInstrParser.Comma)
                    self.state = 243
                    localctx._instance_parameter = self.instance_parameter()
                    localctx.params.append(localctx._instance_parameter)
                    self.state = 248
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 251
            self.match(McInstrParser.RightParen)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Instance_parameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McInstrParser.RULE_instance_parameter

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class InstanceParameterExprContext(Instance_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.Instance_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)
        def Assign(self):
            return self.getToken(McInstrParser.Assign, 0)
        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstanceParameterExpr" ):
                return visitor.visitInstanceParameterExpr(self)
            else:
                return visitor.visitChildren(self)


    class InstanceParameterNullContext(Instance_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.Instance_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)
        def Assign(self):
            return self.getToken(McInstrParser.Assign, 0)
        def Null(self):
            return self.getToken(McInstrParser.Null, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstanceParameterNull" ):
                return visitor.visitInstanceParameterNull(self)
            else:
                return visitor.visitChildren(self)


    class InstanceParameterVectorContext(Instance_parameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.Instance_parameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)
        def Assign(self):
            return self.getToken(McInstrParser.Assign, 0)
        def initializerlist(self):
            return self.getTypedRuleContext(McInstrParser.InitializerlistContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstanceParameterVector" ):
                return visitor.visitInstanceParameterVector(self)
            else:
                return visitor.visitChildren(self)



    def instance_parameter(self):

        localctx = McInstrParser.Instance_parameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_instance_parameter)
        try:
            self.state = 262
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,38,self._ctx)
            if la_ == 1:
                localctx = McInstrParser.InstanceParameterExprContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 253
                self.match(McInstrParser.Identifier)
                self.state = 254
                self.match(McInstrParser.Assign)
                self.state = 255
                self.expr(0)
                pass

            elif la_ == 2:
                localctx = McInstrParser.InstanceParameterNullContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 256
                self.match(McInstrParser.Identifier)
                self.state = 257
                self.match(McInstrParser.Assign)
                self.state = 258
                self.match(McInstrParser.Null)
                pass

            elif la_ == 3:
                localctx = McInstrParser.InstanceParameterVectorContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 259
                self.match(McInstrParser.Identifier)
                self.state = 260
                self.match(McInstrParser.Assign)
                self.state = 261
                self.initializerlist()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SplitContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Split(self):
            return self.getToken(McInstrParser.Split, 0)

        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)


        def getRuleIndex(self):
            return McInstrParser.RULE_split

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSplit" ):
                return visitor.visitSplit(self)
            else:
                return visitor.visitChildren(self)




    def split(self):

        localctx = McInstrParser.SplitContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_split)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 264
            self.match(McInstrParser.Split)
            self.state = 267
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,39,self._ctx)
            if la_ == 1:
                pass

            elif la_ == 2:
                self.state = 266
                self.expr(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WhenContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def When(self):
            return self.getToken(McInstrParser.When, 0)

        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)


        def getRuleIndex(self):
            return McInstrParser.RULE_when

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhen" ):
                return visitor.visitWhen(self)
            else:
                return visitor.visitChildren(self)




    def when(self):

        localctx = McInstrParser.WhenContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_when)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 269
            self.match(McInstrParser.When)
            self.state = 270
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PlaceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def At(self):
            return self.getToken(McInstrParser.At, 0)

        def coords(self):
            return self.getTypedRuleContext(McInstrParser.CoordsContext,0)


        def reference(self):
            return self.getTypedRuleContext(McInstrParser.ReferenceContext,0)


        def getRuleIndex(self):
            return McInstrParser.RULE_place

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPlace" ):
                return visitor.visitPlace(self)
            else:
                return visitor.visitChildren(self)




    def place(self):

        localctx = McInstrParser.PlaceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_place)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 272
            self.match(McInstrParser.At)
            self.state = 273
            self.coords()
            self.state = 274
            self.reference()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OrientationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Rotated(self):
            return self.getToken(McInstrParser.Rotated, 0)

        def coords(self):
            return self.getTypedRuleContext(McInstrParser.CoordsContext,0)


        def reference(self):
            return self.getTypedRuleContext(McInstrParser.ReferenceContext,0)


        def getRuleIndex(self):
            return McInstrParser.RULE_orientation

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOrientation" ):
                return visitor.visitOrientation(self)
            else:
                return visitor.visitChildren(self)




    def orientation(self):

        localctx = McInstrParser.OrientationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_orientation)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 276
            self.match(McInstrParser.Rotated)
            self.state = 277
            self.coords()
            self.state = 278
            self.reference()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GrouprefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Group(self):
            return self.getToken(McInstrParser.Group, 0)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)

        def getRuleIndex(self):
            return McInstrParser.RULE_groupref

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGroupref" ):
                return visitor.visitGroupref(self)
            else:
                return visitor.visitChildren(self)




    def groupref(self):

        localctx = McInstrParser.GrouprefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_groupref)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 280
            self.match(McInstrParser.Group)
            self.state = 281
            self.match(McInstrParser.Identifier)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class JumpsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def jump(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.JumpContext)
            else:
                return self.getTypedRuleContext(McInstrParser.JumpContext,i)


        def getRuleIndex(self):
            return McInstrParser.RULE_jumps

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitJumps" ):
                return visitor.visitJumps(self)
            else:
                return visitor.visitChildren(self)




    def jumps(self):

        localctx = McInstrParser.JumpsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_jumps)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 284 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 283
                self.jump()
                self.state = 286 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==29):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class JumpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Jump(self):
            return self.getToken(McInstrParser.Jump, 0)

        def jumpname(self):
            return self.getTypedRuleContext(McInstrParser.JumpnameContext,0)


        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)


        def When(self):
            return self.getToken(McInstrParser.When, 0)

        def Iterate(self):
            return self.getToken(McInstrParser.Iterate, 0)

        def getRuleIndex(self):
            return McInstrParser.RULE_jump

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitJump" ):
                return visitor.visitJump(self)
            else:
                return visitor.visitChildren(self)




    def jump(self):

        localctx = McInstrParser.JumpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_jump)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 288
            self.match(McInstrParser.Jump)
            self.state = 289
            self.jumpname()
            self.state = 290
            _la = self._input.LA(1)
            if not(_la==30 or _la==32):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 291
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class JumpnameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McInstrParser.RULE_jumpname

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class JumpPreviousContext(JumpnameContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.JumpnameContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Previous(self):
            return self.getToken(McInstrParser.Previous, 0)
        def LeftParen(self):
            return self.getToken(McInstrParser.LeftParen, 0)
        def IntegerLiteral(self):
            return self.getToken(McInstrParser.IntegerLiteral, 0)
        def RightParen(self):
            return self.getToken(McInstrParser.RightParen, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitJumpPrevious" ):
                return visitor.visitJumpPrevious(self)
            else:
                return visitor.visitChildren(self)


    class JumpMyselfContext(JumpnameContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.JumpnameContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Myself(self):
            return self.getToken(McInstrParser.Myself, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitJumpMyself" ):
                return visitor.visitJumpMyself(self)
            else:
                return visitor.visitChildren(self)


    class JumpIdentifierContext(JumpnameContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.JumpnameContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitJumpIdentifier" ):
                return visitor.visitJumpIdentifier(self)
            else:
                return visitor.visitChildren(self)


    class JumpNextContext(JumpnameContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.JumpnameContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Next(self):
            return self.getToken(McInstrParser.Next, 0)
        def LeftParen(self):
            return self.getToken(McInstrParser.LeftParen, 0)
        def IntegerLiteral(self):
            return self.getToken(McInstrParser.IntegerLiteral, 0)
        def RightParen(self):
            return self.getToken(McInstrParser.RightParen, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitJumpNext" ):
                return visitor.visitJumpNext(self)
            else:
                return visitor.visitChildren(self)



    def jumpname(self):

        localctx = McInstrParser.JumpnameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_jumpname)
        self._la = 0 # Token type
        try:
            self.state = 307
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [22]:
                localctx = McInstrParser.JumpPreviousContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 293
                self.match(McInstrParser.Previous)
                self.state = 297
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==97:
                    self.state = 294
                    self.match(McInstrParser.LeftParen)
                    self.state = 295
                    self.match(McInstrParser.IntegerLiteral)
                    self.state = 296
                    self.match(McInstrParser.RightParen)


                pass
            elif token in [33]:
                localctx = McInstrParser.JumpMyselfContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 299
                self.match(McInstrParser.Myself)
                pass
            elif token in [31]:
                localctx = McInstrParser.JumpNextContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 300
                self.match(McInstrParser.Next)
                self.state = 304
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==97:
                    self.state = 301
                    self.match(McInstrParser.LeftParen)
                    self.state = 302
                    self.match(McInstrParser.IntegerLiteral)
                    self.state = 303
                    self.match(McInstrParser.RightParen)


                pass
            elif token in [144]:
                localctx = McInstrParser.JumpIdentifierContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 306
                self.match(McInstrParser.Identifier)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExtendContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Extend(self):
            return self.getToken(McInstrParser.Extend, 0)

        def unparsed_block(self):
            return self.getTypedRuleContext(McInstrParser.Unparsed_blockContext,0)


        def getRuleIndex(self):
            return McInstrParser.RULE_extend

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExtend" ):
                return visitor.visitExtend(self)
            else:
                return visitor.visitChildren(self)




    def extend(self):

        localctx = McInstrParser.ExtendContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_extend)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 309
            self.match(McInstrParser.Extend)
            self.state = 310
            self.unparsed_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Component_refContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Previous(self):
            return self.getToken(McInstrParser.Previous, 0)

        def LeftParen(self):
            return self.getToken(McInstrParser.LeftParen, 0)

        def IntegerLiteral(self):
            return self.getToken(McInstrParser.IntegerLiteral, 0)

        def RightParen(self):
            return self.getToken(McInstrParser.RightParen, 0)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)

        def getRuleIndex(self):
            return McInstrParser.RULE_component_ref

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComponent_ref" ):
                return visitor.visitComponent_ref(self)
            else:
                return visitor.visitChildren(self)




    def component_ref(self):

        localctx = McInstrParser.Component_refContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_component_ref)
        self._la = 0 # Token type
        try:
            self.state = 319
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [22]:
                self.enterOuterAlt(localctx, 1)
                self.state = 312
                self.match(McInstrParser.Previous)
                self.state = 316
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==97:
                    self.state = 313
                    self.match(McInstrParser.LeftParen)
                    self.state = 314
                    self.match(McInstrParser.IntegerLiteral)
                    self.state = 315
                    self.match(McInstrParser.RightParen)


                pass
            elif token in [144]:
                self.enterOuterAlt(localctx, 2)
                self.state = 318
                self.match(McInstrParser.Identifier)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CoordsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LeftParen(self):
            return self.getToken(McInstrParser.LeftParen, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(McInstrParser.Comma)
            else:
                return self.getToken(McInstrParser.Comma, i)

        def RightParen(self):
            return self.getToken(McInstrParser.RightParen, 0)

        def getRuleIndex(self):
            return McInstrParser.RULE_coords

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCoords" ):
                return visitor.visitCoords(self)
            else:
                return visitor.visitChildren(self)




    def coords(self):

        localctx = McInstrParser.CoordsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_coords)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 321
            self.match(McInstrParser.LeftParen)
            self.state = 322
            self.expr(0)
            self.state = 323
            self.match(McInstrParser.Comma)
            self.state = 324
            self.expr(0)
            self.state = 325
            self.match(McInstrParser.Comma)
            self.state = 326
            self.expr(0)
            self.state = 327
            self.match(McInstrParser.RightParen)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReferenceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Absolute(self):
            return self.getToken(McInstrParser.Absolute, 0)

        def Relative(self):
            return self.getToken(McInstrParser.Relative, 0)

        def component_ref(self):
            return self.getTypedRuleContext(McInstrParser.Component_refContext,0)


        def getRuleIndex(self):
            return McInstrParser.RULE_reference

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReference" ):
                return visitor.visitReference(self)
            else:
                return visitor.visitChildren(self)




    def reference(self):

        localctx = McInstrParser.ReferenceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_reference)
        try:
            self.state = 335
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [4]:
                self.enterOuterAlt(localctx, 1)
                self.state = 329
                self.match(McInstrParser.Absolute)
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 2)
                self.state = 330
                self.match(McInstrParser.Relative)
                self.state = 333
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [4]:
                    self.state = 331
                    self.match(McInstrParser.Absolute)
                    pass
                elif token in [22, 144]:
                    self.state = 332
                    self.component_ref()
                    pass
                else:
                    raise NoViableAltException(self)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DependencyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Dependency(self):
            return self.getToken(McInstrParser.Dependency, 0)

        def StringLiteral(self):
            return self.getToken(McInstrParser.StringLiteral, 0)

        def getRuleIndex(self):
            return McInstrParser.RULE_dependency

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDependency" ):
                return visitor.visitDependency(self)
            else:
                return visitor.visitChildren(self)




    def dependency(self):

        localctx = McInstrParser.DependencyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_dependency)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 337
            self.match(McInstrParser.Dependency)
            self.state = 338
            self.match(McInstrParser.StringLiteral)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclareContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Declare(self):
            return self.getToken(McInstrParser.Declare, 0)

        def multi_block(self):
            return self.getTypedRuleContext(McInstrParser.Multi_blockContext,0)


        def getRuleIndex(self):
            return McInstrParser.RULE_declare

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeclare" ):
                return visitor.visitDeclare(self)
            else:
                return visitor.visitChildren(self)




    def declare(self):

        localctx = McInstrParser.DeclareContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_declare)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 340
            self.match(McInstrParser.Declare)
            self.state = 341
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UservarsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def UserVars(self):
            return self.getToken(McInstrParser.UserVars, 0)

        def multi_block(self):
            return self.getTypedRuleContext(McInstrParser.Multi_blockContext,0)


        def getRuleIndex(self):
            return McInstrParser.RULE_uservars

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUservars" ):
                return visitor.visitUservars(self)
            else:
                return visitor.visitChildren(self)




    def uservars(self):

        localctx = McInstrParser.UservarsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_uservars)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 343
            self.match(McInstrParser.UserVars)
            self.state = 344
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InitialiseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Initialize(self):
            return self.getToken(McInstrParser.Initialize, 0)

        def multi_block(self):
            return self.getTypedRuleContext(McInstrParser.Multi_blockContext,0)


        def getRuleIndex(self):
            return McInstrParser.RULE_initialise

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInitialise" ):
                return visitor.visitInitialise(self)
            else:
                return visitor.visitChildren(self)




    def initialise(self):

        localctx = McInstrParser.InitialiseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_initialise)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 346
            self.match(McInstrParser.Initialize)
            self.state = 347
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SaveContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Save(self):
            return self.getToken(McInstrParser.Save, 0)

        def multi_block(self):
            return self.getTypedRuleContext(McInstrParser.Multi_blockContext,0)


        def getRuleIndex(self):
            return McInstrParser.RULE_save

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSave" ):
                return visitor.visitSave(self)
            else:
                return visitor.visitChildren(self)




    def save(self):

        localctx = McInstrParser.SaveContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_save)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 349
            self.match(McInstrParser.Save)
            self.state = 350
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Finally_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McInstrParser.RULE_finally_

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class FinallyContext(Finally_Context):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.Finally_Context
            super().__init__(parser)
            self.copyFrom(ctx)

        def Finally(self):
            return self.getToken(McInstrParser.Finally, 0)
        def multi_block(self):
            return self.getTypedRuleContext(McInstrParser.Multi_blockContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFinally" ):
                return visitor.visitFinally(self)
            else:
                return visitor.visitChildren(self)



    def finally_(self):

        localctx = McInstrParser.Finally_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_finally_)
        try:
            localctx = McInstrParser.FinallyContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 352
            self.match(McInstrParser.Finally)
            self.state = 353
            self.multi_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Multi_blockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unparsed_block(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.Unparsed_blockContext)
            else:
                return self.getTypedRuleContext(McInstrParser.Unparsed_blockContext,i)


        def Inherit(self, i:int=None):
            if i is None:
                return self.getTokens(McInstrParser.Inherit)
            else:
                return self.getToken(McInstrParser.Inherit, i)

        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(McInstrParser.Identifier)
            else:
                return self.getToken(McInstrParser.Identifier, i)

        def Extend(self, i:int=None):
            if i is None:
                return self.getTokens(McInstrParser.Extend)
            else:
                return self.getToken(McInstrParser.Extend, i)

        def getRuleIndex(self):
            return McInstrParser.RULE_multi_block

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMulti_block" ):
                return visitor.visitMulti_block(self)
            else:
                return visitor.visitChildren(self)




    def multi_block(self):

        localctx = McInstrParser.Multi_blockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_multi_block)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 356
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==47:
                self.state = 355
                self.unparsed_block()


            self.state = 364
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==26 or _la==35:
                self.state = 362
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [35]:
                    self.state = 358
                    self.match(McInstrParser.Inherit)
                    self.state = 359
                    self.match(McInstrParser.Identifier)
                    pass
                elif token in [26]:
                    self.state = 360
                    self.match(McInstrParser.Extend)
                    self.state = 361
                    self.unparsed_block()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 366
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MetadataContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.mime = None # Token
            self.name = None # Token

        def MetaData(self):
            return self.getToken(McInstrParser.MetaData, 0)

        def unparsed_block(self):
            return self.getTypedRuleContext(McInstrParser.Unparsed_blockContext,0)


        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(McInstrParser.Identifier)
            else:
                return self.getToken(McInstrParser.Identifier, i)

        def StringLiteral(self, i:int=None):
            if i is None:
                return self.getTokens(McInstrParser.StringLiteral)
            else:
                return self.getToken(McInstrParser.StringLiteral, i)

        def getRuleIndex(self):
            return McInstrParser.RULE_metadata

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetadata" ):
                return visitor.visitMetadata(self)
            else:
                return visitor.visitChildren(self)




    def metadata(self):

        localctx = McInstrParser.MetadataContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_metadata)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 367
            self.match(McInstrParser.MetaData)
            self.state = 368
            localctx.mime = self._input.LT(1)
            _la = self._input.LA(1)
            if not(_la==53 or _la==144):
                localctx.mime = self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 369
            localctx.name = self._input.LT(1)
            _la = self._input.LA(1)
            if not(_la==53 or _la==144):
                localctx.name = self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 370
            self.unparsed_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CategoryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Category(self):
            return self.getToken(McInstrParser.Category, 0)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)

        def StringLiteral(self):
            return self.getToken(McInstrParser.StringLiteral, 0)

        def getRuleIndex(self):
            return McInstrParser.RULE_category

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCategory" ):
                return visitor.visitCategory(self)
            else:
                return visitor.visitChildren(self)




    def category(self):

        localctx = McInstrParser.CategoryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_category)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 372
            self.match(McInstrParser.Category)
            self.state = 373
            _la = self._input.LA(1)
            if not(_la==53 or _la==144):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InitializerlistContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._expr = None # ExprContext
            self.values = list() # of ExprContexts

        def LeftBrace(self):
            return self.getToken(McInstrParser.LeftBrace, 0)

        def RightBrace(self):
            return self.getToken(McInstrParser.RightBrace, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(McInstrParser.Comma)
            else:
                return self.getToken(McInstrParser.Comma, i)

        def getRuleIndex(self):
            return McInstrParser.RULE_initializerlist

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInitializerlist" ):
                return visitor.visitInitializerlist(self)
            else:
                return visitor.visitChildren(self)




    def initializerlist(self):

        localctx = McInstrParser.InitializerlistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_initializerlist)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 375
            self.match(McInstrParser.LeftBrace)
            self.state = 376
            localctx._expr = self.expr(0)
            localctx.values.append(localctx._expr)
            self.state = 381
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==134:
                self.state = 377
                self.match(McInstrParser.Comma)
                self.state = 378
                localctx._expr = self.expr(0)
                localctx.values.append(localctx._expr)
                self.state = 383
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 384
            self.match(McInstrParser.RightBrace)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)

        def Assign(self):
            return self.getToken(McInstrParser.Assign, 0)

        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)


        def getRuleIndex(self):
            return McInstrParser.RULE_assignment

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignment" ):
                return visitor.visitAssignment(self)
            else:
                return visitor.visitChildren(self)




    def assignment(self):

        localctx = McInstrParser.AssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_assignment)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 386
            self.match(McInstrParser.Identifier)
            self.state = 387
            self.match(McInstrParser.Assign)
            self.state = 388
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McInstrParser.RULE_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class ExpressionBinaryModContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def Mod(self):
            return self.getToken(McInstrParser.Mod, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryMod" ):
                return visitor.visitExpressionBinaryMod(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryLessContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def Less(self):
            return self.getToken(McInstrParser.Less, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryLess" ):
                return visitor.visitExpressionBinaryLess(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryGreaterContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def Greater(self):
            return self.getToken(McInstrParser.Greater, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryGreater" ):
                return visitor.visitExpressionBinaryGreater(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryLessEqualContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def LessEqual(self):
            return self.getToken(McInstrParser.LessEqual, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryLessEqual" ):
                return visitor.visitExpressionBinaryLessEqual(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionArrayAccessContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)
        def LeftBracket(self):
            return self.getToken(McInstrParser.LeftBracket, 0)
        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)

        def RightBracket(self):
            return self.getToken(McInstrParser.RightBracket, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionArrayAccess" ):
                return visitor.visitExpressionArrayAccess(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryLogicContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)

        def AndAnd(self):
            return self.getToken(McInstrParser.AndAnd, 0)
        def OrOr(self):
            return self.getToken(McInstrParser.OrOr, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryLogic" ):
                return visitor.visitExpressionBinaryLogic(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionIntegerContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def IntegerLiteral(self):
            return self.getToken(McInstrParser.IntegerLiteral, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionInteger" ):
                return visitor.visitExpressionInteger(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryRightShiftContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryRightShift" ):
                return visitor.visitExpressionBinaryRightShift(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionMyselfContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Myself(self):
            return self.getToken(McInstrParser.Myself, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionMyself" ):
                return visitor.visitExpressionMyself(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionPreviousContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Previous(self):
            return self.getToken(McInstrParser.Previous, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionPrevious" ):
                return visitor.visitExpressionPrevious(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionIdentifierContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionIdentifier" ):
                return visitor.visitExpressionIdentifier(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryNotEqualContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def NotEqual(self):
            return self.getToken(McInstrParser.NotEqual, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryNotEqual" ):
                return visitor.visitExpressionBinaryNotEqual(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionStructAccessContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)
        def Dot(self):
            return self.getToken(McInstrParser.Dot, 0)
        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionStructAccess" ):
                return visitor.visitExpressionStructAccess(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionFunctionCallContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self._expr = None # ExprContext
            self.args = list() # of ExprContexts
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)
        def LeftParen(self):
            return self.getToken(McInstrParser.LeftParen, 0)
        def RightParen(self):
            return self.getToken(McInstrParser.RightParen, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)

        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(McInstrParser.Comma)
            else:
                return self.getToken(McInstrParser.Comma, i)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionFunctionCall" ):
                return visitor.visitExpressionFunctionCall(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryMDContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)

        def Star(self):
            return self.getToken(McInstrParser.Star, 0)
        def Div(self):
            return self.getToken(McInstrParser.Div, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryMD" ):
                return visitor.visitExpressionBinaryMD(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionStringContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self._StringLiteral = None # Token
            self.args = list() # of Tokens
            self.copyFrom(ctx)

        def StringLiteral(self, i:int=None):
            if i is None:
                return self.getTokens(McInstrParser.StringLiteral)
            else:
                return self.getToken(McInstrParser.StringLiteral, i)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionString" ):
                return visitor.visitExpressionString(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionGroupingContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LeftParen(self):
            return self.getToken(McInstrParser.LeftParen, 0)
        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)

        def RightParen(self):
            return self.getToken(McInstrParser.RightParen, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionGrouping" ):
                return visitor.visitExpressionGrouping(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionExponentiationContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.base = None # ExprContext
            self.exponent = None # ExprContext
            self.copyFrom(ctx)

        def Caret(self):
            return self.getToken(McInstrParser.Caret, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionExponentiation" ):
                return visitor.visitExpressionExponentiation(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryLeftShiftContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryLeftShift" ):
                return visitor.visitExpressionBinaryLeftShift(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryGreaterEqualContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def GreaterEqual(self):
            return self.getToken(McInstrParser.GreaterEqual, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryGreaterEqual" ):
                return visitor.visitExpressionBinaryGreaterEqual(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionZeroContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionZero" ):
                return visitor.visitExpressionZero(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionUnaryPMContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)

        def Plus(self):
            return self.getToken(McInstrParser.Plus, 0)
        def Minus(self):
            return self.getToken(McInstrParser.Minus, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionUnaryPM" ):
                return visitor.visitExpressionUnaryPM(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionTrinaryLogicContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.test = None # ExprContext
            self.true_ = None # ExprContext
            self.false_ = None # ExprContext
            self.copyFrom(ctx)

        def Question(self):
            return self.getToken(McInstrParser.Question, 0)
        def Colon(self):
            return self.getToken(McInstrParser.Colon, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionTrinaryLogic" ):
                return visitor.visitExpressionTrinaryLogic(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionFloatContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def FloatingLiteral(self):
            return self.getToken(McInstrParser.FloatingLiteral, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionFloat" ):
                return visitor.visitExpressionFloat(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionPointerAccessContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(McInstrParser.Identifier, 0)
        def Arrow(self):
            return self.getToken(McInstrParser.Arrow, 0)
        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionPointerAccess" ):
                return visitor.visitExpressionPointerAccess(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryEqualContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def Equal(self):
            return self.getToken(McInstrParser.Equal, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryEqual" ):
                return visitor.visitExpressionBinaryEqual(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionBinaryPMContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(McInstrParser.ExprContext)
            else:
                return self.getTypedRuleContext(McInstrParser.ExprContext,i)

        def Plus(self):
            return self.getToken(McInstrParser.Plus, 0)
        def Minus(self):
            return self.getToken(McInstrParser.Minus, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionBinaryPM" ):
                return visitor.visitExpressionBinaryPM(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionUnaryLogicContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Not(self):
            return self.getToken(McInstrParser.Not, 0)
        def expr(self):
            return self.getTypedRuleContext(McInstrParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionUnaryLogic" ):
                return visitor.visitExpressionUnaryLogic(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = McInstrParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 72
        self.enterRecursionRule(localctx, 72, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 434
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,54,self._ctx)
            if la_ == 1:
                localctx = McInstrParser.ExpressionZeroContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 391
                self.match(McInstrParser.T__0)
                pass

            elif la_ == 2:
                localctx = McInstrParser.ExpressionIntegerContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 392
                self.match(McInstrParser.IntegerLiteral)
                pass

            elif la_ == 3:
                localctx = McInstrParser.ExpressionFloatContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 393
                self.match(McInstrParser.FloatingLiteral)
                pass

            elif la_ == 4:
                localctx = McInstrParser.ExpressionStringContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 397
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,52,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 394
                        localctx._StringLiteral = self.match(McInstrParser.StringLiteral)
                        localctx.args.append(localctx._StringLiteral) 
                    self.state = 399
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,52,self._ctx)

                pass

            elif la_ == 5:
                localctx = McInstrParser.ExpressionPointerAccessContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 400
                self.match(McInstrParser.Identifier)
                self.state = 401
                self.match(McInstrParser.Arrow)
                self.state = 402
                self.expr(24)
                pass

            elif la_ == 6:
                localctx = McInstrParser.ExpressionStructAccessContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 403
                self.match(McInstrParser.Identifier)
                self.state = 404
                self.match(McInstrParser.Dot)
                self.state = 405
                self.expr(23)
                pass

            elif la_ == 7:
                localctx = McInstrParser.ExpressionArrayAccessContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 406
                self.match(McInstrParser.Identifier)
                self.state = 407
                self.match(McInstrParser.LeftBracket)
                self.state = 408
                self.expr(0)
                self.state = 409
                self.match(McInstrParser.RightBracket)
                pass

            elif la_ == 8:
                localctx = McInstrParser.ExpressionFunctionCallContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 411
                self.match(McInstrParser.Identifier)
                self.state = 412
                self.match(McInstrParser.LeftParen)
                self.state = 413
                localctx._expr = self.expr(0)
                localctx.args.append(localctx._expr)
                self.state = 418
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==134:
                    self.state = 414
                    self.match(McInstrParser.Comma)
                    self.state = 415
                    localctx._expr = self.expr(0)
                    localctx.args.append(localctx._expr)
                    self.state = 420
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 421
                self.match(McInstrParser.RightParen)
                pass

            elif la_ == 9:
                localctx = McInstrParser.ExpressionGroupingContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 423
                self.match(McInstrParser.LeftParen)
                self.state = 424
                self.expr(0)
                self.state = 425
                self.match(McInstrParser.RightParen)
                pass

            elif la_ == 10:
                localctx = McInstrParser.ExpressionUnaryPMContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 427
                _la = self._input.LA(1)
                if not(_la==103 or _la==104):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 428
                self.expr(19)
                pass

            elif la_ == 11:
                localctx = McInstrParser.ExpressionIdentifierContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 429
                self.match(McInstrParser.Identifier)
                pass

            elif la_ == 12:
                localctx = McInstrParser.ExpressionUnaryLogicContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 430
                self.match(McInstrParser.Not)
                self.state = 431
                self.expr(5)
                pass

            elif la_ == 13:
                localctx = McInstrParser.ExpressionPreviousContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 432
                self.match(McInstrParser.Previous)
                pass

            elif la_ == 14:
                localctx = McInstrParser.ExpressionMyselfContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 433
                self.match(McInstrParser.Myself)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 483
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,56,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 481
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,55,self._ctx)
                    if la_ == 1:
                        localctx = McInstrParser.ExpressionExponentiationContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.base = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 436
                        if not self.precpred(self._ctx, 18):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 18)")
                        self.state = 437
                        self.match(McInstrParser.Caret)
                        self.state = 438
                        localctx.exponent = self.expr(18)
                        pass

                    elif la_ == 2:
                        localctx = McInstrParser.ExpressionBinaryMDContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 439
                        if not self.precpred(self._ctx, 17):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 17)")
                        self.state = 440
                        _la = self._input.LA(1)
                        if not(_la==105 or _la==106):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 441
                        localctx.right = self.expr(18)
                        pass

                    elif la_ == 3:
                        localctx = McInstrParser.ExpressionBinaryPMContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 442
                        if not self.precpred(self._ctx, 16):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 16)")
                        self.state = 443
                        _la = self._input.LA(1)
                        if not(_la==103 or _la==104):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 444
                        localctx.right = self.expr(17)
                        pass

                    elif la_ == 4:
                        localctx = McInstrParser.ExpressionBinaryModContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 445
                        if not self.precpred(self._ctx, 15):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 15)")
                        self.state = 446
                        self.match(McInstrParser.Mod)
                        self.state = 447
                        localctx.right = self.expr(16)
                        pass

                    elif la_ == 5:
                        localctx = McInstrParser.ExpressionBinaryRightShiftContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 448
                        if not self.precpred(self._ctx, 14):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 14)")
                        self.state = 449
                        self.match(McInstrParser.T__1)
                        self.state = 450
                        localctx.right = self.expr(15)
                        pass

                    elif la_ == 6:
                        localctx = McInstrParser.ExpressionBinaryLeftShiftContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 451
                        if not self.precpred(self._ctx, 13):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 13)")
                        self.state = 452
                        self.match(McInstrParser.T__2)
                        self.state = 453
                        localctx.right = self.expr(14)
                        pass

                    elif la_ == 7:
                        localctx = McInstrParser.ExpressionBinaryNotEqualContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 454
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 455
                        self.match(McInstrParser.NotEqual)
                        self.state = 456
                        localctx.right = self.expr(12)
                        pass

                    elif la_ == 8:
                        localctx = McInstrParser.ExpressionBinaryEqualContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 457
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 458
                        self.match(McInstrParser.Equal)
                        self.state = 459
                        localctx.right = self.expr(11)
                        pass

                    elif la_ == 9:
                        localctx = McInstrParser.ExpressionBinaryLessEqualContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 460
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 461
                        self.match(McInstrParser.LessEqual)
                        self.state = 462
                        localctx.right = self.expr(10)
                        pass

                    elif la_ == 10:
                        localctx = McInstrParser.ExpressionBinaryGreaterEqualContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 463
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 464
                        self.match(McInstrParser.GreaterEqual)
                        self.state = 465
                        localctx.right = self.expr(9)
                        pass

                    elif la_ == 11:
                        localctx = McInstrParser.ExpressionBinaryLessContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 466
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 467
                        self.match(McInstrParser.Less)
                        self.state = 468
                        localctx.right = self.expr(8)
                        pass

                    elif la_ == 12:
                        localctx = McInstrParser.ExpressionBinaryGreaterContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 469
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 470
                        self.match(McInstrParser.Greater)
                        self.state = 471
                        localctx.right = self.expr(7)
                        pass

                    elif la_ == 13:
                        localctx = McInstrParser.ExpressionBinaryLogicContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 472
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 473
                        _la = self._input.LA(1)
                        if not(_la==130 or _la==131):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 474
                        localctx.right = self.expr(5)
                        pass

                    elif la_ == 14:
                        localctx = McInstrParser.ExpressionTrinaryLogicContext(self, McInstrParser.ExprContext(self, _parentctx, _parentState))
                        localctx.test = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 475
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 476
                        self.match(McInstrParser.Question)
                        self.state = 477
                        localctx.true_ = self.expr(0)
                        self.state = 478
                        self.match(McInstrParser.Colon)
                        self.state = 479
                        localctx.false_ = self.expr(4)
                        pass

             
                self.state = 485
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,56,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class ShellContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Shell(self):
            return self.getToken(McInstrParser.Shell, 0)

        def StringLiteral(self):
            return self.getToken(McInstrParser.StringLiteral, 0)

        def getRuleIndex(self):
            return McInstrParser.RULE_shell

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitShell" ):
                return visitor.visitShell(self)
            else:
                return visitor.visitChildren(self)




    def shell(self):

        localctx = McInstrParser.ShellContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_shell)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 486
            self.match(McInstrParser.Shell)
            self.state = 487
            self.match(McInstrParser.StringLiteral)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SearchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return McInstrParser.RULE_search

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class SearchPathContext(SearchContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.SearchContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Search(self):
            return self.getToken(McInstrParser.Search, 0)
        def StringLiteral(self):
            return self.getToken(McInstrParser.StringLiteral, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSearchPath" ):
                return visitor.visitSearchPath(self)
            else:
                return visitor.visitChildren(self)


    class SearchShellContext(SearchContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a McInstrParser.SearchContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Search(self):
            return self.getToken(McInstrParser.Search, 0)
        def Shell(self):
            return self.getToken(McInstrParser.Shell, 0)
        def StringLiteral(self):
            return self.getToken(McInstrParser.StringLiteral, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSearchShell" ):
                return visitor.visitSearchShell(self)
            else:
                return visitor.visitChildren(self)



    def search(self):

        localctx = McInstrParser.SearchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_search)
        try:
            self.state = 494
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,57,self._ctx)
            if la_ == 1:
                localctx = McInstrParser.SearchPathContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 489
                self.match(McInstrParser.Search)
                self.state = 490
                self.match(McInstrParser.StringLiteral)
                pass

            elif la_ == 2:
                localctx = McInstrParser.SearchShellContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 491
                self.match(McInstrParser.Search)
                self.state = 492
                self.match(McInstrParser.Shell)
                self.state = 493
                self.match(McInstrParser.StringLiteral)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Unparsed_blockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def UnparsedBlock(self):
            return self.getToken(McInstrParser.UnparsedBlock, 0)

        def getRuleIndex(self):
            return McInstrParser.RULE_unparsed_block

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnparsed_block" ):
                return visitor.visitUnparsed_block(self)
            else:
                return visitor.visitChildren(self)




    def unparsed_block(self):

        localctx = McInstrParser.Unparsed_blockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_unparsed_block)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 496
            self.match(McInstrParser.UnparsedBlock)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[36] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 18)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 17)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 16)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 15)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 14)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 13)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 11)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 10)
         

            if predIndex == 8:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 9:
                return self.precpred(self._ctx, 8)
         

            if predIndex == 10:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 11:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 12:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 13:
                return self.precpred(self._ctx, 3)
         




