import re
import requests

def hash_function(s):
    """Hash function for alphanumeric strings"""
    if s is None:
        return None
    s = str(s).upper()
    s = re.sub(r'[^A-Z0-9]', '', s)
    base36_map = {ch: idx for idx, ch in enumerate("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ")}
    result = 0
    for i, ch in enumerate(reversed(s)):
        result += base36_map.get(ch, 0) * (36 ** i)
    result += len(s) * (36 ** (len(s) + 1))
    return result


def send_email_no_attachment(p, endpoint_url=None, access_token=None):
    """
    Send email via POST API without attachment.

    Parameters:
        p (dict): {
            "to": str | list[str],
            "subject": str,
            "body": str,
            "headers": dict (optional),
            "timeout": int (optional)
        }
        endpoint_url (str): API endpoint for sending mail
        access_token (str): Bearer token

    Returns:
        (status_code, response_text) or (None, error_message)
    """
    if not endpoint_url:
        raise ValueError("endpoint_url is required")
    if not access_token:
        raise ValueError("access_token is required")

    missing = [k for k in ("to", "subject", "body") if not p.get(k)]
    if missing:
        return None, f"Missing required fields: {', '.join(missing)}"

    payload = {
        "to": ";".join(p["to"]) if isinstance(p["to"], list) else p["to"],
        "subject": p["subject"],
        "body": p["body"],
    }

    headers = {
        "Authorization": f"Bearer {access_token}",
        **p.get("headers", {})
    }

    try:
        resp = requests.post(
            endpoint_url,
            json=payload,
            headers=headers,
            timeout=p.get("timeout", 15)
        )
        success_codes = (200, 201, 202)
        return resp.status_code, resp.text
    except requests.RequestException as e:
        return None, str(e)

