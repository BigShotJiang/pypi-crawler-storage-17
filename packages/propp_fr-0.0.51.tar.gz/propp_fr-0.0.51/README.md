# Propp_fr

Pattern Recognition and Ontologies for Prose Processing

Natural Language Processing Pipeline for French Literary Works
