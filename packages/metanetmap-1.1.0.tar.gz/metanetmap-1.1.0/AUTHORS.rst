=======
Credits
=======

Development Lead
----------------

* Coralie Muller <coralie.muller@inria.fr> https://orcid.org/0000-0002-5186-1666

Contributors
------------

* Sylvain Prigent https://orcid.org/0000-0001-5146-0347

* Clémence Frioux https://orcid.org/0000-0003-2114-0697


