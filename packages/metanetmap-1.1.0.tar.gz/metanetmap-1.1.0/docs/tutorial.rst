Tutorial: Exploring MetaNetMap with toy data
=================================================

Please refer to the notebook `MetaNetMap.ipynb` in the `notebook` folder of the `GitHub repository <https://github.com/coraliemuller/metanetmap>`_ for a step-by-step guide on how to use MetaNetMap with example data.