# SharePoint API Python Client – Documentation

This repository provides a lightweight Python client for interacting with SharePoint sites via SharePoint's REST API. The library handles NTLM authentication, list operations, file management, and time registration while abstracting SharePoint-specific implementation details.

## Dependencies
- Python ≥3.9
- requests ≥2.32.2
- requests-ntlm ≥1.3.0

## Installation

```bash
pip install sharepoint-api
```

Or install from source:

```bash
git clone https://github.com/your-org/nc-devops-sharepoint-v1-api.git
cd nc-devops-sharepoint-v1-api
pip install -e .
```

## Authentication & Initialization
The client uses NTLM authentication via `requests-ntlm`. Choose between two initialization methods:

### Quick Initialization
```python
from sharepoint_api.SharePointAPI import SharePointAPI

creds = {
    "username": "your_user",
    "password": "your_password",
    "sharepoint_url": "https://your.sharepoint.com",
    "proxies": {}
}

# Recommended compact initialization (bypasses normal constructor)
sp: SharePointAPI = SharePointAPI._compact_init(creds)
```

### Full Initialization
```python
from requests_ntlm import HttpNtlmAuth
from sharepoint_api.SharePointAPI import SharePointAPI

sp = SharePointAPI(
    sharepoint_url="https://your.sharepoint.com",
    auth=HttpNtlmAuth("your_user", "your_password"),
    proxies={}
)
```

## Core Operations

### List Operations
```python
from sharepoint_api.SharePointList import SharePointList

# Get all lists in a site
site = "YOUR_SITE"
lists: list[SharePointList] = sp.get_lists(site)

# Access specific list
cases: SharePointList = sp.get_list_by_name(site, "Sager")
print(cases.Title)

# Filter items with CAML queries
filters = ' and '.join([
    "(TeamId == '3')",
    "(Status == '11 - Modtaget')",
    "((Status != '90 - Lukket') and (Status != '91 - Afvist'))"
])
filtered_items = sp.get_list_by_name(site, "Sager", filters).all_items
```

### File Operations
```python
from sharepoint_api.SharePointList import SharePointListItem

# Upload file
item: SharePointListItem = sp.upload_file(
    site="cases",
    folder="Documents",
    file_name="report.pdf",
    file_path="/local/path/report.pdf"
)

# Download file
sp.download_file(
    site="cases",
    file_url=item.FileRef,
    download_path="./downloads/report.pdf"
)

# Copy file
copy_result = sp.copy_file(
    site="cases",
    source_url=item.FileRef,
    target_folder="Archive",
    new_name="report_2023.pdf"
)

# Delete file
sp.delete_file(site="cases", file_url=item.FileRef)
```

### Folder Management
```python
# Check folder existence
if not sp.folder_exists(site="cases", folder_path="Documents/Archived"):
    sp.create_new_folder(site="cases", folder_path="Documents/Archived")
```

### Time Registration
```python
time_list = sp.get_time_registration_list_by_name(site="HR", list_name="TimeRegistrations")
entries = time_list.get_items(select=["Title", "Hours", "Date"])
for entry in entries:
    print(f"{entry.Date}: {entry.Hours} hours - {entry.Title}")
```

### Version History
```python
item = sp.get_list_by_name(site="Legal", list_name="Contracts").get_item_by_id(42)
versions = sp.get_item_versions(item)
print(f"Item has {len(versions)} versions:")
for v in versions:
    print(f"Version {v.VersionLabel} by {v.CreatedBy}")
```
