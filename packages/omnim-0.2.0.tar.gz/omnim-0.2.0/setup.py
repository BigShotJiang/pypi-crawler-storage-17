from setuptools import setup

setup(
    name="omnim",
    url="https://github.com/cet-t/omnim",
    version="0.2.0",
    description="useful toolkit",
    author="cet",
    packages=["omnim"],
    include_package_data=True,
    zip_safe=True,
)
