# mathtypes

A simple package that provides you math types like fraction

## Installation
```bash
pip install mathtypes
```
<!-- ## Usage -->
