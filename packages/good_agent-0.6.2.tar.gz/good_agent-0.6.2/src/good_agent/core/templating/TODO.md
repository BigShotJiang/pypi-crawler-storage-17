
- [ ] Full Test Suite for Templating Engine
- [ ] Add comments/documentation
- [ ] Templating environment - global vs context. What about context vars and some kind of "get_template_env" function?
