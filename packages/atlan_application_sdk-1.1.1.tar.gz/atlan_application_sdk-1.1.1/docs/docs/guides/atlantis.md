# Custom App Frontends with Atlantis

The `frontend` directory in the app is designated to be used to add frontends for your application.

As of today, you can build this frontend using any frontend framework.

More information about Atlantis will be available soon.