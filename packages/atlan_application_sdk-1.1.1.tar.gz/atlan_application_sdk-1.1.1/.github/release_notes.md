## v1.1.1 (December 17, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v1.1.0...v1.1.1

### Bug Fixes

- pushing logs to atlan-objectstore (#894) (by @Garavitey in [76fec72](https://github.com/atlanhq/application-sdk/commit/76fec72))
- windows path normalization for prefix download (#895) (by @inishchith in [df99afe](https://github.com/atlanhq/application-sdk/commit/df99afe))
