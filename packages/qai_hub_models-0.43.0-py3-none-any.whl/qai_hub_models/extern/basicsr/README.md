BasicSR is not compatible with recently released PyTorch and Python (3.13+) versions.
We have copied minimal required functions here for use by some models.

Copied code license: https://github.com/XPixelGroup/BasicSR/blob/8d56e3a045f9fb3e1d8872f92ee4a4f07f886b0a/LICENSE.txt
