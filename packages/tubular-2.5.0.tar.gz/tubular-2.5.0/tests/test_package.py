def test_tubular_is_importable():
    "import of full package was failing, so added simple test that this succeeds"
    try:
        pass
    except Exception as e:
        raise e
