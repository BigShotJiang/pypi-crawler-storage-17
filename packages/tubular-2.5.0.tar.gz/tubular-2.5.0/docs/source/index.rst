.. tubular documentation master file, created by
   sphinx-quickstart on Mon Apr  7 13:47:38 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to tubular's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   API Documentation <tubular>

.. toctree::
   :maxdepth: 1

   Changelog <changelog>
   Contributing <contributing>
   Code of Conduct <code-of-conduct>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`