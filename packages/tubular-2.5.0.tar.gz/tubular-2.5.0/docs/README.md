# This is a guide of how to create an auto doc from sphinx

Steps:
*   Create a new foldor called docs with mkdir docs
*   Create the requirements.txt in the docs with all the sphinx requirements you need
*   Run the sphinx-quickstart
*   Change conf.py
*   cd docs --> sphinx-apidoc -o . ../tubular