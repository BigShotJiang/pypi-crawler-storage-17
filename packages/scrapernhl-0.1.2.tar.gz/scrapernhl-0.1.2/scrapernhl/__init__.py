"""NHL data scraping package"""

__version__ = "0.1.2"

# Import main scraper functions for easy access
from .scraper import *

__all__ = ['scraper']
