"""Salt-Bundle external pillar modules."""
