from .global_val import VERSION

__version__ = VERSION
