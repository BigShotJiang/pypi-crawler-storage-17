"""Capabilities defined in fabricatio-digest."""
