"""A extension for fabricatio, providing capabilities to handle raw requirment, digesting it into a task list."""
