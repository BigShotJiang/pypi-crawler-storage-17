"""Actions defined in fabricatio-digest."""
