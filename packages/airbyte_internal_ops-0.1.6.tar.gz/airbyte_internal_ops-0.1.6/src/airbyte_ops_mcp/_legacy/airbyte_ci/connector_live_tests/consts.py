# Copyright (c) 2024 Airbyte, Inc., all rights reserved.
from __future__ import annotations

MAX_LINES_IN_REPORT = 1000
