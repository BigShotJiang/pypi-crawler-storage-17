"""Tests for awesome_python_template package."""
