from .keyable import Keyable
from .named import Named

__all__ = [
    "Keyable",
    "Named",
]
