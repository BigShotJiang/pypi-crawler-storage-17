def spot_name(base: str, quote: str) -> str:
  return f'{base}{quote}'

def perp_name(base: str, quote: str) -> str:
  return f'{base}_{quote}'