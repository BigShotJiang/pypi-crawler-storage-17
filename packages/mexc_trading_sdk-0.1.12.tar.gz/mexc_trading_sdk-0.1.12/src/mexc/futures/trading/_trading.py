from dataclasses import dataclass
from mexc.futures.core import AuthFuturesMixin

@dataclass
class Trading(AuthFuturesMixin):
  ...