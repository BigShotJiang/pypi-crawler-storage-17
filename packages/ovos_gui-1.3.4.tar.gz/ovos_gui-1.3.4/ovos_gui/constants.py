from ovos_config.locations import get_xdg_cache_save_path

GUI_CACHE_PATH = get_xdg_cache_save_path('ovos_gui')

