from pathlib import Path

VLMRUN_HUB_PATH = Path(__file__).parent
VLMRUN_HUB_CATALOG_PATH = VLMRUN_HUB_PATH / "catalog.yaml"
VLMRUN_HUB_CONTRIB_CATALOG_PATH = VLMRUN_HUB_PATH / "schemas" / "contrib" / "catalog.yaml"
