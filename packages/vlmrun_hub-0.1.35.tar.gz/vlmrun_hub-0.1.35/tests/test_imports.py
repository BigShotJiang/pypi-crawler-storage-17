def test_standalone_import():
    from vlmrun import hub  # noqa: F401
