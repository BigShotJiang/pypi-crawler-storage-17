"""ML Space (MLS) Package Initialization Module.

Этот модуль инициализирует пакет `allocation` и определяет его публичный интерфейс.
"""
