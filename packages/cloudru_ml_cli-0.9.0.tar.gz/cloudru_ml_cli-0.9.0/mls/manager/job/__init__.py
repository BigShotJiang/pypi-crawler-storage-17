"""ML Space (MLS) Package Initialization Module.

Этот модуль инициализирует пакет `job` и определяет его публичный интерфейс.
"""
