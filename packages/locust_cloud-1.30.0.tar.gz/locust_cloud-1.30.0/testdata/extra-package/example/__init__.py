def hello():
    print("Hello from the example package!")
