"""Tests for utt-project-summary plugin."""
