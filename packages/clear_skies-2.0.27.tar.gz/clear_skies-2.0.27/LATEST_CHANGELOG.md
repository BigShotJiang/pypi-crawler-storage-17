## [2.0.27] - 2025-12-17

### Added
- Add grahpql backend by @cmancone in [#48](https://github.com/clearskies-py/clearskies/pull/48)
- Add grahpql backend

### Changed
- Update docstrings
- Inject the default client by name

### Fixed
- Use requests auth instead of headers
- Use the built-in functions of clearskies now
- Fix various bugs around the many2many columns by @cmancone in [#47](https://github.com/clearskies-py/clearskies/pull/47)
- Fix various bugs around the many2many columns

