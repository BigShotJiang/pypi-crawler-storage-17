# Define the version number
__version__ = "1.1.0"
