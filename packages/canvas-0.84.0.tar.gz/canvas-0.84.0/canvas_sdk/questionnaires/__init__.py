from .utils import from_yaml as questionnaire_from_yaml

__all__ = __exports__ = ("questionnaire_from_yaml",)
