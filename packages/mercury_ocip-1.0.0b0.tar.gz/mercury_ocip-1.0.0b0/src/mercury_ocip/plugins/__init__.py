from mercury_ocip.plugins.base_plugin import BasePlugin

__all__ = ["BasePlugin"]
