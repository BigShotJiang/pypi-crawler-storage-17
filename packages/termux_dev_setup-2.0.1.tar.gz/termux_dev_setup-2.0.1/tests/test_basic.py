def test_import():
    import termux_dev_setup
    assert termux_dev_setup is not None
