# Rekord.io Python SDK

[![PyPI version](https://badge.fury.io/py/rekord-io-sdk.svg)](https://badge.fury.io/py/rekord-io-sdk)

Official Python SDK for [Rekord.io](https://rekord.io).

Rekord.io provides a trust layer for verifiable data, anchoring data on-chain to create immutable, audit-ready records for regulatory compliance and data integrity.

## Installation

Install via pip:

```bash
pip install rekord-io-sdk
```

## Configuration

The SDK uses `rekord_sdk.Configuration` to manage API credentials and endpoints.

### Authentication

Rekord.io uses **Auth0 OAuth2 Client Credentials Flow**. You will need:

- Client ID
- Client Secret
- Auth0 Domain
- Audience

## Usage Example

Here is a basic example of how to initialize the client and authenticate.

```python
import os
import rekord_sdk
from rekord_sdk.rest import ApiException

# 1. Configure
configuration = rekord_sdk.Configuration()
configuration.host = "https://api-v2-dev.rekord.io"

# 2. Authenticate (You need to handle OAuth2 token retrieval separately)
# This SDK expects a Bearer token in the configuration
# See full integration example below for Auth0 handling

# Example: setting a token (you would get this from Auth0)
access_token = "YOUR_ACCESS_TOKEN"

# Override auth settings to inject the token
original_auth_settings = configuration.auth_settings

def auth_settings_with_token():
    settings = original_auth_settings()
    settings["bearerAuth"] = {
        "type": "bearer",
        "in": "header",
        "key": "Authorization",
        "value": f"Bearer {access_token}",
    }
    return settings

configuration.auth_settings = auth_settings_with_token

# 3. Create API Client
api_client = rekord_sdk.ApiClient(configuration)
passport_api = rekord_sdk.PassportApi(api_client)

# 4. Create a Passport
try:
    artifact = {
        "json": {"event": "market_data", "price": 50000},
        "filename": "btc_price_20240101.json",
        "mimeType": "application/json"
    }

    body = {
        "passport_label": "my-daily-passport-20240101",
        "artifacts": [artifact]
    }

    response = passport_api.passport_create_post(body=body)
    print("Passport Created:", response)

except ApiException as e:
    print(f"Exception when calling PassportApi->passport_create_post: {e}")
```

## Features

- **Passports**: Create and manage daily data containers.
- **Artifacts**: Append immutable data files to passports.
- **Verification**: Verify data integrity against blockchain anchors.

## Requirements

- Python 3.4+
- `urllib3` >= 1.15
- `six` >= 1.10
- `certifi`
- `python-dateutil`

## License

MIT
