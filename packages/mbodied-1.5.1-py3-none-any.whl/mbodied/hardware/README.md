Note: HardwareInteface and SimInterface are deprecated. Please use the new classes in ``mbodied/robot/``.
