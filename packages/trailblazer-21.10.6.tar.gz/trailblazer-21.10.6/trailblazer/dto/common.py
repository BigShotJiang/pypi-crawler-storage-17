from enum import StrEnum


class SortOrder(StrEnum):
    ASC: str = "asc"
    DESC: str = "desc"
