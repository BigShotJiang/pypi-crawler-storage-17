from trailblazer.exc import TrailblazerError


class UserTokenVerificationError(TrailblazerError):
    pass


class GoogleCertsError(TrailblazerError):
    pass
