class GoogleOAuthClientError(Exception):
    pass
