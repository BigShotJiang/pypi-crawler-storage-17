from trailblazer.store.store import Store


class MockStore(Store):
    """Instance of a mock Store."""
