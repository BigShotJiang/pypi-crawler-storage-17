Changelog
=========

0.1.3 (2023-10-12)
------------------

**Added**

- 📏 Introduced `overlaps` and `contains` functionality.


0.0.1 (2023-10-04)
------------------

**Added**

- 🌱 Create a simple and minimal `Interval` object having duration and degeneracy information.