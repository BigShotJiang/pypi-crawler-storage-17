import{a1 as a}from"./_plugin-vue_export-helper-BRjKvGBy.js";const r=a("v-spacer","div","VSpacer");export{r as V};
