# Changelog

## [0.2.3](https://github.com/Pushikoo/Pushikoo/compare/pushikoo-v0.2.2...pushikoo-v0.2.3) (2025-12-19)


### Bug Fixes

* **cron:** edit ineffective ([8bef3f4](https://github.com/Pushikoo/Pushikoo/commit/8bef3f407303305d1fbb34b031d4a35e9a9d7256))

## [0.2.2](https://github.com/Pushikoo/Pushikoo/compare/pushikoo-v0.2.1...pushikoo-v0.2.2) (2025-12-19)


### Bug Fixes

* **api:** replace get_object_by_id with get() in instance API ([9711721](https://github.com/Pushikoo/Pushikoo/commit/9711721980dbb2761ee02a17b6427d95479b99bb))

## [0.2.1](https://github.com/Pushikoo/Pushikoo/compare/pushikoo-v0.2.0...pushikoo-v0.2.1) (2025-12-19)


### Continuous Integration

* update release-please workflow outputs and versioning setup ([3c5f08d](https://github.com/Pushikoo/Pushikoo/commit/3c5f08defac740adf0b45b2b2485482949ce0359))
