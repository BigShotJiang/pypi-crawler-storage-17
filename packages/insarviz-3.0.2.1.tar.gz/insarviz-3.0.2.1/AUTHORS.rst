Contributors
============

Here are a list of people that work, or have worked, on insarviz.

* UGA stands for University Grenoble Alpes (https://www.univ-grenoble-alpes.fr/).
* ISTerre stands for Institut des Sciences de la Terre (https://www.isterre.fr).
* LIG stands for Laboratoire d'Informatique de Grenoble (http://www.liglab.fr/).

Current contributors
--------------------

Alphabetic order of last name : 

* Renaud Blanch (LIG/UGA) Renaud.Blanch@imag.fr
* Marc Coiffier (ISTerre/CNRS) marc.coiffier@univ-grenoble-alpes.fr
* Erwan Pathier (ISTERRE/UGA) erwan.pathier@univ-grenoble-alpes.fr
* Franck Thollard (ISTerre/CNRS) franck.thollard@univ-grenoble-alpes.fr

Former contributors
-------------------

* Augustin Bengolea
* Romain Montel
* Margaux Mouchené (ISTERRE/LIG/CNRS) margaux.mouchene@univ-grenoble-alpes.fr
* Colin Thomas (ISTERRE/CNRS) colin.thomas1@univ-grenoble-alpes.fr

Contact
-------

Franck Thollard <franck.thollard@univ-grenoble-alpes.fr>

