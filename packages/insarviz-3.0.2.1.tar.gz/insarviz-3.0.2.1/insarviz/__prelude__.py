from .__logging__ import logger
from platformdirs import PlatformDirs
from .version     import version

insarviz_dirs = PlatformDirs("InsarViz", "ISTerre-Cycle")
