#!/usr/bin/env python
"""
back compatible
"""
from .wxutils import *
