Analyze the previous context (code, command output, or conversation) and explain it clearly.
Focus on:
1. What is happening?
2. Why is it happening?
3. Key concepts involved.
4. Potential issues or improvements (if applicable).

Keep the explanation concise but thorough.
