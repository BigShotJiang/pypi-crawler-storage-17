from .plugin_loader import PluginLoader


loader = PluginLoader()
loader.load()
