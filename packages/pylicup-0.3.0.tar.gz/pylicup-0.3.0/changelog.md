## v0.3.0 (2025-12-17)

### Feat

- Added support for python 3.14

## v0.2.0 (2025-12-01)

### Feat

- Replaced poetry with pixi; Updated dependencies

## v0.1.2 (2023-03-29)

### Fix

- License text gets now between a comment block

## v0.1.1 (2023-03-29)

### Fix

- Small fixes on the license manager

## v0.1.0 (2023-03-29)

### Feat

- Moved files into module

## v0.0.1 (2021-10-01)
