from pathlib import Path

_tests_module = Path(__file__).parent
test_results = _tests_module  / "test_results"
test_data = _tests_module / "test_data"