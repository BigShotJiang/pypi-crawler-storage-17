############
Installation
############

`seppy` requires python >= 3.9.

It can be installed from `PyPI <https://pypi.org/project/seppy/>`_ using:

.. code:: bash

    pip install seppy