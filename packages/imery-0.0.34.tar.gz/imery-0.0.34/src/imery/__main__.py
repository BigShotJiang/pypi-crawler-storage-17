"""
Entry point for running imery as a module: python -m imery
"""

from imery.app import main

if __name__ == "__main__":
    main()
