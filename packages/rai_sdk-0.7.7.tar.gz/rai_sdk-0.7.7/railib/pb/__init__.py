# workaround https://github.com/protocolbuffers/protobuf/issues/3430
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))
