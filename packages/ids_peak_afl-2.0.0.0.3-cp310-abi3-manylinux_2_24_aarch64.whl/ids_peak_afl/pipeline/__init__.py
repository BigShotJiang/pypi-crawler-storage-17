from ids_peak_afl.pipeline.modules.basic_auto_features import (
    BasicAutoFeatures)