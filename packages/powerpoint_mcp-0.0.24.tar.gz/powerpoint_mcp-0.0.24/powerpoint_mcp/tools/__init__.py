"""
PowerPoint MCP Tools

Collection of tools for PowerPoint automation.
"""

from .manage_slide import powerpoint_manage_slide