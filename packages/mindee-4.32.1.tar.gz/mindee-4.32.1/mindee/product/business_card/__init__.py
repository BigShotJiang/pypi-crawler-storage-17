from mindee.product.business_card.business_card_v1 import BusinessCardV1
from mindee.product.business_card.business_card_v1_document import (
    BusinessCardV1Document,
)

__all__ = [
    "BusinessCardV1",
    "BusinessCardV1Document",
]
