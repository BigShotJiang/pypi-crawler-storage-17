from mindee.product.fr.carte_grise.carte_grise_v1 import CarteGriseV1
from mindee.product.fr.carte_grise.carte_grise_v1_document import (
    CarteGriseV1Document,
)

__all__ = [
    "CarteGriseV1",
    "CarteGriseV1Document",
]
