from mindee.parsing.common.ocr.ocr import Ocr

__all__ = ["Ocr"]
