"""This package is for integration tests.

Unit tests live side-by-side with tested modules.
"""
