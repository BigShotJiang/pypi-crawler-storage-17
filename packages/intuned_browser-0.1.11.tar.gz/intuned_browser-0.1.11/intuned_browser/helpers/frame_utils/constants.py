IFRAME_TAGS = ["iframe", "frame"]

ALL_IFRAMES_CSS_SELECTOR = ", ".join(IFRAME_TAGS)
