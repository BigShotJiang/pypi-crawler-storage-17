# Sadə nümunə sözlər: English → Azerbaijani
WORDS = {
    "apple": "alma",
    "banana": "banan",
    "cat": "pişik",
    "dog": "it",
    "house": "ev",
    "car": "maşın",
    "tree": "ağac",
    "water": "su",
    "sun": "günəş",
    "moon": "ay",
    "be": "olmaq",
    "and": "və",
    "in": "icinde",
    "to": "üçün",
    "have": "var",
    "it": "o",
    "I": "Men",
    "that": "ki",
    "for": "üçün"
}
