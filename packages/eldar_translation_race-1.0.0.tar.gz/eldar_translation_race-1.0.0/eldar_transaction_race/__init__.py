from .game import TranslationRace
