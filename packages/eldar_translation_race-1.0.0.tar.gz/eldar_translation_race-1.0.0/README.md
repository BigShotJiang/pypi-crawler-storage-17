# Eldar Translation Race

CLI Translation Race Game (Tərcümə Yarışı)

## Install
```bash
pip install eldar-translation-race
