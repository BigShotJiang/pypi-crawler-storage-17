Licenses
========

This directory holds license and credit information for works the Jdaviz
package is derived from or distributes, and/or datasets.

The license file for the Jdaviz package itself is located in the root of
this repository.
