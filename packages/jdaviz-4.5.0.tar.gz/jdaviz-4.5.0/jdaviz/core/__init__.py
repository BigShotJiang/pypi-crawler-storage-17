# Import glue translators because this registers them - not used directly here
import glue_astronomy.translators as _glue_astronomy_translators  # noqa
