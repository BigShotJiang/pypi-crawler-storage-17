<template>
  <j-tray-plugin
    description='Download a data product from the Virtual Observatory'
    :link="'https://www.ivoa.net/astronomers/index.html'"
    :popout_button="popout_button">

    <v-row>
      <v-alert type="info">
        Virtual Observatory support has been moved to the loaders infrastructure.
      </v-alert>
    </v-row>
  </j-tray-plugin>
</template>

