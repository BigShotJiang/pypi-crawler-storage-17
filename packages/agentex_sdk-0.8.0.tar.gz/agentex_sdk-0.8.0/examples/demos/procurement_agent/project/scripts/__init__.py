"""Procurement agent scripts module."""
