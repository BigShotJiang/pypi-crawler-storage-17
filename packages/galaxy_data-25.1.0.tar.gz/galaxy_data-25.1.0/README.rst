
.. image:: https://badge.fury.io/py/galaxy-data.svg
   :target: https://pypi.org/project/galaxy-data/


Overview
--------

The Galaxy_ models, datatype framework, and datatype implementations.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
