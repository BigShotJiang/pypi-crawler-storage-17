"""Merge 2 head revisions after pulling 24.1 into dev

Revision ID: eee9229a9765
Revises: 570bce1e82f9, c63848676caf
Create Date: 2024-06-13 11:50:03.226676

"""

# revision identifiers, used by Alembic.
revision = "eee9229a9765"
down_revision = ("570bce1e82f9", "c63848676caf")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
