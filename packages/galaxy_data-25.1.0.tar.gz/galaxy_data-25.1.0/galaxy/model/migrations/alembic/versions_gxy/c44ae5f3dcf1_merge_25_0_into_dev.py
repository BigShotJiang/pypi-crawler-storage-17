"""Merge 25.0 into dev

Revision ID: c44ae5f3dcf1
Revises: fb16d09348db, c716ee82337b
Create Date: 2025-06-18 09:42:01.625882

"""

# revision identifiers, used by Alembic.
revision = "c44ae5f3dcf1"
down_revision = ("fb16d09348db", "c716ee82337b")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
