"""Merge alembic heads after pulling external_user_id length extension forward

Revision ID: 92fb564c7095
Revises: 987ce9839ecb, e93c5d0b47a9
Create Date: 2023-10-12 07:58:43.659168

"""

# revision identifiers, used by Alembic.
revision = "92fb564c7095"
down_revision = ("987ce9839ecb", "e93c5d0b47a9")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
