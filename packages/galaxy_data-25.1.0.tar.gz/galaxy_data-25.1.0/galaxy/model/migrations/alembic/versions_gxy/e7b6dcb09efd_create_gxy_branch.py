"""create gxy branch

Revision ID: e7b6dcb09efd
Revises:
Create Date: 2021-11-05 16:32:43.243049

"""

# revision identifiers, used by Alembic.
revision = "e7b6dcb09efd"
down_revision = None
branch_labels = ("gxy",)
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
