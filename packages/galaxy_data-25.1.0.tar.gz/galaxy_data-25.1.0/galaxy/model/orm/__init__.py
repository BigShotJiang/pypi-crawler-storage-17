"""
galaxy.model.orm - ORM-related functionality
"""
