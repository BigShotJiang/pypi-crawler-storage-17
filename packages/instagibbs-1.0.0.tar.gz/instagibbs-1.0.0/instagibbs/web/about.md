
The aim of instagibbs is to rapidly obtain $\Delta G$ and $\Delta \Delta G$ values from HDX-MS data both at the peptide and residue level. 

<!-- ΔG unicode? -->
Instagibbs version: $version

View instagibbs source on [GitHub](https://github.com/Jhsmit/instagibbs)

This website runs on [solara](https://solara.dev/)