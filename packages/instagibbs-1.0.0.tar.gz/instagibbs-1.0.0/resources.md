solara app example:
https://github.com/edd3x/urban_trees_app/blob/main/app.py


sidebar:
https://vuetifyjs.com/en/components/lists/#action-and-item-groups
https://github.com/widgetti/solara/blob/master/solara/website/components/sidebar.py#L5


deploy:
https://docs.railway.app/guides/start-command