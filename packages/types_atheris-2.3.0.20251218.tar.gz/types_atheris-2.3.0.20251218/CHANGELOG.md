## 2.3.0.20250306 (2025-03-06)

Update tools versions in `stubtest` workflow (#13582)

## 2.3.0.20240831 (2024-08-31)

Added types for atheris (#12462)

