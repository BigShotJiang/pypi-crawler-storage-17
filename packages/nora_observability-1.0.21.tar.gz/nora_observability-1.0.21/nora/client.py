"""
Nora Observability Client
자동으로 AI 라이브러리 호출을 trace하고 API로 전송합니다.
"""

import time
import threading
import inspect
import queue
from typing import Optional, Dict, Any, List, Callable, TypeVar
from datetime import datetime
import uuid
from contextvars import ContextVar
from functools import wraps

try:
    import requests
except ImportError:
    requests = None


# Context variables for trace grouping
_current_trace_group: ContextVar[Optional["TraceGroup"]] = ContextVar(
    "_current_trace_group", default=None
)

# Context variable for tracking current agent (for nested agent function calls)
_current_agent_context: ContextVar[Optional[str]] = ContextVar(
    "_current_agent_context", default=None
)

F = TypeVar("F", bound=Callable[..., Any])


class TraceGroup:
    """
    여러 LLM 호출을 하나의 논리적 그룹으로 묶는 컨텍스트.

    Context manager 또는 데코레이터로 사용 가능합니다.

    사용법 (Context Manager):
        with nora.trace_group(name="multi_agent_pipeline"):
            # 이 블록 안의 모든 LLM 호출이 그룹으로 묶임
            response1 = client.chat.completions.create(...)
            response2 = client.chat.completions.create(...)

    사용법 (데코레이터):
        @nora.trace_group(name="batch_process")
        async def generate():
            async for chunk in agent.streaming():
                yield chunk
    """

    def __init__(self, name: str, metadata: Optional[Dict[str, Any]] = None):
        self.group_id = str(uuid.uuid4())
        self.trace_id = None  # External API trace ID
        self.name = name
        self.metadata = metadata or {}
        self.start_time = None
        self.end_time = None
        self.traces = []
        self.execution_span_ids = []  # Track ExecutionSpan IDs for decision linking
        self._prev_auto_flush = None  # 이전 auto flush 상태 저장
        self._prev_trace_group = None  # 이전 trace_group 저장 (중첩 지원)

    def _aggregate_output(self) -> str:
        """Aggregate output from all traces in the group."""
        outputs = [trace.get("response", "") for trace in self.traces if trace.get("response")]
        return "\n".join(outputs) if outputs else ""

    def _aggregate_tokens(self) -> Dict[str, int]:
        """Aggregate token usage from all traces in the group."""
        total_tokens = 0
        prompt_tokens = 0
        completion_tokens = 0

        for trace in self.traces:
            tokens = trace.get("tokens_used")
            if tokens is None:
                tokens = 0
            total_tokens += tokens

            # Try to extract detailed token info from metadata if available
            metadata = trace.get("metadata", {})
            response_info = metadata.get("response", {})
            usage = response_info.get("usage", {})

            if usage:
                prompt_tokens += usage.get("prompt_tokens", 0)
                completion_tokens += usage.get("completion_tokens", 0)

        return {
            "total_tokens": total_tokens,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
        }

    def _calculate_cost(self) -> float:
        """Calculate total cost from all traces in the group."""
        # This is a placeholder - actual cost calculation would depend on provider pricing
        # You can implement custom cost calculation logic here
        return 0.0

    def __enter__(self):
        self.start_time = time.time()
        # 이전 trace_group 저장 (중첩 지원)
        self._prev_trace_group = _current_trace_group.get()
        _current_trace_group.set(self)

        # Create pending trace via API
        client = get_client()
        if client:
            self.trace_id = client._create_pending_trace(self.name, self.metadata)
            self._prev_auto_flush = getattr(client, "_auto_flush_enabled", True)
            client._auto_flush_enabled = False

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.end_time = time.time()
        # 이전 trace_group 복원 (중첩 지원)
        _current_trace_group.set(self._prev_trace_group)

        # Update trace to success status
        client = get_client()
        if client and self.trace_id:
            status = "error" if exc_type is not None else "success"
            # Aggregate data from all traces in the group
            output = self._aggregate_output()
            tokens = self._aggregate_tokens()
            cost = self._calculate_cost()

            client._update_trace_status(
                self.trace_id,
                status,
                self.start_time,
                self.end_time,
                output=output,
                tokens=tokens,
                cost=cost,
            )

        # 자동 플러시 재개
        flush_after_exit = False
        if client:
            if self._prev_auto_flush is not None:
                flush_after_exit = self._prev_auto_flush
                client._auto_flush_enabled = self._prev_auto_flush

        # trace_group 종료 시 적체된 trace를 바로 플러시 (데코레이터 사용 시에도 보장)
        if client and flush_after_exit and client._traces:
            client.flush()
        
        # Auto-aggregate decisions on trace_group exit
        if client:
            try:
                client._build_and_send_agent_answer_decisions()
            except Exception as e:
                print(f"[Nora] ⚠️ Decision aggregation failed: {e}")

        return False  # 예외를 재발생시킴

    async def __aenter__(self):
        """비동기 context manager 진입."""
        self.start_time = time.time()
        # 이전 trace_group 저장 (중첩 지원)
        self._prev_trace_group = _current_trace_group.get()
        _current_trace_group.set(self)

        # Create pending trace via API
        client = get_client()
        if client:
            self.trace_id = client._create_pending_trace(self.name, self.metadata)
            self._prev_auto_flush = getattr(client, "_auto_flush_enabled", True)
            client._auto_flush_enabled = False

        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """비동기 context manager 종료."""
        self.end_time = time.time()
        # 이전 trace_group 복원 (중첩 지원)
        _current_trace_group.set(self._prev_trace_group)

        # Update trace to success status
        client = get_client()
        if client and self.trace_id:
            status = "error" if exc_type is not None else "success"
            # Aggregate data from all traces in the group
            output = self._aggregate_output()
            tokens = self._aggregate_tokens()
            cost = self._calculate_cost()

            client._update_trace_status(
                self.trace_id,
                status,
                self.start_time,
                self.end_time,
                output=output,
                tokens=tokens,
                cost=cost,
            )

        # 자동 플러시 재개
        flush_after_exit = False
        if client:
            if self._prev_auto_flush is not None:
                flush_after_exit = self._prev_auto_flush
                client._auto_flush_enabled = self._prev_auto_flush

        # 비동기 컨텍스트 종료 시에도 적체된 trace를 즉시 플러시
        if client and flush_after_exit and client._traces:
            client.flush()
        
        # Auto-aggregate decisions on trace_group exit
        if client:
            try:
                client._build_and_send_agent_answer_decisions()
            except Exception as e:
                print(f"[Nora] ⚠️ Decision aggregation failed: {e}")

        return False  # 예외를 재발생시킴

    def __call__(self, func: F) -> F:
        """데코레이터로 사용될 때 호출됩니다."""
        group_name = self.name
        group_metadata = self.metadata

        def _new_group() -> "TraceGroup":
            meta_copy = dict(group_metadata) if isinstance(group_metadata, dict) else group_metadata
            return TraceGroup(name=group_name, metadata=meta_copy)

        # Async generator
        if inspect.isasyncgenfunction(func):

            @wraps(func)
            async def async_gen_wrapper(*args, **kwargs):
                group = _new_group()
                async with group:
                    async for item in func(*args, **kwargs):
                        yield item

            return async_gen_wrapper  # type: ignore

        # Generator
        elif inspect.isgeneratorfunction(func):

            @wraps(func)
            def gen_wrapper(*args, **kwargs):
                group = _new_group()
                with group:
                    yield from func(*args, **kwargs)

            return gen_wrapper  # type: ignore

        # Async function
        elif inspect.iscoroutinefunction(func):

            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                group = _new_group()
                async with group:
                    return await func(*args, **kwargs)

            return async_wrapper  # type: ignore

        # Sync function
        else:

            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                group = _new_group()
                with group:
                    return func(*args, **kwargs)

            return sync_wrapper  # type: ignore


class NoraClient:
    """
    Nora Observability 클라이언트

    Trace 데이터를 수집하고 배치로 API에 전송합니다.
    """

    def __init__(
        self,
        api_key: str,
        api_url: str = "https://noraobservabilitybackend-staging.up.railway.app/v1",
        batch_size: int = 10,
        flush_interval: float = 5.0,
        service_url: Optional[str] = None,
        environment: str = "default",
        semantics: Optional[Dict[str, Dict[str, List[str]]]] = None,
        agent_map: Optional[Dict[str, List[str]]] = None,
    ):
        """
        Args:
            api_key: Nora API 키
            api_url: Trace 데이터를 전송할 API 엔드포인트 URL
            batch_size: 한 번에 전송할 trace 개수 (기본값: 10)
            flush_interval: 자동 전송 간격(초) (기본값: 5.0)
            service_url: 외부 서비스 URL (선택사항, 나중에 외부 API 호출에 사용)
            environment: 환경 정보 (기본값: "default")
            semantics: span_kind 추론용 매핑 (예: {"retrieval": {"functions": [...], "classes": [...], "tools": [...]}})
            agent_map: 함수→에이전트 매핑 (예: {"research_agent": ["search_papers", "fetch_data"], "analysis_agent": [...]})
        """
        self.api_key = api_key
        self.api_url = api_url
        self.trace_create_url = f"{api_url}/traces/"
        self.execution_span_url = f"{api_url}/executions/"
        self.decision_create_url = f"{api_url}/decision/"
        self.service_url = service_url
        self.environment = environment
        self.semantics = semantics or {}
        self.agent_map = agent_map or {}
        self.project_id: Optional[str] = None
        self.organization_id: Optional[str] = None
        self.enabled = True
        self._auto_flush_enabled = True  # trace_group에서 제어 가능

        self._traces: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._last_flush = time.time()

        # Decisions background processing (prints instead of real API calls)
        self._decisions_enabled = True
        self._atomic_decisions: List[Dict[str, Any]] = []
        self._decision_queue: "queue.Queue[Dict[str, Any]]" = queue.Queue()
        self._decision_stop = threading.Event()
        self._decision_worker = threading.Thread(
            target=self._decision_worker_loop, name="nora-decision-worker", daemon=True
        )
        self._decision_worker.start()
        
        # Map trace_id -> list of execution_ids (for decision linking)
        self._trace_execution_ids: Dict[str, List[str]] = {}
        self._trace_exec_lock = threading.Lock()
        
        # Track active execution span threads to wait for completion during flush
        self._execution_threads: List[threading.Thread] = []
        self._execution_threads_lock = threading.Lock()
        
        # Map trace_id -> decision_id (for decision linking)
        self._trace_decision_ids: Dict[str, str] = {}
        self._decision_id_lock = threading.Lock()
        
        # Track last agent name for detecting agent changes
        self._last_agent_name: Optional[str] = None
        
        # Track most recent execution_id for each trace_id (for atomic linking)
        self._last_execution_id_per_trace: Dict[str, str] = {}
        self._last_exec_id_lock = threading.Lock()

        # Track per-trace execution order for matching execution_ids to atomics
        self._trace_execution_order: Dict[str, int] = {}
        
        # Track pending tool calls from LLM to group tool executions under same agent
        self._pending_tool_calls: Dict[str, str] = {}  # {tool_name: llm_agent_name}
        self._pending_tools_lock = threading.Lock()

    def _match_semantics(
        self,
        category: str,
        function_name: Optional[str],
        class_name: Optional[str],
        tool_names: List[str],
    ) -> bool:
        cfg = self.semantics.get(category, {})
        if function_name and function_name in cfg.get("functions", []):
            return True
        if class_name and class_name in cfg.get("classes", []):
            return True
        if any(t in cfg.get("tools", []) for t in tool_names):
            return True
        return False

    def _resolve_span_kind(
        self,
        span_kind: Optional[str],
        metadata: Optional[Dict[str, Any]],
        tool_calls: Optional[List[Dict[str, Any]]],
        provider: Optional[str],
        model: Optional[str],
    ) -> Optional[str]:
        # User-specified span_kind wins (free-form)
        if span_kind is not None:
            return span_kind

        md = metadata or {}
        function_name = md.get("function_name") if isinstance(md, dict) else None
        class_name = md.get("class_name") if isinstance(md, dict) else None
        tool_names = [
            tc.get("name")
            for tc in (tool_calls or [])
            if isinstance(tc, dict) and tc.get("name")
        ]

        # Semantics-based inference (optional)
        for category in ("retrieval", "router", "policy_eval"):
            if self._match_semantics(category, function_name, class_name, tool_names):
                return category

        # Default inference when nothing matches
        if tool_names:
            return "tool"
        if provider or model:
            return "llm"
        return None

    def trace(
        self,
        provider: str,
        model: str,
        prompt: Optional[str] = None,
        response: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None,
        tokens_used: Optional[int] = None,
        error: Optional[str] = None,
        finish_reason: Optional[str] = None,
        response_id: Optional[str] = None,
        system_fingerprint: Optional[str] = None,
        tool_calls: Optional[List[Dict[str, Any]]] = None,
        span_kind: Optional[str] = None,
        **extra_fields,
    ) -> None:
        """
        Trace 데이터를 수집합니다.

        Args:
            provider: AI 제공자 (openai, anthropic, etc.)
            model: 사용된 모델 이름
            prompt: 입력 프롬프트
            response: 응답 내용
            metadata: 추가 메타데이터
            start_time: 요청 시작 시간 (timestamp)
            end_time: 요청 종료 시간 (timestamp)
            tokens_used: 사용된 토큰 수
            error: 에러 메시지 (있는 경우)
            finish_reason: 완료 이유 (stop, length, tool_calls, etc.)
            response_id: API 응답 ID
            system_fingerprint: 시스템 fingerprint
            tool_calls: Tool/Function calls 정보
            span_kind: 사용자 지정 가능. 기본 추론 순서: semantics 매칭 → tool_calls 감지 시 "tool" → provider/model 존재 시 "llm" → 그 외 None
            **extra_fields: 추가 필드 (확장성)
        """
        if not self.enabled:
            return

        resolved_span_kind = self._resolve_span_kind(
            span_kind=span_kind,
            metadata=metadata,
            tool_calls=tool_calls,
            provider=provider,
            model=model,
        )

        trace_data = {
            "id": str(uuid.uuid4()),
            "timestamp": datetime.utcnow().isoformat(),
            "provider": provider,
            "model": model,
            "prompt": prompt,
            "response": response,
            "metadata": metadata or {},
            "start_time": start_time,
            "end_time": end_time,
            "duration": (end_time - start_time) if (start_time and end_time) else None,
            "tokens_used": tokens_used,
            "error": error,
            "finish_reason": finish_reason,
            "response_id": response_id,
            "system_fingerprint": system_fingerprint,
            "tool_calls": tool_calls,
            "environment": self.environment,
            "span_kind": resolved_span_kind,
        }

        # 추가 필드 병합
        trace_data.update(extra_fields)

        # 현재 활성화된 trace group 정보 추가
        current_group = get_current_trace_group()

        if current_group:
            if trace_data["metadata"] is None:
                trace_data["metadata"] = {}
            trace_data["metadata"]["trace_group"] = {
                "id": current_group.group_id,
                "name": current_group.name,
            }
            current_group.traces.append(trace_data)

            # Also keep a copy in client-level traces for aggregation APIs
            with self._lock:
                self._traces.append(trace_data)

            # Send execution span immediately if trace_id exists
            # _send_execution_span will extract execution_id from API response and store it
            if current_group.trace_id:
                print()
                self._send_execution_span(current_group.trace_id, trace_data)
                
                # Capture atomic decision for LLM tool calling
                self._maybe_capture_llm_tool_decision(
                    trace_data=trace_data,
                    trace_group_id=current_group.group_id,
                    trace_id=current_group.trace_id,
                )
            else:
                print("[Nora] ⚠️  WARNING: trace_id is None, cannot send execution span")
        else:
            # No trace_group: use old batch behavior
            with self._lock:
                self._traces.append(trace_data)

                # trace_group 내부에서는 자동 플러시 비활성화
                if not self._auto_flush_enabled:
                    return

                # 배치 크기나 시간 간격에 따라 자동 전송
                should_flush = (
                    len(self._traces) >= self._batch_size
                    or (time.time() - self._last_flush) >= self._flush_interval
                )

                if should_flush:
                    self._flush()

            # After standard trace handling, decisions aggregation can be scheduled on flush only

    def _flush(self, sync: bool = False) -> None:
        """수집된 trace 데이터를 API로 전송합니다.

        Args:
            sync: True면 동기적으로 전송 (기본값: False, 비동기 전송)
        """
        if not self._traces:
            return

        if not requests:
            # requests가 없으면 경고 출력 (한 번만)
            if not hasattr(self, "_warned_no_requests"):
                print("[Nora] Warning: 'requests' library not found. Install it to send traces.")
                self._warned_no_requests = True
            return

        traces_to_send = self._traces.copy()
        self._traces.clear()
        self._last_flush = time.time()

        if sync:
            # 동기적으로 전송 (테스트용)
            self._send_traces(traces_to_send)
        else:
            # 비동기로 전송 (메인 스레드 블로킹 방지)
            thread = threading.Thread(target=self._send_traces, args=(traces_to_send,), daemon=True)
            thread.start()

        # Wait for any pending execution span threads to complete (for decision linking)
        # Only wait if sync=True (for tests) or if we need execution_ids before building decisions
        with self._execution_threads_lock:
            threads_to_wait = [t for t in self._execution_threads if t.is_alive()]
        
        for t in threads_to_wait:
            t.join(timeout=2.0)  # Wait max 2 seconds per thread
        
        # Clean up finished threads
        with self._execution_threads_lock:
            self._execution_threads = [t for t in self._execution_threads if t.is_alive()]

        # After traces are sent, aggregate decisions (agent/answer) in background
        try:
            self._build_and_send_agent_answer_decisions()
        except Exception as e:
            print(f"[Nora] ⚠️ Decision aggregation failed: {e}")

    def _create_pending_trace(
        self, trace_name: str, metadata: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """Create a pending trace and return trace_id.

        Args:
            trace_name: Name of the trace
            metadata: Additional metadata for the trace

        Returns:
            trace_id from API response, or None if failed
        """
        if not requests:
            return None

        try:
            headers = {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            }

            # Build payload with required fields
            payload = {
                "trace_name": trace_name,
                "input": metadata.get("input", "") if metadata else "",
                "environment": self.environment,
            }

            # Add project_id if available
            if self.project_id:
                payload["project_id"] = self.project_id

            print(f"[Nora] 🔄 Creating pending trace '{trace_name}'")
            response = requests.post(
                self.trace_create_url, json=payload, headers=headers, timeout=10
            )


            if response.status_code in (200, 201):
                response_data = response.json()

                # Get trace_id from 'id' field in response
                trace_id = response_data.get("id")

                if not trace_id:
                    print(f"[Nora] ❌ ERROR: 'id' not found in response. Response: {response_data}")
                    return None

                print(f"[Nora] ✅ Created trace with ID: {trace_id}")
                return trace_id
            else:
                print(f"[Nora] ⚠️  Warning: Failed to create trace (status: {response.status_code})")
                print(f"[Nora] Response body: {response.text[:500]}")
                return None

        except requests.exceptions.RequestException as e:
            print(f"[Nora] ❌ Error creating trace: {str(e)}")
            return None
        except Exception as e:
            print(f"[Nora] ❌ Unexpected error creating trace: {str(e)}")
            return None

    def _update_trace_status(
        self,
        trace_id: str,
        status: str,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None,
        output: Optional[str] = None,
        tokens: Optional[Dict[str, int]] = None,
        cost: Optional[float] = None,
    ) -> None:
        """Update trace status to success or error.

        Args:
            trace_id: The trace ID to update
            status: New status (success, error)
            start_time: Trace start time
            end_time: Trace end time
            output: Aggregated output from all spans
            tokens: Token usage information
            cost: Total cost
        """
        if not requests or not trace_id:
            return

        try:
            headers = {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            }

            # Build URL with trace_id dynamically
            update_url = f"{self.api_url}/traces/{trace_id}"

            # Build payload with required fields
            payload = {
                "status": status,
            }

            # Add optional fields
            if output:
                payload["output"] = output

            if start_time and end_time:
                payload["latency"] = end_time - start_time

            if cost is not None:
                payload["cost"] = cost

            if tokens:
                payload["tokens"] = tokens

            print(f"[Nora] 🔄 Updating trace {trace_id} to status: {status}")
            response = requests.patch(update_url, json=payload, headers=headers, timeout=10)

            if response.status_code in (200, 201):
                print(f"[Nora] ✅ Successfully updated trace to {status}")
            else:
                print(f"[Nora] ⚠️  Warning: Failed to update trace (status: {response.status_code})")

        except requests.exceptions.RequestException as e:
            print(f"[Nora] ❌ Error updating trace: {str(e)}")
        except Exception as e:
            print(f"[Nora] ❌ Unexpected error updating trace: {str(e)}")

    def _parse_input_from_span(self, span_data: Dict[str, Any]) -> Optional[str]:
        """Try to extract a sensible `input` string from an execution span.

        Heuristics (in order):
        1. `metadata.request.parameters.input`
        2. `metadata.input`
        3. `prompt` field on span
        4. `metadata.request.messages` -> join `user` messages or take first message content
        Returns None when no candidate found.
        """
        try:
            if not isinstance(span_data, dict):
                return None

            md = span_data.get("metadata") or {}

            # 1) metadata.request.parameters.input
            try:
                req_params = (md.get("request") or {}).get("parameters")
                if isinstance(req_params, dict):
                    inp = req_params.get("input")
                    if inp:
                        return inp if isinstance(inp, str) else str(inp)
            except Exception:
                pass

            # 2) metadata.input
            try:
                if isinstance(md, dict) and md.get("input"):
                    return md.get("input") if isinstance(md.get("input"), str) else str(md.get("input"))
            except Exception:
                pass

            # 3) prompt field
            try:
                if span_data.get("prompt"):
                    return span_data.get("prompt") if isinstance(span_data.get("prompt"), str) else str(span_data.get("prompt"))
            except Exception:
                pass

            # 4) metadata.request.messages (common OpenAI shape)
            try:
                msgs = (md.get("request") or {}).get("messages")
                if isinstance(msgs, list) and msgs:
                    user_parts = []
                    for m in msgs:
                        if isinstance(m, dict):
                            role = m.get("role")
                            content = m.get("content") or m.get("text") or m.get("value")
                            if role == "user" and content:
                                user_parts.append(content)
                    if user_parts:
                        return "\n".join(user_parts)

                    # fallback: first message content
                    for m in msgs:
                        if isinstance(m, dict):
                            content = m.get("content") or m.get("text")
                            if content:
                                return content
            except Exception:
                pass

            return None
        except Exception:
            return None

    def _update_trace_input(self, trace_id: str, input_value: str) -> None:
        """Patch only the `input` field of an existing trace.

        This method performs a focused PATCH containing only the `input` key so
        that other trace fields are not modified.
        """
        if not requests or not trace_id or input_value is None:
            return

        try:
            headers = {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            }

            update_url = f"{self.api_url}/traces/{trace_id}"
            payload = {"input": input_value}

            print(f"[Nora] 🔄 Updating trace {trace_id} input only")
            response = requests.patch(update_url, json=payload, headers=headers, timeout=10)

            if response.status_code in (200, 201):
                print(f"[Nora] ✅ Successfully updated trace input for {trace_id}")
            else:
                print(f"[Nora] ⚠️  Warning: Failed to update trace input (status: {response.status_code})")
        except requests.exceptions.RequestException as e:
            print(f"[Nora] ❌ Error updating trace input: {str(e)}")
        except Exception as e:
            print(f"[Nora] ❌ Unexpected error updating trace input: {str(e)}")

    def _create_decision(self, trace_id: str) -> Optional[str]:
        """Create a decision and return decision_id.

        Args:
            trace_id: The trace ID to associate with this decision

        Returns:
            decision_id from API response, or None if failed
        """
        if not requests or not trace_id:
            return None

        try:
            headers = {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            }

            # Build payload with trace_id
            payload = {
                "trace_id": trace_id,
            }

            print(f"[Nora] 🔄 Creating decision for trace {trace_id}")
            response = requests.post(
                self.decision_create_url, json=payload, headers=headers, timeout=10
            )

            if response.status_code in (200, 201):
                response_data = response.json()
                decision_id = response_data.get("id")

                if not decision_id:
                    print(f"[Nora] ❌ ERROR: 'id' not found in decision response. Response: {response_data}")
                    return None

                print(f"[Nora] ✅ Created decision with ID: {decision_id}")

                # Store in map for later use (caller already has lock if needed)
                self._trace_decision_ids[trace_id] = decision_id

                return decision_id
            else:
                print(f"[Nora] ⚠️  Warning: Failed to create decision (status: {response.status_code})")
                print(f"[Nora] Response body: {response.text[:500]}")
                return None

        except requests.exceptions.RequestException as e:
            print(f"[Nora] ❌ Error creating decision: {str(e)}")
            return None
        except Exception as e:
            print(f"[Nora] ❌ Unexpected error creating decision: {str(e)}")
            return None

    def _update_decision_span(self, decision_span_id: str, updates: Dict[str, Any]) -> bool:
        """Patch/update an existing decision span via API.

        Calls: PATCH v1/decision/{decision_span_id}

        Returns True on success (HTTP 200/201), False otherwise.
        """
        if not requests or not decision_span_id:
            return False

        try:
            url = f"{self.api_url}/decision/{decision_span_id}"
            headers = {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            }

            print(f"[Nora] 🔄 Updating decision span {decision_span_id} with: {updates}")
            response = requests.patch(url, json=updates, headers=headers, timeout=10)
            if response.status_code in (200, 201):
                print(f"[Nora] ✅ Successfully updated decision span {decision_span_id}")
                return True
            else:
                print(f"[Nora] ⚠️  Warning: Failed to update decision span (status: {response.status_code})")
                try:
                    print(f"[Nora] Response body: {response.text[:500]}")
                except Exception:
                    pass
                return False

        except requests.exceptions.RequestException as e:
            print(f"[Nora] ❌ HTTP error updating decision span: {e}")
            return False
        except Exception as e:
            print(f"[Nora] ❌ Unexpected error updating decision span: {e}")
            return False

    def _send_execution_span(self, trace_id: str, span_data: Dict[str, Any]) -> None:
        """Send execution span immediately to API and capture execution_id.

        Args:
            trace_id: The parent trace ID
            span_data: The execution span data (contains local span "id")
        """

        if not requests:
            print("[Nora] ⚠️  WARNING: requests module not available")
            return

        if not trace_id:
            print("[Nora] ⚠️  WARNING: trace_id is empty or None")
            return

        # Store span_data id for later use in decision capture
        local_span_id = span_data.get("id")

        def _send():
            try:
                headers = {
                    "X-API-Key": self.api_key,
                    "Content-Type": "application/json",
                }

                # Extract span_name from span_data or generate a default
                span_name = (
                    span_data.get("provider", "unknown") + "_" + span_data.get("model", "execution")
                )

                # Build payload with required fields
                payload = {
                    "trace_id": trace_id,
                    "span_name": span_name,
                    "span_data": span_data,
                }

                # Parse and update trace input from this execution span (only update input field)
                try:
                    parsed_input = self._parse_input_from_span(span_data)
                    if parsed_input:
                        # Update only the input value on the Trace (focused PATCH)
                        self._update_trace_input(trace_id, parsed_input)
                except Exception:
                    # Non-fatal: continue even if parsing/updating input fails
                    pass

                # If this execution span represents an LLM call, include model and tokens.
                # `span_kind` is set earlier when traces are created; prefer that indicator.
                try:
                    span_kind = span_data.get("span_kind")
                except Exception:
                    span_kind = None

                if span_kind == "llm":
                    # Include model if available
                    model_val = span_data.get("model")
                    if model_val is not None:
                        payload["model"] = model_val

                    # Build tokens object: prefer explicit `tokens` dict on span_data,
                    # otherwise fall back to `tokens_used` -> {"total_tokens": N}
                    tokens_obj = None
                    try:
                        # Preferred output: only `total_input` and `total_output` keys
                        # 1) If explicit tokens dict provided with desired keys, use them
                        tokens_field = span_data.get("tokens")
                        if isinstance(tokens_field, dict):
                            # Prefer explicit `total_input`/`total_output` if present
                            if ("total_input" in tokens_field) or ("total_output" in tokens_field):
                                ti = tokens_field.get("total_input")
                                to = tokens_field.get("total_output")
                                obj: Dict[str, int] = {}
                                if ti is not None:
                                    obj["total_input"] = int(ti)
                                if to is not None:
                                    obj["total_output"] = int(to)
                                tokens_obj = obj if obj else None
                            else:
                                # Accept alternative key names inside tokens_field
                                # e.g., `input_tokens`/`output_tokens`, `prompt_tokens`/`completion_tokens`, or `tokens_used`
                                alt_ti = None
                                alt_to = None
                                if isinstance(tokens_field.get("input_tokens"), int):
                                    alt_ti = tokens_field.get("input_tokens")
                                if isinstance(tokens_field.get("output_tokens"), int):
                                    alt_to = tokens_field.get("output_tokens")
                                if alt_ti is None and isinstance(tokens_field.get("prompt_tokens"), int):
                                    alt_ti = tokens_field.get("prompt_tokens")
                                if alt_to is None and isinstance(tokens_field.get("completion_tokens"), int):
                                    alt_to = tokens_field.get("completion_tokens")
                                # tokens_used can be used as a fallback for output
                                if alt_to is None and isinstance(tokens_field.get("tokens_used"), int):
                                    alt_to = tokens_field.get("tokens_used")

                                if alt_ti is not None or alt_to is not None:
                                    obj: Dict[str, int] = {}
                                    if alt_ti is not None:
                                        obj["total_input"] = int(alt_ti)
                                    if alt_to is not None:
                                        obj["total_output"] = int(alt_to)
                                    tokens_obj = obj
                                else:
                                    # not usable, fall through to other metadata checks
                                    tokens_obj = None
                        else:
                            # 2) Try metadata/usage fields: metadata.input_tokens / metadata.output_tokens
                            md = span_data.get("metadata") or {}
                            usage = None
                            try:
                                usage = (md.get("response") or {}).get("usage")
                            except Exception:
                                usage = None

                            total_input = None
                            total_output = None

                            if isinstance(usage, dict):
                                # Map common names
                                if isinstance(usage.get("prompt_tokens"), int):
                                    total_input = usage.get("prompt_tokens")
                                if isinstance(usage.get("completion_tokens"), int):
                                    total_output = usage.get("completion_tokens")

                            # Fallback to metadata.input_tokens / metadata.output_tokens
                            if total_input is None:
                                try:
                                    if isinstance(md.get("input_tokens"), int):
                                        total_input = md.get("input_tokens")
                                except Exception:
                                    pass
                            if total_output is None:
                                try:
                                    if isinstance(md.get("output_tokens"), int):
                                        total_output = md.get("output_tokens")
                                except Exception:
                                    pass

                            # If we have at least one side, build the tokens_obj
                            if total_input is not None or total_output is not None:
                                obj: Dict[str, int] = {}
                                if total_input is not None:
                                    obj["total_input"] = int(total_input)
                                if total_output is not None:
                                    obj["total_output"] = int(total_output)
                                tokens_obj = obj
                            else:
                                # 3) Last-resort: if tokens_used exists, assume it's total_output
                                tokens_used = span_data.get("tokens_used")
                                if tokens_used is not None:
                                    tokens_obj = {"total_output": int(tokens_used)}
                    except Exception:
                        tokens_obj = None

                    # Attach tokens only when available and relevant
                    if tokens_obj is not None:
                        payload["tokens"] = tokens_obj

                print(f"[Nora] 📤 Sending execution span '{span_name}' for trace {trace_id}")
                response = requests.post(
                    self.execution_span_url, json=payload, headers=headers, timeout=10
                )

                if response.status_code in (200, 201):
                    try:
                        response_data = response.json()
                        execution_id = response_data.get("id")
                        
                        if execution_id:
                            print(f"[Nora] ✅ Got execution_id from API: {execution_id}")
                            
                            # Store execution_id in the global map keyed by trace_id
                            with self._trace_exec_lock:
                                if trace_id not in self._trace_execution_ids:
                                    self._trace_execution_ids[trace_id] = []
                                self._trace_execution_ids[trace_id].append(execution_id)
                                print(f"[Nora] 📝 Stored execution_id in map for trace {trace_id}. Count: {len(self._trace_execution_ids[trace_id])}")
                        else:
                            print(f"[Nora] ⚠️  No 'id' in API response: {response_data}")
                            # Fallback: use local span_id if backend doesn't return id
                            if local_span_id:
                                with self._trace_exec_lock:
                                    if trace_id not in self._trace_execution_ids:
                                        self._trace_execution_ids[trace_id] = []
                                    self._trace_execution_ids[trace_id].append(local_span_id)
                                    print(f"[Nora] 📝 Fallback: Stored local span_id in map")
                    except Exception as e:
                        print(f"[Nora] ⚠️  Error parsing response: {e}")
                        # Fallback on parse error
                        if local_span_id:
                            with self._trace_exec_lock:
                                if trace_id not in self._trace_execution_ids:
                                    self._trace_execution_ids[trace_id] = []
                                self._trace_execution_ids[trace_id].append(local_span_id)
                    
                    print(
                        f"[Nora] ✅ Successfully sent execution span (status: {response.status_code})"
                    )
                else:
                    print(
                        f"[Nora] ⚠️  Warning: Failed to send execution span (status: {response.status_code})"
                    )
                    try:
                        print(f"[Nora] Response: {response.text[:200]}")
                    except Exception:
                        pass

            except requests.exceptions.RequestException as e:
                print(f"[Nora] ❌ Error sending execution span: {str(e)}")
            except Exception as e:
                print(f"[Nora] ❌ Unexpected error sending execution span: {str(e)}")

        # Send asynchronously to avoid blocking
        thread = threading.Thread(target=_send, daemon=True)
        
        # Track this thread for flush operations
        with self._execution_threads_lock:
            self._execution_threads.append(thread)
        
        thread.start()

    def _send_traces(self, traces: List[Dict[str, Any]]) -> None:
        """실제 API로 trace 데이터를 전송합니다.

        Note: 개별 execution span은 이미 _send_execution_span()으로 전송되었으므로,
        여기서는 batch aggregation이나 메타데이터 업데이트만 필요하면 구현.
        현재는 no-op.
        """
        if not traces:
            return

        # ExecutionSpan이 개별적으로 전송되므로, batch 전송은 스킵
        print(f"[Nora] ℹ️  {len(traces)} trace(s) already sent via individual ExecutionSpan posts")

    # =========================
    # Decision span collection
    # =========================

    def _maybe_capture_llm_tool_decision(
        self,
        trace_data: Dict[str, Any],
        trace_group_id: Optional[str],
        trace_id: Optional[str],
    ) -> None:
        """Capture atomic decision when LLM is called with tools.
        
        Only creates decision if tools were provided in request metadata.
        Options = available tools, selected_option = tools actually called by LLM.
        
        span_kind determined by semantics:
        1. If function is in semantics["llm"]["functions"], span_kind = "llm"
        2. Otherwise, span_kind = "llm" (default for LLM tool calling)
        """
        try:
            metadata = trace_data.get("metadata", {})
            request_params = metadata.get("request", {}).get("parameters", {})
            available_tools = request_params.get("tools", [])
            
            # Skip if no tools were provided
            if not available_tools:
                return
            
            # Extract tool names from available tools
            tool_options = []
            for tool in available_tools:
                if isinstance(tool, dict) and "function" in tool:
                    func_info = tool["function"]
                    tool_name = func_info.get("name")
                    tool_desc = func_info.get("description", "")
                    if tool_name:
                        tool_options.append({
                            "content": f"{tool_name}: {tool_desc}" if tool_desc else tool_name,
                            "score": None,
                        })
            
            if not tool_options:
                return
            
            # Extract selected tools from response tool_calls
            selected_tools = []
            tool_calls = trace_data.get("tool_calls", [])
            if tool_calls:
                for tc in tool_calls:
                    if isinstance(tc, dict):
                        # Handle nested function structure from OpenAI
                        func_info = tc.get("function", {})
                        tool_name = func_info.get("name") if func_info else tc.get("name")
                        if tool_name:
                            selected_tools.append({
                                "content": tool_name,
                                "score": 1.0,
                            })
            
            # Determine agent name (use model as fallback)
            agent_name = f"llm_{trace_data.get('model', 'unknown')}"
            
            # Determine span_kind from semantics
            span_kind = "llm"  # default
            model = trace_data.get('model', 'unknown')
            
            # Check if LLM function is explicitly in semantics
            llm_cfg = self.semantics.get("llm", {})
            if model in llm_cfg.get("functions", []):
                span_kind = "llm"
            
            # Check if agent changed
            if hasattr(self, '_last_agent_name') and self._last_agent_name != agent_name:
                if self._atomic_decisions:
                    print(f"[Nora] 🔄 Agent changed: {self._last_agent_name} -> {agent_name}, flushing previous agent decisions")
                    self._flush_current_agent_decisions()
            
            self._last_agent_name = agent_name
            
            # Determine execution order within this trace
            execution_order = None
            if trace_id:
                execution_order = self._trace_execution_order.get(trace_id, 0)
                self._trace_execution_order[trace_id] = execution_order + 1
            
            print(f"[Nora] 🧠 LLM tool decision capture: model={trace_data.get('model')}, agent={agent_name}, span_kind={span_kind}, tools={len(tool_options)}, selected={len(selected_tools)}")
            
            # Register selected tools as pending under this LLM agent
            with self._pending_tools_lock:
                for tool in selected_tools:
                    tool_name = tool.get("content")
                    if tool_name:
                        self._pending_tool_calls[tool_name] = agent_name
                        print(f"[Nora] 📌 Registered pending tool: {tool_name} -> {agent_name}")
            
            atomic = {
                "id": str(uuid.uuid4()),
                "timestamp": datetime.utcnow().isoformat(),
                "span_kind": span_kind,
                "trace_group_id": trace_group_id,
                "agent_name": agent_name,
                "function_name": f"llm_tool_call_{trace_data.get('model', 'unknown')}",
                "options": tool_options,
                "selected_option": selected_tools,
                "evidence": [],
                "execution_id": None,
                "decision_id": None,
                "_trace_id": trace_id,
                "_execution_order": execution_order,
            }
            
            self._atomic_decisions.append(atomic)
            self._send_decision_async("atomic", atomic)
        except Exception as e:
            print(f"[Nora] ⚠️ LLM tool decision capture skipped due to error: {e}")

    def _maybe_capture_decision(
        self,
        func_name: str,
        result: Any,
        trace_group_id: Optional[str],
        execution_span_ids: Optional[List[str]] = None,
    ) -> None:
        """If semantics marks func_name as retrieval, extract decision and enqueue Atomic DecisionSpan.

        Silent no-op when extraction not possible.
        
        Note: Stores trace_id with atomic so execution_id can be fetched later from map.
        Atomic represents a single retrieval call, so it has one execution_id (not a list).
        
        New behavior: When agent changes, flush previous agent's atomics immediately.
        """
        try:
            cfg = self.semantics.get("retrieval", {})
            if not cfg or func_name not in (cfg.get("functions") or []):
                return

            extracted = self._extract_retrieval_options(result)
            if not extracted:
                return

            agent_name = self._resolve_agent_name(func_name, result)
            
            # Override agent if this function is a pending tool call from LLM
            with self._pending_tools_lock:
                if func_name in self._pending_tool_calls:
                    llm_agent = self._pending_tool_calls[func_name]
                    print(f"[Nora] 🔗 Tool execution {func_name} linked to LLM agent {llm_agent} (was {agent_name})")
                    agent_name = llm_agent
                    # Remove from pending after use
                    del self._pending_tool_calls[func_name]

            # Check if agent changed - if so, flush previous agent's decisions
            if hasattr(self, '_last_agent_name') and self._last_agent_name != agent_name:
                if self._atomic_decisions:
                    print(f"[Nora] 🔄 Agent changed: {self._last_agent_name} -> {agent_name}, flushing previous agent decisions")
                    self._flush_current_agent_decisions()
            
            self._last_agent_name = agent_name

            # Get current trace group to find its trace_id
            current_group = get_current_trace_group()
            trace_id = None
            if current_group:
                trace_id = current_group.trace_id

            # Determine execution order within this trace (increments per atomic captured)
            execution_order = None
            if trace_id:
                execution_order = self._trace_execution_order.get(trace_id, 0)
                self._trace_execution_order[trace_id] = execution_order + 1

            print(f"[Nora] 🧠 Decision capture: func={func_name}, agent={agent_name}, trace_id={trace_id}, order={execution_order}")

            atomic = {
                "id": str(uuid.uuid4()),
                "timestamp": datetime.utcnow().isoformat(),
                "span_kind": "retrieval",
                "trace_group_id": trace_group_id,
                "agent_name": agent_name,
                "function_name": func_name,
                "options": extracted["options"],
                "execution_id": None,  # Will be filled on flush (single ID, not array)
                "decision_id": None,  # Will be filled on flush after decision creation
                "_trace_id": trace_id,  # Internal field for decision/execution lookup
                "_execution_order": execution_order,  # Track position for ordering across agent flushes
            }

            self._atomic_decisions.append(atomic)
            self._send_decision_async("atomic", atomic)
        except Exception as e:
            print(f"[Nora] ⚠️ decision capture skipped due to error: {e}")

    def _extract_retrieval_options(self, result: Any) -> Optional[Dict[str, Any]]:
        """
        Normalize retrieval results into a list of {content: str, score: float|None}.

        Supported forms (content required, score optional):
          1) {"options": [{"content": str, "score": float(optional)}, ...]}
          2) {"options": ["content1", "content2", ...]}
          3) [{"content": str, "score": float(optional)}, ...]
          4) ["content1", "content2", ...]
        """
        options = None
        if isinstance(result, dict) and "options" in result:
            options = result.get("options")
        elif isinstance(result, list):
            options = result
        else:
            return None

        if not isinstance(options, list) or not options:
            return None

        normalized: List[Dict[str, Any]] = []
        for opt in options:
            if isinstance(opt, dict) and ("content" in opt):
                normalized.append({"content": opt["content"], "score": opt.get("score")})
            elif isinstance(opt, str):
                normalized.append({"content": opt, "score": None})
            else:
                return None

        return {"options": normalized}

    def _resolve_agent_name(self, func_name: str, result: Any) -> str:
        """Resolve agent_name used to aggregate AgentDecision.

        Priority:
        1) result dict contains 'agent_name'
        2) _current_agent_context (if inside an agent function)
        3) self.agent_map: {agent_name: [function_names]} - find which agent contains func_name
        4) fallback: func_name
        """
        try:
            if isinstance(result, dict) and isinstance(result.get("agent_name"), str):
                return result["agent_name"]
        except Exception:
            pass

        # Check current agent context (e.g., if search_web is called inside research_agent)
        try:
            current_context = _current_agent_context.get()
            if current_context:
                return current_context
        except Exception:
            pass

        try:
            agent_map = self.agent_map or {}
            if isinstance(agent_map, dict):
                # Format: {agent_name: [function_names]}
                # Find which agent contains this function
                matched_agents = []
                for agent_name, func_list in agent_map.items():
                    if isinstance(func_list, list) and func_name in func_list:
                        matched_agents.append(agent_name)
                
                if len(matched_agents) > 1:
                    print(f"[Nora] ⚠️  Warning: Function '{func_name}' found in multiple agents: {matched_agents}. Using first match: {matched_agents[0]}")
                    return matched_agents[0]
                elif len(matched_agents) == 1:
                    return matched_agents[0]
        except Exception as e:
            print(f"[Nora] ⚠️  Error resolving agent from agent_map: {e}")

        return func_name

    def _send_decision_async(self, kind: str, payload: Dict[str, Any]) -> None:
        if not self._decisions_enabled:
            return
        
        # For atomic decisions, don't send to queue yet - they'll be sent on flush
        # This allows time for execution_id to be populated from the async thread
        if kind == "atomic":
            # Atomic decisions are sent during flush, after execution threads complete
            # Just mark them in the decision list (already done in _maybe_capture_decision)
            return
        
        # For agent/answer decisions, enqueue immediately
        self._decision_queue.put({"kind": kind, "payload": payload})

    def _decision_worker_loop(self) -> None:
        while not self._decision_stop.is_set():
            try:
                item = self._decision_queue.get(timeout=0.5)
            except queue.Empty:
                continue
            try:
                kind = item.get("kind")
                payload = item.get("payload")
                if kind == "atomic":
                    self._post_atomic_decision(payload)
                elif kind == "agent":
                    self._post_agent_decision(payload)
                else:
                    # Simulate API call by printing for non-atomic kinds
                    print(f"[Nora] 🧠 (PRINT) Would POST Decision kind='{kind}': {payload}")
            except Exception as e:
                print(f"[Nora] ❌ Decision processing error: {e}")
            finally:
                try:
                    self._decision_queue.task_done()
                except Exception:
                    pass

    def _post_atomic_decision(self, atomic: Dict[str, Any]) -> None:
        """Send atomic decision to backend at decision_create_url/atomic-decision."""
        if not requests:
            print("[Nora] ⚠️  WARNING: requests module not available for atomic decision")
            return

        try:
            # Backend expects the DecisionSpan ID, not the client-side atomic ID
            decision_span_id = atomic.get("decision_id")
            execution_span_id = atomic.get("execution_id")
            agent_name = atomic.get("agent_name")
            function_name = atomic.get("function_name")
            span_kind = atomic.get("span_kind")
            options = atomic.get("options") or []
            selected_option = atomic.get("selected_option") or []
            evidence = atomic.get("evidence") or []

            if not (decision_span_id and execution_span_id and agent_name and function_name and span_kind):
                print(
                    "[Nora] ⚠️  Missing required fields for atomic decision, "
                    f"decision_span_id={decision_span_id}, execution_span_id={execution_span_id}, "
                    f"agent_name={agent_name}, function_name={function_name}, span_kind={span_kind}"
                )
                return

            url = f"{self.decision_create_url}atomic-decision"
            headers = {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            }
            payload = {
                "decision_span_id": decision_span_id,
                "execution_span_id": execution_span_id,
                "agent_name": agent_name,
                "function_name": function_name,
                "span_kind": span_kind,
                "options": options,
                "selected_option": selected_option,
                "evidence": evidence,
            }

            response = requests.post(url, json=payload, headers=headers, timeout=10)
            if response.status_code in (200, 201):
                print(f"[Nora] ✅ Posted atomic decision {decision_span_id}")
            else:
                print(f"[Nora] ⚠️  Failed to post atomic decision (status: {response.status_code}) payload={payload}")
        except requests.exceptions.RequestException as e:
            print(f"[Nora] ❌ HTTP error posting atomic decision: {e}")
        except Exception as e:
            print(f"[Nora] ❌ Unexpected error posting atomic decision: {e}")

    def _post_agent_decision(self, agent_decision: Dict[str, Any]) -> None:
        """Send agent decision to backend at decision_create_url/agent-decision."""
        if not requests:
            print("[Nora] ⚠️  WARNING: requests module not available for agent decision")
            return

        try:
            decision_span_id = agent_decision.get("decision_id")
            contributors = agent_decision.get("contributors") or []
            agent_name = agent_decision.get("agent_name")
            p_error = agent_decision.get("p_error")

            if not (decision_span_id and agent_name):
                print(
                    "[Nora] ⚠️  Missing required fields for agent decision, "
                    f"decision_span_id={decision_span_id}, agent_name={agent_name}"
                )
                return

            url = f"{self.decision_create_url}agent-decision"
            headers = {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            }

            payload: Dict[str, Any] = {
                "decision_span_id": decision_span_id,
                "contributors": contributors,
                "agent_name": agent_name,
            }
            if p_error is not None:
                payload["p_error"] = p_error

            response = requests.post(url, json=payload, headers=headers, timeout=10)
            if response.status_code in (200, 201):
                print(f"[Nora] ✅ Posted agent decision {decision_span_id}")
            else:
                print(f"[Nora] ⚠️  Failed to post agent decision (status: {response.status_code}) payload={payload}")

            # Always attempt to PATCH the trace-level decision span to record agent contributors/status
            try:
                updates: Dict[str, Any] = {"contributors": contributors}
                if agent_name:
                    updates["agent_name"] = agent_name
                if p_error is not None:
                    updates["p_error"] = p_error
                updates["status"] = "agent_posted"

                # decision_span_id is the trace-level decision created earlier
                if decision_span_id:
                    self._update_decision_span(decision_span_id, updates)
            except Exception as e:
                print(f"[Nora] ⚠️ Failed to update decision span after agent post: {e}")
        except requests.exceptions.RequestException as e:
            print(f"[Nora] ❌ HTTP error posting agent decision: {e}")
        except Exception as e:
            print(f"[Nora] ❌ Unexpected error posting agent decision: {e}")

    def _build_and_send_agent_answer_decisions(self) -> None:
        """Aggregate Atomic -> AgentDecision, then one Decision (formerly Answer).

        Called during _flush or when agent changes. If no atomics, it's a no-op.
        
        Flow:
        1. Create decision_id via API if not exists (per unique trace_id)
        2. Fill execution_id and decision_id in each atomic
        3. Send atomics
        4. Aggregate into AgentDecisions (with decision_id)
        5. Create final Decision (formerly AnswerDecision)
        """
        if not self._atomic_decisions:
            return

        # Step 1: Create decision_id for each unique trace_id (if not exists)
        unique_trace_ids = set()
        for atomic in self._atomic_decisions:
            trace_id = atomic.get("_trace_id")
            if trace_id:
                unique_trace_ids.add(trace_id)
        
        for trace_id in unique_trace_ids:
            with self._decision_id_lock:
                if trace_id not in self._trace_decision_ids:
                    # Create decision via API
                    self._create_decision(trace_id)

        # Step 2: Brief sleep for execution span responses
        import time
        time.sleep(0.1)

        # Step 3: Fill execution_id and decision_id using _execution_order
        with self._trace_exec_lock:
            for atomic in self._atomic_decisions:
                trace_id = atomic.get("_trace_id")
                execution_order = atomic.get("_execution_order")
                
                # Fill execution_id by order
                if trace_id and execution_order is not None and trace_id in self._trace_execution_ids:
                    exec_ids = self._trace_execution_ids[trace_id]
                    if execution_order < len(exec_ids):
                        atomic["execution_id"] = exec_ids[execution_order]
        
        # Fill decision_id separately to avoid nested locks
        for atomic in self._atomic_decisions:
            trace_id = atomic.get("_trace_id")
            
            with self._decision_id_lock:
                if trace_id and trace_id in self._trace_decision_ids:
                    atomic["decision_id"] = self._trace_decision_ids[trace_id]
            
            # Remove internal fields before sending
            atomic.pop("_trace_id", None)
            atomic.pop("_execution_order", None)

        # Step 3: Send all atomics to decision queue (with execution_id and decision_id now populated)
        for atomic in self._atomic_decisions:
            self._decision_queue.put({"kind": "atomic", "payload": atomic})

        # Step 4: Group by agent_name and create AgentDecisions
        by_agent: Dict[str, List[Dict[str, Any]]] = {}
        for d in self._atomic_decisions:
            agent = d.get("agent_name") or "unknown"
            by_agent.setdefault(agent, []).append(d)

        # AgentDecision per agent
        for agent_name, items in by_agent.items():
            trace_groups = sorted({x.get("trace_group_id") for x in items if x.get("trace_group_id")})
            
            # Collect all execution_ids from this agent's atomics into contributors array
            contributors = []
            for x in items:
                exec_id = x.get("execution_id")
                if exec_id:
                    contributors.append(exec_id)
            
            # Get decision_id (all items in same agent should have same decision_id if from same trace)
            # For now, use the first available decision_id
            decision_id = None
            for x in items:
                if x.get("decision_id"):
                    decision_id = x["decision_id"]
                    break
            
            agent_decision = {
                "id": str(uuid.uuid4()),
                "timestamp": datetime.utcnow().isoformat(),
                "agent_name": agent_name,
                "atomic_ids": [x["id"] for x in items],
                "contributors": contributors,  # Array of ExecutionSpan IDs
                "trace_groups": trace_groups,
                "decision_id": decision_id,  # Added decision_id
            }
            self._send_decision_async("agent", agent_decision)

        # Step 5: Create final Decision (formerly AnswerDecision) across all agents in this flush
        agent_names = sorted(by_agent.keys())
        all_groups = sorted({x.get("trace_group_id") for items in by_agent.values() for x in items if x.get("trace_group_id")})
        
        # Collect all execution_ids for decision
        all_contributors = []
        for items in by_agent.values():
            for x in items:
                exec_id = x.get("execution_id")
                if exec_id:
                    all_contributors.append(exec_id)
        
        decision = {
            "id": str(uuid.uuid4()),
            "timestamp": datetime.utcnow().isoformat(),
            "span_kind": "retrieval",
            "decision_type": "retrieval",
            "groups": all_groups,
            "agent_names": agent_names,
            "contributors": all_contributors,  # Array of all ExecutionSpan IDs
        }
        self._send_decision_async("decision", decision)  # Changed from "answer" to "decision"

        # After scheduling posts, update per-trace decision spans with contributors/status
        for trace_id in unique_trace_ids:
            with self._decision_id_lock:
                decision_span_id = self._trace_decision_ids.get(trace_id)

            if decision_span_id:
                with self._trace_exec_lock:
                    contributors = list(self._trace_execution_ids.get(trace_id, []))

                updates: Dict[str, Any] = {
                    "contributors": contributors,
                    "status": "completed",
                }
                try:
                    self._update_decision_span(decision_span_id, updates)
                except Exception as e:
                    print(f"[Nora] ⚠️ Failed to PATCH decision span {decision_span_id}: {e}")

        # Clear after scheduling posts to avoid duplicates
        self._atomic_decisions.clear()

        # Reset execution order counters for processed traces
        for trace_id in unique_trace_ids:
            self._trace_execution_order.pop(trace_id, None)

        # Ensure queued decisions are processed before returning
        try:
            self._decision_queue.join()
        except Exception:
            pass

    def _flush_current_agent_decisions(self) -> None:
        """Flush only the current agent's atomic decisions without creating final Decision.
        
        Called when agent changes during execution. Creates AgentDecision but not final Decision.
        """
        if not self._atomic_decisions:
            return

        # Step 1: Create decision_id for each unique trace_id (if not exists)
        unique_trace_ids = set()
        for atomic in self._atomic_decisions:
            trace_id = atomic.get("_trace_id")
            if trace_id:
                unique_trace_ids.add(trace_id)
        
        for trace_id in unique_trace_ids:
            with self._decision_id_lock:
                if trace_id not in self._trace_decision_ids:
                    self._create_decision(trace_id)

        # Step 2: Brief sleep to allow execution span responses to arrive
        # Execution spans are sent asynchronously, so we give them a moment
        import time
        time.sleep(0.1)  # 100ms should be enough for most API responses

        # Step 3: Fill execution_id and decision_id using stored execution order
        with self._trace_exec_lock:
            for atomic in self._atomic_decisions:
                trace_id = atomic.get("_trace_id")
                execution_order = atomic.get("_execution_order")
                
                # Get execution_id by order index
                if trace_id and trace_id in self._trace_execution_ids:
                    exec_ids = self._trace_execution_ids[trace_id]
                    if execution_order is not None and execution_order < len(exec_ids):
                        atomic["execution_id"] = exec_ids[execution_order]
                        print(f"[Nora] 📌 Assigned execution_id to atomic at order {execution_order}: {exec_ids[execution_order]}")
        
        # Fill decision_id separately to avoid nested locks
        for atomic in self._atomic_decisions:
            trace_id = atomic.get("_trace_id")
            
            with self._decision_id_lock:
                if trace_id and trace_id in self._trace_decision_ids:
                    atomic["decision_id"] = self._trace_decision_ids[trace_id]
            
            # Remove internal fields before sending
            atomic.pop("_trace_id", None)
            atomic.pop("_execution_order", None)

        # Step 4: Send atomics
        for atomic in self._atomic_decisions:
            self._decision_queue.put({"kind": "atomic", "payload": atomic})

        # Step 5: Create AgentDecision for current agent
        if self._atomic_decisions:
            agent_name = self._atomic_decisions[0].get("agent_name", "unknown")
            trace_groups = sorted({x.get("trace_group_id") for x in self._atomic_decisions if x.get("trace_group_id")})
            
            contributors = []
            for x in self._atomic_decisions:
                exec_id = x.get("execution_id")
                if exec_id:
                    contributors.append(exec_id)
            
            decision_id = None
            for x in self._atomic_decisions:
                if x.get("decision_id"):
                    decision_id = x["decision_id"]
                    break
            
            agent_decision = {
                "id": str(uuid.uuid4()),
                "timestamp": datetime.utcnow().isoformat(),
                "agent_name": agent_name,
                "atomic_ids": [x["id"] for x in self._atomic_decisions],
                "contributors": contributors,
                "trace_groups": trace_groups,
                "decision_id": decision_id,
            }
            self._send_decision_async("agent", agent_decision)

        # Clear atomics
        # Update per-trace decision spans for this agent flush
        unique_trace_ids = set()
        for atomic in self._atomic_decisions:
            tid = atomic.get("_trace_id")
            if tid:
                unique_trace_ids.add(tid)

        for trace_id in unique_trace_ids:
            with self._decision_id_lock:
                decision_span_id = self._trace_decision_ids.get(trace_id)

            if decision_span_id:
                with self._trace_exec_lock:
                    contributors = list(self._trace_execution_ids.get(trace_id, []))

                updates: Dict[str, Any] = {
                    "contributors": contributors,
                    "status": "completed",
                }
                try:
                    self._update_decision_span(decision_span_id, updates)
                except Exception as e:
                    print(f"[Nora] ⚠️ Failed to PATCH decision span {decision_span_id}: {e}")

        self._atomic_decisions.clear()

        # Ensure queued decisions are processed before returning
        try:
            self._decision_queue.join()
        except Exception:
            pass

    def flush(self, sync: bool = False) -> None:
        """수동으로 trace 데이터를 즉시 전송합니다.

        Args:
            sync: True면 동기적으로 전송 (기본값: False, 비동기 전송)
        """
        with self._lock:
            self._flush(sync=sync)

    def disable(self) -> None:
        """Trace 기능을 비활성화합니다."""
        self.flush()  # 비활성화 전에 남은 데이터 전송
        self.enabled = False

    def enable(self) -> None:
        """Trace 기능을 활성화합니다."""
        self.enabled = True

    def find_traces_by_group(self, group_name: str) -> List[Dict[str, Any]]:
        """특정 trace group 이름으로 수집된 모든 traces를 검색합니다."""
        matching_traces = []
        with self._lock:
            for trace in self._traces:
                group_info = trace.get("metadata", {}).get("trace_group", {})
                if group_info.get("name") == group_name:
                    matching_traces.append(trace)
        return matching_traces

    def find_traces_by_group_id(self, group_id: str) -> List[Dict[str, Any]]:
        """특정 trace group ID로 수집된 모든 traces를 검색합니다."""
        matching_traces = []
        with self._lock:
            for trace in self._traces:
                group_info = trace.get("metadata", {}).get("trace_group", {})
                if group_info.get("id") == group_id:
                    matching_traces.append(trace)
        return matching_traces

    def get_trace_groups(self) -> List[Dict[str, Any]]:
        """현재 수집된 모든 trace group 정보를 반환합니다."""
        groups_dict = {}
        with self._lock:
            for trace in self._traces:
                group_info = trace.get("metadata", {}).get("trace_group", {})
                if group_info:
                    group_id = group_info.get("id")
                    if group_id and group_id not in groups_dict:
                        groups_dict[group_id] = {
                            "id": group_id,
                            "name": group_info.get("name"),
                            "metadata": group_info.get("metadata", {}),
                            "trace_count": 0,
                            "total_tokens": 0,
                            "total_duration": 0.0,
                            "trace_ids": [],
                        }
                    if group_id:
                        groups_dict[group_id]["trace_count"] += 1
                        tokens = trace.get("tokens_used") or 0
                        groups_dict[group_id]["total_tokens"] += tokens
                        groups_dict[group_id]["trace_ids"].append(trace.get("id"))
                        duration = trace.get("duration") or 0.0
                        groups_dict[group_id]["total_duration"] += duration
        return list(groups_dict.values())


# 전역 클라이언트 인스턴스
_client: Optional[NoraClient] = None


def get_client() -> Optional[NoraClient]:
    """전역 클라이언트 인스턴스를 반환합니다."""
    return _client


def set_client(client: NoraClient) -> None:
    """전역 클라이언트 인스턴스를 설정합니다."""
    global _client
    _client = client


def get_current_trace_group() -> Optional[TraceGroup]:
    """현재 활성화된 trace group을 반환합니다."""
    return _current_trace_group.get()
