"""Okta API Script Package"""

__version__ = "0.1.2"
__author__ = "Mykel Alvis"
__email__ = "malvis@lynker.com"
