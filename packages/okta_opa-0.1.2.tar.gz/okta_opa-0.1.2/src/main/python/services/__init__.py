# This file marks the services directory as a Python package.

__version__ = "0.1.2"
__author__ = "Mykel Alvis"
__email__ = "malvis@lynker.com"
