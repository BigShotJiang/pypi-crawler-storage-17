"""Tests for sleap-share client."""
