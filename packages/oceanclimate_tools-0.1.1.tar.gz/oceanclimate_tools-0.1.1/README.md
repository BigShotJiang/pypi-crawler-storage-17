# oceanclimate_tools

[![PyPI version](https://img.shields.io/pypi/v/oceanclimate-tools)](https://pypi.org/project/oceanclimate-tools/)
[![Python versions](https://img.shields.io/pypi/pyversions/oceanclimate-tools)](https://pypi.org/project/oceanclimate-tools/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

Beginner-friendly Python utilities for oceanography and climate data preprocessing.


## Why this exists
Climate and ocean datasets often come from different sources and use different units
(e.g., °C vs °F vs K, m/s vs knots, hPa vs atm). Before analysis, visualization,
or machine learning, these values must be standardized.

This package provides small, well-documented conversion helpers to make climate
and ocean data easier to work with—especially for beginners.

## What’s included
- Temperature conversions (°F, °C, K)
- Wind speed conversions (m/s, km/h, mph, knots)
- Pressure conversions (Pa, hPa, atm, psi)
- Salinity helpers (simple, approximate)
- Geographic helpers (degrees/radians, haversine distance)

## Installation
```bash
pip install oceanclimate-tools
```

## Quick start
```python
from oceanclimate_tools import (
    fahrenheit_to_celsius,
    mps_to_knots,
    haversine_distance_km
)

fahrenheit_to_celsius(68)          # 20.0
mps_to_knots(10)                   # 19.438444924406
haversine_distance_km(
    43.6532, -79.3832,
    40.7128, -74.0060
)
```

## Design philosophy
- Accuracy over rounding
- Simple, readable functions
- Beginner-friendly documentation
- Intended for learning, preprocessing, and reproducible analysis






