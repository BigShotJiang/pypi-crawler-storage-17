from .message_pb2 import ResourceState

__all__ = [
    "ResourceState",
]
