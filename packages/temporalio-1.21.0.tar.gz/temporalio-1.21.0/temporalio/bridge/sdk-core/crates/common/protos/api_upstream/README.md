# Temporal proto files  

This repository contains both the protobuf descriptors and OpenAPI documentation for the Temporal platform.

## How to use

Install as git submodule to the project.

## Contribution

Make your change to the temporal/proto files, and run `make` to update the openapi definitions.

## License

MIT License, please see [LICENSE](LICENSE) for details.
