from .external_data_pb2 import LocalActivityMarkerData, PatchedMarkerData

__all__ = [
    "LocalActivityMarkerData",
    "PatchedMarkerData",
]
