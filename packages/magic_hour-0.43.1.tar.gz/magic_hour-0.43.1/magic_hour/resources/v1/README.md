# v1

## Submodules
- [ai_clothes_changer](ai_clothes_changer/README.md) - ai_clothes_changer
- [ai_face_editor](ai_face_editor/README.md) - ai_face_editor
- [ai_gif_generator](ai_gif_generator/README.md) - ai_gif_generator
- [ai_headshot_generator](ai_headshot_generator/README.md) - ai_headshot_generator
- [ai_image_editor](ai_image_editor/README.md) - ai_image_editor
- [ai_image_generator](ai_image_generator/README.md) - ai_image_generator
- [ai_image_upscaler](ai_image_upscaler/README.md) - ai_image_upscaler
- [ai_meme_generator](ai_meme_generator/README.md) - ai_meme_generator
- [ai_photo_editor](ai_photo_editor/README.md) - ai_photo_editor
- [ai_qr_code_generator](ai_qr_code_generator/README.md) - ai_qr_code_generator
- [ai_talking_photo](ai_talking_photo/README.md) - ai_talking_photo
- [ai_voice_generator](ai_voice_generator/README.md) - ai_voice_generator
- [animation](animation/README.md) - animation
- [audio_projects](audio_projects/README.md) - audio_projects
- [auto_subtitle_generator](auto_subtitle_generator/README.md) - auto_subtitle_generator
- [face_detection](face_detection/README.md) - face_detection
- [face_swap](face_swap/README.md) - face_swap
- [face_swap_photo](face_swap_photo/README.md) - face_swap_photo
- [files](files/README.md) - files
- [image_background_remover](image_background_remover/README.md) - image_background_remover
- [image_projects](image_projects/README.md) - image_projects
- [image_to_video](image_to_video/README.md) - image_to_video
- [lip_sync](lip_sync/README.md) - lip_sync
- [photo_colorizer](photo_colorizer/README.md) - photo_colorizer
- [text_to_video](text_to_video/README.md) - text_to_video
- [video_projects](video_projects/README.md) - video_projects
- [video_to_video](video_to_video/README.md) - video_to_video

