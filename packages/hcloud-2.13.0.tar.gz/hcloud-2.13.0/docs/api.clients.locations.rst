LocationsClient
==================


.. autoclass:: hcloud.locations.client.LocationsClient
    :members:

.. autoclass:: hcloud.locations.client.BoundLocation
    :members:

.. autoclass:: hcloud.locations.domain.Location
    :members:
