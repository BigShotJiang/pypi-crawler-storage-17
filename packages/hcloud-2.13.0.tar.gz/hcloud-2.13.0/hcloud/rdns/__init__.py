from __future__ import annotations

from .domain import DNSPtr

__all__ = [
    "DNSPtr",
]
