This module allows to add a reference name on documents and simplifies
the link between document pages.
