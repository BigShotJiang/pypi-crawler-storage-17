from .confini_parser import ConfiniParserFactory, ConfiniError

__version__ = "1.0.1"
__author__ = "Ethan"
__email__ = "176188484@qq.com"
__license__ = "MIT"
__description__ = "An INI file parser"
