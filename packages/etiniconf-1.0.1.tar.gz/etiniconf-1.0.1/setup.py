from setuptools import setup, find_packages

with open("README.md", "r") as fh:  
    long_description = fh.read()  

setup(
    name="etiniconf", 
    version="1.0.1", 
    packages=find_packages(), 
    include_package_data=True, 
    description="An INI file parser", 
    long_description=long_description, 
    long_description_content_type="text/markdown", 
    author="Ethan", 
    author_email="176188484@qq.com", 
    license="MIT", 
    classifiers=[
        "License :: OSI Approved :: MIT License", 
        "Programming Language :: Python :: 3.9", 
    ],
)