# Copyright (c) 2024- Datalayer, Inc.
#
# BSD 3-Clause License

"""Logging Configuration for Jupyter MCP Server"""

import logging

logger = logging.getLogger(__name__)
