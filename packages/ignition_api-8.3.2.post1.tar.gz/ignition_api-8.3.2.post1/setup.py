# pylint: skip-file
"""Ignition API."""

from setuptools import setup

setup()
