"""Package information."""

__version__ = "8.3.2"
__build__ = "2025120210"
