class ValueEval(object):
    pass
