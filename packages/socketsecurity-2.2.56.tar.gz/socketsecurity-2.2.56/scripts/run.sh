#!/bin/sh

cd /socketcli
python3 socketcli.py