print("I am script 2")
