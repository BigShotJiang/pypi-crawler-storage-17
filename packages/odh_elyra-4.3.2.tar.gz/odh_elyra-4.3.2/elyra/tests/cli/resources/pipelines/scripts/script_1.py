print("I am script 1")
