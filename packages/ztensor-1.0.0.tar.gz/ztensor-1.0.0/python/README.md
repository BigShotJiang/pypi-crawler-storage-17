# ztensor

A Python package providing high-performance bindings to the `ztensor` Rust core library for reading `.zt` tensor files.
