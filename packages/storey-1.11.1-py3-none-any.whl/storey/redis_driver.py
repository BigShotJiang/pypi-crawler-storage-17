# Copyright 2020 Iguazio
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import asyncio
import json
import math
import os
import time
from datetime import datetime, timedelta, timezone
from functools import partial
from typing import List, Optional, Union

import pandas as pd
import redis
import redis.cluster

from .drivers import Driver
from .dtypes import RedisError
from .utils import schema_file_name


class NeedsRedisAccess:
    """
    Checks that params for access to Redis exist and are legal

    :param redis_utl: URL to the redis server. If not set, the MLRUN_REDIS_URL environment variable will be used.
    """

    def __init__(self, redis_url=None):
        redis_url = redis_url or os.getenv("MLRUN_REDIS_URL")
        if not redis_url:
            raise ValueError("no redis_client object or MLRUN_REDIS_URL environment-var provided, aborting")

        self._redis_url = redis_url


class RedisDriver(NeedsRedisAccess, Driver):
    INTERFNAL_FIELD_PREFIX = chr(0x1)
    REDIS_TIMEOUT = 5  # Seconds
    REDIS_WATCH_INTERVAL = 1  # Seconds
    DATETIME_FIELD_PREFIX = "_dt:"
    TIMEDELTA_FIELD_PREFIX = "_td:"
    DEFAULT_KEY_PREFIX = "storey:"
    AGGREGATION_ATTRIBUTE_PREFIX = INTERFNAL_FIELD_PREFIX + "aggr_"
    AGGREGATION_TIME_ATTRIBUTE_PREFIX = INTERFNAL_FIELD_PREFIX + "mtaggr_"
    OBJECT_MTIME_ATTRIBUTE_PREFIX = INTERFNAL_FIELD_PREFIX + "_mtime_"

    def __init__(
        self,
        redis_client: Optional[Union[redis.Redis, redis.cluster.RedisCluster]] = None,
        key_prefix: str = None,
        redis_url: Optional[str] = None,
    ):
        # if client provided a redis-client object, use it. otherwise store the redis url, and create redis-client
        # upon demand (any access to self.redis)
        if redis_client is not None:
            self._redis = redis_client
        else:
            NeedsRedisAccess.__init__(self, redis_url)
            self._redis = None

        self._key_prefix = key_prefix if key_prefix is not None else self.DEFAULT_KEY_PREFIX
        self._mtime_name = self.OBJECT_MTIME_ATTRIBUTE_PREFIX

    @staticmethod
    def asyncify(fn):
        """Run a synchronous function asynchronously."""

        async def inner_fn(*args, **kwargs):
            loop = asyncio.get_event_loop()
            partial_fn = partial(fn, *args, **kwargs)
            return await loop.run_in_executor(None, partial_fn)

        return inner_fn

    @property
    def redis(self):
        if self._redis is None:
            try:
                self._redis = redis.cluster.RedisCluster.from_url(self._redis_url, decode_responses=True)
            except redis.cluster.RedisClusterException:
                self._redis = redis.Redis.from_url(self._redis_url, decode_responses=True)
        return self._redis

    @staticmethod
    def __build_key(key_prefix, *parts):
        return f"{{{key_prefix}{''.join([str(p) for p in parts])}}}"

    @staticmethod
    def make_key(key_prefix, container_and_table, key):
        return RedisDriver.__build_key(key_prefix, container_and_table, ":", key)

    def _make_key(self, container, table, key):
        return RedisDriver.__build_key(self._key_prefix, container, table, ":", key)

    @staticmethod
    def _static_data_key(redis_key_prefix):
        """
        The Redis key for the Hash containing static data (AKA, "additional data").

        The `redis_key_prefix` string should be the Redis key prefix used to store
        data for a Storey container, table path, and key combination.
        """
        return f"{redis_key_prefix}:static"

    def _aggregation_time_key(self, redis_key_prefix, feature_name):
        """
        The Redis key containing the associated timestamp for an aggregation.

        The `redis_key_prefix` string should be the Redis key prefix used to store
        data for a Storey container, table path, and key combination.
        """
        return f"{redis_key_prefix}:{RedisDriver.AGGREGATION_TIME_ATTRIBUTE_PREFIX}{feature_name}"

    @staticmethod
    def _list_key(redis_key_prefix, list_attribute_name):
        """
        The key containing a list of aggregation data.

        The `redis_key_prefix` string should be the Redis key prefix used to store
        data for a Storey container, table path, and key combination.
        """
        return f"{redis_key_prefix}:{list_attribute_name}"

    @classmethod
    def _convert_python_obj_to_redis_value(cls, value):
        if isinstance(value, datetime):
            if pd.isnull(value):
                return None
            return f"{cls.DATETIME_FIELD_PREFIX}{value.timestamp()}"
        elif isinstance(value, timedelta):
            return f"{cls.TIMEDELTA_FIELD_PREFIX}{value.total_seconds()}"
        else:
            if isinstance(value, float):
                if value == math.inf or value == -math.inf:
                    value = str(value)  # stored in redis as "inf" string
                elif math.isnan(value):
                    value = str(value)  # stored in redis as "nan" string
                elif value % 1 == 0:
                    value = int(value)  # cast whole numbers to integer

            return json.dumps(value)

    @classmethod
    def _convert_python_obj_to_lua_value(cls, value):
        if isinstance(value, datetime):
            if pd.isnull(value):
                return None
            return f'"{cls.DATETIME_FIELD_PREFIX}{value.timestamp()}"'
        elif isinstance(value, timedelta):
            return f'"{cls.TIMEDELTA_FIELD_PREFIX}{value.total_seconds()}"'
        elif isinstance(value, bool):
            return f'"{json.dumps(value)}"'
        else:
            if isinstance(value, float):
                if value == math.inf:
                    value = "math.huge"
                elif value == -math.inf:
                    value = "-math.huge"
                elif math.isnan(value):
                    value = "0/0"
                elif value % 1 == 0:
                    # Store whole numbers as integers to save space.
                    value = int(value)

            return json.dumps(value)

    @classmethod
    def convert_redis_value_to_python_obj(cls, value):
        if value is None:
            return None

        str_value = cls.convert_to_str(value)

        value = str_value.lower()
        if value.startswith(cls.TIMEDELTA_FIELD_PREFIX):
            ret = timedelta(seconds=float(value.split(":")[1]))
        elif value.startswith(cls.DATETIME_FIELD_PREFIX):
            ret = datetime.fromtimestamp(float(value.split(":")[1]), tz=timezone.utc)
        elif value == "inf":
            ret = math.inf
        elif value == "-inf":
            ret = -math.inf
        elif value == "nan" or value == "-nan" or value == "0/0" or value == "-0/0":
            ret = float("nan")
        elif value == "true":
            ret = True
        elif value == "false":
            ret = False
        else:
            # if value is a number, convert type to int / float
            try:
                ret = float(value)
                try:
                    ret = int(value)
                except ValueError:
                    pass
            except ValueError:
                ret = str_value
        return ret

    @classmethod
    def convert_to_str(cls, key):
        if isinstance(key, bytes):
            return key.decode("utf-8")
        else:
            return key

    def _discard_old_pending_items(self, pending, max_window_millis):
        res = {}
        if pending:
            last_time = int(list(pending.keys())[-1] / max_window_millis) * max_window_millis
            min_time = last_time - max_window_millis
            for _time, value in pending.items():
                if _time > min_time:
                    res[_time] = value
        return res

    def _build_feature_store_lua_update_script(
        self, redis_key_prefix, aggregation_element, partitioned_by_key, additional_data
    ):
        redis_keys_involved = []
        pending_updates = {}
        condition_expression = None

        additional_data_lua_script = f'local redis_hash="{self._static_data_key(redis_key_prefix)}";\n'
        # Static attributes, like "name," "age," -- everything that isn't an agg.
        if additional_data:
            for name, value in additional_data.items():
                expression_value = self._convert_python_obj_to_lua_value(value)
                # NOTE: This logic assumes that static attributes we're supposed
                # to delete will appear in the `additional_data` dict with a
                # "falsey" value. This is the same logic the V3ioDriver uses.
                if expression_value:
                    additional_data_lua_script = (
                        f"{additional_data_lua_script}redis.call("
                        f'"HSET",redis_hash, "{name}", {expression_value});\n'
                    )
                else:
                    additional_data_lua_script = (
                        f'{additional_data_lua_script}redis.call("HDEL",redis_hash, "{name}");\n'
                    )

        lua_script = additional_data_lua_script

        if aggregation_element:
            times_updates = {}
            new_cached_times = {}
            initialized_attributes = {}
            if partitioned_by_key:
                condition_expression = aggregation_element.storage_specific_cache.get(self._mtime_name, None)
            lua_tonum_function = (
                'local function tonum(str) if str == "inf" then return math.huge elseif str == "-inf" then '
                'return -math.huge elseif str == "nan" then return 0/0 end return tonumber(str) end;\n'
            )
            lua_strToArr_funct = (
                "local function strToArr(input)\n"
                "    local result = {}\n"
                "    if input == nil or input == false then return {} end\n"
                '    for value in string.gmatch(input, "([^,]+)") do\n'
                "        table.insert(result, value)\n"
                "    end\n"
                "    return result\n"
                "end\n"
            )
            lua_script = f"{lua_script}local old_value;local aggr_key;\n"
            lua_script = f"{lua_script}{lua_tonum_function}{lua_strToArr_funct}\n"
            for name, bucket in aggregation_element.aggregation_buckets.items():
                # Only save raw aggregates, not virtual
                if bucket.should_persist:
                    # In case we have pending data that spreads over more than 2 windows, discard the old ones.
                    pending_updates[name] = self._discard_old_pending_items(
                        bucket.get_and_flush_pending(), bucket.max_window_millis
                    )
                    for bucket_start_time, aggregation_values in pending_updates[name].items():
                        # the relevant attribute out of the 2 feature attributes
                        feature_attr = "a" if int(bucket_start_time / bucket.max_window_millis) % 2 == 0 else "b"

                        aggr_time_attribute_name = f"{bucket.name}_{feature_attr}"
                        array_time_attribute_key = self._aggregation_time_key(
                            redis_key_prefix, aggr_time_attribute_name
                        )
                        aggr_mtime_attr_name = (
                            f"{RedisDriver.AGGREGATION_TIME_ATTRIBUTE_PREFIX}{aggr_time_attribute_name}"
                        )

                        cached_time = bucket.storage_specific_cache.get(array_time_attribute_key, -1)

                        expected_time = int(bucket_start_time / bucket.max_window_millis) * bucket.max_window_millis
                        expected_time_expr = self._convert_python_obj_to_lua_value(
                            datetime.fromtimestamp(expected_time / 1000)
                        )
                        lua_index_to_update = 1 + int((bucket_start_time - expected_time) / bucket.period_millis)

                        for (
                            aggregation,
                            aggregation_value,
                        ) in aggregation_values.items():
                            list_attribute_name = f"{name}_{aggregation}_{feature_attr}"
                            lua_script = f'{lua_script}\
                                aggr_key="{RedisDriver.AGGREGATION_ATTRIBUTE_PREFIX}{list_attribute_name}";\n'

                            if cached_time < expected_time:
                                list_attribute_key = self._list_key(redis_key_prefix, list_attribute_name)
                                if not initialized_attributes.get(list_attribute_key, -1) == expected_time:
                                    initialized_attributes[list_attribute_key] = expected_time
                                    lua_script = (
                                        f'{lua_script}local t=redis.call("HGET",redis_hash,"{aggr_mtime_attr_name}");\n'
                                        f'if (type(t)~="boolean" and (tonumber(t) < {expected_time})) then '
                                        f'redis.call("HDEL",redis_hash, aggr_key); end;\n'
                                    )
                                    default_value = self._convert_python_obj_to_redis_value(
                                        aggregation_value.default_value
                                    )
                                    lua_script = (
                                        f'{lua_script}local curr_agg=redis.call("HGET",redis_hash, aggr_key)\n'
                                        "local arr=strToArr(curr_agg);\n"
                                        f"local org_arr_len=#arr\n"
                                        f"for i=1,({bucket.total_number_of_buckets}-org_arr_len) \
                                            do arr[#arr+1]={default_value};end;\n"
                                        f'if org_arr_len ~= #arr then redis.call("HSET", redis_hash, aggr_key,\
                                            table.concat(arr, ",")) end;\n'
                                    )
                                if array_time_attribute_key not in times_updates:
                                    times_updates[array_time_attribute_key] = expected_time_expr
                                new_cached_times[name] = (
                                    array_time_attribute_key,
                                    expected_time,
                                )

                            # Updating the specific cells
                            if cached_time <= expected_time:
                                new_value_expression = aggregation_value.aggregate_lua_script(
                                    "old_value", aggregation_value.value
                                )
                                lua_script = (
                                    f'{lua_script}arr=strToArr(redis.call("HGET",redis_hash, aggr_key))\n'
                                    f"old_value=tonum(arr[{lua_index_to_update}]);\n"
                                    f'arr[{lua_index_to_update}]=string.format("%.17f",{new_value_expression});\n'
                                    'redis.call("HSET", redis_hash, aggr_key, table.concat(arr, ","))\n'
                                )
                        lua_script = f'{lua_script}\
                            redis.call("HSET",redis_hash,"{aggr_mtime_attr_name}",{expected_time});'
        return lua_script, condition_expression, pending_updates, redis_keys_involved

    async def _save_key(self, container, table_path, key, aggr_item, partitioned_by_key, additional_data):
        redis_key_prefix = self._make_key(container, table_path, key)
        static_redis_key_prefix = self._static_data_key(redis_key_prefix)
        (
            update_expression,
            mtime_condition,
            pending_updates,
            redis_keys_involved,
        ) = self._build_feature_store_lua_update_script(
            redis_key_prefix, aggr_item, partitioned_by_key, additional_data
        )
        if not update_expression:
            return
        current_time = int(time.time_ns() / 1000)
        if mtime_condition is not None:
            update_expression = (
                f'if redis.call("HGET", "{static_redis_key_prefix}","{self._mtime_name}") == "{mtime_condition}" then\n'
                f'{update_expression}\
                    redis.call("HSET","{static_redis_key_prefix}","{self._mtime_name}",{current_time});\n'
                "return 1;else return 0;end;"
            )
        else:
            update_expression = (
                f"{update_expression}redis.call("
                f'"HSET","{static_redis_key_prefix}","{self._mtime_name}",{current_time});return 1;'
            )

        redis_keys_involved.append(static_redis_key_prefix)
        update_ok = await self.asyncify(self.redis.eval)(
            update_expression, len(redis_keys_involved), *redis_keys_involved
        )

        if update_ok:
            if aggr_item:
                aggr_item.storage_specific_cache[self._mtime_name] = current_time
        # In case Mtime condition evaluated to False, we run the conditioned
        # expression, then fetch and cache the latest key's state
        else:
            (
                update_expression,
                _,
                _,
                redis_keys_involved,
            ) = self._build_feature_store_lua_update_script(redis_key_prefix, aggr_item, False, additional_data)
            update_expression = (
                f"{update_expression}redis.call("
                f'"HSET","{static_redis_key_prefix}","{self._mtime_name}",{current_time});return 1;'
            )

            update_ok = await RedisDriver.asyncify(self.redis.eval)(
                update_expression, len(redis_keys_involved), *redis_keys_involved
            )
            if update_ok and aggr_item:
                await self._fetch_state_by_key(aggr_item, container, table_path, key)

    async def _get_all_fields(self, redis_key: str):
        values = await self.redis_hscan(redis_key, f"[^{self.INTERFNAL_FIELD_PREFIX}]*")
        res = {
            RedisDriver.convert_to_str(key): RedisDriver.convert_redis_value_to_python_obj(val)
            for key, val in values.items()
        }
        return res

    async def _get_specific_fields(self, redis_key: str, attributes: List[str]):
        non_aggregation_attrs = [name for name in attributes if not name.startswith(RedisDriver.INTERFNAL_FIELD_PREFIX)]
        try:
            values = await RedisDriver.asyncify(self.redis.hmget)(redis_key, non_aggregation_attrs)
        except redis.ResponseError as e:
            raise RedisError(f"Failed to get key {redis_key}. Response error was: {e}") from e
        if len(values) == 1:
            if values == [None]:
                return {}
            return {non_aggregation_attrs[0]: RedisDriver.convert_redis_value_to_python_obj(values[0])}
        else:
            return {
                RedisDriver.convert_to_str(k): RedisDriver.convert_redis_value_to_python_obj(v)
                for k, v in values.items()
            }

    async def _load_by_key(self, container, table_path, key, attributes):
        """
        Return all static attributes, or certain attributes.

        NOTE: Following the V3IO driver's implementation, this method will not
        return aggregation attributes or associated time values -- just static
        data, AKA "additional data."
        """
        redis_key_prefix = self._make_key(container, table_path, key)
        static_key = self._static_data_key(redis_key_prefix)
        if attributes == "*":
            values = await self._get_all_fields(static_key)
        else:
            values = await self._get_specific_fields(static_key, attributes)
        return values

    async def _get_associated_time_attr(self, redis_key_prefix, aggr_name):
        aggr_without_relevant_attr = aggr_name[:-2]
        feature_name_only = aggr_without_relevant_attr[: aggr_without_relevant_attr.rindex("_")]
        feature_with_relevant_attr = f"{feature_name_only}{aggr_name[-2:]}"
        aggr_mtime_attribute_name = f"{RedisDriver.AGGREGATION_TIME_ATTRIBUTE_PREFIX}{feature_with_relevant_attr}"

        associated_time_key = self._aggregation_time_key(redis_key_prefix, feature_with_relevant_attr)
        time_val = await RedisDriver.asyncify(self.redis.hget)(
            self._static_data_key(redis_key_prefix), aggr_mtime_attribute_name
        )
        time_val = RedisDriver.convert_to_str(time_val)

        try:
            time_in_millis = int(time_val)
        except TypeError as e:
            raise RedisError(f"Invalid associated time attribute: {associated_time_key} " f"-> {time_val}") from e

        # Return a form of the time attribute that Storey expects. This should include
        # name of the feature but not the aggregation name (min, max) or relevant
        # attribute (_a, _b).
        associated_time_attr = f"{RedisDriver.AGGREGATION_TIME_ATTRIBUTE_PREFIX}" f"{feature_with_relevant_attr}"

        return associated_time_attr, time_in_millis

    async def _load_aggregates_by_key(self, container, table_path, key):
        """
        Loads a specific key from the store, and returns it in the following format
        {
            'feature_name_aggr1': {<start time A>: [], {<start time B>: []}},
            'feature_name_aggr2': {<start time A>: [], {<start time B>: []}}
        }
        """
        redis_key_prefix = self._make_key(container, table_path, key)
        additional_data = await self._get_all_fields(self._static_data_key(redis_key_prefix))
        aggregations = {}
        # Aggregation Redis keys start with the Redis key prefix for this Storey container, table
        # path, and "key," followed by ":aggr_"
        redis_key_prefix = self._make_key(container, table_path, key)
        redis_key = self._static_data_key(redis_key_prefix)
        values = await self.redis_hscan(redis_key, f"{self.AGGREGATION_ATTRIBUTE_PREFIX}*")

        for aggr_key, value in values.items():
            # Build an attribute for this aggregation in the format that Storey
            # expects to receive from this method. The feature and aggregation
            # name are embedded in the Redis key. Also, drop the "_a" or "_b"
            # portion of the key, which is "the relevant attribute out of the 2
            # feature attributes," according to comments in the V3IO driver.
            value = RedisDriver.convert_to_str(value)
            value = value.split(",")
            aggr_key = aggr_key[len(self.AGGREGATION_ATTRIBUTE_PREFIX) :]
            aggr_key = RedisDriver.convert_to_str(aggr_key)
            feature_and_aggr_name = aggr_key[:-2]

            # To get the associated time, we need the aggregation name and the relevant
            # attribute (a or b), so we take a second form of the string for that purpose.
            aggr_name_with_relevant_attribute = aggr_key
            associated_time_attr, time_in_millis = await self._get_associated_time_attr(
                redis_key_prefix, aggr_name_with_relevant_attribute
            )
            if feature_and_aggr_name not in aggregations:
                aggregations[feature_and_aggr_name] = {}
            aggregations[feature_and_aggr_name][time_in_millis] = [
                float(RedisDriver.convert_redis_value_to_python_obj(v)) for v in value
            ]
            aggregations[feature_and_aggr_name][associated_time_attr] = time_in_millis

        # Story expects to get None back if there were no aggregations, and the
        # same for additional data.
        aggregations_to_return = aggregations if aggregations else None
        additional_data_to_return = additional_data if additional_data else None
        return aggregations_to_return, additional_data_to_return

    async def redis_hscan(self, redis_key, match):
        try:
            cursor = 0
            values = {}
            while True:
                cursor, v = await RedisDriver.asyncify(self.redis.hscan)(redis_key, cursor, match=match)
                values.update(v)
                if cursor == 0:
                    break
        except redis.ResponseError as e:
            raise RedisError(f"Failed to get key {redis_key}. Response error was: {e}")
        return values

    async def _fetch_state_by_key(self, aggr_item, container, table_path, key):
        redis_key_prefix = self._make_key(container, table_path, key)
        aggregations = {}
        # Aggregation Redis keys start with the Redis key prefix for this Storey container, table
        # path, and "key," followed by ":aggr_"
        redis_key_prefix = self._make_key(container, table_path, key)
        redis_key = self._static_data_key(redis_key_prefix)
        values = await self.redis_hscan(redis_key, f"{self.AGGREGATION_ATTRIBUTE_PREFIX}*")
        for aggr_key, value in values.items():
            # Build an attribute for this aggregation in the format that Storey
            # expects to receive from this method. The feature and aggregation
            # name are embedded in the Redis key. Also, drop the "_a" or "_b"
            # portion of the key, which is "the relevant attribute out of the 2
            # feature attributes," according to comments in the V3IO driver.
            value = RedisDriver.convert_to_str(value)
            value = value.split(",")
            aggr_key = aggr_key[len(self.AGGREGATION_ATTRIBUTE_PREFIX) :]
            aggr_key = RedisDriver.convert_to_str(aggr_key)
            feature_and_aggr_name = aggr_key[:-2]

            # To get the associated time, we need the aggregation name and the relevant
            # attribute (a or b), so we take a second form of the string for that purpose.
            aggr_name_with_relevant_attribute = aggr_key
            associated_time_attr, time_in_millis = await self._get_associated_time_attr(
                redis_key_prefix, aggr_name_with_relevant_attribute
            )
            if feature_and_aggr_name not in aggregations:
                aggregations[feature_and_aggr_name] = {}
            aggregations[feature_and_aggr_name][time_in_millis] = [
                float(RedisDriver.convert_redis_value_to_python_obj(v)) for v in value
            ]
            aggregations[feature_and_aggr_name][associated_time_attr] = time_in_millis

    def _get_time_attributes_from_aggregations(self, aggregation_element):
        attributes = {}
        for bucket in aggregation_element.aggregation_buckets.values():
            attributes[f"{bucket.name}_a"] = f"{RedisDriver.AGGREGATION_TIME_ATTRIBUTE_PREFIX}{bucket.name}_a"
            attributes[f"{bucket.name}_b"] = f"{RedisDriver.AGGREGATION_TIME_ATTRIBUTE_PREFIX}{bucket.name}_b"
        return list(attributes.values())

    async def _save_schema(self, container, table_path, schema):
        redis_key = self._make_key(container, table_path, schema_file_name)
        await RedisDriver.asyncify(self.redis.set)(redis_key, json.dumps(schema))

    async def _load_schema(self, container, table_path):
        redis_key = self._make_key(container, table_path, schema_file_name)
        schema = await RedisDriver.asyncify(self.redis.get)(redis_key)
        if schema:
            return json.loads(schema)
