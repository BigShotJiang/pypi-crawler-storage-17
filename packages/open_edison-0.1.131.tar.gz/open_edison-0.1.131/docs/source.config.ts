import { defineSource } from 'fumadocs-core'

export default defineSource({
  contentDir: '.',
  baseUrl: '/docs',
})
