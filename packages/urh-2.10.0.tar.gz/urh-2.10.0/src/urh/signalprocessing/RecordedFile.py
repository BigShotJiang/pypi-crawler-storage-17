class RecordedFile:
    def __init__(self, filename, sample_rate, timestamp):
        self.filename = filename
        self.sample_rate = sample_rate
        self.timestamp = timestamp
