VERSION = "2.10.0"

if __name__ == "__main__":
    # To read out version easy on command line for InnoSetup
    print(VERSION)
