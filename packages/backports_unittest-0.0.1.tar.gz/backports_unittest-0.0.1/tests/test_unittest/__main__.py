from . import load_tests
from backports import unittest

unittest.main()
