from backports import unittest

class PassingTest(unittest.TestCase):
    def test_true(self):
        self.assertTrue(True)
