from setuptools import setup

setup(
    name="exptime",
    version="0.1.3",       # increment version for new releases
    py_modules=["exptime"],  # single-file module
    python_requires=">=3.9",
    description="A simple module that can make custom timeout-based expections.",
    author="wirnty",
    author_email="skedovichusjdj@gmail.com",
    url="https://pypi.org/project/exptime/",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)