# Typed Okx

> A fully typed, validated async client for the Okx API

Use *autocomplete* instead of documentation.

🚧 Under construction.