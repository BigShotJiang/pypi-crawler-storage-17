"""
### Typed Okx
> A fully typed, validated async client for the Okx API

- Details
"""