from functools import lru_cache
import cv2,PyPDF2,pytesseract,cv2,pysrt
import numpy as np
from pdf2image import convert_from_path
from PIL import Image
