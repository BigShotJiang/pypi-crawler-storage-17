import 'bootstrap-sass'

window.$ = require('jquery')
window.Cookies = require('js-cookie')
