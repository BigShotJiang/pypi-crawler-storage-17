'''
Generic settings to be used with rdmo-admin outside of an rdmo-app.
'''

from rdmo.core.settings import *  # noqa: F403

ROOT_URLCONF = ''

DATABASES = {}

STATIC_ROOT = 'static_root'
