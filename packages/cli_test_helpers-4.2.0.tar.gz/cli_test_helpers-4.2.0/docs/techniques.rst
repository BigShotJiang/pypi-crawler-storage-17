Techniques
==========

Test-driven Development (TDD)
-----------------------------

Remember to stick to the test-driven mantra:

#. Write one line of test code. Make the test fail.
#. Write one line of application code. Make the test pass.
#. Goto 1.
