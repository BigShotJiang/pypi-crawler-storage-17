from brainscore_language import benchmark_registry
from .benchmark import Futrell2018Pearsonr

benchmark_registry['Futrell2018-pearsonr'] = Futrell2018Pearsonr
