from brainscore_language import benchmark_registry
from .benchmark import Blank2014Linear

benchmark_registry['Blank2014-linear'] = Blank2014Linear
