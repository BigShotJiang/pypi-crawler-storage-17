def test_can_import():
    # noinspection PyUnresolvedReferences
    import brainscore_language
