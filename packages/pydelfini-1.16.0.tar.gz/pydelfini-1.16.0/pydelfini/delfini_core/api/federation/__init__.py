"""Federation operations"""
