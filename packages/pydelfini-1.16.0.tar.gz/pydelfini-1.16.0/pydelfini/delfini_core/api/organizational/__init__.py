"""Organizational operations"""
