"""Configuration templates for bioamla projects."""

AVAILABLE_TEMPLATES = ["default", "minimal", "research", "production"]
