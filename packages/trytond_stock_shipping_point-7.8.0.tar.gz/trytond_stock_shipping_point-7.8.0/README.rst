###########################
Stock Shipping Point Module
###########################

The *Stock Shipping Point Module* adds a shipping point to shipments.

.. toctree::
   :maxdepth: 2

   design
   releases
