"""Utility helpers for PagerDuty toolkit."""
