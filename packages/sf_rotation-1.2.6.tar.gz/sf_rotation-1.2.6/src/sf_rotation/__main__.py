"""
Allow running as: python -m sf_rotation
"""
from .main import main

if __name__ == "__main__":
    main()
