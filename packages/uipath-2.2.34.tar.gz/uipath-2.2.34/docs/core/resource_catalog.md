::: uipath.platform.resource_catalog._resource_catalog_service
