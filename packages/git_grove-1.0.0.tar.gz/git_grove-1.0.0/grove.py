import argparse
from operator import itemgetter
import os
import json
import subprocess
import logging
import sys
from contextlib import contextmanager

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

TREE_MODE = "040000"
BLOB_MODE = "100644"
DEFAULT_REMOTE = "origin"
def remote_name(ref):
    return f"{DEFAULT_REMOTE}/{ref}"

def run_git_output(command, cwd, input_str=None):
    """Runs git and returns stripped output. Handles pipes via input_str."""
    try:
        logger.debug(f"Running command: {command} in {cwd}")
        res = subprocess.run(
            command, cwd=cwd, shell=True, check=True,
            input=input_str, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        logger.debug(f'Output of command: {res.stdout}\n\n{res.stderr}')
        return res.stdout.strip()
    except subprocess.CalledProcessError as e:
        logger.error(f"Git command failed: {e.stderr.strip()}")
        return None

def with_slash(name):
    if not name.endswith('/'):
        return name + '/'
    return name

class _TreeFrame:
    __slots__ = ("name", "data", "parent", "entries")

    def __init__(self, name: str, data: dict, parent: "_TreeFrame | None"):
        self.name = name
        self.data = data
        self.parent = parent
        self.entries = []  # list[tuple[str, str]] of (name, mktree_line)

class Repository:
    def __init__(self, name, url, output_dir, cache_dir):
        self.name = name
        self.url = url
        self.output_dir = os.path.abspath(output_dir)
        self.cache_dir = os.path.abspath(cache_dir)
        self.data_dir = os.path.join(self.cache_dir, name)
        self.index_file = os.path.join(self.data_dir, "sync_index")
    
    def clone(self):
        if os.path.exists(self.data_dir):
            logger.debug(f"Repository '{self.name}' already cloned.")
            return

        logger.info(f"Cloning repository '{self.name}' from {self.url}...")
        p = subprocess.run(f"git clone --filter=blob:none --no-checkout {self.url} {self.data_dir}", 
                        cwd=self.cache_dir, shell=True, check=True)
        
        logger.debug(f'Output of git clone: {p.stdout}\n\n{p.stderr}')
    
    def fetch(self):
        logger.info(f"Fetching latest updates for repository '{self.name}'...")
        p = subprocess.run(f"git fetch {DEFAULT_REMOTE}", cwd=self.data_dir, shell=True, check=True)

        logger.debug(f'Output of git fetch: {p.stdout}\n\n{p.stderr}')

    def get_ref_target(self, ref):
        if os.path.exists(os.path.join(self.data_dir, '.git', 'refs', 'heads', ref)):
            return remote_name(ref)
        elif os.path.exists(os.path.join(self.data_dir, '.git', 'packed-refs')):
            packed_refs_path = os.path.join(self.data_dir, '.git', 'packed-refs')
            with open(packed_refs_path, 'r') as f:
                for line in f.read().splitlines():
                    if line.rstrip().endswith(ref):
                        return remote_name(ref)
                
        return ref

    def get_latest_commit(self, rev):
        commit_hash = run_git_output(f"git rev-parse {self.get_ref_target(rev)}", self.data_dir)
        if not commit_hash:
            raise ValueError(f"Branch '{rev}' not found in repository '{self.name}'")
        
        return commit_hash
    
    def get_object(self, rev, path):
        """
        Returns (mode, type, hash) for any path (File OR Folder).
        """
        clean_path = path.strip('/')
        
        obj_hash = run_git_output(f"git rev-parse {self.get_ref_target(rev)}:{clean_path}", self.data_dir)
        if not obj_hash:
            return None
        
        obj_type = run_git_output(f"git cat-file -t {obj_hash}", self.data_dir)
        
        if obj_type == "tree":
            return (TREE_MODE, "tree", obj_hash)
        elif obj_type == "blob":
            return (BLOB_MODE, "blob", obj_hash)
        
        return None
    
    def get_env(self):
        env = os.environ.copy()
        env.update({
            "GIT_DIR": os.path.join(self.data_dir, ".git"),
            "GIT_INDEX_FILE": self.index_file,     # <--- Points to the persistent file
            "GIT_WORK_TREE": self.output_dir
        })

        return env
    
    def insert_into_tree(self, tree, parts, leaf):
        """
        Inserts a path into the nested dictionary structure (Trie).
        """
        current = tree
        # Navigate to the parent of the leaf
        for part in parts[:-1]:
            if part not in current:
                current[part] = {}
            current = current[part]
            
            # Conflict Resolution: If a file path overlaps a directory path, 
            # the deeper structure wins (this clears the conflicting leaf).
            if "__type__" in current: 
                current.clear() 

        # Set the leaf
        leaf_name = parts[-1]
        current[leaf_name] = leaf

    def mktree(self, stdin):
        return run_git_output("git mktree", cwd=self.data_dir, input_str=stdin)

    def parse_paths(self, rev, paths):
        file_tree = {}
        valid_targets = False
        
        for path in paths:
            logger.debug(f"Processing path: {path}")
            details = self.get_object(rev, path)
            logger.debug(f"Details for path '{path}': {details}")
            
            if details:
                mode, obj_type, obj_hash = details
                valid_targets = True
                
                leaf_data = {
                    "__mode__": mode,
                    "__type__": obj_type,
                    "__hash__": obj_hash
                }
                
                if not path.strip():
                    # is root path (it also covers all other paths)
                    return {'': leaf_data}

                parts = path.strip('/').split('/')
                self.insert_into_tree(file_tree, parts, leaf_data)
            else:
                logger.warning(f"Path '{path}' not found in remote.")
                if os.path.exists(os.path.join(self.output_dir, path.strip('/'))):
                    logger.error(f"Path {path} exists locally. Please remove it or remove this path from the registry.")
                    raise RuntimeError(f"Path {path} exists locally.")

        if not valid_targets:
            raise ValueError("No valid targets found.")
        
        return file_tree

    def build_mktree_entries(self, rev, paths):
        # if specified root path (empty path), the tree_dict will look like:
        # {
        #   '': {
        #           '__mode__': '040000',
        #           '__type__': 'tree',
        #           '__hash__': '<root hash>'
        #       }
        #  }
        tree_dict = self.parse_paths(rev, paths)
        if '' in tree_dict:
            # root path specified, return its hash directly
            logger.debug("Root path specified, returning its hash directly.")
            return tree_dict['']['__hash__']

        return self._build_mktree_entries(tree_dict)

    def _build_mktree_entries_legacy(self, tree_dict):
        """
        Recursively writes git trees using 'git mktree'.
        Returns the hash of the newly created tree.
        """

        mktree_entries = []
        
        for name, data in tree_dict.items():
            if "__type__" in data:
                # It's a Leaf Node (Existing File or Folder from Remote)
                # Format: <mode> <type> <hash> <name>
                entry = f"{data['__mode__']} {data['__type__']} {data['__hash__']}\t{name}"
                mktree_entries.append(entry)
                logger.debug(f"Added leaf entry: {entry}")
            else:
                # It's a Branch Node (Virtual Folder we created)
                # Recurse down to build it first
                subtree_hash = self._build_mktree_entries_legacy(data)
                entry = f"{TREE_MODE} tree {subtree_hash}\t{name}"
                mktree_entries.append(entry)
                logger.debug(f"Added branch entry: {entry}")
                
        # Git mktree requires entries to be sorted for deterministic tree hash generation
        mktree_entries.sort(key=lambda x: x.split('\t')[1])

        logger.debug(f"mktree entries at current level: {mktree_entries}")
        
        return self.mktree("\n".join(mktree_entries))
    
    def _build_mktree_entries(self, tree_dict):
        ENTER, EXIT = 0, 1
        root = _TreeFrame("", tree_dict, None)

        stack: 'list[tuple[_TreeFrame, int]]' = [(root, ENTER)]
        result = None

        while stack:
            node, phase = stack.pop()

            if phase == ENTER:
                stack.append((node, EXIT))

                # Collect leaf entries; schedule branch nodes
                for name, data in node.data.items():
                    if "__type__" in data:
                        _type = data['__type__']
                        entry = f"{data['__mode__']} {_type} {data['__hash__']}\t{name}"
                        node.entries.append((with_slash(name) if _type == 'tree' else name, entry))
                        logger.debug(f"Added leaf entry: {entry}")
                    else:
                        stack.append((_TreeFrame(name, data, node), ENTER))

                node.data = None  # release reference early
                continue

            # EXIT phase: children already computed and appended into node.entries
            node.entries.sort(key=itemgetter(0))
            logger.debug(f"mktree entries at current level: {node.entries}")
            stdin = "\n".join(entry for _, entry in node.entries)
            subtree_hash = self.mktree(stdin)
            result = subtree_hash

            if node.parent is not None:
                entry = f"{TREE_MODE} tree {subtree_hash}\t{node.name}"
                node.parent.entries.append((with_slash(node.name), entry))
                logger.debug(f"Added branch entry: {entry}")

        return result


    def ensure_latest(self, rev):
        self.clone()
        self.fetch()
        latest_commit = self.get_latest_commit(rev)
        return latest_commit

    def read_tree(self, tree_hash):
        logger.debug(f"Reading tree {tree_hash} into output directory {self.output_dir}...")

        env = self.get_env()
        logger.debug(f'Using env: {env}')

        self.ensure_output_dir()

        # --reset: Tells Git "Make the index AND disk match this new tree"
        # -u:     Update working files
        subprocess.run(f"git read-tree -u --reset {tree_hash}",
                     cwd=self.data_dir, shell=True, check=True, env=env)
    
    def ensure_output_dir(self):
        if not os.path.exists(self.output_dir):
            logger.debug(f"Creating output directory: {self.output_dir}")
            os.makedirs(self.output_dir, exist_ok=True)

class SyncData:
    def __init__(self, name, url, rev, paths, target, last_synced, details):
        self.name = name
        self.url = url
        self.rev = rev
        self.paths = paths
        self.target = target
        self.last_synced = last_synced
        self.details = details

    def update_last_synced(self, commit_hash):
        self.last_synced = commit_hash
        self.details['last_synced'] = commit_hash

def sync_repository(data: SyncData, cache_dir):
    repo = Repository(data.name, data.url, data.target, cache_dir)

    logger.info(f"Processing revision {data.name} @ {data.rev}")

    logger.debug(f'SyncData: {data.__dict__}')

    latest_commit = repo.ensure_latest(data.rev)
    # check only commit hash because git has its own diff algorithm which is written in C
    if data.last_synced == latest_commit:
        logger.info(f"Already up-to-date at commit {latest_commit}. Skipping.")
        return repo, False

    logger.info(f"Latest Commit: {latest_commit}")
    logger.info(f'Update last_synced for {data.name} to {latest_commit}')
    data.update_last_synced(latest_commit)

    return repo, True

def sync_single(data: SyncData, cache_dir):
    repo, updated = sync_repository(data, cache_dir)
    if not updated:
        return False

    tree_hash = repo.build_mktree_entries(data.rev, data.paths)
    logger.info(f"Built Tree Hash: {tree_hash}")

    repo.read_tree(tree_hash)
    logger.info(f"Synced to: {repo.output_dir}")
    return True

def get_repository_display(repo):
    return repo.get('name', None) or repo.get('url')

def url_warning_check(url):
    if not (url.startswith("http://") or url.startswith("https://") or url.startswith("git@") or url.startswith("ssh://")):
        logger.warning(f"The URL '{url}' does not appear to be a standard Git URL."
                        "Please ensure it is correct to avoid issues during synchronization.")

def sync_single_sparse_checkout(data: SyncData, cache_dir, sparse_mode):
    repo, updated = sync_repository(data, cache_dir)
    if not updated:
        return False

    env = repo.get_env()

    mode_flag = f"--{sparse_mode}"

    path_arguments = " ".join(data.paths if sparse_mode == "cone" else [f"/{path.strip('/')}" for path in data.paths])
        
    repo.ensure_output_dir()

    logger.info(f"Setting sparse-checkout with mode '{sparse_mode}' for paths: {data.paths}")
    # sparse-checkout maintains a global sparse-checkout file in .git/info/sparse-checkout for all branches,
    # when running in parallel, this may cause race conditions
    #
    # related code:
    # char *get_sparse_checkout_filename(void)
    # {
    # 	return repo_git_path(the_repository, "info/sparse-checkout");
    # }
    #
    # Core machanism of sparse-checkout:
    # static int update_working_directory(struct repository *r,
	#			     struct pattern_list *pl)
    subprocess.run(f"git sparse-checkout set {mode_flag} {path_arguments}",
                   cwd=repo.data_dir, shell=True, check=True, env=env)

    logger.info(f"Checking out revision '{data.rev}'...")
    subprocess.run(f"git reset --hard {repo.get_ref_target(data.rev)}",
                   cwd=repo.data_dir, shell=True, check=True, env=env)

    logger.info(f"Synced to: {repo.output_dir}")
    return True

def registry_updated(func):
    def wrapper(self: 'Registry', *args, **kwargs):
        result = func(self, *args, **kwargs)
        self.notify_update()
        return result

    return wrapper

def name_from_url(url):
    name = url.split('/')[-1]
    if name.endswith('.git'):
        name = name[:-4]
    return name

def name_of_repository(repo, precomputed_url=None):
    name = repo.get('name', None)
    if name is None:
        url = precomputed_url or repo.get('url')
        name = name_from_url(url)

    return name

class Registry:
    '''
    Loads and parses the registry file.
    Format:
        {
            // directory to store cached git repositories
            "cache_dir": "path/to/cache", // optional, default is .cache
            // directory to store synced files
            "target_dir": "path/to/target", // optional, default is current dir
            // backend to use for syncing files
            "backend": "mktree | sparse-checkout", // optional, default is mktree
            // only used when backend is sparse-checkout
            "sparse-checkout": {
                "mode": "cone | no-cone", // optional, default is no-cone
                ...
            } 
            ...
            "repositories": [
                {
                    "name": "xxx", // optional, default value is derived from url
                    "url": "xxx", // required
                    "revisions": { // branch name, commit hash or other references
                        "xxx": {
                            "paths": ["path1", "path2", ...], // path to sync
                            // relative path to <target_dir> in unix style
                            "target": "path/to/target" // optional, default to <name> or <name>/<revision> if multiple revisions exist
                            "last_synced": "commit_hash" // optional, used for tracking
                        }
                        ...
                    }
                },
                ...
            ]
        }
    '''
    BACKEND_MODES = ('mktree', 'sparse-checkout')
    def __init__(self, registry_file):
        self.registry_file = registry_file

        self.load_registry()

        self.flags = {}

    def set_flag(self, key, value=True):
        self.flags[key] = value

    def unset_flag(self, key):
        if key in self.flags:
            del self.flags[key]

    @registry_updated
    def init_registry(self):
        logger.info("Initializing new registry...")
        self._data = {}
        self._data['repositories'] = []

    @registry_updated
    def _add_repository(self, repo_data):
        self._data['repositories'].append(repo_data)

    @registry_updated
    def set_cache_dir(self, cache_dir):
        self._data['cache_dir'] = cache_dir
        
    @registry_updated
    def set_target_dir(self, target_dir):
        self._data['target_dir'] = target_dir

    @registry_updated
    def set_backend(self, backend):
        self._data['backend'] = backend

    def find_repository(self, name_or_url):
        for repo in self._data.get('repositories', []):
            url = repo.get('url')
            if url is None:
                logger.warning(f"Repository entry missing 'url': {repo}")
                continue

            if url == name_or_url:
                return repo

            name = name_of_repository(repo, precomputed_url=url)

            if name == name_or_url:
                return repo

        logger.debug(f"Repository '{name_or_url}' not found in registry.")
        return None

    def evaluate_next(self, obj, key: str):
        if isinstance(obj, list):
            if key.isdigit():
                try:
                    i = int(key)
                except ValueError:
                    logger.error(f"Invalid list index '{key}'.")
                    return None
            
                if i < 0 or i >= len(obj):
                    logger.error(f"List index '{i}' out of range.")
                    return None
                
                return obj[i]
            else:
                repo = self.find_repository(key)
                if repo is not None:
                    return repo
                
                logger.error(f"Invalid list index '{key}' and no matching item found.")
        elif isinstance(obj, dict):
            if key not in obj:
                logger.error(f"Key '{key}' not found in the registry.")
                return None

            return obj.get(key)
        else:
            logger.error(f'Invalid object type ({type(obj)}) encountered during evaluation.')
            return None

    def _get_path(self, path: str):
        index = 0
        prev = 0
        current = self._data
        while True:
            index = path.find('.', index)
            if index == -1:
                break

            if path[index - 1] == '\\':
                index += 1
                continue

            part = path[prev:index].replace('\\.', '.')
            prev = index + 1
            index += 1

            current = self.evaluate_next(current, part)
        
        return current, path[prev:]

    def unset(self, path):
        parent, key = self._get_path(path)
        if parent is not None and key in parent:
            del parent[key]
            self.notify_update()
            logger.info(f"Unset value at path '{path}'.")

    def set_value(self, path, value):
        parent, key = self._get_path(path)
        if parent is not None:
            self.update(parent, key, value)
            logger.info(f"Set value at path '{path}' to '{value}'.")

    @registry_updated
    def update(self, obj, attr, value):
        if obj is None:
            obj = self._data

        if isinstance(obj, dict):
            obj[attr] = value
        elif isinstance(obj, list):
            try:
                index = int(attr)
            except ValueError:
                logger.error(f"Invalid list index '{attr}'.")
                return

            if index < 0 or index >= len(obj):
                logger.error(f"List index '{index}' out of range.")
                return

            obj[index] = value
        else:
            logger.error(f"Object is neither a dictionary nor a list.")

    def add_revision(self, name_or_url, revision, paths, target=None, last_synced=None, name=None):
        repo = self.find_repository(name_or_url)
        if repo is None:
            logger.info(f"Adding new repository '{name_or_url}' to registry.")

            url_warning_check(name_or_url)

            repo = {
                'url': name_or_url,
                'revisions': {}
            }
            self._add_repository(repo)
        
        if name is not None:
            if 'name' in repo and repo['name'] != name:
                logger.error(f"Repository name conflict: existing '{repo['name']}', new '{name}'")
                return

            self.update(repo, 'name', name)

        revisions = repo['revisions']
        if revision not in revisions:
            self.update(revisions, revision, {})

        rev_data = revisions[revision]

        current_paths = set(rev_data.get('paths', set()))
        current_paths_num = len(current_paths)
        current_paths.update(paths)
        if len(current_paths) > current_paths_num:
            self.update(rev_data, 'paths', list(current_paths))
            logger.info(f"Added/Updated revision '{revision}' in repository '{get_repository_display(repo)}'.")

        if target is not None:
            self.update(rev_data, 'target', target)
            logger.info(f"Set target for revision '{revision}' in repository '{get_repository_display(repo)}' to '{target}'.")

        if last_synced is not None:
            self.update(rev_data, 'last_synced', last_synced)
            logger.info(f"Set last_synced for revision '{revision}' in repository '{get_repository_display(repo)}' to '{last_synced}'.")


    def remove_revision(self, name_or_url, revision, paths=None):
        repo = self.find_repository(name_or_url)
        if repo is None:
            logger.error(f"Repository '{get_repository_display(repo)}' not found.")
            return

        revisions = repo['revisions']
        if revision not in revisions:
            logger.error(f"Revision '{revision}' not found in repository '{get_repository_display(repo)}'.")
            return

        rev_data = revisions[revision]
        if paths is None:
            self.update(rev_data, 'paths', [])
            logger.info(f"Removed all paths from revision '{revision}' in repository '{get_repository_display(repo)}'.")
        else:
            existing_paths = rev_data.get('paths', [])
            paths = set(paths)
            self.update(rev_data, 'paths', [p for p in existing_paths if p not in paths])
            logger.info(f"Removed specified paths from revision '{revision}' in repository '{get_repository_display(repo)}'.")

        if not rev_data['paths']:
            del revisions[revision]
            logger.info(f"Removed revision '{revision}' from repository '{get_repository_display(repo)}' as it has no more paths.")
            self.notify_update()
            if not revisions:
                self._data['repositories'].remove(repo)
                logger.info(f"Removed repository '{get_repository_display(repo)}' as it has no more revisions.")

    def unset_updated(self):
        self.updated = False

    def notify_update(self):
        self.updated = True

    def dump_registry(self):
        if not self.updated:
            logger.info("No updates to registry. Skipping save.")
            return

        logger.info("Saving updated registry...")
        with open(self.registry_file, 'w') as f:
            json.dump(self._data, f, indent=4)
            self.updated = False

    def load_registry(self):
        if not os.path.exists(self.registry_file):
            logger.warning(f"Registry file {self.registry_file} not found.")
            self.init_registry()
            return
        
        with open(self.registry_file, 'r') as f:
            data = json.load(f)
        
        self._data = data
            
        self.updated = False
        
    @property
    def repositories(self) -> list:
        return self._data.get('repositories', [])
    
    @property
    def cache_dir(self) -> str:
        return self._data.get('cache_dir', os.path.join(os.getcwd(), '.cache'))

    @property
    def target_dir(self) -> str:
        return self._data.get('target_dir', os.getcwd())

    @property
    def backend(self):
        mode = self._data.get('backend', 'mktree')
        if mode not in self.BACKEND_MODES:
            logger.warning(f"Unknown backend '{mode}'. Falling back to '{self.BACKEND_MODES[0]}'.")
            mode = self.BACKEND_MODES[0]

        config = self._data.get(mode, {})
        if mode == 'sparse-checkout':
            sparse_mode = config.get('mode', 'no-cone')
            if sparse_mode not in ('cone', 'no-cone'):
                logger.warning(f"Unknown sparse-checkout mode '{sparse_mode}'. Falling back to 'no-cone'.")
                sparse_mode = 'no-cone'

            config['mode'] = sparse_mode

            self.update(self._data, mode, config)

        return mode, config

    def get_filtered_revisions(self, repo):
        return repo.get('revisions', {}).keys()

    def filter_targets(self, targets):
        to_keep = {}
        for target in targets:
            if ':' in target:
                name_or_url, revision = target.split(':', 1)
            else:
                name_or_url = target
                revision = None
            
            if name_or_url not in to_keep:
                to_keep[name_or_url] = set()
            
            if revision is not None:
                to_keep[name_or_url].add(revision)
            else:
                to_keep[name_or_url] = True # Mark to keep all revisions

        def get_filtered_revisions(repo):
            url = None
            name = repo.get('name', None)
            if name is None:
                url = repo.get('url')
                name = name_of_repository(repo, precomputed_url=url)

            if name in to_keep:
                return to_keep[name]

            url = url or repo.get('url')
            if url in to_keep:
                return to_keep[url]

            return False

        self.get_filtered_revisions = get_filtered_revisions

    def __iter__(self):
        for repo in self.repositories:
            url = repo.get('url')
            name = name_of_repository(repo, precomputed_url=url)
            #repo['name'] = name

            # True, Fasle, or Set of revisions to keep
            filtered_revs = self.get_filtered_revisions(repo)
            if filtered_revs is False:
                continue

            revisions = repo.get('revisions', {})
            multi_rev = len(revisions) > 1
            for rev, details in revisions.items():
                if filtered_revs is not True and rev not in filtered_revs:
                    continue

                # filtered_rev is either True or a Set containing this rev

                paths = details.get('paths', [])
                target = details.get('target', None)
                if target is None:
                    target = f'{name}/{rev}' if multi_rev else name
                    #details['target'] = target
                
                last_synced = None if self.flags.get('force') else details.get('last_synced', None)
                yield SyncData(name, url, rev, paths, os.path.join(self.target_dir, target), last_synced, details)
        

def read_registry(registry_file):
    logger.info(f"Using registry file: {registry_file}")
    return Registry(registry_file)

def get_registry(args):
    return read_registry(args.registry)

def sync_dispatcher(backend_mode, backend_config):
    if backend_mode == 'mktree':
        logger.info("Using mktree backend for synchronization.")
        return sync_single
    elif backend_mode == 'sparse-checkout':
        sparse_mode = backend_config.get('mode')

        logger.info("Using sparse-checkout backend for synchronization.")
        logger.info(f"Sparse-checkout mode: {sparse_mode}")

        def wrapper(data: SyncData, cache_dir):
            return sync_single_sparse_checkout(data, cache_dir, sparse_mode=sparse_mode)

        return wrapper
    else:
        logger.error(f"Unknown backend mode: {backend_mode}")
        return lambda data, cache_dir: False


def sync(registry: Registry):
    try:
        logger.info("Starting synchronization process...")
        os.makedirs(registry.cache_dir, exist_ok=True)
        os.makedirs(registry.target_dir, exist_ok=True)
        
        _sync = sync_dispatcher(*registry.backend)

        for data in registry:
            if _sync(data, registry.cache_dir):
                registry.notify_update()

    except Exception as e:
        logger.error(f"Synchronization failed: {str(e)}")
        registry.unset_updated()
    finally:
        logger.info("Ending synchronization process...")
        registry.dump_registry()
        logger.info("Synchronization process ended.")

def handle_sync(args):
    registry = get_registry(args)
    if args.target:
        registry.filter_targets(args.target)

    if args.force:
        registry.set_flag('force')

    sync(registry)

@contextmanager
def get_registry_from(args):
    registry = get_registry(args)
    try:
        yield registry
    finally:
        registry.dump_registry()

def handler(func):
    def wrapper(args):
        with get_registry_from(args) as registry:
            func(registry, args)
    
    return wrapper

@handler
def handle_add(registry: Registry, args):
    registry.add_revision(
        name_or_url=args.name_or_url,
        revision=args.revision,
        paths=args.paths,
        target=args.target,
        last_synced=args.last_synced,
        name=args.name
    )

@handler
def handle_remove(registry: Registry, args):
    registry.remove_revision(
        name_or_url=args.name_or_url,
        revision=args.revision,
        paths=args.paths if args.paths else None
    )

@handler
def handle_set(registry: Registry, args):
    registry.set_value(args.path, args.value)

@handler
def handle_unset(registry: Registry, args):
    registry.unset(args.path)

@handler
def handle_list(registry: Registry, args):
    if args.path:
        parent, key = registry._get_path(args.path)
        value = registry.evaluate_next(parent, key)
        print(value)
        return

    for repo in registry.repositories:
        repo_display = get_repository_display(repo)
        revisions = repo.get('revisions', {})
        for rev, details in revisions.items():
            paths = details.get('paths', [])
            for path in paths:
                print(f"{repo_display} {rev} {path}")

@handler
def handle_batch_add(registry: Registry, args):
    if args.file:
        with open(args.file, 'r') as f:
            lines = f.readlines()
    else:
        logger.info("Reading from stdin. Press Ctrl+D (Unix) or Ctrl+Z (Windows) to end input.")
        lines = sys.stdin.readlines()
    
    for line in lines:
        parts = line.strip().split()
        if len(parts) < 3:
            logger.warning(f"Skipping invalid line: {line.strip()}. Expected format: <repo_name_or_url> <revision> <path1> [<path2> ...]")
            continue
        
        name_or_url = parts[0]
        revision = parts[1]
        paths = parts[2:]

        registry.add_revision(
            name_or_url=name_or_url,
            revision=revision,
            paths=paths
        )

def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('-v', '--verbose', action='store_true', help="Enable verbose output")
    parser.add_argument('-r', '--registry', type=str, default='./registry.json', help="Path to the registry file")

    subparsers = parser.add_subparsers(dest='subcommand', title='subcommands', required=True)

    parser_sync = subparsers.add_parser('sync', help='Synchronize repositories based on the registry file')
    parser_sync.add_argument('target', nargs='*', help='Optional targets (<repo_name_or_url>[:<revision>]) to sync')
    parser_sync.add_argument('-f', '--force', action='store_true', help="Force synchronization even if up-to-date")
    parser_sync.set_defaults(func=handle_sync)

    parser_add = subparsers.add_parser('add', help='Add a repository/revision/path to the registry')
    parser_add.add_argument('name_or_url', help='Repository name or URL')
    parser_add.add_argument('revision', help='Revision to add (branch, tag, commit hash)')
    parser_add.add_argument('paths', nargs='+', help='Paths to sync')
    parser_add.add_argument('--name', type=str, help='Set a name for the repository')
    parser_add.add_argument('--target', type=str, help='Target output directory')
    parser_add.add_argument('--last_synced', type=str, help='Commit hash to add as last_synced')
    parser_add.set_defaults(func=handle_add) 

    parser_remove = subparsers.add_parser('rm', help='Remove a repository/revision/path from the registry')
    parser_remove.add_argument('name_or_url', help='Repository name or URL')
    parser_remove.add_argument('revision', help='Revision to remove (branch, tag, commit hash)')
    parser_remove.add_argument('paths', nargs='*', help='Paths to remove')
    parser_remove.set_defaults(func=handle_remove) 

    parser_set = subparsers.add_parser('set', help='Set a value in the registry')
    parser_set.add_argument('path', help='Path to a field in the registry to set (E.g., repositories.<index, name or url>.name); '
                                            'Dot "." can be escaped with "\\"')
    parser_set.add_argument('value', help='Value to set at the specified path')
    parser_set.set_defaults(func=handle_set) 

    parser_unset = subparsers.add_parser('unset', help='Unset a value in the registry')
    parser_unset.add_argument('path', help='Path to a field in the registry to unset (E.g., repositories.<index, name or url>.name); '
                                            'Dot "." can be escaped with "\\"')
    parser_unset.set_defaults(func=handle_unset)

    parser_list = subparsers.add_parser('ls', help='List repositories and revisions in the registry')
    parser_list.add_argument('path', nargs='?', help='Path to a value in the registry to list '
                                                        '(E.g., repositories.<index, name or url>.name); '
                                                        'Dot "." can be escaped with "\\"')
    parser_list.set_defaults(func=handle_list)

    parser_batch_add = subparsers.add_parser('batch-add', help='Batch add repositories/revisions/paths from a file to the registry')
    parser_batch_add.add_argument('file', nargs='?', help='Path to the file to add from; if not provided, reads from stdin;'
                                                            'format: one entry per line: <repo_name_or_url> <revision> <path1> [<path2> ...]')
    parser_batch_add.set_defaults(func=handle_batch_add)
    

    if len(sys.argv) == 1:
        parser.print_help(sys.stderr)
        sys.exit(1)

    args = parser.parse_args()

    if args.verbose:
        logger.info("Verbose mode enabled.")
        logger.setLevel(logging.DEBUG)

    if not hasattr(args, 'func'):
        parser.print_help()
        sys.exit(1)

    return args


def main():
    args = parse_args()
    args.func(args)

if __name__ == "__main__":
    main()