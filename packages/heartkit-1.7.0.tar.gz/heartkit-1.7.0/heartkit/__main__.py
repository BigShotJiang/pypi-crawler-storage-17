from heartkit import cli

cli.main()
