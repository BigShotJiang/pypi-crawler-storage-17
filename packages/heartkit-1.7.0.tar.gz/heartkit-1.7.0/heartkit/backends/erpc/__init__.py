#!/usr/bin/env python

# Copyright 2016 NXP
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

import os
import typing

# Yocto and python27 combination
if "IS_YOCTO" in os.environ:
    from . import erpc_version
else:
    from . import (
        arbitrator,
        basic_codec,
        client,
        codec,
        crc16,
        server,
        simple_server,
        transport,
    )


class Reference(object):
    """Simple container class used for pass by reference."""

    def __init__(self, value: typing.Any = None):
        # Read/write attribute holding the referent.
        self.value = value

    def __str__(self):
        return "<%s@%x value=%s>" % (self.__class__.__name__, id(self), repr(self.value))

    def __repr__(self):
        return self.__str__()
