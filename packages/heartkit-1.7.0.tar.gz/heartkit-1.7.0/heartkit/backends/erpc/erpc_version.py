#!/usr/bin/env python

# Copyright 2017-2022 NXP
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

# Should be same as in erpc_version.h
ERPC_VERSION = "1.9.1"
