"""
# Data Assets API

This module includes built-in datasets.

"""
