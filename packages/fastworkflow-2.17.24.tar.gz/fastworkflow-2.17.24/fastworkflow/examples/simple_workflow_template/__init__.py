"""Simple workflow template for fastWorkflow inheritance examples."""
