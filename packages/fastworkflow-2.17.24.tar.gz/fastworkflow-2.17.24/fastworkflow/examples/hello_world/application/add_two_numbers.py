def add_two_numbers(a: float, b: float) -> float:
    return a+b