# keepachangelog-parser

## Usage

```
usage: keepachangelog_parser [-h] file

positional arguments:
  file        path to file to CHANGELOG.md to parse

options:
  -h, --help  show this help message and exit
```
