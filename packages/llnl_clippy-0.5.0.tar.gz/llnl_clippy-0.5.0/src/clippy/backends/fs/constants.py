# Constants unique to the fs backend.
# the flag to pass for a dry run to make sure syntax is proper

DRY_RUN_FLAG = "--clippy-validate"
# the flag to pass to get detailed help for constructing the class
HELP_FLAG = "--clippy-help"
