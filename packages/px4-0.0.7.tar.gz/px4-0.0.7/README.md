# PX4 CLI Utility

A command-line interface for commanding PX4 quadrotors over MAVLink with support for agile trajectories and motion capture feedback.
