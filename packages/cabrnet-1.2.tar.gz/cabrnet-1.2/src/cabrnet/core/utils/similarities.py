from abc import ABC, abstractmethod
import torch
import torch.nn as nn
from loguru import logger
from torch import Tensor


class SimilarityLayer(nn.Module, ABC):
    r"""Abstract layer for computing similarity scores based on distances in the convolutional space."""

    def __init__(self, **kwargs):
        r"""Uses nn.Module init function."""
        nn.Module.__init__(self)

    @abstractmethod
    def distances(self, features: Tensor, prototypes: Tensor, **kwargs) -> Tensor:
        r"""Computes pairwise distances between a tensor of features and a tensor of prototypes.

        Args:
            features (tensor): Input tensor. Shape (N, D, H, W).
            prototypes (tensor): Tensor of prototypes. Shape (P, D, 1, 1).

        Returns:
            Distance between each feature vector and each prototype. Shape (N, P, H, W).
        """
        raise NotImplementedError

    @abstractmethod
    def distances_to_similarities(self, distances: Tensor, **kwargs) -> Tensor:
        r"""Converts a tensor of distances into a tensor of similarity scores.

        Args:
            distances (tensor): Input tensor. Any shape.

        Returns:
            Similarity score corresponding to the provided distances. Same shape as input.
        """
        raise NotImplementedError

    def similarities(self, features: Tensor, prototypes: Tensor, **kwargs) -> Tensor:
        r"""Computes pairwise similarity scores between a tensor of features and a tensor of prototypes.

        Args:
            features (tensor): Input tensor. Shape (N, D, H, W).
            prototypes (tensor): Tensor of prototypes. Shape (P, D, 1, 1).

        Returns:
            Tensor of similarity scores. Shape (N, P, H, W).
        """
        # By default, similarity scores are computed from the distances
        distances = self.distances(features=features, prototypes=prototypes, **kwargs)
        return self.distances_to_similarities(distances=distances, **kwargs)

    def forward(self, features: Tensor, prototypes: Tensor, **kwargs) -> Tensor:
        r"""Return pairwise similarity scores between a tensor of features and a tensor of prototypes.

        Args:
            features (tensor): Input tensor. Shape (N, D, H, W).
            prototypes (tensor): Tensor of prototypes. Shape (P, D, 1, 1).

        Returns:
            Tensor of similarity scores. Shape (N, P, H, W).
            Tensor of distances. Shape (N, P, H, W).
        """
        return self.similarities(features, prototypes, **kwargs)


class SimilarityLayerStub(SimilarityLayer):
    r"""Dummy layer for architectures that do not require a similarity layer."""

    def distances(self, features: Tensor, prototypes: Tensor, **kwargs) -> Tensor:
        r"""Raises an error when called.

        Args:
            features (tensor): Unused.
            prototypes (tensor): Unused.

        Returns:
            Nothing.
        """
        raise NotImplementedError

    def distances_to_similarities(self, distances: Tensor, **kwargs) -> Tensor:
        r"""Raises an error when called.

        Args:
            distances (tensor): Unused.

        Returns:
            Nothing.
        """
        raise NotImplementedError


class SquaredEuclideanDistance(SimilarityLayer, ABC):
    r"""Layer for computing Euclidean (L2) distances in the convolutional space."""

    def distances(self, features: Tensor, prototypes: Tensor, **kwargs) -> Tensor:
        r"""Computes pairwise squared Euclidean (L2) distances between a tensor of features and a tensor of prototypes.

        Args:
            features (tensor): Input tensor. Shape (N, D, H, W).
            prototypes (tensor): Tensor of prototypes. Shape (P, D, 1, 1).

        Returns:
            Tensor of distances. Shape (N, P, H, W).
        """
        N, D, H, W = features.shape
        features = features.view((N, D, -1))  # Shape (N, D, HxW)
        features = torch.transpose(features, 1, 2)  # Shape (N, HxW, D)
        prototypes = prototypes.squeeze(dim=(2, 3))  # Shape (P, D)
        distances = torch.cdist(features, prototypes) ** 2  # Shape (N, HxW, P)
        distances = torch.transpose(distances, 1, 2)  # Shape (N, P, HxW)
        distances = distances.view(distances.shape[:2] + (H, W))  # Shape (N, P, H, W)
        return distances


class ProtoPNetDistance(SimilarityLayer, ABC):
    r"""Layer for computing Euclidean (L2) distances in the convolutional space (ProtoPNet original implementation).

    Attributes:
        _summation_kernel: Accumulation tensor used to compute the Euclidean distance.
    """

    _summation_kernel: Tensor

    def __init__(self, num_prototypes: int, num_features: int, **kwargs) -> None:
        r"""Initializes a ProtoPNetDistance layer.

        Args:
            num_prototypes (int): Number of prototypes.
            num_features (int): Size of each prototype.
        """
        super().__init__(**kwargs)
        self.register_buffer("_summation_kernel", torch.ones((num_prototypes, num_features, 1, 1)))
        logger.warning("Enabling compatibility mode with ProtoPNet legacy code when computing similarity scores.")

    def distances(self, features: Tensor, prototypes: Tensor, **kwargs) -> Tensor:
        r"""Computes pairwise squared Euclidean (L2) distances between a tensor of features and a tensor of prototypes,
        as originally implemented in ProtoPNet, i.e., using the formula ||x - y||² = ||x||² - 2 x.y. + ||y||².

        Args:
            features (tensor): Input tensor. Shape (N, D, H, W).
            prototypes (tensor): Tensor of prototypes. Shape (P, D, 1, 1).

        Returns:
            Tensor of distances. Shape (N, P, H, W).
        """
        features_l2_squared = torch.conv2d(input=features**2, weight=self._summation_kernel)

        # ||P||² Shape (P, 1, 1)
        prototypes_l2_squared = torch.sum(prototypes**2, dim=(1, 2, 3)).view(-1, 1, 1)

        # features x prototypes (N, P, H, W)
        features_x_prototypes = torch.conv2d(input=features, weight=prototypes)
        # Swap order of operations to reproduce ProtoPNet legacy code
        # Introduces slight changes on the output of the layer due to floating point operations
        intermediate = -2 * features_x_prototypes + prototypes_l2_squared
        return features_l2_squared + intermediate


class ProtoTreeDistance(SimilarityLayer, ABC):
    r"""Layer for computing Euclidean (L2) distances in the convolutional space (ProtoTree original implementation).

    Attributes:
        _summation_kernel: Accumulation tensor used to compute the Euclidean distance.
    """

    _summation_kernel: Tensor

    def __init__(self, num_prototypes: int, num_features: int, **kwargs) -> None:
        r"""Initializes a ProtoTreeDistance layer.

        Args:
            num_prototypes (int): Number of prototypes.
            num_features (int): Size of each prototype.
        """
        super().__init__(**kwargs)
        self.register_buffer("_summation_kernel", torch.ones((num_prototypes, num_features, 1, 1)))
        logger.warning("Enabling compatibility mode with ProtoTree legacy code when computing similarity scores.")

    def distances(self, features: Tensor, prototypes: Tensor, **kwargs) -> Tensor:
        r"""Computes pairwise squared Euclidean (L2) distances between a tensor of features and a tensor of prototypes,
        as originally implemented in ProtoTree, i.e., using the formula ||x - y||² = ||x||² + ||y||² - 2 x.y.

        Args:
            features (tensor): Input tensor. Shape (N, D, H, W).
            prototypes (tensor): Tensor of prototypes. Shape (P, D, 1, 1).

        Returns:
            Tensor of distances. Shape (N, P, H, W).
        """
        # ||X||² Shape (N, D, H, W)
        features_l2_squared = torch.conv2d(input=features**2, weight=self._summation_kernel)

        # ||P||² Shape (P, 1, 1)
        prototypes_l2_squared = torch.sum(prototypes**2, dim=(1, 2, 3)).view(-1, 1, 1)

        # features x prototypes (N, P, H, W)
        features_x_prototypes = torch.conv2d(input=features, weight=prototypes)

        return features_l2_squared + prototypes_l2_squared - 2 * features_x_prototypes


class LogDistance(SimilarityLayer, ABC):
    r"""Abstract layer for computing similarity scores based on the log of distances in the convolutional space.

    Attributes:
        stability_factor: Stability factor.
    """

    def __init__(self, stability_factor: float = 1e-4, **kwargs) -> None:
        r"""Initializes a ProtoPNetDistance layer.

        Args:
            stability_factor (float, optional): Stability factor. Default: 1e-4.
        """
        super().__init__(**kwargs)
        self.stability_factor = stability_factor

    def distances_to_similarities(self, distances: Tensor, **kwargs) -> Tensor:
        r"""Converts a tensor of distances into a tensor of similarity scores, such that
        sim=log((1+distances)/(1+epsilon)) where epsilon is the stability factor.

        Args:
            distances (tensor): Input tensor. Any shape.

        Returns:
            Similarity score corresponding to the provided distances. Same shape as input.
        """
        # Ensures that distances are greater than 0
        distances = torch.relu(distances)
        return torch.log((distances + 1) / (distances + self.stability_factor))


class ExpDistance(SimilarityLayer, ABC):
    r"""Abstract layer for computing similarity scores based on the exponential of distances in the convolutional space.

    Attributes:
        log_probabilities: If True, returns similarity scores as log of probabilities.
        stability_factor: Stability factor.
    """

    def __init__(self, log_probabilities: bool = False, stability_factor: float = 1e-14, **kwargs) -> None:
        r"""Initializes a ProtoPNetDistance layer.

        Args:
            log_probabilities (bool, optional): If True, returns similarity scores as log of probabilities.
                Default: False.
            stability_factor (float, optional): Stability factor. Default: 1e-14.
        """
        super().__init__(**kwargs)
        self.log_probabilities = log_probabilities
        self.stability_factor = stability_factor

    def distances_to_similarities(self, distances: Tensor, **kwargs) -> Tensor:
        r"""Converts a tensor of distances into a tensor of similarity scores, such that
        sim=exp(-sqrt(distances+epsilon)) where epsilon is the stability factor.
        If log_probabilities is enabled, simply returns -sqrt(distances+epsilon).

        Args:
            distances (tensor): Input tensor. Any shape.

        Returns:
            Similarity score corresponding to the provided distances. Same shape as input.
        """
        distances = torch.sqrt(torch.abs(distances) + self.stability_factor)
        if self.log_probabilities:
            return -distances
        return torch.exp(-distances)


class LegacyProtoPNetSimilarity(ProtoPNetDistance, LogDistance):
    r"""Layer for computing similarity scores based on Euclidean (L2) distances in the convolutional space
        (ProtoPNet original implementation).

    Attributes:
        stability_factor: Stability factor.
        _summation_kernel: Accumulation tensor used to compute the Euclidean distance.
    """

    def __init__(
        self, num_prototypes: int = 0, num_features: int = 0, stability_factor: float = 1e-4, **kwargs
    ) -> None:
        r"""Initializes a LegacyProtoPNetSimilarity layer.

        Args:
            num_prototypes (int, optional): Number of prototypes (this should be set automatically). Default: 0.
            num_features (int, optional): Size of each prototype (this should be set automatically). Default: 0.
            stability_factor (float, optional): Stability factor. Default: 1e-4.
        """
        super().__init__(
            num_prototypes=num_prototypes, num_features=num_features, stability_factor=stability_factor, **kwargs
        )


class ProtoPNetSimilarity(SquaredEuclideanDistance, LogDistance):
    r"""Layer for computing similarity scores based on Euclidean (L2) distances in the convolutional space
        (ProtoPNet implementation updated with cdist function).

    Attributes:
        stability_factor: Stability factor.
    """

    def __init__(self, stability_factor: float = 1e-4, **kwargs) -> None:
        r"""Initializes a ProtoPNetSimilarity layer.

        Args:
            stability_factor (float, optional): Stability factor. Default: 1e-4.
        """
        super().__init__(stability_factor=stability_factor, **kwargs)


class LegacyProtoTreeSimilarity(ProtoTreeDistance, ExpDistance):
    r"""Layer for computing similarity scores based on Euclidean (L2) distances in the convolutional space
        (ProtoPTree original implementation).

    Attributes:
        log_probabilities: If True, returns similarity scores as log of probabilities.
        stability_factor: Stability factor.
        _summation_kernel: Accumulation tensor used to compute the Euclidean distance.
    """

    def __init__(
        self,
        num_prototypes: int = 0,
        num_features: int = 0,
        log_probabilities: bool = False,
        stability_factor: float = 1e-14,
        **kwargs,
    ) -> None:
        r"""Initializes a LegacyProtoTreeSimilarity layer.

        Args:
            num_prototypes (int, optional): Number of prototypes (this should be set automatically). Default: 0.
            num_features (int, optional): Size of each prototype (this should be set automatically). Default: 0.
            log_probabilities (bool, optional): If True, returns similarity scores as log of probabilities.
                Default: False.
            stability_factor (float, optional): Stability factor. Default: 1e-14.
        """
        super().__init__(
            num_prototypes=num_prototypes,
            num_features=num_features,
            log_probabilities=log_probabilities,
            stability_factor=stability_factor,
            **kwargs,
        )


class ProtoTreeSimilarity(SquaredEuclideanDistance, ExpDistance):
    r"""Layer for computing similarity scores based on Euclidean (L2) distances in the convolutional space
        (ProtoPTree implementation updated with cdist function).

    Attributes:
        log_probabilities: If True, returns similarity scores as log of probabilities.
        stability_factor: Stability factor.
    """

    def __init__(self, log_probabilities: bool = False, stability_factor: float = 1e-14, **kwargs) -> None:
        r"""Initializes a ProtoTreeSimilarity layer.

        Args:

            log_probabilities (bool, optional): If True, returns similarity scores as log of probabilities.
                Default: False.
            stability_factor (float, optional): Stability factor. Default: 1e-14.
        """
        super().__init__(log_probabilities=log_probabilities, stability_factor=stability_factor, **kwargs)


class CosineSimilarity(SimilarityLayer):
    r"""Layer for computing similarity scores based on the cosine distance between the two vectors."""

    def __init__(self, stability_factor: float = 1e-8, **kwargs) -> None:
        r"""Initializes a CosineSimilarity layer.

        Args:
            stability_factor (float, optional): Stability factor. Default: 1e-8.
        """
        super().__init__(**kwargs)
        self.stability_factor = stability_factor

    def distances(self, features: Tensor, prototypes: Tensor, **kwargs) -> Tensor:
        r"""Computes pairwise cosine distance between a tensor of features and a tensor of prototypes.

        Args:
            features (tensor): Input tensor. Shape (N, D, H, W).
            prototypes (tensor): Tensor of prototypes. Shape (P, D, 1, 1).

        Returns:
            Tensor of distances. Shape (N, P, H, W).
        """
        # Compute pairwise similarity manually since torch does not offer this feature yet
        scalar_product = torch.conv2d(features, prototypes)  # Shape (N, P, H, W)
        f_norm = torch.linalg.vector_norm(features, dim=1, keepdim=True)  # Shape (N, 1, H, W)
        p_norm = torch.linalg.vector_norm(prototypes, dim=1, keepdim=True).swapaxes(0, 1)  # Shape (1, P, 1, 1)
        cosine_sim = scalar_product / ((f_norm * p_norm) + self.stability_factor)  # Between [-1, 1]
        return 1 - cosine_sim

    def distances_to_similarities(self, distances: Tensor, **kwargs) -> Tensor:
        r"""Converts a tensor of distances into a tensor of similarity scores, such that
        sim=1-distances.

        Args:
            distances (tensor): Input tensor. Any shape.

        Returns:
            Similarity score corresponding to the provided distances. Same shape as input.
        """
        return 1 - distances
