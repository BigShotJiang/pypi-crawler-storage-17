from __future__ import annotations

import argparse
from typing import Any

import torch
import torch.nn as nn
from torch.optim.lr_scheduler import ReduceLROnPlateau

from cabrnet.core.utils.parser import load_config
from loguru import logger
import re


def move_optimizer_to(optim: torch.optim.Optimizer, device: str | torch.device) -> None:
    r"""Moves optimizer to target device. Solution from https://github.com/pytorch/pytorch/issues/8741.

    Args:
        optim (Optimizer): Optimizer.
        device (str | device): Hardware device.
    """
    for param in optim.state.values():
        if isinstance(param, torch.Tensor):
            param.data = param.data.to(device)
            if param._grad is not None:
                param._grad.data = param._grad.data.to(device)
        elif isinstance(param, dict):
            for subparam in param.values():
                if isinstance(subparam, torch.Tensor):
                    subparam.data = subparam.data.to(device)
                    if subparam._grad is not None:
                        subparam._grad.data = subparam._grad.data.to(device)


class OptimizerManager:
    r"""Manager in charge of optimizers, learning rate schedulers and freezing parameters.

    Attributes:
        config: Configuration dictionary used to build this object.
        param_groups: Dictionary separating the model parameters into groups.
        optimizers: Dictionary of optimizers associated with different parameter groups.
        schedulers: Dictionary of learning rate schedulers associated with optimizers.
        schedulers_trig: Dictionary recording the trigger of each scheduler.
        periods: Dictionary defining training periods.
    """

    def __init__(self, config_dict: dict, module: nn.Module) -> None:
        r"""Initializes a OptimizeManager object.

        Args:
            config_dict (dictionary): Configuration dictionary.
            module (Module): Target module.

        """
        self.config = config_dict

        self.param_groups: dict[str, list[nn.Parameter]] = {}
        self.optimizers: dict[str, torch.optim.Optimizer] = {}
        self.schedulers: dict[str, torch.optim.lr_scheduler.LRScheduler] = {}
        self.schedulers_trig: dict[str, str] = {}
        self.periods: dict[str, dict[str, Any]] = {}

        self._set_param_groups(module=module)
        self._set_optimizers()
        self._set_periods()

    @staticmethod
    def build_from_config(config: str | dict[str, Any], model: nn.Module) -> OptimizerManager:
        r"""Builds an OptimizerManager object from a YML file.

        Args:
            config (str | dict): Path to configuration file, or configuration dictionary.
            model (Module): Target module.

        Returns:
            OptimizerManager.
        """
        if not isinstance(config, (str, dict)):
            raise ValueError(f"Unsupported configuration format: {type(config)}")
        if isinstance(config, str):
            config_dict = load_config(config)
        else:
            config_dict = config
        return OptimizerManager(config_dict=config_dict, module=model)

    def _set_param_groups(self, module: nn.Module) -> None:
        r"""Builds the groups of parameters from the configuration dictionary.

        Args:
            module (Module): Target module.
        """
        param_groups = self.config.get("param_groups")

        if param_groups is None:
            # Create a default param group encompassing all model parameters
            self.param_groups["main"] = [param for _, param in module.named_parameters()]
            return

        covered_names = set()

        # Sounds silly but I made mistakes before
        INCLUDE = "include"
        EXCLUDE = "exclude"
        START, STOP = "start", "stop"
        INCLUDE_TYPE = "type"
        EXCLUDE_TYPE = "exclude_type"

        for group_name, group_value in param_groups.items():
            self.param_groups[group_name] = []
            if isinstance(group_value, str | list):
                group_value = {INCLUDE: group_value}
            # group_value is now a dictionary

            unknown_keys = set(group_value.keys())
            unknown_keys = unknown_keys.difference({INCLUDE, EXCLUDE, START, STOP, INCLUDE_TYPE, EXCLUDE_TYPE})
            if unknown_keys:
                raise ValueError(
                    f"Unknown key {list(unknown_keys)[0]}"
                    + (f", ({len(unknown_keys) - 1} similar messages)." if len(unknown_keys) > 1 else "")
                )

            # INCLUDE or START
            if group_value.get(INCLUDE) and (group_value.get(START) or group_value.get(STOP)):
                raise ValueError(f"Cannot use both keywords '{INCLUDE}' and '{START}'/'{STOP}'")

            exclude = group_value.get(EXCLUDE, [])
            if isinstance(exclude, str):
                exclude = [exclude]

            # Type-based filter
            included_types = group_value.get(INCLUDE_TYPE, [])
            if isinstance(included_types, str):
                included_types = [included_types]
            excluded_types = group_value.get(EXCLUDE_TYPE, [])
            if isinstance(excluded_types, str):
                excluded_types = [excluded_types]
            if included_types and excluded_types:
                raise ValueError(f"Cannot use both keywords '{INCLUDE_TYPE}' and '{EXCLUDE_TYPE}'")

            def recursive_type_filter(current_module: nn.Module, prefix: str, result: list, type_list: list):
                class_name = current_module.__class__.__name__

                if type(current_module) in type_list or class_name in type_list:
                    # Positive match, add all parameters
                    for param_name, _ in current_module.named_parameters():
                        result.append(f"{prefix}{param_name}")
                else:
                    # Recursive call
                    for child_name, child in current_module.named_children():
                        recursive_type_filter(child, f"{prefix}{child_name}.", result, type_list)

            if not included_types:
                included_parameters = [name for name, _ in module.named_parameters()]
            else:
                included_parameters = []
                recursive_type_filter(module, "", included_parameters, included_types)
            excluded_parameters = []
            if excluded_types:
                recursive_type_filter(module, "", excluded_parameters, excluded_types)

            # DEBUG logging
            logger.debug(f"Group {group_name} includes {len(included_parameters)} parameters, "
                        f"excludes {len(excluded_parameters)} parameters.")
            
            module_parameters = [name for name in included_parameters if name not in excluded_parameters]

            # Collect the names of the layers to keep in order to avoid duplicates
            selected = set()
            if INCLUDE in group_value:
                include = group_value.get(INCLUDE, [])
                if isinstance(include, str):
                    include = [include]

                for submodule in include:
                    match_found = False
                    for name in module_parameters:
                        if name.startswith(submodule) or re.search(submodule, name):
                            match_found = True
                            selected.add(name)
                    if not match_found:
                        logger.warning(f"No parameter matching keyword {submodule_name} in model")
            else:
                start = group_value.get(START)
                stop = group_value.get(STOP)
                record = start is None
                stop_found = False
                for name in module_parameters:
                    if start and name.startswith(start):
                        record = True
                    elif stop_found and not name.startswith(stop):
                        break
                    if record:
                        selected.add(name)
                    if stop and name.startswith(stop):
                        stop_found = True
                if stop and not stop_found:
                    raise ValueError(f"Unknown parameter group boundary: {stop}")

            # Exclude parameters
            for name, param in module.named_parameters():
                if name in selected:
                    if any(name.startswith(pattern) or re.search(pattern, name) for pattern in exclude):
                        continue
                    covered_names.add(name)
                    logger.debug(f"Adding parameter {name} to group {group_name}")
                    self.param_groups[group_name].append(param)

            if group_value and not self.param_groups[group_name]:
                # Parameter group is empty
                logger.warning(f"Empty parameter group {group_name}.")

        # Check which model parameters are not covered by any group
        not_covered_count = 0
        first_not_covered_param = ""
        for name, _ in module.named_parameters():
            if name not in covered_names:
                if not_covered_count == 0:
                    first_not_covered_param = name
                not_covered_count += 1
        if not_covered_count > 0:
            logger.warning(
                f"{first_not_covered_param} does not belong to any parameter group "
                f"({not_covered_count - 1} similar messages)."
            )

    def _set_optimizers(self) -> None:
        r"""Sets optimizers."""
        optim_config = self.config["optimizers"]
        for optim_name in optim_config:
            config = optim_config[optim_name]
            global_params = config.get("params")
            optim_fn = config["type"]
            
            if "Muon" in optim_fn:
                try:
                    from muon import SingleDeviceMuon  # pylint: disable=import-outside-toplevel
                except ImportError as exc:
                    raise ImportError(
                        f"Optimizer '{optim_fn}' requires the Muon package. "
                        "Install with: pip install git+https://github.com/KellerJordan/Muon"
                    ) from exc
            
            if config.get("groups") is None:
                param_group = self.param_groups["main"]
                if optim_fn == "SingleDeviceMuon":
                    self.optimizers[optim_name] = SingleDeviceMuon(params=param_group, **global_params)
                else:
                    self.optimizers[optim_name] = getattr(torch.optim, optim_fn)(params=param_group, **global_params)
            else:
                optimizer_params = []
                for group_name, group_config in config["groups"].items():
                    if group_name not in self.param_groups.keys():
                        raise ValueError(f"Parameter group not found for optimizer {optim_name}: {group_name}")
                    optimizer_params.append({"params": self.param_groups[group_name], **group_config})
                if optim_fn == "SingleDeviceMuon":
                    self.optimizers[optim_name] = SingleDeviceMuon(
                        params=optimizer_params, **(global_params if global_params else {})
                    )
                else:
                    self.optimizers[optim_name] = (
                        getattr(torch.optim, optim_fn)(optimizer_params, **global_params)
                        if global_params is not None
                        else getattr(torch.optim, optim_fn)(optimizer_params)
                    )
            if config.get("scheduler") is not None:
                scheduler_type = config["scheduler"]["type"]
                scheduler_params = config["scheduler"].get("params")
                scheduler_trig = config["scheduler"].get("trigger", "epoch")
                assert scheduler_trig in ["epoch", "batch"], f"Unsupported LR scheduling trigger {scheduler_trig}"
                self.schedulers[optim_name] = (
                    getattr(torch.optim.lr_scheduler, scheduler_type)(
                        optimizer=self.optimizers[optim_name], **scheduler_params
                    )
                    if scheduler_params is not None
                    else getattr(torch.optim.lr_scheduler, scheduler_type)(optimizer=self.optimizers[optim_name])
                )
                self.schedulers_trig[optim_name] = scheduler_trig
            else:
                logger.warning(f"No scheduler defined for optimizer {optim_name}")

    def _set_periods(self) -> None:
        r"""Sets training periods."""
        num_epochs = self.config["num_epochs"]
        if self.config.get("periods") is None:
            # Single training period
            self.periods = {
                "main_period": {
                    "epoch_range": [0, num_epochs - 1],
                    "freeze": None,
                    "optimizers": self.optimizers.keys(),
                    "patience": float("inf"),
                }
            }
        else:
            current_epoch = 0
            for period_name, period_config in self.config["periods"].items():
                # Sanity check on keys
                for key in period_config.keys():
                    assert key in [
                        "num_epochs",
                        "epoch_range",
                        "optimizers",
                        "freeze",
                        "patience",
                    ], f"Unknown period configuration parameter {key}."

                # Update configuration if necessary
                if period_config.get("num_epochs") is not None:
                    if period_config.get("epoch_range") is not None:
                        # num_epochs parameter takes precedence over epoch_range
                        logger.warning(
                            f"Overwriting epoch range for period {period_name} based on provided value for num_epochs"
                        )
                    # Convert num_epochs into epoch_range
                    period_config["epoch_range"] = [
                        current_epoch,
                        current_epoch + period_config["num_epochs"] - 1,
                    ]
                    current_epoch += period_config["num_epochs"]
                    del period_config["num_epochs"]
                elif period_config.get("epoch_range") is None:
                    # Default epoch range
                    period_config["epoch_range"] = [current_epoch, num_epochs - 1]
                if period_config.get("optimizers") is None:
                    raise ValueError(f"Missing optimizer for training period {period_name}")
                if period_config.get("patience") is None:
                    # By default, patience is infinite
                    period_config["patience"] = float("inf")
                self.periods[period_name] = period_config
                if isinstance(self.periods[period_name]["optimizers"], str):
                    self.periods[period_name]["optimizers"] = [self.periods[period_name]["optimizers"]]
                if isinstance(self.periods[period_name].get("freeze"), str):
                    self.periods[period_name]["freeze"] = [self.periods[period_name]["freeze"]]

                # Sanity checks
                epoch_range = self.periods[period_name]["epoch_range"]
                if not isinstance(epoch_range, list) or len(epoch_range) != 2:
                    raise ValueError(f"Invalid epoch range format for training period {period_name}: {epoch_range}")
                if self.periods[period_name].get("freeze") is not None:
                    for group_name in self.periods[period_name]["freeze"]:
                        if group_name not in self.param_groups.keys():
                            raise ValueError(f"Unknown parameter group for training period {period_name}: {group_name}")
                for optim_name in self.periods[period_name]["optimizers"]:
                    if optim_name not in self.optimizers.keys():
                        raise ValueError(f"Unknown optimizers name for training period {period_name}: {optim_name}")

            # Create periods for all non-covered epochs
            create_period = False
            full_train_period_idx = 0
            for epoch in range(num_epochs):
                # Extend search range to num_epochs + 1 to ensure that last period is created
                active_periods = self.get_active_periods(epoch)
                if not active_periods and not create_period:
                    create_period = True
                    self.periods[f"full_train_period_{full_train_period_idx}"] = {
                        "epoch_range": [epoch, -1],  # No freeze
                        "optimizers": list(self.optimizers.keys()),  # Enable all optimizers
                    }
                elif create_period and active_periods:
                    # Current full train period ended last epoch
                    self.periods[f"full_train_period_{full_train_period_idx}"]["epoch_range"][1] = epoch - 1
                    logger.info(
                        f"Creating full training period for epoch range "
                        f"{self.periods[f'full_train_period_{full_train_period_idx}']['epoch_range']}"
                    )
                    full_train_period_idx += 1
                    create_period = False
            # Complete final period (if any)
            if create_period:
                self.periods[f"full_train_period_{full_train_period_idx}"]["epoch_range"][1] = num_epochs - 1
                logger.info(
                    f"Creating full training period for epoch range "
                    f"{self.periods[f'full_train_period_{full_train_period_idx}']['epoch_range']}"
                )
        logger.info("Training periods")
        for period_name, period_config in self.periods.items():
            logger.info(
                f"+ Period {period_name}: "
                f"range [{period_config['epoch_range'][0]}-{period_config['epoch_range'][1]}], "
                f"applied on {period_config['optimizers']}"
            )

    def get_active_periods(self, epoch: int) -> list[str]:
        r"""Returns all active periods associated with a given epoch index.

        Args:
            epoch (int): Current epoch.

        Returns:
            List of period names.
        """
        p_names = []
        for p_name in self.periods:
            min_epoch, max_epoch = self.periods[p_name]["epoch_range"]
            if min_epoch <= epoch <= max_epoch:
                p_names.append(p_name)
        return p_names

    def freeze_group(self, name: str, freeze: bool) -> None:
        r"""Freezes all parameters of a given group.

        Args:
            name (str): Group name.
            freeze (bool): Whether this parameter should be frozen or unfrozen.
        """
        logger.debug(f"Parameter group {name} is {'frozen' if freeze else 'trainable'}")
        for param in self.param_groups[name]:
            param.requires_grad = not freeze

    def freeze(self, epoch: int) -> None:
        r"""Applies parameter freeze depending on current epoch.

        Args:
            epoch (int): Current epoch.
        """
        groups_to_freeze = []
        for period_name in self.get_active_periods(epoch):
            period_config = self.periods[period_name]
            if period_config.get("freeze") is not None:
                groups_to_freeze += period_config["freeze"]
                logger.info(f"Period {period_name} applies for epoch {epoch}: freezing groups {groups_to_freeze}")

        for group_name in self.param_groups:
            self.freeze_group(name=group_name, freeze=(group_name in groups_to_freeze))

    def freeze_non_associated_groups(self, optim_name: str):
        r"""Freezes all groups that are not associated to a given optimizer.

        Args:
            optim_name (str): Optimizer name.
        """
        assert optim_name in self.optimizers.keys(), f"Unknown optimizer {optim_name}"
        associated_groups = list(self.config["optimizers"][optim_name].get("groups", {"main": None}).keys())
        for group_name in self.param_groups:
            self.freeze_group(name=group_name, freeze=(group_name not in associated_groups))

    def zero_grad(self):
        r"""Resets all optimizer gradients."""
        for name in self.optimizers:
            self.optimizers[name].zero_grad()

    def optimizer_step(self, epoch: int):
        r"""Applies optimizer step depending on current epoch.

        Args:
            epoch (int): Current epoch.
        """
        for period_name in self.get_active_periods(epoch):
            period_config = self.periods[period_name]
            for optim_name in period_config["optimizers"]:
                self.optimizers[optim_name].step()

    def get_patience(self, epoch: int) -> float | int:
        r"""Returns the patience threshold of the current period.
        WARNING: In case multiple periods are overlapping, returns the patience of the first period.

        Args:
            epoch (int): Current epoch.
        """
        for period_name in self.get_active_periods(epoch):
            period_config = self.periods[period_name]
            return period_config["patience"]
        raise ValueError(f"No active period for epoch {epoch}")

    def scheduler_step(self, epoch: int, metric: Any):
        r"""Applies learning rate scheduler step depending on current epoch.

        Args:
            epoch (int): Current epoch.
            metric (any): Target metric (used for ReduceLROnPlateau).
        """
        for period_name in self.get_active_periods(epoch):
            period_config = self.periods[period_name]
            for optim_name in period_config["optimizers"]:
                # Not all optimizers are associated with a scheduler. Not all schedulers are called after each epoch
                if self.schedulers.get(optim_name) is not None and self.schedulers_trig.get(optim_name) == "epoch":
                    if isinstance(self.schedulers[optim_name], ReduceLROnPlateau):
                        self.schedulers[optim_name].step(metric)
                    else:
                        self.schedulers[optim_name].step()

    def to(self, device: str | torch.device):
        r"""Moves OptimizerManager to a given device.

        Args:
            device (str | device): Hardware device.
        """
        for optim_name in self.optimizers:
            move_optimizer_to(self.optimizers[optim_name], device)

    def state_dict(self) -> dict[str, Any]:
        r"""Returns the state of the Optimizer manager as a dictionary."""
        state = {"optimizers": {}, "schedulers": {}}
        for optim_name in self.optimizers:
            state["optimizers"][optim_name] = self.optimizers[optim_name].state_dict()
        for optim_name in self.schedulers:
            state["schedulers"][optim_name] = self.schedulers[optim_name].state_dict()
        return state

    def load_state_dict(self, state_dict: dict[str, Any]) -> None:
        r"""Loads state dictionary, restoring optimizers and schedulers to a previous state.

        Args:
            state_dict (dictionary): State dictionary.
        """
        for optim_name in self.optimizers:
            self.optimizers[optim_name].load_state_dict(state_dict["optimizers"][optim_name])
        for optim_name in self.schedulers:
            self.schedulers[optim_name].load_state_dict(state_dict["schedulers"][optim_name])

    DEFAULT_TRAINING_CONFIG: str = "training.yml"
    DEFAULT_TRAINING_STATE: str = "optimizer_state.pth"

    @staticmethod
    def create_parser(
        parser: argparse.ArgumentParser | None = None, mandatory_config: bool = False
    ) -> argparse.ArgumentParser:
        r"""Creates the argument parser for CaBRNet training configuration.

        Args:
            parser (ArgumentParser, optional): Existing parser (if any). Default: False.
            mandatory_config (bool, optional): If True, makes the configuration mandatory. Default: False.

        Returns:
            The parser itself.
        """
        if parser is None:
            parser = argparse.ArgumentParser(description="Load training configuration.")

        parser.add_argument(
            "-t",
            "--training",
            type=str,
            required=mandatory_config,
            metavar="/path/to/file.yml",
            help="path to the training configuration file",
        )
        return parser
