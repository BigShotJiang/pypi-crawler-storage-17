"""Project initialization and management utilities.

This package provides utilities for initializing new pyrig projects,
creating project structure, managing dependencies, and versioning.
"""
