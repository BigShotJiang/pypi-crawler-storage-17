line = "gnusto=cleesh"
args = {"regexp": r"^foo=", "match_first": True}
options = ["-e", "^foo=", "--match-first"]
