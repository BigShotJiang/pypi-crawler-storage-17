input_file = "input-repeat.txt"
line = "foo=bar\r"
args = {"match_first": False}
options = ["--match-last"]
nonuniversal_lines = True
