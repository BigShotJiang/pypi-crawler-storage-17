input_file = "input-cr.txt"
line = "bar=quux"
args = {}
options = []
nonuniversal_lines = True
