line = "gnusto=cleesh"
args = {"regexp": "notinfile"}
options = ["-e", "notinfile"]
