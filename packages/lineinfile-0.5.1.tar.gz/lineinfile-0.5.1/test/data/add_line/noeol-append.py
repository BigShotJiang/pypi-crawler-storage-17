input_file = "input-noeol.txt"
line = "gnusto=cleesh"
args = {}
options = []
