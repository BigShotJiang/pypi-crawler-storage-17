line = "bar=quux\r"
args = {}
options = []
nonuniversal_lines = True
