input_file = "input-noeol.txt"
line = "x=y"
args = {}
options = []
