input_file = "input-repeat.txt"
line = "foo=bar\r"
args = {}
options = []
nonuniversal_lines = True
