line = "gnusto=cleesh"
args = {"regexp": r"^prefeed="}
options = ["-e", "^prefeed="]
