import re

regexp = re.compile(r"^foo=")
