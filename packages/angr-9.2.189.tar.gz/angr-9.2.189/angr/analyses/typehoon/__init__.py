from __future__ import annotations

from .typehoon import Typehoon

__all__ = ("Typehoon",)
