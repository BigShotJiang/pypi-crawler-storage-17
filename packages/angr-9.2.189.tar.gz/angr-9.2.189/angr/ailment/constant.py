from __future__ import annotations

UNDETERMINED_SIZE = -0xC0DE
