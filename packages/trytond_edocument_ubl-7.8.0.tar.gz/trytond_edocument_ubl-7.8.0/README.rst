####################
EDocument UBL Module
####################

The *EDocument UBL Module* adds electronic documents from `UBL
<https://docs.oasis-open.org/ubl/os-UBL-2.4/UBL-2.4.html>`_.

.. toctree::
   :maxdepth: 2

   design
   releases
