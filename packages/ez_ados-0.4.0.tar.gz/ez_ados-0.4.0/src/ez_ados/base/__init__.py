"""Base module for common things in Azure DevOps."""
