"""Program version."""

# Will be automatically updated in CI.
__version__ = "0.4.0"
