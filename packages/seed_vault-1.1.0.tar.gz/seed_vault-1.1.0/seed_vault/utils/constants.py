AREA_COLOR = "#5dade2"
DOC_BASE_URL = "https://auscope.github.io/seed-vault"