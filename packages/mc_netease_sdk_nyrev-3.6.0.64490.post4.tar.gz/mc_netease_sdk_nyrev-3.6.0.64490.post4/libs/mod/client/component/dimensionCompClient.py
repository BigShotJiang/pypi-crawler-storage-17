# -*- coding: utf-8 -*-


from mod.common.component.baseComponent import BaseComponent


class DimensionCompClient(BaseComponent):
    def GetLocalTime(self):
        # type: () -> int
        """
        获取当前维度的时间
        """
        pass

