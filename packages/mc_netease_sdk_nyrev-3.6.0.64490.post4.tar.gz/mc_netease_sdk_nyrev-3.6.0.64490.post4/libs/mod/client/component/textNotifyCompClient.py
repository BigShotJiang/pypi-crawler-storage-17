# -*- coding: utf-8 -*-


from mod.common.component.baseComponent import BaseComponent


class TextNotifyComponet(BaseComponent):
    def SetLeftCornerNotify(self, textMsg):
        # type: (str) -> bool
        """
        客户端设置左上角通知信息
        """
        pass

