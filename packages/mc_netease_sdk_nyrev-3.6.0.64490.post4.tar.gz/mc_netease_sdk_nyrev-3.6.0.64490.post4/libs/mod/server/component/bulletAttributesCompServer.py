# -*- coding: utf-8 -*-


class BulletAttributesComponentServer(object):
    def GetSourceEntityId(self):
        # type: () -> str
        """
        获取抛射物发射者实体id
        """
        pass

