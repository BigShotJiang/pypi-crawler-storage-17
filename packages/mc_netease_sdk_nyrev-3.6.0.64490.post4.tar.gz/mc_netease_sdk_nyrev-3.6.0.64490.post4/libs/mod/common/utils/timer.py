# -*- coding: utf-8 -*-


class CallLater(object):
    pass
