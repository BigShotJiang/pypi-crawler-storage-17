class DEMO:
    def apply_scale(
        self,
        input_file: str,
    ) -> None:
        print(f"apply_scale {input_file}")
