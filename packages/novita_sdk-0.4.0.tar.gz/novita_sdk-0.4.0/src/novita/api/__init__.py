"""API resources for the Novita SDK."""
