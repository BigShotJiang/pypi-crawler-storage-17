# Tiramisu Framework v3.0

## AI Decision Governance System

**Collaborative Multi-Agent RAO** - A framework that governs decisions before generating responses.

---

## What's Different?

| Traditional Frameworks | Tiramisu 3.0 |
|------------------------|--------------|
| Generate responses | **Govern decisions** |
| One agent responds | **3 personas collaborate** |
| No prior validation | **Validates before analyzing** |
| Output = text | **Output = traceable plan** |

---

## Concept: Governance Before Generation
```
User Query
    │
    ▼
┌─────────────────────────────────┐
│  RAO-4: COLLABORATIVE VALIDATION│
│  Each persona validates its area│
│  Decides: continue or block     │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│  RAO-5: COLLABORATIVE ANALYSIS  │
│  Router selects LEADER          │
│  Others SUPPORT                 │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│  RAO-6: COLLABORATIVE PLAN      │
│  Each persona → 1 action        │
│  System prioritizes             │
└─────────────────────────────────┘
    │
    ▼
   Traceable Result
```

---

## Installation
```bash
pip install tiramisu-framework --upgrade
```

---

## Quick Start
```python
from tiramisu import GovernanceOrchestrator

orchestrator = GovernanceOrchestrator()

context = {
    'product': 'artisan coffee',
    'target_market': 'urban class A'
}

result = orchestrator.execute(
    'My product is not selling well', 
    context
)

print(orchestrator.display_logs(result))
print(result.plan.summary)
```

**Output:**
```
==================================================
TIRAMISU 3.0 - Decision Governance
==================================================
>> RAO-4 Collaborative Validation | Confidence: medium | Total gaps: 13 | Decision: APPROVED
>> RAO-5 Collaborative Analysis | Leader: Persona K | Confidence: high | Method: keywords | Support: ['M', 'G']
>> RAO-6 Collaborative Plan | Actions generated: 3 | Quality score: 100.0% | Priorities: [1, 2, 3]
==================================================

Prioritized Action Plan:
  P1: Define strategic positioning (30 days)
  P2: Activate presence on priority channels (14 days)
  P3: Create authentic content (7 days)
```

---

## The 3 Personas

| Persona | Expertise | Focus |
|---------|-----------|-------|
| **K** | Strategy | Positioning, 4Ps, segmentation |
| **M** | Digital | Channels, metrics, technology |
| **G** | Execution | Content, video, fast action |

---

## RAO Levels

### RAO-4: Collaborative Validation

Each persona validates if it has the necessary data for its area.
```python
from tiramisu import RAO4Validator

validator = RAO4Validator()
result = validator.validate(query, context)

print(result.confidence)        # HIGH, MEDIUM, VERIFY, BLOCKED
print(result.gaps_by_persona)   # Gaps from K, M, and G
print(result.decision_log)      # Traceability
```

**Confidence Levels:**
- `HIGH` - Proceeds normally
- `MEDIUM` - Proceeds with caveats
- `VERIFY` - Requests more data
- `BLOCKED` - Stops execution

---

### RAO-5: Collaborative Analysis

Router selects the LEADER, other personas SUPPORT.
```python
from tiramisu import RAO5Analyzer

analyzer = RAO5Analyzer()
result = analyzer.analyze(query, context)

print(result.leader)              # K, M, or G
print(result.supplements)         # Insights from supporters
print(result.routing_method)      # keywords, embeddings, fallback
```

**Cascading Router:**
1. Keywords (fast)
2. Embeddings (semantic)
3. Fallback (default)

---

### RAO-6: Collaborative Action Plan

Each persona contributes 1 action, system prioritizes.
```python
from tiramisu import RAO6Planner

planner = RAO6Planner()
plan = planner.generate_plan(analysis)

print(plan.actions)           # List of prioritized actions
print(plan.quality_score)     # 0-100%
print(plan.summary)           # Formatted plan
```

---

## Key Differentiators

### 1. Governance, Not Generation
The system decides **if**, **how**, and **with whom** to respond before generating any content.

### 2. Sufficiency-Based Validation
Doesn't ask "can I respond?" but "do I have enough data for **this type** of problem?"

### 3. Structured Collaboration
Personas don't chat freely. Each has a fixed role per RAO level.

### 4. Traceability
Every decision generates an explainable log. You know **why** the system decided that way.

### 5. Contractual Output
Result isn't loose text. It's a structured plan with priorities and score.

---

## Architecture
```
tiramisu/
├── personas/           # K, M, G with fixed roles
│   ├── base.py
│   ├── persona_k.py
│   ├── persona_m.py
│   └── persona_g.py
├── rao/                # Governance levels
│   ├── rao_4_validator.py
│   ├── rao_5_analyzer.py
│   └── rao_6_planner.py
├── governance/         # Orchestrator
│   └── orchestrator.py
└── router/             # Hybrid routing
```

---

## When to Use Tiramisu 3.0

✅ Systems that need to **explain decisions**

✅ Domains with **multiple perspectives**

✅ Applications requiring **prior validation**

✅ Projects that value **traceability**

---

## When NOT to Use

❌ Simple Q&A chatbots

❌ Systems that don't need auditing

❌ Applications where speed > governance

---

## License

MIT License - Copyright (c) 2025 Jony Wolff

---

## Legal Notice

The included personas are **generic templates**. 
For production use, customize with your own domain knowledge.
