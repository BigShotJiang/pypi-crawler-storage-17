soco.config module
==================

.. automodule:: soco.config
    :member-order: bysource
    :members:
