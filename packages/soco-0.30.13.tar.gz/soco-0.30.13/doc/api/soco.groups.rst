soco.groups module
==================

.. automodule:: soco.groups
    :member-order: bysource
    :members:
