soco.cache module
=================

.. automodule:: soco.cache
    :member-order: bysource
    :inherited-members:
    :private-members: _BaseCache
