# EndpointTestAgentSelectorType

Retrieve either all available agents, a specific list of agents, or a list of agent labels.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


