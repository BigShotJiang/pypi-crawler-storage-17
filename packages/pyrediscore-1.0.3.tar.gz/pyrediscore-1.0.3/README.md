# pyredis-core
Low-level decorators for redis instance I/O operations
