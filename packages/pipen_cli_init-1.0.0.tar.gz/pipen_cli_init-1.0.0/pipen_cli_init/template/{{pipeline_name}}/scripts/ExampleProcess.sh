invar={{in.invar | quote}}
outfile={{out.outfile | quote}}
echo "$invar" > $outfile
