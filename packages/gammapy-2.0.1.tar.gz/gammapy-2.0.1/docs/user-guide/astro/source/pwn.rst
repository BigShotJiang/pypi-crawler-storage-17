.. _astro-source-pwn:

Pulsar Wind Nebula Source Models
================================

Plot the evolution of the radius of the PWN:

.. plot:: user-guide/astro/source/plot_pwn_evolution.py
    :include-source:
