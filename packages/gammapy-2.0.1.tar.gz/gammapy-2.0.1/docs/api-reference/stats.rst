.. _api_stats:

******************
stats - Statistics
******************

.. currentmodule:: gammapy.stats

.. automodapi:: gammapy.stats
    :no-inheritance-diagram:
    :include-all-objects:
