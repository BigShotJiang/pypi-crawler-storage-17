.. _api_irf:

***********************************
irf - Instrument response functions
***********************************

.. currentmodule:: gammapy.irf

.. automodapi:: gammapy.irf
    :no-inheritance-diagram:
    :include-all-objects:
