.. _api_CLI:

****************************
scripts - Command line tools
****************************

.. currentmodule:: gammapy.scripts

.. click:: gammapy.scripts.main:cli
   :prog: gammapy
   :show-nested:
