.. _api_datasets:

***************************
datasets - Reduced datasets
***************************

.. currentmodule:: gammapy.datasets

.. automodapi:: gammapy.datasets
    :no-inheritance-diagram:
    :include-all-objects:
