.. _api_makers:

***********************
makers - Data reduction
***********************

.. automodapi:: gammapy.makers
    :no-inheritance-diagram:
    :include-all-objects:

.. automodapi:: gammapy.makers.utils
    :no-inheritance-diagram:
    :include-all-objects:
