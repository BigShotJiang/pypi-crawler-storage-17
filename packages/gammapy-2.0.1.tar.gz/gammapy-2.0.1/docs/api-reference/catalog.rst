.. _api_catalog:

*************************
catalog - Source catalogs
*************************

.. currentmodule:: gammapy.catalog

.. automodapi:: gammapy.catalog
    :no-inheritance-diagram:
    :include-all-objects:
