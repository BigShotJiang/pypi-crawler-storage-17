.. include:: ../references.txt

.. _api_estimators:

**********************************
estimators - High level estimators
**********************************

.. currentmodule:: gammapy.estimators

.. automodapi:: gammapy.estimators
    :no-inheritance-diagram:
    :include-all-objects:

.. automodapi:: gammapy.estimators.utils
    :no-inheritance-diagram:
    :include-all-objects:
