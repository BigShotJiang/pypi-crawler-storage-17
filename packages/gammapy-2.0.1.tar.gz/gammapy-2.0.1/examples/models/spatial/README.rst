Spatial models
--------------

.. _spatial_models_gallery:
