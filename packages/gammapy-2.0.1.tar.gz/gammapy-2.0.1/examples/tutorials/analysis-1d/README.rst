Data analysis
=============

The following set of tutorials are devoted to data analysis, and grouped according to the specific covered use
cases in spectral analysis and flux fitting, image and cube analysis modelling and fitting, as well as
time-dependent analysis with light-curves.

1D Spectral
-----------