Astrophysics use cases
======================

This section outlines some source specific use cases.
