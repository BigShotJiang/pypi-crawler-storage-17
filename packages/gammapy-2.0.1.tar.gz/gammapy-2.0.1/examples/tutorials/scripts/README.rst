.. _tutorials_scripts:

Scripts
=======

For interactive use, IPython and Jupyter are great, and most Gammapy examples use those.
However, for long-running, non-interactive tasks like data reduction or survey maps,
you might prefer a Python script.

The following example shows how to run Gammapy within a Python script.