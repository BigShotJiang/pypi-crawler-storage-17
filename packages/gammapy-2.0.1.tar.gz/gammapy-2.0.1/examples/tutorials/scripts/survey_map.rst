.. include:: ../references.txt

.. _survey_map:

Survey map
==========

Here's an example of a Gammapy analysis as a Python script:

.. literalinclude:: ../../examples/survey_map.py

To execute it run:

.. code-block:: bash

    python survey_example.py
