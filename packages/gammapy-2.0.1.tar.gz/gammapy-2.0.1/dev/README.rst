Dev
===

This directory is a place for Gammapy developers to put stuff that is useful
for maintenance, such as i.e. a helper script to produce a list of contributors.
