"""Communicate with the Nanmai TTS service."""

import aiohttp
import re
from typing import AsyncGenerator, Dict, Union, Optional
from contextlib import asynccontextmanager

from .auth import generate_headers
from .constants import API_URL
from .exceptions import NanmaiAPIError, NetworkError, NoAudioReceived


class Communicate:
    """
    Communicate with the Nanmai TTS service.
    Mimics the interface of edge-tts Communicate class.
    """

    def __init__(
        self,
        text: str,
        voice: str = "DeepSeek",
        proxy: Optional[str] = None,
        session: Optional[aiohttp.ClientSession] = None
    ):
        """
        Initialize the Communicate instance.

        Args:
            text: Text to synthesize
            voice: Voice to use (DeepSeek or Kimi)
            proxy: Proxy URL (e.g., "http://127.0.0.1:7890")
            session: Existing aiohttp ClientSession for connection pooling
        """
        if not isinstance(text, str):
            raise TypeError("text must be str")
        if not isinstance(voice, str):
            raise TypeError("voice must be str")

        # Validate voice
        if voice not in ["DeepSeek", "Kimi"]:
            raise ValueError(f"Invalid voice: {voice}. Must be 'DeepSeek' or 'Kimi'")

        self.text = self._convert_fullwidth_to_halfwidth(text)
        self.voice = voice
        self.proxy = proxy
        self._external_session = session

    def _convert_fullwidth_to_halfwidth(self, text: str) -> str:
        """Convert full-width ASCII characters to half-width equivalents."""
        result = []
        for char in text:
            code = ord(char)
            # Full-width ASCII range: U+FF01 to U+FF5E
            if 0xFF01 <= code <= 0xFF5E:
                # Convert to half-width by subtracting 0xFEE0
                halfwidth_code = code - 0xFEE0
                result.append(chr(halfwidth_code))
            elif code == 0x3000:  # Full-width space
                result.append(" ")
            else:
                result.append(char)
        return "".join(result)

    def _get_speakable_count(self, text: str) -> int:
        """Count speakable characters (CJK, Alphanumeric)."""
        return len(re.findall(r'[a-zA-Z0-9\u4e00-\u9fff]', text))

    def _smart_sanitize(self, text: str) -> str:
        """
        Smart sanitization for short texts.
        Removes non-standard symbols if text length is short to prevent API errors.
        """
        # Whitelist: CJK, Alphanumeric, Standard Punctuation, Whitespace
        whitelist_pattern = r'[^a-zA-Z0-9\u4e00-\u9fff,\.!?:;，。！？：；\s]'
        return re.sub(whitelist_pattern, '', text)

    @asynccontextmanager
    async def _get_session(self) -> AsyncGenerator[aiohttp.ClientSession, None]:
        """Context manager to handle internal vs external session."""
        if self._external_session:
            # Use external session, do not close it
            yield self._external_session
        else:
            # Create new session, close it afterwards
            async with aiohttp.ClientSession() as session:
                yield session

    async def stream(self) -> AsyncGenerator[Dict[str, Union[str, bytes]], None]:
        """
        Stream audio data from the Nanmai TTS service.
        """
        # 1. Pre-check: Content Validity
        speakable_count = self._get_speakable_count(self.text)

        if speakable_count == 0:
            raise NoAudioReceived(
                "No audio received: Text contains only punctuation or whitespace"
            )

        # 2. Smart Sanitization for short texts
        text_to_send = self.text
        if speakable_count < 3:
            text_to_send = self._smart_sanitize(self.text)
            if not text_to_send.strip():
                text_to_send = self.text  # Fallback if sanitization removed everything

        # 3. Prepare Request
        data = aiohttp.FormData()
        data.add_field("text", text_to_send)
        data.add_field("audio_type", "mp3")
        data.add_field("format", "stream")

        headers = generate_headers()
        url = f"{API_URL}?roleid={self.voice}"

        try:
            async with self._get_session() as session:
                async with session.post(
                    url,
                    data=data,
                    headers=headers,
                    proxy=self.proxy
                ) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        raise NanmaiAPIError(f"Nanmai API Error {response.status}: {error_text}")

                    # True streaming
                    chunk_count = 0
                    async for chunk in response.content.iter_chunked(4096):
                        if chunk:
                            chunk_count += 1
                            yield {"type": "audio", "data": chunk}

                    if chunk_count == 0:
                        raise NoAudioReceived("Empty audio data received from API")

        except aiohttp.ClientError as e:
            raise NetworkError(f"Network error: {e}") from e
        except Exception as e:
            if isinstance(e, (NanmaiAPIError, NoAudioReceived, NetworkError)):
                raise e
            raise NanmaiAPIError(f"TTS synthesis failed: {e}") from e

    async def save(self, audio_fname: str) -> None:
        """
        Save the audio to a file.

        Args:
            audio_fname: Output filename
        """
        with open(audio_fname, "wb") as f:
            async for chunk in self.stream():
                if chunk["type"] == "audio":
                    f.write(chunk["data"])

    async def get_audio_data(self) -> bytes:
        """
        Get the complete audio data as bytes.
        This is a convenience method for applications that need the full audio at once.

        Returns:
            Complete audio data as bytes
        """
        audio_chunks = []
        async for chunk in self.stream():
            if chunk["type"] == "audio":
                audio_chunks.append(chunk["data"])
        return b"".join(audio_chunks)
