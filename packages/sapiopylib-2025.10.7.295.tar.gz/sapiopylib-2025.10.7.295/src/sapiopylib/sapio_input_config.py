inputPath = "[Not from Sapio]"
