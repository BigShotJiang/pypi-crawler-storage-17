"""Transcription engine: audio source, receiver interfaces, transcribers"""
