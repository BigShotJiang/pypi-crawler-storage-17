Playlists
---------

.. currentmodule:: ytmusicapi
.. automethod:: YTMusic.get_playlist
.. automethod:: YTMusic.create_playlist
.. automethod:: YTMusic.edit_playlist
.. automethod:: YTMusic.delete_playlist
.. automethod:: YTMusic.add_playlist_items
.. automethod:: YTMusic.remove_playlist_items
