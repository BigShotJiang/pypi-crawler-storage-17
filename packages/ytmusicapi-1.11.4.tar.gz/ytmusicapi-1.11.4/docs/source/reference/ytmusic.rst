YTMusic
-------

.. currentmodule:: ytmusicapi
.. autoclass:: YTMusic
.. automethod:: YTMusic.__init__
