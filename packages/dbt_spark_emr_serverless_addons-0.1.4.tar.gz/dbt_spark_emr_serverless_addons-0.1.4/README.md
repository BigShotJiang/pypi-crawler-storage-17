# dbt-spark-emr-serverless
Dbt Spark Adapter for EMR serverless
