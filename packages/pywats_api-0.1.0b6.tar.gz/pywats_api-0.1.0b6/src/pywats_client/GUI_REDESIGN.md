1. Change the connection logic:
    I want to 