"""Deprecated case template rule models have been removed."""

__all__: list[str] = []
