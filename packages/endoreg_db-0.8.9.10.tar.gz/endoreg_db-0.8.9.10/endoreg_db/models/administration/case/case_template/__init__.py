"""Case template models have been deprecated and are no longer available."""

__all__: list[str] = []
