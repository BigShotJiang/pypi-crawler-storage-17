from letta_evals.targets.base import AbstractAgentTarget
from letta_evals.targets.letta_agent import LettaAgentTarget

__all__ = ["AbstractAgentTarget", "LettaAgentTarget"]
