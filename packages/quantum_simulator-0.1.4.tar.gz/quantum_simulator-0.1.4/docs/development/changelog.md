# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.4] - 2025-12-16

### Added
- Fix broken links in documentation
- Added initial math overview documentation

## [0.1.3] - 2025-12-16

### Added
- Fix documentation references

## [0.1.2] - 2025-12-16

### Added
- Fix documentation
- Fix docs github action

## [0.1.1] - 2025-12-16

### Added
- Fix dimension mismatch bug
- Fix CNOT bug
- Fix documentation
- Add CONTRIBUTING.md
- Fix tests
- Fix linting

## [0.1.0] - 2025-12-16

### Added
- Initial release
- Initial project structure
- Basic quantum simulation functionality
- Documentation with MkDocs
- CI/CD with GitHub Actions
- `QuantumSimulator` class for quantum state simulation
- Basic quantum gates (X, Y, Z, H, CNOT)
- `QuantumCircuit` class for building quantum circuits
- Quantum measurement functionality
- Comprehensive documentation
- Unit tests and type checking
- PyPI packaging configuration
- GitHub Actions for automated testing and publishing

### Features
- Support for multi-qubit quantum systems
- State vector representation of quantum states
- Gate application and circuit execution
- Measurement with state collapse
- Modern Python packaging with `pyproject.toml`
- MkDocs documentation with Material theme
- Automated PyPI publishing on releases
- Automated documentation deployment to GitHub Pages
