def test_import():
    """Simple smoke test to ensure the package can be imported."""
    import latentflow
    assert latentflow is not None