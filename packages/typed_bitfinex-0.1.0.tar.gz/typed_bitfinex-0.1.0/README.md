# Typed Bitfinex

> A fully typed, validated async client for the Bitfinex API

Use *autocomplete* instead of documentation.

🚧 Under construction.