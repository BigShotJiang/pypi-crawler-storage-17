"""
### Typed Bitfinex
> A fully typed, validated async client for the Bitfinex API

- Details
"""