"""Profiling utilities for ciffy."""
