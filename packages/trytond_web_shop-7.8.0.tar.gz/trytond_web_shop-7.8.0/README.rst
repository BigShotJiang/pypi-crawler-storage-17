Web Shop Module
###############

The web_shop module provides facilities to store configuration of online web
shop.
