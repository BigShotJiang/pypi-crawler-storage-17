This module provides a new field on users to store the user's digital
signature
