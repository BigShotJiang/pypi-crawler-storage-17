1.  Go to *Settings \> Users & Companies \> Users*.
2.  Open one of the existing users.
3.  You can set a digital signature for it on the field "Signature".
