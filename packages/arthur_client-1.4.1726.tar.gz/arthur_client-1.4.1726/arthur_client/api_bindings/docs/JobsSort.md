# JobsSort


## Enum

* `QUEUED_AT` (value: `'queued_at'`)

* `STARTED_AT` (value: `'started_at'`)

* `FINISHED_AT` (value: `'finished_at'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


