# coding=utf-8
from applyx.conf.config import Configuration

settings = Configuration()
