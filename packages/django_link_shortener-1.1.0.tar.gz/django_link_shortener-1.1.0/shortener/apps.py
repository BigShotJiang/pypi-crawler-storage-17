from django.apps import AppConfig


class ShortenerConfig(AppConfig):
    name = 'shortener'

    default_auto_field = "django.db.models.BigAutoField"
