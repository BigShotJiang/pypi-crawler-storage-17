# Polymath Schemas

This repository contains the schemas for the Polymath python implementation found at polymath-server, used by agent clients.