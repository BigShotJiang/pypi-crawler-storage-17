# Citing

If you use this software in your scientific work, please cite [this article](https://doi.org/10.1101/2025.05.06.652335):

- [doi](https://doi.org/10.1101/2025.05.06.652335)
- [bibtex file](https://github.com/Computational-Biology-Aachen/MxlPy/citation.bibtex)
