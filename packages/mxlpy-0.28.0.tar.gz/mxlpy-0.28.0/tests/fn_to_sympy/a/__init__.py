from . import b

__all__ = [
    "attr_a",
    "b",
    "fn_a",
]

attr_a = 1.0


def fn_a() -> float:
    return 1.0
