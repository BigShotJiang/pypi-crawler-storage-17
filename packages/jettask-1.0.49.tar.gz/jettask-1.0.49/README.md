# JetTask

高性能分布式任务队列系统，支持 Web 监控。

## 安装

```bash
pip install jettask
```

## 快速开始

详细文档请访问：https://jettask.readthedocs.io
