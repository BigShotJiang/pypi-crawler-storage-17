from edsnlp.utils.doc_to_text import get_char_offsets as alignment  # noqa: E402, F401
