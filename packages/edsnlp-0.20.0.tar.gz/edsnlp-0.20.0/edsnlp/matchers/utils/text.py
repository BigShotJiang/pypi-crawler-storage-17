from edsnlp.utils.doc_to_text import get_text  # noqa: E402, F401
