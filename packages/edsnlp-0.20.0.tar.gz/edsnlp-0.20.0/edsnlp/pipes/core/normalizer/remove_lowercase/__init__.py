from .factory import create_component
