# Default punctuation defined for the sentencizer : https://spacy.io/api/sentencizer
punctuation = {
    "!",
    ".",
    "?",
    "܂",
    "‼",
    "‽",
    "⁇",
    "⁈",
    "⁉",
    "﹖",
    "﹗",
    "！",
    "．",
    "？",
}
