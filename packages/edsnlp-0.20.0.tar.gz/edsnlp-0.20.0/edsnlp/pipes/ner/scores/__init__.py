from edsnlp.pipes.ner.scores.base_score import SimpleScoreMatcher

Score = SimpleScoreMatcher
