from .negation import NegationQualifier

Negation = NegationQualifier
