history = [
    "antécédents",
    "atcd",
    "atcds",
    "tacds",
    "antécédent",
]

sections_history = [
    "antécédents",
    "antécédents familiaux",
    "histoire de la maladie",
]
