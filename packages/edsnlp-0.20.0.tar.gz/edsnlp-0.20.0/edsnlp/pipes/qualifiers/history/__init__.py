from .history import HistoryQualifier

History = HistoryQualifier
