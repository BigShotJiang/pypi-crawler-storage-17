from .reported_speech import ReportedSpeechQualifier

ReportedSpeech = ReportedSpeechQualifier
