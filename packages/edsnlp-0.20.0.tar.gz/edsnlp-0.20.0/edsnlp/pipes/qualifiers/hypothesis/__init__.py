from .hypothesis import HypothesisQualifier

Hypothesis = HypothesisQualifier
