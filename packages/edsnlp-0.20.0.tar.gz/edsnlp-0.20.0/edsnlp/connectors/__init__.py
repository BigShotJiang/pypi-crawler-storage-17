from .brat import BratConnector
from .omop import OmopConnector
