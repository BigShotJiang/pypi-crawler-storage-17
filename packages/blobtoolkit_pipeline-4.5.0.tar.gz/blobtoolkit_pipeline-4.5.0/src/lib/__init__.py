"""This is a template package to demonstrate Continuous Integration."""
