#!/usr/bin/env python3
"""blobtoolkit version."""

__version__ = "blobtoolkit-pipeline v4.5.0"
