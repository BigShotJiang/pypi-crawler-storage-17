* Digital5, S.L. <jonerikceberio@digital5.es>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Roca
* Florian da Costa <florian.dacosta@akretion.com>
