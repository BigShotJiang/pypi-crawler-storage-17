#. Go to *Invoicing > Configuration > Journals*.
#. Enable *Avoid zero lines*.
#. Save.

NOTE: This option is only available for journals of type "purchase".
