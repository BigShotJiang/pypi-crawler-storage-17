This module adds the possibility to avoid creating purchase invoice lines without
quantity.
