"""
A simple and intuitive Python library for reading and writing files in various formats.

Provides utilities for working with text, JSON, YAML, and pickle files.
"""

import json
import pickle

import yaml


def read(path, encoding="utf-8"):
    """
    Reads file content as a single string.
    :param path: str. Path to the file.
    :param encoding: str. File encoding. Defaults to 'utf-8'.
    :return: str. File content with trailing newline stripped.
    """
    with open(path, "r", encoding=encoding) as f:
        data = f.read().strip("\n")
    return data


def read_lines(path, encoding="utf-8"):
    """
    Reads file content as a list of lines.
    :param path: str. Path to the file.
    :param encoding: str. File encoding. Defaults to 'utf-8'.
    :return: list of str. List of lines with newlines stripped.
    """
    with open(path, "r", encoding=encoding) as f:
        data = [line.strip("\n") for line in f.readlines()]
    return data


def read_json(file_path, encoding="utf-8", **kwargs):
    """
    Reads and parses a JSON file.
    :param file_path: str. Path to the JSON file.
    :param encoding: str. File encoding. Defaults to 'utf-8'.
    :param kwargs: dict. Additional arguments passed to json.load().
    :return: dict or list. Parsed JSON data.
    """
    with open(file_path, "r", encoding=encoding) as f:
        data = json.load(f, **kwargs)
        return data


def read_yaml(file_path, encoding="utf-8", **kwargs):
    """
    Reads and parses a YAML file.
    :param file_path: str. Path to the YAML file.
    :param encoding: str. File encoding. Defaults to 'utf-8'.
    :param kwargs: dict. Additional arguments passed to yaml.safe_load().
    :return: dict or list or any. Parsed YAML data.
    """
    with open(file_path, "r", encoding=encoding) as f:
        data = yaml.safe_load(f, **kwargs)
        return data


def write_json(data, path, encoding="utf-8", ensure_ascii=False, indent=4, **kwargs):
    """
    Writes data to a JSON file.
    :param data: dict or list. Data to serialize to JSON.
    :param path: str. Path to the output file.
    :param encoding: str. File encoding. Defaults to 'utf-8'.
    :param ensure_ascii: bool. Whether to escape non-ASCII characters. Defaults to False.
    :param indent: int. Number of spaces for indentation. Defaults to 4.
    :param kwargs: dict. Additional arguments passed to json.dump().
    :return: None.
    """
    with open(path, "w", encoding=encoding) as f:
        json.dump(data, f, ensure_ascii=ensure_ascii, indent=indent, **kwargs)


def write(data, path, encoding="utf-8", mode="w"):
    """
    Writes a string to a file.
    :param data: str. String to write.
    :param path: str. Path to the output file.
    :param encoding: str. File encoding. Defaults to 'utf-8'.
    :param mode: str. File open mode (w, a, w+, a+). Defaults to 'w'.
    :return: None.
    """
    with open(path, mode, encoding=encoding) as f:
        f.write(data)


def write_lines(data, path, encoding="utf-8", mode="w"):
    """
    Writes a list of strings to a file, one per line.
    :param data: list of str. List of strings to write.
    :param path: str. Path to the output file.
    :param encoding: str. File encoding. Defaults to 'utf-8'.
    :param mode: str. File open mode (w, a, w+, a+). Defaults to 'w'.
    :return: None.
    """
    with open(path, mode, encoding=encoding) as f:
        for line in data:
            f.write(line.strip("\n") + "\n")


def write_line(data, path, encoding="utf-8"):
    """
    Appends a line to a file.
    :param data: str. String to append as a new line.
    :param path: str. Path to the output file.
    :param encoding: str. File encoding. Defaults to 'utf-8'.
    :return: None.
    """
    with open(path, "a", encoding=encoding) as f:
        f.write(data.strip("\n") + "\n")


def write_yaml(data, path, encoding="utf-8", **kwargs):
    """
    Writes data to a YAML file.
    :param data: dict or list or any. Data to serialize to YAML.
    :param path: str. Path to the output file.
    :param encoding: str. File encoding. Defaults to 'utf-8'.
    :param kwargs: dict. Additional arguments passed to yaml.dump().
    :return: None.
    """
    with open(path, "w", encoding=encoding) as f:
        yaml.dump(data, f, **kwargs)


def read_pkl(path, **kwargs):
    """
    Reads and deserializes a pickle file.
    :param path: str. Path to the pickle file.
    :param kwargs: dict. Additional arguments passed to pickle.load().
    :return: any. Deserialized Python object.
    """
    with open(path, "rb") as f:
        pkl = pickle.load(f, **kwargs)
    return pkl


def write_pkl(data, path, **kwargs):
    """
    Serializes and writes a Python object to a pickle file.
    :param data: any. Python object to serialize.
    :param path: str. Path to the output pickle file.
    :param kwargs: dict. Additional arguments passed to pickle.dump().
    :return: None.
    """
    with open(path, "wb") as f:
        pickle.dump(data, f, **kwargs)
