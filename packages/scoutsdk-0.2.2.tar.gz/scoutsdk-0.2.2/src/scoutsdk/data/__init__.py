"""Data package for scoutsdk."""

from importlib.resources import files

__all__ = ["files"]
