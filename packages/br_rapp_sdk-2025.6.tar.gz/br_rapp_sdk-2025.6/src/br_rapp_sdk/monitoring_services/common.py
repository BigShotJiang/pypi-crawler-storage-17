ODIN_GROUP = "odin.trirematics.io"
ODIN_VERSION = "v1"

ODIN_MONITORINGJOB_KIND = "MonitoringJob"

ODIN_MONITORINGJOB_PLURAL = "monitoringjobs"