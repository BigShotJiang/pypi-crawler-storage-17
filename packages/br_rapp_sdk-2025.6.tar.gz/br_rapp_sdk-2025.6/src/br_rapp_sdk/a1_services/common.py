ODIN_GROUP = "odin.trirematics.io"
ODIN_VERSION = "v1"

ODIN_POLICYJOB_KIND = "PolicyJob"

ODIN_POLICYJOB_PLURAL = "policyjobs"