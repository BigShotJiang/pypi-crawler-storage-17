# Changelog

## 0.1.0 (2025-12-16)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/Synext-Solution/cnos-hub-gen-sdk-py/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([5975ea6](https://github.com/Synext-Solution/cnos-hub-gen-sdk-py/commit/5975ea6b718ed085cda3bec2bf6f9fd9c045b7d5))


### Chores

* configure new SDK language ([9f9702d](https://github.com/Synext-Solution/cnos-hub-gen-sdk-py/commit/9f9702d201e97fedeb35599b525d8b90ffce7235))
* sync repo ([0257455](https://github.com/Synext-Solution/cnos-hub-gen-sdk-py/commit/0257455a755f2ea88538d613e5bfd90186601418))
* update SDK settings ([aead32f](https://github.com/Synext-Solution/cnos-hub-gen-sdk-py/commit/aead32f5118497a4d9e95bcebf4f25d529f0277f))
* update SDK settings ([f9301f5](https://github.com/Synext-Solution/cnos-hub-gen-sdk-py/commit/f9301f51e84fd282af9e7d2daebf5f4ea65ae94b))
* update SDK settings ([8624c03](https://github.com/Synext-Solution/cnos-hub-gen-sdk-py/commit/8624c03a4ec295364788f219c68b97d62b8f15f4))
* update SDK settings ([547c2c0](https://github.com/Synext-Solution/cnos-hub-gen-sdk-py/commit/547c2c00cf59371ae084672636146a5032d58b81))
