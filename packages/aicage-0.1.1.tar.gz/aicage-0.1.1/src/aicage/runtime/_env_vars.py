"""Shared environment variable names used for container setup."""

AICAGE_UID = "AICAGE_UID"
AICAGE_GID = "AICAGE_GID"
AICAGE_USER = "AICAGE_USER"

AICAGE_TOOL_PATH = "AICAGE_TOOL_PATH"

__all__ = ["AICAGE_UID", "AICAGE_GID", "AICAGE_USER", "AICAGE_TOOL_PATH"]
