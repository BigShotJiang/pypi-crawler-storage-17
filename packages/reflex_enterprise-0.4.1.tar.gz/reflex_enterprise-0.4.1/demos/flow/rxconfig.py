import reflex as rx

config = rx.Config(
    app_name="flow",
    disable_plugins=["reflex.plugins.sitemap.SitemapPlugin"],
)
