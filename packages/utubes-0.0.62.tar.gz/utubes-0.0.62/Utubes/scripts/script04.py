
class Creds:

    DATA01 = '4fe3fecfe5334023a1472516cc99d805'
    DATA02 = '0f02b7c483c04257984695007a4a8d5c'

class Okeys(object):

    DATA01 = "%(title,fulltitle,alt_title)s%(season_number& |)s%(season_number&S|)s%(season_number|)02d%(episode_number&E|)s%(episode_number|)02d.%(ext)s"
