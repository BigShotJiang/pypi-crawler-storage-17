#===========================================================

class BKeys(object):

    DATA01 = "|"
    DATA02 = "="
    DATA07 = "+"
    DATA08 = "-{}"
    DATA03 = "[{}]"
    DATA04 = "|{}|{}"
    DATA05 = "={}={}"
    DATA06 = "+{}+{}+{}"
    DATA10 = "{}{} ({}) {}"

#===========================================================

class UKeys(object):

    DATA08 = str("ext")
    DATA13 = str("title")
    DATA09 = str("login")
    DATA05 = str("format")
    DATA01 = str("formats")
    DATA06 = str("filesize")
    DATA02 = str("duration")
    DATA10 = str("username")
    DATA11 = str("password")
    DATA03 = str("format_id")
    DATA04 = str("format_note")
    DATA07 = str("filesize_approx")
    DATA12 = str("geo_bypass_country")

#===========================================================
