appname = "utubes"
version = "0.0.62"
pythons = "~=3.10"

DATA03 = 'ㅤ'
DATA01 = None
DATA02 = ['Natural Language :: English',
          'Intended Audience :: Developers',
          'Operating System :: OS Independent',
          'Programming Language :: Python :: 3.10',
          'Programming Language :: Python :: 3.11',
          'Programming Language :: Python :: 3.12',
          'Programming Language :: Python :: 3.13',
          'Programming Language :: Python :: 3.14',
          'Topic :: Software Development :: Libraries',
          'Topic :: Software Development :: Localization',
          'Topic :: Software Development :: User Interfaces',
          'Topic :: Software Development :: Version Control']

mention = ['Ytdlp', 'Utube', 'Youtube']
install = ["yt-dlp", "requests", "instaloader", "beautifulsoup4"]
