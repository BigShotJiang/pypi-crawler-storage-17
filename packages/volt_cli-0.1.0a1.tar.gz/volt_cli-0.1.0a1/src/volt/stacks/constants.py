DB_SQL_MODEL = ["SQLite", "PostgreSQL", "MySQL"]
DB_USER_DEFAULT = [DB_SQL_MODEL[1]]
DB_NOSQL_MODEL = {"MongoDB"}
SQL_DEFAULT_DATABASE = {
    DB_SQL_MODEL[0]: "sqlite",
    DB_SQL_MODEL[1]: "postgres",
    DB_SQL_MODEL[2]: "mysql",
}
