# ASTUR/__init__.py
from .core import process_faa, compute_ARSC_extended_counts

__version__ = "0.0.7"
__author__ = "Satoshi Nishino"