# short/long term memories middleware
# langchain uses a FileSystemMiddleware concept for implementing memories. Its
# generally a virtual filesystem in the case of short-term memory and a
# special prefixed location for long-term memory. This causes confusion and
# conflict with accessing the real filesystem for code analysis during triage work.
#
# I'm going to recreate this middleware as a "memories" middleware and adjust
# the prompt and tool description such that the LLM will know when to properly
# use it versus REAL filesystem tools.


import deepagents
from langchain.agents.middleware.types import AgentMiddleware


class MemoriesMiddleware(AgentMiddleware):
    pass
