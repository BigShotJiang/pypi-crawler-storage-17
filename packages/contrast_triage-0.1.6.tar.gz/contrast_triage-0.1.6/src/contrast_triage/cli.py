#!/usr/bin/env python3

import argparse
from rich_argparse import RichHelpFormatter
from rich.console import Console
from rich.markup import escape
from rich.progress import track
from .inputs import load_sarif_file, relativize_sarif_uri
from .agent import TriageAgent, TriageResponse
from .triage_analysis import ContrastAiTriageAnalysis, Classification
from typing import Any, List
from sarif_pydantic import Result
from langgraph.graph.state import CompiledStateGraph
import logging
from langchain_core.messages import (
    AIMessageChunk,
    BaseMessageChunk,
    ToolMessage,
    ToolMessageChunk,
)
from pythonjsonlogger.json import JsonFormatter

try:
    from contrast_triage import __version__
except ImportError:
    __version__ = "0.0.0+unknown"

logger: logging.Logger


def cli():
    parser = argparse.ArgumentParser(
        description="Contrast AI-powered Triage Agent",
        formatter_class=RichHelpFormatter,
    )

    parser.add_argument(
        "--model-provider",
        type=str,
        default="bedrock_converse",
        help="Model provider to use (default: %(default)s).",
    )
    parser.add_argument(
        "--model-name",
        type=str,
        default="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        help="Model name to use (default: %(default)s)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Do a dry run of the triage.  This will NOT incur any LLM costs, but the output will be bogus (default: %(default)s)",
    )
    parser.add_argument(
        "--index",
        type=int,
        help="Only processing this result index from sarif.",
    )
    parser.add_argument(
        "--srcroot",
        type=str,
        default=".",
        help="Path to the source code directory. (default: %(default)s)",
    )
    parser.add_argument(
        "--agent-log",
        type=str,
        default="triage_agent.log",
        help=(
            "output file for the triage agent log. Really only useful for development and debugging time (default: %(default)s)"
        ),
    )
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
        help="Show the version number and exit.",
    )
    parser.add_argument(
        "input", type=str, help="Path to the SARIF file containing findings."
    )
    parser.add_argument(
        "output",
        type=str,
        default=None,
        help="Path for modified sarif results to be written",
    )

    args = parser.parse_args()

    main(args)


def init_logging(log_path: str) -> logging.Logger:
    global logger
    logger = logging.getLogger(__name__)
    filehandler = logging.FileHandler(log_path, mode="w+")
    formatter = JsonFormatter("%(asctime)s %(name)s %(levelname)s %(message)s")

    filehandler.setFormatter(formatter)
    logger.addHandler(filehandler)
    logger.setLevel(logging.DEBUG)

    return logger


console = Console()


def main(args: argparse.Namespace):
    global logger

    logger = init_logging(args.agent_log)

    console.print(f"Contrast Triage AI-Agent, version: {escape(__version__)}")

    console.print(f"Loading SARIF file: {escape(args.input)}")
    sarif = load_sarif_file(args.input)
    if len(sarif.runs) == 0 or not sarif.runs[0].results:
        raise ValueError("No findings found in SARIF file.")

    console.print(f"Number of runs in SARIF: {len(sarif.runs)}")

    total_findings = 0
    for run_idx, run in enumerate(sarif.runs):
        console.print(f"Tool Run: {run_idx}")
        console.print(f"Tool Driver: [bold]{escape(run.tool.driver.name)}[/bold]")
        if not run.results:
            console.print("     No results from run", style="bold yellow")
        else:
            cnt = len(run.results)
            total_findings += cnt
            console.print(f"    Number of findings in run: {cnt}")
    console.print("total findings", total_findings)
    agent = TriageAgent(args.model_provider, args.model_name, args.srcroot)
    assert len(sarif.runs) > 0
    run0 = sarif.runs[0]
    assert run0.results is not None

    sarif_results = run0.results
    if args.index is not None:
        sarif_results = sarif_results[args.index : (args.index + 1)]

    triage_sarif_results(agent, sarif_results, args.dry_run)

    with open(args.output, "w") as f:
        f.write(
            sarif.model_dump_json(by_alias=True, exclude_none=True, exclude_unset=True)
        )


def triage_classification(classification: str) -> Classification:
    match (classification):
        case "TRUE_POSITIVE":
            return Classification.TRUE_POSITIVE
        case "FALSE_POSITIVE":
            return Classification.FALSE_POSITIVE
        case _:
            return Classification.UNKNOWN


def triage_sarif_results(
    agent: TriageAgent, sarif_results: List[Result], dry_run: bool
) -> None:
    for finding in sarif_results:
        try:
            triage_result = do_select(agent.agent, finding, dry_run)
            if triage_result is None:
                continue
            if finding.properties is None:
                finding.properties = {}

            props = ContrastAiTriageAnalysis(
                schemaVersion=None,
                classification=triage_classification(triage_result.classification),
                justification=triage_result.justification,
                workDetail=triage_result.triage_work,
            )
            finding.properties["contrastTriageAnalysis"] = props.model_dump()
        except Exception as e:
            logger.error(f"got an exception: {e}")
            raise e
        finally:
            print(f"\n\nToken Tracker: {agent.token_tracker.get_total_cost_data()}")


def do_select(
    graph: CompiledStateGraph, result: Result, dry_run: bool = False
) -> TriageResponse | None:
    global logger

    if not result.properties:
        result.properties = {}
    if dry_run:
        console.print("[yellow]DRY RUNNING![/yellow]")
        return TriageResponse(
            classification="FALSE_POSITIVE",
            justification="This is a dry run, so no real analysis was performed.",
            triage_work="No work performed during dry run.",
        )
    print(f"Triaging finding:")
    print(f"    rule_id: {result.rule_id}")
    print(f"    text: {result.message.text}")
    if result.locations is None or len(result.locations) == 0:
        raise ValueError("location data not present")
    relativize_sarif_uri(result)
    prompt_template = f"""
        Determine if this vulnerability finding is a false positive.
        First generate a plan, which are a lists of tasks to accomplish this work.  If future tasks in the plan depend on the results
        of previous tasks, do not add them to the plan.  The will be added dynamically while the
        plan is being executed.

        If you are unable to collect enough information to accurately determine if this is a false positive, then tell the user what data
        is missing and that you can't accurately classify the finding.  The uri in the vulnerability_finding below is the path to the source code
        that contains the vulnerability.

        <vulnerability_finding>
        {result}
        </vulnerability_finding>
        """
    state = {
        "messages": [{"role": "user", "content": prompt_template}],
    }

    response: TriageResponse | Any | None = None
    for ns, evt_type, evt_data in graph.stream(
        state, subgraphs=True, stream_mode=["messages", "updates"]
    ):
        logger.info(f"ns={ns}\neventtype={evt_type}\ndata={evt_data}\n")

        if evt_type == "messages":
            msg, meta = evt_data
            if isinstance(msg, AIMessageChunk):
                for item in msg.content:
                    if not isinstance(item, dict):
                        continue
                    if item["type"] == "text":
                        console.print(
                            item["text"],
                            end="",
                        )
            if isinstance(msg, ToolMessage):
                console.print(
                    f"[purple][bold]ToolCall Returned Content:[/bold]\n{msg.content}[/purple]"
                )
        if evt_type == "updates":
            if "model" in evt_data:
                console.print("\n", end="")
            if isinstance(evt_data, dict):
                if "tools" in evt_data:
                    t: dict[str, Any] = evt_data["tools"]
                    if "todos" not in t:
                        continue
                    todos = t.get("todos", [])
                    console.print("[bold][cyan]Todo List:[/cyan][/bold]")
                    for todo in todos:
                        console.print(
                            f"   [cyan]{todo['content']}: [bold]{todo['status']}[/bold][/cyan]"
                        )
                if "model" in evt_data and "structured_response" in evt_data["model"]:
                    r = evt_data["model"]["structured_response"]
                    if not isinstance(r, TriageResponse):
                        continue
                    response = r

    if response is None:
        console.print("[red]No Triage Results Found[/red]")
        return None

    console.print(
        f"[green][bold]Classification:[/bold]\n{response.classification}\n\n[bold]Justification:[/bold]\n{response.justification}\n\n[bold]Work Performed:[/bold]\n{response.triage_work}[/green]"
    )

    return response


if __name__ == "__main__":
    cli()
