from aws_bedrock import AWS_BEDROCK_PRICING
from pydantic import BaseModel, Field
from typing import Tuple, List, Annotated, Dict, TypedDict, Literal
from enum import Enum
import operator
from sarif_pydantic import Result
from langchain_core.messages import BaseMessage
from langgraph.graph import add_messages


class FunctionDesc(BaseModel):
    name: str = Field(description="name of function")
    parameters: List[Tuple] = Field(
        description="a list of tuples describing the parameter order via list entry and (parameter name, parameter type) via tuple"
    )
    purpose: str = Field(description="purpose of function")
    filepath: str = Field(
        description="path, relative to current working dir, of the file containing the function"
    )
    line_num: int = Field(
        description="line number within file which function declaration starts"
    )


class VulnContext(BaseModel):
    business_logic_description: str = Field(
        description="a description of the business logic the vulnerable line of code is being used within"
    )
    reason: str = Field(
        description="The reason for why might this line of code have a vulnerability in it based on its use in business logic"
    )
    containing_function: FunctionDesc = Field(
        description="A structured description of the function that contains the vulnerable line of code"
    )


class RiskLevelType(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class ImpactStatement(BaseModel):
    statement: str = Field(
        description="A statement that describes the impact of one thing should a vulnerability be exploited"
    )
    risk: RiskLevelType = Field(
        description="The risk level to the security of the system should the situation in this impact statement happen"
    )


class RiskAnalysis(BaseModel):
    impact_statement: List[str] = Field(
        description="a list of items that are impacted should this vulnerability be exploited"
    )


class ClassificationType(str, Enum):
    TRUE_POSITIVE = "True Positive"
    FALSE_POSITIVE = "False Positive"


class TriageReport(BaseModel):
    """A triage report describing the triage data used and results"""

    determination: ClassificationType = Field(
        description="A determination of the finding"
    )
    classification: float = Field(
        description="a number between 0 and 1 that describes how confident "
    )
    risk: RiskLevelType = Field(
        description="The determined risk of this vulnerability if its True Positive"
    )
    justification: str = Field(
        description="A statement justifying the determination, classification, and risk values"
    )
    context: VulnContext = Field(
        description="The relevant context data used in the triage process"
    )
    function_desc: FunctionDesc = Field(
        description="A description of the business logic used in the determination decision"
    )


class Task(BaseModel):
    """Represents a single task in the plan."""

    purpose: str = Field(description="The purpose of why the task should be performed.")
    description: str = Field(description="A prompt of what be performed in this task")


class AgentState(TypedDict):
    messages: Annotated[List[BaseMessage], add_messages]
    finding: Result
    source_code_dir: str
    triage_context: Dict[str, str]
    plan: Annotated[List[Task], operator.add]
    vuln_context: VulnContext | None
    model_name: str
    thing: str
