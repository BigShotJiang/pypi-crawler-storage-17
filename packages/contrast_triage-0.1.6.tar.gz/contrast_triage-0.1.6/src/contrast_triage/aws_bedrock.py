"""
AWS bedrock model ids and token costs
"""

from typing import Literal

# Current pricing on AWS Bedrock as of 10/16/2025
AWS_BEDROCK_PRICING = {
    "us.anthropic.claude-3-5-sonnet-20240620-v1:0": {
        "input": {"cost": 0.003, "count": 1000},
        "output": {"cost": 0.015, "count": 1000},
    },
    "us.anthropic.claude-sonnet-4-20250514-v1:0": {
        "input": {"cost": 0.003, "count": 1000},
        "output": {"cost": 0.015, "count": 1000},
    },
    "us.anthropic.claude-sonnet-4-5-20250929-v1:0": {
        "input": {"cost": 0.0033, "count": 1000},
        "output": {"cost": 0.0165, "count": 1000},
    },
    "us.anthropic.claude-haiku-4-5-20251001-v1:0": {
        "input": {"cost": 0.0011, "count": 1000},
        "output": {"cost": 0.0055, "count": 1000},
    },
    "us.amazon.nova-premier-v1:0": {
        "input": {"cost": 0.0025, "count": 1000},
        "output": {"cost": 0.00125, "count": 1000},
    },
    "us.amazon.nova-pro-v1:0": {
        "input": {"cost": 0.0008, "count": 1000},
        "output": {"cost": 0.0032, "count": 1000},
    },
    "us.amazon.nova-lite-v1:0": {
        "input": {"cost": 0.00006, "count": 1000},
        "output": {"cost": 0.00024, "count": 1000},
    },
    "us.amazon.nova-micro-v1:0": {
        "input": {"cost": 0.000035, "count": 1000},
        "output": {"cost": 0.00014, "count": 1000},
    },
    "us.meta.llama3-3-70b-instruct-v1:0": {
        "input": {"cost": 0.00072, "count": 1000},
        "output": {"cost": 0.00072, "count": 1000},
    },
    "us.openai.gpt-oss-120b-1:0": {
        "input": {"cost": 0.00015, "count": 1000},
        "output": {"cost": 0.0006, "count": 1000},
    },
    "us.deepseek.r1-v1:0": {
        "input": {"cost": 0.00135, "count": 1000},
        "output": {"cost": 0.0054, "count": 1000},
    },
    "us.deepseek.v3-v1:0": {
        "input": {"cost": 0.00058, "count": 1000},
        "output": {"cost": 0.00168, "count": 1000},
    },
    "us.qwen.qwen3-coder-480b-a35b-v1:0": {
        "input": {"cost": 0.00045, "count": 1000},
        "output": {"cost": 0.0018, "count": 1000},
    },
    "us.qwen.qwen3-32b-v1:0": {
        "input": {"cost": 0.00015, "count": 1000},
        "output": {"cost": 0.0006, "count": 1000},
    },
}


def compute_cost(
    model: str, token_type: Literal["input", "output"], count: int
) -> float:
    token_rates = AWS_BEDROCK_PRICING[model]
    token_type_price = token_rates[token_type]
    cost = token_type_price["cost"]
    per_count = token_type_price["count"]
    return count / per_count * cost
