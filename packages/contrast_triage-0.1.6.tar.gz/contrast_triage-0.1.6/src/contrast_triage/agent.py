from langchain.agents import create_agent
from deepagents.middleware import SubAgent, CompiledSubAgent
from .middleware.tokentracker import TokenUsageTrackerMiddleware

from langchain.chat_models import init_chat_model, BaseChatModel
from langchain.agents.middleware import TodoListMiddleware
from langgraph.cache.base import BaseCache
from deepagents.middleware.patch_tool_calls import PatchToolCallsMiddleware
from langchain_community.agent_toolkits import FileManagementToolkit
from langchain_core.tools import BaseTool
from collections.abc import Callable, Sequence
from typing import Any, Literal
from langchain.agents.middleware.types import AgentMiddleware
from langchain.agents.structured_output import ResponseFormat
from langgraph.types import Checkpointer
from langgraph.store.base import BaseStore
from langgraph.graph.state import CompiledStateGraph
from langchain.agents import create_agent
from sarif_pydantic import Result
from langchain_core.messages import AIMessage
from pydantic import BaseModel, Field
from langchain.agents.structured_output import ToolStrategy, AutoStrategy
from pprint import pprint
from langchain_core.callbacks.usage import UsageMetadataCallbackHandler


BASE_AGENT_PROMPT = "In order to complete the objective that the user asks of you, you have access to a number of standard tools."


def create_deep_triage_agent(
    model: str | BaseChatModel | None = None,
    tools: Sequence[BaseTool | Callable | dict[str, Any]] | None = None,
    *,
    system_prompt: str | None = None,
    middleware: Sequence[AgentMiddleware] = (),
    subagents: list[SubAgent | CompiledSubAgent] | None = None,
    response_format: ResponseFormat | None = None,
    context_schema: type[Any] | None = None,
    checkpointer: Checkpointer | None = None,
    store: BaseStore | None = None,
    use_longterm_memory: bool = False,
    debug: bool = False,
    name: str | None = None,
    cache: BaseCache | None = None,
) -> CompiledStateGraph:
    """Create a deep agent.

    This agent will by default have access to a tool to write todos (write_todos),
    four file editing tools: write_file, ls, read_file, edit_file, and a tool to call
    subagents.

    Args:
        tools: The tools the agent should have access to.
        system_prompt: The additional instructions the agent should have. Will go in
            the system prompt.
        middleware: Additional middleware to apply after standard middleware.
        model: The model to use.
        subagents: The subagents to use. Each subagent should be a dictionary with the
            following keys:
                - `name`
                - `description` (used by the main agent to decide whether to call the
                  sub agent)
                - `prompt` (used as the system prompt in the subagent)
                - (optional) `tools`
                - (optional) `model` (either a LanguageModelLike instance or dict
                  settings)
                - (optional) `middleware` (list of AgentMiddleware)
        response_format: A structured output response format to use for the agent.
        context_schema: The schema of the deep agent.
        checkpointer: Optional checkpointer for persisting agent state between runs.
        store: Optional store for persisting longterm memories.
        use_longterm_memory: Whether to use longterm memory - you must provide a store
            in order to use longterm memory.
        debug: Whether to enable debug mode. Passed through to create_agent.
        name: The name of the agent. Passed through to create_agent.
        cache: The cache to use for the agent. Passed through to create_agent.

    Returns:
        A configured deep agent.
    """
    if model is None:
        raise ValueError("model can't be null!")

    deepagent_middleware = [
        TodoListMiddleware(),
        PatchToolCallsMiddleware(),
    ]
    if middleware is not None:
        deepagent_middleware.extend(middleware)

    return create_agent(
        model,
        system_prompt=(
            f"{system_prompt}\n\n{BASE_AGENT_PROMPT}"
            if system_prompt
            else BASE_AGENT_PROMPT
        ),
        tools=tools,
        middleware=deepagent_middleware,
        response_format=response_format,
        context_schema=context_schema,
        checkpointer=checkpointer,
        store=store,
        debug=debug,
        name=name,
        cache=cache,
    ).with_config({"recursion_limit": 1000})


class TriageResponse(BaseModel):
    classification: Literal["TRUE_POSITIVE", "FALSE_POSITIVE", "UNKNOWN"]
    justification: str = Field(
        description="A short and consise justification for the classification based on the work performed"
    )
    triage_work: str = Field(
        description="A detailed explanation of the work performed to arrive at the classification such that the effort can be validated"
    )


class TriageAgent:
    prompt_template = """
        Determine if this vulnerability finding is a false positive.
        First generate a plan, which are a lists of tasks to accomplish this work.  If future tasks in the plan depend on the results
        of previous tasks, do not add them to the plan.  The will be added dynamically while the
        plan is being executed.

        If you are unable to collect enough information to accurately determine if this is a false positive, then tell the user what data
        is missing and that you can't accurately classify the finding.  The uri in the vulnerability_finding below is the path to the source code
        that contains the vulnerability.

        <vulnerability_finding>
        {result}
        </vulnerability_finding>
        """
    state = {
        "messages": [{"role": "user", "content": prompt_template}],
    }

    def __init__(self, provider: str, model: str, project_source: str) -> None:

        self.usage_cb = UsageMetadataCallbackHandler()
        self.llm = init_chat_model(
            model=model,
            model_provider=provider,
            temperature=0,
            callbacks=[self.usage_cb],
        )
        read_only_tools = FileManagementToolkit(
            root_dir=project_source,
            selected_tools=["read_file", "list_directory", "file_search"],
        )
        self.token_tracker = TokenUsageTrackerMiddleware()
        resp_format = AutoStrategy(schema=TriageResponse)

        self.agent = create_deep_triage_agent(
            model=self.llm,
            tools=read_only_tools.get_tools(),
            subagents=[],
            middleware=[self.token_tracker],
            response_format=resp_format,
        )

    def triage_finding(self, result: Result) -> TriageResponse | None:
        prompt = self.prompt_template.format(result=result)
        state = {
            "messages": [{"role": "user", "content": prompt}],
        }

        ret: TriageResponse | None = None
        for ns, evt_type, evt_data in self.agent.stream(
            state, subgraphs=True, stream_mode=["messages", "updates"]
        ):
            if evt_type == "messages":
                pass
            if evt_type == "updates":
                print(f"evt: {evt_data}")
                if not isinstance(evt_data, dict):
                    continue
                print("-" * 60)
                pprint(evt_data)
                if "model" in evt_data and "structured_response" in evt_data["model"]:
                    response = evt_data["model"]["structured_response"]
                    if not isinstance(response, TriageResponse):
                        continue
                    ret = response

        return ret
