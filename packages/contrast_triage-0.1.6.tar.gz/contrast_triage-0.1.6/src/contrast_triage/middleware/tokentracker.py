"""
Middleware for langgraph agents that will track token usage and cost over multiple turns.
It can track tokens and cost between multiple models being used simultaneously

TODO: it does not yet handle special tokens and cost, like "cached tokens".  That will be
added when token caching middleware is added.
"""

from typing import Any, override, Self
from langchain.agents.middleware.types import AgentMiddleware, AgentState
from langgraph.runtime import Runtime
from pydantic import Field, BaseModel
from ..aws_bedrock import AWS_BEDROCK_PRICING, compute_cost
from typing import Tuple, List, Dict, cast
from langchain_core.messages import AIMessage, AIMessageChunk
from dataclasses import dataclass, field
import logging
from langchain_core.callbacks import UsageMetadataCallbackHandler
from langchain_core.messages.ai import UsageMetadata, add_usage
import operator
from collections.abc import Callable

_logger = logging.getLogger(__name__)


class TokenUsageEvent(BaseModel):
    input: int = Field(description="The number of input tokens used")
    output: int = Field(description="The number of output tokens used")
    model_name: str = Field(
        description="The name of the model the tokens were used from"
    )

    def calculate_cost(self) -> Tuple[float, float]:
        if self.model_name not in AWS_BEDROCK_PRICING:
            raise ValueError(f"model '{self.model_name}' has no pricing data")
        model_input_price = AWS_BEDROCK_PRICING[self.model_name]["input"]
        model_output_price = AWS_BEDROCK_PRICING[self.model_name]["output"]
        input_token_cost: float = (
            self.input / model_input_price["count"] * model_input_price["cost"]
        )
        output_token_cost: float = (
            self.output / model_output_price["count"] * model_output_price["cost"]
        )
        return (input_token_cost, output_token_cost)

    @staticmethod
    def from_usagemetadata(model: str, usage: UsageMetadata) -> "TokenUsageEvent":
        return TokenUsageEvent(
            input=usage["input_tokens"], output=usage["output_tokens"], model_name=model
        )


@dataclass
class TokenCost:
    input_tokens: int = 0
    output_tokens: int = 0
    input_cost: float = 0
    output_cost: float = 0
    total_cost: float = 0

    def _add(self, event: TokenUsageEvent):
        self.input_tokens += event.input
        self.output_tokens += event.output
        cost = event.calculate_cost()
        self.input_cost += cost[0]
        self.output_cost += cost[1]
        self.total_cost = self.input_cost + self.output_cost


@dataclass
class TokenCostTracker:
    events: List[TokenUsageEvent] = field(default_factory=list)

    def add(self, event: TokenUsageEvent):
        self.events.append(event)

    def compute_cost_report(self) -> Dict[str, TokenCost]:
        ret = {}
        for evt in self.events:
            if evt.model_name not in ret:
                ret[evt.model_name] = TokenCost()
            try:
                ret[evt.model_name]._add(evt)
            except ValueError as e:
                _logger.error(f"error trying to add a token cost event {e}")

        return ret


class CostUsageMetadata(UsageMetadata):
    """
    extend the langchain usagemetadata structure to contain cost information as well.
    """

    input_cost: float
    output_cost: float
    total_cost: float


def add_cost_usage(
    left: CostUsageMetadata | None, right: CostUsageMetadata | None
) -> CostUsageMetadata:
    """
    Recursively add two CostUsageMetadata objects.
    Args:
        left: The first `CostUsageMetadata` object.
        right: The second `CostUsageMetadata` object.

    Returns:
        The sum of the two `CostUsageMetadata` objects.

    """
    if not (left or right):
        return CostUsageMetadata(
            input_tokens=0,
            output_tokens=0,
            total_tokens=0,
            input_token_details={},
            output_token_details={},
            input_cost=0.0,
            output_cost=0.0,
            total_cost=0.0,
        )
    if not (left and right):
        return cast("CostUsageMetadata", left or right)

    return CostUsageMetadata(
        input_tokens=left["input_tokens"] + right["input_tokens"],
        output_tokens=left["output_tokens"] + right["output_tokens"],
        total_tokens=left["total_tokens"] + right["total_tokens"],
        input_token_details={},
        output_token_details={},
        input_cost=left["input_cost"] + right["input_cost"],
        output_cost=left["output_cost"] + right["output_cost"],
        total_cost=left["total_cost"] + right["total_cost"],
    )


def make_cost_usage_metadata(
    provider: str, model: str, usage: UsageMetadata
) -> CostUsageMetadata:
    """
    create a CostUsageMetadata structure from a UsageMetadata structure.
    """
    assert provider == "bedrock_converse" or provider == "bedrock"
    input_tokens = usage["input_tokens"]
    output_tokens = usage["output_tokens"]
    input_cost = compute_cost(model, "input", input_tokens)
    output_cost = compute_cost(model, "output", output_tokens)
    return CostUsageMetadata(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        input_token_details=usage.get("input_token_details", {}),
        output_token_details=usage.get("output_token_details", {}),
        total_tokens=usage["total_tokens"],
        input_cost=input_cost,
        output_cost=output_cost,
        total_cost=input_cost + output_cost,
    )


class TokenUsageTrackerMiddleware(AgentMiddleware):
    def __init__(self) -> None:
        self.token_cost_tracker = TokenCostTracker()

    @override
    def after_model(
        self, state: AgentState, runtime: Runtime[None]
    ) -> dict[str, Any] | None:

        if "messages" not in state or len(state["messages"]) == 0:
            _logger.error(f"state object is invalid")
            return super().after_model(state, runtime)

        # get the previous AIMessage to check for token usage metadata from the model call
        # Sometime a ToolMessage will proceed the AIMessage, so we need to search backwards.
        # The AIMessage is what has the usage metadata.
        msg: AIMessage | None = None
        for i in range(len(state["messages"]) - 1, -1, -1):
            if isinstance(state["messages"][i], AIMessage):
                msg = cast(AIMessage, state["messages"][i])
                break

        if isinstance(msg, AIMessage):
            usage = msg.usage_metadata
            rmeta = msg.response_metadata
            if (usage is not None) and ("model_name" in rmeta):
                evt = TokenUsageEvent.from_usagemetadata(rmeta["model_name"], usage)
                self.token_cost_tracker.add(evt)
                _logger.debug(f"added token usage event {evt}")
            else:
                if isinstance(msg, AIMessageChunk):
                    # only the last chunk in a streamed message will have usage_metadata data
                    _logger.debug("skipping ai message chunk")
                else:
                    _logger.error("token usage or model not present. skipping!")
        else:
            _logger.info(f"skipping unexpected msg type {type(msg)}")

        return super().after_model(state, runtime)

    def get_total_cost_data(self) -> Dict[str, TokenCost]:
        return self.token_cost_tracker.compute_cost_report()
