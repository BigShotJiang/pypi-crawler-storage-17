"""Init   module."""

from aptt.heads.language_modeling import (
    CombinedLMHead,
    LanguageModelingHead,
    MultiTokenPredictionHead,
)
