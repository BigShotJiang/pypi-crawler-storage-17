def hello() -> str:
    return f"Hello from the arena"