from arena.hello import hello

def run_hello() -> None:
    print(hello())

if __name__ == "__main__":
    run_hello()
