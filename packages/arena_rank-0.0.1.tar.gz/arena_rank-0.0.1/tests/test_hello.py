from arena.hello import hello

def test_hello() -> None:
    assert hello() == "Hello from the arena"