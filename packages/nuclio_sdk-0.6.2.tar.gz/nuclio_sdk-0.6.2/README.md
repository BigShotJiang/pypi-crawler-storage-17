![CI](https://github.com/nuclio/nuclio-sdk-py/workflows/CI/badge.svg)

# Nuclio SDK

Python SDK for Nuclio (www.nuclio.io, www.github.com/nuclio/nuclio).
