from .dataframe_ext import LakeNamespace
