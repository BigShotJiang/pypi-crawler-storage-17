"""
A subpackage containing abstract base classes for arrays over Galois fields or rings.
"""

from ._array import *
