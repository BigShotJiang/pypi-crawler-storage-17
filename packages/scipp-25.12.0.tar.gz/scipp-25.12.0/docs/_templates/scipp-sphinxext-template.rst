{{ fullname | escape | underline}}

.. automodule:: {{ fullname }}
