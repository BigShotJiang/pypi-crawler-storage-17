Internals
=========

.. toctree::
   :maxdepth: 2

   concepts
   constructing_variables
   customizing
   multi_dimensional_indexing
   transform
   variable_implementation