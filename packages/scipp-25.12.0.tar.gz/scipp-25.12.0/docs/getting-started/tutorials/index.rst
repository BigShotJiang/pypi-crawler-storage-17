Tutorials
=========

.. toctree::
   :maxdepth: 2

   from-tabular-data-to-binned-data
   solar_flares
