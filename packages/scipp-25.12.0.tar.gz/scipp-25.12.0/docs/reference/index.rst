API Reference
=============

.. toctree::
   :maxdepth: 2

   classes
   creation-functions
   free-functions
   modules
   linear-algebra
   dtype
   units
   error-propagation
   ownership-mechanism-and-readonly-flags
   logging
   testing
