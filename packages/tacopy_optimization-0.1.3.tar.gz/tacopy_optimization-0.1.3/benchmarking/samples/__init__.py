"""Sample tail-recursive functions for benchmarking."""
