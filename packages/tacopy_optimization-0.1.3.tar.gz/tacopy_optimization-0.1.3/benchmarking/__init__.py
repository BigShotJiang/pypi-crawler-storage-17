"""Benchmarking suite for tacopy."""
