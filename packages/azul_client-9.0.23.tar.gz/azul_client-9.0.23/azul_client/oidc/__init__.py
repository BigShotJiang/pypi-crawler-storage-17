from .oidc import OIDC

__all__ = [
    "OIDC",
]
