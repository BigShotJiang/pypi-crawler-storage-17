# Benchmarks

Performance benchmarks using Criterion.

## Running Benchmarks

```bash
cargo bench
```
