# Tests

Integration tests for PDF library.

## Structure

- `fixtures/` - Test PDF files
- `test_*.rs` - Integration test files

## Running Tests

```bash
cargo test --test '*'
```
