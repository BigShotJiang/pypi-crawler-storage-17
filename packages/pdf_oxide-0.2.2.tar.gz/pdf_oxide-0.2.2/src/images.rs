//! Image extraction from PDFs.
//!
//! Handles extraction and management of images embedded in PDF documents.

// use crate::error::Result;

/// PDF image.
pub struct PdfImage {
    // TODO: Add fields
}
