default_app_config = "django_whatsapp_api_wrapper.apps.DjangoWhatsappApiWrapperConfig"


