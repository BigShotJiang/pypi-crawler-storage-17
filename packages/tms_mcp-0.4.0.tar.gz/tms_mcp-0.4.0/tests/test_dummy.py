# This file serves as a placeholder, ensuring that pytest does not return an error due to the absence of any test files.
# Once you start developing your own tests, this file and its function can be safely removed.


def test_dummy():
    pass
