DEFAULT: int = 2

MINIMUM: int = 0

MAXIMUM: int = 9
