NONE_VALUE: str = "NONE"
# Note that is has to be an upppercase string to be compatible with the rest of the system.
