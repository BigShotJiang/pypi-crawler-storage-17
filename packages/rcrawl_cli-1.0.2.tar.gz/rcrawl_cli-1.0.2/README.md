# RCrawl CLI

Command-line interface for RCrawl API.

## Installation

```bash
# Via pip
pip install rcrawl-cli

# Via pipx (recommended)
pipx install rcrawl-cli

# From source
git clone https://github.com/your-org/rcrawl-cli.git
cd rcrawl-cli
pip install -e .
```

## Quick Start

```bash
# Configure
rcrawl config init

# Login
rcrawl auth login

# Scrape a page
rcrawl scrape https://example.com

# Get help
rcrawl --help
```

## Documentation

- [User Guide](USER_GUIDE.md) - Installation and usage instructions
- [Developer Guide](DEVELOPER_GUIDE.md) - Development and contribution guide
