"""HTTP client for RCrawl API."""

import time
from typing import Optional, Dict, Any, Union
import httpx
from httpx import Response


class APIError(Exception):
    """Base exception for API errors."""
    pass


class AuthenticationError(APIError):
    """Authentication failed."""
    pass


class ValidationError(APIError):
    """Request validation failed."""
    pass


class APIRequestError(APIError):
    """API request failed."""
    def __init__(self, message: str, status_code: Optional[int] = None, response: Optional[Dict] = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class NetworkError(APIError):
    """Network error occurred."""
    pass


class APIClient:
    """HTTP client for interacting with RCrawl API."""
    
    def __init__(
        self,
        api_url: str,
        api_key: Optional[str] = None,
        token: Optional[str] = None,
        timeout: int = 30,
        retry_attempts: int = 3,
        retry_delay: int = 1,
    ):
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key
        self.token = token
        self.timeout = timeout
        self.retry_attempts = retry_attempts
        self.retry_delay = retry_delay
        
        # Setup headers
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        
        if self.api_key:
            self.headers["X-API-Key"] = self.api_key
        elif self.token:
            self.headers["Authorization"] = f"Bearer {self.token}"
    
    def _get_client(self) -> httpx.Client:
        """Get HTTP client instance."""
        return httpx.Client(
            base_url=self.api_url,
            headers=self.headers,
            timeout=self.timeout,
        )
    
    def _handle_response(self, response: Response) -> Dict[str, Any]:
        """Handle API response and raise appropriate errors."""
        if response.status_code == 401:
            raise AuthenticationError("Authentication failed. Please run 'rcrawl auth login'")
        
        if response.status_code == 403:
            raise AuthenticationError("Access forbidden. Check your permissions.")
        
        if response.status_code == 400:
            try:
                error_data = response.json()
                error_msg = error_data.get("detail", "Validation error")
                raise ValidationError(f"Validation error: {error_msg}")
            except:
                raise ValidationError(f"Validation error: {response.text}")
        
        if response.status_code >= 500:
            raise APIRequestError(
                f"Server error: {response.status_code}",
                status_code=response.status_code,
            )
        
        if response.status_code >= 400:
            try:
                error_data = response.json()
                error_msg = error_data.get("detail", response.text)
                raise APIRequestError(
                    f"API error ({response.status_code}): {error_msg}",
                    status_code=response.status_code,
                    response=error_data,
                )
            except:
                raise APIRequestError(
                    f"API error ({response.status_code}): {response.text}",
                    status_code=response.status_code,
                )
        
        try:
            return response.json()
        except:
            return {"text": response.text}
    
    def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """Make HTTP request with retry logic."""
        last_error = None
        
        for attempt in range(self.retry_attempts):
            try:
                with self._get_client() as client:
                    response = client.request(
                        method=method,
                        url=path,
                        params=params,
                        json=json_data,
                        **kwargs,
                    )
                    return self._handle_response(response)
            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_error = e
                if attempt < self.retry_attempts - 1:
                    time.sleep(self.retry_delay * (attempt + 1))
                    continue
                raise NetworkError(f"Network error: {str(e)}")
            except (AuthenticationError, ValidationError, APIRequestError):
                raise
            except Exception as e:
                last_error = e
                if attempt < self.retry_attempts - 1:
                    time.sleep(self.retry_delay * (attempt + 1))
                    continue
                raise APIError(f"Unexpected error: {str(e)}")
        
        raise NetworkError(f"Request failed after {self.retry_attempts} attempts: {str(last_error)}")
    
    def get(self, path: str, params: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Make GET request."""
        return self._request("GET", path, params=params, **kwargs)
    
    def post(self, path: str, json_data: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Make POST request."""
        return self._request("POST", path, json_data=json_data, **kwargs)
    
    def put(self, path: str, json_data: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Make PUT request."""
        return self._request("PUT", path, json_data=json_data, **kwargs)
    
    def delete(self, path: str, **kwargs) -> Dict[str, Any]:
        """Make DELETE request."""
        return self._request("DELETE", path, **kwargs)
