"""RCrawl CLI - Command-line interface for RCrawl API."""

__version__ = "1.0.2"
