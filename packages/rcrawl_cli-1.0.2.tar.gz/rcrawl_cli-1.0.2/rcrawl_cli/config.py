"""Configuration management for RCrawl CLI."""

import json
import os
from pathlib import Path
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field

__all__ = ["Config", "ConfigManager"]


class Config(BaseModel):
    """CLI configuration model."""
    
    api_url: str = Field(default="https://api.rcrawl.com", description="API server URL")
    api_key: Optional[str] = Field(default=None, description="API key for authentication")
    token: Optional[str] = Field(default=None, description="JWT token")
    default_format: str = Field(default="json", description="Default output format")
    timeout: int = Field(default=30, description="Request timeout in seconds")
    retry_attempts: int = Field(default=3, description="Number of retry attempts")
    retry_delay: int = Field(default=1, description="Delay between retries in seconds")
    output_dir: str = Field(default="./rcrawl-output", description="Default output directory")
    save_screenshots: bool = Field(default=False, description="Save screenshots locally")
    save_to_s3: bool = Field(default=False, description="Save results to S3")


class ConfigManager:
    """Manages CLI configuration."""
    
    def __init__(self):
        self.config_dir = self._get_config_dir()
        self.config_file = self.config_dir / "config.json"
        self.config_dir.mkdir(parents=True, exist_ok=True)
    
    def _get_config_dir(self) -> Path:
        """Get configuration directory based on OS."""
        if os.name == "nt":  # Windows
            return Path(os.getenv("APPDATA", "")) / ".rcrawl"
        else:  # Linux/macOS
            return Path.home() / ".rcrawl"
    
    def load(self) -> Config:
        """Load configuration from file."""
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                return Config(**data)
            except Exception as e:
                print(f"Warning: Failed to load config: {e}")
                return Config()
        return Config()
    
    def save(self, config: Config) -> None:
        """Save configuration to file."""
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(config.model_dump(exclude_none=True), f, indent=2)
        except Exception as e:
            raise Exception(f"Failed to save config: {e}")
    
    def get(self, key: str) -> Optional[Any]:
        """Get configuration value."""
        config = self.load()
        return getattr(config, key, None)
    
    def set(self, key: str, value: Any) -> None:
        """Set configuration value."""
        config = self.load()
        if hasattr(config, key):
            setattr(config, key, value)
            self.save(config)
        else:
            raise ValueError(f"Unknown configuration key: {key}")
    
    def unset(self, key: str) -> None:
        """Unset configuration value (set to None)."""
        config = self.load()
        if hasattr(config, key):
            setattr(config, key, None)
            self.save(config)
        else:
            raise ValueError(f"Unknown configuration key: {key}")
    
    def get_from_env(self) -> Dict[str, Any]:
        """Get configuration from environment variables."""
        env_config = {}
        env_mapping = {
            "RCRAWL_API_URL": "api_url",
            "RCRAWL_API_KEY": "api_key",
            "RCRAWL_TOKEN": "token",
            "RCRAWL_FORMAT": "default_format",
            "RCRAWL_TIMEOUT": ("timeout", int),
            "RCRAWL_OUTPUT_DIR": "output_dir",
        }
        
        for env_var, config_key in env_mapping.items():
            value = os.getenv(env_var)
            if value:
                if isinstance(config_key, tuple):
                    key, converter = config_key
                    env_config[key] = converter(value)
                else:
                    env_config[config_key] = value
        
        return env_config
    
    def get_merged_config(self) -> Config:
        """Get configuration merged from file and environment."""
        config = self.load()
        env_config = self.get_from_env()
        
        # Override with environment variables
        for key, value in env_config.items():
            if hasattr(config, key):
                setattr(config, key, value)
        
        return config
