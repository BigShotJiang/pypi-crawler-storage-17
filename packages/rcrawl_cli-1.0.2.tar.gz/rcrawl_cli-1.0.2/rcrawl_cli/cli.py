"""Main CLI entry point."""

import click
from typing import Optional
from .config import ConfigManager
from .api_client import APIClient
from .utils.errors import handle_error


@click.group()
@click.option("--api-url", envvar="RCRAWL_API_URL", help="API server URL")
@click.option("--api-key", envvar="RCRAWL_API_KEY", help="API key")
@click.option("--token", envvar="RCRAWL_TOKEN", help="JWT token")
@click.option("--format", "output_format", default="json", help="Output format: json, yaml, table, markdown")
@click.option("--verbose", "-v", count=True, help="Verbose output")
@click.option("--quiet", "-q", is_flag=True, help="Quiet mode")
@click.option("--no-color", is_flag=True, help="Disable colored output")
@click.option("--config", type=click.Path(), help="Path to config file")
@click.version_option(version="1.0.0")
@click.pass_context
def cli(ctx, api_url, api_key, token, output_format, verbose, quiet, no_color, config):
    """RCrawl CLI - Command-line interface for RCrawl API."""
    ctx.ensure_object(dict)
    
    # Load configuration
    config_manager = ConfigManager()
    if config:
        # Load from specified config file
        import json
        from .config import Config
        with open(config, "r") as f:
            config_data = json.load(f)
        cfg = Config(**config_data)
    else:
        cfg = config_manager.get_merged_config()
    
    # Override with CLI options
    if api_url:
        cfg.api_url = api_url
    if api_key:
        cfg.api_key = api_key
    if token:
        cfg.token = token
    
    # Create API client
    try:
        client = APIClient(
            api_url=cfg.api_url,
            api_key=cfg.api_key,
            token=cfg.token,
            timeout=cfg.timeout,
            retry_attempts=cfg.retry_attempts,
            retry_delay=cfg.retry_delay,
        )
    except Exception as e:
        handle_error(e, verbose > 0)
    
    ctx.obj["client"] = client
    ctx.obj["config"] = cfg
    ctx.obj["output_format"] = output_format
    ctx.obj["verbose"] = verbose
    ctx.obj["quiet"] = quiet
    ctx.obj["no_color"] = no_color


# Import commands (lazy import to avoid circular dependencies)
def register_commands():
    """Register all CLI commands."""
    from .commands import scrape, batch, crawl, map_cmd, extract, tasks, tokens, auth, apikeys, admin, monitoring, config_cmd, completion
    
    cli.add_command(scrape.scrape)
    cli.add_command(batch.batch)
    cli.add_command(crawl.crawl)
    cli.add_command(map_cmd.map)
    cli.add_command(extract.extract)
    cli.add_command(tasks.tasks)
    cli.add_command(tokens.tokens)
    cli.add_command(auth.auth)
    cli.add_command(apikeys.apikeys)
    cli.add_command(admin.admin)
    cli.add_command(monitoring.monitoring)
    cli.add_command(config_cmd.config)
    cli.add_command(completion.completion)

# Register commands
register_commands()


if __name__ == "__main__":
    cli()
