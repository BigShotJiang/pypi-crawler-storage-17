"""Setup script for RCrawl CLI."""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="rcrawl-cli",
    version="1.0.2",
    author="rsu2000",
    author_email="rsu2000@gmail.com",
    description="Command-line interface for RCrawl API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    license="MIT",
    url="https://github.com/your-org/rcrawl-cli",
    project_urls={
        "Documentation": "https://docs.rcrawl.com",
        "Source": "https://github.com/your-org/rcrawl-cli",
        "Tracker": "https://github.com/your-org/rcrawl-cli/issues",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.11",
    install_requires=[
        "click>=8.0.0",
        "httpx>=0.28.0",
        "pydantic>=2.10.0",
        "pydantic-settings>=2.6.0",
        "pyyaml>=6.0",
        "tqdm>=4.66.0",
        "beautifulsoup4>=4.12.0",
    ],
    extras_require={
        "dev": [
            "pytest>=8.0.0",
            "pytest-asyncio>=0.24.0",
            "black>=24.0.0",
            "ruff>=0.1.0",
        ],
        "completion": [
            "click-completion>=0.5.0",
        ],
        "excel": [
            "pandas>=2.0.0",
            "openpyxl>=3.1.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "rcrawl=rcrawl_cli.cli:cli",
        ],
    },
)
