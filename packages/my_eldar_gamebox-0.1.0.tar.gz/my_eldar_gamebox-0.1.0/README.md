# 🎮 GameBox

## Guess the Number

```python
from gamebox.guess_number import play
play()
