# Table を実行する

```bash{file=a.sh,display=no}
if [ "$3" != "-y" ]; then
  echo "error"
  echo "error in stderr" 1>&2
  exit 1
fi
echo $* | tee -a log
```

タイトル行をオプションにする

::: run bash a.sh
| -x | -y | opt |
| :--- | :--- | :--- |
| 1    | true | abc |
| 2    | false | def |
| 3    | true |     |

この場合、以下のものを実行し、Result 列を追加して結果を表示する。エラーが発生した場合は、その行で実行を止めてエラーと出力を表示する。

```bash{run=no}
bash a.sh -x 1 -y abc
bash a.sh -x 2 def
bash a.sh -x 3 -y
```

出力はこんな感じ。

```
Command: bash a.sh -x 2 opt def
Output:
error

Error:
error in stderr

Execution failed
```

