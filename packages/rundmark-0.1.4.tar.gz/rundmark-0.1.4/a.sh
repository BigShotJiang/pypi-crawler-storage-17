if [ "$3" != "-y" ]; then
  echo "error"
  echo "error in stderr" 1>&2
  exit 1
fi
echo $* | tee -a log