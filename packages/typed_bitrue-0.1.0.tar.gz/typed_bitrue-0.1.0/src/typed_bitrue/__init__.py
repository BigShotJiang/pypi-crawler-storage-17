"""
### Typed Bitrue
> A fully typed, validated async client for the Bitrue API

- Details
"""