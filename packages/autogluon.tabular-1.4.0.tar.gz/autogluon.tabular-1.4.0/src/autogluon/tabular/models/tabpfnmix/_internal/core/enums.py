

class Task:
    CLASSIFICATION = "classification"
    REGRESSION = "regression"
