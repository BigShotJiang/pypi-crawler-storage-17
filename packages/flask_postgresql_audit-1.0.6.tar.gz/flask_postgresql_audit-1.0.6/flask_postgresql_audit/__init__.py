# ruff: noqa: F401
from .core import Audit, PostgreSQLAudit

__version__ = "1.0.6"
