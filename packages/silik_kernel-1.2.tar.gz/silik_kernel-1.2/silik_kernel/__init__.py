"""Silik Base Kernel : Multi Kernel Interaction"""

__version__ = "1.2"

from .kernel import SilikBaseKernel  # noqa: F401
