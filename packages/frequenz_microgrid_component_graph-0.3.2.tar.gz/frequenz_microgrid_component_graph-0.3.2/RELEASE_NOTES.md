# Frequenz Microgrid Component Graph Library Release Notes

## New Features

- It is now possible to create subclasses of the `ComponentGraph` and `ComponentGraphConfig` classes from python.
