from syngen.ml.flatten_json.flatten_json import (  # noqa: F401;
    check_if_numbers_are_consecutive,
    flatten,
    flatten_preserve_lists,
    unflatten,
    unflatten_list,
    safe_flatten
)
