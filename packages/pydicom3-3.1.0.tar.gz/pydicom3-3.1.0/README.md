# Pydicom3
Pydicom3 is a vendored fork of the [pydicom](https://github.com/pydicom/pydicom) package, 
with a few changes made to increase error tolerance so as to allow for the ingestion of a wider range of 
DICOM files we receive from data vendors (which may be malformed but salvageable).

For any documentation needs, please refer to the `pydicom` package.
