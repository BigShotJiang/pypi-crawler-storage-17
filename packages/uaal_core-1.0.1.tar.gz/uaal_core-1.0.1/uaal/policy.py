POLICIES = {
    "credit-policy-v1": {
        "min_score": 700,
        "max_util": 0.6
    }
}

def get_policy(version: str):
    return POLICIES.get(version)
