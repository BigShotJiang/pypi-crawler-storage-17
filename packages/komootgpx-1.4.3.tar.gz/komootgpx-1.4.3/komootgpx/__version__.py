VERSION = (1, 4, 3)
__version__ = '.'.join(map(str, VERSION))
