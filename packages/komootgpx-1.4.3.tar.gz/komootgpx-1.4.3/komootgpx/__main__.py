from .komootgpx import entrypoint

if __name__ == "__main__":
    entrypoint()
