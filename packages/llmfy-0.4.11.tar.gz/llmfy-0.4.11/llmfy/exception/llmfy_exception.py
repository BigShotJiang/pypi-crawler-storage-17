class LLMfyException(Exception):
    """LLMfyException Class"""

    pass
