"""Version information automatically updated by bumpver."""

__version__ = "1.0.0"
