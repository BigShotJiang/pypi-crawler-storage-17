# -*- coding: utf-8 -*-
# Author: Nianze A. TAO (Omozawa SUENO)
"""
call mol2chemfigPy3.main
"""
import mol2chemfigPy3


if __name__ == "__main__":
    mol2chemfigPy3.main("mol2chemfig")
