# version
__version__ = "0.4.1"
# author
__author__ = "Sina Gilassi"
# email
__email__ = "sina.gilassi@gmail.com"
# license
__license__ = "Apache-2.0"
# package description
__description__ = "Python Thermodynamic Calculation Engine powered by PyThermoDB."
