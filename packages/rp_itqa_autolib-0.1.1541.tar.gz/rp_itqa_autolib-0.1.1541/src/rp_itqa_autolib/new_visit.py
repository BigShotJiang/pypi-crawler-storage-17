from unittest import result
from robot.api.deco import keyword, not_keyword
from robot.api import logger
import typing
from robot.libraries.BuiltIn import BuiltIn
from db import *
import random
from .utils_basic import *
from .new_patient_transaction import new_patient_transaction


class new_visit(new_patient_transaction):
    def __init__(self):
        self.Tcid=''
        self.Name=''
        self.Mrn=''
        self.VisitNum=''
        self.VisitDate=''
        self.NewVisitType=''
        self.Dob=''
        self.CurSex=''
        self.BirthSex=''
        self.Address=''
        self.PrimPhone=''
        self.CreatedDate=''
        self.Pronouns=''   # NOT USED
        self.ZipCode=''    # NOT USED
        self.Race=''       # NOT USED
        self.Ethnicity=''  # NOT USED

    
    def create_visit_obj(self,tcidBase): 
        tcidBase = tcidBase.strip()
        
        q = f"""    SELECT 
           V.TCID, V.SearchID
          ,V3.NewVisitType
          ,'' AS DOB, '' AS CurSex, '' AS BirSex, '' AS Address, '' AS PrimPhone, '' AS CreatedDate, '' AS Pronouns, '' AS ZipCode, '' AS Race, '' AS Ethnicity
    FROM  td.Visit_001VisitList AS V
    JOIN  td.Visit_003NewVisitCreation V3 ON V3.TCID = V.TCID
    WHERE V.ActiveTestCase = 'A' 
          AND V.TCID LIKE '{tcidBase}%' """
        
        queryResult = query(q)
        newVisitList = self.build_new_visit_list(queryResult,tcidBase)
        randomVisit = self.get_random_visit(newVisitList,tcidBase)
        return randomVisit

    [not_keyword]
    def get_random_visit(self,newVisitList:list,tcidBase):
        logger.console(f"\n   --------------------------------------------------------------------------------")
        logger.console(f"    Random Visit Variation ...[py]")
        logger.console(f"   --------------------------------------------------------------------------------")
        
        if not newVisitList:
            logger.console(f"    ---WARNING--- NO Visits FOUND FOR TCID '{tcidBase}'")
            logger.console(f"    (PLEASE RUN JENKINS JOB 'Athena-Data-Creation-<MODULE>')\n")
            return

        randVisit:new_visit = random.choice(newVisitList)
        tcid_variation_len= randVisit.Tcid.rfind("_") # EHR-Interfaces_001_001
        tcid_variation = randVisit.Tcid[0:tcid_variation_len] 
        tcid_variation_count = randVisit.Tcid[tcid_variation_len+1:]# EHR-Interfaces_001
        
        q = f"""    SELECT 
           V.TCID, V.SearchID
          ,V3.NewVisitType
          ,F.TCID, F.DOB, F.CurSex, F.BirSex, F.Address,F.CreatedDate,F.Pronouns, F.ZipCode, F.Race, F.Ethnicity, F.PrimPhone
    FROM  td.Visit_001VisitList AS V
    JOIN  td.Visit_003NewVisitCreation V3 ON V3.TCID = V.TCID
    JOIN  (SELECT TCID + '_{tcid_variation_count}' AS TCID, DOB, CurSex, BirSex, Address,CreatedDate, Pronouns, ZipCode, Race, Ethnicity, PrimPhone
           FROM td.FullReg_01Registration
           WHERE TCID = '{tcid_variation}') AS F ON F.TCID = V.TCID
    WHERE  V.ActiveTestCase = 'A'
           AND V.TCID = '{randVisit.Tcid}' """

        newVisit:list  = queryOne(q)
        randVisit= self.parse_visit_to_newVisitObj(newVisit)

        return randVisit


    [not_keyword]
    def build_new_visit_list(self,queryResult:list,tcidBase)->list:
        logger.console(f"\n   --------------------------------------------------------------------------------")
        logger.console(f"   Print All Visit Variations ...[py]")
        logger.console(f"   --------------------------------------------------------------------------------")

        if not queryResult:
            logger.console(f"    ---WARNING--- NO Visits FOUND FOR TCID '{tcidBase}'")
            logger.console(f"    (PLEASE RUN JENKINS JOB 'Athena-Data-Creation-<MODULE>')\n")
            return

        newVisitList : list[new_visit] = []

        for visit in queryResult:  # <mrn:1044953>;<name:Murphy,TEST-INTERFACES>;<visitdt:11/26/2025>;<visitnum:10002016318>
            visitObj= self.parse_visit_to_newVisitObj(visit)
            if visitObj is None: # RETURN NONE IF VISIT NOT CREATED
                return None #FAIL
            newVisitList.append(visitObj)
        return newVisitList
    
    [not_keyword]
    def parse_visit_to_newVisitObj(self,result: list):
        result.CurSex = self.changeSexToOneChar(result.CurSex)
        result.BirSex = self.changeSexToOneChar(result.BirSex)
        result.DOB = self.Assign_DOB_When_Exists(result.DOB)
        searchIdString =  result.SearchID
        visitStr = searchIdString.replace("('","")
        visitStr = str(visitStr).replace("',)","") 
        visitStr = str(visitStr).replace("<","")
        visitStr = str(visitStr).replace(">","")
        visitList = visitStr.split(";")
        visit = new_visit()
        visit.Tcid = result.TCID
        
        if len(visitList) < 4:
            logger.console(f"   *****************************************************")
            logger.console(f"   WARNING: Visit not created!! - Missing MRN or Name")
            logger.console(f"   *****************************************************")
            return None
         
        if "mrn:" in str(visitList[0]):
            mrn = str(visitList[0].replace("mrn:","").replace(">",""))
            visit.Mrn= mrn

        if "name:" in str(visitList[1]):
            name = str(visitList[1].replace("name:","").replace(">",""))
            visit.Name= name.upper()

        if "visitdt:" in str(visitList[2]):
            dateCreated = str(visitList[2].replace("visitdt:","").replace(">",""))
            visit.VisitDate = dateCreated

        if "visitnum:" in str(visitList[3]):
            visitNum = str(visitList[3].replace("visitnum:","").replace(">",""))
            visit.VisitNum= visitNum

        visit.NewVisitType = result.NewVisitType
        visit.Dob= result.DOB
        visit.CurSex= result.CurSex
        visit.Address= result.Address
        visit.PrimPhone= result.PrimPhone
        visit.BirthSex= result.BirSex
        visit.CurSex= result.CurSex
        visit.Race= result.Race
        visit.Ethnicity= result.Ethnicity
        visit.CreatedDate= result.CreatedDate

        logger.console(f"   Visit_00NewVisit          ('{visit.Name}', '{visit.Mrn}',{visit.VisitNum}, '{visit.VisitDate}')")
        logger.console(f"   Visit_003NewVisitCreation ('{visit.NewVisitType}')")

        if  len((visit.Address).strip()) > 0:
            logger.console(f"   FullReg_01Reg             ('{visit.Dob}','{visit.CurSex}','{visit.BirthSex}','{visit.Address}','{visit.Race}','{visit.Ethnicity}','{visit.CreatedDate}')\n")
        
        logger.console(f"")

        return visit

if __name__ == '__main__':
    newVisit = new_visit()
    newVisit.create_visit_obj('EHR-Tabs_001')