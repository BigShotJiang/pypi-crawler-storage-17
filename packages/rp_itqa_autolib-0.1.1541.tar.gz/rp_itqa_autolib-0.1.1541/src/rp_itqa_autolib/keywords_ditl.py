"""
----------------------------------------------------------------------------------
 Author:  Frank Runfola
 Created: 1/20/2024
----------------------------------------------------------------------------------
"""
   
import sys
import time
import datetime
from random import randrange
import random
import re
from time import gmtime, strftime
import pyautogui
import pywinauto
import RPA.Windows as rpawin
import typing
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
import pywinauto.base_wrapper
import pywinauto.controls
import pywinauto.element_info
import pywinauto.uia_element_info
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows
from pywinauto import timings
from pywinauto import findbestmatch
from pywinauto.application import Application


DELIMITER_LEN = 30
AlteraWindow = "Altera Gateway"
_static_win = None


dict = {
    "TonyStark":  ["Genius", "Billionarie",  "Playboy"],  
    "SteveRogers": ["Super Soldier", "Captain America", "Avenger"],
    "BruceBanner": ["Genius", "Hulk", "Avenger"],
    "NatashaRomanoff": ["Black Widow", "Avenger"],
    "ClintBarton": ["Hawkeye", "Avenger"]
}



def Get_Altera_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if "Altera Gateway" in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id, handle=proc.handle)
            break
    return app,proc

def Verify_Checked_In_Patient_On_Tracking_Board_Py(mrn):
    notVerified = True
    app, proc = Get_Altera_App()
    logger.console(f"   Verify_Checked_In_Patient_On_Tracking_Board_Py()  (mrn={mrn})...[Py]\n")
    
    try:
        app = app.window(handle=proc.handle)
        dlg = app.child_window(auto_id="ScmApplicationHost", found_index=0) #dlg.print_control_identifiers()
        dlg = dlg.child_window(auto_id="ClrTabHost", found_index=0)
        dlg = dlg.child_window(class_name="WindowsFormsHost", control_type="Pane", found_index=0)
        dlg = dlg.child_window(auto_id="1182534", control_type="Pane")
        dlg = dlg.child_window(auto_id="ctlStatusBoardClient", class_name_re="WindowsForms.*")
        dlg = dlg.child_window(auto_id="pnlGrids", control_type="Pane")
        patGrid = dlg.child_window(auto_id="grdPatListGrid", control_type="Pane")
        childWrapper = patGrid.wrapper_object()
        child1 = childWrapper.children()
        #child2 = child1[0].children()
        #texts = child3[0].children_texts()
        props = patGrid.legacy_properties()
        logger.console(f"      props={props}\n")

        #patGrid.print_control_identifiers(filename="pats.txt")
        # groups = patGrid.children(control_type="Custom")
        ##logger.console(f"      rows={len(groups)}\n")
        
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Verify_Visit_Problem_Type_Is_Not_Showing_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        notVerified = False
        raise Exception(f"{e}")
        
    finally: 
        logger.console(f"")

    return notVerified

'''-------------------------------------------------------------------------------
Verify Items:
- Check name
- Apt start time matches what was selected in Athena
- Check in time matches what time you did step 2
- Appointment Type matches what was selected in Athena
- Status is set to Checked In
- Attending matches what was selected in Athena.
 ---------------------------------------------------------------------------------'''
   
   
if __name__ == '__main__':
    logger.console(f"\nBEGIN MAIN....\n")
    Verify_Checked_In_Patient_On_Tracking_Board_Py("123456")