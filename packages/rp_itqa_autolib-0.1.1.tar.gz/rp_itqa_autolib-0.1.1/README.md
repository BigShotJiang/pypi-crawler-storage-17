## Install Deps
```bash
# Install dependencies (or pip install setuptools wheel twine)
pip install -r requirements.txt

# Upgrade/Install pip
pip install --upgrade pip --force-reinstall

# Install wheel
pip install -U pip build twine --force-reinstall

# Generates src dist and real dist (binaries all necessary files to run package)
rm -rf dist build *.egg-info
python -m build

# installs a wheel package file from your local dist/ folder
# dist/ is the standard output folder where your build step drops artifacts.
pip install dist/*.whl --force-reinstall

# Test the the import
python -c "import rp_itqa_autolib; import rp_itqa_autolib.main; 
print('ok')"

#  Verify it shows up
pip list 
```


## Publish to PyPi
 - PyPI API Token Setup (for Twine Uploads)
 - This project is published to **PyPI** using an **API token** (not a password).


```bash
# Publish dist/ folder (wheels, .whl, and .tar.gz) 
# and uploads them to a Python package index for others to use
twine upload --repository rp-itqa-autolib dist/*

# if no project exists
unset TWINE_USERNAME TWINE_PASSWORD TWINE_REPOSITORY_URL
twine upload dist/*
```




## Create an API Token on PyPI.org

1. Sign in to **pypi.org**
2. Go to **Account settings → API tokens**
3. Click **Add API token**
4. Choose the scope you want:
   - **Entire account** (user-scoped), or
   - **Specific project** (project-scoped) *(recommended once the project exists)*

> Keep the token private. Treat it like a password.

---

## How to Use the Token

When using **Twine**:

- **Username:** `__token__`  
- **Password:** your token value **including** the `pypi-` prefix

Example:
- Username: `__token__`
- Password: `pypi-XXXXXXXXXXXXXXXXXXXXXXXXXXXX`

---

## Optional: Configure `~/.pypirc` (Multiple Projects)

- If you upload multiple projects, you can configure a `.pypirc` file so Twine knows which token to use.

📍 Location:
- **Windows:** `C:\Users\<YOU>\.pypirc`

```yml
[distutils]
index-servers =
  pypi
  rp-itqa-autolib

[pypi]
repository = https://upload.pypi.org/legacy/
username = __token__
password = pypi-REPLACE_WITH_YOUR_DEFAULT_TOKEN

[rp-itqa-autolib]
repository = https://upload.pypi.org/legacy/
username = __token__
password = pypi-<REPLACE_WITH_YOUR_PROJECT_TOKEN>
 # project token
```
