"""
----------------------------------------------------------------------------------
 Author:  Frank Runfola
 Created: 15/23/25
----------------------------------------------------------------------------------
"""
import sys
import time


import random
import re
import pywinauto.keyboard
import pywinauto.mouse
import pyautogui
import pywinauto
import RPA.Windows as rpawin
import typing
import datetime
import calendar

from random import randrange
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
from time import gmtime, strftime
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows
from pywinauto import timings
from pywinauto import findbestmatch
from pywinauto.application import Application
from datetime import datetime

DELIMITER_LEN = 30
AllscriptsWindow = "Altera Gateway"
_static_win = None
suspectedCancerManagedService = True

dict = {
    "TonyStark":  ["Genius", "Billionarie",  "Playboy"],  
    "SteveRogers": ["Super Soldier", "Captain America", "Avenger"],
    "BruceBanner": ["Genius", "Hulk", "Avenger"],
    "NatashaRomanoff": ["Black Widow", "Avenger"],
    "ClintBarton": ["Hawkeye", "Avenger"]
}




def Get_Allscripts_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if AllscriptsWindow in proc.name: 
            app = app.connect(process=proc.process_id).window(handle=proc.handle)
            app.click_input()
            break
    return app,proc

def Get_Structured_Notes_Entry():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if "Structured Notes Entry" in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id, handle=proc.handle)
            break
    return app,proc


def Find_Window(name):
    foundWindow = False
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if name in proc.name: 
            app = app.connect(process=proc.process_id)
            app = app.window(handle=proc.handle)
            foundWindow = True
            break
    return foundWindow, app,proc

def Verify_Valid_Print_Prompt_Py(name):
    try:
        logger.console(f"   Verify_Valid_Print_Prompt_Py() ... [Py]")
        foundWindow, app,proc = Find_Window(name)
        if not foundWindow:
            raise ElementNotFound("Printing Window not found!!!")
        else:
            logger.console(f"      FOUND Printing Window - (PASS)")
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Verify_Valid_Print_Prompt_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise ElementNotFound("Printing Window not found!!!")


def Get_Altera_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if AllscriptsWindow in proc.name: 
            app = app.connect(process=proc.process_id).window(handle=proc.handle)
            app.click_input()
            break
    return app,proc


######################################################################
# *IMPORTANT*: SECTIONS PANE ON SIDE MUST BE EXPANDED TO FIND TABS
######################################################################
def Click_Section_Item_Py(name): # 
    
    logger.console(f"   Click_Section_Item_Py()  (name={name})...[Py]")
    
    try:
        app, proc = Get_Structured_Notes_Entry()
        app = app.window(handle=proc.handle)
        dlg = app.child_window(auto_id="StructuredNotesMain")
        dlg = dlg.child_window(auto_id="pnlStructuredNoteMain")
        dlg = dlg.child_window(auto_id="pnlStructuredNoteContent", control_type="Pane")
        dlg = dlg.child_window(auto_id="ultraTabControl1", control_type="Tab")
        dlg = dlg.child_window(auto_id="ultraTabPageControl1", control_type="Pane")
        dlg = dlg.child_window(auto_id="SNCreate", control_type="Pane")
        
        childPanes = dlg.children(control_type="Pane")
        sectionPane = None
        
        ##########################################
        ### SEARCH FOR SECTIONS PANE
        ##########################################
        for pane in childPanes:
            auto_id = pane.element_info.automation_id
            logger.console(f"      (auto_id='{auto_id}')", newline=False)
            isSectionsPane = re.search("^[0-9].*[0-9].*$", auto_id) # look for Auto_id = <INTEGERS>
            
            if isSectionsPane != None:
                logger.console(f"\n      Found Sections Pane (auto_id={auto_id} ...[py]")
                dlg = dlg.child_window(auto_id=f"{auto_id}", control_type="Pane")
                sectionPane = dlg
                break
            
        ##########################################
        ### FAIL HERE IF SECTION PANE NOT FOUND
        ##########################################
        if sectionPane is None: 
            raise Exception(f"Sections Pane not found in 'Click_Section_Item_Py' [Py]")

        dlg = sectionPane.child_window(control_type="Pane")# Sections Pane
        #dlg.print_control_identifiers(depth=3)       
        dlg = sectionPane.child_window(auto_id="pnlTreeContainer", control_type="Pane")
        dlg = dlg.child_window(auto_id="pnlTreeView", control_type="Pane")
        dlg = dlg.child_window(auto_id="treSection", control_type="Tree")
        dlg = dlg.child_window(title=f"{name}", control_type="TreeItem")
        logger.console(f"      click '{name}' ...[py]\n")
        dlg.click_input()

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Click_Section_Item_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")
    
def Click_Performance_Status_Not_Required_This_Visit_Py(radioButton):
    logger.console(f"   Click_Performance_Status_Not_Required_This_Visit_Py() ...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Provider Note")
        # SKIPPING SEVERAL LAYERS HERE
        logger.console(f"      click '{radioButton}' ...[py]\n")
        dlg = dlg.child_window(title=f"{radioButton}", control_type="Text")
        dlg.click_input()

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Click_Performance_Status_Not_Required_This_Visit_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")
    
def Type_Visit_Reason_Text_Py(reason):
    logger.console(f"   Type_Visit_Reason_Text_Py() (reason={reason})...[Py]")
    try:
        logger.console(f"      TAB ...[py]")
        pyautogui.press("TAB")
        logger.console(f"      press keys 'CTRL+A' (prepare overwrite) ...[py]")
        pywinauto.keyboard.send_keys(keys='^a^c') # Modifier for CTRL+A 
        logger.console(f"      Type '{reason}' ...[py]\n")
        pywinauto.keyboard.send_keys(reason)

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Type_Visit_Reason_Text_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")
    
def Type_History_of_Present_Illness_Text_Py(text):
    logger.console(f"   Type_History_of_Present_Illness_Text_Py() (text={text})...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Provider Note")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart", control_type="Custom", found_index=3) #dlg.print_control_identifiers()
        dlg = dlg.child_window(class_name="ScrollViewer", control_type="Pane", found_index=4)  #found_index=2 
        logger.console(f"      click 'text box' ...[py]")
        dlg.click_input()
        logger.console(f"      press keys 'CTRL+A' (prepare overwrite) ...[py]")
        pywinauto.keyboard.send_keys(keys='^a^c') # Modifier for CTRL+A 
        logger.console(f"      type '{text}' ...[py]\n")
        pywinauto.keyboard.send_keys(text)

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Type_History_of_Present_Illness_Text_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")
    
def Assessment_And_Plan_Type_Text_Py(text):
    logger.console(f"   Assessment_And_Plan_Type_Text_Py() ...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Assessment & Plan")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=0)
        dlg = dlg.child_window(class_name="ScrollViewer", control_type="Pane", found_index=1)  #found_index=2 
        dlg = dlg. child_window(class_name="FormattedFreeTextTX", control_type="Custom")
        dlg = dlg. child_window(class_name_re=".*TextControl", control_type="Document")
        logger.console(f"      click 'Assessment & Plan' text area ...[py]")
        dlg.click_input()
        logger.console(f"      press keys 'CTRL+A' (prepare overwrite) ...[py]")
        pywinauto.keyboard.send_keys(keys='^a^c') # Modifier for CTRL+A 
        logger.console(f"      type '{text}' ...[py]\n")
        pywinauto.keyboard.send_keys(text)

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Assessment_And_Plan_Type_Text_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")
    
def Known_Or_Suspected_Cancer_Managed_By_Your_Service_Py():
    logger.console(f"   Known_Or_Suspected_Cancer_Managed_By_Your_Service_Py() ...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Assessment & Plan")
        ####################################
        ## Select Tab to unselect text area
        ####################################
        logger.console(f"      click 'Assessment & Plan' tab ...[py]")
        dlg.click_input()
        ####################################
        ## Page Down to bottom part of pane
        ####################################
        logger.console(f"      press 'pagedown' 3...[py]")
        pyautogui.press(keys="PAGEDOWN",presses=3)
        
        dlg = Get_Breast_Medicine_Tab_Dlg("Assessment & Plan")
        
        ########################################################################
        ## SKIP IF SUSPECTED CANCER PANE DOESN'T EXIST
        ########################################################################
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=2) #found_index=2 worked at first
        dlg = dlg.child_window(class_name="ScrollViewer", control_type="Pane",found_index=0 )
        menuItem = dlg.child_window(auto_id="TextBlock", control_type="Text",found_index=0)
        
        if "suspected cancer" in str(menuItem.element_info.name):
            logger.console(f"      ..FOUND ..\"suspected cancer managed by your service\" pane ..[py]")
            dlg = dlg.child_window(auto_id="ListScrollViewer", control_type="Pane")
            radioBtn = dlg. child_window(class_name="RadioButton", control_type="RadioButton", found_index=2)
            logger.console(f"      click 'unknown/work-up in progress' ...[py]\n")
            radioBtn.click_input()
        else:
            suspectedCancerManagedService = False
            logger.console(f"      ..\"suspected cancer managed by your service\" menu pane DOES NOT EXIST. (SKIPPING) ...[py]\n")

    except Exception as e:  # CAN'T FIND  uspected cancer managed by your service - this probably is not an error
        suspectedCancerManagedService = False
        logger.console(f"      (Error={e} [Py]\n")
        logger.console(f"      ..\"suspected cancer managed by your service\" menu pane DOES NOT EXIST. (SKIPPING) ...[py]\n")


def Click_Patient_Readiness_Py(radioButton):
    logger.console(f"   Click_Patient_Readiness_Py()  (name={radioButton})...[Pyn")

    try:
        dlg = GetPnlValuePanel(0)
        dlg = dlg.child_window(title="Patient Readiness:", control_type="Pane")
        dlg = dlg.child_window(title=f"{radioButton}", control_type="RadioButton")
        logger.console(f"      click '{radioButton}' ...[py]\n")
        dlg.click_input()

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Click_Patient_Readiness_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")

def Select_AppTrainee_Statement_Discussed_With_Py():
    logger.console(f"   Select_AppTrainee_Statement_Py() ...[Py]")
    
    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Attestation")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=3)
        dlg = dlg.child_window(class_name="ScrollViewer", control_type="Pane", found_index=2) #AppTrainee_Statemen=3rd elem
        dlg = dlg.child_window(auto_id="ListScrollViewer", control_type="Pane")
        dlg = dlg. child_window(class_name="RadioButton", control_type="RadioButton", found_index=1)
        logger.console(f"      click 'Discussed With' ...[py]\n")
        dlg.click_input()

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Select_AppTrainee_Statement_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"{e}")
    
##########################################################################################
##NO LONGER USED -  6/4/25 - Frank Runfola
# Replaced with "Mouse Over Document Info Tab And Select Co-signer Checkbox"
##########################################################################################
def Hover_Over_Doc_Info_And_Click_First_CoSigner_Checkbox_Py(x,y):
    logger.console(f"   Click_First_CoSigner_Checkbox_Py() (x={x}, y={y}) ...[Py]")
    app, proc = Get_Structured_Notes_Entry()
        
    x = int(x)
    y = int(y)
    
    try:
        logger.console(f"      Move_Mouse_To_Coords (coords=({x}, {y})) ...[Py]")
        pywinauto.mouse.move(coords=(x,y)) 
        
        app = app.window(handle=proc.handle)
        app.set_focus()
        dlg = app.child_window(auto_id="StructuredNotesMain")
        dlg = dlg.child_window(auto_id="pnlStructuredNoteMain")
        dlg = dlg.child_window(auto_id="pnlStructuredNoteContent")
        dlg = dlg.child_window(auto_id="ultraTabControl1")
        dlg = dlg.child_window(auto_id="ultraTabPageControl1")
        dlg = dlg.child_window(auto_id="SNCreate") #dlg.print_control_identifiers(depth=3)
        dlg = dlg.child_window(auto_id="_SNCreateAutoHideControl")        
        dlg = dlg.child_window(class_name_re="WindowsForms.*", control_type="Pane", found_index=0)
        dlg = dlg.child_window(auto_id="SNControlPanel")
        dlg = dlg.child_window(auto_id="pnlSNControlPanel")
        dlg = dlg.child_window(auto_id="GrpBxCoSignature")
        dlg = dlg.child_window(auto_id="chkCoSignature1")
        logger.console(f"      click first CoSigner checkbox (id:chkCoSignature1) ...[Py]\n")
        dlg.click_input()
        
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Click_First_CoSigner_Checkbox_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Enter_App_Time_Spent_Py(time_spent):
    logger.console(f"   Enter_App_Time_Spent_Py  (time_spent={time_spent}) ...[Py]")
    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Attestation")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=1)
        dlg = dlg.child_window(class_name="ScrollViewer",control_type="Pane", found_index=0)
        dlg = dlg.child_window(auto_id="PART_Numeric",control_type="Edit")

        logger.console(f"      click 'Time Spent' text box ...[Py]")
        dlg.click_input()
        logger.console(f"      type '{time_spent}' ...[Py]\n")
        pywinauto.keyboard.send_keys(time_spent)

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Click_First_CoSigner_Checkbox_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")
    
def Enter_Attending_Time_Spent_Py(time_spent):
    logger.console(f"   Enter_Attending_Time_Spent_Py  (time_spent={time_spent}) ...[Py]")
    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Attestation")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=1)
        dlg = dlg.child_window(class_name="ScrollViewer",control_type="Pane", found_index=0)
        dlg = dlg.child_window(auto_id="PART_InputTextBox",control_type="Edit")

        logger.console(f"      click 'Time Spent' text box ...[Py]")
        dlg.click_input()# THIS clicks 'APP TIME SPENT' - it's the first pane in section and identical to the others
        logger.console(f"      TAB TAB (Move to Attending Time Spent)...[py]")
        pyautogui.press("TAB",presses=2)
        logger.console(f"      type '{time_spent}' ...[Py]\n")
        pywinauto.keyboard.send_keys(time_spent)

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Enter_Attending_Time_Spent_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Enter_Attending_Time_Spent_Coords_Py_NOT_BEING_USED(time_spent,x,y):
    try:
        x = int(x)
        y= int(y)
        logger.console(f"       Click 'Attending Time Spent' (coords=({x},{y})) ...[Py]")
        pywinauto.mouse.click(coords=(x,y))
        logger.console(f"       Type '{time_spent}' ...[Py]")
        pyautogui.typewrite(time_spent)
        
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Enter_Attending_Time_Spent_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Click_Is_Note_Ready_For_Attending_Yes_Py():
    logger.console(f"   Click_Is_Note_Ready_For_Attending_Yes_Py() ...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Attestation")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=3)
        dlg = dlg.child_window(auto_id="ListScrollViewer", control_type="Pane", found_index=2)  #found_index=2 
        dlg = dlg. child_window(title="Yes", control_type="Text")        #dlg.print_control_identifiers()
        logger.console(f"      click 'Yes' (Is note ready for Attending?) ...[py]\n")
        dlg.click_input()

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Click_Is_Note_Ready_For_Attending_Yes_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Click_Is_Note_Ready_For_Attending_Yes_Py():
    logger.console(f"   Click_Is_Note_Ready_For_Attending_Yes_Py() ...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Attestation")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=3)
        dlg = dlg.child_window(auto_id="ListScrollViewer", control_type="Pane", found_index=2)  #found_index=2 
        dlg = dlg. child_window(title="Yes", control_type="Text")        #dlg.print_control_identifiers()
        logger.console(f"      click 'Yes' (Is note ready for Attending?) ...[py]\n")
        dlg.click_input()

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Click_Is_Note_Ready_For_Attending_Yes_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Verify_Red_Check_Mark_Displays_For_Clinic_Notes_Py(): # ***NOT CURRENTLY USED***
    logger.console(f"   Verify_Red_Check_Mark_Displays_For_Clinic_Notes_Py() ...[Py]")
    app, proc = Get_Allscripts_App()

    try:
        app = app.window(handle=proc.handle)
        app.set_focus()
        dlg = app.child_window(auto_id="ScmApplicationHost", control_type="Custom")
        dlg = dlg.child_window(auto_id="ClrTabHost", control_type="Custom")
        dlg = dlg.child_window(class_name="WindowsFormsHost", control_type="Pane")
        dlg = dlg.child_window(class_name_re="WindowsForms.*", control_type="Pane")
        dlg = dlg.child_window(auto_id="DocReviewMain", control_type="Pane")
        dlg = dlg.child_window(class_name="windowDockingArea7", control_type="Pane")
        dlg = dlg.child_window(class_name="dockableWindow7", control_type="Pane")
        dlg = dlg.child_window(class_name="Summary", control_type="Pane")
        dlg = dlg.child_window(class_name="SummaryFormat", control_type="Pane")
        dlg = dlg.child_window(class_name="pnlGrid", control_type="Pane")
        dlg = dlg.child_window(class_name="pnlGrid2", control_type="Pane")
        dlg = dlg.child_window(title="Day View", control_type="Pane")
        dlg.print_control_identifiers()

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Verify_Red_Check_Mark_Displays_For_Clinic_Notes_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Verify_Document_Has_Date_Of_Today_Edit_Click_Modify_Py():
    logger.console(f"   Verify_Document_Has_Date_Of_Today_Edit_Click_Modify_Py() ...[Py]")
    
    #VERIFY DOCUMENT DATE IS TODAY
    currMonth = calendar.month_abbr[datetime.now().month] # get 3 char month to match EHR
    currDateCheck = datetime.now().strftime(f"%d-{currMonth}-%Y") #Outputs 29-May-20225
    logger.console(f"      currDateCheck = {currDateCheck}...")

    try:
        app, proc = Get_Allscripts_App()
        app = app.window(handle=proc.handle)
        app.set_focus()
        dlg = app.child_window(auto_id="ScmApplicationHost",control_type="Custom", found_index=0)
        dlgClrTab = dlg.child_window(auto_id="ClrTabHost", class_name="ClrTabHost",control_type="Custom")
        dlg = dlgClrTab.child_window(class_name="WindowsFormsHost", control_type="Pane", found_index=0)
        dlg = dlg.child_window(class_name_re="WindowsForms.*", control_type="Pane", found_index=0)
        dlg = dlg.child_window(auto_id="windowDockingArea11", control_type="Pane")
        dlg = dlg.child_window(auto_id="dockableWindow5", control_type="Pane")
        dlg = dlg.child_window(auto_id="Report", control_type="Pane")
        dlg = dlg.child_window(auto_id="ReportFormat", control_type="Pane")
        dlg = dlg.child_window(auto_id="reportUltraGrid", control_type="Table")#dlg.print_control_identifiers()
        dlg = dlg.child_window(title="DateTable", control_type="Table")
        dlg = dlg.child_window(title="DateTable row 1", control_type="Custom")
        dlg = dlg.child_window(title="DateDocuments", control_type="Table")
        row = dlg.child_window(title="DateDocuments row 1", control_type="Custom")
        dateDlg = row.child_window(title="Date", control_type="DataItem")  #,found_index=2
        dateFound = str(dateDlg.legacy_properties()['Value'])
        logger.console(f"      Document Date = {dateFound} - ", newline=False)

        if dateFound == currDateCheck:
            logger.console(f"(DATE MATCHES TODAY) - PASS ...[py]")
            logger.console(f"      Click on document ...[py]")
            row.click_input()
            #
            dlg = dlgClrTab.child_window(class_name="DocReview_Toolbar", control_type="Custom")
            dlg = dlgClrTab.child_window(auto_id="m_toolBar", control_type="Custom")
            dlg = dlgClrTab.child_window(class_name="EclpToolBar", control_type="ToolBar")
            dlg = dlgClrTab.child_window(auto_id="ActionList_ModifyDocument", control_type="Button")
            logger.console(f"      Click 'Modify' ...[py]\n")
            dlg.click_input()
        else:
            logger.console(f"(DATE DOES NOT MATCH TODAY!!) - FAIL!!! ...[py]")
            raise Exception(f"Document not found")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Verify_Document_Has_Date_Of_Today_Edit_Click_Modify_Py' [Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        raise Exception(f"Error={e}")

###############################################
###############################################
#            VERIFY
###############################################
###############################################
def Performance_Status_Not_Required_This_Visit_Verify_Py():
    logger.console(f"   Click_Performance_Status_Not_Required_This_Visit_Py() ...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Provider Note")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart", control_type="Custom", found_index=1)
        dlg = dlg.child_window(auto_id="ListScrollViewer", control_type="Pane", found_index=2)
        radioBtn = dlg.child_window(class_name="RadioButton", control_type="RadioButton", found_index=2)
        toggleState = radioBtn.is_selected() #pywinauto.controls.uia_controls.ButtonWrapper(radioBtn).is_selected()

        logger.console(f"      verify '3rd RadioButton (Not required this visit)' toggleState = 1 - ", newline=False)
        
        if toggleState == 1:
            logger.console(f"PASS (toggleState={toggleState}) ...[py]\n")
        else:
            logger.console(f"FAIL (toggleState={toggleState}) ...[py]\n")
            raise Exception(f"toggleState is {toggleState}, it should be 1")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Click_Performance_Status_Not_Required_This_Visit_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Visit_Reason_Text_Verify_Py(verify):
    logger.console(f"   Visit_Reason_Text_Verify_Py()  (verify={verify}) ...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Provider Note")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=3)
        dlg = dlg.child_window(title=f"{verify}", auto_id="txtFreeText", control_type="Edit")
        text = dlg.legacy_properties()['Value'] # GET THE TEXT!

        logger.console(f"      Visit Reason Text = '{text}' - ", newline=False)
        
        if text == verify:
            logger.console(f"PASS ('{text}' EQUALS '{verify}') ...[py]\n")
        else:
            logger.console(f"FAIL ('{text}' NOT EQUALS '{verify})' ...\n[py]")
            raise Exception(f"text is {text}, it should be {verify}")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Visit_Reason_Text_Verify_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def History_Of_Present_Illness_Text_Verify_Py(verify):
    logger.console(f"   History_Of_Present_Illness_Text_Verify_Py()  (verify={verify}) ...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Provider Note")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=3)
        dlg = dlg.child_window(title=f"{verify}", auto_id="txtFreeText", control_type="Edit")
        text = dlg.legacy_properties()['Value'] # GET THE TEXT!

        logger.console(f"      History Of Present Illness Text = '{text}' - ", newline=False)
        
        if text == verify:
            logger.console(f"PASS ('{text}' EQUALS '{verify}') ...[py]\n")
        else:
            logger.console(f"FAIL ('{text}' NOT EQUALS '{verify})' ...[py]\n")
            raise Exception(f"text is {text}, it should be {verify}")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'History_Of_Present_Illness_Text_Verify_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Assessment_And_Plan_Type_Text_Verify_Py(verify):
    logger.console(f"   Assessment_And_Plan_Type_Text_Verify_Py()  (verify={verify}) ...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Assessment & Plan")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom",found_index=0)
        dlg = dlg.child_window(class_name="ScrollViewer", control_type="Pane", found_index=1)  #found_index=2 
        dlg = dlg.child_window(class_name="FormattedFreeTextTX", control_type="Custom")
        dlg = dlg.child_window(control_type="Document")
        text = dlg.legacy_properties()['Value'].strip() # GET THE TEXT!

        logger.console(f"      Assessment And Plan Text = '{text}' - ", newline=False)
        
        if text == verify:
            logger.console(f"PASS ({text} EQUALS {verify}) ...[py]\n")
        else:
            logger.console(f"FAIL ('{text}' NOT EQUALS '{verify})' ...[py]\n")
            raise Exception(f"text is {text}, it should be {verify}")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Assessment_And_Plan_Type_Text_Verify_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Known_Or_Suspected_Cancer_Managed_By_Your_Service_Verify_Py():
    logger.console(f"   Known_Or_Suspected_Cancer_Managed_By_Your_Service_Verify_Py() ...[Py]")
    
    ########################################################################
    ## SKIP VERIFY IF SUSPECTED CANCER PANE DOESN'T EXIST
     ########################################################################
    if suspectedCancerManagedService is False:
        logger.console(f"      ..\"suspected cancer managed by service\" menu pane DOES NOT EXIST. (SKIPPING VERIFICATION) ...[py]\n")
        return

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Assessment & Plan")
        ####################################
        ## Select Tab to unselect text area
        ####################################
        logger.console(f"      click 'Assessment & Plan' tab ...[py]")
        dlg.click_input()
        ####################################
        ## Page Down to bottom part of pane
        ####################################
        logger.console(f"      press 'pagedown' 2...[py]")
        pyautogui.press(keys="PAGEDOWN",presses=2)
        
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=2)
        dlg = dlg.child_window(class_name="ScrollViewer", control_type="Pane", found_index=0 )
        radioBtn = dlg.child_window(class_name="RadioButton", control_type="RadioButton", found_index=2)
        toggleState = radioBtn.is_selected() 
        
        logger.console(f"      verify '3rd RadioButton (unknown/work-up in progress)' toggleState = 1 - ", newline=False)
        
        if toggleState == 1:
            logger.console(f"      PASS (toggleState={toggleState}) ...[py]\n")
        else:
            logger.console(f"      FAIL (toggleState={toggleState}) ...[py]\n")
            raise Exception(f"toggleState is {toggleState}, it should be 1")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Known_Or_Suspected_Cancer_Managed_By_Your_Service_Verify_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Enter_App_Time_Spent_Verify_Py(verify):
    logger.console(f"   Enter_App_Time_Spent_Verify_Py()  (verify={verify}) ...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Attestation")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=1)
        dlg = dlg.child_window(class_name="ScrollViewer", control_type="Pane", found_index=0)  #found_index=2 
        dlg = dlg.child_window(auto_id="PART_Numeric", control_type="Edit")
        text = dlg.legacy_properties()['Value'] # GET THE TEXT!

        logger.console(f"      Time Spent = '{text}' - ", newline=False)
        
        if text == verify:
            logger.console(f"PASS ({text} EQUALS {verify}) ...[py]\n")
        else:
            logger.console(f"FAIL ('{text}' NOT EQUALS '{verify})' ...[py]\n")
            raise Exception(f"text is {text}, it should be {verify}")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Enter_App_Time_Spent_Verify_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Select_AppTrainee_Statement_Discussed_With_Verify_Py():
    logger.console(f"   Select_AppTrainee_Statement_Discussed_With_Verify_Py() ...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Attestation")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=3)
        dlg = dlg.child_window(class_name="ScrollViewer", control_type="Pane", found_index=2)
        dlg = dlg.child_window(auto_id="ListScrollViewer", control_type="Pane")
        dlg = dlg. child_window(class_name="RadioButton", control_type="RadioButton", found_index=1)
        toggleState = dlg.is_selected() #pywinauto.controls.uia_controls.ButtonWrapper(radioBtn).is_selected()

        logger.console(f"      verify '3rd RadioButton (discussed with)' toggleState = 1 - ", newline=False)
        
        if toggleState == 1:
            logger.console(f"PASS (toggleState={toggleState}) ...[py]\n")
        else:
            logger.console(f"FAIL (toggleState={toggleState}) ...[py]\n")
            raise Exception(f"toggleState is {toggleState}, it should be 1")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Select_AppTrainee_Statement_Discussed_With_Verify_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")


##########################################################################################################################
#  THis function isn't needed anymore - the "Note Ready for Attending, does't save"
##########################################################################################################################
def Click_Is_Note_Ready_For_Attending_Yes_Verify_Py():
    logger.console(f"   Click_Is_Note_Ready_For_Attending_Yes_Verify_Py() ...[Py]")

    try:
        dlg = Get_Breast_Medicine_Tab_Dlg("Attestation")
        dlg = dlg.child_window(class_name="AbsoluteLayoutPart",control_type="Custom", found_index=3)
        dlg = dlg.child_window(auto_id="ListScrollViewer", control_type="Pane", found_index=2)  #found_index=2 
        dlg.print_control_identifiers()
        dlg = dlg. child_window(class_name="RadioButton", control_type="RadioButton", found_index=0)
        toggleState = dlg.is_selected() #pywinauto.controls.uia_controls.ButtonWrapper(radioBtn).is_selected()

        logger.console(f"      verify '3rd RadioButton (Yes)' toggleState = 1 - ", newline=False)
        
        if toggleState == 1:
            logger.console(f"PASS (toggleState={toggleState}) ...[py]\n")
        else:
            logger.console(f"FAIL (toggleState={toggleState}) ...[py]\n")
            raise Exception(f"toggleState is {toggleState}, it should be 1")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Click_Is_Note_Ready_For_Attending_Yes_Verify_Py' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

#------------------------------------------------
#            HELPERS
#------------------------------------------------
def GetPnlValuePanel(stmtIndex):
    try:
        pnlContent = GetPnlContent() # Returns auto_id=pnlContent
        dlg = dlg.child_window(auto_id="Provider Attestations", control_type="Pane", found_index=0)
        dlg = dlg.child_window(auto_id="Provider Attestations", control_type="Pane")
        dlg = dlg.child_window(auto_id="StatementRow", control_type="Pane", found_index=stmtIndex)#dlg.print_control_identifiers()
        dlg = dlg.child_window(auto_id="pnlValuePanel", control_type="Pane")
        return dlg
    
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'GetPnlValuePanel' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def GetPnlContent():
    try:
        app, proc = Get_Structured_Notes_Entry()
        app = app.window(handle=proc.handle)
        app.set_focus()
        dlg = app.child_window(auto_id="StructuredNotesMain", control_type="Pane")
        dlg = dlg.child_window(auto_id="pnlStructuredNoteMain", control_type="Pane")
        dlg = dlg.child_window(auto_id="pnlStructuredNoteContent", control_type="Pane")
        dlg = dlg.child_window(auto_id="ultraTabControl1", control_type="Tab")
        dlg = dlg.child_window(auto_id="ultraTabPageControl1", control_type="Pane")
        dlg = dlg.child_window(auto_id="SNCreate", control_type="Pane")
        dlg = dlg.child_window(auto_id="Create_Fill_Panel", control_type="Pane")
        dlg = dlg.child_window(auto_id="ctrlStructuredNoteContent", control_type="Pane")
        dlg = dlg.child_window(auto_id="pnlContainer", control_type="Pane")
        dlg = dlg.child_window(auto_id="pnlContent", control_type="Pane")
        return dlg
    
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'GetPnlContent' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")

def Get_Breast_Medicine_Tab_Dlg(item):
    try:
        dlg = GetPnlContent() # Returns auto_id=pnlContent
        dlg = dlg.child_window(auto_id="Follow-up Note", control_type="Pane", found_index=0)
        dlg = dlg.child_window(auto_id="FormBuilder Form Host - OP Breast Medicine (BRM) Follow-up FB")
        dlg = dlg.child_window(class_name_re="WindowsForms.*", control_type="Pane", found_index=0)  #dlg.print_control_identifiers()
        dlg = dlg.child_window(class_name="Pane", control_type="Pane", found_index=0) 
        dlg = dlg.child_window(auto_id="FormBuilder_Form_id_287", control_type="Custom", found_index=0)  #dlg.print_control_identifiers()
        dlg = dlg.child_window(auto_id="TheTabControl", class_name="XamTabControl",control_type="Tab")
        dlg = dlg.child_window(title_re=f"SXA.FormBuilder.*{item}]",control_type="TabItem")
        return dlg
    
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Get_Breast_Medicine_Tab_Dlg' [Py]")
        logger.console(f"      (Error={e} [Py]\n")
        raise Exception(f"Error={e}")



#########################################
#            MAINS
#########################################
if __name__ == '__main__':
    logger.console(f"\nBEGIN MAIN....\n")
    #Click_Section_Item_Py("Provider Note") 
    #Click_Patient_Readiness_Py("Patient ready for Attending")
    #Hover_Over_Doc_Info_And_Click_First_CoSigner_Checkbox_Py(1947,100)
    #Enter_App_Time_Spent_Py("5")
    #Select_AppTrainee_Statement_Discussed_With_Py()
    #Click_Is_Note_Ready_For_Attending_Yes_Py()
    #Verify_Red_Check_Mark_Displays_For_Clinic_Notes_Py()
    #Verify_Document_Has_Date_Of_Today_Edit_Click_Modify_Py()
    #Verify_Document_Data_Py()
    #Click_Performance_Status_Not_Required_This_Visit_Py("Not required this visit")
    #Type_Visit_Reason_Text_Py("This is a test")
    #Type_History_of_Present_Illness_Text_Py("Blah")
    #Assessment_And_Plan_Type_Text_Py("blah")

    #############################
    #        VERIFY
    #############################
    #-----------------------------------
    # Provide note
    #-----------------------------------
    #Performance_Status_Not_Required_This_Visit_Verify_Py()
    #Visit_Reason_Text_Verify_Py("VisitReasonText")
    #History_Of_Present_Illness_Text_Verify_Py("IllnessHistoryText")
    #-----------------------------------
    # Assessment & Plan
    #-----------------------------------
    Assessment_And_Plan_Type_Text_Verify_Py('AssessmentAndPlanText')
    #Known_Or_Suspected_Cancer_Managed_By_Your_Service_Py()
    #-----------------------------------
    # Attestation
    #-----------------------------------
    #Enter_Time_Spent_Verify_Py("5")
    #Select_AppTrainee_Statement_Discussed_With_Verify_Py()
    #Click_Is_Note_Ready_For_Attending_Yes_Verify_Py()
    

    #Enter_Attending_Time_Spent_Py ("5")