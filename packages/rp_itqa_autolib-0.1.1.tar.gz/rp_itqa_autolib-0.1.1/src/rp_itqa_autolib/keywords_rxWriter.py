"""
----------------------------------------------------------------------------------
 Author:
 Created:
----------------------------------------------------------------------------------
"""

import sys
import time
from datetime import datetime, timedelta
from random import randrange
import random
import re
from time import gmtime, strftime
import pyautogui
import pywinauto
import RPA.Windows as rpawin
import typing
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
import pywinauto.base_wrapper
import pywinauto.controls
import pywinauto.element_info
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows
from pywinauto import timings
from pywinauto import findbestmatch
from pywinauto.application import Application


AllscriptsWindow = "Altera Gateway"
_static_win = None
statusCellClass = "k-touch-action-auto gridFontSmall row-align ng-star-inserted"
dateCellClass   = "k-touch-action-auto gridFontSmall row-align date-padding ng-star-inserted"

def Click_Add_Rx_Button_Py():
    try:
        logger.console(f"   Click_Add_Rx_Button() ... [Py]")
        rootWebArea = Get_RootWebArea() 
        dlg = rootWebArea.child_window(class_name="navbar-primary", control_type="Group")
        dlg = dlg.child_window(class_name="navbar-primary-menu", control_type="List")#dlg.print_control_identifiers()
        dlg = dlg.child_window(title_re=".*Add Rx.*", control_type="ListItem")
        #logger.console(f"      Click 'Add Rx' (auto_id=\"rxsb-add-rx-new-search\" ... [py]\n")
        #dlg = dlg.child_window( auto_id="rxsb-add-rx-new-search", control_type="Hyperlink")
        logger.console(f"      Click 'Add Rx' ... [py]\n")
        dlg.click_input()
        time.sleep(5)
        
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Click_Add_Rx_Button' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        raise Exception(f"{e}")
    
def Select_Rx_Py_NOT_WORKING():  # DOESNT WORK
    try:
        logger.console(f"   Select_Rx_Py() ...[Py]")
        rootWebArea = Get_RootWebArea()
        grpBox = rootWebArea.child_window(class_name="k-grid k-grid-md", control_type="Group", found_index=0)   #rootWebArea.GroupBox5
        listView = grpBox.child_window(title="Data table", control_type="DataGrid", found_index=0) #ListView0 #
        allGroups = listView.child_window(class_name="k-table-tbody",control_type="Group", found_index=0)  #GroupBox #c#All Groups
        dlg = allGroups.child_window(title="Data table Data table", class_name="k-master-row k-table-row", found_index=0)  #DataItem12 #
        dlg = allGroups.child_window(title="Data table Data table", class_name="k-table-td k-touch-action-auto", found_index=0)  #DataItem12 #
        logger.console(f"   CHECKPOINT1")
        dlg = dlg.child_window(class_name="k-grid k-grid-md", control_type="Group", found_index=0) 
        dlg = dlg.child_window(title="Data table", control_type="DataGrid", found_index=0)
        dlg = dlg.child_window(class_name="k-table k-table-md", control_type="Table", found_index=0)
        logger.console(f"   CHECKPOINT2")
        dlg = dlg.child_window(class_name="k-table-tbody", control_type="Group", found_index=0) 
        dlg = dlg.child_window(class_name="k-master-row k-table-row", control_type="DataItem", found_index=0)
        dlg.click_input()
        logger.console(f"      verifying medication is selected ...", newline=False)
        rootWebArea = rootWebArea.child_window(title_re=".*1 selected)", control_type="Text")
        logger.console(f"(CONFIRMED) [py]\n")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Select_Rx_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        raise Exception(f"Error={e}")    

def Type_Medication_To_Search_Py(search):
    try:
        logger.console(f"   Type_Medication_To_Search_Py()  (search='{search}') ...[Py]")
        rootWebArea = Get_RootWebArea()   #rootWebArea.print_control_identifiers()
        dlg = rootWebArea.child_window(control_type="Edit")
        dlg.click_input()
        logger.console(f"      typing '{search}' ... [py]\n")
        pyautogui.typewrite(f"{search}")
        
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Type_Medication_To_Search_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        raise Exception(f"Error={e}")

def Select_Rx_Py_DOESNT_WORK():  # DOESNT WORK
    try:
        logger.console(f"   Select_Rx_Py() ...[Py]")
        rootWebArea = Get_RootWebArea()
        grpBox = rootWebArea.child_window(class_name="k-grid k-grid-md", control_type="Group", found_index=0)   #rootWebArea.GroupBox5
        listView = grpBox.child_window(class_name="k-grid-aria-root", control_type="DataGrid", found_index=0) #ListView0 #
        allGroups = listView.hild_window(title="Data table", control_type="Group", found_index=0)  #GroupBox #c#All Groups
        dlg = allGroups.child_window(class_name="k-master-row k-table-row ng-star-inserted", control_type="DataItem", found_index=0)  #DataItem12 #
        dlg = dlg.child_window(class_name="k-table-td k-touch-action-auto ng-star-inserted", control_type="DataItem", found_index=0) 
        logger.console(f"   CHECKPOINT1")
        dlg = dlg.child_window(class_name="k-grid k-grid-md", control_type="Group", found_index=0) 
        dlg = dlg.child_window(class_name="k-grid-aria-root", control_type="DataGrid", found_index=0)
        dlg = dlg.child_window(class_name="k-table k-table-md ng-star-inserted", control_type="Table", found_index=0)
        logger.console(f"   CHECKPOINT2")
        dlg = dlg.child_window(class_name="k-table-tbody", control_type="Group", found_index=0) 
        dlg = dlg.child_window(class_name="k-master-row k-table-row ng-star-insertedy", control_type="DataItem", found_index=0)        
        dlg.click_input()
        logger.console(f"      verifying medication is selected ...", newline=False)
        rootWebArea = rootWebArea.child_window(title_re=".*1 selected)", control_type="Text")
        logger.console(f"(CONFIRMED) [py]\n")

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Select_Rx_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        raise Exception(f"Error={e}")

def Fill_Out_Rx_Criteria_And_Submit(rxRegex):
    try:
        logger.console(f"   Fill_Out_Rx_Criteria_And_Submit() (rxSelect='{rxRegex}') ...[Py]")
        rootWebArea = Get_RootWebArea() 
        GroupBox131 = rootWebArea.child_window(class_name='k-grid k-grid-md',control_type="Group", found_index=9)
        dataTable = GroupBox131.child_window(title="Data table", control_type="DataGrid",found_index=0)
        group = dataTable.child_window(title_re=f".*Neosporin 400 units-3.5 mg-5000.*", control_type="DataItem", found_index=0)
        dataItem = group.child_window(title_re=f".*Neosporin 400 units-3.5 mg-5000.*", control_type="DataItem", found_index=0)

        freq = dataItem.child_window(control_type="ComboBox", found_index=2).click_input()
        
        logger.console("      Typing '4 times a day' ... [py]")
        pywinauto.keyboard.send_keys(keys='^a^c')        
        pyautogui.typewrite("4 times a day")
        pyautogui.press("ENTER")
        
        time.sleep(1)
        
        logger.console("      Field Select [Reason for PRN] ...  ", newline=False) 
        reason = dataItem.child_window(control_type="ComboBox", found_index=3).click_input()
        logger.console("Typing 'for allergies' ... [py]")
        pywinauto.keyboard.send_keys(keys='^a^c')
        pyautogui.typewrite("for allergies")
        pyautogui.press(f"ENTER")
        
        time.sleep(1)

        logger.console(f"      Field Select [Refills] ...  ", newline=False) 
        dataItem.child_window(control_type="Spinner", found_index=2).click_input()

        logger.console("Typing '3' ... [py]")
        pywinauto.keyboard.send_keys(keys='^a^c')
        pyautogui.typewrite("3")
        pyautogui.press(f"ENTER")
        

        logger.console("      Field Select [Quantity] ... ", newline=False)
        dataItem.child_window(class_name="k-radio-label raioButtonLabel k-label",control_type="Group",found_index=1).click_input()
        time.sleep(1)
        pyautogui.press("TAB")
        logger.console("Typing '2' ... [py]")
        pywinauto.keyboard.send_keys(keys='^a^c')
        pyautogui.typewrite("2")
        time.sleep(1)
        
        logger.console("      Field Select [Package] ... [py]")
        pyautogui.press("TAB", presses=2)
        pyautogui.press(f"ENTER")
        pyautogui.press(f"ENTER")
        pyautogui.press("TAB", presses=9)
 
        time.sleep(1)
        
        logger.console(f"      Field Select [Internal Note] ...  ", newline=False) 
        #dataItem.child_window(class_name_re="full_width resizeOption k-textarea k-input.*", control_type="Edit").click_input()
        logger.console("Typing 'Internal Note' ... [py]")
        pyautogui.typewrite("Internal Note")
        
        time.sleep(1)

        logger.console(f"      Field Select [Submit Method] ...  ", newline=False) 
        dataItem.child_window(auto_id="rxFormSubmitMethod").click_input()
        logger.console("Typing 'Add to Med List Only' ... [py]")
        pyautogui.typewrite("Add to Med List Only")
        pyautogui.press(f"ENTER")
        
        time.sleep(2)

        logger.console(f"      Click 'Submit' ... [py]\n")
        rootWebArea.child_window(title='Submit',control_type="Button").click_input()


    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Fill_Out_Rx_Criteria_And_Submit' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        raise Exception(f"Error={e}")

def Discontinue_Medications_Py(discontinueReason):
    logger.console(f"   Discontinue_Medications() ...[Py]")
    time.sleep(3)
    currDateCheck = Get_Date_ddmmmyyyy_Dashes_Lead_0()
    logger.console(f"      (Discontinue Reason = '{discontinueReason}') ...[Py]")
    logger.console(f"      (Search Date Match = '{currDateCheck}') ...[Py]")
    logger.console(f"      (Search Status = 'Active') ...[Py]")
    
    rootWebArea = Get_RootWebArea()
    dataGrid = Get_Data_Grid()

    groupRows = dataGrid.child_window(class_name="k-table-tbody", control_type="Group")
    allRows = groupRows.children(control_type="DataItem")
    Print_Row_Headers(allRows)
    i = 0
    
    for row in allRows:
        i=i+1
        logger.console(f"      {str(i).ljust(6)}", newline=False)
        rowName = str(row.element_info.name)
        rowNameTrim = str(row.element_info.name)[0:50]
        logger.console(f"  {str(rowNameTrim).ljust(50)}", newline=False)
        
        rowValue = groupRows.child_window(title=f"{rowName}", control_type="DataItem")#rowValue.print_control_identifiers()   
                    
        statusCell = rowValue.child_window(title_re=f"Active|Inactive|Discontinued|No Longer Taking", control_type="DataItem")
        status = str(statusCell.element_info.name)
        logger.console(f"  {str(status).ljust(15)}", newline=False)
        
        dateCell = rowValue.child_window(title_re="[0-9].*-.*-202[0-9]", control_type="DataItem", found_index=0)
        date = str(dateCell.element_info.name)
        logger.console(f"  {str(date).ljust(18)}", newline=False)

        rowValue.click_input()
        
        if status=="Active" and date == currDateCheck:
            logger.console(f"  ('Active' and '{date}' FOUND)\n")
            dataItem = rowValue.child_window(control_type="DataItem", found_index=0)
            checkBoxColumn = rowValue.child_window(class_name_re="k-table-td k-touch-action-auto ng-star-inserted", found_index=0)
            logger.console(f"      click checkbox ...[Py]")
            checkBox = checkBoxColumn.child_window(class_name_re="checkboxstyle.*", control_type="CheckBox")
            checkBox.click_input()
            
            logger.console(f"      click 'Discontinue' ...[Py]")
            discontinueBtn = rootWebArea.child_window(title="Discontinue", control_type="Button")
            discontinueBtn.click_input()
            time.sleep(3)
            
            logger.console(f"      Type Reason '{discontinueReason}' ...[Py]")
            pyautogui.press("TAB", presses=3)
            time.sleep(1)
            pyautogui.press(f"ENTER")
            time.sleep(1)
            pyautogui.typewrite(f"{discontinueReason}")
            time.sleep(1)
            logger.console(f"      Select 'Discontinue_Medications(s)' ...[Py]\n")
            pyautogui.press("TAB", presses=4)
            #discontinueBtn = rootWebArea.child_window(title="Discontinue Medication(s)", control_type="Button") TABS is easier
            time.sleep(1)
            pyautogui.press(f"ENTER")

            return  # leave function, ACTIVE ROW FOUND AND DISCONTINUED
        else:
            logger.console(f"  ('Discontinued' and '{date}' NOT FOUND)")

    ##############################################################################
    ### IF YOU GET THIS FAR AND CANNOT FIND AN ACTIVE MEDICATION, THROW EXCEPTION
    ##############################################################################
    raise Exception(f"\nError=No Active Medications Found!! (Unable to discontinue) ...[Py]\n")


def Verify_Discontinued_Medications_Py():
    time.sleep(3)
    currDateCheck =Get_Date_ddmmmyyyy_Dashes_Lead_0()
    logger.console(f"   Verify_Discontinued_Medications() ...[Py]")
    logger.console(f"      (Search Date Match = '{currDateCheck}) ...[Py]")
    logger.console(f"      (Search Status = 'Discontinue' ) ...[Py]")

    dataGrid = Get_Data_Grid()
    ######################################################################################################
    # Unable to re-Activate these filters for next run. I will just check the status
    ######################################################################################################
    groupRows = dataGrid.child_window(class_name="k-table-tbody", control_type="Group")
    allRows = groupRows.children(control_type="DataItem")
    Print_Row_Headers(allRows)
    i = 0
    
    for row in allRows:
        i=i+1
        logger.console(f"      {str(i).ljust(6)}", newline=False)
        rowName = str(row.element_info.name)
        rowNameTrim = str(row.element_info.name)[0:50]
        logger.console(f"  {str(rowNameTrim).ljust(50)}", newline=False)
        
        rowValue = groupRows.child_window(title=f"{rowName}", control_type="DataItem")#rowValue.print_control_identifiers()     
            
        statusCell = rowValue.child_window(title_re=f"Active|Inactive|Discontinued|No Longer Taking", control_type="DataItem")
        status = str(statusCell.element_info.name)
        logger.console(f"  {str(status).ljust(15)}", newline=False)
        
        dateCell = rowValue.child_window(title_re="[0-9].*-.*-202[0-9]", control_type="DataItem", found_index=0)
        date = str(dateCell.element_info.name)

        logger.console(f"  {str(date).ljust(18)}", newline=False)

        rowValue.click_input()
        ###############################################################################
        #-changing the filter in the drop down to now include 'Inactive: <br>
        #-The Rx will now display on screen with a status of Discontinued with the current date.
        ###############################################################################
        if status=="Discontinued" and date == currDateCheck:
            logger.console(f"  ('Discontinued' and '{date}' FOUND) [Py]\n")
            return  # leave function, DISCONTINUED ROW FOUND
        else:
            logger.console(f"  ('Discontinued' and '{date}' NOT FOUND )")

    ##############################################################################
    ### IF YOU GET THIS FAR AND CANNOT FIND THE DISCONTINUED MEDICATION, THROW EXCEPTION
    ##############################################################################
    raise Exception(f"\nError=No 'Discontinued' Medications Found!! ...[Py]\n")

##############################################################################
#                             HELPERS
##############################################################################


def Sort_By_Status_Asc_Py():
    logger.console(f"    Sort_By_Status_Asc_Py() ...[Py]")  
    rootWebArea = Get_RootWebArea() 
    group1 = rootWebArea.child_window(class_name='k-grid k-grid-md',control_type="Group", found_index=0)
    dataGrid = group1.child_window(title="Data table", control_type="DataGrid")
    group = dataGrid.child_window(class_name="k-table-thead", control_type="Group")
    headerRow = group.child_window(title_re=".*Medication Details.*No Refills After Last Fill Date",control_type="DataItem")
    origDateHeader = headerRow.child_window(title_re="Status.*",control_type="DataItem")
    logger.console(f"       click Arrow (Next to Status) ...[Py]\n")
    origDateHeader.click_input() # sorts by asc  for getting Active first
    
def Sort_By_Date_Desc_Py():
    logger.console(f"   Sort_By_Date_Desc_Py() ...[Py]")  
    rootWebArea = Get_RootWebArea() 
    group1 = rootWebArea.child_window(class_name='k-grid k-grid-md',control_type="Group", found_index=0)
    dataGrid = group1.child_window(title="Data table", control_type="DataGrid")
    group = dataGrid.child_window(class_name="k-table-thead", control_type="Group")
    headerRow = group.child_window(title_re=".*Medication Details.*No Refills After Last Fill Date",control_type="DataItem")
    origDateHeader = headerRow.child_window(title_re="Original Date.*",control_type="DataItem")
    logger.console(f"       click Arrow (Next to Date) (2 times)...[Py]\n")
    origDateHeader.click_input() # sorts by asc  for getting Active first
    origDateHeader.click_input() # sorts by desc  for getting recent date


def Filter_Only_InActive_Status_Py():
    try:
        logger.console(f"    Filter_Only_InActive_Status_Py() ...[Py]")
        rootWebArea = Get_RootWebArea() 
        
        statusList = rootWebArea.child_window(class_name="k-input-inner", control_type="Group", found_index=0)
        statusList.click_input()
        time.sleep(0.5)
        pyautogui.press("backspace")
        logger.console(f"      Unselect 'Active' ...[Py]")
        pyautogui.press("backspace")
        time.sleep(0.5)
        logger.console(f"      Unselect 'Unsubmited' ...[Py]")
        pyautogui.press("Left", presses=2) #skip over Inactive
        time.sleep(0.5)
        pyautogui.press("backspace")
        logger.console(f"      Unselect 'No Longer Taking' ...[Py]\n")
 
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Filter_Only_InActive_Status_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        logger.console(f"")
        raise Exception(f"Error={e}")

def Add_Back_All_Filter_Statuses_Py(x0,y0,x1,y1,y2,y3): 
    try:
        X0 = int(x0)
        Y0 = int(y0)
        X1 = int(x1)
        Y1 = int(y1)
        Y2 = int(y2)
        Y3 = int(y3)

        logger.console(f"    Add_Back_All_Filter_Statuses_Py() ...[Py]")

        logger.console(f"       Click 'Status List Header' (coords=({X0},{Y0})) ...[Py]")
        pywinauto.mouse.click(coords=(X0,Y0))
        
        logger.console(f"       select 'Active' (coords=({X1},{Y1})) ...[Py]")
        pywinauto.mouse.click(coords=(X1,Y1))
                              
        logger.console(f"       select 'Unsubmitted' (coords=({X1},{Y2})) ...[Py]")
        pywinauto.mouse.click(coords=(X1,Y2))
                              
        logger.console(f"       select 'No Longer Taking' (coords=({X1},{Y3})) ...[Py]\n")
        pywinauto.mouse.click(coords=(X1,Y3))

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Add_Back_All_Filter_Statuses_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        logger.console(f"")
        raise Exception(f"Error={e}")

def Filter_Medications_Quick_Click():
    try:
        logger.console(f"    Filter_Active_Medications_Quick_Click() ...[Py]")    
        rootWebArea = Get_RootWebArea() 
        
        group = rootWebArea.child_window(class_name="k-multiselect-wrap k-floatwrap", control_type="Group")
        list = group.child_window(class_name="k-reset", control_type="List").click_input()
        
        pyautogui.press("backspace")
        logger.console(f"      Unselect 'Active' ...[Py]")
        pyautogui.press("backspace")
        logger.console(f"      Unselect 'Unsubmited' ...[Py]")
        pyautogui.press("Left", presses=2)
        pyautogui.press("backspace")
        logger.console(f"      Unselect 'No Longer Taking' ...[Py]\n")
 
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Filter_Medications' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        logger.console(f"")
        raise Exception(f"Error={e}")

def Filter_Active_Medications_NOT_WORKING():
    try:
        logger.console(f"      Filter_Medications() ...[Py]")    
        rootWebArea = Get_RootWebArea() 
        
        #Click Drop Down Arrow
        rootWebArea.child_window(class_name="k-icon k-i-arrow-s", control_type="Group",found_index=0).click_input()
        list1 = rootWebArea.child_window(control_type="List",found_index=2)

        inactive = list1.child_window(title_re=".*Inactive.*", control_type="ListItem")
        inActiveCB = inactive.child_window(title_re=".*Inactive.*", auto_id="chk-Inactive", control_type="CheckBox")
        props = inActiveCB.legacy_properties()
                
        unsubmitted = list1.child_window(title_re=".*Unsubmitted.*", control_type="ListItem")
        unsubmittedCB = unsubmitted.child_window(title_re=".*Unsubmitted.*", auto_id="chk-Unsubmitted", control_type="CheckBox")
        
        noLonger = list1.child_window(title_re=".*Taking.*", control_type="ListItem")
        noLongerCB =  noLonger.child_window(title_re=".*Taking.*", auto_id="chk-No Longer Taking", control_type="CheckBox")


    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Filter_Medications' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        logger.console(f"")
        raise Exception(f"Error={e}")

def Get_Data_Grid():
    rootWebArea = Get_RootWebArea() 
    group1 = rootWebArea.child_window(class_name='k-grid k-grid-md',control_type="Group", found_index=0)
    dataGrid = group1.child_window(title="Data table", control_type="DataGrid", class_name="k-grid-aria-root")
    return dataGrid

def Print_Row_Headers(allRows):
    logger.console(f"\n      rows={len(allRows)}\n")
    logger.console(f"      Search All Medications for Active ...[py]\n")

    logger.console(f"      {str('row').ljust(6)}  {str('Name').ljust(50)}  {str('Status').ljust(15)}  {str('OrigDate').ljust(18)}  {str('Result')}")
    logger.console(f"      ------  --------------------------------------------------  ---------------  ------------------  ------------------------------")

def Get_Prescription_Writer_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if "Prescription Writer" in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id, handle=proc.handle)
            break
    return app,proc

def Get_RootWebArea():
    app, proc = Get_Prescription_Writer_App()
    app = app.window(handle=proc.handle) #dlg.print_control_identifiers()
    dlg = app.child_window(auto_id="webView")
    dlg = dlg.child_window(auto_id="webView2")
    dlg = dlg.child_window(class_name="Static", control_type="Text")
    dlg = dlg.child_window(class_name="Chrome_WidgetWin_0", control_type="Pane")
    dlg = dlg.child_window(title="RxWriter", control_type="Pane")
    dlg = dlg.child_window(title="RxWriter - Web content", control_type="Pane")
    dlg = dlg.child_window(class_name="NonClientView", control_type="Pane")
    dlg = dlg.child_window(class_name="EmbeddedBrowserFrameView", control_type="Pane")
    dlg = dlg.child_window(class_name="BrowserView", control_type="Pane")
    dlg = dlg.child_window(class_name="SidebarContentsSplitView", control_type="Pane",found_index=0)
    dlg = dlg.child_window(class_name="SidebarContentsSplitView", control_type="Pane")
    dlg = dlg.child_window(class_name="View", control_type="Pane",found_index=0)
    dlg = dlg.child_window(class_name="View", control_type="Pane")
    rootWebArea = dlg.child_window(auto_id="RootWebArea")
    return rootWebArea

def Get_Date_ddmmmyyyy_Dashes():
    currDateCheck = str(datetime.now().strftime("%d-%b-%Y").lstrip('0').replace("/0", "-"))
    return currDateCheck

def Get_Date_ddmmmyyyy_Dashes_Lead_0():
    currDateCheck = str(datetime.now().strftime("%d-%b-%Y").replace("/0", "-"))
    return currDateCheck

###############################################
#                    MAIN
###############################################
#
if __name__ == '__main__':
    logger.console(f"\nBEGIN MAIN....\n")
    #Click_Add_Rx_Button_Py()
    #Type_Medication_To_Search_Py('Neosporin')
    #Select_Rx_Py()
    #Fill_Out_Rx_Criteria_And_Submit("Neosporin 400")  # units-3.5 mg-5000")
    Discontinue_Medications_Py("Intolerance")
    #Filter_Only_InActive_Status_Py()
    #Filter_InActive_Medications_Quick_Click_Py()
    #Verify_Discontinued_Medications_Py()
    #Add_Back_All_Filter_Statuses_Py(1510,212,241,293,318)
    #Verify_Discontinued_Medications_Py()
    #Get_Date_ddmmmyyyy_Dashes_Lead_0()
    #Click_Add_Rx_Button_Py()
    #Select_Rx_Py()
    #Fill_Out_Rx_Criteria_And_Submit("Neosporin 400")
    #Sort_By_Status_Asc_Py()
    