from pydantic_resolve import base_entity

BaseEntity = base_entity()