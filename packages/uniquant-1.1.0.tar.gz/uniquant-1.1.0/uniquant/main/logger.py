import logging

logger = logging.getLogger("uniquant")
logger.setLevel(logging.DEBUG)