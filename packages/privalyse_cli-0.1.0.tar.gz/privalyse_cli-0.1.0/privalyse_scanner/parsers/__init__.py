"""
Parsers package for Privalyse Scanner
"""
