See discussion here:
https://github.com/plasma-umass/scalene/issues/554#issuecomment-1400730365.

Original code is in `svm-original.py`; optimized code is added in `svm-optimized.py`.

The optimized code runs almost 300x faster than the original.
