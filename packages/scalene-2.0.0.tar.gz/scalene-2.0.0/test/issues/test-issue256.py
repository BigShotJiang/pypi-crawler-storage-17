ret_value = dict()

for k in range(10**7):
    temp = k * 2
    ret_value[k] = temp
