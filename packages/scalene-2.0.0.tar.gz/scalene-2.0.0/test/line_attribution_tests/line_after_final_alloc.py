def main():
    accum = bytes()
    for i in range(31):
        accum += bytes(10485767 * 2)

    asdf = bytes(2 * 10485767)
    some_dead_line = None


if __name__ == "__main__":
    main()
