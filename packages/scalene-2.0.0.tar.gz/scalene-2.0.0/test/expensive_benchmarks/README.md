# NOTE: bm_async_tree_io is 3 benchmarks

### async_tree_io ###
Mean +- std dev: 1.44 sec +- 0.04 sec

### docutils ###
Mean +- std dev: 2.38 sec +- 0.03 sec

### mdp ###
Mean +- std dev: 2.74 sec +- 0.11 sec


### pprint_pformat ###
Mean +- std dev: 1.41 sec +- 0.02 sec

### async_tree_cpu_io_mixed ###
Mean +- std dev: 795 ms +- 24 ms


### async_tree_memoization ###
Mean +- std dev: 697 ms +- 16 ms

### async_tree_none ###
Mean +- std dev: 576 ms +- 25 ms

### sympy_expand ###
Mean +- std dev: 488 ms +- 7 ms

### raytrace ###
Mean +- std dev: 469 ms +- 10 ms

### fannkuch ###
Mean +- std dev: 367 ms +- 5 ms