
To launch this test, you must first run the Pingable python agent, then run the test client :
```bash
python3 ../../sample_agents/ping/run_pingable_agent.py
```

```bash
python3 run_test_client.py
```

