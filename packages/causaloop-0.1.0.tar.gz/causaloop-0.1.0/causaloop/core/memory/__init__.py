"""Docstring for causaloop.core.memory."""
