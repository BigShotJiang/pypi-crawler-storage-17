"""Docstring for causaloop.core.action."""
