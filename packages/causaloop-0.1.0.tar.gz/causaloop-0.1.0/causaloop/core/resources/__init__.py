"""Docstring for causaloop.core.resources."""
