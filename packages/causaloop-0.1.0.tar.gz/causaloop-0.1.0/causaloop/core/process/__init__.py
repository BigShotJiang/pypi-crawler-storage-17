"""Docstring for causaloop.core.process."""
