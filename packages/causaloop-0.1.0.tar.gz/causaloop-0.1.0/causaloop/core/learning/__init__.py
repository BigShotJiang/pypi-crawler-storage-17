"""Docstring for causaloop.core.learning."""
