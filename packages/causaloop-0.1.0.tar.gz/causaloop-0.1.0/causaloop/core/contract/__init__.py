"""Docstring for causaloop.core.contract."""
