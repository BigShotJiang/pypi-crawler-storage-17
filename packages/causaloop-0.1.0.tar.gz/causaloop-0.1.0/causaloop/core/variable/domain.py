"""Domain-specific Variable implementations."""

from __future__ import annotations

from typing import Any

import numpy as np

from ...utils.logging import get_logger
from .base import Variable, VariableRole

logger = get_logger(__name__)


class ContinuousVariable(Variable):
    """
    Variable representing continuous quantities.

    Supports ranges, bounds, and continuous validation.

    Examples
    --------
    >>> from causaloop import ContinuousVariable, VariableRole
    >>>
    >>> # Create a bounded continuous variable
    >>> temperature = ContinuousVariable(
    ...     name="temperature",
    ...     description="Ambient temperature",
    ...     units="Celsius",
    ...     role=VariableRole.ENDOGENOUS,
    ...     lower_bound=-273.15,  # Absolute zero
    ...     upper_bound=1000.0,   # Reasonable maximum
    ...     default_value=22.0
    ... )
    >>>
    >>> # Update with valid value
    >>> temperature.update(25.5, confidence=0.9)
    True
    >>>
    >>> # Invalid value (too low)
    >>> temperature.update(-300.0)
    False
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        units: str | None = None,
        role: VariableRole = VariableRole.ENDOGENOUS,
        lower_bound: float | None = None,
        upper_bound: float | None = None,
        default_value: float | None = None,
        tolerance: float = 1e-6,
        config: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize a continuous variable.

        Parameters
        ----------
        name : str
            Variable name.
        description : str, optional
            Human-readable description.
        units : str, optional
            Physical units.
        role : VariableRole, optional
            Role in causal relationships.
        lower_bound : float, optional
            Lower bound for valid values.
        upper_bound : float, optional
            Upper bound for valid values.
        default_value : float, optional
            Default value.
        tolerance : float, optional
            Numerical tolerance for comparisons.
        config : dict, optional
            Configuration dictionary.
        """
        # Needed by validate()
        self.lower_bound = lower_bound
        self.upper_bound = upper_bound
        self.tolerance = tolerance

        super().__init__(
            name=name,
            description=description,
            units=units,
            role=role,
            initial_value=default_value,
            config=config,
        )

        logger.debug(
            "Initialized ContinuousVariable %s with bounds [%s, %s]",
            name,
            lower_bound,
            upper_bound,
        )

    def validate(self, value: Any) -> bool:
        """
        Validate a continuous value.

        Parameters
        ----------
        value : Any
            Value to validate.

        Returns
        -------
        bool
            True if value is a valid continuous number.
        """
        # Check if value is numeric
        if not isinstance(value, int | float | np.number):
            logger.warning(
                "Value for continuous variable %s is not numeric: %s",
                self.name,
                type(value).__name__,
            )
            return False

        # Check bounds
        if self.lower_bound is not None and value < self.lower_bound - self.tolerance:
            logger.debug(
                "Value %s below lower bound %s for %s",
                value,
                self.lower_bound,
                self.name,
            )
            return False

        if self.upper_bound is not None and value > self.upper_bound + self.tolerance:
            logger.debug(
                "Value %s above upper bound %s for %s",
                value,
                self.upper_bound,
                self.name,
            )
            return False

        return True

    def is_within_bounds(self, value: float, margin: float = 0.0) -> bool:
        """
        Check if value is within bounds with optional margin.

        Parameters
        ----------
        value : float
            Value to check.
        margin : float, optional
            Safety margin (default: 0).

        Returns
        -------
        bool
            True if value is within bounds ± margin.
        """
        lower_check = (
            self.lower_bound is None
            or value >= self.lower_bound - margin - self.tolerance
        )
        upper_check = (
            self.upper_bound is None
            or value <= self.upper_bound + margin + self.tolerance
        )
        return lower_check and upper_check

    def distance_to_boundary(self, value: float) -> tuple[float | None, float | None]:
        """
        Calculate distance to lower and upper boundaries.

        Parameters
        ----------
        value : float
            Current value.

        Returns
        -------
        tuple[Optional[float], Optional[float]]
            Distance to lower bound (positive if above) and
            distance to upper bound (positive if below).
        """
        lower_dist = value - self.lower_bound if self.lower_bound is not None else None
        upper_dist = self.upper_bound - value if self.upper_bound is not None else None
        return lower_dist, upper_dist


class DiscreteVariable(Variable):
    """
    Variable representing discrete quantities.

    Supports finite sets of allowed values and categorical data.

    Examples
    --------
    >>> from causaloop import DiscreteVariable, VariableRole
    >>>
    >>> # Create a categorical variable
    >>> status = DiscreteVariable(
    ...     name="system_status",
    ...     description="System operational status",
    ...     role=VariableRole.ENDOGENOUS,
    ...     allowed_values=["running", "stopped", "error", "maintenance"],
    ...     default_value="stopped"
    ... )
    >>>
    >>> # Valid update
    >>> status.update("running", confidence=0.95)
    True
    >>>
    >>> # Invalid update
    >>> status.update("invalid_status")
    False
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        units: str | None = None,
        role: VariableRole = VariableRole.ENDOGENOUS,
        allowed_values: list[Any] | None = None,
        default_value: Any | None = None,
        allow_none: bool = False,
        config: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize a discrete variable.

        Parameters
        ----------
        name : str
            Variable name.
        description : str, optional
            Human-readable description.
        units : str, optional
            Physical units.
        role : VariableRole, optional
            Role in causal relationships.
        allowed_values : list[Any], optional
            List of allowed values. If None, any value is allowed.
        default_value : Any, optional
            Default value if not specified.
        allow_none : bool, optional
            Whether None is an allowed value.
        config : dict, optional
            Configuration dictionary.
        """
        # Needed by validate()
        self.allowed_values = allowed_values if allowed_values is not None else []
        self.allow_none = allow_none
        if allow_none:
            self.allowed_values.append(None)

        super().__init__(
            name=name,
            description=description,
            units=units,
            role=role,
            initial_value=default_value,
            config=config,
        )

        logger.debug(
            "Initialized DiscreteVariable %s with %d allowed values",
            name,
            len(self.allowed_values),
        )

    def validate(self, value: Any) -> bool:
        """
        Validate a discrete value.

        Parameters
        ----------
        value : Any
            Value to validate.

        Returns
        -------
        bool
            True if value is valid.
        """
        # Check if value is in allowed list
        if value in self.allowed_values:
            return True

        logger.debug("Value %s not in allowed list for %s", value, self.name)
        return False

    def add(self, value: Any) -> bool:
        """
        Add a value to the allowed set.

        Parameters
        ----------
        value : Any
            Value to add.
        """
        if value is None and not self.allow_none:
            logger.debug("None is not allowed to %s", self.name)
            print("XXX", value, self.allow_none)
            return False
        if value not in self.allowed_values:
            self.allowed_values.append(value)
            logger.debug("Added allowed value %s to %s", value, self.name)
            return True

        logger.warning("Can't add allowed value %s to %s", value, self.name)
        return False

    def remove(self, value: Any) -> bool:
        """
        Remove a value from the allowed set.

        Parameters
        ----------
        value : Any
            Value to remove.

        Returns
        -------
        bool
            True if value was removed.
        """
        if value in self.allowed_values:
            self.allowed_values.remove(value)
            logger.debug("Removed allowed value %s from %s", value, self.name)
            return True

        return False


class BooleanVariable(DiscreteVariable):
    """
    Specialized discrete variable for boolean values.

    Examples
    --------
    >>> from causaloop import BooleanVariable, VariableRole
    >>>
    >>> # Create a boolean variable
    >>> is_active = BooleanVariable(
    ...     name="is_active",
    ...     description="Whether system is active",
    ...     role=VariableRole.ENDOGENOUS,
    ...     default_value=False
    ... )
    >>>
    >>> # Update with boolean value
    >>> is_active.update(True, confidence=0.99)
    True
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        role: VariableRole = VariableRole.ENDOGENOUS,
        default_value: bool | None = None,
        config: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize a boolean variable.

        Parameters
        ----------
        name : str
            Variable name.
        description : str, optional
            Human-readable description.
        role : VariableRole, optional
            Role in causal relationships.
        default_value : bool, optional
            Default value if not specified.
        config : dict, optional
            Configuration dictionary.
        """
        super().__init__(
            name=name,
            description=description,
            units=None,
            role=role,
            allowed_values=[True, False],
            default_value=default_value,
            allow_none=False,
            config=config,
        )

    def toggle(self) -> bool:
        """
        Toggle the boolean value.

        Returns
        -------
        bool
            True if toggle was successful.
        """
        if self.value is not None:
            new_value = not self.value
            return self.update(new_value, confidence=self.confidence)
        return False


class VectorVariable(Variable):
    """
    Variable representing vector/multi-dimensional quantities.

    Examples
    --------
    >>> import numpy as np
    >>> from causaloop import VectorVariable, VariableRole
    >>>
    >>> # Create a 3D position vector
    >>> position = VectorVariable(
    ...     name="position",
    ...     description="3D position vector",
    ...     units="meters",
    ...     role=VariableRole.ENDOGENOUS,
    ...     dimension=3,
    ...     default_value=np.array([0.0, 0.0, 0.0])
    ... )
    >>>
    >>> # Update with vector
    >>> position.update(np.array([1.0, 2.0, 3.0]), confidence=0.9)
    True
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        units: str | None = None,
        role: VariableRole = VariableRole.ENDOGENOUS,
        dimension: int | None = None,
        default_value: np.ndarray[Any, Any] | None = None,
        norm_bound: float | None = None,
        config: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize a vector variable.

        Parameters
        ----------
        name : str
            Variable name.
        description : str, optional
            Human-readable description.
        units : str, optional
            Physical units.
        role : VariableRole, optional
            Role in causal relationships.
        dimension : int, optional
            Expected dimension. If None, any dimension is allowed.
        default_value : np.ndarray, optional
            Default vector value.
        norm_bound : float, optional
            Maximum allowed norm of the vector.
        config : dict, optional
            Configuration dictionary.
        """
        # Needed by validate()
        self.dimension = dimension

        super().__init__(
            name=name,
            description=description,
            units=units,
            role=role,
            initial_value=default_value,
            config=config,
        )

        self.norm_bound = norm_bound

        # Add dimension constraint if specified
        if dimension is not None:
            self.add_constraint(self._check_dimension)

        # Add norm constraint if specified
        if norm_bound is not None:
            self.add_constraint(self._check_norm)

        logger.debug(
            "Initialized VectorVariable %s with dimension=%s, norm_bound=%s",
            name,
            dimension,
            norm_bound,
        )

    def _check_dimension(self, value: np.ndarray[Any, Any]) -> bool:
        """Check if vector has correct dimension."""
        return value.ndim == 1 and (
            self.dimension is None or len(value) == self.dimension
        )

    def _check_norm(self, value: np.ndarray[Any, Any]) -> bool:
        """Check if vector norm is within bound."""
        if self.norm_bound is None:
            return True
        norm = np.linalg.norm(value)
        if norm <= self.norm_bound:
            return True
        return False

    def validate(self, value: Any) -> bool:
        """
        Validate a vector value.

        Parameters
        ----------
        value : Any
            Value to validate.

        Returns
        -------
        bool
            True if value is a valid vector.
        """
        # Check if value is a numpy array
        if not isinstance(value, np.ndarray):
            logger.warning(
                "Value for vector variable %s is not a numpy array: %s",
                self.name,
                type(value).__name__,
            )
            return False

        # Check dimension
        if value.ndim != 1:
            logger.debug("Vector %s has ndim=%d, expected 1", self.name, value.ndim)
            return False

        # Check specific dimension if required
        if self.dimension is not None and len(value) != self.dimension:
            logger.debug(
                "Vector %s has length %d, expected %d",
                self.name,
                len(value),
                self.dimension,
            )
            return False

        return True

    def get_norm(self) -> float | None:
        """
        Get the norm of the current vector.

        Returns
        -------
        Optional[float]
            Vector norm, or None if no value set.
        """
        if self.value is not None and isinstance(self.value, np.ndarray):
            return float(np.linalg.norm(self.value))
        return None

    def get_unit_vector(self) -> np.ndarray[Any, Any] | None:
        """
        Get the unit vector in the current direction.

        Returns
        -------
        Optional[np.ndarray]
            Unit vector, or None if no value set or zero vector.
        """
        if not isinstance(self.value, np.ndarray):
            return None
        norm = self.get_norm()
        if self.value is not None and norm is not None and norm > 0:
            return self.value / norm
        return None
