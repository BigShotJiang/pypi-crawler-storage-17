"""
Variable module for CausaLoop.

This module defines the core Variable abstraction - the fundamental unit of causal
representation that carries state, uncertainty, constraints, and reasoning capabilities.
"""

from .base import Variable, VariableMetadata, VariableRole, VariableStatus
from .domain import (
    BooleanVariable,
    ContinuousVariable,
    DiscreteVariable,
    VectorVariable,
)
from .meta import (
    AggregationMethod,
    ConflictResolutionStrategy,
    MetaVariable,
    ValueProposal,
)
from .random import (
    RandomState,
    RandomStateManager,
    RandomStateTuple,
    random_state_manager,
    sampling_context,
    set_random_seed,
)
from .state import StateTransition, StateTransitionType, VariableState
from .stochastic import (
    DistributionParameters,
    DistributionType,
    MixtureVariable,
    NormalVariable,
    StochasticVariable,
    UniformVariable,
)

__all__ = [
    # Base
    "VariableRole",
    "VariableStatus",
    "VariableMetadata",
    "Variable",
    # Domain
    "ContinuousVariable",
    "DiscreteVariable",
    "BooleanVariable",
    "VectorVariable",
    # Meta
    "AggregationMethod",
    "ConflictResolutionStrategy",
    "ValueProposal",
    "MetaVariable",
    # Random
    "RandomStateTuple",
    "RandomState",
    "RandomStateManager",
    "set_random_seed",
    "sampling_context",
    "random_state_manager",
    # State
    "StateTransitionType",
    "StateTransition",
    "VariableState",
    # Stochastic
    "DistributionType",
    "DistributionParameters",
    "StochasticVariable",
    "NormalVariable",
    "UniformVariable",
    "MixtureVariable",
]
