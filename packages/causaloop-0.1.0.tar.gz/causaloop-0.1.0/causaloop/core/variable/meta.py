"""MetaVariable for managing metadata and cross-variable relationships."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum, auto
from typing import Any

import numpy as np

from ...utils.logging import get_logger
from .base import Variable, VariableRole

logger = get_logger(__name__)


class AggregationMethod(Enum):
    """
    Methods for aggregating multiple variable values into a single consensus value.

    Defines the mathematical and statistical approaches for combining multiple
    value proposals into a single representative value. Each method has different
    properties regarding robustness to outliers, sensitivity to confidence,
    and computational complexity.

    Attributes
    ----------
    MEAN : AggregationMethod
        Arithmetic mean (average) of all proposed values. Simple and fast but
        sensitive to outliers. Formula: (Σ values) / n

    MEDIAN : AggregationMethod
        Median (middle value) of all proposed values. More robust to outliers
        than mean. For n values, median is the middle value when sorted
        (or average of two middle values for even n).

    WEIGHTED_MEAN : AggregationMethod
        Confidence-weighted average. Each value is weighted by its confidence
        score. Formula: Σ(value_i * confidence_i) / Σ(confidence_i)
        Most appropriate when confidence estimates are reliable.

    MAX_CONFIDENCE : AggregationMethod
        Selects the value with the highest confidence score. Simple and
        confidence-aware, but ignores information from other proposals.
        May be unstable if confidence estimates are noisy.

    CONSENSUS : AggregationMethod
        Finds clusters of similar values and selects from the largest cluster.
        Robust to multiple conflicting proposals. Uses tolerance-based grouping
        to identify value clusters before aggregation.

    BAYESIAN_FUSION : AggregationMethod
        Bayesian inference combining prior distribution with proposal likelihoods.
        Most statistically rigorous but computationally intensive. Assumes
        proposal distributions are known or can be estimated.

    Notes
    -----
    The choice of aggregation method depends on:
    1. Reliability of confidence estimates
    2. Presence of outliers or adversarial proposals
    3. Computational constraints
    4. Statistical properties required

    For sensor fusion applications, WEIGHTED_MEAN or BAYESIAN_FUSION are often
    appropriate. For conflict resolution with untrusted sources, CONSENSUS
    or MEDIAN provide robustness.

    Examples
    --------
    >>> from causaloop import AggregationMethod, MetaVariable
    >>>
    >>> # Create a meta-variable with different aggregation methods
    >>> sensor_mean = MetaVariable(
    ...     name="sensor_average",
    ...     aggregation_method=AggregationMethod.MEAN
    ... )
    >>>
    >>> confidence_weighted = MetaVariable(
    ...     name="confidence_weighted",
    ...     aggregation_method=AggregationMethod.WEIGHTED_MEAN
    ... )
    >>>
    >>> robust_aggregator = MetaVariable(
    ...     name="robust_value",
    ...     aggregation_method=AggregationMethod.CONSENSUS
    ... )
    >>>
    >>> # Compare aggregation behaviors
    >>> print(f"Mean aggregation: {AggregationMethod.MEAN.name}")
    >>> Mean aggregation: MEAN
    >>> print(f"Median (robust to outliers): {AggregationMethod.MEDIAN.name}")
    >>> Median (robust to outliers): MEDIAN
    >>> print(f"Bayesian (statistical): {AggregationMethod.BAYESIAN_FUSION.name}")
    >>> Bayesian (statistical): BAYESIAN_FUSION
    """

    MEAN = auto()
    """Arithmetic mean (average) of all proposed values."""

    MEDIAN = auto()
    """Median (middle value) of all proposed values."""

    WEIGHTED_MEAN = auto()
    """Confidence-weighted average of proposed values."""

    MAX_CONFIDENCE = auto()
    """Value with highest confidence score."""

    CONSENSUS = auto()
    """Value from largest cluster of similar proposals."""

    BAYESIAN_FUSION = auto()
    """Bayesian inference combining prior and likelihoods."""


class ConflictResolutionStrategy(Enum):
    """
    Strategies for resolving conflicts between multiple value proposals.

    Defines approaches for handling situations where different sources propose
    conflicting values for the same variable. Each strategy represents a
    different philosophy for trust allocation, recency weighting, and
    conflict management.

    Attributes
    ----------
    HIGHEST_CONFIDENCE : ConflictResolutionStrategy
        Selects the proposal with the highest confidence score. Assumes
        confidence estimates are accurate and comparable across sources.
        Simple but may ignore valuable information from other proposals.

    MOST_RECENT : ConflictResolutionStrategy
        Selects the most recent proposal. Appropriate for time-sensitive
        systems where newer information supersedes older information.
        Requires accurate and synchronized timestamps.

    WEIGHTED_AVERAGE : ConflictResolutionStrategy
        Computes a weighted average based on confidence scores and optionally
        recency. Balances information from all sources while weighting by
        estimated reliability.

    DOMAIN_SPECIFIC : ConflictResolutionStrategy
        Uses domain-specific rules or heuristics to resolve conflicts.
        May incorporate additional metadata, source reputation, or
        contextual information not captured in confidence scores.

    CONSENSUS : ConflictResolutionStrategy
        Looks for agreement among multiple proposals. May require a
        minimum number of agreeing sources or a supermajority threshold.
        Robust to outliers and adversarial sources.

    EXTERNAL_ARBITRATION : ConflictResolutionStrategy
        Delegates conflict resolution to an external system, human operator,
        or higher-level reasoning process. Used when automated resolution
        is insufficient or when conflicts indicate systemic issues.

    Notes
    -----
    Conflict resolution is distinct from aggregation:
    - **Aggregation** combines all proposals into a single value
    - **Conflict resolution** chooses between incompatible proposals

    In practice, these are often used together: first attempt aggregation,
    and if conflicts persist (e.g., high variance), apply conflict resolution.

    The choice of strategy depends on:
    1. Source reliability characteristics
    2. Consequences of incorrect resolution
    3. Availability of domain knowledge
    4. Time constraints for resolution

    Examples
    --------
    >>> from causaloop import ConflictResolutionStrategy, MetaVariable
    >>>
    >>> # Different conflict scenarios require different strategies
    >>> sensor_conflict = MetaVariable(
    ...     name="sensor_data",
    ...     conflict_strategy=ConflictResolutionStrategy.HIGHEST_CONFIDENCE
    ... )
    >>>
    >>> time_critical = MetaVariable(
    ...     name="market_price",
    ...     conflict_strategy=ConflictResolutionStrategy.MOST_RECENT
    ... )
    >>>
    >>> safety_critical = MetaVariable(
    ...     name="reactor_temperature",
    ...     conflict_strategy=ConflictResolutionStrategy.CONSENSUS
    ... )
    >>>
    >>> # Domain-specific resolution for specialized knowledge
    >>> medical_diagnosis = MetaVariable(
    ...     name="patient_diagnosis",
    ...     conflict_strategy=ConflictResolutionStrategy.DOMAIN_SPECIFIC
    ... )
    >>>
    >>> # External arbitration when automated resolution fails
    >>> legal_judgment = MetaVariable(
    ...     name="legal_interpretation",
    ...     conflict_strategy=ConflictResolutionStrategy.EXTERNAL_ARBITRATION
    ... )
    """

    HIGHEST_CONFIDENCE = auto()
    """Select proposal with highest confidence score."""

    MOST_RECENT = auto()
    """Select most recent proposal."""

    WEIGHTED_AVERAGE = auto()
    """Weighted average based on confidence and recency."""

    DOMAIN_SPECIFIC = auto()
    """Use domain-specific rules or heuristics."""

    CONSENSUS = auto()
    """Require agreement among multiple sources."""

    EXTERNAL_ARBITRATION = auto()
    """Delegate to external system or human operator."""


@dataclass
class ValueProposal:
    """
    Represents a proposed value for a variable from a specific source.

    Contains the proposed value along with metadata about its provenance,
    confidence, timing, and additional context. ValueProposals are the
    fundamental unit of information in multi-source reasoning systems.

    Parameters
    ----------
    value : Any
        The proposed value. Can be any type supported by the variable's
        validation and serialization system. Typically numeric, categorical,
        or structured data matching the variable's domain.

    confidence : float
        Confidence score for the proposed value, ranging from 0.0 to 1.0.
        Represents the source's estimate of reliability or accuracy.
        Should be calibrated appropriately for the application domain.

    source : str
        Identifier of the proposal source. Typically a mechanism ID,
        sensor name, algorithm identifier, or human operator ID.
        Used for provenance tracking and source-specific weighting.

    timestamp : datetime
        Time when the proposal was generated or observed. Should use
        UTC timezone for consistency. Critical for recency-based
        reasoning and temporal correlation.

    metadata : dict[str, Any], optional
        Additional context-specific metadata about the proposal.
        May include:
        - Measurement uncertainty or error bounds
        - Processing pipeline information
        - Quality metrics or flags
        - Environmental conditions
        - Source-specific parameters
        Default: empty dictionary.

    Attributes
    ----------
    value : Any
        See Parameters section.

    confidence : float
        See Parameters section.

    source : str
        See Parameters section.

    timestamp : datetime
        See Parameters section.

    metadata : dict[str, Any]
        See Parameters section.

    Raises
    ------
    ValueError
        If confidence is not in range [0.0, 1.0].

    Notes
    -----
    ValueProposals are designed to be immutable once created. For updates
    or corrections, create a new ValueProposal rather than modifying
    an existing one.

    The metadata field enables extensibility without modifying the core
    structure. Metadata keys should follow naming conventions appropriate
    to the application domain.

    For Bayesian reasoning systems, confidence may represent the inverse
    of variance or precision. For human-provided estimates, it may represent
    subjective certainty.

    Examples
    --------
    >>> from datetime import datetime, timezone
    >>> from causaloop.core.variable import ValueProposal
    >>>
    >>> # Basic temperature reading from a sensor
    >>> temp_proposal = ValueProposal(
    ...     value=22.5,
    ...     confidence=0.92,
    ...     source="temperature_sensor_001",
    ...     timestamp=datetime.utcnow(),
    ...     metadata={
    ...         "sensor_type": "thermocouple",
    ...         "calibration_date": "2025-12-10",
    ...         "sampling_rate": "1 Hz",
    ...         "environment": "indoor_lab"
    ...     }
    ... )
    >>>
    >>> # Financial forecast from an algorithm
    >>> forecast_proposal = ValueProposal(
    ...     value=150.25,
    ...     confidence=0.75,
    ...     source="price_predictor_v2",
    ...     timestamp=datetime.now(timezone.utc),
    ...     metadata={
    ...         "model_version": "2.1.3",
    ...         "prediction_horizon": "24h",
    ...         "input_features": ["volume", "sentiment", "trend"],
    ...         "uncertainty_interval": [140.5, 160.0]
    ...     }
    ... )
    >>>
    >>> # Medical diagnosis from a clinician
    >>> diagnosis_proposal = ValueProposal(
    ...     value="Type_II_Diabetes",
    ...     confidence=0.88,
    ...     source="dr_smith",
    ...     timestamp=datetime.now(timezone.utc),
    ...     metadata={
    ...         "certainty_level": "high",
    ...         "supporting_evidence": ["glucose_level", "family_history"],
    ...         "differential_diagnoses": ["Prediabetes", "Type_I_Diabetes"],
    ...         "notes": "Patient presents with classic symptoms"
    ...     }
    ... )
    >>>
    >>> # Invalid confidence (should raise ValueError)
    >>> try:
    ...     invalid_proposal = ValueProposal(
    ...         value=10.0,
    ...         confidence=1.5,  # Invalid: > 1.0
    ...         source="test",
    ...         timestamp=datetime.now(timezone.utc)
    ...     )
    ... except ValueError as e:
    ...     print(f"Validation error: {e}")
    Validation error: Confidence must be between 0.0 and 1.0, got 1.5
    """

    value: Any
    confidence: float
    source: str
    timestamp: datetime
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """
        Validate the ValueProposal after initialization.

        Performs validation checks to ensure the proposal is well-formed.
        Currently validates confidence range.

        Raises
        ------
        ValueError
            If confidence is outside valid range [0.0, 1.0].
        """
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError(
                f"Confidence must be between 0.0 and 1.0, got {self.confidence}"
            )

    def to_dict(self) -> dict[str, Any]:
        """
        Convert ValueProposal to dictionary representation.

        Returns
        -------
        dict[str, Any]
            Dictionary containing all proposal data. Suitable for
            serialization or transmission.

        Examples
        --------
        >>> from datetime import datetime
        >>> from causaloop import ValueProposal
        >>> proposal = ValueProposal(
        ...     value=42.0,
        ...     confidence=0.9,
        ...     source="test",
        ...     timestamp=datetime(2025, 12, 10, 12, 0, 0)
        ... )
        >>> data = proposal.to_dict()
        >>> print(data["value"])
        42.0
        >>> print(data["source"])
        test
        """
        return {
            "value": self.value,
            "confidence": self.confidence,
            "source": self.source,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ValueProposal:
        """
        Create ValueProposal from dictionary representation.

        Parameters
        ----------
        data : dict[str, Any]
            Dictionary containing proposal data. Must include:
            - value: The proposed value
            - confidence: Confidence score (0.0 to 1.0)
            - source: Source identifier
            - timestamp: ISO format timestamp string
            - metadata: Optional metadata dictionary

        Returns
        -------
        ValueProposal
            Reconstructed ValueProposal instance.

        Raises
        ------
        KeyError
            If required fields are missing.
        ValueError
            If timestamp cannot be parsed or confidence is invalid.

        Examples
        --------
        >>> from causaloop import ValueProposal
        >>> data = {
        ...     "value": 99.5,
        ...     "confidence": 0.85,
        ...     "source": "sensor_01",
        ...     "timestamp": "2025-12-10T10:30:45.123456",
        ...     "metadata": {"unit": "Celsius"}
        ... }
        >>> proposal = ValueProposal.from_dict(data)
        >>> print(proposal.value)
        99.5
        >>> print(proposal.source)
        sensor_01
        """
        import dateutil.parser

        return cls(
            value=data["value"],
            confidence=data["confidence"],
            source=data["source"],
            timestamp=dateutil.parser.isoparse(data["timestamp"]),
            metadata=data.get("metadata", {}),
        )

    def is_stale(self, max_age_seconds: float = 3600.0) -> bool:
        """
        Check if the proposal is stale (older than specified age).

        Parameters
        ----------
        max_age_seconds : float, optional
            Maximum age in seconds before proposal is considered stale.
            Default: 3600.0 (1 hour).

        Returns
        -------
        bool
            True if proposal is stale, False otherwise.

        Examples
        --------
        >>> from datetime import datetime, timezone, timedelta
        >>> from causaloop import ValueProposal
        >>>
        >>> # Fresh proposal (just created)
        >>> fresh = ValueProposal(
        ...     value=10.0,
        ...     confidence=0.9,
        ...     source="test",
        ...     timestamp=datetime.now(timezone.utc)
        ... )
        >>> print(fresh.is_stale(max_age_seconds=60))
        False
        >>>
        >>> # Old proposal (2 hours ago)
        >>> old = ValueProposal(
        ...     value=10.0,
        ...     confidence=0.9,
        ...     source="test",
        ...     timestamp=datetime.now(timezone.utc) - timedelta(hours=2)
        ... )
        >>> print(old.is_stale(max_age_seconds=3600))
        True
        """
        now = datetime.now(timezone.utc)
        age = (now - self.timestamp).total_seconds()
        return age > max_age_seconds

    def __str__(self) -> str:
        """Representation of ValueProposal."""
        return (
            f"ValueProposal(value={self.value}, "
            f"confidence={self.confidence:.3f}, "
            f"source={self.source}, "
            f"timestamp={self.timestamp.isoformat()[:19]})"
        )

    def __repr__(self) -> str:
        """Detailed representation of ValueProposal."""
        return (
            f"ValueProposal(value={self.value!r}, "
            f"confidence={self.confidence:.3f}, "
            f"source={self.source!r}, "
            f"timestamp={self.timestamp.isoformat()!r}, "
            f"metadata={self.metadata!r})"
        )


class MetaVariable(Variable):
    """
    Variable that manages relationships between other variables.

    MetaVariables can aggregate, reconcile, and reason about multiple
    related variables. They're useful for creating derived variables,
    managing conflicts, and implementing system-level reasoning.

    Examples
    --------
    >>> from datetime import datetime, timezone
    >>> from causaloop import MetaVariable, VariableRole, AggregationMethod, ValueProposal
    >>>
    >>> # Create a meta-variable that averages temperature sensors
    >>> avg_temp = MetaVariable(
    ...     name="average_temperature",
    ...     description="Average of all temperature sensors",
    ...     units="Celsius",
    ...     role=VariableRole.OBSERVATION,
    ...     aggregation_method=AggregationMethod.WEIGHTED_MEAN
    ... )
    >>>
    >>> # Add value proposals from different sensors
    >>> proposals = [
    ...     ValueProposal(22.5, 0.9, "sensor_1", datetime.now(timezone.utc)),
    ...     ValueProposal(23.1, 0.8, "sensor_2", datetime.now(timezone.utc)),
    ...     ValueProposal(21.9, 0.95, "sensor_3", datetime.now(timezone.utc)),
    ... ]
    >>> for proposal in proposals:
    ...     avg_temp.add_proposal(proposal)
    ...
    >>> # Resolve to get consensus value
    >>> avg_temp.resolve()
    >>> True
    >>> print(f"Average temperature: {avg_temp.value:.2f}°C")
    Average temperature: 22.47°C
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        units: str | None = None,
        role: VariableRole = VariableRole.ENDOGENOUS,
        aggregation_method: AggregationMethod = AggregationMethod.WEIGHTED_MEAN,
        conflict_strategy: ConflictResolutionStrategy = ConflictResolutionStrategy.HIGHEST_CONFIDENCE,
        config: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize a MetaVariable.

        Parameters
        ----------
        name : str
            Unique name of the meta-variable.
        description : str, optional
            Human-readable description.
        units : str, optional
            Physical units.
        role : VariableRole, optional
            Role in causal relationships.
        aggregation_method : AggregationMethod, optional
            Method for aggregating multiple proposals.
        conflict_strategy : ConflictResolutionStrategy, optional
            Strategy for resolving conflicts.
        config : dict, optional
            Configuration dictionary.
        """
        super().__init__(
            name=name,
            description=description,
            units=units,
            role=role,
            config=config,
        )

        self.aggregation_method = aggregation_method
        self.conflict_strategy = conflict_strategy
        self.proposals: list[ValueProposal] = []
        self.resolution_history: list[dict[str, Any]] = []

        logger.debug(
            "Initialized MetaVariable %s with aggregation=%s, conflict_strategy=%s",
            name,
            aggregation_method.name,
            conflict_strategy.name,
        )

    def add_proposal(self, proposal: ValueProposal) -> None:
        """
        Add a value proposal from a source.

        Parameters
        ----------
        proposal : ValueProposal
            Proposed value with confidence and metadata.

        Examples
        --------
        >>> from datetime import datetime, timezone
        >>> from causaloop import MetaVariable, ValueProposal
        >>> meta = MetaVariable(name="test")
        >>> proposal = ValueProposal(42.0, 0.9, "source_1", datetime.now(timezone.utc))
        >>> meta.add_proposal(proposal)
        """
        self.proposals.append(proposal)
        logger.debug(
            "Added proposal to %s: value=%s from %s with confidence=%.3f",
            self.name,
            proposal.value,
            proposal.source,
            proposal.confidence,
        )

    def clear_proposals(self) -> None:
        """Clear all pending proposals."""
        self.proposals.clear()
        logger.debug("Cleared proposals for %s", self.name)

    def resolve(self, force: bool = False) -> bool:
        """
        Resolve proposals into a single value.

        Parameters
        ----------
        force : bool, optional
            If True, force resolution even with conflicting proposals.

        Returns
        -------
        bool
            True if resolution was successful.

        Raises
        ------
        ValueError
            If no proposals available or aggregation fails.
        """
        if not self.proposals:
            raise ValueError(f"No proposals available for {self.name}")

        # Filter out stale proposals (older than 1 hour by default)
        cutoff = datetime.now(timezone.utc) - timedelta(hours=1)
        recent_proposals = [p for p in self.proposals if p.timestamp >= cutoff]

        if not recent_proposals and not force:
            raise ValueError(f"No recent proposals for {self.name}")

        proposals_to_use = recent_proposals if recent_proposals else self.proposals

        # Apply aggregation method
        try:
            value, confidence = self._aggregate(proposals_to_use)
        except Exception as e:
            logger.error("Aggregation failed for %s: %s", self.name, str(e))
            return False

        # Update variable
        success = self.update(value, confidence, source="meta_resolution")

        # Record resolution
        if success:
            resolution_record = {
                "timestamp": datetime.now(timezone.utc),
                "method": self.aggregation_method.name,
                "input_proposals": len(proposals_to_use),
                "output_value": value,
                "output_confidence": confidence,
                "had_conflict": len(proposals_to_use) > 1,
            }
            self.resolution_history.append(resolution_record)

            # Keep history manageable
            if len(self.resolution_history) > 100:
                self.resolution_history = self.resolution_history[-100:]

            # Clear processed proposals
            self.proposals = []

        return success

    def _aggregate(self, proposals: list[ValueProposal]) -> tuple[Any, float]:
        """
        Aggregate multiple proposals into a single value.

        Parameters
        ----------
        proposals : list[ValueProposal]
            List of value proposals to aggregate.

        Returns
        -------
        tuple[Any, float]
            Aggregated value and confidence.

        Raises
        ------
        ValueError
            If aggregation method is not implemented or fails.
        """
        if not proposals:
            raise ValueError("Cannot aggregate empty proposal list")

        # Single proposal case
        if len(proposals) == 1:
            proposal = proposals[0]
            return proposal.value, proposal.confidence

        # Multiple proposals - apply aggregation method
        if self.aggregation_method == AggregationMethod.MEAN:
            return self._aggregate_mean(proposals)
        elif self.aggregation_method == AggregationMethod.MEDIAN:
            return self._aggregate_median(proposals)
        elif self.aggregation_method == AggregationMethod.WEIGHTED_MEAN:
            return self._aggregate_weighted_mean(proposals)
        elif self.aggregation_method == AggregationMethod.MAX_CONFIDENCE:
            return self._aggregate_max_confidence(proposals)
        elif self.aggregation_method == AggregationMethod.CONSENSUS:
            return self._aggregate_consensus(proposals)
        else:
            raise ValueError(f"Unknown aggregation method: {self.aggregation_method}")

    def _aggregate_mean(self, proposals: list[ValueProposal]) -> tuple[float, float]:
        """Aggregate using arithmetic mean."""
        values = [p.value for p in proposals]
        confidences = [p.confidence for p in proposals]

        # Assume values are numeric
        try:
            mean_value = sum(values) / len(values)
            mean_confidence = sum(confidences) / len(confidences)
            return mean_value, mean_confidence
        except TypeError:
            # For non-numeric values, fall back to max confidence
            return self._aggregate_max_confidence(proposals)

    def _aggregate_median(self, proposals: list[ValueProposal]) -> tuple[float, float]:
        """Aggregate using median."""
        try:
            values = [p.value for p in proposals]
            confidences = [p.confidence for p in proposals]

            # Sort by value
            sorted_pairs = sorted(
                zip(values, confidences, strict=False), key=lambda x: x[0]
            )
            values_sorted, confidences_sorted = zip(*sorted_pairs, strict=False)

            # Calculate median
            n = len(values_sorted)
            if n % 2 == 1:
                median_value = values_sorted[n // 2]
                median_confidence = confidences_sorted[n // 2]
            else:
                idx1, idx2 = n // 2 - 1, n // 2
                median_value = (values_sorted[idx1] + values_sorted[idx2]) / 2
                median_confidence = (
                    confidences_sorted[idx1] + confidences_sorted[idx2]
                ) / 2

            return median_value, median_confidence
        except (TypeError, ZeroDivisionError):
            return self._aggregate_max_confidence(proposals)

    def _aggregate_weighted_mean(
        self, proposals: list[ValueProposal]
    ) -> tuple[float, float]:
        """Aggregate using confidence-weighted mean."""
        try:
            values = [p.value for p in proposals]
            confidences = [p.confidence for p in proposals]

            # Weight values by confidence
            weighted_sum = sum(v * c for v, c in zip(values, confidences, strict=False))
            total_confidence = sum(confidences)

            if total_confidence == 0:
                return self._aggregate_mean(proposals)

            weighted_mean = weighted_sum / total_confidence
            avg_confidence = total_confidence / len(confidences)

            return weighted_mean, avg_confidence
        except (TypeError, ZeroDivisionError):
            return self._aggregate_max_confidence(proposals)

    def _aggregate_max_confidence(
        self, proposals: list[ValueProposal]
    ) -> tuple[Any, float]:
        """Select proposal with maximum confidence."""
        best_proposal = max(proposals, key=lambda p: p.confidence)
        return best_proposal.value, best_proposal.confidence

    def _aggregate_consensus(self, proposals: list[ValueProposal]) -> tuple[Any, float]:
        """
        Find consensus among proposals.

        Looks for clusters of similar values and selects the largest cluster.
        """
        # Simple implementation: group similar values
        tolerance = 0.1  # 10% tolerance for numeric values

        try:
            # Group similar values
            groups: list[list[ValueProposal]] = []
            for proposal in proposals:
                placed = False
                for group in groups:
                    # Check if value is similar to group mean
                    group_values = [p.value for p in group]
                    group_mean = sum(group_values) / len(group_values)

                    # Calculate relative difference
                    if proposal.value == 0 and group_mean == 0:
                        rel_diff = 0
                    elif proposal.value == 0 or group_mean == 0:
                        rel_diff = abs(proposal.value - group_mean)
                    else:
                        rel_diff = abs((proposal.value - group_mean) / group_mean)

                    if rel_diff <= tolerance:
                        group.append(proposal)
                        placed = True
                        break

                if not placed:
                    groups.append([proposal])

            # Find largest group
            largest_group = max(groups, key=len)

            # Use weighted mean of largest group
            return self._aggregate_weighted_mean(largest_group)
        except Exception:
            # Fall back to max confidence
            return self._aggregate_max_confidence(proposals)

    def detect_conflict(self, threshold: float = 0.5) -> bool:
        """
        Detect if proposals contain significant conflicts.

        Parameters
        ----------
        threshold : float, optional
            Confidence threshold for considering a conflict (default: 0.5).

        Returns
        -------
        bool
            True if significant conflict detected.
        """
        if len(self.proposals) < 2:
            return False

        high_conf_proposals = [p for p in self.proposals if p.confidence >= threshold]

        if len(high_conf_proposals) < 2:
            return False

        # Delegate to a helper method that can be tested separately
        try:
            return self._check_numeric_conflict(high_conf_proposals)
        except Exception:
            # Now we can test this by mocking _check_numeric_conflict to raise Exception
            return self._check_string_conflict(high_conf_proposals)

    def _check_numeric_conflict(self, proposals: list[ValueProposal]) -> bool:
        """Check for numeric conflicts (can raise exceptions)."""
        values = [p.value for p in proposals]

        if all(v == values[0] for v in values):
            return False

        if all(isinstance(v, int | float | np.number) for v in values):
            avg = sum(values) / len(values)
            max_deviation = max(abs(v - avg) for v in values)
            rel_diff = max_deviation / abs(avg + 1e-10)
            if rel_diff > 0.1:
                return True
            else:
                return False

        # Not all numeric, can't use numeric check
        raise ValueError("Not all values are numeric")

    def _check_string_conflict(self, proposals: list[ValueProposal]) -> bool:
        """Fallback string comparison."""
        proposal_list = [str(p.value) for p in proposals]
        return len(set(proposal_list)) > 1

    def validate(self, value: Any) -> bool:
        """
        Validate a value for this meta-variable.

        Parameters
        ----------
        value : Any
            Value to validate.

        Returns
        -------
        bool
            True if value is valid.
        """
        # Meta-variables typically have broad validation
        # Subclasses can override for specific validation
        return value is not None

    def to_dict(self) -> dict[str, Any]:
        """Convert meta-variable to dictionary."""
        base_dict = super().to_dict()
        base_dict.update(
            {
                "type": "MetaVariable",
                "aggregation_method": self.aggregation_method.name,
                "conflict_strategy": self.conflict_strategy.name,
                "proposals_count": len(self.proposals),
                "resolution_history_count": len(self.resolution_history),
            }
        )
        return base_dict
