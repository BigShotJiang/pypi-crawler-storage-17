"""VariableReasoner for implementing reasoning capabilities on variables."""
