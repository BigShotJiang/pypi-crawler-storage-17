"""Stochastic Variable implementations for probabilistic reasoning."""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, TypeAlias, overload

import numpy as np
from scipy import stats
from scipy.stats._distn_infrastructure import rv_continuous_frozen, rv_discrete_frozen

from ...utils.logging import get_logger
from .base import Variable, VariableRole
from .random import FloatArray, IntArray, Number, RandomState, RandomStateManager

logger = get_logger(__name__)

# Type-safe aliases for better type checking
FloatOrArray: TypeAlias = float | FloatArray


class DistributionType(Enum):
    """
    Enumeration of probability distribution types supported by CausaLoop.

    Defines the statistical distributions that can be used to model stochastic
    variables' uncertainty. Each distribution type represents a family of
    probability distributions characterized by specific parameters and properties.

    Attributes
    ----------
    NORMAL : DistributionType
        Normal (Gaussian) distribution. Characterized by mean (mu) and standard
        deviation (sigma). Symmetric, bell-shaped curve. Suitable for modeling
        measurement errors, natural variations, and quantities affected by
        many small independent factors.

    UNIFORM : DistributionType
        Uniform distribution. Characterized by lower and upper bounds.
        Constant probability density between bounds, zero elsewhere. Suitable
        for modeling complete uncertainty within known bounds or random
        selection from a finite interval.

    EXPONENTIAL : DistributionType
        Exponential distribution. Characterized by rate (lambda)
        or scale (beta = 1/lambda).
        Models time between events in Poisson processes. Memoryless property.
        Suitable for waiting times, failure times, and inter-arrival times.

    BETA : DistributionType
        Beta distribution. Characterized by shape parameters alpha and beta.
        Defined on interval [0, 1]. Flexible shape for modeling probabilities
        and proportions. Conjugate prior for Bernoulli and binomial distributions.

    GAMMA : DistributionType
        Gamma distribution. Characterized by shape (k) and scale (theta) parameters.
        Generalization of exponential and chi-squared distributions. Suitable
        for waiting times, rainfall amounts, and insurance claim modeling.

    POISSON : DistributionType
        Poisson distribution. Characterized by rate parameter lambda.
        Discrete distribution for counting events in fixed interval.
        Suitable for rare event counts, arrival processes, and defect counts.

    BERNOULLI : DistributionType
        Bernoulli distribution. Characterized by success probability p.
        Binary outcome distribution (0 or 1). Fundamental building block for
        binary classification and success/failure modeling.

    CATEGORICAL : DistributionType
        Categorical (multinoulli) distribution. Characterized by probability
        vector over finite set of categories. Generalization of Bernoulli
        to multiple discrete outcomes.

    MIXTURE : DistributionType
        Mixture distribution. Weighted combination of other distributions.
        Flexible modeling of multi-modal data and heterogeneous populations.

    EMPIRICAL : DistributionType
        Empirical distribution. Derived directly from observed data.
        Non-parametric representation using observed samples or histogram.

    Notes
    -----
    Distribution types are used in conjunction with DistributionParameters
    to fully specify a probability distribution. Each type requires specific
    parameters as defined by standard statistical notation.

    For Bayesian inference, certain distributions serve as conjugate priors:
    - Beta is conjugate prior for Bernoulli/Binomial
    - Gamma is conjugate prior for Poisson
    - Normal is conjugate prior for Normal with known variance

    Examples
    --------
    >>> from causaloop import DistributionType
    >>>
    >>> # Common distributions for different modeling scenarios
    >>> measurement_error = DistributionType.NORMAL
    >>> unknown_bounded = DistributionType.UNIFORM
    >>> waiting_time = DistributionType.EXPONENTIAL
    >>> probability_estimate = DistributionType.BETA
    >>> count_data = DistributionType.POISSON
    >>> binary_outcome = DistributionType.BERNOULLI
    >>>
    >>> # Check if a distribution is continuous
    >>> continuous_dists = {
    ...     DistributionType.NORMAL,
    ...     DistributionType.UNIFORM,
    ...     DistributionType.EXPONENTIAL,
    ...     DistributionType.BETA,
    ...     DistributionType.GAMMA
    ... }
    >>>
    >>> # Check if a distribution is discrete
    >>> discrete_dists = {
    ...     DistributionType.POISSON,
    ...     DistributionType.BERNOULLI,
    ...     DistributionType.CATEGORICAL
    ... }
    """

    NORMAL = auto()
    """Normal (Gaussian) distribution: N(mu, sigma^2)."""

    UNIFORM = auto()
    """Uniform distribution: U(a, b)."""

    EXPONENTIAL = auto()
    """Exponential distribution: Exp(lambda)."""

    BETA = auto()
    """Beta distribution: Beta(alpha, beta)."""

    GAMMA = auto()
    """Gamma distribution: Gamma(k, theta)."""

    POISSON = auto()
    """Poisson distribution: Pois(lambda)."""

    BERNOULLI = auto()
    """Bernoulli distribution: Bern(p)."""

    CATEGORICAL = auto()
    """Categorical distribution: Cat(p_1, ..., p_k)."""

    MIXTURE = auto()
    """Mixture distribution: sum(W_i.Dist_i)."""

    EMPIRICAL = auto()
    """Empirical distribution from observed data."""


@dataclass
class DistributionParameters:
    """
    Container for probability distribution parameters.

    Encapsulates both the distribution type and its specific parameter values
    in a structured format. Provides factory methods for common distributions
    to ensure correct parameter naming and validation.

    Parameters
    ----------
    distribution_type : DistributionType
        Type of probability distribution (e.g., NORMAL, UNIFORM, EXPONENTIAL).

    parameters : dict[str, Any]
        Dictionary of parameter names to values. Must match the expected
        parameters for the specified distribution type.
        - NORMAL: {"mean": float, "std": float}
        - UNIFORM: {"low": float, "high": float}
        - EXPONENTIAL: {"scale": float} or {"rate": float}
        - BETA: {"alpha": float, "beta": float}
        - GAMMA: {"shape": float, "scale": float} or {"k": float, "theta": float}
        - POISSON: {"lambda": float} or {"rate": float}
        - BERNOULLI: {"p": float}
        - CATEGORICAL: {"probabilities": list[float]}
        - MIXTURE: {"weights": list[float], "components": list[DistributionParameters]}
        - EMPIRICAL: {"samples": list[float]} or {"histogram": dict}

    random_seed : int | None
        Random seed for reproducible sampling from this distribution.
        If None, uses the global deterministic random state.

    Attributes
    ----------
    distribution_type : DistributionType
        See Parameters section.

    parameters : dict[str, Any]
        See Parameters section.

    random_seed : int | None
        See Parameters section.

    Raises
    ------
    ValueError
        If parameters dictionary does not contain required keys for the
        specified distribution type, or if parameter values are invalid
        (e.g., negative standard deviation, low > high for uniform).

    Notes
    -----
    Parameter names follow standard statistical conventions where possible.
    Some distributions have multiple parameterizations (e.g., exponential
    can use rate lambda or scale beta = 1/lambda). The factory methods enforce
    consistent parameter naming.

    For mixture distributions, the weights should sum to 1. For categorical
    distributions, probabilities should sum to 1.

    The random_seed parameter ensures reproducible sampling. When specified,
    all samples from distributions using these parameters will be deterministic.

    Examples
    --------
    >>> from causaloop import DistributionParameters, DistributionType
    >>>
    >>> # Using factory methods with reproducibility
    >>> normal_params = DistributionParameters.normal(mean=0.0, std=1.0, seed=42)
    >>> uniform_params = DistributionParameters.uniform(low=0.0, high=10.0, seed=42)
    >>> exp_params = DistributionParameters.exponential(scale=2.0, seed=42)
    >>> beta_params = DistributionParameters.beta(alpha=2.0, beta=5.0, seed=42)
    >>>
    >>> # Direct instantiation
    >>> gamma_params = DistributionParameters(
    ...     distribution_type=DistributionType.GAMMA,
    ...     parameters={"shape": 3.0, "scale": 2.0},
    ...     random_seed=42
    ... )
    >>>
    >>> # Accessing parameters
    >>> print(f"Normal mean: {normal_params.parameters['mean']}")
    Normal mean: 0.0
    >>> print(f"Random seed: {normal_params.random_seed}")
    Random seed: 42
    """

    distribution_type: DistributionType
    parameters: dict[str, Any]
    random_seed: int | None = field(default=None, repr=False)

    @classmethod
    def normal(
        cls, mean: float, std: float, seed: int | None = None
    ) -> DistributionParameters:
        """
        Create parameters for a Gaussian distribution.

        Parameters
        ----------
        mean : float
            Mean (mu) of the normal distribution. Represents the central
            tendency or expected value.
        std : float
            Standard deviation (sigma) of the normal distribution. Must be positive.
            Represents the spread or uncertainty. Variance = sigma^2.
        seed : int | None
            Random seed for reproducible sampling. If None, uses global state.

        Returns
        -------
        DistributionParameters
            Parameters for N(mu, sigma^2) distribution.

        Raises
        ------
        ValueError
            If std is not positive.

        Examples
        --------
        >>> from causaloop import DistributionParameters
        >>> params = DistributionParameters.normal(mean=10.0, std=2.0, seed=42)
        >>> print(params.distribution_type)
        DistributionType.NORMAL
        >>> print(params.parameters["mean"])
        10.0
        >>> print(params.random_seed)
        42
        """
        if std <= 0:
            raise ValueError(f"Standard deviation must be positive, got {std}")

        return cls(
            distribution_type=DistributionType.NORMAL,
            parameters={"mean": mean, "std": std},
            random_seed=seed,
        )

    @classmethod
    def uniform(
        cls, low: float, high: float, seed: int | None = None
    ) -> DistributionParameters:
        """
        Create parameters for a uniform distribution.

        Parameters
        ----------
        low : float
            Lower bound of the uniform distribution (inclusive).
        high : float
            Upper bound of the uniform distribution (exclusive for continuous,
            inclusive definitions vary). Must be greater than low.
        seed : int | None
            Random seed for reproducible sampling.

        Returns
        -------
        DistributionParameters
            Parameters for U(low, high) distribution.

        Raises
        ------
        ValueError
            If high <= low.

        Examples
        --------
        >>> from causaloop import DistributionParameters
        >>> params = DistributionParameters.uniform(low=0.0, high=1.0, seed=42)
        >>> print(params.parameters["low"])
        0.0
        >>> print(params.parameters["high"])
        1.0
        """
        if high <= low:
            raise ValueError(
                f"high must be greater than low, got low={low}, high={high}"
            )

        return cls(
            distribution_type=DistributionType.UNIFORM,
            parameters={"low": low, "high": high},
            random_seed=seed,
        )

    @classmethod
    def exponential(
        cls, scale: float, seed: int | None = None
    ) -> DistributionParameters:
        """
        Create parameters for an exponential distribution.

        Uses scale parameterization: f(x; beta) = (1/beta)exp(-x/beta) for x ≥ 0.
        Alternative rate parameterization: lambda = 1/beta.

        Parameters
        ----------
        scale : float
            Scale parameter (beta). Must be positive. Mean = beta, variance = beta^2.
            Equivalent to 1/sigma where sigma is the rate parameter.
        seed : int | None
            Random seed for reproducible sampling.

        Returns
        -------
        DistributionParameters
            Parameters for Exp(beta) distribution.

        Raises
        ------
        ValueError
            If scale is not positive.

        Examples
        --------
        >>> from causaloop import DistributionParameters
        >>> params = DistributionParameters.exponential(scale=5.0, seed=42)
        >>> print(params.parameters["scale"])
        5.0
        """
        if scale <= 0:
            raise ValueError(f"Scale parameter must be positive, got {scale}")

        return cls(
            distribution_type=DistributionType.EXPONENTIAL,
            parameters={"scale": scale},
            random_seed=seed,
        )

    @classmethod
    def beta(
        cls, alpha: float, beta: float, seed: int | None = None
    ) -> DistributionParameters:
        """
        Create parameters for a beta distribution.

        Parameters
        ----------
        alpha : float
            First shape parameter (alpha). Must be positive. Often interpreted as
            "number of successes + 1" in Bayesian context.
        beta : float
            Second shape parameter (beta). Must be positive. Often interpreted as
            "number of failures + 1" in Bayesian context.
        seed : int | None
            Random seed for reproducible sampling.

        Returns
        -------
        DistributionParameters
            Parameters for Beta(alpha, beta) distribution.

        Raises
        ------
        ValueError
            If alpha or beta is not positive.

        Notes
        -----
        The beta distribution is defined on [0, 1]. Mean = alpha/(alpha+beta).
        Useful as conjugate prior for Bernoulli and binomial distributions.

        Examples
        --------
        >>> from causaloop import DistributionParameters
        >>> params = DistributionParameters.beta(alpha=2.0, beta=5.0, seed=42)
        >>> print(params.parameters["alpha"])
        2.0
        """
        if alpha <= 0:
            raise ValueError(f"Alpha must be positive, got {alpha}")
        if beta <= 0:
            raise ValueError(f"Beta must be positive, got {beta}")

        return cls(
            distribution_type=DistributionType.BETA,
            parameters={"alpha": alpha, "beta": beta},
            random_seed=seed,
        )

    @classmethod
    def gamma(
        cls, k: float, theta: float, seed: int | None = None
    ) -> DistributionParameters:
        """
        Create parameters for a gamma distribution.

        Parameters
        ----------
        k : float
            Shape parameter of the distribution.
        theta : float
            Scale parameter of the distribution.
        seed : int | None
            Random seed for reproducible sampling.

        Returns
        -------
        DistributionParameters
            Parameters for Gamma(k, theta) distribution.

        Raises
        ------
        ValueError
            If k or theta is not positive.

        Examples
        --------
        >>> from causaloop import DistributionParameters
        >>> params = DistributionParameters.gamma(k=1.0, theta=1.0, seed=42)
        >>> params.parameters['k']
        1.0
        """
        if k < 0:
            raise ValueError(f"K must be positive, got {k}")
        if theta < 0:
            raise ValueError(f"Theta must be positive, got {theta}")

        return cls(
            distribution_type=DistributionType.GAMMA,
            parameters={"k": k, "theta": theta},
            random_seed=seed,
        )

    @classmethod
    def poisson(cls, lam: float, seed: int | None = None) -> DistributionParameters:
        """
        Create parameters for a poisson distribution.

        Parameters
        ----------
        lam : float
            Rate parameter of the distribution.
        seed : int | None
            Random seed for reproducible sampling.

        Returns
        -------
        DistributionParameters
            Parameters for Pois(lambda) distribution.

        Raises
        ------
        ValueError
            If lambda is not positive.

        Examples
        --------
        >>> from causaloop import DistributionParameters
        >>> params = DistributionParameters.poisson(lam=10.0, seed=42)
        >>> print(params.distribution_type)
        DistributionType.POISSON
        """
        if lam < 0:
            raise ValueError(f"lambda must be positive, got {lam}")

        return cls(
            distribution_type=DistributionType.POISSON,
            parameters={"lambda": lam},
            random_seed=seed,
        )

    @classmethod
    def bernoulli(cls, p: float, seed: int | None = None) -> DistributionParameters:
        """
        Create parameters for a bernoulli distribution.

        Parameters
        ----------
        p : float
            Success probability of the distribution.
        seed : int | None
            Random seed for reproducible sampling.

        Returns
        -------
        DistributionParameters
            Parameters for Bern(p) distribution.

        Raises
        ------
        ValueError
            If p is not between 0 and 1.

        Examples
        --------
        >>> from causaloop import DistributionParameters
        >>> params = DistributionParameters.bernoulli(p=0.3, seed=42)
        >>> print(params.distribution_type, params.random_seed)
        DistributionType.BERNOULLI 42
        """
        if p < 0.0:
            raise ValueError(f"Parameter `p` must be positive, got {p}")
        if p > 1.0:
            raise ValueError(f"Parameter `p` must be <= 1.0, got {p}")

        return cls(
            distribution_type=DistributionType.BERNOULLI,
            parameters={"p": p},
            random_seed=seed,
        )

    @classmethod
    def categorical(
        cls, probabilities: list[float], seed: int | None = None
    ) -> DistributionParameters:
        """
        Create parameters for a categorical distribution.

        Parameters
        ----------
        probabilities : list[float]
            List of the robabilities of the distribution.
        seed : int | None
            Random seed for reproducible sampling.

        Returns
        -------
        DistributionParameters
            Parameters for Cat(p_1, ..., p_k) distribution.

        Raises
        ------
        ValueError
            If p_i is not between 0 and 1 and sum(p_i) is not 1.

        Examples
        --------
        >>> from causaloop import DistributionParameters
        >>> params = DistributionParameters.categorical(
        ...     probabilities=[0.3, 0.2, 0.5], seed=42
        ... )
        >>> print(params.parameters['probabilities'])
        [0.3, 0.2, 0.5]
        """
        for i, p in enumerate(probabilities):
            if p < 0.0:
                raise ValueError(f"Probability p_{i} must be positive, got {p}")
            if p > 1.0:
                raise ValueError(f"Probability p_{i} must be <= 1.0, got {p}")
        if sum(probabilities) != 1.0:
            raise ValueError("Sum of the probabilities should be equal to 1.")

        return cls(
            distribution_type=DistributionType.CATEGORICAL,
            parameters={"probabilities": probabilities},
            random_seed=seed,
        )

    @classmethod
    def mixture(
        cls,
        weights: list[float],
        components: list[DistributionParameters],
        seed: int | None = None,
    ) -> DistributionParameters:
        """
        Create parameters for a categorical distribution.

        Parameters
        ----------
        probabilities : list[float]
            List of the robabilities of the distribution.
        seed : int | None
            Random seed for reproducible sampling.

        Returns
        -------
        DistributionParameters
            Parameters for mixture distribution.

        Raises
        ------
        ValueError
            If p_i is not between 0 and 1 and sum(p_i) is not 1.

        Examples
        --------
        >>> from causaloop import DistributionParameters
        >>> params1 = DistributionParameters.normal(mean=5.0, std=2.0, seed=42)
        >>> params2 = DistributionParameters.normal(mean=15.0, std=1.0, seed=42)
        >>> params = DistributionParameters.mixture(
        ...     weights=[0.4, 0.6], components=[params1, params2], seed=42
        ... )
        >>> print(params.parameters['components'][1])
        NORMAL(mean=15.0, std=1.0, seed=42)
        """
        for i, w in enumerate(weights):
            if w < 0.0:
                raise ValueError(f"Weight w_{i} must be positive, got {w}")

        return cls(
            distribution_type=DistributionType.MIXTURE,
            parameters={"weights": weights, "components": components},
            random_seed=seed,
        )

    @classmethod
    def empirical(
        cls, samples: list[float], seed: int | None = None
    ) -> DistributionParameters:
        """
        Create parameters for an empirical distribution.

        Parameters
        ----------
        samples : list[float]
            List of the samples of the distribution.
        seed : int | None
            Random seed for reproducible sampling.

        Returns
        -------
        DistributionParameters
            Parameters for empirical distribution.

        Raises
        ------
        ValueError
            If samples is empty.

        Examples
        --------
        >>> from causaloop import DistributionParameters
        >>> params = DistributionParameters.empirical(
        ...     samples=[3, 5, -1, 5, 3], seed=42
        ... )
        >>> print(params.parameters['samples'])
        [3, 5, -1, 5, 3]
        """
        if not samples:
            raise ValueError("Samples should not be empty")

        return cls(
            distribution_type=DistributionType.EMPIRICAL,
            parameters={"samples": samples},
            random_seed=seed,
        )

    def validate(self) -> bool:
        """
        Validate that parameters are appropriate for the distribution type.

        Returns
        -------
        bool
            True if parameters are valid for the specified distribution type.

        Raises
        ------
        ValueError
            If required parameters are missing or have invalid values.

        Examples
        --------
        >>> from causaloop.core.variable.stochastic import DistributionParameters
        >>> params = DistributionParameters.normal(mean=0.0, std=1.0)
        >>> params.validate()  # Should pass
        True
        """
        required_params = {
            DistributionType.NORMAL: {"mean", "std"},
            DistributionType.UNIFORM: {"low", "high"},
            DistributionType.EXPONENTIAL: {"scale"},
            DistributionType.BETA: {"alpha", "beta"},
            DistributionType.GAMMA: {"k", "theta"},
            DistributionType.POISSON: {"lambda"},
            DistributionType.BERNOULLI: {"p"},
            DistributionType.CATEGORICAL: {"probabilities"},
            DistributionType.MIXTURE: {"weights", "components"},
            DistributionType.EMPIRICAL: {"samples"},
        }

        if self.distribution_type in required_params:
            required = required_params[self.distribution_type]
            missing = required - set(self.parameters.keys())
            if missing:
                raise ValueError(
                    f"{self.distribution_type.name} distribution requires "
                    f"parameters: {missing}"
                )

        return True

    def get_random_state(self) -> RandomState:
        """
        Get a reproducible random state for this distribution.

        Returns
        -------
        RandomState
            Random state initialized with this distribution's seed.
            If no seed was specified, returns the global deterministic state.

        Examples
        --------
        >>> from causaloop import DistributionParameters
        >>> params = DistributionParameters.normal(mean=0, std=1, seed=42)
        >>> rng = params.get_random_state()
        >>> samples = rng.normal(size=10)  # Reproducible sampling
        """
        if self.random_seed is not None:
            return RandomState(seed=self.random_seed)
        return RandomStateManager().get_deterministic_state()

    def __str__(self) -> str:
        """Representation of distribution parameters."""
        param_str = ", ".join(f"{k}={v}" for k, v in self.parameters.items())
        seed_str = f", seed={self.random_seed}" if self.random_seed is not None else ""
        return f"{self.distribution_type.name}({param_str}{seed_str})"

    def __repr__(self) -> str:
        """Detailed representation of distribution parameters."""
        return (
            f"DistributionParameters("
            f"distribution_type={self.distribution_type}, "
            f"parameters={self.parameters}, "
            f"random_seed={self.random_seed})"
        )


class StochasticVariable(Variable, ABC):
    """
    Base class for stochastic (probabilistic) variables.

    Represents variables with inherent uncertainty modeled via probability
    distributions. Supports sampling, density estimation, and Bayesian updates.

    In CausaLoop, stochastic variables are active reasoning entities that:
    1. Maintain probabilistic beliefs about their values
    2. Can resolve conflicts between competing causal mechanisms
    3. Can suggest optimal interventions based on their uncertainty
    4. Compute reliability metrics from their distribution properties
    5. Learn from historical data to improve their probabilistic models
    6. Guarantee reproducible sampling through isolated random states

    Attributes
    ----------
    distribution_params : DistributionParameters | None
        Parameters defining the probability distribution.
    samples : list[float]
        History of sampled values.
    _distribution : stats.rv_continuous | stats.rv_discrete | None
        Internal scipy distribution object.
    _random_state : RandomState
        Isolated random state for reproducible sampling.
    _current_random_seed : int | None
        Current random seed if deterministic.
    _random_state_checkpoints : dict[str, str]
        Mapping of checkpoint names to checkpoint IDs.

    Examples
    --------
    >>> import numpy as np
    >>> from causaloop import StochasticVariable, VariableRole
    >>>
    >>> class TemperatureSensor(StochasticVariable):
    ...     def __init__(self, name: str, true_temp: float, noise_std: float):
    ...         super().__init__(name, role=VariableRole.OBSERVATION)
    ...         self.true_temp = true_temp
    ...         self.noise_std = noise_std
    ...
    ...     def sample(self, n: int = 1) -> np.ndarray:
    ...         noise = self._random_state.normal(0, self.noise_std, n)
    ...         return self.true_temp + noise
    ...
    >>> sensor = TemperatureSensor("temp_sensor", 22.0, 0.5)
    >>> sensor.set_random_seed(42)  # Ensure reproducibility
    >>> samples = sensor.sample(1000)
    >>> print(f"Mean: {samples.mean():.2f}, Std: {samples.std():.2f}")
    Mean: 22.01, Std: 0.49
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        units: str | None = None,
        role: VariableRole = VariableRole.ENDOGENOUS,
        distribution_params: DistributionParameters | None = None,
        config: dict[str, Any] | None = None,
        random_seed: int | None = None,
    ) -> None:
        """
        Initialize a stochastic variable with reproducibility support.

        Parameters
        ----------
        name : str
            Variable name.
        description : str, optional
            Human-readable description.
        units : str, optional
            Physical units.
        role : VariableRole, optional
            Role in causal relationships.
        distribution_params : DistributionParameters | None, optional
            Parameters defining the probability distribution.
        config : dict[str, Any] | None, optional
            Configuration dictionary.
        random_seed : int | None, optional
            Random seed for reproducible sampling. If provided, ensures
            deterministic behavior. Takes precedence over seed in distribution_params.

        Raises
        ------
        ValueError
            If random_seed is provided but not an integer.
        """
        super().__init__(
            name=name,
            description=description,
            units=units,
            role=role,
            config=config,
        )

        self.distribution_params = distribution_params
        self.samples: list[float] = []
        self._distribution: (
            stats.rv_continuous
            | rv_continuous_frozen
            | stats.rv_discrete
            | rv_discrete_frozen
            | None
        ) = None
        self._random_state_checkpoints: dict[str, str] = {}

        # Initialize reproducible random state
        self._initialize_random_state(random_seed)

        # Initialize distribution if parameters provided
        self._initialize_distribution()

    def _initialize_random_state(self, random_seed: int | None) -> None:
        """
        Initialize reproducible random state for this variable.

        Parameters
        ----------
        random_seed : int | None
            Random seed for deterministic behavior. If None, uses seed from
            distribution_params or creates non-deterministic state.

        Raises
        ------
        ValueError
            If random_seed is provided but not an integer.
        """
        # Determine the seed to use (explicit seed takes precedence)
        final_seed = random_seed

        if final_seed is None and self.distribution_params:
            # Use seed from distribution parameters if available
            final_seed = self.distribution_params.random_seed

        # Create reproducible random state
        label = f"variable_{self.name}"
        self._random_state = RandomState(seed=final_seed, label=label)
        self._current_random_seed = final_seed

        logger.debug(
            "Initialized random state for variable '%s' with seed %s",
            self.name,
            final_seed,
        )

    def _initialize_distribution(self) -> None:
        """Initialize the scipy distribution from parameters."""
        if self.distribution_params is None:
            return

        # Validate the distribution parameters
        self.distribution_params.validate()

        dist_type = self.distribution_params.distribution_type
        params = self.distribution_params.parameters

        try:
            if dist_type == DistributionType.NORMAL:
                self._distribution = stats.norm(loc=params["mean"], scale=params["std"])
            elif dist_type == DistributionType.UNIFORM:
                self._distribution = stats.uniform(
                    loc=params["low"], scale=params["high"] - params["low"]
                )
            elif dist_type == DistributionType.EXPONENTIAL:
                self._distribution = stats.expon(scale=params["scale"])
            elif dist_type == DistributionType.BETA:
                self._distribution = stats.beta(a=params["alpha"], b=params["beta"])
            elif dist_type == DistributionType.GAMMA:
                self._distribution = stats.gamma(a=params["k"], scale=params["theta"])
            elif dist_type == DistributionType.POISSON:
                self._distribution = stats.poisson(mu=params["lambda"])
            elif dist_type == DistributionType.BERNOULLI:
                self._distribution = stats.bernoulli(p=params["p"])
            else:
                logger.warning(
                    "Distribution type %s not fully implemented for %s",
                    dist_type.name,
                    self.name,
                )
        except Exception as e:
            logger.error(
                "Failed to initialize distribution for %s: %s", self.name, str(e)
            )

    def set_random_seed(self, seed: int) -> None:
        """
        Set random seed for reproducible sampling.

        This is essential for:
        - Debugging causal relationships
        - Validating counterfactual scenarios
        - Reproducing optimization results
        - Scientific validation

        Parameters
        ----------
        seed : int
            Random seed to use for all future sampling.

        Raises
        ------
        ValueError
            If seed is not an integer.

        Examples
        --------
        >>> variable.set_random_seed(42)
        >>> samples1 = variable.sample(100)
        >>> variable.set_random_seed(42)  # Reset to same seed
        >>> samples2 = variable.sample(100)  # Identical to samples1
        """
        if not isinstance(seed, int):
            raise ValueError(f"Seed must be integer, got {type(seed)}")

        self._random_state.seed(seed)
        self._current_random_seed = seed
        logger.debug("Variable '%s' random seed set to %s", self.name, seed)

    def checkpoint_random_state(self, name: str = "default") -> str:
        """
        Create a checkpoint of the current random state.

        This allows for:
        - Replaying specific causal scenarios
        - Debugging stochastic behavior
        - Comparing different intervention strategies
        - Serializing simulation state

        Parameters
        ----------
        name : str
            Name for this checkpoint.

        Returns
        -------
        str
            Checkpoint ID that can be used to restore state.

        Examples
        --------
        >>> checkpoint = variable.checkpoint_random_state("before_intervention")
        >>> # ... perform causal operations ...
        >>> variable.restore_random_state(checkpoint)  # Back to pre-intervention state
        """
        checkpoint_id = self._random_state.checkpoint(name)
        self._random_state_checkpoints[name] = checkpoint_id
        return checkpoint_id

    def restore_random_state(self, checkpoint_id: str) -> bool:
        """
        Restore random state from checkpoint.

        Parameters
        ----------
        checkpoint_id : str
            Checkpoint ID to restore.

        Returns
        -------
        bool
            True if restoration was successful.

        Examples
        --------
        >>> checkpoint = variable.checkpoint_random_state("state1")
        >>> variable.restore_random_state(checkpoint)
        True
        """
        return self._random_state.restore_checkpoint(checkpoint_id)

    def get_random_state_info(self) -> dict[str, Any]:
        """
        Get information about current random state.

        Returns
        -------
        dict[str, Any]
            Dictionary with random state information for debugging.

        Examples
        --------
        >>> info = variable.get_random_state_info()
        >>> print(info['random_seed'])
        42
        """
        return {
            "variable_name": self.name,
            "random_seed": self._current_random_seed,
            "checkpoints": list(self._random_state_checkpoints.keys()),
            "samples_generated": len(self.samples),
            "distribution_type": (
                self.distribution_params.distribution_type.name
                if self.distribution_params
                else None
            ),
        }

    @abstractmethod
    def sample(self, n: int = 1) -> FloatArray | IntArray:
        """
        Sample from the variable's distribution with reproducibility.

        Parameters
        ----------
        n : int, optional
            Number of samples to draw.

        Returns
        -------
        FloatArray | IntArray
            Array of samples with appropriate dtype (float64 for continuous,
            int64 for discrete distributions).

        Notes
        -----
        This method guarantees reproducible results when:
        1. Random seed is set via set_random_seed()
        2. Random state checkpoints are used
        3. Sampling order is preserved
        4. No external random operations interfere

        Examples
        --------
        >>> variable.set_random_seed(42)
        >>> samples1 = variable.sample(100)
        >>> variable.set_random_seed(42)  # Reset to same seed
        >>> samples2 = variable.sample(100)  # Will be identical to samples1
        """
        pass

    @overload
    def pdf(self, x: float) -> float: ...

    @overload
    def pdf(self, x: FloatArray) -> FloatArray: ...

    def pdf(self, x: FloatOrArray) -> FloatOrArray:
        """
        Calculate probability density at given point(s).

        Parameters
        ----------
        x : float | FloatArray
            Point(s) at which to evaluate density.

        Returns
        -------
        float | FloatArray
            Probability density.

        Raises
        ------
        ValueError
            If no distribution is defined.

        Examples
        --------
        >>> density = variable.pdf(0.5)
        >>> densities = variable.pdf(np.array([0.1, 0.5, 0.9]))
        """
        if self._distribution is None:
            raise ValueError(f"No distribution defined for {self.name}")

        if isinstance(self._distribution, stats.rv_continuous | rv_continuous_frozen):
            result = self._distribution.pdf(x)
        else:
            result = self._distribution.pmf(x)

        if isinstance(x, float) and isinstance(result, np.ndarray) and result.size == 1:
            return float(result[0])
        elif isinstance(x, float):
            return float(result)
        else:
            return np.asarray(result, dtype=np.float64)

    @overload
    def cdf(self, x: float) -> float: ...

    @overload
    def cdf(self, x: FloatArray) -> FloatArray: ...

    def cdf(self, x: FloatOrArray) -> FloatOrArray:
        """
        Calculate cumulative probability up to given point(s).

        Parameters
        ----------
        x : float | FloatArray
            Point(s) at which to evaluate CDF.

        Returns
        -------
        float | FloatArray
            Cumulative probability.

        Raises
        ------
        ValueError
            If no distribution is defined.

        Examples
        --------
        >>> prob = variable.cdf(0.5)
        >>> probs = variable.cdf(np.array([0.1, 0.5, 0.9]))
        """
        if self._distribution is None:
            raise ValueError(f"No distribution defined for {self.name}")

        result = self._distribution.cdf(x)
        if isinstance(x, float) and isinstance(result, np.ndarray) and result.size == 1:
            return float(result[0])
        elif isinstance(x, float):
            return float(result)
        else:
            return np.asarray(result, dtype=np.float64)

    @overload
    def quantile(self, q: float) -> float: ...

    @overload
    def quantile(self, q: FloatArray) -> FloatArray: ...

    def quantile(self, q: FloatOrArray) -> FloatOrArray:
        """
        Calculate quantiles for given probability/probabilities.

        Parameters
        ----------
        q : float | FloatArray
            Probability/probabilities (between 0 and 1).

        Returns
        -------
        float | FloatArray
            Quantile values.

        Raises
        ------
        ValueError
            If no distribution is defined.
        ValueError
            If q is outside [0, 1].

        Examples
        --------
        >>> median = variable.quantile(0.5)
        >>> quartiles = variable.quantile(np.array([0.25, 0.5, 0.75]))
        """
        if self._distribution is None:
            raise ValueError(f"No distribution defined for {self.name}")

        # Validate probabilities
        if isinstance(q, float):
            if q < 0 or q > 1:
                raise ValueError(f"Probability must be in [0, 1], got {q}")
        else:
            if np.any(q < 0) or np.any(q > 1):
                raise ValueError("All probabilities must be in [0, 1]")

        result = self._distribution.ppf(q)
        if isinstance(q, float) and isinstance(result, np.ndarray) and result.size == 1:
            return float(result[0])
        elif isinstance(q, float):
            return float(result)
        else:
            return np.asarray(result, dtype=np.float64)

    def entropy(self) -> float | None:
        """
        Calculate entropy of the distribution.

        Returns
        -------
        float | None
            Entropy in nats, or None if not calculable.

        Examples
        --------
        >>> entropy = variable.entropy()
        >>> if entropy is not None:
        ...     print(f"Entropy: {entropy:.3f} nats")
        """
        if self._distribution is None:
            return None

        try:
            result = self._distribution.entropy()
            return float(result)
        except (AttributeError, NotImplementedError):
            return None

    def kl_divergence(self, other: StochasticVariable) -> float | None:
        """
        Calculate KL divergence between this and another distribution.

        Parameters
        ----------
        other : StochasticVariable
            Other distribution to compare with.

        Returns
        -------
        float | None
            KL divergence in nats, or None if not calculable.

        Notes
        -----
        This is a Monte Carlo approximation if analytical solution not available.

        Examples
        --------
        >>> divergence = variable1.kl_divergence(variable2)
        >>> if divergence is not None:
        ...     print(f"KL divergence: {divergence:.3f}")
        """
        if self._distribution is None or other._distribution is None:
            return None

        try:
            # Sample from this distribution
            raw_samples = self.sample(10000)

            # Convert to float64 for PDF evaluation
            # np.asarray handles both FloatArray and IntArray
            samples = np.asarray(raw_samples, dtype=np.float64)

            log_p = np.log(self.pdf(samples) + 1e-10)
            log_q = np.log(other.pdf(samples) + 1e-10)
            # Monte Carlo estimate
            kl_estimate = float(np.mean(log_p - log_q))

            # Sanity check
            if not np.isfinite(kl_estimate):
                logger.warning(
                    "KL divergence non-finite for %s vs %s",
                    self.name,
                    other.name,
                )
                return None

            return kl_estimate
        except Exception as e:
            logger.warning(
                "KL divergence calculation failed for %s vs %s: %s",
                self.name,
                other.name,
                str(e),
            )
            return None

    def bayesian_update(
        self, observation: float, observation_variance: float = 1.0
    ) -> bool:
        """
        Perform Bayesian update given an observation.

        Parameters
        ----------
        observation : float
            Observed value.
        observation_variance : float, optional
            Variance of the observation noise.

        Returns
        -------
        bool
            True if update was successful.

        Notes
        -----
        Currently only implements conjugate prior update for normal distributions.

        Examples
        --------
        >>> variable.bayesian_update(observation=22.5, observation_variance=0.1)
        True
        """
        if self.distribution_params is None:
            return False

        if self.distribution_params.distribution_type != DistributionType.NORMAL:
            logger.warning(
                "Bayesian update only implemented for normal distributions, not %s",
                self.distribution_params.distribution_type.name,
            )
            return False

        # Extract current parameters
        params = self.distribution_params.parameters
        prior_mean = params["mean"]
        prior_std = params["std"]
        prior_variance = prior_std**2

        # Conjugate prior update for normal-normal
        posterior_variance = 1 / (1 / prior_variance + 1 / observation_variance)
        posterior_mean = posterior_variance * (
            prior_mean / prior_variance + observation / observation_variance
        )
        posterior_std = math.sqrt(posterior_variance)

        # Update distribution
        self.distribution_params = DistributionParameters.normal(
            posterior_mean, posterior_std, seed=self._current_random_seed
        )
        self._initialize_distribution()

        # Update current value to posterior mean
        self.update(posterior_mean, confidence=0.9)

        logger.debug(
            "Bayesian update for %s: prior N(%.3f, %.3f) → posterior N(%.3f, %.3f)",
            self.name,
            prior_mean,
            prior_std,
            posterior_mean,
            posterior_std,
        )

        return True

    def validate(self, value: Any) -> bool:
        """
        Validate a value for stochastic variable.

        Parameters
        ----------
        value : Any
            Value to validate.

        Returns
        -------
        bool
            True if value could plausibly come from the distribution.

        Examples
        --------
        >>> is_valid = variable.validate(1.5)
        >>> print(f"Value is valid: {is_valid}")
        """
        if self._distribution is None:
            return True

        try:
            if (
                self.distribution_params
                and self.distribution_params.distribution_type
                == DistributionType.NORMAL
            ):
                mean = self.distribution_params.parameters["mean"]
                std = self.distribution_params.parameters["std"]

                if isinstance(value, tuple | list | set | np.ndarray):
                    is_validated = [abs(float(v) - mean) <= 4 * std for v in value]
                    if all(is_validated):
                        return True
                    else:
                        return False
                elif isinstance(value, float):
                    if abs(float(value) - mean) <= 4 * std:
                        return True
                    else:
                        return False

            if isinstance(value, tuple | list | set | np.ndarray):
                for v in value:
                    if not 0.001 <= self.cdf(float(v)) <= 0.999:
                        return False
                return True
            return 0.001 <= self.cdf(float(value)) <= 0.999

        except Exception:
            return False


class NormalVariable(StochasticVariable):
    """
    Normally distributed stochastic variable with reproducibility.

    Examples
    --------
    >>> import numpy as np
    >>> from causaloop import NormalVariable, VariableRole
    >>>
    >>> # Create a normally distributed variable
    >>> temperature = NormalVariable(
    ...     name="temperature",
    ...     description="Temperature with measurement noise",
    ...     units="Celsius",
    ...     role=VariableRole.OBSERVATION,
    ...     mean=22.0,
    ...     std=0.5,
    ...     random_seed=42
    ... )
    >>>
    >>> # Sample from distribution
    >>> samples = temperature.sample(1000)
    >>> print(f"Sample mean: {samples.mean():.2f}, std: {samples.std():.2f}")
    Sample mean: 22.01, std: 0.49
    >>>
    >>> # Bayesian update with observation
    >>> temperature.bayesian_update(22.5, observation_variance=0.1)
    True
    """

    def __init__(
        self,
        name: str,
        mean: float,
        std: float,
        description: str = "",
        units: str | None = None,
        role: VariableRole = VariableRole.ENDOGENOUS,
        config: dict[str, Any] | None = None,
        random_seed: int | None = None,
    ) -> None:
        """
        Initialize a normal variable.

        Parameters
        ----------
        name : str
            Variable name.
        mean : float
            Mean of the normal distribution.
        std : float
            Standard deviation of the normal distribution.
        description : str, optional
            Human-readable description.
        units : str, optional
            Physical units.
        role : VariableRole, optional
            Role in causal relationships.
        config : dict[str, Any] | None, optional
            Configuration dictionary.
        random_seed : int | None, optional
            Random seed for reproducible sampling.

        Raises
        ------
        ValueError
            If std is not positive.
        """
        distribution_params = DistributionParameters.normal(mean, std, seed=random_seed)

        super().__init__(
            name=name,
            description=description,
            units=units,
            role=role,
            distribution_params=distribution_params,
            config=config,
            random_seed=random_seed,
        )

    def sample(self, n: int = 1) -> FloatArray:
        """
        Sample from normal distribution.

        Parameters
        ----------
        n : int
            Number of samples to draw.

        Returns
        -------
        FloatArray
            Array of normally distributed samples.
        """
        if self.distribution_params:
            params = self.distribution_params.parameters
            mean = params["mean"]
            std = params["std"]
        else:
            mean = 0.0
            std = 1.0

        # Generate samples using our reproducible random state
        samples = self._random_state.normal(mean, std, n)

        # Store samples for history
        self.samples.extend(samples.tolist())

        return samples

    def validate(self, value: Any) -> bool:
        """
        Validate value for normal distribution.

        Parameters
        ----------
        value : Any
            Value to validate.

        Returns
        -------
        bool
            True if value is within 5 standard deviations of the mean.
        """
        if not isinstance(value, Number):
            return False

        if self.distribution_params:
            params = self.distribution_params.parameters
            mean = params["mean"]
            std = params["std"]
            if abs(float(value) - mean) <= 5 * std:
                return True
            else:
                return False

        return True


class UniformVariable(StochasticVariable):
    """
    Uniformly distributed stochastic variable with reproducibility.

    Examples
    --------
    >>> import numpy as np
    >>> from causaloop import UniformVariable, VariableRole
    >>>
    >>> # Create a uniformly distributed variable
    >>> position = UniformVariable(
    ...     name="position",
    ...     low=0.0,
    ...     high=10.0,
    ...     description="Random position in 1D space",
    ...     units="meters",
    ...     role=VariableRole.ENDOGENOUS,
    ...     random_seed=42
    ... )
    >>>
    >>> # All samples should be between 0 and 10
    >>> samples = position.sample(5000)
    >>> print(f"Min: {samples.min():.2f}, Max: {samples.max():.2f}")
    Min: 0.00, Max: 10.00
    """

    def __init__(
        self,
        name: str,
        low: float,
        high: float,
        description: str = "",
        units: str | None = None,
        role: VariableRole = VariableRole.ENDOGENOUS,
        config: dict[str, Any] | None = None,
        random_seed: int | None = None,
    ) -> None:
        """
        Initialize a uniform variable.

        Parameters
        ----------
        name : str
            Variable name.
        low : float
            Lower bound of uniform distribution.
        high : float
            Upper bound of uniform distribution.
        description : str, optional
            Human-readable description.
        units : str, optional
            Physical units.
        role : VariableRole, optional
            Role in causal relationships.
        config : dict[str, Any] | None, optional
            Configuration dictionary.
        random_seed : int | None, optional
            Random seed for reproducible sampling.

        Raises
        ------
        ValueError
            If low >= high.
        """
        if low >= high:
            raise ValueError(f"low must be less than high, got low={low}, high={high}")

        distribution_params = DistributionParameters.uniform(
            low, high, seed=random_seed
        )

        super().__init__(
            name=name,
            description=description,
            units=units,
            role=role,
            distribution_params=distribution_params,
            config=config,
            random_seed=random_seed,
        )

    def sample(self, n: int = 1) -> FloatArray:
        """
        Sample from uniform distribution.

        Parameters
        ----------
        n : int
            Number of samples to draw.

        Returns
        -------
        FloatArray
            Array of uniformly distributed samples.
        """
        if self.distribution_params:
            params = self.distribution_params.parameters
            low = params["low"]
            high = params["high"]
        else:
            low = 0.0
            high = 1.0

        # Use our reproducible random state directly
        samples = self._random_state.uniform(low, high, n)

        # Store samples for history
        self.samples.extend(samples.tolist())

        return samples

    def validate(self, value: Any) -> bool:
        """
        Validate value for uniform distribution.

        Parameters
        ----------
        value : Any
            Value to validate.

        Returns
        -------
        bool
            True if value is within bounds (with small tolerance).
        """
        if not isinstance(value, Number):
            return False

        if self.distribution_params:
            params = self.distribution_params.parameters
            low = params["low"]
            high = params["high"]
            if low - 1e-10 <= float(value) <= high + 1e-10:
                return True
            else:
                return False

        return True


class MixtureVariable(StochasticVariable):
    """
    Mixture distribution variable (weighted combination of distributions).

    Examples
    --------
    >>> import numpy as np
    >>> from causaloop import MixtureVariable, NormalVariable, VariableRole
    >>>
    >>> # Create a bimodal mixture
    >>> comp1 = NormalVariable("comp1", mean=0, std=1, random_seed=42)
    >>> comp2 = NormalVariable("comp2", mean=5, std=1, random_seed=43)
    >>>
    >>> mixture = MixtureVariable(
    ...     name="bimodal",
    ...     components=[comp1, comp2],
    ...     weights=[0.7, 0.3],
    ...     description="Bimodal mixture distribution",
    ...     role=VariableRole.ENDOGENOUS,
    ...     random_seed=44
    ... )
    >>>
    >>> # Samples will come from both modes
    >>> samples = mixture.sample(10000)
    >>> print(f"Sample mean: {samples.mean():.2f}")
    Sample mean: 1.53
    """

    def __init__(
        self,
        name: str,
        components: list[StochasticVariable],
        weights: list[float] | None = None,
        description: str = "",
        units: str | None = None,
        role: VariableRole = VariableRole.ENDOGENOUS,
        config: dict[str, Any] | None = None,
        random_seed: int | None = None,
    ) -> None:
        """
        Initialize a mixture variable.

        Parameters
        ----------
        name : str
            Variable name.
        components : list[StochasticVariable]
            List of component distributions.
        weights : list[float] | None, optional
            Weights for each component. If None, uniform weights.
        description : str, optional
            Human-readable description.
        units : str, optional
            Physical units.
        role : VariableRole, optional
            Role in causal relationships.
        config : dict[str, Any] | None, optional
            Configuration dictionary.
        random_seed : int | None, optional
            Random seed for reproducible sampling.

        Raises
        ------
        ValueError
            If weights don't match components length.
        """
        super().__init__(
            name=name,
            description=description,
            units=units,
            role=role,
            distribution_params=None,
            config=config,
            random_seed=random_seed,
        )

        self.components = components

        if weights is None:
            self.weights = [1.0 / len(components)] * len(components)
        else:
            if len(weights) != len(components):
                raise ValueError(
                    f"Number of weights ({len(weights)}) must match "
                    f"number of components ({len(components)})"
                )

            total = sum(weights)
            if abs(total - 1.0) > 1e-10:
                weights = [w / total for w in weights]

            self.weights = weights

        logger.debug(
            "Initialized MixtureVariable %s with %d components", name, len(components)
        )

    def sample(self, n: int = 1) -> FloatArray:
        """
        Sample from mixture distribution.

        Parameters
        ----------
        n : int
            Number of samples to draw.

        Returns
        -------
        FloatArray
            Array of samples from the mixture distribution.
        """
        # Create an array of component indices [0, 1, ..., k-1]
        component_indices = np.arange(len(self.components))
        # Convert weights to numpy array
        weights_array = np.array(self.weights, dtype=np.float64)

        # Choose components according to weights
        chosen_indices = self._random_state.choice(
            component_indices, size=n, p=weights_array
        )

        samples = np.zeros(n, dtype=np.float64)
        for i, component in enumerate(self.components):
            mask = chosen_indices == i
            if mask.any():
                component_samples = component.sample(mask.sum())
                # Ensure we get float64
                samples[mask] = np.asarray(component_samples, dtype=np.float64)

        return samples

    @overload
    def pdf(self, x: float) -> float: ...

    @overload
    def pdf(self, x: FloatArray) -> FloatArray: ...

    def pdf(self, x: FloatOrArray) -> FloatOrArray:
        """
        Calculate mixture density.

        Parameters
        ----------
        x : float | FloatArray
            Point(s) at which to evaluate density.

        Returns
        -------
        float | FloatArray
            Probability density at x.
        """
        if isinstance(x, float):
            x_array = np.array([x], dtype=np.float64)
            return_scalar = True
        else:
            x_array = np.asarray(x, dtype=np.float64)
            return_scalar = False

        density = np.zeros_like(x_array, dtype=np.float64)
        for weight, component in zip(self.weights, self.components, strict=False):
            try:
                component_density = component.pdf(x_array)
                density += weight * np.asarray(component_density, dtype=np.float64)
            except (ValueError, AttributeError):
                pass

        if return_scalar:
            return float(density[0])
        return density

    def validate(self, value: Any) -> bool:
        """
        Validate value for mixture distribution.

        Parameters
        ----------
        value : Any
            Value to validate.

        Returns
        -------
        bool
            True if value could plausibly come from any component.
        """
        if not isinstance(value, Number):
            return False

        for component in self.components:
            if component.validate(value):
                return True

        return False
