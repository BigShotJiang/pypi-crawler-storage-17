"""VariableState for managing state snapshots and transitions."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Any

from ...utils.id import generate_id
from ...utils.logging import get_logger

logger = get_logger(__name__)


class StateTransitionType(Enum):
    """
    Enumeration of state transition types.

    Defines the various reasons why a state might change, which is useful for
    auditing, debugging, and understanding the provenance of state changes.

    Attributes
    ----------
        UPDATE: Normal value update during regular operation
        INTERVENTION: External manual intervention or override
        RESET: Reset to initial or default state values
        RECONCILIATION: Conflict resolution between conflicting states
        OBSERVATION: Update based on observed data from external sources
        SIMULATION: Change during simulation or what-if analysis
    """

    UPDATE = auto()  # Normal value update
    INTERVENTION = auto()  # External intervention
    RESET = auto()  # Reset to initial state
    RECONCILIATION = auto()  # Conflict resolution
    OBSERVATION = auto()  # Observation from data
    SIMULATION = auto()  # Simulation step


@dataclass
class StateTransition:
    """
    Immutable record of a single state transition event.

    Captures a complete snapshot of a state change, including what changed,
    why it changed, and when it changed. Useful for audit trails, undo/redo
    functionality, debugging, and state history analysis.

    Attributes
    ----------
        from_state: Dictionary representing the state before the transition
        to_state: Dictionary representing the state after the transition
        transition_type: Type of transition from StateTransitionType enum
        timestamp: When the transition occurred (recommended: UTC timezone)
        reason: Optional human-readable explanation for the transition
        metadata: Optional additional context-specific information

    Examples
    --------
    >>> from datetime import datetime, timezone
    >>> from causaloop import StateTransition, StateTransitionType
    >>> transition = StateTransition(
    ...     from_state={"temp": 20},
    ...     to_state={"temp": 22},
    ...     transition_type=StateTransitionType.UPDATE,
    ...     timestamp=datetime.now(timezone.utc),
    ...     reason="User adjusted temperature"
    ... )
    """

    from_state: dict[str, Any]
    to_state: dict[str, Any]
    transition_type: StateTransitionType
    timestamp: datetime
    reason: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class VariableState:
    """
    Represents a complete state snapshot of a variable.

    Captures value, uncertainty, confidence, and metadata at a specific
    point in time. Supports state transitions and history tracking.

    Examples
    --------
    >>> from causaloop import VariableState, StateTransitionType
    >>>
    >>> # Create initial state
    >>> state1 = VariableState(
    ...     value=22.5,
    ...     confidence=0.9,
    ...     uncertainty=0.1,
    ...     metadata={"source": "sensor_1"}
    ... )
    >>>
    >>> # Create updated state
    >>> state2 = VariableState(
    ...     value=23.0,
    ...     confidence=0.85,
    ...     uncertainty=0.15,
    ...     metadata={"source": "sensor_2"}
    ... )
    >>>
    >>> # Record transition
    >>> transition = state1.transition_to(
    ...     state2,
    ...     transition_type=StateTransitionType.UPDATE,
    ...     reason="Sensor reading update"
    ... )
    >>>
    >>> print(f"Value change: {transition.from_state['value']} → {transition.to_state['value']}")
    Value change: 22.5 → 23.0
    """

    def __init__(
        self,
        value: Any,
        confidence: float,
        uncertainty: float,
        status: str = "resolved",
        metadata: dict[str, Any] | None = None,
        parent_variable_id: str | None = None,
        parent_variable_name: str | None = None,
    ) -> None:
        """
        Initialize a variable state.

        Parameters
        ----------
        value : Any
            Value of the variable in this state.
        confidence : float
            Confidence in the value (0 to 1).
        uncertainty : float
            Uncertainty level (0 to 1).
        status : str, optional
            Status of the variable in this state.
        metadata : dict, optional
            Additional metadata about this state.
        parent_variable_id : str, optional
            ID of the parent variable.
        parent_variable_name : str, optional
            Name of the parent variable.

        Raises
        ------
        ValueError
            If confidence or uncertainty not in [0, 1].
        """
        # Validate inputs
        if not 0 <= confidence <= 1:
            raise ValueError(f"Confidence must be between 0 and 1, got {confidence}")
        if not 0 <= uncertainty <= 1:
            raise ValueError(f"Uncertainty must be between 0 and 1, got {uncertainty}")

        # Generate unique ID
        self._id: str = generate_id("state")

        # Timestamps
        self._created_at: datetime = datetime.now(timezone.utc)
        self._updated_at: datetime = self._created_at

        # Core state
        self.value = value
        self.confidence = confidence
        self.uncertainty = uncertainty
        self.status = status
        self.metadata = metadata or {}

        # Parent reference
        self.parent_variable_id = parent_variable_id
        self.parent_variable_name = parent_variable_name

        # Transition history
        self.transitions: list[StateTransition] = []

        logger.debug(
            "Created VariableState %s for variable %s: value=%s, confidence=%.3f",
            self.id,
            parent_variable_name or "unknown",
            value,
            confidence,
        )

    @property
    def id(self) -> str:
        """Get the state's unique identifier."""
        return self._id

    @property
    def created_at(self) -> datetime:
        """Get the creation timestamp."""
        return self._created_at

    @property
    def updated_at(self) -> datetime:
        """Get the last update timestamp."""
        return self._updated_at

    def touch(self) -> None:
        """Update the last modified timestamp."""
        self._updated_at = datetime.now(timezone.utc)

    def is_compatible_to(self, other: VariableState) -> bool:
        """
        Check compatibility to another VariableState.

        Parameters
        ----------
        other : VariableState
            Other state to verify compatibility with.

        Returns
        -------
        bool
            True if compatible, False otherwise
        """
        return self.parent_variable_id == other.parent_variable_id

    def transition_to(
        self,
        new_state: VariableState,
        transition_type: StateTransitionType,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> StateTransition:
        """
        Record a transition from this state to a new state.

        Parameters
        ----------
        new_state : VariableState
            The new state being transitioned to.
        transition_type : StateTransitionType
            Type of transition.
        reason : str, optional
            Reason for the transition.
        metadata : dict, optional
            Additional metadata about the transition.

        Returns
        -------
        StateTransition
            Record of the transition.

        Raises
        ------
        ValueError
            If states are not from the same variable.
        """
        # Check if states are compatible
        if not self.is_compatible_to(new_state):
            raise ValueError(
                "Cannot transition between states of different variables: "
                f"{self.parent_variable_id} != {new_state.parent_variable_id}"
            )

        # Special case: transitioning to self
        if self is new_state:
            logger.warning(
                "Transitioning state %s to itself. "
                "Consider using self_transition() for clarity.",
                self.id,
            )

        # Create transition record
        transition = StateTransition(
            from_state=self.to_dict(),
            to_state=new_state.to_dict(),
            transition_type=transition_type,
            timestamp=datetime.now(timezone.utc),
            reason=reason,
            metadata=metadata or {},
        )

        # Record transition in both states
        self.transitions.append(transition)

        if self is not new_state:
            new_state.transitions.append(transition)

        logger.debug(
            "Recorded transition %s for variable %s: %s → %s",
            transition_type.name,
            self.parent_variable_name or "unknown",
            self.value,
            new_state.value,
        )

        return transition

    def self_transition(
        self,
        transition_type: StateTransitionType,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> StateTransition:
        """
        Record a transition where the state remains unchanged.

        Parameters
        ----------
        transition_type : StateTransitionType
            Type of transition.
        reason : str, optional
            Reason for the transition.
        metadata : dict, optional
            Additional metadata about the transition.

        Returns
        -------
        StateTransition
            Record of the transition.

        Notes
        -----
        Useful for:
        - Auditing no-op operations
        - Recording status updates without value changes
        - Heartbeat/keepalive signals
        - Metadata-only updates
        """
        return self.transition_to(
            new_state=self,
            transition_type=transition_type,
            reason=reason,
            metadata=metadata,
        )

    def distance_to(self, other: VariableState, metric: str = "value") -> float:
        """
        Calculate distance to another state.

        Parameters
        ----------
        other : VariableState
            Other state to compare with.
        metric : str, optional
            Distance metric to use:
            - "value": Absolute difference in values (for numeric)
            - "confidence": Difference in confidence
            - "uncertainty": Difference in uncertainty
            - "composite": Weighted combination

        Returns
        -------
        float
            Distance between states.

        Raises
        ------
        ValueError
            If metric is unknown or states are incompatible.
        """
        if not self.is_compatible_to(other):
            raise ValueError(
                "Cannot compare states of different variables: "
                f"{self.parent_variable_id} != {other.parent_variable_id}"
            )

        if metric == "confidence":
            return abs(self.confidence - other.confidence)

        elif metric == "uncertainty":
            return abs(self.uncertainty - other.uncertainty)

        elif metric == "value":
            # Try numeric comparison
            try:
                return abs(float(self.value) - float(other.value))
            except (TypeError, ValueError):
                # For non-numeric values, use equality check
                return 0.0 if self.value == other.value else 1.0

        elif metric == "composite":
            # Weighted combination of metrics
            value_dist = self.distance_to(other, "value")
            conf_dist = self.distance_to(other, "confidence")
            uncert_dist = self.distance_to(other, "uncertainty")

            # Normalize value distance if possible
            try:
                max_val = max(abs(float(self.value)), abs(float(other.value)), 1.0)
                value_dist = value_dist / max_val
            except (TypeError, ValueError):
                value_dist = value_dist  # Already 0 or 1

            return 0.5 * value_dist + 0.3 * conf_dist + 0.2 * uncert_dist

        else:
            raise ValueError(f"Unknown distance metric: {metric}")

    def is_similar_to(
        self,
        other: VariableState,
        tolerance: float = 0.01,
        metric: str = "composite",
    ) -> bool:
        """
        Check if this state is similar to another state.

        Parameters
        ----------
        other : VariableState
            Other state to compare with.
        tolerance : float, optional
            Maximum allowed distance (default: 0.01).
        metric : str, optional
            Distance metric to use.

        Returns
        -------
        bool
            True if states are similar within tolerance.
        """
        distance = self.distance_to(other, metric)
        return distance <= tolerance

    def interpolate(
        self,
        other: VariableState,
        alpha: float = 0.5,
    ) -> VariableState:
        """
        Interpolate between this state and another state.

        Parameters
        ----------
        other : VariableState
            Other state to interpolate to.
        alpha : float, optional
            Interpolation parameter (0 = this state, 1 = other state).

        Returns
        -------
        VariableState
            Interpolated state.

        Raises
        ------
        ValueError
            If states are incompatible or alpha not in [0, 1].
        """
        # Check compatibility
        if not self.is_compatible_to(other):
            raise ValueError(
                "Cannot interpolate states of different variables: "
                f"{self.parent_variable_id} != {other.parent_variable_id}"
            )

        if not 0 <= alpha <= 1:
            raise ValueError(f"Alpha must be between 0 and 1, got {alpha}")

        # Interpolate numeric values
        try:
            interp_value = (1 - alpha) * float(self.value) + alpha * float(other.value)
        except (TypeError, ValueError):
            # For non-numeric, use the closer state
            interp_value = self.value if alpha < 0.5 else other.value

        # Interpolate confidence and uncertainty
        interp_confidence = (1 - alpha) * self.confidence + alpha * other.confidence
        interp_uncertainty = (1 - alpha) * self.uncertainty + alpha * other.uncertainty

        # Determine status & mrge metadata
        if alpha < 0.5:
            interp_status = self.status
            interp_metadata = {**other.metadata, **self.metadata}
        else:
            interp_status = other.status
            interp_metadata = {**self.metadata, **other.metadata}

        return VariableState(
            value=interp_value,
            confidence=interp_confidence,
            uncertainty=interp_uncertainty,
            status=interp_status,
            metadata=interp_metadata,
            parent_variable_id=self.parent_variable_id,
            parent_variable_name=self.parent_variable_name,
        )

    def to_dict(self) -> dict[str, Any]:
        """
        Convert state to dictionary representation.

        Returns
        -------
        dict[str, Any]
            Dictionary containing state information.
        """
        return {
            "id": self.id,
            "value": self.value,
            "confidence": self.confidence,
            "uncertainty": self.uncertainty,
            "status": self.status,
            "metadata": self.metadata,
            "parent_variable_id": self.parent_variable_id,
            "parent_variable_name": self.parent_variable_name,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "transitions_count": len(self.transitions),
        }

    def to_json(self) -> str:
        """
        Convert state to JSON string.

        Returns
        -------
        str
            JSON representation of the state.
        """
        return json.dumps(self.to_dict(), default=str)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> VariableState:
        """
        Create a VariableState from dictionary.

        Parameters
        ----------
        data : dict[str, Any]
            Dictionary containing state information.

        Returns
        -------
        VariableState
            Reconstructed VariableState.

        Notes
        -----
        This doesn't fully restore all metadata like transitions.
        It's meant for serialization/deserialization of state snapshots.

        Id and created date are different from the dictionary.
        """
        state = cls(
            value=data["value"],
            confidence=data["confidence"],
            uncertainty=data["uncertainty"],
            status=data.get("status", "resolved"),
            metadata=data.get("metadata", {}),
            parent_variable_id=data.get("parent_variable_id"),
            parent_variable_name=data.get("parent_variable_name"),
        )

        return state

    def __str__(self) -> str:
        """Representation of the state."""
        return (
            f"VariableState("
            f"value={self.value}, "
            f"confidence={self.confidence:.3f}, "
            f"uncertainty={self.uncertainty:.3f})"
        )

    def __repr__(self) -> str:
        """Detailed representation of the state."""
        return (
            f"{self.__class__.__name__}("
            f"id={self.id}, "
            f"value={self.value!r}, "
            f"confidence={self.confidence:.3f}, "
            f"parent={self.parent_variable_name})"
        )
