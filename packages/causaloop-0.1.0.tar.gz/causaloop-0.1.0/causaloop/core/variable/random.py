"""Reproducible random number generation for CausaLoop."""

from __future__ import annotations

import threading
from collections.abc import Generator
from contextlib import contextmanager
from typing import Any, TypeAlias, TypedDict, overload

import numpy as np
import numpy.typing as npt

from ...utils.logging import get_logger

logger = get_logger(__name__)

# Type-safe aliases for better type checking
Number: TypeAlias = int | float | np.number
FloatArray: TypeAlias = npt.NDArray[np.float64]
IntArray: TypeAlias = npt.NDArray[np.int64]


class RandomStateTuple(TypedDict):
    """Type-safe representation of numpy RandomState internal tuple."""

    bit_generator: str
    state: list[int]
    pos: int
    has_gauss: int
    cached_gaussian: float


def _get_rng_state_tuple(rng: np.random.RandomState) -> RandomStateTuple:
    """
    Get random state as typed dictionary.

    Parameters
    ----------
    rng : np.random.RandomState
        Numpy RandomState instance.

    Returns
    -------
    RandomStateTuple
        Random state as typed dictionary.

    Raises
    ------
    TypeError
        If get_state() doesn't return expected tuple format.
    """
    state = rng.get_state()

    # Runtime type checking for safety
    if not isinstance(state, tuple):
        raise TypeError(f"Expected tuple from get_state(), got {type(state)}")

    if len(state) != 5:
        raise TypeError(
            f"Expected 5-element tuple from get_state(), got {len(state)} elements"
        )

    # Unpack with type checking
    bit_generator, state_array, pos, has_gauss, cached_gaussian = state

    # Additional type validation
    if not isinstance(bit_generator, str):
        raise TypeError(f"bit_generator should be str, got {type(bit_generator)}")

    if not isinstance(state_array, np.ndarray):
        raise TypeError(f"state_array should be np.ndarray, got {type(state_array)}")

    if not isinstance(pos, int):
        raise TypeError(f"pos should be int, got {type(pos)}")

    if not isinstance(has_gauss, int):
        raise TypeError(f"has_gauss should be int, got {type(has_gauss)}")

    if not isinstance(cached_gaussian, Number):
        raise TypeError(f"cached_gaussian should be float, got {type(cached_gaussian)}")

    # Convert to our typed dictionary
    return RandomStateTuple(
        bit_generator=bit_generator,
        state=state_array.tolist(),
        pos=pos,
        has_gauss=has_gauss,
        cached_gaussian=float(cached_gaussian),
    )


def _create_numpy_state_tuple(
    rng_state: RandomStateTuple,
) -> tuple[str, np.ndarray, int, int, float]:
    """
    Create numpy random state tuple from typed dictionary.

    Parameters
    ----------
    rng_state : RandomStateTuple
        Random state as typed dictionary.

    Returns
    -------
    tuple[str, np.ndarray, int, int, float]
        Random state tuple ready for set_state().
    """
    return (
        rng_state["bit_generator"],
        np.array(rng_state["state"], dtype=np.uint32),
        rng_state["pos"],
        rng_state["has_gauss"],
        rng_state["cached_gaussian"],
    )


class RandomState:
    """
    Guaranteed reproducible random state for CausaLoop.

    This class provides deterministic random number generation with full
    state checkpointing and restoration capabilities. It is essential for:

    1. **Scientific Reproducibility**: Same seed → same random sequence
    2. **Causal Debugging**: Replay exact stochastic scenarios
    3. **Optimization Consistency**: Deterministic optimization algorithms
    4. **Parallel Execution**: Thread-safe isolated random states
    5. **Stateful Reasoning**: Variables maintain random state history

    The implementation never uses numpy's global random state (`np.random`)
    to ensure complete isolation and determinism.

    Attributes
    ----------
    label : str
        Descriptive label for debugging and logging.
    _rng : np.random.RandomState
        Isolated numpy RandomState instance.
    _seed : int | None
        Current random seed, or None if using entropy.
    _is_deterministic : bool
        True if seeded deterministically, False if using entropy.
    _operation_counter : int
        Counter of random operations performed.
    _state_history : list[dict[str, Any]]
        History of state checkpoints.
    _child_states : dict[str, RandomState]
        Child random states derived from this one.
    _lock : threading.RLock
        Lock for thread-safe operations.

    Examples
    --------
    >>> import numpy as np
    >>> from causaloop import RandomState
    >>>
    >>> # Create deterministic random state
    >>> rng = RandomState(seed=42, label="test")
    >>> samples1 = rng.normal(size=5)
    >>>
    >>> # Create another with same seed - will produce identical sequence
    >>> rng2 = RandomState(seed=42, label="test2")
    >>> samples2 = rng2.normal(size=5)
    >>> np.allclose(samples1, samples2)
    True
    >>>
    >>> # Create checkpoint for causal analysis
    >>> checkpoint = rng.checkpoint("before_intervention")
    >>> # ... perform causal operations ...
    >>> rng.restore_checkpoint(checkpoint)  # Back to pre-intervention state

    Notes
    -----
    This implementation uses numpy's RandomState which provides the Mersenne
    Twister PRNG algorithm (MT19937) with a period of 2^19937-1.
    """

    def __init__(self, seed: int | None = None, label: str = "unnamed") -> None:
        """
        Initialize a reproducible random state.

        Parameters
        ----------
        seed : int | None
            Random seed for deterministic behavior. If None, uses entropy
            from system sources (time, PID, etc.) for true randomness.
        label : str
            Descriptive label for debugging and logging.

        Raises
        ------
        ValueError
            If seed is provided but not an integer.
        """
        self.label = label
        self._lock = threading.RLock()

        if seed is not None:
            if not isinstance(seed, int):
                raise ValueError(f"Seed must be integer, got {type(seed)}")
            self._rng = np.random.RandomState(seed)
            self._seed = seed
            self._is_deterministic = True
            logger.debug(
                "Created deterministic random state '%s' with seed %s", label, seed
            )
        else:
            # Generate entropy seed from multiple system sources
            import os
            import random as py_random
            import time

            entropy_seed = (
                int(time.time() * 1000)
                ^ (os.getpid() << 16)
                ^ (hash(label) % (2**32))
                ^ py_random.getrandbits(32)
            ) % (2**32 - 1)

            self._rng = np.random.RandomState(entropy_seed)
            self._seed = entropy_seed
            self._is_deterministic = False
            logger.debug(
                "Created non-deterministic random state '%s' with entropy seed", label
            )

        self._operation_counter = 0
        self._state_history: list[dict[str, Any]] = []
        self._child_states: dict[str, RandomState] = {}

    def seed(self, seed: int) -> None:
        """
        Reset random state with new seed.

        Resets the internal random number generator and clears operation
        history. After calling this method, the random state will produce
        the same sequence as if it were freshly initialized with this seed.

        Parameters
        ----------
        seed : int
            Random seed for deterministic behavior.

        Raises
        ------
        ValueError
            If seed is not an integer.
        """
        if not isinstance(seed, int):
            raise ValueError(f"Seed must be integer, got {type(seed)}")

        with self._lock:
            self._rng.seed(seed)
            self._seed = seed
            self._is_deterministic = True
            self._operation_counter = 0
            self._state_history.clear()
            logger.debug("Random state '%s' reseeded with %s", self.label, seed)

    def get_state(self) -> dict[str, Any]:
        """
        Get complete current random state for checkpointing.

        Returns a serializable dictionary containing all information needed
        to restore the exact random state later. This includes numpy's
        internal PRNG state, operation counters, and child states.

        Returns
        -------
        dict[str, Any]
            Serializable state dictionary.

        Examples
        --------
        >>> from causaloop import RandomState
        >>> rng = RandomState(seed=42)
        >>> # Perform some operations
        >>> _ = rng.normal(size=10)
        >>> # Save state
        >>> state = rng.get_state()
        >>> # Restore later
        >>> rng.set_state(state)
        """
        with self._lock:
            # Use our type-safe wrapper to get the state as typed dict
            rng_state_dict = _get_rng_state_tuple(self._rng)

            # Convert numpy state to serializable format
            serializable_state: dict[str, Any] = {
                "label": self.label,
                "seed": self._seed,
                "is_deterministic": self._is_deterministic,
                "operation_counter": self._operation_counter,
                "rng_state": rng_state_dict,
                "state_history_length": len(self._state_history),
                "child_states": {
                    k: v.get_state() for k, v in self._child_states.items()
                },
            }
            return serializable_state

    def set_state(self, state: dict[str, Any]) -> None:
        """
        Restore random state from checkpoint.

        Parameters
        ----------
        state : dict[str, Any]
            State dictionary previously obtained from get_state().

        Raises
        ------
        ValueError
            If state dictionary is malformed or incompatible.
        """
        with self._lock:
            # Restore numpy's internal state
            rng_state_data = state.get("rng_state")
            if rng_state_data:
                # Validate the structure matches RandomStateTuple
                required_keys = {
                    "bit_generator",
                    "state",
                    "pos",
                    "has_gauss",
                    "cached_gaussian",
                }
                if not all(key in rng_state_data for key in required_keys):
                    missing = required_keys - set(rng_state_data.keys())
                    raise ValueError(f"Missing required keys in rng_state: {missing}")

                # Create RandomStateTuple from the data
                rng_state = RandomStateTuple(
                    bit_generator=str(rng_state_data["bit_generator"]),
                    state=list(rng_state_data["state"]),
                    pos=int(rng_state_data["pos"]),
                    has_gauss=int(rng_state_data["has_gauss"]),
                    cached_gaussian=float(rng_state_data["cached_gaussian"]),
                )

                # Convert to numpy tuple and set state
                rng_tuple = _create_numpy_state_tuple(rng_state)
                self._rng.set_state(rng_tuple)

            # Restore metadata
            self._seed = state.get("seed", self._seed)
            self._is_deterministic = state.get(
                "is_deterministic", self._is_deterministic
            )
            self._operation_counter = state.get("operation_counter", 0)

            # Restore child states
            child_states = state.get("child_states", {})
            for name, child_state in child_states.items():
                if name in self._child_states:
                    self._child_states[name].set_state(child_state)
                else:
                    self.create_child_state(name)
                    self._child_states[name].set_state(child_state)

            logger.debug(
                "Random state '%s' restored to operation %s",
                self.label,
                self._operation_counter,
            )

    def checkpoint(self, name: str | None = None) -> str:
        """
        Create a checkpoint of current state.

        Parameters
        ----------
        name : str | None
            Optional name for the checkpoint. If None, generates automatic
            name based on operation counter.

        Returns
        -------
        str
            Checkpoint ID that can be used to restore state.

        Examples
        --------
        >>> from causaloop import RandomState
        >>> rng = RandomState(seed=42)
        >>> checkpoint1 = rng.checkpoint("initial_state")
        >>> _ = rng.normal(size=10)
        >>> checkpoint2 = rng.checkpoint("after_sampling")
        >>> rng.restore_checkpoint(checkpoint1)  # Back to initial state
        True
        >>> rng.restore_checkpoint(checkpoint2)  # Back to after_sampling state
        True
        """
        with self._lock:
            state = self.get_state()
            self._state_history.append(state)

            # Store the checkpoint ID with the state
            if name is None:
                checkpoint_id = f"{self.label}_checkpoint_{len(self._state_history)}"
            else:
                checkpoint_id = f"{self.label}_{name}"

            # Store the checkpoint ID in the state for later retrieval
            state["_checkpoint_id"] = checkpoint_id

            logger.debug(
                "Created checkpoint '%s' for random state '%s'",
                checkpoint_id,
                self.label,
            )
            return checkpoint_id

    def restore_checkpoint(self, checkpoint_id: str) -> bool:
        """
        Restore state from checkpoint ID.

        Parameters
        ----------
        checkpoint_id : str
            Checkpoint ID to restore.

        Returns
        -------
        bool
            True if restoration was successful, False otherwise.

        Examples
        --------
        >>> import numpy as np
        >>> from causaloop import RandomState
        >>> rng = RandomState(seed=42, label="test")
        >>> checkpoint1 = rng.checkpoint("state1")
        >>> samples1 = rng.normal(size=5)
        >>> checkpoint2 = rng.checkpoint("state2")
        >>> samples2 = rng.normal(size=5)
        >>>
        >>> # Restore to first checkpoint
        >>> rng.restore_checkpoint(checkpoint1)
        True
        >>> new_samples = rng.normal(size=5)
        >>> # new_samples will be identical to samples1
        >>> np.allclose(samples1, new_samples)
        True
        """
        with self._lock:
            # First try: exact match with stored checkpoint ID
            for state in self._state_history:
                if state.get("_checkpoint_id") == checkpoint_id:
                    self.set_state(state)
                    logger.debug(
                        "Restored checkpoint '%s' for random state '%s'",
                        checkpoint_id,
                        self.label,
                    )
                    return True

            # second try: auto-generated checkpoint (label_checkpoint_N format)
            try:
                parts = checkpoint_id.split("_")
                checkpoint_num = int(parts[2])
                if 1 <= checkpoint_num <= len(self._state_history):
                    # Checkpoint numbers are 1-indexed
                    state = self._state_history[checkpoint_num - 1]
                    self.set_state(state)
                    logger.debug(
                        "Restored auto-generated checkpoint '%s' (index %d)",
                        checkpoint_id,
                        checkpoint_num - 1,
                    )
                    return True
            except (IndexError, ValueError) as e:
                logger.debug(
                    "Failed to parse checkpoint ID '%s' as auto-generated: %s",
                    checkpoint_id,
                    e,
                )

            logger.error(
                "Checkpoint '%s' not found for random state '%s'. "
                "Available checkpoints: %s",
                checkpoint_id,
                self.label,
                [
                    s.get("_checkpoint_id", f"unknown_{i}")
                    for i, s in enumerate(self._state_history)
                ],
            )
            return False

    def create_child_state(self, name: str, seed: int | None = None) -> RandomState:
        """
        Create a child random state derived from this one.

        Child states are useful for hierarchical random state management,
        such as isolating subsystems while maintaining overall reproducibility.

        Parameters
        ----------
        name : str
            Name for the child state.
        seed : int | None
            Seed for child. If None, generates seed from parent's current
            state to ensure deterministic derivation.

        Returns
        -------
        RandomState
            Child random state.

        Examples
        --------
        >>> from causaloop import RandomState
        >>> parent = RandomState(seed=42)
        >>> child = parent.create_child_state("subsystem")
        >>> # Child produces deterministic sequence based on parent's state
        >>> child_samples = child.normal(size=5)
        """
        with self._lock:
            if seed is None:
                parent_samples = self._rng.randint(0, 2**32 - 1, size=1)
                seed = int(parent_samples[0])

            child = RandomState(seed=seed, label=f"{self.label}.{name}")
            self._child_states[name] = child
            return child

    def _record_operation(self) -> None:
        """Record that a random operation has been performed."""
        with self._lock:
            self._operation_counter += 1

    def normal(
        self, loc: float = 0.0, scale: float = 1.0, size: int | None = None
    ) -> FloatArray:
        """
        Generate normally distributed random numbers.

        Parameters
        ----------
        loc : float
            Mean of the distribution.
        scale : float
            Standard deviation of the distribution.
        size : int | None
            Number of samples to generate.

        Returns
        -------
        FloatArray
            Array of normally distributed samples.
        """
        with self._lock:
            self._record_operation()
            samples = self._rng.normal(loc, scale, size)
            return np.asarray(samples, dtype=np.float64)

    def uniform(
        self, low: float = 0.0, high: float = 1.0, size: int | None = None
    ) -> FloatArray:
        """
        Generate uniformly distributed random numbers.

        Parameters
        ----------
        low : float
            Lower bound of the distribution.
        high : float
            Upper bound of the distribution.
        size : int | None
            Number of samples to generate.

        Returns
        -------
        FloatArray
            Array of uniformly distributed samples.
        """
        with self._lock:
            self._record_operation()
            samples = self._rng.uniform(low, high, size)
            return np.asarray(samples, dtype=np.float64)

    def randint(
        self, low: int, high: int | None = None, size: int | None = None
    ) -> IntArray:
        """
        Generate random integers.

        Parameters
        ----------
        low : int
            Lower bound (inclusive).
        high : int | None
            Upper bound (exclusive). If None, low is used as upper bound
            and 0 as lower bound.
        size : int | None
            Number of samples to generate.

        Returns
        -------
        IntArray
            Array of random integers.
        """
        with self._lock:
            self._record_operation()
            if high is None:
                samples = self._rng.randint(low, size=size)
            else:
                samples = self._rng.randint(low, high, size)
            return np.asarray(samples, dtype=np.int64)

    def choice(
        self,
        a: int | FloatArray | IntArray,
        size: int | None = None,
        replace: bool = True,
        p: FloatArray | None = None,
    ) -> FloatArray | IntArray:
        """
        Generate random samples from a given array.

        Parameters
        ----------
        a : int | FloatArray | IntArray
            If an int, random sample from np.arange(a).
        size : int | None
            Number of samples to generate.
        replace : bool
            Whether to sample with replacement.
        p : FloatArray | None
            Probabilities associated with each entry in a.

        Returns
        -------
        FloatArray | IntArray
            Random samples from a.
        """
        with self._lock:
            self._record_operation()
            if p is not None:
                p_array = np.asarray(p, dtype=np.float64)
            else:
                p_array = None

            a_array: np.ndarray | FloatArray | IntArray | None = None
            if isinstance(a, int):
                a_array = np.arange(a)
            else:
                a_array = a

            samples = self._rng.choice(a_array, size, replace, p_array)

            if np.issubdtype(samples.dtype, np.integer):
                return np.asarray(samples, dtype=np.int64)
            else:
                return np.asarray(samples, dtype=np.float64)

    def shuffle(self, x: FloatArray | IntArray | list[float] | list[int]) -> None:
        """
        Shuffle array in-place.

        Parameters
        ----------
        x : FloatArray | IntArray | list[float] | list[int]
            Array to shuffle.
        """
        with self._lock:
            self._record_operation()
            self._rng.shuffle(x)

    @overload
    def random(self) -> float: ...

    @overload
    def random(self, size: int) -> FloatArray: ...

    @overload
    def random(self, size: tuple[int, ...]) -> FloatArray: ...

    def random(self, size: int | tuple[int, ...] | None = None) -> float | FloatArray:
        """
        Generate uniform random numbers in [0, 1).

        Generates random numbers from a uniform distribution over the
        semi-open interval [0, 1). This is a fundamental operation used
        for generating samples from arbitrary distributions via inverse
        transform sampling.

        Parameters
        ----------
        size : int | tuple[int, ...] | None
            Number of samples to generate. Can be:
            - None: returns a single float
            - int: returns 1D array of length `size`
            - tuple: returns array with shape `size`

        Returns
        -------
        float | FloatArray
            Single random float if size is None, otherwise numpy array
            of random floats with specified shape.

        Raises
        ------
        ValueError
            If size contains negative values or non-integer elements.
        TypeError
            If size is not None, int, or tuple.

        Examples
        --------
        >>> from causaloop import RandomState
        >>> rng = RandomState(seed=42)
        >>>
        >>> # Single random number
        >>> x = rng.random()
        >>> print(f"Single value: {x:.6f}")
        Single value: 0.374540
        >>> isinstance(x, float)
        True
        >>>
        >>> # 1D array
        >>> arr1d = rng.random(5)
        >>> print(f"1D array shape: {arr1d.shape}")
        1D array shape: (5,)
        >>> print(f"Values: {arr1d}")
        Values: [0.95071431 0.73199394 0.59865848 0.15601864 0.15599452]
        >>>
        >>> # 2D array
        >>> arr2d = rng.random((2, 3))
        >>> print(f"2D array shape: {arr2d.shape}")
        2D array shape: (2, 3)
        >>> print(f"Values: {arr2d}")
        Values: [[0.05808361 0.86617615 0.60111501]
         [0.70807258 0.02058449 0.96990985]]

        Notes
        -----
        The uniform distribution over [0, 1) is:
        - P(x) = 1 for 0 ≤ x < 1
        - P(x) = 0 otherwise

        This function uses numpy's Mersenne Twister implementation (MT19937)
        which has a period of 2^19937-1 and 623-dimensional equidistribution.

        For generating random integers in a range, use randint().
        For generating random numbers from other distributions, use the
        appropriate methods (normal(), uniform(), etc.).

        Thread Safety:
        This method is thread-safe due to internal locking. Multiple threads
        can call random() concurrently without corrupting the random state.
        """
        with self._lock:
            self._record_operation()

            # Validate size parameter
            if size is not None:
                if isinstance(size, int):
                    if size < 0:
                        raise ValueError(f"size must be non-negative, got {size}")
                elif isinstance(size, tuple):
                    if not all(isinstance(dim, int) for dim in size):
                        raise TypeError(
                            f"All dimensions in size must be integers, got {size}"
                        )
                    if any(dim < 0 for dim in size):
                        raise ValueError(
                            f"All dimensions must be non-negative, got {size}"
                        )
                else:
                    raise TypeError(
                        f"size must be None, int, or tuple, got {type(size)}"
                    )

            # Generate random numbers
            result = self._rng.random(size)

            # Ensure correct return type
            if size is None:
                return float(result)
            else:
                return np.array(result, dtype=np.float64)

    def bytes(self, length: int) -> bytes:
        """
        Generate random bytes.

        Parameters
        ----------
        length : int
            Number of bytes to generate.

        Returns
        -------
        bytes
            Random bytes.
        """
        with self._lock:
            self._record_operation()
            data: bytes = self._rng.bytes(length)
            return data

    def is_deterministic(self) -> bool:
        """
        Check if this random state is deterministic.

        Returns
        -------
        bool
            True if seeded deterministically, False if using entropy.
        """
        return self._is_deterministic

    def get_info(self) -> dict[str, Any]:
        """
        Get information about this random state.

        Returns
        -------
        dict[str, Any]
            Information dictionary containing label, seed, operation count,
            and other metadata.
        """
        with self._lock:
            return {
                "label": self.label,
                "seed": self._seed,
                "is_deterministic": self._is_deterministic,
                "operations_performed": self._operation_counter,
                "checkpoints_available": len(self._state_history),
                "child_states": list(self._child_states.keys()),
            }

    def __str__(self) -> str:
        """Representation."""
        return (
            f"RandomState(label='{self.label}', "
            f"seed={self._seed}, deterministic={self._is_deterministic})"
        )


class RandomStateManager:
    """
    Manages random states for CausaLoop with thread safety.

    This singleton class provides centralized management of random states
    for the entire CausaLoop framework. It maintains:

    1. **Global Deterministic State**: For reproducible simulations
    2. **Global Non-deterministic State**: For true randomness when needed
    3. **Thread-Local States**: For parallel execution with consistency
    4. **Context Management**: For isolated random operations

    The manager ensures that all stochastic operations in CausaLoop are
    properly isolated and reproducible, which is essential for causal
    reasoning and scientific validation.

    Attributes
    ----------
    _deterministic_state : RandomState
        Global deterministic random state.
    _nondeterministic_state : RandomState
        Global non-deterministic random state.
    _thread_local : threading.local
        Thread-local storage for isolated random states.

    Examples
    --------
    >>> from causaloop import RandomStateManager
    >>>
    >>> # Get global deterministic state
    >>> manager = RandomStateManager()
    >>> rng = manager.get_deterministic_state()
    >>> samples = rng.normal(size=10)
    >>>
    >>> # Set global seed for reproducibility
    >>> manager.set_seed(42)
    >>>
    >>> # Create isolated context for causal intervention
    >>> with manager.isolated_context(seed=123) as isolated_rng:
    ...     intervention_samples = isolated_rng.normal(size=5)
    """

    _instance: RandomStateManager | None = None
    _lock = threading.RLock()

    def __new__(cls) -> RandomStateManager:
        """
        Create or return the singleton instance of RandomStateManager.

        This method implements the singleton pattern to ensure only one instance
        of the random state manager exists in the entire CausaLoop framework.
        The singleton pattern is essential for:

        1. **Global Consistency**: All parts of the system access the
            same random states
        2. **Resource Management**: Single point of control for random state
            allocation
        3. **Thread Safety**: Coordinated access across multiple threads
        4. **State Persistence**: Maintain random state history across the
            application

        The implementation uses double-checked locking with a reentrant lock to
        ensure thread safety during singleton initialization.

        Returns
        -------
        RandomStateManager
            The singleton instance of the random state manager.

        Notes
        -----
        - This is a class method but does not use the @classmethod decorator
          because __new__ is a special method that is implicitly a class method.
        - The lock (`cls._lock`) is a class-level threading.RLock that ensures
          thread safety during singleton creation.
        - The `_initialize()` method is called only once, when the singleton
          is first created.

        Thread Safety
        -------------
        The implementation is thread-safe:
        1. The class-level lock prevents race conditions during initialization
        2. Double-checked locking pattern minimizes lock contention
        3. The instance check is performed inside the lock to prevent
           the "check-then-act" race condition

        Examples
        --------
        >>> from causaloop import RandomStateManager
        >>>
        >>> # First call creates the singleton
        >>> manager1 = RandomStateManager()
        >>>
        >>> # Subsequent calls return the same instance
        >>> manager2 = RandomStateManager()
        >>> manager1 is manager2
        True
        >>>
        >>> # Thread-safe access from multiple threads
        >>> import threading
        >>> def get_manager():
        ...     return RandomStateManager()
        >>>
        >>> threads = [threading.Thread(target=get_manager) for _ in range(10)]
        >>> for thread in threads:
        ...     thread.start()
        >>> for thread in threads:
        ...     thread.join()
        >>> # All threads received the same singleton instance

        See Also
        --------
        threading.RLock : The reentrant lock used for thread safety.
        super().__new__ : The parent class's __new__ method for actual instance creation.
        """
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialize()
            return cls._instance

    def _initialize(self) -> None:
        """Initialize the global random state manager."""
        self._deterministic_state = RandomState(
            seed=42,  # Default global seed for reproducibility
            label="global_deterministic",
        )

        self._nondeterministic_state = RandomState(
            seed=None,  # True randomness
            label="global_nondeterministic",
        )

        self._thread_local = threading.local()

    def get_deterministic_state(self) -> RandomState:
        """
        Get the global deterministic random state.

        This state should be used for all operations requiring reproducibility,
        such as debugging, testing, and scientific validation.

        Returns
        -------
        RandomState
            Global deterministic random state.
        """
        return self._deterministic_state

    def get_nondeterministic_state(self) -> RandomState:
        """
        Get the global non-deterministic random state.

        This state should be used when true randomness is required,
        such as Monte Carlo simulations or stochastic optimization
        where exploration is desired.

        Returns
        -------
        RandomState
            Global non-deterministic random state.
        """
        return self._nondeterministic_state

    def get_thread_local_state(self, seed: int | None = None) -> RandomState:
        """
        Get thread-local random state.

        Essential for parallel execution where each thread needs its own
        isolated but reproducible random state. This method ensures that:

        1. Each thread gets its own isolated random state
        2. Random states are reproducible when seeds are provided
        3. Thread states are lazily initialized on first access
        4. The global deterministic state is used for seed generation when needed

        Parameters
        ----------
        seed : int | None
            Seed for the thread-local state. If None, generates a deterministic
            seed from thread ID and global state to ensure reproducibility
            across runs while maintaining thread isolation.

            Note: If seed is provided, it should be unique per thread to avoid
            duplicate random sequences.

        Returns
        -------
        RandomState
            Thread-local random state instance.

        Raises
        ------
        ValueError
            If seed is provided but not an integer.
        RuntimeError
            If thread-local storage cannot be initialized.

        Examples
        --------
        >>> from causaloop import RandomStateManager
        >>> manager = RandomStateManager()
        >>>
        >>> # Get thread-local state with automatic seeding
        >>> thread_rng = manager.get_thread_local_state()
        >>> samples = thread_rng.normal(size=5)
        >>>
        >>> # Get with explicit seed for reproducibility
        >>> thread_rng2 = manager.get_thread_local_state(seed=42)
        >>> samples2 = thread_rng2.normal(size=5)
        >>>
        >>> # In parallel execution:
        >>> import concurrent.futures
        >>> def process_data(thread_id: int):
        ...     rng = manager.get_thread_local_state(seed=100 + thread_id)
        ...     return rng.normal(size=3)
        >>>
        >>> with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        ...     results = list(executor.map(process_data, range(3)))
        ...     # Each thread has its own reproducible random state

        Notes
        -----
        - Thread-local states are stored in `threading.local()` storage,
          which ensures each thread sees only its own instances.
        - When seed is None, the generated seed combines:
          - A random sample from the global deterministic state
          - The thread ID for uniqueness
          - Modulo operation to ensure it's within valid seed range
        - Thread-local states persist until the thread terminates or
          the thread-local storage is cleared.
        - For maximum reproducibility in parallel simulations, provide
          explicit seeds to each thread.
        """
        thread_id = threading.get_ident()

        # ALWAYS validate seed parameter first
        if seed is not None and not isinstance(seed, int):
            raise ValueError(f"seed must be an integer, got {type(seed).__name__}")

        # Initialize thread-local storage if needed
        if not hasattr(self._thread_local, "random_states"):
            try:
                self._thread_local.random_states = {}
            except Exception as e:
                raise RuntimeError(
                    f"Failed to initialize thread-local storage: {e}"
                ) from e

        # Type assertion for mypy
        random_states: dict[int, RandomState] = self._thread_local.random_states

        # Return existing state if already created
        if thread_id in random_states:
            return random_states[thread_id]

        # Create new thread-local state
        if seed is None:
            # Generate deterministic seed from global state and thread ID
            try:
                # Get random integer from global deterministic state
                base_seed_array = self._deterministic_state.randint(
                    0, 2**32 - 1, size=1
                )
                base_seed = int(base_seed_array[0])

                # Combine with thread ID for uniqueness
                thread_seed = (base_seed ^ thread_id) % (2**32 - 1)
            except Exception as e:
                raise RuntimeError(
                    f"Failed to generate thread seed for thread {thread_id}: {e}"
                ) from e
        else:
            # Use provided seed
            thread_seed = seed

        # Create the thread-local random state
        try:
            thread_state = RandomState(seed=thread_seed, label=f"thread_{thread_id}")
        except Exception as e:
            raise RuntimeError(
                f"Failed to create random state for thread {thread_id}: {e}"
            ) from e

        # Store and return
        random_states[thread_id] = thread_state

        logger.debug(
            "Created thread-local random state for thread %s with seed %s",
            thread_id,
            thread_seed,
        )

        return thread_state

    def set_seed(self, seed: int) -> None:
        """
        Set global deterministic seed.

        This method resets the global deterministic random state with the
        given seed. All future operations using the deterministic state
        will be reproducible.

        Parameters
        ----------
        seed : int
            Random seed for global deterministic state.

        Raises
        ------
        ValueError
            If seed is not an integer.
        """
        if not isinstance(seed, int):
            raise ValueError(f"Seed must be integer, got {type(seed)}")

        with self._lock:
            self._deterministic_state.seed(seed)
            logger.info("Global deterministic seed set to %s", seed)

    @contextmanager
    def isolated_context(
        self, seed: int | None = None, label: str = "isolated"
    ) -> Generator[RandomState, None, None]:
        """
        Context manager for isolated random operations.

        Creates a completely isolated random state for operations within
        the context. This is useful for testing interventions, comparing
        scenarios, or isolating subsystems.

        Parameters
        ----------
        seed : int | None
            Seed for the isolated context. If None, uses entropy.
        label : str
            Label for the context.

        Yields
        ------
        RandomState
            Isolated random state for use within the context.

        Examples
        --------
        >>> from causaloop import RandomStateManager
        >>> manager = RandomStateManager()
        >>> with manager.isolated_context(seed=42) as rng:
        ...     samples = rng.normal(size=10)
        ...     # These samples are completely isolated from global state
        """
        isolated_state = RandomState(seed=seed, label=label)

        try:
            yield isolated_state
        finally:
            # Context cleanup if needed
            pass


def set_random_seed(seed: int) -> None:
    """
    Set global random seed for all stochastic operations in CausaLoop.

    This ensures reproducibility across the entire framework.

    Parameters
    ----------
    seed : int
        Random seed to use.

    Raises
    ------
    ValueError
        If seed is not a positive integer or zero.

    Examples
    --------
    >>> from causaloop import set_random_seed
    >>> set_random_seed(42)
    >>> # All subsequent stochastic operations will be reproducible
    """
    if not isinstance(seed, int):
        raise ValueError(f"Seed must be integer, got {type(seed)}")

    if seed < 0:
        raise ValueError(f"Seed must not be negative, got {seed}")

    RandomStateManager().set_seed(seed)


@contextmanager
def sampling_context(
    seed: int, name: str = "sampling"
) -> Generator[RandomState, None, None]:
    """
    Create a context for reproducible sampling operations.

    Useful for:
    - Testing causal interventions
    - Comparing optimization strategies
    - Parallel simulation with deterministic results

    Parameters
    ----------
    seed : int
        Random seed for the context.
    name : str
        Context name for debugging.

    Yields
    ------
    RandomState
        Random state for use within the context.

    Raises
    ------
    ValueError
        If seed is not a positive integer or zero.

    Examples
    --------
    >>> from causaloop import sampling_context
    >>> with sampling_context(seed=42, name="test_intervention") as rng:
    ...     # All sampling in this block uses isolated, reproducible random state
    ...     samples = rng.normal(size=100)
    """
    if not isinstance(seed, int):
        raise ValueError(f"Seed must be integer, got {type(seed)}")

    if seed < 0:
        raise ValueError(f"Seed must not be negative, got {seed}")

    with RandomStateManager().isolated_context(seed=seed, label=name) as rng:
        yield rng


def random_state_manager() -> RandomStateManager:
    """
    Get the global random state manager.

    Returns
    -------
    RandomStateManager
        Global random state manager instance.

    Examples
    --------
    >>> from causaloop import random_state_manager
    >>> manager = random_state_manager()
    >>> rng = manager.get_deterministic_state()
    """
    return RandomStateManager()
