"""
Base Variable class for CausaLoop.

Defines the fundamental Variable abstraction that represents a causal quantity with
state, uncertainty, constraints, and reasoning capabilities.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Any, ClassVar, TypeVar

from ...utils.id import generate_id
from ...utils.logging import get_logger
from ...utils.mixin import ObservableMixin, SerializableMixin, StatefulMixin

logger = get_logger(__name__)

T = TypeVar("T")
VariableType = TypeVar("VariableType", bound="Variable")


class VariableRole(Enum):
    """
    Defines the causal role of a variable within the system.

    The role determines how a variable participates in causal relationships,
    how it's updated, and what constraints apply to it. This classification
    is fundamental for causal reasoning and intervention planning.

    Attributes
    ----------
    ENDOGENOUS : VariableRole
        Internal variable determined by the system's mechanisms. These variables
        evolve according to the system dynamics and are typically outputs of
        causal mechanisms. Example: Room temperature in a climate control system.

    EXOGENOUS : VariableRole
        External input variable that influences the system but is not determined
        by it. These are typically boundary conditions or external drivers.
        Example: Outdoor temperature affecting a building's thermal dynamics.

    INTERVENTION : VariableRole
        Variable that can be directly manipulated by external interventions.
        These are targets for optimization or control actions.
        Example: Thermostat setpoint that can be adjusted.

    OBSERVATION : VariableRole
        Variable that can be observed/measured but not directly manipulated.
        These provide information about the system state but aren't control knobs.
        Example: Sensor readings from installed equipment.

    LATENT : VariableRole
        Unobserved variable that has causal influence on the system. These
        represent hidden states or factors that must be inferred.
        Example: Unmeasured internal stress in a mechanical component.

    RESOURCE : VariableRole
        Variable representing a consumable or limited resource. These have
        availability constraints and depletion dynamics.
        Example: Battery charge level, fuel quantity, budget allocation.

    CONSTRAINT : VariableRole
        Variable representing a system constraint or boundary condition.
        These define limits that must not be violated.
        Example: Maximum allowable pressure, minimum safety margin.

    Notes
    -----
    Variable roles are not mutually exclusive - a variable can have multiple
    aspects (e.g., both ENDOGENOUS and OBSERVATION). However, the primary role
    determines its core behavior in causal reasoning.

    Examples
    --------
    >>> from causaloop import VariableRole
    >>>
    >>> # Define roles for different variables in a power grid
    >>> generator_output = VariableRole.ENDOGENOUS  # Determined by generator dynamics
    >>> wind_speed = VariableRole.EXOGENOUS         # External weather condition
    >>> demand_setpoint = VariableRole.INTERVENTION # Can be adjusted by operators
    >>> line_temperature = VariableRole.OBSERVATION # Measured but not controlled
    >>> equipment_wear = VariableRole.LATENT        # Unmeasured but affects reliability
    >>> fuel_supply = VariableRole.RESOURCE         # Consumable fuel stock
    >>> voltage_limit = VariableRole.CONSTRAINT     # System operational limit
    """

    ENDOGENOUS = auto()
    """Internal variable determined by system mechanisms."""

    EXOGENOUS = auto()
    """External input variable influencing the system."""

    INTERVENTION = auto()
    """Variable that can be directly manipulated."""

    OBSERVATION = auto()
    """Observable but not directly manipulable variable."""

    LATENT = auto()
    """Unobserved variable with causal influence."""

    RESOURCE = auto()
    """Variable representing a consumable resource."""

    CONSTRAINT = auto()
    """Variable representing a system constraint."""


class VariableStatus(Enum):
    """
    Represents the current operational status of a variable.

    The status indicates the variable's state in the causal reasoning process,
    including whether its value is resolved, conflicted, or requires attention.
    This is used for monitoring, debugging, and automated reasoning.

    Attributes
    ----------
    INITIALIZED : VariableStatus
        Variable has been created but no value has been set or processed.
        This is the starting state for all new variables.

    RESOLVED : VariableStatus
        Variable has a single, consistent value that satisfies all constraints.
        This is the normal operational state for functioning variables.

    CONFLICTED : VariableStatus
        Multiple sources propose conflicting values for the variable.
        Requires conflict resolution before the variable can be used.
        Example: Two sensors giving significantly different readings.

    UNCERTAIN : VariableStatus
        Variable has high uncertainty or low confidence in its current value.
        May indicate measurement noise, model uncertainty, or insufficient data.

    VIOLATED : VariableStatus
        Variable's current value violates one or more constraints.
        Requires corrective action or constraint relaxation.
        Example: Temperature exceeding safe operating limits.

    INTERVENED : VariableStatus
        Variable's value has been set by an external intervention.
        This status helps track which variables have been manually controlled.

    OBSERVED : VariableStatus
        Variable's value comes from direct observation/measurement.
        Distinguished from model-predicted or inferred values.

    Notes
    -----
    Status transitions are monitored by the system to trigger appropriate
    actions. For example, a VIOLATED status might trigger an alert or
    automatic constraint enforcement.

    Examples
    --------
    >>> from causaloop import VariableStatus
    >>>
    >>> # Typical status progression
    >>> initial = VariableStatus.INITIALIZED  # New variable
    >>> measured = VariableStatus.OBSERVED    # Value from sensor
    >>> consistent = VariableStatus.RESOLVED  # Validated and consistent
    >>>
    >>> # Problem states requiring attention
    >>> conflicting_sources = VariableStatus.CONFLICTED
    >>> constraint_breach = VariableStatus.VIOLATED
    >>> low_confidence = VariableStatus.UNCERTAIN
    >>> manual_override = VariableStatus.INTERVENED
    """

    INITIALIZED = auto()
    """Variable created but not yet processed."""

    RESOLVED = auto()
    """Value determined and consistent."""

    CONFLICTED = auto()
    """Multiple conflicting values from different sources."""

    UNCERTAIN = auto()
    """Value has high uncertainty or low confidence."""

    VIOLATED = auto()
    """Constraint violation detected."""

    INTERVENED = auto()
    """Value set by external intervention."""

    OBSERVED = auto()
    """Value observed from data/measurement."""


@dataclass
class VariableMetadata:
    """
    Comprehensive metadata container for variable properties and provenance.

    Stores descriptive information, units, domain context, precision requirements,
    timestamps, tags, and custom annotations. This metadata supports:
    - Documentation and understanding of variable purpose
    - Unit consistency checking
    - Domain-specific reasoning
    - Provenance tracking
    - Search and filtering by tags
    - Custom extensions via annotations

    Parameters
    ----------
    name : str
        Human-readable name of the variable. Should be descriptive and unique
        within its context. Example: "reactor_core_temperature"

    description : str, optional
        Detailed description of what the variable represents, its purpose,
        and any relevant context. Default: "" (empty string).

    units : str, optional
        Physical or logical units of measurement. Should follow standard
        notation (e.g., "meters", "kg/s", "USD", "percentage").
        Default: None (unitless).

    domain : str, optional
        Domain or context in which the variable operates. Helps with
        domain-specific reasoning and validation.
        Example: "thermal", "financial", "biological".
        Default: None (generic).

    precision : float, optional
        Required numerical precision for comparisons and calculations.
        Used for tolerance in equality checks and convergence criteria.
        Default: 1e-6.

    created_at : datetime, optional
        Timestamp when the variable was created. Automatically set to
        current UTC time if not specified.

    updated_at : datetime, optional
        Timestamp when the variable metadata was last modified. Automatically
        set to current UTC time if not specified.

    tags : set[str], optional
        Set of tags for categorization and filtering. Tags are case-sensitive
        and should use snake_case or kebab-case conventions.
        Default: empty set.

    annotations : dict[str, Any], optional
        Custom key-value pairs for extended metadata. Supports domain-specific
        extensions without modifying the core structure.
        Default: empty dictionary.

    Attributes
    ----------
    name : str
        See Parameters section.

    description : str
        See Parameters section.

    units : Optional[str]
        See Parameters section.

    domain : Optional[str]
        See Parameters section.

    precision : float
        See Parameters section.

    created_at : datetime
        See Parameters section.

    updated_at : datetime
        See Parameters section.

    tags : set[str]
        See Parameters section.

    annotations : dict[str, Any]
        See Parameters section.

    Methods
    -------
    update()
        Update the last modified timestamp to current UTC time.

    add_tag(tag: str)
        Add a tag to the variable's tag set.

    add_annotation(key: str, value: Any)
        Add or update a custom annotation.

    Examples
    --------
    >>> from datetime import datetime
    >>> from causaloop import VariableMetadata
    >>>
    >>> # Basic metadata for a temperature variable
    >>> temp_metadata = VariableMetadata(
    ...     name="ambient_temperature",
    ...     description="Ambient air temperature at sensor location",
    ...     units="Celsius",
    ...     domain="environmental",
    ...     precision=0.1,  # 0.1 degree precision
    ...     tags={"sensor", "environment", "monitoring"}
    ... )
    >>>
    >>> # Metadata with custom annotations
    >>> stock_metadata = VariableMetadata(
    ...     name="stock_price_XYZ",
    ...     description="Closing price of XYZ Corporation",
    ...     units="USD",
    ...     domain="financial",
    ...     precision=0.01,
    ...     annotations={
    ...         "ticker": "XYZ",
    ...         "exchange": "NASDAQ",
    ...         "sector": "technology",
    ...         "data_source": "market_data_api_v2"
    ...     }
    ... )
    >>>
    >>> # Modifying metadata
    >>> temp_metadata.add_tag("outdoor")
    >>> temp_metadata.add_annotation("sensor_id", "temp_sensor_001")
    >>> temp_metadata.update()  # Refresh updated_at timestamp
    >>>
    >>> print(f"Tags: {temp_metadata.tags}")
    Tags: {'sensor', 'environment', 'monitoring', 'outdoor'}
    >>> print(f"Last updated: {temp_metadata.updated_at}")
    Last updated: 2025-12-10 10:28:53.454682
    """

    name: str
    description: str = ""
    units: str | None = None
    domain: str | None = None
    precision: float = 1e-6
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    tags: set[str] = field(default_factory=set)
    annotations: dict[str, Any] = field(default_factory=dict)

    def update(self) -> None:
        """
        Update the last modified timestamp to current UTC time.

        This method should be called whenever any metadata field is modified
        to maintain accurate provenance tracking.

        Examples
        --------
        >>> import time
        >>> from causaloop import VariableMetadata
        >>> metadata = VariableMetadata(name="test")
        >>> original_time = metadata.updated_at
        >>> time.sleep(0.001)
        >>> metadata.update()
        >>> assert metadata.updated_at > original_time
        """
        self.updated_at = datetime.now(timezone.utc)

    def add_tag(self, tag: str) -> None:
        """
        Add a tag to the variable's tag set.

        Tags are used for categorization, filtering, and search. Duplicate
        tags are automatically ignored (set semantics).

        Parameters
        ----------
        tag : str
            Tag to add. Should be descriptive and follow naming conventions
            (snake_case or kebab-case recommended).

        Raises
        ------
        TypeError
            If tag is not a string.

        Examples
        --------
        >>> from causaloop import VariableMetadata
        >>> metadata = VariableMetadata(name="test")
        >>> metadata.add_tag("experimental")
        >>> metadata.add_tag("high_priority")
        >>> print(metadata.tags)
        {'experimental', 'high_priority'}
        >>>
        >>> # Duplicate tags are ignored
        >>> metadata.add_tag("experimental")
        >>> print(len(metadata.tags))
        2
        """
        if not isinstance(tag, str):
            raise TypeError(f"Tag must be a string, got {type(tag).__name__}")

        self.tags.add(tag)
        self.update()

    def add_annotation(self, key: str, value: Any) -> None:
        """
        Add or update a custom annotation.

        Annotations allow for domain-specific metadata extensions without
        modifying the core metadata structure. They are stored as key-value
        pairs and can contain any serializable data.

        Parameters
        ----------
        key : str
            Annotation key. Should be descriptive and follow naming conventions
            (snake_case recommended).
        value : Any
            Annotation value. Must be JSON-serializable for proper serialization.

        Raises
        ------
        TypeError
            If key is not a string.

        Notes
        -----
        If the key already exists, its value will be overwritten.

        Examples
        --------
        >>> from causaloop import VariableMetadata
        >>> metadata = VariableMetadata(name="test")
        >>>
        >>> # Add various types of annotations
        >>> metadata.add_annotation("version", "1.2.3")
        >>> metadata.add_annotation("calibration_date", "2024-01-15")
        >>> metadata.add_annotation("allowed_range", {"min": 0, "max": 100})
        >>>
        >>> print(metadata.annotations["version"])
        1.2.3
        >>> print(metadata.annotations["allowed_range"]["min"])
        0
        """
        if not isinstance(key, str):
            raise TypeError(
                f"Annotation key must be a string, got {type(key).__name__}"
            )

        self.annotations[key] = value
        self.update()


class Variable(ObservableMixin, SerializableMixin, StatefulMixin[dict[str, Any]], ABC):
    """
    Base class for all Variables in CausaLoop.

    A Variable represents a causal quantity with state, uncertainty, constraints,
    and reasoning capabilities. It serves as the output of mechanisms and can
    participate in causal relationships while maintaining consistency.

    Attributes
    ----------
    metadata : VariableMetadata
        Metadata about the variable including name, description, units, etc.
    role : VariableRole
        Role of the variable in causal relationships.
    status : VariableStatus
        Current status of the variable.
    value : Optional[Any]
        Current value of the variable.
    uncertainty : float
        Current uncertainty level (0=deterministic, 1=completely uncertain).
    constraints : list[Callable]
        List of constraint functions that must be satisfied.
    dependencies : set[str]
        IDs of variables this variable depends on.
    dependents : set[str]
        IDs of variables that depend on this variable.
    confidence : float
        Confidence in current value (0 to 1).
    history : list[tuple[datetime, Any, float]]
        Historical values with timestamps and confidence.

    Examples
    --------
    >>> import numpy as np
    >>> from causaloop import Variable, VariableRole
    >>>
    >>> class Temperature(Variable):
    ...     def validate(self, value: float) -> bool:
    ...         return -273.15 <= value <= 1000.0  # Absolute zero to reasonable max
    ...
    >>> temp = Temperature(
    ...     name="room_temperature",
    ...     description="Ambient room temperature",
    ...     units="Celsius",
    ...     role=VariableRole.ENDOGENOUS
    ... )
    >>> temp.update(22.5, confidence=0.95)
    True
    >>> print(f"Value: {temp.value}°C, Confidence: {temp.confidence:.2f}")
    Value: 22.5°C, Confidence: 0.95
    """

    # Class-level configuration
    DEFAULT_CONFIDENCE: ClassVar[float] = 0.8
    DEFAULT_UNCERTAINTY: ClassVar[float] = 0.1
    MAX_HISTORY_LENGTH: ClassVar[int] = 1000

    def __init__(
        self,
        name: str,
        description: str = "",
        units: str | None = None,
        role: VariableRole = VariableRole.ENDOGENOUS,
        initial_value: Any | None = None,
        initial_confidence: float = DEFAULT_CONFIDENCE,
        config: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize a new Variable.

        Parameters
        ----------
        name : str
            Unique name of the variable.
        description : str, optional
            Human-readable description of the variable.
        units : str, optional
            Physical units of the variable (e.g., "meters", "kg/s").
        role : VariableRole, optional
            Role in causal relationships (default: ENDOGENOUS).
        initial_value : Any, optional
            Initial value of the variable.
        initial_confidence : float, optional
            Initial confidence in the value (default: 0.8).
        config : dict, optional
            Configuration dictionary for the variable.

        Raises
        ------
        ValueError
            If name is empty or confidence not in [0, 1].

        Notes
        -----
        The following events can be subscribed for further analysis:
            validation_failed, value_changed, constraint_added,
            dependency_added, dependent_added, state_restored,
            history_cleared, reset
        """
        # Initialize mixins
        ObservableMixin.__init__(self)
        SerializableMixin.__init__(self)
        StatefulMixin.__init__(self)

        # Generate unique ID
        self._id: str = generate_id("variable")

        # Timestamps
        self._created_at: datetime = datetime.now(timezone.utc)
        self._updated_at: datetime = self._created_at

        # Configuration
        self._config = config or {}

        # Validate inputs
        if not name:
            raise ValueError("Variable name cannot be empty")
        if not 0 <= initial_confidence <= 1:
            raise ValueError(
                f"Confidence must be between 0 and 1, got {initial_confidence}"
            )

        # Core attributes
        self.metadata = VariableMetadata(
            name=name,
            description=description,
            units=units,
        )
        self.role = role
        self.status = VariableStatus.INITIALIZED

        # Value and uncertainty
        self._value: Any | None = None
        self.uncertainty = self.DEFAULT_UNCERTAINTY
        self.confidence = initial_confidence

        # Dependencies and relationships
        self.dependencies: set[str] = set()
        self.dependents: set[str] = set()

        # Constraints and validation
        self.constraints: list[Callable[[Any], bool]] = []
        self.validators: list[Callable[[Any], bool]] = []

        # History tracking
        self.history: list[tuple[datetime, Any | None, float]] = []

        # Initialize with value if provided
        if initial_value is not None:
            self.update(initial_value, initial_confidence)

        logger.debug(
            "Initialized variable %s (id: %s, role: %s)", name, self.id, role.name
        )

    @property
    def id(self) -> str:
        """Get the variable's unique identifier."""
        return self._id

    @property
    def created_at(self) -> datetime:
        """Get the creation timestamp."""
        return self._created_at

    @property
    def updated_at(self) -> datetime:
        """Get the last update timestamp."""
        return self._updated_at

    def touch(self) -> None:
        """Update the last modified timestamp."""
        self._updated_at = datetime.now(timezone.utc)
        self.metadata.update()

    @property
    def value(self) -> Any | None:
        """
        Get the current value of the variable.

        Returns
        -------
        Optional[Any]
            Current value, or None if not set.
        """
        return self._value

    @property
    def name(self) -> str:
        """Get the variable name."""
        return self.metadata.name

    @property
    def units(self) -> str | None:
        """Get the variable units."""
        return self.metadata.units

    @property
    def description(self) -> str:
        """Get the variable description."""
        return self.metadata.description

    def update(
        self,
        value: Any,
        confidence: float = DEFAULT_CONFIDENCE,
        source: str | None = None,
        timestamp: datetime | None = None,
    ) -> bool:
        """
        Update the variable's value with validation.

        Parameters
        ----------
        value : Any
            New value for the variable.
        confidence : float, optional
            Confidence in the new value (default: 0.8).
        source : str, optional
            Source of the update (e.g., mechanism id).
        timestamp : datetime, optional
            Timestamp for the update (default: current time).

        Returns
        -------
        bool
            True if update was successful, False if validation failed.

        Raises
        ------
        ValueError
            If confidence is not in [0, 1].

        Examples
        --------
        >>> from causaloop import Variable, VariableRole
        >>> class TempVariable(Variable):
        ...     def validate(self, value: float) -> bool:
        ...         return 0. <= value <= 100.
        >>> var = TempVariable(name="test", role=VariableRole.ENDOGENOUS)
        >>> var.update(42.0, confidence=0.9)
        True
        >>> var.update(-1, confidence=0.5)  # Assuming a constraint prevents negative values
        Validation failed for variable test: value=-1
        False
        """
        # Validate confidence
        if not 0 <= confidence <= 1:
            raise ValueError(f"Confidence must be between 0 and 1, got {confidence}")

        # Validate value
        if not self._validate_value(value):
            logger.warning(
                "Validation failed for variable %s: value=%s", self.name, value
            )
            self.status = VariableStatus.VIOLATED
            self.notify("validation_failed", value=value, variable=self)
            return False

        # Store old value for notification
        old_value = self._value

        # Update value and metadata
        self._value = value
        self.confidence = confidence
        self.status = VariableStatus.RESOLVED
        self.touch()  # Update timestamp

        # Record history
        ts = timestamp or datetime.now(timezone.utc)
        self.history.append((ts, value, confidence))

        # Trim history if too long
        if len(self.history) > self.MAX_HISTORY_LENGTH:
            self.history = self.history[-self.MAX_HISTORY_LENGTH :]

        # Notify observers
        self.notify(
            "value_changed",
            variable=self,
            old_value=old_value,
            new_value=value,
            confidence=confidence,
            source=source,
        )

        logger.debug(
            "Updated variable %s: value=%s, confidence=%.3f, source=%s",
            self.name,
            value,
            confidence,
            source,
        )
        return True

    def add_constraint(self, constraint: Callable[[Any], bool]) -> None:
        """
        Add a constraint function that must be satisfied by the variable's value.

        Parameters
        ----------
        constraint : Callable[[Any], bool]
            Function that takes a value and returns True if constraint is satisfied.

        Examples
        --------
        >>> from causaloop import Variable, VariableRole
        >>> class AgeVariable(Variable):
        ...     def validate(self, value: int) -> bool:
        ...         return value <= 100
        >>> var = AgeVariable(name="age", role=VariableRole.ENDOGENOUS)
        >>> var.add_constraint(lambda x: x >= 0)
        >>> var.update(45)
        True
        >>> var.update(-5)
        False
        """
        self.constraints.append(constraint)
        self.notify("constraint_added", variable=self, constraint=constraint)
        logger.debug("Added constraint to variable %s", self.name)

    def add_validator(self, validator: Callable[[Any], bool]) -> None:
        """
        Add a validator function for value validation.

        Parameters
        ----------
        validator : Callable[[Any], bool]
            Function that validates a value.
        """
        self.validators.append(validator)
        logger.debug("Added validator to variable %s", self.name)

    def add_dependency(self, variable_id: str) -> None:
        """
        Add a dependency on another variable.

        Parameters
        ----------
        variable_id : str
            ID of the variable this variable depends on.
        """
        self.dependencies.add(variable_id)
        self.notify("dependency_added", variable=self, dependency=variable_id)
        logger.debug("Variable %s now depends on %s", self.name, variable_id)

    def add_dependent(self, variable_id: str) -> None:
        """
        Add a variable that depends on this one.

        Parameters
        ----------
        variable_id : str
            ID of the variable that depends on this variable.
        """
        self.dependents.add(variable_id)
        self.notify("dependent_added", variable=self, dependent=variable_id)
        logger.debug("Variable %s now has dependent %s", self.name, variable_id)

    # SerializableMixin implementation
    def to_dict(self) -> dict[str, Any]:
        """
        Convert variable to dictionary representation.

        Returns
        -------
        dict[str, Any]
            Dictionary containing variable state and metadata.
        """
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "units": self.units,
            "role": self.role.name,
            "status": self.status.name,
            "value": self._serialize_value(self._value),
            "confidence": self.confidence,
            "uncertainty": self.uncertainty,
            "created_at": self._serialize_value(self.created_at),
            "updated_at": self._serialize_value(self.updated_at),
            "dependencies": list(self.dependencies),
            "dependents": list(self.dependents),
            "constraints_count": len(self.constraints),
            "history_length": len(self.history),
            "config": self._config,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Variable:
        """
        Create a variable from dictionary representation.

        Parameters
        ----------
        data : dict[str, Any]
            Dictionary containing variable data.

        Returns
        -------
        Variable
            Reconstructed variable.

        Notes
        -----
        This is a simplified reconstruction. Some runtime state may not be fully restored.
        """
        # Note: This doesn't fully restore all runtime state like constraints
        # It's meant for serialization/deserialization of variable definitions
        instance = cls(
            name=data["name"],
            description=data.get("description", ""),
            units=data.get("units"),
            role=VariableRole[data["role"]],
            config=data.get("config", {}),
        )

        # Restore value if present
        if data.get("value") is not None:
            instance.update(
                data["value"], data.get("confidence", instance.DEFAULT_CONFIDENCE)
            )

        # Restore ID if present
        if "id" in data:
            instance._id = data["id"]

        return instance

    # StatefulMixin implementation
    def get_state(self, last_entries: int = 10) -> dict[str, Any]:
        """
        Get the current state of the variable.

        Returns
        -------
        dict[str, Any]
            Current variable state.
        """
        return {
            "value": self._value,
            "confidence": self.confidence,
            "uncertainty": self.uncertainty,
            "status": self.status.name,
            "history": [
                (ts.isoformat(), val, conf)
                for ts, val, conf in self.history[-last_entries:]
            ],
        }

    def set_state(self, state: dict[str, Any]) -> None:
        """
        Set the variable state.

        Parameters
        ----------
        state : dict
            State to restore.
        """
        # Restore basic state
        self._value = state.get("value")
        self.confidence = state.get("confidence", self.DEFAULT_CONFIDENCE)
        self.uncertainty = state.get("uncertainty", self.DEFAULT_UNCERTAINTY)

        # Restore status
        status_str = state.get("status")
        if status_str:
            try:
                self.status = VariableStatus[status_str]
            except KeyError:
                self.status = VariableStatus.RESOLVED

        # Restore history
        history_data = state.get("history", [])
        self.history = []
        for ts_str, val, conf in history_data:
            try:
                ts = datetime.fromisoformat(ts_str)
                self.history.append((ts, val, conf))
            except (ValueError, TypeError):
                continue

        self.touch()
        self.notify("state_restored", variable=self, state=state)

    def get_history(
        self,
        n: int | None = None,
        since: datetime | None = None,
    ) -> list[tuple[datetime, Any | None, float]]:
        """
        Get historical values of the variable.

        Parameters
        ----------
        n : int, optional
            Number of most recent entries to return.
        since : datetime, optional
            Only return entries since this timestamp.

        Returns
        -------
        list[tuple[datetime, Optional[Any], float]]
            Historical values with timestamps and confidence.
        """
        history = self.history

        if since is not None:
            history = [entry for entry in history if entry[0] >= since]

        if n is not None:
            history = history[-n:]

        return history

    def clear_history(self) -> None:
        """Clear the variable's history."""
        self.history.clear()
        self.notify("history_cleared", variable=self)
        logger.debug("Cleared history for variable %s", self.name)

    def reset(self) -> None:
        """
        Reset the variable to its initial state.

        This clears the value, history, and resets status to INITIALIZED.
        Dependencies and constraints are preserved.
        """
        old_state = self.get_state()

        self._value = None
        self.confidence = self.DEFAULT_CONFIDENCE
        self.uncertainty = self.DEFAULT_UNCERTAINTY
        self.status = VariableStatus.INITIALIZED
        self.clear_history()
        self.touch()

        self.notify("reset", variable=self, old_state=old_state)
        logger.debug("Reset variable %s", self.name)

    @abstractmethod
    def validate(self, value: Any) -> bool:
        """
        Abstract method for value validation.

        Subclasses must implement domain-specific validation logic.

        Parameters
        ----------
        value : Any
            Value to validate.

        Returns
        -------
        bool
            True if value is valid for this variable.
        """
        ...

    def _validate_value(self, value: Any) -> bool:
        """
        Private validation pipeline.

        Parameters
        ----------
        value : Any
            Value to validate.

        Returns
        -------
        bool
            True if value passes all validations and constraints.
        """
        # Run abstract validation first
        if not self.validate(value):
            return False

        # Run registered validators
        for validator in self.validators:
            if not validator(value):
                return False

        # Check constraints
        for constraint in self.constraints:
            if not constraint(value):
                return False

        return True

    def __str__(self) -> str:
        """Representation of the variable."""
        return f"Variable(name={self.name}, id={self.id}, role={self.role.name})"

    def __repr__(self) -> str:
        """Detailed representation of the variable."""
        return (
            f"{self.__class__.__name__}("
            f"name={self.name!r}, "
            f"id={self.id!r}, "
            f"role={self.role}, "
            f"value={self._value}, "
            f"confidence={self.confidence:.3f})"
        )
