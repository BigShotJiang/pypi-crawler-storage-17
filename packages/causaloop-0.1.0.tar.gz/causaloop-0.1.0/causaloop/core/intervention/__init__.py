"""Docstring for causaloop.core.intervention."""
