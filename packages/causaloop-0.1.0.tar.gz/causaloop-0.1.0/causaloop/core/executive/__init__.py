"""Docstring for causaloop.core.executive."""
