"""Docstring for causaloop.integration."""
