"""Docstring for causaloop.integration.external."""
