"""
Statistical computation utilities for causal analysis and time series inference.

This module provides a comprehensive suite of statistical methods designed
specifically for causal inference, time series analysis, and uncertainty
quantification in research-grade applications. All implementations are numerically
stable, handle edge cases robustly, and provide extensive diagnostic information
for research reproducibility.

The module is organized into several specialized analyzers:
- TimeSeriesAnalyzer: Trend detection, seasonality analysis, change point detection
- UncertaintyAnalyzer: Confidence intervals, error propagation, bootstrap methods
- CausalMetrics: Granger causality, transfer entropy, correlation analysis
- AnomalyDetector: Statistical anomaly detection with severity classification
- StatisticalUtils: Core statistical functions with error handling

All methods include:
1. Comprehensive parameter validation
2. Graceful handling of edge cases
3. Detailed metadata for research documentation
4. Execution time tracking
5. Confidence estimates with uncertainty quantification

References
----------
1. Hyndman, R. J., & Athanasopoulos, G. (2018). Forecasting: principles and practice.
   OTexts.
2. Brockwell, P. J., & Davis, R. A. (2016). Introduction to time series and forecasting.
   Springer.
3. Efron, B., & Tibshirani, R. J. (1994). An introduction to the bootstrap. CRC press.
4. Granger, C. W. (1969). Investigating causal relations by econometric models and
   cross-spectral methods. Econometrica: Journal of the Econometric Society, 424-438.
5. Schreiber, T. (2000). Measuring information transfer. Physical review letters, 85(2), 461.

Notes
-----
- All timestamps should be in UTC for consistency
- Missing values are handled using appropriate imputation or exclusion
- Statistical significance is evaluated at alpha=0.05 by default
- Methods assume independent observations unless otherwise specified
"""

from .core import (
    AnomalySeverity,
    ChangePointResult,
    SeasonalityResult,
    SeasonalityType,
    StatisticalResult,
    TrendAnalysisResult,
    TrendDirection,
    UncertaintyResult,
)
from .utils import StatisticalUtils

__all__ = [
    # Core
    "TrendDirection",
    "SeasonalityType",
    "AnomalySeverity",
    "StatisticalResult",
    "TrendAnalysisResult",
    "SeasonalityResult",
    "ChangePointResult",
    "UncertaintyResult",
    # Utils
    "StatisticalUtils",
]
