"""
Core data structures and base classes for statistical analysis.

This module provides the fundamental building blocks for all statistical
analyses in the package, including result containers, enums, and base
classes with comprehensive validation and serialization capabilities.

Classes
-------
TrendDirection
    Enumeration of possible trend directions in time series data.
SeasonalityType
    Enumeration of seasonality patterns in time series data.
AnomalySeverity
    Enumeration of anomaly severity levels based on statistical significance.
StatisticalResult
    Base class for all statistical analysis results.
TrendAnalysisResult
    Result of trend analysis on time series data.
SeasonalityResult
    Result of seasonality analysis on time series data.
ChangePointResult
    Result of change point detection in time series data.
UncertaintyResult
    Result of uncertainty quantification analysis.

Notes
-----
- All result classes include comprehensive validation in __post_init__
- Metadata is designed for research reproducibility
- Serialization methods support JSON export for documentation
- Confidence estimates range from 0.0 to 1.0 with boundary warnings
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any

import numpy as np


class TrendDirection(Enum):
    """
    Enumeration of possible trend directions in time series data.

    Attributes
    ----------
    INCREASING : TrendDirection
        The time series shows a statistically significant positive trend.
        Values tend to increase over time.
    DECREASING : TrendDirection
        The time series shows a statistically significant negative trend.
        Values tend to decrease over time.
    STABLE : TrendDirection
        No statistically significant trend detected. The time series is
        stationary or exhibits no clear directional movement.
    INSUFFICIENT_DATA : TrendDirection
        Cannot determine trend due to insufficient data points or
        non-numeric values.
    CYCLICAL : TrendDirection
        The time series exhibits cyclical patterns without a clear
        long-term direction.

    Examples
    --------
    >>> from causaloop import TrendDirection
    >>> trend = TrendDirection.INCREASING
    >>> print(f"Detected trend: {trend.name}")
    Detected trend: INCREASING
    >>> print(f"Description: {trend.name.lower()} trend")
    Description: increasing trend
    """

    INCREASING = auto()
    DECREASING = auto()
    STABLE = auto()
    INSUFFICIENT_DATA = auto()
    CYCLICAL = auto()


class SeasonalityType(Enum):
    """
    Enumeration of seasonality patterns in time series data.

    Attributes
    ----------
    NONE : SeasonalityType
        No significant seasonal pattern detected.
    DAILY : SeasonalityType
        Daily seasonality (24-hour cycles).
    WEEKLY : SeasonalityType
        Weekly seasonality (7-day cycles).
    MONTHLY : SeasonalityType
        Monthly seasonality (~30-day cycles).
    QUARTERLY : SeasonalityType
        Quarterly seasonality (~90-day cycles).
    YEARLY : SeasonalityType
        Yearly seasonality (365-day cycles).
    MULTIPLE : SeasonalityType
        Multiple seasonal patterns detected.

    Examples
    --------
    >>> from causaloop import SeasonalityType
    >>> seasonality = SeasonalityType.DAILY
    >>> if seasonality != SeasonalityType.NONE:
    ...     print(f"Detected {seasonality.name.lower()} seasonality")
    Detected daily seasonality
    """

    NONE = auto()
    DAILY = auto()
    WEEKLY = auto()
    MONTHLY = auto()
    QUARTERLY = auto()
    YEARLY = auto()
    MULTIPLE = auto()


class AnomalySeverity(Enum):
    """
    Enumeration of anomaly severity levels based on statistical significance.

    Severity is determined by how many standard deviations an observation
    is from the expected value:

    Attributes
    ----------
    NORMAL : AnomalySeverity
        Within 2 standard deviations (≈95% confidence interval).
        Not considered anomalous.
    MILD : AnomalySeverity
        2-3 standard deviations from expected (≈95-99.7% interval).
        Mild anomaly worthy of monitoring.
    MODERATE : AnomalySeverity
        3-4 standard deviations from expected (≈99.7-99.994% interval).
        Moderate anomaly requiring investigation.
    SEVERE : AnomalySeverity
        4-5 standard deviations from expected (≈99.994-99.9999% interval).
        Severe anomaly requiring immediate attention.
    EXTREME : AnomalySeverity
        More than 5 standard deviations from expected.
        Extreme anomaly indicating possible measurement error or
        critical system failure.

    Examples
    --------
    >>> from causaloop import AnomalySeverity
    >>> severity = AnomalySeverity.SEVERE
    >>> if severity.value >= AnomalySeverity.MODERATE.value:
    ...     print(f"High severity anomaly detected: {severity.name}")
    High severity anomaly detected: SEVERE
    """

    NORMAL = auto()
    MILD = auto()
    MODERATE = auto()
    SEVERE = auto()
    EXTREME = auto()


@dataclass(kw_only=True)
class StatisticalResult:
    """
    Base class for all statistical analysis results.

    Provides a standardized structure for returning statistical analysis
    results with success status, confidence estimates, and comprehensive
    metadata for research reproducibility.

    Attributes
    ----------
    success : bool
        Whether the statistical analysis completed successfully.
        If False, the result may contain partial or default values.
    confidence : float
        Confidence estimate in the analysis result, ranging from 0.0 to 1.0.
        Represents the statistical confidence or reliability of the result.
    metadata : Dict[str, Any]
        Additional metadata about the analysis process, including:
        - Method used and parameters
        - Sample statistics
        - Computational details
        - Warnings or limitations
    error_message : Optional[str]
        Error message if the analysis failed. None if successful.
    execution_time_ms : Optional[float]
        Execution time in milliseconds for performance monitoring.

    Examples
    --------
    >>> from causaloop import StatisticalResult
    >>> result = StatisticalResult(
    ...     success=True,
    ...     confidence=0.95,
    ...     metadata={"method": "linear_regression", "n_samples": 100},
    ...     execution_time_ms=15.2
    ... )
    >>> print(f"Analysis succeeded with {result.confidence:.1%} confidence")
    Analysis succeeded with 95.0% confidence

    Notes
    -----
    - Confidence values are automatically validated in __post_init__
    - Metadata should include sufficient detail for reproducibility
    - Execution time helps with performance optimization
    - Error messages provide context for debugging failed analyses
    """

    success: bool
    confidence: float
    metadata: dict[str, Any] = field(default_factory=dict)
    error_message: str | None = None
    execution_time_ms: float | None = None

    def __post_init__(self) -> None:
        """
        Validate the statistical result after initialization.

        Performs validation checks and issues warnings for potential issues.

        Raises
        ------
        ValueError
            If confidence is outside valid range [0, 1].

        Warns
        -----
        UserWarning
            If confidence is close to boundary values (0 or 1) which may
            indicate overconfidence or numerical issues.
        """
        if not 0 <= self.confidence <= 1:
            raise ValueError(
                f"Confidence must be in range [0, 1], got {self.confidence}"
            )

        if self.confidence < 0.01:
            warnings.warn(
                f"Extremely low confidence ({self.confidence:.4f}) may indicate "
                "unreliable analysis or insufficient data",
                RuntimeWarning,
                stacklevel=2,
            )
        elif self.confidence > 0.999:
            warnings.warn(
                f"Extremely high confidence ({self.confidence:.4f}) may indicate "
                "overfitting or unrealistic assumptions",
                RuntimeWarning,
                stacklevel=2,
            )

    def to_dict(self) -> dict[str, Any]:
        """
        Convert result to dictionary for serialization.

        Returns
        -------
        Dict[str, Any]
            Dictionary representation of the result suitable for JSON
            serialization or storage.

        Examples
        --------
        >>> from causaloop import StatisticalResult
        >>> result = StatisticalResult(success=True, confidence=0.9)
        >>> result_dict = result.to_dict()
        >>> print(result_dict.keys())
        dict_keys(['success', 'confidence', 'metadata', 'error_message',
                    'execution_time_ms', 'timestamp'])
        """
        return {
            "success": self.success,
            "confidence": self.confidence,
            "metadata": self.metadata,
            "error_message": self.error_message,
            "execution_time_ms": self.execution_time_ms,
            "timestamp": datetime.now().isoformat(),
        }

    def __str__(self) -> str:
        """Return human-readable string representation."""
        status = "SUCCESS" if self.success else "FAILED"
        confidence_pct = f"{self.confidence:.1%}"
        time_str = (
            f"{self.execution_time_ms:.1f} ms" if self.execution_time_ms else "N/A"
        )

        return (
            f"StatisticalResult(status={status}, confidence={confidence_pct}, "
            f"time={time_str}, metadata_keys={len(self.metadata)})"
        )


@dataclass
class TrendAnalysisResult(StatisticalResult):
    """
    Result of trend analysis on time series data.

    Contains comprehensive information about detected trends including
    direction, strength, statistical significance, and model parameters.

    Attributes
    ----------
    direction : TrendDirection
        Direction of the detected trend (increasing, decreasing, stable, etc.).
    slope : float
        Slope of the trend line (change per time unit).
        Positive for increasing trends, negative for decreasing trends.
    intercept : float
        Intercept of the trend line at time zero.
    r_squared : float
        Coefficient of determination (R²) indicating goodness of fit.
        Range: 0.0 (no fit) to 1.0 (perfect fit).
    p_value : float
        P-value for the trend significance test.
        Typically compared against alpha=0.05 threshold.
    strength : float
        Normalized measure of trend strength from 0.0 (no trend) to 1.0
        (strong trend). Combines slope magnitude and statistical significance.
    is_significant : bool
        Whether the trend is statistically significant at the chosen
        significance level (default alpha=0.05).
    sample_size : int
        Number of data points used in the analysis.
    slope_se : Optional[float] = None
        Standard error of the slope estimate. None if not calculated.
    confidence_interval : Optional[Tuple[float, float]] = None
        95% confidence interval for the slope. None if not calculated.
    residuals : Optional[np.ndarray] = None
        Residuals from the trend model. Useful for diagnostic checking.

    Examples
    --------
    >>> from causaloop import TrendAnalysisResult, TrendDirection
    >>> result = TrendAnalysisResult(
    ...     success=True,
    ...     confidence=0.92,
    ...     direction=TrendDirection.INCREASING,
    ...     slope=0.5,
    ...     intercept=10.0,
    ...     r_squared=0.85,
    ...     p_value=0.001,
    ...     strength=0.8,
    ...     is_significant=True,
    ...     sample_size=100
    ... )
    >>> if result.is_significant:
    ...     print(f"Significant {result.direction.name.lower()} trend detected")
    ...     print(f"Rate of change: {result.slope:.3f} per time unit")
    Significant increasing trend detected
    Rate of change: 0.500 per time unit

    Notes
    -----
    - R² values close to 1.0 indicate the trend model explains most variance
    - P-values < 0.05 are typically considered statistically significant
    - Strength is calculated as: strength = |slope| * (1 - p_value) / scale_factor
    - Always check residuals for patterns indicating model misspecification
    """

    direction: TrendDirection
    slope: float
    intercept: float
    r_squared: float
    p_value: float
    strength: float
    is_significant: bool
    sample_size: int
    slope_se: float | None = None
    confidence_interval: tuple[float, float] | None = None
    residuals: np.ndarray | None = None

    def __post_init__(self) -> None:
        """
        Validate trend analysis result.

        Performs additional validation specific to trend analysis results.

        Raises
        ------
        ValueError
            If sample size is negative, R² is outside [0, 1], or p-value is
            outside [0, 1].

        Warns
        -----
        RuntimeWarning
            If R² is suspiciously high (>0.999) which may indicate overfitting.
        """
        super().__post_init__()

        if self.sample_size < 0:
            raise ValueError(f"Sample size cannot be negative: {self.sample_size}")

        if not 0 <= self.r_squared <= 1:
            raise ValueError(f"R-squared must be in [0, 1], got {self.r_squared}")

        if not 0 <= self.p_value <= 1:
            raise ValueError(f"P-value must be in [0, 1], got {self.p_value}")

        if not 0 <= self.strength <= 1:
            warnings.warn(
                f"Trend strength {self.strength} is outside typical range [0, 1]",
                RuntimeWarning,
                stacklevel=2,
            )

        if self.r_squared > 0.999 and self.sample_size < 100:
            warnings.warn(
                f"R² = {self.r_squared:.4f} with n={self.sample_size} may indicate "
                "overfitting. Consider cross-validation.",
                RuntimeWarning,
                stacklevel=2,
            )

    def get_trend_description(self) -> str:
        """
        Get a human-readable description of the trend.

        Returns
        -------
        str
            Descriptive text summarizing the trend analysis result.

        Examples
        --------
        >>> from causaloop import TrendAnalysisResult, TrendDirection
        >>> result = TrendAnalysisResult(
        ...     success=True, confidence=0.9,
        ...     direction=TrendDirection.INCREASING,
        ...     slope=0.5, intercept=0.5, r_squared=0.85, p_value=0.01,
        ...     strength=0.7, is_significant=True, sample_size=50
        ... )
        >>> print(result.get_trend_description())
        statistically significant increasing trend (slope = 0.500, R² = 0.850, p = 0.010)
        """
        if not self.success:
            return "Trend analysis failed"

        if self.direction == TrendDirection.INSUFFICIENT_DATA:
            return "Insufficient data for trend analysis"

        significance = (
            "statistically significant"
            if self.is_significant
            else "not statistically significant"
        )
        direction = self.direction.name.lower()

        return (
            f"{significance} {direction} trend "
            f"(slope = {self.slope:.3f}, "
            f"R² = {self.r_squared:.3f}, "
            f"p = {self.p_value:.3f})"
        )

    def __str__(self) -> str:
        """Return human-readable string representation."""
        base_str = super().__str__()
        trend_desc = self.get_trend_description()
        return f"{base_str}: {trend_desc}"


@dataclass
class SeasonalityResult(StatisticalResult):
    """
    Result of seasonality analysis on time series data.

    Identifies and characterizes seasonal patterns in time series data,
    including period, strength, and decomposition components.

    Attributes
    ----------
    seasonality_type : SeasonalityType
        Type of seasonality detected (daily, weekly, monthly, etc.).
    period : Optional[int]
        Primary seasonal period in time units. None if no seasonality detected.
    strength : float
        Strength of the seasonal pattern from 0.0 (no seasonality) to 1.0
        (strong seasonality). Calculated as proportion of variance explained
        by seasonal component.
    seasonal_component : Optional[np.ndarray]
        Estimated seasonal component of the time series. Same length as
        input data. None if seasonality not detected or decomposition failed.
    trend_component : Optional[np.ndarray]
        Estimated trend component from seasonal decomposition.
    residual_component : Optional[np.ndarray]
        Residuals after removing trend and seasonal components.
    seasonal_peaks : Optional[List[int]] = None
        Indices of seasonal peaks within one period.
    seasonal_troughs : Optional[List[int]] = None
        Indices of seasonal troughs within one period.
    amplitude : Optional[float] = None
        Amplitude of the seasonal pattern (peak-to-trough difference).
    phase : Optional[float] = None
        Phase shift of the seasonal pattern in radians.

    Examples
    --------
    >>> from causaloop import SeasonalityResult, SeasonalityType
    >>> result = SeasonalityResult(
    ...     success=True,
    ...     confidence=0.88,
    ...     seasonality_type=SeasonalityType.DAILY,
    ...     period=24,
    ...     strength=0.65,
    ...     amplitude=15.2,
    ...     metadata={"method": "STL", "decomposition": "additive"}
    ... )
    >>> if result.strength > 0.3:
    ...     print(f"Strong {result.seasonality_type.name.lower()} seasonality detected")
    ...     print(f"Period: {result.period} time units, Strength: {result.strength:.2f}")
    Strong daily seasonality detected
    Period: 24 time units, Strength: 0.65

    Notes
    -----
    - Seasonality strength > 0.3 is typically considered meaningful
    - Multiple seasonal periods can be handled through the MULTIPLE type
    - Decomposition uses additive model by default: data = trend + seasonal + residual
    - For multiplicative patterns, consider log transformation first
    """

    seasonality_type: SeasonalityType
    period: int | None
    strength: float
    seasonal_component: np.ndarray | None = None
    trend_component: np.ndarray | None = None
    residual_component: np.ndarray | None = None
    seasonal_peaks: list[int] | None = None
    seasonal_troughs: list[int] | None = None
    amplitude: float | None = None
    phase: float | None = None

    def __post_init__(self) -> None:
        """
        Validate seasonality analysis result.

        Raises
        ------
        ValueError
            If period is not positive when seasonality is detected, or
            strength is outside [0, 1].
        """
        super().__post_init__()

        if self.seasonality_type != SeasonalityType.NONE and self.period is not None:
            if self.period <= 0:
                raise ValueError(f"Seasonal period must be positive, got {self.period}")
            if self.period > 10000:
                warnings.warn(
                    f"Unusually large seasonal period: {self.period}. "
                    "Check time units and data frequency.",
                    RuntimeWarning,
                    stacklevel=2,
                )

        if not 0 <= self.strength <= 1:
            raise ValueError(
                f"Seasonality strength must be in [0, 1], got {self.strength}"
            )

        if self.strength > 0.9:
            warnings.warn(
                f"Extremely high seasonality strength ({self.strength:.3f}). "
                "Verify data hasn't been detrended already.",
                RuntimeWarning,
                stacklevel=2,
            )

    def get_seasonality_description(self) -> str:
        """
        Get a human-readable description of the seasonality.

        Returns
        -------
        str
            Descriptive text summarizing the seasonality analysis result.

        Examples
        --------
        >>> from causaloop import SeasonalityResult, SeasonalityType
        >>> result = SeasonalityResult(
        ...     success=True,
        ...     confidence=0.78,
        ...     seasonality_type=SeasonalityType.WEEKLY,
        ...     period=7,
        ...     strength=0.45
        ... )
        >>> print(result.get_seasonality_description())
        weekly seasonality detected (period=7, strength=0.45)
        """
        if not self.success:
            return "Seasonality analysis failed"

        if self.seasonality_type == SeasonalityType.NONE:
            return "No significant seasonality detected"

        seasonality_name = self.seasonality_type.name.lower()
        period_str = f" (period={self.period}" if self.period else ""
        strength_str = f", strength={self.strength:.2f})"

        return f"{seasonality_name} seasonality detected{period_str}{strength_str}"

    def __str__(self) -> str:
        """Return human-readable string representation."""
        base_str = super().__str__()
        seasonality_desc = self.get_seasonality_description()
        return f"{base_str}: {seasonality_desc}"


@dataclass
class ChangePointResult(StatisticalResult):
    """
    Result of change point detection in time series data.

    Identifies points where the statistical properties of a time series
    change significantly, indicating regime changes, interventions, or
    structural breaks.

    Attributes
    ----------
    change_points : List[int]
        Indices where change points are detected (0-based indexing).
    confidence_scores : List[float]
        Confidence scores for each detected change point [0, 1].
    change_types : List[str]
        Type of change at each point (e.g., 'mean', 'variance', 'trend', 'both').
    magnitudes : List[float]
        Magnitude of change at each point (normalized).
    segments : List[Tuple[int, int]]
        Start and end indices of homogeneous segments between change points.
    segment_stats : List[Dict[str, Any]]
        Statistical properties of each segment (mean, variance, etc.).

    Examples
    --------
    >>> from causaloop import ChangePointResult
    >>> result = ChangePointResult(
    ...     success=True,
    ...     confidence=0.87,
    ...     change_points=[49, 99],
    ...     confidence_scores=[0.92, 0.78],
    ...     change_types=['mean', 'variance'],
    ...     magnitudes=[2.5, 1.8],
    ...     segments=[],
    ...     segment_stats=[]
    ... )
    >>> for i, cp in enumerate(result.change_points):
    ...     print(f"Change at index {cp}: {result.change_types[i]} "
    ...           f"(confidence: {result.confidence_scores[i]:.2f})")
    Change at index 49: mean (confidence: 0.92)
    Change at index 99: variance (confidence: 0.78)

    Notes
    -----
    - Change points divide the time series into statistically homogeneous segments
    - Multiple algorithms available: binary segmentation, PELT, window-based
    - Confidence scores help prioritize important changes
    - Consider false discovery rate control for multiple testing
    """

    change_points: list[int]
    confidence_scores: list[float]
    change_types: list[str]
    magnitudes: list[float]
    segments: list[tuple[int, int]]
    segment_stats: list[dict[str, Any]]

    def __post_init__(self) -> None:
        """
        Validate change point detection result.

        Raises
        ------
        ValueError
            If lengths of change_points, confidence_scores, change_types,
            or magnitudes don't match.
        """
        super().__post_init__()

        n_changes = len(self.change_points)
        if len(self.confidence_scores) != n_changes:
            raise ValueError(
                f"Mismatch: {n_changes} change points but "
                f"{len(self.confidence_scores)} confidence scores"
            )

        if len(self.change_types) != n_changes:
            raise ValueError(
                f"Mismatch: {n_changes} change points but "
                f"{len(self.change_types)} change types"
            )

        if len(self.magnitudes) != n_changes:
            raise ValueError(
                f"Mismatch: {n_changes} change points but "
                f"{len(self.magnitudes)} magnitudes"
            )

        # Validate confidence scores
        for i, score in enumerate(self.confidence_scores):
            if not 0 <= score <= 1:
                warnings.warn(
                    f"Confidence score {score} at index {i} is outside [0, 1]",
                    RuntimeWarning,
                    stacklevel=2,
                )

        # Validate change points are sorted
        if not all(
            self.change_points[i] < self.change_points[i + 1]
            for i in range(n_changes - 1)
        ):
            warnings.warn(
                "Change points are not sorted in ascending order",
                RuntimeWarning,
                stacklevel=2,
            )

    def get_change_description(self) -> str:
        """
        Get a human-readable description of detected change points.

        Returns
        -------
        str
            Descriptive text summarizing the change point analysis.

        Examples
        --------
        >>> from causaloop import ChangePointResult
        >>> result = ChangePointResult(
        ...     success=True,
        ...     confidence=0.85,
        ...     change_points=[50, 150],
        ...     confidence_scores=[0.9, 0.8],
        ...     change_types=['mean', 'variance'],
        ...     magnitudes=[2.0, 1.5],
        ...     segments=[(0, 49), (50, 149), (150, 199)],
        ...     segment_stats=[{}, {}, {}]
        ... )
        >>> print(result.get_change_description())
        Detected 2 change points at indices [50, 150] with mean confidence 0.85
        """
        if not self.success:
            return "Change point detection failed"

        n_changes = len(self.change_points)
        if n_changes == 0:
            return "No change points detected"

        avg_confidence = (
            np.mean(self.confidence_scores) if self.confidence_scores else 0.0
        )

        return (
            f"Detected {n_changes} change point{'s' if n_changes != 1 else ''} "
            f"at indices {self.change_points} with mean confidence {avg_confidence:.2f}"
        )

    def __str__(self) -> str:
        """Return human-readable string representation."""
        base_str = super().__str__()
        change_desc = self.get_change_description()
        return f"{base_str}: {change_desc}"


@dataclass
class UncertaintyResult(StatisticalResult):
    """
    Result of uncertainty quantification analysis.

    Quantifies uncertainty in measurements, estimates, or predictions using
    statistical methods like bootstrapping, Monte Carlo simulation, or
    analytical error propagation.

    Attributes
    ----------
    estimate : float
        Point estimate (mean, median, or other central tendency).
    lower_bound : float
        Lower bound of the confidence/credible interval.
    upper_bound : float
        Upper bound of the confidence/credible interval.
    interval_width : float
        Width of the confidence interval (upper_bound - lower_bound).
    interval_type : str
        Type of interval ('confidence', 'credible', 'prediction').
    confidence_level : float
        Confidence level of the interval (e.g., 0.95 for 95% CI).
    standard_error : Optional[float]
        Standard error of the estimate. None if not applicable.
    distribution_type : Optional[str]
        Assumed or estimated distribution type.
    distribution_params : Optional[Dict[str, float]]
        Parameters of the distribution.
    samples : Optional[np.ndarray]
        Bootstrap or Monte Carlo samples used for estimation.

    Examples
    --------
    >>> from causaloop import UncertaintyResult
    >>> result = UncertaintyResult(
    ...     success=True,
    ...     confidence=0.95,
    ...     estimate=10.5,
    ...     lower_bound=9.8,
    ...     upper_bound=11.2,
    ...     interval_width=1.4,
    ...     interval_type="confidence",
    ...     confidence_level=0.95,
    ...     standard_error=0.35,
    ...     metadata={"method": "bootstrap", "n_samples": 10000}
    ... )
    >>> print(f"Estimate: {result.estimate:.2f}")
    Estimate: 10.50
    >>> print(f"95% CI: ({result.lower_bound:.2f}, {result.upper_bound:.2f})")
    95% CI: (9.80, 11.20)

    Notes
    -----
    - Bootstrap intervals are non-parametric and make fewer assumptions
    - Prediction intervals are wider than confidence intervals as they include
      observation error
    - For small samples (<30), consider t-distribution based intervals
    - Bayesian credible intervals have different interpretation than
      frequentist confidence intervals
    """

    estimate: float
    lower_bound: float
    upper_bound: float
    interval_width: float
    interval_type: str
    confidence_level: float
    standard_error: float | None = None
    distribution_type: str | None = None
    distribution_params: dict[str, float] | None = None
    samples: np.ndarray | None = None

    def __post_init__(self) -> None:
        """
        Validate uncertainty quantification result.

        Raises
        ------
        ValueError
            If lower_bound > upper_bound, confidence_level not in (0, 1),
            or interval_width doesn't match bounds.
        """
        super().__post_init__()

        if self.lower_bound > self.upper_bound:
            raise ValueError(
                f"Lower bound ({self.lower_bound}) cannot be greater than "
                f"upper bound ({self.upper_bound})"
            )

        if not 0 < self.confidence_level < 1:
            raise ValueError(
                f"Confidence level must be in (0, 1), got {self.confidence_level}"
            )

        calculated_width = self.upper_bound - self.lower_bound
        if not np.isclose(self.interval_width, calculated_width, rtol=1e-10):
            warnings.warn(
                f"Interval width {self.interval_width} doesn't match "
                f"calculated width {calculated_width}",
                RuntimeWarning,
                stacklevel=2,
            )

        if self.standard_error is not None and self.standard_error < 0:
            warnings.warn(
                f"Negative standard error: {self.standard_error}",
                RuntimeWarning,
                stacklevel=2,
            )

    def contains_value(self, value: float) -> bool:
        """
        Check if a value is within the confidence interval.

        Parameters
        ----------
        value : float
            Value to check against the confidence interval.

        Returns
        -------
        bool
            True if the value is within the interval (inclusive),
            False otherwise.

        Examples
        --------
        >>> from causaloop import UncertaintyResult
        >>> result = UncertaintyResult(
        ...     success=True, confidence=0.9,
        ...     estimate=10.0, lower_bound=9.0, upper_bound=11.0,
        ...     interval_width=2.0, interval_type="confidence",
        ...     confidence_level=0.95
        ... )
        >>> print(result.contains_value(10.5))
        True
        >>> print(result.contains_value(12.0))
        False
        """
        return self.lower_bound <= value <= self.upper_bound

    def get_interval_description(self) -> str:
        """
        Get a human-readable description of the uncertainty result.

        Returns
        -------
        str
            Descriptive text summarizing the uncertainty analysis.

        Examples
        --------
        >>> from causaloop import UncertaintyResult
        >>> result = UncertaintyResult(
        ...     success=True,
        ...     confidence=0.97,
        ...     estimate=10.5,
        ...     lower_bound=9.8,
        ...     upper_bound=11.2,
        ...     interval_width=1.4,
        ...     interval_type="confidence",
        ...     confidence_level=0.95
        ... )
        >>> print(result.get_interval_description())
        95% confidence interval: 10.50 (9.80, 11.20) [width: 1.40]
        """
        if not self.success:
            return "Uncertainty quantification failed"

        conf_pct = f"{self.confidence_level:.0%}"
        return (
            f"{conf_pct} {self.interval_type} interval: "
            f"{self.estimate:.2f} ({self.lower_bound:.2f}, {self.upper_bound:.2f}) "
            f"[width: {self.interval_width:.2f}]"
        )

    def __str__(self) -> str:
        """Return human-readable string representation."""
        base_str = super().__str__()
        interval_desc = self.get_interval_description()
        return f"{base_str}: {interval_desc}"
