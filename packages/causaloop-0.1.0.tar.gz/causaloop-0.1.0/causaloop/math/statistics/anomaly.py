"""Docstring for causaloop.math.statistics.anomaly."""
