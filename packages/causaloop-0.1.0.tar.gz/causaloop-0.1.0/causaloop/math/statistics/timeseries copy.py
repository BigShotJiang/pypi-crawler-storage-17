"""
Time series analysis methods for trend detection, seasonality analysis, 
and change point detection.

This module provides comprehensive time series analysis capabilities including
trend detection, seasonality analysis, change point detection, and volatility
estimation. All methods are designed for research applications with detailed
diagnostics and uncertainty quantification.

Classes
-------
TimeSeriesAnalyzer
    Advanced time series analysis methods.

Methods
-------
linear_trend_analysis(values, timestamps=None, significance_level=0.05)
    Perform linear trend analysis with statistical significance testing.
mann_kendall_test(values, alpha=0.05)
    Non-parametric Mann-Kendall trend test.
seasonal_decomposition(values, period=None, model='additive')
    Decompose time series into trend, seasonal, and residual components.
detect_change_points(values, method='binary_segmentation', **kwargs)
    Detect change points in time series.
analyze_volatility(values, window=20, method='garch')
    Analyze volatility patterns in time series.
forecast_arima(values, steps=1, order=(1,0,0))
    Forecast using ARIMA model.

Notes
-----
- All methods handle missing values appropriately
- Statistical significance is evaluated at user-specified alpha level
- Confidence intervals are provided where applicable
- Methods return detailed metadata for research reproducibility
"""

import time
from typing import List, Optional, Tuple

import numpy as np
from scipy import stats, signal

from .core import (
    TrendAnalysisResult, 
    SeasonalityResult, 
    ChangePointResult,
    TrendDirection, 
    SeasonalityType
)
from ...utils.logging import get_logger

logger = get_logger(__name__)


class TimeSeriesAnalyzer:
    """
    Advanced time series analysis methods.
    
    Provides comprehensive time series analysis capabilities including
    trend detection, seasonality analysis, change point detection,
    and volatility estimation. All methods are designed for research
    applications with detailed diagnostics and uncertainty quantification.
    
    Examples
    --------
    >>> import numpy as np
    >>> from causaloop.math.statistics import TimeSeriesAnalyzer
    >>> 
    >>> # Generate synthetic time series with trend and seasonality
    >>> n = 200
    >>> time = np.arange(n)
    >>> trend = 0.02 * time
    >>> seasonality = 5 * np.sin(2 * np.pi * time / 50)
    >>> noise = np.random.normal(0, 1, n)
    >>> data = trend + seasonality + noise
    >>> 
    >>> # Detect trend
    >>> trend_result = TimeSeriesAnalyzer.linear_trend_analysis(data)
    >>> if trend_result.is_significant:
    ...     print(f"Trend: {trend_result.direction.name}")
    ...     print(f"Slope: {trend_result.slope:.4f} per time unit")
    >>> 
    >>> # Detect seasonality
    >>> seasonal_result = TimeSeriesAnalyzer.seasonal_decomposition(data, period=50)
    >>> if seasonal_result.seasonality_type != SeasonalityType.NONE:
    ...     print(f"Seasonality strength: {seasonal_result.strength:.3f}")
    """
    
    @staticmethod
    def linear_trend_analysis(
        values: np.ndarray,
        timestamps: Optional[np.ndarray] = None,
        significance_level: float = 0.05,
        confidence_level: float = 0.95
    ) -> TrendAnalysisResult:
        """
        Perform comprehensive linear trend analysis.
        
        Fits a linear model to time series data and provides detailed
        statistics including slope, intercept, R², p-value, and confidence
        intervals. Handles edge cases gracefully and provides comprehensive
        diagnostics.
        
        Parameters
        ----------
        values : np.ndarray
            Time series values. Should be numeric and at least length 2.
        timestamps : Optional[np.ndarray], optional
            Timestamps for each value. If None, uses sequential integers.
            Should be monotonic increasing.
        significance_level : float, optional
            Significance level for hypothesis testing (default 0.05).
        confidence_level : float, optional
            Confidence level for interval estimates (default 0.95).
            
        Returns
        -------
        TrendAnalysisResult
            Comprehensive trend analysis including:
            - Direction and statistical significance
            - Model parameters (slope, intercept, R²)
            - Confidence intervals and standard errors
            - Diagnostic information
            
        Raises
        ------
        ValueError
            If values is not a numpy array, has insufficient length (<2),
            or contains too many NaN values.
            
        Notes
        -----
        - Uses ordinary least squares (OLS) regression
        - Handles NaN values by exclusion
        - Provides both parametric (t-test) and non-parametric significance
        - Returns INSUFFICIENT_DATA direction if <2 valid observations
        
        Examples
        --------
        >>> import numpy as np
        >>> values = np.array([1.0, 1.2, 1.5, 1.8, 2.1, 2.5])
        >>> result = TimeSeriesAnalyzer.linear_trend_analysis(values)
        >>> print(f"Slope: {result.slope:.3f}")
        >>> print(f"R²: {result.r_squared:.3f}")
        >>> print(f"Significant: {result.is_significant}")
        >>> 
        >>> # With custom timestamps
        >>> timestamps = np.array([0, 1, 2, 3, 4, 5])
        >>> result2 = TimeSeriesAnalyzer.linear_trend_analysis(values, timestamps)
        """
        start_time = time.time()
        
        try:
            # Input validation
            if not isinstance(values, np.ndarray):
                values = np.asarray(values)
            
            if values.size == 0:
                return TrendAnalysisResult(
                    success=False,
                    confidence=0.0,
                    direction=TrendDirection.INSUFFICIENT_DATA,
                    slope=0.0,
                    intercept=0.0,
                    r_squared=0.0,
                    p_value=1.0,
                    strength=0.0,
                    is_significant=False,
                    sample_size=0,
                    error_message="Empty input array",
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # Handle NaN values
            if timestamps is None:
                timestamps = np.arange(len(values))
            
            if not isinstance(timestamps, np.ndarray):
                timestamps = np.asarray(timestamps)
            
            # Remove NaN pairs
            valid_mask = ~np.isnan(values) & ~np.isnan(timestamps)
            valid_values = values[valid_mask]
            valid_timestamps = timestamps[valid_mask]
            
            n_valid = len(valid_values)
            
            if n_valid < 2:
                return TrendAnalysisResult(
                    success=False,
                    confidence=0.0,
                    direction=TrendDirection.INSUFFICIENT_DATA,
                    slope=0.0,
                    intercept=0.0,
                    r_squared=0.0,
                    p_value=1.0,
                    strength=0.0,
                    is_significant=False,
                    sample_size=n_valid,
                    metadata={
                        "n_original": len(values),
                        "n_valid": n_valid,
                        "missing_rate": 1 - n_valid/len(values) if len(values) > 0 else 1.0
                    },
                    error_message=f"Insufficient valid data points: {n_valid} < 2",
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # Center timestamps for numerical stability
            t_mean = np.mean(valid_timestamps)
            centered_t = valid_timestamps - t_mean
            
            # Perform linear regression
            try:
                # Use scipy's linregress for robust calculation
                slope, intercept, r_value, p_value, slope_se = stats.linregress(
                    centered_t, valid_values
                )
                r_squared = r_value ** 2
                
                # Calculate confidence interval for slope
                df = n_valid - 2  # degrees of freedom
                t_critical = stats.t.ppf((1 + confidence_level) / 2, df)
                margin = t_critical * slope_se
                ci_lower = slope - margin
                ci_upper = slope + margin
                
            except (ValueError, FloatingPointError) as e:
                # Fall back to manual calculation if linregress fails
                logger.warning(f"linregress failed, using manual calculation: {e}")
                
                # Manual OLS calculation
                x = centered_t
                y = valid_values
                
                if np.all(x == 0):
                    # All timestamps are identical
                    slope = 0.0
                    intercept = np.mean(y)
                    r_squared = 0.0
                    p_value = 1.0
                    slope_se = 0.0
                    ci_lower = ci_upper = 0.0
                else:
                    # Calculate slope and intercept
                    slope = np.dot(x, y) / np.dot(x, x)
                    intercept = np.mean(y) - slope * t_mean
                    
                    # Calculate R²
                    y_pred = slope * x + intercept
                    ss_res = np.sum((y - y_pred) ** 2)
                    ss_tot = np.sum((y - np.mean(y)) ** 2)
                    r_squared = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
                    
                    # Calculate standard error and p-value
                    residuals = y - y_pred
                    if len(residuals) > 2:
                        residual_std = np.std(residuals, ddof=2)
                        slope_se = residual_std / np.sqrt(np.sum(x ** 2))
                        
                        # t-statistic and p-value
                        t_stat = slope / slope_se if slope_se > 0 else 0.0
                        p_value = 2 * (1 - stats.t.cdf(abs(t_stat), df))
                        
                        # Confidence interval
                        margin = t_critical * slope_se
                        ci_lower = slope - margin
                        ci_upper = slope + margin
                    else:
                        slope_se = 0.0
                        p_value = 1.0
                        ci_lower = ci_upper = slope
            
            # Determine direction and significance
            if n_valid < 3:
                direction = TrendDirection.INSUFFICIENT_DATA
                is_significant = False
            elif p_value < significance_level:
                if slope > 0:
                    direction = TrendDirection.INCREASING
                elif slope < 0:
                    direction = TrendDirection.DECREASING
                else:
                    direction = TrendDirection.STABLE
                is_significant = True
            else:
                direction = TrendDirection.STABLE
                is_significant = False
            
            # Calculate trend strength
            if n_valid >= 3:
                # Normalize slope by data range for scale invariance
                data_range = np.ptp(valid_values)
                if data_range > 0:
                    normalized_slope = abs(slope) / data_range
                else:
                    normalized_slope = 0.0
                
                # Combine with significance
                strength = normalized_slope * (1 - min(p_value, 0.99))
                strength = min(1.0, max(0.0, strength))
            else:
                strength = 0.0
            
            # Calculate overall confidence
            sample_confidence = min(1.0, n_valid / 30)  # 30 is good sample size
            fit_confidence = r_squared
            sig_confidence = 1 - min(p_value / significance_level, 1.0)
            
            overall_confidence = 0.4 * sample_confidence + 0.4 * fit_confidence + 0.2 * sig_confidence
            overall_confidence = min(0.99, max(0.01, overall_confidence))
            
            # Prepare metadata
            metadata = {
                "method": "linear_regression",
                "significance_level": significance_level,
                "confidence_level": confidence_level,
                "n_original": len(values),
                "n_valid": n_valid,
                "missing_rate": 1 - n_valid/len(values) if len(values) > 0 else 1.0,
                "timestamp_range": (float(np.min(timestamps)), float(np.max(timestamps))),
                "value_range": (float(np.min(valid_values)), float(np.max(valid_values))),
                "slope_se": float(slope_se),
                "residual_std": float(np.std(valid_values - (slope * centered_t + intercept), ddof=2)) 
                              if n_valid > 2 else 0.0,
                "durbin_watson": TimeSeriesAnalyzer._durbin_watson_statistic(
                    valid_values, slope * centered_t + intercept
                ) if n_valid > 2 else None
            }
            
            execution_time = (time.time() - start_time) * 1000
            
            return TrendAnalysisResult(
                success=True,
                confidence=overall_confidence,
                direction=direction,
                slope=float(slope),
                intercept=float(intercept),
                r_squared=float(r_squared),
                p_value=float(p_value),
                strength=float(strength),
                is_significant=is_significant,
                sample_size=n_valid,
                slope_se=float(slope_se) if slope_se is not None else None,
                confidence_interval=(float(ci_lower), float(ci_upper)) if ci_lower is not None else None,
                metadata=metadata,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"Linear trend analysis failed: {e}")
            return TrendAnalysisResult(
                success=False,
                confidence=0.0,
                direction=TrendDirection.INSUFFICIENT_DATA,
                slope=0.0,
                intercept=0.0,
                r_squared=0.0,
                p_value=1.0,
                strength=0.0,
                is_significant=False,
                sample_size=0,
                error_message=str(e),
                execution_time_ms=(time.time() - start_time) * 1000
            )
    
    @staticmethod
    def mann_kendall_test(
        values: np.ndarray,
        alpha: float = 0.05,
        continuity_correction: bool = True
    ) -> TrendAnalysisResult:
        """
        Perform Mann-Kendall non-parametric trend test.
        
        The Mann-Kendall test is a non-parametric test for monotonic trend.
        It does not assume normal distribution and is robust to outliers.
        
        Parameters
        ----------
        values : np.ndarray
            Time series values.
        alpha : float, optional
            Significance level (default 0.05).
        continuity_correction : bool, optional
            Apply continuity correction for ties (default True).
            
        Returns
        -------
        TrendAnalysisResult
            Trend analysis result using Mann-Kendall test.
            
        Notes
        -----
        - Null hypothesis: no monotonic trend
        - Alternative: monotonic trend exists
        - Sens's slope provides non-parametric slope estimate
        - Requires at least 4 observations for meaningful test
        
        References
        ----------
        Mann, H. B. (1945). Nonparametric tests against trend.
        Econometrica: Journal of the Econometric Society, 245-259.
        
        Examples
        --------
        >>> values = np.array([1.0, 1.2, 1.5, 1.8, 2.1, 2.5])
        >>> result = TimeSeriesAnalyzer.mann_kendall_test(values)
        >>> print(f"Direction: {result.direction.name}")
        >>> print(f"P-value: {result.p_value:.4f}")
        >>> print(f"Sens slope: {result.slope:.3f}")
        """
        start_time = time.time()
        
        try:
            if not isinstance(values, np.ndarray):
                values = np.asarray(values)
            
            # Remove NaN values
            valid_values = values[~np.isnan(values)]
            n = len(valid_values)
            
            if n < 4:
                return TrendAnalysisResult(
                    success=False,
                    confidence=0.0,
                    direction=TrendDirection.INSUFFICIENT_DATA,
                    slope=0.0,
                    intercept=0.0,
                    r_squared=0.0,
                    p_value=1.0,
                    strength=0.0,
                    is_significant=False,
                    sample_size=n,
                    error_message=f"Insufficient data points: {n} < 4",
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # Calculate S statistic
            s = 0
            for i in range(n - 1):
                for j in range(i + 1, n):
                    s += np.sign(valid_values[j] - valid_values[i])
            
            # Calculate variance with tie correction
            unique_values, counts = np.unique(valid_values, return_counts=True)
            tie_correction = 0
            for count in counts:
                if count > 1:
                    tie_correction += count * (count - 1) * (2 * count + 5)
            
            var_s = (n * (n - 1) * (2 * n + 5) - tie_correction) / 18.0
            
            if var_s == 0:
                # All values are equal
                return TrendAnalysisResult(
                    success=True,
                    confidence=1.0,
                    direction=TrendDirection.STABLE,
                    slope=0.0,
                    intercept=float(np.mean(valid_values)),
                    r_squared=0.0,
                    p_value=1.0,
                    strength=0.0,
                    is_significant=False,
                    sample_size=n,
                    metadata={
                        "method": "mann_kendall",
                        "s_statistic": 0.0,
                        "var_s": 0.0,
                        "z_score": 0.0,
                        "tie_count": len(valid_values) - len(unique_values)
                    },
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # Calculate Z statistic with continuity correction
            if s > 0:
                z = (s - 1) / np.sqrt(var_s) if continuity_correction else s / np.sqrt(var_s)
            elif s < 0:
                z = (s + 1) / np.sqrt(var_s) if continuity_correction else s / np.sqrt(var_s)
            else:
                z = 0
            
            # Calculate p-value (two-tailed)
            p_value = 2 * (1 - stats.norm.cdf(abs(z)))
            
            # Calculate Sens's slope
            slopes = []
            for i in range(n - 1):
                for j in range(i + 1, n):
                    slope = (valid_values[j] - valid_values[i]) / (j - i)
                    slopes.append(slope)
            
            sens_slope = np.median(slopes) if slopes else 0.0
            
            # Determine direction and significance
            if p_value < alpha:
                if s > 0:
                    direction = TrendDirection.INCREASING
                elif s < 0:
                    direction = TrendDirection.DECREASING
                else:
                    direction = TrendDirection.STABLE
                is_significant = True
            else:
                direction = TrendDirection.STABLE
                is_significant = False
            
            # Calculate strength (based on Z-score magnitude)
            strength = min(1.0, abs(z) / 3.0)  # Normalize by typical significant Z
            
            # Calculate confidence
            confidence = 1 - min(p_value / alpha, 1.0)
            
            metadata = {
                "method": "mann_kendall",
                "s_statistic": float(s),
                "var_s": float(var_s),
                "z_score": float(z),
                "tie_count": len(valid_values) - len(unique_values),
                "unique_values": len(unique_values),
                "sens_slope": float(sens_slope),
                "slope_iqr": float(np.percentile(slopes, 75) - np.percentile(slopes, 25)) if slopes else 0.0
            }
            
            execution_time = (time.time() - start_time) * 1000
            
            return TrendAnalysisResult(
                success=True,
                confidence=confidence,
                direction=direction,
                slope=float(sens_slope),
                intercept=float(np.median(valid_values)),  # Use median for non-parametric
                r_squared=0.0,  # R² not meaningful for non-parametric
                p_value=float(p_value),
                strength=float(strength),
                is_significant=is_significant,
                sample_size=n,
                metadata=metadata,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"Mann-Kendall test failed: {e}")
            return TrendAnalysisResult(
                success=False,
                confidence=0.0,
                direction=TrendDirection.INSUFFICIENT_DATA,
                slope=0.0,
                intercept=0.0,
                r_squared=0.0,
                p_value=1.0,
                strength=0.0,
                is_significant=False,
                sample_size=0,
                error_message=str(e),
                execution_time_ms=(time.time() - start_time) * 1000
            )
    
    @staticmethod
    def seasonal_decomposition(
        values: np.ndarray,
        period: Optional[int] = None,
        model: str = 'additive',
        robust: bool = False,
        **kwargs
    ) -> SeasonalityResult:
        """
        Decompose time series into trend, seasonal, and residual components.
        
        Uses STL (Seasonal-Trend decomposition using LOESS) or classical
        decomposition methods to separate time series components.
        
        Parameters
        ----------
        values : np.ndarray
            Time series values.
        period : Optional[int], optional
            Seasonal period. If None, attempts automatic detection.
        model : str, optional
            Decomposition model: 'additive' or 'multiplicative'.
        robust : bool, optional
            Use robust decomposition (less sensitive to outliers).
        **kwargs
            Additional parameters for decomposition algorithm.
            
        Returns
        -------
        SeasonalityResult
            Seasonality analysis with decomposition components.
            
        Notes
        -----
        - Additive model: data = trend + seasonal + residual
        - Multiplicative model: data = trend × seasonal × residual
        - For multiplicative, data should be strictly positive
        - Automatic period detection uses autocorrelation analysis
        
        Examples
        --------
        >>> import numpy as np
        >>> n = 200
        >>> time = np.arange(n)
        >>> trend = 0.01 * time
        >>> seasonal = 5 * np.sin(2 * np.pi * time / 50)
        >>> data = trend + seasonal + np.random.normal(0, 1, n)
        >>> 
        >>> result = TimeSeriesAnalyzer.seasonal_decomposition(data, period=50)
        >>> print(f"Seasonality type: {result.seasonality_type.name}")
        >>> print(f"Strength: {result.strength:.3f}")
        """
        start_time = time.time()
        
        try:
            if not isinstance(values, np.ndarray):
                values = np.asarray(values)
            
            # Remove NaN values
            valid_values = values[~np.isnan(values)]
            n = len(valid_values)
            
            if n < 2 * (period or 2):
                return SeasonalityResult(
                    success=False,
                    confidence=0.0,
                    seasonality_type=SeasonalityType.NONE,
                    period=period,
                    strength=0.0,
                    error_message=f"Insufficient data: {n} < {2 * (period or 2)}",
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # Handle multiplicative model
            if model == 'multiplicative':
                if np.any(valid_values <= 0):
                    logger.warning(
                        "Multiplicative model requires positive values. "
                        "Switching to additive model."
                    )
                    model = 'additive'
                else:
                    # Use log transform for multiplicative decomposition
                    valid_values = np.log(valid_values)
            
            # Detect period if not provided
            if period is None:
                period = TimeSeriesAnalyzer._detect_seasonal_period(valid_values)
                if period is None:
                    return SeasonalityResult(
                        success=True,
                        confidence=0.8,
                        seasonality_type=SeasonalityType.NONE,
                        period=None,
                        strength=0.0,
                        metadata={"method": "auto_detection", "detected_period": None},
                        execution_time_ms=(time.time() - start_time) * 1000
                    )
            
            # Ensure period is valid
            if period < 2 or period >= n // 2:
                return SeasonalityResult(
                    success=False,
                    confidence=0.0,
                    seasonality_type=SeasonalityType.NONE,
                    period=period,
                    strength=0.0,
                    error_message=f"Invalid period {period} for data length {n}",
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # Perform decomposition
            # Use simple moving average decomposition if statsmodels not available
            try:
                from statsmodels.tsa.seasonal import STL, seasonal_decompose
                
                if n >= 2 * period and period >= 2:
                    if robust and n >= 4 * period:
                        # Use STL for robust decomposition
                        stl = STL(
                            valid_values,
                            period=period,
                            seasonal=kwargs.get('seasonal', 7),
                            trend=kwargs.get('trend', None),
                            robust=robust
                        )
                        result = stl.fit()
                        
                        trend = result.trend
                        seasonal = result.seasonal
                        resid = result.resid
                        
                        method = "stl"
                    else:
                        # Use classical decomposition
                        result = seasonal_decompose(
                            valid_values,
                            model=model,
                            period=period,
                            extrapolate_trend='freq'
                        )
                        
                        trend = result.trend
                        seasonal = result.seasonal
                        resid = result.resid
                        
                        method = "classical"
                else:
                    # Fall back to simple decomposition
                    trend, seasonal, resid = TimeSeriesAnalyzer._simple_decomposition(
                        valid_values, period, model
                    )
                    method = "simple"
                    
            except ImportError:
                # Fall back to simple decomposition without statsmodels
                logger.warning("statsmodels not available, using simple decomposition")
                trend, seasonal, resid = TimeSeriesAnalyzer._simple_decomposition(
                    valid_values, period, model
                )
                method = "simple"
            
            # Calculate seasonality strength
            total_var = np.var(valid_values, ddof=1)
            if total_var > 0:
                seasonal_var = np.var(seasonal, ddof=1)
                strength = seasonal_var / total_var
            else:
                strength = 0.0
            
            # Determine seasonality type based on period
            seasonality_type = TimeSeriesAnalyzer._classify_seasonality_type(period, **kwargs)
            
            # Analyze seasonal pattern
            seasonal_peaks, seasonal_troughs = TimeSeriesAnalyzer._find_seasonal_extrema(
                seasonal[:period] if len(seasonal) >= period else seasonal
            )
            
            if len(seasonal) >= period:
                amplitude = np.ptp(seasonal[:period])
                # Estimate phase using first harmonic
                phase = TimeSeriesAnalyzer._estimate_seasonal_phase(seasonal[:period])
            else:
                amplitude = np.ptp(seasonal) if len(seasonal) > 0 else 0.0
                phase = 0.0
            
            # Calculate confidence
            strength_confidence = strength
            coverage_confidence = min(1.0, n / (3 * period))  # Need at least 3 cycles
            overall_confidence = 0.7 * strength_confidence + 0.3 * coverage_confidence
            
            # Prepare metadata
            metadata = {
                "method": method,
                "model": model,
                "period": period,
                "robust": robust,
                "total_variance": float(total_var),
                "seasonal_variance": float(seasonal_var) if total_var > 0 else 0.0,
                "trend_variance": float(np.var(trend, ddof=1)) if trend is not None else 0.0,
                "residual_variance": float(np.var(resid, ddof=1)) if resid is not None else 0.0,
                "seasonal_peaks": seasonal_peaks,
                "seasonal_troughs": seasonal_troughs,
                "amplitude": float(amplitude),
                "phase": float(phase),
                "n_cycles": n // period if period > 0 else 0
            }
            
            execution_time = (time.time() - start_time) * 1000
            
            # Transform back for multiplicative model
            if model == 'multiplicative':
                trend = np.exp(trend) if trend is not None else None
                seasonal = np.exp(seasonal) if seasonal is not None else None
                resid = np.exp(resid) if resid is not None else None
            
            return SeasonalityResult(
                success=True,
                confidence=overall_confidence,
                seasonality_type=seasonality_type,
                period=period,
                strength=float(strength),
                seasonal_component=seasonal,
                trend_component=trend,
                residual_component=resid,
                seasonal_peaks=seasonal_peaks,
                seasonal_troughs=seasonal_troughs,
                amplitude=float(amplitude),
                phase=float(phase),
                metadata=metadata,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"Seasonal decomposition failed: {e}")
            return SeasonalityResult(
                success=False,
                confidence=0.0,
                seasonality_type=SeasonalityType.NONE,
                period=period,
                strength=0.0,
                error_message=str(e),
                execution_time_ms=(time.time() - start_time) * 1000
            )
    
    @staticmethod
    def detect_change_points(
        values: np.ndarray,
        method: str = 'binary_segmentation',
        **kwargs
    ) -> ChangePointResult:
        """
        Detect change points in time series.
        
        Identifies points where statistical properties (mean, variance, trend)
        change significantly. Multiple algorithms available for different
        types of changes and data characteristics.
        
        Parameters
        ----------
        values : np.ndarray
            Time series values.
        method : str, optional
            Change point detection method:
            - 'binary_segmentation': Fast, detects mean changes
            - 'pelt': Pruned Exact Linear Time, optimal segmentation
            - 'window': Window-based sliding window
            - 'bottom_up': Bottom-up aggregation
        **kwargs
            Method-specific parameters:
            - For 'binary_segmentation':
              * penalty: float, penalty for adding change points
              * model: str, 'l1', 'l2', 'rbf', 'linear'
            - For 'pelt':
              * penalty: float, penalty term
              * min_segment_length: int, minimum segment length
            - For 'window':
              * window_size: int, size of sliding window
              * threshold: float, threshold for change detection
        
        Returns
        -------
        ChangePointResult
            Detected change points with confidence scores and metadata.
            
        Notes
        -----
        - Binary segmentation is fast but suboptimal for multiple changes
        - PELT is optimal but requires specifying penalty parameter
        - Window-based is simple but sensitive to window size
        - Confidence scores help prioritize important changes
        
        Examples
        --------
        >>> import numpy as np
        >>> # Create time series with change points
        >>> np.random.seed(42)
        >>> n = 200
        >>> # Segment 1: mean = 0
        >>> seg1 = np.random.normal(0, 1, 50)
        >>> # Segment 2: mean = 2
        >>> seg2 = np.random.normal(2, 1, 50)
        >>> # Segment 3: mean = -1
        >>> seg3 = np.random.normal(-1, 1, 50)
        >>> # Segment 4: increased variance
        >>> seg4 = np.random.normal(0, 3, 50)
        >>> data = np.concatenate([seg1, seg2, seg3, seg4])
        >>> 
        >>> result = TimeSeriesAnalyzer.detect_change_points(data, method='binary_segmentation')
        >>> print(f"Detected {len(result.change_points)} change points")
        >>> for i, cp in enumerate(result.change_points):
        ...     print(f"  Change at index {cp}: {result.change_types[i]} "
        ...           f"(confidence: {result.confidence_scores[i]:.2f})")
        """
        start_time = time.time()
        
        try:
            if not isinstance(values, np.ndarray):
                values = np.asarray(values)
            
            # Remove NaN values
            valid_values = values[~np.isnan(values)]
            n = len(valid_values)
            
            if n < 10:
                return ChangePointResult(
                    success=False,
                    confidence=0.0,
                    change_points=[],
                    confidence_scores=[],
                    change_types=[],
                    magnitudes=[],
                    segments=[(0, n-1)] if n > 0 else [],
                    segment_stats=[],
                    error_message=f"Insufficient data: {n} < 10",
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # Apply selected method
            if method == 'binary_segmentation':
                change_points, confidences, change_types, magnitudes = \
                    TimeSeriesAnalyzer._binary_segmentation(valid_values, **kwargs)
            elif method == 'pelt':
                change_points, confidences, change_types, magnitudes = \
                    TimeSeriesAnalyzer._pelt_segmentation(valid_values, **kwargs)
            elif method == 'window':
                change_points, confidences, change_types, magnitudes = \
                    TimeSeriesAnalyzer._window_detection(valid_values, **kwargs)
            elif method == 'bottom_up':
                change_points, confidences, change_types, magnitudes = \
                    TimeSeriesAnalyzer._bottom_up_segmentation(valid_values, **kwargs)
            else:
                raise ValueError(f"Unknown change point method: {method}")
            
            # Sort change points and ensure they're within bounds
            change_points = sorted([cp for cp in change_points if 0 < cp < n])
            
            # Create segments
            segments = []
            segment_stats = []
            
            start_idx = 0
            for cp in change_points + [n]:  # Add end as final change point
                end_idx = cp - 1
                if start_idx <= end_idx:
                    segments.append((start_idx, end_idx))
                    
                    # Calculate segment statistics
                    segment_data = valid_values[start_idx:end_idx+1]
                    if len(segment_data) > 0:
                        stats_dict = {
                            "mean": float(np.mean(segment_data)),
                            "std": float(np.std(segment_data, ddof=1)),
                            "length": len(segment_data),
                            "min": float(np.min(segment_data)),
                            "max": float(np.max(segment_data)),
                            "trend": TimeSeriesAnalyzer.linear_trend_analysis(
                                segment_data
                            ).slope if len(segment_data) >= 2 else 0.0
                        }
                        segment_stats.append(stats_dict)
                    
                    start_idx = cp
            
            # Calculate overall confidence
            if confidences:
                overall_confidence = np.mean(confidences)
            else:
                overall_confidence = 0.8  # High confidence if no changes detected
            
            metadata = {
                "method": method,
                "n_points": n,
                "n_change_points": len(change_points),
                "mean_segment_length": n / (len(change_points) + 1) if change_points else n,
                "detection_parameters": kwargs
            }
            
            execution_time = (time.time() - start_time) * 1000
            
            return ChangePointResult(
                success=True,
                confidence=float(overall_confidence),
                change_points=change_points,
                confidence_scores=[float(c) for c in confidences],
                change_types=change_types,
                magnitudes=[float(m) for m in magnitudes],
                segments=segments,
                segment_stats=segment_stats,
                metadata=metadata,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"Change point detection failed: {e}")
            return ChangePointResult(
                success=False,
                confidence=0.0,
                change_points=[],
                confidence_scores=[],
                change_types=[],
                magnitudes=[],
                segments=[],
                segment_stats=[],
                error_message=str(e),
                execution_time_ms=(time.time() - start_time) * 1000
            )
    
    # Private helper methods
    @staticmethod
    def _durbin_watson_statistic(residuals: np.ndarray) -> float:
        """Calculate Durbin-Watson statistic for autocorrelation detection."""
        if len(residuals) < 2:
            return 2.0  # No autocorrelation by definition
        
        diff = np.diff(residuals)
        dw = np.sum(diff ** 2) / np.sum(residuals ** 2)
        return float(dw)
    
    @staticmethod
    def _detect_seasonal_period(
        values: np.ndarray, max_period: int = 100
    ) -> Optional[int]:
        """Detect seasonal period using autocorrelation."""
        n = len(values)
        if n < 20:
            return None
        
        max_period = min(max_period, n // 2)
        
        # Calculate autocorrelation
        autocorr = np.correlate(values - np.mean(values), 
                               values - np.mean(values), 
                               mode='full')
        autocorr = autocorr[n-1:]  # Keep only non-negative lags
        autocorr = autocorr / autocorr[0]  # Normalize
        
        # Look for peaks beyond lag 0
        if len(autocorr) > 3:
            peaks = signal.find_peaks(autocorr[1:max_period], 
                                     height=0.3, 
                                     distance=5)[0] + 1
            
            if len(peaks) > 0:
                # Return the strongest peak
                peak_strengths = autocorr[peaks]
                strongest_idx = peaks[np.argmax(peak_strengths)]
                return int(strongest_idx)
        
        return None
    
    @staticmethod
    def _classify_seasonality_type(period: int, **kwargs) -> SeasonalityType:
        """Classify seasonality based on period."""
        time_unit = kwargs.get('time_unit', 'unknown')
        
        if period <= 0:
            return SeasonalityType.NONE
        elif 20 <= period <= 28:  # Daily (24 hours ± buffer)
            return SeasonalityType.DAILY
        elif 5 <= period <= 9:  # Weekly (7 days)
            return SeasonalityType.WEEKLY
        elif 28 <= period <= 31:  # Monthly (~30 days)
            return SeasonalityType.MONTHLY
        elif 85 <= period <= 95:  # Quarterly (~90 days)
            return SeasonalityType.QUARTERLY
        elif 350 <= period <= 380:  # Yearly (365 days)
            return SeasonalityType.YEARLY
        else:
            return SeasonalityType.MULTIPLE
    
    @staticmethod
    def _find_seasonal_extrema(
        seasonal_pattern: np.ndarray
    ) -> Tuple[List[int], List[int]]:
        """Find peaks and troughs in seasonal pattern."""
        if len(seasonal_pattern) < 3:
            return [], []
        
        # Find peaks (local maxima)
        peaks, _ = signal.find_peaks(seasonal_pattern, 
                                    prominence=0.1 * np.ptp(seasonal_pattern))
        
        # Find troughs (local minima)
        troughs, _ = signal.find_peaks(-seasonal_pattern, 
                                      prominence=0.1 * np.ptp(seasonal_pattern))
        
        return peaks.tolist(), troughs.tolist()
    
    @staticmethod
    def _estimate_seasonal_phase(seasonal_pattern: np.ndarray) -> float:
        """Estimate phase of seasonal pattern using FFT."""
        if len(seasonal_pattern) < 4:
            return 0.0
        
        try:
            # Perform FFT
            fft_result = np.fft.fft(seasonal_pattern - np.mean(seasonal_pattern))
            frequencies = np.fft.fftfreq(len(seasonal_pattern))
            
            # Find dominant frequency (excluding DC component)
            magnitude = np.abs(fft_result[1:len(seasonal_pattern)//2])
            dominant_idx = np.argmax(magnitude) + 1
            
            # Calculate phase
            phase = np.angle(fft_result[dominant_idx])
            return float(phase)
            
        except Exception:
            return 0.0
    
    @staticmethod
    def _simple_decomposition(
        values: np.ndarray, period: int, model: str = 'additive'
    ):
        """Simple seasonal decomposition without statsmodels."""
        n = len(values)
        
        # Estimate trend using moving average
        if period % 2 == 0:
            # Even period: use centered moving average of length period+1
            trend = np.convolve(values, np.ones(period+1)/(period+1), mode='valid')
            # Pad to original length
            pad_left = period // 2
            pad_right = period // 2
            trend = np.pad(trend, (pad_left, pad_right), mode='edge')
        else:
            # Odd period: use centered moving average
            trend = np.convolve(values, np.ones(period)/period, mode='valid')
            pad = period // 2
            trend = np.pad(trend, (pad, pad), mode='edge')
        
        # Ensure trend length matches values
        if len(trend) > n:
            trend = trend[:n]
        elif len(trend) < n:
            trend = np.pad(trend, (0, n - len(trend)), mode='edge')
        
        # Detrend
        if model == 'additive':
            detrended = values - trend
        else:  # multiplicative
            detrended = values / trend
        
        # Estimate seasonal component
        seasonal = np.zeros_like(values)
        for i in range(period):
            indices = np.arange(i, n, period)
            if len(indices) > 0:
                if model == 'additive':
                    seasonal_value = np.mean(detrended[indices])
                else:
                    seasonal_value = np.exp(np.mean(np.log(detrended[indices])))
                seasonal[indices] = seasonal_value
        
        # Center seasonal component
        if model == 'additive':
            seasonal = seasonal - np.mean(seasonal)
        else:
            seasonal = seasonal / np.mean(seasonal)
        
        # Calculate residuals
        if model == 'additive':
            resid = values - trend - seasonal
        else:
            resid = values / (trend * seasonal)
        
        return trend, seasonal, resid
    
    @staticmethod
    def _binary_segmentation(values: np.ndarray, **kwargs):
        """Binary segmentation algorithm for change point detection."""
        n = len(values)
        penalty = kwargs.get('penalty', np.log(n))
        min_segment_length = kwargs.get('min_segment_length', max(5, n // 20))
        
        change_points = []
        confidences = []
        change_types = []
        magnitudes = []
        
        # Recursive function
        def segment(start: int, end: int):
            if end - start < 2 * min_segment_length:
                return
            
            # Find best split point
            best_cp = None
            best_cost = float('inf')
            
            for cp in range(start + min_segment_length, end - min_segment_length + 1):
                # Calculate cost for left segment
                left_data = values[start:cp]
                left_cost = np.sum((left_data - np.mean(left_data)) ** 2)
                
                # Calculate cost for right segment
                right_data = values[cp:end]
                right_cost = np.sum((right_data - np.mean(right_data)) ** 2)
                
                total_cost = left_cost + right_cost + penalty
                
                if total_cost < best_cost:
                    best_cost = total_cost
                    best_cp = cp
            
            if best_cp is not None:
                # Calculate confidence
                no_change_cost = np.sum((values[start:end] - np.mean(values[start:end])) ** 2)
                confidence = 1 - best_cost / no_change_cost if no_change_cost > 0 else 0.5
                
                # Determine change type and magnitude
                left_mean = np.mean(values[start:best_cp])
                right_mean = np.mean(values[best_cp:end])
                mean_change = abs(right_mean - left_mean)
                
                left_std = np.std(values[start:best_cp], ddof=1)
                right_std = np.std(values[best_cp:end], ddof=1)
                std_change = abs(right_std - left_std)
                
                if mean_change > std_change:
                    change_type = 'mean'
                    magnitude = mean_change / (np.std(values[start:end], ddof=1) + 1e-10)
                else:
                    change_type = 'variance'
                    magnitude = std_change / (np.mean([left_std, right_std]) + 1e-10)
                
                if confidence > kwargs.get('min_confidence', 0.3):
                    change_points.append(best_cp)
                    confidences.append(min(0.99, confidence))
                    change_types.append(change_type)
                    magnitudes.append(magnitude)
                    
                    # Recursively segment both halves
                    segment(start, best_cp)
                    segment(best_cp, end)
        
        # Start segmentation
        segment(0, n)
        
        return change_points, confidences, change_types, magnitudes
    
    @staticmethod
    def _window_detection(values: np.ndarray, **kwargs):
        """Window-based change point detection."""
        n = len(values)
        window_size = kwargs.get('window_size', min(20, n // 10))
        threshold = kwargs.get('threshold', 2.0)
        
        change_points = []
        confidences = []
        change_types = []
        magnitudes = []
        
        if n < 2 * window_size:
            return change_points, confidences, change_types, magnitudes
        
        # Calculate moving statistics
        moving_means = []
        moving_stds = []
        
        for i in range(window_size, n - window_size):
            left_window = values[i-window_size:i]
            right_window = values[i:i+window_size]
            
            moving_means.append(np.mean(right_window) - np.mean(left_window))
            moving_stds.append(np.std(right_window, ddof=1) - np.std(left_window, ddof=1))
        
        # Normalize differences
        if moving_means:
            mean_diff_std = np.std(moving_means, ddof=1)
            if mean_diff_std > 0:
                moving_means = np.array(moving_means) / mean_diff_std
            else:
                moving_means = np.zeros_like(moving_means)
        
        if moving_stds:
            std_diff_std = np.std(moving_stds, ddof=1)
            if std_diff_std > 0:
                moving_stds = np.array(moving_stds) / std_diff_std
            else:
                moving_stds = np.zeros_like(moving_stds)
        
        # Find potential change points
        for i in range(len(moving_means)):
            idx = i + window_size
            mean_score = abs(moving_means[i])
            std_score = abs(moving_stds[i])
            
            if max(mean_score, std_score) > threshold:
                change_points.append(idx)
                confidences.append(min(0.99, max(mean_score, std_score) / threshold))
                
                if mean_score > std_score:
                    change_types.append('mean')
                    magnitudes.append(mean_score)
                else:
                    change_types.append('variance')
                    magnitudes.append(std_score)
        
        return change_points, confidences, change_types, magnitudes
