"""
Core statistical utilities with robust error handling.

This module provides fundamental statistical functions with comprehensive
validation, NaN handling, and edge case protection. All methods are designed
to be numerically stable and return sensible defaults when data is insufficient
or invalid.

Classes
-------
StatisticalUtils
    Core statistical utilities with robust error handling.

Methods
-------
safe_mean(arr, default=0.0, skipna=True)
    Calculate mean with NaN/Inf handling and validation.
safe_std(arr, default=0.0, ddof=1, skipna=True)
    Calculate standard deviation with robust error handling.
safe_percentile(arr, q, default=0.0)
    Calculate percentiles with edge case protection.
is_numeric_array(arr)
    Check if array contains convertible numeric values.
remove_outliers_iqr(arr, multiplier=1.5)
    Remove outliers using IQR method.
winsorize(arr, limits=(0.05, 0.05))
    Winsorize array to limit extreme values.
calculate_skewness(arr)
    Calculate sample skewness (Fisher-Pearson coefficient).
calculate_kurtosis(arr, fisher=True)
    Calculate sample kurtosis.

Notes
-----
- All methods handle NaN values appropriately (skip or propagate)
- Default values are returned when calculation is not possible
- Input validation prevents silent errors
- Methods are stateless and thread-safe
"""

from typing import Any

import numpy as np

from ...utils.logging import get_logger

logger = get_logger(__name__)


class StatisticalUtils:
    """
    Core statistical utilities with robust error handling.

    Provides fundamental statistical functions with comprehensive
    validation, NaN handling, and edge case protection. All methods
    are designed to be numerically stable and return sensible defaults
    when data is insufficient or invalid.

    Examples
    --------
    >>> import numpy as np
    >>> from causaloop import StatisticalUtils
    >>>
    >>> # Handle arrays with missing values
    >>> data = np.array([1.0, 2.0, np.nan, 4.0, 5.0])
    >>> mean = StatisticalUtils.safe_mean(data)
    >>> print(f"Mean (ignoring NaN): {mean:.2f}")
    Mean (ignoring NaN): 3.00
    >>>
    >>> # Handle empty arrays gracefully
    >>> empty_data = np.array([])
    >>> std = StatisticalUtils.safe_std(empty_data, default=1.0)
    >>> print(f"Std of empty array: {std:.2f}")
    Std of empty array: 1.00
    """

    @staticmethod
    def safe_mean(arr: np.ndarray, default: float = 0.0, skipna: bool = True) -> float:
        """
        Calculate mean of array with robust error handling.

        Parameters
        ----------
        arr : np.ndarray
            Input array. Can contain NaN or Inf values.
        default : float, optional
            Default value to return if mean cannot be calculated.
        skipna : bool, optional
            If True, skip NaN and Inf values. If False, NaN propagates.

        Returns
        -------
        float
            Mean of valid values in array, or default if calculation fails.

        Raises
        ------
        TypeError
            If input is not a numpy array or convertible to one.

        Examples
        --------
        >>> import numpy as np
        >>> from causaloop import StatisticalUtils
        >>> StatisticalUtils.safe_mean([1, 2, 3, 4, 5])
        3.0
        >>> StatisticalUtils.safe_mean([1, 2, np.nan, 4, 5])
        3.0
        >>> StatisticalUtils.safe_mean([])
        0.0
        >>> StatisticalUtils.safe_mean([], default=np.nan)
        nan
        """
        try:
            arr = np.asarray(arr)

            if arr.size == 0:
                return default

            if skipna:
                arr = arr.astype(float, copy=False)
                valid = np.isfinite(arr)

                if not np.any(valid):
                    return default

                return float(np.mean(arr[valid]))
            else:
                return float(np.mean(arr))

        except (TypeError, ValueError) as e:
            logger.warning(f"Error calculating mean: {e}. Returning default: {default}")
            return default

    @staticmethod
    def safe_std(
        arr: np.ndarray, default: float = 0.0, ddof: int = 1, skipna: bool = True
    ) -> float:
        """
        Calculate standard deviation with robust error handling.

        Parameters
        ----------
        arr : np.ndarray
            Input array. Can contain NaN or Inf values.
        default : float, optional
            Default value to return if std cannot be calculated.
        ddof : int, optional
            Delta degrees of freedom. The divisor used is N - ddof.
        skipna : bool, optional
            If True, skip NaN and Inf values. If False, NaN propagates.

        Returns
        -------
        float
            Standard deviation of valid values, or default if calculation fails.

        Notes
        -----
        - Returns default when the number of valid observations is <= ddof
        - Uses Bessel's correction by default (ddof=1)
        - For population std, use ddof=0

        Examples
        --------
        >>> from causaloop import StatisticalUtils
        >>> StatisticalUtils.safe_std([1, 2, 3, 4, 5])
        1.58...
        >>> StatisticalUtils.safe_std([1, 1, 1, 1, 1])
        0.0
        >>> StatisticalUtils.safe_std([1])
        0.0
        >>> StatisticalUtils.safe_std([])
        0.0
        """
        try:
            arr = np.asarray(arr)

            if arr.size == 0:
                return default

            if skipna:
                arr = arr.astype(float, copy=False)
                valid = np.isfinite(arr)

                n_valid = np.count_nonzero(valid)
                if n_valid <= ddof:
                    return default

                return float(np.std(arr[valid], ddof=ddof))
            else:
                if arr.size <= ddof:
                    return default

                return float(np.std(arr, ddof=ddof))

        except (TypeError, ValueError) as e:
            logger.warning(f"Error calculating std: {e}. Returning default: {default}")
            return default

    @staticmethod
    def safe_percentile(
        arr: np.ndarray, q: float | list[float], default: float = 0.0
    ) -> float | np.ndarray:
        """
        Calculate percentiles with edge case protection.

        Parameters
        ----------
        arr : np.ndarray
            Input array. Can contain NaN or Inf values.
        q : float or list of floats
            Percentile(s) to compute, in range [0, 100].
        default : float, optional
            Default value to return if percentile cannot be calculated.

        Returns
        -------
        float or np.ndarray
            Percentile value(s), or default if calculation fails.

        Raises
        ------
        ValueError
            If q is outside [0, 100].

        Examples
        --------
        >>> from causaloop import StatisticalUtils
        >>> StatisticalUtils.safe_percentile([1, 2, 3, 4, 5], 50)
        3.0
        >>> StatisticalUtils.safe_percentile([1, 2, 3, 4, 5], [25, 50, 75])
        array([2., 3., 4.])
        >>> StatisticalUtils.safe_percentile([], 50)
        0.0
        """
        try:
            arr = np.asarray(arr)
            q_array = np.atleast_1d(q)

            # Validate q
            if np.any(q_array < 0) or np.any(q_array > 100):
                raise ValueError(f"Percentile q must be in [0, 100], got {q}")

            if arr.size == 0:
                result = np.full(q_array.shape, default, dtype=float)
            else:
                arr = arr.astype(float, copy=False)
                valid = np.isfinite(arr)

                if not np.any(valid):
                    result = np.full(q_array.shape, default, dtype=float)
                else:
                    result = np.percentile(arr[valid], q_array, method="linear").astype(
                        float
                    )

            if np.ndim(q) == 0:
                return float(result[0])
            return result

        except (TypeError, ValueError) as e:
            logger.warning(
                f"Error calculating percentile: {e}. Returning default: {default}"
            )
            q_array = np.atleast_1d(q)
            fallback = np.full(q_array.shape, default, dtype=float)

            if np.ndim(q) == 0:
                return float(fallback[0])
            return fallback

    @staticmethod
    def is_numeric_array(arr: Any) -> bool:
        """
        Check if array contains convertible numeric values.

        Parameters
        ----------
        arr : Any
            Input to check for numeric convertibility.

        Returns
        -------
        bool
            True if array can be converted to a numeric dtype
            (e.g. float) without conversion errors, False otherwise.

        Examples
        --------
        >>> from causaloop import StatisticalUtils
        >>> StatisticalUtils.is_numeric_array([1, 2, 3])
        True
        >>> StatisticalUtils.is_numeric_array([1.0, 2.0, 3.0])
        True
        >>> StatisticalUtils.is_numeric_array(['a', 'b', 'c'])
        False
        >>> StatisticalUtils.is_numeric_array([1, 'a', 3])
        False
        """
        try:
            if arr is None:
                return False

            arr_np = np.asarray(arr)

            # Empty array is trivially numeric
            if arr_np.size == 0:
                return True

            # Fast path for already-numeric dtypes
            if np.issubdtype(arr_np.dtype, np.number):
                return True

            # Attempt safe numeric conversion
            arr_np.astype(float)
            return True

        except (TypeError, ValueError):
            return False

    @staticmethod
    def remove_outliers_iqr(arr: np.ndarray, multiplier: float = 1.5) -> np.ndarray:
        """
        Remove outliers using Interquartile Range (IQR) method.

        Parameters
        ----------
        arr : np.ndarray
            Input array. Can contain NaN or Inf values.
        multiplier : float, optional
            Multiplier for IQR to determine outlier bounds.
            Typical values: 1.5 (default) for moderate outliers,
            3.0 for extreme outliers.

        Returns
        -------
        np.ndarray
            Array with outliers removed.

        Notes
        -----
        - Outliers are values below Q1 - multiplier*IQR or above Q3 + multiplier*IQR
        - Returns empty array if all non-NaN values are outliers
        - Preserves NaN values (they are not considered outliers)
        - If IQR is zero, no values are removed

        Examples
        --------
        >>> import numpy as np
        >>> from causaloop import StatisticalUtils
        >>> data = np.array([1, 2, 3, 4, 5, 100])
        >>> StatisticalUtils.remove_outliers_iqr(data)
        array([1, 2, 3, 4, 5])
        >>> StatisticalUtils.remove_outliers_iqr(data, multiplier=38.2)
        array([  1,   2,   3,   4,   5, 100])
        """
        try:
            arr = np.asarray(arr)

            if arr.size == 0:
                return arr

            # Work in float space for safe isnan / isfinite
            arr_float = arr.astype(float, copy=False)

            nan_mask = np.isnan(arr_float)
            finite_mask = np.isfinite(arr_float)

            valid = arr_float[finite_mask & ~nan_mask]

            if valid.size == 0:
                return arr

            q1 = np.percentile(valid, 25)
            q3 = np.percentile(valid, 75)
            iqr = q3 - q1

            if iqr == 0:
                return arr

            lower_bound = q1 - multiplier * iqr
            upper_bound = q3 + multiplier * iqr

            inlier_mask = (
                (arr_float >= lower_bound) & (arr_float <= upper_bound)
            ) | nan_mask

            return np.array(arr[inlier_mask])

        except (TypeError, ValueError) as e:
            logger.warning(f"Error removing outliers: {e}. Returning original array.")
            return arr

    @staticmethod
    def winsorize(
        arr: np.ndarray, limits: tuple[float, float] = (0.05, 0.05)
    ) -> np.ndarray:
        """
        Winsorize array by limiting extreme values.

        Parameters
        ----------
        arr : np.ndarray
            Input array. Can contain NaN or Inf values.
        limits : tuple of float, optional
            Tuple of (lower_limit, upper_limit) as proportions to trim
            from each end. Each value in [0, 0.5].

        Returns
        -------
        np.ndarray
            Winsorized array with extreme values replaced by percentiles.

        Raises
        ------
        ValueError
            If limits are outside [0, 0.5] or lower_limit + upper_limit >= 1.

        Examples
        --------
        >>> import numpy as np
        >>> from causaloop import StatisticalUtils
        >>> data = np.array([1, 2, 3, 4, 5, 100])
        >>> StatisticalUtils.winsorize(data, limits=(0.1, 0.1))
        array([ 1.5,  2. ,  3. ,  4. ,  5. , 52.5])
        """
        try:
            arr = np.asarray(arr)

            if arr.size == 0:
                return arr

            lower_limit, upper_limit = limits

            # Validate limits
            if not 0 <= lower_limit <= 0.5:
                raise ValueError(f"Lower limit must be in [0, 0.5], got {lower_limit}")
            if not 0 <= upper_limit <= 0.5:
                raise ValueError(f"Upper limit must be in [0, 0.5], got {upper_limit}")
            if lower_limit + upper_limit >= 1:
                raise ValueError(
                    f"Sum of limits must be < 1, got {lower_limit + upper_limit}"
                )

            # Work in float space for safe NaN / Inf handling
            arr_float = arr.astype(float, copy=False)

            nan_mask = np.isnan(arr_float)
            finite_mask = np.isfinite(arr_float)

            valid = arr_float[finite_mask & ~nan_mask]

            if valid.size == 0:
                return arr

            lower_percentile = np.percentile(valid, lower_limit * 100)
            upper_percentile = np.percentile(valid, 100 - upper_limit * 100)

            winsorized = arr_float.copy()
            winsorized[finite_mask & ~nan_mask] = np.clip(
                valid, lower_percentile, upper_percentile
            )

            return np.array(winsorized)

        except (TypeError, ValueError) as e:
            logger.warning(f"Error winsorizing array: {e}. Returning original array.")
            return arr

    @staticmethod
    def calculate_skewness(arr: np.ndarray) -> float:
        """
        Calculate sample skewness (Fisher-Pearson coefficient).

        Parameters
        ----------
        arr : np.ndarray
            Input array. Can contain NaN or Inf values.

        Returns
        -------
        float
            Sample skewness. Returns 0 for insufficient data.

        Notes
        -----
        - Skewness > 0: right-skewed (tail on right)
        - Skewness < 0: left-skewed (tail on left)
        - Skewness ≈ 0: approximately symmetric
        - Requires at least 3 non-NaN values

        Examples
        --------
        >>> from causaloop import StatisticalUtils
        >>> StatisticalUtils.calculate_skewness([1, 2, 3, 4, 5])
        0.0
        >>> StatisticalUtils.calculate_skewness([1, 1, 1, 2, 100])
        2.23...
        """
        try:
            arr = np.asarray(arr, dtype=float)

            # Exclude NaN and Inf
            valid = arr[np.isfinite(arr)]
            n = valid.size

            if n < 3:
                return 0.0

            mean = np.mean(valid)
            s = np.std(valid, ddof=1)  # sample standard deviation

            if s == 0:
                return 0.0

            # Fisher–Pearson sample skewness
            centered = (valid - mean) / s
            skewness = (n / ((n - 1) * (n - 2))) * np.sum(centered**3)

            return float(skewness)

        except (TypeError, ValueError) as e:
            logger.warning(f"Error calculating skewness: {e}")
            return 0.0

    @staticmethod
    def calculate_kurtosis(arr: np.ndarray, fisher: bool = True) -> float:
        """
        Calculate sample kurtosis.

        Parameters
        ----------
        arr : np.ndarray
            Input array. Can contain NaN or Inf values.
        fisher : bool, optional
            If True (default), Fisher's definition is used (excess kurtosis).
            If False, Pearson's definition is used.

        Returns
        -------
        float
            Sample kurtosis. Returns 0 for insufficient data.

        Notes
        -----
        - Excess kurtosis (Fisher=True):
        * > 0: leptokurtic (heavy tails)
        * < 0: platykurtic (light tails)
        * = 0: mesokurtic (normal tails)
        - Requires at least 4 non-NaN values

        Examples
        --------
        >>> from causaloop import StatisticalUtils
        >>> StatisticalUtils.calculate_kurtosis([1, 2, 3, 4, 5])
        -1.2
        >>> StatisticalUtils.calculate_kurtosis([1, 1, 1, 1, 100])
        5.0
        """
        try:
            arr = np.asarray(arr, dtype=float)

            # Exclude NaN and Inf
            valid = arr[np.isfinite(arr)]
            n = valid.size

            if n < 4:
                return 0.0

            mean = np.mean(valid)
            diffs = valid - mean

            m2 = np.mean(diffs**2)
            if m2 == 0:
                return 0.0

            m4 = np.mean(diffs**4)

            # Biased excess kurtosis
            g2 = m4 / (m2**2) - 3.0

            # Unbiased Fisher–Pearson correction
            G2 = ((n - 1) / ((n - 2) * (n - 3))) * ((n + 1) * g2 + 6.0)

            if fisher:
                return float(G2)
            else:
                return float(G2 + 3.0)

        except (TypeError, ValueError) as e:
            logger.warning(f"Error calculating kurtosis: {e}")
            return 0.0

    @staticmethod
    def calculate_moments(arr: np.ndarray, max_order: int = 4) -> dict[int, float]:
        """
        Calculate statistical central moments up to specified order.

        Parameters
        ----------
        arr : np.ndarray
            Input array. Can contain NaN or Inf values.
        max_order : int, optional
            Maximum moment order to calculate (default 4).

        Returns
        -------
        Dict[int, float]
            Dictionary mapping moment order to calculated value.
            Moment 1 is the mean; higher moments are central moments
            normalized by N.

        Examples
        --------
        >>> import numpy as np
        >>> from causaloop import StatisticalUtils
        >>> data = np.random.normal(0, 1, 1000)
        >>> moments = StatisticalUtils.calculate_moments(data, max_order=4)
        >>> print(f"Mean: {moments[1]:.3f}")
        Mean: 0.001
        >>> print(f"Variance: {moments[2]:.3f}")
        Variance: 1.026
        """
        try:
            if max_order < 1:
                raise ValueError("max_order must be >= 1")

            arr = np.asarray(arr, dtype=float)

            # Exclude NaN and Inf
            valid = arr[np.isfinite(arr)]
            n = valid.size

            moments: dict[int, float] = {}

            if n == 0:
                return dict.fromkeys(range(1, max_order + 1), 0.0)

            mean = np.mean(valid)
            moments[1] = float(mean)

            centered = valid - mean

            for order in range(2, max_order + 1):
                moments[order] = float(np.mean(centered**order))

            return moments

        except (TypeError, ValueError) as e:
            logger.warning(f"Error calculating moments: {e}")
            return dict.fromkeys(range(1, max_order + 1), 0.0)

    @staticmethod
    def calculate_scale(arr: np.ndarray, method: str = "mad") -> float:
        """
        Calculate robust scale estimates.

        Parameters
        ----------
        arr : np.ndarray
            Input array. Can contain NaN or Inf values.
        method : str, optional
            Scale estimation method:
            - 'mad': Median Absolute Deviation
            - 'iqr': Interquartile Range
            - 'sn': Qn estimator (robust to outliers)

        Returns
        -------
        float
            Robust scale estimate.

        Examples
        --------
        >>> import numpy as np
        >>> from causaloop import StatisticalUtils
        >>> data = np.array([1, 2, 3, 4, 5, 100])  # Contains outlier
        >>> StatisticalUtils.calculate_robust_scale(data, 'mad')
        2.22...
        >>> StatisticalUtils.calculate_robust_scale(data, 'iqr')
        1.85...
        """
        try:
            arr = np.asarray(arr, dtype=float)

            # Remove NaN and Inf
            valid_arr = arr[np.isfinite(arr)]

            n = len(valid_arr)
            if n < 2:
                return 0.0

            if method == "mad":
                median = np.median(valid_arr)
                mad = np.median(np.abs(valid_arr - median))
                # Consistency factor for Gaussian std
                return float(mad * 1.4826)

            elif method == "iqr":
                q1, q3 = np.percentile(valid_arr, [25, 75])
                iqr = q3 - q1
                # Consistency factor for Gaussian std
                return float(iqr / 1.349)

            elif method == "sn":
                # Qn estimator using pairwise differences (simple, O(n^2))
                from itertools import combinations

                diffs = [
                    abs(valid_arr[i] - valid_arr[j])
                    for i, j in combinations(range(n), 2)
                ]

                qn = np.percentile(diffs, 25)
                # Approximate finite-sample correction factor
                c = 1.1926 if n <= 12 else 2.2219
                return float(c * qn)

            else:
                raise ValueError(f"Unknown scale method: {method}")

        except (TypeError, ValueError) as e:
            logger.warning(f"Error calculating robust scale: {e}")
            return 0.0
