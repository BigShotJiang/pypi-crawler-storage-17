"""Docstring for causaloop.math.statistics.uncertainty."""
