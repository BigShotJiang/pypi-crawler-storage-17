"""
Time series analysis methods for trend detection, seasonality analysis, 
and change point detection.

This module provides comprehensive time series analysis capabilities including
trend detection, seasonality analysis, change point detection, and volatility
estimation. All methods are designed for research applications with detailed
diagnostics and uncertainty quantification.

Classes
-------
TimeSeriesAnalyzer
    Advanced time series analysis methods.

Methods
-------
linear_trend_analysis(values, timestamps=None, significance_level=0.05)
    Perform linear trend analysis with statistical significance testing.
mann_kendall_test(values, alpha=0.05)
    Non-parametric Mann-Kendall trend test.
seasonal_decomposition(values, period=None, model='additive')
    Decompose time series into trend, seasonal, and residual components.
detect_change_points(values, method='binary_segmentation', **kwargs)
    Detect change points in time series.
analyze_volatility(values, window=20, method='garch')
    Analyze volatility patterns in time series.
forecast_arima(values, steps=1, order=(1,0,0))
    Forecast using ARIMA model.

Notes
-----
- All methods handle missing values appropriately
- Statistical significance is evaluated at user-specified alpha level
- Confidence intervals are provided where applicable
- Methods return detailed metadata for research reproducibility
"""

import time
from typing import List, Optional, Tuple

import numpy as np
from scipy import stats, signal

from .core import (
    TrendAnalysisResult, 
    SeasonalityResult, 
    ChangePointResult,
    TrendDirection, 
    SeasonalityType
)
from ...utils.logging import get_logger

logger = get_logger(__name__)


class TimeSeriesAnalyzer:
    """
    Advanced time series analysis methods.
    
    Provides comprehensive time series analysis capabilities including
    trend detection, seasonality analysis, change point detection,
    and volatility estimation. All methods are designed for research
    applications with detailed diagnostics and uncertainty quantification.
    
    Examples
    --------
    >>> import numpy as np
    >>> from causaloop.math.statistics import TimeSeriesAnalyzer
    >>> 
    >>> # Generate synthetic time series with trend and seasonality
    >>> n = 200
    >>> time = np.arange(n)
    >>> trend = 0.02 * time
    >>> seasonality = 5 * np.sin(2 * np.pi * time / 50)
    >>> noise = np.random.normal(0, 1, n)
    >>> data = trend + seasonality + noise
    >>> 
    >>> # Detect trend
    >>> trend_result = TimeSeriesAnalyzer.linear_trend_analysis(data)
    >>> if trend_result.is_significant:
    ...     print(f"Trend: {trend_result.direction.name}")
    ...     print(f"Slope: {trend_result.slope:.4f} per time unit")
    >>> 
    >>> # Detect seasonality
    >>> seasonal_result = TimeSeriesAnalyzer.seasonal_decomposition(data, period=50)
    >>> if seasonal_result.seasonality_type != SeasonalityType.NONE:
    ...     print(f"Seasonality strength: {seasonal_result.strength:.3f}")
    """
    
    @staticmethod
    def linear_trend_analysis(
        values: np.ndarray,
        timestamps: Optional[np.ndarray] = None,
        significance_level: float = 0.05,
        confidence_level: float = 0.95
    ) -> TrendAnalysisResult:
        """
        Perform comprehensive linear trend analysis.
        """
        start_time = time.time()
        
        try:
            # Input validation
            if not isinstance(values, np.ndarray):
                values = np.asarray(values)
            
            if values.size == 0:
                return TrendAnalysisResult(
                    success=False,
                    confidence=0.0,
                    direction=TrendDirection.INSUFFICIENT_DATA,
                    slope=0.0,
                    intercept=0.0,
                    r_squared=0.0,
                    p_value=1.0,
                    strength=0.0,
                    is_significant=False,
                    sample_size=0,
                    error_message="Empty input array",
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # Handle timestamps
            if timestamps is None:
                timestamps = np.arange(len(values))
            
            if not isinstance(timestamps, np.ndarray):
                timestamps = np.asarray(timestamps)
            
            # Remove NaN pairs
            valid_mask = ~np.isnan(values) & ~np.isnan(timestamps)
            valid_values = values[valid_mask]
            valid_timestamps = timestamps[valid_mask]
            n_valid = len(valid_values)
            
            if n_valid < 2:
                return TrendAnalysisResult(
                    success=False,
                    confidence=0.0,
                    direction=TrendDirection.INSUFFICIENT_DATA,
                    slope=0.0,
                    intercept=0.0,
                    r_squared=0.0,
                    p_value=1.0,
                    strength=0.0,
                    is_significant=False,
                    sample_size=n_valid,
                    metadata={
                        "n_original": len(values),
                        "n_valid": n_valid,
                        "missing_rate": 1 - n_valid / len(values) if len(values) > 0 else 1.0
                    },
                    error_message=f"Insufficient valid data points: {n_valid} < 2",
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # Center timestamps
            t_mean = np.mean(valid_timestamps)
            centered_t = valid_timestamps - t_mean
            
            # Linear regression
            slope, intercept, r_value, p_value, slope_se = stats.linregress(centered_t, valid_values)
            r_squared = r_value ** 2
            
            # Confidence interval for slope
            df = n_valid - 2
            t_critical = stats.t.ppf((1 + confidence_level) / 2, df)
            margin = t_critical * slope_se
            ci_lower = slope - margin
            ci_upper = slope + margin
            
            # Determine direction and significance
            if p_value < significance_level:
                if slope > 0:
                    direction = TrendDirection.INCREASING
                elif slope < 0:
                    direction = TrendDirection.DECREASING
                else:
                    direction = TrendDirection.STABLE
                is_significant = True
            else:
                direction = TrendDirection.STABLE
                is_significant = False
            
            # Trend strength
            data_range = np.ptp(valid_values)
            strength = (abs(slope) / data_range) * (1 - min(p_value, 0.99)) if data_range > 0 else 0.0
            strength = np.clip(strength, 0.0, 1.0)
            
            # Overall confidence
            sample_conf = min(1.0, n_valid / 30)
            overall_confidence = 0.4 * sample_conf + 0.4 * r_squared + 0.2 * (1 - min(p_value / significance_level, 1.0))
            overall_confidence = np.clip(overall_confidence, 0.01, 0.99)
            
            # Metadata
            residuals = valid_values - (slope * centered_t + intercept)
            metadata = {
                "method": "linear_regression",
                "significance_level": significance_level,
                "confidence_level": confidence_level,
                "n_original": len(values),
                "n_valid": n_valid,
                "missing_rate": 1 - n_valid / len(values) if len(values) > 0 else 1.0,
                "timestamp_range": (float(np.min(timestamps)), float(np.max(timestamps))),
                "value_range": (float(np.min(valid_values)), float(np.max(valid_values))),
                "slope_se": float(slope_se),
                "residual_std": float(np.std(residuals, ddof=2)) if n_valid > 2 else 0.0,
                "durbin_watson": TimeSeriesAnalyzer._durbin_watson_statistic(residuals) if n_valid > 2 else None
            }
            
            execution_time = (time.time() - start_time) * 1000
            
            return TrendAnalysisResult(
                success=True,
                confidence=overall_confidence,
                direction=direction,
                slope=float(slope),
                intercept=float(intercept),
                r_squared=float(r_squared),
                p_value=float(p_value),
                strength=float(strength),
                is_significant=is_significant,
                sample_size=n_valid,
                slope_se=float(slope_se),
                confidence_interval=(float(ci_lower), float(ci_upper)),
                metadata=metadata,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"Linear trend analysis failed: {e}")
            return TrendAnalysisResult(
                success=False,
                confidence=0.0,
                direction=TrendDirection.INSUFFICIENT_DATA,
                slope=0.0,
                intercept=0.0,
                r_squared=0.0,
                p_value=1.0,
                strength=0.0,
                is_significant=False,
                sample_size=0,
                error_message=str(e),
                execution_time_ms=(time.time() - start_time) * 1000
            )

    @staticmethod
    def mann_kendall_test(
        values: np.ndarray,
        alpha: float = 0.05,
        continuity_correction: bool = True
    ) -> TrendAnalysisResult:
        """
        Perform Mann-Kendall non-parametric trend test.
        """
        start_time = time.time()
        
        try:
            if not isinstance(values, np.ndarray):
                values = np.asarray(values)
            
            valid_values = values[~np.isnan(values)]
            n = len(valid_values)
            
            if n < 4:
                return TrendAnalysisResult(
                    success=False,
                    confidence=0.0,
                    direction=TrendDirection.INSUFFICIENT_DATA,
                    slope=0.0,
                    intercept=0.0,
                    r_squared=0.0,
                    p_value=1.0,
                    strength=0.0,
                    is_significant=False,
                    sample_size=n,
                    error_message=f"Insufficient data points: {n} < 4",
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # S statistic
            s = np.sum(np.sign(valid_values[None, :] - valid_values[:, None])[np.triu_indices(n, 1)])
            
            # Tie correction
            _, counts = np.unique(valid_values, return_counts=True)
            tie_correction = np.sum(counts * (counts - 1) * (2 * counts + 5))
            
            var_s = (n * (n - 1) * (2 * n + 5) - tie_correction) / 18.0
            
            if var_s == 0:
                return TrendAnalysisResult(
                    success=True,
                    confidence=1.0,
                    direction=TrendDirection.STABLE,
                    slope=0.0,
                    intercept=float(np.median(valid_values)),
                    r_squared=0.0,
                    p_value=1.0,
                    strength=0.0,
                    is_significant=False,
                    sample_size=n,
                    metadata={
                        "method": "mann_kendall",
                        "s_statistic": 0.0,
                        "var_s": 0.0,
                        "z_score": 0.0,
                        "tie_count": n - len(np.unique(valid_values))
                    },
                    execution_time_ms=(time.time() - start_time) * 1000
                )
            
            # Z statistic
            if s > 0:
                z = (s - 1) / np.sqrt(var_s) if continuity_correction else s / np.sqrt(var_s)
            elif s < 0:
                z = (s + 1) / np.sqrt(var_s) if continuity_correction else s / np.sqrt(var_s)
            else:
                z = 0.0
            
            p_value = 2 * (1 - stats.norm.cdf(abs(z)))
            
            # Sens slope
            slopes = [(valid_values[j] - valid_values[i]) / (j - i) for i in range(n - 1) for j in range(i + 1, n)]
            sens_slope = np.median(slopes) if slopes else 0.0
            
            # Direction
            if p_value < alpha:
                direction = TrendDirection.INCREASING if s > 0 else TrendDirection.DECREASING
                is_significant = True
            else:
                direction = TrendDirection.STABLE
                is_significant = False
            
            confidence = 1 - min(p_value / alpha, 1.0)
            
            metadata = {
                "method": "mann_kendall",
                "s_statistic": float(s),
                "var_s": float(var_s),
                "z_score": float(z),
                "tie_count": n - len(np.unique(valid_values)),
                "unique_values": len(np.unique(valid_values)),
                "sens_slope": float(sens_slope),
                "slope_iqr": float(np.percentile(slopes, 75) - np.percentile(slopes, 25)) if slopes else 0.0
            }
            
            execution_time = (time.time() - start_time) * 1000
            
            return TrendAnalysisResult(
                success=True,
                confidence=confidence,
                direction=direction,
                slope=float(sens_slope),
                intercept=float(np.median(valid_values)),
                r_squared=0.0,
                p_value=float(p_value),
                strength=min(1.0, abs(z) / 3.0),
                is_significant=is_significant,
                sample_size=n,
                metadata=metadata,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"Mann-Kendall test failed: {e}")
            return TrendAnalysisResult(
                success=False,
                confidence=0.0,
                direction=TrendDirection.INSUFFICIENT_DATA,
                slope=0.0,
                intercept=0.0,
                r_squared=0.0,
                p_value=1.0,
                strength=0.0,
                is_significant=False,
                sample_size=0,
                error_message=str(e),
                execution_time_ms=(time.time() - start_time) * 1000
            )

    @staticmethod
    def _durbin_watson_statistic(residuals: np.ndarray) -> float:
        """Calculate Durbin-Watson statistic for autocorrelation detection."""
        if len(residuals) < 2:
            return 2.0
        diff = np.diff(residuals)
        dw = np.sum(diff ** 2) / (np.sum(residuals ** 2) + 1e-10)
        return float(dw)
