"""Docstring for causaloop.solver."""
