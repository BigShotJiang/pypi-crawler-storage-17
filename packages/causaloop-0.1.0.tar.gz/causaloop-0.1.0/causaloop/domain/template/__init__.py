"""Docstring for causaloop.domain.template."""
