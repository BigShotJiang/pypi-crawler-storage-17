"""Docstring for causaloop.domain."""
