"""
Structured logging for CausaLoop.

Provides research-grade logging with different verbosity levels,
structured output, and support for logging causal reasoning steps.
"""

import json
import logging
import sys
from datetime import datetime, timezone
from enum import IntEnum
from typing import Any, cast


class LogLevel(IntEnum):
    """
    Extended logging levels for causal reasoning.

    Extends standard logging levels with domain-specific levels
    for causal operations.
    """

    CRITICAL = logging.CRITICAL
    ERROR = logging.ERROR
    WARNING = logging.WARNING
    INFO = logging.INFO
    DEBUG = logging.DEBUG
    TRACE = 5  # More detailed than DEBUG
    CAUSAL = 15  # Between INFO and DEBUG for causal operations
    REASONING = 25  # Between DEBUG and TRACE for reasoning steps


# Register custom levels
logging.addLevelName(LogLevel.TRACE, "TRACE")
logging.addLevelName(LogLevel.CAUSAL, "CAUSAL")
logging.addLevelName(LogLevel.REASONING, "REASONING")


class CausalLogger(logging.Logger):
    """
    Extended logger with causal reasoning methods.

    Adds convenience methods for logging causal operations,
    interventions, and reasoning steps with structured context.
    """

    def trace(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log at TRACE level."""
        if self.isEnabledFor(LogLevel.TRACE):
            self._log(LogLevel.TRACE, msg, args, **kwargs)

    def causal(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log at CAUSAL level (causal operations)."""
        if self.isEnabledFor(LogLevel.CAUSAL):
            self._log(LogLevel.CAUSAL, msg, args, **kwargs)

    def reasoning(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log at REASONING level (reasoning steps)."""
        if self.isEnabledFor(LogLevel.REASONING):
            self._log(LogLevel.REASONING, msg, args, **kwargs)

    def log_intervention(
        self,
        variable: str,
        value: Any,
        old_value: Any | None = None,
        reason: str | None = None,
        **context: Any,
    ) -> None:
        """
        Log an intervention (do-operation) with structured data.

        Parameters
        ----------
        variable : str
            Name or ID of the variable being intervened on.
        value : Any
            New value after intervention.
        old_value : Any, optional
            Previous value before intervention.
        reason : str, optional
            Reason for the intervention.
        **context
            Additional context data to log.
        """
        structured_data = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "type": "intervention",
            "variable": variable,
            "new_value": str(value),
            "old_value": str(old_value) if old_value is not None else None,
            "reason": reason,
            **context,
        }

        self.causal(
            "Intervention: %s = %s (was: %s)",
            variable,
            value,
            old_value,
            extra={"causal_data": structured_data},
        )

    def log_counterfactual(
        self,
        scenario: str,
        actual: Any,
        counterfactual: Any,
        probability: float | None = None,
        **context: Any,
    ) -> None:
        """
        Log a counterfactual reasoning step.

        Parameters
        ----------
        scenario : str
            Description of the counterfactual scenario.
        actual : Any
            Actual observed value.
        counterfactual : Any
            Counterfactual value.
        probability : float, optional
            Probability or confidence of the counterfactual.
        **context
            Additional context data.
        """
        structured_data = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "type": "counterfactual",
            "scenario": scenario,
            "actual": str(actual),
            "counterfactual": str(counterfactual),
            "probability": probability,
            **context,
        }

        self.reasoning(
            "Counterfactual: %s | Actual: %s, CF: %s",
            scenario,
            actual,
            counterfactual,
            extra={"causal_data": structured_data},
        )


# Register our custom logger class
logging.setLoggerClass(CausalLogger)


class JSONFormatter(logging.Formatter):
    """
    Formatter that outputs JSON for structured logging.

    Useful for log aggregation and analysis in research workflows.
    """

    def format(self, record: logging.LogRecord) -> str:
        """
        Format the log record as JSON.

        Parameters
        ----------
        record : logging.LogRecord
            Log record to format.

        Returns
        -------
        str
            JSON string representation of the log record.
        """
        log_data = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }

        # Add causal-specific data if present
        if hasattr(record, "causal_data"):
            log_data["causal_data"] = record.causal_data

        # Add exception info if present
        if record.exc_info and not record.exc_text:
            record.exc_text = self.formatException(record.exc_info)

        if record.exc_text:
            log_data["exception"] = record.exc_text

        return json.dumps(log_data, default=str)


def setup_logging(
    level: str | int = "INFO",
    json_output: bool = False,
    log_file: str | None = None,
    module_levels: dict[str, str | int] | None = None,
) -> None:
    """
    Configure logging for CausaLoop.

    Parameters
    ----------
    level : str or int, default='INFO'
        Default logging level. Can be string name or integer value.
    json_output : bool, default=False
        If True, output logs as JSON. If False, use human-readable format.
    log_file : str, optional
        If provided, also log to this file.
    module_levels : dict, optional
        Specific logging levels for modules.
        Example: {'causaloop.core': 'DEBUG', 'causaloop.solver': 'WARNING'}

    Examples
    --------
    >>> from causaloop import get_logger, setup_logging
    >>> setup_logging(level='CAUSAL', json_output=True)
    >>> logger = get_logger(__name__)
    >>> logger.causal("Starting causal inference")
    """
    # Convert string level to int if needed
    if isinstance(level, str):
        level = getattr(logging, level.upper(), logging.INFO)

    # Clear any existing handlers
    logging.root.handlers.clear()

    formatter: logging.Formatter

    # Create formatter
    if json_output:
        formatter = JSONFormatter()
    else:
        formatter = logging.Formatter(
            fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    console_handler.setLevel(level)

    # Add console handler to root
    logging.root.addHandler(console_handler)

    # File handler if specified
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        file_handler.setLevel(level)
        logging.root.addHandler(file_handler)

    # Set module-specific levels
    if module_levels:
        for module, module_level in module_levels.items():
            if isinstance(module_level, str):
                module_level = getattr(logging, module_level.upper())
            logging.getLogger(module).setLevel(module_level)

    # Set root level to lowest of all handlers
    root_level = min(level, *(h.level for h in logging.root.handlers))
    logging.root.setLevel(root_level)


def get_logger(name: str) -> CausalLogger:
    """
    Get a logger instance with causal extensions.

    Parameters
    ----------
    name : str
        Logger name, typically __name__.

    Returns
    -------
    CausalLogger
        Logger instance with causal reasoning methods.
    """
    logger = logging.getLogger(name)

    return cast(CausalLogger, logger)
