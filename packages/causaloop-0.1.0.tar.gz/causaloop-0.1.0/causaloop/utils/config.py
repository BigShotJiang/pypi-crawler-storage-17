"""
Configuration management for CausaLoop.

Provides hierarchical configuration with environment variable support,
type validation, and schema definition for research reproducibility.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Optional import for YAML support
try:
    import yaml

    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False


@dataclass
class SolverConfig:
    """
    Configuration for mathematical solvers.

    Attributes
    ----------
    ode_tol : float
        Tolerance for ODE solvers.
    sde_steps : int
        Number of steps for SDE integration.
    max_iterations : int
        Maximum iterations for optimization solvers.
    parallel : bool
        Enable parallel computation.
    workers : int
        Number of parallel workers.
    """

    ode_tol: float = 1e-6
    sde_steps: int = 1000
    max_iterations: int = 1000
    parallel: bool = False
    workers: int = 4


@dataclass
class RuntimeConfig:
    """
    Configuration for causal runtime.

    Attributes
    ----------
    check_contracts : bool
        Enable contract checking at runtime.
    validate_state : bool
        Validate state consistency each step.
    max_history : int
        Maximum number of historical states to keep.
    realtime_factor : float
        Speed factor for simulation (1.0 = realtime).
    causal_consistency : bool
        Enable causal consistency checking.
    """

    check_contracts: bool = True
    validate_state: bool = True
    max_history: int = 1000
    realtime_factor: float = 1.0
    causal_consistency: bool = True


@dataclass
class LoggingConfig:
    """
    Configuration for logging.

    Attributes
    ----------
    level : str
        Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
    json_output : bool
        Output logs as JSON.
    log_file : Optional[str]
        Path to log file.
    module_levels : dict[str, str]
        Module-specific logging levels.
    """

    level: str = "INFO"
    json_output: bool = False
    log_file: str | None = None
    module_levels: dict[str, str] = field(default_factory=dict)


class Config:
    """
    Hierarchical configuration manager for CausaLoop.

    Supports loading from multiple sources with precedence:
    1. Environment variables (CAUSALOOP_*)
    2. Config file (YAML)
    3. Default values

    Configuration is validated and type-safe.

    Examples
    --------
    >>> from causaloop import Config
    >>> config = Config()
    >>> config.solver.ode_tol
    1e-06

    >>> config.update_from_file('config.yaml')
    >>> config.update_from_env()
    """

    def __init__(
        self,
        config_file: str | Path | None = None,
        env_prefix: str = "CAUSALOOP",
    ) -> None:
        """
        Initialize configuration.

        Parameters
        ----------
        config_file : str or Path, optional
            Path to YAML configuration file.
        env_prefix : str, default='CAUSALOOP'
            Prefix for environment variables.
        """
        self.env_prefix = env_prefix

        # Initialize with defaults
        self.solver = SolverConfig()
        self.runtime = RuntimeConfig()
        self.logging = LoggingConfig()

        # Custom settings
        self._custom: dict[str, Any] = {}

        # Load from file if provided
        if config_file:
            self.update_from_file(config_file)

        # Override with environment variables
        self.update_from_env()

    def update_from_file(self, config_file: str | Path) -> None:
        """
        Update configuration from YAML file.

        Parameters
        ----------
        config_file : str or Path
            Path to YAML configuration file.

        Raises
        ------
        FileNotFoundError
            If config_file doesn't exist.
        ImportError
            If pyyaml is not installed.
        yaml.YAMLError
            If YAML is malformed.
        """
        if not YAML_AVAILABLE:
            raise ImportError(
                "PyYAML is required to load YAML config files. "
                "Install with: pip install pyyaml"
            )

        config_path = Path(config_file)
        if not config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_file}")

        with open(config_path) as f:
            data = yaml.safe_load(f) or {}

        self._update_from_dict(data)

    def update_from_env(self) -> None:
        """
        Update configuration from environment variables.

        Environment variables should be prefixed with env_prefix
        and use double underscore for nesting:

        CAUSALOOP_SOLVER__ODE_TOL=1e-8
        CAUSALOOP_LOGGING__LEVEL=DEBUG
        """
        env_data: dict[str, Any] = {}

        for key, value in os.environ.items():
            if key.startswith(f"{self.env_prefix}_"):
                # Convert CAUSALOOP_SOLVER__ODE_TOL to solver.ode_tol
                path = key[len(self.env_prefix) + 1 :].lower().split("__")

                # Build nested dictionary
                current = env_data
                for part in path[:-1]:
                    if part not in current:
                        current[part] = {}
                    current = current[part]

                # Try to convert to appropriate type
                current[path[-1]] = self._convert_env_value(value)

        self._update_from_dict(env_data)

    def _update_from_dict(self, data: dict[str, Any]) -> None:
        """
        Update configuration from dictionary.

        Parameters
        ----------
        data : dict
            Configuration data.
        """
        # Update solver config
        if "solver" in data:
            self._update_dataclass(self.solver, data["solver"])

        # Update runtime config
        if "runtime" in data:
            self._update_dataclass(self.runtime, data["runtime"])

        # Update logging config
        if "logging" in data:
            self._update_dataclass(self.logging, data["logging"])

        # Store custom settings
        custom_keys = set(data.keys()) - {"solver", "runtime", "logging"}
        for key in custom_keys:
            self._custom[key] = data[key]

    def _update_dataclass(
        self, dataclass_instance: Any, updates: dict[str, Any]
    ) -> None:
        """
        Update a dataclass instance with dictionary values.

        Parameters
        ----------
        dataclass_instance
            Dataclass instance to update.
        updates : dict
            Dictionary of updates.
        """
        for key, value in updates.items():
            if hasattr(dataclass_instance, key):
                setattr(dataclass_instance, key, value)

    def _convert_env_value(self, value: str) -> Any:
        """
        Convert environment variable string to appropriate type.

        Parameters
        ----------
        value : str
            Environment variable value.

        Returns
        -------
        Any
            Converted value.
        """
        # Try to convert to int
        try:
            return int(value)
        except ValueError:
            pass

        # Try to convert to float
        try:
            return float(value)
        except ValueError:
            pass

        # Try to convert to bool
        lower = value.lower()
        if lower in ("true", "yes", "on"):
            return True
        if lower in ("false", "no", "off"):
            return False

        # Return as string
        return value

    def get(self, key: str, default: Any = None) -> Any:
        """
        Get configuration value by dot notation.

        Parameters
        ----------
        key : str
            Dot notation key (e.g., 'solver.ode_tol').
        default : Any, optional
            Default value if key not found.

        Returns
        -------
        Any
            Configuration value.

        Examples
        --------
        >>> from causaloop import Config
        >>> config = Config()
        >>> config.get('solver.ode_tol')
        1e-06

        >>> config.get('custom.setting', 'default')
        'default'
        """
        parts = key.split(".")
        current: Any = self

        for part in parts:
            if hasattr(current, part):
                current = getattr(current, part)
            elif isinstance(current, dict) and part in current:
                current = current[part]
            elif hasattr(current, "_custom") and part in current._custom:
                current = current._custom[part]
            else:
                return default

        return current

    def to_dict(self) -> dict[str, Any]:
        """
        Convert configuration to dictionary.

        Returns
        -------
        dict
            Dictionary representation of configuration.
        """
        return {
            "solver": {
                field: getattr(self.solver, field)
                for field in self.solver.__dataclass_fields__
            },
            "runtime": {
                field: getattr(self.runtime, field)
                for field in self.runtime.__dataclass_fields__
            },
            "logging": {
                field: getattr(self.logging, field)
                for field in self.logging.__dataclass_fields__
            },
            **self._custom,
        }

    def save(self, config_file: str | Path) -> None:
        """
        Save configuration to YAML file.

        Parameters
        ----------
        config_file : str or Path
            Path to save configuration.

        Raises
        ------
        ImportError
            If pyyaml is not installed.
        """
        if not YAML_AVAILABLE:
            raise ImportError(
                "PyYAML is required to save YAML config files. "
                "Install with: pip install pyyaml"
            )

        config_path = Path(config_file)
        config_path.parent.mkdir(parents=True, exist_ok=True)

        with open(config_path, "w") as f:
            yaml.dump(self.to_dict(), f, default_flow_style=False)
