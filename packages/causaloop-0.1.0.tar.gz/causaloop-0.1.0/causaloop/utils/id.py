"""
Unique identifier generation.

Provides thread-safe, distributed-friendly ID generation for all CausaLoop objects.
Ensures every Variable, Mechanism, Process, etc., has a globally unique identifier.
"""

import threading
import time
import uuid


class IDGenerator:
    """
    Thread-safe ID generator with multiple generation strategies.

    Combines timestamp, counter, and random components to ensure uniqueness
    even in distributed environments with clock skew.

    Attributes
    ----------
    prefix : str
        Prefix for all generated IDs (e.g., 'var', 'mech', 'proc').
    counter : int
        Monotonically increasing counter for sequence generation.
    lock : threading.Lock
        Thread lock for safe concurrent access.

    Examples
    --------
    >>> from causaloop import IDGenerator
    >>> gen = IDGenerator('var')
    >>> gen.generate()  # doctest: +SKIP
    'var_1765249497673_1_69f161f2'

    >>> gen.generate(seed='custom')  # doctest: +SKIP
    'var_1765249516626_2_1736c2fe'
    """

    def __init__(self, prefix: str = "obj") -> None:
        """
        Initialize ID generator with a prefix.

        Parameters
        ----------
        prefix : str, default='obj'
            Prefix for all generated IDs. Should be descriptive
            (e.g., 'variable', 'mechanism', 'process').
        """
        self.prefix = prefix
        self.counter = 0
        self.lock = threading.Lock()

    def generate(self, seed: str | None = None) -> str:
        """
        Generate a unique identifier.

        Format: {prefix}_{timestamp}_{counter}_{unique}

        Parameters
        ----------
        seed : str, optional
            Custom seed for the unique component. If None, a random
            UUID hex string is used.

        Returns
        -------
        str
            Unique identifier string.

        Notes
        -----
        Thread-safe and monotonic within a single generator instance.
        For distributed uniqueness, combine with machine/process identifier
        in the prefix or seed.
        """
        with self.lock:
            timestamp = int(time.time() * 1000)  # Milliseconds for precision
            self.counter += 1

            # In IDGenerator.generate() method:
            if seed is None:
                unique = uuid.uuid4().hex[:8]  # 8-char random suffix
            else:
                # Deterministic hash from seed - ensure 8 chars with padding
                hash_val = abs(hash(seed))
                hex_str = hex(hash_val)[2:]  # Remove '0x'
                # Pad or truncate to 8 characters
                unique = hex_str.zfill(8)[:8]  # Pad with zeros, take first 8

            return f"{self.prefix}_{timestamp}_{self.counter}_{unique}"

    def reset(self) -> None:
        """Reset the internal counter (mainly for testing)."""
        with self.lock:
            self.counter = 0


# Global generators for common object types
_VARIABLE_GEN = IDGenerator("variable")
_STATE_GEN = IDGenerator("state")
_MECHANISM_GEN = IDGenerator("mechanism")
_PROCESS_GEN = IDGenerator("process")
_CONTRACT_GEN = IDGenerator("contract")


def generate_id(obj_type: str = "object", seed: str | None = None) -> str:
    """
    Generate a unique ID for an object type.

    Convenience function using pre-configured generators.

    Parameters
    ----------
    obj_type : str, default='object'
        Type of object: 'variable', 'mechanism', 'process', 'contract',
        or 'object' for generic.
    seed : str, optional
        Custom seed for deterministic generation.

    Returns
    -------
    str
        Unique identifier.

    Raises
    ------
    ValueError
        If obj_type is not recognized.

    Examples
    --------
    >>> from causaloop import generate_id
    >>> generate_id('variable')  # doctest: +SKIP
    'variable_1765250016697_1_73c7af78'

    >>> generate_id('mechanism', seed='metabolic_ode')  # doctest: +SKIP
    'mechanism_1765250038229_1_41682ee4'
    """
    generators = {
        "variable": _VARIABLE_GEN,
        "state": _STATE_GEN,
        "mechanism": _MECHANISM_GEN,
        "process": _PROCESS_GEN,
        "contract": _CONTRACT_GEN,
        "object": IDGenerator("object"),
    }

    if obj_type not in generators:
        raise ValueError(
            f"Unknown object type: {obj_type}. "
            f"Expected one of: {list(generators.keys())}"
        )

    return generators[obj_type].generate(seed)
