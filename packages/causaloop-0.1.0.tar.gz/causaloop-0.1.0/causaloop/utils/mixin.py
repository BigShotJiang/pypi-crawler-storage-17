"""
Reusable mixin classes for CausaLoop.

Provides common functionality through inheritance to avoid code duplication
and ensure consistent patterns across the codebase.
"""

import json
from abc import abstractmethod
from collections.abc import Callable
from dataclasses import asdict, is_dataclass
from typing import Any, Generic, TypeVar, cast

T = TypeVar("T")


class ObservableMixin:
    """
    Mixin for observable objects that notify listeners of changes.

    Implements the observer pattern for state changes, interventions,
    and other events. Useful for Variables that need to notify
    dependent Mechanisms of value changes.

    Attributes
    ----------
    _observers : dict[str, list[Callable[..., None]]]
        Registered observers by event type.

    Examples
    --------
    >>> from causaloop import ObservableMixin
    >>> class Variable(ObservableMixin):
    ...     def __init__(self):
    ...         super().__init__()
    ...         self.value = None
    ...     def set_value(self, value):
    ...         old = self.value
    ...         self.value = value
    ...         self.notify('value_changed', old=old, new=value)
    >>> var = Variable()
    >>> var.subscribe('value_changed', lambda **kwargs: print(kwargs))
    >>> var.set_value(42)  # prints: {'old': None, 'new': 42}
    """

    def __init__(self) -> None:
        """Initialize observable mixin."""
        self._observers: dict[str, list[Callable[..., None]]] = {}

    def subscribe(self, event: str, callback: Callable[..., None]) -> None:
        """
        Subscribe to an event.

        Parameters
        ----------
        event : str
            Event type to subscribe to.
        callback : Callable[..., None]
            Function to call when event occurs.
            Signature: callback(**kwargs) -> None
        """
        if event not in self._observers:
            self._observers[event] = []
        self._observers[event].append(callback)

    def unsubscribe(self, event: str, callback: Callable[..., None]) -> bool:
        """
        Unsubscribe from an event.

        Parameters
        ----------
        event : str
            Event type to unsubscribe to.
        callback : Callable[..., None]
            Callback to remove.

        Returns
        -------
        bool
            True if callback was removed, False if not found.
        """
        if event not in self._observers:
            return False

        try:
            self._observers[event].remove(callback)
            return True
        except ValueError:
            return False

    def notify(self, event: str, **kwargs: Any) -> None:
        """
        Notify all observers of an event.

        Parameters
        ----------
        event : str
            Event type to notify.
        **kwargs
            Event data passed to observers.
        """
        if event not in self._observers:
            return

        for callback in self._observers[event][:]:  # Copy in case callbacks modify list
            try:
                callback(**kwargs)
            except Exception:
                # Don't let one observer's failure break others
                import traceback

                traceback.print_exc()
                continue

    def clear_observers(self, event: str | None = None) -> None:
        """
        Clear all observers or observers for a specific event.

        Parameters
        ----------
        event : str, optional
            If provided, clear only observers for this event.
            If None, clear all observers.
        """
        if event is None:
            self._observers.clear()
        elif event in self._observers:
            del self._observers[event]


class SerializableMixin:
    """
    Mixin for serializable objects.

    Provides methods for converting objects to/from JSON and dictionaries,
    with support for dataclasses and custom serialization.

    Examples
    --------
    >>> from dataclasses import dataclass
    >>> from causaloop import SerializableMixin
    >>> @dataclass
    ... class Point(SerializableMixin):
    ...     x: float
    ...     y: float
    >>> p = Point(1.0, 2.0)
    >>> p.to_dict()
    {'x': 1.0, 'y': 2.0}
    >>> p.to_json()
    '{"x": 1.0, "y": 2.0}'
    """

    def to_dict(self) -> dict[str, Any]:
        """
        Convert object to dictionary.

        Returns
        -------
        dict
            Dictionary representation.

        Notes
        -----
        For dataclasses, uses dataclasses.asdict().
        For other classes, uses __dict__ but filters private attributes.
        """
        if is_dataclass(self):
            return asdict(self)

        # For non-dataclasses, serialize public attributes
        result: dict[str, Any] = {}
        for key, value in self.__dict__.items():
            if not key.startswith("_"):
                result[key] = self._serialize_value(value)

        return result

    def _serialize_value(self, value: Any) -> Any:
        """
        Serialize a value for dictionary representation.

        Parameters
        ----------
        value : Any
            Value to serialize.

        Returns
        -------
        Any
            Serializable representation.
        """
        if is_dataclass(value) and not isinstance(value, type):
            return asdict(value)
        elif hasattr(value, "to_dict"):
            return value.to_dict()
        elif isinstance(value, set | list | tuple):
            return [self._serialize_value(v) for v in value]
        elif isinstance(value, dict):
            return {k: self._serialize_value(v) for k, v in value.items()}
        else:
            return value

    def to_json(self, indent: int | None = None) -> str:
        """
        Convert object to JSON string.

        Parameters
        ----------
        indent : int, optional
            JSON indentation.

        Returns
        -------
        str
            JSON string representation.
        """
        return json.dumps(self.to_dict(), indent=indent, default=str)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SerializableMixin":
        """
        Create object from dictionary.

        Parameters
        ----------
        data : dict
            Dictionary representation.

        Returns
        -------
        SerializableMixin
            New instance.

        Raises
        ------
        NotImplementedError
            If class doesn't implement custom from_dict.
        """
        if is_dataclass(cls):
            return cls(**data)
        raise NotImplementedError(
            f"{cls.__name__}.from_dict() not implemented " f"for non-dataclass types"
        )

    @classmethod
    def from_json(cls, json_str: str) -> "SerializableMixin":
        """
        Create object from JSON string.

        Parameters
        ----------
        json_str : str
            JSON string representation.

        Returns
        -------
        SerializableMixin
            New instance.
        """
        data = json.loads(json_str)
        return cls.from_dict(data)


class StatefulMixin(Generic[T]):
    """
    Mixin for objects with state that can be saved and restored.

    Provides checkpoint/restore functionality for Variables, Mechanisms,
    and Processes. Useful for counterfactual reasoning and optimization
    where state needs to be rolled back.

    Type Parameters
    ---------------
    T
        Type of the state representation.

    Examples
    --------
    >>> from causaloop import StatefulMixin
    >>> class Simulation(StatefulMixin[dict[str, float]]):
    ...     def __init__(self):
    ...         self.time = 0.0
    ...         self.values = {'x': 0.0, 'y': 0.0}
    ...     def get_state(self) -> dict[str, float]:
    ...         return {'time': self.time, **self.values}
    ...     def set_state(self, state: dict[str, float]) -> None:
    ...         self.time = state['time']
    ...         self.values = {k: state[k] for k in ['x', 'y']}
    >>> sim = Simulation()
    >>> checkpoint = sim.checkpoint()
    >>> sim.time = 10.0
    >>> sim.restore(checkpoint)
    >>> sim.time
    0.0
    """

    @abstractmethod
    def get_state(self) -> T:
        """
        Get current state.

        Returns
        -------
        T
            State representation.

        Notes
        -----
        Must be implemented by subclass.
        """
        pass

    @abstractmethod
    def set_state(self, state: T) -> None:
        """
        Set state from representation.

        Parameters
        ----------
        state : T
            State representation.

        Notes
        -----
        Must be implemented by subclass.
        """
        pass

    def checkpoint(self) -> T:
        """
        Create a checkpoint of current state.

        Returns
        -------
        T
            State checkpoint.
        """
        return self.get_state()

    def restore(self, checkpoint: T) -> None:
        """
        Restore state from checkpoint.

        Parameters
        ----------
        checkpoint : T
            State checkpoint to restore.
        """
        self.set_state(checkpoint)

    def get_state_diff(self, other_state: T) -> dict[str, Any]:
        """
        Get difference between current state and another state.

        Parameters
        ----------
        other_state : T
            Other state to compare with.

        Returns
        -------
        dict
            Dictionary of differences.

        Notes
        -----
        Default implementation assumes state is a dictionary.
        Override for custom state types.
        """
        current = self.get_state()

        if not (isinstance(current, dict) and isinstance(other_state, dict)):
            raise TypeError(
                "Default get_state_diff only works with dict states. "
                "Override this method for custom state types."
            )

        # Type narrowing - mypy now knows these are dicts
        current_dict = cast(dict[str, Any], current)
        other_dict = cast(dict[str, Any], other_state)

        diff: dict[str, Any] = {}
        all_keys = set(current_dict.keys()) | set(other_dict.keys())

        for key in all_keys:
            if key in current_dict and key in other_dict:
                if current_dict[key] != other_dict[key]:
                    diff[key] = {
                        "current": current_dict[key],
                        "other": other_dict[key],
                    }
            elif key in current_dict:
                diff[key] = {"current": current_dict[key], "other": None}
            else:
                diff[key] = {"current": None, "other": other_dict[key]}

        return diff
