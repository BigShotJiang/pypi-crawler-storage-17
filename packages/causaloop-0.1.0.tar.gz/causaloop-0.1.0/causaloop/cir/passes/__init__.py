"""Docstring for causaloop.cir.passes."""
