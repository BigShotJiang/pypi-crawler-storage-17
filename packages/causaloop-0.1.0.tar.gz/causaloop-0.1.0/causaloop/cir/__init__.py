"""Docstring for causaloop.cir."""
