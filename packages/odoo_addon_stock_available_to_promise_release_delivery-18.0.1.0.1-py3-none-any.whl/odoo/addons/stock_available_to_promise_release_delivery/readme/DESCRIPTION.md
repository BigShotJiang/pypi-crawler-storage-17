Glue module between *Stock Available to Promise Release* and *Delivery - Stock*.

When updating the delivery method on an unreleased delivery order, it'll ensure
moves will take the expected delivery route.
