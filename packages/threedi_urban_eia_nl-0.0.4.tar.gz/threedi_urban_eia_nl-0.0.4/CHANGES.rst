Changelog of threedi-urban-eia-nl
===================================================


0.0.4 (2025-12-19)
------------------

- Fix title underline length in README.rst example section.


0.0.3 (2025-12-19)
------------------

- Also scan for .gpkg files in zip archives when looking for schematisation database.


0.0.2 (2024-09-10)
------------------

- Publish to PyPI via OIDC

- Update all github action versions.


0.0.1 (2024-09-10)
------------------

- Initial project structure created with cookiecutter and
  https://github.com/nens/cookiecutter-python-template

- Move to pyproject.toml

- Clean up workflows and project structure
