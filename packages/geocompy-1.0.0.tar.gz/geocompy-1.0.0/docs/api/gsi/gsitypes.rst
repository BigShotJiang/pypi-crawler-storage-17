:icon: material/code-braces

Types
=====

.. automodule:: geocompy.gsi.gsitypes
    :exclude-members: param_descriptions,word_descriptions

    Definitions
    -----------

.. autodata:: param_descriptions
    :no-value:

.. autodata:: word_descriptions
    :no-value:
