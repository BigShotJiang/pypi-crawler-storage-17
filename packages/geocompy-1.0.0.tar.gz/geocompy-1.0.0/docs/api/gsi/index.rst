:icon: protocol_gsionline

GSI Online
==========

.. automodule:: geocompy.gsi
    :inherited-members:

    Definitions
    -----------

.. toctree::
    :maxdepth: 1
    :hidden:

    gsitypes
    gsidata
    gsiformat
