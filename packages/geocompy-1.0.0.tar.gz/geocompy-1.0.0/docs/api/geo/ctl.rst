:icon: material/arrow-right-bottom

Controller Task
===============

.. automodule:: geocompy.geo.ctl
    :inherited-members:

    Definitions
    -----------
