:icon: material/arrow-right-bottom

Alt-User
========

.. automodule:: geocompy.geo.aus
    :inherited-members:

    Definitions
    -----------