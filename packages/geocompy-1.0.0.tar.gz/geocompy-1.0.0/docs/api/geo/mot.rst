:icon: material/arrow-right-bottom

Motorization
============

.. automodule:: geocompy.geo.mot
    :inherited-members:

    Definitions
    -----------
