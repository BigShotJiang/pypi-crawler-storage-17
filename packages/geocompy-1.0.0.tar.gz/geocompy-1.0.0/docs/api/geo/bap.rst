:icon: material/arrow-right-bottom

Basic Applications
==================

.. automodule:: geocompy.geo.bap
    :inherited-members:

    Definitions
    -----------
