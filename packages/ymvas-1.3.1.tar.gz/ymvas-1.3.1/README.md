Ymvas - handle your life like a developer!

Installation:
```bash
pip3 install ymvas
```

Installation system base:
```bash
curl -sL http://docs.ymvas.com/vas/ymvas/install-unix.bash | bash
```

