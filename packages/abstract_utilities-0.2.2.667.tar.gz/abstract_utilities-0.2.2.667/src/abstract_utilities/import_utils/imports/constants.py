IMPORT_TAG = 'import '
FROM_TAG = 'from '
