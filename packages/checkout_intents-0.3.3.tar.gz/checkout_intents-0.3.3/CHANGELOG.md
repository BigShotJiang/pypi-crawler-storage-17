# Changelog

## 0.3.3 (2025-12-17)

Full Changelog: [v0.3.2...v0.3.3](https://github.com/rye-com/checkout-intents-python/compare/v0.3.2...v0.3.3)

### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([1567425](https://github.com/rye-com/checkout-intents-python/commit/156742587303ed71cd6bd48cac88b289aa7b066a))


### Chores

* **docs:** use environment variables for authentication in code snippets ([1786fcf](https://github.com/rye-com/checkout-intents-python/commit/1786fcf0791f227d91a07e3aad06a302d16aa8e0))
* **internal:** add missing files argument to base client ([3af52aa](https://github.com/rye-com/checkout-intents-python/commit/3af52aa804ed204b5aeab65b996956448a2f0225))
* update lockfile ([3695089](https://github.com/rye-com/checkout-intents-python/commit/3695089432c17c48ebd52580651c023e75c44b8d))

## 0.3.2 (2025-11-28)

Full Changelog: [v0.3.1...v0.3.2](https://github.com/rye-com/checkout-intents-python/compare/v0.3.1...v0.3.2)

### Bug Fixes

* ensure streams are always closed ([33adf1a](https://github.com/rye-com/checkout-intents-python/commit/33adf1a16c46c3ec7463a1af36351efb76479b1f))


### Chores

* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([61385ca](https://github.com/rye-com/checkout-intents-python/commit/61385ca14394f826160467cb3d50168b652263c9))

## 0.3.1 (2025-11-22)

Full Changelog: [v0.3.0...v0.3.1](https://github.com/rye-com/checkout-intents-python/compare/v0.3.0...v0.3.1)

### Chores

* add Python 3.14 classifier and testing ([c5e5f48](https://github.com/rye-com/checkout-intents-python/commit/c5e5f4878211b638fad6db325ee1ea2971571c1e))

## 0.3.0 (2025-11-18)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/rye-com/checkout-intents-python/compare/v0.2.0...v0.3.0)

### Features

* Add python sdk target to stainless config ([eea256f](https://github.com/rye-com/checkout-intents-python/commit/eea256fef46bb35554488dba5a0818345096a66a))


### Bug Fixes

* **docs:** supply valid buyer details ([12d25b1](https://github.com/rye-com/checkout-intents-python/commit/12d25b12808a05aaedcf48fc97384b5da40ca7e4))


### Chores

* **internal:** format code ([445dea0](https://github.com/rye-com/checkout-intents-python/commit/445dea070ddcc8574d0304001e79bd25ca2f9de7))

## 0.2.0 (2025-11-13)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/rye-com/checkout-intents-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** add polling helpers ([35dfc75](https://github.com/rye-com/checkout-intents-python/commit/35dfc75a2335fabb2ad1bab4b14f3f231deca600))
* **api:** infer environment from api key ([341d678](https://github.com/rye-com/checkout-intents-python/commit/341d6781d5275abec09fcc6d4634d3725f096674))


### Bug Fixes

* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([004dd94](https://github.com/rye-com/checkout-intents-python/commit/004dd94cb5ec8647b21ba2568744bbb3e850c132))


### Chores

* **internal:** add type ignore annotations ([0d0990e](https://github.com/rye-com/checkout-intents-python/commit/0d0990e8b9f83614725366b69df65ca2c9aec402))
* **internal:** replace rye with uv ([6cc9fcc](https://github.com/rye-com/checkout-intents-python/commit/6cc9fcc05af9040b863187affc79323812af3d83))


### Documentation

* **api:** add polling helpers ([7bd9f19](https://github.com/rye-com/checkout-intents-python/commit/7bd9f19fbec2bdc289cc3ace4edfa10e0914b3a2))
* **internal:** replace rye with uv ([7fbabe6](https://github.com/rye-com/checkout-intents-python/commit/7fbabe69d822fc3577a1762804dae36e9ea7385a))

## 0.1.0 (2025-11-11)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/rye-com/checkout-intents-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([e4a0e20](https://github.com/rye-com/checkout-intents-python/commit/e4a0e206d7566f904ac22caea8954990ad5c7271))
* **api:** api update ([7d95f0d](https://github.com/rye-com/checkout-intents-python/commit/7d95f0db63098d4edf209c7291959eb5f08df44b))


### Chores

* configure new SDK language ([a8f36d4](https://github.com/rye-com/checkout-intents-python/commit/a8f36d46dc5c0d3e868d289132bb83465736d0f5))
* update SDK settings ([5271e8a](https://github.com/rye-com/checkout-intents-python/commit/5271e8aa9f149e67b203919039afb2f61deca5e2))
* update SDK settings ([949efc6](https://github.com/rye-com/checkout-intents-python/commit/949efc6b67a53d856d11214bc6a924d879c2dfab))
