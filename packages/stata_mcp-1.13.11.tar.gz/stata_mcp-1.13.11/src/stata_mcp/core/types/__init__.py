from _error import StataMCPError

__all__ = [
    "StataMCPError"
]
