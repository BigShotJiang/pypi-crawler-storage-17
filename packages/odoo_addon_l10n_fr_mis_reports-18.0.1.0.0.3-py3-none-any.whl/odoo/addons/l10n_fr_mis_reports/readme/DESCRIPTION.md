This modules provides MIS Builder Report templates for the French P&L
and Balance Sheet taking the liasse fiscale and liasse fiscale
simplifiée as reference.
