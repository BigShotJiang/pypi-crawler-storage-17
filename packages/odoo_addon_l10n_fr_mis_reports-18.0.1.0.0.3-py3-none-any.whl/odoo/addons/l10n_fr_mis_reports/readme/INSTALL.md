This module depends on the *mis_builder* module, which is available in
the OCA project [mis-builder](https://github.com/OCA/mis-builder).
