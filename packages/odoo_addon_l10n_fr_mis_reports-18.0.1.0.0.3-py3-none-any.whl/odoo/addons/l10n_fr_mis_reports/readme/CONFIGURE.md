To configure this module, you need to go to *Invoicing \> Reporting \>
MIS Reporting \> MIS Reports* and create a new MIS Report according to
the desired time periods and using one of the following templates
provided by this module:

- Compte de résultat (FR - liasse fiscale)
- Compte de résultat (FR - liasse fiscale simplifiée)
- Bilan (FR - liasse fiscale)
- Bilan (FR - liasse fiscale simplifiée)

To obtain correct results, the account codes prefixes must match the
official French chart of accounts.
