To use this module, you need to go to *Invoicing \> Reporting \> MIS
Reporting \> MIS reports* and use the buttons available on the
previously configured reports such as **Preview**, **Print** and
**Export**.
