# Copyright 2025 Canonical Ltd.
# See LICENSE file for licensing details.
"""The configuration constants and objects used by the charms."""
