"""Tests for dbbasic_web.router module"""
import pytest
from dbbasic_web.router import (
    parse_query_string, parse_form_data, parse_cookies
)


class TestParseQueryString:
    """Test parse_query_string() function"""

    def test_empty_string(self):
        """Empty string should return empty dict"""
        assert parse_query_string("") == {}

    def test_single_param(self):
        """Single param should parse correctly"""
        assert parse_query_string("page=1") == {"page": "1"}

    def test_multiple_params(self):
        """Multiple params should parse correctly"""
        result = parse_query_string("page=1&limit=10&sort=name")
        assert result == {"page": "1", "limit": "10", "sort": "name"}

    def test_url_encoded_values(self):
        """URL encoded values should be decoded"""
        result = parse_query_string("name=John%20Doe&email=john%40example.com")
        assert result == {"name": "John Doe", "email": "john@example.com"}

    def test_empty_value(self):
        """Empty value is discarded by parse_qsl default behavior"""
        result = parse_query_string("key=")
        # Note: urllib.parse.parse_qsl discards empty values by default
        assert result == {}


class TestParseFormData:
    """Test parse_form_data() function"""

    def test_empty_body(self):
        """Empty body should return empty dicts"""
        form, files = parse_form_data(b"", "application/x-www-form-urlencoded")
        assert form == {}
        assert files == {}

    def test_urlencoded_form(self):
        """URL encoded form should parse correctly"""
        body = b"username=alice&password=secret"
        content_type = "application/x-www-form-urlencoded"
        form, files = parse_form_data(body, content_type)
        assert form == {"username": "alice", "password": "secret"}
        assert files == {}

    def test_urlencoded_with_charset(self):
        """URL encoded with charset should parse correctly"""
        body = b"name=test"
        content_type = "application/x-www-form-urlencoded; charset=utf-8"
        form, files = parse_form_data(body, content_type)
        assert form == {"name": "test"}
        assert files == {}

    def test_unknown_content_type(self):
        """Unknown content type should return empty dicts"""
        form, files = parse_form_data(b"some data", "text/plain")
        assert form == {}
        assert files == {}

    def test_multipart_form_field(self):
        """Multipart form should parse text fields"""
        boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
        body = (
            b"------WebKitFormBoundary7MA4YWxkTrZu0gW\r\n"
            b'Content-Disposition: form-data; name="username"\r\n'
            b"\r\n"
            b"alice\r\n"
            b"------WebKitFormBoundary7MA4YWxkTrZu0gW--\r\n"
        )
        content_type = f"multipart/form-data; boundary={boundary}"
        form, files = parse_form_data(body, content_type)
        assert form == {"username": "alice"}
        assert files == {}

    def test_multipart_file_upload(self):
        """Multipart form should parse file uploads"""
        boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
        file_content = b"Hello, this is file content!"
        body = (
            b"------WebKitFormBoundary7MA4YWxkTrZu0gW\r\n"
            b'Content-Disposition: form-data; name="document"; filename="test.txt"\r\n'
            b"Content-Type: text/plain\r\n"
            b"\r\n"
            + file_content +
            b"\r\n"
            b"------WebKitFormBoundary7MA4YWxkTrZu0gW--\r\n"
        )
        content_type = f"multipart/form-data; boundary={boundary}"
        form, files = parse_form_data(body, content_type)
        assert form == {}
        assert "document" in files
        assert files["document"]["filename"] == "test.txt"
        assert files["document"]["content"] == file_content

    def test_multipart_mixed_fields_and_files(self):
        """Multipart form should handle both fields and files"""
        boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
        file_content = b"\x89PNG\r\n\x1a\n"  # PNG magic bytes
        body = (
            b"------WebKitFormBoundary7MA4YWxkTrZu0gW\r\n"
            b'Content-Disposition: form-data; name="title"\r\n'
            b"\r\n"
            b"My Photo\r\n"
            b"------WebKitFormBoundary7MA4YWxkTrZu0gW\r\n"
            b'Content-Disposition: form-data; name="photo"; filename="image.png"\r\n'
            b"Content-Type: image/png\r\n"
            b"\r\n"
            + file_content +
            b"\r\n"
            b"------WebKitFormBoundary7MA4YWxkTrZu0gW--\r\n"
        )
        content_type = f"multipart/form-data; boundary={boundary}"
        form, files = parse_form_data(body, content_type)
        assert form == {"title": "My Photo"}
        assert "photo" in files
        assert files["photo"]["filename"] == "image.png"
        assert files["photo"]["content"] == file_content


class TestParseCookies:
    """Test parse_cookies() function"""

    def test_empty_headers(self):
        """Empty headers should return empty dict"""
        assert parse_cookies([]) == {}

    def test_single_cookie(self):
        """Single cookie should parse correctly"""
        headers = [(b"cookie", b"session=abc123")]
        result = parse_cookies(headers)
        assert result == {"session": "abc123"}

    def test_multiple_cookies(self):
        """Multiple cookies should parse correctly"""
        headers = [(b"cookie", b"session=abc123; user=alice; theme=dark")]
        result = parse_cookies(headers)
        assert result == {"session": "abc123", "user": "alice", "theme": "dark"}

    def test_cookie_with_spaces(self):
        """Cookies with spaces should be trimmed"""
        headers = [(b"cookie", b"session = abc123 ; user = alice")]
        result = parse_cookies(headers)
        assert result == {"session": "abc123", "user": "alice"}

    def test_string_header_values(self):
        """String header values should work"""
        headers = [(b"cookie", "session=abc123")]
        result = parse_cookies(headers)
        assert result == {"session": "abc123"}

    def test_ignores_non_cookie_headers(self):
        """Non-cookie headers should be ignored"""
        headers = [
            (b"content-type", b"application/json"),
            (b"cookie", b"session=abc123"),
            (b"accept", b"*/*"),
        ]
        result = parse_cookies(headers)
        assert result == {"session": "abc123"}

    def test_cookie_without_value(self):
        """Cookie without = should be ignored"""
        headers = [(b"cookie", b"invalid; session=abc123")]
        result = parse_cookies(headers)
        # 'invalid' has no =, so only 'session' should be parsed
        assert result == {"session": "abc123"}
