"""Tests for dbbasic_web.request module"""
import pytest
from dbbasic_web.request import Request


class TestRequestBasicProperties:
    """Test basic Request property access"""

    def test_method_default(self):
        """Default method should be GET"""
        request = Request({})
        assert request.method == 'GET'

    def test_method_explicit(self):
        """Method should return explicit value"""
        request = Request({'method': 'POST'})
        assert request.method == 'POST'

    def test_path_default(self):
        """Default path should be /"""
        request = Request({})
        assert request.path == '/'

    def test_path_explicit(self):
        """Path should return explicit value"""
        request = Request({'path': '/users/123'})
        assert request.path == '/users/123'

    def test_body_default(self):
        """Default body should be empty bytes"""
        request = Request({})
        assert request.body == b''

    def test_body_explicit(self):
        """Body should return explicit value"""
        request = Request({'body': b'hello world'})
        assert request.body == b'hello world'


class TestRequestDictAccess:
    """Test PHP-style dict access"""

    def test_POST_empty(self):
        """POST should return empty dict by default"""
        request = Request({})
        assert request.POST == {}

    def test_POST_with_form_data(self):
        """POST should return form data"""
        request = Request({'form': {'username': 'alice', 'password': 'secret'}})
        assert request.POST == {'username': 'alice', 'password': 'secret'}

    def test_GET_empty(self):
        """GET should return empty dict by default"""
        request = Request({})
        assert request.GET == {}

    def test_GET_with_query_data(self):
        """GET should return query string data"""
        request = Request({'query': {'page': '1', 'limit': '10'}})
        assert request.GET == {'page': '1', 'limit': '10'}

    def test_COOKIES_empty(self):
        """COOKIES should return empty dict by default"""
        request = Request({})
        assert request.COOKIES == {}

    def test_COOKIES_with_data(self):
        """COOKIES should return cookie data"""
        request = Request({'cookies': {'session': 'abc123'}})
        assert request.COOKIES == {'session': 'abc123'}

    def test_PATH_empty(self):
        """PATH should return empty list by default"""
        request = Request({})
        assert request.PATH == []

    def test_PATH_with_parts(self):
        """PATH should return path parts"""
        request = Request({'path_parts': ['users', '123', 'edit']})
        assert request.PATH == ['users', '123', 'edit']


class TestRequestParam:
    """Test param() method - Perl CGI.pm style"""

    def test_param_from_POST(self):
        """param() should return POST value first"""
        request = Request({
            'form': {'email': 'post@example.com'},
            'query': {'email': 'get@example.com'}
        })
        assert request.param('email') == 'post@example.com'

    def test_param_from_GET_when_not_in_POST(self):
        """param() should fall back to GET"""
        request = Request({
            'form': {},
            'query': {'page': '5'}
        })
        assert request.param('page') == '5'

    def test_param_default_when_missing(self):
        """param() should return default when key not found"""
        request = Request({'form': {}, 'query': {}})
        assert request.param('missing', 'default_value') == 'default_value'

    def test_param_none_when_missing_no_default(self):
        """param() should return None when key not found and no default"""
        request = Request({'form': {}, 'query': {}})
        assert request.param('missing') is None


class TestRequestCookie:
    """Test cookie() method"""

    def test_cookie_exists(self):
        """cookie() should return cookie value"""
        request = Request({'cookies': {'session': 'token123'}})
        assert request.cookie('session') == 'token123'

    def test_cookie_missing_with_default(self):
        """cookie() should return default when missing"""
        request = Request({'cookies': {}})
        assert request.cookie('session', 'none') == 'none'

    def test_cookie_missing_no_default(self):
        """cookie() should return None when missing and no default"""
        request = Request({'cookies': {}})
        assert request.cookie('session') is None


class TestRequestPathParam:
    """Test path_param() method"""

    def test_path_param_valid_index(self):
        """path_param() should return segment at index"""
        request = Request({'path_parts': ['users', '123', 'edit']})
        assert request.path_param(0) == 'users'
        assert request.path_param(1) == '123'
        assert request.path_param(2) == 'edit'

    def test_path_param_out_of_bounds(self):
        """path_param() should return default when out of bounds"""
        request = Request({'path_parts': ['users']})
        assert request.path_param(5, 'default') == 'default'

    def test_path_param_out_of_bounds_no_default(self):
        """path_param() should return None when out of bounds and no default"""
        request = Request({'path_parts': ['users']})
        assert request.path_param(5) is None


class TestRequestFiles:
    """Test files property for multipart uploads"""

    def test_files_empty(self):
        """files should return empty dict by default"""
        request = Request({})
        assert request.files == {}

    def test_files_with_upload(self):
        """files should return uploaded file data"""
        request = Request({
            'files': {
                'avatar': {
                    'filename': 'photo.jpg',
                    'content': b'\xff\xd8\xff\xe0',
                    'content_type': 'image/jpeg'
                }
            }
        })
        assert 'avatar' in request.files
        assert request.files['avatar']['filename'] == 'photo.jpg'
        assert request.files['avatar']['content'] == b'\xff\xd8\xff\xe0'

    def test_files_multiple_uploads(self):
        """files should support multiple file uploads"""
        request = Request({
            'files': {
                'doc1': {'filename': 'a.pdf', 'content': b'pdf1', 'content_type': 'application/pdf'},
                'doc2': {'filename': 'b.pdf', 'content': b'pdf2', 'content_type': 'application/pdf'},
            }
        })
        assert len(request.files) == 2
        assert request.files['doc1']['filename'] == 'a.pdf'
        assert request.files['doc2']['filename'] == 'b.pdf'


class TestRequestDictCompatibility:
    """Test that Request is still dict-compatible"""

    def test_dict_access(self):
        """Request should support dict-style access"""
        request = Request({'method': 'POST', 'path': '/test'})
        assert request['method'] == 'POST'
        assert request['path'] == '/test'

    def test_dict_get(self):
        """Request should support .get()"""
        request = Request({'method': 'POST'})
        assert request.get('method') == 'POST'
        assert request.get('missing', 'default') == 'default'

    def test_dict_keys(self):
        """Request should support .keys()"""
        request = Request({'method': 'POST', 'path': '/test'})
        assert set(request.keys()) == {'method', 'path'}

    def test_dict_in_operator(self):
        """Request should support 'in' operator"""
        request = Request({'method': 'POST'})
        assert 'method' in request
        assert 'missing' not in request
