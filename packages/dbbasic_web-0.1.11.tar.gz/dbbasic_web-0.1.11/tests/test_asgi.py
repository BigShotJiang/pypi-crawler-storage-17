"""Tests for dbbasic_web.asgi module"""
import pytest
from dbbasic_web.asgi import app


class MockReceive:
    """Mock ASGI receive callable"""

    def __init__(self, body: bytes = b""):
        self.body = body
        self.called = False

    async def __call__(self):
        if not self.called:
            self.called = True
            return {
                "type": "http.request",
                "body": self.body,
                "more_body": False
            }
        return {"type": "http.disconnect"}


class MockSend:
    """Mock ASGI send callable"""

    def __init__(self):
        self.messages = []

    async def __call__(self, message):
        self.messages.append(message)

    @property
    def status(self):
        """Get response status code"""
        for msg in self.messages:
            if msg["type"] == "http.response.start":
                return msg["status"]
        return None

    @property
    def headers(self):
        """Get response headers as dict"""
        for msg in self.messages:
            if msg["type"] == "http.response.start":
                return {
                    k.decode() if isinstance(k, bytes) else k:
                    v.decode() if isinstance(v, bytes) else v
                    for k, v in msg.get("headers", [])
                }
        return {}

    @property
    def body(self):
        """Get response body"""
        body_parts = []
        for msg in self.messages:
            if msg["type"] == "http.response.body":
                body_parts.append(msg.get("body", b""))
        return b"".join(body_parts)


@pytest.mark.asyncio
class TestAsgiApp:
    """Test ASGI application"""

    async def test_404_for_unknown_path(self):
        """Unknown path should return 404"""
        scope = {
            "type": "http",
            "method": "GET",
            "path": "/nonexistent/path/that/does/not/exist",
            "query_string": b"",
            "headers": [],
        }
        receive = MockReceive()
        send = MockSend()

        await app(scope, receive, send)

        assert send.status == 404

    async def test_http_request_reads_body(self):
        """HTTP handler should read request body"""
        scope = {
            "type": "http",
            "method": "POST",
            "path": "/test",
            "query_string": b"",
            "headers": [],
        }
        receive = MockReceive(body=b"test body content")
        send = MockSend()

        await app(scope, receive, send)

        # Just verify it didn't crash and returned something
        assert send.status is not None

    async def test_response_headers_encoded(self):
        """Response headers should be bytes"""
        scope = {
            "type": "http",
            "method": "GET",
            "path": "/nonexistent",
            "query_string": b"",
            "headers": [],
        }
        receive = MockReceive()
        send = MockSend()

        await app(scope, receive, send)

        # Check that response was sent
        assert len(send.messages) >= 1
        assert send.messages[0]["type"] == "http.response.start"


@pytest.mark.asyncio
class TestLifespanHandler:
    """Test ASGI lifespan handling"""

    async def test_lifespan_startup(self):
        """Lifespan startup should complete"""
        scope = {"type": "lifespan"}

        messages = [
            {"type": "lifespan.startup"},
            {"type": "lifespan.shutdown"},
        ]
        message_iter = iter(messages)

        async def receive():
            return next(message_iter)

        sent = []
        async def send(message):
            sent.append(message)

        await app(scope, receive, send)

        assert {"type": "lifespan.startup.complete"} in sent
        assert {"type": "lifespan.shutdown.complete"} in sent
