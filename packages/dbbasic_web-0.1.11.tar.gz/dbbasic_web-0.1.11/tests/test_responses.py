"""Tests for dbbasic_web.responses module"""
import pytest
from dbbasic_web.responses import (
    html, json, json_error, text, redirect, sse_event, now_iso
)


class TestHtmlResponse:
    """Test html() response helper"""

    def test_html_basic(self):
        """html() should return correct tuple"""
        status, headers, body = html("<h1>Hello</h1>")
        assert status == 200
        assert ("content-type", "text/html; charset=utf-8") in headers
        assert body == [b"<h1>Hello</h1>"]

    def test_html_custom_status(self):
        """html() should accept custom status"""
        status, headers, body = html("<h1>Not Found</h1>", status=404)
        assert status == 404

    def test_html_additional_headers(self):
        """html() should merge additional headers"""
        status, headers, body = html(
            "<h1>Hello</h1>",
            headers=[("x-custom", "value")]
        )
        assert ("content-type", "text/html; charset=utf-8") in headers
        assert ("x-custom", "value") in headers

    def test_html_encodes_utf8(self):
        """html() should encode unicode to UTF-8"""
        status, headers, body = html("<p>Caf\u00e9</p>")
        assert body == ["<p>Caf\u00e9</p>".encode("utf-8")]


class TestJsonResponse:
    """Test json() response helper"""

    def test_json_with_string(self):
        """json() should accept string"""
        status, headers, body = json('{"key": "value"}')
        assert status == 200
        assert ("content-type", "application/json; charset=utf-8") in headers
        assert body == [b'{"key": "value"}']

    def test_json_with_bytes(self):
        """json() should accept bytes"""
        status, headers, body = json(b'{"key": "value"}')
        assert body == [b'{"key": "value"}']

    def test_json_custom_status(self):
        """json() should accept custom status"""
        status, headers, body = json('{}', status=201)
        assert status == 201

    def test_json_additional_headers(self):
        """json() should merge additional headers"""
        status, headers, body = json(
            '{}',
            headers=[("x-request-id", "123")]
        )
        assert ("x-request-id", "123") in headers


class TestJsonErrorResponse:
    """Test json_error() convenience helper"""

    def test_json_error_default_status(self):
        """json_error() should default to 404"""
        status, headers, body = json_error("Not found")
        assert status == 404
        assert ("content-type", "application/json; charset=utf-8") in headers

    def test_json_error_custom_status(self):
        """json_error() should accept custom status"""
        status, headers, body = json_error("Bad request", status=400)
        assert status == 400

    def test_json_error_body_format(self):
        """json_error() should format message correctly"""
        import json as json_lib
        status, headers, body = json_error("Something went wrong")
        parsed = json_lib.loads(body[0])
        assert parsed == {"error": "Something went wrong"}


class TestTextResponse:
    """Test text() response helper"""

    def test_text_basic(self):
        """text() should return correct tuple"""
        status, headers, body = text("Hello, World!")
        assert status == 200
        assert ("content-type", "text/plain; charset=utf-8") in headers
        assert body == [b"Hello, World!"]

    def test_text_custom_status(self):
        """text() should accept custom status"""
        status, headers, body = text("Error", status=500)
        assert status == 500


class TestRedirectResponse:
    """Test redirect() response helper"""

    def test_redirect_default_status(self):
        """redirect() should default to 302"""
        status, headers, body = redirect("/login")
        assert status == 302
        assert ("location", "/login") in headers
        assert body == [b""]

    def test_redirect_custom_status(self):
        """redirect() should accept custom status"""
        status, headers, body = redirect("/new-page", status=301)
        assert status == 301


class TestSseEvent:
    """Test sse_event() helper"""

    def test_sse_event_data_only(self):
        """sse_event() should format data-only event"""
        result = sse_event("hello")
        assert result == b"data: hello\n\n"

    def test_sse_event_with_event_type(self):
        """sse_event() should include event type"""
        result = sse_event("hello", event="message")
        assert b"event: message\n" in result
        assert b"data: hello\n" in result

    def test_sse_event_with_id(self):
        """sse_event() should include id"""
        result = sse_event("hello", id="123")
        assert b"id: 123\n" in result
        assert b"data: hello\n" in result

    def test_sse_event_multiline_data(self):
        """sse_event() should handle multiline data"""
        result = sse_event("line1\nline2\nline3")
        assert b"data: line1\n" in result
        assert b"data: line2\n" in result
        assert b"data: line3\n" in result

    def test_sse_event_empty_data(self):
        """sse_event() should handle empty data"""
        result = sse_event("")
        assert b"data: \n" in result


class TestNowIso:
    """Test now_iso() helper"""

    def test_now_iso_format(self):
        """now_iso() should return ISO format with Z suffix"""
        result = now_iso()
        assert result.endswith("Z")
        # Should be parseable datetime format
        assert "T" in result
        # Basic format: YYYY-MM-DDTHH:MM:SS.microsZ
        parts = result.rstrip("Z").split("T")
        assert len(parts) == 2
        date_part = parts[0]
        assert len(date_part.split("-")) == 3  # YYYY-MM-DD
