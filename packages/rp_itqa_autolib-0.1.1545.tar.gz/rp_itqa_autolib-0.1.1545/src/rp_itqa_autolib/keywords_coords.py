"""
----------------------------------------------------------------------------------
 Author:
 Created:
----------------------------------------------------------------------------------
"""

import sys
import time
from datetime import datetime, timedelta
from random import randrange
import random
import re
from time import gmtime, strftime
import pyautogui
import pywinauto
import RPA.Windows as rpawin
import typing
from RPA.core.windows.context import ElementNotFound
from RPA.core.windows.locators import WindowsElement
from RPA.Windows import Windows
import pywinauto.base_wrapper
import pywinauto.controls
import pywinauto.element_info
from robot.api import logger
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto import findwindows
from pywinauto import timings
from pywinauto import findbestmatch
from pywinauto.application import Application


AlteraWindow = "Altera Gateway"
_static_win = None
statusCellClass = "k-touch-action-auto gridFontSmall row-align ng-star-inserted"
dateCellClass   = "k-touch-action-auto gridFontSmall row-align date-padding ng-star-inserted"

def Click_Add_Rx_Button_Py():
    try:
        logger.console(f"   Click_Add_Rx_Button_Py() ... [Py]")
        rootWebArea = Get_RootWebArea() 
        dlg = rootWebArea.child_window(class_name="navbar-primary", control_type="Group")
        dlg = dlg.child_window(class_name="navbar-primary-menu", control_type="List")#dlg.print_control_identifiers()
        logger.console(f"      Search 'title_re=.*Add Rx.*' ... [py]")
        dlg = dlg.child_window(title_re=".*Add Rx.*", control_type="ListItem")
        logger.console(f"      Click 'Add Rx' ... [py]\n")
        #logger.console(f"      Click 'Add Rx' (auto_id=\"rxsb-add-rx-new-search\" ... [py]\n")
        #dlg = dlg.child_window( auto_id="rxsb-add-rx-new-search", control_type="Hyperlink")
        dlg.click_input(double=True)
        time.sleep(5)
        
    except Exception as e:
        logger.console(f"      **ERROR** in 'Click_Add_Rx_Button_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        raise Exception(f"{e}")

def Type_Medication_To_Search_Py(search):
    try:
        logger.console(f"   Type_Medication_To_Search_Py()  (search='{search}') ...[Py]")
        rootWebArea = Get_RootWebArea()   #rootWebArea.print_control_identifiers()
        dlg = rootWebArea.child_window(control_type="Edit")
        dlg.click_input()
        logger.console(f"      typing '{search}' ... [py]\n")
        pyautogui.typewrite(f"{search}")
        
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Type_Medication_To_Search_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        raise Exception(f"Error={e}")

def Select_Rx_Py(x=450, y=327):  #x=450   y=327
    try:
        x = int(x)
        y = int(y)
        logger.console(f"    Select_Rx_Py(coords=({x},{y})) ...[Py]")
        logger.console(f"       Click 'Rx Item' (coords=({x},{y})) ...[Py]\n")
        pywinauto.mouse.move(coords=(x,y))
        time.sleep(2)
        pywinauto.mouse.click(coords=(x,y))

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Select_Rx_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        raise Exception(f"Error={e}")

def Fill_Out_Rx_Criteria_And_Submit_Py(xFreq=1204, yFreq=549):#X=1343,Y=549}
    try:
        xFreq = int(xFreq)
        yFreq = int(yFreq)

        logger.console(f"   Fill_Out_Rx_Criteria_And_Submit_Py (coords=({xFreq},{yFreq})) ...[Py]\n")
        #
        # Frequency
        logger.console("      Field Select [Frequency] ...  ") #Frequency - 4 times a day
        logger.console(f"         CLICK coords=({xFreq},{yFreq}) ...[py]")
        pywinauto.mouse.move(coords=(xFreq,yFreq))
        time.sleep(2)
        pywinauto.mouse.click(coords=(xFreq,yFreq))
        logger.console("          TYPE '4 times a day' ...[py]\n")
        pyautogui.typewrite("4 times a day")
        time.sleep(3)
        #
        # Reason for PRN
        logger.console("      Field Select [Reason for PRN] ....[py]") #Reason for PRN - for allergies
        logger.console("         PRESS 'TAB' *2 ... [py]")
        pyautogui.press(f"TAB", presses=2)
        logger.console("         TYPE 'for allergies' ...[py]\n")
        pyautogui.typewrite("for allergies")
        time.sleep(3)
        #
        # Package
        logger.console("      Field Select [Package] ...[py]") #packages
        logger.console("         PRESS 'TAB' *3 ... [py]")
        pyautogui.press(f"TAB", presses=4)
        logger.console("         TYPE '2' ... [py]")
        pyautogui.typewrite(f"2")                             #packages-Unit - 2  
        logger.console("         PRESS 'TAB' ... [py]")
        pyautogui.press(f"TAB")
        logger.console("         TYPE '10 g' ... [py]\n")
        pyautogui.typewrite(f"10 g")                           #packages-Unit - 10 g 
        time.sleep(3)
        #
        # Refills
        #
        logger.console(f"      Field Select [Refills] ...[py]")
        logger.console("          PRESS 'TAB' *3 ... [py]")
        pyautogui.press(f"TAB", presses=3)
        logger.console("          TYPE '3' ... [py]\n")
        pyautogui.typewrite("3")                             #Refills - 3
        time.sleep(3)
        #
        # Submit Method
        # 
        logger.console(f"      Field Select [Submit Method] ...[py]")
        logger.console("          PRESS 'TAB' *4 ... [py]")
        pyautogui.press("TAB", presses=4)
        logger.console(f"         CLICK coords=({1304},{657}) ... [py]")
        pywinauto.mouse.move(coords=(1304,657))
        time.sleep(3)
        logger.console("          TYPE 'Add to Med' ... [py]\n")
        pyautogui.typewrite("Add to Med")
        #logger.console("          PRESS 'DOWN' *2 (Selects 'Add to Med')... [py]") 
        #pyautogui.press("DOWN", presses=2) # Add to Med List Only
        #time.sleep(3)
        #logger.console("          PRESS 'ENTER' ... [py]\n")
        #pyautogui.press("ENTER")
        time.sleep(3)
        #
        # Internal Note
        #
        logger.console(f"      Field Select [Internal Note] ...[py]")
        logger.console("          PRESS 'TAB' *3 ... [py]")
        pyautogui.press("TAB", presses=3)
        logger.console("          TYPE 'Testing' ... [py]\n")
        pyautogui.typewrite("Testing")
        time.sleep(3)
        #
        # Submit
        #
        logger.console(f"      Click 'Submit' ... [py]")
        logger.console(f"         CLICK coords=({1667},{820}) ... [py]")
        pywinauto.mouse.move(coords=(1667,820))
        time.sleep(3)
        pywinauto.mouse.click(coords=(1667,820))

    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Fill_Out_Rx_Criteria_And_Submit_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        raise Exception(f"Error={e}")

def Discontinue_Medications_Py():
    logger.console(f"   Discontinue_Medications() ...[Py]")
    time.sleep(3)
    currDateCheck = Get_Date_ddmmmyyyy_Dashes_Lead_0()
    logger.console(f"      (Search Date Match = '{currDateCheck}') ...[Py]")
    logger.console(f"      (Search Status = 'Active') ...[Py]")
    
    rootWebArea = Get_RootWebArea()
    dataGrid = Get_Data_Grid() #control_type="DataGrid", class_name="k-grid-aria-root")

    rowGroup = dataGrid.child_window(class_name="k-table-tbody", control_type="Group") #k-grid-content k-virtual-content (old)
    allRows = rowGroup.children(control_type="DataItem") # GET ALL ROWS
    Print_Row_Headers(allRows)
    i = 0
    
    for row in allRows:
        i=i+1
        logger.console(f"      {str(i).ljust(6)}", newline=False)
        rowName = str(row.element_info.name)
        rowNameTrim = str(row.element_info.name)[0:50]
        logger.console(f"  {str(rowNameTrim).ljust(50)}", newline=False)
        
        rowValue = rowGroup.child_window(title=f"{rowName}", control_type="DataItem")#rowValue.print_control_identifiers()   
        statusCell = rowValue.child_window(title_re=f"Active|Inactive|Discontinued|No Longer Taking", control_type="DataItem")
        status = str(statusCell.element_info.name)
        logger.console(f"  {str(status).ljust(15)}", newline=False)
        
        dateCell = rowValue.child_window(title_re="[0-9].*-.*-202[0-9]", control_type="DataItem", found_index=0)
        date = str(dateCell.element_info.name)
        logger.console(f"  {str(date).ljust(18)}", newline=False)

        rowValue.click_input()
       
        
        if status=="Active" and date == currDateCheck:
            #################################################
            # CLICK Checkbox
            #################################################
            logger.console(f"  ('Active' and '{date}' FOUND)\n")
            checkbox = rowValue.child_window(control_type="DataItem", found_index=1) # get second item in row (checkbox)
            logger.console(f"      click checkbox ...[Py]")
            checkBox = checkbox.child_window(control_type="CheckBox") #'class_name="checkboxstyle",
            checkBox.click_input()
            #################################################
            # CLICK 'Dicontinue'
            #################################################
            logger.console(f"      CLICK 'Discontinue' ...[Py]")
            discontinueBtn = rootWebArea.child_window(title="Discontinue", control_type="Button")
            discontinueBtn.click_input()
            #################################################
            # Interact with Reason dialogue
            ################################################
            logger.console(f"      CLICK 'Reason' TextBox (coords={1270},{356}) ... [py]\n")
            pywinauto.mouse.move(coords=(1270,356))
            time.sleep(2)
            pywinauto.mouse.click(coords=(1270,356))
            time.sleep(2)
            logger.console(f"      Type Reason 'Intolerance' ...[Py]")
            pyautogui.typewrite("Intolerance")
            logger.console(f"      Select 'Discontinue_Medications(s)' ...[Py]")
            logger.console("          PRESS 'TAB' *3 ... [py]\n")
            pyautogui.press("TAB", presses=4)
            pyautogui.press(f"ENTER")

            return  # leave function, ACTIVE ROW FOUND AND DISCONTINUED
        else:
            logger.console(f"  ('Discontinued' and '{date}' NOT FOUND)")

    ##############################################################################
    ### IF YOU GET THIS FAR AND CANNOT FIND AN ACTIVE MEDICATION, THROW EXCEPTION
    ##############################################################################
    raise Exception(f"\nError=No Active Medications Found!! (Unable to discontinue) ...[Py]\n")


def Verify_Discontinued_Medications_Py():
    time.sleep(3)
    currDateCheck =Get_Date_ddmmmyyyy_Dashes_Lead_0()
    logger.console(f"   Verify_Discontinued_Medications() ...[Py]")
    logger.console(f"      (Search Date Match = '{currDateCheck}) ...[Py]")
    logger.console(f"      (Search Status = 'Discontinue' ) ...[Py]")

    dataGrid = Get_Data_Grid()
    ######################################################################################################
    # Unable to re-Activate these filters for next run. I will just check the status
    ######################################################################################################
    groupRows = dataGrid.child_window(class_name="k-table-tbody", control_type="Group")  #k-grid-content k-virtual-content
    allRows = groupRows.children(control_type="DataItem")
    Print_Row_Headers(allRows)
    i = 0
    
    for row in allRows:
        i=i+1
        logger.console(f"      {str(i).ljust(6)}", newline=False)
        rowName = str(row.element_info.name)
        rowNameTrim = str(row.element_info.name)[0:50]
        logger.console(f"  {str(rowNameTrim).ljust(50)}", newline=False)
        
        rowValue = groupRows.child_window(title=f"{rowName}", control_type="DataItem")#rowValue.print_control_identifiers()     
            
        statusCell = rowValue.child_window(title_re=f"Active|Inactive|Discontinued|No Longer Taking", control_type="DataItem")
        status = str(statusCell.element_info.name)
        logger.console(f"  {str(status).ljust(15)}", newline=False)
        
        dateCell = rowValue.child_window(title_re="[0-9].*-.*-202[0-9]", control_type="DataItem", found_index=0)
        date = str(dateCell.element_info.name)

        logger.console(f"  {str(date).ljust(18)}", newline=False)

        rowValue.click_input()
        ###############################################################################
        #-changing the filter in the drop down to now include 'Inactive: <br>
        #-The Rx will now display on screen with a status of Discontinued with the current date.
        ###############################################################################
        if status=="Discontinued" and date == currDateCheck:
            logger.console(f"  ('Discontinued' and '{date}' FOUND) [Py]\n")
            return  # leave function, DISCONTINUED ROW FOUND
        else:
            logger.console(f"  ('Discontinued' and '{date}' NOT FOUND )")

    ##############################################################################
    ### IF YOU GET THIS FAR AND CANNOT FIND THE DISCONTINUED MEDICATION, THROW EXCEPTION
    ##############################################################################
    raise Exception(f"\nError=No 'Discontinued' Medications Found!! ...[Py]\n")

##############################################################################
#                             HELPERS
##############################################################################
def Sort_By_Date_Desc_Py():
    logger.console(f"   Sort_By_Date_Desc_Py() ...[Py]")  

    logger.console(f"      CLICK 'X' To clear Filters (coords={1329},{324}) ... [py]\n")
    pywinauto.mouse.move(coords=(1329,324))
    time.sleep(2)
    pywinauto.mouse.click(coords=(1329,324))
    pywinauto.mouse.click(coords=(1329,324)) # need two clicks to get DESC

##################
# DEPRACATED
##################
def Sort_By_Status_Asc_Py(): #  1053, 324
    logger.console(f"    Sort_By_Status_Asc_Py() ...[Py]")  
    rootWebArea = Get_RootWebArea() 
    group1 = rootWebArea.child_window(class_name='k-widget k-grid',control_type="Group", found_index=0)
    dataGrid = group1.child_window(title="Data table", control_type="DataGrid", class_name="k-grid-aria-root")
    headerRow = dataGrid.child_window(title_re=".*Medication Details Sortable Status Sortable.*")
    origDateHeader = headerRow.child_window(title="Status Sortable",control_type="DataItem")
    origDate = origDateHeader.child_window(class_name="k-link",control_type="Group")
    logger.console(f"          click Arrow (Next to Status) ...[Py]\n")
    origDate.click_input() # sorts by asc  for getting Active first

def Filter_Only_InActive_Status_Py(x=1580):
    try:
        logger.console(f"   Filter_Only_InActive_Status_Py() ...[Py]\n")

        #################################################
        # CLICK Clear Filters
        #################################################
        logger.console(f"      CLICK 'X' To clear Filters (coords={x},243) ... [py]\n")
        pywinauto.mouse.move(coords=(1889,243))
        time.sleep(1)
        pywinauto.mouse.click(coords=(1889,243))

        #################################################
        # CLICK Filter Text Area
        #################################################
        logger.console(f"      CLICK Filter Text Area (coords={x},194) ... [py]\n")
        pywinauto.mouse.move(coords=(x,194))
        time.sleep(1)
        pywinauto.mouse.click(coords=(x,194))

        #################################################
        # CLICK Inactive
        #################################################
        logger.console(f"      CLICK 'Inactive' (coords={x},249) ... [py]\n")
        pywinauto.mouse.move(coords=(x,249))
        time.sleep(1)
        pywinauto.mouse.click(coords=(x,249))

 
    except Exception as e:
        logger.console(f"\n      **ERROR** in 'Filter_Only_InActive_Status_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        logger.console(f"")
        raise Exception(f"Error={e}")

def Add_Back_All_Filter_Statuses_Py(x=1580):
    try:
        logger.console(f"   Add_Back_All_Filter_Statuses_Py() ...[Py]\n")
        #################################################
        # CLICK Clear Filters
        #################################################
        logger.console(f"      CLICK 'X' To clear Filters (coords={1889},{243}) ... [py]\n")
        pywinauto.mouse.move(coords=(1889,243))
        time.sleep(1)
        pywinauto.mouse.click(coords=(1889,243))

        #################################################
        # CLICK Filter Text Area
        #################################################
        logger.console(f"      CLICK Filter Text Area (coords={x},194) ... [py]\n")
        pywinauto.mouse.move(coords=(x,194))
        time.sleep(1)
        pywinauto.mouse.click(coords=(x,194))


        #################################################
        # CLICK Active
        ################################################
        logger.console(f"      CLICK 'Active' (coords={x},224) ... [py]\n")
        pywinauto.mouse.move(coords=(x,224))
        time.sleep(1)
        pywinauto.mouse.click(coords=(x,224))

        #################################################
        # CLICK Inactive
        #################################################
        logger.console(f"      CLICK 'Inactive' (coords={x},249) ... [py]\n")
        pywinauto.mouse.move(coords=(x,249))
        time.sleep(1)
        pywinauto.mouse.click(coords=(x,249))

        #################################################
        # CLICK Unsubmitted
        #################################################
        logger.console(f"      CLICK 'Unsubmitted' (coords={x},274) ... [py]\n")
        pywinauto.mouse.move(coords=(x,274))
        time.sleep(1)
        pywinauto.mouse.click(coords=(x,274))

        #################################################
        # CLICK Unsubmitted
        #################################################
        logger.console(f"      CLICK 'Unsubmitted' (coords={x},299) ... [py]\n")
        pywinauto.mouse.move(coords=(x,299))
        time.sleep(1)
        pywinauto.mouse.click(coords=(x,299))

    except Exception as e:
        logger.console(f"\n    **ERROR** in 'Add_Back_All_Filter_Statuses_Py' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        logger.console(f"")
        raise Exception(f"Error={e}")

def Filter_Medications_Quick_Click():
    try:
        logger.console(f"   Filter_Active_Medications_Quick_Click() ...[Py]")    
        rootWebArea = Get_RootWebArea() 
        
        group = rootWebArea.child_window(class_name="k-multiselect-wrap k-floatwrap", control_type="Group")
        list = group.child_window(class_name="k-reset", control_type="List").click_input()
        
        pyautogui.press("backspace")
        logger.console(f"      Unselect 'Active' ...[Py]")
        pyautogui.press("backspace")
        logger.console(f"      Unselect 'Unsubmited' ...[Py]")
        pyautogui.press("Left", presses=2)
        pyautogui.press("backspace")
        logger.console(f"      Unselect 'No Longer Taking' ...[Py]\n")
 
    except Exception as e:
        logger.console(f"\n    **ERROR** in 'Filter_Medications' ...[Py]")
        logger.console(f"      (Error={e} ...[Py]\n")
        logger.console(f"")
        raise Exception(f"Error={e}")

def Get_Data_Grid():
    rootWebArea = Get_RootWebArea() 
    group1 = rootWebArea.child_window(class_name='k-grid k-grid-md',control_type="Group", found_index=0)  #'k-widget k-grid' (old)
    dataGrid = group1.child_window(title="Data table", control_type="DataGrid", class_name="k-grid-aria-root")
    return dataGrid

def Print_Row_Headers(allRows):
    logger.console(f"\n      rows={len(allRows)}\n")
    logger.console(f"      Search All Medications for Active ...[py]\n")

    logger.console(f"      {str('row').ljust(6)}  {str('Name').ljust(50)}  {str('Status').ljust(15)}  {str('OrigDate').ljust(18)}  {str('Result')}")
    logger.console(f"      ------  --------------------------------------------------  ---------------  ------------------  ------------------------------")

def Get_Prescription_Writer_App():
    app = Application(backend="uia")
    procs = findwindows.find_elements()
    for proc in procs:
        if "Prescription Writer" in proc.name:
            app = Application(backend="uia").connect(process=proc.process_id, handle=proc.handle)
            break
    return app,proc

def Get_RootWebArea():
    app, proc = Get_Prescription_Writer_App()
    app = app.window(handle=proc.handle) #dlg.print_control_identifiers()
    dlg = app.child_window(auto_id="webView")
    dlg = dlg.child_window(auto_id="webView2")
    dlg = dlg.child_window(class_name="Static", control_type="Text")
    dlg = dlg.child_window(class_name="Chrome_WidgetWin_0", control_type="Pane")
    #dlg = dlg.child_window(class_name="Chrome_WidgetWin_1", control_type="Pane")
    dlg = dlg.child_window(title="RxWriter", control_type="Pane")
    dlg = dlg.child_window(title="RxWriter - Web content", control_type="Pane")
    dlg = dlg.child_window(class_name="NonClientView", control_type="Pane")
    dlg = dlg.child_window(class_name="EmbeddedBrowserFrameView", control_type="Pane")
    dlg = dlg.child_window(class_name="BrowserView", control_type="Pane")
    dlg = dlg.child_window(class_name="SidebarContentsSplitView", control_type="Pane",found_index=0)
    dlg = dlg.child_window(class_name="SidebarContentsSplitView", control_type="Pane")
    dlg = dlg.child_window(class_name="View", control_type="Pane")
    rootWebArea = dlg.child_window(auto_id="RootWebArea")
    return rootWebArea

def Get_Date_ddmmmyyyy_Dashes():
    currDateCheck = str(datetime.now().strftime("%d-%b-%Y").lstrip('0').replace("/0", "-"))
    return currDateCheck

def Get_Date_ddmmmyyyy_Dashes_Lead_0():
    currDateCheck = str(datetime.now().strftime("%d-%b-%Y").replace("/0", "-"))
    return currDateCheck

###############################################
#                    MAIN
###############################################
#
if __name__ == '__main__':
    logger.console(f"\nBEGIN MAIN....\n")
    #Select_Rx_Py(450,327)
    #Type_Medication_To_Search_Py('Neosporin')
    #Select_Rx_Py()
    #Fill_Out_Rx_Criteria_And_Submit("Neosporin 400 units-3.5 mg-5000")
    #Discontinue_Medications_Py()
    #Filter_InActive_Medications_Quick_Click_Py()
    #Verify_Discontinued_Medications_Py()
    #Add_Back_All_Filter_Statuses_Py(1510,212,241,293,318)
    #Verify_Discontinued_Medications_Py()
    #Get_Date_ddmmmyyyy_Dashes_Lead_0()
    Filter_Only_InActive_Status_Py()