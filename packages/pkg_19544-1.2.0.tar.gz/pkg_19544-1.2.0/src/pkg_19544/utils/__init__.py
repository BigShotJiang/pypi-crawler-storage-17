from pkg_19544.configs import constants

__all__ = (
    "constants",
)
