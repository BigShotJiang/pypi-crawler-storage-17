# cleanurl-test

[![CI](https://github.com/tagdots-dev/cleanurl-test/actions/workflows/ci.yaml/badge.svg?logo=github&labelColor=222222)](https://github.com/tagdots-dev/cleanurl-test/actions/workflows/ci.yaml)
[![CodeQL](https://github.com/tagdots-dev/cleanurl-test/actions/workflows/reusable-codeql.yaml/badge.svg?logo=github&labelColor=222222)](https://github.com/tagdots-dev/cleanurl-test/actions/workflows/reusable-codeql.yaml)
[![coverage](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/tagdots-dev/cleanurl-test/refs/heads/badges/badges/coverage.json)](https://github.com/tagdots-dev/cleanurl-test/actions/workflows/cron-tasks.yaml)
