from teletools.cipher._file_cipher import decrypt_file_or_folder, encrypt_file_or_folder

__all__ = ["decrypt_file_or_folder", "encrypt_file_or_folder"]
