"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Test server for MCP Proxy Adapter framework.
This server demonstrates all features of the framework and is used for testing.
"""

