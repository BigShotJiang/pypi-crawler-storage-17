"""Core domain models and business logic."""
