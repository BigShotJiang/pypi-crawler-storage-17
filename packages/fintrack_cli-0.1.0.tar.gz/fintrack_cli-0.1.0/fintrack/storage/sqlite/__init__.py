"""SQLite implementation of storage repositories."""
