"""Tests for FinTrack."""
