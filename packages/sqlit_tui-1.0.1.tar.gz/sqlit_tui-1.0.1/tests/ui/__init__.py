"""UI tests package for Textual Pilot-based testing."""
