"""
UI components for the CAI REPL.
"""
