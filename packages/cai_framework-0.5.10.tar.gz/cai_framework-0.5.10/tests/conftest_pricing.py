# Minimal conftest for pricing tests
import pytest

# Simple configuration without problematic imports
def pytest_configure(config):
    """Configure pytest for pricing tests"""
    pass 