# `Processor interface`

::: cai.sdk.agents.tracing.processor_interface
