# `Setup`

::: cai.sdk.agents.tracing.setup
