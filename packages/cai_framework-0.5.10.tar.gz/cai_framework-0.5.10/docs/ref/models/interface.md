# `Model interface`

::: cai.sdk.agents.models.interface
