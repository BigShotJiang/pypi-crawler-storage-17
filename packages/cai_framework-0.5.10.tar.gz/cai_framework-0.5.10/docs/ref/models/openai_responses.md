# `OpenAI Responses model`

::: cai.sdk.agents.models.openai_responses
