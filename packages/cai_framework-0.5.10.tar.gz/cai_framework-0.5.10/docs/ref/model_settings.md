# `Model settings`

::: cai.sdk.agents.model_settings
