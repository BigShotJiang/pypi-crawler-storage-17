# `Events`

::: cai.sdk.agents.voice.events
