# `Model`

::: cai.sdk.agents.voice.model
