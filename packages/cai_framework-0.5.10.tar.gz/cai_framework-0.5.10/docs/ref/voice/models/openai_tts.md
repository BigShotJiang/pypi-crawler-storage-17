# `OpenAI TTS`

::: cai.sdk.agents.voice.models.openai_tts
