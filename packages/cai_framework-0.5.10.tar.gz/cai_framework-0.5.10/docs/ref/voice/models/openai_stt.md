# `OpenAI STT`

::: cai.sdk.agents.voice.models.openai_stt
