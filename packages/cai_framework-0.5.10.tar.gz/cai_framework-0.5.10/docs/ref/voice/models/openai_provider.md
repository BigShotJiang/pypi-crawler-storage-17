# `OpenAIVoiceModelProvider`

::: cai.sdk.agents.voice.models.openai_model_provider
