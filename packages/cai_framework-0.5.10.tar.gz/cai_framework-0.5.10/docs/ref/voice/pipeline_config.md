# `Pipeline Config`

::: cai.sdk.agents.voice.pipeline_config
