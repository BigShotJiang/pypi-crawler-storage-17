# `Pipeline`

::: cai.sdk.agents.voice.pipeline
