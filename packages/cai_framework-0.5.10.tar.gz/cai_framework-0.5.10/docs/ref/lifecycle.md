# `Lifecycle`

::: cai.sdk.agents.lifecycle

    options:
        show_source: false
