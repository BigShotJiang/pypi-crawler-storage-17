"""
Django Inertia Starter

A CLI tool to quickly scaffold Django + Inertia.js projects with React or Vue.
"""

__version__ = "1.0.0"
__author__ = "Django Inertia Starter Team"
__email__ = "contact@django-inertia-starter.com"
