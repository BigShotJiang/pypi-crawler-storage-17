# -*- coding: utf-8 -*-
"""
模块: core

功能: SDK root error
"""

ERROR_CODE = {}


class KaiwuError(Exception):
    """Base class for exceptions in this module."""
