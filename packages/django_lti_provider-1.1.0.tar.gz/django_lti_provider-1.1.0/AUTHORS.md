Maintainer
----------
Columbia University Center for Teaching & Learning 

Original Authors
----------------
* Susan Dreher (@sdreher)
* Nik Nyby (@nikolas)

Contributors
----------------
A list of much-appreciated contributors who have submitted patches and reported bugs:
* Nicolas Can, University of Lille, France (@ptitloup)
* Srijan Anand, Senior Backend Developer at Valiance Analytics, Noida (@srijannnd)
* AZ Vasquez (@thedpws)
* Tylor Dodge (dodget)
* Kyle Lawlor-Bagcal (wgwz)
