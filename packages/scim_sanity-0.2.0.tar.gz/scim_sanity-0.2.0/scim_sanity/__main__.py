"""Entry point for python -m scim_sanity."""

from .cli import main

if __name__ == "__main__":
    main()

