"""scim-sanity: A zero-dependency CLI tool for validating SCIM 2.0 payloads."""

__version__ = "0.2.0"

