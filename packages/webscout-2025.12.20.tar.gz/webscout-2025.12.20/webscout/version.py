__version__ = "2025.12.20"
__prog__ = "webscout"
