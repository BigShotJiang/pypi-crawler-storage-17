"""
Standalone package for Remote Terminal MCP
"""
__version__ = "1.1.0"
