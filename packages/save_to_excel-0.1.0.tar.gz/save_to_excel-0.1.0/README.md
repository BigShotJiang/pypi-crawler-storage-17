# excelutils

A simple utility to save MongoDB or list data into Excel using pandas.

## Install
pip install excelutils

## Usage

```python
from excelutils import save_to_excel

save_to_excel("Data.xlsx", collection)
