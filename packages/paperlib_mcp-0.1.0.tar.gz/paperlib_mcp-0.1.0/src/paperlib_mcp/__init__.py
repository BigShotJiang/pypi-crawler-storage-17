"""Paper Library MCP - 文献管理与检索 MCP 服务器"""

__version__ = "0.1.0"
