"""
datavitals.cleaning

Provides standardized data cleaning utilities
for reusable data engineering pipelines.

Author: Kamaleshkumar.K
"""

from typing import Optional, Dict, Any
import pandas as pd


class DataCleaningError(Exception):
    """Custom exception for data cleaning errors."""
    pass


def clean_dataframe(
    df: pd.DataFrame,
    *,
    drop_nulls: bool = True,
    drop_duplicates: bool = True,
    trim_strings: bool = True,
    convert_numeric: bool = True,
    fillna_map: Optional[Dict[str, Any]] = None
) -> pd.DataFrame:
    """
    Clean a pandas DataFrame using a standard, reusable strategy.

    Parameters
    ----------
    df : pd.DataFrame
        Input raw dataframe.
    drop_nulls : bool, default True
        Drop rows containing null values.
    drop_duplicates : bool, default True
        Remove duplicate rows.
    trim_strings : bool, default True
        Strip whitespace from string columns.
    convert_numeric : bool, default True
        Attempt safe numeric type conversion.
    fillna_map : dict, optional
        Column-wise fillna mapping (overrides drop_nulls for those columns).

    Returns
    -------
    pd.DataFrame
        Cleaned dataframe.

    Raises
    ------
    DataCleaningError
        If input is invalid or cleaning fails.
    """

    # -------------------------
    # Validation
    # -------------------------
    if not isinstance(df, pd.DataFrame):
        raise DataCleaningError("Input must be a pandas DataFrame")

    if df.empty:
        # Return empty DataFrame safely
        return df.copy()

    cleaned_df = df.copy()

    # -------------------------
    # Trim string columns
    # -------------------------
    if trim_strings:
        for col in cleaned_df.select_dtypes(include=["object"]).columns:
            cleaned_df[col] = cleaned_df[col].astype(str).str.strip()

    # -------------------------
    # Fill NA using mapping (if provided)
    # -------------------------
    if fillna_map:
        for col, value in fillna_map.items():
            if col in cleaned_df.columns:
                cleaned_df[col] = cleaned_df[col].fillna(value)

    # -------------------------
    # Convert numeric columns safely
    # -------------------------
    if convert_numeric:
        for col in cleaned_df.columns:
            # Try numeric conversion only if column looks numeric
            cleaned_df[col] = pd.to_numeric(
                cleaned_df[col],
                errors="ignore"
            )

    # -------------------------
    # Drop null rows
    # -------------------------
    if drop_nulls:
        cleaned_df = cleaned_df.dropna(how="any")

    # -------------------------
    # Drop duplicate rows
    # -------------------------
    if drop_duplicates:
        cleaned_df = cleaned_df.drop_duplicates()

    # -------------------------
    # Final sanity check
    # -------------------------
    if cleaned_df.empty:
        raise DataCleaningError(
            "Data cleaning resulted in an empty DataFrame. "
            "Check input data or cleaning rules."
        )

    cleaned_df.reset_index(drop=True, inplace=True)
    return cleaned_df
