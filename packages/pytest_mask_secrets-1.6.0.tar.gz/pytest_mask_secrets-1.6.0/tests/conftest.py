# Enable pytest's pytester fixture; plugin is loaded via entry-point
pytest_plugins = [
    "pytester",
]

