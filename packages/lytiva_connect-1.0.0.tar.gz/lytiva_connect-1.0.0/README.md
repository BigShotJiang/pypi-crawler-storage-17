# Lytiva Connect Library

A standalone Python library for interacting with Lytiva smart devices via MQTT. This library handles the protocol logic for Lytiva lights, including dimmers, CCT (Color Temperature), and RGB devices.

## Installation

```bash
pip install lytiva-connect
```

## How to use with MQTT

Lytiva devices communicate via JSON payloads over MQTT. This library helps you generate those payloads and parse the status messages returned by devices.

### 1. Basic Light Control (Dimmer)

To turn on a light and set its brightness:

```python
import json
from lytiva import LytivaDevice

# Initialize device at address 10
device = LytivaDevice(address=10, device_type="dimmer")

# Generate the ON payload with 75% brightness (191 out of 255)
payload_dict = device.get_turn_on_payload(brightness=191)
payload_json = json.dumps(payload_dict)

# Publish payload_json to your MQTT command topic
# Example topic: LYT/homeassistant/10/command
print(f"Publish to MQTT: {payload_json}")
# Output: {"version": "v1.0", "address": "10", "state": "ON", "type": "dimmer", "dimming": 74}
```

### 2. CCT (Color Temperature) Control

```python
device = LytivaDevice(address=20, device_type="cct")

# Set brightness to 100% and temperature to 4000K
payload = device.get_turn_on_payload(brightness=255, kelvin=4000)
# Output: {"version": "v1.0", "address": "20", "state": "ON", "type": "cct", "dimming": 100, "kelvin": 4000}
```

### 3. RGB Color Control

```python
device = LytivaDevice(address=30, device_type="rgb")

# Set color to Red (255, 0, 0)
payload = device.get_turn_on_payload(rgb=(255, 0, 0))
# Output: {"version": "v1.0", "address": "30", "state": "ON", "type": "rgb", "r": 255, "red": 255, ...}
```

### 4. Decoding Status Messages
When a device sends its status back to MQTT, you can decode it easily:

```python
# Received from MQTT topic: LYT/homeassistant/10/status
raw_mqtt_message = '{"address": 10, "state": "ON", "dimming": 50}'

status = device.decode_status(raw_mqtt_message)
print(status)
# Returns: {'is_on': True, 'brightness': 128}
```

## Features
- Scalable payload generation for all Lytiva device types.
- Robust decoding of MQTT status messages.
- Helper functions for Mireds/Kelvin conversion.