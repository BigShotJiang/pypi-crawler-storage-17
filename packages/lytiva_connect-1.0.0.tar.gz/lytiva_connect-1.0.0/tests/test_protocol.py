"""Tests for Lytiva protocol library."""
import json
import pytest
from lytiva import LytivaDevice, mireds_to_kelvin, kelvin_to_mireds

def test_device_on_payload_dimmer():
    """Test dimmer ON payload."""
    device = LytivaDevice(address=10, device_type="dimmer")
    payload = device.get_turn_on_payload(brightness=128)
    assert payload["state"] == "ON"
    assert payload["dimming"] == 50
    assert payload["address"] == "10"

def test_device_on_payload_cct():
    """Test CCT ON payload."""
    device = LytivaDevice(address=20, device_type="cct")
    payload = device.get_turn_on_payload(brightness=255, kelvin=3000)
    assert payload["state"] == "ON"
    assert payload["dimming"] == 100
    assert payload["kelvin"] == 3000

def test_device_on_payload_rgb():
    """Test RGB ON payload."""
    device = LytivaDevice(address=30, device_type="rgb")
    payload = device.get_turn_on_payload(rgb=(255, 0, 0))
    assert payload["state"] == "ON"
    assert payload["r"] == 255
    assert payload["red"] == 255

def test_device_off_payload():
    """Test OFF payload."""
    device = LytivaDevice(address=10, device_type="dimmer")
    payload = device.get_turn_off_payload()
    assert payload["state"] == "OFF"
    assert payload["dimming"] == 0

def test_decode_status_dimmer():
    """Test decoding dimmer status."""
    device = LytivaDevice(address=10, device_type="dimmer")
    status = device.decode_status('{"address": 10, "state": "ON", "dimming": 50}')
    assert status["is_on"] is True
    assert status["brightness"] == 128

def test_decode_status_cct():
    """Test decoding CCT status."""
    device = LytivaDevice(address=20, device_type="cct")
    # Test flat payload
    status = device.decode_status('{"address": 20, "state": "ON", "dimming": 100, "kelvin": 4000}')
    assert status["brightness"] == 255
    assert status["kelvin"] == 4000
    
    # Test nested payload
    status = device.decode_status('{"address": 20, "cct": {"dimming": 80, "kelvin": 2700}}')
    assert status["brightness"] == 204
    assert status["kelvin"] == 2700

def test_decode_status_rgb():
    """Test decoding RGB status."""
    device = LytivaDevice(address=30, device_type="rgb")
    status = device.decode_status('{"address": 30, "state": "ON", "red": 255, "green": 0, "blue": 0}')
    assert status["rgb_color"] == (255, 0, 0)
    assert status["is_on"] is True

def test_conversion_helpers():
    """Test mireds/kelvin conversions."""
    assert mireds_to_kelvin(370) == 2703
    assert kelvin_to_mireds(2700) == 370
    assert mireds_to_kelvin(None) == 2700
    assert kelvin_to_mireds(None) == 370
