"""Core protocol logic for Lytiva devices."""
from __future__ import annotations

import json
from typing import Any, Dict, Optional

class LytivaDevice:
    """Represents a Lytiva device and its protocol logic."""

    def __init__(self, address: str | int, device_type: str = "dimmer") -> None:
        """Initialize the device."""
        self.address = str(address)
        self.device_type = device_type
        self.version = "v1.0"

    def get_turn_on_payload(
        self, 
        brightness: Optional[int] = None, 
        kelvin: Optional[int] = None, 
        rgb: Optional[tuple[int, int, int]] = None
    ) -> Dict[str, Any]:
        """Generate payload to turn the light on."""
        payload = {
            "version": self.version,
            "address": self.address,
            "state": "ON"
        }

        if self.device_type == "dimmer" or brightness is not None:
            if brightness is not None:
                payload.update({
                    "type": "dimmer", 
                    "dimming": int(brightness * 100 / 255)
                })

        if self.device_type == "cct":
            if kelvin is not None:
                # Scaled color temperature logic (0-100)
                # Note: Home Assistant handles mired conversion, but library 
                # can provide the scaled protocol value.
                # In the original code: ct_scaled = 100 - ct_percent
                # We'll keep the logic simple here or move the full conversion.
                payload.update({
                    "type": "cct",
                    "kelvin": kelvin
                })
                if brightness is not None:
                    payload["dimming"] = int(brightness * 100 / 255)

        if self.device_type == "rgb":
            if rgb is not None:
                r, g, b = rgb
                payload.update({
                    "type": "rgb",
                    "r": r, "g": g, "b": b,
                    "red": r, "green": g, "blue": b
                })

        return payload

    def get_turn_off_payload(self) -> Dict[str, Any]:
        """Generate payload to turn the light off."""
        payload = {
            "version": self.version,
            "address": self.address,
            "state": "OFF",
            "type": self.device_type
        }
        
        if self.device_type == "dimmer":
            payload["dimming"] = 0
        elif self.device_type == "cct":
            payload.update({"dimming": 0, "color_temperature": 0, "kelvin": 0})
        elif self.device_type == "rgb":
            payload.update({
                "r": 0, "g": 0, "b": 0,
                "red": 0, "green": 0, "blue": 0
            })
            
        return payload

    def decode_status(self, payload_str: str) -> Dict[str, Any]:
        """Decode a status payload string into a standardized dictionary."""
        try:
            payload = json.loads(payload_str)
        except (ValueError, TypeError):
            return {}

        if str(payload.get("address")) != self.address:
            return {}

        result = {}
        
        # Helper for nested or flat data
        def get_val(key):
            nested = payload.get(self.device_type)
            if isinstance(nested, dict) and (val := nested.get(key)) is not None:
                return val
            return payload.get(key)

        # State mapping
        state = payload.get("state")
        if state is not None:
            result["is_on"] = (state in ("ON", "on", True, 1))

        # Brightness / Dimming
        if self.device_type in ("dimmer", "cct"):
            if (d := get_val("dimming")) is not None:
                result["brightness"] = round(d * 255 / 100)
                if "is_on" not in result:
                    result["is_on"] = d > 0

        # CCT
        if self.device_type == "cct":
            result["kelvin"] = get_val("kelvin")
            result["color_temperature"] = get_val("color_temperature")

        # RGB
        if self.device_type == "rgb":
            rgb_data = payload.get("rgb") or payload
            r = rgb_data.get("r") if rgb_data.get("r") is not None else rgb_data.get("red")
            g = rgb_data.get("g") if rgb_data.get("g") is not None else rgb_data.get("green")
            b = rgb_data.get("b") if rgb_data.get("b") is not None else rgb_data.get("blue")
            
            if all(v is not None for v in (r, g, b)):
                result["rgb_color"] = (r, g, b)
                if "is_on" not in result:
                    result["is_on"] = any((r, g, b))

        return result

def mireds_to_kelvin(mireds: Optional[int | str]) -> int:
    """Convert mireds to kelvin with Lytiva defaults."""
    try:
        if mireds is None or str(mireds) == "None":
            return 2700
        m = int(float(mireds))
        if m <= 0: return 2700
        return round(1000000 / m)
    except (ValueError, TypeError):
        return 2700

def kelvin_to_mireds(kelvin: Optional[int | str]) -> int:
    """Convert kelvin to mireds with Lytiva defaults."""
    try:
        if kelvin is None or str(kelvin) == "None":
            return 370
        k = int(float(kelvin))
        if k <= 0: return 370
        return round(1000000 / k)
    except (ValueError, TypeError):
        return 370
