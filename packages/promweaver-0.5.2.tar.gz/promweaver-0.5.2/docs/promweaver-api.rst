Promweaver API Documentation
============================

Submodules
----------

promweaver.bc\_provider module
------------------------------

.. automodule:: promweaver.bc_provider
    :members:
    :show-inheritance:

promweaver.compute\_bc module
-----------------------------

.. automodule:: promweaver.compute_bc
    :members:
    :show-inheritance:

promweaver.cone\_prom\_bc module
--------------------------------

.. automodule:: promweaver.cone_prom_bc
    :members:
    :show-inheritance:

promweaver.prom\_compatible\_bc module
--------------------------------

.. automodule:: promweaver.prom_compatible_bc
    :members:
    :show-inheritance:

promweaver.iso\_prom module
---------------------------

.. automodule:: promweaver.iso_prom
    :members:
    :show-inheritance:

promweaver.stratified\_prom module
----------------------------------

.. automodule:: promweaver.stratified_prom
    :members:
    :show-inheritance:

promweaver.j\_prom\_bc module
-----------------------------

.. automodule:: promweaver.j_prom_bc
    :members:
    :show-inheritance:

promweaver.limb\_darkening module
---------------------------------

.. automodule:: promweaver.limb_darkening
    :members:
    :show-inheritance:

promweaver.pctr\_prom module
----------------------------

.. automodule:: promweaver.pctr_prom
    :members:
    :show-inheritance:

promweaver.utils module
-----------------------

.. automodule:: promweaver.utils
    :members:
    :show-inheritance:
