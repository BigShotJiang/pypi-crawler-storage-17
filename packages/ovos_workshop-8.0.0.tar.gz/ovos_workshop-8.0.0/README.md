# OVOS Workshop
OVOS Workshop contains skill base classes and supporting tools to build skills
and applications for OpenVoiceOS systems.
