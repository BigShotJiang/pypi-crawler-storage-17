from ovos_workshop.decorators.layers import IntentLayers
from ovos_utils.log import log_deprecation
log_deprecation("Import from `ovos_workshop.decorators.layers`", "0.1.0")
import warnings

warnings.warn(
    "Import from `ovos_workshop.decorators.layers`",
    DeprecationWarning,
    stacklevel=2,
)
