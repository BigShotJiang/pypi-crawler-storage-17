# haram 🐍

The forbidden counterpart to Python’s Zen.

## Usage

```python
import haram
