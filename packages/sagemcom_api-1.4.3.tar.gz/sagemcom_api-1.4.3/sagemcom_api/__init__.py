"""Package to communicate with Sagemcom F@st internal APIs."""
