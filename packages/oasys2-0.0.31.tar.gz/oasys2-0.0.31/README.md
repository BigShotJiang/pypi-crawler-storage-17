# OASYS2
New release of OASYS, fully in python

- The package oasys2.canvas contains customization to elements belonging to biolab/orange-canvas-core.
- The package oasys2.widget contains customization to elements belonging to biolab/orange-widget-base.
- the package oasys2.widgets contains widgets to be displayed at the 2 top folders of the OASYS toolbox.

**The software is currently in its ALPHA release and undergoing testing by a selected group of collaborators and users.**

Installation instructions can be found [here](https://github.com/oasys-kit/OASYS2/wiki)
