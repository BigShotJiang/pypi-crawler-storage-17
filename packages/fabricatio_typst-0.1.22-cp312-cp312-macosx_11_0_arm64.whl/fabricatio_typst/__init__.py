"""This package provides the core functionality for the fabricatio-typst module.

It includes capabilities for processing and generating typst documents, integrating with other components of the fabricatio system.
"""
