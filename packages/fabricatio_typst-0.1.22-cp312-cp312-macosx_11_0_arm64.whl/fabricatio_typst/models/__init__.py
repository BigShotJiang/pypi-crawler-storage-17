"""This module contains model definitions for the fabricatio-typst package.

It includes classes and data structures that represent typst documents, formatting rules, and related entities within the system.
"""
