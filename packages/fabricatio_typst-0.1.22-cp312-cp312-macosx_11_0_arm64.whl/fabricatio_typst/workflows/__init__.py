"""A module containing some builtin workflows."""

from fabricatio_core.utils import cfg

cfg(feats=["workflows"])
