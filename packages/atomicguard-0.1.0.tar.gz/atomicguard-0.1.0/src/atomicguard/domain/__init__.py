"""
Domain layer for the Dual-State Framework.

Contains core business logic with no external dependencies.
"""

from atomicguard.domain.exceptions import RmaxExhausted
from atomicguard.domain.interfaces import (
    ArtifactDAGInterface,
    GeneratorInterface,
    GuardInterface,
)
from atomicguard.domain.models import (
    AmbientEnvironment,
    Artifact,
    ArtifactStatus,
    Context,
    ContextSnapshot,
    FeedbackEntry,
    GuardResult,
    WorkflowResult,
    WorkflowState,
)
from atomicguard.domain.prompts import (
    PromptTemplate,
    StepDefinition,
    TaskDefinition,
)

__all__ = [
    # Models
    "Artifact",
    "ArtifactStatus",
    "ContextSnapshot",
    "FeedbackEntry",
    "Context",
    "AmbientEnvironment",
    "GuardResult",
    "WorkflowState",
    "WorkflowResult",
    # Prompts and Tasks (structures only, no content)
    "PromptTemplate",
    "StepDefinition",
    "TaskDefinition",
    # Interfaces
    "GeneratorInterface",
    "GuardInterface",
    "ArtifactDAGInterface",
    # Exceptions
    "RmaxExhausted",
]
