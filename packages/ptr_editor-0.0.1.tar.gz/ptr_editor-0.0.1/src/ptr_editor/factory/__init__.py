"""Factory functions for creating PTR elements."""


from ptr_editor.factory.blocks import ObsBlockFactory

__all__ = [
    "ObsBlockFactory",
  
]
