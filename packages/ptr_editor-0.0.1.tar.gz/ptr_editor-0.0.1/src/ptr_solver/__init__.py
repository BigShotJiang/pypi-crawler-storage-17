"""PTR Solver module."""

from ptr_solver.solvable_mixin import PtrSolvableMixin

__all__ = ["PtrSolvableMixin"]
