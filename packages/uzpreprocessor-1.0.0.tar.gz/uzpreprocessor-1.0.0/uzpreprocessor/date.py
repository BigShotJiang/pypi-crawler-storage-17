"""
Date to words conversion module.

Converts dates to Uzbek (Latin) words with support for multiple input formats.
"""

import re
from datetime import date, datetime
from typing import Union, TYPE_CHECKING

if TYPE_CHECKING:
    from uzpreprocessor.number import UzNumberToWords


class UzDateToWords:
    """
    Uzbek (Latin) date-to-words converter.
    
    Supports multiple date formats:
    - ISO: 2025-09-18, 2025-09-18T14:35:08
    - European: 18.09.2025, 18/09/2025
    - US: 09/18/2025, 09-18-2025
    - Text: "18 September 2025", "September 18, 2025"
    - Legal: "2025-yil 18-sentabr"
    
    Examples:
        >>> from uzpreprocessor import UzNumberToWords
        >>> n = UzNumberToWords()
        >>> converter = UzDateToWords(n)
        >>> converter.date("2025-09-18")
        'ikki ming yigirma beshinchi yil o'n sakkizinchi sentabr'
    """
    
    MONTHS = (
        "yanvar", "fevral", "mart", "aprel", "may", "iyun",
        "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"
    )
    
    # Optimized: Single dict lookup for all month names
    MONTH_MAP = {
        # Uzbek
        "yanvar": 1, "fevral": 2, "mart": 3, "aprel": 4, "may": 5,
        "iyun": 6, "iyul": 7, "avgust": 8, "sentabr": 9,
        "oktabr": 10, "noyabr": 11, "dekabr": 12,
        
        # English full
        "january": 1, "february": 2, "march": 3, "april": 4,
        "may": 5, "june": 6, "july": 7, "august": 8,
        "september": 9, "october": 10, "november": 11, "december": 12,
        
        # English short
        "jan": 1, "feb": 2, "mar": 3, "apr": 4,
        "jun": 6, "jul": 7, "aug": 8,
        "sep": 9, "sept": 9,
        "oct": 10, "nov": 11, "dec": 12,
    }
    
    DATE_PATTERNS = [
        "%Y-%m-%d",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%d.%m.%Y",
        "%d-%m-%Y",
        "%d/%m/%Y",
        "%m/%d/%Y",
        "%m-%d-%Y",
        "%Y/%m/%d",
        "%Y.%m.%d",
    ]
    
    # Optimized: Compile regex patterns once
    _PATTERN_LEGAL = re.compile(
        r"(?P<year>\d{4})\s*[- ]?\s*yil\s*[- ]?\s*(?P<day>\d{1,2})\s*[- ]?\s*(?P<month>[a-z]+)",
        re.IGNORECASE
    )
    _PATTERN_DAY_MONTH_YEAR = re.compile(
        r"(?P<day>\d{1,2})\s+(?P<month>[a-z]+)\s+(?P<year>\d{4})",
        re.IGNORECASE
    )
    _PATTERN_MONTH_DAY_YEAR = re.compile(
        r"(?P<month>[a-z]+)\s+(?P<day>\d{1,2})\s+(?P<year>\d{4})",
        re.IGNORECASE
    )
    
    def __init__(self, number_converter: "UzNumberToWords"):
        """
        Initialize date converter.
        
        Args:
            number_converter: Instance of UzNumberToWords for number conversion
        """
        self.n = number_converter
    
    def _parse_date(self, value: Union[str, date, datetime]) -> date:
        """
        Parse date from various input formats.
        
        Args:
            value: Date as string, date, or datetime object
            
        Returns:
            Parsed date object
            
        Raises:
            ValueError: If date format is unsupported
        """
        # Direct types
        if isinstance(value, date) and not isinstance(value, datetime):
            return value
        
        if isinstance(value, datetime):
            return value.date()
        
        if not isinstance(value, str):
            raise ValueError(f"Unsupported date type: {type(value)}")
        
        raw = value
        value_lower = value.strip().lower()
        
        # Normalize commas (for: September 18, 2025)
        value_lower = value_lower.replace(",", "")
        
        # 1) Legal format: 2025-yil 18-sentabr
        m = self._PATTERN_LEGAL.match(value_lower)
        if m:
            year = int(m.group("year"))
            day = int(m.group("day"))
            month_name = m.group("month").lower()
            
            if month_name in self.MONTH_MAP:
                return date(year, self.MONTH_MAP[month_name], day)
        
        # 2) Text format: 18 september 2025
        m = self._PATTERN_DAY_MONTH_YEAR.match(value_lower)
        if m:
            day = int(m.group("day"))
            year = int(m.group("year"))
            month_name = m.group("month").lower()
            
            if month_name in self.MONTH_MAP:
                return date(year, self.MONTH_MAP[month_name], day)
        
        # 2b) Text format: september 18 2025
        m = self._PATTERN_MONTH_DAY_YEAR.match(value_lower)
        if m:
            day = int(m.group("day"))
            year = int(m.group("year"))
            month_name = m.group("month").lower()
            
            if month_name in self.MONTH_MAP:
                return date(year, self.MONTH_MAP[month_name], day)
        
        # 3) ISO format (try first as it's most common)
        try:
            return datetime.fromisoformat(raw).date()
        except (ValueError, AttributeError):
            pass
        
        # 4) Classic numeric formats
        for pattern in self.DATE_PATTERNS:
            try:
                return datetime.strptime(value_lower, pattern).date()
            except ValueError:
                continue
        
        raise ValueError(f"Unsupported date format: {raw}")
    
    def date(self, value: Union[str, date, datetime]) -> str:
        """
        Convert date to words.
        
        Args:
            value: Date to convert (string, date, or datetime)
            
        Returns:
            Words representation of the date
            
        Example:
            >>> converter.date("2025-09-18")
            'ikki ming yigirma beshinchi yil o'n sakkizinchi sentabr'
        """
        d = self._parse_date(value)
        
        year = f"{self.n.ordinal(d.year)} yil"
        day = self.n.ordinal(d.day)
        month = self.MONTHS[d.month - 1]
        
        return f"{year} {day} {month}"

