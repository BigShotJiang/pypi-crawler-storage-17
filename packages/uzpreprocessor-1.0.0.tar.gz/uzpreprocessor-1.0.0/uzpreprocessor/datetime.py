"""
Datetime to words conversion module.

Combines date and time conversion into a single datetime converter.
"""

from datetime import datetime
from typing import Union, TYPE_CHECKING

if TYPE_CHECKING:
    from uzpreprocessor.date import UzDateToWords
    from uzpreprocessor.time import UzTimeToWords


class UzDateAndTimeToWords:
    """
    Uzbek (Latin) datetime-to-words converter.
    
    Combines date and time conversion into a single converter.
    
    Examples:
        >>> from uzpreprocessor import UzNumberToWords, UzDateToWords, UzTimeToWords
        >>> n = UzNumberToWords()
        >>> d = UzDateToWords(n)
        >>> t = UzTimeToWords(n)
        >>> converter = UzDateAndTimeToWords(d, t)
        >>> converter.datetime("2025-09-18T14:35:08")
        'ikki ming yigirma beshinchi yil o'n sakkizinchi sentabr o'n to'rt soat o'ttiz besh daqiqa sakkiz soniya'
    """
    
    def __init__(
        self,
        date_converter: "UzDateToWords",
        time_converter: "UzTimeToWords",
    ):
        """
        Initialize datetime converter.
        
        Args:
            date_converter: Instance of UzDateToWords
            time_converter: Instance of UzTimeToWords
        """
        self.date_converter = date_converter
        self.time_converter = time_converter
    
    def datetime(self, value: Union[str, datetime]) -> str:
        """
        Convert datetime to words.
        
        Args:
            value: Datetime to convert (string or datetime object)
            
        Returns:
            Words representation combining date and time
            
        Example:
            >>> converter.datetime("2025-09-18T14:35:08")
            'ikki ming yigirma beshinchi yil o'n sakkizinchi sentabr o'n to'rt soat o'ttiz besh daqiqa sakkiz soniya'
        """
        if isinstance(value, str):
            try:
                dt = datetime.fromisoformat(value)
            except ValueError:
                # Try parsing with strptime as fallback
                # This handles formats that fromisoformat might not support
                dt = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S")
        else:
            dt = value
        
        date_part = self.date_converter.date(dt)
        time_part = self.time_converter.time(dt)
        
        return f"{date_part} {time_part}"

