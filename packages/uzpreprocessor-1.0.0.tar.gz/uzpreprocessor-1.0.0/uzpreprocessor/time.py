"""
Time to words conversion module.

Converts time to Uzbek (Latin) words with support for multiple input formats
and spoken/formal modes.
"""

import re
from datetime import datetime, time
from typing import Union, TYPE_CHECKING

if TYPE_CHECKING:
    from uzpreprocessor.number import UzNumberToWords


class UzTimeToWords:
    """
    Uzbek (Latin) time-to-words converter.
    
    Rules:
    - AM/PM present → spoken Uzbek style (ertalab, tushlikdan keyin, etc.)
    - otherwise → formal numeric style
    
    Supports multiple formats:
    - ISO: 14:35, 14:35:08
    - With separators: 14.35, 14-35, 14 35
    - AM/PM: 2 PM, 14:35 PM
    - With timezone: 14:35:08Z, 14:35:08+05:00
    
    Examples:
        >>> from uzpreprocessor import UzNumberToWords
        >>> n = UzNumberToWords()
        >>> converter = UzTimeToWords(n)
        >>> converter.time("14:35:08")
        'o'n to'rt soat o'ttiz besh daqiqa sakkiz soniya'
        >>> converter.time("2 PM")
        'tushlikdan keyin soat o'n to'rt'
    """
    
    TIME_PATTERNS = [
        "%H:%M",
        "%H:%M:%S",
        "%H:%M:%S.%f",
        "%H-%M",
        "%H-%M-%S",
        "%H.%M",
        "%H.%M.%S",
        "%H %M",
        "%H %M %S",
        # AM / PM
        "%I:%M %p",
        "%I:%M:%S %p",
        "%I %p",
        "%I:%M%p",
        "%I%p",
        # No separators
        "%H%M",
        "%H%M%S",
    ]
    
    # Optimized: Compile regex patterns once
    _PATTERN_WHITESPACE = re.compile(r"\s+")
    _PATTERN_AMPM = re.compile(r"\b(AM|PM)\b", re.IGNORECASE)
    _PATTERN_TIMEZONE = re.compile(r"(Z|[+-]\d{2}:?\d{2})$")
    _PATTERN_COLON = re.compile(r"\s*:\s*")
    _PATTERN_DASH = re.compile(r"\s*-\s*")
    _PATTERN_DOT = re.compile(r"\s*\.\s*")
    _PATTERN_AMPM_SPACE = re.compile(r"\s*(AM|PM)\s*", re.IGNORECASE)
    
    # Optimized: Use list of tuples for period lookup
    _SPOKEN_PERIODS = [
        ((5, 10), "ertalab"),
        ((11, 12), "tushlikdan oldin"),
        ((13, 17), "tushlikdan keyin"),
        ((18, 22), "kechqurun"),
    ]
    
    def __init__(self, number_converter: "UzNumberToWords"):
        """
        Initialize time converter.
        
        Args:
            number_converter: Instance of UzNumberToWords for number conversion
        """
        self.n = number_converter
    
    def _normalize(self, text: str) -> tuple[str, bool]:
        """
        Normalize time string for parsing.
        
        Args:
            text: Raw time string
            
        Returns:
            Tuple of (normalized_text, is_ampm)
        """
        # Strip and normalize case
        text = text.strip().upper()
        text = self._PATTERN_WHITESPACE.sub(" ", text)
        
        # Detect AM/PM early (before destroying spaces)
        is_ampm = bool(self._PATTERN_AMPM.search(text))
        
        # Remove timezone suffixes
        text = self._PATTERN_TIMEZONE.sub("", text)
        
        # Normalize separators
        text = self._PATTERN_COLON.sub(":", text)
        text = self._PATTERN_DASH.sub("-", text)
        text = self._PATTERN_DOT.sub(".", text)
        
        # Normalize AM/PM spacing
        text = self._PATTERN_AMPM_SPACE.sub(r" \1", text)
        
        # Final cleanup
        text = self._PATTERN_WHITESPACE.sub(" ", text).strip()
        
        return text, is_ampm
    
    def _parse_time(self, value: Union[str, time, datetime]) -> tuple[time, bool]:
        """
        Parse time from various input formats.
        
        Args:
            value: Time as string, time, or datetime object
            
        Returns:
            Tuple of (time_object, is_ampm)
            
        Raises:
            ValueError: If time format is unsupported
        """
        if isinstance(value, datetime):
            return value.time(), False
        
        if isinstance(value, time):
            return value, False
        
        if not isinstance(value, str):
            raise ValueError(f"Unsupported time type: {type(value)}")
        
        raw = value
        text, is_ampm = self._normalize(value)
        
        # Try ISO format first (most common)
        try:
            return time.fromisoformat(text), is_ampm
        except (ValueError, AttributeError):
            pass
        
        # Try known patterns
        for pattern in self.TIME_PATTERNS:
            try:
                return datetime.strptime(text, pattern).time(), is_ampm
            except ValueError:
                continue
        
        raise ValueError(f"Unsupported time format: {raw}")
    
    def _spoken_period(self, hour: int) -> str:
        """
        Get spoken period name for hour (ertalab, tushlikdan keyin, etc.).
        
        Args:
            hour: Hour (0-23)
            
        Returns:
            Period name in Uzbek
        """
        # Optimized: Use tuple lookup instead of if-elif chain
        for (start, end), period in self._SPOKEN_PERIODS:
            if start <= hour <= end:
                return period
        return "tun"
    
    def time(self, value: Union[str, time, datetime]) -> str:
        """
        Convert time to words.
        
        Args:
            value: Time to convert (string, time, or datetime)
            
        Returns:
            Words representation of the time
            
        Example:
            >>> converter.time("14:35:08")
            'o'n to'rt soat o'ttiz besh daqiqa sakkiz soniya'
            >>> converter.time("2 PM")
            'tushlikdan keyin soat o'n to'rt'
        """
        t, is_ampm = self._parse_time(value)
        
        # Spoken mode (when AM/PM is present)
        if is_ampm:
            period = self._spoken_period(t.hour)
            parts = [period, "soat", self.n.number(t.hour)]
            
            if t.minute:
                parts.append(self.n.number(t.minute))
                parts.append("daqiqa")
            
            if t.second:
                parts.append(self.n.number(t.second))
                parts.append("soniya")
            
            return " ".join(parts)
        
        # Formal mode (standard 24-hour format)
        parts = []
        
        if t.hour:
            parts.append(f"{self.n.number(t.hour)} soat")
        if t.minute:
            parts.append(f"{self.n.number(t.minute)} daqiqa")
        if t.second:
            parts.append(f"{self.n.number(t.second)} soniya")
        
        return "nol soat" if not parts else " ".join(parts)

