"""
Number to words conversion module.

Converts numbers, currency, and percentages to Uzbek (Latin) words.
"""

from decimal import Decimal, getcontext
from typing import Union

# Set high precision for decimal calculations
getcontext().prec = 30


class UzNumberToWords:
    """
    Uzbek (Latin) number-to-words converter.
    
    Supports:
    - integers (arbitrary size)
    - decimals up to 12 digits
    - negative numbers
    - currency: so'm / tiyin
    - percentages
    
    Examples:
        >>> converter = UzNumberToWords()
        >>> converter.number(123)
        'bir yuz yigirma uch'
        >>> converter.number(123.456)
        'bir yuz yigirma uch butun to'rt yuz ellik olti mingdan'
        >>> converter.money(12345.67)
        'o'n ikki ming uch yuz qirq besh so'm oltmish yetti tiyin'
        >>> converter.percent(12.345)
        'o'n ikki butun uch yuz qirq besh mingdan foiz'
    """
    
    # Optimized: Use tuples for immutable lookup tables
    UNITS = (
        "nol", "bir", "ikki", "uch", "to'rt",
        "besh", "olti", "yetti", "sakkiz", "to'qqiz"
    )
    
    TENS = (
        "", "o'n", "yigirma", "o'ttiz", "qirq",
        "ellik", "oltmish", "yetmish",
        "sakson", "to'qson"
    )
    
    HUNDREDS = (
        "", "bir yuz", "ikki yuz", "uch yuz", "to'rt yuz",
        "besh yuz", "olti yuz", "yetti yuz",
        "sakkiz yuz", "to'qqiz yuz"
    )
    
    ORDERS = (
        "ming",
        "million",
        "milliard",
        "trillion",
    )
    
    # Optimized: Use dict for O(1) lookup
    FRACTION_ORDERS = {
        1: "o'ndan",
        2: "yuzdan",
        3: "mingdan",
        4: "o'n mingdan",
        5: "yuz mingdan",
        6: "milliondan",
        7: "o'n milliondan",
        8: "yuz milliondan",
        9: "milliarddan",
        10: "o'n milliarddan",
        11: "yuz milliarddan",
        12: "trilliondan",
    }
    
    def ordinal(self, value: int) -> str:
        """
        Convert number to ordinal form (tartib son).
        
        Args:
            value: Integer to convert
            
        Returns:
            Ordinal form with 'inchi' suffix
            
        Example:
            >>> converter.ordinal(5)
            'beshinchi'
        """
        return f"{self.number(value)}inchi"
    
    def _triad_to_words(self, n: int) -> str:
        """
        Convert a three-digit number (0-999) to words.
        
        Args:
            n: Integer between 0 and 999
            
        Returns:
            Words representation of the triad
        """
        if n == 0:
            return ""
        
        parts = []
        
        # Hundreds
        hundreds = n // 100
        if hundreds > 0:
            parts.append(self.HUNDREDS[hundreds])
        
        # Tens and units
        remainder = n % 100
        if remainder > 0:
            tens = remainder // 10
            units = remainder % 10
            
            if tens > 0:
                parts.append(self.TENS[tens])
            if units > 0:
                parts.append(self.UNITS[units])
        
        return " ".join(parts)
    
    def _integer_to_words(self, n: int) -> str:
        """
        Convert an integer to words.
        
        Args:
            n: Integer to convert (can be arbitrarily large)
            
        Returns:
            Words representation of the integer
        """
        if n == 0:
            return "nol"
        
        # Optimized: Build triads list directly without intermediate storage
        triads = []
        num = n
        
        while num > 0:
            triads.append(num % 1000)
            num //= 1000
        
        # Optimized: Pre-allocate list size for better performance
        words = []
        num_triads = len(triads)
        
        # Process triads from highest to lowest order
        for i in range(num_triads - 1, -1, -1):
            triad = triads[i]
            if triad == 0:
                continue
            
            triad_words = self._triad_to_words(triad)
            if triad_words:
                words.append(triad_words)
            
            # Add order name (ming, million, etc.)
            if i > 0:
                words.append(self.ORDERS[i - 1])
        
        return " ".join(words)
    
    def number(self, value: Union[int, float, str, Decimal]) -> str:
        """
        Convert a number to words (supports decimals up to 12 digits).
        
        Args:
            value: Number to convert (int, float, str, or Decimal)
            
        Returns:
            Words representation of the number
            
        Example:
            >>> converter.number(123.456)
            'bir yuz yigirma uch butun to'rt yuz ellik olti mingdan'
            >>> converter.number(-42)
            'minus qirq ikki'
        """
        num = Decimal(str(value))
        
        if num == 0:
            return "nol"
        
        words = []
        
        # Handle negative numbers
        if num < 0:
            words.append("minus")
            num = abs(num)
        
        # Optimized: Use format instead of str() for better control
        s = format(num, 'f')
        
        # Split integer and fractional parts
        if '.' in s:
            int_part_str, frac_part_str = s.split('.', 1)
            # Optimized: Use rstrip to remove trailing zeros efficiently
            frac_part_str = frac_part_str.rstrip('0')[:12]
        else:
            int_part_str = s
            frac_part_str = ""
        
        int_part = int(int_part_str)
        words.append(self._integer_to_words(int_part))
        
        # Handle fractional part
        if frac_part_str:
            frac_len = len(frac_part_str)
            frac_number = int(frac_part_str)
            
            words.append("butun")
            words.append(self._integer_to_words(frac_number))
            words.append(self.FRACTION_ORDERS[frac_len])
        
        return " ".join(words)
    
    def money(self, amount: Union[int, float, str, Decimal]) -> str:
        """
        Convert currency amount to words (so'm / tiyin).
        
        Args:
            amount: Currency amount to convert
            
        Returns:
            Words representation with so'm and tiyin
            
        Example:
            >>> converter.money(12345.67)
            'o'n ikki ming uch yuz qirq besh so'm oltmish yetti tiyin'
            >>> converter.money(1000)
            'bir ming so'm'
        """
        amount = Decimal(str(amount))
        
        words = []
        
        # Handle negative amounts
        if amount < 0:
            words.append("minus")
            amount = abs(amount)
        
        s = format(amount, 'f')
        
        # Split so'm and tiyin parts
        if '.' in s:
            som_str, tiyin_str = s.split('.', 1)
            # Ensure tiyin is exactly 2 digits
            tiyin_str = (tiyin_str + "00")[:2]
        else:
            som_str = s
            tiyin_str = "00"
        
        som = int(som_str)
        tiyin = int(tiyin_str)
        
        # Convert so'm
        words.append(self._integer_to_words(som))
        words.append("so'm")
        
        # Convert tiyin if present
        if tiyin > 0:
            words.append(self._integer_to_words(tiyin))
            words.append("tiyin")
        
        return " ".join(words)
    
    def percent(self, value: Union[int, float, str, Decimal]) -> str:
        """
        Convert percentage to words.
        
        Args:
            value: Percentage value to convert
            
        Returns:
            Words representation with 'foiz' suffix
            
        Example:
            >>> converter.percent(12.345)
            'o'n ikki butun uch yuz qirq besh mingdan foiz'
        """
        return f"{self.number(value)} foiz"

