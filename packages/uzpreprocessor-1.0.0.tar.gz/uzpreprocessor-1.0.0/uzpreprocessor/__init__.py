"""
UzPreprocessor - Uzbek Text Preprocessing Library

A comprehensive library for converting numbers, dates, times, and currency
to Uzbek (Latin) words. Perfect for legal documents, invoices, and text processing.

Example:
    >>> from uzpreprocessor import UzPreprocessor
    >>> processor = UzPreprocessor()
    >>> print(processor.number(123))
    'bir yuz yigirma uch'
    >>> print(processor.money(12345.67))
    'o\'n ikki ming uch yuz qirq besh so\'m oltmish yetti tiyin'
"""

__version__ = "1.0.0"
__author__ = "Javhar Abdulatipov"
__email__ = "jakharbek@gmail.com"

from uzpreprocessor.number import UzNumberToWords
from uzpreprocessor.date import UzDateToWords
from uzpreprocessor.time import UzTimeToWords
from uzpreprocessor.datetime import UzDateAndTimeToWords

__all__ = [
    "UzPreprocessor",
    "UzNumberToWords",
    "UzDateToWords",
    "UzTimeToWords",
    "UzDateAndTimeToWords",
]


class UzPreprocessor:
    """
    Main convenience class that provides all conversion functionality.
    
    This class combines all converters into a single, easy-to-use interface.
    
    Example:
        >>> processor = UzPreprocessor()
        >>> processor.number(123)
        'bir yuz yigirma uch'
        >>> processor.date("2025-09-18")
        'ikki ming yigirma beshinchi yil o\'n sakkizinchi sentabr'
    """
    
    def __init__(self):
        """Initialize all converters."""
        self._number_converter = UzNumberToWords()
        self._date_converter = UzDateToWords(self._number_converter)
        self._time_converter = UzTimeToWords(self._number_converter)
        self._datetime_converter = UzDateAndTimeToWords(
            self._date_converter,
            self._time_converter
        )
    
    @property
    def number(self) -> UzNumberToWords:
        """Access the number converter."""
        return self._number_converter
    
    @property
    def date(self) -> UzDateToWords:
        """Access the date converter."""
        return self._date_converter
    
    @property
    def time(self) -> UzTimeToWords:
        """Access the time converter."""
        return self._time_converter
    
    @property
    def datetime(self) -> UzDateAndTimeToWords:
        """Access the datetime converter."""
        return self._datetime_converter

