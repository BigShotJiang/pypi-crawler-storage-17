#!/usr/bin/env python3
"""
Basic usage examples for UzPreprocessor library.
"""

from uzpreprocessor import UzPreprocessor

def main():
    """Run basic usage examples."""
    
    # Initialize the processor
    processor = UzPreprocessor()
    
    print("=" * 60)
    print("UzPreprocessor - Basic Usage Examples")
    print("=" * 60)
    print()
    
    # Number conversion
    print("1. NUMBER CONVERSION")
    print("-" * 60)
    print(f"123 -> {processor.number.number(123)}")
    print(f"123.456 -> {processor.number.number(123.456)}")
    print(f"-42 -> {processor.number.number(-42)}")
    print(f"5 (ordinal) -> {processor.number.ordinal(5)}")
    print()
    
    # Currency conversion
    print("2. CURRENCY CONVERSION")
    print("-" * 60)
    print(f"1000 -> {processor.number.money(1000)}")
    print(f"12345.67 -> {processor.number.money(12345.67)}")
    print()
    
    # Percentage conversion
    print("3. PERCENTAGE CONVERSION")
    print("-" * 60)
    print(f"12.345 -> {processor.number.percent(12.345)}")
    print()
    
    # Date conversion
    print("4. DATE CONVERSION")
    print("-" * 60)
    print(f"2025-09-18 -> {processor.date.date('2025-09-18')}")
    print(f"18.09.2025 -> {processor.date.date('18.09.2025')}")
    print(f"18 September 2025 -> {processor.date.date('18 September 2025')}")
    print()
    
    # Time conversion
    print("5. TIME CONVERSION")
    print("-" * 60)
    print(f"14:35:08 -> {processor.time.time('14:35:08')}")
    print(f"2 PM -> {processor.time.time('2 PM')}")
    print()
    
    # DateTime conversion
    print("6. DATETIME CONVERSION")
    print("-" * 60)
    print(f"2025-09-18T14:35:08 -> {processor.datetime.datetime('2025-09-18T14:35:08')}")
    print()

if __name__ == "__main__":
    main()

