
def upload_attachment():
    pass

def delete_attachment():
    pass