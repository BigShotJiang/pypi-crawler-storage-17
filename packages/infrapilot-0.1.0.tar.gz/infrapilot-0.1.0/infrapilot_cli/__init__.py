"""InfraPilot CLI package."""

from __future__ import annotations

from infrapilot_cli.main import main

__all__ = ["main"]
