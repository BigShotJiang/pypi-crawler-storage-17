from infrapilot_cli.utils.names import generate_fun_name

__all__ = ["generate_fun_name"]
