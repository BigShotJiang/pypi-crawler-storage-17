"""Detector geometry module."""

from .manager import GeoManager
