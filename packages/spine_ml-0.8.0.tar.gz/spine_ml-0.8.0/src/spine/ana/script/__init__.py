"""Module with all analysis scripts."""

from .save import *
