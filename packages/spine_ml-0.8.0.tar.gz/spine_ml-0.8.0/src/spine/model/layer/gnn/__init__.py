"""Module with all methods to build Graph Neural Networks."""

from .factories import *
