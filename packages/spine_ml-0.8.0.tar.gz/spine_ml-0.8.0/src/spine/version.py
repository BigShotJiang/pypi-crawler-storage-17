"""Module which stores the current software version."""

__version__ = "0.8.0"
