"""Trigger information processing module."""

from .trigger import *
