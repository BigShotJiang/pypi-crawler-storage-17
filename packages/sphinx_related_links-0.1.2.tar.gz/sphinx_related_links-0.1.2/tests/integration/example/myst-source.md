---
relatedlinks: https://ubuntu.com/
discourse: 57290
---

# MyST Source

The sidebar should contain links to the above Discourse topic
and the Ubuntu homepage.

## Heading

Furo won't show the right sidebar without an internal heading.
