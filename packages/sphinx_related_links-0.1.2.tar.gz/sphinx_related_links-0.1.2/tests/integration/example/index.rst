:relatedlinks: https://ubuntu.com/
:discourse: 57290


Test doc
========

This is a test document for the related-links extension.

The extension provides functionality for adding related links to pages
via metadata configuration.


Heading
-------

Furo won't show the right sidebar without an internal heading.

.. toctree::
    :hidden:

    myst-source
