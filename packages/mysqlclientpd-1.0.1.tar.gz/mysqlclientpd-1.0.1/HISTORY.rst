======================
 What's new in 1.0.0
======================

Release: 2025-12-16

* Branched from parent project at Version 2.2.7
* Changed license format and added path to MariaDB Connector C 64 Bit for windows build
