__author__ = "Jan Schmid <mysticentity0@gmail.com>"
__version__ = "1.0.1"
version_info = (1, 0, 1, "dev", 0)
