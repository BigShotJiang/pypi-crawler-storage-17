
.. image:: https://badge.fury.io/py/galaxy-naivgation.svg
   :target: https://pypi.org/project/galaxy-naivgation/



Overview
--------

The Galaxy_ client DOM navigation framework.

Navigation data that feeds tours generation, Jest testing, and Selenium testing.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
