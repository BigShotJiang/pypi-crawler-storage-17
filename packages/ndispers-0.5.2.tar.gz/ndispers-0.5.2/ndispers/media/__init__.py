"""
ndispers.media contains the collections of specific crystals and glasses.
"""
from . import crystals
from . import glasses

