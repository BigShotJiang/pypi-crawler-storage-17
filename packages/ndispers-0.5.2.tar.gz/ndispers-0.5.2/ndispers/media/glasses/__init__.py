"""
ndispers.media.glass/__init__.py
glasses and isotropic crystals
"""

from ._fusedsilica import FusedSilica
from ._caf2 import CaF2