"""
ndispers.groups contains the crystal groups inherited from base class `Medium`.
"""

from ._uniax_neg_3m import Uniax_neg_3m
from ._uniax_neg_32 import Uniax_neg_32