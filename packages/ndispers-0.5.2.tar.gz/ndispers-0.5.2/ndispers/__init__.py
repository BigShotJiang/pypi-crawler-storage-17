"""
init file of ndispers package
"""
__version__ = "0.5.2"

from . import _baseclass, media

