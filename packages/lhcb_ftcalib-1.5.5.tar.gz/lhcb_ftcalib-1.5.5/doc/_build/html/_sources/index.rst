lhcb_ftcalib Documentation
==========================

.. toctree::
   :maxdepth: 2
   :titlesonly:
   :caption: Contents:

   Tutorial
   CommandLineInterface
   modules

   EPMComparison
   Troubleshooting

.. toctree::
   :maxdepth: 2
   :titlesonly:
   :caption: Theory:

   likelihood
   calibrationFuncTheory
   combination

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
