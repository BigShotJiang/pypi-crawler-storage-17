"""
Admin URLs for Universal Payment System v2.0.

Internal dashboard and management interfaces with DRF nested routing.
All URLs require staff/superuser access.
"""

app_name = 'cfg_maintenance_admin'

urlpatterns = [
    
]
