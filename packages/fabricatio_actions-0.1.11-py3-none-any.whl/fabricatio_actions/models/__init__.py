"""Models defined in fabricatio-actions."""
