# Pyarmor 9.2.0 (basic), 009672, 2025-12-20T04:00:49.626539
from .pyarmor_runtime import __pyarmor__
