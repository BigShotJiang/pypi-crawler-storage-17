import rp.libs.tetris.__main__
