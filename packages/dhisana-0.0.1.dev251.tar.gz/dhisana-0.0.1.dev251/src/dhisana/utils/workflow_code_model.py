from pydantic import BaseModel


class WorkflowPythonCode(BaseModel):
    workflow_python_code: str