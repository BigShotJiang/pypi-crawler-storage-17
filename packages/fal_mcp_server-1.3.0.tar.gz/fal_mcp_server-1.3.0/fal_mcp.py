#!/usr/bin/env python3
from fal_mcp_server.server import main

if __name__ == "__main__":
    main()
