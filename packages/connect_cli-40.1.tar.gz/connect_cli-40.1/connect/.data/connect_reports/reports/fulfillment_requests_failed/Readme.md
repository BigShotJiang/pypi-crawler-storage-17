# Failed Requests Report

This report provides a view of all failed requests received for a given period of time together with the reason that was provided when failing it.

Report accepts to limit the output by:
* Type of request
* List of products
* Type of transaction (preview, test or production)