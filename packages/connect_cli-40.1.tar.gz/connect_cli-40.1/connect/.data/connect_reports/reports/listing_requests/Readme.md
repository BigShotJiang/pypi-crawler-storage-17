# Listing Requests

This report provides a view of all listing requests available in your account

Report accepts to limit the output by:
* Creation date
* Product
* Marketplace
* Request Status