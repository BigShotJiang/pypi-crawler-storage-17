# Requests Report
This report provides a view of all transactions received for a given period of time

Report accepts to limit the output by:
* List of products
* Type of request
* Status of the request
* List of marketplaces
* List of hubs