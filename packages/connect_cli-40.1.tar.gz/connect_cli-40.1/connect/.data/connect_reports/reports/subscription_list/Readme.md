# Subscription List Report

This report provides a view of all subscriptions available at your account.

Report accepts to limit the output by:

* Subscription creation date range
* List of products
* List of marketplaces
* Billing period
* Subscription status