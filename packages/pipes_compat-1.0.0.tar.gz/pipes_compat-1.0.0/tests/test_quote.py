"""Tests for pipes.quote() function."""

import pipes


class TestQuote:
    """Test cases for the quote() function."""

    def test_quote_simple_string(self):
        """Test quoting a simple string."""
        result = pipes.quote("hello")
        # shlex.quote only adds quotes when necessary
        # For simple strings without special chars, it may not add quotes
        assert isinstance(result, str)
        assert len(result) > 0
        # The result should be safe to use in shell commands
        # Verify it's the same as shlex.quote
        import shlex

        assert result == shlex.quote("hello")

    def test_quote_string_with_spaces(self):
        """Test quoting a string with spaces."""
        result = pipes.quote("hello world")
        assert result == "'hello world'"

    def test_quote_string_with_special_chars(self):
        """Test quoting a string with special characters."""
        result = pipes.quote("hello$world")
        assert result == "'hello$world'"

    def test_quote_string_with_quotes(self):
        """Test quoting a string that contains quotes."""
        result = pipes.quote("hello'world")
        # shlex.quote handles quotes properly
        assert "'" in result or '"' in result

    def test_quote_empty_string(self):
        """Test quoting an empty string."""
        result = pipes.quote("")
        assert result == "''"

    def test_quote_unicode_string(self):
        """Test quoting a unicode string."""
        result = pipes.quote("héllo wörld")
        assert "héllo" in result or "wörld" in result

    def test_quote_path_with_spaces(self):
        """Test quoting a file path with spaces."""
        result = pipes.quote("/path/to/file with spaces.txt")
        assert "file with spaces" in result

    def test_quote_returns_string(self):
        """Test that quote() returns a string type."""
        result = pipes.quote("test")
        assert isinstance(result, str)

    def test_quote_shell_safe(self):
        """Test that quoted strings are safe for shell use."""
        test_strings = [
            "hello world",
            "file$name",
            "test;rm -rf /",
            "test && echo hello",
            "test | grep foo",
        ]
        for s in test_strings:
            quoted = pipes.quote(s)
            # The quoted string should not contain unescaped special chars
            assert isinstance(quoted, str)
            assert len(quoted) > 0
