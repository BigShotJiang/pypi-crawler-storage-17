# Core functionality for SecureVector SDK
