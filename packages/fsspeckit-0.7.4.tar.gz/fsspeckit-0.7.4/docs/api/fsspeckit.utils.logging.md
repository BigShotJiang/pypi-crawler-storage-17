# `fsspeckit.utils.logging`

::: fsspeckit.common.logging

> **Note**: The `fsspeckit.utils.logging` module is maintained for backwards compatibility. New code should import logging utilities directly from `fsspeckit.common.logging` for better discoverability.
>
> This module is equivalent to `fsspeckit.common.logging` and exports the same functions for backwards compatibility only.
