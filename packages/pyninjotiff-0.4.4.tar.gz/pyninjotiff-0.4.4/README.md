# pyninjotiff
python library for writing Ninjo-compatible TIFF files
