## Version 0.4.4 (2025/12/15)


### Pull Requests Merged

#### Bugs fixed

* [PR 37](https://github.com/pytroll/pyninjotiff/pull/37) - Fix sdist and precommit

In this release 1 pull request was closed.


## Version 0.4.3 (2025/12/15)


### Pull Requests Merged

#### Bugs fixed

* [PR 36](https://github.com/pytroll/pyninjotiff/pull/36) - Fix compatibility with numpy 2.3

#### Features added

* [PR 34](https://github.com/pytroll/pyninjotiff/pull/34) - remove stray six usage

In this release 2 pull requests were closed.


## Version 0.4.2 (2025/09/03)



## Version 0.4.1 (2025/07/21)


### Pull Requests Merged

#### Features added

* [PR 35](https://github.com/pytroll/pyninjotiff/pull/35) - Update python and dask versions
* [PR 30](https://github.com/pytroll/pyninjotiff/pull/30) - Add test deployment to pypi

In this release 2 pull requests were closed.
