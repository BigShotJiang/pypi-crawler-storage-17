
``wuttaweb.views.base``
=======================

.. automodule:: wuttaweb.views.base
   :members:
