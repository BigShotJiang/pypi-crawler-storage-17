
# WuttaWeb

Web app for Wutta Framework

See docs at https://rattailproject.org/docs/wuttaweb/
