"""Exceptions."""


class VirtualHostNotExistsError(Exception):
    """Virtual host doesn't exist."""

    pass
