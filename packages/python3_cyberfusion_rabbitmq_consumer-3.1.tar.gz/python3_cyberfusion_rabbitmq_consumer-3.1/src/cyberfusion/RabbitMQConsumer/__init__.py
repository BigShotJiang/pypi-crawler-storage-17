"""Empty class to turn this into a package."""
