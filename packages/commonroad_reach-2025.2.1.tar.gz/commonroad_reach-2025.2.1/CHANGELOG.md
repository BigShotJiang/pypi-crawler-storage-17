
# Changelog
## [2022.11]

### Changed

- Upgrade to work with CommonRoad-IO 2022.3.
## [2022.7]

### Added

- First release of the toolbox.
