#pragma once

#include <iostream>

#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <stack>
#include <tuple>
#include <string>
#include <cstring>

#include <memory>
#include <exception>
#include <cmath>
#include <typeinfo>
#include <algorithm>
#include <iterator>

#include <boost/algorithm/string.hpp>

namespace ba = boost::algorithm;

