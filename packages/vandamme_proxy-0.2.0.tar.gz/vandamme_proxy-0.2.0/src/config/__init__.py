"""Configuration module for vandamme-proxy."""
