"""CLI module for vandamme-proxy."""
