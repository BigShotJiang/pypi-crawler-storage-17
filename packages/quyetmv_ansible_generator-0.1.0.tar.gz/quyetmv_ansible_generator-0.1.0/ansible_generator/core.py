import os
from pathlib import Path
from . import templates

def create_structure(base_path):
    """Creates the Ansible directory structure."""
    
    # Define the directory structure
    dirs = [
        "inventory/testing/group_vars",
        "inventory/production/group_vars",
        "roles/common/tasks",
        "roles/common/handlers",
        "roles/common/templates",
        "roles/common/files",
        "roles/common/vars",
        "roles/common/defaults",
        "roles/common/meta",
    ]

    # Create directories
    for d in dirs:
        path = base_path / d
        path.mkdir(parents=True, exist_ok=True)
        print(f"Created directory: {path}")

    # Define files and their initial content
    files = {
        "ansible.cfg": templates.ANSIBLE_CFG,
        "site.yml": templates.SITE_YML,
        "README.md": templates.README_MD.format(project_name=base_path.name),
        ".ansible-lint": templates.ANSIBLE_LINT,
        "inventory/testing/hosts.ini": templates.HOSTS_INI,
        "inventory/production/hosts.ini": templates.HOSTS_INI,
        "inventory/testing/group_vars/all.yml": templates.GROUP_VARS_ALL,
        "inventory/production/group_vars/all.yml": templates.GROUP_VARS_ALL,
        "roles/common/tasks/main.yml": templates.ROLE_TASKS,
        "roles/common/handlers/main.yml": templates.ROLE_HANDLERS,
        "roles/common/vars/main.yml": templates.ROLE_VARS,
        "roles/common/defaults/main.yml": templates.ROLE_DEFAULTS,
        "roles/common/meta/main.yml": templates.ROLE_META,
    }

    # Create files
    for filename, content in files.items():
        path = base_path / filename
        if not path.exists():
            with open(path, "w") as f:
                f.write(content)
            print(f"Created file: {path}")
        else:
            print(f"File already exists: {path}")
