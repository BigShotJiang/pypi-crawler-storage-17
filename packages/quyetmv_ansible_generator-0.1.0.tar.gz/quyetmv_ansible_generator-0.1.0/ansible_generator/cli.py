import argparse
from pathlib import Path
from . import core

def main():
    parser = argparse.ArgumentParser(description="Generate Ansible Boilerplate")
    parser.add_argument("project_name", nargs="?", default=".", help="Name of the project directory (default: current directory)")
    args = parser.parse_args()

    # Determine base path
    if args.project_name == ".":
        base_path = Path.cwd()
    else:
        base_path = Path.cwd() / args.project_name
        base_path.mkdir(parents=True, exist_ok=True)

    print(f"Generating Ansible boilerplate in: {base_path}")
    core.create_structure(base_path)
    print("\nAnsible boilerplate created successfully!")

if __name__ == "__main__":
    main()
