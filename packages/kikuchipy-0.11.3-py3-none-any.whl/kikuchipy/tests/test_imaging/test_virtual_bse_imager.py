# Copyright 2019-2024 The kikuchipy developers
#
# This file is part of kikuchipy.
#
# kikuchipy is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# kikuchipy is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with kikuchipy. If not, see <http://www.gnu.org/licenses/>.

from hyperspy.roi import RectangularROI
import matplotlib.pyplot as plt
import numpy as np
import pytest

import kikuchipy as kp


class TestVirtualBSEImager:
    def test_init(self, dummy_signal):
        vbse_imager = kp.imaging.VirtualBSEImager(dummy_signal)

        assert isinstance(vbse_imager._signal, kp.signals.EBSD)
        assert vbse_imager.grid_shape == (3, 3)

    def test_init_lazy(self, dummy_signal):
        lazy_signal = dummy_signal.as_lazy()
        vbse_imager = kp.imaging.VirtualBSEImager(lazy_signal)

        assert isinstance(vbse_imager._signal, kp.signals.LazyEBSD)

    @pytest.mark.parametrize(
        "grid_shape, desired_rows, desired_cols",
        [
            (
                (10, 10),
                np.linspace(0, 60, 10 + 1),
                np.linspace(0, 60, 10 + 1),
            ),
            (
                (13, 7),
                np.linspace(0, 60, 13 + 1),
                np.linspace(0, 60, 7 + 1),
            ),
        ],
    )
    def test_set_grid_shape(
        self, kikuchipy_h5ebsd_path, grid_shape, desired_rows, desired_cols
    ):
        s = kp.load(kikuchipy_h5ebsd_path / "patterns.h5")
        vbse_imager = kp.imaging.VirtualBSEImager(s)
        vbse_imager.grid_shape = grid_shape

        assert vbse_imager.grid_shape == grid_shape
        assert np.allclose(vbse_imager.grid_rows, desired_rows)
        assert np.allclose(vbse_imager.grid_cols, desired_cols)

    def test_repr(self, dummy_signal):
        vbse_imager = kp.imaging.VirtualBSEImager(dummy_signal)

        assert repr(vbse_imager) == (
            "VirtualBSEImager for <EBSD, title: , dimensions: (3, 3|3, 3)>"
        )

    @pytest.mark.parametrize("grid_shape", [(3, 3), (2, 3)])
    def test_plot_grid(self, kikuchipy_h5ebsd_path, grid_shape):
        s = kp.load(kikuchipy_h5ebsd_path / "patterns.h5")
        vbse_imager = kp.imaging.VirtualBSEImager(s)
        vbse_imager.grid_shape = grid_shape
        rgb_channels = [(0, 0), (0, 1), (1, 0)]
        pattern_idx = (2, 2)
        p = vbse_imager.plot_grid(pattern_idx=pattern_idx, rgb_channels=rgb_channels)
        p2 = vbse_imager.plot_grid()

        assert isinstance(p, kp.signals.EBSD)
        assert np.allclose(p.data, s.inav[pattern_idx].data)
        assert np.allclose(p2.data, s.inav[0, 0].data)

        markers = p.metadata.Markers
        assert len(markers) == 6
        assert markers.Texts.kwargs["offsets"].shape == (int(np.prod(grid_shape)), 2)
        assert markers.Texts.kwargs["facecolors"] == "r"
        assert markers.HorizontalLines.kwargs["ec"] == "w"
        assert markers.Rectangles.kwargs["ec"] == "r"

        plt.close("all")

    def test_plot_grid_raises(self):
        s = kp.signals.EBSD(np.zeros((60, 60)))
        vbse_imager = kp.imaging.VirtualBSEImager(s)
        vbse_imager.grid_shape = (1, 1)

        with pytest.raises(ValueError, match="Green channel tile coordinates cannot "):
            _ = vbse_imager.plot_grid(rgb_channels=[(0, 0), (1, 0), (0, 1)])

    @pytest.mark.parametrize("color", ["c", "m", "k"])
    def test_plot_grid_text_color(self, kikuchipy_h5ebsd_path, color):
        s = kp.load(kikuchipy_h5ebsd_path / "patterns.h5")
        vbse_imager = kp.imaging.VirtualBSEImager(s)
        p = vbse_imager.plot_grid(color=color)

        assert p.metadata.Markers.Texts.kwargs["facecolors"] == color

        plt.close("all")


class TestGetImagesFromGrid:
    def test_get_single_image_from_grid(self, dummy_signal):
        vbse_imager = kp.imaging.VirtualBSEImager(dummy_signal)
        vbse_imager.grid_shape = (1, 1)
        vbse_img = vbse_imager.get_images_from_grid()

        assert np.allclose(vbse_img.data.mean(), 40.666668)

    @pytest.mark.parametrize("dtype_out", [np.float32, np.float64])
    def test_dtype_out(self, dummy_signal, dtype_out):
        vbse_imager = kp.imaging.VirtualBSEImager(dummy_signal)
        vbse_imager.grid_shape = (1, 1)
        vbse_images = vbse_imager.get_images_from_grid(dtype_out=dtype_out)

        assert vbse_images.data.dtype == dtype_out

    def test_axes_manager_transfer(self, kikuchipy_h5ebsd_path):
        s = kp.load(kikuchipy_h5ebsd_path / "patterns.h5")
        vbse_imager = kp.imaging.VirtualBSEImager(s)
        vbse_img = vbse_imager.get_images_from_grid()

        s_nav_axes = s.axes_manager.navigation_axes
        vbse_sig_axes = vbse_img.axes_manager.signal_axes

        assert all([vbse_sig_axes[i].scale == s_nav_axes[i].scale for i in range(2)])
        assert all([vbse_sig_axes[i].name == s_nav_axes[i].name for i in range(2)])
        assert all([vbse_sig_axes[i].units == s_nav_axes[i].units for i in range(2)])

    def test_get_images_lazy(self, kikuchipy_h5ebsd_path):
        s = kp.load(kikuchipy_h5ebsd_path / "patterns.h5", lazy=True)
        vbse_imager = kp.imaging.VirtualBSEImager(s)
        _ = vbse_imager.get_images_from_grid()


class TestGetRGBImage:
    def test_get_rgb_image_rois(self, kikuchipy_h5ebsd_path):
        s = kp.load(kikuchipy_h5ebsd_path / "patterns.h5")
        vbse_imager = kp.imaging.VirtualBSEImager(s)

        # Get channels by ROIs
        rois1 = [
            vbse_imager.roi_from_grid(i) for i in np.ndindex(vbse_imager.grid_shape)
        ][:3]
        vbse_rgb_img1 = vbse_imager.get_rgb_image(r=rois1[0], g=rois1[1], b=rois1[2])

        # Get channels from grid tile indices
        rois2 = [(0, 0), (0, 1), (0, 2)]
        vbse_rgb_img2 = vbse_imager.get_rgb_image(r=rois2[0], g=rois2[1], b=rois2[2])

        assert isinstance(vbse_rgb_img1, kp.signals.VirtualBSEImage)
        assert vbse_rgb_img1.data.dtype == np.dtype(
            [("R", "u1"), ("G", "u1"), ("B", "u1")]
        )

        vbse_rgb_img1.change_dtype("uint8")
        vbse_rgb_img2.change_dtype("uint8")
        assert np.allclose(vbse_rgb_img1.data, vbse_rgb_img2.data)

    def test_get_rgb_image_dtype(self, kikuchipy_h5ebsd_path):
        s = kp.load(kikuchipy_h5ebsd_path / "patterns.h5")
        vbse_imager = kp.imaging.VirtualBSEImager(s)
        vbse_rgb_img = vbse_imager.get_rgb_image(
            r=(0, 0), g=(0, 1), b=(0, 2), dtype_out=np.uint16
        )

        assert vbse_rgb_img.data.dtype == np.dtype(
            [("R", "u2"), ("G", "u2"), ("B", "u2")]
        )

    @pytest.mark.parametrize(
        "percentile, desired_mean_intensity",
        [(None, 136.481481), ((1, 99), 134.740740)],
    )
    def test_get_rgb_image_contrast_stretching(
        self, kikuchipy_h5ebsd_path, percentile, desired_mean_intensity
    ):
        s = kp.load(kikuchipy_h5ebsd_path / "patterns.h5")
        vbse_imager = kp.imaging.VirtualBSEImager(s)
        vbse_rgb_img = vbse_imager.get_rgb_image(
            r=(0, 0), g=(0, 1), b=(0, 2), percentiles=percentile
        )
        vbse_rgb_img.change_dtype("uint8")

        assert np.allclose(vbse_rgb_img.data.mean(), desired_mean_intensity)

    @pytest.mark.parametrize(
        "alpha_add, desired_mean_intensity", [(0, 88.5), (10, 107.9)]
    )
    def test_get_rgb_alpha(
        self, kikuchipy_h5ebsd_path, alpha_add, desired_mean_intensity
    ):
        s = kp.load(kikuchipy_h5ebsd_path / "patterns.h5")
        vbse_imager = kp.imaging.VirtualBSEImager(s)

        alpha = np.arange(9).reshape((3, 3))
        alpha[0] += alpha_add

        vbse_rgb_img = vbse_imager.get_rgb_image(
            r=(0, 0), g=(0, 1), b=(0, 2), alpha=alpha
        )
        vbse_rgb_img.change_dtype("uint8")

        assert np.allclose(vbse_rgb_img.data.mean(), desired_mean_intensity, atol=0.1)

    def test_get_rgb_alpha_signal(self, kikuchipy_h5ebsd_path):
        s = kp.load(kikuchipy_h5ebsd_path / "patterns.h5")
        vbse_imager = kp.imaging.VirtualBSEImager(s)

        vbse_img = s.get_virtual_bse_intensity(roi=RectangularROI(0, 0, 10, 10))

        vbse_rgb_img1 = vbse_imager.get_rgb_image(
            r=(0, 1), g=(0, 2), b=(0, 3), alpha=vbse_img
        )
        vbse_rgb_img2 = vbse_imager.get_rgb_image(
            r=(0, 1), g=(0, 2), b=(0, 3), alpha=vbse_img.data
        )
        vbse_rgb_img1.change_dtype("uint8")
        vbse_rgb_img2.change_dtype("uint8")

        assert np.allclose(vbse_rgb_img1.data, vbse_rgb_img2.data)

    def test_get_rgb_image_lazy(self, kikuchipy_h5ebsd_path):
        s = kp.load(kikuchipy_h5ebsd_path / "patterns.h5", lazy=True)
        vbse_imager = kp.imaging.VirtualBSEImager(s)

        assert isinstance(vbse_imager._signal, kp.signals.LazyEBSD)

        vbse_rgb_img = vbse_imager.get_rgb_image(r=(0, 0), g=(0, 1), b=(0, 2))

        assert isinstance(vbse_rgb_img.data, np.ndarray)

    def test_get_rgb_1d(self):
        s = kp.signals.EBSD(np.random.random(9 * 3600).reshape((9, 60, 60)))
        vbse_imager = kp.imaging.VirtualBSEImager(s)

        with pytest.raises(ValueError, match="The signal dimension cannot be "):
            _ = vbse_imager.get_rgb_image(r=(0, 0), g=(0, 1), b=(0, 2))

    @pytest.mark.parametrize(
        "r, g, b, desired_mean_intensity",
        [
            ([(0, 1), (0, 2)], [(1, 1), (1, 2)], [(2, 1), (2, 2)], 125.1),
            ([(2, 1), (2, 2)], [(3, 1), (3, 2)], [(4, 1), (4, 2)], 109.0),
        ],
    )
    def test_get_rgb_multiple_rois_per_channel(
        self, kikuchipy_h5ebsd_path, r, g, b, desired_mean_intensity
    ):
        s = kp.load(kikuchipy_h5ebsd_path / "patterns.h5")
        vbse_imager = kp.imaging.VirtualBSEImager(s)

        vbse_rgb_img1 = vbse_imager.get_rgb_image(r=r, g=g, b=b)
        vbse_rgb_img1.change_dtype("uint8")

        assert np.allclose(vbse_rgb_img1.data.mean(), desired_mean_intensity, atol=0.1)

        roi_r = vbse_imager.roi_from_grid(r)
        roi_g = vbse_imager.roi_from_grid(g)
        roi_b = vbse_imager.roi_from_grid(b)
        vbse_rgb_img2 = vbse_imager.get_rgb_image(r=roi_r, g=roi_g, b=roi_b)
        vbse_rgb_img2.change_dtype("uint8")

        assert np.allclose(vbse_rgb_img1.data, vbse_rgb_img2.data)
