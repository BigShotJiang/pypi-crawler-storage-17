import ffmpegp

if __name__ == "__main__":
    ffmpegp.main()