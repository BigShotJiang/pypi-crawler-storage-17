"""Tests for the hindsight package."""
