def main():
    print("Hello from aai!")


if __name__ == "__main__":
    main()
