def hello(msg):
    print('Hello! %s' % msg)
