# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2025/7/17 10:53
# Description:

__version__ = "1.0.21"
