import { redirect } from "next/navigation"

export default function DocsPage() {
    redirect("/docs/getting-started")
}
