"""Kytchen scripts module."""
