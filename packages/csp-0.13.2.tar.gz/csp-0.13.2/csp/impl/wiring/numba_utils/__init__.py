# We need to import this to register the support for datetime in numba
from . import datetime_extension
