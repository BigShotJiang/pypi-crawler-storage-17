UNNAMED_OUTPUT_NAME = "__csp__unnamed_output__"
