from modeltranslation._typing import monkeypatch

# monkeypatch generic classes at runtime
monkeypatch()
