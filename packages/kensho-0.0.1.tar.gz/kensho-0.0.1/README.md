# Kensho (placeholder)

This directory provides a minimal Python distribution used to reserve the
``kensho`` package name on PyPI. The release exports a simple metadata helper
and will be replaced with the production Kensho Health OS SDK in the future.
