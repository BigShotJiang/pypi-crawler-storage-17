"""
Model for the Prompt Resource provider.
"""
from .prompt_types import PromptTypes
from .multipart_prompt import MultipartPrompt
