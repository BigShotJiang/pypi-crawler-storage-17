from adam.commands.command import ExtractAllOptionsHandler, ExtractOptionsHandler, ExtractSequenceOptionsHandler, ExtractTrailingOptionsHandler
from adam.repl_state import ReplState
from adam.commands.app.utils_app import AppHandler

def app(state: ReplState) -> AppHandler:
    return AppHandler(state)

def extract_options(args: list[str], options: list[str]):
    return ExtractOptionsHandler(args, options = options)

def extract_trailing_options(args: list[str], trailing: list[str]):
    return ExtractTrailingOptionsHandler(args, trailing = trailing)

def extract_all_options(args: list[str], trailing = None, sequence = None, options = None):
    return ExtractAllOptionsHandler(args, trailing = trailing, sequence = sequence, options = options)

def extract_sequence(args: list[str], sequence: list[str]):
    return ExtractSequenceOptionsHandler(args, sequence = sequence)