"""
FlaxKV2 服务器模块
"""

from flaxkv2.server.zmq_server import FlaxKVServer

__all__ = ["FlaxKVServer"] 