"""WACCY extension for QuickBooks Online integration."""

__version__ = "0.1.0"

