---
icon: material/file-code
---

# Encodings


<!-- ::: src/meta_tools/encodings/test.lp
    handler: asp
    options:
        glossary: true
        predicate_table: true
        dependency_graph: true
        encodings:
            git_link: true
            source: true
        start_level: 1 -->
