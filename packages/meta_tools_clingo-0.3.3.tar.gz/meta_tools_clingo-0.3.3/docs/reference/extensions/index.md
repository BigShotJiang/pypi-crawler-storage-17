---
icon: material/head-dots-horizontal
---

# Extensions
