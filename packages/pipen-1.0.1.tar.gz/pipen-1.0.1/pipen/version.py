"""Provide version of pipen"""

__version__ = "1.0.1"
