# mobility-datasets

[![codecov](https://codecov.io/gh/mhabedank/mobility-datasets/branch/main/graph/badge.svg)](https://codecov.io/gh/mhabedank/mobility-datasets)

Python library for downloading, loading, and working with autonomous driving and mobility datasets (KITTI, nuScenes, Waymo, etc.)
