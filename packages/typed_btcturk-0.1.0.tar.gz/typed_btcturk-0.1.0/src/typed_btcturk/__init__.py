"""
### Typed Btcturk
> A fully typed, validated async client for the Btcturk API

- Details
"""