from ...imports import *
from .nullProxy import nullProxy,nullProxy_logger
@lru_cache(maxsize=None)
def lazy_import(name: str):
    """
    Import module safely. If unavailable, return NullProxy.
    """

    if name in sys.modules:
        return sys.modules[name]

    try:
        module = importlib.import_module(name)
        return module
    except Exception as e:
        nullProxy_logger.warning(
            "[lazy_import] Failed to import '%s': %s",
            name,
            e,
        )
        return nullProxy(name)

def get_lazy_attr(module_name: str, *attrs):
    obj = lazy_import(module_name)

    for attr in attrs:
        try:
            obj = getattr(obj, attr)
        except Exception:
            return nullProxy(module_name, attrs)

    return obj
