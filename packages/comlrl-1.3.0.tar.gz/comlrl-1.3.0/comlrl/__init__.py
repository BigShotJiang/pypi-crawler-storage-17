from importlib.metadata import PackageNotFoundError, version

__version__ = version("comlrl")

__all__ = ["__version__"]
