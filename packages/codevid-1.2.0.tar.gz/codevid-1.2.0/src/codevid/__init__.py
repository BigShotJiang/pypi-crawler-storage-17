"""Codevid - Generate video tutorials from automated tests."""

__version__ = "1.2.0"
