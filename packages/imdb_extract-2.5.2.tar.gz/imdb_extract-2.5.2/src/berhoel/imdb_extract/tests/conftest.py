"""Pytest helper for IMDBExtract."""
