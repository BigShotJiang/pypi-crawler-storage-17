from quanti_fret.apps.cli.view.cli_view import CliView  # noqa: F401

__ALL__ = ['CliView']
