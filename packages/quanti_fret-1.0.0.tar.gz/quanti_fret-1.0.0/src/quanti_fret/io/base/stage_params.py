from quanti_fret.algo import (
    BackgroundEngine, BackgroundMode, create_background_engine
)
from quanti_fret.core import QtfException, QtfSeries
from quanti_fret.io.base.config import Config

import abc
from typing import Any


class StageParams(abc.ABC):
    """ Class that returns the parameters to use to run each stages of a given
    phase.

    This class is linked to a :any:`Config`, a :any:`QtfSeriesManager` and a
    :any:`ResultsManager` that are used to get the differents parameters.

    When asking for the parameters of a given stage, an exception is raised if
    some can't be retrieved. You can ignore this behavior by setting
    ``allow_none_values`` to ``True``. This will set invalid parameters to
    ``None``.

    The :meth:`get` method always return one parameter more than the ones to
    pass to the stage's run method, which is a decription of the input series
    (either its name or the mode used for background computation). This is used
    when saving the results.

    This class is expected to be overritten for each phase.
    """

    @abc.abstractmethod
    def get(
        self, stage: str, allow_none_values: bool = False
    ) -> tuple[Any, ...]:
        """ Get the parameters to run the stage passed in arguments.

        Args:
            stage (str): Stage to get the parameters for. Must be in
                the stages accepted by the ``StageParams`` implementation.
            allow_none_values (bool, optional): If ``true``, will not raise
                exceptions if elements are missing for the run, instead values
                not found will be set to ``None``. Defaults to ``False``.

        Raises:
            QtfException: The stage is unknown.
            QtfException: Parameters are missing and ``allow_none_values`` is
                set to ``False``.

        Returns:
            tuple[Any, ...]:
                The parameters to run the stage (see each ``StageParams``
                implementation for more information).
        """
        pass

    def _get_background_engine_from_config(
        self, config: Config, invert_floating: bool = False
    ) -> BackgroundEngine | None:
        """ Utility function to retrive the background engine from the config.

        Args:
            config (Config): Config to use.
            invert_floating (bool, optional): Invert the background floating
                value. Used to differenciate background stage for calibration
                and the rest. Indeed during the Background stage, floating
                value means that no background should be created.

        Returns:
            BackgroundEngine | None:
                The engine to use or None if no engine was created.
        """
        floating: bool = config.get('Background', 'floating')
        mode: BackgroundMode = config.get('Background', 'mode')
        percentile: float = config.get('Background', 'percentile')
        fixed_background: tuple[float, float, float] = \
            config.get('Background', 'fixed_background')

        if invert_floating:
            floating = not floating

        if floating:
            return create_background_engine(
                mode=mode, background=fixed_background, percentile=percentile
            )
        else:
            return None

    def _validate_series_for_background(
        self, engine: BackgroundEngine | None, series: QtfSeries,
        disable_exception: bool = False
    ) -> bool:
        """ Test if the series is compatible with the background mode.

        For now, test that all the triplets have a background mask if the
        mode is BackgroundMode.MASK.

        Args:
            engine (BackgroundEngine): Background engine to use.
            series (QtfSeries): Series to check.
            disable_exception (bool, optional): If set to ``True``, will not
                raise an exception on error. Default to ``False``.

        Raises:
            QtfException: If the series is not compatible.

        Returns:
            bool: ``True`` if series is compatible, ``False`` otherwise.
        """
        if engine is None:
            return True
        if engine.mode == BackgroundMode.MASK:
            if not series.have_all_mask_bckg():
                if not disable_exception:
                    err = "Some triplets don't have a mask background"
                    raise QtfException(err)
                else:
                    return False
        return True
