# itmo-sem1-python

## hw1
- 1.1 nl 
- 1.2 tail 
- 1.3 wc
