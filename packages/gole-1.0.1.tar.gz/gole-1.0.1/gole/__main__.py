from gole.cli import app

app()
