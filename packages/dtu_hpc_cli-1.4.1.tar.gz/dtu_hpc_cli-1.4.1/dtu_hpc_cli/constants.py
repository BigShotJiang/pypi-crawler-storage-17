CONFIG_FILENAME = ".dtu_hpc.json"

HISTORY_FILENAME = ".dtu_hpc_history.json"
