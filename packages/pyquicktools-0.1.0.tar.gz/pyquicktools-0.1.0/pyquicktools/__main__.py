from .doctor import run_doctor

if __name__ == "__main__":
    run_doctor()
