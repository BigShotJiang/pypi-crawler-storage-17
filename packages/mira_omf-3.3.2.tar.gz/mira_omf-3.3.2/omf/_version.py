# Version placeholder that will be replaced during substitution
__version__ = "3.3.2"
