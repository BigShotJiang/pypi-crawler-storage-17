"""
FortiOS Log Search API Module
"""

from .search import Search

__all__ = ['Search']
