from .fortianalyzer import FortiAnalyzer

__all__ = ['FortiAnalyzer']
