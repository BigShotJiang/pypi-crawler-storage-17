"""Test for pkg."""

import videodataset


def test_pkg() -> None:
    """Test for pkg."""
    assert videodataset.__package__ == "videodataset"
