from jobbergate_core.sdk.job_templates.app import JobTemplates

__all__ = [
    "JobTemplates",
]
