# Typed Dydx

> A fully typed, validated async client for the Dydx API

Use *autocomplete* instead of documentation.

🚧 Under construction.