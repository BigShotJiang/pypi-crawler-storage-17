"""
### Typed Dydx
> A fully typed, validated async client for the Dydx API

- Details
"""