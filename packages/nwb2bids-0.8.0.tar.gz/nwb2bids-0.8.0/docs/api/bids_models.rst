BIDS Models
===========

.. automodule:: nwb2bids.bids_models
