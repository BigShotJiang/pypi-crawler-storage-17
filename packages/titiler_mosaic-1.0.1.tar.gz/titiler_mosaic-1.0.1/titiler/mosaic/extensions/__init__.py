"""titiler mosaic extensions module."""
