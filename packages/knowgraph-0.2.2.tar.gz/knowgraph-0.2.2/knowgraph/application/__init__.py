"""Application layer - Use cases and orchestration logic."""
