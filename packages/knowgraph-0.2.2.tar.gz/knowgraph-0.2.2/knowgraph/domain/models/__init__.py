"""Domain models - Immutable value objects and aggregate roots."""
