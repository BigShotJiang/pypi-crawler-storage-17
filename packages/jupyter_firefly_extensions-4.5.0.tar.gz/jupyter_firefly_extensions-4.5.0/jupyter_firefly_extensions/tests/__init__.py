"""Python unit tests for jupyter_firefly_extensions."""
