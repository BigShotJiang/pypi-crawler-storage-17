"""TurkAnime API paket giriş noktası."""
from .objects import Anime, Bolum, Video
from .bypass import session
