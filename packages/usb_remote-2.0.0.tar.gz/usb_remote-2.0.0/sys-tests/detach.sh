#!/bin/bash

uvx usb-remote detach --serial 000001
uvx usb-remote detach --serial FTA955HH
uvx usb-remote detach --serial FTA94JXC
uvx usb-remote detach --serial FTA974AY
uvx usb-remote detach --serial 0019C52F
uvx usb-remote detach --serial 0000000000000001
uvx usb-remote detach --desc Unifying
uvx usb-remote detach --desc Scope
uvx usb-remote detach --desc WebCam
