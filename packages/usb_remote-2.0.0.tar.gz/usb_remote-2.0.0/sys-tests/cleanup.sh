#!/bin/bash

sudo usbip detach -p 0
sudo usbip detach -p 1
sudo usbip detach -p 2
sudo usbip detach -p 3
sudo usbip detach -p 4
sudo usbip detach -p 5
sudo usbip detach -p 6
sudo usbip detach -p 7
sudo usbip detach -p 8
sudo usbip detach -p 9
sudo usbip detach -p 10
sudo usbip detach -p 11
sudo usbip detach -p 12
sudo usbip port
