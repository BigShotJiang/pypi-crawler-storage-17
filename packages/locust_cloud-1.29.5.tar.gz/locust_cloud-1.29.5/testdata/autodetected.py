# this file is not explicitly specified in --extra-files but should be added automatically
def stuff():
    print("import finder works")
