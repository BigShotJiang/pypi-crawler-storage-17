from typing import List, Generator, Union, Dict, Any
from lagent.core.llm import LLMClient
from lagent.core.agent import ContextAgent
from lagent.config import get_settings

class Lagent:
    """
    High-level client for Lagent.
    Provides a simple interface to initialize and interact with the agent.
    """
    def __init__(
        self, 
        api_key: str = None, 
        base_url: str = None, 
        model_name: str = None, 
        db_url: str = None, 
        tools: List[str] = None
    ):
        """
        Initialize the Lagent client.
        
        Args:
            api_key: OpenAI API Key.
            base_url: OpenAI Base URL.
            model_name: Model name (e.g., gpt-3.5-turbo).
            db_url: Database URL. Defaults to in-memory SQLite if not provided and not in env.
            tools: List of tool names to enable.
        """
        # 1. Initialize LLM
        self.llm = LLMClient(api_key=api_key, base_url=base_url, model_name=model_name)
        
        # 2. Determine DB URL
        # If explicitly passed, use it.
        # If not, try settings/env. 
        # If still none, agent will default to :memory: internally, so passing None is fine.
        
        # 3. Initialize Agent
        # Single-user, single-session mode for SDK usage typically
        self.agent = ContextAgent(
            llm_client=self.llm,
            db_url=db_url,
            tools=tools,
            user_id="sdk_user",
            # We let the agent generate a session ID unless we want to persist between runs
            # If the user provides a persistent DB URL, they might want to adhere to a session ID?
            # For simplicity in this v1 SDK, we create a new session per Client instance.
        )
        
    def chat(self, query: str) -> str:
        """
        Send a query to the agent and get the final response synchronously.
        """
        final_answer = ""
        for event in self.agent.run(query):
            if event.get("event") == "final_answer":
                final_answer = event.get("content")
                # We don't break here because we might want to capture usage_stats or wait for completion
            elif event.get("event") == "error":
                raise RuntimeError(f"Agent Error: {event.get('content')}")
        return final_answer
        
    def stream(self, query: str) -> Generator[Dict[str, Any], None, None]:
        """
        Stream events from the agent.
        """
        yield from self.agent.run(query)
