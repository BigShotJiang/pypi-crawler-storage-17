# DnsQueryClass

Domain class used by this test. 'in' stands for Internet, while 'ch' stands for Chaos.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


