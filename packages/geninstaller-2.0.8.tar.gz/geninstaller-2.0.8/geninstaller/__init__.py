__version__ = "2.0.8"

# DO on version change:
# ! keep the version up to date in:
# plop/installer/installer dependencies too !
# pyproject.toml
# README.md changelog
