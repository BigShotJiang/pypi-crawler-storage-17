import os

DEV_MODE=os.getenv("GENINSTALLER_DEV_MODE", "0") == "1"