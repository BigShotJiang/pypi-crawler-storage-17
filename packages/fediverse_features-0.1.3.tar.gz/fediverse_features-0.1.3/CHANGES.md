# Changes

## 0.1.3

* Add output to fediverse-features [features#41](https://codeberg.org/helge/fediverse-features/issues/41)
* Display current version on latest subcommand