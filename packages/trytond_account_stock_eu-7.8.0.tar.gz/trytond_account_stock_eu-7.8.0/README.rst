#######################
Account Stock EU Module
#######################

The *Account Stock EU Module* is used to generate the `Intrastat
<https://en.wikipedia.org/wiki/Intrastat>`_ declarations every month.

.. toctree::
   :maxdepth: 2

   usage
   design
   releases
