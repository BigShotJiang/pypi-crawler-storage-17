import json
import pathlib
from datetime import datetime

import numpy as np


class HydropandasEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, (np.float32, np.float64)):
            return float(obj)
        elif isinstance(obj, pathlib.PurePath):
            return str(obj)
        elif isinstance(obj, datetime):
            return obj.isoformat()
        elif isinstance(obj, type):
            return f"class : {obj.__name__}"

        # Add other conversions here
        return super().default(obj)
