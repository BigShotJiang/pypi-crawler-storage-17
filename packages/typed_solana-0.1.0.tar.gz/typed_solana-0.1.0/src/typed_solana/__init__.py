"""
### Typed Solana
> A fully typed, validated async client for the Solana API

- Details
"""