# Typed Solana

> A fully typed, validated async client for the Solana API

Use *autocomplete* instead of documentation.

🚧 Under construction.