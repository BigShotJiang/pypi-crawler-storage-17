"""Common setup for Hussh tests."""

import os
from pathlib import Path, PurePath
import subprocess
import time

import docker
import pexpect
import pytest

TESTDIR = PurePath(__file__).parent
TEST_SERVER_IMAGE = "ghcr.io/jacobcallahan/hussh/hussh-test-server:latest"


@pytest.fixture(scope="session")
def ensure_test_server_image():
    """Ensure that the test server Docker image is available."""
    client = docker.from_env()
    try:
        client.images.get(TEST_SERVER_IMAGE)
    except docker.errors.ImageNotFound:
        client.images.pull(TEST_SERVER_IMAGE)
    client.close()


@pytest.fixture(scope="session", autouse=True)
def run_test_server(ensure_test_server_image):
    """Run a test server in a Docker container."""
    client = docker.from_env()
    try:  # check to see if the container is already running
        container = client.containers.get("hussh-test-server")
        if container.status != "running":
            container.start()
            time.sleep(5)  # give the server time to start
        managed = False
    except docker.errors.NotFound:  # if not, start it
        container = client.containers.run(
            TEST_SERVER_IMAGE,
            detach=True,
            ports={"22/tcp": 8022},
            name="hussh-test-server",
        )
        managed = True
        time.sleep(5)  # give the server time to start
    yield container
    if managed:
        container.stop()
        container.remove()
    client.close()


@pytest.fixture(scope="session")
def run_second_server(ensure_test_server_image):
    """Run a test server in a Docker container."""
    client = docker.from_env()
    try:  # check to see if the container is already running
        container = client.containers.get("hussh-test-server2")
    except docker.errors.NotFound:  # if not, start it
        container = client.containers.run(
            TEST_SERVER_IMAGE,
            detach=True,
            ports={"22/tcp": 8023},
            name="hussh-test-server2",
        )
        time.sleep(5)  # give the server time to start
    yield container
    container.stop()
    container.remove()
    client.close()


@pytest.fixture(scope="session")
def setup_agent_auth():
    # Define the key paths
    base_key = Path(TESTDIR / "data/test_key")
    auth_key = Path(TESTDIR / "data/auth_test_key")

    # Ensure proper permissions on the keys
    base_key.chmod(0o600)
    auth_key.chmod(0o600)

    # Start the ssh-agent and get the environment variables
    output = subprocess.check_output(["ssh-agent", "-s"])
    env = {}
    for line in output.decode().splitlines():
        if "=" in line and not line.startswith("echo"):
            key, value = line.split("=", 1)
            # Strip trailing semicolons and 'export' suffix
            value = value.split(";")[0].strip()
            env[key.strip()] = value

    # Set the SSH_AUTH_SOCK and SSH_AGENT_PID environment variables
    os.environ["SSH_AUTH_SOCK"] = env["SSH_AUTH_SOCK"]
    os.environ["SSH_AGENT_PID"] = env["SSH_AGENT_PID"]

    # Add the keys to the ssh-agent
    result = subprocess.run(
        ["ssh-add", str(base_key)], capture_output=True, text=True, check=False
    )
    if result.returncode != 0:
        raise RuntimeError(f"Failed to add key to agent: {result.stderr}")

    # The auth_key is password protected
    child = pexpect.spawn("ssh-add", [str(auth_key)])
    child.expect("Enter passphrase for .*: ")
    child.sendline("husshpuppy")
    child.expect(pexpect.EOF)
    child.close()
    if child.exitstatus != 0:
        raise RuntimeError("Failed to add password-protected key to agent")

    yield

    # Kill the ssh-agent after the tests have run
    agent_pid = env["SSH_AGENT_PID"]
    result = subprocess.run(["kill", agent_pid], check=False, capture_output=True)
    if result.returncode != 0:
        print(f"Warning: Failed to kill ssh-agent (PID {agent_pid}): {result.stderr.decode()}")
