To make use of this feature, you only need to configure products of type `service` that you want to impact the delivery date.

1.  Navigate to "Inventory \> Products \> Products".
2.  Select the "Service" type product you wish to configure.
3.  Switch to the "Sales" tab.
4.  Check the "Affect Delivery Date" boolean field in the "Extra Info" section.

> **Note:** By default all Service products are set to to NOT affect the Sales Order delivery date computation.
