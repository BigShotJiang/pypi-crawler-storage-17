"""
Windmouse - A cross-platform human-like mouse control library.
"""
