"""Version information for gundog-client."""

__version__ = "0.4.0"
