"""Prompt templates."""

from .system import DEFAULT_SYSTEM_PROMPT

__all__ = ["DEFAULT_SYSTEM_PROMPT"]
