# <code class="doc-symbol-module"></code> `yaozarrs.v04`

Specification: <https://ngff.openmicroscopy.org/0.4>

Schema: <https://github.com/ome/ngff/tree/7ac3430c74a66e5bcf53e41c429143172d68c0a4>

## Images

::: yaozarrs.v04._image
      options:
        filters:
          - "!^_"
          - "!^serialize_model"

## Labels

::: yaozarrs.v04._labels

## Plates

::: yaozarrs.v04._plate

## Collections

::: yaozarrs.v04._bf2raw
