# <code class="doc-symbol-module"></code> `yaozarrs.v05`

Specification: <https://ngff.openmicroscopy.org/0.5/>

Schema: <https://github.com/ome/ngff/tree/8cbba216e37407bd2d4bd5c7128ab13bd0a6404e>


## Images

::: yaozarrs.v05._image

## Labels

::: yaozarrs.v05._labels

## Plates

::: yaozarrs.v05._plate

## Collections

::: yaozarrs.v05._bf2raw
