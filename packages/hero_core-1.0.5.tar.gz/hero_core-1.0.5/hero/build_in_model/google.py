from hero.build_in_model.model import BasicModel

class GoogleModel(BasicModel):
    pass