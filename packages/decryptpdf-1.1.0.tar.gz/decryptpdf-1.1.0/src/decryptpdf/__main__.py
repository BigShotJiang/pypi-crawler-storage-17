"""Make the CLI runnable using python -m decryptpdf."""

from .cli import app

app(prog_name="decryptpdf")
