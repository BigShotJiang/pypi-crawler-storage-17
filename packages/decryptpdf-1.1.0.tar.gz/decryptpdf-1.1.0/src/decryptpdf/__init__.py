__version__ = "1.1.0"
from ._main import decrypt_pdf

__all__ = ["decrypt_pdf"]
