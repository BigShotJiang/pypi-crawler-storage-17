
# 

This sources are adapted from https://github.com/DiedrichsenLab/surfAnalysisPy

# Dependencies

- numpy
- SUITPy
- matplotlib

# License - GPL-3.0 license


