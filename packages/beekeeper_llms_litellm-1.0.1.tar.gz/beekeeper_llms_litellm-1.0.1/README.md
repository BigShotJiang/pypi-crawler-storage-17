# Beekeeper llms extension - LiteLLM

## Installation 

```bash
pip install beekeeper-llms-litellm
```
