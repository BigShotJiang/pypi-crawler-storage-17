# Snippet

Test

```md {.snippet width="65%"}
---
press:
  paper:
    format: a5
    orientation: landscape
  frame: true
template: article
fragments:
  ts-frame

---

The HTML specification is maintained by the W3C.

*[HTML]: HyperText Markup Language
*[W3C]: World Wide Web Consortium
```
