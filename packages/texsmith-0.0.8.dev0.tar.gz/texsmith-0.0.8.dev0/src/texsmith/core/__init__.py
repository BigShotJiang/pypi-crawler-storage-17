"""Core domain layer for TexSmith."""

from __future__ import annotations


__all__ = []
