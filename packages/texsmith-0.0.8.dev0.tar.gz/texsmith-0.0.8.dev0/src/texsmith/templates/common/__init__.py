"""Shared LaTeX assets reused by built-in templates."""
