# Plumbing

This section dives into the inner workings of TeXSmith, exploring its architecture, core components, and the mechanisms that enable its seamless integration of Markdown and LaTeX. Whether you're curious about how TeXSmith processes documents or interested in extending its capabilities, this guide provides a comprehensive overview of the plumbing that powers TeXSmith.
