# Generated Examples

This folder contains generated examples. Run the following command to regenerate them before running the documentation build:

```bash
uv run ./scripts/generate_examples.py
```