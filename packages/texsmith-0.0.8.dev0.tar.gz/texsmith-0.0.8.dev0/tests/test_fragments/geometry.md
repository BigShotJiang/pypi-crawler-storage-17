---
press:
  paper:
    format: a5
    orientation: landscape
    frame: true
    margin:
      left: 3cm
      bottom: 5
    watermark: "FOOBAR"
---
# Geometry Fragment Test

This is a test of the geometry fragment.
