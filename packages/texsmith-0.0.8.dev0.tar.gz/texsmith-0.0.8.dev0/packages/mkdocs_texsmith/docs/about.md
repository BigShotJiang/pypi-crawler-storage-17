# About

This plugin provides a seamless way to convert your MkDocs documentation into a LaTeX document, which can then be compiled into a PDF. It leverages the power of TeXSmith to handle the conversion process, ensuring high-quality output that adheres to LaTeX standards.
