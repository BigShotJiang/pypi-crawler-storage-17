# Salesforce changelog

## [0.1.17] - 2025-12-19
- Updated connector definition (YAML version 1.0.3)
- Source commit: 12f6b994
- SDK version: 0.1.0

## [0.1.16] - 2025-12-19
- Updated connector definition (YAML version 1.0.3)
- Source commit: 5d11bfdf
- SDK version: 0.1.0

## [0.1.15] - 2025-12-19
- Updated connector definition (YAML version 1.0.3)
- Source commit: e996e848
- SDK version: 0.1.0

## [0.1.14] - 2025-12-18
- Updated connector definition (YAML version 1.0.3)
- Source commit: f7c55d3e
- SDK version: 0.1.0

## [0.1.13] - 2025-12-17
- Updated connector definition (YAML version 1.0.3)
- Source commit: af456521
- SDK version: 0.1.0

## [0.1.12] - 2025-12-17
- Updated connector definition (YAML version 1.0.3)
- Source commit: 6a6c981e
- SDK version: 0.1.0

## [0.1.11] - 2025-12-15
- Updated connector definition (YAML version 1.0.3)
- Source commit: c4c39c27
- SDK version: 0.1.0

## [0.1.10] - 2025-12-15
- Updated connector definition (YAML version 1.0.3)
- Source commit: 85f4e6b0
- SDK version: 0.1.0

## [0.1.9] - 2025-12-15
- Updated connector definition (YAML version 1.0.3)
- Source commit: 0bfa6500
- SDK version: 0.1.0

## [0.1.8] - 2025-12-15
- Updated connector definition (YAML version 1.0.3)
- Source commit: ea5a02a3
- SDK version: 0.1.0

## [0.1.7] - 2025-12-15
- Updated connector definition (YAML version 1.0.3)
- Source commit: f13dee0a
- SDK version: 0.1.0

## [0.1.6] - 2025-12-15
- Updated connector definition (YAML version 1.0.3)
- Source commit: d79da1e7
- SDK version: 0.1.0

## [0.1.5] - 2025-12-15
- Updated connector definition (YAML version 1.0.3)
- Source commit: 06e7d5c6
- SDK version: 0.1.0

## [0.1.4] - 2025-12-13
- Updated connector definition (YAML version 1.0.3)
- Source commit: 1ab72bd8
- SDK version: 0.1.0

## [0.1.3] - 2025-12-12
- Updated connector definition (YAML version 1.0.3)
- Source commit: 4d366cb5
- SDK version: 0.1.0

## [0.1.2] - 2025-12-12
- Updated connector definition (YAML version 1.0.2)
- Source commit: dc79dc8b
- SDK version: 0.1.0

## [0.1.1] - 2025-12-12
- Updated connector definition (YAML version 1.0.2)
- Source commit: 244fd1c6
- SDK version: 0.1.0

## [0.1.0] - 2025-12-12
- Updated connector definition (YAML version 1.0.1)
- Source commit: e71241ac
- SDK version: 0.1.0
