def check (cmd ,mf ):
    m =mf .findNode ("gcloud")
    if m is None or m .filename is None :
        return None 





    return {"includes":["google.api"]}
