PutRubricAssignmentData
=======================

.. currentmodule:: codegrade.models.put_rubric_assignment_data

.. autoclass:: PutRubricAssignmentData
   :members: max_points, rows
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
