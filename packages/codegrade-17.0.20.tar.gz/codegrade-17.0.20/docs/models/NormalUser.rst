NormalUser
==========

.. currentmodule:: codegrade.models.normal_user

.. autoclass:: NormalUser
   :members: type, name, is_test_student
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
