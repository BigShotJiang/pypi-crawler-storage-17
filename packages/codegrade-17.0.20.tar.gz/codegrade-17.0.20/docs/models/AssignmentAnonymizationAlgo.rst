AssignmentAnonymizationAlgo
===========================

.. currentmodule:: codegrade.models.assignment_anonymization_algo

.. class:: AssignmentAnonymizationAlgo

**Options**

* ``murmur_v3``
