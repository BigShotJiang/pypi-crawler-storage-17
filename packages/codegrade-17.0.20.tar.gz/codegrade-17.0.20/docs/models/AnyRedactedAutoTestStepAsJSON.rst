AnyRedactedAutoTestStepAsJSON
=============================

.. currentmodule:: codegrade.models.any_redacted_auto_test_step_as_json

.. autoclass:: AnyRedactedAutoTestStepAsJSON
   :members: redacted, type, data
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
