AtImageCachingEnabledSetting
============================

.. currentmodule:: codegrade.models.at_image_caching_enabled_setting

.. autoclass:: AtImageCachingEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
