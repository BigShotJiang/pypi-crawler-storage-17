BaseCoupon
==========

.. currentmodule:: codegrade.models.base_coupon

.. autoclass:: BaseCoupon
   :members: id, created_at, limit, used_amount
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
