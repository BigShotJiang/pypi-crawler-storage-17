CsvLargeFileLimitSetting
========================

.. currentmodule:: codegrade.models.csv_large_file_limit_setting

.. autoclass:: CsvLargeFileLimitSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
