AssignmentDoneType
==================

.. currentmodule:: codegrade.models.assignment_done_type

.. class:: AssignmentDoneType

**Options**

* ``assigned_only``
* ``all_graders``
