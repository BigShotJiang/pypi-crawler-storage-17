CreateOutputHtmlProxyAutoTestData
=================================

.. currentmodule:: codegrade.models.create_output_html_proxy_auto_test_data

.. autoclass:: CreateOutputHtmlProxyAutoTestData
   :members: allow_remote_resources, allow_remote_scripts
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
