CreateCommentReplyData
======================

.. currentmodule:: codegrade.models.create_comment_reply_data

.. autoclass:: CreateCommentReplyData
   :members: comment, reply_type, in_reply_to
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
