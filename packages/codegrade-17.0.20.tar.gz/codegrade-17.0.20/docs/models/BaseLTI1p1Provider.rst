BaseLTI1p1Provider
==================

.. currentmodule:: codegrade.models.base_lti1p1_provider

.. autoclass:: BaseLTI1p1Provider
   :members: lms, version, supports_lock_date
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
