PatchCommentReplyData
=====================

.. currentmodule:: codegrade.models.patch_comment_reply_data

.. autoclass:: PatchCommentReplyData
   :members: comment
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
