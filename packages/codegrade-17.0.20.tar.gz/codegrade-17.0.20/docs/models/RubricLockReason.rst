RubricLockReason
================

.. currentmodule:: codegrade.models.rubric_lock_reason

.. class:: RubricLockReason

**Options**

* ``auto_test``
* ``auto_test_2``
