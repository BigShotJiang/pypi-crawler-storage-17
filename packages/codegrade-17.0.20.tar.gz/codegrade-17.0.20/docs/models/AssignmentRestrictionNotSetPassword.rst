AssignmentRestrictionNotSetPassword
===================================

.. currentmodule:: codegrade.models.assignment_restriction_not_set_password

.. autoclass:: AssignmentRestrictionNotSetPassword
   :members: tag
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
