AssignmentKind
==============

.. currentmodule:: codegrade.models.assignment_kind

.. class:: AssignmentKind

**Options**

* ``normal``
* ``exam``
