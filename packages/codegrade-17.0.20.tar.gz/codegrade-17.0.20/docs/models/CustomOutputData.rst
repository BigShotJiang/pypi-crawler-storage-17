CustomOutputData
================

.. currentmodule:: codegrade.models.custom_output_data

.. autoclass:: CustomOutputData
   :members: program, regex
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
