AutoTestStepBaseInputAsJSON
===========================

.. currentmodule:: codegrade.models.auto_test_step_base_input_as_json

.. autoclass:: AutoTestStepBaseInputAsJSON
   :members: id, description
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
