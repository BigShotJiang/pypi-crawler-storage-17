NameAndEmailFromNrpsOnlySetting
===============================

.. currentmodule:: codegrade.models.name_and_email_from_nrps_only_setting

.. autoclass:: NameAndEmailFromNrpsOnlySetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
