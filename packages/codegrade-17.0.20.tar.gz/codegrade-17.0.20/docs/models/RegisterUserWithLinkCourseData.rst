RegisterUserWithLinkCourseData
==============================

.. currentmodule:: codegrade.models.register_user_with_link_course_data

.. autoclass:: RegisterUserWithLinkCourseData
   :members: username, password, email, name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
