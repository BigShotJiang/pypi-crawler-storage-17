BlackboardZipUploadEnabledSetting
=================================

.. currentmodule:: codegrade.models.blackboard_zip_upload_enabled_setting

.. autoclass:: BlackboardZipUploadEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
