RubricAnalyticsData
===================

.. currentmodule:: codegrade.models.rubric_analytics_data

.. autoclass:: RubricAnalyticsData
   :members: tag, rows
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
