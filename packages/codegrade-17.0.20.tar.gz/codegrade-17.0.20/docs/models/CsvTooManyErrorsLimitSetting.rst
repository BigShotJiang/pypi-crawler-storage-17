CsvTooManyErrorsLimitSetting
============================

.. currentmodule:: codegrade.models.csv_too_many_errors_limit_setting

.. autoclass:: CsvTooManyErrorsLimitSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
