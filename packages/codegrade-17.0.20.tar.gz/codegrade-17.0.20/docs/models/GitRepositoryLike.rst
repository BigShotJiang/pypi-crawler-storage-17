GitRepositoryLike
=================

.. currentmodule:: codegrade.models.git_repository_like

.. autoclass:: GitRepositoryLike
   :members: id, name, url, is_template, is_private
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
