AutoTestStepResultState
=======================

.. currentmodule:: codegrade.models.auto_test_step_result_state

.. class:: AutoTestStepResultState

**Options**

* ``not_started``
* ``running``
* ``passed``
* ``failed``
* ``timed_out``
* ``skipped``
