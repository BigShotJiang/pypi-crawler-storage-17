NewAutoTestTestOutputLimitSetting
=================================

.. currentmodule:: codegrade.models.new_auto_test_test_output_limit_setting

.. autoclass:: NewAutoTestTestOutputLimitSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
