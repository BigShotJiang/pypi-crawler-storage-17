MaxLargeUploadSizeSetting
=========================

.. currentmodule:: codegrade.models.max_large_upload_size_setting

.. autoclass:: MaxLargeUploadSizeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
