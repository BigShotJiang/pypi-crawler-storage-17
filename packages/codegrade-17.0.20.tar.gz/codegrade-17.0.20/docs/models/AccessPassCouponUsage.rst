AccessPassCouponUsage
=====================

.. currentmodule:: codegrade.models.access_pass_coupon_usage

.. autoclass:: AccessPassCouponUsage
   :members: scope, coupon
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
