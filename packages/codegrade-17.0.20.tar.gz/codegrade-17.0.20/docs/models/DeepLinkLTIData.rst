DeepLinkLTIData
===============

.. currentmodule:: codegrade.models.deep_link_lti_data

.. autoclass:: DeepLinkLTIData
   :members: auth_token, name, deadline, lock_date, available_at
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
