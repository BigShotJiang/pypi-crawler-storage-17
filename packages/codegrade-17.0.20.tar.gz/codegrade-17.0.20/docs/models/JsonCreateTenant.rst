JsonCreateTenant
================

.. currentmodule:: codegrade.models.json_create_tenant

.. autoclass:: JsonCreateTenant
   :members: name, abbreviated_name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
