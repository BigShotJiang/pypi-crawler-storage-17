FileType
========

.. currentmodule:: codegrade.models.file_type

.. class:: FileType

**Options**

* ``file``
* ``directory``
