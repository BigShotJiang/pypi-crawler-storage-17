CoursePriceWithRefundData
=========================

.. currentmodule:: codegrade.models.course_price_with_refund_data

.. autoclass:: CoursePriceWithRefundData
   :members: is_repurchase
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
