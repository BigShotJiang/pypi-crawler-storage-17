PatchSnippetData
================

.. currentmodule:: codegrade.models.patch_snippet_data

.. autoclass:: PatchSnippetData
   :members: key, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
