AutoTestQualityComment
======================

.. currentmodule:: codegrade.models.auto_test_quality_comment

.. autoclass:: AutoTestQualityComment
   :members: step_id, result_id, file_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
