LTIAssignmentLaunchData
=======================

.. currentmodule:: codegrade.models.lti_assignment_launch_data

.. autoclass:: LTIAssignmentLaunchData
   :members: type, assignment, submission
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
