BasePurchaseSummary
===================

.. currentmodule:: codegrade.models.base_purchase_summary

.. autoclass:: BasePurchaseSummary
   :members: id, success_at, item_purchase_iteration
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
