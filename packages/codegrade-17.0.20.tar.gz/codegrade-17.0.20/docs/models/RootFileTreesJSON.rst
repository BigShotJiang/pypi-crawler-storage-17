RootFileTreesJSON
=================

.. currentmodule:: codegrade.models.root_file_trees_json

.. autoclass:: RootFileTreesJSON
   :members: teacher, student
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
