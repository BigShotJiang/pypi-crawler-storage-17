PurchaseIteration
=================

.. currentmodule:: codegrade.models.purchase_iteration

.. class:: PurchaseIteration

**Options**

* ``first``
* ``second``
