PatchAutoTestData
=================

.. currentmodule:: codegrade.models.patch_auto_test_data

.. autoclass:: PatchAutoTestData
   :members: json, fixture
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
