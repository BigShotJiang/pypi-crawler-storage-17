InvalidGroupException
=====================

.. currentmodule:: codegrade.models.invalid_group_exception

.. autoclass:: InvalidGroupException
   :members: group
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
