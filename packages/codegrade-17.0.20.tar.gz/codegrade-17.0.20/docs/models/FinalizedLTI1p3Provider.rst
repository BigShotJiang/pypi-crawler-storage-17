FinalizedLTI1p3Provider
=======================

.. currentmodule:: codegrade.models.finalized_lti1p3_provider

.. autoclass:: FinalizedLTI1p3Provider
   :members: finalized
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
