ReleaseMessageMaxTimeSetting
============================

.. currentmodule:: codegrade.models.release_message_max_time_setting

.. autoclass:: ReleaseMessageMaxTimeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
