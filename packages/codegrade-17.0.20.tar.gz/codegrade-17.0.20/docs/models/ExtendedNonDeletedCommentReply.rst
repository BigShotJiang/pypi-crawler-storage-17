ExtendedNonDeletedCommentReply
==============================

.. currentmodule:: codegrade.models.extended_non_deleted_comment_reply

.. autoclass:: ExtendedNonDeletedCommentReply
   :members: author
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
