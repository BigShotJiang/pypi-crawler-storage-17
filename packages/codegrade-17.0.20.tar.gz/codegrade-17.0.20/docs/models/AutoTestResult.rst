AutoTestResult
==============

.. currentmodule:: codegrade.models.auto_test_result

.. autoclass:: AutoTestResult
   :members: id, created_at, updated_at, started_at, work_id, state, points_achieved
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
