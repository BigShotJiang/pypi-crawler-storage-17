AiAssistantEnabledSetting
=========================

.. currentmodule:: codegrade.models.ai_assistant_enabled_setting

.. autoclass:: AiAssistantEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
