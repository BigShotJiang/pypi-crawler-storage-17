QuizViewModesEnabledSetting
===========================

.. currentmodule:: codegrade.models.quiz_view_modes_enabled_setting

.. autoclass:: QuizViewModesEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
