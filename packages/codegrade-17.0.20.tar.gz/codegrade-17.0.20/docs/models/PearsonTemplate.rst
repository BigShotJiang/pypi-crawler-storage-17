PearsonTemplate
===============

.. currentmodule:: codegrade.models.pearson_template

.. autoclass:: PearsonTemplate
   :members: type, id, editable
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
