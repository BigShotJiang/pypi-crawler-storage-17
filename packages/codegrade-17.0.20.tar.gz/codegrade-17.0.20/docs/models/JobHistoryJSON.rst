JobHistoryJSON
==============

.. currentmodule:: codegrade.models.job_history_json

.. autoclass:: JobHistoryJSON
   :members: not_started, active, finished, total_finished
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
