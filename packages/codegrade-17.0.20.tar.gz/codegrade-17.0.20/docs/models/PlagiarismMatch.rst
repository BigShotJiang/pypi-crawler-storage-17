PlagiarismMatch
===============

.. currentmodule:: codegrade.models.plagiarism_match

.. autoclass:: PlagiarismMatch
   :members: id, files, lines
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
