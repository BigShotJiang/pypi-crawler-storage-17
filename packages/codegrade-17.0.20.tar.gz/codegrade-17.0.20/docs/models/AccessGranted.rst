AccessGranted
=============

.. currentmodule:: codegrade.models.access_granted

.. autoclass:: AccessGranted
   :members: tag, grant
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
