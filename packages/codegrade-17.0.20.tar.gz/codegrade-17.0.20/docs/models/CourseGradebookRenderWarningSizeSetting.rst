CourseGradebookRenderWarningSizeSetting
=======================================

.. currentmodule:: codegrade.models.course_gradebook_render_warning_size_setting

.. autoclass:: CourseGradebookRenderWarningSizeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
