RetryGroupSubmissionGradePassbackEnabledSetting
===============================================

.. currentmodule:: codegrade.models.retry_group_submission_grade_passback_enabled_setting

.. autoclass:: RetryGroupSubmissionGradePassbackEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
