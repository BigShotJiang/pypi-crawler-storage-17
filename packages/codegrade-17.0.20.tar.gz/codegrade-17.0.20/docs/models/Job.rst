Job
===

.. currentmodule:: codegrade.models.job

.. autoclass:: Job
   :members: id, state, result
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
