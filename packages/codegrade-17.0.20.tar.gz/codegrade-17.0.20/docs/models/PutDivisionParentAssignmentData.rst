PutDivisionParentAssignmentData
===============================

.. currentmodule:: codegrade.models.put_division_parent_assignment_data

.. autoclass:: PutDivisionParentAssignmentData
   :members: parent_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
