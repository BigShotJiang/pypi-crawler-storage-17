NotificationSetting
===================

.. currentmodule:: codegrade.models.notification_setting

.. autoclass:: NotificationSetting
   :members: options, possible_values
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
