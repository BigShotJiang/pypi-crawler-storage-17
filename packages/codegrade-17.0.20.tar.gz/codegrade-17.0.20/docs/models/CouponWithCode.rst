CouponWithCode
==============

.. currentmodule:: codegrade.models.coupon_with_code

.. autoclass:: CouponWithCode
   :members: scope, course_price
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
