BaseNotification
================

.. currentmodule:: codegrade.models.base_notification

.. autoclass:: BaseNotification
   :members: id, read, reasons, created_at, comment_base_id, work_id, assignment_id, course_id, comment_reply
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
