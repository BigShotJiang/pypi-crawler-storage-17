NotificationCommentReplyNotificationAsJSON
==========================================

.. currentmodule:: codegrade.models.notification_comment_reply_notification_as_json

.. autoclass:: NotificationCommentReplyNotificationAsJSON
   :members: type, file_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
