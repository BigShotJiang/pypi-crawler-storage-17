NewAutoTestDiffViewerEnabledSetting
===================================

.. currentmodule:: codegrade.models.new_auto_test_diff_viewer_enabled_setting

.. autoclass:: NewAutoTestDiffViewerEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
