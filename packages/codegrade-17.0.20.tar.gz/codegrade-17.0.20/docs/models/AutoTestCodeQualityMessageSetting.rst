AutoTestCodeQualityMessageSetting
=================================

.. currentmodule:: codegrade.models.auto_test_code_quality_message_setting

.. autoclass:: AutoTestCodeQualityMessageSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
