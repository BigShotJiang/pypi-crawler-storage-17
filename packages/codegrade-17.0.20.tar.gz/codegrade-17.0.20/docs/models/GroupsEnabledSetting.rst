GroupsEnabledSetting
====================

.. currentmodule:: codegrade.models.groups_enabled_setting

.. autoclass:: GroupsEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
