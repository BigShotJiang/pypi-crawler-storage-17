- Add support for PDF signatures (possible, but no easy because the
  signature certificate is a very particular PDF export option)
