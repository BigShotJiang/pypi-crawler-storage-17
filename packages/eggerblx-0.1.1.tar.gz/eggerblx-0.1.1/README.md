# eggeR

Simple Roblox user API wrapper.

## Install
```bash
pip install eggeR