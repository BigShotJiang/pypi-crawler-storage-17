"""Constants for rtdpy"""

DTTOL = 1e-10
