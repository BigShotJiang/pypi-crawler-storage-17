## 0.6.0

* Add Arbitrary RTD model

## 0.5.3

* Make Axial Dispersion model much faster.
  * Testing indicates ~2 orders of magnitude speed up in some cases.
  * Pin Courant number

## 0.5.2

* Change convolve function to scipy.signal.convolve for speed
