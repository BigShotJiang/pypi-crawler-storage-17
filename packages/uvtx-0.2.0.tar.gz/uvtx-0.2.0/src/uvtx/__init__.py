"""uvtx - A Python task runner built for uv."""

__version__ = "0.2.0"
