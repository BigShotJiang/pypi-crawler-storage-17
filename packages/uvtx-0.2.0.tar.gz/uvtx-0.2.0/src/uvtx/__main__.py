"""Entry point for running pt as a module: python -m pt."""

from uvtx.cli import main

if __name__ == "__main__":
    main()
