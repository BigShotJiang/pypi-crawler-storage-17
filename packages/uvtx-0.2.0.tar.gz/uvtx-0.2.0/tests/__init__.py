"""Tests for pyr."""
