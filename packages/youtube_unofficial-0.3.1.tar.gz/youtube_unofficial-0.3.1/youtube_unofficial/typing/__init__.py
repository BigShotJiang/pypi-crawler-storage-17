"""Typing definitions."""
