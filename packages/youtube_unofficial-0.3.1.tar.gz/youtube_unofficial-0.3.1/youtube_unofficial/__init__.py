"""Unofficial YouTube client."""
from __future__ import annotations

from .client import YouTubeClient

__all__ = ('YouTubeClient',)
__version__ = 'v0.3.1'
