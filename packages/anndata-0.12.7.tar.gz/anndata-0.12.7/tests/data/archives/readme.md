# archives

This directory contains an archive of anndata files written by older versions of the library.
It's for testing backwards compat.
This should really live somewhere else, but it's here for now.

## Directories

Directories with version numbers contain files written by the corresponding version of `anndata`.
