"""Version information for shtym."""

__version__ = "0.2.0"
