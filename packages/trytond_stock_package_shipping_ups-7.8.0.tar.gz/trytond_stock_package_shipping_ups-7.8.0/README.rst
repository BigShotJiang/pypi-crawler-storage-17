##########################
Stock Package Shipping UPS
##########################

The *Stock Package Shipping UPS Module* allows to generate `UPS
<https://www.ups.com/>`_ labels per package using their APIs.

.. toctree::
   :maxdepth: 2

   usage
   configuration
   design
   releases
