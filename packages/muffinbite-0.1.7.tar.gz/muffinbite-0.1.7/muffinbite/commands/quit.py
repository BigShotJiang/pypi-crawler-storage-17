import sys
def quit():
    """
    Exit the MuffinBite
    """
    return sys.exit(0)