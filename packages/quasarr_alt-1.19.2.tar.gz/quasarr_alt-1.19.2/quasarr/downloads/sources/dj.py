# -*- coding: utf-8 -*-
# Quasarr
# Project by https://github.com/rix1337


def get_dj_download_links(shared_state, url, mirror, title):  # signature must align with other download link functions!
    return [url]
