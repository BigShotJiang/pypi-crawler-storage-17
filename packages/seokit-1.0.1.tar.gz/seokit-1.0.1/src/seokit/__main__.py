"""Entry point for python -m seokit."""
from seokit.cli import main

if __name__ == "__main__":
    main()
