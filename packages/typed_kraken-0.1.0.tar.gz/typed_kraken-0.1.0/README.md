# Typed Kraken

> A fully typed, validated async client for the Kraken API

Use *autocomplete* instead of documentation.

🚧 Under construction.