"""
### Typed Kraken
> A fully typed, validated async client for the Kraken API

- Details
"""