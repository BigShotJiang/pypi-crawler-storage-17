"""
CrystalWindow Example Demos
---------------------------
Run demos like this:

    python -m CrystalWindow.examples.<demo_name>

"""
__all__ = ["guitesting", "gravitytest", "windowtesting", "sandbox", "3dsquare", "squaremove,"]
