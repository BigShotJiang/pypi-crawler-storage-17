Modular MIMO simulation implementation with effecient generation of large numbers of channel realizations.

# Installation
```bash
pip install mimophys
```
