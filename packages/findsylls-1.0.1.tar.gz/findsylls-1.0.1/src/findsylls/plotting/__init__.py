from .plot_segmentation import plot_segmentation_result

__all__ = ["plot_segmentation_result"]
