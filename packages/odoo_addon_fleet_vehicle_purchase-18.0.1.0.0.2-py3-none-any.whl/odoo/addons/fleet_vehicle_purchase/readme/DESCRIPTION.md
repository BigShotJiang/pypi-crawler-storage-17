Allow to define fleet vehicles on Purchase Orders in order to inherit
them properly
