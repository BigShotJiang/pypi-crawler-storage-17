## gii.csv

A subset of data taken from the UN's [Gender Inequality Index](http://hdr.undp.org/en/composite/GII).
