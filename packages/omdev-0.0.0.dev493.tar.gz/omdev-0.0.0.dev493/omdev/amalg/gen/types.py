import typing as ta

from ...py.tokens import all as tks


Tokens: ta.TypeAlias = tks.Tokens
