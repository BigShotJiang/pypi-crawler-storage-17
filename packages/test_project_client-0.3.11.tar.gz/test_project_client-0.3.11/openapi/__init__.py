"""OpenAPI specifications bundled with this package."""
