"""
Layer 1: Primitives - Opinionated helper methods for dome
These helpers provide higher-level abstractions over the raw API client.
Each method wraps a Layer 0 operation with the _structured suffix.
"""
from typing import Any, Dict, List, Literal, Optional, Type, TypeVar, Union
from pydantic import BaseModel
from .raw import *

T = TypeVar('T', bound=BaseModel)


class DomePrimitives:
    """
    Opinionated helper methods for dome.

    Generated Layer 1 primitives for 3 operations.
    """

    def __init__(self, default_client: DefaultClient):
        self.default_client = default_client

    async def get_market_price_structured(
        self,
        token_id: str,
        at_time: int = None,
        response_model: Type[T] = None
    ) -> T | Dict[str, Any]:
        """
        Fetches the current market price for a market by `token_id`. When `at_time` is not provided, returns the most real-time price available. When `at_time` is provided, returns the historical market price at that specific timestamp.

**Example Request (with historical timestamp):**
```bash
curl 'https://api.domeapi.io/v1/polymarket/market-price/19701256321759583954581192053894521654935987478209343000964756587964612528044?at_time=1762164600'
```

**Example Request (real-time price):**
```bash
curl 'https://api.domeapi.io/v1/polymarket/market-price/19701256321759583954581192053894521654935987478209343000964756587964612528044'
```
        This is a Layer 1 primitive that wraps the Layer 0 get_market_price() method.
        If response_model is provided, the response will be parsed into that Pydantic model.

        Args:
            token_id: The token ID for the Polymarket market
            at_time: Optional Unix timestamp (in seconds) to fetch a historical market price. If not provided, returns the most real-time price available.
            response_model: Optional Pydantic model to parse the response into
        Returns:
            Parsed response as the specified Pydantic model, or raw Dict if no model provided
        """
        # Call Layer 0 method
        response = await self.default_client.get_market_price(
            token_id=token_id,
            at_time=at_time
        )

        # If no response model specified, return raw response
        if response_model is None:
            return response

        # Parse response into Pydantic model
        try:
            return response_model.model_validate(response)
        except Exception as e:
            raise ValueError(f"Failed to parse response as {response_model.__name__}: {e}")

    async def get_matching_markets_sports_structured(
        self,
        polymarket_market_slug: List[str] = None,
        kalshi_event_ticker: List[str] = None,
        response_model: Type[T] = None
    ) -> T | Dict[str, Any]:
        """
        Find equivalent markets across different prediction market platforms (Polymarket, Kalshi, etc.) for sports events. Provide either one or more Polymarket market slugs or Kalshi event tickers.
        This is a Layer 1 primitive that wraps the Layer 0 get_matching_markets_sports() method.
        If response_model is provided, the response will be parsed into that Pydantic model.

        Args:
            polymarket_market_slug: The Polymarket market slug(s) to find matching markets for. To get multiple markets at once, provide the query param multiple times with different slugs. Can not be combined with kalshi_event_ticker.
            kalshi_event_ticker: The Kalshi event ticker(s) to find matching markets for. To get multiple markets at once, provide the query param multiple times with different tickers. Can not be combined with polymarket_market_slug.
            response_model: Optional Pydantic model to parse the response into
        Returns:
            Parsed response as the specified Pydantic model, or raw Dict if no model provided
        """
        # Call Layer 0 method
        response = await self.default_client.get_matching_markets_sports(
            polymarket_market_slug=polymarket_market_slug,
            kalshi_event_ticker=kalshi_event_ticker
        )

        # If no response model specified, return raw response
        if response_model is None:
            return response

        # Parse response into Pydantic model
        try:
            return response_model.model_validate(response)
        except Exception as e:
            raise ValueError(f"Failed to parse response as {response_model.__name__}: {e}")

    async def get_matching_markets_sports_by_sport_structured(
        self,
        sport: Literal["nfl", "mlb", "cfb", "nba", "nhl"],
        date: str,
        response_model: Type[T] = None
    ) -> T | Dict[str, Any]:
        """
        Find equivalent markets across different prediction market platforms (Polymarket, Kalshi, etc.) for sports events by sport and date.
        This is a Layer 1 primitive that wraps the Layer 0 get_matching_markets_sports_by_sport() method.
        If response_model is provided, the response will be parsed into that Pydantic model.

        Args:
            sport: The sport to find matching markets for
            date: The date to find matching markets for in YYYY-MM-DD format
            response_model: Optional Pydantic model to parse the response into
        Returns:
            Parsed response as the specified Pydantic model, or raw Dict if no model provided
        """
        # Call Layer 0 method
        response = await self.default_client.get_matching_markets_sports_by_sport(
            sport=sport,
            date=date
        )

        # If no response model specified, return raw response
        if response_model is None:
            return response

        # Parse response into Pydantic model
        try:
            return response_model.model_validate(response)
        except Exception as e:
            raise ValueError(f"Failed to parse response as {response_model.__name__}: {e}")
