"""
Our module to generate web resources dynamically to
be able to download them later with a scrapper to be
used in the video edition.
"""
