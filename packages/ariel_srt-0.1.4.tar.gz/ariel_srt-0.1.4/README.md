This is a Python library for our SRT project ARIEL.

We developed the ARIEL-SRT package that is available on PyPI. To install it, run this command in the terminal:

`pip install ariel-srt`

The full package dependencies of ARIEL-SRT can be found in requirements.txt, and the main project repo is available at: https://github.com/shilab-ecnu/ARIEL.
