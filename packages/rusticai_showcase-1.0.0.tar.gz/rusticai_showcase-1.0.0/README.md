# Rustic AI Showcase

Module that showcases Rustic AI capabilities

## Installing

```shell
pip install rusticai-showcase
```

## Building from Source

```shell
poetry install --with dev
poetry build
```
