from cumulusci.utils.deprecation import warn_moved

from .base_task_flow_config import *  # noqa

warn_moved(".base_task_flow_config", ".BaseTaskFlowConfig")
