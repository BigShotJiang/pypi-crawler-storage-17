# VIBE-ANALYSIS.md

*Generated: 2025-12-14 14:06*

This file provides comprehensive analysis of the codebase for AI coding assistants.

## Project Overview

The project provides a Textual‑based terminal UI that lets developers converse with an LLM‑powered coding agent (VibeAcpAgent) via the Agent Communication Protocol, enabling actions such as file browsing, reading/writing, search‑replace, bash execution, and context‑aware autocompletion through a pluggable backend (Mistral or WatsonX). It is aimed at software engineers who want instant, AI‑augmented assistance for navigating, editing, and testing code directly from the command line, with built‑in session handling, approval callbacks, and extensible tooling.

---

## Technology Stack

| Language | Minimum Version | Notes |
|----------|----------------|-------|
| Python   | 3.12           | Declared in `pyproject.toml` (`requires-python = ">=3.12"`). |
| UV       | 0.8.0          | Fast Python package manager used for installation (`tool.uv.required-version`). |
| Hatch    | –              | Build backend (`hatchling`, `hatch-vcs`). |

| Framework / Library | Version Constraint | Primary Use |
|---------------------|--------------------|--------------|
| **Textual** | `>=1.0.0` | TUI framework for the UI (`vibe.cli.textual_ui`). |
| **Rich** | `>=14.0.0` | Rich‑text rendering in the TUI and logs. |
| **Pydantic** | `>=2.12.4` | Data validation & settings models. |
| **Pydantic‑settings** | `>=2.12.0` | Configuration loading from files/env. |
| **httpx** | `>=0.28.1` | Async HTTP client for backend LLM services. |
| **tenacity** | `>=8.2.0` | Retry logic with exponential back‑off. |
| **watchfiles** | `>=1.1.1` | File‑system watcher (`WatchController`). |
| **agent-client-protocol** | `==0.6.3` | ACP (Agent Communication Protocol) implementation. |
| **mcp** | `>=1.14.0` | JSON‑RPC layer used by ACP. |
| **mistralai** | `==1.9.11` | Official Mistral LLM SDK. |
| **aiofiles** | `>=24.1.0` | Async file I/O. |
| **pexpect** | `>=4.9.0` | Subprocess interaction for tool execution. |
| **packaging** | `>=24.1` | Version handling & compatibility utilities. |
| **python-dotenv** | `>=1.0.0` | Loading environment variables from `.env`. |
| **tomli-w** | `>=1.2.0` | Writing TOML configuration files. |
| **pyperclip** | `>=1.11.0` | Clipboard integration for the CLI. |
| **textual‑speedups** | `>=0.2.1` | Optional C extensions that speed up Textual. |
| **respx** | `>=0.22.0` | HTTPX mocking library used in tests. |
| **pre‑commit** | `>=4.2.0` (dev) | Git hook manager. |
| **pyright** | `>=1.1.403` (dev) | Static type checker. |
| **ruff** | `>=0.14.5` (dev) | Linter & formatter. |
| **vulture** | `>=2.14` (dev) | Dead code detection. |
| **typos** | `>=1.34.0` (dev) | Spell‑checking of source. |
| **twine** | `>=5.0.0` (dev) | Publishing to PyPI. |
| **pyinstaller** | `>=6.17.0` (build) | Packaging as a standalone executable. |

| Build / Packaging Tool | Version Constraint | Role |
|------------------------|--------------------|------|
| hatchling | – | Core build backend. |
| hatch‑vcs | – | Version extraction from VCS. |
| editables | – | Editable install support. |
| uv | `>=0.8.0` | Primary package manager for CI/CD. |
| pyinstaller | `>=6.17.0` (optional) | Builds single‑file executables. |
| pre‑commit | `>=4.2.0` (dev) | Runs linting & formatting hooks. |
| twine | `>=5.0.0` (dev) | Uploads distributions to PyPI. |

| Testing Framework / Tool | Version Constraint | Purpose |
|--------------------------|--------------------|---------|
| pytest | `>=8.3.5` (dev) | Core test runner. |
| pytest‑asyncio | `>=1.2.0` (dev) | Async test support. |
| pytest‑timeout | `>=2.4.0` (dev) | Test time‑outs. |
| pytest‑textual‑snapshot | `>=1.1.0` (dev) | Snapshot testing for Textual UI. |
| pytest‑xdist | `>=3.8.0` (dev) | Parallel test execution. |
| respx | `>=0.22.0` (dev) | Mocking HTTPX calls. |
| unittest.mock (stdlib) | – | General test doubles / patching. |

| Linter / Static Analyzer | Version Constraint | Focus |
|--------------------------|--------------------|-------|
| ruff | `>=0.14.5` (dev) | Fast linting & formatting. |
| pyright | `>=1.1.403` (dev) | Type checking. |
| vulture | `>=2.14` (dev) | Dead‑code detection. |
| typos | `>=1.34.0` (dev) | Spell‑checking of identifiers/comments. |

**External Services & Integrations**

- **LLM Providers**
  - **WatsonX** – accessed through the `WatsonXBackend` (custom backend implementation).  
  - **Mistral AI** – accessed via the official `mistralai` SDK.  
  - **Fireworks AI** – used in test fixtures to simulate alternative LLM responses.

- **Agent Communication**
  - **ACP (Agent Communication Protocol)** – JSON‑RPC based protocol over HTTP, powered by `agent-client-protocol` and `mcp`.

- **File‑system Watching**
  - **watchfiles** – monitors project files for external changes (used by `WatchController`).

- **Clipboard Integration**
  - **pyperclip** – platform‑agnostic clipboard handling for the CLI.

- **Environment / Secret Management**
  - **python‑dotenv** – loads API keys (e.g., `MISTRAL_API_KEY`) from `.env` files.

---

## Development Commands

| Task | Command |
|------|----------|
| Install **uv** (if not already installed) | `curl -LsSf https://install.uv.dev | sh` |
| Install project dependencies (editable install with dev extras) | `uv sync --all-extras` |
| Install only runtime dependencies (editable) | `uv pip install -e .` |
| Install only development dependencies (editable) | `uv pip install -e .[dev]` |
| Run the Vibe CLI application (after installing the package) | `vibe` |
| Run the Vibe ACP entry‑point (for ACP testing) | `vibe‑acp` |
| Run the application directly via **uv** without installing | `uv run vibe` |
| Run all tests (including async & snapshot tests) | `uv run pytest -vv` |
| Run a specific test file | `uv run pytest -vv tests/acp/test_write_file.py` |
| Run a specific test function | `uv run pytest -vv tests/acp/test_write_file.py::test_write_file_success` |
| Run tests with coverage report | `uv run pytest --cov=vibe -vv` |
| Lint the codebase with **ruff** | `uv run ruff check .` |
| Auto‑fix lintable issues with **ruff** | `uv run ruff check . --fix` |
| Format code with **ruff** (PEP‑8 compliant) | `uv run ruff format .` |
| Run both linting and formatting in one step | `uv run ruff check . && uv run ruff format .` |
| Build the distribution packages (wheel & sdist) | `uv build` |
| Build using Hatch (alternative) | `hatch build` |
| Publish the built package to PyPI (requires credentials) | `uv publish` |
| Run the helper install script (installs **uv** then the package) | `bash scripts/install.sh` |
| Bump project version (arg: `major`, `minor`, or `patch`) | `python scripts/bump_version.py patch` |
| Run the onboarding flow (interactive UI) | `vibe --onboard` |
| Clean up compiled Python files and caches | `find . -type d -name "__pycache__" -exec rm -rf {} + && find . -type f -name "*.pyc" -delete` |
| Start a live‑reload development server for the UI (requires **watchfiles**) | `uv run watchfiles --watch vibe/ -- python -m vibe.cli.entrypoint` |

---

## Code Style Guidelines

**Code Style Guidelines for the Mistral‑Vibe Project**

---

### 1. Naming Conventions  

| Element | Recommended Style | Example |
|--------|-------------------|----------|
| **Packages & modules** | lower‑case, underscore‑separated if needed | `vibe/cli/commands`, `tests/acp` |
| **Files** | snake_case, `.py` extension | `run_textual_ui.py`, `test_search_replace.py` |
| **Classes & Exceptions** | PascalCase (CapWords) | `VibeApp`, `AcpToolState`, `BackendFactory`, `ConfigurationError` |
| **Functions & Methods** | snake_case, async functions prefixed with `async_` only when the name would be ambiguous (otherwise just normal snake_case) | `run_textual_ui`, `async_get_completion` |
| **Variables & Attributes** | snake_case; boolean flags prefixed with `is_`, `has_`, `should_` | `is_running`, `has_error`, `should_retry` |
| **Constants & Enum members** | UPPER_SNAKE_CASE | `MAX_RETRIES`, `DEFAULT_TIMEOUT`, `class Mode(StrEnum): READ_ONLY = "read_only"` |
| **Type aliases** | PascalCase ending with `Type` (optional) | `JsonRpcMessageType`, `PathLike` |
| **Test fixtures / helpers** | snake_case, prefixed with `make_` or `fake_` when they construct objects | `make_config`, `fake_backend` |

---

### 2. Import Ordering & Organization  

1. **Standard library imports** – grouped together, alphabetically sorted.  
2. **Third‑party imports** – next group, also alphabetically sorted.  
3. **Local package imports** – last group, sorted alphabetically.  

Separate each group with a single blank line.  
Do **not** use relative imports (`from .module import …`); absolute imports are enforced by the `ruff` rule `ban-relative-imports = "all"`.

Example:

```python
import asyncio
import json
import pathlib
from typing import AsyncGenerator, Callable, List

import httpx
import rich
import textual

from vibe.core.config import VibeConfig
from vibe.acp.agent import VibeAcpAgent
```

If an import is only needed for type checking, place it under a `if TYPE_CHECKING:` block.

```python
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vibe.backend.base import BackendLike
```

---

### 3. Type Hinting & Annotations  

* **Strict typing** – every public function, method, and class attribute must be annotated.  
* Use **PEP 585** generic types (`list[int]`, `dict[str, Any]`).  
* For **Pydantic models** and **dataclasses**, annotate all fields; use `Field` or `model_validator` where validation is required.  
* Async generators are annotated as `AsyncGenerator[ItemType, None]`.  
* Callable signatures are explicit, e.g. `Callable[[str, int], Awaitable[bool]]`.  
* When a function returns `None` explicitly, annotate as `-> None`.  
* Prefer `Path` from `pathlib` over `str` for filesystem paths.  

---

### 4. Error Handling Patterns  

* Raise **domain‑specific exceptions** (defined in `vibe/core/exceptions.py` or similar) rather than generic `Exception`.  
* Use **try/except** blocks only around the smallest possible risky call.  
* Preserve the original traceback with `raise ... from err` when re‑wrapping.  
* For transient external calls (HTTP, file I/O) wrap with **tenacity** retry decorators (`@retry`, `@async_retry`).  
* Validate inputs early; raise `ValueError`, `TypeError`, or custom `InvalidArgumentError` with clear messages.  
* Log unexpected errors using the module‑level `logger` (Rich‑styled) before re‑raising or exiting.  

Example:

```python
@async_retry(stop=stop_after_attempt(3), wait=wait_exponential())
async def fetch_completion(prompt: str) -> str:
    try:
        response = await http_client.post(url, json={"prompt": prompt})
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        logger.error("LLM request failed: %s", exc.response.text)
        raise BackendError("Failed to fetch completion") from exc
    return response.json()["completion"]
```

---

### 5. Documentation Style  

* **Docstrings** follow the **Google style** (compatible with `pyright` and Sphinx).  
* Every public class, function, method, and module must have a docstring.  
* Include a short one‑line summary, followed by a blank line, then description, args, returns, raises, and examples where appropriate.  

Example:

```python
def read_file(path: pathlib.Path) -> str:
    """Read the contents of a file.

    Args:
        path: Absolute or relative path to the file to read.

    Returns:
        The file contents as a UTF‑8 decoded string.

    Raises:
        FileNotFoundError: If `path` does not exist.
        PermissionError: If the file cannot be accessed.
    """
    ...
```

* Inline comments are **sentence‑case**, start with a capital letter, and end with a period.  
* Use `# noqa: <rule>` sparingly, only when a rule cannot be satisfied for a justified reason.  

---

### 6. Formatting Rules  

* **Line length:** 88 characters (enforced by `ruff`).  
* **Indentation:** 4 spaces, no tabs.  
* **Trailing commas:** always include for multi‑line collections, function arguments, and imports.  
* **Blank lines:**  
  * Two blank lines before top‑level class or function definitions.  
  * One blank line between method definitions inside a class.  
* **Quotes:** single quotes for strings unless the string contains a single quote, then double quotes.  
* **Boolean literals:** use lowercase `True`/`False` (standard Python).  
* **Operators:** surrounded by single spaces (`a == b`, `x += 1`).  
* **Imports:** sorted alphabetically within groups, as described above.  
* **Unused imports / variables:** must be removed; `ruff` will flag them (`F401`, `F841`).  

All formatting is automatically enforced by the pre‑commit hook configuration:

```yaml
-   repo: https://github.com/charliermarsh/ruff-pre-commit
    rev: v0.14.5
    hooks:
      - id: ruff
        args: [--fix, --exit-non-zero-on-fix]
```

Running `ruff format` and `ruff check --fix` will bring files into compliance.

---

### 7. Asynchronous Code Conventions  

* Use **`async`/`await`** consistently; never mix blocking I/O with async code.  
* All long‑running or I/O‑bound operations should be **awaited**; wrap CPU‑bound work in `run_in_executor` if needed.  
* Async context managers (`async with`) are preferred for resources such as HTTP clients, database sessions, or file handles.  
* Cancelation is propagated via `asyncio.CancelledError`; catch it only at top‑level entry points if cleanup is required.  

---

### 8. Testing Practices (Reflecting Style)  

* Tests live under `tests/` and use **pytest** with the **asyncio** plugin for async code.  
* Test functions are named `test_<behavior>` and use **snake_case**.  
* Fixtures are defined in `conftest.py` or module‑local and are annotated with `@pytest.fixture`.  
* Use **parameterization** (`@pytest.mark.parametrize`) for varied inputs, and **mocking** (`unittest.mock.patch` or `respx`) for external dependencies.  
* Snapshot tests for the Textual UI leverage `pytest-textual-snapshot`.  

---

### 9. Logging & Output  

* The project uses **Rich** for structured, colour‑rich logging.  
* A module‑level logger is created via `logging.getLogger(__name__)` and configured in `vibe/core/logging.py`.  
* Log messages are **sentence‑case**, avoid trailing periods, and include contextual information (e.g., request IDs).  

---

### 10. Miscellaneous Rules  

* **No relative imports** – enforce absolute imports throughout the codebase.  
* **No wildcard imports** (`from module import *`).  
* **All public APIs** are exported via `__all__` where appropriate.  
* **Configuration** is accessed through the singleton‑like `VibeConfig`; direct file I/O is avoided.  
* **Caching** uses `functools.lru_cache` for pure functions (e.g., regex compilation) and a custom LRU for larger structures.  

--- 

Adhering to these guidelines ensures consistency, readability, and smooth operation of the automated tooling (ruff, pre‑commit, mypy/pyright) that underpins the Mistral‑Vibe codebase.

---

## Architecture Overview

High‑level System Design  
The Vibe project is organized as a layered, event‑driven application that sits between a terminal‑based UI (the **TUI**) and one or more remote **LLM** services.  The core layers are:

* **User Interface Layer** – implemented with Textual (the **TUI**) and Rich for styling.  It is responsible for rendering widgets, capturing key bindings, and exposing a **CommandRegistry** that maps textual commands to concrete actions.  UI components subscribe to **SessionNotification** events (Observer pattern) to stay in sync with the agent state.

* **Agent Layer** – the **VibeAcpAgent** implements the **ACP** (Agent Communication Protocol).  It receives JSON‑RPC messages from the UI, orchestrates tool execution, maintains per‑user **AcpSession** objects, and streams LLM responses back to the UI.  The agent follows the Template Method pattern for its conversation loop and uses a **MiddlewarePipeline** (Chain of Responsibility) to pre‑process incoming ACP messages.

* **Tooling Layer** – tools inherit from **BaseTool** (Template Method) and declare their metadata, input validation (via Pydantic), and a concrete `run` method.  Each tool has an associated **AcpToolState** subclass that persists invocation state across sessions.  Tool execution can request user approval via an **ApprovalCallback**, which is wired to the **ApprovalApp** UI component.

* **Backend Layer** – concrete backend implementations (e.g., `WatsonXBackend`, `OpenAIBackend`) satisfy the **BackendLike** protocol.  They are created by the **BackendFactory** (Factory pattern) and communicate with remote LLM services using **httpx** (asynchronous HTTP client).  Network calls are wrapped with tenacity‑based retry logic and token‑refresh strategies.

* **Configuration & Persistence Layer** – the singleton‑like **VibeConfig** loads settings from `config.toml`, environment variables, and defaults via **pydantic‑settings**.  Configuration migration logic lives in `vibe/core/config.py`.  Caches (LRU for compiled regexes, cache‑aside for index data) and the **Repository** pattern (e.g., version‑update cache) isolate data‑access concerns.

* **File‑system Watcher** – the **WatchController** uses `watchfiles` to push external file changes into the UI as **SessionNotification** events, keeping the index and completions up‑to‑date.

Key Abstractions & Design Patterns  
- **Singleton** – module‑level logger and the global `VibeConfig` instance.  
- **Factory / Builder** – `BackendFactory`, `VibeConfig` builder, `IndexBuilder`, UI widget factories in `compose()`.  
- **Strategy** – pluggable result renderers, backend compatibility validators, completion managers.  
- **Observer** – UI widgets subscribe to `Message`/`SessionNotification` events; the agent notifies via callbacks.  
- **Command pattern** – `CommandRegistry` maps textual commands and key bindings to callable actions dispatched by the UI.  
- **Chain of Responsibility** – `MiddlewarePipeline` processes ACP messages before they reach the agent.  
- **Template Method** – `BaseTool.run`, `VibeAcpAgent.conversation_loop`, and various abstract base classes.  
- **Adapter** – `ToolUIDataAdapter` converts tool result models into UI‑friendly structures; backend adapters translate vendor APIs to `BackendLike`.  
- **Composite** – `MultiCompleter` aggregates multiple `Completer` instances (path, command, fuzzy).  
- **Repository** – version‑update cache and other storage abstractions isolate persistence logic.  
- **Retry / Tenacity** – network resilience for backend calls.  
- **Async Context Manager / Generator** – used for HTTP client lifecycles and streaming LLM completions.  

Data Flow / Request Lifecycle  
1. **User Input** – a key press or command is captured by the TUI, routed through `CommandRegistry`, and may trigger an ACP request (e.g., tool invocation).  
2. **ACP Message Creation** – the UI builds a JSON‑RPC payload respecting the **ACP** schema and sends it over the internal ACP channel to the active `AcpSession`.  
3. **Middleware Processing** – the message traverses `MiddlewarePipeline`; middleware can augment, validate, or short‑circuit the request.  
4. **Agent Handling** – `VibeAcpAgent` parses the JSON‑RPC method, looks up the corresponding `BaseTool` subclass, and constructs an `AcpToolState` instance to track execution.  
5. **Tool Execution** – the tool’s `run` method may call external resources (e.g., filesystem, subprocess) and/or invoke the **Backend** for LLM completions.  If the tool requires user consent, it fires an `ApprovalCallback` that displays a modal UI via `ApprovalApp`.  
6. **Backend Interaction** – the selected backend sends an HTTP request (via `httpx`) to the remote LLM service.  Responses are streamed back as async generators, wrapped with tenacity retry logic.  
7. **Result Propagation** – tool results are serialized into an ACP response, stored in the associated `AcpToolState`, and sent back through the ACP channel.  
8. **UI Update** – the UI receives a `SessionNotification` (e.g., `AgentPlanUpdate`, `AgentStats`), the observer callbacks update relevant widgets, and the chat view reflects the new assistant messages or tool outputs.  

Critical Files & Their Roles  
- `vibe/cli/textual_ui/app.py` – entry point for the TUI (`run_textual_ui`), composes the main UI layout, wires the `CommandRegistry`, and connects the UI to the ACP agent.  
- `vibe/acp/acp_agent.py` – core implementation of the ACP agent, session management, middleware integration, and tool orchestration.  
- `vibe/core/agent.py` – defines abstract agent interfaces and common utilities shared by ACP and future agents.  
- `vibe/core/config.py` – singleton `VibeConfig` loader, migration logic, and environment handling.  
- `vibe/tools/base.py` – `BaseTool` definition, metadata handling, and the Template Method for tool execution.  
- `vibe/tools/*` – concrete tool implementations (`bash`, `read_file`, `search_replace`, etc.).  
- `vibe/backends/*` – backend implementations (`watsonx.py`, `openai.py`) adhering to `BackendLike`.  
- `vibe/middleware/*` – middleware components that enrich or guard ACP messages.  
- `vibe/cli/commands/CommandRegistry.py` – registry mapping textual commands to callables.  
- `vibe/cli/init/*` – onboarding flow, configuration bootstrap, and progress UI.  
- `vibe/watchfiles/controller.py` – `WatchController` for filesystem event propagation.  
- `vibe/acp/entrypoint.py` – `vibe-acp` CLI that launches the ACP server for external clients.  

Entry Points  
- `vibe.cli.entrypoint:main` (`vibe` command) – launches the full Textual UI, performs onboarding if needed, and starts the ACP agent loop.  
- `vibe.acp.entrypoint:main` (`vibe-acp` command) – starts a lightweight ACP server that can be driven by external tools or IDE extensions.  

Overall, the architecture cleanly separates concerns: the UI layer handles presentation and user interaction; the agent layer mediates between UI and tools; the tooling layer encapsulates domain actions; the backend layer abstracts remote LLM services; and the configuration/repository layer provides consistent, testable state management.  The extensive use of well‑known design patterns (Factory, Builder, Strategy, Observer, Middleware, Template Method) ensures extensibility, testability (via `FakeBackend`, `FakeTool`, and extensive pytest suites), and maintainability across the codebase.

---

## File Contracts & Dependencies

*This section documents the relationships and contracts between files in the codebase.*


### Hub Files

*Files with the most connections (imports, dependencies, calls)*


| File | Connections |
|------|-------------|
| `vibe/core/agent.py` | 83 |
| `vibe/cli/textual_ui/app.py` | 75 |
| `vibe/acp/acp_agent.py` | 62 |
| `vibe/core/config.py` | 56 |
| `vibe/core/types.py` | 49 |
| `vibe/core/tools/base.py` | 44 |
| `vibe/core/utils.py` | 40 |
| `vibe/acp/tools/builtins/bash.py` | 35 |
| `tests/test_agent_observer_streaming.py` | 33 |
| `vibe/acp/tools/base.py` | 30 |


### Configuration Dependencies

*Config files and which source files depend on them*


**`.env`** used by:
- `vibe/core/config.py`
- `vibe/core/config_path.py`
- `vibe/setup/onboarding/__init__.py`
- `vibe/setup/onboarding/screens/watsonx_setup.py`
- `vibe/setup/onboarding/screens/api_key.py`

**`.env (global env file)`** used by:
- `tests/onboarding/test_ui_onboarding.py`

**`.env (via load_api_keys_from_env)`** used by:
- `vibe/acp/acp_agent.py`

**`.gitignore`** used by:
- `vibe/core/system_prompt.py`
- `vibe/core/autocompletion/file_indexer/ignore_rules.py`
- `vibe/cli/init/discovery.py`

**`.ignore`** used by:
- `tests/tools/test_grep.py`

**`.pre-commit-config.yaml`** used by:
- `.github/workflows/ci.yml`

**`.python-version`** used by:
- `action.yml`

**`.vibe/config.toml`** used by:
- `tests/core/test_config_resolution.py`
- `tests/acp/test_acp.py`

**`.vibeignore`** used by:
- `tests/tools/test_grep.py`
- `vibe/core/tools/builtins/grep.py`

**`.vscode/launch.json`** used by:
- `scripts/bump_version.py`

**`CONFIG_FILE (typically ~/.vibe/config.toml)`** used by:
- `vibe/cli/entrypoint.py`

**`CONFIG_FILE.path`** used by:
- `vibe/core/utils.py`

**`GLOBAL_CONFIG_FILE.path`** used by:
- `vibe/core/utils.py`

**`HISTORY_FILE (typically ~/.vibe/history.txt)`** used by:
- `vibe/cli/entrypoint.py`

**`INSTRUCTIONS_FILE (path defined in vibe/core/config_path.py)`** used by:
- `vibe/core/system_prompt.py`

**`INSTRUCTIONS_FILE (typically ~/.vibe/instructions.txt)`** used by:
- `vibe/cli/entrypoint.py`

**`VIBE-ANALYSIS.json`** used by:
- `vibe/core/context_injector.py`

**`VIBE-ANALYSIS.md`** used by:
- `vibe/core/context_injector.py`

**`VibeConfig loads its own configuration files (e.g., viberc.toml, not listed directly here)`** used by:
- `vibe/cli/textual_ui/app.py`

**`agents/*.toml`** used by:
- `vibe/core/config.py`

**`config.toml`** used by:
- `tests/conftest.py`
- `tests/core/test_config_migration.py`
- `tests/core/test_config_resolution.py`
- `vibe/core/config.py`
- `vibe/core/config_path.py`

**`config.toml (global config file)`** used by:
- `tests/onboarding/test_ui_onboarding.py`

**`distribution/zed/extension.toml`** used by:
- `scripts/bump_version.py`

**`history file (path defined by vibe.core.config_path.HISTORY_FILE)`** used by:
- `vibe/cli/textual_ui/app.py`

**`instructions.md`** used by:
- `vibe/core/config_path.py`

**`pyproject.toml`** used by:
- `scripts/bump_version.py`

**`tests/acp/test_initialize.py`** used by:
- `scripts/bump_version.py`

**`uv.lock`** used by:
- `.github/workflows/ci.yml`

**`vibe.log`** used by:
- `vibe/core/config_path.py`

**`vibe/core/__init__.py`** used by:
- `scripts/bump_version.py`

**`vibehistory`** used by:
- `vibe/core/config_path.py`


### Resource Dependencies

*Templates, static files, and data files*


**`.vscode/launch.json`** loaded by:
- `scripts/bump_version.py`

**`LOG_DIR.path (directory for log file)`** loaded by:
- `vibe/core/utils.py`

**`LOG_FILE.path (log output file)`** loaded by:
- `vibe/core/utils.py`

**`Project documentation files listed in PROJECT_DOC_FILENAMES (e.g., README.md, README.rst, docs/*)`** loaded by:
- `vibe/core/system_prompt.py`

**`UtilityPrompt.DANGEROUS_DIRECTORY template file`** loaded by:
- `vibe/core/system_prompt.py`

**`UtilityPrompt.PROJECT_CONTEXT template file`** loaded by:
- `vibe/core/system_prompt.py`

**`app.tcss (CSS stylesheet for the Textual UI)`** loaded by:
- `vibe/cli/textual_ui/app.py`

**`core/prompts/*.md`** loaded by:
- `vibe/core/prompts/__init__.py`

**`core/tools/builtins/prompts/bash.md`** loaded by:
- `vibe/acp/tools/builtins/bash.py`

**`core/tools/builtins/prompts/read_file.md`** loaded by:
- `vibe/acp/tools/builtins/read_file.py`

**`core/tools/builtins/prompts/search_replace.md`** loaded by:
- `vibe/acp/tools/builtins/search_replace.py`

**`core/tools/builtins/prompts/todo.md`** loaded by:
- `vibe/acp/tools/builtins/todo.py`

**`core/tools/builtins/prompts/write_file.md`** loaded by:
- `vibe/acp/tools/builtins/write_file.py`

**`distribution/zed/extension.toml`** loaded by:
- `scripts/bump_version.py`

**`icons/mistral_vibe.svg`** loaded by:
- `distribution/zed/extension.toml`

**`onboarding.tcss`** loaded by:
- `vibe/setup/onboarding/__init__.py`

**`prompts/*.md`** loaded by:
- `vibe/core/config.py`
- `vibe/core/tools/base.py`

**`prompts/utility/compact.md`** loaded by:
- `vibe/core/agent.py`

**`pyproject.toml`** loaded by:
- `scripts/bump_version.py`

**`snapshot_report.html`** loaded by:
- `.github/workflows/ci.yml`

**`system_prompt/template.md`** loaded by:
- `vibe/core/agent.py`

**`tests/acp/test_initialize.py`** loaded by:
- `scripts/bump_version.py`

**`update_cache.json`** loaded by:
- `vibe/cli/update_notifier/adapters/filesystem_update_cache_repository.py`

**`vibe-acp.spec`** loaded by:
- `.github/workflows/build-and-upload.yml`

**`vibe/core/__init__.py`** loaded by:
- `scripts/bump_version.py`


### Environment Variables

*Environment variables used across the codebase*


| Variable | Used By |
|----------|---------|
| `(dynamic) provider.api_key_env_var – the name of the environment variable that holds the API key` | `vibe/core/llm/backend/watsonx/backend.py` |
| `<provider>.api_key_env_var (dynamic environment variable name for the API key)` | `vibe/setup/onboarding/screens/api_key.py` |
| `API keys accessed indirectly via load_api_keys_from_env (e.g., MISTRAL_API_KEY, OPENAI_API_KEY, etc.)` | `vibe/acp/acp_agent.py` |
| `API_KEY` | `tests/backend/test_backend.py` |
| `Any environment variable name specified by provider.api_key_env_var (accessed via os.getenv)` | `vibe/core/llm/backend/generic.py` |
| `CI` | `vibe/core/tools/builtins/bash.py` |
| `COMSPEC` | `tests/test_system_prompt.py`, `vibe/core/system_prompt.py` |
| `DEBIAN_FRONTEND` | `vibe/core/tools/builtins/bash.py` |
| `Environment variables accessed indirectly via load_api_keys_from_env (e.g., MISTRAL_API_KEY, ANTHROPIC_API_KEY, etc.)` | `vibe/cli/entrypoint.py` |
| `GITHUB_OUTPUT` | `.github/workflows/build-and-upload.yml` |
| `GITHUB_PATH` | `.github/workflows/ci.yml` |
| `GIT_PAGER` | `vibe/core/tools/builtins/bash.py` |
| `HOME` | `scripts/install.sh` |
| `LC_ALL` | `vibe/core/tools/builtins/bash.py` |
| `LECHAT_API_KEY` | `tests/test_agent_stats.py` |
| `LESS` | `vibe/core/tools/builtins/bash.py` |
| `MISTRAL_API_KEY` | `tests/conftest.py`, `tests/test_agent_stats.py`, `tests/acp/test_acp.py` (+3) |
| `NONINTERACTIVE` | `vibe/core/tools/builtins/bash.py` |
| `NO_COLOR` | `vibe/core/tools/builtins/bash.py` |
| `NO_TTY` | `vibe/core/tools/builtins/bash.py` |
| `PAGER` | `vibe/core/tools/builtins/bash.py` |
| `PATH` | `scripts/install.sh` |
| `PROMPT_INPUT` | `action.yml` |
| `PYTHON_VERSION` | `.github/workflows/ci.yml` |
| `ProviderConfig.api_key_env_var (environment variable holding the Mistral API key)` | `vibe/core/llm/backend/mistral.py` |
| `SHELL` | `tests/conftest.py` |
| `TERM` | `vibe/core/tools/builtins/bash.py` |
| `TMUX` | `tests/cli/test_clipboard.py`, `vibe/cli/clipboard.py` |
| `VIBE_* (prefixed variables for settings)` | `vibe/core/config.py` |
| `VIBE_HOME` | `tests/core/test_config_resolution.py`, `tests/acp/test_acp.py`, `vibe/core/config_path.py` |
| `VIBE_MOCK_LLM_DATA` | `tests/mock/mock_entrypoint.py`, `tests/mock/utils.py` |
| `WATSONX_API_KEY` | `vibe/core/config.py`, `vibe/setup/onboarding/screens/watsonx_setup.py`, `vibe/setup/onboarding/screens/model_selection.py` |
| `WATSONX_ENDPOINT` | `vibe/core/llm/backend/watsonx/backend.py` |
| `WATSONX_PROJECT_ID` | `vibe/core/llm/backend/watsonx/backend.py`, `vibe/setup/onboarding/screens/watsonx_setup.py` |
| `WATSONX_REGION` | `vibe/core/llm/backend/watsonx/backend.py`, `vibe/setup/onboarding/screens/watsonx_setup.py`, `vibe/setup/onboarding/screens/model_selection.py` |
| `os.environ entry set at runtime for the same variable` | `vibe/setup/onboarding/screens/api_key.py` |


### Internal Import Graph

*How project files import from each other*

- `vibe/cli/textual_ui/app.py` → `vibe/cli/textual_ui/widgets/messages/UserMessage.py`, `vibe/core/__version__ as CORE_VERSION.py`, `vibe/cli/update_notifier/UpdateCacheRepository.py`, `vibe/cli/textual_ui/widgets/context_progress/TokenState.py`, `vibe/cli/update_notifier/FileSystemUpdateCacheRepository.py` (+41)
- `vibe/core/agent.py` → `vibe/core/tools/base/BaseTool.py`, `vibe/core/llm/backend/factory/BACKEND_FACTORY.py`, `vibe/core/tools/manager/ToolManager.py`, `vibe/core/utils/TOOL_ERROR_TAG.py`, `vibe/core/config/VibeConfig.py` (+39)
- `vibe/acp/acp_agent.py` → `acp/schema/ToolCall.py`, `acp/schema/PromptCapabilities.py`, `acp/schema/SessionModelState.py`, `acp/schema/ModelInfo.py`, `acp/schema/TextContentBlock.py` (+32)
- `tests/test_agent_observer_streaming.py` → `vibe/core/config/VibeConfig.py`, `vibe/core/tools/builtins/todo/TodoArgs.py`, `vibe/core/middleware/ResetReason.py`, `vibe/core/utils/CancellationReason.py`, `vibe/core/middleware/MiddlewareAction.py` (+20)
- `tests/test_agent_tool_call.py` → `vibe/core/config/VibeConfig.py`, `vibe/core/types/BaseEvent.py`, `vibe/core/types/SyncApprovalCallback.py`, `vibe/core/agent/Agent.py`, `vibe/core/tools/base/ToolPermission.py` (+14)
- `vibe/acp/tools/builtins/bash.py` → `vibe/core/tools/builtins/bash/Bash as CoreBashTool.py`, `acp/schema/EnvVariable.py`, `vibe/acp/tools/base/BaseAcpTool.py`, `vibe/core/tools/builtins/bash/BashArgs.py`, `acp/CreateTerminalRequest.py` (+13)
- `vibe/acp/tools/builtins/search_replace.py` → `vibe/acp/tools/base/BaseAcpTool.py`, `acp/schema/ToolCallProgress.py`, `vibe/acp/tools/base/AcpToolState.py`, `vibe/core/tools/builtins/search_replace/SearchReplaceArgs.py`, `acp/schema/ToolCallLocation.py` (+12)
- `vibe/acp/tools/builtins/todo.py` → `acp/schema/PlanEntryPriority.py`, `vibe/core/tools/builtins/todo/TodoStatus.py`, `vibe/core/tools/builtins/todo/TodoArgs.py`, `vibe/core/tools/builtins/todo/Todo as CoreTodoTool.py`, `vibe/acp/tools/base/BaseAcpTool.py` (+11)
- `vibe/cli/textual_ui/renderers/tool_renderers.py` → `vibe/cli/textual_ui/widgets/tool_widgets ToolResultWidget.py`, `vibe/cli/textual_ui/widgets/tool_widgets ToolApprovalWidget.py`, `vibe/cli/textual_ui/widgets/tool_widgets BashApprovalWidget.py`, `vibe/cli/textual_ui/widgets/tool_widgets GrepApprovalWidget.py`, `vibe/cli/textual_ui/widgets/tool_widgets ReadFileResultWidget.py` (+10)
- `tests/backend/test_backend.py` → `tests/backend/data/Url.py`, `vibe/core/llm/backend/factory.py`, `tests/backend/data/mistral.py`, `vibe/core/llm/exceptions.py`, `vibe/core/llm/types.py` (+9)
- `tests/acp/test_multi_session.py` → `vibe/core/config/ModelConfig.py`, `tests/stubs/fake_backend/FakeBackend.py`, `acp/PromptRequest.py`, `acp/schema/TextContentBlock.py`, `acp/NewSessionRequest.py` (+9)
- `tests/acp/test_new_session.py` → `acp/SetSessionModelRequest.py`, `vibe/core/types/LLMMessage.py`, `tests/stubs/fake_backend/FakeBackend.py`, `acp/NewSessionRequest.py`, `vibe/core/types/LLMUsage.py` (+9)
- `vibe/cli/entrypoint.py` → `vibe/core/config_path/HISTORY_FILE.py`, `vibe/core/interaction_logger/InteractionLogger.py`, `vibe/setup/onboarding/run_onboarding.py`, `vibe/cli/textual_ui/app/run_textual_ui.py`, `vibe/core/config_path/INSTRUCTIONS_FILE.py` (+9)
- `vibe/acp/tools/session_update.py` → `acp/helpers/ToolCallContentVariant.py`, `vibe/acp/tools/base/ToolResultSessionUpdateProtocol.py`, `vibe/acp/tools/base/ToolCallSessionUpdateProtocol.py`, `acp/schema/TextContentBlock.py`, `acp/schema/ToolKind.py` (+9)
- `tests/acp/test_set_model.py` → `acp/SetSessionModelRequest.py`, `vibe/core/types/LLMMessage.py`, `tests/stubs/fake_backend/FakeBackend.py`, `acp/NewSessionRequest.py`, `vibe/core/types/LLMUsage.py` (+8)


### Cross-File Calls

*Function calls, class instantiations, and inheritance across files*


**Accesses:**
- `tests/test_agent_tool_call.py` → `vibe/core/agent.py` (Tests read and assert on agent.messages, agent.stats, and agent.tool_manager methods.)
- `tests/update_notifier/test_ui_version_update_notification.py` → `vibe/cli/update_notifier.py` (Reads notifier.fetch_update_calls attribute to verify gateway invocation count)

**Calls:**
- `vibe/cli/textual_ui/app.py` → `vibe/cli/init.py` (Calls execute_init() in _run_init() to perform codebase analysis)
- `vibe/cli/textual_ui/app.py` → `vibe/cli/update_notifier.py` (Calls get_update_if_available() in _check_version_update())
- `vibe/cli/textual_ui/app.py` → `vibe/core/autocompletion/path_prompt_adapter.py` (Calls render_path_prompt() in _handle_agent_turn())
- `vibe/cli/textual_ui/app.py` → `vibe/cli/clipboard.py` (Calls copy_selection_to_clipboard() in on_mouse_up())
- `vibe/cli/textual_ui/app.py` → `vibe/core/config.py` (Calls VibeConfig.save_updates() in _save_config_changes() and _set_tool_permission_always())
- `vibe/cli/textual_ui/app.py` → `vibe/core/utils.py` (Uses logger, get_user_cancellation_message, is_dangerous_directory, etc.)
- `tests/test_ui_input_history.py` → `vibe/cli/textual_ui/app.py` (Uses VibeApp.run_test() as an async context manager.)
- `tests/test_ui_input_history.py` → `vibe/cli/textual_ui/app.py` (Calls VibeApp.query_one() to retrieve ChatInputBody and ChatInputContainer widgets.)
- `tests/test_ui_pending_user_message.py` → `vibe/cli/textual_ui/app.py` (Calls VibeApp.run_test() to get async pilot context)
- `tests/test_agent_stats.py` → `vibe/core/agent.py` (Calls Agent methods: act, reload_with_initial_messages, compact, clear_history.)
- *...and 147 more*

**Checks_Subclass:**
- `vibe/acp/tools/session_update.py` → `vibe/acp/tools/base.py` (Uses issubclass to see if event.tool_class implements ToolCallSessionUpdateProtocol or ToolResultSessionUpdateProtocol and then calls the corresponding static method.)

**Decorates:**
- `vibe/core/llm/backend/generic.py` → `vibe/core/utils.py` (async_retry and async_generator_retry decorators are applied to _make_request and _make_streaming_request.)

**Imports:**
- `tests/test_cli_programmatic_preload.py` → `vibe/core/types.py` (Uses LLMMessage, OutputFormat, and Role enum/value definitions.)
- `tests/backend/test_backend.py` → `tests/backend/data/fireworks.py` (Imports parameter sets for Fireworks provider test cases.)
- `tests/backend/test_backend.py` → `tests/backend/data/mistral.py` (Imports parameter sets for Mistral provider test cases.)
- `tests/acp/test_bash.py` → `vibe/core/tools/base.py` (Imports ToolError for exception handling)
- `tests/acp/test_bash.py` → `vibe/core/tools/builtins/bash.py` (Imports BashArgs, BashResult, BashToolConfig data models)
- `tests/acp/test_bash.py` → `acp/schema.py` (Imports TerminalOutputResponse and WaitForTerminalExitResponse types for mock handle)
- `vibe/cli/init/glossary.py` → `vibe/cli/init/indexer.py` (Imports IndexResult class for type annotations and to access indexing data.)
- `vibe/cli/textual_ui/renderers/tool_renderers.py` → `vibe/cli/textual_ui/widgets/tool_widgets.py` (Imports widget classes (e.g., BashApprovalWidget, WriteFileResultWidget) used as return types for approval/result widgets.)
- `vibe/acp/tools/session_update.py` → `acp/helpers.py` (Imports SessionUpdate and ToolCallContentVariant types used in function signatures.)

**Imports_From:**
- `tests/test_ui_input_history.py` → `vibe/cli/textual_ui/widgets/chat_input/body.py` (Uses ChatInputBody class to access the .history attribute.)
- `tests/test_ui_input_history.py` → `vibe/cli/textual_ui/widgets/chat_input/container.py` (Uses ChatInputContainer class to interact with the input widget and its .value property.)
- `tests/conftest.py` → `vibe/core/config_path.py` (imports the config_path module to access its internal default path variable)
- `tests/test_agent_stats.py` → `vibe/core/config.py` (Imports Backend, ModelConfig, ProviderConfig, SessionLoggingConfig, VibeConfig to construct configuration objects.)
- `tests/test_agent_stats.py` → `vibe/core/tools/base.py` (Imports BaseToolConfig and ToolPermission for defining enabled tool configuration.)
- `tests/test_agent_stats.py` → `vibe/core/types.py` (Imports data classes such as AgentStats, AssistantEvent, CompactStartEvent, CompactEndEvent, FunctionCall, LLMMessage, Role, ToolCall used in assertions and test setup.)
- `tests/test_tagged_text.py` → `vibe/core/utils.py` (Uses constants CANCELLATION_TAG and KNOWN_TAGS for test expectations.)
- `tests/tools/test_grep.py` → `vibe/core/tools/base.py` (Imports ToolError for exception handling)
- `tests/tools/test_bash.py` → `vibe/core/tools/base.py` (Uses BaseToolState, ToolError, and ToolPermission classes.)
- `tests/tools/test_manager_get_tool_config.py` → `vibe/core/config.py` (Uses VibeConfig and SessionLoggingConfig classes to build configuration objects.)
- *...and 74 more*

**Inherits:**
- `tests/test_ui_pending_user_message.py` → `vibe/core/agent.py` (StubAgent subclasses Agent)
- `tests/stubs/fake_tool.py` → `vibe/core/tools/base.py` (FakeTool inherits from BaseTool defined in vibe/core/tools/base.py)
- `tests/stubs/fake_connection.py` → `acp/connection.py` (FakeAgentSideConnection inherits from AgentSideConnection defined in acp/connection.py)
- `tests/snapshots/base_snapshot_test_app.py` → `vibe/cli/textual_ui/app.py` (BaseSnapshotTestApp inherits from VibeApp.)
- `tests/snapshots/test_ui_snapshot_basic_conversation.py` → `tests/snapshots/base_snapshot_test_app.py` (SnapshotTestAppWithConversation inherits from BaseSnapshotTestApp.)
- `tests/snapshots/test_ui_snapshot_release_update_notification.py` → `tests/snapshots/base_snapshot_test_app.py` (SnapshotTestAppWithUpdate inherits from BaseSnapshotTestApp)
- `tests/autocompletion/test_path_completion_controller.py` → `vibe/cli/autocompletion/base.py` (StubView inherits from CompletionView)
- `tests/acp/test_multi_session.py` → `vibe/core/agent.py` (PatchedAgent class subclasses Agent)
- `tests/acp/test_set_model.py` → `vibe/core/agent.py` (PatchedAgent class inherits from vibe.core.agent.Agent.)
- `tests/acp/test_content.py` → `vibe/core/agent.py` (PatchedAgent subclass inherits from Agent)
- *...and 39 more*

**Inherits_Check/Calls:**
- `vibe/acp/acp_agent.py` → `vibe/acp/tools/base.py` (Checks if a tool class is subclass of BaseAcpTool and calls its update_tool_state method.)

**Instantiates:**
- `vibe/cli/textual_ui/app.py` → `vibe/core/agent.py` (Creates Agent instance in _initialize_agent())
- `vibe/cli/textual_ui/app.py` → `vibe/cli/textual_ui/widgets/messages.py` (Creates various message widgets (AssistantMessage, UserMessage, ErrorMessage, etc.))
- `vibe/cli/textual_ui/app.py` → `vibe/cli/textual_ui/widgets/loading.py` (Creates LoadingWidget during agent turns and init commands)
- `vibe/cli/textual_ui/app.py` → `vibe/cli/textual_ui/widgets/approval_app.py` (Creates ApprovalApp when a tool requires user approval)
- `vibe/cli/textual_ui/app.py` → `vibe/cli/textual_ui/widgets/config_app.py` (Creates ConfigApp when user opens configuration panel)
- `tests/test_ui_input_history.py` → `vibe/cli/history_manager.py` (Creates a HistoryManager object with the temporary history file.)
- `tests/test_ui_input_history.py` → `vibe/cli/textual_ui/app.py` (Fixture vibe_app creates a VibeApp instance.)
- `tests/test_ui_input_history.py` → `vibe/core/config.py` (Creates SessionLoggingConfig and VibeConfig objects in the vibe_config fixture.)
- `tests/test_history_manager.py` → `vibe/cli/history_manager.py` (Creates HistoryManager instances and invokes its methods add(), get_previous() and get_next())
- `tests/test_ui_pending_user_message.py` → `vibe/cli/textual_ui/app.py` (Creates VibeApp instance in fixture vibe_app)
- *...and 127 more*

**Instantiates & Uses:**
- `tests/test_agent_observer_streaming.py` → `vibe/core/middleware.py` (Adds InjectBeforeMiddleware to agent.middleware_pipeline and calls its before_turn/after_turn methods through the pipeline)
- `vibe/core/agent.py` → `core/llm/format.py` (Creates APIToolFormatHandler (self.format_handler) and calls its parse_message, resolve_tool_calls, get_available_tools, etc.)

**Instantiates|Calls:**
- `vibe/core/llm/backend/watsonx/backend.py` → `vibe/core/llm/backend/watsonx/auth.py` (Instantiates WatsonXAuth; calls its async __aenter__ and __aexit__ methods for token handling.)
- `vibe/core/autocompletion/file_indexer/indexer.py` → `vibe/core/autocompletion/file_indexer/store.py` (Creates a FileIndexStore (self._store = FileIndexStore(...)) and invokes its methods rebuild(), clear(), snapshot(), apply_changes())
- `vibe/core/autocompletion/file_indexer/indexer.py` → `vibe/core/autocompletion/file_indexer/watcher.py` (Creates a WatchController (self._watcher = WatchController(self._handle_watch_changes)) and calls its start() and stop() methods)

**Modifies:**
- `tests/mock/mock_backend_factory.py` → `vibe/core/llm/backend/factory.py` (Replaces BACKEND_FACTORY[backend_type] with a custom factory function within the context and restores the original afterwards.)

**Modifies_Attribute:**
- `tests/conftest.py` → `vibe/core/config_path.py` (sets config_path._DEFAULT_VIBE_HOME to the temporary .vibe directory created for tests)

**Monkeypatches:**
- `tests/test_ui_pending_user_message.py` → `vibe/cli/textual_ui/app.py` (Replaces VibeApp._initialize_agent with a fake that waits on an asyncio.Event)

**Patches:**
- `tests/acp/test_set_mode.py` → `vibe/acp/acp_agent.py` (Monkey‑patches VibeAgent with PatchedAgent using unittest.mock.patch.)
- `tests/acp/test_new_session.py` → `vibe/acp/acp_agent.py` (Monkey‑patches VibeAgent class inside the module.)

**Pushes_Screen:**
- `vibe/setup/onboarding/screens/watsonx_setup.py` → `vibe/setup/onboarding/screens/model_selection.py` (Calls self.app.push_screen("model_selection") after successful save)

**Pushes_To_Screen:**
- `vibe/setup/onboarding/screens/provider_selection.py` → `vibe/setup/onboarding/screens/watsonx_config.py` (Calls app.push_screen('watsonx_config') to navigate to WatsonX configuration screen.)
- `vibe/setup/onboarding/screens/provider_selection.py` → `vibe/setup/onboarding/screens/api_key.py` (Calls app.push_screen('api_key') to navigate to API key entry screen for Mistral.)

**Queries:**
- `tests/test_ui_pending_user_message.py` → `vibe/cli/textual_ui/widgets/messages.py` (Tests query for UserMessage and InterruptMessage widgets)
- `tests/test_ui_pending_user_message.py` → `vibe/cli/textual_ui/widgets/chat_input/container.py` (Accesses ChatInputContainer to set the input value)
- `tests/tools/test_ui_bash_execution.py` → `vibe/cli/textual_ui/widgets/messages.py` (Queries BashOutputMessage and ErrorMessage instances from the VibeApp UI.)

**Raises:**
- `vibe/core/tools/builtins/todo.py` → `vibe/core/tools/base.py` (Raises ToolError for invalid actions or configuration violations.)
- `vibe/cli/update_notifier/adapters/pypi_version_update_gateway.py` → `vibe/cli/update_notifier/ports/version_update_gateway.py` (Raises VersionUpdateGatewayError with various VersionUpdateGatewayCause values)

**Reads_Attributes:**
- `vibe/cli/textual_ui/widgets/welcome.py` → `vibe/core/config.py` (Accesses VibeConfig fields: disable_welcome_banner_animation, active_model, mcp_servers, models, effective_workdir)

**Reads_Variable:**
- `vibe/cli/textual_ui/widgets/welcome.py` → `vibe/core/__init__.py` (Uses __version__ for display in the banner)

**Runs:**
- `.github/workflows/ci.yml` → `vibe (CLI entry point defined in the project)` (Executes 'uv run vibe --help' to verify the CLI starts)
- `.github/workflows/ci.yml` → `vibe-acp (CLI entry point defined in the project)` (Executes 'uv run vibe-acp --help' to verify the CLI starts)
- `.github/workflows/ci.yml` → `tests/ (project test suite)` (Executes 'uv run pytest' for unit tests and 'uv run pytest tests/snapshots' for snapshot tests)

**Subclass:**
- `tests/acp/test_set_mode.py` → `vibe/core/agent.py` (Defines PatchedAgent as a subclass of Agent inside the acp_agent fixture.)

**Type_Check:**
- `tests/onboarding/test_ui_onboarding.py` → `vibe/setup/onboarding/screens/api_key.py` (Uses isinstance(app.screen, ApiKeyScreen) to verify navigation.)
- `tests/onboarding/test_ui_onboarding.py` → `vibe/setup/onboarding/screens/theme_selection.py` (Uses isinstance(app.screen, ThemeSelectionScreen) and accesses ThemeSelectionScreen constants.)

**Type_Check_Import:**
- `vibe/cli/textual_ui/renderers/tool_renderers.py` → `vibe/core/tools/ui.py` (Imports ToolResultDisplay for type hinting of display objects.)

**Type_Checks:**
- `vibe/core/llm/backend/generic.py` → `vibe/core/config.py` (ModelConfig and ProviderConfig are imported for type annotations.)

**Type_Hint:**
- `vibe/core/tools/builtins/grep.py` → `vibe/core/types.py` (Uses ToolCallEvent and ToolResultEvent in type annotations for UI display methods.)

**Type_Hints:**
- `vibe/core/tools/mcp.py` → `vibe/core/types.py` (ToolCallEvent and ToolResultEvent are used for method signatures)

**Updates:**
- `scripts/bump_version.py` → `pyproject.toml` (Replaces the version line with the newly bumped version.)
- `scripts/bump_version.py` → `distribution/zed/extension.toml` (Updates version string, download URL, and zip filename to the new version.)
- `scripts/bump_version.py` → `.vscode/launch.json` (Updates the JSON field "version" to the new version.)
- `scripts/bump_version.py` → `vibe/core/__init__.py` (Updates the module-level __version__ attribute to the new version.)
- `scripts/bump_version.py` → `tests/acp/test_initialize.py` (Updates the hard‑coded version string used in test initialization.)

**Uses:**
- `tests/test_agent_observer_streaming.py` → `vibe/core/types.py` (References enums and dataclasses like Role, AssistantEvent, ToolCallEvent, etc.)
- `tests/test_agent_observer_streaming.py` → `vibe/core/tools/builtins/todo.py` (Casts ToolCallEvent.args to TodoArgs for argument verification)
- `tests/test_agent_tool_call.py` → `vibe/core/tools/base.py` (BaseToolConfig and ToolPermission are used to configure tool permissions in make_config.)
- `tests/test_agent_tool_call.py` → `vibe/core/config.py` (SessionLoggingConfig and VibeConfig objects are constructed for the Agent.)
- `tests/test_agent_tool_call.py` → `vibe/core/types.py` (Various event and type classes (AssistantEvent, ToolCallEvent, ToolResultEvent, etc.) are referenced in assertions.)
- `tests/test_agent_tool_call.py` → `vibe/core/tools/builtins/todo.py` (TodoItem model is used to craft tool call arguments for write actions.)
- `tests/stubs/fake_backend.py` → `vibe/core/types.py` (uses LLMChunk and LLMMessage type definitions; calls LLMChunk.model_copy method)
- `tests/update_notifier/test_version_update_use_case.py` → `vibe/cli/update_notifier/__init__.py` (Uses classes UpdateCache, VersionUpdate, VersionUpdateGatewayCause, VersionUpdateGatewayError as data structures and error representation.)
- `tests/backend/test_backend.py` → `vibe/core/llm/types.py` (References BackendLike type annotation.)
- `tests/autocompletion/test_path_completer_fuzzy.py` → `pathlib/__init__.py` (creates Path objects, calls mkdir(), write_text(), and other filesystem methods)
- *...and 41 more*

**Uses_Type:**
- `tests/mock/mock_backend_factory.py` → `vibe/core/config.py` (Uses the Backend enum/type for the backend_type parameter.)


### Shared State Patterns

*Global variables, singletons, and shared state*

- `vibe/cli/textual_ui/app.py`: self.config (shared VibeConfig instance)
- `vibe/cli/textual_ui/app.py`: self.commands (CommandRegistry shared across widgets)
- `vibe/cli/textual_ui/app.py`: self.event_handler (single EventHandler managing tool results)
- `vibe/cli/textual_ui/app.py`: self._update_cache_repository (shared cache for version updates)
- `vibe/cli/textual_ui/app.py`: VibeConfig.save_updates (writes to shared configuration file)
- `vibe/cli/textual_ui/app.py`: HISTORY_FILE (global path used for persisting chat history)
- `tests/conftest.py`: Modifies config_path._DEFAULT_VIBE_HOME (global configuration path)
- `tests/conftest.py`: Sets environment variables that affect global runtime behavior
- `tests/test_agent_stats.py`: Agent.stats (per‑instance cumulative statistics object)
- `tests/test_agent_stats.py`: Agent.session_id (shared with interaction_logger for logging consistency)
- `tests/__init__.py`: module-level constant TESTS_ROOT used by other test modules
- `tests/test_agent_observer_streaming.py`: Agent instance maintains internal message list and middleware pipeline which are accessed across test steps
- `tests/test_agent_observer_streaming.py`: Interaction logger attached to Agent is mocked and shared across calls
- `tests/test_agent_tool_call.py`: Agent instance holds mutable config, messages, stats, and tool_manager that are shared across test steps.
- `scripts/install.sh`: PLATFORM
- `scripts/install.sh`: UV_INSTALLED
- `scripts/install.sh`: PATH modifications via export
- `vibe/__init__.py`: VIBE_ROOT (global constant representing the package root directory)
- `tests/stubs/fake_backend.py`: stores request messages and extra headers in instance lists
- `tests/stubs/fake_backend.py`: stores token counting call arguments in _count_tokens_calls
- *...and 99 more*


### Entry Point Dependencies

*What each entry point directly depends on*


**`vibe/cli/textual_ui/app.py`**:
- `vibe/cli/clipboard/copy_selection_to_clipboard.py`
- `vibe/cli/commands/CommandRegistry.py`
- `vibe/cli/init/execute_init.py`
- `vibe/cli/init/InitProgress.py`
- `vibe/cli/init/format_init_summary.py`
- `vibe/cli/textual_ui/handlers/event_handler/EventHandler.py`
- `vibe/cli/textual_ui/widgets/approval_app/ApprovalApp.py`
- `vibe/cli/textual_ui/widgets/chat_input/ChatInputContainer.py`
- `vibe/cli/textual_ui/widgets/compact/CompactMessage.py`
- `vibe/cli/textual_ui/widgets/config_app/ConfigApp.py`
- *...and 50 more*


---

## Project Structure

```
mistral-vibe/
├── .github/
│   ├── workflows/
│   │   ├── build-and-upload.yml
│   │   ├── ci.yml
│   │   └── release.yml
│   └── CODEOWNERS
├── distribution/
│   └── zed/
│       ├── icons/
│       │   └── mistral_vibe.svg
│       ├── extension.toml
│       └── LICENSE
├── scripts/
│   ├── bump_version.py
│   ├── install.sh
│   └── README.md
├── tests/
│   ├── acp/
│   │   ├── test_acp.py
│   │   ├── test_bash.py
│   │   ├── test_content.py
│   │   ├── test_initialize.py
│   │   ├── test_multi_session.py
│   │   ├── test_new_session.py
│   │   ├── test_read_file.py
│   │   ├── test_search_replace.py
│   │   ├── test_set_mode.py
│   │   ├── test_set_model.py
│   │   └── test_write_file.py
│   ├── autocompletion/
│   │   ├── test_file_indexer.py
│   │   ├── test_fuzzy.py
│   │   ├── test_path_completer_fuzzy.py
│   │   ├── test_path_completer_recursive.py
│   │   ├── test_path_completion_controller.py
│   │   ├── test_path_prompt_transformer.py
│   │   ├── test_slash_command_controller.py
│   │   └── test_ui_chat_autocompletion.py
│   ├── backend/
│   │   ├── data/
│   │   │   ├── __init__.py
│   │   │   ├── fireworks.py
│   │   │   └── mistral.py
│   │   ├── __init__.py
│   │   └── test_backend.py
│   ├── cli/
│   │   └── test_clipboard.py
│   ├── core/
│   │   ├── test_config_migration.py
│   │   └── test_config_resolution.py
│   ├── mock/
│   │   ├── __init__.py
│   │   ├── mock_backend_factory.py
│   │   ├── mock_entrypoint.py
│   │   └── utils.py
│   ├── onboarding/
│   │   ├── test_run_onboarding.py
│   │   └── test_ui_onboarding.py
│   ├── playground/
│   ├── snapshots/
│   │   ├── __snapshots__/
│   │   │   ├── test_ui_snapshot_basic_conversation/
│   │   │   │   └── test_snapshot_shows_basic_conversation.svg
│   │   │   ├── test_ui_snapshot_code_block_horizontal_scrolling/
│   │   │   │   └── test_snapshot_allows_horizontal_scrolling_for_long_code_blocks.svg
│   │   │   └── test_ui_snapshot_release_update_notification/
│   │   │       └── test_snapshot_shows_release_update_notification.svg
│   │   ├── base_snapshot_test_app.py
│   │   ├── snap_compare.py
│   │   ├── test_ui_snapshot_basic_conversation.py
│   │   ├── test_ui_snapshot_code_block_horizontal_scrolling.py
│   │   └── test_ui_snapshot_release_update_notification.py
│   ├── stubs/
│   │   ├── fake_backend.py
│   │   ├── fake_connection.py
│   │   └── fake_tool.py
│   ├── tools/
│   │   ├── test_bash.py
│   │   ├── test_grep.py
│   │   ├── test_manager_get_tool_config.py
│   │   └── test_ui_bash_execution.py
│   ├── update_notifier/
│   │   ├── adapters/
│   │   │   ├── fake_update_cache_repository.py
│   │   │   └── fake_version_update_gateway.py
│   │   ├── test_filesystem_update_cache_repository.py
│   │   ├── test_github_version_update_gateway.py
│   │   ├── test_pypi_version_update_gateway.py
│   │   ├── test_ui_version_update_notification.py
│   │   └── test_version_update_use_case.py
│   ├── __init__.py
│   ├── conftest.py
│   ├── test_agent_auto_compact.py
│   ├── test_agent_backend.py
│   ├── test_agent_observer_streaming.py
│   ├── test_agent_stats.py
│   ├── test_agent_tool_call.py
│   ├── test_cli_programmatic_preload.py
│   ├── test_history_manager.py
│   ├── test_system_prompt.py
│   ├── test_tagged_text.py
│   ├── test_ui_input_history.py
│   └── test_ui_pending_user_message.py
├── vibe/
│   ├── acp/
│   │   ├── tools/
│   │   │   ├── builtins/
│   │   │   │   ├── bash.py
│   │   │   │   ├── read_file.py
│   │   │   │   ├── search_replace.py
│   │   │   │   ├── todo.py
│   │   │   │   └── write_file.py
│   │   │   ├── __init__.py
│   │   │   ├── base.py
│   │   │   └── session_update.py
│   │   ├── __init__.py
│   │   ├── acp_agent.py
│   │   ├── entrypoint.py
│   │   └── utils.py
│   ├── cli/
│   │   ├── autocompletion/
│   │   │   ├── __init__.py
│   │   │   ├── base.py
│   │   │   ├── path_completion.py
│   │   │   └── slash_command.py
│   │   ├── init/
│   │   │   ├── __init__.py
│   │   │   ├── analysis_index.py
│   │   │   ├── contracts.py
│   │   │   ├── discovery.py
│   │   │   ├── executor.py
│   │   │   ├── generator.py
│   │   │   ├── glossary.py
│   │   │   └── indexer.py
│   │   ├── textual_ui/
│   │   │   ├── handlers/
│   │   │   │   ├── __init__.py
│   │   │   │   └── event_handler.py
│   │   │   ├── renderers/
│   │   │   │   ├── __init__.py
│   │   │   │   └── tool_renderers.py
│   │   │   ├── widgets/
│   │   │   │   ├── chat_input/
│   │   │   │   │   ├── __init__.py
│   │   │   │   │   ├── body.py
│   │   │   │   │   ├── completion_manager.py
│   │   │   │   │   ├── completion_popup.py
│   │   │   │   │   ├── container.py
│   │   │   │   │   └── text_area.py
│   │   │   │   ├── __init__.py
│   │   │   │   ├── approval_app.py
│   │   │   │   ├── blinking_message.py
│   │   │   │   ├── compact.py
│   │   │   │   ├── config_app.py
│   │   │   │   ├── context_progress.py
│   │   │   │   ├── loading.py
│   │   │   │   ├── messages.py
│   │   │   │   ├── mode_indicator.py
│   │   │   │   ├── path_display.py
│   │   │   │   ├── tool_widgets.py
│   │   │   │   ├── tools.py
│   │   │   │   └── welcome.py
│   │   │   ├── __init__.py
│   │   │   ├── app.py
│   │   │   └── app.tcss
│   │   ├── update_notifier/
│   │   │   ├── adapters/
│   │   │   │   ├── filesystem_update_cache_repository.py
│   │   │   │   ├── github_version_update_gateway.py
│   │   │   │   └── pypi_version_update_gateway.py
│   │   │   ├── ports/
│   │   │   │   ├── update_cache_repository.py
│   │   │   │   └── version_update_gateway.py
│   │   │   ├── __init__.py
│   │   │   └── version_update.py
│   │   ├── __init__.py
│   │   ├── clipboard.py
│   │   ├── commands.py
│   │   ├── entrypoint.py
│   │   └── history_manager.py
│   ├── core/
│   │   ├── autocompletion/
│   │   │   ├── file_indexer/
│   │   │   │   ├── __init__.py
│   │   │   │   ├── ignore_rules.py
│   │   │   │   ├── indexer.py
│   │   │   │   ├── store.py
│   │   │   │   └── watcher.py
│   │   │   ├── __init__.py
│   │   │   ├── completers.py
│   │   │   ├── fuzzy.py
│   │   │   ├── path_prompt.py
│   │   │   └── path_prompt_adapter.py
│   │   ├── llm/
│   │   │   ├── backend/
│   │   │   │   ├── watsonx/
│   │   │   │   │   ├── __init__.py
│   │   │   │   │   ├── auth.py
│   │   │   │   │   ├── backend.py
│   │   │   │   │   └── models.py
│   │   │   │   ├── __init__.py
│   │   │   │   ├── factory.py
│   │   │   │   ├── generic.py
│   │   │   │   └── mistral.py
│   │   │   ├── __init__.py
│   │   │   ├── exceptions.py
│   │   │   ├── format.py
│   │   │   └── types.py
│   │   ├── prompts/
│   │   │   ├── __init__.py
│   │   │   ├── cli.md
│   │   │   ├── compact.md
│   │   │   ├── dangerous_directory.md
│   │   │   ├── project_context.md
│   │   │   └── tests.md
│   │   ├── tools/
│   │   │   ├── builtins/
│   │   │   │   ├── prompts/
│   │   │   │   │   ├── __init__.py
│   │   │   │   │   ├── bash.md
│   │   │   │   │   ├── grep.md
│   │   │   │   │   ├── read_file.md
│   │   │   │   │   ├── search_replace.md
│   │   │   │   │   ├── todo.md
│   │   │   │   │   └── write_file.md
│   │   │   │   ├── bash.py
│   │   │   │   ├── grep.py
│   │   │   │   ├── read_file.py
│   │   │   │   ├── search_replace.py
│   │   │   │   ├── todo.py
│   │   │   │   └── write_file.py
│   │   │   ├── base.py
│   │   │   ├── manager.py
│   │   │   ├── mcp.py
│   │   │   └── ui.py
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── config.py
│   │   ├── config_path.py
│   │   ├── context_injector.py
│   │   ├── interaction_logger.py
│   │   ├── middleware.py
│   │   ├── output_formatters.py
│   │   ├── programmatic.py
│   │   ├── system_prompt.py
│   │   ├── types.py
│   │   └── utils.py
│   ├── setup/
│   │   └── onboarding/
│   │       ├── screens/
│   │       │   ├── __init__.py
│   │       │   ├── api_key.py
│   │       │   ├── model_selection.py
│   │       │   ├── provider_selection.py
│   │       │   ├── theme_selection.py
│   │       │   ├── watsonx_setup.py
│   │       │   └── welcome.py
│   │       ├── __init__.py
│   │       ├── base.py
│   │       └── onboarding.tcss
│   └── __init__.py
├── .gitignore
├── .pre-commit-config.yaml
├── .python-version
├── .typos.toml
├── action.yml
├── AGENTS.md
├── CHANGELOG.md
├── CLAUDE.md
├── CONTRIBUTING.md
├── flake.nix
├── LICENSE
├── pyproject.toml
├── README.md
└── vibe-acp.spec
```

---

## File Index

*Analyzed 192 files, 192 chunks processed*

### Module: `(root)/`

#### `pyproject.toml`

**Purpose**: Defines the package metadata, dependencies, build configuration, scripts, and tooling settings for the mistral-vibe-watsonx Python project.

**Dependencies**: agent-client-protocol==0.6.3, aiofiles>=24.1.0, httpx>=0.28.1, mcp>=1.14.0, mistralai==1.9.11

**Complexity**: low

#### `.pre-commit-config.yaml`

**Purpose**: Defines the pre-commit configuration, specifying which repositories of hooks to run, their versions, and any arguments or exclusions for each hook.

**Dependencies**: mpalmer/action-validator, pre-commit/pre-commit-hooks, fsouza/mirrors-pyright, astral-sh/ruff-pre-commit, crate-ci/typos

**Complexity**: low

#### `.typos.toml`

**Purpose**: Configures the Typos static analysis tool to extend its ignore regex list, adding patterns for lines that disable typos checking and a custom 'datas' pattern.

**Complexity**: low

#### `action.yml`

**Purpose**: Defines a composite GitHub Action that installs Python (optionally a specific version), sets up the UV package manager, installs the Mistral Vibe project, and runs it with a provided prompt and API key.

**Dependencies**: actions/setup-python, astral-sh/setup-uv, uv

**Complexity**: low

### Module: `.github/workflows/`

#### `.github/workflows/release.yml`

**Purpose**: Defines a GitHub Actions workflow that runs on a published release (or manual trigger) to build the Python package with uv, upload the distribution artifacts, and publish the package to PyPI.

**Patterns**: CI/CD pipeline, GitHub Actions workflow

**Dependencies**: actions/checkout, actions/setup-python, astral-sh/setup-uv, actions/upload-artifact, pypa/gh-action-pypi-publish

**Complexity**: low

#### `.github/workflows/build-and-upload.yml`

**Purpose**: Defines a GitHub Actions workflow that builds the project on multiple operating systems and architectures, then uploads the resulting binaries as artifacts.

**Patterns**: matrix strategy, artifact upload, conditional steps based on OS

**Dependencies**: actions/checkout@v4, astral-sh/setup-uv@v5, actions/setup-python@v5, actions/upload-artifact@v5

**Complexity**: low

#### `.github/workflows/ci.yml`

**Purpose**: Defines the CI workflow for the repository, running pre‑commit checks, unit tests, and snapshot tests on push or pull‑request to the main branch.

**Patterns**: Caching of dependencies, Parallel jobs, Conditional artifact upload

**Dependencies**: actions/checkout, astral-sh/setup-uv, actions/setup-python, actions/cache, actions/upload-artifact

**Complexity**: medium

### Module: `distribution/zed/`

#### `distribution/zed/extension.toml`

**Purpose**: Defines the metadata and platform‑specific binaries for the Mistral Vibe agent server extension.

**Complexity**: low

### Module: `scripts/`

#### `scripts/install.sh`

**Purpose**: Installs the uv package manager if it is missing and then installs the mistral-vibe tool using uv, handling platform detection and PATH adjustments.

**Exports**: `error`, `info`, `success`, `warning`, `check_platform`, `check_uv_installed`, `install_uv`, `install_vibe`, `main`, `RED` (+6 more)

**Functions**: `error()`, `info()`, `success()`, `warning()`, `check_platform()`, `check_uv_installed()`, `install_uv()`, `install_vibe()`

**Dependencies**: uv, curl

**Complexity**: low

#### `scripts/bump_version.py`

**Purpose**: Command‑line script that reads the current semantic version from pyproject.toml, bumps it (major, minor, micro/patch), and propagates the new version string to several project files.

**Exports**: `parse_version`, `format_version`, `bump_version`, `update_hard_values_files`, `get_current_version`, `main`, `BumpType`, `BUMP_TYPES`

**Functions**: `parse_version()`, `format_version()`, `bump_version()`, `update_hard_values_files()`, `get_current_version()`, `main()`

**Complexity**: low

### Module: `tests/`

#### `tests/test_ui_input_history.py`

**Purpose**: Provides pytest test cases for the textual UI input history functionality, verifying navigation through past inputs, interaction with command completion, and cursor movement behavior.

**Exports**: `vibe_config`, `vibe_app`, `history_file`, `inject_history_file`, `test_ui_navigation_through_input_history`, `test_ui_does_nothing_if_command_completion_is_active`, `test_ui_does_not_prevent_arrow_down_to_move_cursor_to_bottom_lines`, `test_ui_resumes_arrow_down_after_manual_move`

**Functions**: `vibe_config()`, `vibe_app()`, `history_file()`, `inject_history_file()`, `test_ui_navigation_through_input_history()`, `test_ui_does_nothing_if_command_completion_is_active()`, `test_ui_does_not_prevent_arrow_down_to_move_cursor_to_bottom_lines()`, `test_ui_resumes_arrow_down_after_manual_move()`

**Patterns**: Fixture pattern (pytest fixtures), Manual dependency injection

**Dependencies**: pytest

**Complexity**: medium

#### `tests/test_history_manager.py`

**Purpose**: Provides pytest unit tests for the HistoryManager class, verifying its behavior regarding entry normalization, size limits, filtering, prefix handling, and navigation.

**Exports**: `test_history_manager_normalizes_loaded_entries_like_numbers_to_strings`, `test_history_manager_retains_a_fixed_number_of_entries`, `test_history_manager_filters_invalid_and_duplicated_entries`, `test_history_manager_filters_commands`, `test_history_manager_allows_navigation_round_trip`, `test_history_manager_prefix_filtering`

**Functions**: `test_history_manager_normalizes_loaded_entries_like_numbers_to_strings()`, `test_history_manager_retains_a_fixed_number_of_entries()`, `test_history_manager_filters_invalid_and_duplicated_entries()`, `test_history_manager_filters_commands()`, `test_history_manager_allows_navigation_round_trip()`, `test_history_manager_prefix_filtering()`

**Dependencies**: pytest

**Complexity**: low

#### `tests/test_ui_pending_user_message.py`

**Purpose**: Provides pytest‑based asynchronous UI tests that verify how pending user messages are displayed and can be interrupted while the VibeApp agent is initializing.

**Exports**: `_wait_for`, `StubAgent`, `vibe_config`, `vibe_app`, `_patch_delayed_init`, `test_shows_user_message_as_pending_until_agent_is_initialized`, `test_can_interrupt_pending_message_during_initialization`, `test_retry_initialization_after_interrupt`

**Classes**: `StubAgent`

**Functions**: `vibe_config()`, `vibe_app()`, `test_shows_user_message_as_pending_until_agent_is_initialized()`, `test_can_interrupt_pending_message_during_initialization()`, `test_retry_initialization_after_interrupt()`

**Patterns**: pytest fixture pattern, monkeypatching for test isolation, async test execution, await‑until helper

**Dependencies**: pytest

**Complexity**: medium

#### `tests/conftest.py`

**Purpose**: Provides pytest fixtures that set up a temporary Vibe configuration directory, mock required environment variables, and standardize platform settings for the test suite.

**Exports**: `get_base_config`, `config_dir`, `_mock_api_key`, `_mock_platform`

**Functions**: `get_base_config()`, `config_dir()`, `_mock_api_key()`, `_mock_platform()`

**Patterns**: Fixture (pytest), Monkeypatching for dependency injection

**Dependencies**: pytest, tomli_w

**Complexity**: low

#### `tests/test_agent_stats.py`

**Purpose**: Pytest test suite that validates the behavior of Agent statistics, reload, compact, auto‑compact, and history‑clearing functionality in the Vibe agent implementation.

**Exports**: `make_config`, `observer_capture`, `TestAgentStatsHelpers`, `TestReloadPreservesStats`, `TestReloadPreservesMessages`, `TestCompactStatsHandling`, `TestAutoCompactIntegration`, `TestClearHistoryFullReset`, `TestStatsEdgeCases`

**Classes**: `TestAgentStatsHelpers`, `TestReloadPreservesStats`, `TestReloadPreservesMessages`, `TestCompactStatsHandling`, `TestAutoCompactIntegration`

**Functions**: `make_config()`, `observer_capture()`

**Patterns**: Factory (make_config), Observer (message_observer callback), Fixture (pytest.fixture), Builder (construction of VibeConfig with nested config objects)

**Dependencies**: pytest

**Complexity**: medium

#### `tests/test_agent_backend.py`

**Purpose**: Defines pytest fixtures and asynchronous test cases to verify Agent behavior with respect to HTTP headers, token statistics, and streaming mode.

**Exports**: `vibe_config`, `test_passes_x_affinity_header_when_asking_an_answer`, `test_passes_x_affinity_header_when_asking_an_answer_streaming`, `test_updates_tokens_stats_based_on_backend_response`, `test_updates_tokens_stats_based_on_backend_response_streaming`

**Functions**: `vibe_config()`, `test_passes_x_affinity_header_when_asking_an_answer()`, `test_passes_x_affinity_header_when_asking_an_answer_streaming()`, `test_updates_tokens_stats_based_on_backend_response()`, `test_updates_tokens_stats_based_on_backend_response_streaming()`

**Patterns**: pytest fixtures, async test functions with pytest.mark.asyncio, assertions on object state

**Dependencies**: pytest, pytest-asyncio

**Complexity**: low

#### `tests/__init__.py`

**Purpose**: Defines the root directory path for the test suite by exposing a TESTS_ROOT constant.

**Exports**: `TESTS_ROOT`

**Complexity**: low

#### `tests/test_system_prompt.py`

**Purpose**: Tests that get_universal_system_prompt returns a prompt containing correct Windows-specific information when the platform is mocked as Windows.

**Functions**: `test_get_universal_system_prompt_includes_windows_prompt_on_windows()`

**Dependencies**: pytest

**Complexity**: low

#### `tests/test_agent_observer_streaming.py`

**Purpose**: Provides unit tests for the Agent's streaming, middleware injection, tool call handling, cancellation, and error logging behaviours.

**Exports**: `InjectBeforeMiddleware`, `make_config`, `observer_capture`

**Classes**: `InjectBeforeMiddleware`

**Functions**: `make_config()`, `observer_capture()`

**Patterns**: Observer pattern (message_observer callback), Middleware/Chain‑of‑Responsibility pattern, Factory/Builder pattern for test fixtures, Async iterator handling for streaming

**Dependencies**: pytest

**Complexity**: medium

#### `tests/test_agent_tool_call.py`

**Purpose**: Provides a suite of async pytest test cases that verify the behavior of the Vibe Agent’s tool call handling, approval flow, error handling, and internal state management.

**Exports**: `act_and_collect_events`, `make_config`, `make_todo_tool_call`, `make_agent`, `test_single_tool_call_executes_under_auto_approve`, `test_tool_call_requires_approval_if_not_auto_approved`, `test_tool_call_approved_by_callback`, `test_tool_call_rejected_when_auto_approve_disabled_and_rejected_by_callback`, `test_tool_call_skipped_when_permission_is_never`, `test_approval_always_sets_tool_permission_for_subsequent_calls` (+6 more)

**Functions**: `act_and_collect_events()`, `make_config()`, `make_todo_tool_call()`, `make_agent()`, `test_single_tool_call_executes_under_auto_approve()`, `test_tool_call_requires_approval_if_not_auto_approved()`, `test_tool_call_approved_by_callback()`, `test_tool_call_rejected_when_auto_approve_disabled_and_rejected_by_callback()`

**Patterns**: Callback pattern (approval_callback), Factory functions for test objects (make_config, make_agent), Dependency injection via FakeBackend and FakeTool, Parametrized test (pytest.mark.parametrize) for interruption cases

**Dependencies**: pytest

**Complexity**: medium

#### `tests/test_cli_programmatic_preload.py`

**Purpose**: Defines test cases for the programmatic Vibe run with streaming output, using a spy formatter to verify message ordering and system‑message handling.

**Exports**: `SpyStreamingFormatter`, `test_run_programmatic_preload_streaming_is_batched`, `test_run_programmatic_ignores_system_messages_in_previous`

**Classes**: `SpyStreamingFormatter`

**Functions**: `test_run_programmatic_preload_streaming_is_batched()`, `test_run_programmatic_ignores_system_messages_in_previous()`

**Patterns**: Test Spy (mock formatter), Monkeypatching, Factory pattern for mock backend, Dependency injection via fixtures

**Dependencies**: pytest

**Complexity**: low

#### `tests/test_agent_auto_compact.py`

**Purpose**: Test that the Agent's auto‑compact feature triggers correctly and that the message observer receives the expected messages.

**Functions**: `test_auto_compact_triggers_and_batches_observer()`

**Patterns**: Observer (message_observer callback), Async testing with pytest.mark.asyncio

**Dependencies**: pytest

**Complexity**: low

#### `tests/test_tagged_text.py`

**Purpose**: Provides unit tests for the TaggedText class and related tag constants, verifying creation, string conversion, parsing, and edge‑case handling.

**Functions**: `test_tagged_text_creation_without_tag()`, `test_tagged_text_creation_with_tag()`, `test_tagged_text_from_string_with_known_tag()`, `test_tagged_text_from_string_with_known_tag_multiline()`, `test_tagged_text_from_string_with_known_tag_whitespace()`, `test_tagged_text_from_string_with_unknown_tag()`, `test_tagged_text_from_string_with_text_before_tag()`, `test_tagged_text_from_string_with_text_after_tag()`

**Patterns**: pytest test functions, parameterized testing via @pytest.mark.parametrize

**Dependencies**: pytest

**Complexity**: low

### Module: `tests/acp/`

#### `tests/acp/test_write_file.py`

**Purpose**: Provides pytest test cases for the ACP write_file tool, verifying correct request creation, session updates, error handling, and edge cases.

**Exports**: `MockConnection`, `mock_connection`, `acp_write_file_tool`, `TestAcpWriteFileBasic`, `TestAcpWriteFileExecution`, `TestAcpWriteFileSessionUpdates`

**Classes**: `MockConnection`, `TestAcpWriteFileBasic`, `TestAcpWriteFileExecution`, `TestAcpWriteFileSessionUpdates`

**Functions**: `mock_connection()`, `acp_write_file_tool()`

**Patterns**: Fixture pattern (pytest fixtures), Mock object pattern, Async test pattern

**Dependencies**: pytest

**Complexity**: medium

#### `tests/acp/test_set_mode.py`

**Purpose**: Provides pytest async test cases for verifying VibeAcpAgent's session mode setting behavior.

**Exports**: `backend`, `acp_agent`, `TestACPSetMode`

**Classes**: `TestACPSetMode`

**Functions**: `backend()`, `acp_agent()`

**Patterns**: Fixture, Async Test, Dependency Injection, Patch/Monkey‑patch

**Dependencies**: pytest

**Complexity**: low

#### `tests/acp/test_multi_session.py`

**Purpose**: Provides pytest‑style integration tests that verify multi‑session handling, error handling for unknown sessions, and concurrent message processing in the Vibe ACP agent.

**Exports**: `backend`, `acp_agent`, `TestMultiSessionCore`

**Classes**: `TestMultiSessionCore`

**Functions**: `backend()`, `acp_agent()`

**Patterns**: Fixture (pytest), Dependency injection via fixtures, Mocking/patching (unittest.mock), Async test execution (pytest-asyncio)

**Dependencies**: pytest, pytest-asyncio, unittest, asyncio, pathlib

**Complexity**: medium

#### `tests/acp/test_bash.py`

**Purpose**: Provides pytest-based unit tests for the ACP Bash tool, including mock terminal and connection objects and a suite of test cases covering parsing, execution, timeout, embedding, configuration, and cleanup behavior.

**Exports**: `MockTerminalHandle`, `MockConnection`, `mock_connection`, `acp_bash_tool`

**Classes**: `MockTerminalHandle`, `MockConnection`, `TestAcpBashBasic`, `TestAcpBashExecution`, `TestAcpBashTimeout`

**Functions**: `mock_connection()`, `acp_bash_tool()`

**Patterns**: Test fixtures (pytest), Mock objects for external dependencies, Async test functions (pytest-asyncio), Dependency injection via fixtures

**Dependencies**: pytest, pytest-asyncio

**Complexity**: medium

#### `tests/acp/test_set_model.py`

**Purpose**: Defines pytest fixtures and a suite of asynchronous tests verifying the behavior of VibeAcpAgent.setSessionModel, including model switching, config persistence, conversation history preservation, and stats reset.

**Exports**: `backend`, `acp_agent`, `TestACPSetModel`

**Classes**: `TestACPSetModel`

**Functions**: `backend()`, `acp_agent()`

**Patterns**: Fixture (pytest), Monkey patching (unittest.mock.patch), Factory (creation of VibeAcpAgent via callback), Dependency Injection (injecting FakeBackend into Agent)

**Dependencies**: pytest, unittest.mock, pathlib, typing (future annotations)

**Complexity**: medium

#### `tests/acp/test_read_file.py`

**Purpose**: Provides pytest test cases for the ACP ReadFile tool, including a mock connection and various scenarios such as offsets, limits, and error handling.

**Exports**: `MockConnection`, `mock_connection`, `acp_read_file_tool`, `TestAcpReadFileBasic`, `TestAcpReadFileExecution`

**Classes**: `MockConnection`, `TestAcpReadFileBasic`, `TestAcpReadFileExecution`

**Functions**: `mock_connection()`, `acp_read_file_tool()`

**Patterns**: pytest fixtures, async test (pytest-asyncio), mock object

**Dependencies**: pytest

**Complexity**: medium

#### `tests/acp/test_search_replace.py`

**Purpose**: Provides pytest test suite for the ACP SearchReplace tool, using a mock connection to verify reading, writing, backup handling, error handling, and session update generation.

**Exports**: `MockConnection`, `TestAcpSearchReplaceBasic`, `TestAcpSearchReplaceExecution`, `TestAcpSearchReplaceSessionUpdates`

**Classes**: `MockConnection`, `TestAcpSearchReplaceBasic`, `TestAcpSearchReplaceExecution`, `TestAcpSearchReplaceSessionUpdates`

**Functions**: `mock_connection()`, `acp_search_replace_tool()`

**Patterns**: Factory (fixtures creating tool instances), Mock Object (MockConnection), Dependency Injection (injecting mock connection via state), Builder (SearchReplaceArgs/Config usage), Observer (session update notifications)

**Dependencies**: pytest

**Complexity**: medium

#### `tests/acp/test_content.py`

**Purpose**: Defines pytest fixtures and a suite of async tests that verify how different ACP content blocks (text, embedded resources, resource links) are transformed into user messages sent to the backend via VibeAcpAgent.

**Classes**: `TestACPContent`

**Functions**: `backend()`, `acp_agent()`

**Patterns**: Fixture pattern (pytest), Mocking/patching (unittest.mock), Async test pattern (pytest-asyncio)

**Dependencies**: pytest

**Complexity**: low

#### `tests/acp/test_acp.py`

**Purpose**: Provides asynchronous pytest tests for the ACP (Agent Communication Protocol) implementation, including utilities to launch the mock ACP agent process, send/receive JSON‑RPC messages, and validate session, tool‑call and permission request behaviors.

**Exports**: `deep_merge`, `_create_vibe_home_dir`, `vibe_home_dir`, `vibe_home_grep_ask`, `JsonRpcRequest`, `JsonRpcError`, `JsonRpcResponse`, `JsonRpcNotification`, `InitializeJsonRpcRequest`, `InitializeJsonRpcResponse` (+23 more)

**Classes**: `JsonRpcRequest`, `JsonRpcError`, `JsonRpcResponse`, `JsonRpcNotification`, `InitializeJsonRpcRequest`

**Functions**: `deep_merge()`, `vibe_home_dir()`, `vibe_home_grep_ask()`, `get_acp_agent_process()`, `send_json_rpc()`, `read_response()`, `read_response_for_id()`, `read_multiple_responses()`

**Patterns**: Async generator for resource cleanup, pytest fixtures for test setup, Factory‑like helper functions to build JSON‑RPC messages, Parsing/dispatch based on JSON‑RPC method signatures

**Dependencies**: acp, acp.schema, pydantic, pytest, tomli_w

**Complexity**: medium

#### `tests/acp/test_new_session.py`

**Purpose**: Provides pytest fixtures and test cases to verify the behavior of VibeAcpAgent's new session creation and model handling.

**Exports**: `backend`, `acp_agent`, `TestACPNewSession`

**Classes**: `TestACPNewSession`

**Functions**: `backend()`, `acp_agent()`

**Patterns**: Fixture (pytest), Factory (inner _create_agent function), Dependency Injection, Mocking (unittest.mock.patch)

**Dependencies**: pytest, unittest.mock

**Complexity**: medium

#### `tests/acp/test_initialize.py`

**Purpose**: Provides pytest fixtures and tests that verify the behavior of the ACP initialize endpoint of the VibeAcpAgent, including handling of terminal-auth capabilities.

**Exports**: `acp_agent`, `TestACPInitialize`

**Classes**: `TestACPInitialize`

**Functions**: `acp_agent()`

**Patterns**: Factory (agent creation within fixture), Test Fixture (pytest), Dependency Injection (FakeAgentSideConnection provides the connection)

**Dependencies**: pytest

**Complexity**: low

### Module: `tests/autocompletion/`

#### `tests/autocompletion/test_path_completer_fuzzy.py`

**Purpose**: Provides pytest test cases for the PathCompleter fuzzy matching functionality, verifying that various pattern inputs return the expected autocompletion results.

**Functions**: `file_tree()`, `test_fuzzy_matches_subsequence_characters()`, `test_fuzzy_matches_consecutive_characters_higher()`, `test_fuzzy_matches_prefix_highest()`, `test_fuzzy_matches_across_directory_boundaries()`, `test_fuzzy_matches_case_insensitive()`, `test_fuzzy_matches_word_boundaries_preferred()`, `test_fuzzy_matches_empty_pattern_shows_all()`

**Patterns**: pytest fixture, unit test naming convention, assertion based testing

**Dependencies**: pytest

**Complexity**: low

#### `tests/autocompletion/test_path_completion_controller.py`

**Purpose**: Provides pytest tests for the PathCompletionController, using a stub view to verify suggestion rendering, navigation, and completion behavior.

**Exports**: `StubView`, `file_tree`, `make_controller`, `test_lists_root_entries`, `test_suggests_hidden_entries_only_with_dot_prefix`, `test_lists_nested_entries_when_prefixing_with_folder_name`, `test_resets_when_fragment_invalid`, `test_applies_selected_completion_on_tab_keycode`, `test_applies_selected_completion_on_enter_keycode`, `test_navigates_and_cycles_across_suggestions` (+8 more)

**Classes**: `StubView`

**Functions**: `file_tree()`, `make_controller()`

**Patterns**: Dependency Injection (controller receives completer and view), pytest fixture pattern, Stub/Mock pattern for UI components

**Dependencies**: pytest, textual

**Complexity**: low

#### `tests/autocompletion/test_ui_chat_autocompletion.py`

**Purpose**: Provides a comprehensive suite of pytest asynchronous tests for the chat input autocompletion UI, covering command suggestion, path completion, navigation, and fuzzy matching behavior.

**Exports**: `vibe_config`, `vibe_app`, `test_popup_appears_with_matching_suggestions`, `test_popup_hides_when_input_cleared`, `test_pressing_tab_writes_selected_command_and_keeps_popup_visible`, `ensure_selected_command`, `test_arrow_navigation_updates_selected_suggestion`, `test_arrow_navigation_cycles_through_suggestions`, `test_pressing_enter_submits_selected_command_and_hides_popup`, `file_tree` (+9 more)

**Functions**: `vibe_config()`, `vibe_app()`, `test_popup_appears_with_matching_suggestions()`, `test_popup_hides_when_input_cleared()`, `test_pressing_tab_writes_selected_command_and_keeps_popup_visible()`, `test_arrow_navigation_updates_selected_suggestion()`, `test_arrow_navigation_cycles_through_suggestions()`, `test_pressing_enter_submits_selected_command_and_hides_popup()`

**Patterns**: pytest fixtures, async test functions, UI integration testing with textual's Pilot, helper assertion function for renderable analysis

**Dependencies**: pytest, textual

**Complexity**: medium

#### `tests/autocompletion/test_slash_command_controller.py`

**Purpose**: Unit tests for the SlashCommandController autocompletion component, verifying suggestion generation, filtering, selection cycling, and completion application.

**Exports**: `Suggestion`, `SuggestionEvent`, `Replacement`, `StubView`, `key_event`, `make_controller`, `test_on_text_change_emits_matching_suggestions_in_insertion_order_and_ignores_duplicates`, `test_on_text_change_filters_suggestions_case_insensitively`, `test_on_text_change_clears_suggestions_when_no_matches`, `test_on_text_change_limits_the_number_of_results_to_five_and_preserve_insertion_order` (+3 more)

**Classes**: `Suggestion`, `SuggestionEvent`, `Replacement`, `StubView`

**Functions**: `key_event()`, `make_controller()`, `test_on_text_change_emits_matching_suggestions_in_insertion_order_and_ignores_duplicates()`, `test_on_text_change_filters_suggestions_case_insensitively()`, `test_on_text_change_clears_suggestions_when_no_matches()`, `test_on_text_change_limits_the_number_of_results_to_five_and_preserve_insertion_order()`, `test_on_key_tab_applies_selected_completion()`, `test_on_key_down_and_up_cycle_selection()`

**Patterns**: Test Stub (mock view) pattern, Factory function for test setup

**Dependencies**: textual

**Complexity**: low

#### `tests/autocompletion/test_file_indexer.py`

**Purpose**: Integration test suite for the FileIndexer component, verifying that the index updates correctly in response to filesystem changes and configuration options.

**Exports**: `file_indexer`, `_wait_for`, `test_updates_index_on_file_creation`, `test_updates_index_on_file_deletion`, `test_updates_index_on_file_rename`, `test_updates_index_on_folder_rename`, `test_updates_index_incrementally_by_default`, `test_rebuilds_index_when_mass_change_threshold_is_exceeded`, `test_switching_between_roots_restarts_index`, `test_watcher_failure_does_not_break_existing_index` (+1 more)

**Functions**: `file_indexer()`, `_wait_for()`, `test_updates_index_on_file_creation()`, `test_updates_index_on_file_deletion()`, `test_updates_index_on_file_rename()`, `test_updates_index_on_folder_rename()`, `test_updates_index_incrementally_by_default()`, `test_rebuilds_index_when_mass_change_threshold_is_exceeded()`

**Patterns**: Fixture (pytest), Observer-like behaviour (watcher events), Polling/wait loop for async updates

**Dependencies**: pytest

**Complexity**: low

#### `tests/autocompletion/test_path_completer_recursive.py`

**Purpose**: Provides pytest tests for the PathCompleter class, verifying its recursive path autocompletion behavior under various query patterns.

**Functions**: `file_tree()`, `test_finds_files_recursively_by_filename()`, `test_finds_files_recursively_by_partial_path()`, `test_finds_files_recursively_with_subsequence()`, `test_finds_multiple_matches_recursively()`, `test_prioritizes_exact_path_matches()`, `test_finds_files_when_pattern_matches_directory_name()`

**Patterns**: pytest fixture pattern, unit test pattern

**Dependencies**: pytest

**Complexity**: low

#### `tests/autocompletion/test_fuzzy.py`

**Purpose**: Provides pytest unit tests for the `fuzzy_match` function, verifying its behavior across various matching scenarios such as prefixes, subsequences, case handling, and scoring.

**Functions**: `test_empty_pattern_matches_anything()`, `test_matches_exact_prefix()`, `test_no_match_when_characters_are_out_of_order()`, `test_treats_consecutive_characters_as_subsequence()`, `test_ignores_case()`, `test_treats_scattered_characters_as_subsequence()`, `test_treats_path_separator_as_word_boundary()`, `test_prefers_word_boundary_matching_over_subsequence()`

**Dependencies**: pytest

**Complexity**: low

#### `tests/autocompletion/test_path_prompt_transformer.py`

**Purpose**: Provides pytest test cases for the path prompt transformer, verifying handling of file embeddings, directory links, emails, missing files, binary files, size limits, quoted paths, and deduplication.

**Functions**: `test_treats_paths_to_files_as_embedded_resources()`, `test_treats_path_to_directory_as_resource_links()`, `test_keeps_emails_and_embeds_paths()`, `test_ignores_nonexistent_paths()`, `test_falls_back_to_link_for_binary_files()`, `test_excludes_supposed_binary_files_quickly_before_reading_content()`, `test_applies_max_embed_size_guard()`, `test_parses_paths_with_special_characters_when_quoted()`

**Patterns**: Unit testing with pytest, Test-driven verification of string transformation logic

**Dependencies**: pytest

**Complexity**: low

### Module: `tests/backend/`

#### `tests/backend/test_backend.py`

**Purpose**: Provides pytest test cases for the LLM backend implementations, verifying normal completions, streaming behavior, error handling, payload construction, and user‑agent handling.

**Exports**: `TestBackend`

**Classes**: `TestBackend`

**Patterns**: Factory (via BACKEND_FACTORY), Parametrized tests (pytest.mark.parametrize), Async testing

**Dependencies**: httpx, pytest, respx

**Complexity**: medium

### Module: `tests/backend/data/`

#### `tests/backend/data/mistral.py`

**Purpose**: Provides predefined test data structures for Mistral API responses (simple, tool, and streamed conversations) used in backend tests.

**Exports**: `SIMPLE_CONVERSATION_PARAMS`, `TOOL_CONVERSATION_PARAMS`, `STREAMED_SIMPLE_CONVERSATION_PARAMS`, `STREAMED_TOOL_CONVERSATION_PARAMS`

**Complexity**: low

#### `tests/backend/data/__init__.py`

**Purpose**: Defines simple type aliases for URL strings, JSON responses, result data dictionaries, and byte chunks used across the backend tests.

**Exports**: `Url`, `JsonResponse`, `ResultData`, `Chunk`

**Complexity**: low

#### `tests/backend/data/fireworks.py`

**Purpose**: Provides static test data fixtures for Fireworks AI API responses used in backend tests, including simple and tool-based conversations with both normal and streamed formats.

**Exports**: `SIMPLE_CONVERSATION_PARAMS`, `TOOL_CONVERSATION_PARAMS`, `STREAMED_SIMPLE_CONVERSATION_PARAMS`, `STREAMED_TOOL_CONVERSATION_PARAMS`

**Patterns**: Data fixture pattern, Parametrized test data

**Complexity**: low

### Module: `tests/cli/`

#### `tests/cli/test_clipboard.py`

**Purpose**: Provides pytest test cases for the CLI clipboard utilities, verifying behavior of copy_selection_to_clipboard and the OSC52 low‑level copy implementation.

**Exports**: `MockWidget`, `mock_app`, `test_copy_selection_to_clipboard_no_notification`, `test_copy_selection_to_clipboard_success_with_osc52`, `test_copy_selection_to_clipboard_osc52_fails_success_with_pyperclip`, `test_copy_selection_to_clipboard_osc52_and_pyperclip_fail_success_with_app_copy`, `test_copy_selection_to_clipboard_all_methods_fail`, `test_copy_selection_to_clipboard_multiple_widgets`, `test_copy_selection_to_clipboard_preview_shortening`, `test_copy_osc52_writes_correct_sequence`

**Classes**: `MockWidget`

**Functions**: `mock_app()`, `test_copy_selection_to_clipboard_no_notification()`, `test_copy_selection_to_clipboard_success_with_osc52()`, `test_copy_selection_to_clipboard_osc52_fails_success_with_pyperclip()`, `test_copy_selection_to_clipboard_osc52_and_pyperclip_fail_success_with_app_copy()`, `test_copy_selection_to_clipboard_all_methods_fail()`, `test_copy_selection_to_clipboard_multiple_widgets()`, `test_copy_selection_to_clipboard_preview_shortening()`

**Patterns**: Mocking (unittest.mock.patch, MagicMock), pytest fixtures, parameterized testing (pytest.mark.parametrize), fallback chain testing

**Dependencies**: pytest, textual, pyperclip, unittest.mock, base64

**Complexity**: medium

### Module: `tests/core/`

#### `tests/core/test_config_migration.py`

**Purpose**: Provides helper utilities for tests that migrate a Vibe configuration file, temporarily overriding the VibeConfig.dump_config method and restoring it after the test.

**Exports**: `_restore_dump_config`, `_migrate_config_file`, `_load_migrated_config`

**Patterns**: Context Manager, Monkey Patching, Classmethod Override

**Dependencies**: tomli_w

**Complexity**: low

#### `tests/core/test_config_resolution.py`

**Purpose**: Tests that the configuration resolution logic correctly prefers a local .vibe/config.toml, falls back to the global config, and respects the VIBE_HOME environment variable.

**Exports**: `TestResolveConfigFile`

**Classes**: `TestResolveConfigFile`

**Dependencies**: pytest

**Complexity**: low

### Module: `tests/mock/`

#### `tests/mock/mock_entrypoint.py`

**Purpose**: Provides a wrapper script that intercepts and mocks LLM calls during tests by loading mock data from an environment variable and patching backend methods.

**Exports**: `mock_llm_output`

**Functions**: `mock_llm_output()`

**Patterns**: Mocking via unittest.mock.patch, Iterator over predefined mock chunks

**Dependencies**: pydantic

**Complexity**: low

#### `tests/mock/mock_backend_factory.py`

**Purpose**: Provides a context manager for temporarily replacing a backend factory function in the global BACKEND_FACTORY mapping during tests.

**Exports**: `mock_backend_factory`

**Functions**: `mock_backend_factory()`

**Patterns**: Context Manager, Factory (Mocking)

**Complexity**: low

#### `tests/mock/utils.py`

**Purpose**: Provides utility functions to create mock LLMChunk objects for testing and to package them into an environment variable format for mock LLM responses.

**Exports**: `MOCK_DATA_ENV_VAR`, `mock_llm_chunk`, `get_mocking_env`

**Functions**: `mock_llm_chunk()`, `get_mocking_env()`

**Complexity**: low

### Module: `tests/onboarding/`

#### `tests/onboarding/test_ui_onboarding.py`

**Purpose**: Provides pytest‑asyncio tests that drive the onboarding Textual UI, verifying that the welcome flow, API‑key entry, and theme selection work and persist configuration files.

**Functions**: `test_ui_gets_through_the_onboarding_successfully()`, `test_ui_can_pick_a_theme_and_saves_selection()`

**Patterns**: Arrange‑Act‑Assert testing pattern, Async test execution (pytest‑asyncio), Page Object‑like interaction via Textual Pilot

**Dependencies**: pytest, textual

**Complexity**: low

#### `tests/onboarding/test_run_onboarding.py`

**Purpose**: Provides pytest test cases for the onboarding.run_onboarding function, checking behavior on cancellation, save errors, and successful completion.

**Exports**: `StubApp`, `_exit_raiser`, `test_exits_on_cancel`, `test_warns_on_save_error`, `test_successfully_completes`

**Classes**: `StubApp`

**Functions**: `_exit_raiser()`, `test_exits_on_cancel()`, `test_warns_on_save_error()`, `test_successfully_completes()`

**Patterns**: Test Stub, Monkeypatching, Exception testing (pytest.raises)

**Dependencies**: pytest, textual

**Complexity**: low

### Module: `tests/snapshots/`

#### `tests/snapshots/test_ui_snapshot_code_block_horizontal_scrolling.py`

**Purpose**: Test that a very long code block inside a markdown message can be horizontally scrolled in the Textual UI snapshot.

**Exports**: `test_snapshot_allows_horizontal_scrolling_for_long_code_blocks`

**Functions**: `test_snapshot_allows_horizontal_scrolling_for_long_code_blocks()`

**Dependencies**: textual, pytest

**Complexity**: low

#### `tests/snapshots/base_snapshot_test_app.py`

**Purpose**: Provides a default VibeConfig for snapshot testing and defines BaseSnapshotTestApp, a VibeApp subclass that injects a FakeBackend and hides the chat input cursor for deterministic visual tests.

**Exports**: `default_config`, `BaseSnapshotTestApp`

**Classes**: `BaseSnapshotTestApp`

**Functions**: `default_config()`

**Patterns**: Dependency Injection, Subclassing

**Dependencies**: rich, textual

**Complexity**: low

#### `tests/snapshots/snap_compare.py`

**Purpose**: Defines a typing Protocol `SnapCompare` that specifies the signature of a snapshot comparison callable used in tests.

**Exports**: `SnapCompare`

**Classes**: `SnapCompare`

**Patterns**: Protocol (structural typing), Callable signature definition

**Dependencies**: textual

**Complexity**: low

#### `tests/snapshots/test_ui_snapshot_basic_conversation.py`

**Purpose**: Defines a snapshot test application class that sets up an Agent with a fake backend for UI testing, and provides a pytest test that captures a basic conversation snapshot.

**Exports**: `SnapshotTestAppWithConversation`, `test_snapshot_shows_basic_conversation`

**Classes**: `SnapshotTestAppWithConversation`

**Functions**: `test_snapshot_shows_basic_conversation()`

**Patterns**: Dependency Injection, Factory (FakeBackend creation), Test pattern (pytest snapshot testing)

**Dependencies**: textual

**Complexity**: low

#### `tests/snapshots/test_ui_snapshot_release_update_notification.py`

**Purpose**: Defines a snapshot test application that enables update checks with fake update components and a test function that verifies the UI shows a release update notification using SnapCompare.

**Exports**: `SnapshotTestAppWithUpdate`, `test_snapshot_shows_release_update_notification`

**Classes**: `SnapshotTestAppWithUpdate`

**Functions**: `test_snapshot_shows_release_update_notification()`

**Patterns**: Factory, Dependency Injection, Snapshot Testing

**Dependencies**: textual, vibe

**Complexity**: low

### Module: `tests/stubs/`

#### `tests/stubs/fake_backend.py`

**Purpose**: Provides a minimal asynchronous backend stub for tests, simulating LLM completions and token counting without network calls.

**Exports**: `FakeBackend`

**Classes**: `FakeBackend`

**Patterns**: Test double / Stub, Dependency injection

**Dependencies**: collections (stdlib), vibe.core (project internal), tests.mock (project internal)

**Complexity**: low

#### `tests/stubs/fake_tool.py`

**Purpose**: Provides a stub implementation of a tool for testing, defining dummy argument, result, and state models and a simple async run method.

**Exports**: `FakeToolArgs`, `FakeToolResult`, `FakeToolState`, `FakeTool`

**Classes**: `FakeToolArgs`, `FakeToolResult`, `FakeToolState`, `FakeTool`

**Patterns**: Template Method

**Dependencies**: pydantic

**Complexity**: low

#### `tests/stubs/fake_connection.py`

**Purpose**: Provides a fake implementation of AgentSideConnection for use in tests, delegating to a supplied Agent factory and recording session notifications.

**Exports**: `FakeAgentSideConnection`

**Classes**: `FakeAgentSideConnection`

**Patterns**: Mock Object, Dependency Injection, Context Manager

**Complexity**: low

### Module: `tests/tools/`

#### `tests/tools/test_grep.py`

**Purpose**: Provides a comprehensive pytest test suite for the Grep tool implementation, covering backend detection, pattern matching, ignore handling, truncation, and state tracking.

**Exports**: `grep`, `grep_gnu_only`, `test_detects_ripgrep_when_available`, `test_falls_back_to_gnu_grep`, `test_raises_error_if_no_grep_available`, `test_finds_pattern_in_file`, `test_finds_multiple_matches`, `test_returns_empty_on_no_matches`, `test_fails_with_empty_pattern`, `test_fails_with_nonexistent_path` (+10 more)

**Classes**: `TestGnuGrepBackend`, `TestRipgrepBackend`

**Functions**: `grep()`, `grep_gnu_only()`, `test_detects_ripgrep_when_available()`, `test_falls_back_to_gnu_grep()`, `test_raises_error_if_no_grep_available()`, `test_finds_pattern_in_file()`, `test_finds_multiple_matches()`, `test_returns_empty_on_no_matches()`

**Patterns**: Fixture pattern (pytest fixtures), Async test pattern (pytest-asyncio)

**Dependencies**: pytest

**Complexity**: medium

#### `tests/tools/test_ui_bash_execution.py`

**Purpose**: Provides pytest async tests for the Textual UI bash execution feature, verifying output handling, exit status icons, and non‑UTF8 handling.

**Exports**: `vibe_config`, `vibe_app`, `_wait_for_bash_output_message`, `assert_no_command_error`, `test_ui_reports_no_output`, `test_ui_shows_success_in_case_of_zero_code`, `test_ui_shows_failure_in_case_of_non_zero_code`, `test_ui_handles_non_utf8_output`, `test_ui_handles_utf8_output`, `test_ui_handles_non_utf8_stderr`

**Functions**: `vibe_config()`, `vibe_app()`, `assert_no_command_error()`, `test_ui_reports_no_output()`, `test_ui_shows_success_in_case_of_zero_code()`, `test_ui_shows_failure_in_case_of_non_zero_code()`, `test_ui_handles_non_utf8_output()`, `test_ui_handles_utf8_output()`

**Patterns**: pytest fixtures, async test functions, test utility helper

**Dependencies**: pytest, textual

**Complexity**: low

#### `tests/tools/test_bash.py`

**Purpose**: Provides pytest test cases for the Bash tool implementation, verifying command execution, error handling, working directory, timeouts, output truncation, encoding, and allowlist/denylist logic.

**Exports**: `bash`, `test_runs_echo_successfully`, `test_fails_cat_command_with_missing_file`, `test_uses_effective_workdir`, `test_handles_timeout`, `test_truncates_output_to_max_bytes`, `test_decodes_non_utf8_bytes`, `test_check_allowlist_denylist`

**Functions**: `bash()`, `test_runs_echo_successfully()`, `test_fails_cat_command_with_missing_file()`, `test_uses_effective_workdir()`, `test_handles_timeout()`, `test_truncates_output_to_max_bytes()`, `test_decodes_non_utf8_bytes()`, `test_check_allowlist_denylist()`

**Patterns**: pytest fixtures, async test functions with pytest.mark.asyncio, assert-based testing, exception expectation with pytest.raises

**Dependencies**: pytest

**Complexity**: low

#### `tests/tools/test_manager_get_tool_config.py`

**Purpose**: Provides pytest unit tests for the ToolManager.get_tool_config method, verifying default configurations, user overrides, unknown tool handling, and workdir propagation.

**Exports**: `config`, `tool_manager`, `test_returns_default_config_when_no_overrides`, `test_merges_user_overrides_with_defaults`, `test_preserves_tool_specific_fields_from_overrides`, `test_falls_back_to_base_config_for_unknown_tool`, `test_applies_workdir_from_vibe_config`

**Functions**: `config()`, `tool_manager()`, `test_returns_default_config_when_no_overrides()`, `test_merges_user_overrides_with_defaults()`, `test_preserves_tool_specific_fields_from_overrides()`, `test_falls_back_to_base_config_for_unknown_tool()`, `test_applies_workdir_from_vibe_config()`

**Dependencies**: pytest

**Complexity**: low

### Module: `tests/update_notifier/`

#### `tests/update_notifier/test_filesystem_update_cache_repository.py`

**Purpose**: Provides pytest‑asyncio test cases for the FileSystemUpdateCacheRepository, verifying its behavior when reading, writing, and handling errors with the update cache file.

**Exports**: `test_reads_cache_from_file_when_present`, `test_returns_none_when_cache_file_is_missing`, `test_returns_none_when_cache_file_is_corrupted`, `test_overwrites_existing_cache`, `test_silently_ignores_errors_when_writing_cache_fails`

**Functions**: `test_reads_cache_from_file_when_present()`, `test_returns_none_when_cache_file_is_missing()`, `test_returns_none_when_cache_file_is_corrupted()`, `test_overwrites_existing_cache()`, `test_silently_ignores_errors_when_writing_cache_fails()`

**Patterns**: pytest, pytest-asyncio, Arrange-Act-Assert testing pattern

**Dependencies**: pytest, pytest-asyncio

**Complexity**: low

#### `tests/update_notifier/test_github_version_update_gateway.py`

**Purpose**: Provides a suite of pytest asynchronous tests for the GitHubVersionUpdateGateway, verifying version retrieval, tag handling, draft/prerelease filtering, and error handling.

**Exports**: `Handler`, `GITHUB_API_URL`, `_raise_connect_timeout`, `test_retrieves_latest_version_when_available`, `test_strips_uppercase_prefix_from_tag_name`, `test_considers_no_update_available_when_no_releases_are_found`, `test_considers_no_update_available_when_only_drafts_and_prereleases_are_found`, `test_picks_the_most_recently_published_non_prerelease_and_non_draft`, `test_ignores_draft_releases_and_prereleases`, `test_retrieves_nothing_when_fetching_update_fails`

**Functions**: `test_retrieves_latest_version_when_available()`, `test_strips_uppercase_prefix_from_tag_name()`, `test_considers_no_update_available_when_no_releases_are_found()`, `test_considers_no_update_available_when_only_drafts_and_prereleases_are_found()`, `test_picks_the_most_recently_published_non_prerelease_and_non_draft()`, `test_ignores_draft_releases_and_prereleases()`, `test_retrieves_nothing_when_fetching_update_fails()`

**Patterns**: Parametrize (pytest), Async test (pytest-asyncio), Dependency injection (client passed to gateway), Mock transport for HTTP calls

**Dependencies**: httpx, pytest

**Complexity**: medium

#### `tests/update_notifier/test_ui_version_update_notification.py`

**Purpose**: Provides pytest asynchronous test cases for the VibeApp UI version‑update notification flow, checking that notifications are shown, hidden, or warned based on update availability, cache state, and configuration.

**Exports**: `_wait_for_notification`, `_assert_no_notifications`, `vibe_config_with_update_checks_enabled`, `VibeAppFactory`, `make_vibe_app`, `test_ui_displays_update_notification`, `test_ui_does_not_display_update_notification_when_not_available`, `test_ui_displays_warning_toast_when_check_fails`, `test_ui_does_not_invoke_gateway_nor_show_error_notification_when_update_checks_are_disabled`, `test_ui_does_not_invoke_gateway_nor_show_update_notification_when_update_checks_are_disabled` (+2 more)

**Classes**: `VibeAppFactory`

**Functions**: `vibe_config_with_update_checks_enabled()`, `make_vibe_app()`, `test_ui_displays_update_notification()`, `test_ui_does_not_display_update_notification_when_not_available()`, `test_ui_displays_warning_toast_when_check_fails()`, `test_ui_does_not_invoke_gateway_nor_show_error_notification_when_update_checks_are_disabled()`, `test_ui_does_not_invoke_gateway_nor_show_update_notification_when_update_checks_are_disabled()`, `test_ui_does_not_show_toast_when_update_is_known_in_recent_cache_already()`

**Patterns**: Factory (make_vibe_app fixture returns a factory), Protocol (VibeAppFactory), Fixture (pytest fixtures for setup), Observer (notifications observed via app._notifications)

**Dependencies**: pytest, textual

**Complexity**: medium

#### `tests/update_notifier/test_version_update_use_case.py`

**Purpose**: Test suite for the version update use case, verifying behavior of get_update_if_available with various scenarios and cache handling.

**Exports**: `current_timestamp`, `test_retrieves_the_latest_version_update_when_available`, `test_retrieves_nothing_when_the_current_version_is_the_latest`, `test_retrieves_nothing_when_the_current_version_is_greater_than_the_latest`, `test_retrieves_nothing_when_no_version_is_available`, `test_retrieves_nothing_when_latest_version_is_invalid`, `test_replaces_hyphens_with_plus_signs_in_latest_version_to_conform_with_PEP_440`, `test_retrieves_nothing_when_current_version_is_invalid`, `test_raises_version_update_error`, `test_notifies_and_updates_cache_when_repository_is_empty` (+5 more)

**Functions**: `current_timestamp()`, `test_retrieves_the_latest_version_update_when_available()`, `test_retrieves_nothing_when_the_current_version_is_the_latest()`, `test_retrieves_nothing_when_the_current_version_is_greater_than_the_latest()`, `test_retrieves_nothing_when_no_version_is_available()`, `test_retrieves_nothing_when_latest_version_is_invalid()`, `test_replaces_hyphens_with_plus_signs_in_latest_version_to_conform_with_PEP_440()`, `test_retrieves_nothing_when_current_version_is_invalid()`

**Patterns**: pytest fixtures, pytest.mark.asyncio, pytest parametrization, dependency injection via test doubles (FakeVersionUpdateGateway, FakeUpdateCacheRepository)

**Dependencies**: pytest

**Complexity**: medium

#### `tests/update_notifier/test_pypi_version_update_gateway.py`

**Purpose**: Provides pytest asynchronous tests for the PyPIVersionUpdateGateway, verifying its behavior when fetching version updates from the PyPI API under various scenarios.

**Exports**: `test_retrieves_nothing_when_no_versions_are_available`, `test_retrieves_the_latest_non_yanked_version`, `test_retrieves_nothing_when_only_yanked_versions_are_available`, `test_does_not_match_versions_by_substring`, `_raise_connect_timeout`, `test_retrieves_nothing_when_fetching_update_fails`

**Functions**: `test_retrieves_nothing_when_no_versions_are_available()`, `test_retrieves_the_latest_non_yanked_version()`, `test_retrieves_nothing_when_only_yanked_versions_are_available()`, `test_does_not_match_versions_by_substring()`, `test_retrieves_nothing_when_fetching_update_fails()`

**Patterns**: pytest async tests, parametrized testing, mock transport for HTTP client

**Dependencies**: httpx, pytest

**Complexity**: low

### Module: `tests/update_notifier/adapters/`

#### `tests/update_notifier/adapters/fake_version_update_gateway.py`

**Purpose**: Provides a fake implementation of VersionUpdateGateway for testing, allowing simulated version update responses or errors.

**Exports**: `FakeVersionUpdateGateway`

**Classes**: `FakeVersionUpdateGateway`

**Patterns**: Test double (Fake), Adapter

**Complexity**: low

#### `tests/update_notifier/adapters/fake_update_cache_repository.py`

**Purpose**: Provides a lightweight in‑memory fake implementation of the UpdateCacheRepository interface for testing purposes.

**Exports**: `FakeUpdateCacheRepository`

**Classes**: `FakeUpdateCacheRepository`

**Patterns**: Test Double (Fake), Repository Pattern

**Complexity**: low

### Module: `vibe/`

#### `vibe/__init__.py`

**Purpose**: Defines the project root directory path for the Vibe package by exposing a VIBE_ROOT constant.

**Exports**: `VIBE_ROOT`

**Complexity**: low

### Module: `vibe/acp/`

#### `vibe/acp/entrypoint.py`

**Purpose**: Provides a command‑line entry point for running Mistral Vibe in ACP mode, handling a --setup flag to run onboarding or launching the ACP server.

**Exports**: `Arguments`, `parse_arguments`, `main`

**Classes**: `Arguments`

**Functions**: `parse_arguments()`, `main()`

**Patterns**: Command‑line entrypoint pattern, Dataclass as simple argument container

**Complexity**: low

#### `vibe/acp/utils.py`

**Purpose**: Provides enums and helper mappings for Vibe session approval modes and tool permission options, converting them to the ACP schema objects.

**Exports**: `VibeSessionMode`, `ToolOption`, `TOOL_OPTIONS`

**Classes**: `VibeSessionMode`, `ToolOption`

**Patterns**: Enum, Adapter

**Complexity**: low

#### `vibe/acp/acp_agent.py`

**Purpose**: Implements the ACP (Assistant Communication Protocol) agent for Mistral Vibe, handling session management, prompt processing, tool calls, approvals and communication over the ACP connection.

**Exports**: `VibeAcpAgent`, `run_acp_server`, `AcpSession`, `_run_acp_server`

**Classes**: `AcpSession`, `VibeAcpAgent`

**Functions**: `run_acp_server()`

**Patterns**: Template Method (overriding AcpAgent methods), Callback (approval callback), Factory (session creation), Observer (sending SessionNotification updates)

**Dependencies**: acp, pydantic

**Complexity**: medium

### Module: `vibe/acp/tools/`

#### `vibe/acp/tools/session_update.py`

**Purpose**: Provides functions that translate tool call and tool result events into session update objects for the ACP UI layer.

**Exports**: `tool_call_session_update`, `tool_result_session_update`, `TOOL_KIND`

**Functions**: `tool_call_session_update()`, `tool_result_session_update()`

**Patterns**: Adapter (ToolUIDataAdapter), Protocol / Interface (ToolCallSessionUpdateProtocol, ToolResultSessionUpdateProtocol), Factory‑like conditional creation of content objects

**Complexity**: medium

#### `vibe/acp/tools/base.py`

**Purpose**: Provides base classes and state handling for ACP (Agent-side Connection Protocol) tools, including utilities for updating ACP sessions and managing tool state.

**Exports**: `ToolCallSessionUpdateProtocol`, `ToolResultSessionUpdateProtocol`, `AcpToolState`, `BaseAcpTool`

**Classes**: `ToolCallSessionUpdateProtocol`, `ToolResultSessionUpdateProtocol`, `AcpToolState`, `BaseAcpTool`

**Patterns**: Abstract Base Class, Protocol (runtime‑checkable), Factory method (get_tool_instance), Template Method (abstract _get_tool_state_class)

**Dependencies**: pydantic

**Complexity**: medium

### Module: `vibe/acp/tools/builtins/`

#### `vibe/acp/tools/builtins/search_replace.py`

**Purpose**: Implements an ACP‑enabled search‑and‑replace tool by extending the core SearchReplace logic, handling remote file reads/writes and session updates.

**Exports**: `AcpSearchReplaceState`, `SearchReplace`

**Classes**: `AcpSearchReplaceState`, `SearchReplace`

**Patterns**: Adapter (adapts core SearchReplace to ACP transport), Template Method (subclass overrides abstract workflow methods), Mixin/Multiple Inheritance

**Complexity**: medium

#### `vibe/acp/tools/builtins/bash.py`

**Purpose**: Provides an ACP‑compatible Bash tool that creates a remote terminal, executes a command with optional timeout and environment variables, streams the output, and reports the result back to the caller.

**Exports**: `AcpBashState`, `Bash`

**Classes**: `AcpBashState`, `Bash`

**Patterns**: Inheritance, Async/Await, Factory Method (via _get_tool_state_class), Template Method (run overridden from CoreBashTool)

**Dependencies**: asyncio (standard library), shlex (standard library), acp (project package), vibe (project package)

**Complexity**: medium

#### `vibe/acp/tools/builtins/read_file.py`

**Purpose**: Implements an ACP‑enabled read‑file tool that delegates to the core read‑file implementation and retrieves file contents via an ACP ReadTextFileRequest.

**Exports**: `AcpReadFileState`, `ReadFile`, `ReadFileResult`

**Classes**: `AcpReadFileState`, `ReadFile`

**Patterns**: Template Method (subclass overrides hook methods), Factory (tool state class creation via _get_tool_state_class)

**Dependencies**: acp

**Complexity**: medium

#### `vibe/acp/tools/builtins/todo.py`

**Purpose**: Wraps the core Todo tool for the ACP framework and converts Todo tool results into agent plan updates.

**Exports**: `AcpTodoState`, `Todo`, `TodoArgs`

**Classes**: `AcpTodoState`, `Todo`

**Patterns**: Adapter, Template Method

**Complexity**: low

#### `vibe/acp/tools/builtins/write_file.py`

**Purpose**: Implements an ACP‑aware WriteFile tool by extending the core WriteFile implementation and handling session updates for tool calls and results.

**Exports**: `AcpWriteFileState`, `WriteFile`

**Classes**: `AcpWriteFileState`, `WriteFile`

**Patterns**: Adapter (wraps core tool with ACP behavior), Factory Method (for creating the appropriate tool state class)

**Dependencies**: acp

**Complexity**: medium

### Module: `vibe/cli/`

#### `vibe/cli/entrypoint.py`

**Purpose**: Provides the command‑line entry point for the Vibe application, parsing arguments, loading configuration, handling session continuation/resume, and launching either the interactive textual UI or a programmatic run.

**Exports**: `parse_arguments`, `get_prompt_from_stdin`, `load_config_or_exit`, `main`

**Functions**: `parse_arguments()`, `get_prompt_from_stdin()`, `load_config_or_exit()`, `main()`

**Patterns**: Command‑line interface (CLI) pattern, Factory (default config creation), Singleton‑like access for global VibeConfig

**Dependencies**: rich

**Complexity**: medium

#### `vibe/cli/history_manager.py`

**Purpose**: Provides a simple command‑line history manager that stores, loads, and navigates past input entries with a configurable maximum size.

**Exports**: `HistoryManager`

**Classes**: `HistoryManager`

**Complexity**: low

#### `vibe/cli/clipboard.py`

**Purpose**: Provides utilities to copy selected text from a Textual app to the system clipboard, trying OSC52, pyperclip, and the app's own clipboard method, and shows a notification.

**Exports**: `copy_selection_to_clipboard`

**Functions**: `copy_selection_to_clipboard()`

**Patterns**: Chain of Responsibility (fallback copy methods until one succeeds)

**Dependencies**: pyperclip, textual

**Complexity**: medium

#### `vibe/cli/commands.py`

**Purpose**: Defines a simple command registry for the VIBE CLI, providing command metadata, alias lookup, and help text generation.

**Exports**: `Command`, `CommandRegistry`

**Classes**: `Command`, `CommandRegistry`

**Patterns**: Registry pattern

**Complexity**: low

### Module: `vibe/cli/autocompletion/`

#### `vibe/cli/autocompletion/path_completion.py`

**Purpose**: Provides a controller for path autocompletion in the CLI, computing suggestions asynchronously and handling user interactions such as navigation and selection.

**Exports**: `PathCompletionController`, `MAX_SUGGESTIONS_COUNT`

**Classes**: `PathCompletionController`

**Patterns**: Controller (MVC) pattern, Executor/Worker pattern for async computation, Observer-like callback via Future.add_done_callback

**Dependencies**: textual

**Complexity**: medium

#### `vibe/cli/autocompletion/slash_command.py`

**Purpose**: Provides a controller that manages slash‑command autocompletion in the CLI, interfacing a CommandCompleter with a CompletionView and handling key events.

**Exports**: `MAX_SUGGESTIONS_COUNT`, `SlashCommandController`

**Classes**: `SlashCommandController`

**Patterns**: Controller pattern, Command pattern, Observer (event handling)

**Dependencies**: textual

**Complexity**: medium

#### `vibe/cli/autocompletion/base.py`

**Purpose**: Defines core abstractions for CLI autocompletion: an enumeration of possible completion handling results and a protocol that UI views must implement to render and manage completion suggestions.

**Exports**: `CompletionResult`, `CompletionView`

**Classes**: `CompletionResult`, `CompletionView`

**Patterns**: Protocol (duck typing), Enum

**Complexity**: low

### Module: `vibe/cli/init/`

#### `vibe/cli/init/discovery.py`

**Purpose**: Scans a codebase to discover relevant files, builds a directory tree representation, classifies files (source, config, docs, packages, entry points), and handles chunking for large files.

**Exports**: `MAX_FILE_SIZE_BYTES`, `CHUNK_SIZE_CHARS`, `DEFAULT_IGNORE_PATTERNS`, `SOURCE_EXTENSIONS`, `CONFIG_EXTENSIONS`, `DOC_EXTENSIONS`, `PACKAGE_FILES`, `ENTRY_POINT_PATTERNS`, `FileInfo`, `DiscoveryResult` (+7 more)

**Classes**: `FileInfo`, `DiscoveryResult`

**Functions**: `load_gitignore_patterns()`, `is_ignored()`, `classify_file()`, `build_tree_structure()`, `discover_codebase()`, `get_file_content()`, `get_chunk_count()`

**Patterns**: Data Class, Recursive Traversal, Factory‑style function for building tree representation

**Complexity**: medium

#### `vibe/cli/init/analysis_index.py`

**Purpose**: Provides data structures and builder logic to create a JSON index of the VIBE-ANALYSIS.md document, enabling fast lookup of sections, files, and topics without scanning the full markdown.

**Exports**: `SubsectionIndex`, `FileMention`, `FilePositions`, `FileEntry`, `SectionIndex`, `AnalysisIndex`, `build_index_from_context`, `IndexBuilder`

**Classes**: `SubsectionIndex`, `FileMention`, `FilePositions`, `FileEntry`, `SectionIndex`

**Functions**: `build_index_from_context()`

**Patterns**: Builder pattern (IndexBuilder), Dataclass for declarative data structures

**Dependencies**: standard library (dataclasses, datetime, json, pathlib, typing), project packages (vibe.cli.init.contracts, vibe.cli.init.glossary, vibe.cli.init.indexer)

**Complexity**: medium

#### `vibe/cli/init/__init__.py`

**Purpose**: Provides the /init command implementation for the Vibe CLI by re‑exporting the core functions and classes needed to generate a VIBE-ANALYSIS.md file.

**Exports**: `execute_init`, `extract_contracts`, `ContractsResult`, `get_section_names`

**Complexity**: low

#### `vibe/cli/init/generator.py`

**Purpose**: Provides the core logic for generating the VIBE-ANALYSIS.md documentation file, orchestrating per‑section LLM prompts, assembling the markdown with controlled headers, and building a detailed JSON index for fast lookup.

**Exports**: `GenerationContext`, `SECTION_PROMPTS`, `GenerationResult`, `generate_vibe_md`, `update_vibe_md`, `get_section_names`

**Classes**: `GenerationContext`, `GenerationResult`

**Functions**: `generate_vibe_md()`, `update_vibe_md()`, `get_section_names()`

**Patterns**: Builder pattern (IndexBuilder used to incrementally construct the JSON index), Factory‑like prompt templates (SECTION_PROMPTS dictionary), Async generator pattern for streaming LLM completions, Dataclass usage for simple containers

**Dependencies**: vibe (internal package providing analysis_index, contracts, discovery, glossary, indexer), standard library modules: dataclasses, datetime, logging, pathlib, typing

**Complexity**: medium

#### `vibe/cli/init/indexer.py`

**Purpose**: Implements the indexing phase of the VIBE initialization workflow: it analyzes source files (optionally in chunks) using an LLM, merges chunk analyses, and builds a comprehensive INDEX data structure describing each file, its relationships, patterns, and detected frameworks.

**Exports**: `FunctionInfo`, `ClassInfo`, `FileRelationship`, `FileAnalysis`, `IndexResult`, `IndexProgress`, `analyze_file_chunk`, `merge_chunk_analyses`, `_parse_analysis_json`, `_dict_to_file_analysis` (+2 more)

**Classes**: `FunctionInfo`, `ClassInfo`, `FileRelationship`, `FileAnalysis`, `IndexResult`

**Functions**: `analyze_file_chunk()`, `merge_chunk_analyses()`, `build_index()`, `format_index_as_markdown()`

**Patterns**: async processing, LLM‑driven analysis, chunked file handling, builder pattern for IndexResult

**Dependencies**: vibe (internal package), dataclasses (stdlib), json (stdlib), logging (stdlib), re (stdlib)

**Complexity**: medium

#### `vibe/cli/init/contracts.py`

**Purpose**: Defines data structures and functions to aggregate file dependency relationships, build a dependency graph, identify hub files, and render the contracts section for VIBE-ANALYSIS.md.

**Exports**: `DependencyEdge`, `FileNode`, `ContractsResult`, `extract_contracts`, `_normalize_import_to_path`, `_add_edge_to_graph`, `format_contracts_as_markdown`

**Classes**: `DependencyEdge`, `FileNode`, `ContractsResult`

**Functions**: `extract_contracts()`, `format_contracts_as_markdown()`

**Patterns**: DataClass

**Complexity**: medium

#### `vibe/cli/init/executor.py`

**Purpose**: Coordinates the entire `/init` workflow by running discovery, indexing, glossary extraction, contracts extraction, and VIBE-ANALYSIS.md generation, while reporting progress.

**Exports**: `InitProgress`, `InitResult`, `execute_init`, `format_init_summary`

**Classes**: `InitProgress`, `InitResult`

**Functions**: `execute_init()`, `format_init_summary()`

**Complexity**: medium

#### `vibe/cli/init/glossary.py`

**Purpose**: Implements Phase 3 of the init workflow: extracts acronyms, domain terms, project‑specific jargon, and frameworks from indexed project content and builds a structured GlossaryResult for later markdown generation.

**Exports**: `GlossaryEntry`, `GlossaryResult`, `GLOSSARY_EXTRACTION_PROMPT`, `extract_glossary`, `_build_index_summary`, `_collect_key_concepts`, `_read_documentation`, `_parse_glossary_json`, `format_glossary_as_markdown`, `build_glossary_context_prompt`

**Classes**: `GlossaryEntry`, `GlossaryResult`

**Functions**: `extract_glossary()`, `format_glossary_as_markdown()`, `build_glossary_context_prompt()`

**Complexity**: medium

### Module: `vibe/cli/textual_ui/`

#### `vibe/cli/textual_ui/app.py`

**Purpose**: Defines the Textual UI application for the Vibe CLI, handling rendering, user input, command execution, agent interaction, and update notifications.

**Exports**: `BottomApp`, `VibeApp`, `run_textual_ui`

**Classes**: `BottomApp`, `VibeApp`

**Functions**: `run_textual_ui()`

**Patterns**: Observer (event handling via Textual messages), Command (CommandRegistry dispatch), Async Task / Future management, Factory (widget creation based on UI state), MVC‑like separation (widgets as view, VibeApp as controller)

**Dependencies**: textual, asyncio (stdlib), enum (stdlib), subprocess (stdlib), typing (stdlib)

**Complexity**: high

### Module: `vibe/cli/textual_ui/handlers/`

#### `vibe/cli/textual_ui/handlers/event_handler.py`

**Purpose**: Provides an EventHandler class that processes different UI events (tool calls, tool results, assistant messages, compact start/end) and mounts the appropriate widgets in the Textual UI.

**Exports**: `EventHandler`

**Classes**: `EventHandler`

**Patterns**: Observer (event handling), Handler

**Dependencies**: textual

**Complexity**: medium

#### `vibe/cli/textual_ui/handlers/__init__.py`

**Purpose**: Provides a package‑level shortcut by re‑exporting the EventHandler class for easier imports within the textual UI handlers package.

**Exports**: `EventHandler`

**Complexity**: low

### Module: `vibe/cli/textual_ui/renderers/`

#### `vibe/cli/textual_ui/renderers/__init__.py`

**Purpose**: Re‑exports the `get_renderer` function from the internal `tool_renderers` module for convenient access.

**Exports**: `get_renderer`

**Patterns**: Facade (module re‑export)

**Complexity**: low

#### `vibe/cli/textual_ui/renderers/tool_renderers.py`

**Purpose**: Defines renderer classes that map tool results to appropriate Textual UI widgets and prepares data for approval and result display.

**Exports**: `ToolRenderer`, `BashRenderer`, `WriteFileRenderer`, `SearchReplaceRenderer`, `TodoRenderer`, `ReadFileRenderer`, `GrepRenderer`, `get_renderer`

**Classes**: `ToolRenderer`, `BashRenderer`, `WriteFileRenderer`, `SearchReplaceRenderer`, `TodoRenderer`

**Functions**: `get_renderer()`

**Patterns**: Factory (renderer registry), Template Method (subclass overrides of base renderer methods)

**Complexity**: medium

### Module: `vibe/cli/textual_ui/widgets/`

#### `vibe/cli/textual_ui/widgets/approval_app.py`

**Purpose**: Defines a Textual UI widget that presents an approval dialog for a tool command, handling user navigation, selection, and emitting approval or rejection messages.

**Exports**: `ApprovalApp`

**Classes**: `ApprovalApp`

**Patterns**: Observer (Textual Message system), Command (action methods for key bindings)

**Dependencies**: textual

**Complexity**: medium

#### `vibe/cli/textual_ui/widgets/loading.py`

**Purpose**: Provides a Textual widget that displays an animated loading spinner with gradient colors, status text, and optional Easter‑egg messages.

**Exports**: `LoadingWidget`

**Classes**: `LoadingWidget`

**Patterns**: Observer (uses set_interval callbacks), Component composition (Textual widget)

**Dependencies**: textual

**Complexity**: medium

#### `vibe/cli/textual_ui/widgets/path_display.py`

**Purpose**: Provides a Textual UI widget that displays a filesystem path, abbreviating the user's home directory with a tilde.

**Exports**: `PathDisplay`

**Classes**: `PathDisplay`

**Patterns**: Adapter

**Dependencies**: textual

**Complexity**: low

#### `vibe/cli/textual_ui/widgets/mode_indicator.py`

**Purpose**: Defines a Textual UI widget that displays and toggles the auto‑approve mode indicator.

**Exports**: `ModeIndicator`

**Classes**: `ModeIndicator`

**Dependencies**: textual

**Complexity**: low

#### `vibe/cli/textual_ui/widgets/tools.py`

**Purpose**: Provides Textual UI widgets for displaying tool call information and tool result output, including handling of success, error, and skipped states with collapsible views.

**Exports**: `ToolCallMessage`, `ToolResultMessage`

**Classes**: `ToolCallMessage`, `ToolResultMessage`

**Patterns**: Factory (renderer selection via get_renderer), Strategy (different result widget types selected at runtime)

**Dependencies**: textual

**Complexity**: medium

#### `vibe/cli/textual_ui/widgets/compact.py`

**Purpose**: Defines a CompactMessage widget that displays the progress and results of conversation history compaction, including blinking status, token reduction details, and error handling.

**Exports**: `CompactMessage`

**Classes**: `CompactMessage`

**Patterns**: Inheritance, Template Method (overriding get_content)

**Complexity**: low

#### `vibe/cli/textual_ui/widgets/blinking_message.py`

**Purpose**: Provides a Textual UI widget that displays a blinking dot next to a message and can be stopped with a success or error indication.

**Exports**: `BlinkingMessage`

**Classes**: `BlinkingMessage`

**Patterns**: Observer (uses Textual's event loop and timers), Template Method (overrides compose method to build UI)

**Dependencies**: textual, typing

**Complexity**: low

#### `vibe/cli/textual_ui/widgets/tool_widgets.py`

**Purpose**: Defines a collection of Textual UI widgets that display approval prompts and results for various tool actions (bash commands, file writes, search‑replace, todos, file reads, grep, etc.).

**Exports**: `ToolApprovalWidget`, `ToolResultWidget`, `BashApprovalWidget`, `BashResultWidget`, `WriteFileApprovalWidget`, `WriteFileResultWidget`, `SearchReplaceApprovalWidget`, `SearchReplaceResultWidget`, `TodoApprovalWidget`, `TodoResultWidget` (+4 more)

**Classes**: `ToolApprovalWidget`, `ToolResultWidget`, `BashApprovalWidget`, `BashResultWidget`, `WriteFileApprovalWidget`

**Patterns**: Template Method, Inheritance

**Dependencies**: textual

**Complexity**: medium

#### `vibe/cli/textual_ui/widgets/context_progress.py`

**Purpose**: Defines a Textual widget that reactively displays token usage progress as a percentage of a maximum token count.

**Exports**: `TokenState`, `ContextProgress`

**Classes**: `TokenState`, `ContextProgress`

**Patterns**: Observer (reactive watch)

**Dependencies**: textual

**Complexity**: low

#### `vibe/cli/textual_ui/widgets/messages.py`

**Purpose**: Defines a collection of Textual UI widget classes for displaying different kinds of messages (user, assistant, command, interrupt, bash output, and error) within the Vibe CLI.

**Exports**: `UserMessage`, `AssistantMessage`, `UserCommandMessage`, `InterruptMessage`, `BashOutputMessage`, `ErrorMessage`

**Classes**: `UserMessage`, `AssistantMessage`, `UserCommandMessage`, `InterruptMessage`, `BashOutputMessage`

**Patterns**: Component composition via Textual's compose() method

**Dependencies**: textual

**Complexity**: medium

#### `vibe/cli/textual_ui/widgets/config_app.py`

**Purpose**: Provides a Textual UI widget for editing Vibe configuration settings such as the active model and UI theme.

**Exports**: `SettingDefinition`, `ConfigApp`

**Classes**: `ConfigApp`

**Patterns**: Observer (Textual message system), Command pattern (action_ methods)

**Dependencies**: textual

**Complexity**: medium

#### `vibe/cli/textual_ui/widgets/welcome.py`

**Purpose**: Defines the WelcomeBanner Textual widget that displays an animated welcome screen with version, model, and workdir information, using color interpolation and timed animation.

**Exports**: `hex_to_rgb`, `rgb_to_hex`, `interpolate_color`, `LineAnimationState`, `WelcomeBanner`

**Classes**: `LineAnimationState`, `WelcomeBanner`

**Functions**: `hex_to_rgb()`, `rgb_to_hex()`, `interpolate_color()`

**Patterns**: Observer (timer callback via set_interval), State (LineAnimationState caching), Factory (dynamic colour generation)

**Dependencies**: rich, textual

**Complexity**: medium

### Module: `vibe/cli/textual_ui/widgets/chat_input/`

#### `vibe/cli/textual_ui/widgets/chat_input/completion_popup.py`

**Purpose**: Defines a Textual widget that displays a popup with completion suggestions for the chat input.

**Exports**: `CompletionPopup`

**Classes**: `CompletionPopup`

**Dependencies**: rich, textual

**Complexity**: low

#### `vibe/cli/textual_ui/widgets/chat_input/body.py`

**Purpose**: Implements a Textual widget that provides a chat input area with prompt handling, history navigation, and submission messaging.

**Exports**: `ChatInputBody`

**Classes**: `ChatInputBody`, `ChatInputBody.Submitted`

**Patterns**: Observer (event/message) pattern via Textual's message system

**Dependencies**: textual

**Complexity**: medium

#### `vibe/cli/textual_ui/widgets/chat_input/__init__.py`

**Purpose**: Re-exports the main chat input widget classes for easier import elsewhere in the project.

**Exports**: `ChatInputBody`, `ChatInputContainer`, `ChatTextArea`

**Complexity**: low

#### `vibe/cli/textual_ui/widgets/chat_input/container.py`

**Purpose**: Provides a Textual UI container widget that manages chat input, history, autocompletion (slash commands and filesystem paths), and emits a submission message.

**Exports**: `ChatInputContainer`

**Classes**: `ChatInputContainer`, `ChatInputContainer.Submitted`

**Patterns**: Observer (Textual Message system), Composite (Textual container hierarchy)

**Dependencies**: textual

**Complexity**: medium

#### `vibe/cli/textual_ui/widgets/chat_input/text_area.py`

**Purpose**: Provides a custom TextArea widget for chat input, handling submission, history navigation, and integration with an autocompletion manager.

**Exports**: `ChatTextArea`

**Classes**: `ChatTextArea`

**Patterns**: Observer (via Textual message system), Strategy (completion manager delegated handling)

**Dependencies**: textual

**Complexity**: medium

#### `vibe/cli/textual_ui/widgets/chat_input/completion_manager.py`

**Purpose**: Provides a manager that selects and delegates to the appropriate autocompletion controller for the chat input widget, handling text changes and key events.

**Exports**: `CompletionController`, `MultiCompletionManager`

**Classes**: `CompletionController`, `MultiCompletionManager`

**Patterns**: Strategy (selecting appropriate controller at runtime), Chain of Responsibility (iterating controllers until one can handle the input), Protocol/Interface pattern

**Dependencies**: textual

**Complexity**: medium

### Module: `vibe/cli/update_notifier/`

#### `vibe/cli/update_notifier/version_update.py`

**Purpose**: Provides logic to determine whether a newer version of the CLI is available, using a gateway to fetch updates and a cache to avoid frequent network calls.

**Exports**: `UPDATE_CACHE_TTL_SECONDS`, `VersionUpdateAvailability`, `VersionUpdateError`, `get_update_if_available`

**Classes**: `VersionUpdateAvailability`, `VersionUpdateError`

**Functions**: `get_update_if_available()`

**Patterns**: Repository pattern, Dependency injection, Cache‑aside pattern

**Dependencies**: packaging

**Complexity**: medium

#### `vibe/cli/update_notifier/__init__.py`

**Purpose**: Provides a convenient public API for the update_notifier package by re‑exporting key classes, functions, and constants from internal modules.

**Exports**: `DEFAULT_GATEWAY_MESSAGES`, `FileSystemUpdateCacheRepository`, `GitHubVersionUpdateGateway`, `PyPIVersionUpdateGateway`, `UpdateCache`, `UpdateCacheRepository`, `VersionUpdate`, `VersionUpdateAvailability`, `VersionUpdateError`, `VersionUpdateGateway` (+3 more)

**Complexity**: low

### Module: `vibe/cli/update_notifier/adapters/`

#### `vibe/cli/update_notifier/adapters/filesystem_update_cache_repository.py`

**Purpose**: Provides a filesystem‑backed implementation of the UpdateCacheRepository interface, persisting update cache data as JSON under the VIBE_HOME directory.

**Exports**: `FileSystemUpdateCacheRepository`

**Classes**: `FileSystemUpdateCacheRepository`

**Patterns**: Repository, Adapter, Async I/O

**Complexity**: low

#### `vibe/cli/update_notifier/adapters/pypi_version_update_gateway.py`

**Purpose**: Implements a PyPI‑specific gateway that fetches the latest non‑yanked version of a package using the PyPI simple API.

**Exports**: `PyPIVersionUpdateGateway`, `_parse_filename_version`

**Classes**: `PyPIVersionUpdateGateway`

**Patterns**: Adapter pattern, Gateway pattern

**Dependencies**: httpx, packaging

**Complexity**: medium

#### `vibe/cli/update_notifier/adapters/github_version_update_gateway.py`

**Purpose**: Provides a GitHub‑based implementation of the VersionUpdateGateway interface that fetches the latest non‑prerelease, non‑draft release tag from a repository.

**Exports**: `GitHubVersionUpdateGateway`, `_extract_version`

**Classes**: `GitHubVersionUpdateGateway`

**Patterns**: Adapter

**Dependencies**: httpx

**Complexity**: medium

### Module: `vibe/cli/update_notifier/ports/`

#### `vibe/cli/update_notifier/ports/update_cache_repository.py`

**Purpose**: Defines an immutable data class for cache information and a protocol (interface) for a repository that can get and set this cache asynchronously.

**Exports**: `UpdateCache`, `UpdateCacheRepository`

**Classes**: `UpdateCache`, `UpdateCacheRepository`

**Patterns**: Protocol (interface) pattern, Repository pattern, Immutable dataclass

**Complexity**: low

#### `vibe/cli/update_notifier/ports/version_update_gateway.py`

**Purpose**: Defines data structures and an interface for checking version updates, including error handling and cause enumeration.

**Exports**: `VersionUpdate`, `VersionUpdateGatewayCause`, `DEFAULT_GATEWAY_MESSAGES`, `VersionUpdateGatewayError`, `VersionUpdateGateway`

**Classes**: `VersionUpdate`, `VersionUpdateGatewayCause`, `VersionUpdateGatewayError`, `VersionUpdateGateway`

**Patterns**: Protocol (interface), Enum, Dataclass

**Complexity**: low

### Module: `vibe/core/`

#### `vibe/core/context_injector.py`

**Purpose**: Provides intelligent context injection by scanning a VIBE-ANALYSIS JSON index with an LLM, extracting relevant markdown excerpts, and synthesizing a concise context summary for use in conversations.

**Exports**: `RelevantItem`, `ContextResult`, `ContextInjector`, `format_context_for_injection`, `CHUNK_SCAN_PROMPT`, `SYNTHESIS_PROMPT`

**Classes**: `RelevantItem`, `ContextResult`, `ContextInjector`

**Functions**: `format_context_for_injection()`

**Complexity**: medium

#### `vibe/core/config.py`

**Purpose**: Defines the configuration model for VIBE, loads settings from environment, .env, and a TOML file, and provides validation and helper methods.

**Exports**: `load_api_keys_from_env`, `MissingAPIKeyError`, `MissingPromptFileError`, `WrongBackendError`, `TomlFileSettingsSource`, `ProjectContextConfig`, `SessionLoggingConfig`, `Backend`, `ProviderConfig`, `_MCPBase` (+10 more)

**Classes**: `MissingAPIKeyError`, `MissingPromptFileError`, `WrongBackendError`, `TomlFileSettingsSource`, `ProjectContextConfig`

**Functions**: `load_api_keys_from_env()`

**Patterns**: Factory (custom Pydantic settings source), Strategy (backend compatibility validation), Discriminated Union (MCPServer type alias), Builder (incremental configuration updates via save_updates)

**Dependencies**: python-dotenv, pydantic, pydantic-settings, tomli-w

**Complexity**: medium

#### `vibe/core/interaction_logger.py`

**Purpose**: Provides functionality to log interactions of a Vibe session to JSON files, including metadata such as git information, user, and tool availability, and offers utilities to retrieve, reset, and locate logged sessions.

**Exports**: `InteractionLogger`

**Classes**: `InteractionLogger`

**Dependencies**: aiofiles

**Complexity**: medium

#### `vibe/core/system_prompt.py`

**Purpose**: Provides utilities to build a project context (directory tree, git status, docs) and assembles the universal system prompt for the Vibe agent.

**Exports**: `_load_user_instructions`, `_load_project_doc`, `ProjectContextProvider`, `_get_platform_name`, `_get_default_shell`, `_get_os_system_prompt`, `_get_windows_system_prompt`, `_add_commit_signature`, `get_universal_system_prompt`

**Classes**: `ProjectContextProvider`

**Functions**: `get_universal_system_prompt()`

**Patterns**: Builder (assembly of system prompt), Factory (selection of active tool classes)

**Complexity**: medium

#### `vibe/core/__init__.py`

**Purpose**: Defines the package version and re‑exports the `run_programmatic` entry point for external use.

**Exports**: `__version__`, `run_programmatic`

**Complexity**: low

#### `vibe/core/types.py`

**Purpose**: Defines core data models, enums, and type aliases used throughout the Vibe agent framework, including session metadata, agent statistics, LLM messages, tool call representations, and approval callbacks.

**Exports**: `ResumeSessionInfo`, `AgentStats`, `SessionInfo`, `SessionMetadata`, `StrToolChoice`, `AvailableFunction`, `AvailableTool`, `FunctionCall`, `ToolCall`, `_content_before` (+16 more)

**Classes**: `ResumeSessionInfo`, `AgentStats`, `SessionInfo`, `SessionMetadata`, `AvailableFunction`

**Functions**: `_content_before()`

**Patterns**: Dataclass for simple value objects, Pydantic BaseModel for data validation and serialization, Enum (StrEnum) for constrained string values, Computed fields via @computed_field, Model pre‑validation via @model_validator(mode='before'), Union of async and sync callbacks for approval handling

**Dependencies**: pydantic

**Complexity**: medium

#### `vibe/core/config_path.py`

**Purpose**: Provides a lazy path resolution wrapper (ConfigPath) and defines project‑wide ConfigPath instances for configuration files, directories, and environment locations.

**Exports**: `ConfigPath`, `_get_vibe_home`, `_resolve_config_file`, `resolve_local_tools_dir`, `VIBE_HOME`, `GLOBAL_CONFIG_FILE`, `GLOBAL_ENV_FILE`, `GLOBAL_TOOLS_DIR`, `SESSION_LOG_DIR`, `CONFIG_FILE` (+7 more)

**Classes**: `ConfigPath`

**Functions**: `resolve_local_tools_dir()`

**Patterns**: Lazy Evaluation (via callable wrapper), Configuration holder

**Complexity**: low

#### `vibe/core/utils.py`

**Purpose**: Provides core utility functions and classes for Vibe, including tagged text handling, user‑cancellation messaging, directory safety checks, retry decorators for async functions/generators, logging setup, and helpers for user‑agent strings and synchronous execution of coroutines.

**Exports**: `CANCELLATION_TAG`, `TOOL_ERROR_TAG`, `VIBE_STOP_EVENT_TAG`, `VIBE_WARNING_TAG`, `KNOWN_TAGS`, `TaggedText`, `CancellationReason`, `ConversationLimitException`, `get_user_cancellation_message`, `is_user_cancellation_event` (+7 more)

**Classes**: `TaggedText`, `CancellationReason`, `ConversationLimitException`

**Functions**: `get_user_cancellation_message()`, `is_user_cancellation_event()`, `is_dangerous_directory()`, `get_user_agent()`, `async_retry()`, `async_generator_retry()`, `run_sync()`, `is_windows()`

**Patterns**: Decorator (retry logic), Factory (decorator factories), Singleton-like (module‑level logger and config objects), Enum

**Dependencies**: httpx

**Complexity**: medium

#### `vibe/core/agent.py`

**Purpose**: Implements the Agent class that orchestrates LLM conversations, middleware processing, tool execution, logging, and session management.

**Exports**: `ToolExecutionResponse`, `ToolDecision`, `AgentError`, `AgentStateError`, `LLMResponseError`, `Agent`

**Classes**: `ToolExecutionResponse`, `ToolDecision`, `AgentError`, `AgentStateError`, `LLMResponseError`

**Patterns**: Factory (backend selection via BACKEND_FACTORY), Chain of Responsibility (MiddlewarePipeline), Strategy (different middleware implementations), Async Generator (streaming events), Template Method (conversation loop structure)

**Dependencies**: pydantic, asyncio, enum, time, uuid

**Complexity**: high

#### `vibe/core/programmatic.py`

**Purpose**: Provides a programmatic entry point that runs a Vibe agent with a given prompt and returns the assistant's final response.

**Exports**: `run_programmatic`

**Functions**: `run_programmatic()`

**Patterns**: Factory (create_formatter), Observer (formatter.on_message_added used as message_observer callback)

**Dependencies**: asyncio (stdlib)

**Complexity**: medium

#### `vibe/core/output_formatters.py`

**Purpose**: Defines formatter classes for different output representations (text, JSON, streaming JSON) and provides a factory function to create the appropriate formatter based on an OutputFormat.

**Exports**: `OutputFormatter`, `TextOutputFormatter`, `JsonOutputFormatter`, `StreamingJsonOutputFormatter`, `create_formatter`

**Classes**: `OutputFormatter`, `TextOutputFormatter`, `JsonOutputFormatter`, `StreamingJsonOutputFormatter`

**Functions**: `create_formatter()`

**Patterns**: Factory, Strategy

**Complexity**: low

#### `vibe/core/middleware.py`

**Purpose**: Defines a middleware framework for VIBE conversations, providing enums, data structures, concrete middleware implementations, and a pipeline to run them before and after each turn.

**Exports**: `MiddlewareAction`, `ResetReason`, `ConversationContext`, `MiddlewareResult`, `ConversationMiddleware`, `TurnLimitMiddleware`, `PriceLimitMiddleware`, `AutoCompactMiddleware`, `ContextWarningMiddleware`, `MiddlewarePipeline` (+1 more)

**Classes**: `MiddlewareAction`, `ResetReason`, `ConversationContext`, `MiddlewareResult`, `ConversationMiddleware`

**Patterns**: Chain of Responsibility (pipeline processing), Strategy (different middleware behaviours), Protocol Interface

**Complexity**: medium

### Module: `vibe/core/autocompletion/`

#### `vibe/core/autocompletion/fuzzy.py`

**Purpose**: Provides fuzzy matching utilities for autocompletion, scoring matches based on prefix, word‑boundary, consecutive, and subsequence heuristics.

**Exports**: `PREFIX_MULTIPLIER`, `WORD_BOUNDARY_MULTIPLIER`, `CONSECUTIVE_MULTIPLIER`, `MatchResult`, `fuzzy_match`

**Classes**: `MatchResult`

**Functions**: `fuzzy_match()`

**Patterns**: Strategy (multiple matching strategies selected at runtime), Functional decomposition

**Complexity**: medium

#### `vibe/core/autocompletion/path_prompt_adapter.py`

**Purpose**: Converts a PathPromptPayload into a formatted text prompt by embedding small text files and creating resource links.

**Exports**: `DEFAULT_MAX_EMBED_BYTES`, `ResourceBlock`, `render_path_prompt`, `_path_prompt_to_content_blocks`, `_try_embed_text_resource`, `_content_blocks_to_prompt_text`, `_format_content_block`, `_is_probably_text`

**Functions**: `render_path_prompt()`

**Patterns**: Adapter (module adapts PathPromptPayload to a prompt string), Pattern Matching (Python match‑case statements)

**Complexity**: medium

#### `vibe/core/autocompletion/path_prompt.py`

**Purpose**: Provides utilities to parse a text message for '@' path anchors, resolve filesystem paths, and build a structured payload for autocompletion prompts.

**Exports**: `PathResource`, `PathPromptPayload`, `build_path_prompt_payload`, `_is_path_anchor`, `_extract_candidate`, `_is_path_char`, `_to_resource`, `_dedupe_resources`

**Classes**: `PathResource`, `PathPromptPayload`

**Functions**: `build_path_prompt_payload()`

**Patterns**: Data Class, Builder (payload construction)

**Complexity**: low

#### `vibe/core/autocompletion/completers.py`

**Purpose**: Provides concrete completer implementations for command names, filesystem paths, and a composite completer that aggregates multiple completers for autocompletion features.

**Exports**: `DEFAULT_MAX_ENTRIES_TO_PROCESS`, `DEFAULT_TARGET_MATCHES`, `Completer`, `CommandCompleter`, `PathCompleter`, `MultiCompleter`

**Classes**: `Completer`, `CommandCompleter`, `PathCompleter`, `MultiCompleter`, `_SearchContext`

**Patterns**: Strategy (different completer implementations), Composite (MultiCompleter aggregates others), Factory (PathCompleter creates search context objects)

**Complexity**: medium

### Module: `vibe/core/autocompletion/file_indexer/`

#### `vibe/core/autocompletion/file_indexer/store.py`

**Purpose**: Manages an in‑memory index of files for autocompletion, supporting full rebuilds, incremental updates, and snapshot retrieval while respecting ignore rules.

**Exports**: `FileIndexStats`, `IndexEntry`, `FileIndexStore`

**Classes**: `FileIndexStats`, `IndexEntry`, `FileIndexStore`

**Patterns**: Lazy caching (ordered entries are cached until the index changes), Command‑style handling of filesystem changes (apply_changes processes a list of Change commands)

**Complexity**: medium

#### `vibe/core/autocompletion/file_indexer/ignore_rules.py`

**Purpose**: Provides mechanisms to compile ignore patterns (including defaults and .gitignore) and determine whether a given path should be ignored for autocompletion indexing.

**Exports**: `DEFAULT_IGNORE_PATTERNS`, `CompiledPattern`, `IgnoreRules`

**Classes**: `CompiledPattern`, `IgnoreRules`

**Complexity**: medium

#### `vibe/core/autocompletion/file_indexer/__init__.py`

**Purpose**: Re-exports key autocompletion file indexing classes (FileIndexer, FileIndexStore, FileIndexStats, IndexEntry) for convenient import elsewhere in the project.

**Exports**: `FileIndexStats`, `FileIndexStore`, `FileIndexer`, `IndexEntry`

**Complexity**: low

#### `vibe/core/autocompletion/file_indexer/indexer.py`

**Purpose**: Provides a thread‑safe indexer that builds and maintains a file index for autocompletion, watches for filesystem changes and updates the index in the background.

**Exports**: `FileIndexer`

**Classes**: `_RebuildTask`, `FileIndexer`

**Patterns**: Observer (via WatchController callback), Worker/Executor pattern (background rebuild using ThreadPoolExecutor), Locking/Guarded state (RLock for thread safety)

**Complexity**: medium

#### `vibe/core/autocompletion/file_indexer/watcher.py`

**Purpose**: Provides a WatchController class that runs a background thread to monitor file system changes under a given root directory using the watchfiles library and dispatches those changes to a user-provided callback.

**Exports**: `WatchController`

**Classes**: `WatchController`

**Patterns**: Observer (callback on change events), Thread management (worker thread)

**Dependencies**: watchfiles

**Complexity**: low

### Module: `vibe/core/llm/`

#### `vibe/core/llm/format.py`

**Purpose**: Provides utilities for parsing, resolving, and handling tool calls in LLM messages, including activation of tools based on configuration and formatting of API‑style tool call responses.

**Exports**: `get_active_tool_classes`, `ParsedToolCall`, `ResolvedToolCall`, `FailedToolCall`, `ParsedMessage`, `ResolvedMessage`, `APIToolFormatHandler`

**Classes**: `ParsedToolCall`, `ResolvedToolCall`, `FailedToolCall`, `ParsedMessage`, `ResolvedMessage`

**Functions**: `get_active_tool_classes()`

**Patterns**: Strategy (format handler selection), Factory (building AvailableTool objects), Caching (lru_cache for regex compilation), Data Validation (Pydantic models)

**Dependencies**: pydantic

**Complexity**: medium

#### `vibe/core/llm/types.py`

**Purpose**: Defines a Protocol that specifies the required async interface for LLM backend implementations used by the Agent.

**Exports**: `BackendLike`

**Classes**: `BackendLike`

**Patterns**: Protocol (typing) for duck‑typing, Dependency Injection via protocol, Async context manager

**Complexity**: low

#### `vibe/core/llm/exceptions.py`

**Purpose**: Defines data models and exception handling for LLM backend errors, providing utilities to build detailed error objects from HTTP responses or request failures.

**Exports**: `ErrorDetail`, `PayloadSummary`, `BackendError`, `ErrorResponse`, `BackendErrorBuilder`

**Classes**: `ErrorDetail`, `PayloadSummary`, `BackendError`, `ErrorResponse`, `BackendErrorBuilder`

**Patterns**: Builder, Factory

**Dependencies**: httpx, pydantic

**Complexity**: medium

### Module: `vibe/core/llm/backend/`

#### `vibe/core/llm/backend/mistral.py`

**Purpose**: Implements a backend for interacting with the Mistral LLM service, providing message mapping, synchronous and streaming completions, and token counting.

**Exports**: `MistralMapper`, `MistralBackend`

**Classes**: `MistralMapper`, `MistralBackend`

**Patterns**: Adapter, Async Context Manager, Factory

**Dependencies**: httpx, mistralai

**Complexity**: medium

#### `vibe/core/llm/backend/generic.py`

**Purpose**: Provides a generic LLM backend for making HTTP requests to various provider APIs, with a pluggable adapter system (e.g., OpenAI) that handles request preparation and response parsing, supporting both standard and streaming completions.

**Exports**: `PreparedRequest`, `APIAdapter`, `BACKEND_ADAPTERS`, `register_adapter`, `OpenAIAdapter`, `GenericBackend`

**Classes**: `PreparedRequest`, `APIAdapter`, `OpenAIAdapter`, `GenericBackend`

**Functions**: `register_adapter()`

**Patterns**: Factory/Registry (adapter registration via decorator), Decorator, Retry (async_retry, async_generator_retry), Context manager (async __aenter__/__aexit__ for client lifecycle)

**Dependencies**: httpx

**Complexity**: medium

#### `vibe/core/llm/backend/factory.py`

**Purpose**: Defines a mapping (factory) from Backend enum values to their corresponding backend implementation classes.

**Exports**: `BACKEND_FACTORY`

**Patterns**: Factory

**Complexity**: low

### Module: `vibe/core/llm/backend/watsonx/`

#### `vibe/core/llm/backend/watsonx/auth.py`

**Purpose**: Provides an httpx authentication handler for IBM WatsonX that automatically obtains and refreshes IAM tokens, supporting proactive and reactive refresh with async safety and retry logic.

**Exports**: `WatsonXAuthError`, `TokenData`, `WatsonXAuth`, `HTTP_UNAUTHORIZED`

**Classes**: `WatsonXAuthError`, `TokenData`, `WatsonXAuth`

**Patterns**: Context manager, Async double‑checked locking, Retry with exponential backoff (tenacity), Token refresh (proactive/reactive) pattern

**Dependencies**: httpx, tenacity

**Complexity**: medium

#### `vibe/core/llm/backend/watsonx/backend.py`

**Purpose**: Provides an async adapter for IBM WatsonX LLM endpoints that implements the BackendLike interface, emulating native tool calling through prompt engineering and response parsing.

**Exports**: `WatsonXBackendError`, `ToolParsingError`, `EmptyResponseError`, `WatsonXBackend`, `_build_tool_schemas_prompt`, `_build_tool_instructions`, `_extract_json_with_brace_counting`, `_extract_tool_call_from_response`, `_separate_content_and_reasoning`

**Classes**: `WatsonXBackendError`, `ToolParsingError`, `EmptyResponseError`, `WatsonXBackend`

**Patterns**: Adapter pattern (WatsonXBackend adapts WatsonX API to BackendLike interface), Retry pattern (tenacity AsyncRetrying), Context manager for resource acquisition (async __aenter__/__aexit__), Factory‑style request body construction

**Dependencies**: httpx, tenacity

**Complexity**: medium

#### `vibe/core/llm/backend/watsonx/models.py`

**Purpose**: Provides a service to discover and fetch available WatsonX foundation models via the WatsonX API, exposing model metadata for dynamic selection.

**Exports**: `WatsonXModel`, `WatsonXModelService`, `fetch_watsonx_models`

**Classes**: `WatsonXModel`, `WatsonXModelService`

**Functions**: `fetch_watsonx_models()`

**Patterns**: Retry (using tenacity's AsyncRetrying), Factory-like instantiation for service objects

**Dependencies**: httpx, tenacity

**Complexity**: medium

#### `vibe/core/llm/backend/watsonx/__init__.py`

**Purpose**: Initializes the WatsonX LLM backend package by exposing key classes and functions for external use.

**Exports**: `WatsonXAuth`, `WatsonXBackend`, `WatsonXModel`, `WatsonXModelService`, `fetch_watsonx_models`

**Complexity**: low

### Module: `vibe/core/prompts/`

#### `vibe/core/prompts/__init__.py`

**Purpose**: Defines enumerated prompt identifiers and helper methods for locating and reading markdown prompt files used by the VIBE system.

**Exports**: `SystemPrompt`, `UtilityPrompt`

**Classes**: `Prompt`, `SystemPrompt`, `UtilityPrompt`

**Patterns**: Enum pattern

**Complexity**: low

### Module: `vibe/core/tools/`

#### `vibe/core/tools/ui.py`

**Purpose**: Defines UI display data structures and an adapter for presenting tool call and result information, providing default representations and a protocol for custom UI data classes.

**Exports**: `ToolCallDisplay`, `ToolResultDisplay`, `ToolUIData`, `ToolUIDataAdapter`

**Classes**: `ToolCallDisplay`, `ToolResultDisplay`, `ToolUIData`, `ToolUIDataAdapter`

**Patterns**: Adapter, Protocol (interface), Strategy (via pluggable UI data class)

**Dependencies**: pydantic

**Complexity**: medium

#### `vibe/core/tools/mcp.py`

**Purpose**: Provides utilities to discover and invoke remote MCP tools via HTTP or stdio and dynamically creates proxy tool classes that integrate with Vibe's BaseTool system.

**Exports**: `_OpenArgs`, `MCPToolResult`, `RemoteTool`, `_MCPContentBlock`, `_MCPResultIn`, `list_tools_http`, `call_tool_http`, `create_mcp_http_proxy_tool_class`, `list_tools_stdio`, `call_tool_stdio` (+1 more)

**Classes**: `_OpenArgs`, `MCPToolResult`, `RemoteTool`, `_MCPContentBlock`, `_MCPResultIn`

**Functions**: `list_tools_http()`, `call_tool_http()`, `create_mcp_http_proxy_tool_class()`, `list_tools_stdio()`, `call_tool_stdio()`, `create_mcp_stdio_proxy_tool_class()`

**Patterns**: Factory (dynamic creation of proxy tool classes), Adapter (proxy classes adapt remote MCP interface to BaseTool interface)

**Dependencies**: mcp, pydantic

**Complexity**: medium

#### `vibe/core/tools/manager.py`

**Purpose**: Manages discovery, registration, and lazy instantiation of tool classes for an Agent, including integration of remote MCP tools.

**Exports**: `NoSuchToolError`, `DEFAULT_TOOL_DIR`, `ToolManager`

**Classes**: `NoSuchToolError`, `ToolManager`

**Patterns**: Registry, Factory, Lazy Initialization

**Complexity**: medium

#### `vibe/core/tools/base.py`

**Purpose**: Provides the core abstract infrastructure for defining tools, including configuration, state handling, permissions, argument validation, and prompt loading.

**Exports**: `ARGS_COUNT`, `ToolError`, `ToolInfo`, `ToolPermissionError`, `ToolPermission`, `BaseToolConfig`, `BaseToolState`, `BaseTool`

**Classes**: `ToolError`, `ToolInfo`, `ToolPermissionError`, `ToolPermission`, `BaseToolConfig`

**Patterns**: Factory Method (from_config), Template Method (abstract run), Abstract Base Class, Generic Programming

**Dependencies**: pydantic

**Complexity**: medium

### Module: `vibe/core/tools/builtins/`

#### `vibe/core/tools/builtins/search_replace.py`

**Purpose**: Provides a tool that applies SEARCH/REPLACE blocks to files, supporting fuzzy matching and detailed error reporting.

**Exports**: `SearchReplaceBlock`, `FuzzyMatch`, `BlockApplyResult`, `SearchReplaceArgs`, `SearchReplaceResult`, `SearchReplaceConfig`, `SearchReplaceState`, `SearchReplace`

**Classes**: `SearchReplaceBlock`, `FuzzyMatch`, `BlockApplyResult`, `SearchReplaceArgs`, `SearchReplaceResult`

**Patterns**: Inheritance, Template Method, Factory (tool registration via BaseTool subclass)

**Dependencies**: aiofiles, pydantic

**Complexity**: medium

#### `vibe/core/tools/builtins/bash.py`

**Purpose**: Provides a BashTool implementation that runs a one‑off shell command with configurable allow/deny lists, timeout handling and output capture.

**Exports**: `Bash`, `BashArgs`, `BashResult`, `BashToolConfig`, `_get_subprocess_encoding`, `_get_base_env`, `_kill_process_tree`, `_get_default_allowlist`, `_get_default_denylist`, `_get_default_denylist_standalone`

**Classes**: `BashToolConfig`, `BashArgs`, `BashResult`, `Bash`

**Patterns**: Template Method (run overrides BaseTool.run), Strategy (allowlist/denylist decision logic), Factory (Bash instances created via configuration)

**Dependencies**: pydantic

**Complexity**: medium

#### `vibe/core/tools/builtins/grep.py`

**Purpose**: Provides a Grep tool that searches files recursively using ripgrep or GNU grep, handling ignore patterns, result truncation, and UI display.

**Exports**: `GrepBackend`, `GrepToolConfig`, `GrepState`, `GrepArgs`, `GrepResult`, `Grep`

**Classes**: `GrepBackend`, `GrepToolConfig`, `GrepState`, `GrepArgs`, `GrepResult`

**Patterns**: Strategy (backend selection), Factory (configuration objects), Command (tool execution model)

**Dependencies**: pydantic

**Complexity**: medium

#### `vibe/core/tools/builtins/read_file.py`

**Purpose**: Implements a tool for safely reading UTF‑8 text files, supporting line offsets, limits, byte‑size truncation, and maintaining a recent‑read history.

**Exports**: `_ReadResult`, `ReadFileArgs`, `ReadFileResult`, `ReadFileToolConfig`, `ReadFileState`, `ReadFile`

**Classes**: `_ReadResult`, `ReadFileArgs`, `ReadFileResult`, `ReadFileToolConfig`, `ReadFileState`

**Patterns**: Template Method (run delegating to protected helpers), Strategy (different tools share BaseTool interface), Factory (configuration creates tool instances), Command (tool encapsulates an executable action)

**Dependencies**: aiofiles, pydantic

**Complexity**: medium

#### `vibe/core/tools/builtins/todo.py`

**Purpose**: Provides a Todo management tool implementation, exposing a BaseTool that can read and write a list of todo items.

**Exports**: `TodoStatus`, `TodoPriority`, `TodoItem`, `TodoArgs`, `TodoResult`, `TodoConfig`, `TodoState`, `Todo`

**Classes**: `TodoStatus`, `TodoPriority`, `TodoItem`, `TodoArgs`, `TodoResult`

**Patterns**: Template Method, Factory

**Dependencies**: pydantic

**Complexity**: medium

#### `vibe/core/tools/builtins/write_file.py`

**Purpose**: Defines the WriteFile tool that creates or overwrites UTF‑8 text files within the project's working directory, handling validation, permissions, and UI display.

**Exports**: `WriteFileArgs`, `WriteFileResult`, `WriteFileConfig`, `WriteFileState`, `WriteFile`

**Classes**: `WriteFileArgs`, `WriteFileResult`, `WriteFileConfig`, `WriteFileState`, `WriteFile`

**Patterns**: Command pattern (tool as command), Template Method (run defines the algorithm, subclasses implement specifics), Factory / Registry (tool subclasses are discovered via BaseTool infrastructure)

**Dependencies**: aiofiles, pydantic

**Complexity**: medium

### Module: `vibe/setup/onboarding/`

#### `vibe/setup/onboarding/__init__.py`

**Purpose**: Defines a Textual application that guides the user through the Vibe CLI onboarding workflow and provides helper functions to run the onboarding process and apply the selected provider/model configuration.

**Exports**: `OnboardingApp`, `run_onboarding`, `_apply_provider_config`, `_ensure_model_in_config`

**Classes**: `OnboardingApp`

**Functions**: `run_onboarding()`

**Patterns**: Factory (screen installation), Singleton (VibeConfig usage), Command (run_onboarding execution)

**Dependencies**: rich, textual

**Complexity**: medium

#### `vibe/setup/onboarding/base.py`

**Purpose**: Defines a base onboarding screen class with common navigation actions (next and cancel) for the setup flow.

**Exports**: `OnboardingScreen`

**Classes**: `OnboardingScreen`

**Dependencies**: textual

**Complexity**: low

### Module: `vibe/setup/onboarding/screens/`

#### `vibe/setup/onboarding/screens/watsonx_setup.py`

**Purpose**: Provides a Textual onboarding screen that collects WatsonX API key, project ID, and region, validates the inputs, and saves them to the environment and a global .env file.

**Exports**: `WatsonXSetupScreen`, `WATSONX_REGIONS`, `WATSONX_DOCS_URL`, `WATSONX_CONSOLE_URL`, `UUID_LENGTH`

**Classes**: `WatsonXSetupScreen`

**Patterns**: Observer (event‑handler methods such as on_input_changed, on_select_changed), Command (textual key bindings)

**Dependencies**: python-dotenv, textual

**Complexity**: medium

#### `vibe/setup/onboarding/screens/model_selection.py`

**Purpose**: Provides a Textual onboarding screen that dynamically fetches and displays available LLM models from a provider (currently WatsonX) and lets the user select one.

**Exports**: `ModelSelectionScreen`, `MAX_DESC_LENGTH`

**Classes**: `ModelSelectionScreen`

**Patterns**: Observer (event handling via on_* methods), Command (action methods bound to key presses)

**Dependencies**: textual

**Complexity**: medium

#### `vibe/setup/onboarding/screens/__init__.py`

**Purpose**: Aggregates and re‑exports the onboarding screen classes so they can be imported from a single location.

**Exports**: `ApiKeyScreen`, `ModelSelectionScreen`, `ProviderSelectionScreen`, `ThemeSelectionScreen`, `WatsonXSetupScreen`, `WelcomeScreen`

**Patterns**: Facade (module re‑export), Aggregator

**Complexity**: low

#### `vibe/setup/onboarding/screens/provider_selection.py`

**Purpose**: Provides a Textual UI screen that lets the user select an LLM provider during onboarding and routes the flow to the appropriate configuration screen.

**Exports**: `PROVIDERS`, `ProviderSelectionScreen`

**Classes**: `ProviderSelectionScreen`

**Patterns**: Event-driven UI, Command pattern (action methods for key bindings)

**Dependencies**: textual

**Complexity**: medium

#### `vibe/setup/onboarding/screens/api_key.py`

**Purpose**: Provides an onboarding screen that collects a provider API key, validates it, saves it to the global .env file and exits the application.

**Exports**: `ApiKeyScreen`, `_save_api_key_to_env_file`, `PROVIDER_HELP`, `CONFIG_DOCS_URL`

**Classes**: `ApiKeyScreen`

**Patterns**: Observer (event‑handler methods such as on_input_changed, on_mouse_up), Factory (dynamic composition of UI widgets in compose())

**Dependencies**: python-dotenv, textual

**Complexity**: medium

#### `vibe/setup/onboarding/screens/welcome.py`

**Purpose**: Defines the WelcomeScreen onboarding UI component that animates a gradient welcome message and shows a hint to press Enter.

**Exports**: `WelcomeScreen`

**Classes**: `WelcomeScreen`

**Patterns**: Observer (timer callbacks for animation), Template Method (overriding lifecycle methods like compose and on_mount)

**Dependencies**: textual

**Complexity**: medium

#### `vibe/setup/onboarding/screens/theme_selection.py`

**Purpose**: Provides the onboarding screen that lets the user select a Textual theme, shows a live preview, and stores the chosen theme in the Vibe configuration.

**Exports**: `ThemeSelectionScreen`, `THEMES`, `VISIBLE_NEIGHBORS`, `FADE_CLASSES`, `PREVIEW_MARKDOWN`

**Classes**: `ThemeSelectionScreen`

**Patterns**: Command pattern (Textual actions), Observer pattern (event handlers like on_resize), MVC/View component (separation of UI composition and logic)

**Dependencies**: textual

**Complexity**: medium


---

## Glossary

*59 terms defined*


### Acronyms

- **ACP**: Agent Communication Protocol – the internal protocol used for communication between the Vibe client and the AI agent, supporting commands, session updates, and remote procedure calls.
- **API**: Application Programming Interface – a set of methods that allow external code to interact with Vibe’s services such as back‑ends and tooling.
- **CD**: Continuous Deployment – automated release pipeline that publishes new Vibe package versions.
- **CI**: Continuous Integration – automated testing and validation performed on each push.
- **CLI**: Command Line Interface – the text‑based entry point for the Vibe assistant (e.g., `vibe` command).
- **JSON‑RPC**: A JSON‑based remote‑procedure‑call protocol used for exchanging ACP messages.
- **LLM**: Large Language Model – the underlying generative AI model (Mistral) that powers the conversational agent.
- **LRU**: Least Recently Used – caching strategy employed for compiled regular expressions.
- **RLock**: Re‑entrant Lock – a thread‑safe lock from the `threading` module used to protect shared state.
- **RPC**: Remote Procedure Call – a generic term for invoking functions on a remote service; Vibe uses JSON‑RPC over HTTP.
- **TUI**: Text‑based User Interface – a terminal‑only UI built with the Textual framework.
- **UI**: User Interface – the visual layer of Vibe, implemented as a Textual TUI.
- **UV**: Universal Virtual‑env – a modern Python package manager used to install Vibe and its dependencies.


### Domain Terms

- **Async context manager**: Objects that manage asynchronous resources (e.g., HTTP clients, backend sessions) via `async with`.
- **Async generator**: Used for streaming LLM completions or file‑index updates without blocking the event loop.
- **Builder pattern**: Step‑wise construction of complex objects such as `VibeConfig`, `IndexBuilder`, or prompt templates.
- **Cache‑aside**: Caching strategy where Vibe first checks an in‑memory cache (often LRU) before fetching data from the underlying source.
- **Chain of Responsibility**: The `MiddlewarePipeline` iterates through middleware until one handles the incoming request.
- **Command pattern**: Encapsulation of UI actions (key bindings, menu selections) into command objects dispatched via `CommandRegistry`.
- **Factory pattern**: Centralised creation of related objects (e.g., tool instances, back‑ends, formatters) through factory functions or methods.
- **Middleware**: Composable components that intercept and possibly transform requests/responses in the `MiddlewarePipeline` before they reach the agent or backend.
- **Observer**: Event‑driven mechanism where UI components subscribe to `Message` objects or session notifications to react to state changes.
- **Pilot**: Textual’s testing harness that simulates user interaction with the TUI for integration tests.
- **Repository pattern**: Abstraction that isolates data‑access logic (e.g., version‑update cache) from business logic, enabling interchangeable storage back‑ends.
- **Singleton**: A pattern used for globally shared objects such as the module‑level logger and the `VibeConfig` instance.
- **Strategy**: Pluggable algorithms selected at runtime (e.g., different backend compatibility validators or result renderers).
- **Template Method**: Base class defines the overall workflow while subclasses override specific steps (e.g., `BaseTool.run`).


### Project Terminology

- **AcpSession**: Per‑user session object that tracks state, pending tool calls, and notification streams for the ACP channel.
- **AcpToolState**: Base class representing the persisted state of a tool invocation; subclasses include `AcpBashState`, `AcpReadFileState`, etc.
- **ApprovalCallback**: Callable invoked when the agent requests user approval for a potentially destructive operation; wired to the `ApprovalApp` UI.
- **BackendFactory**: Factory responsible for instantiating concrete backend implementations (e.g., `WatsonXBackend`, `OpenAIBackend`).
- **BackendLike**: Protocol that defines the minimal interface a backend must expose to the Vibe core (e.g., `chat`, `list_models`).
- **BaseTool**: Core class providing the contract, metadata, and input validation for Vibe’s tooling system.
- **CommandRegistry**: Central registry mapping textual commands and key bindings to callable actions within the UI.
- **FakeBackend**: Test double used in the test suite to emulate a real backend without network calls.
- **FakeTool**: Stub implementation of a tool used for isolated unit testing of the agent and UI logic.
- **IndexBuilder**: Builder that incrementally constructs a searchable index of files and symbols used by the `grep`‑like tool.
- **MiddlewarePipeline**: Ordered collection of middleware objects that process ACP messages before they reach the agent or UI.
- **MultiCompleter**: Composite completer that aggregates several `Completer` instances (e.g., path, command, variable).
- **PathCompleter**: Component that supplies intelligent path completions for file‑related tool arguments.
- **SearchReplaceArgs**: Dataclass encapsulating arguments for the `search_replace` tool (pattern, replacement, file scope, etc.).
- **SessionNotification**: Typed messages emitted by the agent (e.g., `AgentPlanUpdate`, `AgentStats`) and observed by the UI to update the display.
- **Tool**: Abstract representation of an action the agent can invoke; each tool inherits from `BaseTool` and implements `run`.
- **ToolUIDataAdapter**: Adapter that converts internal tool result data into UI‑friendly structures for rendering in the TUI.
- **Vibe**: The overall command‑line coding assistant project; a conversational AI that interacts with the local codebase.
- **VibeAcpAgent**: Concrete implementation of the AI agent that communicates via the ACP protocol and orchestrates tool execution.
- **VibeApp**: The main Textual application class that drives the UI, handles user input, and coordinates agent communication.
- **VibeConfig**: A global, singleton‑like configuration holder (loaded from `config.toml` or environment) used throughout the codebase.
- **WatchController**: File‑system watcher that notifies the UI of external changes to the project files.


### Frameworks & Libraries

- **Rich**: Library for rich‑text rendering and formatting; used by Textual for styling output and by Vibe for colored log messages.
- **Textual**: A modern TUI framework used to build Vibe’s terminal user interface, providing widgets, event loop integration, and a pilot testing harness.
- **httpx**: Asynchronous HTTP client used by backend implementations to communicate with remote LLM services.
- **pathlib**: Standard library module for object‑oriented filesystem path manipulations, preferred over `os.path` in the codebase.
- **pydantic**: Data‑validation library used to define strongly‑typed configuration models, tool arguments, and ACP message schemas.
- **pytest**: Primary test runner for the project; provides fixtures, assertions, and parametrization support.
- **pytest‑asyncio**: Plugin that enables `async def` test functions and the `@pytest.mark.asyncio` marker for asynchronous Vibe components.
- **tenacity**: Retry library employed to wrap flaky network calls and token‑refresh logic with exponential back‑off strategies.
- **unittest.mock**: Standard library mocking framework used throughout the test suite for patching, spying, and creating test doubles.
- **uv**: Fast Python package manager referenced in the README for installing Vibe and its dependencies.


---

*This file was generated by `/init` command. 
Re-run `/init` to update when the codebase changes significantly.*