Software Heritage - Derived Datasets
====================================

Tooling to generate various datasets from the `Software Heritage
<https://www.softwareheritage.org/>`_
`archive <https://archive.softwareheritage.org/>`_;
based on the `in-memory compressed graph representation <https://docs.softwareheritage.org/devel/swh-graph/>`_.
