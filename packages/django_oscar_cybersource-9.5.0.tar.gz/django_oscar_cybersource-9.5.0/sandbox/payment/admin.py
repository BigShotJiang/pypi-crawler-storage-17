from oscar.apps.payment.admin import *  # noqa
