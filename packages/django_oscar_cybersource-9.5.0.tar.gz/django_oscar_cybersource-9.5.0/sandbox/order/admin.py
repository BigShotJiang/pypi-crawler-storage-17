from oscar.apps.order.admin import *  # noqa
