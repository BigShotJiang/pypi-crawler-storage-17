---
draft: true
sidebar_label: mixins
title: aixplain.factories.model_factory.mixins
---

