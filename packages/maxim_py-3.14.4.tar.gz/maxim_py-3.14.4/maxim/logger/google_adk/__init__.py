"""Google ADK integration for Maxim."""

from .client import instrument_google_adk, create_maxim_plugin

__all__ = ["instrument_google_adk", "create_maxim_plugin"]
