"""
watsonx.data API client module.

This file has been modified with the assistance of IBM Bob AI tool
"""

from lakehouse_mcp.client.watsonx import WatsonXClient

__all__ = ["WatsonXClient"]
