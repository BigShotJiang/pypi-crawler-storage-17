# this should mirror what is available in an svg
import math
import sys
import uuid

import numpy as np
import drawsvg

from ..environment.Canvas import _Canvas
from ..helpers.CircleMath import CircleMath

class BaseShape(object):
	'''All provided primitives inherit from this class. If a user wants to make their own primitive, its recommended to
	inherit from this class so the new primative is added to the draw queue.'''
	def __init__(self,**kwargs):
		self._vertices = np.array([])
		self._fill_color='none'
		self._stroke_color='black'
		self._stroke_width=1
		self._close_path = False
		self._fill_opacity = 1.0

		self.is_circle=False
		self.is_arc=False
		self.is_group = False
		self.is_text = False

		self.id = str(uuid.uuid4())

		for k,v in kwargs.items():
			if hasattr(self, k):
				setattr(self, k, v)
			else:
				raise AttributeError(f'Invalid parameter "{k}" for {self.__class__.__name__}. Attribute does not exist.')

		_Canvas.draw_queue.append(self)

	@property
	def fill_color(self):
		'''The fill color of the shape'''
		return self._fill_color

	@fill_color.setter
	def fill_color(self, v):
		self._fill_color = v


	@property
	def fill_opacity(self):
		'''The fill opacity of the shape'''
		return self._fill_opacity

	@fill_opacity.setter
	def fill_opacity(self, v):
		self._fill_opacity = v

	@property
	def close_path(self):
		'''Upon rendering the shape, the last vertex will connect to the first vertex'''
		return self._close_path

	@close_path.setter
	def close_path(self, v:bool):
		self._close_path = v

	@property
	def stroke_color(self):
		'''The stroke color of the shape'''
		return self._stroke_color

	@stroke_color.setter
	def stroke_color(self, v):
		self._stroke_color = v

	@property
	def stroke_width(self):
		'''The stroke width of the shape'''
		return self._stroke_width

	@stroke_width.setter
	def stroke_width(self, v):
		self._stroke_width = v

	@property
	def vertices(self):
		'''The list of vertices'''
		return self._vertices

	@property
	def first_vertex(self):
		'''The first vertex of the shape'''
		rv = (None, None)
		if  self.vertices.size > 0:
			_rv = self.vertices[0]
			rv = (_rv[0], _rv[1])

		return rv

	@property
	def min_x(self):
		'''The smallest x value of all the vertices'''
		rv = self.first_vertex[0]

		_v = self.vertices.tolist()

		for vertex in _v:
			x = vertex[0]
			if x < rv:
				rv = x
		return rv

	@property
	def max_x(self):
		'''The largest x value of all the vertices'''
		rv = self.first_vertex[0]

		_v = self.vertices.tolist()

		for vertex in _v:
			x = vertex[0]
			if x > rv:
				rv = x
		return rv

	@property
	def min_y(self):
		'''The smallest y value of all the vertices'''
		rv = self.first_vertex[1]

		_v = self.vertices.tolist()

		for vertex in _v:
			y = vertex[1]
			if y < rv:
				rv = y
		return rv

	@property
	def max_y(self):
		'''The largest y value of all the vertices'''
		rv = self.first_vertex[1]

		_v = self.vertices.tolist()

		for vertex in _v:
			y = vertex[1]
			if y > rv:
				rv = y
		return rv

	@property
	def center(self):
		'''The center of the shape based on the min/max x/y'''
		x = ((self.max_x - self.min_x)/2) + self.min_x
		y = ((self.max_y - self.min_y)/2) + self.min_y
		return (x,y)

	def add_vertex(self, x, y, z=0):
		'''Append a set of vertexes to the primitive shape'''

		l = self._vertices.tolist()
		l.append([x,y,z,1])

		self._vertices = np.array(l)

		return self


	def transform(self, x, y, z=0):
		'''Transform the vertices based on x/y coords'''

		translate_matrix = np.identity(4)
		translate_matrix[0, -1] = x
		translate_matrix[1, -1] = y
		translate_matrix[2, -1] = z


		self._vertices = np.dot(self._vertices, translate_matrix.T)[:, :4]
		return self


	def rotate(self, theta, origin=None, axis=np.array([0, 0, 1])):
		"""Rotate the shape by the given angle along the given axis.

		:param theta: The angle by which to rotate (in degrees)
		:type theta: float

		:param axis: The axis along which to rotate (defaults to the z-axis)
		:type axis: np.ndarray or list

	   """

		# Convert degrees to radians
		theta = theta * math.pi / 180

		axis = np.array(axis[:])

		x = axis[0]
		y = axis[1]
		z = axis[2]

		s = np.sin(theta)
		c = np.cos(theta)
		c1 = 1 - c

		rotation = np.identity(4)

		rotation[0, 0] = x * x * c1 + c
		rotation[0, 1] = x * y * c1 - z * s
		rotation[0, 2] = x * z * c1 + y * s
		rotation[1, 0] = y * x * c1 + z * s
		rotation[1, 1] = y * y * c1 + c
		rotation[1, 2] = y * z * c1 - x * s
		rotation[2, 0] = x * z * c1 - y * s
		rotation[2, 1] = y * z * c1 + x * s
		rotation[2, 2] = z * z * c1 + c

		if origin == None:
			x_c,y_c = self.center
		else:
			x_c = origin[0]
			y_c = origin[1]

		self.transform(-x_c, -y_c)


		rotation[0, -1] = x_c
		rotation[1, -1] = y_c
		rotation[2, -1] = 1

		self._vertices = np.dot(self._vertices, rotation.T)[:, :4]

		return self


	def rotate_x(self, theta):
		"""This is a convenience function to rotate the shape along the x axis.

		:param theta: The angle by which to rotate (in degrees)
		:type theta: float

		:returns: The rotation matrix used to apply the transformation.
		:rtype: np.ndarray

		"""
		self.rotate(theta, axis=np.array([1, 0, 0]))
		return self

	def rotate_y(self, theta):
		"""This is a convenience function to rotate the shape along the y axis.

		:param theta: The angle by which to rotate (in degrees)
		:type theta: float

		:returns: The rotation matrix used to apply the transformation.
		:rtype: np.ndarray

	   """
		self.rotate(theta, axis=np.array([0, 1, 0]))
		return self

	def rotate_z(self, theta):
		"""This is a convenience function to rotate the shape along the z axis.

		:param theta:The angle by which to rotate (in degrees)
		:type theta: float

		:returns: The rotation matrix used to apply the transformation.
		:rtype: np.ndarray

	   """
		self.rotate(theta, axis=np.array([0, 0, 1]))
		return self


	def scale(self, amt, amt_y=None, origin=None):
		"""Scale the shape by the given amount.

		:param amt: Scale factor for x-axis (2.0 = twice as big)
		:type amt: float
		:param amt_y: Scale factor for y-axis (defaults to amt for uniform scaling)
		:type amt_y: float
		:param origin: Origin point for scaling (defaults to shape center)
		:type origin: tuple
		"""

		if amt_y == None:
			amt_y = amt

		scale_matrix = np.identity(4)
		scale_matrix[0, 0] = amt
		scale_matrix[1, 1] = amt_y
		scale_matrix[2, 2] = 1  # default for z

		self._vertices = self._vertices.dot(scale_matrix)

		return self


	@property
	def svg_object(self):

		if len(self.vertices) > 0:

			verts = self.vertices

			verts = verts.tolist()

			# # verts = vertices.tolist()
			if len(verts)== 0 :
				print(f'verts contains one item of {[[0.0, 0.0, 0.0]]} ... continuing.')
				return None

			start_l = verts.pop(0)
			start_x = start_l[0]
			start_y = start_l[1]

			other_verts = []
			for o_v in verts:
				x = o_v[0]

				y = o_v[1]

				# z = o_v[2]
				other_verts.append(x)
				other_verts.append(y)

			return drawsvg.Lines(start_x, start_y, *other_verts, fill=self.fill_color, stroke=self.stroke_color,
								stroke_width=self.stroke_width, fill_opacity=self.fill_opacity, close=self.close_path)

		else:
			raise Exception("This does not have vertices or a custom svg_object, so it cannot be rendered.")