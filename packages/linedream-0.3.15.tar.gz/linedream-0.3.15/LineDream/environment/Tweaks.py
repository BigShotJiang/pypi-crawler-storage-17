class TweaksBase:
	def __init__(self):
		pass

	def add_tweak(self, t):

		return t

Tweaks = TweaksBase()