from .primitives.Line import Line
from .primitives.Ellipse import Circle, Ellipse, Point
from .primitives.Rectangle import Rectangle, Square
from .environment.Canvas import _Canvas

def main():
	print('entry point')