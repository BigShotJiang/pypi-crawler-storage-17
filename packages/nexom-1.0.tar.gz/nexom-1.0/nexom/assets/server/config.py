#Nexom Web Module Settings

#======== module ========
directory = "{pwd_dir}"

#======== gunicorn ========
_address = "{g_address}"
_port = {g_port}
_workers = {g_workers}
_reload = {g_reload}