from config import _address, _port, _workers, _reload

bind = f"{_address}:{_port}"
workers = _workers
reload = _reload