from nexom.web.path import Path, Pathlib
from nexom.web.request import Request
from nexom.web.response import Response, Redirect
from nexom.web.cookie import Cookie, RequestCookies
from nexom.web.template import Templates

from pages.test import test

if __name__ == "__main__":
    test()