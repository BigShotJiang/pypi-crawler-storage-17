Nexom Python Web Framework

## Install
```bash
pip install nexom

## Server Setup
python -m nexom build-server server_name
