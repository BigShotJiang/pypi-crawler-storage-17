__all__ = ["__version__"]
__version__ = "30.2025.5000"
