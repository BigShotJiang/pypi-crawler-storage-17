from typing import TypeAlias
from ...._schemas import Project

GetProjectsResponse: TypeAlias = list[Project]

