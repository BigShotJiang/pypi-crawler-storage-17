# __init__.py    tells python that this directory is a package
from .main import hello_world