## Install Deps
```bash
# Install dependencies (or pip install setuptools wheel twine)
pip install -r requirements.txt

# Upgrade/Install pip
pip install --upgrade pip --force-reinstall

# Install wheel
pip install -U pip build twine --force-reinstall

# Generates src dist and real dist (binaries all necessary files to run package)
python -m build

# installs a wheel package file from your local dist/ folder
# dist/ is the standard output folder where your build step drops artifacts.
pip install dist/*.whl --force-reinstall

# Test the the import
python -c "import rp_itqa_autolib; import rp_itqa_autolib.main; 
print('ok')"

#  Verify it shows up
pip list 
```


## Publish to PyPi


### Create a API token on PyPi.org

Store it here "$HOME/.pypirc"
```yml
[pypi]
  username = __token__
  password = pypi-AgEIcHlwaS5vcmcCJDNhNDZmYjEzLWQwOTktNDNlZS1hNTUwLWEzYTgxNzRmMDFlNAACKlszLCIxYTQzOTcxYS1iMDgyLTQyODgtYWIxOC04ZGYyNTg2YzU5NTQiXQAABiCkf4_9TtJfh3qfFZ4KA1HVdeiwSAVN1pQWr6mVL_U0pw
```
```bash
# Publish dist/ folder (wheels, .whl, and .tar.gz) 
# and uploads them to a Python package index for others to use
twine upload dist/*
```
