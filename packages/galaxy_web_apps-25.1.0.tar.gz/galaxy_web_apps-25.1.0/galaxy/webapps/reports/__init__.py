"""The Galaxy Reports application."""

from galaxy.web.framework import url_for
from galaxy.web.framework.decorators import expose

__all__ = ("url_for", "expose")
