
.. image:: https://badge.fury.io/py/galaxy-web-apps.svg
   :target: https://pypi.python.org/pypi/galaxy-web-apps/


Overview
--------

The Galaxy_ web apps (Galaxy, Reports, Tool Shed).

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
