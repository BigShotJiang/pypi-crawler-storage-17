from typing import Literal

GrokVoices = Literal[
    "Ara",
    "Eve",
    "Leo",
    "Rex",
    "Sal",
]
