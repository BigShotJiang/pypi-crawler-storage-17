# SPDX-FileCopyrightText: 2024-present David Holzmüller
#
# SPDX-License-Identifier: Apache-2.0

__version__ = "1.7.2"
