"""Entry point for running DeployGuard as a module."""

from deployguard.cli import main

if __name__ == "__main__":
    main()

