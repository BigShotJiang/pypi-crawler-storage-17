# Undetected Chromedriver

This is a fork of [`undetected-chromedriver`](https://github.com/ultrafunkamsterdam/undetected-chromedriver), a Selenium WebDriver replacement with enhanced compatibility for Brave and other Chromium-based browsers.  

It aims to bypass detection mechanisms like Cloudflare, Imperva, and hCaptcha, but results may vary depending on multiple factors. No guarantees are provided, but continuous efforts are made to improve evasion techniques.  
