# get_nhanes

A Python package for processing NHANES data.

## Installation

```bash
pip install -e .
```

## Usage

```python
import get_nhanes
```
