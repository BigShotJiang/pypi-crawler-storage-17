"""Documentation builder for the project."""
