"""Tests for the djpress app."""
