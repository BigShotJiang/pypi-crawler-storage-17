from .stack import run_stack_operations
from .queue import run_queue_operations

__all__ = [
    "run_stack_operations",
    "run_queue_operations",
]
