"""Parsing utilities for various data formats and structures."""

from .parse_docstring_from_file import parse_docstring_from_file as parse_docstring_from_file
