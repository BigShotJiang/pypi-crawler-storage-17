"""Data models for agents, messages, and tools."""
