# mkarchi

mkarchi is a CLI tool that creates a directory and file architecture
from a tree structure text file.

## Installation

```bash
pip install mkarchi
