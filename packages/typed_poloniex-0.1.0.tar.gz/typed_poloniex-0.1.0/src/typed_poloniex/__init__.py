"""
### Typed Poloniex
> A fully typed, validated async client for the Poloniex API

- Details
"""