# ⚠️ PROJECT DEPRECATED & RENAMED

This project has been renamed to **Kinetic Core** and is fully effectively deprecated.

**This package is NOT affiliated with, sponsored by, or endorsed by Salesforce, Inc.**

## Instructions

The `salesforce-toolkit` package is no longer supported and will raise an error if imported.

Please uninstall this package and switch to the new one:

```bash
pip uninstall salesforce-toolkit
pip install kinetic-core
```

## New Repository

Find the new project here: [https://github.com/KineticMCP/kinetic-core](https://github.com/KineticMCP/kinetic-core)
