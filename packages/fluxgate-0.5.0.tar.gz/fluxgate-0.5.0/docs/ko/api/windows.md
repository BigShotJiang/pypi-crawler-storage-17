# API: Window

이 페이지는 사용 가능한 Window를 문서화합니다. Window는 최근 호출에 대한 Metric을 저장하고 제공하는 역할을 합니다.

Window 선택에 대한 개요는 [Windows 컴포넌트 가이드](../components/windows.md)를 참조하십시오.

---

::: fluxgate.windows.CountWindow

::: fluxgate.windows.TimeWindow
