# API: Tracker

이 페이지는 사용 가능한 Tracker를 문서화합니다. Tracker는 예외를 검사하여 실패로 간주해야 하는지 여부를 결정하는 역할을 합니다.

Tracker 선택에 대한 개요는 [Tracker 컴포넌트 가이드](../components/trackers.md)를 참조하십시오.

---

::: fluxgate.trackers.All

::: fluxgate.trackers.TypeOf

::: fluxgate.trackers.Custom
