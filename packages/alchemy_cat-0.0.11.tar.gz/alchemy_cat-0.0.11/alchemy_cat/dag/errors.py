""" errors module """


class PyungoError(Exception):
    """ pyungo custom exception """
    pass
