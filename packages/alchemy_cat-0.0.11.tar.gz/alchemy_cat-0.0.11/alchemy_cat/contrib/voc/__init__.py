#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@author: Xiaobo Yang
@contact: hal_42@zju.edu.cn
@software: PyCharm
@file: __init__.py.py
@time: 2020/2/4 11:53
@desc:
"""
from alchemy_cat.contrib.voc.utils import *
from alchemy_cat.contrib.voc.voc2012seg import *
from alchemy_cat.contrib.voc.voc2012_auger import *
from .voc2012_auger2 import *
