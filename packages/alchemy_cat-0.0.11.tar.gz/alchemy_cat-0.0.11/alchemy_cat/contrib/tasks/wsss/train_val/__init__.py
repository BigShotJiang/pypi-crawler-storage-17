#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Xiaobo Yang
@Contact : hal_42@zju.edu.cn
@Time    : 2021/11/24 22:32
@File    : __init__.py.py
@Software: PyCharm
@Desc    : 
"""
from alchemy_cat.contrib.tasks.wsss.train_val.validate import *
