#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Xiaobo Yang
@Contact : hal_42@zju.edu.cn
@Time    : 2021/5/23 19:52
@File    : __init__.py.py
@Software: PyCharm
@Desc    : 
"""
from .score2seed import *
from .utils import *
