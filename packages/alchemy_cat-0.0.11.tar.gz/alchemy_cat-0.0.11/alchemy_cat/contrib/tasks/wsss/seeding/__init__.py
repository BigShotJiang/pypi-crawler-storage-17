#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Xiaobo Yang
@Contact : hal_42@zju.edu.cn
@Time    : 2021/5/20 22:57
@File    : __init__.py.py
@Software: PyCharm
@Desc    : 
"""
from .pred import *
from .score import *
