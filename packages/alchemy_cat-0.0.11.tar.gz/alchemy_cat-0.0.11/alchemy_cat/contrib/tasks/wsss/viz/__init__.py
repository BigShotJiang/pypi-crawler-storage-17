#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Xiaobo Yang
@Contact : hal_42@zju.edu.cn
@Time    : 2021/11/24 22:15
@File    : __init__.py.py
@Software: PyCharm
@Desc    : 
"""
from alchemy_cat.contrib.tasks.wsss.viz.viz_cam import *
from alchemy_cat.contrib.tasks.wsss.viz.viz_seed import *
