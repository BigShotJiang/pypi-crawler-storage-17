__all__ = ["GitSyncerConf"]

from ndev.services.git.syncer_conf import GitSyncerConf
