from setuptools import setup, find_packages

setup(
    name='epp_event_log_reader',
    version='2.3',
    description='An Eggplant Performance test results reader',
    packages=find_packages(),
)
