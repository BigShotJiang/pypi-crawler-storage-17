
#pip install -e .
import pysbs_peru.IndiceSpreadsCorporativo as isc 
import pysbs_peru.VectorPrecioRentaFija as vprf 
import pysbs_peru.CuponCero as cc 