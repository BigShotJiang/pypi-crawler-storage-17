"""API endpoints for the OpenDota wrapper."""
