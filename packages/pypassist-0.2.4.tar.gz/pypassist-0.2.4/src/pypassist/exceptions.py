#!/usr/bin/env python3
"""
Exceptions.
"""


class PypassistError(Exception):
    """
    Base exception for pypassist.
    """
