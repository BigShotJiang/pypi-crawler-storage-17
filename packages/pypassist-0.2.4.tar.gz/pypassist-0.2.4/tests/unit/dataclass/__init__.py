"""Unit tests for dataclass module."""
