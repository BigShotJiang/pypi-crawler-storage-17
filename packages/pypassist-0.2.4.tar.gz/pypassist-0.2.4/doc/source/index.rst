`PypAssist <https://gitlab.com/pypassist/pypassist>`_ Documentation
================================================================================================

``PypAssist`` is a collection of utilities for working with Python packages.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`