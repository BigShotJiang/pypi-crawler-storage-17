# GCWerks Bindings


GCwerks is a software use in chromatography. It is used to process chromatography data.
 
https://gcwerks.com/



## API

```{eval-rst}  
.. automodule:: avoca.bindings.ebas
    :members:
```