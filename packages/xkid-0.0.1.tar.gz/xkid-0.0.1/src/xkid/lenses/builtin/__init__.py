from __future__ import annotations

# Built-in lenses are imported by name from registry.py
