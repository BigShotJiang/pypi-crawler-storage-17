# Fin-Agent: 智能金融分析助手

<div align="center">

[![PyPI version](https://img.shields.io/pypi/v/fin-agent.svg?style=flat-square)](https://pypi.org/project/fin-agent/)
[![Python Versions](https://img.shields.io/pypi/pyversions/fin-agent.svg?style=flat-square)](https://pypi.org/project/fin-agent/)
[![License](https://img.shields.io/github/license/YUHAI0/fin-agent.svg?style=flat-square)](https://github.com/YUHAI0/fin-agent/blob/main/LICENSE)
[![Repo Size](https://img.shields.io/github/repo-size/YUHAI0/fin-agent.svg?style=flat-square)](https://github.com/YUHAI0/fin-agent)
[![Last Commit](https://img.shields.io/github/last-commit/YUHAI0/fin-agent.svg?style=flat-square)](https://github.com/YUHAI0/fin-agent/commits/main)

</div>

Fin-Agent 是一个基于 **DeepSeek** 等大模型和 **Tushare** 金融数据的智能金融分析代理。它能够通过自然语言交互，帮助用户查询股票行情、分析财务数据、获取市场指标、**选股筛选**以及**策略回测**，并提供投资参考建议。

## ✨ 主要功能

- **自然语言交互**：直接使用中文与 AI 对话，无需记忆复杂的命令或代码。
- **智能诊断**：结合 LLM 的分析能力，对获取的数据进行解读和总结。
- **全面的 Tushare 支持**：覆盖个股、大盘、资金、财务、热点等全方位数据。
- **多模型驱动**：
    - **国内主流大模型**: DeepSeek, Kimi (Moonshot), 智谱 (GLM-4), 阿里 (Qwen), 零一万物 (Yi), 硅基流动 (SiliconFlow)。
    - **本地模型**: 支持 Ollama, LM Studio 等本地部署的 OpenAI 兼容模型。
- **智能选股器**：通过自然语言描述选股条件（基本面、技术面、行业等），Agent 自动转换为筛选参数并返回结果。
- **策略回测引擎**：内置均线 (MA Cross)、MACD、RSI 等经典策略，可对指定股票进行历史回测，生成收益率、最大回撤等绩效报告。
- **深度技术分析**：内置 MACD、RSI、KDJ、BOLL 等常见指标计算，并支持金叉/死叉、超买/超卖等形态的自动识别。

## 📦 安装

```bash
pip install fin-agent
```

## 🚀 快速开始

安装完成后，直接在终端运行以下命令启动：

```bash
fin-agent
```

首次运行会自动引导您配置 API Key。

## ⚙️ 配置说明

Fin-Agent 需要以下配置才能完整工作：

1.  **Tushare Token**: 用于获取金融数据 ([注册 Tushare](https://tushare.pro/))
2.  **LLM 设置**: 
    - 支持直接配置 API Key 使用在线商业模型。
    - 也支持配置 Base URL 使用本地模型（如 Ollama）。
    - 启动时会有向导指引您选择模型供应商。

## 💻 命令行参数

Fin-Agent 提供了一些实用的命令行参数来管理配置和版本：

| 命令 | 说明 |
| :--- | :--- |
| `fin-agent` | 启动交互式对话模式（默认） |
| `fin-agent --clear-token` | 清除现有的 API Key 配置。当需要更换 Token 或切换 LLM 提供商时使用。 |
| `fin-agent --upgrade` | 自动检查 PyPI 并升级到 Fin-Agent 的最新版本。如果遇到重大版本更新，会自动清除旧配置。 |
| `fin-agent -v`, `--version` | 显示当前版本号。 |
| `fin-agent -h`, `--help` | 显示帮助信息和参数说明。 |

## 💬 场景示例

Fin-Agent 支持丰富的金融分析场景，您可以参考以下对话来探索它的能力：

### 1. 基础信息查询
> **用户**："平安银行属于什么行业？什么时候上市的？"
> **Agent**："平安银行（000001.SZ）属于银行行业，上市日期为 19910403。它是深圳本地的股份制商业银行..."

### 2. 实时行情与走势
> **用户**："现在的贵州茅台股价是多少？最近一周走势如何？"
> **Agent**："贵州茅台当前价格为 1750.00 元，今日下跌 0.5%。回顾过去一周（20240101-20240107），股价整体呈现震荡上行趋势，最高触及 1780 元..."

### 3. 大盘指数分析
> **用户**："今天大盘（上证指数）表现怎么样？"
> **Agent**："今日上证指数收于 3050 点，上涨 0.8%，成交量较昨日有所放大，市场情绪回暖..."

### 4. 估值与基本面
> **用户**："帮我看看万科A现在的估值高吗？"
> **Agent**："万科A当前的市盈率（PE）为 6.5 倍，市净率（PB）为 0.6 倍。与历史水平及同行业相比，当前估值处于较低位置..."

### 5. 财务业绩分析
> **用户**："宁德时代去年的营收和净利润是多少？"
> **Agent**："根据 2023 年年报，宁德时代实现营业收入 4009 亿元，同比增长 22%；净利润 441 亿元，同比增长 43%..."

### 6. 业绩预告筛选
> **用户**："最近有哪些公司发布了业绩预增公告？"
> **Agent**："为您查询到近期发布业绩预告的公司中，有以下几家业绩大幅预增：比亚迪（预计增长 60%）、立讯精密..."

### 7. 资金流向监测
> **用户**："今天中信证券的主力资金是流入还是流出？"
> **Agent**："今日中信证券主力资金（大单+特大单）净流出 2.5 亿元，其中特大单流出 1.8 亿元，显示机构资金有撤退迹象..."

### 8. 北向资金动向
> **用户**："今天外资（北向资金）都在买什么？"
> **Agent**："今日沪深港通十大成交活跃股中，外资净买入前三名分别为：贵州茅台（+5亿）、美的集团（+3亿）、招商银行（+2亿）..."

### 9. 涨跌停分析
> **用户**："今天有哪些股票涨停了？是什么原因？"
> **Agent**："今日共有 45 只股票涨停。其中华为概念股表现强势，赛力斯、欧菲光等多只个股涨停..."

### 10. 龙虎榜追踪
> **用户**："查一下今天龙虎榜的情况，有没有机构大举买入的票？"
> **Agent**："今日龙虎榜数据显示，机构席位净买入最多的个股是中科曙光，净买入金额达 3 亿元..."

### 11. 概念板块挖掘
> **用户**："列出几只Sora概念股。"
> **Agent**："Sora（文生视频）概念股主要包括：因赛集团、万兴科技、中广天择等。其中因赛集团近期关注度较高..."

### 12. 技术指标分析
> **用户**："帮我看看平安银行现在的 MACD 和 RSI 指标怎么样？"
> **Agent**："平安银行目前的 MACD 显示 DIF 为 0.15，DEA 为 0.12，MACD 柱状图为正，处于多头趋势。RSI(14) 为 65，显示买盘较强但未进入超买区..."

### 13. 技术形态自动识别
> **用户**："茅台现在出现了什么技术形态？"
> **Agent**："经过分析，贵州茅台（600519.SH）今日出现了 KDJ 金叉信号（K值上穿D值），且收盘价突破了布林带中轨，建议关注..."

### 14. 智能选股 (NEW!)
> **用户**："帮我选出市盈率小于 15，且总市值大于 500 亿的银行股。"
> **Agent**："为您筛选出符合条件的银行股，按市值排序前 5 名如下：工商银行 (PE 5.2, 市值 1.8万亿)、建设银行... 建议关注其中低估值且分红稳定的标的。"

### 15. 策略回测 (NEW!)
> **用户**："回测一下中信证券过去一年用 MACD 策略的表现。"
> **Agent**："回测完成。策略：MACD (金叉买入/死叉卖出)；标的：中信证券 (600030.SH)；时间范围：近一年。
> 结果：总收益率 **+12.5%**，最大回撤 **-8.3%**，共交易 6 次。表现优于同期大盘 (-5.0%)。"

## 📊 数据来源

*   **金融数据**: [Tushare Pro](https://tushare.pro/) - 专业免费的财经数据接口包。
*   **大模型**: 支持 [DeepSeek](https://www.deepseek.com/), Moonshot, ZhipuAI, Qwen 等多种模型。

## 📝 许可证

本项目采用 [MIT License](LICENSE) 开源许可证。

## 📈 开发活动

![Contribution Graph](https://github-readme-activity-graph.vercel.app/graph?username=YUHAI0&repo=fin-agent&theme=react)