def test_always_passes():
    """
    A simple placeholder test that always passes.
    This ensures the test runner is configured correctly.
    """
    assert True
