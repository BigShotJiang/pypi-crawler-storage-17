"""
MIMIC-IV + MCP + Models (M3): Local MIMIC-IV querying with LLMs via Model Context Protocol
"""

__version__ = "0.4.0"
