"""
MCP client configuration utilities.

This package contains scripts for configuring various MCP clients
with the M3 server.
"""
