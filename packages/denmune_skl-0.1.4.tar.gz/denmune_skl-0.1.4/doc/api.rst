.. _api:

#############
API Reference
#############

.. currentmodule:: denmune_skl

Denmune Clusterer
==================

.. autosummary::
   :toctree: generated/
   :template: class.rst

   DenMune
