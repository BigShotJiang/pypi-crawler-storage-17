from typing import List, Any, Optional
from pydantic import create_model, BaseModel, Field
from langchain_community.agent_toolkits.base import BaseToolkit
from langchain_core.tools import BaseTool, ToolException
from ..tools.datasource import DatasourcePredict, DatasourceSearch, datasourceToolSchema
from alita_sdk.tools.utils import clean_string


class DatasourcesToolkit(BaseToolkit):
    tools: List[BaseTool] = []
    
    @staticmethod
    def toolkit_config_schema() -> BaseModel:
        return create_model(
            "datasource",
            # client = (Any, FieldInfo(description="Client object", required=True, autopopulate=True)),
            datasource_ids = (list, Field(description="List of datasource ids", alias="datasource_id")),
            selected_tools = (list, Field(description="List of selected tools", default=['chat', 'search'])),
        )
    
    @classmethod
    def get_toolkit(cls, client: Any, datasource_ids: list[int], toolkit_name: Optional[str] = None, selected_tools: list[str] = []):
        tools = []
        # Use clean toolkit name for context (max 1000 chars in description)
        toolkit_context = f" [Toolkit: {clean_string(toolkit_name)}]" if toolkit_name else ''
        for datasource_id in datasource_ids:
            datasource = client.datasource(datasource_id)
            ds_name = clean_string(datasource.name)
            if len(ds_name) == 0:
                raise ToolException(f'Datasource with id {datasource_id} has incorrect name (i.e. special characters, etc.)')
            if len(selected_tools) == 0 or 'chat' in selected_tools:
                description = f'Search and summarize. {datasource.description}'
                if toolkit_context and len(description + toolkit_context) <= 1000:
                    description = description + toolkit_context
                tools.append(DatasourcePredict(name=f'chat',
                                            description=description,
                                            datasource=datasource, 
                                            args_schema=datasourceToolSchema,
                                            return_type='str'))
            if len(selected_tools) == 0 or 'search' in selected_tools:
                description = f'Search return results. {datasource.description}'
                if toolkit_context and len(description + toolkit_context) <= 1000:
                    description = description + toolkit_context
                tools.append(DatasourceSearch(name=f'search',
                                                description=description,
                                                datasource=datasource, 
                                                args_schema=datasourceToolSchema,
                                                return_type='str'))
        return cls(tools=tools)
            
    def get_tools(self):
        return self.tools
    