import hashlib
import hmac
import time
import json
import requests
import sys # Import sys for printing to stderr

class HgBestClientPython:
    """
    Initializes the HgBestClient with API credentials and base URL.
    """
    def __init__(self, api_key: str, api_secret: str, base_url: str = 'https://hgbest-backend.onrender.com'):
        if not api_key or not api_secret:
            raise ValueError('HgBestClient requires both api_key and api_secret.')

        self.api_key = api_key
        # Ensure api_secret is always bytes for hmac.new
        self.api_secret = api_secret.encode('utf-8')
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        })

    def _generate_sha256_hash(self, data: str) -> str:
        """
        Generates an SHA256 hash of a string.
        """
        hash_val = hashlib.sha256(data.encode('utf-8')).hexdigest()
        print(f"DEBUG_SDK (hash): Hashing data: '{data.replace('\n', '\\n')}'", file=sys.stderr) # ADDED DEBUG
        print(f"DEBUG_SDK (hash): Generated SHA256 Hash: {hash_val}", file=sys.stderr) # ADDED DEBUG
        return hash_val

    def _generate_signature(self, method: str, path: str, timestamp: str, request_body: str) -> str:
        """
        Generates an HMAC SHA256 signature for the request.
        """
        body_hash = self._generate_sha256_hash(request_body)

        string_to_sign = f"{method}\n{path}\n{timestamp}\n{body_hash}"
        print(f"DEBUG_SDK (sign): String to Sign: '{string_to_sign.replace('\n', '\\n')}'", file=sys.stderr) # ADDED DEBUG

        # hmac.new expects key as bytes
        hmac_obj = hmac.new(self.api_secret, string_to_sign.encode('utf-8'), hashlib.sha256)
        signature = hmac_obj.hexdigest()
        print(f"DEBUG_SDK (sign): Generated HMAC Signature: {signature}", file=sys.stderr) # ADDED DEBUG
        return signature

    def _send_signed_request(self, method: str, endpoint: str, data: dict = None):
        """
        Makes a signed API request to the backend.
        """
        timestamp = str(int(time.time() * 1000))  # Unix milliseconds as string

        request_body_str = ""
        if data and (method == 'POST' or method == 'PUT'):
            # Ensure no extra spaces and consistent key ordering for hashing
            # Python's json.dumps generally outputs keys in a stable order for dicts
            # if they are inserted in a stable order (Python 3.7+ dicts preserve insertion order).
            # Using separators=(',', ':') removes whitespace to ensure consistent hashing.
            request_body_str = json.dumps(data, separators=(', ', ': '))

        # --- ADDED DEBUG PRINTS ---
        print(f"DEBUG_SDK (request): Method: {method}", file=sys.stderr)
        print(f"DEBUG_SDK (request): Endpoint: {endpoint}", file=sys.stderr)
        print(f"DEBUG_SDK (request): Timestamp: {timestamp}", file=sys.stderr)
        print(f"DEBUG_SDK (request): Raw Data (dict): {data}", file=sys.stderr)
        print(f"DEBUG_SDK (request): Request Body String for Hashing: '{request_body_str}'", file=sys.stderr)
        # ----------------------------

        signature = self._generate_signature(method, endpoint, timestamp, request_body_str)

        headers = {
            'X-API-KEY': self.api_key,
            'X-API-TIMESTAMP': timestamp,
            'X-API-SIGNATURE': signature,
        }
        # Update session headers, but make sure to remove them or manage carefully
        # if other requests in the same session might use different auth.
        # For this SDK design, overwriting them per request is fine.
        self.session.headers.update(headers)

        url = f"{self.base_url}{endpoint}"

        try:
            if method == 'GET':
                response = self.session.get(url, params=data, timeout=10) # Added timeout
            elif method == 'POST':
                response = self.session.post(url, json=data, timeout=10) # Added timeout
            elif method == 'PUT':
                response = self.session.put(url, json=data, timeout=10) # Added timeout
            elif method == 'DELETE':
                response = self.session.delete(url, json=data, timeout=10) # Added timeout
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            print(f"DEBUG_SDK (response): Response Status: {response.status_code}", file=sys.stderr)
            print(f"DEBUG_SDK (response): Response Text: {response.text}", file=sys.stderr)

            response.raise_for_status() # Raise an HTTPError for bad responses (4xx or 5xx)
            return response.json()
        except requests.exceptions.HTTPError as e:
            print(f"API Error for {method} {endpoint}: {e.response.status_code} - {e.response.text}", file=sys.stderr)
            raise # Re-raise the exception after printing debug info
        except requests.exceptions.RequestException as e:
            print(f"Request Error for {method} {endpoint}: {e}", file=sys.stderr)
            raise # Re-raise the exception after printing debug info

    # --- API Methods (Grouped by domain for clarity) ---

    @property
    def risk(self):
        return _RiskAPI(self)

    @property
    def health(self):
        return _HealthAPI(self)

    @property
    def finance(self):
        return _FinanceAPI(self)

    @property
    def market(self):
        return _MarketAPI(self)

# --- Nested API Classes ---

class _RiskAPI:
    def __init__(self, client: 'HgBestClientPython'):
        self._client = client

    def global_supply_chain_alert(self, payload: dict):
        return self._client._send_signed_request('POST', '/risk/global-supply-chain-alert', payload)

class _HealthAPI:
    def __init__(self, client: 'HgBestClientPython'):
        self._client = client

    def predictive_patient_summary(self, payload: dict):
        return self._client._send_signed_request('POST', '/health/predictive-patient-summary', payload)

    def submit_report(self, payload: dict):
        return self._client._send_signed_request('POST', '/health/reports', payload)

    def get_reports(self, report_id: str = None):
        endpoint = f'/health/reports/{report_id}' if report_id else '/health/reports'
        return self._client._send_signed_request('GET', endpoint)

class _FinanceAPI:
    def __init__(self, client: 'HgBestClientPython'):
        self._client = client

    def macro_sentiment_score(self, payload: dict):
        return self._client._send_signed_request('POST', '/finance/macro-sentiment-score', payload)

class _MarketAPI:
    def __init__(self, client: 'HgBestClientPython'):
        self._client = client

    def algorithmic_divergence_signal(self, payload: dict):
        return self._client._send_signed_request('POST', '/market/algorithmic-divergence-signal', payload)

# Note: The deprecated methods from your original Node.js SDK are omitted here
# for brevity and focus on the core new methods. If you wish to include them,
# you can add them back to the HgBestClientPython class, ensuring they call
# _send_signed_request with appropriate methods and endpoints.


