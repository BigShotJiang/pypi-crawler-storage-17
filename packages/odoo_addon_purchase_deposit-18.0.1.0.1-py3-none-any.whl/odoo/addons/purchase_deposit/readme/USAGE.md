When purchase order is confirmed, a new button "Register Deposit" will
appear. Normally, deposit will be used to create the 1st bill (as
deposit).

1.  On confirmed purchase order, click Register Deposit button, wizard
    will open
2.  2 type of deposit bill can be create 1) Down Payment (percentage) 2)
    Deposit Payment (fixed amount)
3.  Fill in the value and click Create bill or just create deposit.

As deposit is created, when user click button "Create Bill" again in
purchase order, the Vendor Bill will be created with deposit amount
deducted.
