##########################
Acounts Spanish SII Module
##########################

The *Account Spanish SII Module* allow to send invoices to the `SII
<https://sede.agenciatributaria.gob.es/Sede/iva/suministro-inmediato-informacion.html>`_
portal.
This is legal requirement for some Spanish Companies.

.. toctree::
   :maxdepth: 2

   usage
   configuration
   design
   releases
