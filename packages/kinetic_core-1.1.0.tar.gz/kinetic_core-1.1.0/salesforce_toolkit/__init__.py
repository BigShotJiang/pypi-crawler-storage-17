from kinetic_core import *
import warnings

warnings.warn(
    "salesforce-toolkit is deprecated. Please use kinetic-core instead.",
    DeprecationWarning,
    stacklevel=2
)
