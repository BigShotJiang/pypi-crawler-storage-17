__author__ = "amiralimollaei"

from . import main

if __name__ == "__main__":
    main()
