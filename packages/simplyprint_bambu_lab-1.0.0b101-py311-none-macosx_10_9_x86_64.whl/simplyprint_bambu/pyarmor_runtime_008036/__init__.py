# Pyarmor 9.0.8 (ci), 008036, 2025-12-17T16:10:18.464262
from .pyarmor_runtime import __pyarmor__
