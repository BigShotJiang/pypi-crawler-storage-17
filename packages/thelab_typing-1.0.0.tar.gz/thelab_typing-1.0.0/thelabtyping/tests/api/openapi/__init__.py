"""Tests for OpenAPI generation module."""
