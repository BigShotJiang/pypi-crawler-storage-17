#include <cstdlib>

// More efficient to compile than torch/torch.h and others
#include <ATen/core/Tensor.h>

int
main()
{
    return EXIT_SUCCESS;
}