"""Metadata deduced from git at build time."""

id: str
short_id: str

id = "67e7b22e03cbfb2d1c7cc3fdec60bd811440fa85"
short_id = "67e7b22"
