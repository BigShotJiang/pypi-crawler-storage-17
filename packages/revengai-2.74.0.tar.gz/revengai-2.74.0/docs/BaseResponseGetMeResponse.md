# BaseResponseGetMeResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **bool** | Response status on whether the request succeeded | [optional] [default to True]
**data** | [**GetMeResponse**](GetMeResponse.md) |  | [optional] 
**message** | **str** |  | [optional] 
**errors** | [**List[ErrorModel]**](ErrorModel.md) |  | [optional] 
**meta** | [**MetaModel**](MetaModel.md) | Metadata | [optional] 

## Example

```python
from revengai.models.base_response_get_me_response import BaseResponseGetMeResponse

# TODO update the JSON string below
json = "{}"
# create an instance of BaseResponseGetMeResponse from a JSON string
base_response_get_me_response_instance = BaseResponseGetMeResponse.from_json(json)
# print the JSON string representation of the object
print(BaseResponseGetMeResponse.to_json())

# convert the object into a dict
base_response_get_me_response_dict = base_response_get_me_response_instance.to_dict()
# create an instance of BaseResponseGetMeResponse from a dict
base_response_get_me_response_from_dict = BaseResponseGetMeResponse.from_dict(base_response_get_me_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


