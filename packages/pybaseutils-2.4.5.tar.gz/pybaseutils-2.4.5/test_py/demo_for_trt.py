# -*- coding: utf-8 -*-
"""
    @Author : PKing
    @E-mail : 390737991@qq.com
    @Date   : 2022-12-22 17:50:13
    @Brief  :
"""
import tensorrt

print(tensorrt.__version__)