"""Validobj gives you valid objects"""

__version__ = '1.5'

from .validation import parse_input
from .errors import ValidationError
