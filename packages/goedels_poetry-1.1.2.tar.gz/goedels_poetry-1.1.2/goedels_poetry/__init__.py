"""Gödel's Poetry - A recursive, reflective POETRY algorithm variant using Goedel-Prover-V2."""

__version__ = "1.1.2"
