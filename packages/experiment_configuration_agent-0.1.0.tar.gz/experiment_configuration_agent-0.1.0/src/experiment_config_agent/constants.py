AUTOGLUON_CONFIG_SYSTEM_PROMPT = """You are an expert AutoGluon configuration advisor specializing in optimizing TabularPredictor settings for various machine learning problems.

Your role is to analyze the provided information about:
1. The domain and business context
2. The specific use case and problem type
3. The methodology (classification type or regression)
4. Dataset characteristics from the modeling-ready insights

Based on this analysis, you must recommend optimal AutoGluon TabularPredictor configuration parameters that balance:
- Predictive accuracy and model quality
- Training time and computational resources
- Inference speed requirements
- Model complexity and interpretability needs
- Domain-specific requirements

Key AutoGluon Concepts:
======================

EVALUATION METRICS:
- For binary classification: f1, precision, recall, accuracy, roc_auc, balanced_accuracy, log_loss, mcc
- For multiclass classification: accuracy, balanced_accuracy, log_loss, f1_macro, f1_micro, f1_weighted
- For regression: rmse, mae, r2, mse, mape
- Choose metrics based on business requirements (e.g., f1 for imbalanced classes, accuracy for balanced classes)

PRESETS (Quality vs Speed Tradeoff):
- "best_quality": Maximum accuracy with auto_stack=True, uses bagging/stacking (slowest, most accurate)
- "high_quality": Strong accuracy with fast inference, moderate complexity
- "good_quality": Good accuracy with very fast inference (recommended default)
- "medium_quality": Fast training time, ideal for prototyping
- "optimize_for_deployment": Minimal memory/compute footprint
- "interpretable": Simple, explainable models (e.g., linear models, shallow trees)

BAGGING & STACKING (Ensemble Methods):
- num_bag_folds: 0=no bagging, 5-10=k-fold bagging (improves accuracy, increases training time)
- num_bag_sets: Number of times to repeat k-fold bagging (1-3, only if num_bag_folds>0)
- num_stack_levels: 0=no stacking, 1=single-level stacking, 2+=multi-level stacking
- auto_stack: True=AutoGluon automatically determines optimal stacking/bagging (recommended for best quality)
- refit_full: True=retrain on full dataset after validation (essential when bagging is used)

TIME CONSTRAINTS:
- time_limit: Total seconds for training (60-3600+ depending on dataset size)
- Larger datasets need more time, more complex models need more time
- Consider: small datasets (<10K rows): 60-300s, medium (10K-100K): 300-1800s, large (>100K): 1800-7200s

INFERENCE SPEED:
- infer_limit: Max seconds per row prediction (e.g., 0.001=1ms, 0.00005=0.05ms)
- infer_limit_batch_size: Batch size for speed calculation (1=online, 1000+=batch inference)
- Only specify if real-time inference speed is critical

DECISION THRESHOLD CALIBRATION (Binary Classification):
- "auto": Calibrate for metrics like f1, balanced_accuracy (recommended)
- True: Always calibrate
- False: Never calibrate
- Significantly improves f1, balanced_accuracy, and recall-related metrics

Domain-Specific Considerations:
==============================

MANUFACTURING/QUALITY CONTROL:
- High precision to avoid false positives (unnecessary inspections)
- Use precision, f1 metrics
- Consider interpretable models for regulatory compliance
- Fast inference for real-time monitoring

HEALTHCARE/MEDICAL:
- High recall to avoid missing critical cases
- Use recall, balanced_accuracy, f1 metrics
- Interpretability is often critical
- May need decision threshold calibration

FRAUD DETECTION:
- Highly imbalanced classes
- Use f1, balanced_accuracy, roc_auc, precision-recall metrics
- Fast inference for real-time detection
- Consider calibrate_decision_threshold=True

PREDICTIVE MAINTENANCE:
- Balance precision and recall
- Consider temporal patterns
- Fast inference for real-time monitoring
- Good interpretability for actionable insights

CUSTOMER CHURN/RETENTION:
- Focus on identifying at-risk customers (recall)
- Use f1, balanced_accuracy, roc_auc
- Interpretability helps with intervention strategies

FINANCIAL/CREDIT SCORING:
- Regulatory requirements for interpretability
- Balance precision and recall
- Consider "interpretable" preset or simple models

Dataset Characteristics Impact:
==============================

SMALL DATASETS (<10K rows):
- Benefit greatly from bagging (num_bag_folds=5-8)
- May overfit with too many models
- Shorter time_limit (60-300s)
- Consider cross-validation

IMBALANCED CLASSES:
- Use f1, balanced_accuracy, roc_auc metrics (NOT accuracy)
- Consider calibrate_decision_threshold=True
- May benefit from custom hyperparameters

HIGH-DIMENSIONAL DATA (many features):
- May need longer time_limit
- Feature importance analysis post-training
- Consider preset="best_quality" for feature interactions

TEMPORAL/TIME-SERIES PATTERNS:
- Be cautious with shuffling (AutoGluon does stratified splits)
- May need time-based validation splits
- Consider specialized time-series features

Be thoughtful, analytical, and provide production-ready recommendations."""



def format_autogluon_config_prompt(
    domain: dict,
    use_case: str,
    methodology: str,
    dataset_insights: dict
) -> tuple[str, str]:
    """
    Format the system and user prompts for AutoGluon configuration recommendation.
    
    Args:
        domain_name: Name of the business domain
        domain_description: Detailed description of the domain context
        use_case: Description of the specific use case and problem
        methodology: Type of ML problem (binary_classification, multiclass_classification, regression)
        dataset_insights: Dictionary containing feature and target information
        
    Returns:
        Tuple of (system_prompt, user_prompt)
    """
    
    # feature_columns = dataset_insights.get('feature_columns', {})
    # target_info = dataset_insights.get('target', {})
    
    # feature_summary = []
    # for col_name, col_info in feature_columns.items():
    #     feature_summary.append(
    #         f"  - {col_name}: "
    #         f"type={col_info.get('dtype', 'unknown')}, "
    #         f"missing={col_info.get('missing_pct', 0):.1f}%, "
    #         f"unique={col_info.get('unique_count', 'N/A')}"
    #     )
    #     if 'min' in col_info and 'max' in col_info:
    #         feature_summary.append(f"    range=[{col_info['min']}, {col_info['max']}]")
    
    # feature_text = "\n".join(feature_summary) if feature_summary else "No feature information provided"
    
    # # Format target information
    # target_text = []
    # if target_info:
    #     target_text.append(f"Target Column: {target_info.get('name', 'unknown')}")
    #     target_text.append(f"  Type: {target_info.get('dtype', 'unknown')}")
        
    #     if 'class_distribution' in target_info:
    #         target_text.append("  Class Distribution:")
    #         for cls, count in target_info['class_distribution'].items():
    #             target_text.append(f"    - {cls}: {count}")
        
    #     if 'min' in target_info and 'max' in target_info:
    #         target_text.append(f"  Range: [{target_info['min']}, {target_info['max']}]")
            
    #     if 'mean' in target_info:
    #         target_text.append(f"  Mean: {target_info['mean']:.2f}")
    
    # target_summary = "\n".join(target_text) if target_text else "No target information provided"
    
    # # Get dataset size information
    # num_samples = dataset_insights.get('num_samples', 'unknown')
    # num_features = len(feature_columns) if feature_columns else 'unknown'

    # DATASET INSIGHTS:
    # ================
    # Number of Samples: {num_samples}
    # Number of Features: {num_features}

    # Features:
    # {feature_text}

    # {target_summary}
    # 8. hyperparameters: Hyperparameter preset ("default", "light", "very_light")
    # 9. auto_stack: Whether to use automatic stacking (true/false)
    # 10. infer_limit: Max inference time per row in seconds (or null)
    # 11. infer_limit_batch_size: Batch size for inference speed (or null)
    # 12. refit_full: Whether to retrain on full data (true/false)
    # 13. calibrate_decision_threshold: Threshold calibration setting ("auto", true, false)

    
    user_prompt = f"""Please recommend optimal AutoGluon TabularPredictor configuration for the following scenario:

DOMAIN INFORMATION:
==================
Domain: {domain}

USE CASE:
=========
{use_case}

METHODOLOGY:
===========
Problem Type: {methodology}

DATASET INSIGHTS:
================
{dataset_insights}

TASK:
=====
Based on the above information, recommend an optimal AutoGluon configuration that includes:

1. eval_metric: The primary metric to optimize
2. preset: Quality/speed tradeoff preset  
3. additional_metrics: Other metrics to track (list)
4. time_limit: Training time in seconds
5. num_bag_folds: Number of k-fold bagging folds (0 for none, 5-10 for bagging)
6. num_bag_sets: Number of bagging sets (1-3, only if bagging is used)
7. num_stack_levels: Number of stacking levels 


Consider multiple scenarios:
- Scenario A: Maximum accuracy (accepting longer training time)
- Scenario B: Balanced accuracy and speed (production-ready)
- Scenario C: Fast training and inference (prototyping/deployment constrained)

"""
    
    return AUTOGLUON_CONFIG_SYSTEM_PROMPT, user_prompt