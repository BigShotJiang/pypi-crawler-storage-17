from pydantic import BaseModel, Field
from typing import List, Literal, Optional


class AutoGluonConfig(BaseModel):
    eval_metric: str = Field(..., description="Primary metric to optimize. For binary classification: 'f1', 'precision', 'recall', 'accuracy', 'roc_auc', 'balanced_accuracy', 'log_loss'. For multiclass: 'accuracy', 'balanced_accuracy', 'log_loss', 'f1_macro', 'f1_micro', 'f1_weighted'. For regression: 'rmse', 'mae', 'r2', 'mse'")
    
    preset: Literal["best_quality", "high_quality", "good_quality", "medium_quality", "optimize_for_deployment", "interpretable"] = Field(..., description="Preset configurations that control model complexity and training strategy. 'best_quality' for maximum accuracy with stacking/bagging, 'high_quality' for strong accuracy with fast inference, 'good_quality' for good accuracy with very fast inference, 'medium_quality' for fast training, 'optimize_for_deployment' for minimal memory/compute, 'interpretable' for simple models")
    
    additional_metrics: List[str] = Field(..., description="List of additional metrics to track during training. Options: 'f1', 'precision', 'recall', 'accuracy', 'roc_auc', 'balanced_accuracy', 'log_loss', 'rmse', 'mae', 'r2', 'mse'")
    
    time_limit: int = Field(..., description="Time limit in seconds for training all models. Recommended: 60-3600 seconds depending on dataset size and complexity")
    
    num_bag_folds: int = Field(..., description="Number of folds for k-fold bagging. 0 = no bagging, 5-10 = good for improving accuracy with longer training time. Higher values reduce overfitting but increase training time and memory usage")
    
    num_bag_sets: int = Field(..., description="Number of bagging sets. Each set repeats k-fold bagging to further reduce variance. 1 = standard bagging, 2-3 = better accuracy but much longer training. Only relevant when num_bag_folds > 0")
    
    num_stack_levels: int = Field(..., description="Number of stacking levels. 0 = no stacking, 1 = one level of stacking (models trained on predictions of base models), 2+ = multi-level stacking. Higher values can improve accuracy but increase training time exponentially")
    
    # hyperparameters: Optional[str] = Field(default="default", description="Hyperparameters preset. 'default' = balanced set of models, 'light' = fast training with simpler models, 'very_light' = very fast training, 'toy' = minimal training for testing. Can also be a custom dict")
    
    # auto_stack: bool = Field(..., description="If True, automatically determines optimal stacking/bagging configuration. Recommended for best quality. Overrides num_bag_folds, num_bag_sets, num_stack_levels")
    
    # infer_limit: Optional[float] = Field(..., description="Maximum time in seconds to predict a single row. If specified, AutoGluon will only train models that meet this constraint. Example: 0.001 = 1ms per row, 0.00005 = 0.05ms per row (20000 rows/sec)")
    
    # infer_limit_batch_size: Optional[int] = Field(..., description="Batch size for inference speed calculation when infer_limit is specified. 1 = online inference (strict), 1000+ = batch inference (easier to satisfy). Must be specified if infer_limit is set")
    
    # refit_full: bool = Field(..., description="Whether to retrain models on full dataset after initial training. Significantly improves quality when bagging is used. Recommended: True if bagging is enabled")
    
    # calibrate_decision_threshold: Literal["auto", True, False] = Field(..., description="Whether to calibrate the decision threshold for binary classification. 'auto' = calibrate for metrics like f1, balanced_accuracy but not for accuracy, True = always calibrate, False = never calibrate")