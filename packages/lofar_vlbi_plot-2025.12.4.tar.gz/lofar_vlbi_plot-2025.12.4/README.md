# LOFAR-VLBI/plot_field


This repository now contains only the preparatory script for generating the required catalogues for running PILOT (https://github.com/LOFAR-VLBI/pilot)

The script can be installed by:
```bash
pip install lofar-vlbi-plot

# Run directly 
uvx lofar-vlbi-plot --RA 0.234 --DEC 32.234
```




