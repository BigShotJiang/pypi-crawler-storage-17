#################################
Account Tax Non-Deductible Module
#################################

The *Account Tax Non-Deductible Module* allows to define non-deductible taxes
and reports them.

.. toctree::
   :maxdepth: 2

   design
   releases
