2025-12-12 Version: 3.11.1
- Update API CreateAntCloudAuthScene: add request parameters ReturnPicCount.
- Update API CreateAntCloudAuthScene: add request parameters ReturnVideoLength.
- Update API DescribeListAntCloudAuthScenes: add response parameters Body.Scenes.$.ReturnPicCount.
- Update API DescribeListAntCloudAuthScenes: add response parameters Body.Scenes.$.ReturnVideoLength.
- Update API UpdateAntCloudAuthScene: add request parameters ReturnPicCount.
- Update API UpdateAntCloudAuthScene: add request parameters ReturnVideoLength.


2025-11-07 Version: 3.11.0
- Support API CreateAntCloudAuthScene.
- Support API CreateCloudauthstScene.
- Support API CreateSceneConfig.
- Support API CreateWhitelistSetting.
- Support API DeleteAllCustomizeFlowStrategy.
- Support API DeleteAntCloudAuthScene.
- Support API DeleteBlackListStrategy.
- Support API DeleteCloudauthstScene.
- Support API DeleteControlStrategy.
- Support API DeleteCustomizeFlowStrategy.
- Support API DeleteSceneConfig.
- Support API DeleteWhitelistSetting.
- Support API DescribeAntAndCloudAuthUserStatus.
- Support API DescribeCloudauthstSceneList.
- Support API DescribeInfoCheckExportRecord.
- Support API DescribeListAntCloudAuthScenes.
- Support API DescribeListFaceVerifyData.
- Support API DescribeListFaceVerifyInfos.
- Support API DescribeMetaSearchPageList.
- Support API DescribeMetaStatisticsList.
- Support API DescribeMetaStatisticsPageList.
- Support API DescribeOssStatus.
- Support API DescribeOssStatusV2.
- Support API DescribePageSetting.
- Support API DescribeProductCode.
- Support API DescribeVerifyDeviceRiskStatistics.
- Support API DescribeVerifyFailStatistics.
- Support API DescribeVerifyPersonasDeviceModelStatistics.
- Support API DescribeVerifyPersonasOsStatistics.
- Support API DescribeVerifyPersonasProvinceStatistics.
- Support API DescribeVerifyPersonasSexStatistics.
- Support API DescribeVerifySearchPageList.
- Support API DescribeVerifyStatistics.
- Support API DescribeWhitelistSetting.
- Support API DownloadVerifyRecords.
- Support API Id3MetaVerifyWithOCR.
- Support API ModifyBlackListStrategy.
- Support API ModifyControlStrategy.
- Support API ModifyCustomizeFlowStrategyList.
- Support API QueryBlackListStrategy.
- Support API QueryControlStrategy.
- Support API QueryCustomizeFlowStrategy.
- Support API QuerySceneConfigs.
- Support API QueryVerifyDownloadTask.
- Support API QueryVerifyFlowPackage.
- Support API QueryVerifyInvokeSatistic.
- Support API UpdateAntCloudAuthScene.
- Support API UpdateSceneConfig.
- Update API InitFaceVerify: add request parameters H5DegradeConfirmBtn.


2025-09-25 Version: 3.10.0
- Support API Id3MetaVerify.


2025-09-08 Version: 3.9.5
- Update API InitFaceVerify: add request parameters NeedMultiFaceCheck.


2025-08-27 Version: 3.9.4
- Generated python 2019-03-07 for Cloudauth.

2025-08-19 Version: 3.9.3
- Generated python 2019-03-07 for Cloudauth.

2025-06-12 Version: 3.9.2
- Update API CredentialVerifyV2: add request parameters ImageContext.


2025-06-10 Version: 3.9.1
- Update API DescribeCardVerify: add response parameters Body.ResultObject.FaceDetail.


2025-06-10 Version: 3.9.0
- Support API CredentialProductVerifyV2.


2025-06-09 Version: 3.8.0
- Support API DescribeCardVerify.
- Support API InitCardVerify.


2025-06-06 Version: 3.7.0
- Support API Mobile2MetaVerify.


2025-04-27 Version: 3.6.0
- Support API Id2MetaVerifyWithOCR.


2025-04-21 Version: 3.5.0
- Support API CredentialVerifyV2.


2025-01-20 Version: 3.4.2
- Update API InitFaceVerify: add param CameraSelection.


2025-01-06 Version: 3.4.0
- Support API Id2MetaPeriodVerify.
- Support API Mobile3MetaDetailStandardVerify.
- Support API Mobile3MetaSimpleStandardVerify.


2024-11-21 Version: 3.3.0
- Support API Id2MetaStandardVerify.


2024-11-20 Version: 3.2.2
- Update API Id2MetaVerify: update param IdentifyNum.
- Update API Id2MetaVerify: update param ParamType.
- Update API Id2MetaVerify: update param UserName.
- Update API Mobile3MetaDetailVerify: update param IdentifyNum.
- Update API Mobile3MetaDetailVerify: update param Mobile.
- Update API Mobile3MetaDetailVerify: update param ParamType.
- Update API Mobile3MetaDetailVerify: update param UserName.
- Update API Mobile3MetaSimpleVerify: update param IdentifyNum.
- Update API Mobile3MetaSimpleVerify: update param Mobile.
- Update API Mobile3MetaSimpleVerify: update param ParamType.
- Update API Mobile3MetaSimpleVerify: update param UserName.
- Update API MobileDetect: update param Mobiles.
- Update API MobileDetect: update param ParamType.
- Update API MobileOnlineStatus: update param Mobile.
- Update API MobileOnlineStatus: update param ParamType.
- Update API MobileOnlineTime: update param Mobile.
- Update API MobileOnlineTime: update param ParamType.


2024-11-19 Version: 3.2.1
- Update API DescribeFaceGuardRisk: update response param.


2024-11-15 Version: 3.2.0
- Support API DescribeFaceGuardRisk.


2024-10-21 Version: 3.1.0
- Support API DeleteFaceVerifyResult.


2024-10-09 Version: 3.0.0
- Update API CredentialVerify: update response param.


2024-09-25 Version: 2.9.0
- Support API InsertWhiteListSetting.
- Support API PageQueryWhiteListSetting.
- Support API RemoveWhiteListSetting.
- Update API CredentialVerify: add param MerchantDetail.
- Update API CredentialVerify: add param ProductCode.
- Update API CredentialVerify: add param Prompt.
- Update API CredentialVerify: add param PromptModel.
- Update API CredentialVerify: update response param.


2024-09-11 Version: 2.8.0
- Support API Vehicle5ItemQuery.
- Support API VehicleInsureQuery.
- Support API VehicleMetaVerify.
- Support API VehicleMetaVerifyV2.
- Support API VehicleQuery.


2024-09-04 Version: 2.7.3
- Update API BankMetaVerify: add param IdentityType.


2024-08-12 Version: 2.7.2
- Update API InitFaceVerify: add param AppQualityCheck.
- Update API InitFaceVerify: update param FaceContrastPicture.


2024-07-02 Version: 2.7.1
- Update API InitFaceVerify: add param VideoEvidence.


2024-06-19 Version: 2.7.0
- Support API DeepfakeDetect.


2024-06-13 Version: 2.6.2
- Update API InitFaceVerify: add param UiCustomUrl.


2024-05-30 Version: 2.6.1
- Update API CompareFaceVerify: update param SourceFaceContrastPicture.
- Update API CompareFaceVerify: update param TargetFaceContrastPicture.
- Update API CredentialVerify: add param MerchantId.
- Update API CredentialVerify: update response param.


2024-04-26 Version: 2.6.0
- Support API CredentialVerify.


2024-04-10 Version: 2.5.0
- Support API BankMetaVerify.
- Support API DescribePageFaceVerifyData.
- Support API MobileDetect.
- Support API MobileOnlineStatus.
- Support API MobileOnlineTime.


2024-03-13 Version: 2.4.0
- Support API AIGCFaceVerify.


2024-02-22 Version: 2.3.0
- Support API AIGCFaceVerify.


2024-01-23 Version: 2.2.2
- Update Tea.

2024-01-18 Version: 2.2.1
- Generated python 2019-03-07 for Cloudauth.

2023-11-09 Version: 2.2.0
- Generated python 2019-03-07 for Cloudauth.

2023-11-07 Version: 2.1.1
- Generated python 2019-03-07 for Cloudauth.

2023-09-15 Version: 2.1.0
- Generated python 2019-03-07 for Cloudauth.

2023-07-31 Version: 2.0.8
- For 2019-03-07.

2023-07-14 Version: 2.0.7
- For 2019-03-07.

2023-05-18 Version: 2.0.6
- For 2019-03-07.

2022-11-02 Version: 2.0.5
- For 2019-03-07.

2022-10-17 Version: 2.0.4
- For 2019-03-07.

2022-06-29 Version: 2.0.3
- For 2019-03-07.

2022-02-23 Version: 1.0.7
- Add AuthId.

2021-10-27 Version: 2.0.2
- Generated python 2019-03-07 for Cloudauth.

2021-10-27 Version: 1.0.6
- Generated python 2019-03-07 for Cloudauth.

2021-09-09 Version: 1.0.5
- AMP Version Change.

2021-09-08 Version: 1.0.4
- Support crop face image.

2021-04-20 Version: 1.0.2
- LivenessFaceVerify ContrastFaceVerify CompareFaceVerify API Return CertifyId.

2021-04-09 Version: 1.0.1
- New API SDK.

2021-03-30 Version: 2.0.1
- Generated python 2019-03-07 for Cloudauth.

2020-12-30 Version: 2.0.0
- AMP Version Change.

2020-11-26 Version: 1.0.0
- ContrastFaceVerify Support Video.

