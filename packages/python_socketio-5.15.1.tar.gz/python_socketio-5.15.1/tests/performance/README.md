Performance
===========

This directory contains several scripts and tools to test the performance of
the project.
