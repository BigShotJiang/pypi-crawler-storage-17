#!/bin/bash
python text_packet.py
python binary_packet.py
python json_packet.py
python namespace_packet.py
python server_receive.py
python server_send.py
python server_send_broadcast.py
