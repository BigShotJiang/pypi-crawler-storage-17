NAME = "ID31"

DESCRIPTION = "ESRF ID31 beamline"

LONG_DESCRIPTION = "ESRF ID31 beamline"

ICON = "icons/category.png"

BACKGROUND = "light-blue"
