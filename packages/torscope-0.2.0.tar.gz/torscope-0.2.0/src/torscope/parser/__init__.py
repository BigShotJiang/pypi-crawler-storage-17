"""Parsing utilities for Tor documents."""
