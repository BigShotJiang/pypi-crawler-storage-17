__version__ = "0.1.0"
__author__ = "Cal Nightingale"
__credits__ = "Gradient Health"
