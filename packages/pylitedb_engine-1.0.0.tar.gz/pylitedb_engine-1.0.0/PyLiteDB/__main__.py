# Developer: Sreeraj
# GitHub: https://github.com/s-r-e-e-r-a-j

from PyLiteDB.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
