"""
	Common utilities used throughout the framework.
"""
