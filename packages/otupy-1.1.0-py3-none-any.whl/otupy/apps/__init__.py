"""
	Standalone applications based on otupy.

	This package provides a set of modules that uses the otupy core library to build
	OpenC2 Actuators and Controllers.

"""
#import otupy.apps.ctxd
#import otupy.apps.connector
