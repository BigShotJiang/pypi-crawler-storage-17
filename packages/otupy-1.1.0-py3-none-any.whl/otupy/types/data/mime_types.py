import mimetypes

mimetypes.add_type('application/openc2','oc2')
""" OpenC2 mime_type

	Adds a non-registered 'application/openc2' mime types to the local database.
"""
