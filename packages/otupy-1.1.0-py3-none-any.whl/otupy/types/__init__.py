"""
	Definition of OpenC2-compliant data types defined in the Language Specification.
"""
