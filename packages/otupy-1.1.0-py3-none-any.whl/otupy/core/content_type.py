
_OPENC2_CONTENT_TYPE = "openc2"
""" Content type to be exposed in messages """
