""" CTXD additional data types

	This modules defines additional data types specific for the CTXD profile.
"""

from otupy.profiles.ctxd.data import *


