
""" OpenC2 profiles

	This folder collects the implementation of profiles provided with otupy.
"""
import otupy.profiles.ctxd
import otupy.profiles.slpf
