..
    Copyright (C) 2015 CERN.
    Copyright (C) 2025 Ubiquity Press.

    Invenio-Collections is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.



Authors
=======

Invenio module for organizing metadata into collections.

- Esteban J. G. Gabancho <esteban.gabancho@gmail.com>
- Jiri Kuncar <jiri.kuncar@cern.ch>
- Leonardo Rossi <leonardo.r@cern.ch>
- Marco Neumann <marco@crepererum.net>
- Sami Hiltunen <sami.mikael.hiltunen@cern.ch>
- Tibor Simko <tibor.simko@cern.ch>
