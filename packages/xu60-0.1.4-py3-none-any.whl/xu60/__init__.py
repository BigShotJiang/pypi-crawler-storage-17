"""
xu60 - needed now more than ever
"""
from xu60.main import app
__version__="0.1.4"
__all__=["app"]
