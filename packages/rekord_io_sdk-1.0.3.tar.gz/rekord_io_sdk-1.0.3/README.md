# Rekord.io Python SDK

[![PyPI version](https://badge.fury.io/py/rekord-io-sdk.svg)](https://badge.fury.io/py/rekord-io-sdk)

Official Python SDK for [Rekord.io](https://rekord.io).

Rekord.io provides a trust layer for verifiable data, anchoring data on-chain to create immutable, audit-ready records for regulatory compliance and data integrity.

## Installation

Install via pip:

```bash
pip install rekord-io-sdk
```

## Configuration

The SDK uses `rekord_sdk.Configuration` to manage API credentials and endpoints.

### Authentication

Rekord.io uses **Auth0 OAuth2 Client Credentials Flow**. To use this SDK, you need to handle the OAuth2 token retrieval and inject it into the configuration.

**Prerequisites:**

- Rekord.io API Endpoint (e.g., `https://api-v2-dev.rekord.io`)
- Auth0 Access Token (Bearer token)

## Usage Example

### 1. Initialize Client

```python
import rekord_sdk
from rekord_sdk.rest import ApiException

# Configure the client
configuration = rekord_sdk.Configuration()
configuration.host = "https://api-v2-dev.rekord.io"

# Inject the Bearer token (you must obtain this from Auth0 separately)
access_token = "YOUR_ACCESS_TOKEN"

# Override auth settings to use the token
original_auth_settings = configuration.auth_settings

def auth_settings_with_token():
    settings = original_auth_settings()
    settings["bearerAuth"] = {
        "type": "bearer",
        "in": "header",
        "key": "Authorization",
        "value": f"Bearer {access_token}",
    }
    return settings

configuration.auth_settings = auth_settings_with_token

# Create API Client instances
api_client = rekord_sdk.ApiClient(configuration)
passport_api = rekord_sdk.PassportApi(api_client)
```

### 2. Create a Passport

A "Passport" is a container for your data artifacts. It is typically created once per day or per logical grouping.

```python
try:
    # Define an artifact (the data you want to anchor)
    artifact = {
        "json": {
            "event": "market_data",
            "symbol": "BTC/USD",
            "price": 65000.00,
            "timestamp": "2024-01-01T12:00:00Z"
        },
        "filename": "btc_price_20240101_1200.json",
        "mimeType": "application/json"
    }

    # Create passport with initial artifact
    body = {
        "passport_label": "market-data-btc-20240101",
        "artifacts": [artifact]
    }

    response = passport_api.passport_create_post(body=body)

    # Extract Passport ID
    passport_id = response.data.passport_id
    print(f"Passport Created: {passport_id}")

except ApiException as e:
    print(f"Error creating passport: {e}")
```

### 3. Append Artifacts to Existing Passport

You can append new data files (artifacts) to an existing passport. This updates the record on-chain.

```python
try:
    new_artifact = {
        "json": {
            "event": "market_data",
            "symbol": "BTC/USD",
            "price": 65100.00,
            "timestamp": "2024-01-01T13:00:00Z"
        },
        "filename": "btc_price_20240101_1300.json",
        "mimeType": "application/json"
    }

    body = {
        "new_artifacts": [new_artifact]
    }

    # Update passport using the ID obtained from creation
    response = passport_api.passport_passport_id_update_post(
        passport_id="YOUR_PASSPORT_ID",
        body=body
    )
    print("Passport Updated Successfully")

except ApiException as e:
    print(f"Error updating passport: {e}")
```

## Core Concepts

- **Passport**: A digital container that holds a collection of artifacts. Passports are anchored on-chain.
- **Artifact**: A specific piece of data (file, JSON, document) that is added to a passport.
- **Record**: The individual immutable entry created on the blockchain for each update.

## Requirements

- Python 3.4+
- `urllib3` >= 1.15
- `six` >= 1.10
- `certifi`
- `python-dateutil`

## License

MIT
