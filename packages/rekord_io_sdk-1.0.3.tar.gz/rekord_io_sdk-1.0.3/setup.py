# coding: utf-8

"""
Rekord.io Python SDK

Official Python SDK for Rekord.io
Rekord.io provides a trust layer for verifiable data, anchoring data on-chain
to create immutable, audit-ready records.
"""

from setuptools import setup, find_packages

NAME = "rekord-io-sdk"
VERSION = "1.0.3"
# To install the library, run the following
#
# python setup.py install
#
# prerequisite: setuptools
# http://pypi.python.org/pypi/setuptools

REQUIRES = ["urllib3 >= 1.15", "six >= 1.10", "certifi", "python-dateutil"]

# Read long description from README.md
from os import path

this_directory = path.abspath(path.dirname(__file__))
with open(path.join(this_directory, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name=NAME,
    version=VERSION,
    description="Rekord.io Python SDK",
    author="DABL Team",
    author_email="dev@dabl.app",
    url="https://github.com/dabl/rekord-sdk",
    keywords=["Rekord", "Rekord.io", "Blockchain", "Immutable Storage"],
    install_requires=REQUIRES,
    packages=find_packages(),
    include_package_data=True,
    long_description=long_description,
    long_description_content_type="text/markdown",
)
