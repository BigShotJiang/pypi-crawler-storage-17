import pyv

pyv.exec_pyv_file("test.pyv")
