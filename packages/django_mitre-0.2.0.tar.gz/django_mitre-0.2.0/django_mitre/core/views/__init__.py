# Import all application views by default
from .app import *
