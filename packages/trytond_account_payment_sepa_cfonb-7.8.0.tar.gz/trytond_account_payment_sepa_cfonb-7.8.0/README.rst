#################################
Account Payment SEPA CFONB Module
#################################

The *Account Payment SEPA CFONB Module* adds `CFONB
<https://www.cfonb.org/espace-documentaire/sepa>`_ flavors to SEPA messages.

.. toctree::
   :maxdepth: 2

   design
   releases
