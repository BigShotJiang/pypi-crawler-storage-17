"""The building blocks for making devices."""

from ._derived_signal import (
    DerivedSignalFactory,
    derived_signal_r,
    derived_signal_rw,
    derived_signal_w,
)
from ._derived_signal_backend import Transform, merge_gathered_dicts
from ._detector import (
    DetectorController,
    DetectorTrigger,
    DetectorWriter,
    StandardDetector,
    TriggerInfo,
)
from ._device import (
    Device,
    DeviceConnector,
    DeviceMock,
    DeviceVector,
    LazyMock,
    default_mock_class,
    init_devices,
)
from ._device_filler import DeviceFiller
from ._enums import (
    EnabledDisabled,
    EnableDisable,
    InOut,
    OnOff,
    YesNo,
)
from ._flyer import FlyerController, FlyMotorInfo, StandardFlyer
from ._hdf_dataset import HDFDatasetDescription, HDFDocumentComposer
from ._log import config_ophyd_async_logging
from ._mock_signal_backend import MockSignalBackend
from ._mock_signal_utils import (
    callback_on_mock_put,
    get_mock,
    get_mock_put,
    mock_puts_blocked,
    set_mock_put_proceeds,
    set_mock_value,
    set_mock_values,
)
from ._protocol import AsyncConfigurable, AsyncReadable, AsyncStageable, Watcher
from ._providers import (
    AutoIncrementFilenameProvider,
    AutoIncrementingPathProvider,
    AutoMaxIncrementingPathProvider,
    DatasetDescriber,
    FilenameProvider,
    PathInfo,
    PathProvider,
    StaticFilenameProvider,
    StaticPathProvider,
    UUIDFilenameProvider,
    YMDPathProvider,
)
from ._readable import (
    ConfigSignal,
    HintedSignal,
    StandardReadable,
    StandardReadableFormat,
)
from ._settings import Settings, SettingsProvider
from ._signal import (
    Ignore,
    Signal,
    SignalConnector,
    SignalR,
    SignalRW,
    SignalW,
    SignalX,
    observe_signals_value,
    observe_value,
    set_and_wait_for_other_value,
    set_and_wait_for_value,
    soft_signal_r_and_setter,
    soft_signal_rw,
    wait_for_value,
    walk_config_signals,
    walk_devices,
    walk_rw_signals,
    walk_signal_sources,
)
from ._signal_backend import (
    Array1D,
    DTypeScalar_co,
    Primitive,
    SignalBackend,
    SignalDatatype,
    SignalDatatypeT,
    SignalMetadata,
    make_datakey,
)
from ._soft_signal_backend import SoftSignalBackend
from ._status import AsyncStatus, WatchableAsyncStatus, completed_status
from ._table import Table, TableSubclass
from ._utils import (
    CALCULATE_TIMEOUT,
    DEFAULT_TIMEOUT,
    CalculatableTimeout,
    Callback,
    ConfinedModel,
    EnumTypes,
    NotConnectedError,
    Reference,
    StrictEnum,
    SubsetEnum,
    SupersetEnum,
    WatcherUpdate,
    error_if_none,
    gather_dict,
    get_dtype,
    get_enum_cls,
    get_unique,
    in_micros,
    wait_for_connection,
)
from ._yaml_settings import YamlSettingsProvider


# Back compat - delete before 1.0
def __getattr__(name):
    import warnings

    renames = {
        "NotConnected": NotConnectedError,
    }
    rename = renames.get(name)
    if rename is not None:
        warnings.warn(
            DeprecationWarning(
                f"{name!r} is deprecated, use {rename.__name__!r} instead"
            ),
            stacklevel=2,
        )
        return rename
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Device
    "Device",
    "DeviceConnector",
    "DeviceFiller",
    "DeviceVector",
    "init_devices",
    # Protocols
    "AsyncReadable",
    "AsyncConfigurable",
    "AsyncStageable",
    "Watcher",
    # Status
    "AsyncStatus",
    "WatchableAsyncStatus",
    "WatcherUpdate",
    "completed_status",
    # Signal
    "Signal",
    "SignalR",
    "SignalW",
    "SignalRW",
    "SignalX",
    "SignalBackend",
    "SignalConnector",
    # Signal Types
    "SignalDatatype",
    "SignalDatatypeT",
    "DTypeScalar_co",
    "Array1D",
    "StrictEnum",
    "SubsetEnum",
    "SupersetEnum",
    "EnumTypes",
    "Table",
    "SignalMetadata",
    "Primitive",
    # Soft signal
    "SoftSignalBackend",
    "soft_signal_r_and_setter",
    "soft_signal_rw",
    # Mock signal
    "DeviceMock",
    "LazyMock",
    "MockSignalBackend",
    "default_mock_class",
    # Mocking utilities
    "get_mock",
    "set_mock_value",
    "set_mock_values",
    "get_mock_put",
    "callback_on_mock_put",
    "mock_puts_blocked",
    "set_mock_put_proceeds",
    # Signal utilities
    "observe_value",
    "observe_signals_value",
    "wait_for_value",
    "set_and_wait_for_value",
    "set_and_wait_for_other_value",
    "walk_rw_signals",
    "walk_config_signals",
    "walk_devices",
    "walk_signal_sources",
    # Readable
    "StandardReadable",
    "StandardReadableFormat",
    # Detector
    "StandardDetector",
    "TriggerInfo",
    "DetectorTrigger",
    "DetectorController",
    "DetectorWriter",
    # Path
    "PathInfo",
    "PathProvider",
    "StaticPathProvider",
    "AutoIncrementingPathProvider",
    "YMDPathProvider",
    "FilenameProvider",
    "StaticFilenameProvider",
    "AutoIncrementFilenameProvider",
    "AutoMaxIncrementingPathProvider",
    "UUIDFilenameProvider",
    # Datatset
    "DatasetDescriber",
    "HDFDatasetDescription",
    "HDFDocumentComposer",
    # Flyer
    "StandardFlyer",
    "FlyMotorInfo",
    "FlyerController",
    # Settings
    "Settings",
    "SettingsProvider",
    "YamlSettingsProvider",
    # Utils
    "config_ophyd_async_logging",
    "CALCULATE_TIMEOUT",
    "CalculatableTimeout",
    "DEFAULT_TIMEOUT",
    "Callback",
    "ConfinedModel",
    "NotConnectedError",
    "Reference",
    "error_if_none",
    "gather_dict",
    "get_dtype",
    "get_enum_cls",
    "get_unique",
    "in_micros",
    "make_datakey",
    "wait_for_connection",
    "Ignore",
    # Derived signal
    "derived_signal_r",
    "derived_signal_rw",
    "derived_signal_w",
    "Transform",
    "DerivedSignalFactory",
    "merge_gathered_dicts",
    # Back compat - delete before 1.0
    "ConfigSignal",
    "HintedSignal",
    # Standard enums
    "EnabledDisabled",
    "EnableDisable",
    "InOut",
    "OnOff",
    "YesNo",
    "TableSubclass",
]
