# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .class_ import Class
from ..._models import BaseModel

__all__ = ["ClassListResponse"]


class ClassListResponse(BaseModel):
    data: List[Class]
    """The array of classes."""

    object_type: Literal["list"] = FieldInfo(alias="objectType")
    """The type of object. This value is always `"list"`."""

    url: str
    """The endpoint URL where this list can be accessed."""
