# Makes the tests directory a package so type checkers distinguish modules.
