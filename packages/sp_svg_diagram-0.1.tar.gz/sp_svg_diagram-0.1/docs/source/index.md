SVGDiagram
==========

```{toctree}
:maxdepth: 2
:caption: Contents

install

```

![](./_static/example_pentagon.svg)
