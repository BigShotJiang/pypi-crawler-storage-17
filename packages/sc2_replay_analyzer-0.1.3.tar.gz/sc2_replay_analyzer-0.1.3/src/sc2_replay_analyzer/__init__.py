"""SC2 Replay Analyzer - Track your StarCraft II progress."""

__version__ = "0.1.3"
