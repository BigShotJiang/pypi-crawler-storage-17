from __future__ import annotations

from logging import getLogger

LOGGER = getLogger("tag_commit")


__all__ = ["LOGGER"]
