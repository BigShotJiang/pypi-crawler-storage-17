"""MurmurAI API test suite."""
