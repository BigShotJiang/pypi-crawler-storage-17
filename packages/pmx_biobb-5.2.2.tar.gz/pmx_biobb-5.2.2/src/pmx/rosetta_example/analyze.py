import pmx
from pmx import rosetta_analyze
#from .model import Model

rosetta_analyze.FlexDDG_analyze( path='./rosetta_flex_ddg/mutations',mutFile='mut.dat',overwrite=False )


