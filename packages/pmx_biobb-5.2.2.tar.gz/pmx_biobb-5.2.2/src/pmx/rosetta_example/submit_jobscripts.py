import os
os.chdir('/home/energy/vgapsys/covid19/example_rosetta/mut_chE_341I')
os.system('qsub jobscript')
os.chdir('.')

os.chdir('/home/energy/vgapsys/covid19/example_rosetta/mut_chE_342L')
os.system('qsub jobscript')
os.chdir('.')

os.chdir('/home/energy/vgapsys/covid19/example_rosetta/mut_chE_354D')
os.system('qsub jobscript')
os.chdir('.')

os.chdir('/home/energy/vgapsys/covid19/example_rosetta/mut_chE_364Y')
os.system('qsub jobscript')
os.chdir('.')

os.chdir('/home/energy/vgapsys/covid19/example_rosetta/mut_chE_367F')
os.system('qsub jobscript')
os.chdir('.')

os.chdir('/home/energy/vgapsys/covid19/example_rosetta/mut_chE_408I')
os.system('qsub jobscript')
os.chdir('.')

os.chdir('/home/energy/vgapsys/covid19/example_rosetta/mut_chE_435S')
os.system('qsub jobscript')
os.chdir('.')

os.chdir('/home/energy/vgapsys/covid19/example_rosetta/mut_chE_436R')
os.system('qsub jobscript')
os.chdir('.')

os.chdir('/home/energy/vgapsys/covid19/example_rosetta/mut_chE_476S')
os.system('qsub jobscript')
os.chdir('.')

os.chdir('/home/energy/vgapsys/covid19/example_rosetta/mut_chE_483A')
os.system('qsub jobscript')
os.chdir('.')

os.chdir('/home/energy/vgapsys/covid19/example_rosetta/mut_chE_501Y')
os.system('qsub jobscript')
os.chdir('.')

