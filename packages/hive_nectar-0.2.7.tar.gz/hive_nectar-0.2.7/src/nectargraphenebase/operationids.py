#: Operation ids
from typing import Dict

operations: Dict[str, int] = {}
operations["demo_operation"] = 0
