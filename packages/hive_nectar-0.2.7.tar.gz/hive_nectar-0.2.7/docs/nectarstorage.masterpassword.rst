nectarstorage.masterpassword module
===================================

.. automodule:: nectarstorage.masterpassword
   :members:
   :show-inheritance:
   :undoc-members:
