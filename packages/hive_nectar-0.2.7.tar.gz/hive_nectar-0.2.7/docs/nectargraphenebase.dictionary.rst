nectargraphenebase.dictionary module
====================================

.. automodule:: nectargraphenebase.dictionary
   :members:
   :show-inheritance:
   :undoc-members:
