nectarapi.exceptions module
===========================

.. automodule:: nectarapi.exceptions
   :members:
   :show-inheritance:
   :undoc-members:
