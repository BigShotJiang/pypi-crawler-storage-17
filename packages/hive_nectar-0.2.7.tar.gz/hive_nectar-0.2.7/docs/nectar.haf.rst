nectar.haf module
=================

.. automodule:: nectar.haf
   :members:
   :show-inheritance:
   :undoc-members:
