# Linkedin

See [Platforms Overview](index.md) for API key format and setup instructions.

## Setup

```bash
crier config set linkedin.api_key YOUR_KEY
```

## Example

```bash
crier publish my-post.md --to linkedin
```

