Stock Product Location Module
#############################

The *Stock Product Location Module* adds a list of preferred locations by
warehouse and product.

.. toctree::
   :maxdepth: 2

   design
   releases
