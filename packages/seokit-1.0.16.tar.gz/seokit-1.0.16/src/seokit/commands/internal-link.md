Apply internal links to article: $ARGUMENTS

## Instructions

Insert internal links into the specified article based on keyword matching:

```bash
# Validate arguments
if [ -z "$ARGUMENTS" ]; then
    echo "ERROR: No article path provided"
    echo "Usage: /internal-link <article.md>"
    echo "Example: /internal-link ./my-keyword/article.md"
    exit 1
fi

# Validate file exists
if [ ! -f "$ARGUMENTS" ]; then
    echo "ERROR: File not found: $ARGUMENTS"
    echo ""
    echo "Make sure the file path is correct and the file exists."
    exit 1
fi

export SEOKIT_HOME="$HOME/.claude/seokit"

# Check if SEOKit is installed
if [ ! -d "$SEOKIT_HOME" ]; then
    echo "[SEOKIT_NOT_INSTALLED]"
    echo "Error: SEOKit directory not found"
    echo "  Expected: $SEOKIT_HOME"
    echo "  Suggestion: Run 'seokit setup' to install SEOKit first"
    exit 10
fi

# Check if venv exists
if [ ! -d "$SEOKIT_HOME/venv" ]; then
    echo "[VENV_NOT_FOUND]"
    echo "Error: Python virtual environment not found"
    echo "  Expected: $SEOKIT_HOME/venv"
    echo "  Suggestion: Run 'seokit setup' to create the virtual environment"
    exit 11
fi

# Check if script exists
if [ ! -f "$SEOKIT_HOME/scripts/internal-link-manager.py" ]; then
    echo "[SCRIPT_NOT_FOUND]"
    echo "Error: internal-link-manager.py not found"
    echo "  Expected: $SEOKIT_HOME/scripts/internal-link-manager.py"
    echo "  Suggestion: Run 'seokit update' to install latest scripts"
    exit 12
fi

# Activate venv and run apply
source "$SEOKIT_HOME/venv/bin/activate" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "[VENV_ACTIVATION_FAILED]"
    echo "Error: Failed to activate Python virtual environment"
    echo "  Path: $SEOKIT_HOME/venv/bin/activate"
    echo "  Suggestion: Delete and recreate venv with 'seokit setup --force'"
    exit 13
fi

python "$SEOKIT_HOME/scripts/internal-link-manager.py" apply "$ARGUMENTS"
EXIT_CODE=$?

# Handle exit codes with detailed messages
case $EXIT_CODE in
    0)
        echo ""
        echo "✓ Internal links applied successfully"
        ;;
    1)
        echo ""
        echo "──────────────────────────────────────"
        echo "USAGE ERROR"
        echo ""
        echo "Missing article path or links file not found."
        echo ""
        echo "Make sure:"
        echo "  1. You ran '/internal-link:sync <sitemap-url>' first"
        echo "  2. The article file exists"
        echo "──────────────────────────────────────"
        ;;
    3)
        echo ""
        echo "──────────────────────────────────────"
        echo "FILE ERROR"
        echo ""
        echo "Could not read or write the article file."
        echo ""
        echo "Common causes:"
        echo "  - Insufficient permissions"
        echo "  - File is locked by another process"
        echo "──────────────────────────────────────"
        ;;
    4)
        echo ""
        echo "──────────────────────────────────────"
        echo "UNEXPECTED ERROR"
        echo ""
        echo "An unexpected error occurred."
        echo "See traceback above for debugging info."
        echo "──────────────────────────────────────"
        ;;
    130)
        echo ""
        echo "Operation cancelled by user."
        ;;
esac

exit $EXIT_CODE
```

## Exit Codes Reference

| Code | Error Code | Meaning | Action |
|------|------------|---------|--------|
| 0 | - | Success | Links inserted into article |
| 1 | USAGE_ERROR | Missing path or links file | Run sync first, check file path |
| 3 | FILE_ERROR | File read/write failed | Check permissions |
| 4 | UNEXPECTED_ERROR | Unexpected error | Check traceback |
| 10 | SEOKIT_NOT_INSTALLED | SEOKit directory missing | Run `seokit setup` |
| 11 | VENV_NOT_FOUND | Python venv missing | Run `seokit setup` |
| 12 | SCRIPT_NOT_FOUND | Script missing | Run `seokit update` |
| 13 | VENV_ACTIVATION_FAILED | Venv activation failed | Run `seokit setup --force` |
| 130 | - | User cancelled (Ctrl+C) | Re-run when ready |

## How It Works

The script will:
1. Load URL-keyword mappings from `.seokit-links.yaml`
2. Calculate max links allowed (2 per 1000 words)
3. Find keyword matches in article content
4. Insert links following these rules:
   - Exact keyword matching (case-insensitive)
   - Skip headings (H1-H6)
   - Skip code blocks
   - Skip already-linked text
   - Maintain minimum 150 words between links
   - Prioritize sections: body > conclusion > faq > introduction
5. Save the updated article

## Prerequisites

1. Run `/internal-link:sync <sitemap-url>` to create the links file
2. Have an article file ready (.md format)

## Example

```bash
# First, sync your sitemap
/internal-link:sync https://example.com/sitemap.xml

# View available entries
/internal-link:list

# Apply links to your article
/internal-link ./my-keyword/article.md
```

## Expected Output

```
Article: 2500 words → max 5 links allowed

  ✓ Inserted: [keyword](https://example.com/page...)
    Section: body, Position: word 342

  ✓ Inserted: [another keyword](https://example.com/...)
    Section: body, Position: word 856

✓ Saved article with 2 new links

Apply complete: 2/5 links inserted
```
