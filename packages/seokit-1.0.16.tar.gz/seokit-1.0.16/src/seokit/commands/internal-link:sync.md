Sync internal links from sitemap: $ARGUMENTS

## Instructions

Run the internal link sync using the sitemap URL:

```bash
# Validate arguments
if [ -z "$ARGUMENTS" ]; then
    echo "ERROR: No sitemap URL provided"
    echo "Usage: /internal-link:sync <sitemap-url>"
    echo "Example: /internal-link:sync https://example.com/sitemap.xml"
    exit 1
fi

export SEOKIT_HOME="$HOME/.claude/seokit"

# Check if SEOKit is installed
if [ ! -d "$SEOKIT_HOME" ]; then
    echo "[SEOKIT_NOT_INSTALLED]"
    echo "Error: SEOKit directory not found"
    echo "  Expected: $SEOKIT_HOME"
    echo "  Suggestion: Run 'seokit setup' to install SEOKit first"
    exit 10
fi

# Check if venv exists
if [ ! -d "$SEOKIT_HOME/venv" ]; then
    echo "[VENV_NOT_FOUND]"
    echo "Error: Python virtual environment not found"
    echo "  Expected: $SEOKIT_HOME/venv"
    echo "  Suggestion: Run 'seokit setup' to create the virtual environment"
    exit 11
fi

# Check if script exists
if [ ! -f "$SEOKIT_HOME/scripts/internal-link-manager.py" ]; then
    echo "[SCRIPT_NOT_FOUND]"
    echo "Error: internal-link-manager.py not found"
    echo "  Expected: $SEOKIT_HOME/scripts/internal-link-manager.py"
    echo "  Suggestion: Run 'seokit update' to install latest scripts"
    exit 12
fi

# Activate venv and run the sync
source "$SEOKIT_HOME/venv/bin/activate" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "[VENV_ACTIVATION_FAILED]"
    echo "Error: Failed to activate Python virtual environment"
    echo "  Path: $SEOKIT_HOME/venv/bin/activate"
    echo "  Suggestion: Delete and recreate venv with 'seokit setup --force'"
    exit 13
fi

python "$SEOKIT_HOME/scripts/internal-link-manager.py" sync "$ARGUMENTS"
EXIT_CODE=$?

# Handle exit codes with detailed messages
case $EXIT_CODE in
    0)
        echo ""
        echo "✓ Sitemap sync completed successfully"
        echo "  Links saved to: .seokit-links.yaml"
        ;;
    1)
        echo ""
        echo "──────────────────────────────────────"
        echo "Usage error. Provide a valid sitemap URL."
        echo "──────────────────────────────────────"
        ;;
    2)
        echo ""
        echo "──────────────────────────────────────"
        echo "NETWORK ERROR"
        echo ""
        echo "Failed to fetch sitemap URL."
        echo ""
        echo "Common causes:"
        echo "  - Invalid URL format"
        echo "  - Network connectivity issues"
        echo "  - Website blocking requests"
        echo "  - Sitemap file not found (404)"
        echo "──────────────────────────────────────"
        ;;
    3)
        echo ""
        echo "──────────────────────────────────────"
        echo "FILE ERROR"
        echo ""
        echo "Could not save the links file."
        echo ""
        echo "Common causes:"
        echo "  - Insufficient permissions in current directory"
        echo "  - Disk is full"
        echo "──────────────────────────────────────"
        ;;
    4)
        echo ""
        echo "──────────────────────────────────────"
        echo "UNEXPECTED ERROR"
        echo ""
        echo "An unexpected error occurred."
        echo "See traceback above for debugging info."
        echo "──────────────────────────────────────"
        ;;
    130)
        echo ""
        echo "Operation cancelled by user."
        ;;
esac

exit $EXIT_CODE
```

## Exit Codes Reference

| Code | Error Code | Meaning | Action |
|------|------------|---------|--------|
| 0 | - | Success | Links saved to `.seokit-links.yaml` |
| 1 | USAGE_ERROR | Missing arguments | Provide sitemap URL |
| 2 | NETWORK_ERROR | HTTP request failed | Check URL and connectivity |
| 3 | FILE_ERROR | File write failed | Check directory permissions |
| 4 | UNEXPECTED_ERROR | Unexpected error | Check traceback |
| 10 | SEOKIT_NOT_INSTALLED | SEOKit directory missing | Run `seokit setup` |
| 11 | VENV_NOT_FOUND | Python venv missing | Run `seokit setup` |
| 12 | SCRIPT_NOT_FOUND | Script missing | Run `seokit update` |
| 13 | VENV_ACTIVATION_FAILED | Venv activation failed | Run `seokit setup --force` |
| 130 | - | User cancelled (Ctrl+C) | Re-run when ready |

## Expected Output

The script will:
1. Fetch the sitemap.xml from the provided URL
2. Extract all page URLs (max 500)
3. Fetch each page to extract the title
4. Extract keywords from titles
5. Save URL-keyword mappings to `.seokit-links.yaml`

## Next Steps

After syncing, use:
- `/internal-link:list` to view all entries
- `/internal-link <article.md>` to apply links to an article
