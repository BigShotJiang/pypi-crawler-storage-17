List all internal link entries.

## Instructions

Display all saved URL-keyword mappings:

```bash
export SEOKIT_HOME="$HOME/.claude/seokit"

# Check if SEOKit is installed
if [ ! -d "$SEOKIT_HOME" ]; then
    echo "[SEOKIT_NOT_INSTALLED]"
    echo "Error: SEOKit directory not found"
    echo "  Expected: $SEOKIT_HOME"
    echo "  Suggestion: Run 'seokit setup' to install SEOKit first"
    exit 10
fi

# Check if venv exists
if [ ! -d "$SEOKIT_HOME/venv" ]; then
    echo "[VENV_NOT_FOUND]"
    echo "Error: Python virtual environment not found"
    echo "  Expected: $SEOKIT_HOME/venv"
    echo "  Suggestion: Run 'seokit setup' to create the virtual environment"
    exit 11
fi

# Check if script exists
if [ ! -f "$SEOKIT_HOME/scripts/internal-link-manager.py" ]; then
    echo "[SCRIPT_NOT_FOUND]"
    echo "Error: internal-link-manager.py not found"
    echo "  Expected: $SEOKIT_HOME/scripts/internal-link-manager.py"
    echo "  Suggestion: Run 'seokit update' to install latest scripts"
    exit 12
fi

# Activate venv and run list
source "$SEOKIT_HOME/venv/bin/activate" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "[VENV_ACTIVATION_FAILED]"
    echo "Error: Failed to activate Python virtual environment"
    echo "  Path: $SEOKIT_HOME/venv/bin/activate"
    echo "  Suggestion: Delete and recreate venv with 'seokit setup --force'"
    exit 13
fi

python "$SEOKIT_HOME/scripts/internal-link-manager.py" list
EXIT_CODE=$?

# Handle exit codes
case $EXIT_CODE in
    0)
        echo ""
        echo "✓ List completed"
        ;;
    1)
        echo ""
        echo "──────────────────────────────────────"
        echo "NO LINKS FILE"
        echo ""
        echo "The .seokit-links.yaml file was not found."
        echo ""
        echo "Run '/internal-link:sync <sitemap-url>' first to"
        echo "create the links file from your sitemap."
        echo "──────────────────────────────────────"
        ;;
    4)
        echo ""
        echo "──────────────────────────────────────"
        echo "UNEXPECTED ERROR"
        echo ""
        echo "An unexpected error occurred."
        echo "See traceback above for debugging info."
        echo "──────────────────────────────────────"
        ;;
    130)
        echo ""
        echo "Operation cancelled by user."
        ;;
esac

exit $EXIT_CODE
```

## Exit Codes Reference

| Code | Error Code | Meaning | Action |
|------|------------|---------|--------|
| 0 | - | Success | Entries displayed |
| 1 | NO_LINKS_FILE | `.seokit-links.yaml` not found | Run `/internal-link:sync` first |
| 4 | UNEXPECTED_ERROR | Unexpected error | Check traceback |
| 10 | SEOKIT_NOT_INSTALLED | SEOKit directory missing | Run `seokit setup` |
| 11 | VENV_NOT_FOUND | Python venv missing | Run `seokit setup` |
| 12 | SCRIPT_NOT_FOUND | Script missing | Run `seokit update` |
| 13 | VENV_ACTIVATION_FAILED | Venv activation failed | Run `seokit setup --force` |
| 130 | - | User cancelled (Ctrl+C) | Re-run when ready |

## Expected Output

Displays a numbered list of all URL-keyword entries:

```
Found N entries:

--------------------------------------------------------------------------------
1. keyword-name
   URL: https://example.com/page-url
   Title: Page Title...

2. another-keyword
   URL: https://example.com/another-page
   Title: Another Page Title...
--------------------------------------------------------------------------------
Total: N entries
```

## Prerequisites

Run `/internal-link:sync <sitemap-url>` first to create the links file.

## Next Steps

After viewing entries, use `/internal-link <article.md>` to apply links to an article.
