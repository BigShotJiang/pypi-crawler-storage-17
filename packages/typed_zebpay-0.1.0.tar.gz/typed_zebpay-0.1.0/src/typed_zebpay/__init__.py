"""
### Typed Zebpay
> A fully typed, validated async client for the Zebpay API

- Details
"""