# Typed Zebpay

> A fully typed, validated async client for the Zebpay API

Use *autocomplete* instead of documentation.

🚧 Under construction.