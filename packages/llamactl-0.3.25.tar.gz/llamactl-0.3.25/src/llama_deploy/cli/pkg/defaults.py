DEFAULT_DOCKER_IGNORE = """
.venv/
.git/
__pycache__/
*.py[oc]
build/
dist/
wheels/
*.egg-info
.env
"""
