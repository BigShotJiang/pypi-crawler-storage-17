"""SQL migrations for llamactl configuration database.

Files are applied in lexicographic order and must start with:

    PRAGMA user_version=N;

"""
