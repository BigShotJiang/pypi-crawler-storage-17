"""Spark comparisons."""
