"""
Invar: AI-native software engineering framework.

Trade structure for safety. The goal is not to make AI simpler,
but to make AI output more reliable.
"""

__version__ = "0.2.0"
