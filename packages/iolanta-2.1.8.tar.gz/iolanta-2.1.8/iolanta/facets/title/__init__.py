from iolanta.facets.title.facets import TitleFacet

__all__ = ['TitleFacet']
