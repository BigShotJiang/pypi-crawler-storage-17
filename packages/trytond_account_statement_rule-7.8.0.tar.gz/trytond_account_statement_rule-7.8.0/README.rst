#############################
Account Statement Rule Module
#############################

The *Account Statement Rule Module* allows rules to be defined to complete
statement lines from imported files.

.. toctree::
   :maxdepth: 2

   design
   releases
