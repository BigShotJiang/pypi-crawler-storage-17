## 16.0.1.0.0 (2023-05-25)

> - Migration to version 16.0 .
> - Included dependency from module base_view_inheritance_extension from
>   repository <https://https://github.com/OCA/server-tools> .

## 15.0.1.0.0 (2023-04-28)

> - Migration to version 15.0 .

## 14.0.1.0.0 (2021-11-12)

> - Migration to version 14.0 .

## 13.0.3.1.0 (2021-10-05)

> - Migration to version 13.0 .

## 12.0.2.0.0 (2019-12-19)

> - Included dependency from module stock_picking_invoice_link from
>   repository <https://github.com/OCA/stock-logistics-workflow.git>.

## 12.0.1.0.0 (2019-07-16)

> - Migration to version 12.0 .
