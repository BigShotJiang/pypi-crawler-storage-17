This module allows to create invoices directly from picking, without
having to use sale or purchase orders.
