python3 -m build

pip install -e .

