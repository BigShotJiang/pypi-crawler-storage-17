"""
This module provides functions for visualizing detector data,
including scatter plots and beam visualizations.
"""
from typing import Sequence
import pandas as pd
import numpy as np
import matplotlib as mpl
from ..main.functions import gaussian
from ..main.gaussian_fit import fit_gaussian
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
from matplotlib.lines import Line2D

mpl.rcParams.update(
    {
        "font.family": "serif",
        "mathtext.fontset": "cm",
    }
)

mpl.rcParams.update(
    {
        "font.size": 11,
        "axes.titlesize": 14,
        "axes.labelsize": 12,
        "legend.fontsize": 11,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
    }
)


def plot_all_extended_peaks(
    image: np.ndarray,
    xs: Sequence[float] | np.ndarray,
    ys: Sequence[float] | np.ndarray,
    layer: int,
) -> None:
    """
    Plots the full layer image with all detected extended peaks overlaid.

    The peaks are drawn as "x" markers on top of the 2D image, with a legend and
    a colorbar representing pixel intensity (energy).

    Args:
        image (np.ndarray): 2D image array for the detector layer.
        xs (Sequence[float] or np.ndarray): X coordinates (pixel indices) of peaks.
        ys (Sequence[float] or np.ndarray): Y coordinates (pixel indices) of peaks.
        layer (int): Layer index associated with the plot.

    Returns:
        None
    """
    fig, ax = plt.subplots()

    cmap = mpl.colormaps["viridis"]
    cmap.set_under("w")
    im = ax.imshow(image, origin="lower", cmap=cmap)

    ax.scatter(
        xs,
        ys,
        marker="x",
        s=80,
        c="red",
        linewidths=0.5,
    )

    peak_handle = Line2D(
        [],
        [],
        marker="x",
        linestyle="None",
        color="red",
        markersize=8,
        label="Extended peak",
    )

    ax.legend(
        handles=[peak_handle],
        loc="upper right",
        frameon=True,
        framealpha=0.9,
    )

    ax.set_title(rf"{len(xs)} extended peak(s) in layer indexed {layer}")
    ax.set_xlabel(r"idx")
    ax.set_ylabel(r"idy")

    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label(r"Energy")

    fig.tight_layout()
    plt.show()


def plot_focus_extended_peak(
    sub: np.ndarray,
    sigma_x: float,
    sigma_y: float,
    rho: float = 0.0,
    sigma_level: float = 3,
    focus_size: int = 20,
) -> None:
    """
    Plots a zoomed-in patch around an extended peak with a sigma ellipse overlay
    in terms of x-y pixel numbers.

    The patch is displayed with `imshow`, the peak center is marked with an "x",
    and a k-sigma ellipse (default 3σ) is drawn using the provided sigma values.

    Note:
        `Ellipse(width=..., height=...)` expects full axis lengths, so the ellipse
        uses width = 2 * k * sigma_x and height = 2 * k * sigma_y.

    Args:
        sub (np.ndarray): 2D image patch (zoom) around a peak.
        sigma_x (float): Standard deviation along x in pixel units (for the patch).
        sigma_y (float): Standard deviation along y in pixel units (for the patch).
        sigma_level (float): Sigma contour level to draw (e.g., 3 for 3σ).
            Defaults to 3.
        focus_size (int): Patch size used for the zoom title (in pixels).
            Defaults to 20.

    Returns:
        None
    """
    x0 = sub.shape[0] // 2
    y0 = sub.shape[1] // 2

    # covariance matrix
    cov = np.array(
        [
            [sigma_x**2, rho * sigma_x * sigma_y],
            [rho * sigma_x * sigma_y, sigma_y**2],
        ]
    )

    # eigen decomposition
    eigvals, eigvecs = np.linalg.eigh(cov)

    # sort eigenvalues (largest first)
    order = eigvals.argsort()[::-1]
    eigvals = eigvals[order]
    eigvecs = eigvecs[:, order]

    # ellipse parameters
    width = 2 * sigma_level * np.sqrt(eigvals[0])
    height = 2 * sigma_level * np.sqrt(eigvals[1])

    angle = np.degrees(np.arctan2(eigvecs[1, 0], eigvecs[0, 0]))

    # Plots
    fig, ax = plt.subplots()

    cmap = mpl.colormaps["viridis"]
    cmap.set_under("w")

    im = ax.imshow(sub, origin="lower", cmap=cmap)

    ellipse = Ellipse(
        xy=(x0, y0),
        width=width,
        height=height,
        angle=angle,
        fill=False,
        edgecolor="white",
        linewidth=1.5,
        clip_on=True,  # <-- Ensure it's clipped to axes
    )

    ax.add_patch(ellipse)
    ellipse.set_clip_path(ax.patch)  # <-- Explicitly clip to axes

    ax.scatter(
        x0,
        y0,
        marker="x",
        c="black",
        s=80,
        linewidths=1.2,
    )

    # ---- legend handles ----
    peak_handle = Line2D(
        [],
        [],
        marker="x",
        linestyle="None",
        color="black",
        markersize=8,
        label="Peak center",
    )

    ax.legend(
        handles=[peak_handle],
        loc="upper right",
        frameon=True,
        framealpha=0.9,
    )

    ax.set_title(rf"{focus_size}×{focus_size} zoom with {sigma_level}$\sigma$ contour")
    ax.set_xlabel(r"idx")
    ax.set_ylabel(r"idy")

    # Also ensure proper axes limits
    ax.set_xlim(-0.5, focus_size - 0.5)
    ax.set_ylim(-0.5, focus_size - 0.5)

    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label(r"Energy")

    fig.tight_layout()
    plt.show()


def scatter_plot(df: pd.DataFrame, layer: int) -> None:
    """
    Create a scatter plot of hit positions for a given detector layer,
    with energy represented as color.

    Args:
        df (pd.DataFrame): DataFrame containing the event data.
        layer (int): Detector layer to visualise (0–6).

    Returns:
        None
    """

    # Validate input layer
    if layer < 0 or layer > 6:
        raise ValueError("Layer must be between 0 and 6.")

    layer_df = df[df["layer"] == layer]

    cmap = mpl.colormaps["viridis"]
    cmap.set_under("w")

    plt.figure()
    plt.scatter(layer_df["idx"], layer_df["idy"], c=layer_df["E"], cmap=cmap, s=20)
    plt.colorbar(label="Energy")
    plt.xlabel("idx")
    plt.ylabel("idy")
    plt.show()


def plot_hist_with_fit(layer_pixels: np.ndarray, bins: int = 30) -> None:
    """
    Plot the histogram of layer pixels with fitted Gaussian.

    Args:
        layer_pixels (np.ndarray): An array of energy values for a layer.
        bins (int, optional): The number of bins for the histogram.
                              Defaults to 30.
    """
    amplitude_fit, sigma_fit, mu, bin_centers, hist = fit_gaussian(
        layer_pixels, bins=bins
    )

    plt.figure()
    plt.bar(
        bin_centers,
        hist,
        width=bin_centers[1] - bin_centers[0],
        alpha=0.6,
        label="Histogram",
    )
    plt.plot(
        bin_centers,
        gaussian(bin_centers, amplitude_fit, sigma_fit, mu),
        "r-",
        label=f"Fit: sigma={sigma_fit:.3f}",
    )
    plt.xlabel("Energy")
    plt.ylabel("Counts")
    plt.title("Layer noise fit")
    plt.legend()
    plt.show()
