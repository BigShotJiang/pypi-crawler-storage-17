"""
This module defines the DetectorCalibration class, which is used to process and
analyze detector data. It includes methods for finding peaks, fitting Gaussian
distributions, and calculating luminosity for different layers of the detector.
"""
import logging
import os
import numpy as np
import pandas as pd
import npac_calibration.plots.plot as npt
from npac_calibration.main.gaussian_fit import (
    fit_gaussian,
    fit_gaussian_2d,
    fit_corr_gaussian_2d,
)
from npac_calibration.main.functions import threshold
from npac_calibration.main.peaks import (
    find_peaks_and_bunches,
    integrated_luminosity_for_peak,
)
from .utils import df_to_matrix, extracted_image, convert_to_mm
from typing import List, Dict, Any, Optional


class DetectorCalibration:
    """
    A class to handle the calibration of the detector by processing data from
    different layers.
    """

    def __init__(self, outdir: str = "beam_results") -> None:
        """
        Initializes the DetectorCalibration object.

        Args:
            outdir (str): The directory where the output results will be saved.
        """
        self.outdir = outdir
        self._reset_all()

    def _reset_all(self) -> None:
        """
        Resets all attributes of the class to their initial states. This is useful
        when starting a new calibration process.
        """
        self._reset_peaks()
        self.all_layers_results: Dict[
            int, Dict[str, Any]
        ] = {}  # Store results for all layers
        self.combined_df: Optional[
            pd.DataFrame
        ] = None  # Combined DataFrame for all layers

    def _reset_peaks(self) -> None:
        """
        Resets the peak-related attributes for the current layer. This is called
        before processing a new layer.
        """
        self.x_peak: Optional[np.ndarray] = None
        self.y_peak: Optional[np.ndarray] = None
        self.x_bunch: Optional[np.ndarray] = None
        self.y_bunch: Optional[np.ndarray] = None
        self.luminosity: Optional[np.ndarray] = None
        self.sigma_noise: Optional[float] = None
        self.threshold: Optional[float] = None
        self.image: Optional[np.ndarray] = None
        self.layer: Optional[int] = None

    def get_peaks_info(self, layer: Optional[int] = None) -> Dict[str, Any]:
        """
        Returns a dictionary containing information about the peaks for a specified
        layer.
        This method must only be called if `run_layer()` or `run_all_layers()` have
        already been run.

        Args:
            layer (int, optional): The layer for which to retrieve peak information.
                                   If None, returns info for the current layer.

        Returns:
            dict: A dictionary with peak information.

        Raises:
            RuntimeError: If no calibration has been run yet.
            RuntimeError: If the requested layer has not been processed.
        """
        # Case 1: nothing has been run at all
        if not self.all_layers_results and self.layer is None:
            raise RuntimeError(
                "No calibration results available. "
                "Run run_layer() or run_all_layers() first."
            )

        # Case 2: layer explicitly requested
        if layer is not None:
            if layer not in self.all_layers_results:
                raise RuntimeError(
                    f"Layer {layer} has not been processed yet. "
                    "Run run_layer(df, layer) or include it in run_all_layers()."
                )
            return self.all_layers_results[layer].get("peaks_info", {})

        # Case 3: layer=None → use current layer
        if self.layer is None:
            raise RuntimeError(
                "No current layer is set. "
                "Run run_layer(df, layer) first or specify layer explicitly."
            )

        return {
            "x_peak": self.x_peak,
            "y_peak": self.y_peak,
            "x_extended_peak": self.x_bunch,
            "y_extended_peak": self.y_bunch,
            "luminosity": self.luminosity,
            "sigma_noise": self.sigma_noise,
            "threshold": self.threshold,
            "layer": self.layer,
        }

    def get_layer_image(self, layer: Optional[int] = None) -> np.ndarray:
        """
        Returns the detector image for a specified layer.

        Args:
            layer (int, optional): The layer to retrieve the image for.
                                If None, uses the current layer.

        Returns:
            np.ndarray: The 2D image array for the requested layer.

        Raises:
            RuntimeError: If the requested layer has not been processed yet.
        """
        if layer is None:
            if self.layer is None:
                raise RuntimeError(
                    "No layer index specified and no previous layer was processed."
                )
            layer = self.layer

        if layer not in self.all_layers_results:
            raise RuntimeError(
                f"Layer {layer} has not been processed yet. "
                "Run run_layer(df, layer) or run_all_layers() first."
            )

        return self.all_layers_results[layer]["image"]

    @staticmethod
    def _set_filename(layers: List[int], df: pd.DataFrame) -> str:
        """
        Generates a CSV filename based on the processed detector layers.

        If all unique layers present in the input DataFrame are processed, the
        filename reflects this by using the prefix "all_layers". Otherwise, the
        filename encodes the specific layer indices that were processed.

        Examples:
            - all_layers_extended_peaks.csv
            - layer_1_extended_peaks.csv
            - layer_1_2_3_extended_peaks.csv

        Args:
            layers (list[int]): List of layer indices that were processed.
            df (pd.DataFrame): Input event data containing a "layer" column.

        Returns:
            str: A descriptive filename for saving the combined calibration results.
        """
        unique_all = sorted(df["layer"].unique())
        layers_sorted = sorted(layers)

        if layers_sorted == unique_all:
            return "all_layers_extended_peaks.csv"

        layers_str = "_".join(str(i) for i in layers_sorted)
        return f"layer_{layers_str}_extended_peaks.csv"

    def _save_to_csv(
        self,
        results: List[Dict[str, Any]],
        filename: str,
        sort_by_luminosity: bool = True,
    ) -> str:
        """
        Saves the given results to a CSV file.

        Args:
            results (list of dict): The data to be saved.
            filename (str): The name of the output CSV file.
            sort_by_luminosity (bool): If True, sorts the results by luminosity
                                     in descending order.

        Returns:
            str: The path to the saved CSV file.
        """
        # Create output directory if it doesn't exist
        os.makedirs(self.outdir, exist_ok=True)

        # Convert results to DataFrame
        df = pd.DataFrame(results)

        # Sort by luminosity if requested
        if sort_by_luminosity and "luminosity" in df.columns:
            df = df.sort_values("luminosity", ascending=False)

        filepath = os.path.join(self.outdir, filename)

        # Save to CSV
        df.to_csv(filepath, index=False)
        logging.info(f"Results saved to: {filepath}")

        return filepath

    def _process_layer(
        self, df: pd.DataFrame, layer: int, fit_model: str = "gaussian"
    ) -> List[Dict[str, Any]]:
        """
        Processes the data for a single detector layer.

        Args:
            df (pd.DataFrame): The input DataFrame containing detector data.
            layer (int): The layer number to process.
            fit_model (str): The model to use for fitting the peaks. Can be
                             'gaussian' or 'corr_gaussian'.

        Returns:
            list: A list of dictionaries, where each dictionary contains the
                  calibration results for a detected bunch.
        """
        # Reset peaks for current layer
        self._reset_peaks()
        self.layer = layer

        # Select layer data
        layer_df = df[df["layer"] == layer]

        # Noise fit + threshold
        _, sigma_noise, mu_noise, _, _ = fit_gaussian(layer_df["E"].values)
        thres = threshold(mu_noise, sigma_noise, n=3)

        # Store noise info
        self.sigma_noise = float(sigma_noise)
        self.threshold = float(thres)

        # Convert df -> image
        image = df_to_matrix(layer_df)
        self.image = image

        # Find all bunch peaks
        x_peak, y_peak, x_bunch, y_bunch = find_peaks_and_bunches(image, thres)

        # Store peaks as numpy arrays
        self.x_peak = np.asarray(x_peak)
        self.y_peak = np.asarray(y_peak)
        self.x_bunch = np.asarray(x_bunch)
        self.y_bunch = np.asarray(y_bunch)

        if len(x_bunch) == 0:
            logging.warning(f"Warning: No peaks found in layer {layer}")
            return []

        results = []
        L_values = []

        # Process all bunches
        for x0, y0 in zip(x_bunch, y_bunch):
            # extract 20x20 patch
            sub = extracted_image(image, int(x0), int(y0))

            # fit 2D Gaussian
            if fit_model == "gaussian":
                popt, _ = fit_gaussian_2d(sub)
                _, sigma_x, mu_x, sigma_y, mu_y = popt
                rho = 0.0  # no correlation

            elif fit_model == "corr_gaussian":
                popt, _ = fit_corr_gaussian_2d(sub)
                _, mu_x, mu_y, sigma_x, sigma_y, rho = popt

            else:
                raise ValueError(f"Unknown fit_model: {fit_model}")

            # convert local → global pixel coordinates
            mu_x_det = y0 + mu_y - 10
            mu_y_det = x0 + mu_x - 10

            coords_mm, sigma_mm = convert_to_mm(
                (mu_x_det, mu_y_det),
                (sigma_x, sigma_y),
                pixel_size=2,
                min_position_mm=-400,
            )

            # Calculate luminosity
            L = integrated_luminosity_for_peak(image, int(x0), int(y0))
            L_values.append(float(L))

            # store result
            result = {
                "layer": layer,
                "mu_x": float(coords_mm[0]),
                "mu_y": float(coords_mm[1]),
                "sigma_x": float(sigma_mm[0]),
                "sigma_y": float(sigma_mm[1]),
                "pixel_x": int(x0),
                "pixel_y": int(y0),
                "luminosity": float(L),
            }
            if fit_model == "corr_gaussian":
                result["rho"] = float(rho)

            results.append(result)

        # Store luminosities
        self.luminosity = np.asarray(L_values)

        # Sort results by luminosity
        if results:
            # Create a DataFrame to sort easily
            results_df = pd.DataFrame(results)
            results_df = results_df.sort_values("luminosity", ascending=False)
            results = results_df.to_dict("records")

        # Store peaks info for this layer
        self.all_layers_results[layer] = {
            "results": results,
            "peaks_info": self.get_peaks_info(),
            "image": image,
        }

        return results

    def run_layer(
        self,
        df: pd.DataFrame,
        layer: int,
        save_csv: bool = False,
        fit_model: str = "gaussian",
    ) -> List[Dict[str, Any]]:
        """
        Runs the calibration process for a single specified layer.

        Args:
            df (pd.DataFrame): The input DataFrame.
            layer (int): The layer index number to process (e.g. 0 for first layer).
            save_csv (bool): If True, saves the results to a CSV file.
            fit_model (str): The model to use for fitting the peaks. Can be
                             'gaussian' or 'corr_gaussian'.

        Returns:
            list: A list of calibration results for the layer.
        """
        results = self._process_layer(df, layer, fit_model=fit_model)

        if not results:
            return []

        # Save to CSV if requested
        if save_csv:
            filename = self._set_filename([layer], df)
            self._save_to_csv(
                results, filename, sort_by_luminosity=False
            )  # Already sorted

        # Return results (already sorted by luminosity)
        return results

    def run_all_layers(
        self,
        df: pd.DataFrame,
        layers: Optional[List[int]] = None,
        save_csv: bool = True,
        fit_model: str = "gaussian",
    ) -> Dict[int, List[Dict[str, Any]]]:
        """
        Run calibration for all layers.

        Args:
            df (pd.DataFrame): Input data.
            layers (list, optional): List of layers to process. If None, all
                                     unique layers in df will be processed.
            save_csv (bool): If True, saves CSV files for each layer and a
                             combined file for all layers.
            fit_model (str): The model to use for fitting the peaks. Can be
                             'gaussian' or 'corr_gaussian'.

        Returns:
            dict: A dictionary with results for each layer.
        """
        # Reset all data
        self._reset_all()

        # Determine which layers to process
        if layers is None:
            layers = sorted(df["layer"].unique())

        all_results: Dict[int, List[Dict[str, Any]]] = {}
        all_combined_results: List[Dict[str, Any]] = []

        logging.info(f"Processing {len(layers)} layers: {layers}")

        for layer in layers:
            logging.info(f"\nProcessing layer {layer}...")

            try:
                results = self._process_layer(df, layer, fit_model=fit_model)

                if not results:
                    logging.warning(f"  No peaks found in layer {layer}")
                    all_results[layer] = []
                    continue

                # Store results
                all_results[layer] = results
                all_combined_results.extend(results)

                logging.info(f"  Found {len(results)} extended peaks")

            except Exception as e:
                logging.error(f"  Error processing layer {layer}: {e}")
                all_results[layer] = []

        # Save combined CSV if requested and we have results
        if save_csv and all_combined_results:
            combined_df = pd.DataFrame(all_combined_results)
            self.combined_df = combined_df

            os.makedirs(self.outdir, exist_ok=True)

            filename = self._set_filename(layers, df)
            filepath = os.path.join(self.outdir, filename)
            combined_df.to_csv(filepath, index=False)
            logging.info(f"\nCombined results saved to: {filepath}")
            logging.info(f"Total extended peaks across all layers: {len(combined_df)}")

        return all_results

    def _ensure_layer_processed(
        self,
        layer: int,
        df: Optional[pd.DataFrame] = None,
        fit_model: str = "gaussian",
    ) -> None:
        """
        Ensures the specified layer has been processed.

        Args:
            layer (int): Layer index to check/process.
            df (pd.DataFrame, optional): Event data. Required if the layer has not
                been processed yet.
            fit_model (str): The model to use for fitting the peaks. Can be
                             'gaussian' or 'corr_gaussian'.
        Raises:
            RuntimeError: If the layer has not been processed and df is None.
        """
        already = (
            layer in self.all_layers_results
            and self.all_layers_results[layer].get("results") is not None
        )
        if already:
            return

        if df is None:
            raise RuntimeError(
                f"Layer indexed {layer} is not processed yet. "
                f"Call run_layer(df, {layer}) first or pass df to "
                f"visualize_extended_peak(df=...)."
            )

        # process without saving csv
        self._process_layer(df, layer, fit_model=fit_model)

    def visualize_extended_peak(
        self,
        df: Optional[pd.DataFrame] = None,
        layer: Optional[int] = None,
        mode: str = "all",
        peak_number: Optional[int] = None,
        focus_size: int = 20,
        fit_model: str = "gaussian",
    ) -> None:
        """
        Visualizes extended peaks for a given layer.

        This method is typically called after running `run_layer()` or
        `run_all_layers()`. In that case, `df` is optional because the image and
        results can be retrieved from cached calibration outputs.

        If the requested layer has not been processed yet, you must provide `df`
        (event data), or run the calibration methods first.

        Args:
            df (pd.DataFrame, optional): Event data. Required only if the requested
                layer has not been processed yet.
            layer (int, optional): Layer index to visualize (0–6). If None, the last
                processed layer (`self.layer`) is used.
            mode (str): Visualization mode:
                - "all": plot the full layer image with all extended peaks.
                - "focus": zoom around one extended peak (requires `peak_number`).
            peak_number (int, optional): Extended peak number to focus on.
                `peak_number=1` means the first peak in the produced dataset.
                Required when `mode`="focus".
            focus_size (int): Patch size (in pixels) for the zoom view in focus mode.
            fit_model (str): The model to use for fitting the peaks. Can be
                             'gaussian' or 'corr_gaussian'.

        Raises:
            ValueError: If mode is not "all" or "focus".
            TypeError: If `layer` is not an integer when provided, or if
                `peak_number` is not an integer in focus mode.
            ValueError: If `layer` is outside the valid range [0, 6].
            RuntimeError: If results/image are not available and `df` is not provided.
            IndexError: If `peak_number` is out of range for the available peaks.
        """
        mode = mode.lower().strip()
        if mode not in {"all", "focus"}:
            raise ValueError('mode must be "all" or "focus"')

        if layer is None:
            if self.layer is None:
                raise RuntimeError(
                    "No layer index specified and no previous layer was processed. "
                    "Run run_layer(layer=...) or provide layer index explicitly."
                )
            layer = self.layer

        if not isinstance(layer, int):
            raise TypeError("layer must be an integer")

        if layer < 0 or layer > 6:
            raise ValueError("layer must be between 0 and 6")

        # Ensure we have results for that layer
        self._ensure_layer_processed(layer, df=df, fit_model=fit_model)

        layer_pack = self.all_layers_results[layer]
        image = layer_pack.get("image", None)

        if image is None:
            if df is None:
                raise RuntimeError(
                    "Image for this layer index is not stored. "
                    "Either pass df=... to visualize_extended_peak() or "
                    "store images per layer."
                )
            layer_df = df[df["layer"] == layer]
            image = df_to_matrix(layer_df)

        results = self.all_layers_results[layer].get("results", [])
        if not results:
            raise RuntimeError(
                f"No extended peak results stored for layer indexed {layer}."
            )

        # extended peak pixel coords are in results dicts
        xs = [r["pixel_x"] for r in results]
        ys = [r["pixel_y"] for r in results]
        sig_x = [r["sigma_x"] for r in results]
        sig_y = [r["sigma_y"] for r in results]
        rhos = [r.get("rho", 0.0) for r in results]

        if mode == "all":
            npt.plot_all_extended_peaks(image, xs, ys, layer)
            return

        # mode == "focus"
        if peak_number is None:
            raise ValueError('For mode="focus", you must provide peak_number.')

        if not isinstance(peak_number, int):
            raise TypeError("peak_number must be an integer.")

        if peak_number < 1 or peak_number > len(results):
            raise IndexError(
                f"peak_number={peak_number} is out of range. "
                f"Valid range is 1..{len(results)} for layer indexed {layer}."
            )

        # Extract patch around that bunch
        sub = extracted_image(
            image, int(xs[peak_number - 1]), int(ys[peak_number - 1]), int(focus_size)
        )

        npt.plot_focus_extended_peak(
            sub,
            sig_x[peak_number - 1],
            sig_y[peak_number - 1],
            rho=rhos[peak_number - 1],
            sigma_level=3,
            focus_size=focus_size,
        )
