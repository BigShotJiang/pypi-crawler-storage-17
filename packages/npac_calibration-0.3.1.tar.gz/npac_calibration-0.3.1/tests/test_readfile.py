import pandas as pd
import numpy as np
from npac_calibration.read_data.read_files import read_event_pd, get_event_path

EXPECTED_COLS = ["idx", "idy", "layer", "id", "E"]


def test_event_file():
    """
    Test the event CSV file and the read_event_pd() function.


    Ensures that the event CSV file is read into a non-empty pandas DataFrame
    with the expected columns, numeric data types, and physically meaningful
    values (valid layer indices and non-negative energies).
    """

    df = read_event_pd(get_event_path())

    # basic shape
    assert isinstance(df, pd.DataFrame)
    assert not df.empty

    # expected columns
    assert set(EXPECTED_COLS).issubset(df.columns)

    # numeric sanity
    assert np.issubdtype(df["idx"].dtype, np.number)
    assert np.issubdtype(df["idy"].dtype, np.number)
    assert np.issubdtype(df["layer"].dtype, np.number)
    assert np.issubdtype(df["E"].dtype, np.number)

    # domain checks
    assert df["layer"].between(0, 6).all()
    assert (df["E"] >= 0).all()
