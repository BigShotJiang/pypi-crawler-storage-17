<div align="center">

![TinyObj banner](banner/tinyobj.png)

**A tiny, cool data format with syntax freedom.**

[![GitHub Repo](https://img.shields.io/badge/github-repo-blue?logo=github)](https://github.com/tyydev1/tinyobj/)

</div>

Designed for simplicity, flexibility, and clarity.

---

_README coming soon!_
