# reckomate_sdk/client.py
import httpx
import logging
from typing import Dict, Any, Optional, List
from dataclasses import dataclass

from .config.settings import SDKConfig
from .exceptions import SDKError, APIError
from .services.proxy_services import (
    UserService, AdminService, MCQService, RAGService,
    ChatService, AudioQuizService, VideoInterviewService,
    QdrantService, IngestService, ScanService, TokenService
)

logger = logging.getLogger(__name__)


@dataclass
class ServiceRegistry:
    """Container for all SDK services"""
    user: UserService
    admin: AdminService
    mcq: MCQService
    rag: RAGService
    chat: ChatService
    audio: AudioQuizService
    video: VideoInterviewService
    qdrant: QdrantService
    ingest: IngestService
    scan: ScanService
    token: TokenService


class ReckomateSDK:
    """
    Complete SDK proxy for Reckomate Backend API.
    
    Mirrors ALL backend routes as Python methods.
    
    Usage:
        >>> from reckomate_sdk import ReckomateSDK
        >>> sdk = ReckomateSDK(base_url="http://localhost:8000")
        >>> # User routes
        >>> sdk.user.register("+1234567890", "password")
        >>> sdk.user.login("+1234567890", "password")
        >>> # MCQ routes
        >>> sdk.mcq.generate(query="climate", admin_id="admin1", file_id="file1")
        >>> # RAG routes
        >>> sdk.rag.ask_easy(user_id="user1", prompt="What is...?", file_id="file1")
        >>> # And so on for all 100+ routes...
    """
    
    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        api_key: Optional[str] = None,
        timeout: int = 30,
        verify_ssl: bool = True,
        auto_refresh_token: bool = False
    ):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self.auto_refresh_token = auto_refresh_token
        self.access_token: Optional[str] = None
        self.refresh_token: Optional[str] = None
        
        # Create HTTP client
        self.client = httpx.Client(
            base_url=self.base_url,
            timeout=self.timeout,
            verify=verify_ssl,
            headers=self._get_headers()
        )
        
        # Initialize ALL services
        self._services = ServiceRegistry(
            user=UserService(self),
            admin=AdminService(self),
            mcq=MCQService(self),
            rag=RAGService(self),
            chat=ChatService(self),
            audio=AudioQuizService(self),
            video=VideoInterviewService(self),
            qdrant=QdrantService(self),
            ingest=IngestService(self),
            scan=ScanService(self),
            token=TokenService(self)
        )
        
        logger.info(f"ReckomateSDK initialized with {len(self._services.__dataclass_fields__)} services")
    
    def _get_headers(self) -> Dict[str, str]:
        headers = {
            "User-Agent": f"Reckomate-SDK/1.0.0",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        elif self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        return headers
    
    def set_auth_tokens(self, access_token: str, refresh_token: Optional[str] = None):
        """Set authentication tokens for subsequent requests"""
        self.access_token = access_token
        if refresh_token:
            self.refresh_token = refresh_token
        
        # Update client headers
        self.client.headers.update({"Authorization": f"Bearer {access_token}"})
    
    def clear_auth_tokens(self):
        """Clear authentication tokens"""
        self.access_token = None
        self.refresh_token = None
        if "Authorization" in self.client.headers:
            del self.client.headers["Authorization"]
    
    def request(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> Dict[str, Any]:
        """Make HTTP request to backend"""
        try:
            # Auto-refresh token if expired and auto_refresh_token is True
            if (self.auto_refresh_token and self.refresh_token and 
                kwargs.get('requires_auth', True)):
                # Check if token might be expired (simplified)
                # In production, you'd decode JWT and check expiry
                pass
            
            response = self.client.request(
                method=method.upper(),
                url=endpoint,
                **kwargs
            )
            
            # Handle token expiration
            if response.status_code == 401 and self.auto_refresh_token and self.refresh_token:
                try:
                    # Try to refresh token
                    refresh_response = self.token.refresh(self.refresh_token)
                    if 'access_token' in refresh_response:
                        self.set_auth_tokens(
                            refresh_response['access_token'],
                            refresh_response.get('refresh_token', self.refresh_token)
                        )
                        # Retry the original request
                        response = self.client.request(
                            method=method.upper(),
                            url=endpoint,
                            **kwargs
                        )
                except Exception:
                    pass
            
            response.raise_for_status()
            
            # Handle empty responses
            if response.status_code == 204:
                return {"success": True, "message": "No content"}
            
            return response.json()
        except httpx.HTTPStatusError as e:
            error_msg = f"API error {e.response.status_code}"
            try:
                error_data = e.response.json()
                error_msg = f"{error_msg}: {error_data.get('detail', error_data)}"
            except:
                error_msg = f"{error_msg}: {e.response.text}"
            
            logger.error(error_msg)
            raise APIError(error_msg)
        except Exception as e:
            logger.error(f"Request failed: {e}")
            raise APIError(f"Request failed: {e}")
    
    def get(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("GET", endpoint, **kwargs)
    
    def post(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("POST", endpoint, **kwargs)
    
    def put(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("PUT", endpoint, **kwargs)
    
    def delete(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("DELETE", endpoint, **kwargs)
    
    def patch(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("PATCH", endpoint, **kwargs)
    
    # Property accessors for all services
    @property
    def user(self):
        return self._services.user
    
    @property
    def admin(self):
        return self._services.admin
    
    @property
    def mcq(self):
        return self._services.mcq
    
    @property
    def rag(self):
        return self._services.rag
    
    @property
    def chat(self):
        return self._services.chat
    
    @property
    def audio(self):
        return self._services.audio
    
    @property
    def video(self):
        return self._services.video
    
    @property
    def qdrant(self):
        return self._services.qdrant
    
    @property
    def ingest(self):
        return self._services.ingest
    
    @property
    def scan(self):
        return self._services.scan
    
    @property
    def token(self):
        return self._services.token
    
    def health_check(self) -> bool:
        """Check if backend is reachable"""
        try:
            response = self.client.get("/health", timeout=5)
            return response.status_code == 200
        except Exception:
            return False
    
    def list_all_methods(self) -> Dict[str, List[str]]:
        """List all available SDK methods (for Postman/testing)"""
        methods = {}
        for service_name in self._services.__dataclass_fields__.keys():
            service = getattr(self, service_name)
            service_methods = [
                method for method in dir(service) 
                if not method.startswith('_') and callable(getattr(service, method))
            ]
            methods[service_name] = sorted(service_methods)
        
        return methods
    
    def get_endpoint_count(self) -> Dict[str, int]:
        """Get count of endpoints per service"""
        methods = self.list_all_methods()
        return {service: len(methods_list) for service, methods_list in methods.items()}
    
    def close(self):
        self.client.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()