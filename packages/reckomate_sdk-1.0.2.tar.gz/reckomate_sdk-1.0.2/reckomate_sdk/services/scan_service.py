import uuid
from typing import Dict, Any, Optional
from datetime import datetime

from ..config.settings import SDKConfig
from ..exceptions import (
    ServiceError,
    ValidationError,
    DatabaseError,
    QdrantError
)


class ScanService:
    """User scan processing business logic"""
    
    def __init__(self, config: SDKConfig):
        self.config = config
        self._encoder = None
        self._qdrant_client = None
        self._mongo_client = None
    
    @property
    def encoder(self):
        """Lazy initialization of sentence transformer"""
        if self._encoder is None:
            from sentence_transformers import SentenceTransformer
            self._encoder = SentenceTransformer(self.config.embed_model)
        return self._encoder
    
    @property
    def qdrant_client(self):
        """Lazy initialization of Qdrant client"""
        if self._qdrant_client is None:
            from qdrant_client import QdrantClient
            kwargs = self.config.get_qdrant_client_kwargs()
            self._qdrant_client = QdrantClient(**kwargs)
        return self._qdrant_client
    
    @property
    def mongo_db(self):
        """Lazy initialization of MongoDB connection"""
        if self._mongo_client is None:
            from pymongo import MongoClient
            self._mongo_client = MongoClient(self.config.mongo_uri)
        return self._mongo_client[self.config.db_name]
    
    def store_user_scan(
        self,
        user_id: str,
        scan_text: str,
        title: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Store user scan text in Qdrant with metadata in MongoDB.
        
        Args:
            user_id: User ID
            scan_text: Scanned text content
            title: Scan title
            metadata: Optional additional metadata
            
        Returns:
            Dictionary with storage results
            
        Raises:
            ValidationError: If inputs are invalid
            ServiceError: If storage fails
            QdrantError: If Qdrant operation fails
            DatabaseError: If MongoDB operation fails
        """
        try:
            # Validate inputs
            if not user_id or not user_id.strip():
                raise ValidationError("user_id is required")
            
            if not scan_text or not scan_text.strip():
                raise ValidationError("scan_text is required")
            
            if not title or not title.strip():
                raise ValidationError("title is required")
            
            # Generate file ID
            file_id = str(uuid.uuid4())
            
            # Create embedding
            vector = self.encoder.encode(scan_text).tolist()
            
            # Store in Qdrant
            from qdrant_client.http.models import PointStruct
            
            self.qdrant_client.upsert(
                collection_name=self.config.qdrant_collection_name,
                wait=True,
                points=[
                    PointStruct(
                        id=str(uuid.uuid4()),
                        vector=vector,
                        payload={
                            "user_id": user_id,
                            "file_id": file_id,
                            "text": scan_text,
                            "title": title,
                            "type": "user_scan",
                            "created_at": datetime.utcnow().isoformat(),
                            **(metadata or {})
                        },
                    )
                ],
            )
            
            # Store metadata in MongoDB
            scan_doc = {
                "user_id": user_id,
                "file_id": file_id,
                "title": title,
                "text_preview": scan_text[:200],
                "text_length": len(scan_text),
                "metadata": metadata or {},
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
            }
            
            result = self.mongo_db["user_scans"].insert_one(scan_doc)
            scan_id = str(result.inserted_id)
            
            return {
                "success": True,
                "message": "Scan data stored successfully",
                "scan_id": scan_id,
                "file_id": file_id,
                "user_id": user_id,
                "title": title,
                "text_length": len(scan_text),
                "stored_at": datetime.utcnow().isoformat()
            }
            
        except (ValidationError, QdrantError, DatabaseError):
            raise
        except Exception as e:
            raise ServiceError(f"Failed to store user scan: {str(e)}")
    
    def get_user_scans(
        self,
        user_id: str,
        limit: int = 100,
        offset: int = 0
    ) -> Dict[str, Any]:
        """
        Get scans for a specific user.
        
        Args:
            user_id: User ID
            limit: Maximum results to return
            offset: Number of results to skip
            
        Returns:
            Dictionary with user scans
            
        Raises:
            ValidationError: If user_id is invalid
            DatabaseError: If database operation fails
        """
        try:
            # Validate user_id
            if not user_id or not user_id.strip():
                raise ValidationError("user_id is required")
            
            # Query MongoDB
            cursor = self.mongo_db["user_scans"].find(
                {"user_id": user_id}
            ).sort("created_at", -1).skip(offset).limit(limit)
            
            scans = []
            for doc in cursor:
                doc["_id"] = str(doc["_id"])
                scans.append(doc)
            
            # Get total count
            total_count = self.mongo_db["user_scans"].count_documents({"user_id": user_id})
            
            return {
                "success": True,
                "user_id": user_id,
                "scans": scans,
                "total_count": total_count,
                "returned_count": len(scans),
                "offset": offset,
                "limit": limit
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to get user scans: {str(e)}")
    
    def get_scan_by_id(
        self,
        scan_id: str,
        include_text: bool = False
    ) -> Dict[str, Any]:
        """
        Get a specific scan by ID.
        
        Args:
            scan_id: Scan document ID
            include_text: Whether to include full text from Qdrant
            
        Returns:
            Dictionary with scan data
            
        Raises:
            ValidationError: If scan_id is invalid
            NotFoundError: If scan not found
            DatabaseError: If database operation fails
        """
        try:
            from bson import ObjectId
            
            # Validate scan_id
            try:
                obj_id = ObjectId(scan_id)
            except:
                raise ValidationError("Invalid scan_id format")
            
            # Get from MongoDB
            scan_doc = self.mongo_db["user_scans"].find_one({"_id": obj_id})
            if not scan_doc:
                from ..exceptions import NotFoundError
                raise NotFoundError(f"Scan not found: {scan_id}")
            
            # Convert ObjectId to string
            scan_doc["_id"] = str(scan_doc["_id"])
            
            # Get full text from Qdrant if requested
            if include_text and "file_id" in scan_doc:
                try:
                    from qdrant_client.http.models import Filter, FieldCondition, MatchValue
                    
                    # Search for the scan in Qdrant
                    results = self.qdrant_client.scroll(
                        collection_name=self.config.qdrant_collection_name,
                        scroll_filter=Filter(
                            must=[
                                FieldCondition(key="file_id", match=MatchValue(value=scan_doc["file_id"]))
                            ]
                        ),
                        limit=1,
                    )
                    
                    points, _ = results
                    if points and points[0].payload:
                        scan_doc["full_text"] = points[0].payload.get("text", "")
                        
                except Exception:
                    scan_doc["full_text"] = None
            
            return {
                "success": True,
                "scan": scan_doc,
                "include_text": include_text
            }
            
        except (ValidationError, NotFoundError):
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to get scan: {str(e)}")
    
    def delete_scan(
        self,
        scan_id: str
    ) -> Dict[str, Any]:
        """
        Delete a scan from both MongoDB and Qdrant.
        
        Args:
            scan_id: Scan document ID
            
        Returns:
            Dictionary with deletion results
            
        Raises:
            ValidationError: If scan_id is invalid
            NotFoundError: If scan not found
            ServiceError: If deletion fails
        """
        try:
            from bson import ObjectId
            
            # Validate scan_id
            try:
                obj_id = ObjectId(scan_id)
            except:
                raise ValidationError("Invalid scan_id format")
            
            # Get scan document first to get file_id
            scan_doc = self.mongo_db["user_scans"].find_one({"_id": obj_id})
            if not scan_doc:
                from ..exceptions import NotFoundError
                raise NotFoundError(f"Scan not found: {scan_id}")
            
            file_id = scan_doc.get("file_id")
            
            # Delete from Qdrant if file_id exists
            qdrant_deleted = False
            if file_id:
                try:
                    from qdrant_client.http.models import Filter, FieldCondition, MatchValue
                    
                    self.qdrant_client.delete(
                        collection_name=self.config.qdrant_collection_name,
                        points_selector=Filter(
                            must=[
                                FieldCondition(key="file_id", match=MatchValue(value=file_id))
                            ]
                        ),
                    )
                    qdrant_deleted = True
                except Exception:
                    qdrant_deleted = False
            
            # Delete from MongoDB
            mongo_result = self.mongo_db["user_scans"].delete_one({"_id": obj_id})
            mongo_deleted = mongo_result.deleted_count > 0
            
            return {
                "success": True,
                "message": f"Scan {scan_id} deleted",
                "scan_id": scan_id,
                "file_id": file_id,
                "qdrant_deleted": qdrant_deleted,
                "mongo_deleted": mongo_deleted,
                "deleted_count": 1 if mongo_deleted else 0
            }
            
        except (ValidationError, NotFoundError):
            raise
        except Exception as e:
            raise ServiceError(f"Failed to delete scan: {str(e)}")
    
    def search_user_scans(
        self,
        user_id: str,
        query: str,
        top_k: int = 10
    ) -> Dict[str, Any]:
        """
        Search user scans using semantic search.
        
        Args:
            user_id: User ID
            query: Search query
            top_k: Number of results to return
            
        Returns:
            Dictionary with search results
            
        Raises:
            ValidationError: If inputs are invalid
            ServiceError: If search fails
        """
        try:
            # Validate inputs
            if not user_id or not user_id.strip():
                raise ValidationError("user_id is required")
            
            if not query or not query.strip():
                raise ValidationError("query is required")
            
            # Create query embedding
            query_vector = self.encoder.encode(query).tolist()
            
            # Search in Qdrant
            from qdrant_client.http.models import Filter, FieldCondition, MatchValue
            
            results = self.qdrant_client.query_points(
                collection_name=self.config.qdrant_collection_name,
                query=query_vector,
                query_filter=Filter(
                    must=[
                        FieldCondition(key="user_id", match=MatchValue(value=user_id)),
                        FieldCondition(key="type", match=MatchValue(value="user_scan"))
                    ]
                ),
                with_payload=True,
                with_vectors=False,
                limit=top_k,
            )
            
            # Format results
            scans = []
            for r in results.points:
                payload = r.payload or {}
                scans.append({
                    "id": r.id,
                    "score": r.score,
                    "file_id": payload.get("file_id"),
                    "title": payload.get("title"),
                    "text_preview": payload.get("text", "")[:100] + "..." if len(payload.get("text", "")) > 100 else payload.get("text", ""),
                    "created_at": payload.get("created_at"),
                    "metadata": {k: v for k, v in payload.items() if k not in ["text", "user_id", "file_id", "title", "type", "created_at"]}
                })
            
            # Get corresponding MongoDB documents for full metadata
            enriched_scans = []
            for scan in scans:
                file_id = scan.get("file_id")
                if file_id:
                    mongo_doc = self.mongo_db["user_scans"].find_one({"file_id": file_id})
                    if mongo_doc:
                        mongo_doc["_id"] = str(mongo_doc["_id"])
                        scan["mongo_metadata"] = mongo_doc
                enriched_scans.append(scan)
            
            return {
                "success": True,
                "user_id": user_id,
                "query": query,
                "results": enriched_scans,
                "count": len(enriched_scans),
                "top_k": top_k
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise ServiceError(f"Failed to search user scans: {str(e)}")
    
    def update_scan_metadata(
        self,
        scan_id: str,
        metadata_updates: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Update scan metadata.
        
        Args:
            scan_id: Scan document ID
            metadata_updates: Metadata fields to update
            
        Returns:
            Dictionary with update results
            
        Raises:
            ValidationError: If scan_id is invalid or updates are empty
            NotFoundError: If scan not found
            DatabaseError: If update fails
        """
        try:
            from bson import ObjectId
            
            # Validate scan_id
            try:
                obj_id = ObjectId(scan_id)
            except:
                raise ValidationError("Invalid scan_id format")
            
            # Validate updates
            if not metadata_updates:
                raise ValidationError("metadata_updates cannot be empty")
            
            # Remove protected fields
            protected_fields = ["_id", "user_id", "file_id", "created_at"]
            for field in protected_fields:
                metadata_updates.pop(field, None)
            
            if not metadata_updates:
                raise ValidationError("No valid fields to update")
            
            # Update MongoDB
            update_result = self.mongo_db["user_scans"].update_one(
                {"_id": obj_id},
                {
                    "$set": {
                        **metadata_updates,
                        "updated_at": datetime.utcnow()
                    }
                }
            )
            
            if update_result.matched_count == 0:
                from ..exceptions import NotFoundError
                raise NotFoundError(f"Scan not found: {scan_id}")
            
            return {
                "success": True,
                "message": f"Scan {scan_id} metadata updated",
                "scan_id": scan_id,
                "updated_fields": list(metadata_updates.keys()),
                "matched_count": update_result.matched_count,
                "modified_count": update_result.modified_count
            }
            
        except (ValidationError, NotFoundError):
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to update scan metadata: {str(e)}")