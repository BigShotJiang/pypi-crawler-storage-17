import re
import time
from typing import Dict, Any, List
from datetime import datetime

from ..config.settings import SDKConfig
from ..exceptions import ServiceError, ValidationError, OpenAIError


class MCQService:
    """MCQ generation and management business logic"""
    
    def __init__(self, config: SDKConfig):
        self.config = config
        self._openai_client = None
        self._encoder = None
    
    @property
    def openai_client(self):
        """Lazy initialization of OpenAI client"""
        if self._openai_client is None:
            from openai import OpenAI
            self._openai_client = OpenAI(api_key=self.config.openai_api_key)
        return self._openai_client
    
    @property
    def encoder(self):
        """Lazy initialization of sentence transformer"""
        if self._encoder is None:
            from sentence_transformers import SentenceTransformer
            self._encoder = SentenceTransformer(self.config.embed_model)
        return self._encoder
    
    def generate_mcqs(
        self,
        query: str,
        admin_id: str,
        file_id: str,
        top_k: int = 1,
        num_choices: int = 4,
        difficulty: str = "medium"
    ) -> Dict[str, Any]:
        """
        Generate MCQs from a query and context.
        
        Args:
            query: Search query
            admin_id: Admin ID for context
            file_id: File ID for context
            top_k: Number of questions to generate
            num_choices: Number of choices per question
            difficulty: Difficulty level
            
        Returns:
            Dictionary with generated MCQs
            
        Raises:
            ServiceError: If generation fails
            ValidationError: If input is invalid
            OpenAIError: If OpenAI API fails
        """
        try:
            # Validate inputs
            if not query or not query.strip():
                raise ValidationError("Query cannot be empty")
            
            if top_k <= 0:
                raise ValidationError("top_k must be positive")
            
            if num_choices < 2 or num_choices > 6:
                raise ValidationError("num_choices must be between 2 and 6")
            
            difficulty = difficulty.lower()
            if difficulty not in ["easy", "medium", "harder"]:
                difficulty = "medium"
            
            # Get context from RAG service
            from .rag_service import RAGService
            rag_service = RAGService(self.config)
            
            # Retrieve context chunks
            query_vector = self.encoder.encode(query).tolist()
            retrieved = rag_service._retrieve_chunks_for_document(
                query_vector=query_vector,
                file_id=file_id,
                admin_id=admin_id,
                top_k=top_k
            )
            
            if not retrieved:
                raise ServiceError("No content found for admin_id + file_id")
            
            # Prepare context
            context = "\n\n---\n\n".join(
                (r.get("text") or "") for r in retrieved
            )[:6000]
            
            # Generate MCQs
            requested_questions = max(1, int(top_k))
            choice_labels = [chr(ord("A") + i) for i in range(num_choices)]
            allowed = "/".join(choice_labels)
            options_block = "\n".join(f"{c}) <option {c}>" for c in choice_labels)
            
            prompt = f"""
Generate exactly {requested_questions} MCQs in THIS EXACT FORMAT (no numbering, no markdown):

Question: <text>
{options_block}
Answer: <{allowed}>

Only output the MCQs. Do not add extra commentary.

Context:
{context}
"""
            
            # Call OpenAI with retry
            response = None
            for attempt in range(3):
                try:
                    response = self.openai_client.chat.completions.create(
                        model=self.config.openai_model_fast,
                        messages=[{"role": "user", "content": prompt}],
                        temperature=0.25,
                        timeout=40,
                    )
                    break
                except Exception as e:
                    if "timed out" in str(e).lower() or "timeout" in str(e).lower():
                        time.sleep(2)
                        continue
                    raise OpenAIError(f"OpenAI API error: {str(e)}")
            
            if response is None:
                # Fallback to strict model
                try:
                    response = self.openai_client.chat.completions.create(
                        model=self.config.openai_model_strict,
                        messages=[{"role": "user", "content": prompt}],
                        temperature=0.25,
                        timeout=60,
                    )
                except Exception as e:
                    raise OpenAIError(f"OpenAI API fallback error: {str(e)}")
            
            # Parse MCQs
            mcqs_raw = response.choices[0].message.content.strip()
            mcqs = self._parse_mcqs(mcqs_raw, num_choices)
            
            if len(mcqs) < requested_questions:
                raise ServiceError(
                    f"Generated only {len(mcqs)} MCQs (expected {requested_questions})"
                )
            
            if len(mcqs) > requested_questions:
                mcqs = mcqs[:requested_questions]
            
            return {
                "admin_id": admin_id,
                "file_id": file_id,
                "mcqs": mcqs,
                "difficulty": difficulty,
                "query": query,
            }
            
        except (ValidationError, ServiceError, OpenAIError):
            raise
        except Exception as e:
            raise ServiceError(f"Failed to generate MCQs: {str(e)}")
    
    def _parse_mcqs(self, text: str, num_choices: int) -> List[Dict[str, Any]]:
        """
        Parse MCQs from raw text.
        
        Args:
            text: Raw MCQ text
            num_choices: Expected number of choices
            
        Returns:
            List of parsed MCQ dictionaries
        """
        mcqs = []
        blocks = re.split(r"(?i)question\s*[:\-\.\d]*", text)
        
        option_re = re.compile(r"^([A-Z])\)\s*(.+)$")
        option_re_alt = re.compile(r"^([A-Z])\.\s*(.+)$")
        
        for block in blocks:
            block = block.replace("**", "").strip()
            if not block:
                continue
            
            block = re.sub(r"^\s*\d+\)\s*", "", block)
            lines = [l.strip() for l in block.splitlines() if l.strip()]
            
            if not lines:
                continue
            
            question = lines[0]
            options = {}
            answer_label = ""
            
            for line in lines[1:]:
                m = option_re.match(line) or option_re_alt.match(line)
                if m:
                    options[m.group(1)] = m.group(2).strip()
                    continue
                
                m2 = re.match(r"^([A-Z])\)\s*(.+)$", line)
                if m2:
                    options[m2.group(1)] = m2.group(2).strip()
                    continue
                
                if line.lower().startswith("answer:"):
                    part = line.split(":", 1)[1].strip()
                    label = part.split()[0].strip().upper().rstrip(".)")
                    if label:
                        answer_label = label
                        continue
            
            if len(options) == num_choices and answer_label in options:
                mcqs.append({
                    "question": question,
                    "options": options,
                    "answer_label": answer_label,
                    "answer": f"{answer_label}. {options.get(answer_label, '')}",
                })
        
        return mcqs
    
    def evaluate_mcq_answer(
        self,
        question: str,
        selected_answer: str,
        correct_answer: str
    ) -> Dict[str, Any]:
        """
        Evaluate a single MCQ answer.
        
        Args:
            question: MCQ question
            selected_answer: User's selected answer
            correct_answer: Correct answer
            
        Returns:
            Dictionary with evaluation result
        """
        def extract_letter(value: str) -> str:
            if not value:
                return ""
            return value.split(".", 1)[0].strip().upper()
        
        selected_letter = extract_letter(selected_answer)
        correct_letter = extract_letter(correct_answer)
        
        is_correct = selected_letter == correct_letter if selected_letter and correct_letter else False
        
        return {
            "question": question,
            "selected_answer": selected_answer,
            "correct_answer": correct_answer,
            "is_correct": is_correct,
            "selected_letter": selected_letter,
            "correct_letter": correct_letter,
        }
    
    def batch_evaluate_mcqs(
        self,
        responses: List[Dict[str, Any]],
        correct_answers: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Evaluate multiple MCQ answers.
        
        Args:
            responses: List of user responses
            correct_answers: List of correct answers
            
        Returns:
            Dictionary with batch evaluation results
        """
        evaluations = []
        correct_count = 0
        total = len(responses)
        
        # Create a map of questions to correct answers
        correct_map = {}
        for correct in correct_answers:
            question = correct.get("question", "").strip()
            if question:
                correct_map[question] = correct
        
        for response in responses:
            question = response.get("question", "").strip()
            selected = response.get("selected_answer", "")
            
            correct = correct_map.get(question, {})
            correct_answer = correct.get("answer", "")
            
            evaluation = self.evaluate_mcq_answer(question, selected, correct_answer)
            
            if evaluation["is_correct"]:
                correct_count += 1
            
            evaluations.append(evaluation)
        
        score_percent = round((correct_count / total) * 100, 2) if total > 0 else 0.0
        
        return {
            "evaluations": evaluations,
            "summary": {
                "total_questions": total,
                "correct_count": correct_count,
                "incorrect_count": total - correct_count,
                "score_percent": score_percent,
            }
        }