import os
import uuid
from pathlib import Path
from typing import Dict, Any, List, Optional

# Update imports for document processing
from pypdf import PdfReader
from docx import Document
from pptx import Presentation
from PIL import Image
import pytesseract
import pandas as pd
from openpyxl import load_workbook
import xlrd
from striprtf.striprtf import rtf_to_text
import html2text
import lxml.html

from ..config.settings import SDKConfig
from ..utils.chunking import chunk_text
from ..exceptions import (
    ProcessingError,
    ValidationError,
    ServiceError,
    QdrantError
)


class IngestService:
    """Document ingestion and processing business logic"""
    
    def __init__(self, config: SDKConfig):
        self.config = config
        self._encoder = None
        self._qdrant_client = None
        self._mongo_client = None
        
        # Create upload directories
        os.makedirs(config.upload_dir, exist_ok=True)
        os.makedirs(config.upload_audio_dir, exist_ok=True)
    
    @property
    def encoder(self):
        """Lazy initialization of sentence transformer"""
        if self._encoder is None:
            from sentence_transformers import SentenceTransformer
            self._encoder = SentenceTransformer(self.config.embed_model)
        return self._encoder
    
    @property
    def qdrant_client(self):
        """Lazy initialization of Qdrant client"""
        if self._qdrant_client is None:
            from qdrant_client import QdrantClient
            from qdrant_client.http.models import VectorParams, Distance
            
            kwargs = self.config.get_qdrant_client_kwargs()
            self._qdrant_client = QdrantClient(**kwargs)
        return self._qdrant_client
    
    @property
    def mongo_db(self):
        """Lazy initialization of MongoDB connection"""
        if self._mongo_client is None:
            from pymongo import MongoClient
            self._mongo_client = MongoClient(self.config.mongo_uri)
        return self._mongo_client[self.config.db_name]
    
    def extract_text(self, file_path: Path) -> str:
        """
        Extract text from various file formats.
        
        Args:
            file_path: Path to the file
            
        Returns:
            Extracted text
            
        Raises:
            ProcessingError: If text extraction fails
        """
        try:
            suffix = file_path.suffix.lower()
            
            # PDF
            if suffix == ".pdf":
                try:
                    from pypdf import PdfReader
                    reader = PdfReader(str(file_path))
                    pages = [page.extract_text() or "" for page in reader.pages]
                    return "\n".join(pages)
                except ImportError:
                    try:
                        from PyPDF2 import PdfReader
                        reader = PdfReader(str(file_path))
                        pages = [page.extract_text() or "" for page in reader.pages]
                        return "\n".join(pages)
                    except ImportError:
                        raise ProcessingError("PDF extraction requires pypdf or PyPDF2")
            
            # DOCX
            elif suffix == ".docx":
                try:
                    from docx import Document
                    doc = Document(str(file_path))
                    return "\n".join(p.text for p in doc.paragraphs)
                except ImportError:
                    raise ProcessingError("DOCX extraction requires python-docx")
            
            # PPTX
            elif suffix == ".pptx":
                try:
                    from pptx import Presentation
                    prs = Presentation(str(file_path))
                    slides = []
                    for slide in prs.slides:
                        for shape in slide.shapes:
                            if hasattr(shape, "text"):
                                slides.append(shape.text)
                    return "\n".join(slides)
                except ImportError:
                    raise ProcessingError("PPTX extraction requires python-pptx")
            
            # Excel (XLSX, XLS)
            elif suffix in [".xlsx", ".xls"]:
                try:
                    import pandas as pd
                    if suffix == ".xlsx":
                        df = pd.read_excel(str(file_path), header=None, dtype=str)
                    else:
                        df = pd.read_excel(str(file_path), engine='xlrd', header=None, dtype=str)
                    return "\n".join(df.fillna("").values.flatten())
                except ImportError:
                    raise ProcessingError("Excel extraction requires pandas and openpyxl/xlrd")
            
            # CSV
            elif suffix == ".csv":
                try:
                    import pandas as pd
                    df = pd.read_csv(str(file_path), header=None, dtype=str)
                    return "\n".join(df.fillna("").values.flatten())
                except ImportError:
                    raise ProcessingError("CSV extraction requires pandas")
            
            # Images (PNG, JPG, JPEG)
            elif suffix in [".png", ".jpg", ".jpeg"]:
                try:
                    from PIL import Image
                    import pytesseract
                    
                    img = Image.open(str(file_path))
                    return pytesseract.image_to_string(img).strip()
                except ImportError:
                    raise ProcessingError("Image OCR requires Pillow and pytesseract")
                except Exception as e:
                    return f"[Image file: {file_path.name}]"
            
            # Plain text files
            elif suffix in [".txt", ".md", ".json", ".xml", ".html", ".htm"]:
                try:
                    return file_path.read_text(encoding="utf-8", errors="ignore")
                except Exception:
                    return ""
            
            # Unsupported format
            else:
                return f"[Unsupported file format: {suffix}]"
                
        except Exception as e:
            raise ProcessingError(f"Failed to extract text from {file_path.name}: {str(e)}")
    
    def process_file(
        self,
        file_path: str,
        owner_id: str,
        owner_field: str = "admin_id",
        file_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process a file: extract text, chunk, embed, and store in Qdrant.
        
        Args:
            file_path: Path to the file
            owner_id: Owner ID (admin_id or user_id)
            owner_field: Field name for owner ("admin_id" or "user_id")
            file_name: Optional custom file name
            
        Returns:
            Dictionary with processing results
            
        Raises:
            ProcessingError: If processing fails
            ValidationError: If inputs are invalid
            QdrantError: If Qdrant storage fails
        """
        try:
            # Validate inputs
            if not file_path or not Path(file_path).exists():
                raise ValidationError(f"File not found: {file_path}")
            
            if not owner_id or not owner_id.strip():
                raise ValidationError("owner_id is required")
            
            if owner_field not in ["admin_id", "user_id"]:
                raise ValidationError("owner_field must be 'admin_id' or 'user_id'")
            
            path = Path(file_path)
            file_name = file_name or path.name
            
            # Extract text
            text = self.extract_text(path)
            if not text.strip():
                raise ProcessingError("No text extracted from file")
            
            total_chars = len(text)
            
            # Chunk text
            chunks = chunk_text(text)
            if not chunks:
                raise ProcessingError("Chunking failed or produced no chunks")
            
            # Generate embeddings
            vectors = self.encoder.encode(chunks, show_progress_bar=False)
            
            # Generate file ID
            file_id = str(uuid.uuid4())
            
            # Prepare points for Qdrant
            from qdrant_client.http.models import PointStruct
            
            points = []
            for i, (chunk, vec) in enumerate(zip(chunks, vectors)):
                points.append(
                    PointStruct(
                        id=str(uuid.uuid4()),
                        vector=vec.tolist(),
                        payload={
                            owner_field: owner_id,
                            "file_id": file_id,
                            "file_name": file_name,
                            "file_type": path.suffix.lower()[1:] if path.suffix else "unknown",
                            "text": chunk,
                            "chunk_index": i,
                            "total_chunks": len(chunks)
                        }
                    )
                )
            
            # Store in Qdrant
            self.qdrant_client.upsert(
                collection_name=self.config.qdrant_collection_name,
                points=points
            )
            
            # Store metadata in MongoDB
            metadata = {
                "file_id": file_id,
                "file_name": file_name,
                "file_path": str(path),
                "owner_id": owner_id,
                "owner_field": owner_field,
                "total_chars": total_chars,
                "chunks_count": len(chunks),
                "processed_at": datetime.utcnow().isoformat()
            }
            
            self.mongo_db["processed_files"].insert_one(metadata)
            
            return {
                "success": True,
                "message": "File processed successfully",
                "file_id": file_id,
                "file_name": file_name,
                "owner_id": owner_id,
                "owner_field": owner_field,
                "total_chars": total_chars,
                "chunks_stored": len(chunks),
                "collection_name": self.config.qdrant_collection_name
            }
            
        except (ValidationError, ProcessingError, QdrantError):
            raise
        except Exception as e:
            raise ProcessingError(f"Failed to process file: {str(e)}")
    
    def process_audio_file(
        self,
        audio_file_path: str,
        owner_id: str,
        owner_field: str = "admin_id",
        file_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process an audio file: transcribe, chunk, embed, and store.
        
        Args:
            audio_file_path: Path to the audio file
            owner_id: Owner ID
            owner_field: Field name for owner
            file_name: Optional custom file name
            
        Returns:
            Dictionary with processing results
            
        Raises:
            ProcessingError: If processing fails
            ValidationError: If inputs are invalid
        """
        try:
            # Validate inputs
            if not audio_file_path or not Path(audio_file_path).exists():
                raise ValidationError(f"Audio file not found: {audio_file_path}")
            
            path = Path(audio_file_path)
            file_name = file_name or path.name
            
            # Check if it's an audio file
            audio_extensions = ['.mp3', '.wav', '.m4a', '.flac', '.ogg', '.aac']
            if path.suffix.lower() not in audio_extensions:
                raise ValidationError(f"Not an audio file: {path.suffix}")
            
            # Transcribe audio using OpenAI Whisper
            try:
                from openai import OpenAI
                client = OpenAI(api_key=self.config.openai_api_key)
                
                with open(path, "rb") as f:
                    response = client.audio.transcriptions.create(
                        model="whisper-1",
                        file=f,
                        response_format="text"
                    )
                
                transcript = response.strip()
                
            except ImportError:
                raise ProcessingError("OpenAI client required for audio transcription")
            except Exception as e:
                raise ProcessingError(f"Audio transcription failed: {str(e)}")
            
            if not transcript:
                raise ProcessingError("Transcript is empty")
            
            # Process transcript as text
            return self.process_text(
                text=transcript,
                owner_id=owner_id,
                owner_field=owner_field,
                source_name=file_name,
                file_type="audio"
            )
            
        except (ValidationError, ProcessingError):
            raise
        except Exception as e:
            raise ProcessingError(f"Failed to process audio file: {str(e)}")
    
    def process_text(
        self,
        text: str,
        owner_id: str,
        owner_field: str = "admin_id",
        source_name: str = "text_input",
        file_type: str = "text"
    ) -> Dict[str, Any]:
        """
        Process raw text: chunk, embed, and store.
        
        Args:
            text: Text to process
            owner_id: Owner ID
            owner_field: Field name for owner
            source_name: Source name for metadata
            file_type: Type of content
            
        Returns:
            Dictionary with processing results
            
        Raises:
            ProcessingError: If processing fails
            ValidationError: If inputs are invalid
        """
        try:
            # Validate inputs
            if not text or not text.strip():
                raise ValidationError("Text cannot be empty")
            
            if not owner_id or not owner_id.strip():
                raise ValidationError("owner_id is required")
            
            # Chunk text
            chunks = chunk_text(text)
            if not chunks:
                raise ProcessingError("Chunking failed")
            
            # Generate embeddings
            vectors = self.encoder.encode(chunks, show_progress_bar=False)
            
            # Generate file ID
            file_id = str(uuid.uuid4())
            
            # Prepare points for Qdrant
            from qdrant_client.http.models import PointStruct
            
            points = []
            for i, (chunk, vec) in enumerate(zip(chunks, vectors)):
                points.append(
                    PointStruct(
                        id=str(uuid.uuid4()),
                        vector=vec.tolist(),
                        payload={
                            owner_field: owner_id,
                            "file_id": file_id,
                            "file_name": source_name,
                            "file_type": file_type,
                            "text": chunk,
                            "chunk_index": i,
                            "total_chunks": len(chunks)
                        }
                    )
                )
            
            # Store in Qdrant
            self.qdrant_client.upsert(
                collection_name=self.config.qdrant_collection_name,
                points=points
            )
            
            return {
                "success": True,
                "message": "Text processed successfully",
                "file_id": file_id,
                "source_name": source_name,
                "owner_id": owner_id,
                "owner_field": owner_field,
                "chunks_stored": len(chunks),
                "total_chars": len(text),
                "file_type": file_type
            }
            
        except (ValidationError, ProcessingError):
            raise
        except Exception as e:
            raise ProcessingError(f"Failed to process text: {str(e)}")
    
    def get_processed_files(
        self,
        owner_id: Optional[str] = None,
        owner_field: Optional[str] = None,
        limit: int = 100
    ) -> Dict[str, Any]:
        """
        Get list of processed files.
        
        Args:
            owner_id: Optional owner ID filter
            owner_field: Optional owner field filter
            limit: Maximum results to return
            
        Returns:
            Dictionary with processed files list
        """
        try:
            query = {}
            if owner_id and owner_field:
                query = {"owner_id": owner_id, "owner_field": owner_field}
            elif owner_id:
                # Try to find files with either admin_id or user_id
                query = {"$or": [
                    {"owner_id": owner_id, "owner_field": "admin_id"},
                    {"owner_id": owner_id, "owner_field": "user_id"}
                ]}
            
            cursor = self.mongo_db["processed_files"].find(query).sort("processed_at", -1).limit(limit)
            
            files = []
            for doc in cursor:
                doc["_id"] = str(doc["_id"])
                files.append(doc)
            
            return {
                "success": True,
                "files": files,
                "count": len(files),
                "query": query
            }
            
        except Exception as e:
            raise ProcessingError(f"Failed to get processed files: {str(e)}")
    
    def delete_file(
        self,
        file_id: str,
        owner_id: Optional[str] = None,
        owner_field: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Delete a processed file from Qdrant and MongoDB.
        
        Args:
            file_id: File ID to delete
            owner_id: Optional owner ID for verification
            owner_field: Optional owner field for verification
            
        Returns:
            Dictionary with deletion results
            
        Raises:
            ProcessingError: If deletion fails
            ValidationError: If file_id is invalid
        """
        try:
            # Validate file_id
            if not file_id or not file_id.strip():
                raise ValidationError("file_id is required")
            
            # Build filter for Qdrant
            from qdrant_client.http.models import Filter, FieldCondition, MatchValue
            
            filters = [FieldCondition(key="file_id", match=MatchValue(value=file_id))]
            
            if owner_id and owner_field:
                filters.append(FieldCondition(key=owner_field, match=MatchValue(value=owner_id)))
            
            # Delete from Qdrant
            self.qdrant_client.delete(
                collection_name=self.config.qdrant_collection_name,
                points_selector=Filter(must=filters)
            )
            
            # Delete from MongoDB
            query = {"file_id": file_id}
            if owner_id:
                query["owner_id"] = owner_id
            if owner_field:
                query["owner_field"] = owner_field
            
            result = self.mongo_db["processed_files"].delete_many(query)
            
            return {
                "success": True,
                "message": f"File {file_id} deleted successfully",
                "file_id": file_id,
                "qdrant_deleted": True,
                "mongo_deleted_count": result.deleted_count
            }
            
        except (ValidationError, ProcessingError):
            raise
        except Exception as e:
            raise ProcessingError(f"Failed to delete file: {str(e)}")