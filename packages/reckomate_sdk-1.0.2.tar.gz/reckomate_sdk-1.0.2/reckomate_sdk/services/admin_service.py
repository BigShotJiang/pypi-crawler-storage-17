import uuid
from typing import Dict, Any
from datetime import datetime

from bson import ObjectId

from ..config.settings import SDKConfig
from ..utils.hash import hash_password, verify_password
from ..utils.jwt_handler import create_access_token, create_refresh_token
from ..exceptions import AuthenticationError, ValidationError, DatabaseError


class AdminService:
    """Admin-related business logic"""
    
    def __init__(self, config: SDKConfig):
        self.config = config
        self._mongo_client = None
        self._db = None
        self._admin_collection = None
        
    @property
    def db(self):
        """Lazy initialization of MongoDB connection"""
        if self._db is None:
            from pymongo import MongoClient
            self._mongo_client = MongoClient(self.config.mongo_uri)
            self._db = self._mongo_client[self.config.db_name]
            self._admin_collection = self._db["admins"]
        return self._db
    
    @property
    def admin_collection(self):
        if self._admin_collection is None:
            self.db  # Trigger initialization
        return self._admin_collection
    
    async def register_admin(self, email: str, password: str) -> Dict[str, Any]:
        """
        Register a new admin.
        
        Args:
            email: Admin email
            password: Plain text password
            
        Returns:
            Dictionary with registration result
            
        Raises:
            ValidationError: If admin already exists
            DatabaseError: If database operation fails
        """
        try:
            # Check if admin exists
            existing = self.admin_collection.find_one({"email": email})
            if existing:
                raise ValidationError("Admin already exists")
            
            # Hash password
            hashed = hash_password(password)
            
            # Create admin document
            admin_data = {
                "email": email,
                "password": hashed,
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow()
            }
            
            # Insert into database
            result = self.admin_collection.insert_one(admin_data)
            
            # Create tokens
            token_data = {
                "admin_id": str(result.inserted_id),
                "email": email,
                "role": "admin"
            }
            
            access_token = create_access_token(token_data)
            refresh_token = create_refresh_token(token_data)
            
            return {
                "success": True,
                "message": "Admin registered successfully",
                "admin_id": str(result.inserted_id),
                "access_token": access_token,
                "refresh_token": refresh_token,
                "token_type": "bearer"
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to register admin: {str(e)}")
    
    async def login_admin(self, email: str, password: str) -> Dict[str, Any]:
        """
        Login admin.
        
        Args:
            email: Admin email
            password: Plain text password
            
        Returns:
            Dictionary with login result
            
        Raises:
            AuthenticationError: If credentials are invalid
            DatabaseError: If database operation fails
        """
        try:
            # Find admin
            admin = self.admin_collection.find_one({"email": email})
            if not admin:
                raise AuthenticationError("Invalid email or password")
            
            # Verify password
            if not verify_password(password, admin["password"]):
                raise AuthenticationError("Invalid email or password")
            
            # Create tokens
            token_data = {
                "admin_id": str(admin["_id"]),
                "email": email,
                "role": "admin"
            }
            
            access_token = create_access_token(token_data)
            refresh_token = create_refresh_token(token_data)
            
            return {
                "success": True,
                "message": "Login successful",
                "admin_email": email,
                "admin_id": str(admin["_id"]),
                "access_token": access_token,
                "refresh_token": refresh_token,
                "token_type": "bearer"
            }
            
        except AuthenticationError:
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to login admin: {str(e)}")
    
    async def get_admin_by_id(self, admin_id: str) -> Dict[str, Any]:
        """
        Get admin by ID.
        
        Args:
            admin_id: Admin ID
            
        Returns:
            Admin document
            
        Raises:
            NotFoundError: If admin not found
            DatabaseError: If database operation fails
        """
        try:
            admin = self.admin_collection.find_one({"_id": ObjectId(admin_id)})
            if not admin:
                from ..exceptions import NotFoundError
                raise NotFoundError(f"Admin not found: {admin_id}")
            
            # Remove sensitive data
            admin["_id"] = str(admin["_id"])
            if "password" in admin:
                del admin["password"]
            
            return admin
            
        except Exception as e:
            raise DatabaseError(f"Failed to get admin: {str(e)}")
    
    def close(self):
        """Close database connections"""
        if self._mongo_client:
            self._mongo_client.close()
            self._mongo_client = None
            self._db = None
            self._admin_collection = None