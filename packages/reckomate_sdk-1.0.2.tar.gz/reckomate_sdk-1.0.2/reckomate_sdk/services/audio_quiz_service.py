import uuid
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

from ..config.settings import SDKConfig
from ..exceptions import ServiceError, ValidationError, NotFoundError


class AudioQuizService:
    """Audio quiz business logic"""
    
    def __init__(self, config: SDKConfig):
        self.config = config
        self._rag_service = None
        self.active_sessions = {}
    
    @property
    def rag_service(self):
        """Lazy initialization of RAG service"""
        if self._rag_service is None:
            from .rag_service import RAGService
            self._rag_service = RAGService(self.config)
        return self._rag_service
    
    def start_audio_quiz(
        self,
        user_id: str,
        file_id: str,
        num_questions: int = 5
    ) -> Dict[str, Any]:
        """
        Start a new audio quiz session.
        
        Args:
            user_id: User ID
            file_id: File ID
            num_questions: Number of questions
            
        Returns:
            Dictionary with session information
            
        Raises:
            ServiceError: If session creation fails
            ValidationError: If input is invalid
        """
        try:
            # Validate inputs
            if not user_id or not file_id:
                raise ValidationError("user_id and file_id are required")
            
            if num_questions <= 0:
                num_questions = 5
            
            # Generate questions
            questions = self.rag_service.generate_audio_quiz_questions(
                user_id=user_id,
                file_id=file_id,
                num_questions=num_questions
            )
            
            if not questions:
                raise ServiceError("Failed to generate quiz questions")
            
            # Create session
            session_id = str(uuid.uuid4())
            session = {
                "session_id": session_id,
                "user_id": user_id,
                "file_id": file_id,
                "questions": questions,
                "current_question": 0,
                "answers": [],
                "started_at": datetime.utcnow().isoformat(),
                "status": "active"
            }
            
            # Store session
            self.active_sessions[session_id] = session
            
            # Prepare first question
            current_q = questions[0] if questions else {}
            
            return {
                "success": True,
                "session_id": session_id,
                "user_id": user_id,
                "file_id": file_id,
                "total_questions": len(questions),
                "current_question": {
                    "question_id": current_q.get("question_id"),
                    "question": current_q.get("question"),
                    "difficulty": current_q.get("difficulty"),
                    "question_number": 1
                },
                "status": "active"
            }
            
        except (ValidationError, ServiceError):
            raise
        except Exception as e:
            raise ServiceError(f"Failed to start audio quiz: {str(e)}")
    
    def get_next_question(
        self,
        session_id: str
    ) -> Dict[str, Any]:
        """
        Get the next question in an audio quiz session.
        
        Args:
            session_id: Session ID
            
        Returns:
            Dictionary with next question or completion status
            
        Raises:
            NotFoundError: If session not found
            ValidationError: If session is completed
        """
        try:
            # Get session
            session = self.active_sessions.get(session_id)
            if not session:
                raise NotFoundError(f"Session not found: {session_id}")
            
            # Check if completed
            current = session["current_question"]
            questions = session["questions"]
            
            if current >= len(questions):
                return {
                    "success": True,
                    "session_id": session_id,
                    "status": "completed",
                    "message": "Quiz completed",
                    "total_questions": len(questions),
                    "questions_answered": len(session["answers"])
                }
            
            # Get current question
            question = questions[current]
            
            return {
                "success": True,
                "session_id": session_id,
                "question": {
                    "question_id": question["question_id"],
                    "question": question["question"],
                    "difficulty": question["difficulty"],
                    "question_number": current + 1
                },
                "status": "active",
                "progress": {
                    "current": current + 1,
                    "total": len(questions)
                }
            }
            
        except (NotFoundError, ValidationError):
            raise
        except Exception as e:
            raise ServiceError(f"Failed to get next question: {str(e)}")
    
    def submit_answer(
        self,
        session_id: str,
        question_id: str,
        user_answer: str
    ) -> Dict[str, Any]:
        """
        Submit an answer for an audio quiz question.
        
        Args:
            session_id: Session ID
            question_id: Question ID
            user_answer: User's answer text
            
        Returns:
            Dictionary with evaluation and next question
            
        Raises:
            NotFoundError: If session or question not found
            ValidationError: If answer is invalid
            ServiceError: If evaluation fails
        """
        try:
            # Get session
            session = self.active_sessions.get(session_id)
            if not session:
                raise NotFoundError(f"Session not found: {session_id}")
            
            # Find question
            questions = session["questions"]
            question = None
            question_index = -1
            
            for i, q in enumerate(questions):
                if q["question_id"] == question_id:
                    question = q
                    question_index = i
                    break
            
            if not question:
                raise NotFoundError(f"Question not found: {question_id}")
            
            # Validate answer
            if not user_answer or not user_answer.strip():
                raise ValidationError("Answer cannot be empty")
            
            # Evaluate answer
            evaluation = self.rag_service.evaluate_freeform_answer(
                user_id=session["user_id"],
                file_id=session["file_id"],
                question=question["question"],
                reference_answer=question["answer"],
                user_answer=user_answer
            )
            
            # Store answer
            answer_record = {
                "question_id": question_id,
                "question": question["question"],
                "user_answer": user_answer,
                "reference_answer": question["answer"],
                "evaluation": evaluation,
                "submitted_at": datetime.utcnow().isoformat()
            }
            
            session["answers"].append(answer_record)
            
            # Move to next question
            session["current_question"] = question_index + 1
            
            # Check if completed
            is_completed = session["current_question"] >= len(questions)
            
            # Prepare response
            response = {
                "success": True,
                "session_id": session_id,
                "question_id": question_id,
                "evaluation": evaluation,
                "status": "completed" if is_completed else "active"
            }
            
            # Add next question if not completed
            if not is_completed:
                next_question = questions[session["current_question"]]
                response["next_question"] = {
                    "question_id": next_question["question_id"],
                    "question": next_question["question"],
                    "difficulty": next_question["difficulty"],
                    "question_number": session["current_question"] + 1
                }
            else:
                # Calculate overall score
                total_accuracy = sum(a["evaluation"]["accuracy"] for a in session["answers"])
                avg_accuracy = total_accuracy / len(session["answers"]) if session["answers"] else 0
                
                response["summary"] = {
                    "total_questions": len(questions),
                    "questions_answered": len(session["answers"]),
                    "average_accuracy": round(avg_accuracy, 2),
                    "started_at": session["started_at"],
                    "completed_at": datetime.utcnow().isoformat()
                }
                
                # Clean up session
                self._archive_session(session_id)
            
            return response
            
        except (NotFoundError, ValidationError, ServiceError):
            raise
        except Exception as e:
            raise ServiceError(f"Failed to submit answer: {str(e)}")
    
    def get_session_status(
        self,
        session_id: str
    ) -> Dict[str, Any]:
        """
        Get the status of an audio quiz session.
        
        Args:
            session_id: Session ID
            
        Returns:
            Dictionary with session status
            
        Raises:
            NotFoundError: If session not found
        """
        try:
            session = self.active_sessions.get(session_id)
            if not session:
                raise NotFoundError(f"Session not found: {session_id}")
            
            questions = session["questions"]
            current = session["current_question"]
            answers = session["answers"]
            
            # Calculate progress
            completed_questions = len(answers)
            total_questions = len(questions)
            
            # Calculate average accuracy
            if answers:
                total_accuracy = sum(a["evaluation"]["accuracy"] for a in answers)
                avg_accuracy = total_accuracy / len(answers)
            else:
                avg_accuracy = 0
            
            return {
                "success": True,
                "session_id": session_id,
                "user_id": session["user_id"],
                "file_id": session["file_id"],
                "status": session["status"],
                "progress": {
                    "current": current,
                    "completed": completed_questions,
                    "total": total_questions,
                    "percentage": round((completed_questions / total_questions) * 100, 1) if total_questions > 0 else 0
                },
                "performance": {
                    "average_accuracy": round(avg_accuracy, 2),
                    "questions_answered": completed_questions
                },
                "started_at": session["started_at"],
                "current_question": current if current < total_questions else None
            }
            
        except NotFoundError:
            raise
        except Exception as e:
            raise ServiceError(f"Failed to get session status: {str(e)}")
    
    def _archive_session(self, session_id: str):
        """
        Archive a completed session (for future storage in database).
        
        Args:
            session_id: Session ID to archive
        """
        try:
            session = self.active_sessions.get(session_id)
            if session:
                # Here you could store the session in MongoDB
                # For now, just remove from active sessions
                archived_session = session.copy()
                archived_session["status"] = "archived"
                archived_session["archived_at"] = datetime.utcnow().isoformat()
                
                # Store in database (example)
                # from pymongo import MongoClient
                # mongo_client = MongoClient(self.config.mongo_uri)
                # db = mongo_client[self.config.db_name]
                # db["audio_quiz_sessions"].insert_one(archived_session)
                
                # Remove from active sessions
                del self.active_sessions[session_id]
                
        except Exception:
            pass  # Silently fail archiving
    
    def end_session(self, session_id: str) -> Dict[str, Any]:
        """
        End an audio quiz session early.
        
        Args:
            session_id: Session ID
            
        Returns:
            Dictionary with session summary
            
        Raises:
            NotFoundError: If session not found
        """
        try:
            session = self.active_sessions.get(session_id)
            if not session:
                raise NotFoundError(f"Session not found: {session_id}")
            
            # Calculate summary
            questions = session["questions"]
            answers = session["answers"]
            
            total_questions = len(questions)
            questions_answered = len(answers)
            
            # Calculate average accuracy
            if answers:
                total_accuracy = sum(a["evaluation"]["accuracy"] for a in answers)
                avg_accuracy = total_accuracy / len(answers)
            else:
                avg_accuracy = 0
            
            summary = {
                "session_id": session_id,
                "user_id": session["user_id"],
                "file_id": session["file_id"],
                "total_questions": total_questions,
                "questions_answered": questions_answered,
                "questions_skipped": total_questions - questions_answered,
                "average_accuracy": round(avg_accuracy, 2),
                "started_at": session["started_at"],
                "ended_at": datetime.utcnow().isoformat(),
                "status": "ended_early"
            }
            
            # Archive session
            self._archive_session(session_id)
            
            return {
                "success": True,
                "message": "Session ended successfully",
                "summary": summary
            }
            
        except NotFoundError:
            raise
        except Exception as e:
            raise ServiceError(f"Failed to end session: {str(e)}")