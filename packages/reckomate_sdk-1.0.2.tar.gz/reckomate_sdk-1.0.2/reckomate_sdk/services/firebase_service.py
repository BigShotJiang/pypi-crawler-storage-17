from typing import Optional, Dict, Any

from ..config.settings import SDKConfig
from ..exceptions import ServiceError, ValidationError


class FirebaseService:
    """Firebase Cloud Messaging business logic"""
    
    def __init__(self, config: SDKConfig):
        self.config = config
        self._firebase_app = None
        self._initialized = False
    
    def _initialize_firebase(self):
        """Lazy initialization of Firebase Admin SDK"""
        if not self._initialized:
            try:
                import firebase_admin
                from firebase_admin import credentials, messaging
                
                if not firebase_admin._apps:
                    if self.config.firebase_credentials_path:
                        cred = credentials.Certificate(self.config.firebase_credentials_path)
                        firebase_admin.initialize_app(cred)
                    else:
                        # Try to initialize without credentials (for optional use)
                        firebase_admin.initialize_app()
                
                self._firebase_app = firebase_admin.get_app()
                self._initialized = True
                
            except ImportError:
                raise ServiceError("Firebase Admin SDK not installed. Install with: pip install firebase-admin")
            except Exception as e:
                raise ServiceError(f"Failed to initialize Firebase: {str(e)}")
    
    def send_force_logout_notification(
        self,
        fcm_token: str,
        reason: str = "Logged in from another device"
    ) -> Optional[str]:
        """
        Send force logout notification to a device.
        
        Args:
            fcm_token: Firebase Cloud Messaging token
            reason: Reason for force logout
            
        Returns:
            Message ID if successful, None otherwise
            
        Raises:
            ValidationError: If fcm_token is invalid
            ServiceError: If Firebase operation fails
        """
        try:
            # Validate fcm_token
            if not fcm_token or not fcm_token.strip():
                raise ValidationError("fcm_token is required")
            
            # Initialize Firebase if needed
            self._initialize_firebase()
            
            from firebase_admin import messaging
            
            # Create message
            message = messaging.Message(
                data={
                    "type": "FORCE_LOGOUT",
                    "reason": reason,
                    "timestamp": str(datetime.utcnow().isoformat())
                },
                token=fcm_token,
                apns=messaging.APNSConfig(
                    payload=messaging.APNSPayload(
                        aps=messaging.Aps(
                            alert=messaging.ApsAlert(
                                title="Session Terminated",
                                body="You have been logged out from another device."
                            ),
                            sound="default",
                            badge=1
                        )
                    )
                ),
                android=messaging.AndroidConfig(
                    priority="high",
                    notification=messaging.AndroidNotification(
                        title="Session Terminated",
                        body="You have been logged out from another device.",
                        sound="default",
                        channel_id="high_importance_channel"
                    )
                )
            )
            
            # Send message
            response = messaging.send(message)
            
            return response
            
        except ValidationError:
            raise
        except ImportError:
            # Firebase not installed, return None (non-blocking)
            return None
        except Exception as e:
            # Log error but don't fail (non-blocking operation)
            import logging
            logging.getLogger(__name__).warning(f"FCM notification failed: {str(e)}")
            return None
    
    def send_notification(
        self,
        fcm_token: str,
        title: str,
        body: str,
        data: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """
        Send a general notification to a device.
        
        Args:
            fcm_token: Firebase Cloud Messaging token
            title: Notification title
            body: Notification body
            data: Optional additional data
            
        Returns:
            Message ID if successful, None otherwise
            
        Raises:
            ValidationError: If inputs are invalid
        """
        try:
            # Validate inputs
            if not fcm_token or not fcm_token.strip():
                raise ValidationError("fcm_token is required")
            
            if not title or not title.strip():
                raise ValidationError("title is required")
            
            if not body or not body.strip():
                raise ValidationError("body is required")
            
            # Initialize Firebase if needed
            self._initialize_firebase()
            
            from firebase_admin import messaging
            
            # Prepare data payload
            message_data = data or {}
            message_data.update({
                "title": title,
                "body": body,
                "timestamp": str(datetime.utcnow().isoformat())
            })
            
            # Create message
            message = messaging.Message(
                data=message_data,
                token=fcm_token,
                notification=messaging.Notification(
                    title=title,
                    body=body
                ),
                apns=messaging.APNSConfig(
                    payload=messaging.APNSPayload(
                        aps=messaging.Aps(
                            alert=messaging.ApsAlert(
                                title=title,
                                body=body
                            ),
                            sound="default"
                        )
                    )
                ),
                android=messaging.AndroidConfig(
                    priority="normal",
                    notification=messaging.AndroidNotification(
                        title=title,
                        body=body,
                        sound="default"
                    )
                )
            )
            
            # Send message
            response = messaging.send(message)
            
            return response
            
        except ValidationError:
            raise
        except ImportError:
            # Firebase not installed, return None
            return None
        except Exception as e:
            # Log error but don't fail
            import logging
            logging.getLogger(__name__).warning(f"FCM notification failed: {str(e)}")
            return None
    
    def send_multicast_notification(
        self,
        fcm_tokens: List[str],
        title: str,
        body: str,
        data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Send notification to multiple devices.
        
        Args:
            fcm_tokens: List of FCM tokens
            title: Notification title
            body: Notification body
            data: Optional additional data
            
        Returns:
            Dictionary with send results
            
        Raises:
            ValidationError: If inputs are invalid
        """
        try:
            # Validate inputs
            if not fcm_tokens:
                raise ValidationError("fcm_tokens list cannot be empty")
            
            if not title or not title.strip():
                raise ValidationError("title is required")
            
            if not body or not body.strip():
                raise ValidationError("body is required")
            
            # Filter valid tokens
            valid_tokens = [token for token in fcm_tokens if token and token.strip()]
            if not valid_tokens:
                raise ValidationError("No valid FCM tokens provided")
            
            # Initialize Firebase if needed
            self._initialize_firebase()
            
            from firebase_admin import messaging
            
            # Prepare data payload
            message_data = data or {}
            message_data.update({
                "title": title,
                "body": body,
                "timestamp": str(datetime.utcnow().isoformat())
            })
            
            # Create multicast message
            message = messaging.MulticastMessage(
                data=message_data,
                tokens=valid_tokens,
                notification=messaging.Notification(
                    title=title,
                    body=body
                ),
                apns=messaging.APNSConfig(
                    payload=messaging.APNSPayload(
                        aps=messaging.Aps(
                            alert=messaging.ApsAlert(
                                title=title,
                                body=body
                            ),
                            sound="default"
                        )
                    )
                ),
                android=messaging.AndroidConfig(
                    priority="normal",
                    notification=messaging.AndroidNotification(
                        title=title,
                        body=body,
                        sound="default"
                    )
                )
            )
            
            # Send multicast message
            response = messaging.send_multicast(message)
            
            return {
                "success": True,
                "total_tokens": len(valid_tokens),
                "success_count": response.success_count,
                "failure_count": response.failure_count,
                "responses": [
                    {
                        "token": valid_tokens[i],
                        "success": not response.responses[i].exception,
                        "error": str(response.responses[i].exception) if response.responses[i].exception else None
                    }
                    for i in range(len(valid_tokens))
                ]
            }
            
        except ValidationError:
            raise
        except ImportError:
            # Firebase not installed
            return {
                "success": False,
                "error": "Firebase Admin SDK not installed",
                "total_tokens": len(fcm_tokens),
                "success_count": 0,
                "failure_count": len(fcm_tokens)
            }
        except Exception as e:
            # Return error information
            return {
                "success": False,
                "error": str(e),
                "total_tokens": len(fcm_tokens),
                "success_count": 0,
                "failure_count": len(fcm_tokens)
            }
    
    def validate_fcm_token(self, fcm_token: str) -> Dict[str, Any]:
        """
        Validate an FCM token.
        
        Args:
            fcm_token: FCM token to validate
            
        Returns:
            Dictionary with validation result
            
        Raises:
            ValidationError: If token is invalid
        """
        try:
            # Basic validation
            if not fcm_token or not fcm_token.strip():
                raise ValidationError("FCM token cannot be empty")
            
            # Check token format (basic check)
            # FCM tokens are typically 152-164 characters
            token_length = len(fcm_token)
            if token_length < 100 or token_length > 200:
                return {
                    "valid": False,
                    "error": f"Token length {token_length} is outside expected range (100-200)",
                    "token_length": token_length
                }
            
            # Try to send a test notification (silent)
            # This would actually validate the token with Firebase
            # For now, just do basic format validation
            
            return {
                "valid": True,
                "token_length": token_length,
                "message": "Token format appears valid"
            }
            
        except ValidationError:
            raise
        except Exception as e:
            return {
                "valid": False,
                "error": str(e),
                "token_length": len(fcm_token) if fcm_token else 0
            }
    
    def subscribe_to_topic(
        self,
        fcm_tokens: List[str],
        topic: str
    ) -> Dict[str, Any]:
        """
        Subscribe devices to a topic.
        
        Args:
            fcm_tokens: List of FCM tokens
            topic: Topic name
            
        Returns:
            Dictionary with subscription results
        """
        try:
            # Validate inputs
            if not fcm_tokens:
                raise ValidationError("fcm_tokens list cannot be empty")
            
            if not topic or not topic.strip():
                raise ValidationError("topic is required")
            
            # Initialize Firebase if needed
            self._initialize_firebase()
            
            from firebase_admin import messaging
            
            # Filter valid tokens
            valid_tokens = [token for token in fcm_tokens if token and token.strip()]
            
            if not valid_tokens:
                raise ValidationError("No valid FCM tokens provided")
            
            # Subscribe to topic
            response = messaging.subscribe_to_topic(valid_tokens, topic)
            
            return {
                "success": True,
                "topic": topic,
                "total_tokens": len(valid_tokens),
                "success_count": response.success_count,
                "failure_count": response.failure_count,
                "errors": response.errors if hasattr(response, 'errors') else []
            }
            
        except ValidationError:
            raise
        except ImportError:
            return {
                "success": False,
                "error": "Firebase Admin SDK not installed",
                "topic": topic,
                "total_tokens": len(fcm_tokens)
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "topic": topic,
                "total_tokens": len(fcm_tokens)
            }
    
    def unsubscribe_from_topic(
        self,
        fcm_tokens: List[str],
        topic: str
    ) -> Dict[str, Any]:
        """
        Unsubscribe devices from a topic.
        
        Args:
            fcm_tokens: List of FCM tokens
            topic: Topic name
            
        Returns:
            Dictionary with unsubscription results
        """
        try:
            # Validate inputs
            if not fcm_tokens:
                raise ValidationError("fcm_tokens list cannot be empty")
            
            if not topic or not topic.strip():
                raise ValidationError("topic is required")
            
            # Initialize Firebase if needed
            self._initialize_firebase()
            
            from firebase_admin import messaging
            
            # Filter valid tokens
            valid_tokens = [token for token in fcm_tokens if token and token.strip()]
            
            if not valid_tokens:
                raise ValidationError("No valid FCM tokens provided")
            
            # Unsubscribe from topic
            response = messaging.unsubscribe_from_topic(valid_tokens, topic)
            
            return {
                "success": True,
                "topic": topic,
                "total_tokens": len(valid_tokens),
                "success_count": response.success_count,
                "failure_count": response.failure_count,
                "errors": response.errors if hasattr(response, 'errors') else []
            }
            
        except ValidationError:
            raise
        except ImportError:
            return {
                "success": False,
                "error": "Firebase Admin SDK not installed",
                "topic": topic,
                "total_tokens": len(fcm_tokens)
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "topic": topic,
                "total_tokens": len(fcm_tokens)
            }
    
    def send_topic_notification(
        self,
        topic: str,
        title: str,
        body: str,
        data: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """
        Send notification to a topic.
        
        Args:
            topic: Topic name
            title: Notification title
            body: Notification body
            data: Optional additional data
            
        Returns:
            Message ID if successful, None otherwise
        """
        try:
            # Validate inputs
            if not topic or not topic.strip():
                raise ValidationError("topic is required")
            
            if not title or not title.strip():
                raise ValidationError("title is required")
            
            if not body or not body.strip():
                raise ValidationError("body is required")
            
            # Initialize Firebase if needed
            self._initialize_firebase()
            
            from firebase_admin import messaging
            
            # Prepare data payload
            message_data = data or {}
            message_data.update({
                "title": title,
                "body": body,
                "timestamp": str(datetime.utcnow().isoformat())
            })
            
            # Create topic message
            message = messaging.Message(
                data=message_data,
                topic=topic,
                notification=messaging.Notification(
                    title=title,
                    body=body
                )
            )
            
            # Send message
            response = messaging.send(message)
            
            return response
            
        except ValidationError:
            raise
        except ImportError:
            return None
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"FCM topic notification failed: {str(e)}")
            return None