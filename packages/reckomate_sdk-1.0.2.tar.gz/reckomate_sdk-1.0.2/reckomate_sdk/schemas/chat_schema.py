from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime


class ChatMessage(BaseModel):
    user_id: str
    role: str  # "user" or "assistant"
    message: str
    document_id: Optional[str] = None
    timestamp: datetime = datetime.utcnow()


class ChatHistoryResponse(BaseModel):
    user_id: str
    history: List[dict]


class SaveMessageRequest(BaseModel):
    user_id: str
    role: str
    message: str
    document_id: Optional[str] = None