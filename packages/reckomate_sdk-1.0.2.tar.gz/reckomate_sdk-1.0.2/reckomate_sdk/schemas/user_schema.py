from pydantic import BaseModel, Field
from typing import Optional, List


class UserRegister(BaseModel):
    phone: str = Field(..., min_length=10, max_length=15)
    password: str


class UserLogin(BaseModel):
    phone: str = Field(..., min_length=10, max_length=15)
    password: str
    fcm_token: Optional[str] = None


class UserResponse(BaseModel):
    success: bool
    user_id: str
    phone: str
    role: str
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    session_id: Optional[str] = None


class LinkedFile(BaseModel):
    file_id: str
    file_name: str


class UserLoginResponse(UserResponse):
    linked_file_ids: List[str] = []
    mcqs_by_file: dict = {}