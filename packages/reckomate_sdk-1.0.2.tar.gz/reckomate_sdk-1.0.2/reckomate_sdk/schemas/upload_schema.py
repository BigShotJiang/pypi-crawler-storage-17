from pydantic import BaseModel


class UploadResponse(BaseModel):
    status: bool
    filename: str
    file_hash: str
    chunks: int
    filesize_mb: float


class ProcessFileRequest(BaseModel):
    file_path: str
    owner_id: str
    owner_field: str = "admin_id"


class ProcessFileResponse(BaseModel):
    success: bool
    file_id: str
    file_name: str
    chunks_stored: int
    total_characters: int