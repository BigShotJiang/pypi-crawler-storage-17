from pydantic import BaseModel
from typing import Optional


class StartVideoInterviewRequest(BaseModel):
    user_id: str
    file_id: str
    num_questions: Optional[int] = 5


class VideoInterviewQuestion(BaseModel):
    question_id: str
    question: str
    evaluation_criteria: str
    difficulty: str


class VideoInterviewResponse(BaseModel):
    question_id: str
    user_response: str
    duration_seconds: float


class VideoInterviewEvaluation(BaseModel):
    fluency: float
    relevance: float
    completeness: float
    confidence: float
    feedback: str
    overall_score: float