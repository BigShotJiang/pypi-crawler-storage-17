from pydantic import BaseModel
from typing import Optional


class StartAudioQuizRequest(BaseModel):
    user_id: str
    file_id: str
    num_questions: Optional[int] = 5


class AudioQuizAnswer(BaseModel):
    session_id: str
    question_id: str
    user_answer: str


class AudioQuizEvaluation(BaseModel):
    accuracy: float
    relevance: float
    completeness: float
    feedback: str
    verdict: str


class AudioQuizSession(BaseModel):
    session_id: str
    user_id: str
    file_id: str
    questions: list
    current_question: int = 0
    created_at: str