from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class ChatMessage(BaseModel):
    """Chat message model"""
    
    id: Optional[str] = Field(None, description="Message ID")
    user_id: str = Field(..., description="User ID")
    role: str = Field(..., description="Message role (user/assistant)")
    message: str = Field(..., description="Message content")
    document_id: Optional[str] = Field(None, description="Related document ID")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Message timestamp")
    
    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "id": "507f1f77bcf86cd799439012",
                "user_id": "user_123",
                "role": "user",
                "message": "Hello, how are you?",
                "document_id": "doc_456",
                "timestamp": "2024-01-01T12:00:00Z"
            }
        }


class ChatSession(BaseModel):
    """Chat session model"""
    
    id: Optional[str] = Field(None, description="Session ID")
    user_id: str = Field(..., description="User ID")
    title: Optional[str] = Field(None, description="Session title")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Creation timestamp")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="Last update timestamp")
    message_count: int = Field(0, description="Number of messages in session")
    
    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "id": "session_123",
                "user_id": "user_123",
                "title": "Document Q&A Session",
                "created_at": "2024-01-01T10:00:00Z",
                "updated_at": "2024-01-01T12:00:00Z",
                "message_count": 10
            }
        }