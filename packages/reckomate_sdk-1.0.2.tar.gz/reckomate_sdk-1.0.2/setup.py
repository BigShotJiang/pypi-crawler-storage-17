from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="reckomate-sdk",
    version="1.0.2",
    author="Reckomate AI",
    author_email="support@reckomate.com",
    description="Reckomate AI SDK - Business logic without HTTP dependencies",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/reckomate/reckomate-sdk",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        # Core dependencies
        "pydantic>=2.12.5",
        "pydantic-settings>=2.12.0",
        "python-dotenv>=1.2.1",
        
        # AI/ML dependencies
        "sentence-transformers>=5.1.2",
        "openai>=2.8.1",
        "langchain>=1.1.0",
        "langchain-text-splitters>=1.0.0",
        "transformers>=4.57.3",
        "torch>=2.9.1",
        "numpy>=2.3.5",
        "scipy>=1.16.3",
        "scikit-learn>=1.7.2",
        
        # Database dependencies
        "qdrant-client>=1.16.1",
        "pymongo>=4.15.4",
        "motor>=3.7.1",
        
        # File processing dependencies
        "pillow>=12.0.0",
        "pypdf>=6.4.0",
        "python-docx>=1.2.0",
        "python-pptx>=1.0.2",
        "openpyxl>=3.1.5",
        "pandas>=2.3.3",
        "lxml>=6.0.2",
        "pytesseract>=0.3.13",
        "html2text>=2025.4.15",
        "striprtf>=0.0.29",
        "xlrd>=2.0.2",
        
        # Authentication & Security
        "python-jose>=3.5.0",
        "passlib[argon2]>=1.7.4",
        "cryptography>=46.0.3",
        "bcrypt>=4.0.1",
        "argon2-cffi>=25.1.0",
        
        # Async/Networking (minimal)
        "aiohttp>=3.13.2",
        "httpx>=0.28.1",
        
        # Utilities
        "orjson>=3.11.4",
        "pytz>=2025.2",
        "python-dateutil>=2.9.0",
        "typing-extensions>=4.15.0",
        "tqdm>=4.67.1",
        "joblib>=1.5.2",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "black>=23.0.0",
            "isort>=5.12.0",
            "mypy>=1.0.0",
            "build>=1.3.0",
            "twine>=4.0.0",
        ],
        "full": [
            "fastapi>=0.123.4",
            "uvicorn>=0.38.0",
            "websockets>=15.0.1",
            "starlette>=0.50.0",
        ],
        "firebase": [
            "firebase-admin>=6.2.0",
        ],
    },
)
