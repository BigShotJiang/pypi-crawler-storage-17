# Reckomate AI SDK

A reusable Python SDK containing the business logic from Reckomate AI backend, without HTTP dependencies.

## Installation

```bash
# From local development
pip install -e /path/to/reckomate_sdk

# From PyPI (after publishing)
pip install reckomate-sdk