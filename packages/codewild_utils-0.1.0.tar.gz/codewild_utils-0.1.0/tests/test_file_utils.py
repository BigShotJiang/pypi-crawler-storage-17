import os
from codewild_utils import copy_and_rename_files

def _create_temp_files(tmp_path, count):
    src_dir = tmp_path / "src"
    src_dir.mkdir()
    files = []
    for i in range(count):
        p = src_dir / f"file_{i}.txt"
        p.write_text("data")
        files.append(str(p))
    return files

def test_copy_and_rename_preserves_extension(tmp_path):
    files = _create_temp_files(tmp_path, 2)
    dst_dir = tmp_path / "dst"

    copy_and_rename_files(files, str(dst_dir), rename_pattern="renamed_{}")

    assert sorted(os.listdir(dst_dir)) == ["renamed_1.txt", "renamed_2.txt"]


def test_copy_and_rename_custom_extension(tmp_path):
    files = _create_temp_files(tmp_path, 1)
    dst_dir = tmp_path / "dst_custom"

    copy_and_rename_files(files, str(dst_dir), rename_pattern="image_{}.jpg")

    assert os.listdir(dst_dir) == ["image_1.jpg"]
