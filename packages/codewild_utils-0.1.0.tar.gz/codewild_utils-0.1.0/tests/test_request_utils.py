import unittest
from unittest import mock

from codewild_utils.modules.request import get_user_agent_from_pyproject, get_wikidata_entity


class TestUserAgentFromPyproject(unittest.TestCase):
    def test_generates_expected_user_agent_for_utils(self):
        self.assertEqual(
            get_user_agent_from_pyproject("utils"),
            "utils/0.1.0 (ben@codewild.org)",
        )

class TestGetWikidataEntity(unittest.TestCase):
    @mock.patch("codewild_utils.modules.request._DEFAULT_REQUEST_SERVICE.request_json")
    def test_returns_none_for_missing_entity(self, mock_request_json):
        mock_request_json.return_value = {"entities": {"Q00000": {"missing": ""}}}

        self.assertIsNone(get_wikidata_entity("Q00000"))

    @mock.patch("codewild_utils.modules.request._DEFAULT_REQUEST_SERVICE.request_json")
    def test_returns_entity_payload(self, mock_request_json):
        mock_request_json.return_value = {
            "entities": {"Q7206136": {"id": "Q7206136", "label": "test"}}
        }

        entity = get_wikidata_entity("Q7206136")

        self.assertIsNotNone(entity)
        self.assertEqual(entity["id"], "Q7206136")

    if __name__ == "__main__":
        unittest.main()