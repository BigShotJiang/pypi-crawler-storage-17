import importlib.machinery
import importlib.util
import pathlib
import uuid


def _load_data_module():
    """Load the data module without importing the full utils package."""
    module_path = pathlib.Path(__file__).resolve().parents[1] / "src" / "utils" / "modules" / "data.py"
    loader = importlib.machinery.SourceFileLoader("_test_data_module", str(module_path))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return module


generate_guid = _load_data_module().generate_guid


def test_generate_guid_returns_uuid_by_default():
    ident = generate_guid()

    assert isinstance(ident, uuid.UUID)


def test_generate_guid_can_return_string():
    ident = generate_guid(as_uuid=False)

    assert isinstance(ident, str)
    uuid.UUID(ident)  # raises ValueError if not canonical