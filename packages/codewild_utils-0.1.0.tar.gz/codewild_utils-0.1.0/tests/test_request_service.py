from copy import deepcopy
import sys
import pytest
from unittest import mock

sys.modules.setdefault("cv2", mock.Mock())

from codewild_utils.modules.request import RequestService, RequestServiceError


def _mock_response(status_code=200, json_data=None, headers=None):
    response = mock.Mock()
    response.status_code = status_code
    response.headers = headers or {}
    response.raise_for_status.return_value = None
    response.json.return_value = json_data or {}
    return response


def test_request_adds_user_agent_and_base_url():
    session = mock.Mock()
    session.request.return_value = _mock_response()

    service = RequestService(base_url="https://api.example.com", session=session)

    service.request("GET", "/v1/items", params={"limit": 1})

    session.request.assert_called_once()
    args, kwargs = session.request.call_args
    assert args[0] == "GET"
    assert args[1] == "https://api.example.com/v1/items"
    assert "User-Agent" in kwargs["headers"]
    assert kwargs["headers"]["User-Agent"].startswith("utils/")


@mock.patch("codewild_utils.modules.request.time.sleep")
def test_retries_and_sleeps_on_retryable_status(mock_sleep):
    retry_response = _mock_response(status_code=500)
    success_response = _mock_response()

    session = mock.Mock()
    session.request.side_effect = [retry_response, success_response]

    service = RequestService(base_url="https://api.example.com", session=session, backoff_factor=0.1)

    response = service.request("GET", "endpoint")

    assert response is success_response
    assert session.request.call_count == 2
    mock_sleep.assert_called_once_with(0.1)


@mock.patch("codewild_utils.modules.request.time.sleep")
def test_respects_retry_after_header(mock_sleep):
    retry_response = _mock_response(status_code=429, headers={"Retry-After": "2"})
    success_response = _mock_response()

    session = mock.Mock()
    session.request.side_effect = [retry_response, success_response]

    service = RequestService(base_url="https://api.example.com", session=session)

    response = service.request("GET", "endpoint")

    assert response is success_response
    mock_sleep.assert_called_once_with(2.0)


@mock.patch("codewild_utils.modules.request.time.sleep")
def test_raises_error_after_exhausting_retries(mock_sleep):
    retry_response = _mock_response(status_code=500)

    session = mock.Mock()
    session.request.side_effect = [retry_response, retry_response, retry_response]

    service = RequestService(base_url="https://api.example.com", session=session, max_retries=2)

    with pytest.raises(RequestServiceError):
        service.request("GET", "endpoint")

    assert mock_sleep.call_count == 2


def test_paged_post_updates_page_number():
    responses = [
        _mock_response(json_data={"results": [{"id": 1}]}),
        _mock_response(json_data={"results": []}),
    ]

    captured_payloads = []

    def _request(method, endpoint, **kwargs):
        captured_payloads.append(deepcopy(kwargs.get("json")))
        return responses.pop(0)

    service = RequestService()
    with mock.patch.object(service, "request", side_effect=_request):
        items = service.paged_post("https://api.example.com/search", {"criteria": "x"})

    assert items == [{"id": 1}]
    assert captured_payloads[0]["pagingOptions"]["page"] == 1
    assert captured_payloads[1]["pagingOptions"]["page"] == 2
