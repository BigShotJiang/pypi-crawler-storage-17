# codewild-utils

Utility helpers and small CLI entrypoints shared across the Codewild projects.

## Installation

This package is published internally and can be installed from the private
package index or as an editable dependency:

```bash
pip install -e .
```

## Features

* File, CSV, and JSON helpers for quick data inspection.
* Image utilities for working with EXIF metadata and OpenCV rendering helpers.
* HTTP request wrapper with retry and user-agent helpers.
* Wikidata client utilities for small cross-referencing tasks.

## CLI entrypoints

Two simple OpenCV-powered commands are available:

* `codewild_utils.viewer_cv2_main` — browse images in a folder and inspect bounding boxes.
* `codewild_utils.timelapse_cv2_main` — play a timelapse from a directory of images.

Run either command with `python -m codewild_utils.cli` to access the functions directly
or add them as console scripts in your environment.

## Configuration

Some helpers look for `pyproject.toml` metadata to build request headers. Use
`config.toml` files alongside each service to configure behavior when needed.
