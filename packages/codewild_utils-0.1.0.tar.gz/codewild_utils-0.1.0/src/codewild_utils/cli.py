"""Console entrypoints for interactive OpenCV viewers."""

import argparse
import os.path
from codewild_utils import list_images, ViewerCV2

def viewer_cv2_main():
    """Open an interactive image viewer for a directory of photos."""
    ap = argparse.ArgumentParser()

    ap.add_argument('-d', '--directory', required=False, default=os.getcwd(), help='directory of images to display [optional string. defaults to current working directory]')
    ap.add_argument('-f', '--fullscreen', action="store_true", required=False, default=False,
                    help='fullscreen [optional flag] [defaults to false]')

    args = vars(ap.parse_args())

    src = args['directory']

    if not os.path.exists(src):
        print(f"Error: path {src} does not exist")
        exit(1)

    images = list_images(src)

    # Move to ViewerCV2.__init__()
    print(f"Opening ViewerCV2 with {len(images)} images")

    viewer = ViewerCV2(images, fullscreen=args['fullscreen'], header=["basename", "counter"],
                footer=["flags"])
    viewer.show()
    
def timelapse_cv2_main():
    """Play a simple timelapse of images from a directory."""
    ap = argparse.ArgumentParser()

    ap.add_argument('-d', '--directory', required=False, default=os.getcwd(), help='directory of images to display [optional string. defaults to current working directory]')
    ap.add_argument('-f', '--fullscreen', action="store_true", required=False, default=False,
                    help='fullscreen [optional flag] [defaults to false]')
    ap.add_argument('-i', '--interval', required=False, default=2,
                    help='interval in seconds [optional float] [defaults to 2.0]')
    
    args = vars(ap.parse_args())

    src = args['directory']

    if not os.path.exists(src):
        print(f"Error: path {src} does not exist")
        exit(1)

    images = list_images(src)

    viewer = ViewerCV2(images, fullscreen=args['fullscreen'], preload=True)

    viewer.timelapse(interval=float(args['interval']))



