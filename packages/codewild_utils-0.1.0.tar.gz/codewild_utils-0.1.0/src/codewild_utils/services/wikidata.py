from enum import Enum
from ..modules.request import RequestService, RequestServiceError
from ..modules.data import value_from_dict

class WikidataProperties(Enum):
    GBIF = "P846"
    ITIS = "P815"
    NSX = "P10243"
    USDA = "P1772"

class WikidataServiceError(RequestServiceError):
    """Raised when Wikidata requests fail."""

class WikidataService(RequestService):
    BASE_URL = None

    def __init__(
        self,
        *,
        session=None,
        max_retries: int = 3,
        backoff_factor: float = 1.0,
        timeout: float = 10.0,
        user_agent_package: str | None = "utils",
    ) -> None:
        super().__init__(
            base_url=self.BASE_URL,
            session=session,
            max_retries=max_retries,
            backoff_factor=backoff_factor,
            timeout=timeout,
            user_agent_package=user_agent_package,
        )

    def _request(self, endpoint: str, params: dict[str, str | int | None]) -> dict:
        try:
            return self.request_json("GET", endpoint, params=params)
        except RequestServiceError as exc:
            raise WikidataServiceError(str(exc)) from exc

    def get_entity(self, qid: str) -> dict | None:
        
        endpoint="https://www.wikidata.org/w/api.php"
        
        params = {
            "action": "wbgetentities",
            "ids": qid,
            "format": "json",
        }

        data = self._request(endpoint, params)

        if data:
            entities = data.get("entities", {}) if isinstance(data, dict) else {}
            entity = entities.get(qid)

            if entity and not "missing" in entity:
                return entity
        return None

    def get_qid_from_external_id(self, ext_id: str | int, property_id: str) -> str | None:
        """
        Look up the Wikidata QID for a taxon given its external ID.

        Parameters
        ----------
        tsn : str | int
            External ID
        property_id : str
            The Wikidata property ID corresponding to the external ID (e.g. 'P846' for GBIF ID).

        Returns
        -------
        str | None
            The Wikidata QID (e.g. 'Q123456') if found, otherwise None.
        """
        
        endpoint = "https://query.wikidata.org/sparql"
        ext_id_str = str(ext_id)

        # SPARQL: find any item with wdt:{property_id}
        sparql = f"""
        SELECT ?item WHERE {{
        ?item wdt:{property_id} "{ext_id_str}" .
        }}
        LIMIT 1
        """

        params = {
            "query": sparql,
            "format": "json",
        }

        data = self._request(endpoint, params)
        if data:
            bindings = value_from_dict(data, ["results", "bindings"])
            if bindings:
                item_uri = bindings[0]["item"]["value"]  # e.g. "http://www.wikidata.org/entity/Q123456"
                qid = item_uri.rsplit("/", 1)[-1]
                return qid
        
        return None

    def get_property_value_from_qid(self, qid: str, property_id: str) -> str | None:
        entity = self.get_entity(qid)
        if entity:   
            claims:dict = entity.get("claims", {})
            target_claim:list[dict] = claims.get(property_id, [])
            for claim in target_claim:
                datavalue:dict = value_from_dict(claim, ["mainsnak", "datavalue"])
                if 'value' in datavalue:
                    return datavalue.get('value')
        return None
    
    def cross_reference_property_values(self, src_value, src_prop:WikidataProperties, dst_prop:WikidataProperties):
        """
        Makes two requests to Wikidata to cross reference identifers. May take a second or more to complete one request.
        """
        qid = self.get_qid_from_external_id(src_value, src_prop.value)
        if qid:
            return self.get_property_value_from_qid(qid, dst_prop.value)
        return None


