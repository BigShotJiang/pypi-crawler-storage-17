from copy import deepcopy
import inspect
from enum import Enum
import time
from pathlib import Path
from typing import Sequence
import requests
import tomllib
from .data import value_from_dict
from .config import get_module_path


def _resolve_package_name(pkg_name: str | None) -> str | None:
    if pkg_name:
        return pkg_name

    caller_frame = inspect.stack()[1]
    caller_module = inspect.getmodule(caller_frame.frame)
    if caller_module:
        module_path = (caller_module.__package__ or caller_module.__name__).split(".")[0]
        if module_path:
            return module_path

    return None


def _find_pyproject(start_path: Path) -> Path | None:
    for candidate in (start_path, *start_path.parents):
        pyproject_file = candidate / "pyproject.toml"
        if pyproject_file.exists():
            return pyproject_file
    return None


def get_user_agent_from_pyproject(pkg_name: str | None = None) -> str | None:
    """Generate a User-Agent string from a package's ``pyproject.toml``.

    When ``pkg_name`` is not provided, the calling module's package name is
    used. The returned string follows the format
    ``"{name}/{version} ({email})"`` when the information is available.
    """

    package_name = _resolve_package_name(pkg_name)
    if not package_name:
        return None

    module_path = Path(get_module_path(package=package_name))
    search_root = module_path.parent if module_path.is_file() else module_path
    pyproject_path = _find_pyproject(search_root)
    if not pyproject_path:
        return None

    with open(pyproject_path, "rb") as f:
        pyproject_data = tomllib.load(f)

    project_info = pyproject_data.get("project", {})
    name = project_info.get("name", "unknown")
    version = project_info.get("version")
    email = None

    authors = project_info.get("authors")
    if isinstance(authors, list):
        for author in authors:
            if isinstance(author, dict) and author.get("email"):
                email = author["email"]
                break

    user_agent = name
    if version:
        user_agent += f"/{version}"
    if email:
        user_agent += f" ({email})"

    return user_agent


def _set_nested_value(payload: dict, path: Sequence[str], value: int) -> None:
    current = payload
    for key in path[:-1]:
        if key not in current or not isinstance(current[key], dict):
            current[key] = {}
        current = current[key]

    current[path[-1]] = value

class RequestServiceError(Exception):
    """Raised when a service request fails after retries."""

class RequestService:
    """Lightweight HTTP client with retry/backoff and user agent handling."""

    RETRY_STATUS_CODES = {429}

    def __init__(
        self,
        *,
        base_url: str | None = None,
        session: requests.Session | None = None,
        max_retries: int = 3,
        backoff_factor: float = 1.0,
        timeout: float = 10.0,
        user_agent_package: str | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/") if base_url else None
        self.session = session or requests.Session()
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor
        self.timeout = timeout
        self.user_agent_package = user_agent_package

    def _build_url(self, endpoint: str) -> str:
        if self.base_url:
            return f"{self.base_url}/{endpoint.lstrip('/')}"
        return endpoint

    def _prepare_headers(self, headers: dict | None) -> dict:
        request_headers = dict(headers) if headers else {}

        if "User-Agent" not in request_headers:
            user_agent = get_user_agent_from_pyproject(self.user_agent_package)
            if user_agent:
                request_headers["User-Agent"] = user_agent

        return request_headers

    def _should_retry(self, response: requests.Response) -> bool:
        return response.status_code in self.RETRY_STATUS_CODES or response.status_code >= 500

    def _sleep_with_backoff(self, response: requests.Response | None, attempt: int) -> None:
        retry_after = None
        if response:
            retry_after_header = response.headers.get("Retry-After")
            if retry_after_header is not None:
                try:
                    retry_after = float(retry_after_header)
                except (TypeError, ValueError):
                    retry_after = None

        delay = retry_after if retry_after is not None else self.backoff_factor * (2 ** (attempt - 1))
        time.sleep(delay)

    def request(
        self,
        method: str,
        endpoint: str,
        *,
        params: dict | None = None,
        json: dict | None = None,
        headers: dict | None = None,
        timeout: float | None = None,
        allow_redirects: bool = True,
    ) -> requests.Response:
        url = self._build_url(endpoint)
        request_headers = self._prepare_headers(headers)
        last_error: Exception | None = None

        for attempt in range(1, self.max_retries + 1):
            try:
                response = self.session.request(
                    method,
                    url,
                    params=params,
                    json=json,
                    headers=request_headers,
                    timeout=timeout or self.timeout,
                    allow_redirects=allow_redirects,
                )

                if self._should_retry(response):
                    last_error = requests.HTTPError(
                        f"Received retryable status {response.status_code} for {url}"
                    )
                    self._sleep_with_backoff(response, attempt)
                    continue

                response.raise_for_status()
                return response
            except requests.RequestException as exc:
                last_error = exc
                if attempt >= self.max_retries:
                    break
                self._sleep_with_backoff(None, attempt)

        raise RequestServiceError(str(last_error) if last_error else "Unknown request error")

    def request_json(self, method: str, endpoint: str, **kwargs) -> dict:
        response = self.request(method, endpoint, **kwargs)
        return response.json()

    def get(
        self,
        endpoint: str,
        *,
        params: dict | None = None,
        headers: dict | None = None,
        timeout: float | None = None,
        allow_redirects: bool = True,
    ) -> requests.Response:
        return self.request(
            "GET",
            endpoint,
            params=params,
            headers=headers,
            timeout=timeout,
            allow_redirects=allow_redirects,
        )

    def get_json(self, endpoint: str, **kwargs) -> dict:
        return self.request_json("GET", endpoint, **kwargs)

    def paged_post(
        self,
        endpoint: str,
        payload: dict,
        *,
        headers: dict | None = None,
        page_path: Sequence[str] | None = ("pagingOptions", "page"),
        start_page: int = 1,
        timeout: float | None = None,
    ) -> list[dict]:
        """Return JSON responses from paginated POST requests as a flat list."""

        request_payload = deepcopy(payload)
        page = start_page
        responses: list[dict] = []

        while True:
            if page_path:
                _set_nested_value(request_payload, page_path, page)

            response = self.request(
                "POST",
                endpoint,
                json=request_payload,
                headers=headers,
                timeout=timeout,
            )
            response_json = response.json()

            if isinstance(response_json, dict) and isinstance(
                response_json.get("results"), list
            ):
                page_items = response_json.get("results", [])
            elif isinstance(response_json, list):
                page_items = response_json
            else:
                page_items = [response_json]

            if not page_items:
                break

            responses.extend(page_items)
            page += 1

        return responses


_DEFAULT_REQUEST_SERVICE = RequestService()

