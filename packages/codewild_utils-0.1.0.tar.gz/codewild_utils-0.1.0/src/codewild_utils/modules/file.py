import os
from tqdm import tqdm
import shutil

def get_ext(name_or_path):
    return str(os.path.splitext(name_or_path)[-1]).lower()

def get_filepath(folder, filename) -> os.path:
    return os.path.join(folder, filename).replace('\\', '/')

def filter_files(folder, filename, valid_exts=None, contains=None):
    ext = get_ext(filename)
    if contains is not None and filename.find(contains) == -1:
        return None
    if valid_exts is None or ext in valid_exts:
        filepath = get_filepath(folder, filename)
        return filepath

def list_files(dir, recurse=False, valid_exts=None, contains=None):
    files = list()
    if recurse:
        for (rootDir, dirNames, fileNames) in os.walk(dir):
            for f in fileNames:
                r = filter_files(rootDir, f, valid_exts, contains)
                if r is not None:
                    files.append(r)
    else:
        for f in os.listdir(dir):
            path = os.path.join(dir, f)
            if os.path.isfile(path):
                r = filter_files(dir, f, valid_exts, contains)
                if r is not None:
                    files.append(r)
    return files



def list_empty_folders(root_dir):
    """
    Lists all empty folders within a given root directory.

    Args:
        root_dir (str): The path to the root directory to start the search from.

    Returns:
        list: A list of paths to empty folders.
    """
    empty_folders = []
    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Check if both subdirectories and files lists are empty
        if not dirnames and not filenames:
            empty_folders.append(dirpath)
    return empty_folders


def copytree_with_progress(src, dest, total_files=None, desc="Copying files", dirs_exist_ok=False):
    if not total_files:
        total_files = len(list_files(src, recurse=True))
    with tqdm(total=total_files, unit="file", desc=desc) as pbar:
        def _copy_file(source_path, destination_path):
            shutil.copy2(source_path, destination_path)
            pbar.update(1) # Update progress bar after each file
            return destination_path # Return value expected by shutil.copytree

        shutil.copytree(src, dest, copy_function=_copy_file, dirs_exist_ok=dirs_exist_ok)


def copy_and_rename_files(src_files: list[str], dst_dir: str, rename_pattern="new_name_{}"):
    """Copy files to *dst_dir* and rename them.

    The ``rename_pattern`` should contain a single ``{}`` placeholder which will
    be replaced by a 1-indexed counter.  The original file extension is
    preserved unless the pattern itself supplies one.

    Args:
        src_files (list[str]): The source file paths.
        dst_dir (str): Destination directory where files will be copied.
        rename_pattern (str): Pattern used for renaming.
    """

    if not os.path.exists(dst_dir):
        os.makedirs(dst_dir)

    total_files = len(src_files)
    num_digits = len(str(total_files))

    for i, file in enumerate(tqdm(src_files, desc="Copying and renaming")):
        # Determine the new filename
        _, ext = os.path.splitext(file)
        inc = str(i + 1).zfill(num_digits)

        # Apply the pattern and preserve the extension if none was provided
        formatted = rename_pattern.format(inc)
        if os.path.splitext(formatted)[1]:
            new_filename = formatted
        else:
            new_filename = f"{formatted}{ext}"

        dst_path = os.path.join(dst_dir, new_filename)

        try:
            shutil.copy2(file, dst_path)
        except Exception as e:
            print(f"Error copying {file}: {e}")

