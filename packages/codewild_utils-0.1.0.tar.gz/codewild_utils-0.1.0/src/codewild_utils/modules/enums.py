from enum import Enum


class CustomEnum(Enum):

    def __init__(self, code, label):
        self.code = code
        self.label = label

    # TODO: group methods?
    @classmethod
    def get(cls, code:int=None, label:str=None):
        if(code and label):
            raise ValueError("CustomEnum.get accepts either `code` or `label`, not both")
        for c in cls:
            if c.code == code:
                return c
            if c.label == label:
                return c
        return None

    @classmethod
    def get_label(cls, code):
        for c in cls:
            if c.code == code:
                return c.label
        return None

    @classmethod
    def get_code(cls, name):
        for c in cls:
            if c.name == name:
                return c.code
        return None
    
class BasicGrade(Enum):
    A = 'Excellent'
    B = 'Good'
    C = 'Average'
    D = 'Poor'
    F = 'Failing'

class BasicSize(Enum):
    XS = 'Extra Small'
    S = 'Small'
    M = 'Medium'
    L = 'Large'
    XL = 'Extra Large'

