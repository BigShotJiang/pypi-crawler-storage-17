# -*- coding: utf-8 -*-
"""
image.py
A self-contained implementation of ImageCV2 and ViewerCV2 with:
- Real-time carousel updates (flags & drawing)
- Persistent overlays per image (boxes + labels)
- Crop (zoom) support via ImageCV2.bbox in ORIGINAL coordinates
- Programmatic boxes accepted in ORIGINAL coordinates (xyxy, xywh, or normalized), rebased + clipped into crop
- Mouse drawing constrained to cropped image bounds
- Undo last box (Z), left/right navigation, ESC to exit
"""
import enum
import os
import cv2
import numpy as np
import tkinter
from datetime import datetime
from typing import Tuple
import time

from codewild_utils.modules.file import get_ext, list_files
from codewild_utils.modules.system import get_time
from PIL import Image, ImageOps
import exiftool

image_exts = [".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"]
movie_exts = [".mov", ".mp4", ".mpeg", ".avi"]
media_exts = image_exts + movie_exts


# -----------------------------
# Utilities
# -----------------------------


def is_corrupt(filepath):
    if not os.path.isfile(filepath):
        return False

    if get_ext(filepath) in image_exts:
        # another option is through exiftool - corrupt images will have a blank File:FileType
        try:
            im = Image.open(filepath)
            try:
                im.load()
                im.close()
                return False
            except:
                im.close()
                return True
        except:
            return True
    else:
        print(f"Warning: cannot run is_corrupt() on non-image")


def list_images(base_path, recurse=False, valid_exts=None, contains=None):
    if valid_exts is None:
        valid_exts = image_exts
    return list_files(base_path, recurse, valid_exts, contains)


def ensure_pil_image(source):
    """Return a normalized RGB :class:`PIL.Image.Image` from ``source``."""
    if isinstance(source, Image.Image):
        return source if source.mode == "RGB" else source.convert("RGB")
    if isinstance(source, (str, os.PathLike)):
        with Image.open(source) as img:
            return img.convert("RGB")
    raise TypeError("source must be a path-like object or PIL.Image.Image")


def generate_exif_metadata(dir_name, recurse=False):
    images = list_images(dir_name, recurse=recurse)
    result = []
    with exiftool.ExifToolHelper() as et:
        print(f"Getting metadata for {len(images)} images...")
        for image in images:
            try:
                image_metadata = et.get_metadata([image])[0]
                result.append(image_metadata)
            except exiftool.exceptions.ExifToolException as e:
                print(f"Could not get metadata for {image}: {e}")
                result.append({"SourceFile": image, "ExifTool:ExifToolVersion": et.version,
                               "ExifTool:Warning": f"[major]: {e}"})
    return result


def datetime_from_metadata(row, format="%Y:%m:%d %H:%M:%S"):
    dto_idx = [f for f in row if "DateTimeOriginal" in f]
    if not dto_idx:
        print(f"Warning: no DateTimeOriginal field found in metadata")
        return False

    return datetime.strptime(row[dto_idx[0]], format)

# TODO: move to camtrap.utils?
def exif_camera_model(row):
    model_idx = [i for i in row if "Model" in i]
    if not model_idx:
        return False
    return row[model_idx[0]]


def get_dt_taken(filepath, format="%Y:%m:%d %H:%M:%S"):
    with exiftool.ExifToolHelper() as et:
        try:
            rows = et.get_metadata(filepath)
            if rows:
                row = rows[0]
                return datetime_from_metadata(row, format)
        except Exception as e:
            print(f"Could not get metadata for {filepath}: {e}")
    return False


# ----------------------
# DRAWING AND LABELLING UTILITIES
# ----------------------

class DrawnObjStatus(enum.Enum):
    NEW = 'new'
    EDITED = 'edited'
    ORIGINAL = 'original'
    DELETED = 'deleted'


class DrawnBox:
    def __init__(self, rect: list | tuple, labels: dict[str], color: tuple = (255, 0, 255),
                 font=(cv2.FONT_HERSHEY_SIMPLEX, 1, 1), ident: str = None, status=DrawnObjStatus.ORIGINAL):
        self.rect = tuple(rect)

        self.labels = labels

        self.color = color
        self.th = 2
        self.font = font

        # Allows boxes to be tracked
        self.ident = ident
        self.status = status

    @property
    def label_text(self):
        result = None
        if len(self.labels) > 0:
            result = "|".join(list(self.labels.values()))
        return result


# for tools like delete that do not label or draw
# self.tools.append(BaseTool('delete', self._delete_keycodes))
class BaseTool:
    def __init__(self, name: str, keycodes: {int}):
        self.name = name
        self.keycodes = keycodes


class DrawTool(BaseTool):
    def __init__(self, name: str, keycodes: {int}):
        super().__init__(name, keycodes)


# TODO: assess whether append is needed or if function can be accomplished programmatically with category
class LabelTool(BaseTool):
    def __init__(self, name: str, keycodes: {int}, text: str, color: tuple = (255, 0, 255), category: str = None,
                 append: bool = False):
        super().__init__(name, keycodes)
        self.text = text
        self.color = color
        self.category = category
        self.append = append


class LabelAndDrawTool(LabelTool, DrawTool):
    def __init__(self, name: str, keycodes: {int}, text: str, color=None, category: str = None):
        # By definition, cannot append label to existing box
        super().__init__(name, keycodes, text, color, category=category, append=False)


# -----------------------------
# ImageCV2
# -----------------------------

class ImageWrapper:
    """
    Abstract image wrapper that supports:
    - OpenCV or PIL Image rasters
    - Optional crop (self.bbox) in ORIGINAL image coords (acts as a zoom).
    - Boxes supplied at construction (boxes=[...]) are in ORIGINAL image coords (pixel or normalized).
      They are rebased and clipped into the crop during load().
    - Persistent overlays (boxes/labels/colors) stored in CROPPED coords.
    - Live preview rectangle while dragging the mouse.
    - Per-image flags that persist as you page back/forth in the viewer.
    """

    def __init__(self, filepath: str, autoload: bool = False, ident=None, crop_bbox=None):
        self.filepath = filepath
        self.ident = ident
        self.crop_bbox = crop_bbox  # (l,t,r,b) in ORIGINAL coords used to crop before viewing

        # Rasters and sizes
        self.base_raster = None  # immutable CROPPED image
        self.full_w = None
        self.full_h = None
        self.orig_w = None  # CROPPED width
        self.orig_h = None  # CROPPED height
        self._crop_origin = (0, 0)  # ORIGINAL -> CROPPED offset (ox, oy)

    @property
    def basename(self):
        return os.path.basename(self.filepath) if self.filepath else ""

    # -------- Loading & sizing --------

    def load(self):
        """Load image, crop to bbox (if provided), compute dims, and process pending boxes."""
        corrupt_icon = os.path.join(os.path.dirname(__file__), "corrupt_file_icon.jpg")
        try:
            raster = self._read_raster()
            if raster is None:
                raise RuntimeError("Failed to read raster")

            self.full_h, self.full_w = self._raster_shape(raster)

            if self.crop_bbox is not None:
                cl, ct, cr, cb = map(int, self.crop_bbox)
                # clamp crop to full image
                cl = max(0, min(cl, self.full_w - 1))
                cr = max(0, min(cr, self.full_w))
                ct = max(0, min(ct, self.full_h - 1))
                cb = max(0, min(cb, self.full_h))
                if cl >= cr or ct >= cb:
                    raise ValueError("Invalid crop bbox after clamping")

                raster = self._crop_raster(raster, (cl, ct, cr, cb))
                self._crop_origin = (cl, ct)
            else:
                self._crop_origin = (0, 0)

            self.base_raster = raster
        except Exception:
            self.base_raster = self._fallback_raster(corrupt_icon)
            self.full_h, self.full_w = self._raster_shape(self.base_raster)
            self._crop_origin = (0, 0)

        self.orig_h, self.orig_w = self._raster_shape(self.base_raster)

    # Template method hooks -------------------------------------------------

    def _read_raster(self):
        raise NotImplementedError

    def _crop_raster(self, raster, bbox: Tuple[int, int, int, int]):
        raise NotImplementedError

    def _raster_shape(self, raster) -> Tuple[int, int]:
        raise NotImplementedError

    def _fallback_raster(self, corrupt_icon: str):
        raise NotImplementedError

    
class ImagePIL(ImageWrapper):
    def __init__(self, filepath, autoload = False, ident=None, crop_bbox=None):
        super().__init__(filepath, autoload, ident, crop_bbox)

        if autoload:
            self.load()

    def _read_raster(self):
        return ensure_pil_image(self.filepath)

    def _crop_raster(self, raster, bbox: Tuple[int, int, int, int]):
        return raster.crop(bbox)

    def _raster_shape(self, raster) -> Tuple[int, int]:
        width, height = raster.size
        return height, width

    def _fallback_raster(self, corrupt_icon: str):
        try:
            fallback = ensure_pil_image(corrupt_icon)
        except Exception:
            fallback = Image.new("RGB", (320, 240), color=0)
        return ImageOps.invert(fallback)


class ImageCV2(ImageWrapper):
    def __init__(self, filepath, autoload = False, ident=None, crop_bbox=None, boxes=None):
        super().__init__(filepath, autoload, ident, crop_bbox)

        # Boxes supplied at construction (ORIGINAL coords); processed after load()
        self._pending_boxes = boxes or []

        # Persistent state (stored in CROPPED coords)
        self.boxes = []  # list of LabelledBox
        self.deleted_boxes = []  # list of LabelledBox
        self.preview = None  # (l,t,r,b) in DISPLAY coords while dragging

        # self.flags = []       # list[str]
        self.last_viewed = None

        # Mouse helpers
        self.drawing = False
        self.ix = self.iy = 0

        if autoload:
            self.load()

    def load(self):
        super().load()

        # Process any boxes provided at construction (in ORIGINAL coords)
        if self._pending_boxes:
            for bx in self._pending_boxes:
                if bx.rect is None:
                    continue
                rect = self._normalize_rect_from_original(bx.rect)  # original → original-pixel xyxy
                rect = self._rebase_and_clip_into_crop(rect)  # original → cropped coords (clipped)
                if rect is not None:
                    self.boxes.append(
                        DrawnBox(
                            rect=rect,
                            labels=bx.labels,
                            color=bx.color,
                            ident=bx.ident
                        ))

            self._pending_boxes = []

    def _read_raster(self):
        return cv2.imread(self.filepath)

    def _crop_raster(self, raster, bbox: Tuple[int, int, int, int]):
        cl, ct, cr, cb = bbox
        return raster[ct:cb, cl:cr]

    def _raster_shape(self, raster) -> Tuple[int, int]:
        return raster.shape[:2]

    def _fallback_raster(self, corrupt_icon: str):
        fallback = cv2.imread(corrupt_icon)
        if fallback is None:
            fallback = np.zeros((240, 320, 3), dtype=np.uint8)
        return cv2.bitwise_not(fallback)



    # -------- Coordinate helpers --------

    def _normalize_rect_from_original(self, coords):
        """
        Accepts (l,t,r,b) or (x,y,w,h). Also accepts normalized floats [0..1] **relative to FULL IMAGE**.
        Returns (l,t,r,b) in ORIGINAL-PIXEL coordinates.
        """
        if len(coords) != 4:
            raise ValueError("bbox coords must have 4 elements")

        if self.full_w is None or self.full_h is None:
            raise RuntimeError("full image size unknown; call load() first")

        x1, y1, x2, y2 = map(float, coords)

        # If normalized, scale to full-image pixels
        if max(x1, y1, x2, y2) <= 1.0:
            x1 *= self.full_w
            x2 *= self.full_w
            y1 *= self.full_h
            y2 *= self.full_h

        # Heuristic: treat as xywh if x1+x2 <= full_w and y1+y2 <= full_h
        if (x2 > 0 and y2 > 0) and (x1 + x2 <= self.full_w) and (y1 + y2 <= self.full_h):
            l, t, r, b = int(round(x1)), int(round(y1)), int(round(x1 + x2)), int(round(y1 + y2))
        else:
            l, t, r, b = int(round(x1)), int(round(y1)), int(round(x2)), int(round(y2))

        # normalize ordering
        l, r = min(l, r), max(l, r)
        t, b = min(t, b), max(t, b)
        return (l, t, r, b)

    def _rebase_and_clip_into_crop(self, rect):
        """
        Convert ORIGINAL-PIXEL rect → CROPPED coords and clip to the cropped image bounds.
        Returns (l,t,r,b) in CROPPED coords, or None if fully outside.
        """
        if self.orig_w is None or self.orig_h is None:
            # not yet sized
            h, w = self.base_raster.shape[:2]
            self.orig_h, self.orig_w = h, w

        l, t, r, b = rect
        ox, oy = self._crop_origin  # original → crop offset
        # translate into cropped space
        l -= ox
        r -= ox
        t -= oy
        b -= oy

        # clip to cropped bounds
        l = max(l, 0)
        t = max(t, 0)
        r = min(r, self.orig_w)
        b = min(b, self.orig_h)

        if l >= r or t >= b:
            return None
        return (l, t, r, b)

    # -------- Frame building & overlays --------

    def _scaled_frame(self, max_width=None, max_height=None, border=(0, 0, 0, 0)):
        """
        Build a fresh frame from base_raster, resized to fit within max_width/height,
        with a constant border. Returns (frame, sx, sy).
        sx/sy are scale factors CROPPED->DISPLAY (not original).
        """
        img = self.base_raster.copy()
        h, w = img.shape[:2]
        tw, th = w, h

        if max_height is not None and th > max_height:
            r = max_height / float(th)
            tw, th = int(tw * r), max_height
        if max_width is not None and tw > max_width:
            r = max_width / float(tw)
            tw, th = max_width, int(th * r)

        if (tw, th) != (w, h):
            img = cv2.resize(img, (tw, th), interpolation=cv2.INTER_AREA)

        sx = tw / float(self.orig_w if self.orig_w else w)
        sy = th / float(self.orig_h if self.orig_h else h)

        tb, rb, bb, lb = border
        if any(b > 0 for b in border):
            img = cv2.copyMakeBorder(img, tb, bb, lb, rb, cv2.BORDER_CONSTANT, value=[0, 0, 0])

        return img, sx, sy

    def _place_label_rect(self, dl, dt, dr, db, tw, thh, px, py, frame_w, frame_h):
        """
        Compute a label background rectangle that stays inside the frame.
        Default placement is above-left of the box. If that would overflow,
        we *realign to the box's top-right* as the primary fallback. If that
        still overflows vertically, we place it below-right.
        Returns (lx1, ly1, lx2, ly2), and the text baseline point (tx, ty).
        """
        label_w = tw + 2 * px
        label_h = thh + 2 * py

        # 1) Try default: above-left
        lx1 = dl
        lx2 = dl + label_w
        ly2 = dt
        ly1 = dt - label_h

        ok_default = (lx1 >= 0 and lx2 <= frame_w and ly1 >= 0 and ly2 <= frame_h)

        if not ok_default:
            # 2) Snap to top-right of the box
            lx2 = dr
            lx1 = max(0, lx2 - label_w)  # keep inside left edge if needed
            ly2 = dt
            ly1 = dt - label_h

            # If above goes off-screen, move to below-right
            if ly1 < 0:
                ly1 = db
                ly2 = min(frame_h, db + label_h)
                # ensure we still fit vertically
                if ly2 - ly1 < label_h:
                    # clamp inside bottom
                    ly2 = frame_h
                    ly1 = max(0, ly2 - label_h)

            # Final horizontal clamp (rare; if box near left edge and label wider)
            if lx1 < 0:
                lx1 = 0
                lx2 = min(frame_w, label_w)

        tx = lx1 + px
        ty = ly2 - py
        return (lx1, ly1, lx2, ly2), (tx, ty)

    def _draw_saved_boxes(self, frame, sx, sy, border=(0, 0, 0, 0)):
        """Draw all persisted boxes (stored in CROPPED coordinates)."""
        tb, rb, bb, lb = border
        for bx in self.boxes:
            (l, t, r, btm) = bx.rect
            dl = lb + int(round(l * sx))
            dt = tb + int(round(t * sy))
            dr = lb + int(round(r * sx))
            db = tb + int(round(btm * sy))
            cv2.rectangle(frame, (dl, dt), (dr, db), bx.color, bx.th)

            if bx.label_text:
                face, fscale, fth = bx.font
                (tw, thh), _ = cv2.getTextSize(bx.label_text, face, fscale, fth)
                px, py = 6, 6
                (lx1, ly1, lx2, ly2), (tx, ty) = self._place_label_rect(
                    dl, dt, dr, db, tw, thh, px, py, frame.shape[1], frame.shape[0]
                )
                cv2.rectangle(frame, (lx1, ly1), (lx2, ly2), bx.color, -1)
                cv2.putText(frame, bx.label_text, (tx, ty), face, fscale, (0, 0, 0), fth, cv2.LINE_AA)

    def _draw_preview(self, frame, border=(0, 0, 0, 0)):
        """Draw the preview rectangle (in DISPLAY coords) while dragging."""
        if self.preview:
            tb, rb, bb, lb = border
            l, t, r, b = self.preview
            cv2.rectangle(frame, (lb + l, tb + t), (lb + r, tb + b), (0, 255, 0), 2)

    # -------- Mouse callback for interactive drawing --------

    def draw_obj(self, event, x, y, flags, param):
        """
        Mouse callback used by ViewerCV2. All coords here are in DISPLAY space
        (including borders). We translate to display-image coords and track a live
        preview; on mouse-up we commit to CROPPED coords and clamp to bounds.
        """
        tb, rb, bb, lb = param['border']
        sx, sy = param['sx'], param['sy']

        # remove border offsets → display image coords (cropped-space)
        x_adj = max(x - lb, 0)
        y_adj = max(y - tb, 0)

        viewer = param.get('viewer')
        tool = viewer.selected_tool

        if event == cv2.EVENT_LBUTTONDOWN:

            if isinstance(tool, LabelTool):
                cx = int(round(x_adj / sx))
                cy = int(round(y_adj / sy))
                for idx in range(len(self.boxes) - 1, -1, -1):
                    box = self.boxes[idx]
                    l, t, r, btm = box.rect

                    # if you clicked inside a the box
                    if l <= cx <= r and t <= cy <= btm:
                        if tool.append:
                            box.labels[tool.category] = tool.text
                            label_color = box.color
                        else:
                            box.labels = {tool.category: tool.text}
                            label_color = tool.color

                        box.color = label_color

                        # Allows user to keep track of changes
                        box.status = DrawnObjStatus.EDITED

                        self.preview = None
                        self.drawing = False
                        return

            elif isinstance(tool, BaseTool) and tool.name == 'delete':
                # convert click from display to CROPPED coords
                cx = int(round(x_adj / sx))
                cy = int(round(y_adj / sy))
                # delete topmost (iterate reversed)
                for idx in range(len(self.boxes) - 1, -1, -1):
                    l, t, r, btm = self.boxes[idx].rect
                    if l <= cx <= r and t <= cy <= btm:
                        deleted = self.boxes.pop(idx)
                        # Add to deleted boxes, will keep track of deletion order
                        # Don't set status here, original status may be needed
                        # To restore deleted box in ViewerCV2.show
                        self.deleted_boxes.append(deleted)
                        break
                self.preview = None
                self.drawing = False
                return

            self.drawing = True
            self.ix, self.iy = x_adj, y_adj
            self.preview = (self.ix, self.iy, self.ix, self.iy)

        elif event == cv2.EVENT_MOUSEMOVE and self.drawing:

            if isinstance(tool, (DrawTool, LabelAndDrawTool)):
                self.preview = (self.ix, self.iy, x_adj, y_adj)

        elif event == cv2.EVENT_LBUTTONUP:
            # If delete tool is active, do not commit drawings
            if tool.name == 'delete' or not self.drawing:
                self.drawing = False
                self.preview = None
                return

            self.drawing = False
            self.preview = (self.ix, self.iy, x_adj, y_adj)

            dl, dt, dr, db = self.preview
            # DISPLAY → CROPPED coords
            l = int(round(min(dl, dr) / sx))
            r = int(round(max(dl, dr) / sx))
            t = int(round(min(dt, db) / sy))
            b = int(round(max(dt, db) / sy))

            # clamp to cropped image bounds
            l = max(l, 0)
            t = max(t, 0)
            r = min(r, self.orig_w)
            b = min(b, self.orig_h)

            if l < r and t < b:
                # Assign label/color from the active label tool (if any)
                if isinstance(tool, LabelAndDrawTool):
                    self.boxes.append(
                        DrawnBox(
                            rect=(l, t, r, b),
                            labels={tool.category: tool.text},
                            color=tool.color,
                            status=DrawnObjStatus.NEW
                        ))

            self.preview = None

    def set_callback(self, win_name, param):
        cv2.setMouseCallback(
            win_name,
            self.draw_obj,
            param=param
        )


# -----------------------------
# ViewerCV2
# -----------------------------

class ViewerCV2:
    """
    A simple image carousel that renders real-time overlays, remembers per-image
    flags & boxes, supports fullscreen, header/footer, and legend.
    """

    def __init__(self, images=None, 
                 title="Image Viewer", 
                 preload=False,
                 fullscreen=False,
                 max_width=None, 
                 max_height=None,
                 header=None, 
                 legend=None, 
                 footer=None,
                 custom_tools=None):
        
        if not images:
            # TODO: thrown an error
            return False

        self.images = []
        for i in images:
            if isinstance(i, ImageCV2):
                self.images.append(i)
            elif isinstance(i, str) and not is_corrupt(i):
                self.images.append(ImageCV2(filepath=i))

        self.title = title

        # Prevent a blank Tk window from flashing just to get screen size
        tk = tkinter.Tk()
        tk.withdraw()
        self.s_width, self.s_height = tk.winfo_screenwidth(), tk.winfo_screenheight()
        tk.destroy()

        self.fullscreen = fullscreen
        self.max_height = max_height
        self.max_width = max_width
        
        self.header = header
        self.legend = legend
        self.footer = footer

        # layout
        self.border = (0, 0, 0, 0)  # (top, right, bottom, left)

        self._delete_keycodes = {8, 127, 65288}
        self.tools = [BaseTool('delete', self._delete_keycodes)]

        # should perform check for uniqueness
        if custom_tools:
            self.tools.extend(custom_tools)

        self.tool_ref = {}
        for tool in self.tools:
            for keycode in tool.keycodes:
                self.tool_ref[keycode] = tool

        self.selected_tool = None

        if preload:
            for im in self.images:
                if getattr(im, "base_raster", None) is None:
                    im.load()

        # window setup
        cv2.namedWindow(self.title, cv2.WINDOW_NORMAL)
        if self.fullscreen:
            cv2.setWindowProperty(self.title, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)


    def _render_frame(self, index, drawing=False):
        tb, rb, bb, lb = self.border

        image: ImageCV2 = self.images[index]

        if getattr(image, "base_raster", None) is None:
                image.load()

        # dynamic padding for UI regions
        tb_eff, rb_eff, bb_eff, lb_eff = tb, rb, bb, lb
        if self.header is not None: tb_eff += 50
        if self.legend is not None: rb_eff += 300
        if self.footer is not None: bb_eff += 50

        border_eff = (tb_eff, rb_eff, bb_eff, lb_eff)

        # base frame and scale factors (CROPPED->DISPLAY)
        base_frame, sx, sy = image._scaled_frame(
            max_width=min(self.max_width or self.s_width, self.s_width) - (lb_eff + rb_eff),
            max_height=min(self.max_height or self.s_height, self.s_height) - (tb_eff + bb_eff),
            border=border_eff
        )

        frame = base_frame.copy()

        # header text (basename/counter)
        if self.header is not None and ("basename" in self.header or "counter" in self.header):
            font = cv2.FONT_HERSHEY_SIMPLEX
            text = ""
            if "basename" in self.header:
                text += f"{image.basename} "
            if "counter" in self.header:
                text += f"{index + 1}/{len(self.images)}"
            cv2.putText(frame, text, (lb_eff, 40), font, 1, (255, 0, 255), 2)

        if self.footer:
            # if "flags" in footer:
            #     font = cv2.FONT_HERSHEY_SIMPLEX
            #     txt = f"Flags: {image.flags}"
            #     cv2.putText(frame, txt, (lb_eff, frame.shape[0] - 25), font, 1, (255, 0, 255), 2)
            if "tools" in self.footer:
                tool_name = 'none' if not self.selected_tool else self.selected_tool.name
                tool_txt = f"Tool: {tool_name or 'none'}"
                cv2.putText(frame, tool_txt, (lb_eff + 320, frame.shape[0] - 25), font, 1, (255, 255, 255), 2)

        return image, frame, border_eff, sx, sy


    def show(self, entry_point=None):

        index = (entry_point - 1) if (entry_point is not None and entry_point <= len(self.images)) else 0
        if index < 0: index = 0

        while 0 <= index < len(self.images):
            
            image, frame, border_eff, sx, sy = self._render_frame(index)

            callback_param = {'sx': sx, 'sy': sy, 'border': border_eff,
                                'viewer': self}
            image.set_callback(self.title, param=callback_param)

            while True:
                # persistent overlays + live preview
                image._draw_saved_boxes(frame, sx, sy, border=border_eff)
                image._draw_preview(frame, border=border_eff)
                

                cv2.imshow(self.title, frame)
                k = cv2.waitKeyEx(20) & 0xFFFFFFFF
                image.last_viewed = get_time()

                # ESC = quit
                if k == 27:
                    # TODO: ensure that closing window other ways does the same
                    # right now, closing with a click opens another window with next image
                    cv2.destroyAllWindows()
                    return
                # left/right arrows
                elif k == 2424832:  # left
                    index = (index - 1) % len(self.images)
                    break
                elif k == 2555904:  # right
                    index = (index + 1) % len(self.images)
                    break

                if k in self.tool_ref:
                    self.selected_tool = self.tool_ref[k]
                    callback_param['tool'] = self.selected_tool

                # this will be overwritten if user adds a tool with keycode in {'z', 'Z'}
                elif k in (ord('z'), ord('Z')) and image.deleted_boxes:
                    box = image.deleted_boxes.pop()
                    image.boxes.append(box)

                # elif ch in image.flags:
                #     image.flags.remove(ch)
                # else:
                #     image.flags.append(ch)

    def timelapse(self, interval:float=2.0):
        index = 0
        paused = False

        while 0 <= index < len(self.images):
            image, frame, border_eff, sx, sy = self._render_frame(index)
                
            cv2.imshow(self.title, frame)
            k = cv2.waitKeyEx(20) & 0xFFFFFFFF

            # ESC = quit
            if k == 27:
                # TODO: ensure that closing window other ways does the same
                # right now, closing with a click opens another window with next image
                cv2.destroyAllWindows()
                return
            # SPACE = pause
            if k == 32:
                paused = True if not paused else False
            # left/right arrows
            if k == 2424832:  # left
                index = (index - 1) % len(self.images)
                break
            if k == 2555904:  # right
                index = (index + 1) % len(self.images)
                break
            
            if not paused:
                time.sleep(interval)

                index += 1
                
