import uuid
import os
import json
import csv
import io
import re
import codecs
from typing import Any, Dict, Iterable, List, Sequence, Union
from collections import defaultdict
from collections.abc import Mapping
from sqlalchemy import case, func, cast, Integer, delete, insert


def generate_guid(as_uuid: bool = True) -> uuid.UUID | str:
    """Generate a UUID4 identifier.

    Parameters
    ----------
    as_uuid: bool, optional
        When ``True`` (the default) return a :class:`uuid.UUID` instance. Passing
        ``False`` returns the canonical string representation instead.

    Returns
    -------
    uuid.UUID | str
        A UUID object or string representation depending on ``as_uuid``.
    """
    ident = uuid.uuid4()

    return ident if as_uuid else str(ident)

class CsvLoadResult:
    """CSV data wrapper that preserves backward-compatible behaviour."""

    def __init__(
        self,
        rows: list[dict[str, Any]] | None = None,
        errors: list[str] | None = None,
        encoding: str | None = None,
        dialect: csv.Dialect | None = None,
    ) -> None:
        self.rows = rows or []
        self.errors = errors or []
        self.encoding = encoding
        self.dialect = dialect

    def __iter__(self):
        return iter(self.rows)

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, item):
        return self.rows[item]

    def __bool__(self):
        return bool(self.rows) and not self.errors


def _detect_encoding(raw_bytes: bytes, fallback: str = "utf-8-sig") -> str:
    if raw_bytes.startswith(codecs.BOM_UTF8):
        return "utf-8-sig"

    for enc in ("utf-8", fallback, "latin-1"):
        try:
            raw_bytes.decode(enc)
            return enc
        except UnicodeDecodeError:
            continue

    return fallback


def _detect_dialect(sample: str):
    try:
        return csv.Sniffer().sniff(sample)
    except csv.Error:
        return csv.excel


def load_csv(from_path: str = None, from_storage=None, *, encoding: str | None = None, dialect=None) -> CsvLoadResult:
    raw_bytes: bytes | None = None
    errors: list[str] = []

    if from_path is not None and os.path.isfile(from_path):
        try:
            with open(from_path, "rb") as f:
                raw_bytes = f.read()
        except OSError as exc:
            errors.append(f"Could not open CSV file: {exc}")
    elif from_storage is not None:
        filename = getattr(from_storage, "filename", "") or ""
        if not filename.lower().endswith(".csv"):
            errors.append("Uploaded file is not a CSV.")
        try:
            raw_bytes = from_storage.read()
        except Exception as exc:  # pylint: disable=broad-except
            errors.append(f"Could not read uploaded file: {exc}")
        try:
            from_storage.stream.seek(0)
        except Exception:  # pragma: no cover - best effort reset
            pass
    else:
        errors.append("No CSV source provided.")

    if raw_bytes is None:
        return CsvLoadResult([], errors, encoding, dialect)

    encoding = encoding or _detect_encoding(raw_bytes)
    try:
        text = raw_bytes.decode(encoding)
    except UnicodeDecodeError:
        fallback = "utf-8-sig"
        try:
            text = raw_bytes.decode(fallback)
            encoding = fallback
        except UnicodeDecodeError as exc:
            errors.append(f"Failed to decode CSV with encoding {encoding}: {exc}")
            return CsvLoadResult([], errors, encoding, dialect)

    sample = text[:4096]
    if dialect is None:
        dialect = _detect_dialect(sample)

    reader = csv.DictReader(io.StringIO(text), dialect=dialect)
    result: list[dict[str, Any]] = []
    try:
        for row in reader:
            result.append(row)
    except csv.Error as exc:
        errors.append(f"CSV parsing error: {exc}")

    return CsvLoadResult(result, errors, encoding, dialect)

def load_json(filepath):
    if os.path.isfile(filepath) and filepath.endswith(".json"):
        with open(filepath) as f:
            return json.load(f)
    return False

def save_csv(data, fieldnames, dir_name=os.getcwd(), filename="output.csv", overwrite=False) -> bool:
    fullpath = os.path.join(dir_name, filename)
    result = []
    if os.path.exists(fullpath) and not overwrite:
        print(f"Error: could not save data to {dir_name}: {filename} already exists.")
        return False
    for row in data:
        result.append(row)
    try:
        with open(fullpath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(result)
        return True
    except Exception as e:
        print(f"Failed to save {filename}: {e}")
        return False


def dump_csv(rows: Iterable[Mapping[str, Any]], fieldnames: Sequence[str], stream: bool = False, *, encoding: str = "utf-8", dialect: str | csv.Dialect = "excel"):
    """Serialize rows into CSV output.

    When ``stream`` is True, yields encoded CSV chunks suitable for streaming
    responses (e.g., Flask). Otherwise returns a string containing the full CSV
    document.
    """

    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=fieldnames, dialect=dialect)
    writer.writeheader()

    if stream:
        yield buffer.getvalue().encode(encoding)
        buffer.seek(0)
        buffer.truncate(0)

        for row in rows:
            writer.writerow(row)
            yield buffer.getvalue().encode(encoding)
            buffer.seek(0)
            buffer.truncate(0)
    else:
        for row in rows:
            writer.writerow(row)
        return buffer.getvalue()

def group_by_value(list_of_dicts, key):
    result = defaultdict(list)
    for d in list_of_dicts:
        result[d[key]].append(d)
    return dict(result)

def value_from_dict(data: dict, keys=None):
    if not isinstance(data, dict) or not keys:
        return None

    current = data
    for key in keys:
        if not isinstance(current, dict) or key not in current:
            return None
        current = current[key]
    return current

def natural_sort(column, order="asc"):
    """Sorts text naturally, considering both prefix and numeric value separately."""

    # Extract prefix (everything before the first number)
    prefix_part = func.regexp_replace(column, r'[0-9].*', '', 'g')

    # Extract numeric portion (digits only), NULL if no number exists
    numeric_part = func.nullif(func.regexp_replace(column, r'[^0-9]', '', 'g'), '')

    # Cast numeric part to Integer only if it exists
    numeric_value = case(
        (numeric_part.isnot(None), cast(numeric_part, Integer)),
        else_=None  # Avoids type errors
    )

    # Ensure sorting follows: 1) Prefix (A-Z), 2) Number (1, 2, 10)
    if order == "asc":
        return prefix_part.asc(), numeric_value.asc().nullsfirst()
    else:
        return prefix_part.desc(), numeric_value.desc().nullslast()
    
def group_form_rows(
    form_data: Mapping[str, Any],
    prefixes: Union[str, Sequence[str]]
) -> List[Dict[str, Any]]:
    """
    Group flat form fields like '<prefix>-<index>-<field>' into row dicts.

    - form_data: `request.form` (ImmutableMultiDict) or any dict-like mapping.
    - prefixes: a single prefix (e.g. 'transactions') or a list/tuple of acceptable
      prefixes if your keys vary (e.g. ('transaction', 'transactions')).
    - keep_empty: keep rows whose fields are all empty/blank (default False).

    Returns a list sorted by the numeric index: [{field: value, ...}, ...]
    Handles repeated fields (checkboxes) by collecting values into lists.
    """

    # Build a pattern that accepts one or more prefixes
    if isinstance(prefixes, str):
        prefixes = (prefixes,)
    prefix_alt = "|".join(map(re.escape, prefixes))
    pattern = re.compile(rf"^(?:{prefix_alt})-(\d+)-(.+)$")

    # Normalize items: MultiDict -> (key, value) pairs for *each* value
    def iter_items(fd: Mapping[str, Any]) -> Iterable[tuple[str, Any]]:

        # Regular mapping: emit single pair per key
        for key, value in fd.items():
            # If value is a list already (e.g., from non-MultiDict sources), emit each
            if isinstance(value, list):
                for v in value:
                    yield key, v
            else:
                yield key, value

    rows: Dict[int, Dict[str, Any]] = {}

    for key, value in iter_items(form_data):
        m = pattern.match(key)
        if not m:
            continue
        idx = int(m.group(1))
        field = m.group(2)

        bucket = rows.setdefault(idx, {})
        if field in bucket:
            # Collect repeated fields (e.g., checkboxes) into lists
            prev = bucket[field]
            if isinstance(prev, list):
                prev.append(value)
            else:
                bucket[field] = [prev, value]
        else:
            bucket[field] = value

    # Sort by index and optionally drop all-empty rows
    return [rows[i] for i in sorted(rows)]

def first_index_of_dict_item(data_list: list[dict], key_to_match, value_to_match):
    """
    Returns the index of the first dictionary from a list where a specific 
    key's value matches the target value.
    """
    # Iterate through the list with index and value
    for index, d in enumerate(data_list):
        # Check if the dictionary contains the key and if the value matches
        if d.get(key_to_match) == value_to_match:
            # Return index and return it
            return index
    
    # If no matching dictionary is found, return None
    return None

def pop_dict_items_by_value(data_list: list[dict], key_to_match, values_to_match: list[str]):

    for value in values_to_match:
        index = first_index_of_dict_item(data_list, key_to_match, value)
        if index is not None and data_list[index]:
            data_list.pop(index)

    # return data_list