from datetime import datetime
import importlib
import pkgutil
import sys
from typing import Type, List

def get_time(fmt="%Y-%m-%d %H:%M:%S"):
    return datetime.now().strftime(fmt)

def check_input(i):
    if i.lower() == "n":
        return False
    elif i.lower() == "y":
        return True
    else:
        print(f"Input {i} is not a valid option")
        return None

def input_to_continue():
    prompt = "Continue? (y/n) "
    advance = input(prompt)
    test = check_input(advance)
    while test is None:
        advance = input(prompt)
        test = check_input(advance)
    return check_input(advance)

def import_all_modules_from_package(package_name: str):
    """
    Import all modules from a package dynamically.

    Args:
        package_name (str): The package name (e.g., "wild_data.modules").
    """
    try:
        package = importlib.import_module(package_name)
    except ImportError:
        return

    if hasattr(package, "__path__"):
        for _, module_name, _ in pkgutil.walk_packages(package.__path__, package.__name__ + "."):
            if module_name not in sys.modules:
                try:
                    importlib.import_module(module_name)
                except ImportError:
                    pass  # Ignore import errors


def get_all_subclasses(cls: Type) -> List[Type]:
    """
    Recursively retrieve all subclasses of a given class.

    Args:
        cls (Type): The base class.

    Returns:
        List[Type]: A list of all subclasses found.
    """
    subclasses = set(cls.__subclasses__())
    all_subclasses = list(subclasses)

    for subclass in subclasses:
        all_subclasses.extend(get_all_subclasses(subclass))

    return all_subclasses


def find_all_subclasses_in_project(base_class: Type, package_name: str = "wild_data.modules") -> List[Type]:
    """
    Ensure all modules are imported and return all subclasses of the base class.

    Args:
        base_class (Type): The base class to find subclasses for.
        package_name (str): The package containing the modules.

    Returns:
        List[Type]: A list of subclasses found.
    """
    import_all_modules_from_package(package_name)  # Load all modules dynamically
    return get_all_subclasses(base_class)


def get_table_names_of_all_subclasses(base_class):
    # Find all subclasses, including Species, Observations, etc.
    all_model_classes = find_all_subclasses_in_project(base_class)
    # Extract __tablename__ if it exists
    table_names = {
        cls.__name__: getattr(cls, "__tablename__", None) for cls in all_model_classes
    }

    return [table_name for _, table_name in table_names.items() if table_name]
