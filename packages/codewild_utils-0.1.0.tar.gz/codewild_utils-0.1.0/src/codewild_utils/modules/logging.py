import logging
from tqdm import tqdm


def configure_logger(name: str = "app_logger") -> logging.Logger:
    """Set up and return a configured logger instance."""

    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    detailed_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    simple_format = "%(levelname)s - %(message)s"

    formatter = logging.Formatter(simple_format)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    if not any(isinstance(handler, logging.StreamHandler) for handler in logger.handlers):
        logger.addHandler(console_handler)

    return logger

def custom_tqdm(iterable) -> tqdm:
    return tqdm(iterable=iterable)