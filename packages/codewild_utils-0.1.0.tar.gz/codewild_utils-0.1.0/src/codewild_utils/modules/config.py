from __future__ import annotations

import importlib
import os
from functools import lru_cache
from pathlib import Path
from typing import Union
import tomllib
from .data import value_from_dict


PathType = Union[str, os.PathLike[str]]

def get_module_path(package:str, dirname:bool=False) -> str:
    module = importlib.import_module(package)
    module_path = Path(module.__file__).resolve()
    if dirname:
        return os.path.dirname(module_path)
    return module_path


def _normalize_path(filepath: PathType) -> str:
    """Return a canonical, absolute path for caching purposes."""
    return str(Path(filepath).expanduser().resolve()) 


def _default_package_config_path(package: str) -> str:
    module_path = get_module_path(package=package)
    for base in module_path.parents:
        candidate = base / "config.toml"
        if candidate.exists():
            return str(candidate)

        example = base / "config.toml.example"
        if example.exists():
            return str(example)

    raise FileNotFoundError(
        f"Could not locate a config.toml for package '{package}'. Searched ancestors of"
        f" {module_path}."
    )


@lru_cache(maxsize=None)
def _load_config_from_path(filepath: str) -> "Config":
    return Config(filepath)


def load_config(*, filepath: PathType | None = None, package: str | None = None) -> "Config":
    """Return a cached configuration object.

    Args:
        filepath: Explicit path to a configuration file.
        package: Package name to derive a default ``config.toml`` path from.

    A path provided via the ``APP_CONFIG_FILE`` environment variable is used if
    neither ``filepath`` nor ``package`` are provided.
    """

    if filepath and package:
        raise ValueError("Specify either 'filepath' or 'package', not both.")

    if filepath is not None:
        resolved_path = _normalize_path(filepath)
    else:
        env_override = os.getenv("APP_CONFIG_FILE")
        if env_override:
            resolved_path = _normalize_path(env_override)
        elif package is not None:
            resolved_path = _normalize_path(_default_package_config_path(package))
        else:
            raise ValueError(
                "Unable to resolve configuration path. Provide 'filepath', set "
                "'APP_CONFIG_FILE', or supply a package name."
            )

    return _load_config_from_path(resolved_path)


class Config:
    """Base configuration with default settings."""

    def __init__(self, filepath: PathType):

        self._filepath = _normalize_path(filepath)

        with open(self._filepath, "rb") as f:
            self.dict = tomllib.load(f)

        self.PROJECT_ROOT = value_from_dict(self.dict, ['project', 'root'])

        self.SECRET_KEY = value_from_dict(self.dict, ['app', 'secret-key'])
        self.ENVIRONMENT = value_from_dict(self.dict, ['app', 'environment'])
        self.PORT = value_from_dict(self.dict, ['app', 'port'])

        self.DB_HOST = value_from_dict(self.dict, ['connection', 'host'])
        self.DB_PORT = value_from_dict(self.dict, ['connection', 'port'])
        self.DB_USER = value_from_dict(self.dict, ['connection', 'user'])
        self.DB_NAME = value_from_dict(self.dict, ['connection', 'name'])
        self.DB_PASSWORD = value_from_dict(self.dict, ['connection', 'password'])
        
        self.SQLALCHEMY_DATABASE_URI = (
            f"postgresql://{self.DB_USER}:{self.DB_PASSWORD}"
            f"@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"
        )

        if self.ENVIRONMENT == 'development':
            self.DEBUG = True
        elif self.ENVIRONMENT == 'production':
            self.DEBUG = False
            self.SQLALCHEMY_TRACK_MODIFICATIONS = False

        
    @staticmethod
    def validate(self):
        """Log warnings if critical configurations are missing."""
        if not self.SQLALCHEMY_DATABASE_URI:
            print("Warning: SQLALCHEMY_DATABASE_URI is not set.")

