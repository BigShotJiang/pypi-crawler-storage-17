msg = "Hello from mypip!"

__all__ = ["msg"]
