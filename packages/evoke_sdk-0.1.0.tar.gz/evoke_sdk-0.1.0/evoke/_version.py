"""
Evoke SDK version information
"""

__version__ = "0.1.0"
SDK_VERSION = __version__
