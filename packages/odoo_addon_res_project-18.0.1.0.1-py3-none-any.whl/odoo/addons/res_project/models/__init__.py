# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import hr_department
from . import hr_employee_base
from . import res_project_plan
from . import res_project
