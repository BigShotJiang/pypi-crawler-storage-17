# Usage in Subscription

With this report, vendor and providers can know if usage reporting has happened for a given period 
of time on their active subscriptions.

Report provides listing of all active subscriptions, data about the tiers involved in the subscription,
and the list of usage files that subscription had been included to report usage.

Report can be filtered by:

* Products
* Date range relative to usage reporting
