from __future__ import annotations

from logging import getLogger

LOGGER = getLogger("setup_cronjob")


__all__ = ["LOGGER"]
