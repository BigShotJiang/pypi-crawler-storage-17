{{ fullname | escape | underline }}

.. currentmodule:: {{ module }}

.. automethod:: {{ objname }}