
Stats: statistics
-----------------

Utilities for calculating statistics about genomic intervals.

.. automodule:: pyranges.stats
    :members:
    :imported-members:

