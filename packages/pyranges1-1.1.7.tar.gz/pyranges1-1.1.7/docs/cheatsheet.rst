
Cheatsheet
~~~~~~~~~~
Here's a cheatsheet for Pyranges, summarizing the most common operations.

.. image:: https://raw.githubusercontent.com/pyranges/pyrangeyes/for_pyranges1_1/images/pyranges_cheatsheet.png
   :alt: Pyranges cheatsheet
   :target: https://raw.githubusercontent.com/pyranges/pyrangeyes/for_pyranges1_1/images/pyranges_cheatsheet.png
