"""
LLMClientBase - LLM 客户端抽象基类

提供通用的方法实现，子类只需实现核心的差异化方法。
"""

import asyncio
import json
import time
from abc import ABC
from pathlib import Path
from typing import TYPE_CHECKING, List, Union, Optional, Any

from loguru import logger

from maque import ConcurrentRequester
from .processors.image_processor import ImageCacheConfig
from .processors.messages_processor import messages_preprocess
from .processors.unified_processor import batch_process_messages as optimized_batch_preprocess
from .response_cache import ResponseCache, ResponseCacheConfig

if TYPE_CHECKING:
    from maque.async_api.interface import RequestResult


class LLMClientBase(ABC):
    """
    LLM 客户端抽象基类

    子类只需实现 4 个核心方法：
    - _get_url(model, stream) -> str
    - _get_headers() -> dict
    - _build_request_body(messages, model, **kwargs) -> dict
    - _extract_content(response_data) -> str

    可选覆盖：
    - _extract_stream_content(data) -> str
    - _get_stream_url(model) -> str
    """

    def __init__(
        self,
        base_url: str = None,
        api_key: str = None,
        model: str = None,
        concurrency_limit: int = 10,
        max_qps: int = 1000,
        timeout: int = 120,
        retry_times: int = 3,
        retry_delay: float = 1.0,
        cache_image: bool = False,
        cache_dir: str = "image_cache",
        cache: Optional[ResponseCacheConfig] = None,
        **kwargs,
    ):
        """
        Args:
            base_url: API 基础 URL
            api_key: API 密钥
            model: 默认模型名称
            concurrency_limit: 并发请求数限制
            max_qps: 最大 QPS
            timeout: 请求超时时间（秒）
            retry_times: 重试次数
            retry_delay: 重试延迟（秒）
            cache_image: 是否缓存图片
            cache_dir: 图片缓存目录
            cache: 响应缓存配置，默认启用（24小时TTL）。
                   使用 ResponseCacheConfig.disabled() 禁用，
                   使用 ResponseCacheConfig.persistent() 永不过期
        """
        self._base_url = base_url.rstrip("/") if base_url else None
        self._api_key = api_key
        self._model = model
        self._concurrency_limit = concurrency_limit
        self._timeout = timeout

        self._client = ConcurrentRequester(
            concurrency_limit=concurrency_limit,
            max_qps=max_qps,
            timeout=timeout,
            retry_times=retry_times,
            retry_delay=retry_delay,
        )

        self._cache_config = ImageCacheConfig(
            enabled=cache_image,
            cache_dir=cache_dir,
            force_refresh=False,
            retry_failed=False,
        )

        # 响应缓存：默认启用（24小时TTL）
        if cache is None:
            cache = ResponseCacheConfig.default()
        self._response_cache = ResponseCache(cache) if cache.enabled else None

    # ========== 核心抽象方法（子类必须实现）==========

    def _get_url(self, model: str, stream: bool = False) -> str:
        raise NotImplementedError

    def _get_headers(self) -> dict:
        raise NotImplementedError

    def _build_request_body(
        self, messages: List[dict], model: str, stream: bool = False, **kwargs
    ) -> dict:
        raise NotImplementedError

    def _extract_content(self, response_data: dict) -> Optional[str]:
        raise NotImplementedError

    # ========== 可选覆盖的钩子方法 ==========

    def _extract_stream_content(self, data: dict) -> Optional[str]:
        return self._extract_content(data)

    def _get_stream_url(self, model: str) -> str:
        return self._get_url(model, stream=True)

    # ========== 通用工具方法 ==========

    def _get_effective_model(self, model: str = None) -> str:
        effective_model = model or self._model
        if not effective_model:
            raise ValueError("必须提供 model 参数或在初始化时指定 model")
        return effective_model

    async def _preprocess_messages(
        self, messages: List[dict], preprocess_msg: bool = False
    ) -> List[dict]:
        """消息预处理（图片转 base64 等）"""
        if preprocess_msg:
            return await messages_preprocess(
                messages, preprocess_msg=preprocess_msg, cache_config=self._cache_config
            )
        return messages

    async def _preprocess_messages_batch(
        self, messages_list: List[List[dict]], preprocess_msg: bool = False
    ) -> List[List[dict]]:
        """批量消息预处理"""
        if preprocess_msg:
            return await optimized_batch_preprocess(
                messages_list, max_concurrent=self._concurrency_limit, cache_config=self._cache_config
            )
        return messages_list

    # ========== 通用接口实现 ==========

    async def chat_completions(
        self,
        messages: List[dict],
        model: str = None,
        return_raw: bool = False,
        show_progress: bool = False,
        preprocess_msg: bool = False,
        url: str = None,
        use_cache: bool = True,
        **kwargs,
    ) -> Union[str, "RequestResult"]:
        """
        单条聊天完成

        Args:
            messages: 消息列表
            model: 模型名称
            return_raw: 是否返回原始响应
            show_progress: 是否显示进度条
            preprocess_msg: 是否预处理消息
            url: 自定义请求 URL，默认使用 _get_url() 生成
            use_cache: 是否使用缓存，默认 True
        """
        effective_model = self._get_effective_model(model)
        messages = await self._preprocess_messages(messages, preprocess_msg)

        # 检查缓存
        if use_cache and self._response_cache and not return_raw:
            cached = self._response_cache.get(messages, model=effective_model, **kwargs)
            if cached is not None:
                return cached

        body = self._build_request_body(messages, effective_model, stream=False, **kwargs)
        request_params = {"json": body, "headers": self._get_headers()}
        effective_url = url or self._get_url(effective_model, stream=False)

        results, _ = await self._client.process_requests(
            request_params=[request_params], url=effective_url, method="POST", show_progress=show_progress
        )

        data = results[0]
        if return_raw:
            return data
        if data.status == "success":
            content = self._extract_content(data.data)
            # 写入缓存
            if use_cache and self._response_cache and content is not None:
                self._response_cache.set(messages, content, model=effective_model, **kwargs)
            return content
        return data

    def chat_completions_sync(
        self, messages: List[dict], model: str = None, return_raw: bool = False, **kwargs
    ) -> Union[str, "RequestResult"]:
        """同步版本的聊天完成"""
        return asyncio.run(
            self.chat_completions(messages=messages, model=model, return_raw=return_raw, **kwargs)
        )

    async def chat_completions_batch(
        self,
        messages_list: List[List[dict]],
        model: str = None,
        return_raw: bool = False,
        show_progress: bool = True,
        return_summary: bool = False,
        preprocess_msg: bool = False,
        use_cache: bool = True,
        output_file: Optional[str] = None,
        flush_interval: float = 1.0,
        url: str = None,
        **kwargs,
    ) -> Union[List[str], tuple]:
        """
        批量聊天完成（支持断点续传）

        Args:
            messages_list: 消息列表
            model: 模型名称
            return_raw: 是否返回原始响应
            show_progress: 是否显示进度条
            return_summary: 是否返回执行摘要
            preprocess_msg: 是否预处理消息
            use_cache: 是否使用缓存（断点续传）
            output_file: 输出文件路径（JSONL 格式），用于持久化保存结果
            flush_interval: 文件刷新间隔（秒），默认 1 秒
            url: 自定义请求 URL，默认使用 _get_url() 生成
        """
        effective_model = self._get_effective_model(model)
        effective_url = url or self._get_url(effective_model, stream=False)
        headers = self._get_headers()

        messages_list = await self._preprocess_messages_batch(messages_list, preprocess_msg)

        def extractor(result):
            return self._extract_content(result.data)

        # 文件输出相关状态
        file_writer = None
        file_buffer = []
        last_flush_time = time.time()
        completed_indices = set()

        # 如果指定了输出文件，读取已完成的索引（断点续传）
        if output_file:
            output_path = Path(output_file)
            if output_path.exists():
                # 读取所有有效记录
                records = []
                with open(output_path, "r", encoding="utf-8") as f:
                    for line in f:
                        try:
                            record = json.loads(line.strip())
                            if record.get("status") == "success" and "input" in record:
                                idx = record.get("index")
                                if 0 <= idx < len(messages_list):
                                    records.append(record)
                        except (json.JSONDecodeError, KeyError, TypeError):
                            continue

                # 首尾校验：只比较第一条和最后一条的 input
                file_valid = True
                if records:
                    first, last = records[0], records[-1]
                    if first["input"] != messages_list[first["index"]]:
                        file_valid = False
                    elif len(records) > 1 and last["input"] != messages_list[last["index"]]:
                        file_valid = False

                if file_valid:
                    completed_indices = {r["index"] for r in records}
                    if completed_indices:
                        logger.info(f"从文件恢复: 已完成 {len(completed_indices)}/{len(messages_list)}")
                else:
                    raise ValueError(
                        f"文件校验失败: {output_file} 中的 input 与当前 messages_list 不匹配。"
                        f"请删除或重命名该文件后重试。"
                    )

            file_writer = open(output_path, "a", encoding="utf-8")

        def flush_to_file():
            """刷新缓冲区到文件"""
            nonlocal file_buffer, last_flush_time
            if file_writer and file_buffer:
                for record in file_buffer:
                    file_writer.write(json.dumps(record, ensure_ascii=False) + "\n")
                file_writer.flush()
                file_buffer = []
                last_flush_time = time.time()

        def on_file_result(original_idx: int, content: Any, status: str = "success", error: str = None):
            """文件输出回调"""
            nonlocal last_flush_time
            if file_writer is None:
                return
            record = {
                "index": original_idx,
                "output": content,
                "status": status,
                "input": messages_list[original_idx],
            }
            if error:
                record["error"] = error
            file_buffer.append(record)
            # 基于时间刷新
            if time.time() - last_flush_time >= flush_interval:
                flush_to_file()

        try:
            # 计算实际需要执行的索引（排除文件中已完成的）
            all_indices = set(range(len(messages_list)))
            indices_to_skip = completed_indices & all_indices
            if indices_to_skip:
                logger.info(f"从文件恢复跳过: {len(indices_to_skip)}/{len(messages_list)}")

            # 带缓存执行
            if use_cache and self._response_cache:
                # 查询缓存（传递 kwargs 以确保不同参数配置使用不同缓存键）
                cached_responses, uncached_indices = self._response_cache.get_batch(
                    messages_list, model=effective_model, **kwargs
                )

                # 将缓存命中的写入文件（如果文件中没有）
                for i, resp in enumerate(cached_responses):
                    if resp is not None and i not in completed_indices:
                        on_file_result(i, resp)

                # 过滤掉文件中已完成的
                actual_uncached = [i for i in uncached_indices if i not in completed_indices]

                progress = None
                if actual_uncached:
                    logger.info(f"待执行: {len(actual_uncached)}/{len(messages_list)}")

                    uncached_messages = [messages_list[i] for i in actual_uncached]
                    request_params = [
                        {"json": self._build_request_body(m, effective_model, **kwargs), "headers": headers}
                        for m in uncached_messages
                    ]

                    async for batch in self._client.aiter_stream_requests(
                        request_params=request_params,
                        url=effective_url,
                        method="POST",
                        show_progress=show_progress,
                        total_requests=len(uncached_messages),
                    ):
                        for result in batch.completed_requests:
                            original_idx = actual_uncached[result.request_id]
                            try:
                                content = extractor(result)
                                cached_responses[original_idx] = content
                                # 写入缓存（传递 kwargs 保持缓存键一致）
                                self._response_cache.set(
                                    messages_list[original_idx], content, model=effective_model, **kwargs
                                )
                                on_file_result(original_idx, content)
                            except Exception as e:
                                logger.warning(f"提取结果失败: {e}")
                                cached_responses[original_idx] = None
                                on_file_result(original_idx, None, "error", str(e))
                        if batch.is_final:
                            progress = batch.progress

                responses = cached_responses
            else:
                # 不使用缓存，直接批量执行
                indices_to_run = [i for i in range(len(messages_list)) if i not in completed_indices]
                responses = [None] * len(messages_list)

                progress = None
                if indices_to_run:
                    messages_to_run = [messages_list[i] for i in indices_to_run]
                    request_params = [
                        {"json": self._build_request_body(m, effective_model, **kwargs), "headers": headers}
                        for m in messages_to_run
                    ]
                    results, progress = await self._client.process_requests(
                        request_params=request_params, url=effective_url, method="POST", show_progress=show_progress
                    )
                    for local_idx, r in enumerate(results):
                        original_idx = indices_to_run[local_idx]
                        try:
                            content = extractor(r)
                            responses[original_idx] = content
                            on_file_result(original_idx, content)
                        except Exception as e:
                            logger.warning(f"Error: {e}, set content to None")
                            responses[original_idx] = None
                            on_file_result(original_idx, None, "error", str(e))

        finally:
            # 确保最后的数据写入
            flush_to_file()
            if file_writer:
                file_writer.close()

        summary = progress.summary(print_to_console=False) if progress else None
        return (responses, summary) if return_summary else responses

    def chat_completions_batch_sync(
        self,
        messages_list: List[List[dict]],
        model: str = None,
        return_raw: bool = False,
        show_progress: bool = True,
        return_summary: bool = False,
        use_cache: bool = False,
        output_file: Optional[str] = None,
        flush_interval: float = 1.0,
        **kwargs,
    ) -> Union[List[str], tuple]:
        """同步版本的批量聊天完成"""
        return asyncio.run(
            self.chat_completions_batch(
                messages_list=messages_list,
                model=model,
                return_raw=return_raw,
                show_progress=show_progress,
                return_summary=return_summary,
                use_cache=use_cache,
                output_file=output_file,
                flush_interval=flush_interval,
                **kwargs,
            )
        )

    async def chat_completions_stream(
        self, messages: List[dict], model: str = None, preprocess_msg: bool = False, url: str = None, **kwargs
    ):
        """
        流式聊天完成

        Args:
            messages: 消息列表
            model: 模型名称
            preprocess_msg: 是否预处理消息
            url: 自定义请求 URL，默认使用 _get_stream_url() 生成
        """
        import aiohttp
        import json

        effective_model = self._get_effective_model(model)
        messages = await self._preprocess_messages(messages, preprocess_msg)

        body = self._build_request_body(messages, effective_model, stream=True, **kwargs)
        effective_url = url or self._get_stream_url(effective_model)
        headers = self._get_headers()

        timeout = aiohttp.ClientTimeout(total=self._timeout)

        async with aiohttp.ClientSession() as session:
            async with session.post(effective_url, json=body, headers=headers, timeout=timeout) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"HTTP {response.status}: {error_text}")

                async for line in response.content:
                    line = line.decode("utf-8").strip()
                    if line.startswith("data: "):
                        data_str = line[6:]
                        if data_str == "[DONE]":
                            break
                        try:
                            data = json.loads(data_str)
                            content = self._extract_stream_content(data)
                            if content:
                                yield content
                        except json.JSONDecodeError:
                            continue

    def model_list(self) -> List[str]:
        raise NotImplementedError("子类需要实现 model_list 方法")

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(model='{self._model}')"

    # ========== 资源管理 ==========

    def close(self):
        """关闭客户端，释放资源（如缓存连接）"""
        if self._response_cache is not None:
            self._response_cache.close()
            self._response_cache = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        self.close()
