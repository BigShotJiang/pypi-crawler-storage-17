"""scikit-build-core project template generation."""

from buildgen.skbuild.generator import SkbuildProjectGenerator

__all__ = [
    "SkbuildProjectGenerator",
]
