"""Top-level package for atlus."""

__version__ = "1.0.1"
