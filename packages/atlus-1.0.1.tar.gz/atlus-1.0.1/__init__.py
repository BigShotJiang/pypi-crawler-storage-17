"""Convert raw address and phone number strings into the OSM format."""
