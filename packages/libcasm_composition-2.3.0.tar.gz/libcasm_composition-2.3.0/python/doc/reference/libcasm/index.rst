..
    DO NOT DELETE! This causes _autosummary to generate stub files

libcasm package
===============

.. autosummary::
    :toctree: _autosummary
    :template: custom-module-template.rst
    :recursive:

    libcasm.composition
