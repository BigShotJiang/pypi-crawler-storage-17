from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from cloudmersive_spam_api_client.api.spam_detection_api import SpamDetectionApi
