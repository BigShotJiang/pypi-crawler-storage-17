Ancillary Functions
===================

.. automodule:: pyroSAR.ancillary
    :members:
    :undoc-members:
    :show-inheritance:

    .. autosummary::
        :nosignatures:

        find_datasets
        getargs
        groupby
        groupbyTime
        hasarg
        multilook_factors
        parse_datasetname
        seconds
        Lock
        LockCollection
