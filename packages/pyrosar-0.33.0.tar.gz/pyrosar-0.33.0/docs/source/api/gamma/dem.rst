DEM tools
---------

.. automodule:: pyroSAR.gamma.dem
    :members: dem_autocreate, dem_import, dempar, fill, hgt, hgt_collect, makeSRTM, mosaic, swap
    :undoc-members:
    :show-inheritance:

    .. autosummary::
        :nosignatures:

        dem_autocreate
        dem_import
        dempar
        fill
        hgt
        hgt_collect
        makeSRTM
        mosaic
        swap