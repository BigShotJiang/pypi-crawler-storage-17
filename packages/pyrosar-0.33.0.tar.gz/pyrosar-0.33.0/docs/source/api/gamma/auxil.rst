Auxiliary functionality
-----------------------

.. automodule:: pyroSAR.gamma.auxil
    :members:
    :undoc-members:
    :show-inheritance:

    .. autosummary::
        :nosignatures:

        do_execute
        ISPPar
        Namespace
        par2hdr
        process
        slc_corners
        Spacing
        UTM