// eslint-disable-next-line import/prefer-default-export
export const CREDENTIAL_TYPES = {
  available: 'Available',
  notSet: 'Not set',
};
