export const NAME_MAX_CHARS = 20;
export const SLOGAN_MAX_CHARS = 40;
