// eslint-disable-next-line import/prefer-default-export
export const POPOVER_ID = 'color-picker-popover';
