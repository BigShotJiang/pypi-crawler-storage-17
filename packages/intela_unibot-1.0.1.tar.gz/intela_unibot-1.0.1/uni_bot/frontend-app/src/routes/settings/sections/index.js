export { default as LanguagesSection } from './languages';
export { default as DimensionsSection } from './dimensions';
export { default as InfoSection } from './info';
export { default as ColorsSection } from './colors';
export { default as GreetingSection } from './greeting';
