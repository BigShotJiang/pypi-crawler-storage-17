export const MIN_HEIGHT_VALUE = 500;
export const MAX_HEIGHT_VALUE = 1000;
export const MIN_WIDTH_VALUE = 300;
export const MAX_WIDTH_VALUE = 1000;

export const DIMENSIONS = { WIDTH: 'width', HEIGHT: 'height' };
