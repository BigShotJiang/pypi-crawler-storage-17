export const API_BASE_URL = '/uni_bot/api';

export const POLLING_INTERVAL = 1500;
