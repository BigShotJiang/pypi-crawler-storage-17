"""
Fake test for pass test by CI/CD
"""
# pylint: disable=missing-function-docstring


def test_pass() -> None:
    assert 1 + 1 == 2
