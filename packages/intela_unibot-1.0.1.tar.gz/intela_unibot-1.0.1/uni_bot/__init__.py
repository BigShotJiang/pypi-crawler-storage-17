"""
Init module for uni_bot.
"""

__version__ = 'v1.0.1'
