EXTENSIONS_APP_NAME = 'uni_bot_auth'
