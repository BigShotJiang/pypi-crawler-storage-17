# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
# Keep order
from . import stock_product_secondary_unit_mixin
from . import product_product
from . import product_template
from . import stock_move
