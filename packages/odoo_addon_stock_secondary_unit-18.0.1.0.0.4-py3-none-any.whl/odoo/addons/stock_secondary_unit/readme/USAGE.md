To use this module you need to:

1.  Go to a *Product \> General Information tab*.
2.  Create any record in "Secondary unit of measure".
3.  Set the conversion factor.
4.  Go to *Inventory tab* and set a second unit of measure.
5.  Push button 'On hand' and set quantities in stock for this
    product.
6.  Go to product list and you can see the secondary unit value.
