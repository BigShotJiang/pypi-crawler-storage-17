"""Unit tests for strategy module."""
