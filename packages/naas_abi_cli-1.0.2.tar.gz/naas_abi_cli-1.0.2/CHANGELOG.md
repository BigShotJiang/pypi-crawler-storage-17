# CHANGELOG

<!-- version list -->

## v1.0.2 (2025-12-19)


## v1.0.1 (2025-12-19)

### Bug Fixes

- Add missing config in template
  ([`d4df148`](https://github.com/jupyter-naas/abi/commit/d4df148450f356a94ab53b46580db20bbba325b1))


## v1.0.0 (2025-12-19)

- Initial Release
