"""Integration tests for Vandamme Proxy."""
