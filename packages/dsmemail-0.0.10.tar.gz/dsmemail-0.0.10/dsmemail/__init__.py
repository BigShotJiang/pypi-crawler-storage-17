__title__ = 'DigitalStoreMesh Email'
__version__ = '0.0.10'
__author__ = 'DigitalStoreMesh Co.,Ltd'
__license__ = 'MIT'

VERSION = __version__

from .sendmail import sendEmail
from . import utils