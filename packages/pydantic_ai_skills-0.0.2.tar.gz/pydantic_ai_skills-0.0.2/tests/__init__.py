"""Tests for pydantic-ai-skills."""
