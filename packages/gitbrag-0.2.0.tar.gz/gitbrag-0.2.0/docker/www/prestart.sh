#!/usr/bin/env bash

echo "FastAPI Prestart Script Running"


