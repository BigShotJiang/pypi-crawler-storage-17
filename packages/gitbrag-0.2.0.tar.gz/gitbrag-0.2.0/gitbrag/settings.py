from .conf.settings import Settings

settings = Settings()
