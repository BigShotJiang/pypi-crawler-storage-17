
from AgentService.cli import execute_project


def main():
    execute_project()


if __name__ == '__main__':
    main()
