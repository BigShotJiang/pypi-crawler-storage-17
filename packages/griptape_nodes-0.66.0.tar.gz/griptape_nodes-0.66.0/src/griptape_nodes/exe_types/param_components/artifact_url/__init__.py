"""Reusable artifact URL parameters."""
