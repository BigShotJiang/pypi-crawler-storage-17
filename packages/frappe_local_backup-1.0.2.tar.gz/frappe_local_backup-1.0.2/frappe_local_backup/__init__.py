"""Frappe Local Backup Service - Backup your Frappe Cloud sites locally."""

__version__ = "1.0.2"
