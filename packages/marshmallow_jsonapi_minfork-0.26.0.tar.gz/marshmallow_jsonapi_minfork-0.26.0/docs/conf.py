import datetime as dt
import os
import sys

sys.path.insert(0, os.path.abspath(".."))
import marshmallow_jsonapi  # noqa: E402

extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.intersphinx",
    "sphinx.ext.viewcode",
    "sphinx_issues",
]

primary_domain = "py"
default_role = "py:obj"

intersphinx_mapping = {
    "python": ("http://python.readthedocs.io/en/latest/", None),
    "marshmallow": ("http://marshmallow.readthedocs.io/en/latest/", None),
}

issues_github_path = "marshmallow-code/marshmallow-jsonapi"

source_suffix = ".rst"
master_doc = "index"
project = "marshmallow-jsonapi"
copyright = f"Steven Loria {dt.datetime.now(tz=dt.UTC):%Y}"

version = release = marshmallow_jsonapi.__version__

exclude_patterns = ["_build"]

# THEME

# on_rtd is whether we are on readthedocs.org
on_rtd = os.environ.get("READTHEDOCS", None) == "True"

if not on_rtd:  # only import and set the theme if we're building docs locally
    html_theme = "sphinx_rtd_theme"
