*******
Authors
*******

Lead
====

- Steven Loria `@sloria <https://github.com/sloria>`_

Contributors (chronological)
============================

- Jotham Apaloo `@jo-tham <https://github.com/jo-tham>`_
- Anders Steinlein `@asteinlein <https://github.com/asteinlein>`_
- `@floqqi <https://github.com/floqqi>`_
- Colton Allen `@cmanallen <https://github.com/cmanallen>`_
- Dominik Steinberger `@ZeeD26 <https://github.com/ZeeD26>`_
- Tim Mundt `@Tim-Erwin <https://github.com/Tim-Erwin>`_
- Brandon Wood `@woodb <https://github.com/woodb>`_
- Frazer McLean `@RazerM <https://github.com/RazerM>`_
- J Rob Gant `@rgant <https://github.com/rgant>`_
- Dan Poland `@danpoland <https://github.com/danpoland>`_
- Pierre CHAISY `@akira-dev <https://github.com/akira-dev>`_
- `@mrhanky17 <https://github.com/mrhanky17>`_
- Mark Hall `@scmmmh <https://github.com/scmmmh>`_
- Scott Werner `@scottwernervt <https://github.com/scottwernervt>`_
- Michael Dodsworth `@mdodsworth <https://github.com/mdodsworth>`_
- Mathieu Alorent `@kumy <https://github.com/kumy>`_
- Grant Harris `@grantHarris <https://github.com/grantHarris>`_
- Robert Sawicki `@ww3pl <https://github.com/ww3pl>`_
- `@aberres <https://github.com/aberres>`_
- George Alton `@georgealton <https://github.com/georgealton>`_
- Areeb Jamal `@iamareebjamal <https://github.com/iamareebjamal>`_
- Suren Khorenyan `@mahenzon <https://github.com/mahenzon>`_
- Karthikeyan Singaravelan `@tirkarthi <https://github.com/tirkarthi>`_
- Vlad Munteanu `@vladmunteanu https://github.com/vladmunteanu/`
