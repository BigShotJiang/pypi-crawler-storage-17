"""Trampoline Client - Python client for Trampoline dynamic reverse proxy."""

from .client import TrampolineClient

__version__ = "0.1.0"
__all__ = ["TrampolineClient"]
