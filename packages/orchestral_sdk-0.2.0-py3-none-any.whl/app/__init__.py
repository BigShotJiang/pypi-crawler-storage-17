"""
Orchestral App - Web interface for the Orchestral AI framework.

This package provides the web application components including the server,
conversation management, and user interface.
"""

__version__ = "0.2.0"
