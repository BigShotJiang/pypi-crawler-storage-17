def divide_numbers(a, b):
    """
    Divides two numbers and returns the result.
    Intentionally has a bug with integer division.
    """
    return a / b