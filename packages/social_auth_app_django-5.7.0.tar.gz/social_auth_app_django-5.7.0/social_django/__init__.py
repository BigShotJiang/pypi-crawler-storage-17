import importlib.metadata

__version__ = importlib.metadata.version("social-auth-app-django")
