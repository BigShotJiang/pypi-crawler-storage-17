class AntiCAPException(Exception):
    pass
