"""
helper schemas for serialization
"""

# pylint:disable=cyclic-import
