"""
functions related to content evaluation
"""
