# {{ graft_name }}

This minimal graft ships just Markdown/Quarto content—no Python package or extras.

- Quarto website with navbar + sidebar
- Starter page wired to your graft name
- Makefile helpers to render/preview/clean

Run `make render` to produce `_site/`, or `make preview` to iterate locally.
