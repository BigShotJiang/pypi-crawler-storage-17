cid.cid module
==============

.. automodule:: cid.cid
   :members:
   :show-inheritance:
   :undoc-members:
