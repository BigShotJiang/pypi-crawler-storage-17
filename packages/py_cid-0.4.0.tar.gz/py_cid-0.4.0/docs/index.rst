.. include:: ../README.rst

More examples
=============

Check :doc:`usage` for more usage examples

Table of contents
=================

.. toctree::
   :maxdepth: 2

   installation
   usage
   api_reference
   contributing
   authors
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
