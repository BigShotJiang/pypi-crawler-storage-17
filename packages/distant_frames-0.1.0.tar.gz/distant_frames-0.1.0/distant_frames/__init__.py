from .core import extract_frames

__all__ = ["extract_frames"]
