from .r2 import R2Storage

__all__ = ['R2Storage']
