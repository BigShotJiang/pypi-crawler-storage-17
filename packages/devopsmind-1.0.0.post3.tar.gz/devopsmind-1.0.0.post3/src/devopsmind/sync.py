import json
import requests
from pathlib import Path
from datetime import datetime

from rich.text import Text
from rich.table import Table
from rich.console import Group

from devopsmind.cli import frame
from devopsmind.constants import DATA_DIR, VERSION
from devopsmind.progress import load_state, save_state
from devopsmind.update_check import check_for_update


# -------------------------------------------------
# Optional YAML support (NO hard dependency)
# -------------------------------------------------

try:
    import yaml
except Exception:
    yaml = None


# -------------------------------------------------
# Paths
# -------------------------------------------------

CACHE_PATH = DATA_DIR / "leaderboard.json"
SNAPSHOT_PATH = Path.home() / ".devopsmind" / "snapshot.json"

# 🔥 Cloudflare Worker snapshot relay (authoritative remote)
SNAPSHOT_RELAY_URL = "https://devopsmind-relay.gauravchile05.workers.dev/snapshot"


# -------------------------------------------------
# Helpers
# -------------------------------------------------

def _now():
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def _load_json(path: Path):
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def _save_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2))


# -------------------------------------------------
# Snapshot fetch from Worker
# -------------------------------------------------

def _fetch_snapshot_from_worker(user_id: str):
    try:
        r = requests.get(f"{SNAPSHOT_RELAY_URL}/{user_id}", timeout=10)
        if r.status_code != 200:
            return None
        return r.json()
    except Exception:
        return None


# -------------------------------------------------
# Snapshot restore (SAFE)
# -------------------------------------------------

def _restore_from_snapshot(state):
    if not SNAPSHOT_PATH.exists():
        return state

    try:
        raw = SNAPSHOT_PATH.read_text()
        snapshot = yaml.safe_load(raw) if yaml else json.loads(raw)
    except Exception:
        return state

    if snapshot.get("user_id") != state.get("identity"):
        return state

    snapshot_xp = int(snapshot.get("xp", 0))
    local_xp = int(state.get("xp", 0))

    if snapshot_xp <= local_xp:
        return state

    state["xp"] = snapshot_xp
    state.setdefault("progress", {})
    state["progress"]["completed"] = snapshot.get(
        "completed_challenges", []
    )

    state.setdefault("profile", {})
    state["profile"]["rank"] = snapshot.get("rank", "Beginner")
    state["last_synced"] = snapshot.get("updated_at")

    save_state(state)
    return state


# -------------------------------------------------
# Public API
# -------------------------------------------------

def sync_default(local: bool = False):
    """
    devopsmind sync
    """

    # ------------------------------
    # Load local state
    # ------------------------------
    state = load_state()

    # ------------------------------
    # Fetch snapshot from Worker
    # ------------------------------
    user_id = state.get("identity")
    if user_id:
        remote_snapshot = _fetch_snapshot_from_worker(user_id)
        if remote_snapshot:
            SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
            SNAPSHOT_PATH.write_text(
                json.dumps(remote_snapshot, indent=2)
            )

    # ------------------------------
    # Restore from snapshot
    # ------------------------------
    state = _restore_from_snapshot(state)

    state.setdefault("progress", {})
    state["progress"].setdefault("completed", [])
    state.setdefault("last_synced", None)

    profile = state.get("profile", {})
    local_xp = int(state.get("xp", 0))
    local_rank = profile.get("rank", "Beginner")

    # ------------------------------
    # Render (LOCAL ONLY)
    # ------------------------------
    table = Table(show_header=True, header_style="bold")
    table.add_column("Source")
    table.add_column("XP", justify="right")
    table.add_column("Rank")

    table.add_row("Local", str(local_xp), local_rank)

    notes = [
        Text("✔ Synced using local state and snapshot relay.", style="green")
    ]

    # ------------------------------
    # Update check
    # ------------------------------
    update_available, latest, release_notes = check_for_update()

    if update_available:
        notes.append(
            Text(
                f"⬆ New version available: {latest}\n"
                f"Run `pipx upgrade devopsmind` to get new challenges.",
                style="cyan",
            )
        )
        if release_notes:
            notes.append(Text(f"📝 {release_notes}", style="dim"))

    # ------------------------------
    # Always return renderable
    # ------------------------------
    return frame("🔄 Sync", Group(table, *notes))
