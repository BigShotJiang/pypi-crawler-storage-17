Create a bash script named `echo_hello.sh` in the working directory.

Requirements:
- When executed (`bash echo_hello.sh`), the script must print exactly:
  Hello DevOpsMind
- No extra whitespace or newline variations (a single trailing newline is acceptable).
- The script must be executable.
