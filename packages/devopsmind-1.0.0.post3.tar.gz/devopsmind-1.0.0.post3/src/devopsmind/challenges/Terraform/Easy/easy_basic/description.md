Create a file named main.tf with a simple provider block:

provider "aws" {
  region = "us-east-1"
}

This teaches basic Terraform syntax and structure.
Validator performs static syntax validation.

