You have to create file script.sh in the working directory.

Your task:
- Ensure ONLY the owner can read, write, and execute the file.
- No permissions for group or others.

This teaches Linux permission management.
