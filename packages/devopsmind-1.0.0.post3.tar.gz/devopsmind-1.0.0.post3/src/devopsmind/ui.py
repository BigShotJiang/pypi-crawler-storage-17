def print_error(message: str):
    print(f"❌ {message}")


def print_success(message: str):
    print(f"✅ {message}")
