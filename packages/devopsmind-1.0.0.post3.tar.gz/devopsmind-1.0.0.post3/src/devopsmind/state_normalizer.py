"""
State Normalizer

Purpose:
- Provide a forward-compatible normalization layer for legacy state.
- Ensure achievements / badges are monotonic and never lost.
- Preserve all legacy fields without modifying or deleting them.

Design contract:
- XP remains authoritative in state["xp"]
- Rank is derived elsewhere from XP
- Achievements are authoritative in state["achievements"]
- Legacy fields are tolerated but never trusted
"""

from typing import Dict


def normalize_state(state: Dict) -> Dict:
    """
    Normalize state to the latest internal contract.

    This function is:
    - Pure (no IO)
    - Idempotent
    - Non-destructive
    - Safe to call multiple times

    Rules:
    - Achievements must never decrease
    - Legacy fields are merged forward
    - No fields are removed
    """

    if not state:
        return state

    # -------------------------------------------------
    # 🔒 Ensure authoritative achievements field exists
    # -------------------------------------------------
    state.setdefault("achievements", [])

    authoritative = set(state.get("achievements", []) or [])

    # -------------------------------------------------
    # Legacy badge sources (DO NOT REMOVE)
    # -------------------------------------------------
    legacy = set()

    legacy |= set(state.get("badges", []) or [])
    legacy |= set(state.get("achievements_unlocked", []) or [])

    profile = state.get("profile", {}) or {}
    legacy |= set(profile.get("achievements", []) or [])

    # -------------------------------------------------
    # Merge forward (never shrink)
    # -------------------------------------------------
    merged = authoritative | legacy
    state["achievements"] = sorted(merged)

    return state
