import json
from pathlib import Path

from .constants import DATA_DIR

STATE_FILE = DATA_DIR / "state.json"


# -----------------------------
# Badge / Achievement Rules
# -----------------------------
# NOTE:
# - Badges are permanent, write-once facts
# - Rank is derived elsewhere
# - CLI is the only authority that persists badges
#
# ⚠️ IMPORTANT:
# Badge eligibility logic has been intentionally removed.
# This file ONLY persists externally-earned badges.

CHALLENGE_BADGES = {}  # ← intentionally empty (no hardcoding)


def load_state():
    if not STATE_FILE.exists():
        return {
            "username": None,
            "gamer": None,
            "identity": None,
            "xp": 0,
            "badges": [],
            "achievements_unlocked": [],
            "progress": {
                "completed": [],
                "by_stack": {},
                "by_difficulty": {},
            },
            "attempts": {},
        }

    state = json.loads(STATE_FILE.read_text())

    # ---- Backward compatibility ----
    state.setdefault("badges", [])
    state.setdefault("achievements_unlocked", [])

    progress = state.setdefault("progress", {})
    progress.setdefault("completed", [])
    progress.setdefault("by_stack", {})
    progress.setdefault("by_difficulty", {})

    state.setdefault("attempts", {})

    return state


def save_state(state):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, indent=2))


# -----------------------------
# Badge & Achievement Awarding
# -----------------------------
def award_badges(state):
    """
    Legacy function kept for backward compatibility.

    IMPORTANT:
    This function no longer contains any badge rules.
    Badge eligibility is decided elsewhere.
    """
    # No-op by design
    return


# -------------------------------------------------
# 🔥 Generic badge persistence (SOURCE OF TRUTH)
# -------------------------------------------------
def persist_earned_badges(state, earned_badges):
    """
    Persist any externally-computed earned badges.

    This function:
    - does NOT decide eligibility
    - does NOT hard-code badge rules
    - only records earned facts
    """

    if not earned_badges:
        return

    badges = set(state.get("badges", []))
    achievements = set(state.get("achievements_unlocked", []))

    for badge_id in earned_badges:
        badges.add(badge_id)
        achievements.add(badge_id)

    state["badges"] = sorted(badges)
    state["achievements_unlocked"] = sorted(achievements)


def record_completion(
    challenge_id,
    xp,
    stack=None,
    difficulty=None,
    earned_badges=None,
):
    state = load_state()
    progress = state["progress"]

    # Prevent double counting
    if challenge_id in progress["completed"]:
        return state

    # Record completion
    progress["completed"].append(challenge_id)
    state["xp"] += xp

    if stack:
        progress["by_stack"][stack] = progress["by_stack"].get(stack, 0) + 1

    if difficulty:
        progress["by_difficulty"][difficulty] = (
            progress["by_difficulty"].get(difficulty, 0) + 1
        )

    # Legacy hook (now no-op)
    award_badges(state)

    # ✅ Persist externally-earned badges (ONLY truth)
    persist_earned_badges(state, earned_badges or [])

    save_state(state)
    return state
