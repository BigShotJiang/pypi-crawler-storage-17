# xdsl-jax

Extending JAX with xDSL.

## Local Development

1. Clone repository
2. Run `make install`
3. Run `make tests`
