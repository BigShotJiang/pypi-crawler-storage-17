from __future__ import annotations

"""CLI utilities for Fast Plate OCR (Python 3.8 compatible)."""

