from .whisperManager.src.manager_utils import get_whisper_text
