from chickenstats.chicken_nhl.scrape import Season, Scraper
