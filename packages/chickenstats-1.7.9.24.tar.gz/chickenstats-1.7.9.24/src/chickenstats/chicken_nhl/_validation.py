import datetime as dt

from pandera.pandas import Column, DataFrameSchema
from pydantic import BaseModel, field_validator
from polars import Int64, String, Float64, List, Datetime, Struct


class APIEvent(BaseModel):
    """Pydantic model for validating API event data."""

    season: int
    session: str
    game_id: int
    event_idx: int
    period: int
    period_type: str
    period_seconds: int
    game_seconds: int
    event_team: str | None = None
    event: str
    event_code: int
    description: str | None = None
    coords_x: int | None = None
    coords_y: int | None = None
    zone: str | None = None
    player_1: str | None = None
    player_1_eh_id: str | None = None
    player_1_position: str | None = None
    player_1_type: str | None = None
    player_1_api_id: int | str | None = None
    player_1_team_jersey: str | None = None
    player_2: str | None = None
    player_2_eh_id: str | None = None
    player_2_position: str | None = None
    player_2_type: str | None = None
    player_2_api_id: int | str | None = None
    player_2_team_jersey: str | None = None
    player_3: str | None = None
    player_3_eh_id: str | None = None
    player_3_position: str | None = None
    player_3_type: str | None = None
    player_3_api_id: int | str | None = None
    player_3_team_jersey: str | None = None
    strength: int | None = None
    shot_type: str | None = None
    miss_reason: str | None = None
    opp_goalie: str | None = None
    opp_goalie_eh_id: str | None = None
    opp_goalie_api_id: int | str | None = None
    opp_goalie_team_jersey: str | None = None
    event_team_id: int | None = None
    stoppage_reason: str | None = None
    stoppage_reason_secondary: str | None = None
    penalty_type: str | None = None
    penalty_reason: str | None = None
    penalty_duration: int | None = None
    home_team_defending_side: str | None = None
    version: int


APIEventSchemaPolars = {
    "season": Int64,
    "session": String,
    "game_id": Int64,
    "event_idx": Int64,
    "period": Int64,
    "period_type": String,
    "period_seconds": Int64,
    "game_seconds": Int64,
    "event_team": String,
    "event": String,
    "event_code": Int64,
    "description": String,
    "coords_x": Int64,
    "coords_y": Int64,
    "zone": String,
    "player_1": String,
    "player_1_eh_id": String,
    "player_1_position": String,
    "player_1_type": String,
    "player_1_api_id": String,
    "player_1_team_jersey": String,
    "player_2": String,
    "player_2_eh_id": String,
    "player_2_position": String,
    "player_2_type": String,
    "player_2_api_id": String,
    "player_2_team_jersey": String,
    "player_3": String,
    "player_3_eh_id": String,
    "player_3_position": String,
    "player_3_type": String,
    "player_3_api_id": String,
    "player_3_team_jersey": String,
    "strength": Int64,
    "shot_type": String,
    "miss_reason": String,
    "opp_goalie": String,
    "opp_goalie_eh_id": String,
    "opp_goalie_api_id": String,
    "opp_goalie_team_jersey": String,
    "event_team_id": Int64,
    "stoppage_reason": String,
    "stoppage_reason_secondary": String,
    "penalty_type": String,
    "penalty_reason": String,
    "penalty_duration": Int64,
    "home_team_defending_side": String,
    "version": Int64,
}


class APIRosterPlayer(BaseModel):
    """Pydantic model for validating API roster data."""

    season: int
    session: str
    game_id: int
    team: str
    team_venue: str
    player_name: str
    eh_id: str
    api_id: int
    team_jersey: str
    jersey: int
    position: str
    first_name: str
    last_name: str
    headshot_url: str


APIRosterSchemaPolars = {
    "season": Int64,
    "session": String,
    "game_id": Int64,
    "team": String,
    "team_venue": String,
    "player_name": String,
    "eh_id": String,
    "api_id": String,
    "team_jersey": String,
    "jersey": Int64,
    "position": String,
    "first_name": String,
    "last_name": String,
    "headshot_url": String,
}


class ChangeEvent(BaseModel):
    """Pydantic model for validating changes data."""

    season: int
    session: str
    game_id: int
    event_team: str
    event: str
    event_type: str
    description: str
    period: int
    period_seconds: int
    game_seconds: int
    change_on_count: int
    change_off_count: int
    change_on: list[str] | str = ""
    change_on_jersey: list[str] | str = ""
    change_on_eh_id: list[str] | str = ""
    change_on_api_id: list[str] | str = ""
    change_on_positions: list[str] | str = ""
    change_off: list[str] | str = ""
    change_off_jersey: list[str] | str = ""
    change_off_eh_id: list[str] | str = ""
    change_off_api_id: list[str] | str = ""
    change_off_positions: list[str] | str = ""
    change_on_forwards_count: int
    change_off_forwards_count: int
    change_on_forwards: list[str] | str = ""
    change_on_forwards_jersey: list[str] | str = ""
    change_on_forwards_eh_id: list[str] | str = ""
    change_on_forwards_api_id: list[str] | str = ""
    change_off_forwards: list[str] | str = ""
    change_off_forwards_jersey: list[str] | str = ""
    change_off_forwards_eh_id: list[str] | str = ""
    change_off_forwards_api_id: list[str] | str = ""
    change_on_defense_count: int
    change_off_defense_count: int
    change_on_defense: list[str] | str = ""
    change_on_defense_jersey: list[str] | str = ""
    change_on_defense_eh_id: list[str] | str = ""
    change_on_defense_api_id: list[str] | str = ""
    change_off_defense: list[str] | str = ""
    change_off_defense_jersey: list[str] | str = ""
    change_off_defense_eh_id: list[str] | str = ""
    change_off_defense_api_id: list[str] | str = ""
    change_on_goalie_count: int
    change_off_goalie_count: int
    change_on_goalie: list[str] | str = ""
    change_on_goalie_jersey: list[str] | str = ""
    change_on_goalie_eh_id: list[str] | str = ""
    change_on_goalie_api_id: list[str] | str = ""
    change_off_goalie: list[str] | str = ""
    change_off_goalie_jersey: list[str] | str = ""
    change_off_goalie_eh_id: list[str] | str = ""
    change_off_goalie_api_id: list[str] | str = ""
    is_home: int
    is_away: int
    team_venue: str

    @field_validator(
        "change_on_jersey",
        "change_on",
        "change_on_eh_id",
        "change_on_api_id",
        "change_on_positions",
        "change_off_jersey",
        "change_off",
        "change_off_eh_id",
        "change_off_api_id",
        "change_off_positions",
        "change_on_forwards_jersey",
        "change_on_forwards",
        "change_on_forwards_eh_id",
        "change_on_forwards_api_id",
        "change_off_forwards_jersey",
        "change_off_forwards",
        "change_off_forwards_eh_id",
        "change_off_forwards_api_id",
        "change_on_defense_jersey",
        "change_on_defense",
        "change_on_defense_eh_id",
        "change_on_defense_api_id",
        "change_off_defense_jersey",
        "change_off_defense",
        "change_off_defense_eh_id",
        "change_off_defense_api_id",
        "change_on_goalie_jersey",
        "change_on_goalie",
        "change_on_goalie_eh_id",
        "change_on_goalie_api_id",
        "change_off_goalie_jersey",
        "change_off_goalie",
        "change_off_goalie_eh_id",
        "change_off_goalie_api_id",
        mode="after",
    )
    @classmethod
    def fix_list(cls, v):
        """Converts lists into strings."""
        if v and isinstance(v, list) is True:
            return ", ".join(v)

        elif not v:
            return None

        else:
            return v


ChangesSchemaPolars = {
    "season": Int64,
    "session": String,
    "game_id": Int64,
    "event_team": String,
    "event": String,
    "event_type": String,
    "description": String,
    "period": Int64,
    "period_seconds": Int64,
    "game_seconds": Int64,
    "change_on_count": Int64,
    "change_off_count": Int64,
    "change_on": String,
    "change_on_jersey": String,
    "change_on_eh_id": String,
    "change_on_api_id": String,
    "change_on_positions": String,
    "change_off": String,
    "change_off_jersey": String,
    "change_off_eh_id": String,
    "change_off_api_id": String,
    "change_off_positions": String,
    "change_on_forwards_count": Int64,
    "change_off_forwards_count": Int64,
    "change_on_forwards": String,
    "change_on_forwards_jersey": String,
    "change_on_forwards_eh_id": String,
    "change_on_forwards_api_id": String,
    "change_off_forwards": String,
    "change_off_forwards_jersey": String,
    "change_off_forwards_eh_id": String,
    "change_off_forwards_api_id": String,
    "change_on_defense_count": Int64,
    "change_off_defense_count": Int64,
    "change_on_defense": String,
    "change_on_defense_jersey": String,
    "change_on_defense_eh_id": String,
    "change_on_defense_api_id": String,
    "change_off_defense": String,
    "change_off_defense_jersey": String,
    "change_off_defense_eh_id": String,
    "change_off_defense_api_id": String,
    "change_on_goalie_count": Int64,
    "change_off_goalie_count": Int64,
    "change_on_goalie": String,
    "change_on_goalie_jersey": String,
    "change_on_goalie_eh_id": String,
    "change_on_goalie_api_id": String,
    "change_off_goalie": String,
    "change_off_goalie_jersey": String,
    "change_off_goalie_eh_id": String,
    "change_off_goalie_api_id": String,
    "is_home": Int64,
    "is_away": Int64,
    "team_venue": String,
    "game_date": String,
    "home_team": String,
    "away_team": String,
    "version": Int64,
    "sort_value": Int64,
    "opp_team": String,
    "home_forwards_eh_id": List(String),
    "home_forwards_api_id": List(String),
    "home_forwards": List(String),
    "home_forwards_positions": List(String),
    "home_defense_eh_id": List(String),
    "home_defense_api_id": List(String),
    "home_defense": List(String),
    "home_defense_positions": List(String),
    "home_goalie_eh_id": List(String),
    "home_goalie_api_id": List(String),
    "home_goalie": List(String),
    "away_forwards_eh_id": List(String),
    "away_forwards_api_id": List(String),
    "away_forwards": List(String),
    "away_forwards_positions": List(String),
    "away_defense_eh_id": List(String),
    "away_defense_api_id": List(String),
    "away_defense": List(String),
    "away_defense_positions": List(String),
    "away_goalie_eh_id": List(String),
    "away_goalie_api_id": List(String),
    "away_goalie": List(String),
    "home_score": Int64,
    "home_score_diff": Int64,
    "away_score": Int64,
    "away_score_diff": Int64,
    "score_state": String,
    "score_diff": Int64,
    "event_idx": Int64,
    "event_length": Int64,
    "home_on_eh_id": List(String),
    "home_on_api_id": List(String),
    "home_on": List(String),
    "home_on_positions": List(String),
    "away_on_eh_id": List(String),
    "away_on_api_id": List(String),
    "away_on": List(String),
    "away_on_positions": List(String),
    "home_skaters": Int64,
    "away_skaters": Int64,
    "home_forwards_count": Int64,
    "home_defense_count": Int64,
    "home_forwards_percent": Float64,
    "away_forwards_count": Int64,
    "away_defense_count": Int64,
    "away_forwards_percent": Float64,
    "strength_state": String,
    "event_team_skaters": Int64,
    "teammates_eh_id": List(String),
    "teammates_api_id": List(String),
    "teammates": List(String),
    "teammates_positions": List(String),
    "forwards_eh_id": List(String),
    "forwards_api_id": List(String),
    "forwards": List(String),
    "forwards_count": Int64,
    "forwards_percent": Float64,
    "defense_eh_id": List(String),
    "defense_api_id": List(String),
    "defense": List(String),
    "defense_count": Int64,
    "own_goalie_eh_id": List(String),
    "own_goalie_api_id": List(String),
    "own_goalie": List(String),
    "opp_strength_state": String,
    "opp_score_state": String,
    "opp_score_diff": Int64,
    "opp_team_skaters": Int64,
    "opp_team_on_eh_id": List(String),
    "opp_team_on_api_id": List(String),
    "opp_team_on": List(String),
    "opp_team_on_positions": List(String),
    "opp_forwards_eh_id": List(String),
    "opp_forwards_api_id": List(String),
    "opp_forwards": List(String),
    "opp_forwards_count": Int64,
    "opp_forwards_percent": Float64,
    "opp_defense_eh_id": List(String),
    "opp_defense_api_id": List(String),
    "opp_defense": List(String),
    "opp_defense_count": Int64,
    "opp_goalie_eh_id": List(String),
    "opp_goalie_api_id": List(String),
    "opp_goalie": List(String),
    "event_on_1": String,
    "event_on_2": String,
    "event_on_3": String,
    "event_on_4": String,
    "event_on_5": String,
    "event_on_6": String,
    "event_on_1_eh_id": String,
    "event_on_2_eh_id": String,
    "event_on_3_eh_id": String,
    "event_on_4_eh_id": String,
    "event_on_5_eh_id": String,
    "event_on_6_eh_id": String,
    "event_on_1_api_id": String,
    "event_on_2_api_id": String,
    "event_on_3_api_id": String,
    "event_on_4_api_id": String,
    "event_on_5_api_id": String,
    "event_on_6_api_id": String,
    "event_on_1_pos": String,
    "event_on_2_pos": String,
    "event_on_3_pos": String,
    "event_on_4_pos": String,
    "event_on_5_pos": String,
    "event_on_6_pos": String,
    "change_on_1": String,
    "change_on_2": String,
    "change_on_3": String,
    "change_on_4": String,
    "change_on_5": String,
    "change_on_6": String,
    "change_on_1_eh_id": String,
    "change_on_2_eh_id": String,
    "change_on_3_eh_id": String,
    "change_on_4_eh_id": String,
    "change_on_5_eh_id": String,
    "change_on_6_eh_id": String,
    "change_on_1_api_id": String,
    "change_on_2_api_id": String,
    "change_on_3_api_id": String,
    "change_on_4_api_id": String,
    "change_on_5_api_id": String,
    "change_on_6_api_id": String,
    "change_on_1_pos": String,
    "change_on_2_pos": String,
    "change_on_3_pos": String,
    "change_on_4_pos": String,
    "change_on_5_pos": String,
    "change_on_6_pos": String,
    "coords_x": Int64,
    "coords_y": Int64,
    "zone_start": String,
    "block": Int64,
    "change": Int64,
    "chl": Int64,
    "fac": Int64,
    "give": Int64,
    "goal": Int64,
    "hit": Int64,
    "miss": Int64,
    "penl": Int64,
    "shot": Int64,
    "stop": Int64,
    "take": Int64,
    "fenwick": Int64,
    "corsi": Int64,
    "hd_goal": Int64,
    "hd_shot": Int64,
    "hd_miss": Int64,
    "hd_fenwick": Int64,
    "ozf": Int64,
    "nzf": Int64,
    "dzf": Int64,
    "ozc": Int64,
    "dzc": Int64,
    "nzc": Int64,
    "otf": Int64,
    "pen0": Int64,
    "pen2": Int64,
    "pen4": Int64,
    "pen5": Int64,
    "pen10": Int64,
    "teammate_block": Int64,
    "id": Int64,
    "opp_on_1": String,
    "opp_on_2": String,
    "opp_on_3": String,
    "opp_on_4": String,
    "opp_on_5": String,
    "opp_on_6": String,
    "opp_on_1_eh_id": String,
    "opp_on_2_eh_id": String,
    "opp_on_3_eh_id": String,
    "opp_on_4_eh_id": String,
    "opp_on_5_eh_id": String,
    "opp_on_6_eh_id": String,
    "opp_on_1_api_id": String,
    "opp_on_2_api_id": String,
    "opp_on_3_api_id": String,
    "opp_on_4_api_id": String,
    "opp_on_5_api_id": String,
    "opp_on_6_api_id": String,
    "opp_on_1_pos": String,
    "opp_on_2_pos": String,
    "opp_on_3_pos": String,
    "opp_on_4_pos": String,
    "opp_on_5_pos": String,
    "opp_on_6_pos": String,
    "change_off_1": String,
    "change_off_2": String,
    "change_off_3": String,
    "change_off_4": String,
    "change_off_5": String,
    "change_off_1_eh_id": String,
    "change_off_2_eh_id": String,
    "change_off_3_eh_id": String,
    "change_off_4_eh_id": String,
    "change_off_5_eh_id": String,
    "change_off_1_api_id": String,
    "change_off_2_api_id": String,
    "change_off_3_api_id": String,
    "change_off_4_api_id": String,
    "change_off_5_api_id": String,
    "change_off_1_pos": String,
    "change_off_2_pos": String,
    "change_off_3_pos": String,
    "change_off_4_pos": String,
    "change_off_5_pos": String,
    "change_off_6": String,
    "change_off_6_eh_id": String,
    "change_off_6_api_id": String,
    "change_off_6_pos": String,
}


class HTMLEvent(BaseModel):
    """Class for validating HTML event data."""

    season: int
    session: str
    game_id: int
    event_idx: int
    period: int
    period_time: str
    period_seconds: int
    game_seconds: int
    event_team: str | None = ""
    event: str
    description: str | None = None
    player_1: str | None = None
    player_1_eh_id: str | None = None
    player_1_position: str | None = None
    player_2: str | None = None
    player_2_eh_id: str | None = None
    player_2_position: str | None = None
    player_3: str | None = None
    player_3_eh_id: str | None = None
    player_3_position: str | None = None
    zone: str | None = None
    shot_type: str | None = None
    pbp_distance: int | None = None
    penalty_length: int | None = None
    penalty: str | None = None
    strength: str | None = None
    away_skaters: str | None = None
    home_skaters: str | None = None
    version: int

    @field_validator("strength", "away_skaters", "home_skaters")
    @classmethod
    def fix_strength(cls, v):
        """Changes blank strings into None objects."""
        new_v = None if v == " " else v

        return new_v


HTMLEventSchemaPolars = {
    "season": Int64,
    "session": String,
    "game_id": Int64,
    "event_idx": Int64,
    "period": Int64,
    "period_time": String,
    "period_seconds": Int64,
    "game_seconds": Int64,
    "event_team": String,
    "event": String,
    "description": String,
    "player_1": String,
    "player_1_eh_id": String,
    "player_1_position": String,
    "player_2": String,
    "player_2_eh_id": String,
    "player_2_position": String,
    "player_3": String,
    "player_3_eh_id": String,
    "player_3_position": String,
    "zone": String,
    "shot_type": String,
    "pbp_distance": Int64,
    "penalty_length": Int64,
    "penalty": String,
    "strength": String,
    "away_skaters": String,
    "home_skaters": String,
    "version": Int64,
}


class HTMLRosterPlayer(BaseModel):
    """Pydantic model for validating HTML roster data."""

    season: int
    session: str
    game_id: int
    team: str
    team_name: str
    team_venue: str
    player_name: str
    eh_id: str
    team_jersey: str
    jersey: int
    position: str
    starter: int
    status: str


HTMLRosterSchemaPolars = {
    "season": Int64,
    "session": String,
    "game_id": Int64,
    "team": String,
    "team_name": String,
    "team_venue": String,
    "player_name": String,
    "eh_id": String,
    "team_jersey": String,
    "jersey": Int64,
    "position": String,
    "starter": Int64,
    "status": String,
}


class RosterPlayer(BaseModel):
    """Pydantic model for validating roster data."""

    season: int
    session: str
    game_id: int
    team: str
    team_name: str
    team_venue: str
    player_name: str
    api_id: int | None
    eh_id: str
    team_jersey: str
    jersey: int
    position: str
    starter: int
    status: str
    headshot_url: str | None


RosterSchemaPolars = {
    "season": Int64,
    "session": String,
    "game_id": Int64,
    "team": String,
    "team_name": String,
    "team_venue": String,
    "player_name": String,
    "api_id": String,
    "eh_id": String,
    "team_jersey": String,
    "jersey": Int64,
    "position": String,
    "starter": Int64,
    "status": String,
    "headshot_url": String,
}


class PlayerShift(BaseModel):
    """Pydantic model for validating shifts data."""

    season: int
    session: str
    game_id: int
    team: str
    team_name: str
    player_name: str
    eh_id: str
    api_id: int
    team_jersey: str
    position: str
    jersey: int
    shift_count: int
    period: int
    start_time: str
    end_time: str
    duration: str
    start_time_seconds: int
    end_time_seconds: int
    duration_seconds: int
    shift_start: str
    shift_end: str
    goalie: int
    is_home: int
    is_away: int
    team_venue: str


ShiftsSchemaPolars = {
    "season": Int64,
    "session": String,
    "game_id": Int64,
    "team": String,
    "team_name": String,
    "player_name": String,
    "eh_id": String,
    "api_id": String,
    "team_jersey": String,
    "position": String,
    "jersey": Int64,
    "shift_count": Int64,
    "period": Int64,
    "start_time": String,
    "end_time": String,
    "duration": String,
    "start_time_seconds": Int64,
    "end_time_seconds": Int64,
    "duration_seconds": Int64,
    "shift_start": String,
    "shift_end": String,
    "goalie": Int64,
    "is_home": Int64,
    "is_away": Int64,
    "team_venue": String,
}


class PBPEvent(BaseModel):
    """Pydantic model for validating play-by-play data."""

    id: int
    season: int
    session: str
    game_id: int
    game_date: str
    event_idx: int
    period: int
    period_seconds: int
    game_seconds: int
    strength_state: str
    event_team: str | None = None
    opp_team: str | None = None
    event: str
    description: str | None = None
    zone: str | None = None
    coords_x: int | None = None
    coords_y: int | None = None
    danger: int | None = None
    high_danger: int | None = None
    player_1: str | None = None
    player_1_eh_id: str | None = None
    player_1_eh_id_api: str | None = None
    player_1_api_id: int | str | None = None
    player_1_position: str | None = None
    player_1_type: str | None = None
    player_2: str | None = None
    player_2_eh_id: str | None = None
    player_2_eh_id_api: str | None = None
    player_2_api_id: int | str | None = None
    player_2_position: str | None = None
    player_2_type: str | None = None
    player_3: str | None = None
    player_3_eh_id: str | None = None
    player_3_eh_id_api: str | None = None
    player_3_api_id: int | str | None = None
    player_3_position: str | None = None
    player_3_type: str | None = None
    score_state: str
    score_diff: int
    forwards_percent: float = 0
    opp_forwards_percent: float = 0
    shot_type: str | None = None
    event_length: int
    event_distance: float | None = None
    pbp_distance: int | None = None
    event_angle: float | None = None
    penalty: str | None = None
    penalty_length: int | None = None
    home_score: int
    home_score_diff: int
    away_score: int
    away_score_diff: int
    is_home: int
    is_away: int
    home_team: str
    away_team: str
    home_skaters: int
    away_skaters: int
    home_on: list | str | None = None
    home_on_eh_id: list | str | None = None
    home_on_api_id: list | str | None = None
    home_on_positions: list | str | None = None
    away_on: list | str | None = None
    away_on_eh_id: list | str | None = None
    away_on_api_id: list | str | None = None
    away_on_positions: list | str | None = None
    event_team_skaters: int | None = None
    teammates: list | str | None = None
    teammates_eh_id: list | str | None = None
    teammates_api_id: list | str | None = None
    teammates_positions: list | str | None = None
    own_goalie: list | str | None = None
    own_goalie_eh_id: list | str | None = None
    own_goalie_api_id: list | str | None = None
    forwards: list | str | None = None
    forwards_eh_id: list | str | None = None
    forwards_api_id: list | str | None = None
    forwards_count: int | None = None
    defense: list | str | None = None
    defense_eh_id: list | str | None = None
    defense_api_id: list | str | None = None
    defense_count: int | None = None
    opp_strength_state: str | None = None
    opp_score_state: str | None = None
    opp_score_diff: int | None = None
    opp_team_skaters: int | None = None
    opp_team_on: list | str | None = None
    opp_team_on_eh_id: list | str | None = None
    opp_team_on_api_id: list | str | None = None
    opp_team_on_positions: list | str | None = None
    opp_goalie: list | str | None = None
    opp_goalie_eh_id: list | str | None = None
    opp_goalie_api_id: list | str | None = None
    opp_forwards: list | str | None = None
    opp_forwards_eh_id: list | str | None = None
    opp_forwards_api_id: list | str | None = None
    opp_forwards_count: int | None = None
    opp_defense: list | str | None = None
    opp_defense_eh_id: list | str | None = None
    opp_defense_api_id: list | str | None = None
    opp_defense_count: int | None = None
    home_forwards: list | str | None = None
    home_forwards_eh_id: list | str | None = None
    home_forwards_api_id: list | str | None = None
    home_forwards_count: int | None = None
    home_forwards_percent: float = 0
    home_defense: list | str | None = None
    home_defense_eh_id: list | str | None = None
    home_defense_api_id: list | str | None = None
    home_defense_count: int | None = None
    home_goalie: list | str | None = None
    home_goalie_eh_id: list | str | None = None
    home_goalie_api_id: list | str | None = None
    away_forwards: list | str | None = None
    away_forwards_eh_id: list | str | None = None
    away_forwards_api_id: list | str | None = None
    away_forwards_count: int | None = None
    away_forwards_percent: float = 0
    away_defense: list | str | None = None
    away_defense_eh_id: list | str | None = None
    away_defense_api_id: list | str | None = None
    away_defense_count: int | None = None
    away_goalie: list | str | None = None
    away_goalie_eh_id: list | str | None = None
    away_goalie_api_id: list | str | None = None
    change_on_count: int | None = None
    change_off_count: int | None = None
    change_on: list | str | None = None
    change_on_eh_id: list | str | None = None
    change_on_api_id: list | str | None = None
    change_on_positions: list | str | None = None
    change_off: list | str | None = None
    change_off_eh_id: list | str | None = None
    change_off_api_id: list | str | None = None
    change_off_positions: list | str | None = None
    change_on_forwards_count: int | None = None
    change_off_forwards_count: int | None = None
    change_on_forwards: list | str | None = None
    change_on_forwards_eh_id: list | str | None = None
    change_on_forwards_api_id: list | str | None = None
    change_off_forwards: list | str | None = None
    change_off_forwards_eh_id: list | str | None = None
    change_off_forwards_api_id: list | str | None = None
    change_on_defense_count: int | None = None
    change_off_defense_count: int | None = None
    change_on_defense: list | str | None = None
    change_on_defense_eh_id: list | str | None = None
    change_on_defense_api_id: list | str | None = None
    change_off_defense: list | str | None = None
    change_off_defense_eh_id: list | str | None = None
    change_off_defense_api_id: list | str | None = None
    change_on_goalie_count: int | None = None
    change_off_goalie_count: int | None = None
    change_on_goalie: list | str | None = None
    change_on_goalie_eh_id: list | str | None = None
    change_on_goalie_api_id: list | str | None = None
    change_off_goalie: list | str | None = None
    change_off_goalie_eh_id: list | str | None = None
    change_off_goalie_api_id: list | str | None = None
    pred_goal: float = 0
    pred_goal_adj: float = 0
    goal: int = 0
    goal_adj: float = 0
    hd_goal: int = 0
    shot: int = 0
    shot_adj: float = 0
    hd_shot: int = 0
    miss: int = 0
    miss_adj: float = 0
    hd_miss: int = 0
    fenwick: int = 0
    fenwick_adj: float = 0
    hd_fenwick: int = 0
    corsi: int = 0
    corsi_adj: float = 0
    block: int = 0
    block_adj: float = 0
    teammate_block: int = 0
    teammate_block_adj: float = 0
    hit: int = 0
    give: int = 0
    take: int = 0
    fac: int = 0
    penl: int = 0
    change: int = 0
    stop: int = 0
    chl: int = 0
    ozf: int = 0
    nzf: int = 0
    dzf: int = 0
    ozc: int = 0
    nzc: int = 0
    dzc: int = 0
    otf: int = 0
    pen0: int = 0
    pen2: int = 0
    pen4: int = 0
    pen5: int = 0
    pen10: int = 0

    @field_validator("*", mode="before")
    @classmethod
    def invalid_strings(cls, v):
        """Changes blank strings into None."""
        if v == "" or v == " " or v == "nan":
            return None

        else:
            return v

    @field_validator(
        "home_on",
        "home_on_eh_id",
        "home_on_api_id",
        "home_on_positions",
        "home_forwards",
        "home_forwards_eh_id",
        "home_forwards_api_id",
        "home_defense",
        "home_defense_eh_id",
        "home_defense_api_id",
        "home_goalie",
        "home_goalie_eh_id",
        "home_goalie_api_id",
        "away_on",
        "away_on_eh_id",
        "away_on_api_id",
        "away_on_positions",
        "away_forwards",
        "away_forwards_eh_id",
        "away_forwards_api_id",
        "away_defense",
        "away_defense_eh_id",
        "away_defense_api_id",
        "away_goalie",
        "away_goalie_eh_id",
        "away_goalie_api_id",
        "teammates",
        "teammates_eh_id",
        "teammates_api_id",
        "teammates_positions",
        "forwards",
        "forwards_eh_id",
        "forwards_api_id",
        "defense",
        "defense_eh_id",
        "defense_api_id",
        "own_goalie",
        "own_goalie_eh_id",
        "own_goalie_api_id",
        "opp_team_on",
        "opp_team_on_eh_id",
        "opp_team_on_api_id",
        "opp_team_on_positions",
        "opp_forwards",
        "opp_forwards_eh_id",
        "opp_forwards_api_id",
        "opp_defense",
        "opp_defense_eh_id",
        "opp_defense_api_id",
        "opp_goalie",
        "opp_goalie_eh_id",
        "opp_goalie_api_id",
        "change_on",
        "change_on_eh_id",
        "change_on_api_id",
        "change_on_positions",
        "change_off",
        "change_off_eh_id",
        "change_off_api_id",
        "change_off_positions",
        "change_on_forwards",
        "change_on_forwards_eh_id",
        "change_on_forwards_api_id",
        "change_off_forwards",
        "change_off_forwards_eh_id",
        "change_off_forwards_api_id",
        "change_on_defense",
        "change_on_defense_eh_id",
        "change_off_defense",
        "change_off_defense_eh_id",
        "change_off_defense_api_id",
        "change_on_goalie",
        "change_on_goalie_eh_id",
        "change_on_goalie_api_id",
        "change_off_goalie",
        "change_off_goalie_eh_id",
        "change_off_goalie_api_id",
        mode="before",
    )
    @classmethod
    def fix_list(cls, v):
        """Converts lists into strings."""
        if v and isinstance(v, list) is True:
            return ", ".join(v)

        elif not v:
            return None

        else:
            return v

    @field_validator(
        "own_goalie",
        "own_goalie_eh_id",
        "own_goalie_api_id",
        "opp_goalie",
        "opp_goalie_eh_id",
        "opp_goalie_api_id",
        "home_goalie",
        "home_goalie_eh_id",
        "home_goalie_api_id",
        "away_goalie",
        "away_goalie_eh_id",
        "away_goalie_api_id",
        mode="before",
    )
    @classmethod
    def fix_goalies(cls, v):
        """If goalie is None, converts to EMPTY NET."""
        if v is None:
            return "EMPTY NET"

        else:
            return v

    @field_validator(
        "pred_goal",
        "pred_goal_adj",
        "goal",
        "goal_adj",
        "hd_goal",
        "shot",
        "shot_adj",
        "hd_shot",
        "miss",
        "miss_adj",
        "hd_miss",
        "fenwick",
        "fenwick_adj",
        "hd_fenwick",
        "corsi",
        "corsi_adj",
        "block",
        "block_adj",
        "teammate_block",
        "teammate_block_adj",
        "hit",
        "give",
        "take",
        "fac",
        "penl",
        "change",
        "stop",
        "chl",
        "ozf",
        "nzf",
        "dzf",
        "ozc",
        "nzc",
        "dzc",
        "otf",
        "pen0",
        "pen2",
        "pen4",
        "pen5",
        "pen10",
        mode="before",
        check_fields=False,
    )
    @classmethod
    def fix_stats(cls, v):
        """If goalie is None, converts to EMPTY NET."""
        if not v:
            return 0

        else:
            return v


class PBPEventExt(BaseModel):
    """Pydantic model for validating play-by-play data."""

    id: int
    event_idx: int
    event_on_1: str | None = None
    event_on_1_eh_id: str | None = None
    event_on_1_api_id: str | None = None
    event_on_1_pos: str | None = None
    event_on_2: str | None = None
    event_on_2_eh_id: str | None = None
    event_on_2_api_id: str | None = None
    event_on_2_pos: str | None = None
    event_on_3: str | None = None
    event_on_3_eh_id: str | None = None
    event_on_3_api_id: str | None = None
    event_on_3_pos: str | None = None
    event_on_4: str | None = None
    event_on_4_eh_id: str | None = None
    event_on_4_api_id: str | None = None
    event_on_4_pos: str | None = None
    event_on_5: str | None = None
    event_on_5_eh_id: str | None = None
    event_on_5_api_id: str | None = None
    event_on_5_pos: str | None = None
    event_on_6: str | None = None
    event_on_6_eh_id: str | None = None
    event_on_6_api_id: str | None = None
    event_on_6_pos: str | None = None
    event_on_7: str | None = None
    event_on_7_eh_id: str | None = None
    event_on_7_api_id: str | None = None
    event_on_7_pos: str | None = None
    opp_on_1: str | None = None
    opp_on_1_eh_id: str | None = None
    opp_on_1_api_id: str | None = None
    opp_on_1_pos: str | None = None
    opp_on_2: str | None = None
    opp_on_2_eh_id: str | None = None
    opp_on_2_api_id: str | None = None
    opp_on_2_pos: str | None = None
    opp_on_3: str | None = None
    opp_on_3_eh_id: str | None = None
    opp_on_3_api_id: str | None = None
    opp_on_3_pos: str | None = None
    opp_on_4: str | None = None
    opp_on_4_eh_id: str | None = None
    opp_on_4_api_id: str | None = None
    opp_on_4_pos: str | None = None
    opp_on_5: str | None = None
    opp_on_5_eh_id: str | None = None
    opp_on_5_api_id: str | None = None
    opp_on_5_pos: str | None = None
    opp_on_6: str | None = None
    opp_on_6_eh_id: str | None = None
    opp_on_6_api_id: str | None = None
    opp_on_6_pos: str | None = None
    opp_on_7: str | None = None
    opp_on_7_eh_id: str | None = None
    opp_on_7_api_id: str | None = None
    opp_on_7_pos: str | None = None
    change_on_1: str | None = None
    change_on_1_eh_id: str | None = None
    change_on_1_api_id: str | None = None
    change_on_1_pos: str | None = None
    change_on_2: str | None = None
    change_on_2_eh_id: str | None = None
    change_on_2_api_id: str | None = None
    change_on_2_pos: str | None = None
    change_on_3: str | None = None
    change_on_3_eh_id: str | None = None
    change_on_3_api_id: str | None = None
    change_on_3_pos: str | None = None
    change_on_4: str | None = None
    change_on_4_eh_id: str | None = None
    change_on_4_api_id: str | None = None
    change_on_4_pos: str | None = None
    change_on_5: str | None = None
    change_on_5_eh_id: str | None = None
    change_on_5_api_id: str | None = None
    change_on_5_pos: str | None = None
    change_on_6: str | None = None
    change_on_6_eh_id: str | None = None
    change_on_6_api_id: str | None = None
    change_on_6_pos: str | None = None
    change_on_7: str | None = None
    change_on_7_eh_id: str | None = None
    change_on_7_api_id: str | None = None
    change_on_7_pos: str | None = None
    change_off_1: str | None = None
    change_off_1_eh_id: str | None = None
    change_off_1_api_id: str | None = None
    change_off_1_pos: str | None = None
    change_off_2: str | None = None
    change_off_2_eh_id: str | None = None
    change_off_2_api_id: str | None = None
    change_off_2_pos: str | None = None
    change_off_3: str | None = None
    change_off_3_eh_id: str | None = None
    change_off_3_api_id: str | None = None
    change_off_3_pos: str | None = None
    change_off_4: str | None = None
    change_off_4_eh_id: str | None = None
    change_off_4_api_id: str | None = None
    change_off_4_pos: str | None = None
    change_off_5: str | None = None
    change_off_5_eh_id: str | None = None
    change_off_5_api_id: str | None = None
    change_off_5_pos: str | None = None
    change_off_6: str | None = None
    change_off_6_eh_id: str | None = None
    change_off_6_api_id: str | None = None
    change_off_6_pos: str | None = None
    change_off_7: str | None = None
    change_off_7_eh_id: str | None = None
    change_off_7_api_id: str | None = None
    change_off_7_pos: str | None = None


PBPExtSchemaPolars = {
    "id": Int64,
    "event_idx": Int64,
    "event_on_1": String,
    "event_on_1_eh_id": String,
    "event_on_1_api_id": String,
    "event_on_1_pos": String,
    "event_on_2": String,
    "event_on_2_eh_id": String,
    "event_on_2_api_id": String,
    "event_on_2_pos": String,
    "event_on_3": String,
    "event_on_3_eh_id": String,
    "event_on_3_api_id": String,
    "event_on_3_pos": String,
    "event_on_4": String,
    "event_on_4_eh_id": String,
    "event_on_4_api_id": String,
    "event_on_4_pos": String,
    "event_on_5": String,
    "event_on_5_eh_id": String,
    "event_on_5_api_id": String,
    "event_on_5_pos": String,
    "event_on_6": String,
    "event_on_6_eh_id": String,
    "event_on_6_api_id": String,
    "event_on_6_pos": String,
    "event_on_7": String,
    "event_on_7_eh_id": String,
    "event_on_7_api_id": String,
    "event_on_7_pos": String,
    "opp_on_1": String,
    "opp_on_1_eh_id": String,
    "opp_on_1_api_id": String,
    "opp_on_1_pos": String,
    "opp_on_2": String,
    "opp_on_2_eh_id": String,
    "opp_on_2_api_id": String,
    "opp_on_2_pos": String,
    "opp_on_3": String,
    "opp_on_3_eh_id": String,
    "opp_on_3_api_id": String,
    "opp_on_3_pos": String,
    "opp_on_4": String,
    "opp_on_4_eh_id": String,
    "opp_on_4_api_id": String,
    "opp_on_4_pos": String,
    "opp_on_5": String,
    "opp_on_5_eh_id": String,
    "opp_on_5_api_id": String,
    "opp_on_5_pos": String,
    "opp_on_6": String,
    "opp_on_6_eh_id": String,
    "opp_on_6_api_id": String,
    "opp_on_6_pos": String,
    "opp_on_7": String,
    "opp_on_7_eh_id": String,
    "opp_on_7_api_id": String,
    "opp_on_7_pos": String,
    "change_on_1": String,
    "change_on_1_eh_id": String,
    "change_on_1_api_id": String,
    "change_on_1_pos": String,
    "change_on_2": String,
    "change_on_2_eh_id": String,
    "change_on_2_api_id": String,
    "change_on_2_pos": String,
    "change_on_3": String,
    "change_on_3_eh_id": String,
    "change_on_3_api_id": String,
    "change_on_3_pos": String,
    "change_on_4": String,
    "change_on_4_eh_id": String,
    "change_on_4_api_id": String,
    "change_on_4_pos": String,
    "change_on_5": String,
    "change_on_5_eh_id": String,
    "change_on_5_api_id": String,
    "change_on_5_pos": String,
    "change_on_6": String,
    "change_on_6_eh_id": String,
    "change_on_6_api_id": String,
    "change_on_6_pos": String,
    "change_on_7": String,
    "change_on_7_eh_id": String,
    "change_on_7_api_id": String,
    "change_on_7_pos": String,
    "change_off_1": String,
    "change_off_1_eh_id": String,
    "change_off_1_api_id": String,
    "change_off_1_pos": String,
    "change_off_2": String,
    "change_off_2_eh_id": String,
    "change_off_2_api_id": String,
    "change_off_2_pos": String,
    "change_off_3": String,
    "change_off_3_eh_id": String,
    "change_off_3_api_id": String,
    "change_off_3_pos": String,
    "change_off_4": String,
    "change_off_4_eh_id": String,
    "change_off_4_api_id": String,
    "change_off_4_pos": String,
    "change_off_5": String,
    "change_off_5_eh_id": String,
    "change_off_5_api_id": String,
    "change_off_5_pos": String,
    "change_off_6": String,
    "change_off_6_eh_id": String,
    "change_off_6_api_id": String,
    "change_off_6_pos": String,
    "change_off_7": String,
    "change_off_7_eh_id": String,
    "change_off_7_api_id": String,
    "change_off_7_pos": String,
}


class XGFields(BaseModel):
    """Pydantic model for validating xG data before making predictions."""

    period: int
    period_seconds: int
    score_diff: int
    danger: int
    high_danger: int
    position_f: int
    position_d: int
    position_g: int
    event_distance: float
    event_angle: float
    is_rebound: int
    rush_attempt: int
    is_home: int
    seconds_since_last: int
    distance_from_last: float
    # forwards_percent: float
    # forwards_count: int
    # opp_forwards_percent: float
    # opp_forwards_count: int
    prior_shot_same: int
    prior_miss_same: int
    prior_block_same: int
    prior_give_same: int
    prior_take_same: int
    prior_hit_same: int
    prior_shot_opp: int
    prior_miss_opp: int
    prior_block_opp: int
    prior_give_opp: int
    prior_take_opp: int
    prior_hit_opp: int
    prior_face: int
    backhand: int
    bat: int
    between_legs: int
    cradle: int
    deflected: int
    poke: int
    slap: int
    snap: int
    tip_in: int
    wrap_around: int
    wrist: int
    strength_state_3v3: int | None = None
    strength_state_4v4: int | None = None
    strength_state_5v5: int | None = None
    strength_state_3v4: int | None = None
    strength_state_3v5: int | None = None
    strength_state_4v5: int | None = None
    strength_state_4v3: int | None = None
    strength_state_5v3: int | None = None
    strength_state_5v4: int | None = None
    strength_state_Ev3: int | None = None
    strength_state_Ev4: int | None = None
    strength_state_Ev5: int | None = None
    strength_state_3vE: int | None = None
    strength_state_4vE: int | None = None
    strength_state_5vE: int | None = None


class ScheduleGame(BaseModel):
    """Pydantic model for validating schedule data."""

    season: int
    session: int
    game_id: int
    game_date: str
    start_time: str
    game_state: str
    home_team: str
    home_team_id: int
    home_score: int
    away_team: str
    away_team_id: int
    away_score: int
    venue: str
    venue_timezone: str
    neutral_site: int
    game_date_dt_local: dt.datetime
    game_date_dt_utc: dt.datetime
    tv_broadcasts: list
    home_logo: str
    home_logo_dark: str
    away_logo: str
    away_logo_dark: str


ScheduleSchemaPolars = {
    "season": Int64,
    "session": Int64,
    "game_id": Int64,
    "game_date": String,
    "start_time": String,
    "game_state": String,
    "home_team": String,
    "home_team_id": Int64,
    "home_score": Int64,
    "away_team": String,
    "away_team_id": Int64,
    "away_score": Int64,
    "venue": String,
    "venue_timezone": String,
    "neutral_site": Int64,
    "game_date_dt_utc": Datetime(time_unit="us", time_zone="UTC"),
    "tv_broadcasts": List(
        Struct({"id": Int64, "market": String, "countryCode": String, "network": String, "sequenceNumber": Int64})
    ),
    "home_logo": String,
    "home_logo_dark": String,
    "away_logo": String,
    "away_logo_dark": String,
}


class StandingsTeam(BaseModel):
    """Pydantic model for validating standings data."""

    season: int
    date: str
    team: str
    team_name: str
    conference: str | None
    division: str | None
    games_played: int
    points: int = None
    points_pct: float = None
    wins: int
    regulation_wins: int
    shootout_wins: int = None
    losses: int
    ot_losses: int = None
    shootout_losses: int = None
    ties: int = None
    win_pct: float
    regulation_win_pct: float
    streak_code: str
    streak_count: int
    goals_for: int
    goals_against: int
    goals_for_pct: float
    goal_differential: int
    goal_differential_pct: float
    home_games_played: int
    home_points: int
    home_goals_for: int
    home_goals_against: int
    home_goal_differential: int
    home_wins: int
    home_losses: int
    home_ot_losses: int
    home_ties: int
    home_regulation_wins: int
    road_games_played: int
    road_points: int
    road_goals_for: int
    road_goals_against: int
    road_goal_differential: int
    road_wins: int
    road_losses: int
    road_ot_losses: int
    road_ties: int
    road_regulation_wins: int
    l10_points: int
    l10_goals_for: int
    l10_goals_against: int
    l10_goal_differential: int
    l10_goals_for: int
    l10_wins: int
    l10_losses: int
    l10_ot_losses: int
    l10_ties: int
    l10_regulation_wins: int
    team_logo: str
    wildcard_sequence: int
    waivers_sequence: int


StandingsSchemaPolars = {
    "season": Int64,
    "date": String,
    "team": String,
    "team_name": String,
    "conference": String,
    "division": String,
    "games_played": Int64,
    "points": Int64,
    "points_pct": Float64,
    "wins": Int64,
    "regulation_wins": Int64,
    "shootout_wins": Int64,
    "losses": Int64,
    "ot_losses": Int64,
    "shootout_losses": Int64,
    "ties": Int64,
    "win_pct": Float64,
    "regulation_win_pct": Float64,
    "streak_code": String,
    "streak_count": Int64,
    "goals_for": Int64,
    "goals_against": Int64,
    "goals_for_pct": Float64,
    "goal_differential": Int64,
    "goal_differential_pct": Float64,
    "home_games_played": Int64,
    "home_points": Int64,
    "home_goals_for": Int64,
    "home_goals_against": Int64,
    "home_goal_differential": Int64,
    "home_wins": Int64,
    "home_losses": Int64,
    "home_ot_losses": Int64,
    "home_ties": Int64,
    "home_regulation_wins": Int64,
    "road_games_played": Int64,
    "road_points": Int64,
    "road_goals_for": Int64,
    "road_goals_against": Int64,
    "road_goal_differential": Int64,
    "road_wins": Int64,
    "road_losses": Int64,
    "road_ot_losses": Int64,
    "road_ties": Int64,
    "road_regulation_wins": Int64,
    "l10_points": Int64,
    "l10_goals_for": Int64,
    "l10_goals_against": Int64,
    "l10_goal_differential": Int64,
    "l10_wins": Int64,
    "l10_losses": Int64,
    "l10_ot_losses": Int64,
    "l10_ties": Int64,
    "l10_regulation_wins": Int64,
    "team_logo": String,
    "wildcard_sequence": Int64,
    "waivers_sequence": Int64,
}

PBPSchema = DataFrameSchema(
    columns={
        "id": Column(int),
        "season": Column(int),
        "session": Column(str),
        "game_id": Column(int),
        "game_date": Column(str),
        "event_idx": Column(int),
        "period": Column(int),
        "period_seconds": Column(int),
        "game_seconds": Column(int),
        "strength_state": Column(str),
        "event_team": Column(str, nullable=True),
        "opp_team": Column(str, nullable=True),
        "event": Column(str),
        "description": Column(str, nullable=True),
        "zone": Column(str, nullable=True),
        "coords_x": Column(float, nullable=True),
        "coords_y": Column(float, nullable=True),
        "danger": Column(int, default=0),
        "high_danger": Column(int, default=0),
        "player_1": Column(str, nullable=True),
        "player_1_eh_id": Column(str, nullable=True),
        "player_1_eh_id_api": Column(str, nullable=True),
        "player_1_api_id": Column(str, nullable=True),
        "player_1_position": Column(str, nullable=True),
        "player_1_type": Column(str, nullable=True),
        "player_2": Column(str, nullable=True),
        "player_2_eh_id": Column(str, nullable=True),
        "player_2_eh_id_api": Column(str, nullable=True),
        "player_2_api_id": Column(str, nullable=True),
        "player_2_position": Column(str, nullable=True),
        "player_2_type": Column(str, nullable=True),
        "player_3": Column(str, nullable=True),
        "player_3_eh_id": Column(str, nullable=True),
        "player_3_eh_id_api": Column(str, nullable=True),
        "player_3_api_id": Column(str, nullable=True),
        "player_3_position": Column(str, nullable=True),
        "player_3_type": Column(str, nullable=True),
        "score_state": Column(str),
        "score_diff": Column(int),
        "forwards_percent": Column(float, default=0.0),
        "opp_forwards_percent": Column(float, default=0.0),
        "shot_type": Column(str, nullable=True),
        "event_length": Column(int),
        "event_distance": Column(float, nullable=True),
        "pbp_distance": Column("Int64", nullable=True),
        "event_angle": Column(float, nullable=True),
        "penalty": Column(str, nullable=True),
        "penalty_length": Column("Int64", nullable=True),
        "home_score": Column(int),
        "home_score_diff": Column(int),
        "away_score": Column(int),
        "away_score_diff": Column(int),
        "is_home": Column(int, default=0),
        "is_away": Column(int, default=0),
        "home_team": Column(str),
        "away_team": Column(str),
        "home_skaters": Column(int),
        "away_skaters": Column(int),
        "home_on": Column(str, nullable=True),
        "home_on_eh_id": Column(str, nullable=True),
        "home_on_api_id": Column(str, nullable=True),
        "home_on_positions": Column(str, nullable=True),
        "away_on": Column(str, nullable=True),
        "away_on_eh_id": Column(str, nullable=True),
        "away_on_api_id": Column(str, nullable=True),
        "away_on_positions": Column(str, nullable=True),
        "event_team_skaters": Column("Int64", nullable=True),
        "teammates": Column(str, nullable=True),
        "teammates_eh_id": Column(str, nullable=True),
        "teammates_api_id": Column(str, nullable=True),
        "teammates_positions": Column(str, nullable=True),
        "own_goalie": Column(str, nullable=True),
        "own_goalie_eh_id": Column(str, nullable=True),
        "own_goalie_api_id": Column(str, nullable=True),
        "forwards": Column(str, nullable=True),
        "forwards_eh_id": Column(str, nullable=True),
        "forwards_api_id": Column(str, nullable=True),
        "forwards_count": Column("Int64", nullable=True),
        "defense": Column(str, nullable=True),
        "defense_eh_id": Column(str, nullable=True),
        "defense_api_id": Column(str, nullable=True),
        "defense_count": Column("Int64", nullable=True),
        "opp_strength_state": Column(str, nullable=True),
        "opp_score_state": Column(str, nullable=True),
        "opp_score_diff": Column("Int64", nullable=True),
        "opp_team_skaters": Column("Int64", nullable=True),
        "opp_team_on": Column(str, nullable=True),
        "opp_team_on_eh_id": Column(str, nullable=True),
        "opp_team_on_api_id": Column(str, nullable=True),
        "opp_team_on_positions": Column(str, nullable=True),
        "opp_goalie": Column(str, nullable=True),
        "opp_goalie_eh_id": Column(str, nullable=True),
        "opp_goalie_api_id": Column(str, nullable=True),
        "opp_forwards": Column(str, nullable=True),
        "opp_forwards_eh_id": Column(str, nullable=True),
        "opp_forwards_api_id": Column(str, nullable=True),
        "opp_forwards_count": Column("Int64", nullable=True),
        "opp_defense": Column(str, nullable=True),
        "opp_defense_eh_id": Column(str, nullable=True),
        "opp_defense_api_id": Column(str, nullable=True),
        "opp_defense_count": Column("Int64", nullable=True),
        "home_forwards": Column(str, nullable=True),
        "home_forwards_eh_id": Column(str, nullable=True),
        "home_forwards_api_id": Column(str, nullable=True),
        "home_forwards_count": Column("Int64", nullable=True),
        "home_forwards_percent": Column(float, default=0.0),
        "home_defense": Column(str, nullable=True),
        "home_defense_eh_id": Column(str, nullable=True),
        "home_defense_api_id": Column(str, nullable=True),
        "home_defense_count": Column("Int64", nullable=True),
        "home_goalie": Column(str, nullable=True),
        "home_goalie_eh_id": Column(str, nullable=True),
        "home_goalie_api_id": Column(str, nullable=True),
        "away_forwards": Column(str, nullable=True),
        "away_forwards_eh_id": Column(str, nullable=True),
        "away_forwards_api_id": Column(str, nullable=True),
        "away_forwards_count": Column("Int64", nullable=True),
        "away_forwards_percent": Column(float, default=0.0),
        "away_defense": Column(str, nullable=True),
        "away_defense_eh_id": Column(str, nullable=True),
        "away_defense_api_id": Column(str, nullable=True),
        "away_defense_count": Column("Int64", nullable=True),
        "away_goalie": Column(str, nullable=True),
        "away_goalie_eh_id": Column(str, nullable=True),
        "away_goalie_api_id": Column(str, nullable=True),
        "change_on_count": Column("Int64", nullable=True),
        "change_off_count": Column("Int64", nullable=True),
        "change_on": Column(str, nullable=True),
        "change_on_eh_id": Column(str, nullable=True),
        "change_on_api_id": Column(str, nullable=True),
        "change_on_positions": Column(str, nullable=True),
        "change_off": Column(str, nullable=True),
        "change_off_eh_id": Column(str, nullable=True),
        "change_off_api_id": Column(str, nullable=True),
        "change_off_positions": Column(str, nullable=True),
        "change_on_forwards_count": Column("Int64", nullable=True),
        "change_off_forwards_count": Column("Int64", nullable=True),
        "change_on_forwards": Column(str, nullable=True),
        "change_on_forwards_eh_id": Column(str, nullable=True),
        "change_on_forwards_api_id": Column(str, nullable=True),
        "change_off_forwards": Column(str, nullable=True),
        "change_off_forwards_eh_id": Column(str, nullable=True),
        "change_off_forwards_api_id": Column(str, nullable=True),
        "change_on_defense_count": Column("Int64", nullable=True),
        "change_off_defense_count": Column("Int64", nullable=True),
        "change_on_defense": Column(str, nullable=True),
        "change_on_defense_eh_id": Column(str, nullable=True),
        "change_on_defense_api_id": Column(str, nullable=True),
        "change_off_defense": Column(str, nullable=True),
        "change_off_defense_eh_id": Column(str, nullable=True),
        "change_off_defense_api_id": Column(str, nullable=True),
        "change_on_goalie_count": Column("Int64", nullable=True),
        "change_off_goalie_count": Column("Int64", nullable=True),
        "change_on_goalie": Column(str, nullable=True),
        "change_on_goalie_eh_id": Column(str, nullable=True),
        "change_on_goalie_api_id": Column(str, nullable=True),
        "change_off_goalie": Column(str, nullable=True),
        "change_off_goalie_eh_id": Column(str, nullable=True),
        "change_off_goalie_api_id": Column(str, nullable=True),
        "pred_goal": Column(float, default=0.0),
        "pred_goal_adj": Column(float, default=0.0),
        "goal": Column(int, default=0),
        "goal_adj": Column(float, default=0.0),
        "hd_goal": Column(int, default=0),
        "shot": Column(int, default=0),
        "shot_adj": Column(float, default=0.0),
        "hd_shot": Column(int, default=0),
        "miss": Column(int, default=0),
        "miss_adj": Column(float, default=0.0),
        "hd_miss": Column(int, default=0),
        "fenwick": Column(int, default=0),
        "fenwick_adj": Column(float, default=0.0),
        "hd_fenwick": Column(int, default=0),
        "corsi": Column(int, default=0),
        "corsi_adj": Column(float, default=0.0),
        "block": Column(int, default=0),
        "block_adj": Column(float, default=0.0),
        "teammate_block": Column(int, default=0),
        "teammate_block_adj": Column(float, default=0.0),
        "hit": Column(int, default=0),
        "give": Column(int, default=0),
        "take": Column(int, default=0),
        "fac": Column(int, default=0),
        "penl": Column(int, default=0),
        "change": Column(int, default=0),
        "stop": Column(int, default=0),
        "chl": Column(int, default=0),
        "ozf": Column(int, default=0),
        "nzf": Column(int, default=0),
        "dzf": Column(int, default=0),
        "ozc": Column(int, default=0),
        "nzc": Column(int, default=0),
        "dzc": Column(int, default=0),
        "otf": Column(int, default=0),
        "pen0": Column(int, default=0),
        "pen2": Column(int, default=0),
        "pen4": Column(int, default=0),
        "pen5": Column(int, default=0),
        "pen10": Column(int, default=0),
    },
    strict="filter",
    add_missing_columns=True,
    coerce=True,
    ordered=True,
)

PBPSchemaPolars = {
    "id": Int64,
    "season": Int64,
    "session": String,
    "game_id": Int64,
    "game_date": String,
    "event_idx": Int64,
    "period": Int64,
    "period_seconds": Int64,
    "game_seconds": Int64,
    "strength_state": String,
    "event_team": String,
    "opp_team": String,
    "event": String,
    "description": String,
    "zone": String,
    "coords_x": Int64,
    "coords_y": Int64,
    "danger": Int64,
    "high_danger": Int64,
    "player_1": String,
    "player_1_eh_id": String,
    "player_1_eh_id_api": String,
    "player_1_api_id": String,
    "player_1_position": String,
    "player_1_type": String,
    "player_2": String,
    "player_2_eh_id": String,
    "player_2_eh_id_api": String,
    "player_2_api_id": String,
    "player_2_position": String,
    "player_2_type": String,
    "player_3": String,
    "player_3_eh_id": String,
    "player_3_eh_id_api": String,
    "player_3_api_id": String,
    "player_3_position": String,
    "player_3_type": String,
    "score_state": String,
    "score_diff": Int64,
    "forwards_percent": Float64,
    "opp_forwards_percent": Float64,
    "shot_type": String,
    "event_length": Int64,
    "event_distance": Float64,
    "pbp_distance": Int64,
    "event_angle": Float64,
    "penalty": String,
    "penalty_length": Int64,
    "home_score": Int64,
    "home_score_diff": Int64,
    "away_score": Int64,
    "away_score_diff": Int64,
    "is_home": Int64,
    "is_away": Int64,
    "home_team": String,
    "away_team": String,
    "home_skaters": Int64,
    "away_skaters": Int64,
    "home_on": String,
    "home_on_eh_id": String,
    "home_on_api_id": String,
    "home_on_positions": String,
    "away_on": String,
    "away_on_eh_id": String,
    "away_on_api_id": String,
    "away_on_positions": String,
    "event_team_skaters": Int64,
    "teammates": String,
    "teammates_eh_id": String,
    "teammates_api_id": String,
    "teammates_positions": String,
    "own_goalie": String,
    "own_goalie_eh_id": String,
    "own_goalie_api_id": String,
    "forwards": String,
    "forwards_eh_id": String,
    "forwards_api_id": String,
    "forwards_count": Int64,
    "defense": String,
    "defense_eh_id": String,
    "defense_api_id": String,
    "defense_count": Int64,
    "opp_strength_state": String,
    "opp_score_state": String,
    "opp_score_diff": Int64,
    "opp_team_skaters": Int64,
    "opp_team_on": String,
    "opp_team_on_eh_id": String,
    "opp_team_on_api_id": String,
    "opp_team_on_positions": String,
    "opp_goalie": String,
    "opp_goalie_eh_id": String,
    "opp_goalie_api_id": String,
    "opp_forwards": String,
    "opp_forwards_eh_id": String,
    "opp_forwards_api_id": String,
    "opp_forwards_count": Int64,
    "opp_defense": String,
    "opp_defense_eh_id": String,
    "opp_defense_api_id": String,
    "opp_defense_count": Int64,
    "home_forwards": String,
    "home_forwards_eh_id": String,
    "home_forwards_api_id": String,
    "home_forwards_count": Int64,
    "home_forwards_percent": Float64,
    "home_defense": String,
    "home_defense_eh_id": String,
    "home_defense_api_id": String,
    "home_defense_count": Int64,
    "home_goalie": String,
    "home_goalie_eh_id": String,
    "home_goalie_api_id": String,
    "away_forwards": String,
    "away_forwards_eh_id": String,
    "away_forwards_api_id": String,
    "away_forwards_count": Int64,
    "away_forwards_percent": Float64,
    "away_defense": String,
    "away_defense_eh_id": String,
    "away_defense_api_id": String,
    "away_defense_count": Int64,
    "away_goalie": String,
    "away_goalie_eh_id": String,
    "away_goalie_api_id": String,
    "change_on_count": Int64,
    "change_off_count": Int64,
    "change_on": String,
    "change_on_eh_id": String,
    "change_on_api_id": String,
    "change_on_positions": String,
    "change_off": String,
    "change_off_eh_id": String,
    "change_off_api_id": String,
    "change_off_positions": String,
    "change_on_forwards_count": Int64,
    "change_off_forwards_count": Int64,
    "change_on_forwards": String,
    "change_on_forwards_eh_id": String,
    "change_on_forwards_api_id": String,
    "change_off_forwards": String,
    "change_off_forwards_eh_id": String,
    "change_off_forwards_api_id": String,
    "change_on_defense_count": Int64,
    "change_off_defense_count": Int64,
    "change_on_defense": String,
    "change_on_defense_eh_id": String,
    "change_on_defense_api_id": String,
    "change_off_defense": String,
    "change_off_defense_eh_id": String,
    "change_off_defense_api_id": String,
    "change_on_goalie_count": Int64,
    "change_off_goalie_count": Int64,
    "change_on_goalie": String,
    "change_on_goalie_eh_id": String,
    "change_on_goalie_api_id": String,
    "change_off_goalie": String,
    "change_off_goalie_eh_id": String,
    "change_off_goalie_api_id": String,
    "pred_goal": Float64,
    "pred_goal_adj": Float64,
    "goal": Int64,
    "goal_adj": Float64,
    "hd_goal": Int64,
    "shot": Int64,
    "shot_adj": Float64,
    "hd_shot": Int64,
    "miss": Int64,
    "miss_adj": Float64,
    "hd_miss": Int64,
    "fenwick": Int64,
    "fenwick_adj": Float64,
    "hd_fenwick": Int64,
    "corsi": Int64,
    "corsi_adj": Float64,
    "block": Int64,
    "block_adj": Float64,
    "teammate_block": Int64,
    "teammate_block_adj": Float64,
    "hit": Int64,
    "give": Int64,
    "take": Int64,
    "fac": Int64,
    "penl": Int64,
    "change": Int64,
    "stop": Int64,
    "chl": Int64,
    "ozf": Int64,
    "nzf": Int64,
    "dzf": Int64,
    "ozc": Int64,
    "nzc": Int64,
    "dzc": Int64,
    "otf": Int64,
    "pen0": Int64,
    "pen2": Int64,
    "pen4": Int64,
    "pen5": Int64,
    "pen10": Int64,
}

XGSchema = DataFrameSchema(
    columns={
        "season": Column(int),
        "goal": Column(int),
        "period": Column(int),
        "period_seconds": Column(int),
        "score_diff": Column(int),
        "danger": Column(int, default=0),
        "high_danger": Column(int, default=0),
        "position_f": Column(int, default=0),
        "position_d": Column(int, default=0),
        "position_g": Column(int, default=0),
        "event_distance": Column(float),
        "event_angle": Column(float, nullable=True),
        # "forwards_percent": Column(float, nullable=True),
        # "forwards_count": Column(int),
        # "opp_forwards_percent": Column(float, nullable=True),
        # "opp_forwards_count": Column(int),
        "is_rebound": Column(int, default=0),
        "rush_attempt": Column(int, default=0),
        "is_home": Column(int, default=0),
        "seconds_since_last": Column(float, nullable=True),
        "distance_from_last": Column(float, nullable=True),
        "prior_shot_same": Column(int, default=0),
        "prior_miss_same": Column(int, default=0),
        "prior_block_same": Column(int, default=0),
        "prior_give_same": Column(int, default=0),
        "prior_take_same": Column(int, default=0),
        "prior_hit_same": Column(int, default=0),
        "prior_shot_opp": Column(int, default=0),
        "prior_miss_opp": Column(int, default=0),
        "prior_block_opp": Column(int, default=0),
        "prior_give_opp": Column(int, default=0),
        "prior_take_opp": Column(int, default=0),
        "prior_hit_opp": Column(int, default=0),
        "prior_face": Column(int, default=0),
        "backhand": Column(int, default=0),
        "bat": Column(int, default=0),
        "between_legs": Column(int, default=0),
        "cradle": Column(int, default=0),
        "deflected": Column(int, default=0),
        "poke": Column(int, default=0),
        "slap": Column(int, default=0),
        "snap": Column(int, default=0),
        "tip_in": Column(int, default=0),
        "wrap_around": Column(int, default=0),
        "wrist": Column(int, default=0),
        "strength_state_3v3": Column(int, required=False),
        "strength_state_4v4": Column(int, required=False),
        "strength_state_5v5": Column(int, required=False),
        "strength_state_3v4": Column(int, required=False),
        "strength_state_3v5": Column(int, required=False),
        "strength_state_4v5": Column(int, required=False),
        "strength_state_4v3": Column(int, required=False),
        "strength_state_5v3": Column(int, required=False),
        "strength_state_5v4": Column(int, required=False),
        "strength_state_Ev3": Column(int, required=False),
        "strength_state_Ev4": Column(int, required=False),
        "strength_state_Ev5": Column(int, required=False),
        "strength_state_3vE": Column(int, required=False),
        "strength_state_4vE": Column(int, required=False),
        "strength_state_5vE": Column(int, required=False),
    },
    strict="filter",
    add_missing_columns=True,
    coerce=True,
    ordered=True,
)

IndStatSchema = DataFrameSchema(
    columns={
        "season": Column(str),
        "session": Column(str),
        "game_id": Column(str, required=False),
        "game_date": Column(str, required=False),
        "player": Column(str),
        "eh_id": Column(str),
        "api_id": Column(int),
        "position": Column(str),
        "team": Column(str),
        "opp_team": Column(str, required=False),
        "strength_state": Column(str, required=False),
        "period": Column(int, required=False),
        "score_state": Column(str, required=False),
        "forwards": Column(str, required=False),
        "forwards_eh_id": Column(str, required=False),
        "forwards_api_id": Column(str, required=False),
        "defense": Column(str, required=False),
        "defense_eh_id": Column(str, required=False),
        "defense_api_id": Column(str, required=False),
        "own_goalie": Column(str, required=False),
        "own_goalie_eh_id": Column(str, required=False),
        "own_goalie_api_id": Column(str, required=False),
        "opp_forwards": Column(str, required=False),
        "opp_forwards_eh_id": Column(str, required=False),
        "opp_forwards_api_id": Column(str, required=False),
        "opp_defense": Column(str, required=False),
        "opp_defense_eh_id": Column(str, required=False),
        "opp_defense_api_id": Column(str, required=False),
        "opp_goalie": Column(str, required=False),
        "opp_goalie_eh_id": Column(str, required=False),
        "opp_goalie_api_id": Column(str, required=False),
        "g": Column(int, default=0),
        "g_adj": Column(float, default=0),
        "ihdg": Column(int, default=0),
        "a1": Column(int, default=0),
        "a2": Column(int, default=0),
        "ixg": Column(float, default=0),
        "ixg_adj": Column(float, default=0),
        "isf": Column(int, default=0),
        "isf_adj": Column(float, default=0),
        "ihdsf": Column(int, default=0),
        "imsf": Column(int, default=0),
        "imsf_adj": Column(float, default=0),
        "ihdm": Column(int, default=0),
        "iff": Column(int, default=0),
        "iff_adj": Column(float, default=0),
        "ihdf": Column(int, default=0),
        "isb": Column(int, default=0),
        "isb_adj": Column(float, default=0),
        "icf": Column(int, default=0),
        "icf_adj": Column(float, default=0),
        "ibs": Column(int, default=0),
        "ibs_adj": Column(float, default=0),
        "igive": Column(int, default=0),
        "itake": Column(int, default=0),
        "ihf": Column(int, default=0),
        "iht": Column(int, default=0),
        "ifow": Column(int, default=0),
        "ifol": Column(int, default=0),
        "iozfw": Column(int, default=0),
        "iozfl": Column(int, default=0),
        "inzfw": Column(int, default=0),
        "inzfl": Column(int, default=0),
        "idzfw": Column(int, default=0),
        "idzfl": Column(int, default=0),
        "a1_xg": Column(float, default=0),
        "a2_xg": Column(float, default=0),
        "ipent0": Column(int, default=0),
        "ipent2": Column(int, default=0),
        "ipent4": Column(int, default=0),
        "ipent5": Column(int, default=0),
        "ipent10": Column(int, default=0),
        "ipend0": Column(int, default=0),
        "ipend2": Column(int, default=0),
        "ipend4": Column(int, default=0),
        "ipend5": Column(int, default=0),
        "ipend10": Column(int, default=0),
    },
    strict="filter",
    add_missing_columns=True,
    coerce=True,
    ordered=True,
)

OIStatSchema = DataFrameSchema(
    columns={
        "season": Column(str),
        "session": Column(str),
        "game_id": Column(str, required=False),
        "game_date": Column(str, required=False),
        "player": Column(str),
        "eh_id": Column(str),
        "api_id": Column(int),
        "position": Column(str),
        "team": Column(str),
        "opp_team": Column(str, required=False),
        "strength_state": Column(str, required=False),
        "period": Column(int, required=False),
        "score_state": Column(str, required=False),
        "forwards": Column(str, required=False),
        "forwards_eh_id": Column(str, required=False),
        "forwards_api_id": Column(str, required=False),
        "defense": Column(str, required=False),
        "defense_eh_id": Column(str, required=False),
        "defense_api_id": Column(str, required=False),
        "own_goalie": Column(str, required=False),
        "own_goalie_eh_id": Column(str, required=False),
        "own_goalie_api_id": Column(str, required=False),
        "opp_forwards": Column(str, required=False),
        "opp_forwards_eh_id": Column(str, required=False),
        "opp_forwards_api_id": Column(str, required=False),
        "opp_defense": Column(str, required=False),
        "opp_defense_eh_id": Column(str, required=False),
        "opp_defense_api_id": Column(str, required=False),
        "opp_goalie": Column(str, required=False),
        "opp_goalie_eh_id": Column(str, required=False),
        "opp_goalie_api_id": Column(str, required=False),
        "toi": Column(float, default=0),
        "gf": Column(int, default=0),
        "ga": Column(int, default=0),
        "gf_adj": Column(float, default=0),
        "ga_adj": Column(float, default=0),
        "hdgf": Column(int, default=0),
        "hdga": Column(int, default=0),
        "xgf": Column(float, default=0),
        "xga": Column(float, default=0),
        "xgf_adj": Column(float, default=0),
        "xga_adj": Column(float, default=0),
        "sf": Column(int, default=0),
        "sa": Column(int, default=0),
        "sf_adj": Column(float, default=0),
        "sa_adj": Column(float, default=0),
        "hdsf": Column(int, default=0),
        "hdsa": Column(int, default=0),
        "ff": Column(int, default=0),
        "fa": Column(int, default=0),
        "ff_adj": Column(float, default=0),
        "fa_adj": Column(float, default=0),
        "hdff": Column(int, default=0),
        "hdfa": Column(int, default=0),
        "cf": Column(int, default=0),
        "ca": Column(int, default=0),
        "cf_adj": Column(float, default=0),
        "ca_adj": Column(float, default=0),
        "bsf": Column(int, default=0),
        "bsa": Column(int, default=0),
        "bsf_adj": Column(float, default=0),
        "bsa_adj": Column(float, default=0),
        "msf": Column(int, default=0),
        "msa": Column(int, default=0),
        "msf_adj": Column(float, default=0),
        "msa_adj": Column(float, default=0),
        "hdmsf": Column(int, default=0),
        "hdmsa": Column(int, default=0),
        "teammate_block": Column(int, default=0),
        "teammate_block_adj": Column(float, default=0),
        "hf": Column(int, default=0),
        "ht": Column(int, default=0),
        "give": Column(int, default=0),
        "take": Column(int, default=0),
        "ozf": Column(int, default=0),
        "nzf": Column(int, default=0),
        "dzf": Column(int, default=0),
        "fow": Column(int, default=0),
        "fol": Column(int, default=0),
        "ozfw": Column(int, default=0),
        "ozfl": Column(int, default=0),
        "nzfw": Column(int, default=0),
        "nzfl": Column(int, default=0),
        "dzfw": Column(int, default=0),
        "dzfl": Column(int, default=0),
        "pent0": Column(int, default=0),
        "pent2": Column(int, default=0),
        "pent4": Column(int, default=0),
        "pent5": Column(int, default=0),
        "pent10": Column(int, default=0),
        "pend0": Column(int, default=0),
        "pend2": Column(int, default=0),
        "pend4": Column(int, default=0),
        "pend5": Column(int, default=0),
        "pend10": Column(int, default=0),
        "ozs": Column(int, default=0),
        "nzs": Column(int, default=0),
        "dzs": Column(int, default=0),
        "otf": Column(int, default=0),
    },
    strict="filter",
    add_missing_columns=True,
    coerce=True,
    ordered=True,
)

StatSchema = DataFrameSchema(
    columns={
        "season": Column(str),
        "session": Column(str),
        "game_id": Column(str, required=False),
        "game_date": Column(str, required=False),
        "player": Column(str),
        "eh_id": Column(str),
        "api_id": Column(int),
        "position": Column(str),
        "team": Column(str),
        "opp_team": Column(str, required=False),
        "strength_state": Column(str, required=False),
        "period": Column(int, required=False),
        "score_state": Column(str, required=False),
        "forwards": Column(str, required=False),
        "forwards_eh_id": Column(str, required=False),
        "forwards_api_id": Column(str, required=False),
        "defense": Column(str, required=False),
        "defense_eh_id": Column(str, required=False),
        "defense_api_id": Column(str, required=False),
        "own_goalie": Column(str, required=False),
        "own_goalie_eh_id": Column(str, required=False),
        "own_goalie_api_id": Column(str, required=False),
        "opp_forwards": Column(str, required=False),
        "opp_forwards_eh_id": Column(str, required=False),
        "opp_forwards_api_id": Column(str, required=False),
        "opp_defense": Column(str, required=False),
        "opp_defense_eh_id": Column(str, required=False),
        "opp_defense_api_id": Column(str, required=False),
        "opp_goalie": Column(str, required=False),
        "opp_goalie_eh_id": Column(str, required=False),
        "opp_goalie_api_id": Column(str, required=False),
        "toi": Column(float, default=0),
        "g": Column(int, default=0),
        "g_adj": Column(float, default=0),
        "ihdg": Column(int, default=0),
        "a1": Column(int, default=0),
        "a2": Column(int, default=0),
        "ixg": Column(float, default=0),
        "ixg_adj": Column(float, default=0),
        "isf": Column(int, default=0),
        "isf_adj": Column(float, default=0),
        "ihdsf": Column(int, default=0),
        "imsf": Column(int, default=0),
        "imsf_adj": Column(float, default=0),
        "ihdm": Column(int, default=0),
        "iff": Column(int, default=0),
        "iff_adj": Column(float, default=0),
        "ihdf": Column(int, default=0),
        "isb": Column(int, default=0),
        "isb_adj": Column(float, default=0),
        "icf": Column(int, default=0),
        "icf_adj": Column(float, default=0),
        "ibs": Column(int, default=0),
        "ibs_adj": Column(float, default=0),
        "igive": Column(int, default=0),
        "itake": Column(int, default=0),
        "ihf": Column(int, default=0),
        "iht": Column(int, default=0),
        "ifow": Column(int, default=0),
        "ifol": Column(int, default=0),
        "iozfw": Column(int, default=0),
        "iozfl": Column(int, default=0),
        "inzfw": Column(int, default=0),
        "inzfl": Column(int, default=0),
        "idzfw": Column(int, default=0),
        "idzfl": Column(int, default=0),
        "a1_xg": Column(float, default=0),
        "a2_xg": Column(float, default=0),
        "ipent0": Column(int, default=0),
        "ipent2": Column(int, default=0),
        "ipent4": Column(int, default=0),
        "ipent5": Column(int, default=0),
        "ipent10": Column(int, default=0),
        "ipend0": Column(int, default=0),
        "ipend2": Column(int, default=0),
        "ipend4": Column(int, default=0),
        "ipend5": Column(int, default=0),
        "ipend10": Column(int, default=0),
        "gf": Column(int, default=0),
        "ga": Column(int, default=0),
        "gf_adj": Column(float, default=0),
        "ga_adj": Column(float, default=0),
        "hdgf": Column(int, default=0),
        "hdga": Column(int, default=0),
        "xgf": Column(float, default=0),
        "xga": Column(float, default=0),
        "xgf_adj": Column(float, default=0),
        "xga_adj": Column(float, default=0),
        "sf": Column(int, default=0),
        "sa": Column(int, default=0),
        "sf_adj": Column(float, default=0),
        "sa_adj": Column(float, default=0),
        "hdsf": Column(int, default=0),
        "hdsa": Column(int, default=0),
        "ff": Column(int, default=0),
        "fa": Column(int, default=0),
        "ff_adj": Column(float, default=0),
        "fa_adj": Column(float, default=0),
        "hdff": Column(int, default=0),
        "hdfa": Column(int, default=0),
        "cf": Column(int, default=0),
        "ca": Column(int, default=0),
        "cf_adj": Column(float, default=0),
        "ca_adj": Column(float, default=0),
        "bsf": Column(int, default=0),
        "bsa": Column(int, default=0),
        "bsf_adj": Column(float, default=0),
        "bsa_adj": Column(float, default=0),
        "msf": Column(int, default=0),
        "msa": Column(int, default=0),
        "msf_adj": Column(float, default=0),
        "msa_adj": Column(float, default=0),
        "hdmsf": Column(int, default=0),
        "hdmsa": Column(int, default=0),
        "teammate_block": Column(int, default=0),
        "teammate_block_adj": Column(float, default=0),
        "hf": Column(int, default=0),
        "ht": Column(int, default=0),
        "give": Column(int, default=0),
        "take": Column(int, default=0),
        "ozf": Column(int, default=0),
        "nzf": Column(int, default=0),
        "dzf": Column(int, default=0),
        "fow": Column(int, default=0),
        "fol": Column(int, default=0),
        "ozfw": Column(int, default=0),
        "ozfl": Column(int, default=0),
        "nzfw": Column(int, default=0),
        "nzfl": Column(int, default=0),
        "dzfw": Column(int, default=0),
        "dzfl": Column(int, default=0),
        "pent0": Column(int, default=0),
        "pent2": Column(int, default=0),
        "pent4": Column(int, default=0),
        "pent5": Column(int, default=0),
        "pent10": Column(int, default=0),
        "pend0": Column(int, default=0),
        "pend2": Column(int, default=0),
        "pend4": Column(int, default=0),
        "pend5": Column(int, default=0),
        "pend10": Column(int, default=0),
        "ozs": Column(int, default=0),
        "nzs": Column(int, default=0),
        "dzs": Column(int, default=0),
        "otf": Column(int, default=0),
        "g_p60": Column(float, default=0),
        "g_adj_p60": Column(float, default=0),
        "ihdg_p60": Column(float, default=0),
        "a1_p60": Column(float, default=0),
        "a2_p60": Column(float, default=0),
        "ixg_p60": Column(float, default=0),
        "ixg_adj_p60": Column(float, default=0),
        "isf_p60": Column(float, default=0),
        "isf_adj_p60": Column(float, default=0),
        "ihdsf_p60": Column(float, default=0),
        "imsf_p60": Column(float, default=0),
        "imsf_adj_p60": Column(float, default=0),
        "ihdm_p60": Column(float, default=0),
        "iff_p60": Column(float, default=0),
        "iff_adj_p60": Column(float, default=0),
        "ihdf_p60": Column(float, default=0),
        "isb_p60": Column(float, default=0),
        "isb_adj_p60": Column(float, default=0),
        "icf_p60": Column(float, default=0),
        "icf_adj_p60": Column(float, default=0),
        "ibs_p60": Column(float, default=0),
        "ibs_adj_p60": Column(float, default=0),
        "igive_p60": Column(float, default=0),
        "itake_p60": Column(float, default=0),
        "ihf_p60": Column(float, default=0),
        "iht_p60": Column(float, default=0),
        "a1_xg_p60": Column(float, default=0),
        "a2_xg_p60": Column(float, default=0),
        "ipent0_p60": Column(float, default=0),
        "ipent2_p60": Column(float, default=0),
        "ipent4_p60": Column(float, default=0),
        "ipent5_p60": Column(float, default=0),
        "ipent10_p60": Column(float, default=0),
        "ipend0_p60": Column(float, default=0),
        "ipend2_p60": Column(float, default=0),
        "ipend4_p60": Column(float, default=0),
        "ipend5_p60": Column(float, default=0),
        "ipend10_p60": Column(float, default=0),
        "gf_p60": Column(float, default=0),
        "ga_p60": Column(float, default=0),
        "gf_adj_p60": Column(float, default=0),
        "ga_adj_p60": Column(float, default=0),
        "hdgf_p60": Column(float, default=0),
        "hdga_p60": Column(float, default=0),
        "xgf_p60": Column(float, default=0),
        "xga_p60": Column(float, default=0),
        "xgf_adj_p60": Column(float, default=0),
        "xga_adj_p60": Column(float, default=0),
        "sf_p60": Column(float, default=0),
        "sa_p60": Column(float, default=0),
        "sf_adj_p60": Column(float, default=0),
        "sa_adj_p60": Column(float, default=0),
        "hdsf_p60": Column(float, default=0),
        "hdsa_p60": Column(float, default=0),
        "ff_p60": Column(float, default=0),
        "fa_p60": Column(float, default=0),
        "ff_adj_p60": Column(float, default=0),
        "fa_adj_p60": Column(float, default=0),
        "hdff_p60": Column(float, default=0),
        "hdfa_p60": Column(float, default=0),
        "cf_p60": Column(float, default=0),
        "ca_p60": Column(float, default=0),
        "cf_adj_p60": Column(float, default=0),
        "ca_adj_p60": Column(float, default=0),
        "bsf_p60": Column(float, default=0),
        "bsa_p60": Column(float, default=0),
        "bsf_adj_p60": Column(float, default=0),
        "bsa_adj_p60": Column(float, default=0),
        "msf_p60": Column(float, default=0),
        "msa_p60": Column(float, default=0),
        "msf_adj_p60": Column(float, default=0),
        "msa_adj_p60": Column(float, default=0),
        "hdmsf_p60": Column(float, default=0),
        "hdmsa_p60": Column(float, default=0),
        "teammate_block_p60": Column(float, default=0),
        "teammate_block_adj_p60": Column(float, default=0),
        "hf_p60": Column(float, default=0),
        "ht_p60": Column(float, default=0),
        "give_p60": Column(float, default=0),
        "take_p60": Column(float, default=0),
        "pent0_p60": Column(float, default=0),
        "pent2_p60": Column(float, default=0),
        "pent4_p60": Column(float, default=0),
        "pent5_p60": Column(float, default=0),
        "pent10_p60": Column(float, default=0),
        "pend0_p60": Column(float, default=0),
        "pend2_p60": Column(float, default=0),
        "pend4_p60": Column(float, default=0),
        "pend5_p60": Column(float, default=0),
        "pend10_p60": Column(float, default=0),
        "gf_percent": Column(float, default=0),
        "gf_adj_percent": Column(float, default=0),
        "hdgf_percent": Column(float, default=0),
        "xgf_percent": Column(float, default=0),
        "xgf_adj_percent": Column(float, default=0),
        "sf_percent": Column(float, default=0),
        "sf_adj_percent": Column(float, default=0),
        "hdsf_percent": Column(float, default=0),
        "ff_percent": Column(float, default=0),
        "ff_adj_percent": Column(float, default=0),
        "hdff_percent": Column(float, default=0),
        "cf_percent": Column(float, default=0),
        "cf_adj_percent": Column(float, default=0),
        "bsf_percent": Column(float, default=0),
        "bsf_adj_percent": Column(float, default=0),
        "msf_percent": Column(float, default=0),
        "msf_adj_percent": Column(float, default=0),
        "hdmsf_percent": Column(float, default=0),
        "hf_percent": Column(float, default=0),
        "take_percent": Column(float, default=0),
    },
    strict="filter",
    add_missing_columns=True,
    coerce=True,
    ordered=True,
)

LineSchema = DataFrameSchema(
    columns={
        "season": Column(str),
        "session": Column(str),
        "game_id": Column(str, required=False),
        "game_date": Column(str, required=False),
        "team": Column(str),
        "opp_team": Column(str, required=False),
        "strength_state": Column(str, required=False),
        "period": Column(int, required=False),
        "score_state": Column(str, required=False),
        "forwards": Column(str, required=False),
        "forwards_eh_id": Column(str, required=False),
        "forwards_api_id": Column(str, required=False),
        "defense": Column(str, required=False),
        "defense_eh_id": Column(str, required=False),
        "defense_api_id": Column(str, required=False),
        "own_goalie": Column(str, required=False),
        "own_goalie_eh_id": Column(str, required=False),
        "own_goalie_api_id": Column(str, required=False),
        "opp_forwards": Column(str, required=False),
        "opp_forwards_eh_id": Column(str, required=False),
        "opp_forwards_api_id": Column(str, required=False),
        "opp_defense": Column(str, required=False),
        "opp_defense_eh_id": Column(str, required=False),
        "opp_defense_api_id": Column(str, required=False),
        "opp_goalie": Column(str, required=False),
        "opp_goalie_eh_id": Column(str, required=False),
        "opp_goalie_api_id": Column(str, required=False),
        "toi": Column(float, default=0),
        "gf": Column(int, default=0),
        "ga": Column(int, default=0),
        "gf_adj": Column(float, default=0),
        "ga_adj": Column(float, default=0),
        "hdgf": Column(int, default=0),
        "hdga": Column(int, default=0),
        "xgf": Column(float, default=0),
        "xga": Column(float, default=0),
        "xgf_adj": Column(float, default=0),
        "xga_adj": Column(float, default=0),
        "sf": Column(int, default=0),
        "sa": Column(int, default=0),
        "sf_adj": Column(float, default=0),
        "sa_adj": Column(float, default=0),
        "hdsf": Column(int, default=0),
        "hdsa": Column(int, default=0),
        "ff": Column(int, default=0),
        "fa": Column(int, default=0),
        "ff_adj": Column(float, default=0),
        "fa_adj": Column(float, default=0),
        "hdff": Column(int, default=0),
        "hdfa": Column(int, default=0),
        "cf": Column(int, default=0),
        "ca": Column(int, default=0),
        "cf_adj": Column(float, default=0),
        "ca_adj": Column(float, default=0),
        "bsf": Column(int, default=0),
        "bsa": Column(int, default=0),
        "bsf_adj": Column(float, default=0),
        "bsa_adj": Column(float, default=0),
        "msf": Column(int, default=0),
        "msa": Column(int, default=0),
        "msf_adj": Column(float, default=0),
        "msa_adj": Column(float, default=0),
        "hdmsf": Column(int, default=0),
        "hdmsa": Column(int, default=0),
        "teammate_block": Column(int, default=0),
        "teammate_block_adj": Column(float, default=0),
        "hf": Column(int, default=0),
        "ht": Column(int, default=0),
        "give": Column(int, default=0),
        "take": Column(int, default=0),
        "ozf": Column(int, default=0),
        "nzf": Column(int, default=0),
        "dzf": Column(int, default=0),
        "fow": Column(int, default=0),
        "fol": Column(int, default=0),
        "ozfw": Column(int, default=0),
        "ozfl": Column(int, default=0),
        "nzfw": Column(int, default=0),
        "nzfl": Column(int, default=0),
        "dzfw": Column(int, default=0),
        "dzfl": Column(int, default=0),
        "pent0": Column(int, default=0),
        "pent2": Column(int, default=0),
        "pent4": Column(int, default=0),
        "pent5": Column(int, default=0),
        "pent10": Column(int, default=0),
        "pend0": Column(int, default=0),
        "pend2": Column(int, default=0),
        "pend4": Column(int, default=0),
        "pend5": Column(int, default=0),
        "pend10": Column(int, default=0),
        "gf_p60": Column(float, default=0),
        "ga_p60": Column(float, default=0),
        "gf_adj_p60": Column(float, default=0),
        "ga_adj_p60": Column(float, default=0),
        "hdgf_p60": Column(float, default=0),
        "hdga_p60": Column(float, default=0),
        "xgf_p60": Column(float, default=0),
        "xga_p60": Column(float, default=0),
        "xgf_adj_p60": Column(float, default=0),
        "xga_adj_p60": Column(float, default=0),
        "sf_p60": Column(float, default=0),
        "sa_p60": Column(float, default=0),
        "sf_adj_p60": Column(float, default=0),
        "sa_adj_p60": Column(float, default=0),
        "hdsf_p60": Column(float, default=0),
        "hdsa_p60": Column(float, default=0),
        "ff_p60": Column(float, default=0),
        "fa_p60": Column(float, default=0),
        "ff_adj_p60": Column(float, default=0),
        "fa_adj_p60": Column(float, default=0),
        "hdff_p60": Column(float, default=0),
        "hdfa_p60": Column(float, default=0),
        "cf_p60": Column(float, default=0),
        "ca_p60": Column(float, default=0),
        "cf_adj_p60": Column(float, default=0),
        "ca_adj_p60": Column(float, default=0),
        "bsf_p60": Column(float, default=0),
        "bsa_p60": Column(float, default=0),
        "bsf_adj_p60": Column(float, default=0),
        "bsa_adj_p60": Column(float, default=0),
        "msf_p60": Column(float, default=0),
        "msa_p60": Column(float, default=0),
        "msf_adj_p60": Column(float, default=0),
        "msa_adj_p60": Column(float, default=0),
        "hdmsf_p60": Column(float, default=0),
        "hdmsa_p60": Column(float, default=0),
        "teammate_block_p60": Column(float, default=0),
        "teammate_block_adj_p60": Column(float, default=0),
        "hf_p60": Column(float, default=0),
        "ht_p60": Column(float, default=0),
        "give_p60": Column(float, default=0),
        "take_p60": Column(float, default=0),
        "pent0_p60": Column(float, default=0),
        "pent2_p60": Column(float, default=0),
        "pent4_p60": Column(float, default=0),
        "pent5_p60": Column(float, default=0),
        "pent10_p60": Column(float, default=0),
        "pend0_p60": Column(float, default=0),
        "pend2_p60": Column(float, default=0),
        "pend4_p60": Column(float, default=0),
        "pend5_p60": Column(float, default=0),
        "pend10_p60": Column(float, default=0),
        "gf_percent": Column(float, default=0),
        "gf_adj_percent": Column(float, default=0),
        "hdgf_percent": Column(float, default=0),
        "xgf_percent": Column(float, default=0),
        "xgf_adj_percent": Column(float, default=0),
        "sf_percent": Column(float, default=0),
        "sf_adj_percent": Column(float, default=0),
        "hdsf_percent": Column(float, default=0),
        "ff_percent": Column(float, default=0),
        "ff_adj_percent": Column(float, default=0),
        "hdff_percent": Column(float, default=0),
        "cf_percent": Column(float, default=0),
        "cf_adj_percent": Column(float, default=0),
        "bsf_percent": Column(float, default=0),
        "bsf_adj_percent": Column(float, default=0),
        "msf_percent": Column(float, default=0),
        "msf_adj_percent": Column(float, default=0),
        "hdmsf_percent": Column(float, default=0),
        "hf_percent": Column(float, default=0),
        "take_percent": Column(float, default=0),
    },
    strict="filter",
    add_missing_columns=True,
    coerce=True,
    ordered=True,
)

TeamStatSchema = DataFrameSchema(
    columns={
        "season": Column(str),
        "session": Column(str),
        "game_id": Column(str, required=False),
        "game_date": Column(str, required=False),
        "team": Column(str),
        "opp_team": Column(str, required=False),
        "strength_state": Column(str, required=False),
        "period": Column(int, required=False),
        "score_state": Column(str, required=False),
        "toi": Column(float, default=0),
        "gf": Column(int, default=0),
        "ga": Column(int, default=0),
        "gf_adj": Column(float, default=0),
        "ga_adj": Column(float, default=0),
        "hdgf": Column(int, default=0),
        "hdga": Column(int, default=0),
        "xgf": Column(float, default=0),
        "xga": Column(float, default=0),
        "xgf_adj": Column(float, default=0),
        "xga_adj": Column(float, default=0),
        "sf": Column(int, default=0),
        "sa": Column(int, default=0),
        "sf_adj": Column(float, default=0),
        "sa_adj": Column(float, default=0),
        "hdsf": Column(int, default=0),
        "hdsa": Column(int, default=0),
        "ff": Column(int, default=0),
        "fa": Column(int, default=0),
        "ff_adj": Column(float, default=0),
        "fa_adj": Column(float, default=0),
        "hdff": Column(int, default=0),
        "hdfa": Column(int, default=0),
        "cf": Column(int, default=0),
        "ca": Column(int, default=0),
        "cf_adj": Column(float, default=0),
        "ca_adj": Column(float, default=0),
        "bsf": Column(int, default=0),
        "bsa": Column(int, default=0),
        "bsf_adj": Column(float, default=0),
        "bsa_adj": Column(float, default=0),
        "msf": Column(int, default=0),
        "msa": Column(int, default=0),
        "msf_adj": Column(float, default=0),
        "msa_adj": Column(float, default=0),
        "hdmsf": Column(int, default=0),
        "hdmsa": Column(int, default=0),
        "teammate_block": Column(int, default=0),
        "hf": Column(int, default=0),
        "ht": Column(int, default=0),
        "give": Column(int, default=0),
        "take": Column(int, default=0),
        "ozf": Column(int, default=0),
        "nzf": Column(int, default=0),
        "dzf": Column(int, default=0),
        "fow": Column(int, default=0),
        "fol": Column(int, default=0),
        "ozfw": Column(int, default=0),
        "ozfl": Column(int, default=0),
        "nzfw": Column(int, default=0),
        "nzfl": Column(int, default=0),
        "dzfw": Column(int, default=0),
        "dzfl": Column(int, default=0),
        "pent0": Column(int, default=0),
        "pent2": Column(int, default=0),
        "pent4": Column(int, default=0),
        "pent5": Column(int, default=0),
        "pent10": Column(int, default=0),
        "pend0": Column(int, default=0),
        "pend2": Column(int, default=0),
        "pend4": Column(int, default=0),
        "pend5": Column(int, default=0),
        "pend10": Column(int, default=0),
        "ozs": Column(int, default=0),
        "nzs": Column(int, default=0),
        "dzs": Column(int, default=0),
        "otf": Column(int, default=0),
        "gf_p60": Column(float, default=0),
        "ga_p60": Column(float, default=0),
        "gf_adj_p60": Column(float, default=0),
        "ga_adj_p60": Column(float, default=0),
        "hdgf_p60": Column(float, default=0),
        "hdga_p60": Column(float, default=0),
        "xgf_p60": Column(float, default=0),
        "xga_p60": Column(float, default=0),
        "xgf_adj_p60": Column(float, default=0),
        "xga_adj_p60": Column(float, default=0),
        "sf_p60": Column(float, default=0),
        "sa_p60": Column(float, default=0),
        "sf_adj_p60": Column(float, default=0),
        "sa_adj_p60": Column(float, default=0),
        "hdsf_p60": Column(float, default=0),
        "hdsa_p60": Column(float, default=0),
        "ff_p60": Column(float, default=0),
        "fa_p60": Column(float, default=0),
        "ff_adj_p60": Column(float, default=0),
        "fa_adj_p60": Column(float, default=0),
        "hdff_p60": Column(float, default=0),
        "hdfa_p60": Column(float, default=0),
        "cf_p60": Column(float, default=0),
        "ca_p60": Column(float, default=0),
        "cf_adj_p60": Column(float, default=0),
        "ca_adj_p60": Column(float, default=0),
        "bsf_p60": Column(float, default=0),
        "bsa_p60": Column(float, default=0),
        "bsf_adj_p60": Column(float, default=0),
        "bsa_adj_p60": Column(float, default=0),
        "msf_p60": Column(float, default=0),
        "msa_p60": Column(float, default=0),
        "msf_adj_p60": Column(float, default=0),
        "msa_adj_p60": Column(float, default=0),
        "hdmsf_p60": Column(float, default=0),
        "hdmsa_p60": Column(float, default=0),
        "teammate_block_p60": Column(float, default=0),
        "teammate_block_adj_p60": Column(float, default=0),
        "hf_p60": Column(float, default=0),
        "ht_p60": Column(float, default=0),
        "give_p60": Column(float, default=0),
        "take_p60": Column(float, default=0),
        "pent0_p60": Column(float, default=0),
        "pent2_p60": Column(float, default=0),
        "pent4_p60": Column(float, default=0),
        "pent5_p60": Column(float, default=0),
        "pent10_p60": Column(float, default=0),
        "pend0_p60": Column(float, default=0),
        "pend2_p60": Column(float, default=0),
        "pend4_p60": Column(float, default=0),
        "pend5_p60": Column(float, default=0),
        "pend10_p60": Column(float, default=0),
        "gf_percent": Column(float, default=0),
        "gf_adj_percent": Column(float, default=0),
        "hdgf_percent": Column(float, default=0),
        "xgf_percent": Column(float, default=0),
        "xgf_adj_percent": Column(float, default=0),
        "sf_percent": Column(float, default=0),
        "sf_adj_percent": Column(float, default=0),
        "hdsf_percent": Column(float, default=0),
        "ff_percent": Column(float, default=0),
        "ff_adj_percent": Column(float, default=0),
        "hdff_percent": Column(float, default=0),
        "cf_percent": Column(float, default=0),
        "cf_adj_percent": Column(float, default=0),
        "bsf_percent": Column(float, default=0),
        "bsf_adj_percent": Column(float, default=0),
        "msf_percent": Column(float, default=0),
        "msf_adj_percent": Column(float, default=0),
        "hdmsf_percent": Column(float, default=0),
        "hf_percent": Column(float, default=0),
        "take_percent": Column(float, default=0),
    },
    strict="filter",
    add_missing_columns=True,
    coerce=True,
    ordered=True,
)
