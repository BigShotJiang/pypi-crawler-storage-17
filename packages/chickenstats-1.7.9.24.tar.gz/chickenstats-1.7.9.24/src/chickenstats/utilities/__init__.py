from chickenstats.utilities.utilities import (ChickenProgress,
                                              ChickenProgressIndeterminate,
                                              ChickenSession,
                                              add_cs_mplstyles)

add_cs_mplstyles()
