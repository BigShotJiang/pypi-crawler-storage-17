#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""Dunder init for seabirdscientific module"""
