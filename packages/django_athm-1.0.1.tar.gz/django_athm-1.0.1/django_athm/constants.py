BUTTON_COLOR_DEFAULT = "btn"
BUTTON_VALID_THEMES = frozenset({"btn", "btn-light", "btn-dark"})

BUTTON_LANGUAGE_DEFAULT = "es"
BUTTON_VALID_LANGUAGES = frozenset({"es", "en"})
