# Installation

To install SciTiff and all of its dependencies, use

`````{tab-set}
````{tab-item} pip
```sh
pip install scitiff
```
````
````{tab-item} conda
```sh
conda install -c conda-forge scitiff
```
````
`````
