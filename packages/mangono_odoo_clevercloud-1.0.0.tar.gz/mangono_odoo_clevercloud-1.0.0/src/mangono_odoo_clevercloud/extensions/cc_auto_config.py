from __future__ import annotations

from pathlib import Path

from environ_odoo_config.config_section.api import SimpleKey
from environ_odoo_config.environ import Environ
from environ_odoo_config.odoo_config import OdooConfigExtension, OdooEnvConfig


class CleverCloudAutoConfig(OdooConfigExtension):
    _order = 999

    app_id: str = SimpleKey("CC_APP_ID", ini_dest="cc_app_id")
    app_name: str = SimpleKey("CC_APP_NAME", ini_dest="cc_app_name")
    commit_id: str = SimpleKey("CC_COMMIT_ID", ini_dest="cc_commit_id")
    deployment_id: str = SimpleKey("CC_DEPLOYMENT_ID", ini_dest="cc_deployment_id")
    instance_type: str = SimpleKey("INSTANCE_TYPE", ini_dest="instance_type")

    def apply_extension(self, environ: Environ, odoo_config: OdooEnvConfig):
        super().apply_extension(environ, odoo_config)
        if not self.app_id:
            return

        if not odoo_config.misc.config_file:
            odoo_config.misc.config_file = Path("~/odoo-config.ini").expanduser().absolute()

        if odoo_config.update_init.update or odoo_config.update_init.init:
            return

        odoo_config.http.proxy_mode = True
        if not odoo_config.http.port:
            odoo_config.http.port = 8080  # Default listen http port of clevercloud

        if self.instance_type == "production" and not environ.get("LIST_DB"):
            odoo_config.database.list_db = False
