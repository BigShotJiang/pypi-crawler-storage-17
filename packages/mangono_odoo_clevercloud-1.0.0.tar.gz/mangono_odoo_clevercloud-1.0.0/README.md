# ODOO-CLEVERCLOUD

This modules provides all dependencies to deploy an odoo project in clever-cloud environment.
