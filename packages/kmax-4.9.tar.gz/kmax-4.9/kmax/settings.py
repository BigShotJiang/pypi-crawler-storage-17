logger_level = 3
do_table = False
do_boolean_configs = False
defines = None
unselectable = None
output_smtlib2 = True
output_all_unit_types = False
output_unit_pc_format = False
