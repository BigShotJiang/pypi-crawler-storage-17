from .atss_assigner import ATSSAssigner
from .tal_assigner import TaskAlignedAssigner

__all__ = ["ATSSAssigner", "TaskAlignedAssigner"]
