from .dinov3 import DinoV3

__all__ = ["DinoV3"]
