class IncompatibleError(Exception):
    """Raised when two parts of the model are incompatible with each
    other."""
