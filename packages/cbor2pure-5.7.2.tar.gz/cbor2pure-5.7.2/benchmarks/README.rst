cbor2 Benchmarks
================

To run the benchmarks::

    pip install -e .[benchmarks]
    cd benchmarks
    python -m pytest
