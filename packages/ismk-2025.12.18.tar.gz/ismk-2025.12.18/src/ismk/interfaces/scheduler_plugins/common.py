__author__ = "Johannes Köster"
__copyright__ = "Copyright 2025, Johannes Köster"
__email__ = "johannes.koester@uni-due.de"
__license__ = "MIT"

scheduler_plugin_prefix = "ismk-scheduler-plugin-"
scheduler_plugin_module_prefix = scheduler_plugin_prefix.replace("-", "_")
