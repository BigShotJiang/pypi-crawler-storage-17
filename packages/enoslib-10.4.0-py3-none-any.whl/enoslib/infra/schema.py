# default validator
JSON_SCHEMA = "http://json-schema.org/draft-07/schema"
