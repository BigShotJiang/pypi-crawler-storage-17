from notte_core.common.resource import AsyncResource, SyncResource

__all__ = ["SyncResource", "AsyncResource"]
