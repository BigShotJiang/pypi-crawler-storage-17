"""
.. include:: ../README.md
"""

__all__ = [
    "api",
    "model",
    "auth",
    "exceptions",
]
