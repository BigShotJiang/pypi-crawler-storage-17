# amgi-types

This package contains the types for [AMGI](https://amgi.readthedocs.io/en/latest/) applications.

## Installation

```
pip install amgi-types==0.26.0
```

## Contact

For questions or suggestions, please contact [jack.burridge@mail.com](mailto:jack.burridge@mail.com).

## License

Copyright 2025 AMGI
