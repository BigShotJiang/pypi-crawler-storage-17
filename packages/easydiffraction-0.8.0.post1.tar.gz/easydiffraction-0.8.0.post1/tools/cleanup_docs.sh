echo "🧹 Clean up after building documentation"
rm -rf site/
rm -rf docs/assets/javascripts
rm -rf docs/assets/stylesheets
rm -rf docs/assets/images/*.png
rm -rf docs/assets/images/*.svg
rm -rf includes/
rm -rf overrides/
rm -rf docs/tutorials/*.ipynb
rm mkdocs.yml
