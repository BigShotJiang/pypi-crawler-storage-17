from .base import query
from .conditional import conditional
from .marginal import marginal
from .sample import sample