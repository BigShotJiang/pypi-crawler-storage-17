"""
Tests for spotoptim.
"""
