# Oxiliere Audit settings

AUDITLOG_CID_GETTER = "oxutils.audit.utils.get_request_id"
AUDITLOG_LOGENTRY_MODEL =  "auditlog.LogEntry"
