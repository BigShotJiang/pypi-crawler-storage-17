"""Tests for SDC."""
