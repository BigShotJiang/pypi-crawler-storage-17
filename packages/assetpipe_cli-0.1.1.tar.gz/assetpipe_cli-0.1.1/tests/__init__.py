"""
AssetPipe Tests
"""
