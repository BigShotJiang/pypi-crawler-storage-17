# Gator Documentation

Welcome to Gator, a JupyterLab extension and standalone UI for managing conda environments.

```{toctree}
:maxdepth: 2
:caption: Contents:

user-guide/getting-started
api/index
changelog

```

## Indices and tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`
