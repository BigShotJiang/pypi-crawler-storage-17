Types for Google Cloud Logging v2 API
=====================================

.. automodule:: google.cloud.logging_v2.types
    :members:
    :show-inheritance:
