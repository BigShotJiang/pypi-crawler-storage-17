#######################
Analytic Invoice Module
#######################

The *Analytic Invoice Modules* adds analytic accounts to the invoice lines.

.. toctree::
   :maxdepth: 2

   design
   releases
