In Inventory \> Configuration \> Routes, activate the option "Release
based on Available to Promise" on the routes where you want to use the
feature.

To modify the horizon go to "Inventory \> Settings" and change "Stock
reservation horizon".
