"""
yspcrawler: a command-line tool to backup documents from Yandex.Disk public resources

"""

__version__ = '1.0.3'
__author__ = 'Ivan Begtin'
__licence__ = 'MIT'
