#############################
Stock Shipment Customs Module
#############################

The *Stock Shipment Customs Module* enables the generation of commercial
invoices for both customer and supplier return shipments.

.. toctree::
   :maxdepth: 2

   design
   releases
