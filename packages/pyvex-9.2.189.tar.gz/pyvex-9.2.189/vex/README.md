# VEX mirror

This is a mirror of libVEX (of the Valgrind project: valgrind.org) for use with PyVEX (https://github.com/angr/pyvex).
