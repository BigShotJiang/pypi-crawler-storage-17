import warnings
from collections import Counter, defaultdict
from collections.abc import Mapping
from dataclasses import dataclass
from functools import lru_cache
from typing import cast

from cognite.client import data_modeling as dm
from cognite.client.data_classes.data_modeling import ContainerList, ViewId, ViewList
from cognite.client.data_classes.data_modeling.views import (
    ReverseDirectRelation,
    ReverseDirectRelationApply,
    ViewProperty,
    ViewPropertyApply,
)

from cognite.neat._v0.core._client import NeatClient
from cognite.neat._v0.core._client.data_classes.data_modeling import ViewApplyDict
from cognite.neat._v0.core._client.data_classes.schema import DMSSchema
from cognite.neat._v0.core._constants import (
    COGNITE_MODELS,
    COGNITE_SPACES,
    DMS_CONTAINER_PROPERTY_SIZE_LIMIT,
    DMS_VIEW_CONTAINER_SIZE_LIMIT,
    get_base_concepts,
)
from cognite.neat._v0.core._data_model.models._import_contexts import ImportContext, SpreadsheetContext
from cognite.neat._v0.core._data_model.models.data_types import DataType
from cognite.neat._v0.core._data_model.models.entities import ContainerEntity, RawFilter
from cognite.neat._v0.core._data_model.models.entities._single_value import (
    ContainerIndexEntity,
    ViewEntity,
)
from cognite.neat._v0.core._issues import IssueList, NeatError
from cognite.neat._v0.core._issues.errors import (
    CDFMissingClientError,
    PropertyDefinitionDuplicatedError,
    PropertyInvalidDefinitionError,
    PropertyMappingDuplicatedError,
    PropertyNotFoundError,
    ResourceDuplicatedError,
    ResourceNotFoundError,
    ReversedConnectionNotFeasibleError,
)
from cognite.neat._v0.core._issues.errors._external import CDFMissingResourcesError
from cognite.neat._v0.core._issues.warnings import (
    NotSupportedHasDataFilterLimitWarning,
    NotSupportedViewContainerLimitWarning,
    ReversedConnectionNotFeasibleWarning,
    UndefinedViewWarning,
    user_modeling,
)
from cognite.neat._v0.core._issues.warnings._models import ViewWithoutPropertiesWarning
from cognite.neat._v0.core._issues.warnings.user_modeling import (
    ContainerPropertyLimitWarning,
    DirectRelationMissingSourceWarning,
    NotNeatSupportedFilterWarning,
)
from cognite.neat._v0.core._utils.text import humanize_collection

from ._verified import PhysicalDataModel, PhysicalProperty


@dataclass
class _ContainerPropertyIndex:
    """This is a helper class used in the indices validation

    Args:
        location: The index of the property in the properties list.
        property_: The physical property associated with the container.
        index: The index entity that defines the container property.
    """

    location: int
    property_: PhysicalProperty
    index: ContainerIndexEntity


class PhysicalValidation:
    """This class does all the validation of the physical data model that
    have dependencies between components."""

    def __init__(
        self,
        data_model: PhysicalDataModel,
        client: NeatClient | None = None,
        context: ImportContext | None = None,
    ) -> None:
        # import here to avoid circular import issues
        from cognite.neat._v0.core._data_model.analysis._base import DataModelAnalysis

        self._data_model = data_model
        self._client = client
        self._metadata = data_model.metadata
        self._properties = data_model.properties
        self._containers = data_model.containers
        self._views = data_model.views
        self._read_info_by_spreadsheet = context if isinstance(context, SpreadsheetContext) else SpreadsheetContext()

        self.analysis = DataModelAnalysis(physical=self._data_model)
        self._cdf_concepts = {
            ViewEntity.load(concept_as_string) for concept_as_string in get_base_concepts(base_model="CogniteCore")
        }

    def imported_views_and_containers_ids(
        self, include_views_with_no_properties: bool = True
    ) -> tuple[set[ViewEntity], set[ContainerEntity]]:
        existing_views = {view.view for view in self._views}
        imported_views: set[ViewEntity] = set()
        for view in self._views:
            for parent in view.implements or []:
                if parent not in existing_views:
                    imported_views.add(parent)
        existing_containers = {container.container for container in self._containers or []}
        imported_containers: set[ContainerEntity] = set()
        view_with_properties: set[ViewEntity] = set()
        for prop in self._properties:
            if prop.container and prop.container not in existing_containers:
                imported_containers.add(prop.container)
            if prop.view not in existing_views:
                imported_views.add(prop.view)
            view_with_properties.add(prop.view)

        for container in self._containers or []:
            for constraint in container.constraint or []:
                if constraint.require not in existing_containers:
                    imported_containers.add(cast(ContainerEntity, constraint.require))

        if include_views_with_no_properties:
            extra_views = existing_views - view_with_properties
            imported_views.update({view for view in extra_views})

        return imported_views, imported_containers

    def validate(self) -> IssueList:
        imported_views, imported_containers = self.imported_views_and_containers_ids(
            include_views_with_no_properties=False
        )
        if (imported_views or imported_containers) and self._client is None:
            raise CDFMissingClientError(
                f"{self._data_model.metadata.as_data_model_id()} has imported views and/or container: "
                f"{imported_views}, {imported_containers}."
            )
        referenced_views = ViewList([])
        referenced_containers = ContainerList([])
        if self._client:
            referenced_views = self._client.loaders.views.retrieve(
                list(imported_views), include_connected=True, include_ancestor=True
            )
            referenced_containers = self._client.loaders.containers.retrieve(
                list(imported_containers), include_connected=True
            )

            missing_views = {view.as_id() for view in imported_views} - {view.as_id() for view in referenced_views}
            missing_containers = {container.as_id() for container in imported_containers} - {
                container.as_id() for container in referenced_containers
            }

            if missing_views or missing_containers:
                raise CDFMissingResourcesError(containers=tuple(missing_containers), views=tuple(missing_views))

        # Setup data structures for validation
        dms_schema = self._data_model.as_schema()
        ref_view_by_id = {view.as_id(): view for view in referenced_views}
        ref_container_by_id = {container.as_id(): container for container in referenced_containers}
        # All containers and views are the Containers/Views in the Physical DM + the referenced ones
        all_containers_by_id: dict[dm.ContainerId, dm.ContainerApply | dm.Container] = {
            **dict(dms_schema.containers.items()),
            **ref_container_by_id,
        }
        all_views_by_id: dict[dm.ViewId, dm.ViewApply | dm.View] = {**dict(dms_schema.views.items()), **ref_view_by_id}
        properties_by_ids = self._as_properties_by_ids(dms_schema.views, ref_view_by_id)
        ref_properties_by_ids = self._as_properties_by_ids(ref_view_by_id, {})
        all_properties_by_ids = {**ref_properties_by_ids, **properties_by_ids}
        view_properties_by_id = self._as_view_properties_by_id(properties_by_ids)
        parents_view_ids_by_child_id = self._parent_view_ids_by_child_id(all_views_by_id)
        container_properties_by_id = self._create_container_properties_by_id()

        issue_list = IssueList()

        # Validated for duplicated resource
        issue_list.extend(self._duplicated_resources())

        # Validate if views are defined (i.e. have at least one property defined, or inherited)
        issue_list.extend(self._views_without_properties_exist())

        # Neat DMS classes Validation
        # These are errors that can only happen due to the format of the Neat DMS classes
        issue_list.extend(self._validate_raw_filter())
        issue_list.extend(self._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._valid_composite_container_       f._consistent_container_properties(container_properties_by_id))
        issue_list.extend(self._va