"""
CLI module for pychuck.

Handles command-line argument parsing and file execution.
"""
