from osbot_aws.aws.bedrock.models.mistral.Mistral_AI import Mistral_AI


class Mistral_AI_Large_2402_v1_0(Mistral_AI):
    model_id : str = "mistral.mistral-large-2402-v1:0"