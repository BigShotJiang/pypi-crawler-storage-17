from osbot_aws.aws.session.Session__Kwargs import Session__Kwargs


class Session__Kwargs__S3(Session__Kwargs):
    service_name: str = 's3'