# OCP Youtube Plugin

allows OCP to play youtube urls