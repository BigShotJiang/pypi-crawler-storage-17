"""CLI entrypoint for unir."""


def main() -> None:
    print("Hello from unir!")


if __name__ == "__main__":
    main()
