# unir — a unifier for IR datasets

unir provides a unified abstraction layer to load, normalize, and prepare heterogeneous IR datasets for training.
