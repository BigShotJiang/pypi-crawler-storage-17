def main():
    print("Hello from unir!")


if __name__ == "__main__":
    main()
