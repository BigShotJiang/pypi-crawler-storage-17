from .retriever import get_or_default
from .retriever import get_with_try_index
from .retriever import read_from_stdin
from .retriever import read_stdin_contents
