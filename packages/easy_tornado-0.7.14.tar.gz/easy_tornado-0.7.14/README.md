A common toolkit and tornado-based easy setup framework

#### Features
- Python2 and Python3 compatibillity
- Unified time function
- Easy frequently used file operation
- Http utils
- String utils
- Validation utils
- Unified json web api

#### Notes
- version 0.6.6 is mistakenly released, do NOT use for safety!
