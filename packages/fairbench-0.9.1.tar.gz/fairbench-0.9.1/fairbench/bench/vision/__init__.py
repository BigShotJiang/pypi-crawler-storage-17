from fairbench.bench.vision.celeba import celeba
from fairbench.bench.vision.utkface import utkface
from fairbench.bench.vision.waterbirds import waterbirds
