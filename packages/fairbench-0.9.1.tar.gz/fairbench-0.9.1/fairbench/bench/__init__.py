from fairbench.bench.loader import *
from fairbench.bench import tabular
from fairbench.bench import vision
from fairbench.bench import text
from fairbench.bench.loader import cache
