"""
Tile server.

Serves, well, tiles, and their associated metadata.
"""

from .app import app

__all__ = app
