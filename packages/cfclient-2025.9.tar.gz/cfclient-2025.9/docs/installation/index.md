---
title: Installation
page_id: installation_index
sort_order: 1
---

This section contains information about installing the Crazyflie Client

{% sub_page_menu %}
