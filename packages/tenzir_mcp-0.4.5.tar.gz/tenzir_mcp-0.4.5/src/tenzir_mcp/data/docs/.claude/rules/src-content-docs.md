---
paths: src/content/docs/**/*
---

Load the follwing skills:

- `docs:writing-documentation`
- `writing:technical-writing`
