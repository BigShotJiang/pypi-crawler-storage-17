from my_package.core import hello

def test_hello():
    assert hello("Ersilia") == "Hello, Ersilia!"