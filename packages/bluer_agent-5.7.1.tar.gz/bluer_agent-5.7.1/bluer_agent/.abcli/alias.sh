#! /usr/bin/env bash

alias @agent=bluer_agent
alias @ai_agent=bluer_agent
