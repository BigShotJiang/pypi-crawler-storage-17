#! /usr/bin/env bash

function bluer_ai_install_bluer_agent() {
    :
}

# bluer_ai_install_module bluer_agent 1.1.1
