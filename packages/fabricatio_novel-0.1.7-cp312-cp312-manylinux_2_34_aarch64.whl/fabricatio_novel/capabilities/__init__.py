"""Capabilities defined in fabricatio-novel."""
