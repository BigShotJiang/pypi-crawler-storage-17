from .process_mmdet import MMDetProcessor
from .process_mmocr import MMOcrProcessor
