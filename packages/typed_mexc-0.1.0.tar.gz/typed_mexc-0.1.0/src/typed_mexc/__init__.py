"""
### Typed Mexc
> A fully typed, validated async client for the Mexc API

- Details
"""