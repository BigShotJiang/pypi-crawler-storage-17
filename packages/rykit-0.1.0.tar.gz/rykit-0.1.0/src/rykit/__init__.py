def main() -> None:
    print("Hello from rykit!")
