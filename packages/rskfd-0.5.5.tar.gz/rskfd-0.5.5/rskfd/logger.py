# -*- coding: utf-8 -*-
"""
Created on Wed Nov 19 2025

(C) 2025, Rohde&Schwarz, ramian
"""

import logging

logger = logging.getLogger('rskfd')
logger.setLevel(logging.WARNING)
logger.addHandler(logging.NullHandler())

if __name__ == "__main__":
    pass
