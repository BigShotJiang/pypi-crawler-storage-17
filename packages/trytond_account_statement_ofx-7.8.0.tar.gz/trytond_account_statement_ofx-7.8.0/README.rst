############################
Account Statement OFX Module
############################

The *Account Statement OFX Module* implements the import of `OFX
<https://en.wikipedia.org/wiki/Open_Financial_Exchange>`_ files as statements.

.. toctree::
   :maxdepth: 2

   releases
