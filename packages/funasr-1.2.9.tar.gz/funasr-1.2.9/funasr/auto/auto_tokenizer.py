class AutoTokenizer:
    """
    Undo
    """

    def __init__(self):
        pass
