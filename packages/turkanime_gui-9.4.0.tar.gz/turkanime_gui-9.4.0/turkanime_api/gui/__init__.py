"""PyQt6 GUI modülü."""
