"""Marx: Automated multi-agent code review tool for GitHub PRs."""

__version__ = "v0.1.4"
