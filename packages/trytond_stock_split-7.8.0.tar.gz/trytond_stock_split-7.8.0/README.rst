##################
Stock Split Module
##################

The *Stock Split Module* adds a wizard on moves and shipments that allows you
to split them.

.. toctree::
   :maxdepth: 2

   design
   releases
