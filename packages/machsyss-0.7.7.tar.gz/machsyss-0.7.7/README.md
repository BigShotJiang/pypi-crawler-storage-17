# Creating python classes for protobuf
```
protoc -I=proto --python_out=system_structure/proto proto/system_structure.proto
```