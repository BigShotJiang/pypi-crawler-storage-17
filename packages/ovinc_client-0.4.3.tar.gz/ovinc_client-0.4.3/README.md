## OVINC Union Api Client

### Init

Init: `APP_CODE` `APP_SECRET` `OVINC_API_URL`

### Auth

Available: `verify_code`

### Notice

Available: `mail` `sms` `robot`

### TCaptcha

Available: `tcaptcha`
