# from .dinov3_wrapper import dinov3_vits16
# from .dinov3_wrapper import dinov3_vitb16
# from .dinov3_wrapper import dinov3_vits16plus
# from .dinov3_wrapper import dinov3_vitl16plus
# from .dinov3_wrapper import dinov3_vitl16
# from .dinov3_wrapper import dinov3_vith16plus
# from .dinov3_wrapper import dinov3_vit7b16
# from .dinov3_wrapper import dinov3_convnext_base
# from .dinov3_wrapper import dinov3_convnext_large
# from .dinov3_wrapper import dinov3_convnext_small
# from .dinov3_wrapper import dinov3_convnext_tiny
from terratorch.models.backbones.dinov3 import dinov3_wrapper

