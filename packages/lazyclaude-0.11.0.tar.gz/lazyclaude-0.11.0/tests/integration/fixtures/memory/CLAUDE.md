# Project Guidelines

This is a test memory file for integration tests.

## Development Guidelines

- Follow the project conventions
- Use clear naming
