---
allowed-tools: Skill(quality-gates)
description: Run code quality checks (lint, format, type check, tests)
---

Invoke the `quality-gates` skill to run linting, formatting, type checking, and tests.
