"""
datavitals.sql_builder

Provides a safe, reusable, and dynamic SQL query builder
to avoid manual query writing errors.

Author: Kamaleshkumar.K
"""

from typing import List, Dict, Any, Optional


class SQLBuilderError(Exception):
    """Custom exception for SQL builder related errors."""
    pass


def _format_value(value: Any) -> str:
    """
    Safely format a value for SQL usage.
    (Basic protection against common mistakes)
    """
    if isinstance(value, str):
        return f"'{value}'"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if value is None:
        return "NULL"
    return str(value)


def build_select_query(
    *,
    table: str,
    columns: Optional[List[str]] = None,
    where: Optional[Dict[str, Any]] = None,
    limit: Optional[int] = None
) -> str:
    """
    Build a dynamic SELECT SQL query.

    Parameters
    ----------
    table : str
        Table name.
    columns : list of str, optional
        Columns to select. Defaults to SELECT *.
    where : dict, optional
        WHERE conditions (column=value).
    limit : int, optional
        LIMIT clause.

    Returns
    -------
    str
        Generated SQL query.

    Raises
    ------
    SQLBuilderError
        If inputs are invalid.
    """

    # -------------------------
    # Validation
    # -------------------------
    if not table or not isinstance(table, str):
        raise SQLBuilderError("Table name must be a non-empty string")

    if columns is not None and not isinstance(columns, list):
        raise SQLBuilderError("Columns must be a list of strings")

    if where is not None and not isinstance(where, dict):
        raise SQLBuilderError("WHERE clause must be a dictionary")

    if limit is not None and (not isinstance(limit, int) or limit <= 0):
        raise SQLBuilderError("LIMIT must be a positive integer")

    # -------------------------
    # SELECT clause
    # -------------------------
    if not columns:
        select_clause = "SELECT *"
    else:
        select_clause = "SELECT " + ", ".join(columns)

    # -------------------------
    # FROM clause
    # -------------------------
    from_clause = f"FROM {table}"

    # -------------------------
    # WHERE clause
    # -------------------------
    where_clause = ""
    if where:
        conditions = []
        for col, val in where.items():
            formatted_value = _format_value(val)
            conditions.append(f"{col} = {formatted_value}")
        where_clause = "WHERE " + " AND ".join(conditions)

    # -------------------------
    # LIMIT clause
    # -------------------------
    limit_clause = ""
    if limit:
        limit_clause = f"LIMIT {limit}"

    # -------------------------
    # Final query
    # -------------------------
    query_parts = [
        select_clause,
        from_clause,
        where_clause,
        limit_clause
    ]

    query = " ".join(part for part in query_parts if part).strip()
    return query
