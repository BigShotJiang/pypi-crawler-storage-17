CREATE TABLE tv_customer (
    id UUID PRIMARY KEY,
    data JSONB
);
