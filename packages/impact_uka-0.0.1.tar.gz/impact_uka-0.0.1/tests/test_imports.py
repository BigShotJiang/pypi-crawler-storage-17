
def test_imports() -> None:
    import uka
    import uka.transport
    import uka.patch
    import uka.karmi

