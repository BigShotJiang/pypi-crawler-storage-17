# Impact UKA

This is a Python reimplementation of the Java uka package utilized in the original Imapct Java application

# The Original Implementaion was Licenced As Follows

```
/* ********************************************************************
 * KaRMI
 *
 * Copyright (C) 1998-2003 The JavaParty Team, University of Karlsruhe
 *
 * Permission is hereby granted to use and modify this software.
 * The software, or modifications thereof, may be redistributed only
 * if the source code is also provided and this copyright notice stays 
 * attached.
 **********************************************************************/
 ```

