print("\n" + "=" * 80)
