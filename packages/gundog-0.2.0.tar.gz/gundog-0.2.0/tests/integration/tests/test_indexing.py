"""Test module for indexing feature."""

from pytest_bdd import scenarios

# Load all scenarios from the indexing feature file
scenarios("../features/indexing.feature")
