"""Test module for querying feature."""

from pytest_bdd import scenarios

# Load all scenarios from the querying feature file
scenarios("../features/querying.feature")
