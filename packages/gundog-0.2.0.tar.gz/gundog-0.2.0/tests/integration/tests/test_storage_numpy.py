"""Test module for NumPy storage feature."""

from pytest_bdd import scenarios

# Load all scenarios from the numpy storage feature file
scenarios("../features/storage_numpy.feature")
