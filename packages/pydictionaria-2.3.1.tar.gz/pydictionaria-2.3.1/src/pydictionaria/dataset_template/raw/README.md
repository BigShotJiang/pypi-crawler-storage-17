# Source directory

This directory contains the "raw" source data of the dataset from which the
CLDF dataset in [`cldf/`](../cldf) is derived.
