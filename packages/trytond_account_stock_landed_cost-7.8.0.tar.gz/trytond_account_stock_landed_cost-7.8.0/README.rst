################################
Account Stock Landed Cost Module
################################

The *Account Stock Landed Cost Module* allows the allocation of the landed
costs to supplier shipments after they have been received.

.. toctree::
   :maxdepth: 2

   design
   releases
