# _*_ coding: utf-8 _*_
#
# hspylib-askai v1.2.19
#
# Package: main.askai
"""Package initialization."""

__all__ = [
    'core', 
    'exception', 
    'language', 
    'tui'
]
__version__ = '1.2.19'
