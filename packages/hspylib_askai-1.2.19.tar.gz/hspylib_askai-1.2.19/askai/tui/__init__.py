# _*_ coding: utf-8 _*_
#
# hspylib-askai v1.2.19
#
# Package: main.askai.tui
"""Package initialization."""

__all__ = [
    'app_header', 
    'app_icons', 
    'app_suggester', 
    'app_widgets', 
    'askai_app'
]
__version__ = '1.2.19'
