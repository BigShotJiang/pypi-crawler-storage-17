# _*_ coding: utf-8 _*_
#
# hspylib-askai v1.2.19
#
# Package: main.askai.core.router
"""Package initialization."""

__all__ = [
    'agent_tools', 
    'evaluation', 
    'model_selector', 
    'task_agent', 
    'tools'
]
__version__ = '1.2.19'
