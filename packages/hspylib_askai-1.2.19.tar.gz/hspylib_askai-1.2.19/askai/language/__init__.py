# _*_ coding: utf-8 _*_
#
# hspylib-askai v1.2.19
#
# Package: main.askai.language
"""Package initialization."""

__all__ = [
    'ai_translator', 
    'language', 
    'translators'
]
__version__ = '1.2.19'
