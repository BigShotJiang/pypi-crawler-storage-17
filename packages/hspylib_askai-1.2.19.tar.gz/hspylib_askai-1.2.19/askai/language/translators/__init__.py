# _*_ coding: utf-8 _*_
#
# hspylib-askai v1.2.19
#
# Package: main.askai.language.translators
"""Package initialization."""

__all__ = [
    'argos_translator', 
    'deepl_translator', 
    'marian_translator'
]
__version__ = '1.2.19'
