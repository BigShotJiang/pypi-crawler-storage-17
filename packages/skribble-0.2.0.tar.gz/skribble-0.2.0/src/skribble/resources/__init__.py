# Namespace package for resource-specific clients.
