# LLM Completion Library

A Python library for LLM text completion using LiteLLM with Gemini flash 2.5 and OpenAI fallback support.