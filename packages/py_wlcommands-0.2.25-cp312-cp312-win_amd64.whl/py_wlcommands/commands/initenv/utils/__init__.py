"""
Init command utilities.
"""
