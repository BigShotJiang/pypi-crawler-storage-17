# Kamcp
kam mcp
# Install
- pip install kamcp

- uv tool install kamcp

- uv pip install kamcp (no x)

# config 
- Supports all startup methods.
- Use `kamcp --help` to view help information.
```json
{
...
"command":"kamcp",
"args":["stdio"]
...
}
```
# This is a sub-project of the kam project.
