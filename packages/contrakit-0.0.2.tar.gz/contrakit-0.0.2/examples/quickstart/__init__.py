# Quickstart examples for contrakit
# Simple, focused demonstrations of core concepts

__version__ = "1.0.0"
