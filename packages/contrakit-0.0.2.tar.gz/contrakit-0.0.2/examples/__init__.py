"""Examples demonstrating the Mathematical Theory of Contradiction."""
