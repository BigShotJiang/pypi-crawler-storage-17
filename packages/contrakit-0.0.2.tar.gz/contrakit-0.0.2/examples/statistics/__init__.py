# Statistics examples for contrakit
# These examples demonstrate statistical paradoxes and frame integration

__version__ = "1.0.0"