from examples.quantum.CHSH import *
from examples.quantum.KCBS import *
from examples.quantum.magic_squares import *
