# Get started

## Installation

```bash
pip install voraus-logging-lib

# Or with uv
uv add voraus-logging-lib
```

## Basic Usage

```{literalinclude} examples/basic_usage.py
:language: python
```
