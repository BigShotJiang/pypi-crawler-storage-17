"""Documentation examples."""
