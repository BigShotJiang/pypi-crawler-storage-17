"""
SIA Package Initializer
----------------------
Modules:

1. NTT  — Entity / Object modeling
2. CHI  — Chemical analysis toolkit
3. ELS  — Enterprise Logic Studio (ABAP Interpreter)
"""

# =====================================================
# Existing NTT Module
# =====================================================

from .ntt import ntt


# =====================================================
# Existing CHI Module
# =====================================================

from .chi import chi as ChiClass
chi = ChiClass(verbose=False)


# =====================================================
# SIA Enterprise Logic Studio (ABAP Interpreter)
# =====================================================

try:
    # Import the complete ELS module
    from .els import (
        # Main API
        run,
        run_file,
        repl,
        safe_run,
        
        # Core components
        tokenize_abap,
        FullParser,
        RuntimeEnv,
        execute_program,
        
        # Helper functions
        load_sql_table,
        register_class,
        set_object_attr,
        get_object_attr,
        
        # Type system
        ABAPType,
        TypedVariable,
    )
    
    # Re-export with consistent naming
    els_run = run
    els_run_file = run_file
    els_repl = repl
    els_safe_run = safe_run
    els_tokenize_abap = tokenize_abap
    els_FullParser = FullParser
    els_RuntimeEnv = RuntimeEnv
    els_execute_program = execute_program
    els_load_sql_table = load_sql_table
    els_register_class = register_class
    els_set_object_attr = set_object_attr
    els_get_object_attr = get_object_attr
    els_ABAPType = ABAPType
    els_TypedVariable = TypedVariable
    
    # Optional debug flag (future extension-safe)
    els_debug = False

    def els_debug_print(*args, **kwargs):
        """Debug print helper (safe even if unused)"""
        if els_debug:
            print(*args, **kwargs)

except ImportError as e:
    print(f"[SIA] ELS interpreter not loaded: {e}")
    
    # Create placeholder functions for all exports
    def els_run(*args, **kwargs):
        raise ImportError("ELS interpreter missing. Add els.py to the sia folder.")
    
    def els_run_file(*args, **kwargs):
        raise ImportError("ELS interpreter missing. Add els.py to the sia folder.")
    
    def els_repl(*args, **kwargs):
        raise ImportError("ELS interpreter missing. Add els.py to the sia folder.")
    
    def els_safe_run(*args, **kwargs):
        print("[ELS] Interpreter missing.")
        return None
    
    # Placeholders for core components
    els_tokenize_abap = None
    els_FullParser = None
    els_RuntimeEnv = None
    els_execute_program = None
    
    # Placeholders for helper functions
    els_load_sql_table = None
    els_register_class = None
    els_set_object_attr = None
    els_get_object_attr = None
    
    # Placeholders for type system
    els_ABAPType = None
    els_TypedVariable = None
    
    els_debug = False
    
    def els_debug_print(*args, **kwargs):
        pass

except Exception as e:
    print(f"[SIA] Unexpected error loading ELS: {e}")
    # Same fallbacks as above
    def els_run(*args, **kwargs):
        raise ImportError(f"ELS interpreter failed to load: {e}")
    
    # ... (same fallback definitions as above)
    els_debug = False
    els_debug_print = lambda *args, **kwargs: None


# =====================================================
# Package-level convenience functions
# =====================================================

def abap(code: str, params: dict = None) -> str:
    """Convenience function to run ABAP code"""
    return els_run(code, params)


def abap_file(filename: str, params: dict = None) -> str:
    """Convenience function to run ABAP from file"""
    return els_run_file(filename, params)


# =====================================================
# Public API
# =====================================================

__all__ = [
    # Core modules
    "ntt",
    "chi",
    
    # Main ABAP Interpreter API
    "els_run",
    "els_run_file",
    "els_repl",
    "els_safe_run",
    
    # Core components
    "els_tokenize_abap",
    "els_FullParser",
    "els_RuntimeEnv",
    "els_execute_program",
    
    # Helper functions
    "els_load_sql_table",
    "els_register_class",
    "els_set_object_attr",
    "els_get_object_attr",
    
    # Type system
    "els_ABAPType",
    "els_TypedVariable",
    
    # Debug
    "els_debug",
    "els_debug_print",
    
    # Package-level conveniences
    "abap",
    "abap_file",
]