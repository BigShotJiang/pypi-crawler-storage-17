"""Task handlers for different modalities."""

from hftool.tasks.base import BaseTask

__all__ = ["BaseTask"]
