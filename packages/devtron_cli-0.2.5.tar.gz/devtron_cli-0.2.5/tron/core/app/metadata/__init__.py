"""Metadata utilities for tron applications."""

