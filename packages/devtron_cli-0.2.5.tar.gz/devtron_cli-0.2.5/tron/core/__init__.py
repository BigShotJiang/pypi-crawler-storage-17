"""Core package for tron.

This file marks `tron.core` as a package so imports like
`from tron.core.app import ...` work after installation.
"""

