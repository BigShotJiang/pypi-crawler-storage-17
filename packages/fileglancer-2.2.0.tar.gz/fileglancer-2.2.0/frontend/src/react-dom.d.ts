declare module 'react-dom';
