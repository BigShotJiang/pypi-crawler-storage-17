"""Allow running mind as a module: python -m mind"""
from mind.cli import cli

if __name__ == "__main__":
    cli()
