GET_DATA_ANALYST_STATUS_V1 = "v1/assistant/{id}/status"              # GET - Gets the current status of the Data Analyst Assistant data set loading process.
EXTEND_DATA_ANALYST_DATASET_V1 = "v1/assistant/{id}/datasets/extend" # POST - Extends the data sets of an existing Data Analyst Assistant.
