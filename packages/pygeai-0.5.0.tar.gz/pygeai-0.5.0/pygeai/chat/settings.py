LLM_SETTINGS = {
    "temperature": 0.6,
    "max_tokens": 800,
    "frequency_penalty": 0.1,
    "presence_penalty": 0.2
}
