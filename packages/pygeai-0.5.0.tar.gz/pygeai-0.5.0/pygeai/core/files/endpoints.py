UPLOAD_FILE_V1 = "v1/files"	# POST -> Uploads a file
GET_FILE_V1 = "v1/files/{fileId}"	 # GET -> Gets a file by Id
DELETE_FILE_V1 = "v1/files/{fileId}"	 # DELETE -> Deletes a file by Id
GET_FILE_CONTENT_V1 = "v1/files/{fileId}/content"  # GET -> Gets the content of a file by Id
GET_ALL_FILES_V1 = "v1/files/all" 	# GET -> Gets all files