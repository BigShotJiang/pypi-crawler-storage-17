GENERATE_EMBEDDINGS = "/embeddings"  # POST -> Creates an embedding vector representing the input
