# -*- coding: utf-8 -*-

import sys


from pygeai.cli.geai import main as geai


def main():
    sys.exit(geai())


if __name__ == "__main__":
    main()
