# Development

- Run tests with coverage (required 100%): `pytest`
- Lint/format as you prefer; core code targets readability with minimal dependencies.
