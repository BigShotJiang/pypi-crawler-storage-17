Low-Value Asset (LVA) are typically asset with low values and was booked
as expense on vendor bill. In essence, the low value asset is not really
and asset but an expense need to tracke as asset. As such, it has no
residual value, run no depreciation. And when removed, only status is
changed (no accounting entry).

To create low value asset, use the Asset Profile with following setting,

1.  Asset Account = Expense (low value asset)
2.  Number of Years = 0
