from opsorchestrator.core.data_model.technology import Technology
from opsorchestrator.core.data_model.component import Component

class Network(Technology):
    pass
class TestConnectivity(Component):
    pass