"""Contracts for OpsOrchestrator"""
from opsorchestrator.core.data_model.technology import Technology
from opsorchestrator.core.data_model.component import Component

class OpsOrchestrator(Technology):
    pass
class Frontend(Component):
    pass