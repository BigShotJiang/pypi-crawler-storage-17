from opsorchestrator.core.data_model.technology import Technology
from opsorchestrator.core.data_model.component import Component


class Microsoft(Technology):
    pass


class Mde(Component):
    pass