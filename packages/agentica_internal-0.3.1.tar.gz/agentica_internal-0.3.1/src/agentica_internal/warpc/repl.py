from ..repl import AbstractRepl as ReplP

__all__ = [
    'ReplP',
]
