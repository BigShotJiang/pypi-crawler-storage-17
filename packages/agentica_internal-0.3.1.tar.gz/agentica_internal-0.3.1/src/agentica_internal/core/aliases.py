# fmt: off

__all__ = [
    'SessionID',
    'InvocationID',
]

type SessionID = str
type InvocationID = str
