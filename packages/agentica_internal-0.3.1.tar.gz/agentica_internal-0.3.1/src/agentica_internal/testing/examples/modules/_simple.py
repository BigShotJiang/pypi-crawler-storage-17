# fmt: off

"""
Simple module docstring
"""

type my_mod_type = int

my_mod_var: int = 2


class MyModClass:
    a: int
    b: bool

    def f(self, c: float) -> 'MyModClass': ...


def my_mod_func():
    pass
