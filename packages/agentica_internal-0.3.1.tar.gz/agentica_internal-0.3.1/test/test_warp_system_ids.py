from agentica_internal.testing.warpc.system_id_tests import *


def test_system_class_ids():
    verify_system_class_ids()


def test_system_function_ids():
    verify_system_function_ids()


def test_system_object_ids():
    verify_system_object_ids()


def test_system_tables_disjoint():
    verify_system_tables_disjoint()
