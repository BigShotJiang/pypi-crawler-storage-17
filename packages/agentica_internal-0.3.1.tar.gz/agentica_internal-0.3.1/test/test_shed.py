from agentica_internal.testing.cpython.shed_tests import *


def test_builtins_shed():
    verify_builtins_shed()


def test_math_shed():
    verify_math_shed()


def test_not_in_shed():
    verify_not_in_shed()
