#𝖇𝖞 𝖊𝖑𝖎7𝖊𝖎𝖓 - 𝕰7

from .profiler import QueryProfiler

__all__ = ["QueryProfiler"]