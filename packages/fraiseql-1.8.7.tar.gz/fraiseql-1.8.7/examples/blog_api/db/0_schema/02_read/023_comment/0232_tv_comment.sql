CREATE TABLE tv_comment (
    id UUID PRIMARY KEY,
    data JSONB
);
