"""
### Typed Independentreserve
> A fully typed, validated async client for the Independentreserve API

- Details
"""