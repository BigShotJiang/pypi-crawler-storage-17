"""SCP Constructor - Build architecture graphs from scp.yaml files."""

__version__ = "0.1.0"
