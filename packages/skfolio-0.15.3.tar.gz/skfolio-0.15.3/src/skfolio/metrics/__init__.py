"""Metrics module."""

from skfolio.metrics._scorer import make_scorer

__all__ = ["make_scorer"]
