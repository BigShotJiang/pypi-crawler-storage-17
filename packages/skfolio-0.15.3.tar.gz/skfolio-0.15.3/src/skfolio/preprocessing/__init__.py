"""Preprocessing module."""

from skfolio.preprocessing._returns import prices_to_returns

__all__ = ["prices_to_returns"]
