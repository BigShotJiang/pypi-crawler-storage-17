# -*- coding: utf-8 -*-
"""
# ---------------------------------------------------------------------------------------------------------
# ProjectName:  qlv-helper
# FileName:     custom_exception.py
# Description:  自定义异常模块
# Author:       ASUS
# CreateDate:   2025/12/17
# Copyright ©2011-2025. Hunan xxxxxxx Company limited. All rights reserved.
# ---------------------------------------------------------------------------------------------------------
"""


class FirstPhaseException(Exception):
    pass


class SecondPhaseException(Exception):
    pass


class ThirdPhaseException(Exception):
    pass


class FourthPhaseException(Exception):
    pass


class FifthPhaseException(Exception):
    pass


class sixthPhaseException(Exception):
    pass
