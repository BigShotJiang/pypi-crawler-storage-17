from ..protocols.sql import CreateTableProtocol as _CreateTableProtocol

# TODO: breaking changes. remove when major release
CreateTableProtocol = _CreateTableProtocol
