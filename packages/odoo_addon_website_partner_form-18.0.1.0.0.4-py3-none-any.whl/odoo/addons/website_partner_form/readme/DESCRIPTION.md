By default, in Odoo, it is not possible to edit some partner website fields in the
backoffice. It forces user to edit information via website interface,
that is not optimal.

This module adds a 'Website' tab in the partner form view.
It so allows to edit the partner website descriptions fields.
(`website_description`, `website_short_description`).

![partner_form](../static/description/img/partner_form.png)
