from kvirt.ksushy import Ksushy


def run():
    sushy = Ksushy()
    sushy.run()


if __name__ == '__main__':
    run()
