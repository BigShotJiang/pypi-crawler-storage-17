"""CPU Loader - Generate configurable CPU load with WebUI and REST API."""

from .cpu_loader import CPULoader

__all__ = ["CPULoader"]
