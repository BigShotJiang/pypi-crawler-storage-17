# Generated from C:/Users/Javier/Documents/MeaningfulData/Programacion/operations/py_dpm/grammar/dpm_xlParser.g4 by ANTLR 4.13.1
# encoding: utf-8
import sys

from antlr4 import *

if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,95,468,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,46,
        7,46,2,47,7,47,1,0,1,0,1,0,1,0,3,0,101,8,0,3,0,103,8,0,1,0,1,0,1,
        1,1,1,1,1,4,1,110,8,1,11,1,12,1,111,1,2,1,2,3,2,116,8,2,1,3,1,3,
        3,3,120,8,3,1,4,1,4,1,4,1,4,1,4,1,4,3,4,128,8,4,1,5,1,5,1,5,1,5,
        1,6,1,6,1,6,1,6,1,7,1,7,1,7,1,7,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,
        1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,3,8,161,8,8,1,8,1,8,
        1,8,1,8,1,8,1,8,1,8,3,8,170,8,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,
        1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,
        1,8,1,8,1,8,5,8,199,8,8,10,8,12,8,202,9,8,1,9,1,9,1,9,1,9,1,10,1,
        10,1,10,5,10,211,8,10,10,10,12,10,214,9,10,1,10,1,10,1,10,5,10,219,
        8,10,10,10,12,10,222,9,10,3,10,224,8,10,1,11,1,11,1,11,1,11,1,11,
        1,11,1,11,3,11,233,8,11,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,
        1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,4,12,252,8,12,11,12,
        12,12,253,1,12,1,12,3,12,258,8,12,1,13,1,13,1,13,1,13,1,13,1,13,
        1,13,1,13,1,13,1,13,1,13,1,13,3,13,272,8,13,1,14,1,14,1,14,1,14,
        1,14,1,14,1,14,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,3,15,
        290,8,15,1,15,1,15,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,17,1,17,
        1,17,1,17,1,17,1,18,1,18,1,18,1,18,3,18,310,8,18,1,18,1,18,1,19,
        1,19,1,19,1,19,5,19,318,8,19,10,19,12,19,321,9,19,1,20,1,20,1,21,
        1,21,1,21,1,21,1,22,1,22,1,23,1,23,1,24,1,24,1,25,1,25,1,25,1,25,
        1,25,5,25,340,8,25,10,25,12,25,343,9,25,1,25,3,25,346,8,25,1,26,
        1,26,1,26,1,26,1,26,5,26,353,8,26,10,26,12,26,356,9,26,1,26,3,26,
        359,8,26,1,27,1,27,1,27,1,27,1,27,5,27,366,8,27,10,27,12,27,369,
        9,27,1,27,3,27,372,8,27,1,28,1,28,1,28,1,28,1,29,1,29,1,29,1,29,
        1,29,1,29,3,29,384,8,29,1,30,1,30,1,30,1,30,1,30,3,30,391,8,30,1,
        31,1,31,1,31,1,31,1,32,1,32,1,32,1,32,3,32,401,8,32,1,33,1,33,1,
        33,1,33,1,34,1,34,1,35,1,35,1,36,1,36,1,37,1,37,1,38,1,38,1,38,5,
        38,418,8,38,10,38,12,38,421,9,38,1,38,1,38,1,38,5,38,426,8,38,10,
        38,12,38,429,9,38,3,38,431,8,38,1,39,1,39,1,40,1,40,1,40,1,40,1,
        40,1,40,1,40,1,40,5,40,443,8,40,10,40,12,40,446,9,40,3,40,448,8,
        40,1,41,1,41,1,41,1,41,1,42,1,42,1,43,1,43,1,44,1,44,1,45,1,45,1,
        45,1,45,1,46,1,46,1,47,1,47,1,47,0,1,16,48,0,2,4,6,8,10,12,14,16,
        18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,
        62,64,66,68,70,72,74,76,78,80,82,84,86,88,90,92,94,0,15,1,0,16,17,
        1,0,18,19,1,0,3,4,2,0,27,27,29,31,1,0,32,33,1,0,34,35,1,0,20,25,
        1,0,73,75,1,0,76,78,1,0,79,81,1,0,82,83,1,0,8,13,3,0,1,1,60,62,64,
        68,2,0,88,90,92,92,2,0,69,69,92,92,479,0,96,1,0,0,0,2,109,1,0,0,
        0,4,115,1,0,0,0,6,119,1,0,0,0,8,127,1,0,0,0,10,129,1,0,0,0,12,133,
        1,0,0,0,14,137,1,0,0,0,16,169,1,0,0,0,18,203,1,0,0,0,20,223,1,0,
        0,0,22,232,1,0,0,0,24,257,1,0,0,0,26,271,1,0,0,0,28,273,1,0,0,0,
        30,280,1,0,0,0,32,293,1,0,0,0,34,300,1,0,0,0,36,305,1,0,0,0,38,313,
        1,0,0,0,40,322,1,0,0,0,42,324,1,0,0,0,44,328,1,0,0,0,46,330,1,0,
        0,0,48,332,1,0,0,0,50,345,1,0,0,0,52,358,1,0,0,0,54,371,1,0,0,0,
        56,373,1,0,0,0,58,383,1,0,0,0,60,390,1,0,0,0,62,392,1,0,0,0,64,400,
        1,0,0,0,66,402,1,0,0,0,68,406,1,0,0,0,70,408,1,0,0,0,72,410,1,0,
        0,0,74,412,1,0,0,0,76,430,1,0,0,0,78,432,1,0,0,0,80,447,1,0,0,0,
        82,449,1,0,0,0,84,453,1,0,0,0,86,455,1,0,0,0,88,457,1,0,0,0,90,459,
        1,0,0,0,92,463,1,0,0,0,94,465,1,0,0,0,96,102,3,4,2,0,97,98,5,59,
        0,0,98,103,3,2,1,0,99,101,5,59,0,0,100,99,1,0,0,0,100,101,1,0,0,
        0,101,103,1,0,0,0,102,97,1,0,0,0,102,100,1,0,0,0,103,104,1,0,0,0,
        104,105,5,0,0,1,105,1,1,0,0,0,106,107,3,4,2,0,107,108,5,59,0,0,108,
        110,1,0,0,0,109,106,1,0,0,0,110,111,1,0,0,0,111,109,1,0,0,0,111,
        112,1,0,0,0,112,3,1,0,0,0,113,116,3,8,4,0,114,116,3,12,6,0,115,113,
        1,0,0,0,115,114,1,0,0,0,116,5,1,0,0,0,117,120,3,14,7,0,118,120,3,
        8,4,0,119,117,1,0,0,0,119,118,1,0,0,0,120,7,1,0,0,0,121,128,3,16,
        8,0,122,123,5,15,0,0,123,124,3,10,5,0,124,125,5,38,0,0,125,126,3,
        16,8,0,126,128,1,0,0,0,127,121,1,0,0,0,127,122,1,0,0,0,128,9,1,0,
        0,0,129,130,5,41,0,0,130,131,3,68,34,0,131,132,5,42,0,0,132,11,1,
        0,0,0,133,134,3,94,47,0,134,135,5,6,0,0,135,136,3,6,3,0,136,13,1,
        0,0,0,137,138,3,66,33,0,138,139,5,7,0,0,139,140,3,8,4,0,140,15,1,
        0,0,0,141,142,6,8,-1,0,142,143,5,39,0,0,143,144,3,16,8,0,144,145,
        5,40,0,0,145,170,1,0,0,0,146,170,3,22,11,0,147,148,7,0,0,0,148,170,
        3,16,8,15,149,150,5,5,0,0,150,151,5,39,0,0,151,152,3,16,8,0,152,
        153,5,40,0,0,153,170,1,0,0,0,154,155,5,45,0,0,155,156,3,16,8,0,156,
        157,5,47,0,0,157,160,3,16,8,0,158,159,5,48,0,0,159,161,3,16,8,0,
        160,158,1,0,0,0,160,161,1,0,0,0,161,162,1,0,0,0,162,163,5,46,0,0,
        163,170,1,0,0,0,164,170,3,42,21,0,165,170,3,90,45,0,166,170,3,88,
        44,0,167,170,3,86,43,0,168,170,3,62,31,0,169,141,1,0,0,0,169,146,
        1,0,0,0,169,147,1,0,0,0,169,149,1,0,0,0,169,154,1,0,0,0,169,164,
        1,0,0,0,169,165,1,0,0,0,169,166,1,0,0,0,169,167,1,0,0,0,169,168,
        1,0,0,0,170,200,1,0,0,0,171,172,10,13,0,0,172,173,7,1,0,0,173,199,
        3,16,8,14,174,175,10,12,0,0,175,176,7,0,0,0,176,199,3,16,8,13,177,
        178,10,11,0,0,178,179,5,57,0,0,179,199,3,16,8,12,180,181,10,10,0,
        0,181,182,3,84,42,0,182,183,3,16,8,11,183,199,1,0,0,0,184,185,10,
        8,0,0,185,186,5,2,0,0,186,199,3,16,8,9,187,188,10,7,0,0,188,189,
        7,2,0,0,189,199,3,16,8,8,190,191,10,16,0,0,191,192,5,43,0,0,192,
        193,3,80,40,0,193,194,5,44,0,0,194,199,1,0,0,0,195,196,10,9,0,0,
        196,197,5,36,0,0,197,199,3,18,9,0,198,171,1,0,0,0,198,174,1,0,0,
        0,198,177,1,0,0,0,198,180,1,0,0,0,198,184,1,0,0,0,198,187,1,0,0,
        0,198,190,1,0,0,0,198,195,1,0,0,0,199,202,1,0,0,0,200,198,1,0,0,
        0,200,201,1,0,0,0,201,17,1,0,0,0,202,200,1,0,0,0,203,204,5,41,0,
        0,204,205,3,20,10,0,205,206,5,42,0,0,206,19,1,0,0,0,207,212,3,42,
        21,0,208,209,5,37,0,0,209,211,3,42,21,0,210,208,1,0,0,0,211,214,
        1,0,0,0,212,210,1,0,0,0,212,213,1,0,0,0,213,224,1,0,0,0,214,212,
        1,0,0,0,215,220,3,86,43,0,216,217,5,37,0,0,217,219,3,86,43,0,218,
        216,1,0,0,0,219,222,1,0,0,0,220,218,1,0,0,0,220,221,1,0,0,0,221,
        224,1,0,0,0,222,220,1,0,0,0,223,207,1,0,0,0,223,215,1,0,0,0,224,
        21,1,0,0,0,225,233,3,36,18,0,226,233,3,24,12,0,227,233,3,26,13,0,
        228,233,3,28,14,0,229,233,3,32,16,0,230,233,3,30,15,0,231,233,3,
        34,17,0,232,225,1,0,0,0,232,226,1,0,0,0,232,227,1,0,0,0,232,228,
        1,0,0,0,232,229,1,0,0,0,232,230,1,0,0,0,232,231,1,0,0,0,233,23,1,
        0,0,0,234,235,7,3,0,0,235,236,5,39,0,0,236,237,3,16,8,0,237,238,
        5,40,0,0,238,258,1,0,0,0,239,240,7,4,0,0,240,241,5,39,0,0,241,242,
        3,16,8,0,242,243,5,37,0,0,243,244,3,16,8,0,244,245,5,40,0,0,245,
        258,1,0,0,0,246,247,7,5,0,0,247,248,5,39,0,0,248,251,3,16,8,0,249,
        250,5,37,0,0,250,252,3,16,8,0,251,249,1,0,0,0,252,253,1,0,0,0,253,
        251,1,0,0,0,253,254,1,0,0,0,254,255,1,0,0,0,255,256,5,40,0,0,256,
        258,1,0,0,0,257,234,1,0,0,0,257,239,1,0,0,0,257,246,1,0,0,0,258,
        25,1,0,0,0,259,260,5,14,0,0,260,261,5,39,0,0,261,262,3,16,8,0,262,
        263,5,37,0,0,263,264,3,86,43,0,264,265,5,40,0,0,265,272,1,0,0,0,
        266,267,5,28,0,0,267,268,5,39,0,0,268,269,3,16,8,0,269,270,5,40,
        0,0,270,272,1,0,0,0,271,259,1,0,0,0,271,266,1,0,0,0,272,27,1,0,0,
        0,273,274,5,50,0,0,274,275,5,39,0,0,275,276,3,16,8,0,276,277,5,37,
        0,0,277,278,3,16,8,0,278,279,5,40,0,0,279,29,1,0,0,0,280,281,5,55,
        0,0,281,282,5,39,0,0,282,283,3,16,8,0,283,284,5,37,0,0,284,285,5,
        58,0,0,285,286,5,37,0,0,286,289,5,60,0,0,287,288,5,37,0,0,288,290,
        3,92,46,0,289,287,1,0,0,0,289,290,1,0,0,0,290,291,1,0,0,0,291,292,
        5,40,0,0,292,31,1,0,0,0,293,294,5,49,0,0,294,295,5,39,0,0,295,296,
        3,16,8,0,296,297,5,37,0,0,297,298,3,16,8,0,298,299,5,40,0,0,299,
        33,1,0,0,0,300,301,5,56,0,0,301,302,5,39,0,0,302,303,3,16,8,0,303,
        304,5,40,0,0,304,35,1,0,0,0,305,306,7,6,0,0,306,307,5,39,0,0,307,
        309,3,16,8,0,308,310,3,38,19,0,309,308,1,0,0,0,309,310,1,0,0,0,310,
        311,1,0,0,0,311,312,5,40,0,0,312,37,1,0,0,0,313,314,5,26,0,0,314,
        319,3,88,44,0,315,316,5,37,0,0,316,318,3,88,44,0,317,315,1,0,0,0,
        318,321,1,0,0,0,319,317,1,0,0,0,319,320,1,0,0,0,320,39,1,0,0,0,321,
        319,1,0,0,0,322,323,5,91,0,0,323,41,1,0,0,0,324,325,5,43,0,0,325,
        326,3,40,20,0,326,327,5,44,0,0,327,43,1,0,0,0,328,329,7,7,0,0,329,
        45,1,0,0,0,330,331,7,8,0,0,331,47,1,0,0,0,332,333,7,9,0,0,333,49,
        1,0,0,0,334,346,3,44,22,0,335,336,5,39,0,0,336,341,5,73,0,0,337,
        338,5,37,0,0,338,340,5,73,0,0,339,337,1,0,0,0,340,343,1,0,0,0,341,
        339,1,0,0,0,341,342,1,0,0,0,342,344,1,0,0,0,343,341,1,0,0,0,344,
        346,5,40,0,0,345,334,1,0,0,0,345,335,1,0,0,0,346,51,1,0,0,0,347,
        359,3,46,23,0,348,349,5,39,0,0,349,354,5,76,0,0,350,351,5,37,0,0,
        351,353,5,76,0,0,352,350,1,0,0,0,353,356,1,0,0,0,354,352,1,0,0,0,
        354,355,1,0,0,0,355,357,1,0,0,0,356,354,1,0,0,0,357,359,5,40,0,0,
        358,347,1,0,0,0,358,348,1,0,0,0,359,53,1,0,0,0,360,372,3,48,24,0,
        361,362,5,39,0,0,362,367,5,79,0,0,363,364,5,37,0,0,364,366,5,79,
        0,0,365,363,1,0,0,0,366,369,1,0,0,0,367,365,1,0,0,0,367,368,1,0,
        0,0,368,370,1,0,0,0,369,367,1,0,0,0,370,372,5,40,0,0,371,360,1,0,
        0,0,371,361,1,0,0,0,372,55,1,0,0,0,373,374,5,71,0,0,374,375,5,38,
        0,0,375,376,5,1,0,0,376,57,1,0,0,0,377,378,5,72,0,0,378,379,5,38,
        0,0,379,384,3,86,43,0,380,381,5,72,0,0,381,382,5,38,0,0,382,384,
        5,63,0,0,383,377,1,0,0,0,383,380,1,0,0,0,384,59,1,0,0,0,385,391,
        3,50,25,0,386,391,3,52,26,0,387,391,3,54,27,0,388,391,3,56,28,0,
        389,391,3,58,29,0,390,385,1,0,0,0,390,386,1,0,0,0,390,387,1,0,0,
        0,390,388,1,0,0,0,390,389,1,0,0,0,391,61,1,0,0,0,392,393,5,41,0,
        0,393,394,3,64,32,0,394,395,5,42,0,0,395,63,1,0,0,0,396,401,3,68,
        34,0,397,401,3,72,36,0,398,401,3,74,37,0,399,401,3,70,35,0,400,396,
        1,0,0,0,400,397,1,0,0,0,400,398,1,0,0,0,400,399,1,0,0,0,401,65,1,
        0,0,0,402,403,5,41,0,0,403,404,3,72,36,0,404,405,5,42,0,0,405,67,
        1,0,0,0,406,407,3,76,38,0,407,69,1,0,0,0,408,409,5,86,0,0,409,71,
        1,0,0,0,410,411,5,84,0,0,411,73,1,0,0,0,412,413,5,85,0,0,413,75,
        1,0,0,0,414,419,3,78,39,0,415,416,5,37,0,0,416,418,3,60,30,0,417,
        415,1,0,0,0,418,421,1,0,0,0,419,417,1,0,0,0,419,420,1,0,0,0,420,
        431,1,0,0,0,421,419,1,0,0,0,422,427,3,60,30,0,423,424,5,37,0,0,424,
        426,3,60,30,0,425,423,1,0,0,0,426,429,1,0,0,0,427,425,1,0,0,0,427,
        428,1,0,0,0,428,431,1,0,0,0,429,427,1,0,0,0,430,414,1,0,0,0,430,
        422,1,0,0,0,431,77,1,0,0,0,432,433,7,10,0,0,433,79,1,0,0,0,434,435,
        5,51,0,0,435,448,3,16,8,0,436,437,5,52,0,0,437,448,3,88,44,0,438,
        439,5,53,0,0,439,444,3,82,41,0,440,441,5,37,0,0,441,443,3,82,41,
        0,442,440,1,0,0,0,443,446,1,0,0,0,444,442,1,0,0,0,444,445,1,0,0,
        0,445,448,1,0,0,0,446,444,1,0,0,0,447,434,1,0,0,0,447,436,1,0,0,
        0,447,438,1,0,0,0,448,81,1,0,0,0,449,450,3,88,44,0,450,451,5,54,
        0,0,451,452,3,88,44,0,452,83,1,0,0,0,453,454,7,11,0,0,454,85,1,0,
        0,0,455,456,7,12,0,0,456,87,1,0,0,0,457,458,7,13,0,0,458,89,1,0,
        0,0,459,460,5,43,0,0,460,461,3,92,46,0,461,462,5,44,0,0,462,91,1,
        0,0,0,463,464,7,14,0,0,464,93,1,0,0,0,465,466,5,69,0,0,466,95,1,
        0,0,0,34,100,102,111,115,119,127,160,169,198,200,212,220,223,232,
        253,257,271,289,309,319,341,345,354,358,367,371,383,390,400,419,
        427,430,444,447
    ]

class dpm_xlParser ( Parser ):

    grammarFileName = "dpm_xlParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                     "<INVALID>", "<INVALID>", "':='", "'<-'", "<INVALID>",
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                     "<INVALID>", "<INVALID>", "'with'", "<INVALID>", "<INVALID>",
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                     "'group by'", "<INVALID>", "<INVALID>", "<INVALID>",
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                     "<INVALID>", "<INVALID>", "'in'", "<INVALID>", "<INVALID>",
                     "<INVALID>", "<INVALID>", "'{'", "<INVALID>", "'['",
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                     "<INVALID>", "<INVALID>", "<INVALID>", "';'", "<INVALID>",
                     "<INVALID>", "<INVALID>", "'null'", "<INVALID>", "<INVALID>",
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                     "<INVALID>", "'interval'", "'default'" ]

    symbolicNames = [ "<INVALID>", "BOOLEAN_LITERAL", "AND", "OR", "XOR",
                      "NOT", "ASSIGN", "PERSISTENT_ASSIGN", "EQ", "NE",
                      "LT", "LE", "GT", "GE", "MATCH", "WITH", "PLUS", "MINUS",
                      "MULT", "DIV", "MAX_AGGR", "MIN_AGGR", "SUM", "COUNT",
                      "AVG", "MEDIAN", "GROUP_BY", "ABS", "ISNULL", "EXP",
                      "LN", "SQRT", "POWER", "LOG", "MAX", "MIN", "IN",
                      "COMMA", "COLON", "LPAREN", "RPAREN", "CURLY_BRACKET_LEFT",
                      "CURLY_BRACKET_RIGHT", "SQUARE_BRACKET_LEFT", "SQUARE_BRACKET_RIGHT",
                      "IF", "ENDIF", "THEN", "ELSE", "NVL", "FILTER", "WHERE",
                      "GET", "RENAME", "TO", "TIME_SHIFT", "LEN", "CONCAT",
                      "TIME_PERIOD", "EOL", "INTEGER_LITERAL", "DECIMAL_LITERAL",
                      "PERCENT_LITERAL", "NULL_LITERAL", "STRING_LITERAL",
                      "EMPTY_LITERAL", "DATE_LITERAL", "TIME_INTERVAL_LITERAL",
                      "TIME_PERIOD_LITERAL", "CODE", "WS", "INTERVAL", "DEFAULT",
                      "ROW", "ROW_RANGE", "ROW_ALL", "COL", "COL_RANGE",
                      "COL_ALL", "SHEET", "SHEET_RANGE", "SHEET_ALL", "TABLE_REFERENCE",
                      "TABLE_GROUP_REFERENCE", "VAR_REFERENCE", "OPERATION_REFERENCE",
                      "PRECONDITION_ELEMENT", "SELECTION_MODE_WS", "ROW_COMPONENT",
                      "COL_COMPONENT", "SHEET_COMPONENT", "ITEM_SIGNATURE",
                      "PROPERTY_CODE", "CLAUSE_WS", "GROUPING_WS", "SET_OPERAND_MODE_WS" ]

    RULE_start = 0
    RULE_statements = 1
    RULE_statement = 2
    RULE_persistentExpression = 3
    RULE_expressionWithoutAssignment = 4
    RULE_partialSelection = 5
    RULE_temporaryAssignmentExpression = 6
    RULE_persistentAssignmentExpression = 7
    RULE_expression = 8
    RULE_setOperand = 9
    RULE_setElements = 10
    RULE_functions = 11
    RULE_numericOperators = 12
    RULE_comparisonFunctionOperators = 13
    RULE_filterOperators = 14
    RULE_timeOperators = 15
    RULE_conditionalOperators = 16
    RULE_stringOperators = 17
    RULE_aggregateOperators = 18
    RULE_groupingClause = 19
    RULE_itemSignature = 20
    RULE_itemReference = 21
    RULE_rowElem = 22
    RULE_colElem = 23
    RULE_sheetElem = 24
    RULE_rowHandler = 25
    RULE_colHandler = 26
    RULE_sheetHandler = 27
    RULE_interval = 28
    RULE_default = 29
    RULE_argument = 30
    RULE_select = 31
    RULE_selectOperand = 32
    RULE_varID = 33
    RULE_cellRef = 34
    RULE_preconditionElem = 35
    RULE_varRef = 36
    RULE_operationRef = 37
    RULE_cellAddress = 38
    RULE_tableReference = 39
    RULE_clauseOperators = 40
    RULE_renameClause = 41
    RULE_comparisonOperators = 42
    RULE_literal = 43
    RULE_keyNames = 44
    RULE_propertyReference = 45
    RULE_propertyCode = 46
    RULE_temporaryIdentifier = 47

    ruleNames =  [ "start", "statements", "statement", "persistentExpression",
                   "expressionWithoutAssignment", "partialSelection", "temporaryAssignmentExpression",
                   "persistentAssignmentExpression", "expression", "setOperand",
                   "setElements", "functions", "numericOperators", "comparisonFunctionOperators",
                   "filterOperators", "timeOperators", "conditionalOperators",
                   "stringOperators", "aggregateOperators", "groupingClause",
                   "itemSignature", "itemReference", "rowElem", "colElem",
                   "sheetElem", "rowHandler", "colHandler", "sheetHandler",
                   "interval", "default", "argument", "select", "selectOperand",
                   "varID", "cellRef", "preconditionElem", "varRef", "operationRef",
                   "cellAddress", "tableReference", "clauseOperators", "renameClause",
                   "comparisonOperators", "literal", "keyNames", "propertyReference",
                   "propertyCode", "temporaryIdentifier" ]

    EOF = Token.EOF
    BOOLEAN_LITERAL=1
    AND=2
    OR=3
    XOR=4
    NOT=5
    ASSIGN=6
    PERSISTENT_ASSIGN=7
    EQ=8
    NE=9
    LT=10
    LE=11
    GT=12
    GE=13
    MATCH=14
    WITH=15
    PLUS=16
    MINUS=17
    MULT=18
    DIV=19
    MAX_AGGR=20
    MIN_AGGR=21
    SUM=22
    COUNT=23
    AVG=24
    MEDIAN=25
    GROUP_BY=26
    ABS=27
    ISNULL=28
    EXP=29
    LN=30
    SQRT=31
    POWER=32
    LOG=33
    MAX=34
    MIN=35
    IN=36
    COMMA=37
    COLON=38
    LPAREN=39
    RPAREN=40
    CURLY_BRACKET_LEFT=41
    CURLY_BRACKET_RIGHT=42
    SQUARE_BRACKET_LEFT=43
    SQUARE_BRACKET_RIGHT=44
    IF=45
    ENDIF=46
    THEN=47
    ELSE=48
    NVL=49
    FILTER=50
    WHERE=51
    GET=52
    RENAME=53
    TO=54
    TIME_SHIFT=55
    LEN=56
    CONCAT=57
    TIME_PERIOD=58
    EOL=59
    INTEGER_LITERAL=60
    DECIMAL_LITERAL=61
    PERCENT_LITERAL=62
    NULL_LITERAL=63
    STRING_LITERAL=64
    EMPTY_LITERAL=65
    DATE_LITERAL=66
    TIME_INTERVAL_LITERAL=67
    TIME_PERIOD_LITERAL=68
    CODE=69
    WS=70
    INTERVAL=71
    DEFAULT=72
    ROW=73
    ROW_RANGE=74
    ROW_ALL=75
    COL=76
    COL_RANGE=77
    COL_ALL=78
    SHEET=79
    SHEET_RANGE=80
    SHEET_ALL=81
    TABLE_REFERENCE=82
    TABLE_GROUP_REFERENCE=83
    VAR_REFERENCE=84
    OPERATION_REFERENCE=85
    PRECONDITION_ELEMENT=86
    SELECTION_MODE_WS=87
    ROW_COMPONENT=88
    COL_COMPONENT=89
    SHEET_COMPONENT=90
    ITEM_SIGNATURE=91
    PROPERTY_CODE=92
    CLAUSE_WS=93
    GROUPING_WS=94
    SET_OPERAND_MODE_WS=95

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class StartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self):
            return self.getTypedRuleContext(dpm_xlParser.StatementContext,0)


        def EOF(self):
            return self.getToken(dpm_xlParser.EOF, 0)

        def EOL(self):
            return self.getToken(dpm_xlParser.EOL, 0)

        def statements(self):
            return self.getTypedRuleContext(dpm_xlParser.StatementsContext,0)


        def getRuleIndex(self):
            return dpm_xlParser.RULE_start

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStart" ):
                listener.enterStart(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStart" ):
                listener.exitStart(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStart" ):
                return visitor.visitStart(self)
            else:
                return visitor.visitChildren(self)




    def start(self):

        localctx = dpm_xlParser.StartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_start)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 96
            self.statement()
            self.state = 102
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.state = 97
                self.match(dpm_xlParser.EOL)
                self.state = 98
                self.statements()
                pass

            elif la_ == 2:
                self.state = 100
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==59:
                    self.state = 99
                    self.match(dpm_xlParser.EOL)


                pass


            self.state = 104
            self.match(dpm_xlParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.StatementContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.StatementContext,i)


        def EOL(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.EOL)
            else:
                return self.getToken(dpm_xlParser.EOL, i)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_statements

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatements" ):
                listener.enterStatements(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatements" ):
                listener.exitStatements(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatements" ):
                return visitor.visitStatements(self)
            else:
                return visitor.visitChildren(self)




    def statements(self):

        localctx = dpm_xlParser.StatementsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statements)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 109
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 106
                self.statement()
                self.state = 107
                self.match(dpm_xlParser.EOL)
                self.state = 111
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 8180272571060830242) != 0) or ((((_la - 64)) & ~0x3f) == 0 and ((1 << (_la - 64)) & 385876031) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_statement


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class AssignmentExprContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def temporaryAssignmentExpression(self):
            return self.getTypedRuleContext(dpm_xlParser.TemporaryAssignmentExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignmentExpr" ):
                listener.enterAssignmentExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignmentExpr" ):
                listener.exitAssignmentExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignmentExpr" ):
                return visitor.visitAssignmentExpr(self)
            else:
                return visitor.visitChildren(self)


    class ExprWithoutAssignmentContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressionWithoutAssignment(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionWithoutAssignmentContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprWithoutAssignment" ):
                listener.enterExprWithoutAssignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprWithoutAssignment" ):
                listener.exitExprWithoutAssignment(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExprWithoutAssignment" ):
                return visitor.visitExprWithoutAssignment(self)
            else:
                return visitor.visitChildren(self)



    def statement(self):

        localctx = dpm_xlParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_statement)
        try:
            self.state = 115
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 5, 14, 15, 16, 17, 20, 21, 22, 23, 24, 25, 27, 28, 29, 30, 31, 32, 33, 34, 35, 39, 41, 43, 45, 49, 50, 55, 56, 60, 61, 62, 64, 65, 66, 67, 68, 88, 89, 90, 92]:
                localctx = dpm_xlParser.ExprWithoutAssignmentContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 113
                self.expressionWithoutAssignment()
                pass
            elif token in [69]:
                localctx = dpm_xlParser.AssignmentExprContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 114
                self.temporaryAssignmentExpression()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PersistentExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def persistentAssignmentExpression(self):
            return self.getTypedRuleContext(dpm_xlParser.PersistentAssignmentExpressionContext,0)


        def expressionWithoutAssignment(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionWithoutAssignmentContext,0)


        def getRuleIndex(self):
            return dpm_xlParser.RULE_persistentExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPersistentExpression" ):
                listener.enterPersistentExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPersistentExpression" ):
                listener.exitPersistentExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPersistentExpression" ):
                return visitor.visitPersistentExpression(self)
            else:
                return visitor.visitChildren(self)




    def persistentExpression(self):

        localctx = dpm_xlParser.PersistentExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_persistentExpression)
        try:
            self.state = 119
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 117
                self.persistentAssignmentExpression()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 118
                self.expressionWithoutAssignment()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionWithoutAssignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_expressionWithoutAssignment


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ExprWithoutPartialSelectionContext(ExpressionWithoutAssignmentContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionWithoutAssignmentContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprWithoutPartialSelection" ):
                listener.enterExprWithoutPartialSelection(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprWithoutPartialSelection" ):
                listener.exitExprWithoutPartialSelection(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExprWithoutPartialSelection" ):
                return visitor.visitExprWithoutPartialSelection(self)
            else:
                return visitor.visitChildren(self)


    class ExprWithSelectionContext(ExpressionWithoutAssignmentContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionWithoutAssignmentContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def WITH(self):
            return self.getToken(dpm_xlParser.WITH, 0)
        def partialSelection(self):
            return self.getTypedRuleContext(dpm_xlParser.PartialSelectionContext,0)

        def COLON(self):
            return self.getToken(dpm_xlParser.COLON, 0)
        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprWithSelection" ):
                listener.enterExprWithSelection(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprWithSelection" ):
                listener.exitExprWithSelection(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExprWithSelection" ):
                return visitor.visitExprWithSelection(self)
            else:
                return visitor.visitChildren(self)



    def expressionWithoutAssignment(self):

        localctx = dpm_xlParser.ExpressionWithoutAssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_expressionWithoutAssignment)
        try:
            self.state = 127
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 5, 14, 16, 17, 20, 21, 22, 23, 24, 25, 27, 28, 29, 30, 31, 32, 33, 34, 35, 39, 41, 43, 45, 49, 50, 55, 56, 60, 61, 62, 64, 65, 66, 67, 68, 88, 89, 90, 92]:
                localctx = dpm_xlParser.ExprWithoutPartialSelectionContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 121
                self.expression(0)
                pass
            elif token in [15]:
                localctx = dpm_xlParser.ExprWithSelectionContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 122
                self.match(dpm_xlParser.WITH)
                self.state = 123
                self.partialSelection()
                self.state = 124
                self.match(dpm_xlParser.COLON)
                self.state = 125
                self.expression(0)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PartialSelectionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_partialSelection


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class PartialSelectContext(PartialSelectionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.PartialSelectionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CURLY_BRACKET_LEFT(self):
            return self.getToken(dpm_xlParser.CURLY_BRACKET_LEFT, 0)
        def cellRef(self):
            return self.getTypedRuleContext(dpm_xlParser.CellRefContext,0)

        def CURLY_BRACKET_RIGHT(self):
            return self.getToken(dpm_xlParser.CURLY_BRACKET_RIGHT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPartialSelect" ):
                listener.enterPartialSelect(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPartialSelect" ):
                listener.exitPartialSelect(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPartialSelect" ):
                return visitor.visitPartialSelect(self)
            else:
                return visitor.visitChildren(self)



    def partialSelection(self):

        localctx = dpm_xlParser.PartialSelectionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_partialSelection)
        try:
            localctx = dpm_xlParser.PartialSelectContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 129
            self.match(dpm_xlParser.CURLY_BRACKET_LEFT)
            self.state = 130
            self.cellRef()
            self.state = 131
            self.match(dpm_xlParser.CURLY_BRACKET_RIGHT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TemporaryAssignmentExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def temporaryIdentifier(self):
            return self.getTypedRuleContext(dpm_xlParser.TemporaryIdentifierContext,0)


        def ASSIGN(self):
            return self.getToken(dpm_xlParser.ASSIGN, 0)

        def persistentExpression(self):
            return self.getTypedRuleContext(dpm_xlParser.PersistentExpressionContext,0)


        def getRuleIndex(self):
            return dpm_xlParser.RULE_temporaryAssignmentExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTemporaryAssignmentExpression" ):
                listener.enterTemporaryAssignmentExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTemporaryAssignmentExpression" ):
                listener.exitTemporaryAssignmentExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTemporaryAssignmentExpression" ):
                return visitor.visitTemporaryAssignmentExpression(self)
            else:
                return visitor.visitChildren(self)




    def temporaryAssignmentExpression(self):

        localctx = dpm_xlParser.TemporaryAssignmentExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_temporaryAssignmentExpression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 133
            self.temporaryIdentifier()
            self.state = 134
            self.match(dpm_xlParser.ASSIGN)
            self.state = 135
            self.persistentExpression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PersistentAssignmentExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def varID(self):
            return self.getTypedRuleContext(dpm_xlParser.VarIDContext,0)


        def PERSISTENT_ASSIGN(self):
            return self.getToken(dpm_xlParser.PERSISTENT_ASSIGN, 0)

        def expressionWithoutAssignment(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionWithoutAssignmentContext,0)


        def getRuleIndex(self):
            return dpm_xlParser.RULE_persistentAssignmentExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPersistentAssignmentExpression" ):
                listener.enterPersistentAssignmentExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPersistentAssignmentExpression" ):
                listener.exitPersistentAssignmentExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPersistentAssignmentExpression" ):
                return visitor.visitPersistentAssignmentExpression(self)
            else:
                return visitor.visitChildren(self)




    def persistentAssignmentExpression(self):

        localctx = dpm_xlParser.PersistentAssignmentExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_persistentAssignmentExpression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 137
            self.varID()
            self.state = 138
            self.match(dpm_xlParser.PERSISTENT_ASSIGN)
            self.state = 139
            self.expressionWithoutAssignment()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_expression


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class FuncExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def functions(self):
            return self.getTypedRuleContext(dpm_xlParser.FunctionsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncExpr" ):
                listener.enterFuncExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncExpr" ):
                listener.exitFuncExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncExpr" ):
                return visitor.visitFuncExpr(self)
            else:
                return visitor.visitChildren(self)


    class ItemReferenceExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def itemReference(self):
            return self.getTypedRuleContext(dpm_xlParser.ItemReferenceContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterItemReferenceExpr" ):
                listener.enterItemReferenceExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitItemReferenceExpr" ):
                listener.exitItemReferenceExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitItemReferenceExpr" ):
                return visitor.visitItemReferenceExpr(self)
            else:
                return visitor.visitChildren(self)


    class PropertyReferenceExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def propertyReference(self):
            return self.getTypedRuleContext(dpm_xlParser.PropertyReferenceContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPropertyReferenceExpr" ):
                listener.enterPropertyReferenceExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPropertyReferenceExpr" ):
                listener.exitPropertyReferenceExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropertyReferenceExpr" ):
                return visitor.visitPropertyReferenceExpr(self)
            else:
                return visitor.visitChildren(self)


    class InExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.left = None # ExpressionContext
            self.op = None # Token
            self.copyFrom(ctx)

        def setOperand(self):
            return self.getTypedRuleContext(dpm_xlParser.SetOperandContext,0)

        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)

        def IN(self):
            return self.getToken(dpm_xlParser.IN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInExpr" ):
                listener.enterInExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInExpr" ):
                listener.exitInExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInExpr" ):
                return visitor.visitInExpr(self)
            else:
                return visitor.visitChildren(self)


    class KeyNamesExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def keyNames(self):
            return self.getTypedRuleContext(dpm_xlParser.KeyNamesContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKeyNamesExpr" ):
                listener.enterKeyNamesExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKeyNamesExpr" ):
                listener.exitKeyNamesExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitKeyNamesExpr" ):
                return visitor.visitKeyNamesExpr(self)
            else:
                return visitor.visitChildren(self)


    class ConcatExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.left = None # ExpressionContext
            self.op = None # Token
            self.right = None # ExpressionContext
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,i)

        def CONCAT(self):
            return self.getToken(dpm_xlParser.CONCAT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConcatExpr" ):
                listener.enterConcatExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConcatExpr" ):
                listener.exitConcatExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConcatExpr" ):
                return visitor.visitConcatExpr(self)
            else:
                return visitor.visitChildren(self)


    class ParExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)
        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)

        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParExpr" ):
                listener.enterParExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParExpr" ):
                listener.exitParExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParExpr" ):
                return visitor.visitParExpr(self)
            else:
                return visitor.visitChildren(self)


    class UnaryExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)

        def PLUS(self):
            return self.getToken(dpm_xlParser.PLUS, 0)
        def MINUS(self):
            return self.getToken(dpm_xlParser.MINUS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnaryExpr" ):
                listener.enterUnaryExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnaryExpr" ):
                listener.exitUnaryExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryExpr" ):
                return visitor.visitUnaryExpr(self)
            else:
                return visitor.visitChildren(self)


    class NotExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)
        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)

        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)
        def NOT(self):
            return self.getToken(dpm_xlParser.NOT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNotExpr" ):
                listener.enterNotExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNotExpr" ):
                listener.exitNotExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNotExpr" ):
                return visitor.visitNotExpr(self)
            else:
                return visitor.visitChildren(self)


    class SelectExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def select(self):
            return self.getTypedRuleContext(dpm_xlParser.SelectContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSelectExpr" ):
                listener.enterSelectExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSelectExpr" ):
                listener.exitSelectExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSelectExpr" ):
                return visitor.visitSelectExpr(self)
            else:
                return visitor.visitChildren(self)


    class NumericExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.left = None # ExpressionContext
            self.op = None # Token
            self.right = None # ExpressionContext
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,i)

        def MULT(self):
            return self.getToken(dpm_xlParser.MULT, 0)
        def DIV(self):
            return self.getToken(dpm_xlParser.DIV, 0)
        def PLUS(self):
            return self.getToken(dpm_xlParser.PLUS, 0)
        def MINUS(self):
            return self.getToken(dpm_xlParser.MINUS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumericExpr" ):
                listener.enterNumericExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumericExpr" ):
                listener.exitNumericExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumericExpr" ):
                return visitor.visitNumericExpr(self)
            else:
                return visitor.visitChildren(self)


    class LiteralExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def literal(self):
            return self.getTypedRuleContext(dpm_xlParser.LiteralContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralExpr" ):
                listener.enterLiteralExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralExpr" ):
                listener.exitLiteralExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLiteralExpr" ):
                return visitor.visitLiteralExpr(self)
            else:
                return visitor.visitChildren(self)


    class CompExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.left = None # ExpressionContext
            self.op = None # ComparisonOperatorsContext
            self.right = None # ExpressionContext
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,i)

        def comparisonOperators(self):
            return self.getTypedRuleContext(dpm_xlParser.ComparisonOperatorsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCompExpr" ):
                listener.enterCompExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCompExpr" ):
                listener.exitCompExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCompExpr" ):
                return visitor.visitCompExpr(self)
            else:
                return visitor.visitChildren(self)


    class IfExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.conditionalExpr = None # ExpressionContext
            self.thenExpr = None # ExpressionContext
            self.elseExpr = None # ExpressionContext
            self.copyFrom(ctx)

        def IF(self):
            return self.getToken(dpm_xlParser.IF, 0)
        def THEN(self):
            return self.getToken(dpm_xlParser.THEN, 0)
        def ENDIF(self):
            return self.getToken(dpm_xlParser.ENDIF, 0)
        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,i)

        def ELSE(self):
            return self.getToken(dpm_xlParser.ELSE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfExpr" ):
                listener.enterIfExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfExpr" ):
                listener.exitIfExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfExpr" ):
                return visitor.visitIfExpr(self)
            else:
                return visitor.visitChildren(self)


    class ClauseExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)

        def SQUARE_BRACKET_LEFT(self):
            return self.getToken(dpm_xlParser.SQUARE_BRACKET_LEFT, 0)
        def clauseOperators(self):
            return self.getTypedRuleContext(dpm_xlParser.ClauseOperatorsContext,0)

        def SQUARE_BRACKET_RIGHT(self):
            return self.getToken(dpm_xlParser.SQUARE_BRACKET_RIGHT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClauseExpr" ):
                listener.enterClauseExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClauseExpr" ):
                listener.exitClauseExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitClauseExpr" ):
                return visitor.visitClauseExpr(self)
            else:
                return visitor.visitChildren(self)


    class BoolExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ExpressionContext
            super().__init__(parser)
            self.left = None # ExpressionContext
            self.op = None # Token
            self.right = None # ExpressionContext
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,i)

        def AND(self):
            return self.getToken(dpm_xlParser.AND, 0)
        def OR(self):
            return self.getToken(dpm_xlParser.OR, 0)
        def XOR(self):
            return self.getToken(dpm_xlParser.XOR, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBoolExpr" ):
                listener.enterBoolExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBoolExpr" ):
                listener.exitBoolExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBoolExpr" ):
                return visitor.visitBoolExpr(self)
            else:
                return visitor.visitChildren(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = dpm_xlParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 16
        self.enterRecursionRule(localctx, 16, self.RULE_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 169
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                localctx = dpm_xlParser.ParExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 142
                self.match(dpm_xlParser.LPAREN)
                self.state = 143
                self.expression(0)
                self.state = 144
                self.match(dpm_xlParser.RPAREN)
                pass

            elif la_ == 2:
                localctx = dpm_xlParser.FuncExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 146
                self.functions()
                pass

            elif la_ == 3:
                localctx = dpm_xlParser.UnaryExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 147
                localctx.op = self._input.LT(1)
                _la = self._input.LA(1)
                if not(_la==16 or _la==17):
                    localctx.op = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 148
                self.expression(15)
                pass

            elif la_ == 4:
                localctx = dpm_xlParser.NotExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 149
                localctx.op = self.match(dpm_xlParser.NOT)
                self.state = 150
                self.match(dpm_xlParser.LPAREN)
                self.state = 151
                self.expression(0)
                self.state = 152
                self.match(dpm_xlParser.RPAREN)
                pass

            elif la_ == 5:
                localctx = dpm_xlParser.IfExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 154
                self.match(dpm_xlParser.IF)
                self.state = 155
                localctx.conditionalExpr = self.expression(0)
                self.state = 156
                self.match(dpm_xlParser.THEN)
                self.state = 157
                localctx.thenExpr = self.expression(0)
                self.state = 160
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==48:
                    self.state = 158
                    self.match(dpm_xlParser.ELSE)
                    self.state = 159
                    localctx.elseExpr = self.expression(0)


                self.state = 162
                self.match(dpm_xlParser.ENDIF)
                pass

            elif la_ == 6:
                localctx = dpm_xlParser.ItemReferenceExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 164
                self.itemReference()
                pass

            elif la_ == 7:
                localctx = dpm_xlParser.PropertyReferenceExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 165
                self.propertyReference()
                pass

            elif la_ == 8:
                localctx = dpm_xlParser.KeyNamesExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 166
                self.keyNames()
                pass

            elif la_ == 9:
                localctx = dpm_xlParser.LiteralExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 167
                self.literal()
                pass

            elif la_ == 10:
                localctx = dpm_xlParser.SelectExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 168
                self.select()
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 200
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,9,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 198
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
                    if la_ == 1:
                        localctx = dpm_xlParser.NumericExprContext(self, dpm_xlParser.ExpressionContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 171
                        if not self.precpred(self._ctx, 13):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 13)")
                        self.state = 172
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==18 or _la==19):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 173
                        localctx.right = self.expression(14)
                        pass

                    elif la_ == 2:
                        localctx = dpm_xlParser.NumericExprContext(self, dpm_xlParser.ExpressionContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 174
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 12)")
                        self.state = 175
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==16 or _la==17):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 176
                        localctx.right = self.expression(13)
                        pass

                    elif la_ == 3:
                        localctx = dpm_xlParser.ConcatExprContext(self, dpm_xlParser.ExpressionContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 177
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 178
                        localctx.op = self.match(dpm_xlParser.CONCAT)
                        self.state = 179
                        localctx.right = self.expression(12)
                        pass

                    elif la_ == 4:
                        localctx = dpm_xlParser.CompExprContext(self, dpm_xlParser.ExpressionContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 180
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 181
                        localctx.op = self.comparisonOperators()
                        self.state = 182
                        localctx.right = self.expression(11)
                        pass

                    elif la_ == 5:
                        localctx = dpm_xlParser.BoolExprContext(self, dpm_xlParser.ExpressionContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 184
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 185
                        localctx.op = self.match(dpm_xlParser.AND)
                        self.state = 186
                        localctx.right = self.expression(9)
                        pass

                    elif la_ == 6:
                        localctx = dpm_xlParser.BoolExprContext(self, dpm_xlParser.ExpressionContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 187
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 188
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==3 or _la==4):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 189
                        localctx.right = self.expression(8)
                        pass

                    elif la_ == 7:
                        localctx = dpm_xlParser.ClauseExprContext(self, dpm_xlParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 190
                        if not self.precpred(self._ctx, 16):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 16)")
                        self.state = 191
                        self.match(dpm_xlParser.SQUARE_BRACKET_LEFT)
                        self.state = 192
                        self.clauseOperators()
                        self.state = 193
                        self.match(dpm_xlParser.SQUARE_BRACKET_RIGHT)
                        pass

                    elif la_ == 8:
                        localctx = dpm_xlParser.InExprContext(self, dpm_xlParser.ExpressionContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 195
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 196
                        localctx.op = self.match(dpm_xlParser.IN)
                        self.state = 197
                        self.setOperand()
                        pass


                self.state = 202
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,9,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class SetOperandContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CURLY_BRACKET_LEFT(self):
            return self.getToken(dpm_xlParser.CURLY_BRACKET_LEFT, 0)

        def setElements(self):
            return self.getTypedRuleContext(dpm_xlParser.SetElementsContext,0)


        def CURLY_BRACKET_RIGHT(self):
            return self.getToken(dpm_xlParser.CURLY_BRACKET_RIGHT, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_setOperand

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSetOperand" ):
                listener.enterSetOperand(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSetOperand" ):
                listener.exitSetOperand(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSetOperand" ):
                return visitor.visitSetOperand(self)
            else:
                return visitor.visitChildren(self)




    def setOperand(self):

        localctx = dpm_xlParser.SetOperandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_setOperand)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 203
            self.match(dpm_xlParser.CURLY_BRACKET_LEFT)
            self.state = 204
            self.setElements()
            self.state = 205
            self.match(dpm_xlParser.CURLY_BRACKET_RIGHT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SetElementsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def itemReference(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.ItemReferenceContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.ItemReferenceContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.COMMA)
            else:
                return self.getToken(dpm_xlParser.COMMA, i)

        def literal(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.LiteralContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.LiteralContext,i)


        def getRuleIndex(self):
            return dpm_xlParser.RULE_setElements

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSetElements" ):
                listener.enterSetElements(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSetElements" ):
                listener.exitSetElements(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSetElements" ):
                return visitor.visitSetElements(self)
            else:
                return visitor.visitChildren(self)




    def setElements(self):

        localctx = dpm_xlParser.SetElementsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_setElements)
        self._la = 0 # Token type
        try:
            self.state = 223
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [43]:
                self.enterOuterAlt(localctx, 1)
                self.state = 207
                self.itemReference()
                self.state = 212
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==37:
                    self.state = 208
                    self.match(dpm_xlParser.COMMA)
                    self.state = 209
                    self.itemReference()
                    self.state = 214
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            elif token in [1, 60, 61, 62, 64, 65, 66, 67, 68]:
                self.enterOuterAlt(localctx, 2)
                self.state = 215
                self.literal()
                self.state = 220
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==37:
                    self.state = 216
                    self.match(dpm_xlParser.COMMA)
                    self.state = 217
                    self.literal()
                    self.state = 222
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_functions


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class StringFunctionsContext(FunctionsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.FunctionsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def stringOperators(self):
            return self.getTypedRuleContext(dpm_xlParser.StringOperatorsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringFunctions" ):
                listener.enterStringFunctions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringFunctions" ):
                listener.exitStringFunctions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStringFunctions" ):
                return visitor.visitStringFunctions(self)
            else:
                return visitor.visitChildren(self)


    class AggregateFunctionsContext(FunctionsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.FunctionsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def aggregateOperators(self):
            return self.getTypedRuleContext(dpm_xlParser.AggregateOperatorsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAggregateFunctions" ):
                listener.enterAggregateFunctions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAggregateFunctions" ):
                listener.exitAggregateFunctions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAggregateFunctions" ):
                return visitor.visitAggregateFunctions(self)
            else:
                return visitor.visitChildren(self)


    class ConditionalFunctionsContext(FunctionsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.FunctionsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def conditionalOperators(self):
            return self.getTypedRuleContext(dpm_xlParser.ConditionalOperatorsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConditionalFunctions" ):
                listener.enterConditionalFunctions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConditionalFunctions" ):
                listener.exitConditionalFunctions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConditionalFunctions" ):
                return visitor.visitConditionalFunctions(self)
            else:
                return visitor.visitChildren(self)


    class ComparisonFunctionsContext(FunctionsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.FunctionsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def comparisonFunctionOperators(self):
            return self.getTypedRuleContext(dpm_xlParser.ComparisonFunctionOperatorsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparisonFunctions" ):
                listener.enterComparisonFunctions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparisonFunctions" ):
                listener.exitComparisonFunctions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparisonFunctions" ):
                return visitor.visitComparisonFunctions(self)
            else:
                return visitor.visitChildren(self)


    class NumericFunctionsContext(FunctionsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.FunctionsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def numericOperators(self):
            return self.getTypedRuleContext(dpm_xlParser.NumericOperatorsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumericFunctions" ):
                listener.enterNumericFunctions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumericFunctions" ):
                listener.exitNumericFunctions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumericFunctions" ):
                return visitor.visitNumericFunctions(self)
            else:
                return visitor.visitChildren(self)


    class TimeFunctionsContext(FunctionsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.FunctionsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def timeOperators(self):
            return self.getTypedRuleContext(dpm_xlParser.TimeOperatorsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTimeFunctions" ):
                listener.enterTimeFunctions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTimeFunctions" ):
                listener.exitTimeFunctions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTimeFunctions" ):
                return visitor.visitTimeFunctions(self)
            else:
                return visitor.visitChildren(self)


    class FilterFunctionsContext(FunctionsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.FunctionsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def filterOperators(self):
            return self.getTypedRuleContext(dpm_xlParser.FilterOperatorsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFilterFunctions" ):
                listener.enterFilterFunctions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFilterFunctions" ):
                listener.exitFilterFunctions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFilterFunctions" ):
                return visitor.visitFilterFunctions(self)
            else:
                return visitor.visitChildren(self)



    def functions(self):

        localctx = dpm_xlParser.FunctionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_functions)
        try:
            self.state = 232
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [20, 21, 22, 23, 24, 25]:
                localctx = dpm_xlParser.AggregateFunctionsContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 225
                self.aggregateOperators()
                pass
            elif token in [27, 29, 30, 31, 32, 33, 34, 35]:
                localctx = dpm_xlParser.NumericFunctionsContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 226
                self.numericOperators()
                pass
            elif token in [14, 28]:
                localctx = dpm_xlParser.ComparisonFunctionsContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 227
                self.comparisonFunctionOperators()
                pass
            elif token in [50]:
                localctx = dpm_xlParser.FilterFunctionsContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 228
                self.filterOperators()
                pass
            elif token in [49]:
                localctx = dpm_xlParser.ConditionalFunctionsContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 229
                self.conditionalOperators()
                pass
            elif token in [55]:
                localctx = dpm_xlParser.TimeFunctionsContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 230
                self.timeOperators()
                pass
            elif token in [56]:
                localctx = dpm_xlParser.StringFunctionsContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 231
                self.stringOperators()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumericOperatorsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_numericOperators


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class UnaryNumericFunctionsContext(NumericOperatorsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.NumericOperatorsContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)
        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)

        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)
        def ABS(self):
            return self.getToken(dpm_xlParser.ABS, 0)
        def EXP(self):
            return self.getToken(dpm_xlParser.EXP, 0)
        def LN(self):
            return self.getToken(dpm_xlParser.LN, 0)
        def SQRT(self):
            return self.getToken(dpm_xlParser.SQRT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnaryNumericFunctions" ):
                listener.enterUnaryNumericFunctions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnaryNumericFunctions" ):
                listener.exitUnaryNumericFunctions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryNumericFunctions" ):
                return visitor.visitUnaryNumericFunctions(self)
            else:
                return visitor.visitChildren(self)


    class ComplexNumericFunctionsContext(NumericOperatorsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.NumericOperatorsContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)
        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,i)

        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)
        def MAX(self):
            return self.getToken(dpm_xlParser.MAX, 0)
        def MIN(self):
            return self.getToken(dpm_xlParser.MIN, 0)
        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.COMMA)
            else:
                return self.getToken(dpm_xlParser.COMMA, i)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComplexNumericFunctions" ):
                listener.enterComplexNumericFunctions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComplexNumericFunctions" ):
                listener.exitComplexNumericFunctions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComplexNumericFunctions" ):
                return visitor.visitComplexNumericFunctions(self)
            else:
                return visitor.visitChildren(self)


    class BinaryNumericFunctionsContext(NumericOperatorsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.NumericOperatorsContext
            super().__init__(parser)
            self.op = None # Token
            self.left = None # ExpressionContext
            self.right = None # ExpressionContext
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)
        def COMMA(self):
            return self.getToken(dpm_xlParser.COMMA, 0)
        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)
        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,i)

        def POWER(self):
            return self.getToken(dpm_xlParser.POWER, 0)
        def LOG(self):
            return self.getToken(dpm_xlParser.LOG, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBinaryNumericFunctions" ):
                listener.enterBinaryNumericFunctions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBinaryNumericFunctions" ):
                listener.exitBinaryNumericFunctions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBinaryNumericFunctions" ):
                return visitor.visitBinaryNumericFunctions(self)
            else:
                return visitor.visitChildren(self)



    def numericOperators(self):

        localctx = dpm_xlParser.NumericOperatorsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_numericOperators)
        self._la = 0 # Token type
        try:
            self.state = 257
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [27, 29, 30, 31]:
                localctx = dpm_xlParser.UnaryNumericFunctionsContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 234
                localctx.op = self._input.LT(1)
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 3892314112) != 0)):
                    localctx.op = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 235
                self.match(dpm_xlParser.LPAREN)
                self.state = 236
                self.expression(0)
                self.state = 237
                self.match(dpm_xlParser.RPAREN)
                pass
            elif token in [32, 33]:
                localctx = dpm_xlParser.BinaryNumericFunctionsContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 239
                localctx.op = self._input.LT(1)
                _la = self._input.LA(1)
                if not(_la==32 or _la==33):
                    localctx.op = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 240
                self.match(dpm_xlParser.LPAREN)
                self.state = 241
                localctx.left = self.expression(0)
                self.state = 242
                self.match(dpm_xlParser.COMMA)
                self.state = 243
                localctx.right = self.expression(0)
                self.state = 244
                self.match(dpm_xlParser.RPAREN)
                pass
            elif token in [34, 35]:
                localctx = dpm_xlParser.ComplexNumericFunctionsContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 246
                localctx.op = self._input.LT(1)
                _la = self._input.LA(1)
                if not(_la==34 or _la==35):
                    localctx.op = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 247
                self.match(dpm_xlParser.LPAREN)
                self.state = 248
                self.expression(0)
                self.state = 251
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 249
                    self.match(dpm_xlParser.COMMA)
                    self.state = 250
                    self.expression(0)
                    self.state = 253
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not (_la==37):
                        break

                self.state = 255
                self.match(dpm_xlParser.RPAREN)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparisonFunctionOperatorsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_comparisonFunctionOperators


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class IsnullExprContext(ComparisonFunctionOperatorsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ComparisonFunctionOperatorsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ISNULL(self):
            return self.getToken(dpm_xlParser.ISNULL, 0)
        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)
        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)

        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIsnullExpr" ):
                listener.enterIsnullExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIsnullExpr" ):
                listener.exitIsnullExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIsnullExpr" ):
                return visitor.visitIsnullExpr(self)
            else:
                return visitor.visitChildren(self)


    class MatchExprContext(ComparisonFunctionOperatorsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ComparisonFunctionOperatorsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def MATCH(self):
            return self.getToken(dpm_xlParser.MATCH, 0)
        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)
        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)

        def COMMA(self):
            return self.getToken(dpm_xlParser.COMMA, 0)
        def literal(self):
            return self.getTypedRuleContext(dpm_xlParser.LiteralContext,0)

        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMatchExpr" ):
                listener.enterMatchExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMatchExpr" ):
                listener.exitMatchExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMatchExpr" ):
                return visitor.visitMatchExpr(self)
            else:
                return visitor.visitChildren(self)



    def comparisonFunctionOperators(self):

        localctx = dpm_xlParser.ComparisonFunctionOperatorsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_comparisonFunctionOperators)
        try:
            self.state = 271
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [14]:
                localctx = dpm_xlParser.MatchExprContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 259
                self.match(dpm_xlParser.MATCH)
                self.state = 260
                self.match(dpm_xlParser.LPAREN)
                self.state = 261
                self.expression(0)
                self.state = 262
                self.match(dpm_xlParser.COMMA)
                self.state = 263
                self.literal()
                self.state = 264
                self.match(dpm_xlParser.RPAREN)
                pass
            elif token in [28]:
                localctx = dpm_xlParser.IsnullExprContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 266
                self.match(dpm_xlParser.ISNULL)
                self.state = 267
                self.match(dpm_xlParser.LPAREN)
                self.state = 268
                self.expression(0)
                self.state = 269
                self.match(dpm_xlParser.RPAREN)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FilterOperatorsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FILTER(self):
            return self.getToken(dpm_xlParser.FILTER, 0)

        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,i)


        def COMMA(self):
            return self.getToken(dpm_xlParser.COMMA, 0)

        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_filterOperators

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFilterOperators" ):
                listener.enterFilterOperators(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFilterOperators" ):
                listener.exitFilterOperators(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFilterOperators" ):
                return visitor.visitFilterOperators(self)
            else:
                return visitor.visitChildren(self)




    def filterOperators(self):

        localctx = dpm_xlParser.FilterOperatorsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_filterOperators)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 273
            self.match(dpm_xlParser.FILTER)
            self.state = 274
            self.match(dpm_xlParser.LPAREN)
            self.state = 275
            self.expression(0)
            self.state = 276
            self.match(dpm_xlParser.COMMA)
            self.state = 277
            self.expression(0)
            self.state = 278
            self.match(dpm_xlParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TimeOperatorsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_timeOperators


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class TimeShiftFunctionContext(TimeOperatorsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.TimeOperatorsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def TIME_SHIFT(self):
            return self.getToken(dpm_xlParser.TIME_SHIFT, 0)
        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)
        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.COMMA)
            else:
                return self.getToken(dpm_xlParser.COMMA, i)
        def TIME_PERIOD(self):
            return self.getToken(dpm_xlParser.TIME_PERIOD, 0)
        def INTEGER_LITERAL(self):
            return self.getToken(dpm_xlParser.INTEGER_LITERAL, 0)
        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)
        def propertyCode(self):
            return self.getTypedRuleContext(dpm_xlParser.PropertyCodeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTimeShiftFunction" ):
                listener.enterTimeShiftFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTimeShiftFunction" ):
                listener.exitTimeShiftFunction(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTimeShiftFunction" ):
                return visitor.visitTimeShiftFunction(self)
            else:
                return visitor.visitChildren(self)



    def timeOperators(self):

        localctx = dpm_xlParser.TimeOperatorsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_timeOperators)
        self._la = 0 # Token type
        try:
            localctx = dpm_xlParser.TimeShiftFunctionContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 280
            self.match(dpm_xlParser.TIME_SHIFT)
            self.state = 281
            self.match(dpm_xlParser.LPAREN)
            self.state = 282
            self.expression(0)
            self.state = 283
            self.match(dpm_xlParser.COMMA)
            self.state = 284
            self.match(dpm_xlParser.TIME_PERIOD)
            self.state = 285
            self.match(dpm_xlParser.COMMA)
            self.state = 286
            self.match(dpm_xlParser.INTEGER_LITERAL)
            self.state = 289
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==37:
                self.state = 287
                self.match(dpm_xlParser.COMMA)
                self.state = 288
                self.propertyCode()


            self.state = 291
            self.match(dpm_xlParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConditionalOperatorsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_conditionalOperators


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class NvlFunctionContext(ConditionalOperatorsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ConditionalOperatorsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NVL(self):
            return self.getToken(dpm_xlParser.NVL, 0)
        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)
        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,i)

        def COMMA(self):
            return self.getToken(dpm_xlParser.COMMA, 0)
        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNvlFunction" ):
                listener.enterNvlFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNvlFunction" ):
                listener.exitNvlFunction(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNvlFunction" ):
                return visitor.visitNvlFunction(self)
            else:
                return visitor.visitChildren(self)



    def conditionalOperators(self):

        localctx = dpm_xlParser.ConditionalOperatorsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_conditionalOperators)
        try:
            localctx = dpm_xlParser.NvlFunctionContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 293
            self.match(dpm_xlParser.NVL)
            self.state = 294
            self.match(dpm_xlParser.LPAREN)
            self.state = 295
            self.expression(0)
            self.state = 296
            self.match(dpm_xlParser.COMMA)
            self.state = 297
            self.expression(0)
            self.state = 298
            self.match(dpm_xlParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringOperatorsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_stringOperators


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class UnaryStringFunctionContext(StringOperatorsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.StringOperatorsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LEN(self):
            return self.getToken(dpm_xlParser.LEN, 0)
        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)
        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)

        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnaryStringFunction" ):
                listener.enterUnaryStringFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnaryStringFunction" ):
                listener.exitUnaryStringFunction(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryStringFunction" ):
                return visitor.visitUnaryStringFunction(self)
            else:
                return visitor.visitChildren(self)



    def stringOperators(self):

        localctx = dpm_xlParser.StringOperatorsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_stringOperators)
        try:
            localctx = dpm_xlParser.UnaryStringFunctionContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 300
            self.match(dpm_xlParser.LEN)
            self.state = 301
            self.match(dpm_xlParser.LPAREN)
            self.state = 302
            self.expression(0)
            self.state = 303
            self.match(dpm_xlParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AggregateOperatorsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_aggregateOperators


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class CommonAggrOpContext(AggregateOperatorsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.AggregateOperatorsContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)
        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)

        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)
        def MAX_AGGR(self):
            return self.getToken(dpm_xlParser.MAX_AGGR, 0)
        def MIN_AGGR(self):
            return self.getToken(dpm_xlParser.MIN_AGGR, 0)
        def SUM(self):
            return self.getToken(dpm_xlParser.SUM, 0)
        def COUNT(self):
            return self.getToken(dpm_xlParser.COUNT, 0)
        def AVG(self):
            return self.getToken(dpm_xlParser.AVG, 0)
        def MEDIAN(self):
            return self.getToken(dpm_xlParser.MEDIAN, 0)
        def groupingClause(self):
            return self.getTypedRuleContext(dpm_xlParser.GroupingClauseContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCommonAggrOp" ):
                listener.enterCommonAggrOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCommonAggrOp" ):
                listener.exitCommonAggrOp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCommonAggrOp" ):
                return visitor.visitCommonAggrOp(self)
            else:
                return visitor.visitChildren(self)



    def aggregateOperators(self):

        localctx = dpm_xlParser.AggregateOperatorsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_aggregateOperators)
        self._la = 0 # Token type
        try:
            localctx = dpm_xlParser.CommonAggrOpContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 305
            localctx.op = self._input.LT(1)
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 66060288) != 0)):
                localctx.op = self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 306
            self.match(dpm_xlParser.LPAREN)
            self.state = 307
            self.expression(0)
            self.state = 309
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==26:
                self.state = 308
                self.groupingClause()


            self.state = 311
            self.match(dpm_xlParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GroupingClauseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GROUP_BY(self):
            return self.getToken(dpm_xlParser.GROUP_BY, 0)

        def keyNames(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.KeyNamesContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.KeyNamesContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.COMMA)
            else:
                return self.getToken(dpm_xlParser.COMMA, i)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_groupingClause

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGroupingClause" ):
                listener.enterGroupingClause(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGroupingClause" ):
                listener.exitGroupingClause(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGroupingClause" ):
                return visitor.visitGroupingClause(self)
            else:
                return visitor.visitChildren(self)




    def groupingClause(self):

        localctx = dpm_xlParser.GroupingClauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_groupingClause)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 313
            self.match(dpm_xlParser.GROUP_BY)
            self.state = 314
            self.keyNames()
            self.state = 319
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==37:
                self.state = 315
                self.match(dpm_xlParser.COMMA)
                self.state = 316
                self.keyNames()
                self.state = 321
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ItemSignatureContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ITEM_SIGNATURE(self):
            return self.getToken(dpm_xlParser.ITEM_SIGNATURE, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_itemSignature

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterItemSignature" ):
                listener.enterItemSignature(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitItemSignature" ):
                listener.exitItemSignature(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitItemSignature" ):
                return visitor.visitItemSignature(self)
            else:
                return visitor.visitChildren(self)




    def itemSignature(self):

        localctx = dpm_xlParser.ItemSignatureContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_itemSignature)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 322
            self.match(dpm_xlParser.ITEM_SIGNATURE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ItemReferenceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SQUARE_BRACKET_LEFT(self):
            return self.getToken(dpm_xlParser.SQUARE_BRACKET_LEFT, 0)

        def itemSignature(self):
            return self.getTypedRuleContext(dpm_xlParser.ItemSignatureContext,0)


        def SQUARE_BRACKET_RIGHT(self):
            return self.getToken(dpm_xlParser.SQUARE_BRACKET_RIGHT, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_itemReference

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterItemReference" ):
                listener.enterItemReference(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitItemReference" ):
                listener.exitItemReference(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitItemReference" ):
                return visitor.visitItemReference(self)
            else:
                return visitor.visitChildren(self)




    def itemReference(self):

        localctx = dpm_xlParser.ItemReferenceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_itemReference)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 324
            self.match(dpm_xlParser.SQUARE_BRACKET_LEFT)
            self.state = 325
            self.itemSignature()
            self.state = 326
            self.match(dpm_xlParser.SQUARE_BRACKET_RIGHT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RowElemContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ROW(self):
            return self.getToken(dpm_xlParser.ROW, 0)

        def ROW_RANGE(self):
            return self.getToken(dpm_xlParser.ROW_RANGE, 0)

        def ROW_ALL(self):
            return self.getToken(dpm_xlParser.ROW_ALL, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_rowElem

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRowElem" ):
                listener.enterRowElem(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRowElem" ):
                listener.exitRowElem(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRowElem" ):
                return visitor.visitRowElem(self)
            else:
                return visitor.visitChildren(self)




    def rowElem(self):

        localctx = dpm_xlParser.RowElemContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_rowElem)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 328
            _la = self._input.LA(1)
            if not(((((_la - 73)) & ~0x3f) == 0 and ((1 << (_la - 73)) & 7) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ColElemContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COL(self):
            return self.getToken(dpm_xlParser.COL, 0)

        def COL_RANGE(self):
            return self.getToken(dpm_xlParser.COL_RANGE, 0)

        def COL_ALL(self):
            return self.getToken(dpm_xlParser.COL_ALL, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_colElem

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterColElem" ):
                listener.enterColElem(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitColElem" ):
                listener.exitColElem(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitColElem" ):
                return visitor.visitColElem(self)
            else:
                return visitor.visitChildren(self)




    def colElem(self):

        localctx = dpm_xlParser.ColElemContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_colElem)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 330
            _la = self._input.LA(1)
            if not(((((_la - 76)) & ~0x3f) == 0 and ((1 << (_la - 76)) & 7) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SheetElemContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SHEET(self):
            return self.getToken(dpm_xlParser.SHEET, 0)

        def SHEET_RANGE(self):
            return self.getToken(dpm_xlParser.SHEET_RANGE, 0)

        def SHEET_ALL(self):
            return self.getToken(dpm_xlParser.SHEET_ALL, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_sheetElem

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSheetElem" ):
                listener.enterSheetElem(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSheetElem" ):
                listener.exitSheetElem(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSheetElem" ):
                return visitor.visitSheetElem(self)
            else:
                return visitor.visitChildren(self)




    def sheetElem(self):

        localctx = dpm_xlParser.SheetElemContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_sheetElem)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 332
            _la = self._input.LA(1)
            if not(((((_la - 79)) & ~0x3f) == 0 and ((1 << (_la - 79)) & 7) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RowHandlerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def rowElem(self):
            return self.getTypedRuleContext(dpm_xlParser.RowElemContext,0)


        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)

        def ROW(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.ROW)
            else:
                return self.getToken(dpm_xlParser.ROW, i)

        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.COMMA)
            else:
                return self.getToken(dpm_xlParser.COMMA, i)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_rowHandler

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRowHandler" ):
                listener.enterRowHandler(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRowHandler" ):
                listener.exitRowHandler(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRowHandler" ):
                return visitor.visitRowHandler(self)
            else:
                return visitor.visitChildren(self)




    def rowHandler(self):

        localctx = dpm_xlParser.RowHandlerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_rowHandler)
        self._la = 0 # Token type
        try:
            self.state = 345
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [73, 74, 75]:
                self.enterOuterAlt(localctx, 1)
                self.state = 334
                self.rowElem()
                pass
            elif token in [39]:
                self.enterOuterAlt(localctx, 2)
                self.state = 335
                self.match(dpm_xlParser.LPAREN)
                self.state = 336
                self.match(dpm_xlParser.ROW)
                self.state = 341
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==37:
                    self.state = 337
                    self.match(dpm_xlParser.COMMA)
                    self.state = 338
                    self.match(dpm_xlParser.ROW)
                    self.state = 343
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 344
                self.match(dpm_xlParser.RPAREN)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ColHandlerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def colElem(self):
            return self.getTypedRuleContext(dpm_xlParser.ColElemContext,0)


        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)

        def COL(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.COL)
            else:
                return self.getToken(dpm_xlParser.COL, i)

        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.COMMA)
            else:
                return self.getToken(dpm_xlParser.COMMA, i)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_colHandler

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterColHandler" ):
                listener.enterColHandler(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitColHandler" ):
                listener.exitColHandler(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitColHandler" ):
                return visitor.visitColHandler(self)
            else:
                return visitor.visitChildren(self)




    def colHandler(self):

        localctx = dpm_xlParser.ColHandlerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_colHandler)
        self._la = 0 # Token type
        try:
            self.state = 358
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [76, 77, 78]:
                self.enterOuterAlt(localctx, 1)
                self.state = 347
                self.colElem()
                pass
            elif token in [39]:
                self.enterOuterAlt(localctx, 2)
                self.state = 348
                self.match(dpm_xlParser.LPAREN)
                self.state = 349
                self.match(dpm_xlParser.COL)
                self.state = 354
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==37:
                    self.state = 350
                    self.match(dpm_xlParser.COMMA)
                    self.state = 351
                    self.match(dpm_xlParser.COL)
                    self.state = 356
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 357
                self.match(dpm_xlParser.RPAREN)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SheetHandlerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def sheetElem(self):
            return self.getTypedRuleContext(dpm_xlParser.SheetElemContext,0)


        def LPAREN(self):
            return self.getToken(dpm_xlParser.LPAREN, 0)

        def SHEET(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.SHEET)
            else:
                return self.getToken(dpm_xlParser.SHEET, i)

        def RPAREN(self):
            return self.getToken(dpm_xlParser.RPAREN, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.COMMA)
            else:
                return self.getToken(dpm_xlParser.COMMA, i)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_sheetHandler

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSheetHandler" ):
                listener.enterSheetHandler(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSheetHandler" ):
                listener.exitSheetHandler(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSheetHandler" ):
                return visitor.visitSheetHandler(self)
            else:
                return visitor.visitChildren(self)




    def sheetHandler(self):

        localctx = dpm_xlParser.SheetHandlerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_sheetHandler)
        self._la = 0 # Token type
        try:
            self.state = 371
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [79, 80, 81]:
                self.enterOuterAlt(localctx, 1)
                self.state = 360
                self.sheetElem()
                pass
            elif token in [39]:
                self.enterOuterAlt(localctx, 2)
                self.state = 361
                self.match(dpm_xlParser.LPAREN)
                self.state = 362
                self.match(dpm_xlParser.SHEET)
                self.state = 367
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==37:
                    self.state = 363
                    self.match(dpm_xlParser.COMMA)
                    self.state = 364
                    self.match(dpm_xlParser.SHEET)
                    self.state = 369
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 370
                self.match(dpm_xlParser.RPAREN)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntervalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTERVAL(self):
            return self.getToken(dpm_xlParser.INTERVAL, 0)

        def COLON(self):
            return self.getToken(dpm_xlParser.COLON, 0)

        def BOOLEAN_LITERAL(self):
            return self.getToken(dpm_xlParser.BOOLEAN_LITERAL, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_interval

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInterval" ):
                listener.enterInterval(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInterval" ):
                listener.exitInterval(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInterval" ):
                return visitor.visitInterval(self)
            else:
                return visitor.visitChildren(self)




    def interval(self):

        localctx = dpm_xlParser.IntervalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_interval)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 373
            self.match(dpm_xlParser.INTERVAL)
            self.state = 374
            self.match(dpm_xlParser.COLON)
            self.state = 375
            self.match(dpm_xlParser.BOOLEAN_LITERAL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DefaultContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DEFAULT(self):
            return self.getToken(dpm_xlParser.DEFAULT, 0)

        def COLON(self):
            return self.getToken(dpm_xlParser.COLON, 0)

        def literal(self):
            return self.getTypedRuleContext(dpm_xlParser.LiteralContext,0)


        def NULL_LITERAL(self):
            return self.getToken(dpm_xlParser.NULL_LITERAL, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_default

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefault" ):
                listener.enterDefault(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefault" ):
                listener.exitDefault(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDefault" ):
                return visitor.visitDefault(self)
            else:
                return visitor.visitChildren(self)




    def default(self):

        localctx = dpm_xlParser.DefaultContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_default)
        try:
            self.state = 383
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 377
                self.match(dpm_xlParser.DEFAULT)
                self.state = 378
                self.match(dpm_xlParser.COLON)
                self.state = 379
                self.literal()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 380
                self.match(dpm_xlParser.DEFAULT)
                self.state = 381
                self.match(dpm_xlParser.COLON)
                self.state = 382
                self.match(dpm_xlParser.NULL_LITERAL)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_argument


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class IntervalArgContext(ArgumentContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ArgumentContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def interval(self):
            return self.getTypedRuleContext(dpm_xlParser.IntervalContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntervalArg" ):
                listener.enterIntervalArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntervalArg" ):
                listener.exitIntervalArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntervalArg" ):
                return visitor.visitIntervalArg(self)
            else:
                return visitor.visitChildren(self)


    class RowArgContext(ArgumentContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ArgumentContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def rowHandler(self):
            return self.getTypedRuleContext(dpm_xlParser.RowHandlerContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRowArg" ):
                listener.enterRowArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRowArg" ):
                listener.exitRowArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRowArg" ):
                return visitor.visitRowArg(self)
            else:
                return visitor.visitChildren(self)


    class DefaultArgContext(ArgumentContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ArgumentContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def default(self):
            return self.getTypedRuleContext(dpm_xlParser.DefaultContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefaultArg" ):
                listener.enterDefaultArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefaultArg" ):
                listener.exitDefaultArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDefaultArg" ):
                return visitor.visitDefaultArg(self)
            else:
                return visitor.visitChildren(self)


    class ColArgContext(ArgumentContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ArgumentContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def colHandler(self):
            return self.getTypedRuleContext(dpm_xlParser.ColHandlerContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterColArg" ):
                listener.enterColArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitColArg" ):
                listener.exitColArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitColArg" ):
                return visitor.visitColArg(self)
            else:
                return visitor.visitChildren(self)


    class SheetArgContext(ArgumentContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ArgumentContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sheetHandler(self):
            return self.getTypedRuleContext(dpm_xlParser.SheetHandlerContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSheetArg" ):
                listener.enterSheetArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSheetArg" ):
                listener.exitSheetArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSheetArg" ):
                return visitor.visitSheetArg(self)
            else:
                return visitor.visitChildren(self)



    def argument(self):

        localctx = dpm_xlParser.ArgumentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_argument)
        try:
            self.state = 390
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,27,self._ctx)
            if la_ == 1:
                localctx = dpm_xlParser.RowArgContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 385
                self.rowHandler()
                pass

            elif la_ == 2:
                localctx = dpm_xlParser.ColArgContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 386
                self.colHandler()
                pass

            elif la_ == 3:
                localctx = dpm_xlParser.SheetArgContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 387
                self.sheetHandler()
                pass

            elif la_ == 4:
                localctx = dpm_xlParser.IntervalArgContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 388
                self.interval()
                pass

            elif la_ == 5:
                localctx = dpm_xlParser.DefaultArgContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 389
                self.default()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SelectContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CURLY_BRACKET_LEFT(self):
            return self.getToken(dpm_xlParser.CURLY_BRACKET_LEFT, 0)

        def selectOperand(self):
            return self.getTypedRuleContext(dpm_xlParser.SelectOperandContext,0)


        def CURLY_BRACKET_RIGHT(self):
            return self.getToken(dpm_xlParser.CURLY_BRACKET_RIGHT, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_select

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSelect" ):
                listener.enterSelect(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSelect" ):
                listener.exitSelect(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSelect" ):
                return visitor.visitSelect(self)
            else:
                return visitor.visitChildren(self)




    def select(self):

        localctx = dpm_xlParser.SelectContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_select)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 392
            self.match(dpm_xlParser.CURLY_BRACKET_LEFT)
            self.state = 393
            self.selectOperand()
            self.state = 394
            self.match(dpm_xlParser.CURLY_BRACKET_RIGHT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SelectOperandContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def cellRef(self):
            return self.getTypedRuleContext(dpm_xlParser.CellRefContext,0)


        def varRef(self):
            return self.getTypedRuleContext(dpm_xlParser.VarRefContext,0)


        def operationRef(self):
            return self.getTypedRuleContext(dpm_xlParser.OperationRefContext,0)


        def preconditionElem(self):
            return self.getTypedRuleContext(dpm_xlParser.PreconditionElemContext,0)


        def getRuleIndex(self):
            return dpm_xlParser.RULE_selectOperand

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSelectOperand" ):
                listener.enterSelectOperand(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSelectOperand" ):
                listener.exitSelectOperand(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSelectOperand" ):
                return visitor.visitSelectOperand(self)
            else:
                return visitor.visitChildren(self)




    def selectOperand(self):

        localctx = dpm_xlParser.SelectOperandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_selectOperand)
        try:
            self.state = 400
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [39, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83]:
                self.enterOuterAlt(localctx, 1)
                self.state = 396
                self.cellRef()
                pass
            elif token in [84]:
                self.enterOuterAlt(localctx, 2)
                self.state = 397
                self.varRef()
                pass
            elif token in [85]:
                self.enterOuterAlt(localctx, 3)
                self.state = 398
                self.operationRef()
                pass
            elif token in [86]:
                self.enterOuterAlt(localctx, 4)
                self.state = 399
                self.preconditionElem()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VarIDContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CURLY_BRACKET_LEFT(self):
            return self.getToken(dpm_xlParser.CURLY_BRACKET_LEFT, 0)

        def varRef(self):
            return self.getTypedRuleContext(dpm_xlParser.VarRefContext,0)


        def CURLY_BRACKET_RIGHT(self):
            return self.getToken(dpm_xlParser.CURLY_BRACKET_RIGHT, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_varID

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarID" ):
                listener.enterVarID(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarID" ):
                listener.exitVarID(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarID" ):
                return visitor.visitVarID(self)
            else:
                return visitor.visitChildren(self)




    def varID(self):

        localctx = dpm_xlParser.VarIDContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_varID)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 402
            self.match(dpm_xlParser.CURLY_BRACKET_LEFT)
            self.state = 403
            self.varRef()
            self.state = 404
            self.match(dpm_xlParser.CURLY_BRACKET_RIGHT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CellRefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.address = None # CellAddressContext

        def cellAddress(self):
            return self.getTypedRuleContext(dpm_xlParser.CellAddressContext,0)


        def getRuleIndex(self):
            return dpm_xlParser.RULE_cellRef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCellRef" ):
                listener.enterCellRef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCellRef" ):
                listener.exitCellRef(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCellRef" ):
                return visitor.visitCellRef(self)
            else:
                return visitor.visitChildren(self)




    def cellRef(self):

        localctx = dpm_xlParser.CellRefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_cellRef)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 406
            localctx.address = self.cellAddress()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PreconditionElemContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PRECONDITION_ELEMENT(self):
            return self.getToken(dpm_xlParser.PRECONDITION_ELEMENT, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_preconditionElem

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPreconditionElem" ):
                listener.enterPreconditionElem(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPreconditionElem" ):
                listener.exitPreconditionElem(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPreconditionElem" ):
                return visitor.visitPreconditionElem(self)
            else:
                return visitor.visitChildren(self)




    def preconditionElem(self):

        localctx = dpm_xlParser.PreconditionElemContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_preconditionElem)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 408
            self.match(dpm_xlParser.PRECONDITION_ELEMENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VarRefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VAR_REFERENCE(self):
            return self.getToken(dpm_xlParser.VAR_REFERENCE, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_varRef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarRef" ):
                listener.enterVarRef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarRef" ):
                listener.exitVarRef(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarRef" ):
                return visitor.visitVarRef(self)
            else:
                return visitor.visitChildren(self)




    def varRef(self):

        localctx = dpm_xlParser.VarRefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_varRef)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 410
            self.match(dpm_xlParser.VAR_REFERENCE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OperationRefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPERATION_REFERENCE(self):
            return self.getToken(dpm_xlParser.OPERATION_REFERENCE, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_operationRef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperationRef" ):
                listener.enterOperationRef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperationRef" ):
                listener.exitOperationRef(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOperationRef" ):
                return visitor.visitOperationRef(self)
            else:
                return visitor.visitChildren(self)




    def operationRef(self):

        localctx = dpm_xlParser.OperationRefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_operationRef)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 412
            self.match(dpm_xlParser.OPERATION_REFERENCE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CellAddressContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_cellAddress


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class CompRefContext(CellAddressContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.CellAddressContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def argument(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.ArgumentContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.ArgumentContext,i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.COMMA)
            else:
                return self.getToken(dpm_xlParser.COMMA, i)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCompRef" ):
                listener.enterCompRef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCompRef" ):
                listener.exitCompRef(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCompRef" ):
                return visitor.visitCompRef(self)
            else:
                return visitor.visitChildren(self)


    class TableRefContext(CellAddressContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.CellAddressContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def tableReference(self):
            return self.getTypedRuleContext(dpm_xlParser.TableReferenceContext,0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.COMMA)
            else:
                return self.getToken(dpm_xlParser.COMMA, i)
        def argument(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.ArgumentContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.ArgumentContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTableRef" ):
                listener.enterTableRef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTableRef" ):
                listener.exitTableRef(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTableRef" ):
                return visitor.visitTableRef(self)
            else:
                return visitor.visitChildren(self)



    def cellAddress(self):

        localctx = dpm_xlParser.CellAddressContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_cellAddress)
        self._la = 0 # Token type
        try:
            self.state = 430
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [82, 83]:
                localctx = dpm_xlParser.TableRefContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 414
                self.tableReference()
                self.state = 419
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==37:
                    self.state = 415
                    self.match(dpm_xlParser.COMMA)
                    self.state = 416
                    self.argument()
                    self.state = 421
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            elif token in [39, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81]:
                localctx = dpm_xlParser.CompRefContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 422
                self.argument()
                self.state = 427
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==37:
                    self.state = 423
                    self.match(dpm_xlParser.COMMA)
                    self.state = 424
                    self.argument()
                    self.state = 429
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TableReferenceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TABLE_REFERENCE(self):
            return self.getToken(dpm_xlParser.TABLE_REFERENCE, 0)

        def TABLE_GROUP_REFERENCE(self):
            return self.getToken(dpm_xlParser.TABLE_GROUP_REFERENCE, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_tableReference

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTableReference" ):
                listener.enterTableReference(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTableReference" ):
                listener.exitTableReference(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTableReference" ):
                return visitor.visitTableReference(self)
            else:
                return visitor.visitChildren(self)




    def tableReference(self):

        localctx = dpm_xlParser.TableReferenceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_tableReference)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 432
            _la = self._input.LA(1)
            if not(_la==82 or _la==83):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ClauseOperatorsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return dpm_xlParser.RULE_clauseOperators


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class RenameExprContext(ClauseOperatorsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ClauseOperatorsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def RENAME(self):
            return self.getToken(dpm_xlParser.RENAME, 0)
        def renameClause(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.RenameClauseContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.RenameClauseContext,i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(dpm_xlParser.COMMA)
            else:
                return self.getToken(dpm_xlParser.COMMA, i)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRenameExpr" ):
                listener.enterRenameExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRenameExpr" ):
                listener.exitRenameExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRenameExpr" ):
                return visitor.visitRenameExpr(self)
            else:
                return visitor.visitChildren(self)


    class WhereExprContext(ClauseOperatorsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ClauseOperatorsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def WHERE(self):
            return self.getToken(dpm_xlParser.WHERE, 0)
        def expression(self):
            return self.getTypedRuleContext(dpm_xlParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhereExpr" ):
                listener.enterWhereExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhereExpr" ):
                listener.exitWhereExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhereExpr" ):
                return visitor.visitWhereExpr(self)
            else:
                return visitor.visitChildren(self)


    class GetExprContext(ClauseOperatorsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a dpm_xlParser.ClauseOperatorsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def GET(self):
            return self.getToken(dpm_xlParser.GET, 0)
        def keyNames(self):
            return self.getTypedRuleContext(dpm_xlParser.KeyNamesContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGetExpr" ):
                listener.enterGetExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGetExpr" ):
                listener.exitGetExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGetExpr" ):
                return visitor.visitGetExpr(self)
            else:
                return visitor.visitChildren(self)



    def clauseOperators(self):

        localctx = dpm_xlParser.ClauseOperatorsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_clauseOperators)
        self._la = 0 # Token type
        try:
            self.state = 447
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [51]:
                localctx = dpm_xlParser.WhereExprContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 434
                self.match(dpm_xlParser.WHERE)
                self.state = 435
                self.expression(0)
                pass
            elif token in [52]:
                localctx = dpm_xlParser.GetExprContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 436
                self.match(dpm_xlParser.GET)
                self.state = 437
                self.keyNames()
                pass
            elif token in [53]:
                localctx = dpm_xlParser.RenameExprContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 438
                self.match(dpm_xlParser.RENAME)
                self.state = 439
                self.renameClause()
                self.state = 444
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==37:
                    self.state = 440
                    self.match(dpm_xlParser.COMMA)
                    self.state = 441
                    self.renameClause()
                    self.state = 446
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RenameClauseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def keyNames(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dpm_xlParser.KeyNamesContext)
            else:
                return self.getTypedRuleContext(dpm_xlParser.KeyNamesContext,i)


        def TO(self):
            return self.getToken(dpm_xlParser.TO, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_renameClause

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRenameClause" ):
                listener.enterRenameClause(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRenameClause" ):
                listener.exitRenameClause(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRenameClause" ):
                return visitor.visitRenameClause(self)
            else:
                return visitor.visitChildren(self)




    def renameClause(self):

        localctx = dpm_xlParser.RenameClauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_renameClause)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 449
            self.keyNames()
            self.state = 450
            self.match(dpm_xlParser.TO)
            self.state = 451
            self.keyNames()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparisonOperatorsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EQ(self):
            return self.getToken(dpm_xlParser.EQ, 0)

        def NE(self):
            return self.getToken(dpm_xlParser.NE, 0)

        def GT(self):
            return self.getToken(dpm_xlParser.GT, 0)

        def LT(self):
            return self.getToken(dpm_xlParser.LT, 0)

        def GE(self):
            return self.getToken(dpm_xlParser.GE, 0)

        def LE(self):
            return self.getToken(dpm_xlParser.LE, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_comparisonOperators

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparisonOperators" ):
                listener.enterComparisonOperators(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparisonOperators" ):
                listener.exitComparisonOperators(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparisonOperators" ):
                return visitor.visitComparisonOperators(self)
            else:
                return visitor.visitChildren(self)




    def comparisonOperators(self):

        localctx = dpm_xlParser.ComparisonOperatorsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_comparisonOperators)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 453
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 16128) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER_LITERAL(self):
            return self.getToken(dpm_xlParser.INTEGER_LITERAL, 0)

        def DECIMAL_LITERAL(self):
            return self.getToken(dpm_xlParser.DECIMAL_LITERAL, 0)

        def PERCENT_LITERAL(self):
            return self.getToken(dpm_xlParser.PERCENT_LITERAL, 0)

        def STRING_LITERAL(self):
            return self.getToken(dpm_xlParser.STRING_LITERAL, 0)

        def BOOLEAN_LITERAL(self):
            return self.getToken(dpm_xlParser.BOOLEAN_LITERAL, 0)

        def DATE_LITERAL(self):
            return self.getToken(dpm_xlParser.DATE_LITERAL, 0)

        def TIME_INTERVAL_LITERAL(self):
            return self.getToken(dpm_xlParser.TIME_INTERVAL_LITERAL, 0)

        def TIME_PERIOD_LITERAL(self):
            return self.getToken(dpm_xlParser.TIME_PERIOD_LITERAL, 0)

        def EMPTY_LITERAL(self):
            return self.getToken(dpm_xlParser.EMPTY_LITERAL, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_literal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteral" ):
                listener.enterLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteral" ):
                listener.exitLiteral(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLiteral" ):
                return visitor.visitLiteral(self)
            else:
                return visitor.visitChildren(self)




    def literal(self):

        localctx = dpm_xlParser.LiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_literal)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 455
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 8070450532247928834) != 0) or ((((_la - 64)) & ~0x3f) == 0 and ((1 << (_la - 64)) & 31) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class KeyNamesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ROW_COMPONENT(self):
            return self.getToken(dpm_xlParser.ROW_COMPONENT, 0)

        def COL_COMPONENT(self):
            return self.getToken(dpm_xlParser.COL_COMPONENT, 0)

        def SHEET_COMPONENT(self):
            return self.getToken(dpm_xlParser.SHEET_COMPONENT, 0)

        def PROPERTY_CODE(self):
            return self.getToken(dpm_xlParser.PROPERTY_CODE, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_keyNames

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKeyNames" ):
                listener.enterKeyNames(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKeyNames" ):
                listener.exitKeyNames(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitKeyNames" ):
                return visitor.visitKeyNames(self)
            else:
                return visitor.visitChildren(self)




    def keyNames(self):

        localctx = dpm_xlParser.KeyNamesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_keyNames)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 457
            _la = self._input.LA(1)
            if not(((((_la - 88)) & ~0x3f) == 0 and ((1 << (_la - 88)) & 23) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PropertyReferenceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SQUARE_BRACKET_LEFT(self):
            return self.getToken(dpm_xlParser.SQUARE_BRACKET_LEFT, 0)

        def propertyCode(self):
            return self.getTypedRuleContext(dpm_xlParser.PropertyCodeContext,0)


        def SQUARE_BRACKET_RIGHT(self):
            return self.getToken(dpm_xlParser.SQUARE_BRACKET_RIGHT, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_propertyReference

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPropertyReference" ):
                listener.enterPropertyReference(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPropertyReference" ):
                listener.exitPropertyReference(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropertyReference" ):
                return visitor.visitPropertyReference(self)
            else:
                return visitor.visitChildren(self)




    def propertyReference(self):

        localctx = dpm_xlParser.PropertyReferenceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_propertyReference)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 459
            self.match(dpm_xlParser.SQUARE_BRACKET_LEFT)
            self.state = 460
            self.propertyCode()
            self.state = 461
            self.match(dpm_xlParser.SQUARE_BRACKET_RIGHT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PropertyCodeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PROPERTY_CODE(self):
            return self.getToken(dpm_xlParser.PROPERTY_CODE, 0)

        def CODE(self):
            return self.getToken(dpm_xlParser.CODE, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_propertyCode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPropertyCode" ):
                listener.enterPropertyCode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPropertyCode" ):
                listener.exitPropertyCode(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropertyCode" ):
                return visitor.visitPropertyCode(self)
            else:
                return visitor.visitChildren(self)




    def propertyCode(self):

        localctx = dpm_xlParser.PropertyCodeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_propertyCode)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 463
            _la = self._input.LA(1)
            if not(_la==69 or _la==92):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TemporaryIdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CODE(self):
            return self.getToken(dpm_xlParser.CODE, 0)

        def getRuleIndex(self):
            return dpm_xlParser.RULE_temporaryIdentifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTemporaryIdentifier" ):
                listener.enterTemporaryIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTemporaryIdentifier" ):
                listener.exitTemporaryIdentifier(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTemporaryIdentifier" ):
                return visitor.visitTemporaryIdentifier(self)
            else:
                return visitor.visitChildren(self)




    def temporaryIdentifier(self):

        localctx = dpm_xlParser.TemporaryIdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_temporaryIdentifier)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 465
            self.match(dpm_xlParser.CODE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[8] = self.expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 13)


            if predIndex == 1:
                return self.precpred(self._ctx, 12)


            if predIndex == 2:
                return self.precpred(self._ctx, 11)


            if predIndex == 3:
                return self.precpred(self._ctx, 10)


            if predIndex == 4:
                return self.precpred(self._ctx, 8)


            if predIndex == 5:
                return self.precpred(self._ctx, 7)


            if predIndex == 6:
                return self.precpred(self._ctx, 16)


            if predIndex == 7:
                return self.precpred(self._ctx, 9)





