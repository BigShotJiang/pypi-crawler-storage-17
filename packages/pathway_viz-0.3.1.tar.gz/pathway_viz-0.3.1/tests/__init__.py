"""
PathwayViz test suite.

Run with: pytest
"""
