import unittest

from metabolitics.analysis.tests import *
from metabolitics.extensions.tests import *
from metabolitics.preprocessing.tests import *
from metabolitics.utils.tests import *

if __name__ == '__main__':
    unittest.main()
