##############
Customs Module
##############

The *Customs Module* adds customs duties based on the tariff code.

.. toctree::
   :maxdepth: 2

   design
   releases
