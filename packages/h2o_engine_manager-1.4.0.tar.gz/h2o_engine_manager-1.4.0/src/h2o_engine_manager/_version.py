from importlib.metadata import version

__version__=version("h2o_engine_manager")
