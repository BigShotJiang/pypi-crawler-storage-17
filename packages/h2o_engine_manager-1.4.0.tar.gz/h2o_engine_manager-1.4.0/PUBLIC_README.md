# `h2o-engine-maanager`

[![pypi](https://img.shields.io/pypi/v/h2o-engine-manager?style=flat-square)](https://pypi.org/project/h2o-engine-manager/)

Python client for [H2O AI Engine Manager](https://h2oai.github.io/ai-engine-manager/).

## Installation

```sh
pip install h2o-engine-manager
```

## Usage

Visit the [documentation](https://docs.h2o.ai/ai-engine-manager/py/initialization) for more information.