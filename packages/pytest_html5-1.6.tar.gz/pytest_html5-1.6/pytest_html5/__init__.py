__pypi_url__ = "https://pypi.python.org/pypi/pytest-report"
