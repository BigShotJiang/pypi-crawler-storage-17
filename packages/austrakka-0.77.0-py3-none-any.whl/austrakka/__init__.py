# NOTE: do not change the name of this variable or the quote type,
# doing so will break github actions.
__version__ = "0.77.0"
__prog_name__ = "AusTrakka"
