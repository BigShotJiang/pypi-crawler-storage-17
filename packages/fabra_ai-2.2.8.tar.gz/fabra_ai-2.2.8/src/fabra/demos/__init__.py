"""
Packaged demo modules used by `fabra demo`.

These are shipped with the Python distribution so the quickstart works from a
clean install (no repo checkout required).
"""
