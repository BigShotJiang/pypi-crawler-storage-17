"""Test suite for comfy-mcp-server."""
