from asyncfast.cli import main

main()
