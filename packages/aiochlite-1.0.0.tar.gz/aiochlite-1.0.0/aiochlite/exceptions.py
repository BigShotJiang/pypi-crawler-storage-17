class ChClientError(Exception):
    """ClickHouse query execution error."""
