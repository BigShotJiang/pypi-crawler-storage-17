To install this module, you need to:

- Install helpdesk_mgmt_fieldservice
