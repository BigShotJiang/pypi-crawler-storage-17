# DF Test Framework v3 - 最终架构方案

> 基于"能力层与测试类型层解耦"的可无限扩展架构
>
> 日期: 2025-11-02
> 版本: v3.0.0（最终版）
> 状态: 架构设计完成，待实施

---

## 🎉 架构核心突破

经过深度讨论，我们发现了测试框架架构的本质问题，并给出了终极解决方案：

### 问题：能力与测试类型混淆

```
❌ 错误的架构（v2及之前）：

clients/         # API能力
drivers/         # UI能力
core/
├── database/    # ❓ 数据库是能力？还是工具？
└── redis/       # ❓ Redis是能力？还是工具？
testing/
├── performance/ # ❓ 性能测试为什么在testing？
└── security/    # ❓ 安全测试为什么在testing？

问题：
1. 能力层不完整（缺少数据测试能力）
2. 概念混淆（数据库既是能力又是工具）
3. 测试类型不完整（功能测试去哪了？）
```

### 解决方案：两个维度完全分离

```
✅ 正确的架构（v3）：

维度1: 能力层（Layer 1）- 定义"测试什么"
────────────────────────────────────────
clients/      - API通信能力
drivers/      - UI交互能力
engines/      - 数据处理能力
messengers/   - 消息队列能力（可扩展）
chains/       - 区块链能力（可扩展）
devices/      - IoT设备能力（可扩展）
storages/     - 文件存储能力（可扩展）
...           - 任意新能力（可扩展）

维度2: 测试类型层（Layer 3）- 定义"怎么测"
────────────────────────────────────────
testing/
├── functional/     - 功能测试
├── performance/    - 性能测试
├── security/       - 安全测试
├── compatibility/  - 兼容性测试
├── integration/    - 集成测试
├── e2e/            - 端到端测试
├── accessibility/  - 可访问性测试（可扩展）
├── chaos/          - 混沌测试（可扩展）
└── ...             - 任意新测试类型（可扩展）

关键：两个维度完全解耦，任意组合
──────────────────────────────────
任何测试类型 × 任何能力 = 无限可能

示例：
- 性能测试 × API能力 = API性能测试
- 性能测试 × UI能力 = UI性能测试
- 性能测试 × 数据能力 = 数据库性能测试
- 安全测试 × API能力 = API安全测试
- 安全测试 × 数据能力 = 数据安全测试
- 混沌测试 × 消息队列能力 = 消息队列混沌测试
- ...
```

---

## 🏗️ 完整分层架构

```
┌─────────────────────────────────────────────────────────┐
│ Layer 4: 扩展和工具层                                    │
│  extensions/  utils/  cli/                              │
└─────────────────────────────────────────────────────────┘
                         ↑ 依赖
┌─────────────────────────────────────────────────────────┐
│ Layer 3: 测试类型层（定义"怎么测"）                      │
│  testing/                                               │
│   ├── functional/      - 功能测试                       │
│   ├── performance/     - 性能测试                       │
│   ├── security/        - 安全测试                       │
│   ├── compatibility/   - 兼容性测试                     │
│   ├── integration/     - 集成测试                       │
│   ├── e2e/             - 端到端测试                     │
│   ├── data/            - 测试数据管理（通用）            │
│   ├── validation/      - 验证器（通用）                 │
│   ├── mocks/           - Mock（通用）                   │
│   ├── reporting/       - 报告（通用）                   │
│   ├── fixtures/        - Pytest Fixtures（通用）        │
│   └── plugins/         - Pytest插件（通用）             │
└─────────────────────────────────────────────────────────┘
                         ↑ 依赖
┌─────────────────────────────────────────────────────────┐
│ Layer 2: 基础设施层                                      │
│  infrastructure/                                        │
│   ├── bootstrap/  - 启动管理                           │
│   ├── config/     - 配置管理                           │
│   ├── logging/    - 日志系统                           │
│   ├── providers/  - 依赖注入                           │
│   └── runtime/    - 运行时上下文                       │
└─────────────────────────────────────────────────────────┘
                         ↑ 依赖
┌─────────────────────────────────────────────────────────┐
│ Layer 1: 能力层（定义"测试什么"）- 开放式，可无限扩展    │
│                                                         │
│  clients/          - API通信能力                        │
│   ├── rest/          - REST API                        │
│   ├── graphql/       - GraphQL                         │
│   ├── grpc/          - gRPC                            │
│   └── websocket/     - WebSocket                       │
│                                                         │
│  drivers/          - UI交互能力                         │
│   ├── web/           - Web UI（Playwright/Selenium）  │
│   └── mobile/        - Mobile UI（Appium）            │
│                                                         │
│  engines/          - 数据处理能力                       │
│   ├── sql/           - SQL数据库（MySQL/PostgreSQL等） │
│   ├── nosql/         - NoSQL数据库（MongoDB/Redis等）  │
│   ├── bigdata/       - 大数据（Spark/Hive/Kafka等）   │
│   ├── etl/           - ETL                            │
│   └── stream/        - 流处理                         │
│                                                         │
│  messengers/      - 消息队列能力（未来扩展）            │
│   ├── rabbitmq/      - RabbitMQ                       │
│   ├── kafka/         - Kafka                          │
│   └── rocketmq/      - RocketMQ                       │
│                                                         │
│  chains/          - 区块链能力（未来扩展）              │
│   ├── ethereum/      - Ethereum                       │
│   └── bitcoin/       - Bitcoin                        │
│                                                         │
│  devices/         - IoT设备能力（未来扩展）             │
│   ├── mqtt/          - MQTT                           │
│   └── coap/          - CoAP                           │
│                                                         │
│  storages/        - 存储系统能力（未来扩展）            │
│   ├── s3/            - AWS S3                         │
│   ├── oss/           - 阿里云OSS                      │
│   └── ftp/           - FTP                            │
│                                                         │
│  ...              - 任意新能力（可扩展）                │
│                                                         │
└─────────────────────────────────────────────────────────┘
                         ↑ 依赖
┌─────────────────────────────────────────────────────────┐
│ Layer 0: 共享基础层                                      │
│  common/                                                │
│   ├── exceptions.py   - 异常定义                       │
│   ├── types.py        - 类型定义                       │
│   └── protocols.py    - 通用Protocol                   │
└─────────────────────────────────────────────────────────┘
```

---

## 🎯 核心设计原则

### 原则1: 能力层开放性

**能力层不是固定的"三层"，而是开放的、可按需扩展的**

```python
# ✅ 正确理解
能力层 = {
    "clients": "API通信能力",
    "drivers": "UI交互能力",
    "engines": "数据处理能力",
    # 未来可以添加：
    "messengers": "消息队列能力",
    "chains": "区块链能力",
    "devices": "IoT设备能力",
    "storages": "存储系统能力",
    # ... 无限扩展
}

# ❌ 错误理解
能力层 = ["clients", "drivers", "engines"]  # 固定三层
```

### 原则2: 测试类型层开放性

**测试类型层也是开放的、可按需扩展的**

```python
# ✅ 正确理解
测试类型 = {
    "functional": "功能测试",
    "performance": "性能测试",
    "security": "安全测试",
    "compatibility": "兼容性测试",
    "integration": "集成测试",
    "e2e": "端到端测试",
    # 未来可以添加：
    "accessibility": "可访问性测试",
    "chaos": "混沌测试",
    "regression": "回归测试",
    "smoke": "冒烟测试",
    # ... 无限扩展
}
```

### 原则3: 两个维度完全解耦

**任何测试类型都可以使用任何能力**

```
测试矩阵（示例）：

                  clients/  drivers/  engines/  messengers/  chains/
                  (API)     (UI)      (数据)    (消息队列)   (区块链)
functional/         ✓         ✓         ✓          ✓           ✓
performance/        ✓         ✓         ✓          ✓           ✓
security/           ✓         ✓         ✓          ✓           ✓
compatibility/      ✓         ✓         ✓          ✓           ✓
chaos/              ✓         ✓         ✓          ✓           ✓

说明：任意组合都是有效的测试场景
```

---

## 🚀 扩展性验证

### 场景1: 扩展新的能力 - 消息队列

**需求**：需要测试RabbitMQ消息队列

**实施步骤**：

```bash
# Step 1: 在Layer 1创建新能力层
mkdir -p src/df_test_framework/messengers/rabbitmq

# Step 2: 实现能力（遵循Protocol+Adapter+Factory模式）
```

```python
# messengers/rabbitmq/protocols.py
class MessageQueueProtocol(Protocol):
    def send(self, queue: str, message: str) -> None: ...
    def receive(self, queue: str, timeout: int = None) -> str: ...

# messengers/rabbitmq/client.py
class RabbitMQClient:
    """实现MessageQueueProtocol"""
    def send(self, queue: str, message: str):
        # 发送消息
        pass

# messengers/rabbitmq/factory.py
class RabbitMQFactory:
    @classmethod
    def create(cls, host: str, port: int) -> RabbitMQClient:
        return RabbitMQClient(host, port)
```

```python
# Step 3: 添加Fixture
# testing/fixtures/messenger_fixtures.py
@pytest.fixture
def rabbitmq_client():
    client = RabbitMQFactory.create(host="localhost", port=5672)
    yield client
    client.close()
```

```python
# Step 4: 使用（任何测试类型都可以使用）

# 功能测试
def test_message_functional(rabbitmq_client):
    """消息队列功能测试"""
    rabbitmq_client.send("test_queue", "hello")
    message = rabbitmq_client.receive("test_queue")
    assert message == "hello"

# 性能测试
def test_message_performance(rabbitmq_client):
    """消息队列性能测试"""
    from df_test_framework.testing.performance import PerformanceTimer

    with PerformanceTimer() as timer:
        for i in range(1000):
            rabbitmq_client.send("test_queue", f"message_{i}")

    assert timer.elapsed < 5.0  # 1000条消息<5秒

# 安全测试
def test_message_security(rabbitmq_client):
    """消息队列安全测试"""
    # 测试未授权访问
    # ...
```

**关键**：新增能力不影响任何现有代码！

---

### 场景2: 扩展新的测试类型 - 混沌测试

**需求**：需要进行混沌测试（Chaos Testing）

**实施步骤**：

```bash
# Step 1: 在Layer 3创建新测试类型
mkdir -p src/df_test_framework/testing/chaos
```

```python
# testing/chaos/api/fault_injection.py
class APIFaultInjection:
    """API故障注入"""
    def inject_latency(self, endpoint: str, latency_ms: int):
        """注入延迟"""
        pass

    def inject_error(self, endpoint: str, error_code: int):
        """注入错误"""
        pass

# testing/chaos/data/db_chaos.py
class DatabaseChaos:
    """数据库混沌测试"""
    def kill_connection(self):
        """杀死连接"""
        pass

# testing/chaos/message/queue_chaos.py
class MessageQueueChaos:
    """消息队列混沌测试"""
    def inject_message_loss(self, queue: str, loss_rate: float):
        """注入消息丢失"""
        pass
```

```python
# Step 2: 使用（可以使用任何能力）

# 混沌测试 × API能力
def test_api_chaos(rest_client):
    """API混沌测试（使用clients/能力）"""
    fault = APIFaultInjection()
    fault.inject_latency("/api/users", latency_ms=5000)

    response = rest_client.get("/api/users")
    assert response.status_code == 504  # 超时

# 混沌测试 × 数据能力
def test_db_chaos(mysql_engine):
    """数据库混沌测试（使用engines/能力）"""
    chaos = DatabaseChaos()
    chaos.kill_connection()

    # 测试重连机制
    mysql_engine.reconnect()
    assert mysql_engine.is_connected()

# 混沌测试 × 消息队列能力
def test_mq_chaos(rabbitmq_client):
    """消息队列混沌测试（使用messengers/能力）"""
    chaos = MessageQueueChaos()
    chaos.inject_message_loss("test_queue", loss_rate=0.1)

    # 测试消息可靠性机制
    # ...
```

**关键**：新增测试类型可以使用所有能力！

---

### 场景3: 扩展新的能力 - 区块链

**需求**：需要测试以太坊智能合约

**实施步骤**：

```bash
# Step 1: 创建区块链能力层
mkdir -p src/df_test_framework/chains/ethereum
```

```python
# chains/ethereum/protocols.py
class BlockchainProtocol(Protocol):
    def deploy_contract(self, contract_code: str) -> str: ...
    def call_function(self, contract_address: str, function: str, args: list) -> Any: ...

# chains/ethereum/client.py
from web3 import Web3

class EthereumClient:
    """以太坊客户端"""
    def __init__(self, node_url: str):
        self.w3 = Web3(Web3.HTTPProvider(node_url))

    def deploy_contract(self, contract_code: str) -> str:
        # 部署合约
        pass

    def call_function(self, contract_address: str, function: str, args: list):
        # 调用合约函数
        pass
```

```python
# Step 2: 使用（所有测试类型都可以使用）

# 功能测试
def test_contract_functional(ethereum_client):
    """智能合约功能测试（使用chains/能力）"""
    contract_address = ethereum_client.deploy_contract(contract_code)
    result = ethereum_client.call_function(contract_address, "transfer", [100])
    assert result == True

# 安全测试
def test_contract_security(ethereum_client):
    """智能合约安全测试"""
    from df_test_framework.testing.security.blockchain import ReentrancyScanner

    scanner = ReentrancyScanner()
    vulnerabilities = scanner.scan(contract_code)
    assert len(vulnerabilities) == 0
```

**关键**：架构完全支持，无需修改！

---

## 📊 架构优势总结

### 1. 无限扩展性

| 维度 | 扩展方式 | 影响范围 |
|------|---------|---------|
| **新增能力** | 在Layer 1添加新目录 | 无影响，所有测试类型自动可用 |
| **新增测试类型** | 在Layer 3添加新目录 | 无影响，可以使用所有能力 |
| **新增实现** | 在能力层添加Adapter | 无影响，通过配置切换 |

### 2. 组合爆炸的威力

```
假设：
- 5种能力（clients/drivers/engines/messengers/chains）
- 6种测试类型（functional/performance/security/chaos/integration/e2e）

组合数 = 5 × 6 = 30种测试场景

未来：
- 10种能力
- 10种测试类型

组合数 = 10 × 10 = 100种测试场景

所有场景都自动支持！
```

### 3. 清晰的概念模型

```
问题：我要测试XXX

Step 1: 确定能力（测试什么）
  - 是API吗？       → clients/
  - 是UI吗？        → drivers/
  - 是数据吗？      → engines/
  - 是消息队列吗？  → messengers/
  - 是区块链吗？    → chains/

Step 2: 确定测试类型（怎么测）
  - 功能测试？      → testing/functional/
  - 性能测试？      → testing/performance/
  - 安全测试？      → testing/security/
  - 混沌测试？      → testing/chaos/

Step 3: 组合使用
  例如：API性能测试 = testing/performance/api/ + clients/rest/
```

---

## 🎯 实施建议

### 阶段1: 核心架构（P0 - 必须）

实现Layer 1的**现有能力**：
1. ✅ `clients/rest/` - REST客户端（httpx实现）
2. ✅ `drivers/web/` - Web驱动（playwright实现）
3. ✅ `engines/sql/` - SQL引擎（MySQL实现）
4. ✅ `engines/nosql/redis/` - Redis引擎

实现Layer 3的**核心测试类型**：
1. ✅ `testing/functional/` - 功能测试工具
2. ✅ `testing/validation/` - 验证器
3. ✅ `testing/data/` - 数据管理

### 阶段2: 备选实现（P1 - 重要）

1. ✅ `clients/rest/requests/` - requests实现
2. ✅ `drivers/web/selenium/` - selenium实现

### 阶段3: 扩展能力（P2 - 可选）

按需实现：
- `clients/graphql/` - GraphQL客户端
- `engines/bigdata/spark/` - Spark引擎
- `messengers/rabbitmq/` - RabbitMQ客户端

### 阶段4: 扩展测试类型（P2 - 可选）

按需实现：
- `testing/performance/` - 性能测试完整实现
- `testing/security/` - 安全测试完整实现
- `testing/chaos/` - 混沌测试

---

## ✅ 架构设计完成标志

我们的架构讨论已经达成共识，关键点：

1. ✅ **不是"三层对称"**，而是"能力层可无限扩展"
2. ✅ **不是固定结构**，而是"开放式架构"
3. ✅ **核心是解耦**：能力层 ⊥ 测试类型层
4. ✅ **扩展验证通过**：消息队列、区块链、IoT等都可以无缝扩展
5. ✅ **测试类型验证通过**：混沌测试、可访问性测试等都可以无缝扩展

---

**架构设计完成！可以开始实施。**

**下一步**: 创建目录结构并开始重构
