# DF Test Framework v3 - 完整架构重构方案（修订版）

> 基于交互模式分类的现代化测试框架架构
>
> 📅 日期: 2025-11-03
> 📌 版本: v3.0.0（完整架构版 - 修订）
> 🚀 状态: 架构重新设计完成
>
> **重要说明**:
> - 项目仍在搭建阶段，未大规模使用
> - 本次重构**不需要保留向后兼容性**
> - 采用**完整架构版**，为长期发展做好准备

---

## 📖 目录

- [架构设计理念](#架构设计理念)
- [核心架构突破](#核心架构突破)
- [完整分层架构](#完整分层架构)
- [能力层详细设计](#能力层详细设计)
- [实施计划](#实施计划)

---

## 🎯 架构设计理念

### 核心原则：按交互模式分类

> **关键洞察**: 测试框架的能力层应该反映**测试框架与被测系统的交互方式**，而不是技术栈本身

**分类维度**:
1. ✅ **交互模式优先**：请求-响应、会话式交互、数据访问、消息传递等
2. ✅ **语义准确性**：使用准确的术语（databases vs engines）
3. ✅ **职责单一性**：每个能力层只负责一种交互模式
4. ✅ **扩展开放性**：可以无限添加新的能力层

### 与旧方案的对比

| 维度 | 旧方案 | 新方案（完整架构版）| 改进 |
|------|--------|-------------------|------|
| **数据库** | `engines/sql/`, `engines/nosql/` | `databases/sql/`, `databases/nosql/` | ✅ 语义更准确 |
| **消息队列** | `engines/bigdata/kafka/` ❌ | `messengers/queue/kafka/` | ✅ 职责明确 |
| **文件存储** | 未定义 | `storages/object/s3/` | ✅ 新增能力 |
| **数据分析** | `engines/bigdata/spark/` | `engines/batch/spark/` | ✅ 按处理模式分类 |
| **HTTP通信** | `clients/rest/` | `clients/http/rest/` | ✅ 协议层级清晰 |

---

## 🎉 核心架构突破

### 突破1: 按交互模式重新分类能力层

```
旧架构问题：
────────────────────────────────────────
clients/         # API通信
drivers/         # UI交互
engines/         # ❓数据处理？还是计算引擎？
  ├── sql/       # 数据库
  ├── nosql/     # 数据库
  └── bigdata/   # ❌分类维度混乱
      ├── spark/ # 计算引擎
      └── kafka/ # ❌消息队列为什么在这？

问题：
1. engines 语义不准确（DB不是引擎）
2. bigdata 分类混乱（Kafka是消息队列）
3. 缺少文件存储能力
```

```
新架构（完整版）：
────────────────────────────────────────
clients/         # 请求-响应模式（发送请求）
drivers/         # 会话式交互模式（控制操作）
databases/       # 数据访问模式（CRUD）
messengers/      # 消息传递模式（发布/订阅）
storages/        # 文件存储模式（上传/下载）
engines/         # 计算引擎模式（批处理/流处理）

优势：
1. ✅ 按交互方式分类，逻辑清晰
2. ✅ 每个能力层职责单一
3. ✅ 语义准确，易于理解
4. ✅ 扩展性强，可无限添加新能力
```

### 突破2: 多层级协议组织

```
旧方案：
clients/rest/httpx/        # ❌ 扁平化，不清晰

新方案：
clients/http/rest/httpx/   # ✅ 协议层级清晰
  ├── http/               # HTTP协议层
  │   ├── rest/          # REST风格
  │   ├── graphql/       # GraphQL
  │   └── soap/          # SOAP
  ├── rpc/               # RPC协议层
  │   ├── grpc/
  │   └── thrift/
  └── websocket/         # WebSocket协议

优势：
1. ✅ 协议层级结构清晰
2. ✅ 同协议下的不同风格归类明确
3. ✅ 易于扩展新协议
```

### 突破3: 数据库扁平化组织

```
旧方案：
databases/
├── sql/            # SQL分类
│   ├── mysql/
│   ├── postgresql/
│   └── database.py  # 通用类
└── nosql/          # NoSQL分类
    ├── redis/
    └── mongodb/

问题：
- SQL/NoSQL分类有时不清晰
- Elasticsearch是SQL还是NoSQL？

新方案（扁平化）：
databases/
├── mysql/
├── postgresql/
├── sqlite/
├── redis/
├── mongodb/
├── elasticsearch/
├── database.py      # 通用Database工厂类
└── repositories/    # 通用Repository模式

优势：
1. ✅ 所有数据库平级，无分类歧义
2. ✅ 按名称直接索引
3. ✅ 扩展时直接添加新目录
```

---

## 🏗️ 完整分层架构

```
┌─────────────────────────────────────────────────────────┐
│ Layer 4: 扩展和工具层                                    │
│  extensions/  utils/  cli/                              │
└─────────────────────────────────────────────────────────┘
                         ↑ 依赖
┌─────────────────────────────────────────────────────────┐
│ Layer 3: 测试类型层（定义"怎么测"）                      │
│  testing/                                               │
│   ├── functional/      - 功能测试                       │
│   ├── performance/     - 性能测试                       │
│   ├── security/        - 安全测试                       │
│   ├── data/            - 测试数据管理（通用）            │
│   ├── validation/      - 验证器（通用）                 │
│   ├── mocks/           - Mock（通用）                   │
│   ├── reporting/       - 报告（通用）                   │
│   ├── fixtures/        - Pytest Fixtures（通用）        │
│   └── plugins/         - Pytest插件（通用）             │
└─────────────────────────────────────────────────────────┘
                         ↑ 依赖
┌─────────────────────────────────────────────────────────┐
│ Layer 2: 基础设施层                                      │
│  infrastructure/                                        │
│   ├── bootstrap/  - 启动管理                           │
│   ├── config/     - 配置管理                           │
│   ├── logging/    - 日志系统                           │
│   ├── providers/  - 依赖注入                           │
│   └── runtime/    - 运行时上下文                       │
└─────────────────────────────────────────────────────────┘
                         ↑ 依赖
┌─────────────────────────────────────────────────────────┐
│ Layer 1: 能力层（定义"测试什么"）- 按交互模式分类        │
│                                                         │
│  clients/          - 请求-响应模式（API通信）           │
│   ├── http/          - HTTP协议                        │
│   │   ├── rest/        - REST风格                     │
│   │   │   ├── httpx/     - httpx实现                 │
│   │   │   └── requests/  - requests实现（预留）       │
│   │   ├── graphql/     - GraphQL（预留）              │
│   │   └── soap/        - SOAP（预留）                 │
│   ├── rpc/           - RPC协议                        │
│   │   ├── grpc/        - gRPC（预留）                │
│   │   └── thrift/      - Thrift（预留）              │
│   └── websocket/     - WebSocket协议（预留）          │
│                                                         │
│  drivers/          - 会话式交互模式（UI控制）           │
│   ├── web/           - Web浏览器                      │
│   │   ├── playwright/  - Playwright实现              │
│   │   ├── selenium/    - Selenium实现（预留）         │
│   │   └── puppeteer/   - Puppeteer实现（预留）        │
│   ├── mobile/        - 移动应用                       │
│   │   └── appium/      - Appium实现（预留）          │
│   └── desktop/       - 桌面应用（预留）                │
│                                                         │
│  databases/        - 数据访问模式（CRUD操作）           │
│   ├── mysql/         - MySQL（预留）                  │
│   ├── postgresql/    - PostgreSQL（预留）             │
│   ├── sqlite/        - SQLite（预留）                 │
│   ├── redis/         - Redis（已实现）                │
│   ├── mongodb/       - MongoDB（预留）                │
│   ├── elasticsearch/ - Elasticsearch（预留）          │
│   ├── database.py    - 通用Database工厂类（已实现）    │
│   └── repositories/  - 通用Repository模式              │
│                                                         │
│  messengers/       - 消息传递模式（发布/订阅）          │
│   ├── queue/         - 消息队列                       │
│   │   ├── rabbitmq/    - RabbitMQ（预留）            │
│   │   ├── kafka/       - Kafka（预留）               │
│   │   └── rocketmq/    - RocketMQ（预留）            │
│   └── pubsub/        - 发布订阅                       │
│       └── redis/       - Redis Pub/Sub（预留）        │
│                                                         │
│  storages/         - 文件存储模式（上传/下载）          │
│   ├── object/        - 对象存储                       │
│   │   ├── s3/          - AWS S3（预留）              │
│   │   ├── minio/       - MinIO（预留）               │
│   │   └── oss/         - 阿里云OSS（预留）            │
│   ├── file/          - 文件系统                       │
│   │   ├── local/       - 本地文件系统（预留）         │
│   │   ├── ftp/         - FTP（预留）                 │
│   │   └── sftp/        - SFTP（预留）                │
│   └── blob/          - Blob存储（预留）                │
│                                                         │
│  engines/          - 计算引擎模式（数据处理）           │
│   ├── batch/         - 批处理引擎                     │
│   │   ├── spark/       - Apache Spark（预留）        │
│   │   └── hive/        - Apache Hive（预留）         │
│   ├── stream/        - 流处理引擎                     │
│   │   ├── flink/       - Apache Flink（预留）        │
│   │   └── kafka_streams/ - Kafka Streams（预留）     │
│   └── olap/          - OLAP分析引擎（预留）            │
│                                                         │
└─────────────────────────────────────────────────────────┘
                         ↑ 依赖
┌─────────────────────────────────────────────────────────┐
│ Layer 0: 共享基础层                                      │
│  common/                                                │
│   ├── exceptions.py   - 异常定义                       │
│   ├── types.py        - 类型定义                       │
│   └── protocols.py    - 通用Protocol                   │
└─────────────────────────────────────────────────────────┘
```

---

## 💡 能力层详细设计

### 1️⃣ clients/ - 请求-响应模式

**定义**: 发送请求，等待响应，无状态或短连接

```
clients/
├── http/              # HTTP协议族
│   ├── rest/          # REST风格
│   │   ├── protocols.py
│   │   ├── factory.py
│   │   ├── httpx/     # ✅ 立即实现
│   │   │   ├── client.py
│   │   │   └── base_api.py
│   │   └── requests/  # ⏳ 预留
│   │       └── __init__.py
│   ├── graphql/       # ⏳ 预留
│   └── soap/          # ⏳ 预留
│
├── rpc/               # RPC协议族
│   ├── grpc/          # ⏳ 预留
│   └── thrift/        # ⏳ 预留
│
└── websocket/         # WebSocket协议
    └── __init__.py    # ⏳ 预留
```

**立即实现（Phase 1）**:
- `clients/http/rest/httpx/` - 基于httpx的REST客户端
- `clients/http/rest/protocols.py` - REST客户端协议定义
- `clients/http/rest/factory.py` - REST客户端工厂

**预留（Phase 3+）**:
- `clients/http/rest/requests/` - 基于requests的REST客户端
- `clients/http/graphql/` - GraphQL客户端
- `clients/rpc/grpc/` - gRPC客户端

---

### 2️⃣ drivers/ - 会话式交互模式

**定义**: 建立会话，持续交互，有状态长连接

```
drivers/
├── web/               # Web浏览器驱动
│   ├── protocols.py
│   ├── factory.py
│   ├── playwright/    # ✅ 立即实现
│   │   ├── browser.py
│   │   ├── page.py
│   │   └── locator.py
│   ├── selenium/      # ⏳ 预留
│   └── puppeteer/     # ⏳ 预留
│
├── mobile/            # 移动应用驱动
│   └── appium/        # ⏳ 预留
│
└── desktop/           # 桌面应用驱动
    └── __init__.py    # ⏳ 预留
```

**立即实现（Phase 1）**:
- `drivers/web/playwright/` - 基于Playwright的Web驱动
- `drivers/web/protocols.py` - Web驱动协议定义
- `drivers/web/factory.py` - Web驱动工厂

---

### 3️⃣ databases/ - 数据访问模式

**定义**: 数据库CRUD操作，数据持久化

```
databases/
├── mysql/             # ⏳ 预留 - MySQL特定功能
├── postgresql/        # ⏳ 预留 - PostgreSQL特定功能
├── sqlite/            # ⏳ 预留 - SQLite特定功能
├── redis/             # ✅ 立即实现
│   └── client.py
├── mongodb/           # ⏳ 预留
├── elasticsearch/     # ⏳ 预留
│
├── database.py        # ✅ 立即实现 - 通用Database类
├── factory.py         # ✅ 立即实现 - Database工厂
└── repositories/      # ✅ 立即实现 - Repository模式
    ├── base.py
    └── query_spec.py
```

**设计说明**:
- `database.py`: 通用Database类，基于SQLAlchemy，支持所有SQL数据库
- `mysql/`, `postgresql/`: 预留用于数据库特定功能（如MySQL存储过程）
- `redis/`: Redis客户端实现
- `repositories/`: 通用Repository模式，适用于所有数据库

**立即实现（Phase 1）**:
- `databases/database.py` - 通用Database类
- `databases/factory.py` - Database工厂方法
- `databases/redis/client.py` - Redis客户端
- `databases/repositories/` - Repository模式

---

### 4️⃣ messengers/ - 消息传递模式

**定义**: 异步消息发送/接收，发布/订阅

```
messengers/
├── queue/             # 消息队列模式
│   ├── rabbitmq/      # ⏳ 预留
│   ├── kafka/         # ⏳ 预留
│   └── rocketmq/      # ⏳ 预留
│
└── pubsub/            # 发布订阅模式
    └── redis/         # ⏳ 预留
```

**预留（Phase 3+）**:
- 所有内容暂时预留，未来按需实现

---

### 5️⃣ storages/ - 文件存储模式

**定义**: 文件上传/下载，对象存储

```
storages/
├── object/            # 对象存储
│   ├── s3/            # ⏳ 预留
│   ├── minio/         # ⏳ 预留
│   └── oss/           # ⏳ 预留
│
├── file/              # 文件系统
│   ├── local/         # ⏳ 预留
│   ├── ftp/           # ⏳ 预留
│   └── sftp/          # ⏳ 预留
│
└── blob/              # Blob存储
    └── __init__.py    # ⏳ 预留
```

**预留（Phase 3+）**:
- 所有内容暂时预留，未来按需实现

---

### 6️⃣ engines/ - 计算引擎模式

**定义**: 数据批处理、流处理、OLAP分析

```
engines/
├── batch/             # 批处理引擎
│   ├── spark/         # ⏳ 预留
│   └── hive/          # ⏳ 预留
│
├── stream/            # 流处理引擎
│   ├── flink/         # ⏳ 预留
│   └── kafka_streams/ # ⏳ 预留
│
└── olap/              # OLAP分析引擎
    └── __init__.py    # ⏳ 预留
```

**预留（Phase 4+）**:
- 所有内容暂时预留，用于未来大数据测试场景

---

## 📋 实施计划

### Phase 1: 核心架构重构（当前阶段）

#### Step 1: 重组能力层目录 ✅

**已完成**:
- [x] 创建基础目录结构
- [x] 移动文件到新位置
- [x] 修正 `engines/sql/` → `databases/`

**进行中**:
- [ ] 重命名 `engines/` → `databases/`
- [ ] 调整 `clients/rest/` → `clients/http/rest/`
- [ ] 创建预留目录（messengers/, storages/, engines/）

#### Step 2: 添加Protocol和Factory层

**clients/http/rest/**:
```python
# protocols.py
from typing import Protocol

class RestClientProtocol(Protocol):
    def get(self, url: str, **kwargs) -> Any: ...
    def post(self, url: str, **kwargs) -> Any: ...
    # ...

# factory.py
class RestClientFactory:
    @classmethod
    def create(cls, client_type="httpx", **config):
        if client_type == "httpx":
            from .httpx.client import HttpxRestClient
            return HttpxRestClient(**config)
        elif client_type == "requests":
            raise NotImplementedError("requests实现尚未完成")
```

**drivers/web/**:
```python
# protocols.py
from typing import Protocol

class WebDriverProtocol(Protocol):
    def get(self, url: str) -> None: ...
    def find_element(self, locator: str) -> Any: ...
    # ...

# factory.py
class WebDriverFactory:
    @classmethod
    def create(cls, driver_type="playwright", **config):
        if driver_type == "playwright":
            from .playwright.browser import PlaywrightBrowserManager
            return PlaywrightBrowserManager(**config)
```

**databases/**:
```python
# factory.py
class DatabaseFactory:
    @classmethod
    def create_mysql(cls, host, port, user, password, database, **config):
        conn_str = f"mysql+pymysql://{user}:{password}@{host}:{port}/{database}"
        from .database import Database
        return Database(conn_str, **config)

    @classmethod
    def create_redis(cls, host="localhost", port=6379, **config):
        from .redis.client import RedisClient
        return RedisClient(host=host, port=port, **config)
```

#### Step 3: 创建预留目录

```bash
# 消息队列
mkdir -p messengers/queue/rabbitmq
mkdir -p messengers/queue/kafka

# 文件存储
mkdir -p storages/object/s3
mkdir -p storages/file/local

# 计算引擎（重新定义engines）
mkdir -p engines/batch/spark
mkdir -p engines/stream/flink
```

---

### Phase 2: 完善测试支持（未来）

- 测试数据管理完善
- API验证系统
- Mock支持
- 报告系统

### Phase 3: 备选实现（按需）

- `clients/http/rest/requests/`
- `drivers/web/selenium/`
- 其他预留能力的实现

---

## 📊 目录结构变更对照

### v2 → v3 迁移对照表

| v2 路径 | v3 路径（修订版）| 说明 |
|---------|----------------|------|
| `core/http/` | `clients/http/rest/httpx/` | HTTP REST客户端 |
| `ui/` | `drivers/web/playwright/` | Web驱动 |
| `core/database/` | `databases/database.py` | 通用Database类 |
| `core/redis/` | `databases/redis/` | Redis客户端 |
| `patterns/repositories/` | `databases/repositories/` | Repository模式 |
| `patterns/builders/` | `testing/data/builders/` | Builder模式 |
| - | `messengers/` | 🆕 消息队列（预留）|
| - | `storages/` | 🆕 文件存储（预留）|
| - | `engines/` | 🆕 计算引擎（重新定义）|

---

## ✅ 关键决策记录

### 决策1: engines/ 重新定义

**旧定义**: 数据处理能力（包括数据库）
**新定义**: 计算引擎（批处理/流处理）
**理由**: "engine"应该指计算引擎，数据库用 `databases/` 更准确

### 决策2: 数据库扁平化

**方案**: 所有数据库平级，不分SQL/NoSQL
**理由**: 避免分类歧义，按名称直接索引更清晰

### 决策3: 新增能力层

**新增**: `messengers/`, `storages/`
**理由**: 测试场景需要，补充完整的能力矩阵

### 决策4: HTTP协议层级化

**方案**: `clients/http/rest/` 而非 `clients/rest/`
**理由**: 协议层级更清晰，便于扩展HTTP其他风格（GraphQL、SOAP）

---

## 🎯 下一步行动

**立即执行**:
1. ✅ 重命名 `engines/` → `databases/`
2. ✅ 调整 `clients/rest/` → `clients/http/rest/`
3. ✅ 添加Protocol和Factory层
4. ✅ 创建预留目录结构
5. ✅ 更新所有导入语句
6. ✅ 更新顶层 `__init__.py`
7. ✅ 运行测试验证

---

**🤖 Generated with [Claude Code](https://claude.com/claude-code)**
