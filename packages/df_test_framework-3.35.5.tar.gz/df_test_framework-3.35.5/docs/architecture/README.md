# 架构设计文档

深入了解 DF Test Framework 架构设计和实现原理。

> 当前版本：v3.35.0

## 📚 v3.35 架构文档（当前版本）

### 核心文档
1. **[架构总览](OVERVIEW_V3.17.md)** ⭐ - 五层架构 + 事件驱动 + 统一可观测性
   - 五层架构详解（Layer 0-4）
   - EventBus 事件驱动
   - 中间件系统（洋葱模型）
   - 环境管理（ConfigRegistry）
   - 测试隔离机制

2. **[可观测性架构](observability-architecture.md)** - 三大支柱 + EventBus
   - Logging (Loguru)
   - Tracing (OpenTelemetry)
   - Metrics (Prometheus)
   - EventBus 集成

3. **[EventBus 集成分析](eventbus-integration-analysis.md)** - 模块集成状态
   - 已集成 EventBus 的模块
   - 改进路线图

---

## 📚 基础架构设计（历史参考）

### 能力层设计
- **[V3 架构设计](V3_ARCHITECTURE.md)** - v3.0 核心架构方案（基础）
- **[V3 实施指南](V3_IMPLEMENTATION.md)** - v3.0 实施步骤
- **[v2 → v3 迁移指南](../migration/v2-to-v3.md)** - 用户迁移文档

### 质量保证
- **[架构审计报告](ARCHITECTURE_AUDIT.md)** - 文档与代码一致性审计
- **[未来增强功能](FUTURE_ENHANCEMENTS.md)** - 后续增强规划

### 归档
- **[archive/](archive/)** - 架构演进过程文档（已归档）
- **[overview.md](overview.md)** - v2 架构总览（历史参考）

## 🏗️ 架构原则

### 1. 五层架构（v3.16+）

框架采用清晰的五层设计：

```
Layer 4 ─── bootstrap/          # 引导层：框架组装和初始化
Layer 3 ─── testing/ + cli/     # 门面层：Fixtures、调试工具、CLI
Layer 2 ─── capabilities/       # 能力层：clients/drivers/databases/messengers/storages
Layer 1 ─── infrastructure/     # 基础设施：config/logging/telemetry/events/plugins
Layer 0 ─── core/               # 核心层：纯抽象（middleware/context/events/protocols）
横切 ───── plugins/             # 插件：MonitoringPlugin、AllurePlugin
```

**依赖规则**:
- Layer 4 → 可依赖 Layer 0-3 全部
- Layer 3 → 可依赖 Layer 0-2
- Layer 2 → 可依赖 Layer 0-1
- Layer 1 → 只能依赖 Layer 0
- Layer 0 → 无依赖（最底层）

### 2. 核心设计模式

- **Middleware（中间件）**: 洋葱模型请求处理链（签名、认证、重试、日志）
- **EventBus（事件驱动）**: 发布/订阅模式，模块解耦
- **Factory（工厂）**: 测试数据生成
- **Repository（仓储）**: 数据访问抽象
- **Provider（提供者）**: 依赖注入
- **Plugin（插件）**: 功能扩展（Pluggy）

### 3. 设计原则

- **单一职责**: 每个模块只负责一件事
- **依赖倒置**: 依赖抽象而非具体实现
- **开闭原则**: 对扩展开放，对修改关闭
- **接口隔离**: 使用协议和抽象基类
- **显式优于隐式**: 配置和行为明确可见

## 🔑 核心概念

### Bootstrap 启动流程（v3.35）

```python
from df_test_framework.bootstrap import Bootstrap
from df_test_framework.infrastructure.config import ConfigRegistry

# 初始化配置（新方式）
ConfigRegistry.initialize("staging", "config")

# Bootstrap 启动
Bootstrap()
  .with_settings(settings)       # 1. 加载配置
  .with_providers(providers)     # 2. 注册提供者
  .with_event_bus(event_bus)     # 3. 事件总线
  .with_extensions(extensions)   # 4. 加载扩展
  .build()                       # 5. 构建应用
  .run()                         # 6. 创建运行时
```

### RuntimeContext 依赖管理

```python
runtime.http_client()    # 获取HTTP客户端（含中间件）
runtime.database()       # 获取数据库连接
runtime.redis_client()   # 获取Redis客户端
runtime.event_bus        # 获取事件总线
```

### 中间件系统（v3.14+）

洋葱模型请求处理：

```python
from df_test_framework import HttpClient
from df_test_framework.capabilities.clients.http.middleware import (
    SignatureMiddleware,
    BearerTokenMiddleware,
    RetryMiddleware,
)

client = HttpClient(
    base_url="https://api.example.com",
    middlewares=[
        RetryMiddleware(max_retries=3),
        SignatureMiddleware(secret="xxx"),
        BearerTokenMiddleware(token="token"),
    ]
)
```

## 📊 模块依赖关系

```
┌─────────────────────────────────────────────────────────────┐
│                    Layer 4: Bootstrap                        │
│         ┌─────────────────────────────────────┐             │
│         │  Bootstrap → Providers → Runtime    │             │
│         └─────────────────────────────────────┘             │
├─────────────────────────────────────────────────────────────┤
│                Layer 3: Testing + CLI                        │
│    ┌──────────────┐      ┌──────────────┐                   │
│    │   Fixtures   │      │   CLI Tools  │                   │
│    └──────────────┘      └──────────────┘                   │
├─────────────────────────────────────────────────────────────┤
│               Layer 2: Capabilities                          │
│  ┌────────┐ ┌────────┐ ┌──────────┐ ┌──────────────┐        │
│  │ HTTP   │ │ gRPC   │ │ Database │ │  Messengers  │        │
│  │ Client │ │ Client │ │ + Redis  │ │ Kafka/MQ/RMQ │        │
│  └────────┘ └────────┘ └──────────┘ └──────────────┘        │
├─────────────────────────────────────────────────────────────┤
│              Layer 1: Infrastructure                         │
│  ┌────────┐ ┌─────────┐ ┌───────────┐ ┌──────────┐          │
│  │ Config │ │ Logging │ │ Telemetry │ │ EventBus │          │
│  └────────┘ └─────────┘ └───────────┘ └──────────┘          │
├─────────────────────────────────────────────────────────────┤
│                  Layer 0: Core                               │
│  ┌────────────┐ ┌─────────┐ ┌──────────┐ ┌───────────┐      │
│  │ Middleware │ │ Context │ │  Events  │ │ Protocols │      │
│  └────────────┘ └─────────┘ └──────────┘ └───────────┘      │
└─────────────────────────────────────────────────────────────┘
```

## 🎯 技术选型

### 核心依赖

- **httpx**: 现代异步HTTP客户端
- **pydantic**: 数据验证和配置管理
- **sqlalchemy**: 数据库ORM
- **redis**: Redis客户端
- **loguru**: 结构化日志
- **pluggy**: 插件系统
- **pytest**: 测试框架

### 为什么选择这些技术？

- **httpx vs requests**: 支持异步、HTTP/2、更现代的API
- **pydantic**: 类型安全、自动验证、环境变量支持
- **loguru**: 简单易用、结构化日志、自动颜色
- **pluggy**: pytest使用的插件系统，成熟稳定

## 🔗 相关资源

- [架构总览](overview.md)
- [API参考](../api-reference/README.md)
- [用户指南](../user-guide/README.md)

---

**返回**: [文档首页](../README.md)
