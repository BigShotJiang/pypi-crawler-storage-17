# DF Test Framework v3 架构设计方案

> 基于交互模式分类的现代化测试框架架构
>
> 📅 2025-11-03 | v3.0.0 | 状态: ✅ 已实施

---

## 🎯 核心设计决策

### 关键洞察

**测试框架的能力层应该反映"测试框架与被测系统的交互方式"，而非技术栈本身。**

### 三大设计原则

1. **交互模式优先** - 按请求-响应、数据访问、消息传递等交互模式分类
2. **语义准确性** - 使用准确的术语（databases而非engines）
3. **扩展开放性** - 能力层与测试类型层完全解耦，可无限扩展

---

## 📐 架构突破点

### 突破1: 能力层按交互模式分类

```
❌ 旧架构问题:
engines/
  ├── sql/        # 数据库
  ├── nosql/      # 数据库
  └── bigdata/    # ❌ 分类混乱
      ├── spark/  # 计算引擎
      └── kafka/  # ❌ 消息队列为何在这？

问题:
- engines语义不准确（DB不是引擎）
- 分类维度混乱（Kafka是消息系统）
- 扩展性差

✅ 新架构:
clients/         # 请求-响应模式（HTTP/RPC/GraphQL）
drivers/         # 会话式交互模式（浏览器/移动设备）
databases/       # 数据访问模式（MySQL/Redis/MongoDB）
messengers/      # 消息传递模式（Kafka/RabbitMQ/Pulsar）
storages/        # 文件存储模式（S3/MinIO/OSS）
engines/         # 计算引擎模式（Spark/Flink）

优势:
- ✅ 每个能力层职责单一、语义明确
- ✅ 可无限添加新能力层（如区块链、AI等）
- ✅ 扩展时不影响现有结构
```

### 突破2: databases扁平化

```
❌ 旧方案:
databases/
  ├── sql/              # ❌ 多余的分类层
  │   ├── mysql/
  │   └── postgresql/
  └── nosql/            # ❌ 多余的分类层
      ├── redis/
      └── mongodb/

✅ 新方案（扁平化）:
databases/
  ├── mysql/            # ✅ 按数据库类型组织
  ├── postgresql/
  ├── redis/
  ├── mongodb/
  ├── database.py       # 通用Database类
  ├── repositories/     # Repository模式
  └── factory.py        # DatabaseFactory

优势:
- ✅ 减少嵌套层级
- ✅ 添加新数据库更简单
- ✅ 避免SQL/NoSQL的模糊边界
```

### 突破3: 能力层与测试支持层解耦

```
能力层（Capability Layer）    测试支持层（Test Support Layer）
──────────────────────────    ────────────────────────────
clients/                      testing/
drivers/                        ├── assertions/   # 断言工具
databases/                      ├── data/         # 测试数据
messengers/                     │   └── builders/ # 数据构建
storages/                       ├── fixtures/     # Pytest fixtures
engines/                        ├── plugins/      # Pytest插件
                                └── debug/        # 调试工具

关键:
- 能力层提供"技术能力"（如何与系统交互）
- 测试支持层提供"测试工具"（如何编写测试）
- 不按测试类型组织（api/ui/e2e），而是按功能职责组织
- 所有测试工具适用于任何测试类型
```

---

## 🏗️ 完整分层架构

### Layer 0: 基础层（common/）
```
common/
├── exceptions.py      # 异常体系
└── types.py           # 类型定义
```

**职责**: 最底层模块，被所有其他层依赖，避免循环依赖

**说明**: Protocol定义分散在各能力层（如`clients/http/rest/protocols.py`）

---

### Layer 1: 能力层（6个能力维度）

#### 📐 目录组织设计原则

**原则 1：两层结构（类型 + 实现）**
- **适用场景**：同一类别有多种可替换的实现
- **目录层级**：
  - 第一层：能力类型分类（按技术特征/用途）
  - 第二层：具体实现（不同SDK/协议/引擎）
- **示例**：
  ```
  storages/object/{s3, oss}      # 对象存储：不同云厂商实现
  drivers/web/{playwright, selenium}  # Web自动化：不同引擎实现
  messengers/queue/{kafka, rabbitmq}  # 消息队列：不同MQ实现
  ```

**原则 2：一层结构（独立技术栈）**
- **适用场景**：每个技术都是完全独立的系统
- **目录层级**：直接按技术名称划分子目录
- **示例**：
  ```
  databases/{redis, mysql, postgresql}  # 每个都是不同的数据库系统
  clients/{http, graphql, grpc}         # 每个都是不同的通信协议
  ```

**判断标准**：
- ✅ 使用两层：如果实现之间可以互相替换（相同接口/用途）
- ✅ 使用一层：如果每个技术都有独特的API和用途

---

#### 1️⃣ clients/ - 请求-响应模式
```
clients/
└── http/              # HTTP协议
    └── rest/          # REST风格
        ├── httpx/     # ✅ httpx实现（已实现）
        ├── protocols.py  # REST客户端Protocol定义
        ├── factory.py    # REST客户端工厂
        └── __init__.py

# 预留（未实现）：
# ├── requests/      # requests实现
# ├── graphql/       # GraphQL
# └── grpc/          # gRPC
```

#### 2️⃣ drivers/ - 会话式交互模式
```
drivers/
└── web/               # 第一层：设备类型 - Web浏览器
    ├── playwright/    # 第二层：引擎实现 - ✅ Playwright（已实现）
    ├── protocols.py   # Web驱动Protocol定义
    ├── factory.py     # Web驱动工厂
    └── __init__.py

# 预留（未实现）：
# drivers/
# ├── web/           # Web浏览器
# │   └── selenium/  # Selenium实现（预留）
# ├── mobile/        # 移动设备（预留，与 web 平级）
# │   └── appium/    # Appium实现
# └── desktop/       # 桌面应用（预留，与 web 平级）
#     └── winappdriver/  # Windows应用驱动
```

**设计说明**：
- **第一层**（设备类型）：web、mobile、desktop 平级
- **第二层**（引擎实现）：playwright、selenium、appium 等具体实现
- **可替换性**：同一设备类型下的不同引擎可以互换

#### 3️⃣ databases/ - 数据访问模式
```
databases/
├── redis/             # ✅ Redis客户端（已实现）
├── database.py        # ✅ 通用Database类（已实现，基于 SQLAlchemy）
├── repositories/      # ✅ Repository模式（已实现）
├── uow.py             # ✅ Unit of Work模式（已实现）
├── factory.py         # ✅ DatabaseFactory（已实现）
└── __init__.py

# 预留（未实现）：
# ├── mysql/         # MySQL专用客户端（特定功能）
# ├── postgresql/    # PostgreSQL专用客户端（特定功能）
# ├── mongodb/       # MongoDB客户端（NoSQL）
# └── elasticsearch/ # Elasticsearch客户端（搜索引擎）
```

**设计说明**：
- **一层结构**：每个数据库都是独立的技术栈，API 不同
- **database.py**：通用关系型数据库类（基于 SQLAlchemy ORM）
- **专用客户端**：如 redis/、mysql/、mongodb/ 提供特定数据库的原生功能
- **不可替换**：Redis、MySQL、MongoDB 用途不同，无法互换

#### 4️⃣ messengers/ - 消息传递模式
```
messengers/
├── queue/             # 第一层：消息类型 - 消息队列
│   ├── kafka/         # 第二层：MQ实现 - ✅ Kafka（已实现，基于 confluent-kafka）
│   ├── rabbitmq/      # 第二层：MQ实现 - ✅ RabbitMQ（已实现，基于 pika）
│   └── rocketmq/      # 第二层：MQ实现 - ✅ RocketMQ（已实现）
└── pubsub/            # 第一层：消息类型 - 发布订阅（预留）
    └── __init__.py    # ⏳ 预留

# 预留（未实现）：
# └── queue/pulsar/  # Pulsar
```

**设计说明**：
- **两层结构**：第一层按消息传递类型分类，第二层按具体实现
- **第一层分类**（消息类型）：
  - `queue/` - 消息队列（点对点模式）
  - `pubsub/` - 发布订阅（广播模式）
- **第二层实现**（MQ系统）：
  - `kafka/`、`rabbitmq/`、`rocketmq/` 提供消息队列的不同MQ系统实现
- **可替换性**：同一消息类型下的不同实现可以互换（统一的生产者/消费者API）

#### 5️⃣ storages/ - 文件存储模式
```
storages/
├── object/            # 第一层：存储类型 - 对象存储
│   ├── s3/            # 第二层：云厂商实现 - ✅ AWS S3（已实现，基于 boto3）
│   └── oss/           # 第二层：云厂商实现 - ✅ 阿里云 OSS（已实现，基于 oss2）
├── file/              # 第一层：存储类型 - 文件系统
│   └── local/         # 第二层：文件系统实现 - ✅ 本地文件系统（已实现）
└── blob/              # 第一层：存储类型 - Blob存储（预留）
    └── __init__.py

# 预留（未实现）：
# storages/
# ├── object/
# │   ├── minio/     # MinIO（可使用 S3Client，S3协议兼容）
# │   ├── gcs/       # Google Cloud Storage
# │   └── azure/     # Azure Blob Storage
# ├── file/
# │   ├── nfs/       # 网络文件系统
# │   └── ftp/       # FTP文件系统
# └── blob/
#     └── hdfs/      # Hadoop分布式文件系统
```

**设计说明**：
- **两层结构**：第一层按存储类型分类，第二层按具体实现
- **第一层分类**（存储类型）：
  - `object/` - 对象存储（S3协议、OSS协议等）
  - `file/` - 文件系统（本地、网络文件系统等）
  - `blob/` - Blob存储（大数据场景）
- **第二层实现**（云厂商/技术）：
  - `s3/`、`oss/`、`gcs/` 提供对象存储的不同云厂商实现
  - `local/`、`nfs/`、`ftp/` 提供文件系统的不同协议实现
- **可替换性**：同一存储类型下的不同实现可以互换（统一 API）

#### 6️⃣ engines/ - 计算引擎模式
```
engines/
├── batch/             # 第一层：引擎类型 - 批处理引擎
│   └── spark/         # 第二层：引擎实现 - ⏳ Apache Spark（预留）
├── stream/            # 第一层：引擎类型 - 流处理引擎
│   └── flink/         # 第二层：引擎实现 - ⏳ Apache Flink（预留）
└── olap/              # 第一层：引擎类型 - OLAP分析引擎（预留）
    └── __init__.py    # ⏳ 预留

# 预留（未实现）：
# engines/
# ├── batch/
# │   └── hadoop/    # Hadoop MapReduce
# └── olap/
#     ├── clickhouse/  # ClickHouse
#     └── druid/       # Apache Druid
```

**设计说明**：
- **两层结构**：第一层按计算模式分类，第二层按具体引擎实现
- **第一层分类**（计算模式）：
  - `batch/` - 批处理引擎（离线计算）
  - `stream/` - 流处理引擎（实时计算）
  - `olap/` - OLAP分析引擎（多维分析）
- **第二层实现**（计算引擎）：
  - `spark/`、`hadoop/` 提供批处理的不同引擎实现
  - `flink/` 提供流处理引擎实现
  - `clickhouse/`、`druid/` 提供OLAP分析引擎实现
- **可替换性**：同一计算模式下的不同引擎可以互换（例如 Spark 和 Hadoop 都可用于批处理）

---

### Layer 2: 基础设施层（infrastructure/）
```
infrastructure/
├── config/            # 配置管理
├── logging/           # 日志系统
├── providers/         # 依赖注入
├── bootstrap/         # 应用启动
└── runtime/           # 运行时上下文
```

---

### Layer 3: 测试支持层（testing/）

> ⚠️ **v3.12.0 架构演进**：基于实践经验优化了模块组织，详见 [TESTING_MODULE_OPTIMIZATION.md](./TESTING_MODULE_OPTIMIZATION.md)

```
testing/
├── fixtures/                       # 🏗️ Pytest fixtures（依赖 pytest）
│   ├── core.py                     # 核心fixtures（runtime、http_client、database）
│   ├── allure.py                   # Allure fixture（薄包装层）
│   ├── cleanup.py                  # 测试数据清理（v3.11.1）
│   ├── ui.py                       # UI测试fixtures
│   ├── monitoring.py               # 性能监控
│   └── message_queue.py            # 消息队列fixtures
│
├── plugins/                        # 🔌 Pytest插件（依赖 pytest）
│   ├── markers.py                  # 环境标记
│   ├── debug.py                    # 调试插件（测试失败诊断）
│   └── api_autodiscovery.py        # API自动发现
│
├── reporting/                      # 📊 测试报告（不依赖 pytest）
│   └── allure/                     # Allure 子系统
│       ├── observer.py             # AllureObserver（观察者模式）
│       └── helper.py               # AllureHelper（工具类）
│
├── debugging/                      # 🐛 调试工具（不依赖 pytest）
│   ├── http.py                     # HTTPDebugger
│   └── database.py                 # DBDebugger
│
├── mocking/                        # 🎭 Mock 工具
│   ├── http_mock.py
│   ├── database_mock.py
│   ├── redis_mock.py
│   └── time_mock.py
│
├── assertions/                     # ✅ 断言工具
│   └── response.py
│
├── data/                           # 📦 测试数据
│   ├── builders/                   # Builder模式
│   └── loaders/                    # 数据加载器（CSV/JSON/YAML）
│
├── factories/                      # 🏭 数据工厂
│   ├── base.py
│   └── presets.py
│
└── decorators/                     # 🎨 装饰器
    └── api_class.py
```

**职责划分**:

| 模块 | 职责 | 依赖 pytest |
|-----|------|-----------|
| `fixtures/` | pytest fixture 定义 | ✅ 是 |
| `plugins/` | pytest hooks/markers | ✅ 是 |
| `reporting/allure/` | Allure 观察者、工具类 | ❌ 否 |
| `debugging/` | 调试器实现 | ❌ 否 |

**说明**:
- 不再按测试类型组织（api/、ui/），而是按功能职责组织
- `fixtures/` - pytest fixtures，包含 Allure 薄包装层
- `plugins/` - pytest 插件（hooks/markers/debug）
- `reporting/allure/` - Allure 核心实现（不依赖 pytest，可独立测试）
- `debugging/` - 调试器实现（不依赖 pytest，可独立测试）
- `mocking/` - Mock 工具集合
- `assertions/` - 断言工具
- `data/` - 测试数据构建器和加载器
- `factories/` - 工厂模式数据生成

**v3.12.0 架构演进要点**:
1. **职责分离** - pytest 依赖代码（fixtures/、plugins/）与核心实现（reporting/、debugging/）分离
2. **可测试性** - reporting/allure/ 和 debugging/ 不依赖 pytest，可独立单元测试
3. **单一入口** - 用户只需 `pytest_plugins = ["df_test_framework.testing.fixtures"]`
4. **薄包装层** - fixtures/allure.py 只做 pytest 集成，核心逻辑在 reporting/allure/

---

### Layer 4: 扩展和工具层
```
extensions/            # 插件系统
models/                # 数据模型
utils/                 # 工具函数
cli/                   # 命令行工具
```

---

## 🎓 扩展性验证

### 场景1: 添加消息队列测试（Kafka）
```
只需添加:
messengers/queue/kafka/
  ├── __init__.py
  ├── kafka_client.py
  └── producer.py

不影响:
- clients/（API测试）
- drivers/（UI测试）
- databases/（数据库测试）
- testing/（测试组织方式）
```

### 场景2: 添加区块链测试
```
只需添加新能力层:
blockchains/
  ├── ethereum/
  ├── bitcoin/
  └── factory.py

不影响任何现有模块
```

### 场景3: 添加AI模型测试
```
只需添加新能力层:
ai/
  ├── llm/           # 大语言模型
  ├── vision/        # 计算机视觉
  └── speech/        # 语音识别

不影响任何现有模块
```

---

## 📊 设计对比总结

| 维度 | v2.x | v3.0 | 改进 |
|------|------|------|------|
| **数据库** | `engines/sql/` | `databases/mysql/` | ✅ 语义准确+扁平化 |
| **HTTP** | `clients/rest/` | `clients/http/rest/` | ✅ 协议层级清晰 |
| **消息队列** | `engines/bigdata/kafka/` | `messengers/queue/kafka/` | ✅ 职责明确 |
| **UI自动化** | `ui/` | `drivers/web/` | ✅ 按交互模式分类 |
| **测试数据** | `patterns/builders/` | `testing/data/builders/` | ✅ 职责归位 |
| **异常定义** | 顶级`exceptions.py` | `common/exceptions.py` | ✅ 分层清晰 |
| **扩展性** | 受限于技术栈分类 | 可无限添加能力层 | ✅ 架构开放 |

---

## 🎯 实施状态

- ✅ Phase 1: 目录重构（已完成）
- ✅ Phase 2: 导入路径更新（已完成）
- ✅ Phase 3: databases扁平化（已完成）
- ✅ Phase 4: 测试验证（906/906通过）
- ✅ Phase 5: 文档更新（已完成）

**当前版本**: v3.10.0
**Git标签**: v3.10.0

---

## 📝 备注

1. **向后兼容性**: v3.x 保持向后兼容，需参考迁移文档从 v2 升级
2. **顶层导入**: 仍然支持`from df_test_framework import Database`
3. **测试覆盖**: 当前测试覆盖率 80%+，目标80%（已达成）
4. **文档位置**:
   - 架构方案: `docs/architecture/V3_ARCHITECTURE.md`（本文档）
   - 实施指南: `docs/architecture/V3_IMPLEMENTATION.md`
   - 迁移文档: `docs/migration/v2-to-v3.md`
