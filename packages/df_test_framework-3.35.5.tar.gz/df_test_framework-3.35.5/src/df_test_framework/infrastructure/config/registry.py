"""配置注册中心（v3.35.0）

提供统一的配置访问入口，支持:
- 按点号路径访问配置
- 全局单例模式
- 类型安全访问

Example:
    >>> # 初始化
    >>> registry = ConfigRegistry.initialize("staging", "config")
    >>>
    >>> # 全局访问
    >>> registry = ConfigRegistry.get_instance()
    >>> timeout = registry.get("http.timeout")
    >>>
    >>> # 类型安全访问
    >>> base_url = registry.settings.http.base_url
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .schema import FrameworkSettings


class ConfigRegistry:
    """配置注册中心

    提供统一的配置访问入口。

    Example:
        >>> # 方式1: 为指定环境创建
        >>> registry = ConfigRegistry.for_environment("staging")
        >>> timeout = registry.get("http.timeout")
        >>>
        >>> # 方式2: 全局单例
        >>> ConfigRegistry.initialize("staging")
        >>> registry = ConfigRegistry.get_instance()
        >>> base_url = registry.settings.http.base_url
        >>>
        >>> # 方式3: 直接传入配置对象
        >>> settings = FrameworkSettings(env="test")
        >>> registry = ConfigRegistry(settings)
    """

    _instance: ConfigRegistry | None = None

    def __init__(self, settings: FrameworkSettings) -> None:
        """初始化配置注册中心

        Args:
            settings: 配置对象
        """
        self._settings = settings

    @classmethod
    def for_environment(
        cls,
        env: str | None = None,
        config_dir: str | Path = "config",
        settings_class: type[FrameworkSettings] | None = None,
    ) -> ConfigRegistry:
        """为指定环境创建 ConfigRegistry

        优先使用 YAML 配置（如果 config_dir 存在），
        否则回退到 .env 文件模式。

        v3.35.1: 支持自定义配置类

        Args:
            env: 环境名称（None 时从 ENV 环境变量读取）
            config_dir: 配置目录
            settings_class: 配置类（默认 FrameworkSettings）

        Returns:
            ConfigRegistry 实例
        """
        config_path = Path(config_dir)

        # 回退到默认配置类
        from .schema import FrameworkSettings as DefaultSettings

        actual_settings_class = settings_class or DefaultSettings

        if config_path.exists():
            # 使用 YAML 配置
            from .loader import load_config

            settings = load_config(env, config_dir, actual_settings_class)
        else:
            # 回退到 .env 文件模式
            if env:
                settings = actual_settings_class.for_environment(env)
            else:
                settings = actual_settings_class()

        return cls(settings)

    @classmethod
    def get_instance(cls) -> ConfigRegistry:
        """获取全局单例

        需要先调用 initialize() 初始化。

        Returns:
            全局 ConfigRegistry 实例

        Raises:
            RuntimeError: 如果未初始化
        """
        if cls._instance is None:
            raise RuntimeError("ConfigRegistry 未初始化。请先调用 ConfigRegistry.initialize(env)")
        return cls._instance

    @classmethod
    def initialize(
        cls,
        env: str | None = None,
        config_dir: str | Path = "config",
        settings_class: type[FrameworkSettings] | None = None,
    ) -> ConfigRegistry:
        """初始化全局单例

        v3.35.1: 支持自定义配置类

        Args:
            env: 环境名称（None 时从 ENV 环境变量读取）
            config_dir: 配置目录
            settings_class: 配置类（默认 FrameworkSettings）

        Returns:
            全局 ConfigRegistry 实例
        """
        cls._instance = cls.for_environment(env, config_dir, settings_class)
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """重置全局单例（主要用于测试）"""
        cls._instance = None

    @classmethod
    def is_initialized(cls) -> bool:
        """检查是否已初始化

        Returns:
            是否已初始化
        """
        return cls._instance is not None

    @property
    def settings(self) -> FrameworkSettings:
        """获取完整配置对象

        Returns:
            配置对象
        """
        return self._settings

    @property
    def current_env(self) -> str:
        """获取当前环境名称

        Returns:
            环境名称
        """
        return self._settings.env

    def get(self, path: str, default: Any = None) -> Any:
        """按点号路径获取配置值

        Args:
            path: 配置路径（如 "http.timeout"）
            default: 默认值

        Returns:
            配置值

        Example:
            >>> registry.get("http.timeout")
            30
            >>> registry.get("http.base_url")
            "https://api.example.com"
            >>> registry.get("nonexistent", "default")
            "default"
        """
        obj: Any = self._settings
        for key in path.split("."):
            if hasattr(obj, key):
                obj = getattr(obj, key)
            elif isinstance(obj, dict) and key in obj:
                obj = obj[key]
            else:
                return default
        return obj

    # 快捷属性
    @property
    def http(self):
        """HTTP 配置"""
        return self._settings.http

    @property
    def db(self):
        """数据库配置"""
        return self._settings.db

    @property
    def redis(self):
        """Redis 配置"""
        return self._settings.redis

    @property
    def storage(self):
        """存储配置"""
        return self._settings.storage

    @property
    def test(self):
        """测试执行配置"""
        return self._settings.test

    @property
    def logging(self):
        """日志配置"""
        return self._settings.logging

    @property
    def observability(self):
        """可观测性配置"""
        return self._settings.observability

    @property
    def is_debug(self) -> bool:
        """是否调试模式"""
        return self._settings.debug

    @property
    def is_local(self) -> bool:
        """是否本地环境"""
        return self._settings.is_local

    @property
    def is_prod(self) -> bool:
        """是否生产环境"""
        return self._settings.is_prod


__all__ = [
    "ConfigRegistry",
]
