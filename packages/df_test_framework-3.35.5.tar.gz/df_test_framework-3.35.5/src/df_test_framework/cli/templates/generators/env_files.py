"""环境配置文件生成模板

用于生成 YAML 配置文件（v3.35.0+ 推荐）和 .env 系列配置文件（回退模式）
"""

# ============================================================
# YAML 配置模板（v3.35.0+ 推荐）
# ============================================================

# config/base.yaml - 基础配置模板
YAML_BASE_TEMPLATE = """# =============================================================================
# 项目基础配置（所有环境共享）
#
# 生成命令: df-test gen settings --with-yaml
# 生成时间: {timestamp}
#
# v3.35.0+ YAML 配置说明:
# - config/base.yaml           基础配置（所有环境通用）
# - config/environments/dev.yaml    开发环境配置
# - config/environments/test.yaml   测试环境配置
# - config/environments/staging.yaml 预发布环境配置
# - config/environments/prod.yaml   生产环境配置
# - config/environments/local.yaml  本地配置（不提交git，优先级最高）
# - config/secrets/.env.local       敏感信息（不提交git）
#
# 切换环境:
#   pytest tests/ --env=test      # 测试环境（默认）
#   pytest tests/ --env=staging   # 预发布环境
#   pytest tests/ --env=local     # 本地调试配置
# =============================================================================

# 默认环境
env: dev

# ============================================================
# HTTP 配置
# ============================================================
http:
  base_url: http://localhost:8000/api
  timeout: 30
  max_retries: 3

# ============================================================
# 可观测性配置
# ============================================================
observability:
  enabled: true
  debug_output: false  # 设为 true 启用调试输出（需要 pytest -s）
  allure_recording: true

# ============================================================
# 签名中间件配置（可选）
# ============================================================
# signature:
#   enabled: true
#   priority: 10
#   algorithm: md5
#   secret: change_me_in_production
#   header: X-Sign
#   include_paths:
#     - /api/**
#   exclude_paths:
#     - /health
#     - /metrics

# ============================================================
# Bearer Token 中间件配置（可选）
# ============================================================
# bearer_token:
#   enabled: true
#   priority: 20
#   source: login
#   login_url: /auth/login
#   credentials:
#     username: admin
#     password: admin123
#   token_path: data.token
#   include_paths:
#     - /api/**
#   exclude_paths:
#     - /auth/login
#     - /auth/register

# ============================================================
# 数据库配置（可选）
# ============================================================
# db:
#   host: localhost
#   port: 3306
#   name: test_db
#   user: root
#   password: password
#   pool_size: 10
#   charset: utf8mb4

# ============================================================
# Redis 配置（可选）
# ============================================================
# redis:
#   host: localhost
#   port: 6379
#   db: 0
#   password: null

# ============================================================
# 日志配置
# ============================================================
logging:
  level: INFO
"""

# config/environments/dev.yaml - 开发环境配置
YAML_DEV_TEMPLATE = """# =============================================================================
# 开发环境配置
#
# 继承: base.yaml
# 使用: pytest tests/ --env=dev
# =============================================================================

env: dev

http:
  base_url: http://dev-api.example.com/api
  timeout: 60

logging:
  level: DEBUG

observability:
  debug_output: true
"""

# config/environments/test.yaml - 测试环境配置
YAML_TEST_TEMPLATE = """# =============================================================================
# 测试环境配置
#
# 继承: base.yaml
# 使用: pytest tests/ --env=test（默认）
# =============================================================================

env: test

http:
  base_url: http://test-api.example.com/api
  timeout: 30

logging:
  level: INFO

observability:
  debug_output: false
"""

# config/environments/staging.yaml - 预发布环境配置
YAML_STAGING_TEMPLATE = """# =============================================================================
# 预发布环境配置
#
# 继承: base.yaml
# 使用: pytest tests/ --env=staging
# =============================================================================

env: staging

http:
  base_url: https://staging-api.example.com/api
  timeout: 30

logging:
  level: INFO

observability:
  debug_output: false
"""

# config/environments/prod.yaml - 生产环境配置
YAML_PROD_TEMPLATE = """# =============================================================================
# 生产环境配置
#
# ⚠️ 警告: 生产环境配置，请勿泄露敏感信息！
# 继承: base.yaml
# 使用: pytest tests/ --env=prod -m smoke
# =============================================================================

env: prod

http:
  base_url: https://api.example.com/api
  timeout: 30

logging:
  level: ERROR

observability:
  debug_output: false
  allure_recording: true
"""

# config/environments/local.yaml - 本地调试配置
YAML_LOCAL_TEMPLATE = """# =============================================================================
# 本地调试配置
#
# ⚠️ 此文件不应提交到版本控制（已在 .gitignore 中排除）
#
# 继承: test（使用测试环境作为基础，覆盖调试选项）
# 使用: pytest tests/ --env=local -s
# =============================================================================

# 继承 test 环境配置
_extends: test

# 覆盖可观测性配置
observability:
  debug_output: true  # 本地开启调试输出
"""

# config/secrets/.env.local - 敏感信息配置
SECRETS_ENV_LOCAL_TEMPLATE = """# =============================================================================
# 敏感信息配置（本地）
#
# ⚠️ 此文件不应提交到版本控制（已在 .gitignore 中排除）
# 用于存储密码、API密钥等敏感信息
# =============================================================================

# 签名密钥
# SIGNATURE__SECRET=your_secret_key

# 数据库密码
# DB__PASSWORD=your_db_password

# Redis 密码
# REDIS__PASSWORD=your_redis_password

# Token 凭证
# BEARER_TOKEN__CREDENTIALS__PASSWORD=your_login_password
"""

# ============================================================
# .env 配置模板（回退模式）
# ============================================================

# .env - 基础配置模板
ENV_BASE_TEMPLATE = """# =============================================================================
# 项目环境配置文件（.env 回退模式）
#
# 推荐使用 YAML 配置: df-test gen settings --with-yaml
# 生成时间: {timestamp}
#
# v3.35.0+ 配置说明:
# - 推荐使用 YAML 配置（config/base.yaml + config/environments/*.yaml）
# - 此 .env 文件作为回退模式，当 config/ 目录不存在时使用
# - 无 APP_ 前缀（v3.34.1+）
# - 使用 __ 嵌套分隔符（HTTP__BASE_URL）
#
# 切换环境:
#   ENV=dev pytest    # 使用开发环境
#   ENV=test pytest   # 使用测试环境
#   ENV=prod pytest   # 使用生产环境
# =============================================================================

# ============================================================
# 基础配置
# ============================================================
ENV=dev

# ============================================================
# HTTP 配置
# ============================================================
HTTP__BASE_URL=http://localhost:8000/api
HTTP__TIMEOUT=30
HTTP__MAX_RETRIES=3

# ============================================================
# 可观测性配置
# ============================================================
OBSERVABILITY__ENABLED=true
OBSERVABILITY__DEBUG_OUTPUT=false
OBSERVABILITY__ALLURE_RECORDING=true

# ============================================================
# 签名中间件配置（可选）
# ============================================================
# SIGNATURE__ENABLED=true
# SIGNATURE__ALGORITHM=md5
# SIGNATURE__SECRET=change_me_in_production

# ============================================================
# Token 中间件配置（可选）
# ============================================================
# BEARER_TOKEN__ENABLED=true
# BEARER_TOKEN__SOURCE=login
# BEARER_TOKEN__LOGIN_URL=/auth/login
# BEARER_TOKEN__CREDENTIALS__USERNAME=admin
# BEARER_TOKEN__CREDENTIALS__PASSWORD=admin123

# ============================================================
# 数据库配置（可选）
# ============================================================
# DB__HOST=localhost
# DB__PORT=3306
# DB__NAME=test_db
# DB__USER=root
# DB__PASSWORD=password
# DB__POOL_SIZE=10
# DB__CHARSET=utf8mb4

# ============================================================
# Redis 配置（可选）
# ============================================================
# REDIS__HOST=localhost
# REDIS__PORT=6379
# REDIS__PASSWORD=
# REDIS__DB=0

# ============================================================
# 日志配置
# ============================================================
LOGGING__LEVEL=INFO

# ============================================================
# 业务配置
# ============================================================
BUSINESS_TEST_USER_ID=test_user_001
BUSINESS_TEST_ROLE=admin
"""

# .env.dev - 开发环境配置
ENV_DEV_TEMPLATE = """# =============================================================================
# 开发环境配置（.env 回退模式）
#
# 优先级: 高于 .env，低于 .env.local
# 使用方式: ENV=dev pytest
# =============================================================================

ENV=dev

HTTP__BASE_URL=http://dev-api.example.com/api
HTTP__TIMEOUT=60

LOGGING__LEVEL=DEBUG
OBSERVABILITY__DEBUG_OUTPUT=true

# 签名密钥（开发环境）
# SIGNATURE__SECRET=dev_secret_key_12345

# 数据库配置（开发环境）
# DB__HOST=dev-mysql.example.com
# DB__NAME=dev_test_db
# DB__USER=dev_user
# DB__PASSWORD=dev_password
"""

# .env.test - 测试环境配置
ENV_TEST_TEMPLATE = """# =============================================================================
# 测试环境配置（.env 回退模式）
#
# 优先级: 高于 .env，低于 .env.local
# 使用方式: ENV=test pytest
# =============================================================================

ENV=test

HTTP__BASE_URL=http://test-api.example.com/api
HTTP__TIMEOUT=30

LOGGING__LEVEL=INFO
OBSERVABILITY__DEBUG_OUTPUT=false

# 签名密钥（测试环境）
# SIGNATURE__SECRET=test_secret_key_12345

# 数据库配置（测试环境）
# DB__HOST=test-mysql.example.com
# DB__NAME=test_db
# DB__USER=test_user
# DB__PASSWORD=test_password
"""

# .env.prod - 生产环境配置
ENV_PROD_TEMPLATE = """# =============================================================================
# 生产环境配置（.env 回退模式）
#
# ⚠️ 警告: 生产环境配置，请勿泄露敏感信息！
# 优先级: 高于 .env，低于 .env.local
# 使用方式: ENV=prod pytest -m smoke
# =============================================================================

ENV=prod

HTTP__BASE_URL=https://api.example.com/api
HTTP__TIMEOUT=30

LOGGING__LEVEL=ERROR
OBSERVABILITY__DEBUG_OUTPUT=false

# 签名密钥（生产环境）
# SIGNATURE__SECRET=CHANGE_ME_STRONG_SECRET

# 数据库配置（生产环境）
# DB__HOST=prod-mysql.example.com
# DB__NAME=prod_db
# DB__USER=prod_user
# DB__PASSWORD=CHANGE_ME_STRONG_PASSWORD
"""

# .env.example - 配置示例（用于版本控制）
ENV_EXAMPLE_TEMPLATE = """# =============================================================================
# 环境配置示例文件（.env 回退模式）
#
# 推荐使用 YAML 配置: df-test gen settings --with-yaml
#
# 使用说明:
# 1. 复制此文件为 .env
# 2. 修改配置值
# 3. .env 文件不应提交到版本控制
# =============================================================================

# ============================================================
# 基础配置
# ============================================================
ENV=dev

# ============================================================
# HTTP 配置
# ============================================================
HTTP__BASE_URL=http://localhost:8000/api
HTTP__TIMEOUT=30
HTTP__MAX_RETRIES=3

# ============================================================
# 可观测性配置
# ============================================================
OBSERVABILITY__ENABLED=true
OBSERVABILITY__DEBUG_OUTPUT=false
OBSERVABILITY__ALLURE_RECORDING=true

# ============================================================
# 签名中间件配置（可选）
# ============================================================
# SIGNATURE__ENABLED=true
# SIGNATURE__ALGORITHM=md5
# SIGNATURE__SECRET=your_secret_key_here

# ============================================================
# Token 中间件配置（可选）
# ============================================================
# BEARER_TOKEN__ENABLED=true
# BEARER_TOKEN__SOURCE=login
# BEARER_TOKEN__LOGIN_URL=/auth/login
# BEARER_TOKEN__CREDENTIALS__USERNAME=your_username
# BEARER_TOKEN__CREDENTIALS__PASSWORD=your_password

# ============================================================
# 数据库配置（可选）
# ============================================================
# DB__HOST=localhost
# DB__PORT=3306
# DB__NAME=your_database
# DB__USER=your_username
# DB__PASSWORD=your_password

# ============================================================
# Redis 配置（可选）
# ============================================================
# REDIS__HOST=localhost
# REDIS__PORT=6379
# REDIS__PASSWORD=
# REDIS__DB=0
"""

__all__ = [
    # YAML 配置模板（v3.35.0+ 推荐）
    "YAML_BASE_TEMPLATE",
    "YAML_DEV_TEMPLATE",
    "YAML_TEST_TEMPLATE",
    "YAML_STAGING_TEMPLATE",
    "YAML_PROD_TEMPLATE",
    "YAML_LOCAL_TEMPLATE",
    "SECRETS_ENV_LOCAL_TEMPLATE",
    # .env 配置模板（回退模式）
    "ENV_BASE_TEMPLATE",
    "ENV_DEV_TEMPLATE",
    "ENV_TEST_TEMPLATE",
    "ENV_PROD_TEMPLATE",
    "ENV_EXAMPLE_TEMPLATE",
]
