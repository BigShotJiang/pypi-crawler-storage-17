"""CLI入口点

允许通过 `python -m df_test_framework.cli` 运行命令行工具。
"""

from .main import main

if __name__ == "__main__":
    main()
