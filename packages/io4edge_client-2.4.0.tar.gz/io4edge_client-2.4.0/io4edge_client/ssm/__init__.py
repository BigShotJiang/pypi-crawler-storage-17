# SPDX-License-Identifier: Apache-2.0

import io4edge_client.api.ssm.python.ssm.v1.ssm_pb2 as Pb
from .client import Client

__all__ = ["Client", "Pb"]
