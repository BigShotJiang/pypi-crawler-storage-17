# SPDX-License-Identifier: Apache-2.0

from .client import Client
import io4edge_client.api.binaryIoTypeD.python.binaryIoTypeD.v1.binaryIoTypeD_pb2 as Pb

__all__ = ["Client", "Pb"]
