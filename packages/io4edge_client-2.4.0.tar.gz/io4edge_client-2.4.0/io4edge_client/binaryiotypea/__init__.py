# SPDX-License-Identifier: Apache-2.0
from .client import Client
import io4edge_client.api.binaryIoTypeA.python.binaryIoTypeA.v1alpha1.binaryIoTypeA_pb2 as Pb

__all__ = ["Client", "Pb"]
