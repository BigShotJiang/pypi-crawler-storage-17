_instruments = ("pydantic-ai >= 0.2.0",)
_supports_metrics = False
