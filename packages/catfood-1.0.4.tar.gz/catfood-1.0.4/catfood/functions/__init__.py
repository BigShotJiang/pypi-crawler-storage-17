"""提供一些函数"""

from .print import 消息头
from .files import open_file
from .terminal import calculateCharactersDisplayed

__all__ = [
    "open_file",
    "消息头",
    "calculateCharactersDisplayed"
]
