# Changelog

## [0.1.2](https://github.com/Pushikoo/pushikoo-adapter-testprocesser/compare/v0.1.1...v0.1.2) (2025-12-15)


### Miscellaneous Chores

* ci ([5ea421a](https://github.com/Pushikoo/pushikoo-adapter-testprocesser/commit/5ea421aac49b54d8061ecb0eb3c7796016419564))

## [0.1.1](https://github.com/Pushikoo/pushikoo-adapter-testprocesser/compare/v0.1.0...v0.1.1) (2025-12-15)


### Miscellaneous Chores

* ci ([a101de0](https://github.com/Pushikoo/pushikoo-adapter-testprocesser/commit/a101de0c0387a6225b8e4099dcac9c345c4a260b))

## 0.1.0 (2025-12-15)


### Miscellaneous Chores

* ci ([6f5a02c](https://github.com/Pushikoo/pushikoo-adapter-testprocesser/commit/6f5a02c6a563fdd16307129e31f6cd901e05f55b))
