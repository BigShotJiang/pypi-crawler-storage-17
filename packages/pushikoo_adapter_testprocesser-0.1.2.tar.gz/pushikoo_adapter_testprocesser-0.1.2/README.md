<div align="center">

# pushikoo-adapter-testprocesser

TestProcesser for pushikoo-adapter development as a template.

[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/Pushikoo/pushikoo-adapter-testprocesser/package.yml)](https://github.com/Pushikoo/pushikoo-adapter-testprocesser/actions)
[![Python](https://img.shields.io/pypi/pyversions/pushikoo-adapter-testprocesser)](https://pypi.org/project/pushikoo-adapter-testprocesser)
[![PyPI version](https://badge.fury.io/py/pushikoo-adapter-testprocesser.svg)](https://pypi.org/project/pushikoo-adapter-testprocesser)
[![License](https://img.shields.io/github/license/Pushikoo/pushikoo-adapter-testprocesser.svg)](https://pypi.org/project/pushikoo-adapter-testprocesser/)

</div>
