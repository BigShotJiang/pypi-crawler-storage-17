"""
EPI Tests - Test suite for EPI project.
"""
