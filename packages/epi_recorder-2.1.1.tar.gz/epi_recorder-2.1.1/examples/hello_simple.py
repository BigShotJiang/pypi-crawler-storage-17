"""
Simple example for testing epi run command.
"""

print("Hello from EPI Recorder!")
print("This is a simple test script.")

# Simulate some work
result = sum(range(100))
print(f"Sum of 0-99: {result}")

print("Done!")
