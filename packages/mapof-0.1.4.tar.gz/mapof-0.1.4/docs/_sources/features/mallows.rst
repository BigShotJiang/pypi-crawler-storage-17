Mallows
=======

.. automodule:: mapof.core.features.mallows
    :members:

