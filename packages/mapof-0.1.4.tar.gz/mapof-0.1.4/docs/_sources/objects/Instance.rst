Instance Object
===============

.. automodule:: mapof.core.objects.Instance
    :members:

