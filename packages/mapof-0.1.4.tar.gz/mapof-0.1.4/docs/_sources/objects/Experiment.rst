Experiment Object
=================

.. automodule:: mapof.core.objects.Experiment
    :members:

