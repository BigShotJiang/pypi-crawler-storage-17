Embedding
=========

.. toctree::
    :maxdepth: 2

    embed
    initial_positions
