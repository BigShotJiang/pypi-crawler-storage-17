Citation Policy
===============

If you are using this package, we kindly ask you to cite the following article.

.. code-block::

    S. Szufa, P. Faliszewski, P. Skowron, A. Slinko, N. Talmon,
    Drawing a map of elections in the space of statistical cultures.
    In: Proceedings of AAMAS-2020, 1341-1349.
