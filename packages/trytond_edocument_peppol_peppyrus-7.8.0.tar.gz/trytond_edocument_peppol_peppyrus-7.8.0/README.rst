################################
EDocument Peppol Peppyrus Module
################################

The *EDocument Peppol Peppyrus Module* allows sending and receiving electronic
documents on the `Peppol network <https://peppol.org/>`_ thanks to the
`Peppyrus <https://www.peppyrus.be/>`_ service.

.. toctree::
   :maxdepth: 2

   setup
   design
   releases
