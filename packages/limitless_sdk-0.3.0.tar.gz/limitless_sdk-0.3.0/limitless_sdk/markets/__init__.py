"""Markets module for Limitless Exchange."""

from .fetcher import MarketFetcher

__all__ = ["MarketFetcher"]
