# slowql/src/slowql/__main__.py
"""
Entry point for python -m slowql
"""

from slowql.cli.app import main

if __name__ == "__main__":
    main()
