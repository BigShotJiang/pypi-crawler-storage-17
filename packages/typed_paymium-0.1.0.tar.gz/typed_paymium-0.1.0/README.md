# Typed Paymium

> A fully typed, validated async client for the Paymium API

Use *autocomplete* instead of documentation.

🚧 Under construction.