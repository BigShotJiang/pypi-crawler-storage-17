"""
### Typed Paymium
> A fully typed, validated async client for the Paymium API

- Details
"""