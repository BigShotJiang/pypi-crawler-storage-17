REPO_ID = "llmsql-bench/llmsql-benchmark"
DEFAULT_WORKDIR_PATH = "llmsql_workdir"
