"""
Blog app - Example FastDjango application.
"""
