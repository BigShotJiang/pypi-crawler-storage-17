import{a1 as a}from"./_plugin-vue_export-helper-B2mYPZI2.js";const r=a("v-spacer","div","VSpacer");export{r as V};
