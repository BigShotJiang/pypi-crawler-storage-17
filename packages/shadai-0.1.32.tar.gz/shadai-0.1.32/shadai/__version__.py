"""Version information for Shadai Client."""

__version__ = "0.1.29"
__author__ = "Shadai Team"
__description__ = "Official Python client for Shadai AI API"
