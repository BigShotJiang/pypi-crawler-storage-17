"""Security tests for session-mgmt-mcp authentication, authorization, and security controls."""
