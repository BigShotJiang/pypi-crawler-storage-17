"""Anthropic Claude integration plugin for Nexus."""

from nexus_anthropic.plugin import AnthropicPlugin

__version__ = "0.1.0"
__all__ = ["AnthropicPlugin"]
