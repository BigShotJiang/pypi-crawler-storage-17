"""
StackSense Backend - Fly.io Deployment
======================================
FastAPI backend for license management and Lemon Squeezy integration.
"""

__version__ = "1.0.0"
