"""Prompt templates and configurations."""
