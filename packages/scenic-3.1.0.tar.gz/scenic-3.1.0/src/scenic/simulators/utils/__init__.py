"""Various utilities useful across multiple simulators."""
