"""World model and associated code for traffic scenarios in Webots.

This model handles Webots world files generated from Open Street Map data using the Webots OSM importer.
"""
