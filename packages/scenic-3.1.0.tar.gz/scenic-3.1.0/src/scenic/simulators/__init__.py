"""World models and interfaces for particular simulators."""
