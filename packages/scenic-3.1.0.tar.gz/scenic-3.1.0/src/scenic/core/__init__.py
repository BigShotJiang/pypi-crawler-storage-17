"""Scenic's core types and associated support code."""
