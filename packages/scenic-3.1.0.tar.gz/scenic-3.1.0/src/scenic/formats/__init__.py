"""Support for file formats not specific to particular simulators."""
