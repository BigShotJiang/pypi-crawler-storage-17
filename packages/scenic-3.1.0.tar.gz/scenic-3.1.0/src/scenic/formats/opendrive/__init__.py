"""Support for loading OpenDRIVE maps."""

from .workspace import OpenDriveWorkspace
from .xodr_parser import OpenDriveWarning
