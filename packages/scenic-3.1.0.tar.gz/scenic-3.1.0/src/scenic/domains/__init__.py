"""General scenario domains used across simulators."""
