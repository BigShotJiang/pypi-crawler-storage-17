::: inferno.bnn.params
    options:
        members:
        - BNNParameter
        - GaussianParameter
        - FactorizedCovariance
        - DiagonalCovariance
        - KroneckerCovariance
        - LowRankCovariance


