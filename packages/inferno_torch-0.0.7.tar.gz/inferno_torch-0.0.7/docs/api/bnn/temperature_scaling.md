::: inferno.bnn
    options:
        members:
        - TemperatureScaler