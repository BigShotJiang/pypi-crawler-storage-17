from shopware_api_client.models.product_stream import ProductStreamBase


class ProductStream(ProductStreamBase):
    pass
