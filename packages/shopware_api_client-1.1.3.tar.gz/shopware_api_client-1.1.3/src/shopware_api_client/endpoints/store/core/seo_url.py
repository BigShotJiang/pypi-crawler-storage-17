from shopware_api_client.models.seo_url import SeoUrlBase


class SeoUrl(SeoUrlBase):
    pass
