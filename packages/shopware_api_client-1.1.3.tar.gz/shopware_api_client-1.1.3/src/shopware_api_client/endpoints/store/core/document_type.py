from shopware_api_client.models.document_type import DocumentTypeBase


class DocumentType(DocumentTypeBase):
    pass
