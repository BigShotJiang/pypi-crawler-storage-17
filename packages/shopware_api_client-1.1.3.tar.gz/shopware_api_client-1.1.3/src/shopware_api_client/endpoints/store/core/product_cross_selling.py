from shopware_api_client.models.product_cross_selling import ProductCrossSellingBase


class ProductCrossSelling(ProductCrossSellingBase):
    pass
