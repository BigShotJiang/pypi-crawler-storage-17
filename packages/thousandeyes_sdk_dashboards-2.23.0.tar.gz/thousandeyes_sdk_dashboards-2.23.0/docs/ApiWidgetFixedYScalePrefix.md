# ApiWidgetFixedYScalePrefix

Prefix denoting the unit of measurement for the fixed Y-axis scale.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


