# Module :: iron_cage

Foundation utilities and core primitives for structured Python applications

<!--
### Basic use-case

```python
from iron_cage import f1

def main():
  f1()
```

### To add to your project

```bash
uv add iron_cage
```

### Try out from the repository

```shell
git clone <repository>
cd <repository>
uv sync
uv run python -m iron_cage
```
-->

### Sample

<!-- Add usage examples here -->
