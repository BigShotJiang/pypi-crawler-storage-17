# Test collection file
# Pytest auto-discovers tests - no explicit imports needed
