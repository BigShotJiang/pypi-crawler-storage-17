export default {
  extends: ["@commitlint/config-conventional"],
};
