from .sentry import NewonderLog

__version__ = "1.0.2"
__author__ = "Newonder"