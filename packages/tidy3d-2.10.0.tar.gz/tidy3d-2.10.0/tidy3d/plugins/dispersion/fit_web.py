"""Deprecated module"""

from __future__ import annotations

from tidy3d.log import log

log.warning(
    "The module 'plugins.dispersion.fit_web' has been deprecated in favor of "
    "'plugins.dispersion.web' and will be removed in future versions."
)
