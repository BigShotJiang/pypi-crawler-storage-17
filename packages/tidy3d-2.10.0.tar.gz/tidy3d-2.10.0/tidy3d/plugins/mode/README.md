# Mode Solver for propagating EM modes



