"""Web API for mode solver"""

from __future__ import annotations

from tidy3d.web.api.mode import run, run_batch

__all__ = ["run", "run_batch"]
