# Number of seconds to keep re-trying connection before erroring.
from __future__ import annotations

CONNECTION_RETRY_TIME = 180
# Time between checking task status.
REFRESH_TIME = 2
