# SPDX-FileCopyrightText: 2025-present Janna Hopp (https://github.com/bytehexe)
#
# SPDX-License-Identifier: MIT
