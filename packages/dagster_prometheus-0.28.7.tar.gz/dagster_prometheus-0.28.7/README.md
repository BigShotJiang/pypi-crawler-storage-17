# dagster-prometheus

The docs for `dagster-prometheus` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-prometheus).
