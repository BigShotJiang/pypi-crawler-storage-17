# Typed Bithumb

> A fully typed, validated async client for the Bithumb API

Use *autocomplete* instead of documentation.

🚧 Under construction.