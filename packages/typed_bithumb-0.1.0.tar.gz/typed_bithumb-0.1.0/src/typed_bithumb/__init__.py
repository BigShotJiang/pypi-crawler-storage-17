"""
### Typed Bithumb
> A fully typed, validated async client for the Bithumb API

- Details
"""