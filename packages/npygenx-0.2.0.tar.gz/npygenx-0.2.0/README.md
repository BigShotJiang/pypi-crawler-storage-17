# nurnpy

Install (editable):

```bash
pip install -e .
```
