__version__ = "25.12.2"
__tool_name__ = "project_cleanup_tool"
__description__ = "Mend Cleanup Tool"
