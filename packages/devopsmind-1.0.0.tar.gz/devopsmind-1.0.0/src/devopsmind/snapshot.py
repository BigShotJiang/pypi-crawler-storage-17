import hashlib
import json
from datetime import datetime

from .progress import load_state

SNAPSHOT_SCHEMA = "v3.0"


def sign_snapshot(snapshot: dict, email_hash: str) -> dict:
    """
    Sign snapshot using email hash for integrity.

    This function MUST exist because submit.py imports it.
    """

    payload = json.dumps(snapshot, sort_keys=True).encode()
    signature = hashlib.sha256(payload + email_hash.encode()).hexdigest()

    signed = dict(snapshot)
    signed["signature"] = signature
    return signed


def build_snapshot():
    """
    Build canonical snapshot of user state.

    ADDITIVE:
    - Include badges / achievements
    """

    state = load_state() or {}
    profile = state.get("profile", {}) or {}

    progress = state.get("progress", {}) or {}
    completed = progress.get("completed", []) or []

    # -------------------------------------------------
    # 🔥 ADDITIVE: collect badges
    # -------------------------------------------------
    global_badges = state.get("achievements_unlocked", []) or []
    profile_badges = profile.get("achievements", []) or []

    badges = sorted(set(global_badges) | set(profile_badges))

    snapshot = {
        "schema": SNAPSHOT_SCHEMA,
        "user_id": state.get("identity"),
        "username": state.get("username"),
        "handle": state.get("gamer"),
        "xp": int(state.get("xp", 0) or 0),
        "rank": profile.get("rank", "Beginner"),
        "completed_challenges": list(completed),
        "badges": badges,
        "updated_at": datetime.utcnow().isoformat() + "Z",
        "device_id": state.get("device_id"),
    }

    return snapshot
