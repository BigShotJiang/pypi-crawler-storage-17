from .beams import BeamFrame
from .spectrum import SpecFrame
