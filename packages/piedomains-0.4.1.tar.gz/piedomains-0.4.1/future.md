### Additional Data Sources That Can Be Exploited

* [UK Classification Data](data/classification.tsv)
	- https://data.webarchive.org.uk/opendata/ukwa.ds.1/classification/

* [Crowdflower Dataset](data/URL-categorization-DFE.csv)
	- https://data.world/crowdflower/url-categorization

* [DMOZ data]()
	- https://www.kaggle.com/datasets/shawon10/url-classification-dataset-dmoz?resource=download

* [UNB data]()
	- https://www.unb.ca/cic/datasets/url-2016.html

