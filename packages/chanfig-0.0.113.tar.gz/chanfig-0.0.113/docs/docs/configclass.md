---
authors:
  - Zhiyuan Chen
date: 2022-05-04
---

# configclass

::: chanfig.configclasses
