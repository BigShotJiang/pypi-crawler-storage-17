# Persistence module for caching scans
