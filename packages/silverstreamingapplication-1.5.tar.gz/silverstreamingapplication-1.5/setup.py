from setuptools import setup

setup(
    name='silverstreamingapplication',
    version='1.5',
    packages=['com.phida.main', 'com.phida.tests'],
    url='',
    license='',
    author='',
    author_email='',
    description='initial version'
)
