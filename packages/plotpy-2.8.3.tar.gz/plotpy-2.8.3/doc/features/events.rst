.. automodule:: plotpy.events
