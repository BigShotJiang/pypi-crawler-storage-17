.. automodule:: plotpy.widgets.resizedialog
