.. automodule:: plotpy.widgets.colormap
