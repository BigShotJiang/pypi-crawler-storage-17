:tocdepth: 3

Reference
---------

.. automodule:: plotpy.panels.base

.. automodule:: plotpy.panels.itemlist

.. automodule:: plotpy.panels.contrastadjustment

.. automodule:: plotpy.panels.csection
