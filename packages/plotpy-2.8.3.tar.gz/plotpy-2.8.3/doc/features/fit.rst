.. automodule:: plotpy.widgets.fit
