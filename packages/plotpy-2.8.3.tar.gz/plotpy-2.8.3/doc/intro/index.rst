Getting started
===============

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   overview
   motivation
   installation
   examples
   licenses
