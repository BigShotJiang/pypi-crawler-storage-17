Development
===========

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   contribute
   build
   guiqwt_to_plotpy
   v1_to_v2
   platforms
