__version__ = "0.6.2"

from .boss import BOSS

__all__ = ["BOSS"]
