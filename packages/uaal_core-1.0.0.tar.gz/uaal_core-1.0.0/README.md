# UAAL Core

UAAL is an inline enforcement layer that cryptographically records and proves AI decisions.

## What it does
- Blocks AI actions without policy reference
- Writes immutable, append-only decision evidence
- Supports local and S3 Object Lock storage
- Produces regulator-verifiable audit trails

## Who it is for
- Fintech
- Credit decisioning
- Regulated AI systems

## Philosophy
No dashboards. No trust theater. Only proof.
