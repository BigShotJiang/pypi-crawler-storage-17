import json, uuid, datetime, hashlib
from uaal.storage import LocalStore

store = LocalStore()

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def record_decision(inputs: dict, outcome: str, confidence: float):
    decision_id = str(uuid.uuid4())
    timestamp = datetime.datetime.utcnow().isoformat() + "Z"

    payload = {
        "decision_id": decision_id,
        "timestamp": timestamp,
        "decision_type": "CREDIT_LIMIT_AND_APR",
        "inputs": inputs,
        "outcome": outcome,
        "confidence": confidence
    }

    payload_bytes = json.dumps(payload, sort_keys=True).encode()
    payload["hash"] = sha256(payload_bytes)

    store.write(f"{decision_id}.json", payload)
    return decision_id
