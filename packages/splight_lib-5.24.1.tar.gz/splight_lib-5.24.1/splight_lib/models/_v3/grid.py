from splight_lib.models._v3.asset import AssetParams
from splight_lib.models.database import SplightDatabaseBaseModel


class Grid(AssetParams, SplightDatabaseBaseModel):
    pass
