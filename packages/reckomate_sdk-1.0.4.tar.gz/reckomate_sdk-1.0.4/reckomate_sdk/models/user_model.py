from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, EmailStr


class User(BaseModel):
    """User model for data representation"""
    
    id: Optional[str] = Field(None, description="User ID")
    phone: str = Field(..., min_length=10, max_length=15, description="Phone number")
    email: Optional[EmailStr] = Field(None, description="Email address")
    role: str = Field("user", description="User role")
    active_session_id: Optional[str] = Field(None, description="Current session ID")
    active_device_id: Optional[str] = Field(None, description="Current device ID")
    active_fcm_token: Optional[str] = Field(None, description="FCM token for notifications")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Creation timestamp")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="Last update timestamp")
    last_login_at: Optional[datetime] = Field(None, description="Last login timestamp")
    
    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "id": "507f1f77bcf86cd799439011",
                "phone": "+1234567890",
                "email": "user@example.com",
                "role": "user",
                "active_session_id": "session_123",
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2024-01-01T00:00:00Z"
            }
        }


class UserCreate(BaseModel):
    """Model for creating a new user"""
    
    phone: str = Field(..., min_length=10, max_length=15, description="Phone number")
    password: str = Field(..., min_length=8, description="Password")
    email: Optional[EmailStr] = Field(None, description="Email address")
    
    class Config:
        json_schema_extra = {
            "example": {
                "phone": "+1234567890",
                "password": "secure_password_123",
                "email": "user@example.com"
            }
        }


class UserUpdate(BaseModel):
    """Model for updating user information"""
    
    phone: Optional[str] = Field(None, min_length=10, max_length=15, description="Phone number")
    email: Optional[EmailStr] = Field(None, description="Email address")
    active_fcm_token: Optional[str] = Field(None, description="FCM token for notifications")
    
    class Config:
        json_schema_extra = {
            "example": {
                "phone": "+1987654321",
                "email": "newemail@example.com",
                "active_fcm_token": "fcm_token_xyz"
            }
        }


class UserResponse(BaseModel):
    """Model for user API responses"""
    
    id: str = Field(..., description="User ID")
    phone: str = Field(..., description="Phone number")
    email: Optional[str] = Field(None, description="Email address")
    role: str = Field(..., description="User role")
    created_at: datetime = Field(..., description="Creation timestamp")
    last_login_at: Optional[datetime] = Field(None, description="Last login timestamp")
    
    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "id": "507f1f77bcf86cd799439011",
                "phone": "+1234567890",
                "email": "user@example.com",
                "role": "user",
                "created_at": "2024-01-01T00:00:00Z",
                "last_login_at": "2024-01-02T12:00:00Z"
            }
        }