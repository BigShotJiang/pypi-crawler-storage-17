
from typing import Dict, Any, List, Optional

from ..config.settings import SDKConfig
from ..exceptions import QdrantError, ValidationError


class QdrantService:
    """Qdrant vector database operations business logic"""
    
    def __init__(self, config: SDKConfig):
        self.config = config
        self._qdrant_client = None
    
    @property
    def qdrant_client(self):
        """Lazy initialization of Qdrant client"""
        if self._qdrant_client is None:
            from qdrant_client import QdrantClient
            kwargs = self.config.get_qdrant_client_kwargs()
            self._qdrant_client = QdrantClient(**kwargs)
        return self._qdrant_client
    
    def get_admin_collections(self, admin_id: str) -> Dict[str, Any]:
        """
        Get all collections containing data for a specific admin.
        
        Args:
            admin_id: Admin ID
            
        Returns:
            Dictionary with admin's collections
            
        Raises:
            ValidationError: If admin_id is invalid
            QdrantError: If Qdrant operation fails
        """
        try:
            # Validate admin_id
            if not admin_id or not admin_id.strip():
                raise ValidationError("admin_id is required")
            
            # Get all collections
            collections = self.qdrant_client.get_collections().collections
            admin_collections = []
            
            # Check each collection for admin's data
            for col in collections:
                col_name = col.name
                
                try:
                    from qdrant_client.http.models import Filter, FieldCondition, MatchValue
                    
                    response = self.qdrant_client.scroll(
                        collection_name=col_name,
                        limit=1,
                        scroll_filter=Filter(
                            must=[
                                FieldCondition(
                                    key="admin_id",
                                    match=MatchValue(value=admin_id)
                                )
                            ]
                        ),
                    )
                    
                    points, _ = response
                    if points:
                        admin_collections.append(col_name)
                        
                except Exception:
                    # Collection might not have admin_id field or other error
                    continue
            
            return {
                "success": True,
                "admin_id": admin_id,
                "collections": admin_collections,
                "total_collections": len(collections),
                "admin_collections_count": len(admin_collections)
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise QdrantError(f"Failed to get admin collections: {str(e)}")
    
    def delete_admin_collection(
        self,
        admin_id: str,
        collection_name: str
    ) -> Dict[str, Any]:
        """
        Delete all vectors of an admin from a specific collection.
        
        Args:
            admin_id: Admin ID
            collection_name: Collection name
            
        Returns:
            Dictionary with deletion results
            
        Raises:
            ValidationError: If inputs are invalid
            QdrantError: If Qdrant operation fails
        """
        try:
            # Validate inputs
            if not admin_id or not admin_id.strip():
                raise ValidationError("admin_id is required")
            
            if not collection_name or not collection_name.strip():
                raise ValidationError("collection_name is required")
            
            # Check if collection exists
            existing = self.qdrant_client.get_collections().collections
            collection_names = [c.name for c in existing]
            
            if collection_name not in collection_names:
                raise ValidationError(f"Collection does not exist: {collection_name}")
            
            # Delete admin's vectors from collection
            from qdrant_client.http.models import Filter, FieldCondition, MatchValue
            
            self.qdrant_client.delete(
                collection_name=collection_name,
                points_selector=Filter(
                    must=[
                        FieldCondition(
                            key="admin_id",
                            match=MatchValue(value=admin_id)
                        )
                    ]
                ),
            )
            
            return {
                "success": True,
                "message": f"Admin {admin_id} data deleted from collection {collection_name}",
                "admin_id": admin_id,
                "collection_name": collection_name,
                "operation": "delete_vectors"
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise QdrantError(f"Failed to delete admin collection: {str(e)}")
    
    def delete_entire_collection(
        self,
        collection_name: str
    ) -> Dict[str, Any]:
        """
        Delete an entire collection.
        
        Args:
            collection_name: Collection name
            
        Returns:
            Dictionary with deletion results
            
        Raises:
            ValidationError: If collection_name is invalid
            QdrantError: If Qdrant operation fails
        """
        try:
            # Validate collection_name
            if not collection_name or not collection_name.strip():
                raise ValidationError("collection_name is required")
            
            # Delete collection
            self.qdrant_client.delete_collection(collection_name)
            
            return {
                "success": True,
                "message": f"Collection {collection_name} deleted",
                "collection_name": collection_name,
                "operation": "delete_collection"
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise QdrantError(f"Failed to delete collection: {str(e)}")
    
    def drop_all_collections(self) -> Dict[str, Any]:
        """
        Delete all collections (WARNING: destructive operation).
        
        Returns:
            Dictionary with deletion results
            
        Raises:
            QdrantError: If Qdrant operation fails
        """
        try:
            # Get all collections
            collections = self.qdrant_client.get_collections().collections
            
            if not collections:
                return {
                    "success": True,
                    "message": "No collections found",
                    "collections_deleted": [],
                    "count": 0
                }
            
            # Delete each collection
            deleted = []
            for col in collections:
                try:
                    self.qdrant_client.delete_collection(col.name)
                    deleted.append(col.name)
                except Exception:
                    continue
            
            return {
                "success": True,
                "message": f"Deleted {len(deleted)} collections",
                "collections_deleted": deleted,
                "total_collections": len(collections),
                "deleted_count": len(deleted),
                "failed_count": len(collections) - len(deleted)
            }
            
        except Exception as e:
            raise QdrantError(f"Failed to drop all collections: {str(e)}")
    
    def get_collection_info(
        self,
        collection_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get information about a collection or all collections.
        
        Args:
            collection_name: Optional specific collection name
            
        Returns:
            Dictionary with collection information
            
        Raises:
            QdrantError: If Qdrant operation fails
        """
        try:
            if collection_name:
                # Get specific collection info
                try:
                    info = self.qdrant_client.get_collection(collection_name)
                    
                    return {
                        "success": True,
                        "collection_name": collection_name,
                        "info": {
                            "vectors_count": info.vectors_count if hasattr(info, 'vectors_count') else 0,
                            "points_count": info.points_count if hasattr(info, 'points_count') else 0,
                            "segments_count": info.segments_count if hasattr(info, 'segments_count') else 0,
                            "config": info.config.dict() if hasattr(info, 'config') else {},
                            "payload_schema": info.payload_schema if hasattr(info, 'payload_schema') else {}
                        }
                    }
                except Exception as e:
                    raise ValidationError(f"Collection not found: {collection_name}")
            else:
                # Get all collections info
                collections = self.qdrant_client.get_collections().collections
                
                collections_info = []
                for col in collections:
                    try:
                        info = self.qdrant_client.get_collection(col.name)
                        collections_info.append({
                            "name": col.name,
                            "vectors_count": info.vectors_count if hasattr(info, 'vectors_count') else 0,
                            "points_count": info.points_count if hasattr(info, 'points_count') else 0,
                        })
                    except Exception:
                        collections_info.append({
                            "name": col.name,
                            "error": "Failed to get detailed info"
                        })
                
                return {
                    "success": True,
                    "collections": collections_info,
                    "total_collections": len(collections)
                }
            
        except ValidationError:
            raise
        except Exception as e:
            raise QdrantError(f"Failed to get collection info: {str(e)}")
    
    def search_similar(
        self,
        collection_name: str,
        query_vector: List[float],
        filter_conditions: Optional[Dict[str, Any]] = None,
        top_k: int = 10,
        with_payload: bool = True,
        with_vectors: bool = False
    ) -> Dict[str, Any]:
        """
        Search for similar vectors in a collection.
        
        Args:
            collection_name: Collection name
            query_vector: Query embedding vector
            filter_conditions: Optional filter conditions
            top_k: Number of results to return
            with_payload: Whether to include payload
            with_vectors: Whether to include vectors
            
        Returns:
            Dictionary with search results
            
        Raises:
            ValidationError: If inputs are invalid
            QdrantError: If search fails
        """
        try:
            # Validate inputs
            if not collection_name or not collection_name.strip():
                raise ValidationError("collection_name is required")
            
            if not query_vector:
                raise ValidationError("query_vector is required")
            
            # Build filter if provided
            qdrant_filter = None
            if filter_conditions:
                from qdrant_client.http.models import Filter, FieldCondition, MatchValue, Range
                
                must_conditions = []
                for key, value in filter_conditions.items():
                    if isinstance(value, dict):
                        # Range condition
                        if "gte" in value or "lte" in value:
                            range_params = {}
                            if "gte" in value:
                                range_params["gte"] = value["gte"]
                            if "lte" in value:
                                range_params["lte"] = value["lte"]
                            must_conditions.append(
                                FieldCondition(key=key, range=Range(**range_params))
                            )
                    else:
                        # Exact match condition
                        must_conditions.append(
                            FieldCondition(key=key, match=MatchValue(value=value))
                        )
                
                if must_conditions:
                    qdrant_filter = Filter(must=must_conditions)
            
            # Perform search
            results = self.qdrant_client.query_points(
                collection_name=collection_name,
                query=query_vector,
                query_filter=qdrant_filter,
                with_payload=with_payload,
                with_vectors=with_vectors,
                limit=top_k,
            )
            
            # Format results
            hits = []
            for r in results.points:
                hit = {
                    "id": r.id,
                    "score": r.score,
                    "payload": r.payload or {}
                }
                if with_vectors:
                    hit["vector"] = r.vector
                hits.append(hit)
            
            return {
                "success": True,
                "collection_name": collection_name,
                "query_vector_length": len(query_vector),
                "results": hits,
                "count": len(hits),
                "top_k": top_k
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise QdrantError(f"Failed to search similar vectors: {str(e)}")
    
    def count_points(
        self,
        collection_name: str,
        filter_conditions: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Count points in a collection with optional filters.
        
        Args:
            collection_name: Collection name
            filter_conditions: Optional filter conditions
            
        Returns:
            Dictionary with count results
            
        Raises:
            ValidationError: If collection_name is invalid
            QdrantError: If count operation fails
        """
        try:
            # Validate collection_name
            if not collection_name or not collection_name.strip():
                raise ValidationError("collection_name is required")
            
            # Build filter if provided
            qdrant_filter = None
            if filter_conditions:
                from qdrant_client.http.models import Filter, FieldCondition, MatchValue
                
                must_conditions = []
                for key, value in filter_conditions.items():
                    must_conditions.append(
                        FieldCondition(key=key, match=MatchValue(value=value))
                    )
                
                if must_conditions:
                    qdrant_filter = Filter(must=must_conditions)
            
            # Count points
            count = self.qdrant_client.count(
                collection_name=collection_name,
                count_filter=qdrant_filter
            )
            
            return {
                "success": True,
                "collection_name": collection_name,
                "count": count.count,
                "filtered": qdrant_filter is not None,
                "filter_conditions": filter_conditions or {}
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise QdrantError(f"Failed to count points: {str(e)}")
    
    def create_collection(
        self,
        collection_name: str,
        vector_size: int,
        distance: str = "Cosine"
    ) -> Dict[str, Any]:
        """
        Create a new collection.
        
        Args:
            collection_name: Collection name
            vector_size: Vector dimension size
            distance: Distance metric (Cosine, Euclidean, Dot)
            
        Returns:
            Dictionary with creation results
            
        Raises:
            ValidationError: If inputs are invalid
            QdrantError: If creation fails
        """
        try:
            # Validate inputs
            if not collection_name or not collection_name.strip():
                raise ValidationError("collection_name is required")
            
            if vector_size <= 0:
                raise ValidationError("vector_size must be positive")
            
            valid_distances = ["Cosine", "Euclidean", "Dot"]
            if distance not in valid_distances:
                raise ValidationError(f"distance must be one of {valid_distances}")
            
            # Create collection
            from qdrant_client.http.models import VectorParams, Distance
            
            distance_map = {
                "Cosine": Distance.COSINE,
                "Euclidean": Distance.EUCLID,
                "Dot": Distance.DOT
            }
            
            self.qdrant_client.create_collection(
                collection_name=collection_name,
                vectors_config=VectorParams(
                    size=vector_size,
                    distance=distance_map[distance]
                )
            )
            
            return {
                "success": True,
                "message": f"Collection {collection_name} created",
                "collection_name": collection_name,
                "vector_size": vector_size,
                "distance": distance
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise QdrantError(f"Failed to create collection: {str(e)}")