import re
from typing import Dict, Any, List, Optional
from datetime import datetime
from bson import ObjectId

from ..config.settings import SDKConfig
from ..utils.hash import hash_password, verify_password
from ..utils.jwt_handler import create_access_token, create_refresh_token
from ..exceptions import (
    ValidationError,
    AuthenticationError,
    NotFoundError,
    DatabaseError,
    ServiceError
)


class UserService:
    """User-related business logic"""
    
    def __init__(self, config: SDKConfig):
        self.config = config
        self._mongo_client = None
        self._db = None
        self._user_collection = None
        self._links_collection = None
        self._mcq_collection = None
        self._results_collection = None
        
        # Initialize RAG service for context retrieval
        from .rag_service import RAGService
        self.rag_service = RAGService(config)
    
    @property
    def db(self):
        """Lazy initialization of MongoDB connection"""
        if self._db is None:
            from pymongo import MongoClient
            self._mongo_client = MongoClient(self.config.mongo_uri)
            self._db = self._mongo_client[self.config.db_name]
            self._user_collection = self._db["users"]
            self._links_collection = self._db["mobile_file_links"]
            self._mcq_collection = self._db["mcqs"]
            self._results_collection = self._db["results"]
        return self._db
    
    @property
    def user_collection(self):
        if self._user_collection is None:
            self.db
        return self._user_collection
    
    @property
    def links_collection(self):
        if self._links_collection is None:
            self.db
        return self._links_collection
    
    @property
    def mcq_collection(self):
        if self._mcq_collection is None:
            self.db
        return self._mcq_collection
    
    @property
    def results_collection(self):
        if self._results_collection is None:
            self.db
        return self._results_collection
    
    async def register_user(self, phone: str, password: str) -> Dict[str, Any]:
        """
        Register a new user.
        
        Args:
            phone: User phone number
            password: Plain text password
            
        Returns:
            Dictionary with registration result
            
        Raises:
            ValidationError: If user already exists or invalid input
            DatabaseError: If database operation fails
        """
        try:
            # Validate phone format
            if not re.match(r'^\+?[1-9]\d{9,14}$', phone):
                raise ValidationError("Invalid phone number format")
            
            # Check if user exists
            existing = self.user_collection.find_one({"phone": phone})
            if existing:
                raise ValidationError("User already exists")
            
            # Hash password
            hashed = hash_password(password)
            session_id = str(ObjectId())
            
            # Create user document
            data = {
                "phone": phone,
                "password": hashed,
                "role": "user",
                "active_session_id": session_id,
                "active_device_id": None,
                "active_fcm_token": None,
                "created_at": datetime.utcnow(),
            }
            
            # Insert into database
            result = self.user_collection.insert_one(data)
            
            # Create tokens
            token_data = {
                "user_id": str(result.inserted_id),
                "role": "user",
                "phone": phone,
                "session_id": session_id,
            }
            
            access_token = create_access_token(token_data)
            refresh_token = create_refresh_token(token_data)
            
            return {
                "success": True,
                "message": "User registered successfully",
                "user_id": str(result.inserted_id),
                "session_id": session_id,
                "access_token": access_token,
                "refresh_token": refresh_token,
                "token_type": "bearer",
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to register user: {str(e)}")
    
    async def login_user(self, phone: str, password: str, fcm_token: Optional[str] = None) -> Dict[str, Any]:
        """
        Login user.
        
        Args:
            phone: User phone number
            password: Plain text password
            fcm_token: Optional Firebase Cloud Messaging token
            
        Returns:
            Dictionary with login result
            
        Raises:
            AuthenticationError: If credentials are invalid
            DatabaseError: If database operation fails
        """
        try:
            # Find user
            user = self.user_collection.find_one({"phone": phone})
            if not user:
                raise AuthenticationError("Invalid phone or password")
            
            # Verify password
            if not verify_password(password, user["password"]):
                raise AuthenticationError("Invalid phone or password")
            
            # Handle force logout for previous session
            old_fcm = user.get("active_fcm_token")
            if user.get("active_session_id") and old_fcm and fcm_token:
                try:
                    from .firebase_service import FirebaseService
                    firebase_service = FirebaseService(self.config)
                    firebase_service.send_force_logout_notification(old_fcm)
                except Exception:
                    pass  # Continue even if FCM fails
            
            # Create new session
            new_session_id = str(ObjectId())
            
            # Create tokens
            token_data = {
                "user_id": str(user["_id"]),
                "phone": phone,
                "role": user.get("role", "user"),
                "session_id": new_session_id,
            }
            
            access_token = create_access_token(token_data)
            refresh_token = create_refresh_token(token_data)
            
            # Update user session
            self.user_collection.update_one(
                {"_id": user["_id"]},
                {
                    "$set": {
                        "active_session_id": new_session_id,
                        "active_device_id": None,
                        "active_fcm_token": fcm_token,
                        "last_login_at": datetime.utcnow(),
                    }
                },
            )
            
            # Get linked files
            link_docs = list(self.links_collection.find({"mobile": phone}))
            linked_file_ids = list({item["file_id"] for item in link_docs})
            
            return {
                "success": True,
                "message": "Login successful",
                "access_token": access_token,
                "refresh_token": refresh_token,
                "linked_file_ids": linked_file_ids,
                "mcqs_by_file": {},
                "user_id": str(user["_id"]),
                "session_id": new_session_id,
            }
            
        except AuthenticationError:
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to login user: {str(e)}")
    
    async def get_all_users(self) -> Dict[str, Any]:
        """
        Get all users (without passwords).
        
        Returns:
            Dictionary with users list
            
        Raises:
            DatabaseError: If database operation fails
        """
        try:
            docs = list(self.user_collection.find({}, {"password": 0}))
            
            users = []
            for u in docs:
                users.append({
                    "user_id": str(u["_id"]),
                    "phone": u["phone"],
                    "role": u.get("role", "user"),
                    "created_at": u.get("created_at"),
                })
            
            return {
                "success": True,
                "users": users,
                "count": len(users)
            }
            
        except Exception as e:
            raise DatabaseError(f"Failed to get users: {str(e)}")
    
    async def get_user_by_id(self, user_id: str) -> Dict[str, Any]:
        """
        Get user by ID.
        
        Args:
            user_id: User ID
            
        Returns:
            User document
            
        Raises:
            NotFoundError: If user not found
            DatabaseError: If database operation fails
        """
        try:
            user = self.user_collection.find_one({"_id": ObjectId(user_id)}, {"password": 0})
            if not user:
                raise NotFoundError(f"User not found: {user_id}")
            
            user["_id"] = str(user["_id"])
            return user
            
        except NotFoundError:
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to get user: {str(e)}")
    
    async def link_mobile_to_file(self, admin_id: str, mobile: str, file_id: str) -> Dict[str, Any]:
        """
        Link a mobile number to a file.
        
        Args:
            admin_id: Admin ID
            mobile: Mobile number
            file_id: File ID
            
        Returns:
            Dictionary with operation result
            
        Raises:
            ValidationError: If link already exists
            DatabaseError: If database operation fails
        """
        try:
            # Check if link already exists
            existing = self.links_collection.find_one({
                "mobile": mobile,
                "file_id": file_id
            })
            
            if existing:
                raise ValidationError("Mobile already linked to this file")
            
            # Create link document
            link_data = {
                "admin_id": admin_id,
                "mobile": mobile,
                "file_id": file_id,
                "linked_at": datetime.utcnow(),
            }
            
            result = self.links_collection.insert_one(link_data)
            
            return {
                "success": True,
                "message": "Mobile linked to file successfully",
                "link_id": str(result.inserted_id),
                "mobile": mobile,
                "file_id": file_id,
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to link mobile to file: {str(e)}")
    
    async def get_linked_files(self, mobile: str) -> Dict[str, Any]:
        """
        Get files linked to a mobile number.
        
        Args:
            mobile: Mobile number
            
        Returns:
            Dictionary with linked files
            
        Raises:
            DatabaseError: If database operation fails
        """
        try:
            links = list(self.links_collection.find({"mobile": mobile}))
            
            files = []
            for link in links:
                files.append({
                    "file_id": link["file_id"],
                    "admin_id": link.get("admin_id"),
                    "linked_at": link.get("linked_at"),
                })
            
            return {
                "success": True,
                "mobile": mobile,
                "files": files,
                "count": len(files)
            }
            
        except Exception as e:
            raise DatabaseError(f"Failed to get linked files: {str(e)}")
    
    async def generate_mcqs_for_user(
        self,
        user_id: str,
        query: str,
        file_id: str,
        top_k: int = 1,
        num_choices: int = 4,
        difficulty: str = "medium"
    ) -> Dict[str, Any]:
        """
        Generate MCQs for a user.
        
        Args:
            user_id: User ID
            query: Search query
            file_id: File ID
            top_k: Number of questions to generate
            num_choices: Number of choices per question
            difficulty: Difficulty level
            
        Returns:
            Dictionary with generated MCQs
            
        Raises:
            ValidationError: If input is invalid
            ServiceError: If generation fails
        """
        try:
            # Validate user_id
            try:
                uid = ObjectId(user_id)
            except:
                raise ValidationError("Invalid user_id")
            
            # Use RAG service to generate MCQs
            mcq_service = self.rag_service  # RAGService has MCQ generation
            
            result = mcq_service.generate_mcqs(
                query=query,
                admin_id=user_id,  # Using user_id as admin_id for context
                file_id=file_id,
                top_k=top_k,
                num_choices=num_choices,
                difficulty=difficulty
            )
            
            # Store in user's MCQ collection
            document = {
                "created_by": uid,
                "file_id": file_id,
                "query": query,
                "difficulty": difficulty,
                "mcqs": result["mcqs"],
                "created_at": datetime.utcnow(),
            }
            
            result_db = self.mcq_collection.insert_one(document)
            
            return {
                "success": True,
                "mcq_doc_id": str(result_db.inserted_id),
                "file_id": file_id,
                "mcqs": result["mcqs"],
                "difficulty": difficulty,
            }
            
        except Exception as e:
            raise ServiceError(f"Failed to generate MCQs: {str(e)}")
    
    async def store_mcq_results(
        self,
        user_id: str,
        mcq_id: str,
        responses: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Store MCQ results for a user.
        
        Args:
            user_id: User ID
            mcq_id: MCQ document ID
            responses: List of user responses
            
        Returns:
            Dictionary with results summary
            
        Raises:
            NotFoundError: If MCQ not found
            ValidationError: If input is invalid
            DatabaseError: If database operation fails
        """
        try:
            # Validate mcq_id
            try:
                mcq_obj = ObjectId(mcq_id)
            except:
                raise ValidationError("Invalid mcq_id")
            
            # Get MCQ document
            mcq_doc = self.mcq_collection.find_one({"_id": mcq_obj})
            if not mcq_doc:
                raise NotFoundError("MCQ not found")
            
            # Process responses
            processed = []
            correct_count = 0
            total = len(responses)
            
            def extract_letter(value: str) -> str:
                if not value:
                    return ""
                return value.split(".", 1)[0].strip().upper()
            
            for item in responses:
                question = item.get("question", "").strip()
                selected = item.get("selected_answer", "").strip()
                
                # Find correct answer
                correct = None
                for m in mcq_doc.get("mcqs", []):
                    if m.get("question", "").strip() == question:
                        answer_label = m.get("answer_label", "")
                        options = m.get("options", {})
                        if answer_label and answer_label in options:
                            correct = f"{answer_label}. {options[answer_label]}"
                        break
                
                # Check if correct
                is_correct = False
                if selected and correct:
                    is_correct = extract_letter(selected) == extract_letter(correct)
                    if is_correct:
                        correct_count += 1
                
                processed.append({
                    "question": question,
                    "selected_answer": selected,
                    "correct_answer": correct,
                    "status": is_correct,
                })
            
            # Calculate score
            score_percent = round((correct_count / total) * 100, 2) if total > 0 else 0.0
            
            # Store results
            result_doc = {
                "userId": user_id,
                "mcqId": mcq_id,
                "submitted_at": datetime.utcnow(),
                "results": processed,
                "score_percent": score_percent,
                "correct_count": correct_count,
                "total_questions": total,
            }
            
            result_id = self.results_collection.insert_one(result_doc).inserted_id
            
            return {
                "success": True,
                "result_id": str(result_id),
                "summary": {
                    "user_id": user_id,
                    "mcq_id": mcq_id,
                    "total_questions": total,
                    "correct_count": correct_count,
                    "score_percent": score_percent,
                }
            }
            
        except (NotFoundError, ValidationError):
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to store MCQ results: {str(e)}")
    
    async def get_user_results(self, user_id: str) -> Dict[str, Any]:
        """
        Get all MCQ results for a user.
        
        Args:
            user_id: User ID
            
        Returns:
            Dictionary with user results
            
        Raises:
            DatabaseError: If database operation fails
        """
        try:
            docs = list(self.results_collection.find({"userId": user_id}))
            
            results = []
            for doc in docs:
                doc["_id"] = str(doc["_id"])
                if isinstance(doc.get("mcqId"), ObjectId):
                    doc["mcqId"] = str(doc["mcqId"])
                results.append(doc)
            
            return {
                "success": True,
                "user_id": user_id,
                "results": results,
                "count": len(results)
            }
            
        except Exception as e:
            raise DatabaseError(f"Failed to get user results: {str(e)}")
    
    async def get_mcqs_for_user(self, user_id: str) -> Dict[str, Any]:
        """
        Get all MCQs generated for a user.
        
        Args:
            user_id: User ID
            
        Returns:
            Dictionary with user MCQs
            
        Raises:
            DatabaseError: If database operation fails
        """
        try:
            uid = ObjectId(user_id)
            docs = list(self.mcq_collection.find({"created_by": uid}))
            
            mcqs = []
            for doc in docs:
                for m in doc.get("mcqs", []):
                    mcqs.append({
                        "mcq_doc_id": str(doc["_id"]),
                        "question": m.get("question"),
                        "options": m.get("options", {}),
                        "answer_label": m.get("answer_label"),
                        "answer": m.get("answer"),
                        "file_id": doc.get("file_id"),
                        "query": doc.get("query"),
                        "created_at": doc.get("created_at"),
                    })
            
            return {
                "success": True,
                "total": len(mcqs),
                "mcqs": mcqs
            }
            
        except Exception as e:
            raise DatabaseError(f"Failed to get user MCQs: {str(e)}")
    
    def close(self):
        """Close database connections"""
        if self._mongo_client:
            self._mongo_client.close()
            self._mongo_client = None
            self._db = None
            self._user_collection = None
            self._links_collection = None
            self._mcq_collection = None
            self._results_collection = None