from typing import Dict, Any, List, Optional
from datetime import datetime

from ..config.settings import SDKConfig
from ..exceptions import DatabaseError, ValidationError


class ChatService:
    """Chat history business logic"""
    
    def __init__(self, config: SDKConfig):
        self.config = config
        self._mongo_client = None
        self._db = None
        self._chat_collection = None
    
    @property
    def db(self):
        """Lazy initialization of MongoDB connection"""
        if self._db is None:
            from pymongo import MongoClient
            self._mongo_client = MongoClient(self.config.mongo_uri)
            self._db = self._mongo_client[self.config.db_name]
            self._chat_collection = self._db["chat_history"]
        return self._db
    
    @property
    def chat_collection(self):
        if self._chat_collection is None:
            self.db
        return self._chat_collection
    
    def save_message(
        self,
        user_id: str,
        role: str,
        message: str,
        document_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Save a chat message.
        
        Args:
            user_id: User ID
            role: Message role ("user" or "assistant")
            message: Message text
            document_id: Optional document ID
            
        Returns:
            Dictionary with operation result
            
        Raises:
            ValidationError: If input is invalid
            DatabaseError: If database operation fails
        """
        try:
            # Validate inputs
            if not user_id or not user_id.strip():
                raise ValidationError("user_id is required")
            
            if role not in ["user", "assistant"]:
                raise ValidationError("role must be 'user' or 'assistant'")
            
            if not message or not message.strip():
                raise ValidationError("message cannot be empty")
            
            # Create message document
            message_doc = {
                "user_id": user_id,
                "role": role,
                "message": message,
                "document_id": document_id,
                "timestamp": datetime.utcnow()
            }
            
            # Insert into database
            result = self.chat_collection.insert_one(message_doc)
            
            # Convert ObjectId to string for response
            message_doc["_id"] = str(result.inserted_id)
            
            return {
                "success": True,
                "message": "Message saved successfully",
                "chat_id": str(result.inserted_id),
                "data": message_doc
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to save message: {str(e)}")
    
    def get_chat_history(
        self,
        user_id: str,
        limit: Optional[int] = None,
        offset: int = 0
    ) -> Dict[str, Any]:
        """
        Get chat history for a user.
        
        Args:
            user_id: User ID
            limit: Maximum number of messages to return
            offset: Number of messages to skip
            
        Returns:
            Dictionary with chat history
            
        Raises:
            ValidationError: If user_id is invalid
            DatabaseError: If database operation fails
        """
        try:
            # Validate user_id
            if not user_id or not user_id.strip():
                raise ValidationError("user_id is required")
            
            # Build query
            query = {"user_id": user_id}
            
            # Get total count
            total_count = self.chat_collection.count_documents(query)
            
            # Build cursor with sorting
            cursor = self.chat_collection.find(query).sort("timestamp", 1)
            
            # Apply offset and limit
            if offset > 0:
                cursor = cursor.skip(offset)
            
            if limit:
                cursor = cursor.limit(limit)
            
            # Convert to list and serialize
            messages = []
            for msg in cursor:
                msg["_id"] = str(msg["_id"])
                messages.append(msg)
            
            return {
                "success": True,
                "user_id": user_id,
                "history": messages,
                "total_count": total_count,
                "returned_count": len(messages),
                "offset": offset,
                "limit": limit
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to get chat history: {str(e)}")
    
    def get_all_chat_history(
        self,
        limit: Optional[int] = None,
        offset: int = 0
    ) -> Dict[str, Any]:
        """
        Get chat history of all users (admin view).
        
        Args:
            limit: Maximum number of user groups to return
            offset: Number of user groups to skip
            
        Returns:
            Dictionary with all chat history grouped by user
            
        Raises:
            DatabaseError: If database operation fails
        """
        try:
            # Aggregation pipeline to group by user
            pipeline = [
                {"$sort": {"timestamp": 1}},
                {"$group": {
                    "_id": "$user_id",
                    "messages": {
                        "$push": {
                            "_id": "$_id",
                            "role": "$role",
                            "message": "$message",
                            "document_id": "$document_id",
                            "timestamp": "$timestamp"
                        }
                    },
                    "message_count": {"$sum": 1}
                }},
                {"$sort": {"message_count": -1}}
            ]
            
            # Apply offset and limit
            if offset > 0:
                pipeline.append({"$skip": offset})
            
            if limit:
                pipeline.append({"$limit": limit})
            
            # Execute aggregation
            results = []
            for row in self.chat_collection.aggregate(pipeline):
                # Convert ObjectId to string inside messages
                for msg in row["messages"]:
                    msg["_id"] = str(msg["_id"])
                
                results.append({
                    "user_id": row["_id"],
                    "message_count": row["message_count"],
                    "messages": row["messages"]
                })
            
            # Get total user count
            total_users = len(self.chat_collection.distinct("user_id"))
            
            return {
                "success": True,
                "users": results,
                "total_users": total_users,
                "returned_users": len(results),
                "offset": offset,
                "limit": limit
            }
            
        except Exception as e:
            raise DatabaseError(f"Failed to get all chat history: {str(e)}")
    
    def clear_chat_history(
        self,
        user_id: str
    ) -> Dict[str, Any]:
        """
        Clear chat history for a user.
        
        Args:
            user_id: User ID
            
        Returns:
            Dictionary with operation result
            
        Raises:
            ValidationError: If user_id is invalid
            DatabaseError: If database operation fails
        """
        try:
            # Validate user_id
            if not user_id or not user_id.strip():
                raise ValidationError("user_id is required")
            
            # Delete messages
            result = self.chat_collection.delete_many({"user_id": user_id})
            
            return {
                "success": True,
                "message": f"Cleared {result.deleted_count} messages for user {user_id}",
                "user_id": user_id,
                "deleted_count": result.deleted_count
            }
            
        except ValidationError:
            raise
        except Exception as e:
            raise DatabaseError(f"Failed to clear chat history: {str(e)}")
    
    def search_chat_messages(
        self,
        user_id: Optional[str] = None,
        query: Optional[str] = None,
        role: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: int = 100
    ) -> Dict[str, Any]:
        """
        Search chat messages with filters.
        
        Args:
            user_id: Optional user ID filter
            query: Optional text search query
            role: Optional role filter
            start_date: Optional start date filter
            end_date: Optional end date filter
            limit: Maximum results to return
            
        Returns:
            Dictionary with search results
            
        Raises:
            DatabaseError: If database operation fails
        """
        try:
            # Build query
            mongo_query = {}
            
            if user_id:
                mongo_query["user_id"] = user_id
            
            if role:
                mongo_query["role"] = role
            
            if start_date or end_date:
                date_filter = {}
                if start_date:
                    date_filter["$gte"] = start_date
                if end_date:
                    date_filter["$lte"] = end_date
                mongo_query["timestamp"] = date_filter
            
            # Text search if query provided
            if query:
                mongo_query["$text"] = {"$search": query}
                # Ensure text index exists
                try:
                    self.chat_collection.create_index([("message", "text")])
                except:
                    pass
            
            # Execute query
            cursor = self.chat_collection.find(mongo_query).sort("timestamp", -1).limit(limit)
            
            # Convert to list and serialize
            messages = []
            for msg in cursor:
                msg["_id"] = str(msg["_id"])
                messages.append(msg)
            
            return {
                "success": True,
                "query": mongo_query,
                "results": messages,
                "count": len(messages),
                "limit": limit
            }
            
        except Exception as e:
            raise DatabaseError(f"Failed to search chat messages: {str(e)}")
    
    def close(self):
        """Close database connections"""
        if self._mongo_client:
            self._mongo_client.close()
            self._mongo_client = None
            self._db = None
            self._chat_collection = None