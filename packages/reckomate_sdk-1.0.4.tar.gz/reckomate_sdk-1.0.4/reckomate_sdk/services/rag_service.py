
# rag_unified.py
import os
import re
import time
import json
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime

from dotenv import load_dotenv

# Embeddings
from sentence_transformers import SentenceTransformer

# Qdrant
from qdrant_client import QdrantClient
from qdrant_client.http.models import (
    Filter,
    FieldCondition,
    MatchValue,
    VectorParams,
    Distance,
    PayloadSchemaType,
)
from qdrant_client.http.exceptions import UnexpectedResponse

# Mongo (synchronous)
from bson import ObjectId
from pymongo import MongoClient

# OpenAI
from openai import OpenAI
from fastapi import HTTPException

# WebSocket manager (ADDED)
from app.websocket.connection_manager import manager

# ---------------------------------------------------------
# Load ENV
# ---------------------------------------------------------
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise Exception("OPENAI_API_KEY missing in .env")

# OpenAI models via env (with defaults)
OPENAI_MODEL_FAST = os.getenv("OPENAI_MODEL_FAST", "gpt-4o-mini")
OPENAI_MODEL_STRICT = os.getenv("OPENAI_MODEL_STRICT", "gpt-4o")

openai_client = OpenAI(api_key=OPENAI_API_KEY)

# ---------------------------------------------------------
# Global Clients (Shared)
# ---------------------------------------------------------
EMBED_MODEL = os.getenv("EMBED_MODEL", "all-MiniLM-L6-v2")
encoder = SentenceTransformer(EMBED_MODEL)

QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333").strip()
QDRANT_API_KEY = os.getenv("QDRANT_API_KEY", "").strip()
# Support both QDRANT_COLLECTION and QDRANT_COLLECTION_NAME
COLLECTION_NAME = (
    os.getenv("QDRANT_COLLECTION")
    or os.getenv("QDRANT_COLLECTION_NAME")
    or "test-02"
).strip()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/").strip()
DB_NAME = os.getenv("DB_NAME", "rekomate").strip()

qdrant = QdrantClient(
    url=QDRANT_URL,
    api_key=QDRANT_API_KEY or None,
    check_compatibility=False,
)
mongo_client = MongoClient(MONGO_URI)
db_rekomate = mongo_client.get_database(DB_NAME)


# -------------------------------------------
# WebSocket helper (ADDED)
# -------------------------------------------
def send_ws(user_id: str, progress: int, message: str):
    """
    Best-effort non-blocking WebSocket progress notification.
    Schedules manager.send_progress(...) as an asyncio task.
    user_id: typically user/admin id or file_id depending on context.
    """
    try:
        import asyncio

        # manager.send_progress is async — schedule it
        try:
            asyncio.create_task(manager.send_progress(user_id, progress, message))
        except RuntimeError:
            # If no running loop, try getting running loop and create task
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(manager.send_progress(user_id, progress, message))
    except Exception:
        # best-effort; ignore scheduling errors
        pass


# ---------------------------------------------------------
# Ensure Qdrant Collection + Indexes Exist
# ---------------------------------------------------------
def ensure_collection_exists() -> bool:
    try:
        dim = encoder.get_sentence_embedding_dimension()

        # Check if collection exists
        try:
            info = qdrant.get_collection(COLLECTION_NAME)
        except UnexpectedResponse:
            # Create collection if not exists
            qdrant.create_collection(
                collection_name=COLLECTION_NAME,
                vectors_config=VectorParams(size=dim, distance=Distance.COSINE),
            )
            info = qdrant.get_collection(COLLECTION_NAME)

        # Ensure payload indexes for filters (admin_id, file_id, user_id)
        schema = getattr(info, "payload_schema", None) or {}
        for field in ("admin_id", "file_id", "user_id"):
            if field not in schema:
                try:
                    qdrant.create_payload_index(
                        collection_name=COLLECTION_NAME,
                        field_name=field,
                        field_schema=PayloadSchemaType.KEYWORD,
                    )
                except Exception as e:
                    print(f"[ensure_collection_exists] Index create error for {field}: {e}")

        return True
    except Exception as e:
        print(f"[ensure_collection_exists] ERROR: {e}")
        return False


# ---------------------------------------------------------
# Query Rewriter
# ---------------------------------------------------------
def rewrite_query(user_query: str) -> str:
    base = user_query.strip()
    lower = base.lower()

    if len(base.split()) <= 2:
        prompt = f"""
Rewrite and expand this search query to improve semantic search:
Query: "{user_query}"

Rules:
- Add synonyms
- Add related details
- Expand to 10–20 words
- Only return the improved query
"""
    else:
        prompt = f"""
Improve this search query for semantic vector search:
Original: "{user_query}"
Rules:
- Fix spelling
- Add close synonyms
- Only return the improved query
"""

    if any(
        w in lower
        for w in [
            "radiation",
            "greenhouse",
            "climate",
            "atmosphere",
            "global warming",
        ]
    ):
        prompt += """
Ensure improved query includes:
- solar radiation
- infrared radiation
- greenhouse effect
- atmospheric absorption
"""

    try:
        resp = openai_client.chat.completions.create(
            model=OPENAI_MODEL_FAST,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.4,
            timeout=15,
        )
        out = resp.choices[0].message.content.strip()
        return out or user_query
    except Exception:
        return user_query


# ---------------------------------------------------------
# Qdrant helpers
# ---------------------------------------------------------
def retrieve_chunks_for_document(
    query_vector: List[float], file_id: str, top_k: int = 15
):
    if not ensure_collection_exists():
        return []

    results = qdrant.query_points(
        collection_name=COLLECTION_NAME,
        query=query_vector,
        query_filter=Filter(
            must=[FieldCondition(key="file_id", match=MatchValue(value=file_id))]
        ),
        with_payload=True,
        with_vectors=False,
        limit=top_k,
    )

    hits = []
    for r in results.points:
        payload = r.payload or {}
        hits.append(
            (payload.get("text", ""), r.score, payload.get("filename", "unknown"))
        )
    return hits


def retrieve_chunks_global(query_vector: List[float], top_k: int = 15):
    if not ensure_collection_exists():
        return []

    results = qdrant.query_points(
        collection_name=COLLECTION_NAME,
        query=query_vector,
        with_payload=True,
        with_vectors=False,
        limit=top_k,
    )

    hits = []
    for r in results.points:
        payload = r.payload or {}
        hits.append(
            (payload.get("text", ""), r.score, payload.get("filename", "unknown"))
        )
    return hits


# ----------------------------------
# EASY MODE
# ----------------------------------
def answer_query_easy(
    query: str,
    file_id: str,
    top_k: int = 15,
) -> Tuple[str, List[str]]:
    try:
        import asyncio
        try:
            from app.websocket.connection_manager import manager as _ws_manager
        except Exception:
            _ws_manager = None

        def send_ws_local(progress: int, message: str):
            if _ws_manager:
                try:
                    asyncio.create_task(_ws_manager.send_progress(file_id, progress, message))
                except Exception:
                    pass

        # WS: start
        send_ws_local(5, "Easy-mode query received")

        print(f"[EASY] Query: '{query}' for file_id={file_id}")

        improved_query = rewrite_query(query)
        # WS: after rewrite
        send_ws_local(15, "Query improved for semantic search")

        query_vec = encoder.encode(improved_query).tolist()

        # WS: before retrieval
        send_ws_local(20, "Retrieving relevant chunks")

        retrieved = retrieve_chunks_for_document(query_vec, file_id, top_k)

        if not retrieved:
            # WS: nothing found
            send_ws_local(100, "Not found in this document.")
            return "Not found in this document.", []

        # WS: retrieved context
        send_ws_local(30, f"Retrieved {len(retrieved)} chunks")

        context_parts: List[str] = []
        source_files: set[str] = set()
        total_text_len = 0

        for chunk, score, filename in retrieved:
            context_parts.append(
                f"[File: {filename} | Score: {score:.3f}]\n{chunk}"
            )
            source_files.add(filename)
            total_text_len += len(chunk)

        context = "\n\n-----\n\n".join(context_parts)
        context = context[:8000]

        is_tiny_context = total_text_len < 600

        guidance = """
You are answering ONLY from the content of this single document.
If the context is clearly about a completely different topic than the question,
you MUST answer exactly:
"Not found in this document."
"""

        if is_tiny_context:
            guidance += """
The context is short (e.g. a diagram or small note).
If it is clearly related to the question's topic,
you may infer a brief answer using your general knowledge,
as long as it is consistent with the context.
"""

        prompt = f"""
{guidance}

CONTEXT (from file_id = {file_id}):
{context}

QUESTION:
{query}

Respond in 2–3 concise lines. Do NOT exceed 3 lines.
If unrelated, reply exactly:
"Not found in this document."
"""

        # WS: calling OpenAI
        send_ws_local(45, "Sending prompt to model")

        resp = openai_client.chat.completions.create(
            model=OPENAI_MODEL_FAST,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
        )

        answer = resp.choices[0].message.content.strip()
        print(f"[EASY] Answer: {answer}")

        # WS: done
        send_ws_local(100, "Easy-mode answer ready")

        return answer, list(source_files)

    except Exception as e:
        try:
            # best-effort WS error notification
            import asyncio
            from app.websocket.connection_manager import manager as _ws_manager_err
            asyncio.create_task(_ws_manager_err.send_progress(file_id, 100, f"Easy-mode error: {str(e)}"))
        except Exception:
            pass
        print(f"answer_query_easy error: {e}")
        return "Something went wrong while generating answer.", []


# ---------------------------------------------------------
# INTELLIGENT MODE RAG
# ---------------------------------------------------------
def answer_query_intelligent(query: str, file_id: str, top_k: int = 20):
    import asyncio
    try:
        from app.websocket.connection_manager import manager as _ws_manager
    except Exception:
        _ws_manager = None

    def send_ws_local(progress: int, message: str):
        if _ws_manager:
            try:
                asyncio.create_task(_ws_manager.send_progress(file_id, progress, message))
            except:
                pass

    # WS: start
    send_ws_local(5, "Intelligent-mode query received")

    improved = rewrite_query(query)
    send_ws_local(15, "Query rewritten for deep semantic search")

    query_vec = encoder.encode(improved).tolist()

    send_ws_local(25, "Retrieving high-relevance chunks")

    retrieved = retrieve_chunks_for_document(query_vec, file_id, top_k)
    if not retrieved:
        send_ws_local(100, "No relevant content found")
        return "Not found in this document.", []

    send_ws_local(40, f"Retrieved {len(retrieved)} context chunks")

    context_blocks = []
    files = set()
    total_len = 0

    for chunk, score, filename in retrieved:
        context_blocks.append(f"[File: {filename} | Score: {score:.3f}]\n{chunk}")
        files.add(filename)
        total_len += len(chunk)

    context = "\n\n-----\n\n".join(context_blocks)[:15000]

    relevance_prompt = f"""
Check if question matches the context topic.

CONTEXT:
{context}

QUESTION:
{query}

Reply ONLY: RELATED or UNRELATED.
"""

    send_ws_local(55, "Checking contextual relevance")

    relevance_resp = openai_client.chat.completions.create(
        model=OPENAI_MODEL_FAST,
        messages=[{"role": "user", "content": relevance_prompt}],
        temperature=0,
        timeout=15,
    )

    if "UNRELATED" in relevance_resp.choices[0].message.content.upper():
        send_ws_local(100, "Context unrelated — no answer found")
        return "Not found in this document.", list(files)

    prompt = f"""
You may use general knowledge ONLY if it aligns with this context.

CONTEXT:
{context}

QUESTION:
{query}

Write a long, detailed explanation.
"""

    send_ws_local(75, "Generating detailed intelligent answer")

    resp = openai_client.chat.completions.create(
        model=OPENAI_MODEL_FAST,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
        timeout=30,
    )

    answer = resp.choices[0].message.content.strip()

    send_ws_local(100, "Intelligent-mode answer ready")

    return answer, list(files)


# ---------------------------------------------------------
# RAGService Class
# ---------------------------------------------------------
class RAGService:
    """
    Unified service class using shared RAG utilities.
    """

    def __init__(self):
        self.client = qdrant
        self.collection_name = COLLECTION_NAME
        self.db = db_rekomate
        self.correct_answers = {}

        # Audio quiz session store (for /audioQuiz/start, /audioQuiz/answer)
        self.active_audio_sessions: Dict[str, Dict[str, Any]] = {}

        # Ensure collection + payload indexes exist
        ensure_collection_exists()

    # -----------------------------
    # Admin Qdrant Search
    # -----------------------------
    def search(
        self,
        query_vector: List[float],
        admin_id: str,
        file_id: Optional[str] = None,
        top_k: int = 1,
    ):
        # WS: notify search started for admin
        send_ws(admin_id, 5, "Qdrant search started")

        must = [FieldCondition(key="admin_id", match=MatchValue(value=admin_id))]
        if file_id:
            must.append(FieldCondition(key="file_id", match=MatchValue(value=file_id)))

        results = self.client.query_points(
            collection_name=self.collection_name,
            query=query_vector,
            query_filter=Filter(must=must),
            with_payload=True,
            with_vectors=False,
            limit=top_k,
        )

        hits = []
        for r in results.points:
            payload = r.payload or {}
            hits.append(
                {
                    "id": r.id,
                    "score": r.score,
                    "text": payload.get("text"),
                    "filename": payload.get("filename"),
                    "admin_id": payload.get("admin_id"),
                    "file_id": payload.get("file_id"),
                }
            )

        send_ws(admin_id, 100, "Qdrant search completed")
        return hits

    def retrieve_by_text(
        self, embedding_model, text, admin_id, file_id=None, top_k=1
    ):
        # WS: notify retrieval by text
        send_ws(admin_id, 10, "Retrieval by text started")
        vec = embedding_model.encode([text])[0]
        results = self.search(vec, admin_id, file_id, top_k)
        send_ws(admin_id, 100, "Retrieval by text completed")
        return results

    # -----------------------------
    # USER-SIDE CONTEXT (user_id + file_id)
    # -----------------------------
    def get_context_for_user_file(
        self,
        user_id: str,
        file_id: str,
        top_k: int = 10,
    ) -> List[str]:
        """
        Retrieve raw text chunks for a given user_id + file_id.
        Used as context for audio Q&A (question generation + evaluation).
        """
        send_ws(user_id, 5, "Fetching user file context")
        if not ensure_collection_exists():
            send_ws(user_id, 100, "Context fetch failed (collection missing)")
            return []

        points, _ = self.client.scroll(
            collection_name=self.collection_name,
            scroll_filter=Filter(
                must=[
                    FieldCondition(key="user_id", match=MatchValue(value=user_id)),
                    FieldCondition(key="file_id", match=MatchValue(value=file_id)),
                ]
            ),
            limit=top_k,
        )

        chunks: List[str] = []
        for p in points:
            payload = p.payload or {}
            text = payload.get("text") or ""
            if text.strip():
                chunks.append(text)

        send_ws(user_id, 60, f"Fetched {len(chunks)} chunks for user file")
        send_ws(user_id, 100, "User file context ready")
        return chunks

    # -----------------------------
    # Audio Q&A: Question generation (user_id + file_id)
    # -----------------------------
    def generate_audio_quiz_questions_for_user(
        self,
        user_id: str,
        file_id: str,
        num_questions: int = 5,
    ) -> List[Dict[str, Any]]:
        """
        Generate freeform QA-style questions from the user's selected file.
        Each question has a reference answer and difficulty.

        num_questions:
            N number of questions (any positive integer). Caller decides.
        """
        # WS start
        send_ws(user_id, 5, "Generating audio quiz questions")

        # ensure at least 1
        if not isinstance(num_questions, int):
            try:
                num_questions = int(num_questions)
            except Exception:
                num_questions = 5

        if num_questions <= 0:
            num_questions = 1

        contexts = self.get_context_for_user_file(
            user_id=user_id,
            file_id=file_id,
            top_k=10,
        )
        if not contexts:
            print("[generate_audio_quiz_questions_for_user] No context found for user/file.")
            send_ws(user_id, 100, "No context found for audio quiz")
            return []

        send_ws(user_id, 25, "Context retrieved for question generation")

        joined_context = "\n\n".join(contexts)[:8000]

        system_msg = (
            "You are a tutor generating short, clear, factual questions "
            "from the given study material for a spoken audio Q&A session."
        )

        # IMPORTANT: top-level JSON *object* with key "questions"
        prompt = f"""
You are given some study content. Generate {num_questions} questions for an oral exam.

Return a JSON object with a single key "questions", like:

{{
  "questions": [
    {{

      "question": "string, one clear question the AI will ask",
      "answer": "string, ideal reference answer, 1–3 sentences",
      "difficulty": "easy" | "medium" | "hard"
    }},
    ...
  ]
}}

Requirements:
- Generate exactly {num_questions} questions if possible.
- Do not include any fields other than question, answer, difficulty.
- Do not add any text outside the JSON object.

CONTENT:
\"\"\"{joined_context}\"\"\""""

        try:
            send_ws(user_id, 45, "Sending prompt to model for audio quiz")
            resp = openai_client.chat.completions.create(
                model=OPENAI_MODEL_FAST,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.2,
                response_format={"type": "json_object"},  # enforce valid JSON
            )
            raw = resp.choices[0].message.content.strip()
            print("[generate_audio_quiz_questions_for_user] RAW JSON:", raw)
            data = json.loads(raw)
        except Exception as e:
            print(f"[generate_audio_quiz_questions_for_user] JSON parse error: {e}")
            send_ws(user_id, 100, "Audio quiz generation failed")
            return []

        questions_raw = data.get("questions") if isinstance(data, dict) else None
        if not isinstance(questions_raw, list):
            print("[generate_audio_quiz_questions_for_user] 'questions' key missing or not a list.")
            send_ws(user_id, 100, "Audio quiz generation returned invalid format")
            return []

        questions: List[Dict[str, Any]] = []
        for item in questions_raw:
            if not isinstance(item, dict):
                continue
            q_text = (item.get("question") or "").strip()
            a_text = (item.get("answer") or "").strip()
            diff = (item.get("difficulty") or "medium").lower()
            if not q_text or not a_text:
                continue
            if diff not in {"easy", "medium", "hard"}:
                diff = "medium"

            questions.append(
                {
                    "question_id": str(ObjectId()),
                    "question": q_text,
                    "answer": a_text,
                    "difficulty": diff,
                }
            )

        if not questions:
            print("[generate_audio_quiz_questions_for_user] No valid questions parsed.")
            send_ws(user_id, 100, "Audio quiz generation parsed no valid questions")
            return []

        send_ws(user_id, 100, "Audio quiz ready")
        return questions

    # -----------------------------
    # Audio Q&A: Evaluate user's freeform answer
    # -----------------------------
    def evaluate_freeform_answer_for_user(
        self,
        user_id: str,
        file_id: str,
        question: str,
        reference_answer: str,
        user_answer: str,
        context_top_k: int = 5,
    ) -> Dict[str, Any]:
        """
        Evaluate a user's freeform (spoken -> transcribed) answer.
        Returns JSON with accuracy, relevance, completeness, feedback, verdict.
        """
        send_ws(user_id, 5, "Evaluating user's freeform answer")

        contexts = self.get_context_for_user_file(
            user_id=user_id,
            file_id=file_id,
            top_k=context_top_k,
        )
        context_text = "\n\n".join(contexts)[:6000]

        system_msg = (
            "You are a strict but fair examiner evaluating a student's spoken answer "
            "based on reference material and an ideal reference answer."
        )

        prompt = f"""
You will evaluate a student's answer.

CONTEXT (for grounding, do not recite fully):
\"\"\"{context_text}\"\"\"


QUESTION:
{question}

REFERENCE_ANSWER:
{reference_answer}

STUDENT_ANSWER:
{user_answer}

Return a JSON object with exactly these keys:
- "accuracy": float between 0 and 1 (1 = perfectly correct)
- "relevance": float between 0 and 1 (1 = fully on-topic)
- "completeness": float between 0 and 1 (1 = fully complete)
- "feedback": short string, max 3 sentences, specific and actionable
- "verdict": one of "correct", "partially_correct", "incorrect"

Only output valid JSON. Do not add any extra text.
"""

        try:
            send_ws(user_id, 40, "Sending evaluation prompt to model")
            resp = openai_client.chat.completions.create(
                model=OPENAI_MODEL_FAST,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.0,
            )
            raw = resp.choices[0].message.content.strip()
            data = json.loads(raw)
        except Exception as e:
            print(f"[evaluate_freeform_answer_for_user] JSON parse error: {e}")
            data = {
                "accuracy": 0.0,
                "relevance": 0.0,
                "completeness": 0.0,
                "feedback": "Evaluation failed due to parsing error.",
                "verdict": "incorrect",
            }
            send_ws(user_id, 100, "Evaluation failed")

        result = {
            "accuracy": float(data.get("accuracy", 0.0)),
            "relevance": float(data.get("relevance", 0.0)),
            "completeness": float(data.get("completeness", 0.0)),
            "feedback": str(data.get("feedback", "")) or "No feedback.",
            "verdict": str(data.get("verdict", "incorrect")),
        }

        send_ws(user_id, 100, "Evaluation completed")
        return result

    # -----------------------------
    # MCQ Generator
    # -----------------------------
    def generate_mcqs(
        self,
        query: str,
        admin_id: str,
        file_id: str,
        embedding_model,
        top_k=1,
        num_choices=4,
        difficulty="medium",
    ):
        # WS start
        send_ws(admin_id, 5, "Admin MCQ generation started")

        diff = difficulty.lower()
        if diff not in {"easy", "medium", "harder"}:
            diff = "medium"

        retrieved = self.retrieve_by_text(
            embedding_model,
            query,
            admin_id,
            file_id,
            top_k,
        )

        if not retrieved:
            send_ws(admin_id, 100, "No content found for MCQ generation")
            raise HTTPException(
                status_code=400,
                detail="No content found for admin_id + file_id.",
            )

        send_ws(admin_id, 30, f"Context retrieved ({len(retrieved)} chunks)")

        context = "\n\n---\n\n".join(
            (r.get("text") or "") for r in retrieved
        )[:6000]

        requested_questions = max(1, int(top_k))

        choice_labels = [chr(ord("A") + i) for i in range(num_choices)]
        allowed = "/".join(choice_labels)
        options_block = "\n".join(f"{c}) <option {c}>" for c in choice_labels)

        prompt = f"""
Generate exactly {requested_questions} MCQs in THIS EXACT FORMAT (no numbering, no markdown):

Question: <text>
{options_block}
Answer: <{allowed}>

Only output the MCQs. Do not add extra commentary.

Context:
{context}
"""

        response = None
        for attempt in range(3):
            try:
                send_ws(admin_id, 50, f"Sending prompt to model (attempt {attempt + 1})")
                response = openai_client.chat.completions.create(
                    model=OPENAI_MODEL_FAST,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.25,
                    timeout=40,
                )
                break
            except Exception as e:
                if "timed out" in str(e).lower() or "timeout" in str(e).lower():
                    time.sleep(2)
                    continue
                send_ws(admin_id, 100, f"MCQ generation failed: {str(e)}")
                raise HTTPException(
                    status_code=500,
                    detail=f"Error generating MCQs: {str(e)}",
                )

        if response is None:
            try:
                send_ws(admin_id, 70, "Switching to fallback model for MCQ generation")
                response = openai_client.chat.completions.create(
                    model=OPENAI_MODEL_STRICT,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.25,
                    timeout=60,
                )
            except Exception as e:
                send_ws(admin_id, 100, f"MCQ generation failed: {str(e)}")
                raise HTTPException(
                    status_code=500,
                    detail=f"Error generating MCQs: {str(e)}",
                )

        mcqs_raw = response.choices[0].message.content.strip()
        mcqs = self._parse_mcqs(mcqs_raw, num_choices)

        if len(mcqs) < requested_questions:
            send_ws(admin_id, 100, "MCQ parsing failed / insufficient questions")
            raise HTTPException(
                status_code=500,
                detail=(
                    f"Generated only {len(mcqs)} MCQs "
                    f"(expected {requested_questions}). Raw output:\n{mcqs_raw}"
                ),
            )

        if len(mcqs) > requested_questions:
            mcqs = mcqs[:requested_questions]

        doc = {
            "admin_id": admin_id,
            "file_id": file_id,
            "query": query,
            "mcqs": mcqs,
            "created_at": datetime.utcnow(),
        }
        res = self.db["mcqs"].insert_one(doc)

        send_ws(admin_id, 100, "MCQ generation completed")
        return {
            "admin_id": admin_id,
            "file_id": file_id,
            "mcq_id": str(res.inserted_id),
            "mcqs": mcqs,
            "difficulty": diff,
        }

    # -----------------------------
    # Robust MCQ parser
    # -----------------------------
    def _parse_mcqs(self, text: str, num_choices: int):
        mcqs = []
        blocks = re.split(r"(?i)question\s*[:\-\.\d]*", text)

        option_re = re.compile(r"^([A-Z])\)\s*(.+)$")
        option_re_alt = re.compile(r"^([A-Z])\.\s*(.+)$")

        for block in blocks:
            block = block.replace("**", "").strip()
            if not block:
                continue

            block = re.sub(r"^\s*\d+\)\s*", "", block)

            lines = [l.strip() for l in block.splitlines() if l.strip()]
            if not lines:
                continue

            question = lines[0]
            options: Dict[str, str] = {}
            answer_label = ""

            for line in lines[1:]:
                m = option_re.match(line) or option_re_alt.match(line)
                if m:
                    options[m.group(1)] = m.group(2).strip()
                    continue

                m2 = re.match(r"^([A-Z])\)\s*(.+)$", line)
                if m2:
                    options[m2.group(1)] = m2.group(2).strip()
                    continue

                if line.lower().startswith("answer:"):
                    part = line.split(":", 1)[1].strip()
                    label = part.split()[0].strip().upper().rstrip(".)")
                    if label:
                        answer_label = label
                        continue

            if len(options) == num_choices and answer_label in options:
                mcqs.append(
                    {
                        "question": question,
                        "options": options,
                        "answer_label": answer_label,
                        "answer": f"{answer_label}. {options.get(answer_label, '')}",
                    }
                )

        return mcqs

    # -----------------------------
    # STORE RESULTS
    # -----------------------------
    def store_results(
        self,
        user_id: str,
        mcq_id: str,
        responses: List[Any],
    ) -> dict:
        # WS: start
        send_ws(user_id, 5, "Storing MCQ results")

        mcq_collection = self.db["mcqs"]
        results_collection = self.db["results"]

        try:
            mcq_obj_id = ObjectId(mcq_id)
        except Exception as e:
            send_ws(user_id, 100, f"Store results failed: Invalid mcqId: {str(e)}")
            return {"success": False, "message": f"Invalid mcqId: {str(e)}"}

        mcq_doc = mcq_collection.find_one({"_id": mcq_obj_id})

        processed: List[Dict[str, Any]] = []
        correct_count = 0
        total = len(responses)

        def letter_from_option_string(raw: str) -> str:
            if not raw:
                return ""
            return raw.split(".", 1)[0].strip().upper()

        def get_field(item: Any, name: str):
            if isinstance(item, dict):
                return item.get(name)
            return getattr(item, name, None)

        for item in responses:
            q_text = (get_field(item, "question") or "").strip()
            selected_raw = (get_field(item, "selected_answer") or "").strip()
            correct_raw = (get_field(item, "correct_answer") or "").strip()

            options = {}
            if not correct_raw and mcq_doc and mcq_doc.get("mcqs"):
                for m in mcq_doc["mcqs"]:
                    mq = m.get("question")
                    if isinstance(mq, str) and mq.strip() == q_text:
                        options = m.get("options", {}) or {}
                        label = (m.get("answer_label") or "").strip().upper()
                        if label and label in options:
                            correct_raw = f"{label}. {options[label]}"
                        break

            selected_letter = letter_from_option_string(selected_raw)
            correct_letter = letter_from_option_string(correct_raw)

            status = False
            if selected_letter and correct_letter:
                status = selected_letter == correct_letter
            if status:
                correct_count += 1

            processed.append(
                {
                    "question": q_text,
                    "selected_answer": selected_raw,
                    "correct_answer": correct_raw,
                    "status": bool(status),
                }
            )

        score_percent = (
            round((correct_count / total) * 100, 2) if total > 0 else 0.0
        )

        result_doc = {
            "userId": user_id,
            "mcqId": mcq_obj_id,
            "submitted_at": datetime.utcnow(),
            "total_questions": total,
            "correct_count": correct_count,
            "score_percent": score_percent,
            "results": processed,
        }

        insert = results_collection.insert_one(result_doc)
        inserted_id = str(insert.inserted_id)

        result_doc["mcqId"] = str(mcq_obj_id)
        result_doc["_id"] = inserted_id

        send_ws(user_id, 100, "Results stored successfully")
        return {
            "success": True,
            "inserted_id": inserted_id,
            "summary": result_doc,
        }

    # -----------------------------
    # Get MCQ Results
    # -----------------------------
    def get_results_by_user_id(self, user_id: str):
        docs = self.db["results"].find({"userId": user_id})
        out = []
        for d in docs:
            d["_id"] = str(d["_id"])
            if isinstance(d.get("mcqId"), ObjectId):
                d["mcqId"] = str(d["mcqId"])
            out.append(d)
        return {"success": True, "user_id": user_id, "results": out}

    # -----------------------------
    # Get all MCQs
    # -----------------------------
    def get_all_mcqs(self) -> Dict[str, Any]:
        from app.utils.mongo_serializer import serialize_mongo

        try:
            docs = list(self.db["mcqs"].find({}))
            clean_docs = serialize_mongo(docs)
            return {
                "success": True,
                "count": len(clean_docs),
                "mcqs": clean_docs
            }

        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }

    # -----------------------------
    # Admin File Listing
    # -----------------------------
    def get_files_by_admin(self, admin_id: str):
        files_map: Dict[str, str] = {}
        offset = None

        while True:
            points, offset = self.client.scroll(
                collection_name=self.collection_name,
                scroll_filter=Filter(
                    must=[
                        FieldCondition(
                            key="admin_id", match=MatchValue(value=admin_id)
                        )
                    ]
                ),
                limit=100,
                offset=offset,
            )

            for p in points:
                payload = p.payload or {}
                f_id = payload.get("file_id")
                fname = payload.get("filename")
                if f_id and fname:
                    files_map[f_id] = fname

            if offset is None:
                break

        return [{"file_id": f, "file_name": n} for f, n in files_map.items()]

    # -----------------------------
    # Video Interview Question Generation   
        # -----------------------------
    def generate_video_interview_questions_for_user(
        self,
        user_id: str,
        file_id: str,
        num_questions: int = 5,
    ):
        """
        For now, reuse the same generator as audio quiz.
        Later you can tune the prompt specifically for interviews.
        """
        # forward to audio generator (which already reports WS events)
        return self.generate_audio_quiz_questions_for_user(
            user_id=user_id,
            file_id=file_id,
            num_questions=num_questions,
        )
