import uuid
from typing import Dict, Any, List, Optional
from datetime import datetime

from ..config.settings import SDKConfig
from ..exceptions import ServiceError, ValidationError, NotFoundError


class VideoInterviewService:
    """Video interview business logic"""
    
    def __init__(self, config: SDKConfig):
        self.config = config
        self._rag_service = None
        self.active_interviews = {}
    
    @property
    def rag_service(self):
        """Lazy initialization of RAG service"""
        if self._rag_service is None:
            from .rag_service import RAGService
            self._rag_service = RAGService(self.config)
        return self._rag_service
    
    def start_video_interview(
        self,
        user_id: str,
        file_id: str,
        num_questions: int = 5
    ) -> Dict[str, Any]:
        """
        Start a new video interview session.
        
        Args:
            user_id: User ID
            file_id: File ID
            num_questions: Number of questions
            
        Returns:
            Dictionary with session information
            
        Raises:
            ServiceError: If session creation fails
            ValidationError: If input is invalid
        """
        try:
            # Validate inputs
            if not user_id or not file_id:
                raise ValidationError("user_id and file_id are required")
            
            if num_questions <= 0:
                num_questions = 5
            
            # Generate questions (reuse audio quiz generator for now)
            questions = self.rag_service.generate_audio_quiz_questions(
                user_id=user_id,
                file_id=file_id,
                num_questions=num_questions
            )
            
            if not questions:
                raise ServiceError("Failed to generate interview questions")
            
            # Transform questions for video interview format
            interview_questions = []
            for q in questions:
                interview_questions.append({
                    "question_id": q["question_id"],
                    "question": q["question"],
                    "reference_answer": q["answer"],
                    "difficulty": q["difficulty"],
                    "evaluation_criteria": self._generate_evaluation_criteria(q["difficulty"]),
                    "time_limit_seconds": self._get_time_limit(q["difficulty"])
                })
            
            # Create interview session
            interview_id = str(uuid.uuid4())
            interview = {
                "interview_id": interview_id,
                "user_id": user_id,
                "file_id": file_id,
                "questions": interview_questions,
                "current_question": 0,
                "responses": [],
                "started_at": datetime.utcnow().isoformat(),
                "status": "active"
            }
            
            # Store interview
            self.active_interviews[interview_id] = interview
            
            # Prepare first question
            current_q = interview_questions[0] if interview_questions else {}
            
            return {
                "success": True,
                "interview_id": interview_id,
                "user_id": user_id,
                "file_id": file_id,
                "total_questions": len(interview_questions),
                "current_question": {
                    "question_id": current_q.get("question_id"),
                    "question": current_q.get("question"),
                    "difficulty": current_q.get("difficulty"),
                    "evaluation_criteria": current_q.get("evaluation_criteria"),
                    "time_limit_seconds": current_q.get("time_limit_seconds"),
                    "question_number": 1
                },
                "status": "active"
            }
            
        except (ValidationError, ServiceError):
            raise
        except Exception as e:
            raise ServiceError(f"Failed to start video interview: {str(e)}")
    
    def _generate_evaluation_criteria(self, difficulty: str) -> str:
        """
        Generate evaluation criteria based on difficulty.
        
        Args:
            difficulty: Question difficulty
            
        Returns:
            Evaluation criteria string
        """
        criteria = {
            "easy": "Focus on clarity and basic understanding. Check if answer addresses the main point.",
            "medium": "Evaluate depth of understanding, use of relevant terminology, and logical structure.",
            "hard": "Assess critical thinking, ability to connect concepts, and provide nuanced insights."
        }
        return criteria.get(difficulty.lower(), criteria["medium"])
    
    def _get_time_limit(self, difficulty: str) -> int:
        """
        Get time limit in seconds based on difficulty.
        
        Args:
            difficulty: Question difficulty
            
        Returns:
            Time limit in seconds
        """
        limits = {
            "easy": 60,    # 1 minute
            "medium": 120,  # 2 minutes
            "hard": 180     # 3 minutes
        }
        return limits.get(difficulty.lower(), limits["medium"])
    
    def submit_video_response(
        self,
        interview_id: str,
        question_id: str,
        response_text: str,
        duration_seconds: float
    ) -> Dict[str, Any]:
        """
        Submit a response for a video interview question.
        
        Args:
            interview_id: Interview session ID
            question_id: Question ID
            response_text: Transcribed response text
            duration_seconds: Response duration in seconds
            
        Returns:
            Dictionary with evaluation and next question
            
        Raises:
            NotFoundError: If interview or question not found
            ValidationError: If response is invalid
            ServiceError: If evaluation fails
        """
        try:
            # Get interview
            interview = self.active_interviews.get(interview_id)
            if not interview:
                raise NotFoundError(f"Interview not found: {interview_id}")
            
            # Find question
            questions = interview["questions"]
            question = None
            question_index = -1
            
            for i, q in enumerate(questions):
                if q["question_id"] == question_id:
                    question = q
                    question_index = i
                    break
            
            if not question:
                raise NotFoundError(f"Question not found: {question_id}")
            
            # Validate response
            if not response_text or not response_text.strip():
                raise ValidationError("Response cannot be empty")
            
            if duration_seconds <= 0:
                raise ValidationError("Duration must be positive")
            
            # Evaluate response
            evaluation = self._evaluate_video_response(
                question=question["question"],
                reference_answer=question["reference_answer"],
                response_text=response_text,
                duration_seconds=duration_seconds,
                time_limit=question["time_limit_seconds"],
                evaluation_criteria=question["evaluation_criteria"]
            )
            
            # Store response
            response_record = {
                "question_id": question_id,
                "question": question["question"],
                "response_text": response_text,
                "duration_seconds": duration_seconds,
                "evaluation": evaluation,
                "submitted_at": datetime.utcnow().isoformat()
            }
            
            interview["responses"].append(response_record)
            
            # Move to next question
            interview["current_question"] = question_index + 1
            
            # Check if completed
            is_completed = interview["current_question"] >= len(questions)
            
            # Prepare response
            response = {
                "success": True,
                "interview_id": interview_id,
                "question_id": question_id,
                "evaluation": evaluation,
                "status": "completed" if is_completed else "active"
            }
            
            # Add next question if not completed
            if not is_completed:
                next_question = questions[interview["current_question"]]
                response["next_question"] = {
                    "question_id": next_question["question_id"],
                    "question": next_question["question"],
                    "difficulty": next_question["difficulty"],
                    "evaluation_criteria": next_question["evaluation_criteria"],
                    "time_limit_seconds": next_question["time_limit_seconds"],
                    "question_number": interview["current_question"] + 1
                }
            else:
                # Calculate overall score
                if interview["responses"]:
                    total_score = sum(r["evaluation"]["overall_score"] for r in interview["responses"])
                    avg_score = total_score / len(interview["responses"])
                else:
                    avg_score = 0
                
                response["summary"] = {
                    "total_questions": len(questions),
                    "questions_answered": len(interview["responses"]),
                    "average_score": round(avg_score, 2),
                    "started_at": interview["started_at"],
                    "completed_at": datetime.utcnow().isoformat()
                }
                
                # Archive interview
                self._archive_interview(interview_id)
            
            return response
            
        except (NotFoundError, ValidationError):
            raise
        except Exception as e:
            raise ServiceError(f"Failed to submit video response: {str(e)}")
    
    def _evaluate_video_response(
        self,
        question: str,
        reference_answer: str,
        response_text: str,
        duration_seconds: float,
        time_limit: int,
        evaluation_criteria: str
    ) -> Dict[str, Any]:
        """
        Evaluate a video interview response.
        
        Args:
            question: Question text
            reference_answer: Reference answer
            response_text: User's response text
            duration_seconds: Response duration
            time_limit: Time limit for question
            evaluation_criteria: Criteria for evaluation
            
        Returns:
            Dictionary with evaluation metrics
        """
        try:
            # Use RAG service for evaluation
            evaluation = self.rag_service.evaluate_freeform_answer(
                user_id="video_interview",  # Placeholder user_id
                file_id="video_interview",  # Placeholder file_id
                question=question,
                reference_answer=reference_answer,
                user_answer=response_text
            )
            
            # Add video-specific metrics
            # Time management score (closer to time limit is better, but not exceeding)
            if duration_seconds <= time_limit:
                time_score = min(1.0, duration_seconds / time_limit * 1.2)  # Bonus for using time well
            else:
                time_score = max(0.0, 1.0 - (duration_seconds - time_limit) / time_limit)
            
            # Response length score (based on word count)
            word_count = len(response_text.split())
            length_score = min(1.0, word_count / 100)  # Cap at 100 words
            
            # Calculate overall score (weighted average)
            weights = {
                "accuracy": 0.4,
                "relevance": 0.2,
                "completeness": 0.2,
                "time_management": 0.1,
                "response_length": 0.1
            }
            
            overall_score = (
                evaluation["accuracy"] * weights["accuracy"] +
                evaluation["relevance"] * weights["relevance"] +
                evaluation["completeness"] * weights["completeness"] +
                time_score * weights["time_management"] +
                length_score * weights["response_length"]
            )
            
            # Add video-specific feedback
            time_feedback = ""
            if duration_seconds < time_limit * 0.5:
                time_feedback = "Consider providing more detailed answers to fully utilize the available time."
            elif duration_seconds > time_limit:
                time_feedback = "Try to be more concise to stay within the time limit."
            
            length_feedback = ""
            if word_count < 30:
                length_feedback = "Your answer could be more detailed. Aim for 50+ words."
            elif word_count > 200:
                length_feedback = "Your answer is quite long. Try to be more concise while covering key points."
            
            # Combine feedback
            combined_feedback = f"{evaluation['feedback']}"
            if time_feedback:
                combined_feedback += f" {time_feedback}"
            if length_feedback:
                combined_feedback += f" {length_feedback}"
            
            return {
                "accuracy": evaluation["accuracy"],
                "relevance": evaluation["relevance"],
                "completeness": evaluation["completeness"],
                "fluency": evaluation["accuracy"],  # Using accuracy as proxy for fluency
                "time_management": time_score,
                "response_length": length_score,
                "overall_score": round(overall_score, 2),
                "feedback": combined_feedback.strip(),
                "verdict": evaluation["verdict"],
                "metrics": {
                    "duration_seconds": duration_seconds,
                    "time_limit_seconds": time_limit,
                    "word_count": word_count,
                    "time_used_percentage": round((duration_seconds / time_limit) * 100, 1) if time_limit > 0 else 0
                }
            }
            
        except Exception:
            # Fallback evaluation
            return {
                "accuracy": 0.5,
                "relevance": 0.5,
                "completeness": 0.5,
                "fluency": 0.5,
                "time_management": 0.5,
                "response_length": 0.5,
                "overall_score": 0.5,
                "feedback": "Evaluation completed with limited metrics.",
                "verdict": "partially_correct",
                "metrics": {
                    "duration_seconds": duration_seconds,
                    "time_limit_seconds": time_limit,
                    "word_count": len(response_text.split()),
                    "time_used_percentage": round((duration_seconds / time_limit) * 100, 1) if time_limit > 0 else 0
                }
            }
    
    def get_interview_status(
        self,
        interview_id: str
    ) -> Dict[str, Any]:
        """
        Get the status of a video interview session.
        
        Args:
            interview_id: Interview session ID
            
        Returns:
            Dictionary with interview status
            
        Raises:
            NotFoundError: If interview not found
        """
        try:
            interview = self.active_interviews.get(interview_id)
            if not interview:
                raise NotFoundError(f"Interview not found: {interview_id}")
            
            questions = interview["questions"]
            current = interview["current_question"]
            responses = interview["responses"]
            
            # Calculate progress
            completed_questions = len(responses)
            total_questions = len(questions)
            
            # Calculate average score
            if responses:
                total_score = sum(r["evaluation"]["overall_score"] for r in responses)
                avg_score = total_score / len(responses)
            else:
                avg_score = 0
            
            return {
                "success": True,
                "interview_id": interview_id,
                "user_id": interview["user_id"],
                "file_id": interview["file_id"],
                "status": interview["status"],
                "progress": {
                    "current": current,
                    "completed": completed_questions,
                    "total": total_questions,
                    "percentage": round((completed_questions / total_questions) * 100, 1) if total_questions > 0 else 0
                },
                "performance": {
                    "average_score": round(avg_score, 2),
                    "questions_answered": completed_questions
                },
                "started_at": interview["started_at"],
                "current_question": current if current < total_questions else None
            }
            
        except NotFoundError:
            raise
        except Exception as e:
            raise ServiceError(f"Failed to get interview status: {str(e)}")
    
    def _archive_interview(self, interview_id: str):
        """
        Archive a completed interview.
        
        Args:
            interview_id: Interview ID to archive
        """
        try:
            interview = self.active_interviews.get(interview_id)
            if interview:
                # Here you could store the interview in MongoDB
                archived_interview = interview.copy()
                archived_interview["status"] = "archived"
                archived_interview["archived_at"] = datetime.utcnow().isoformat()
                
                # Remove from active interviews
                del self.active_interviews[interview_id]
                
        except Exception:
            pass  # Silently fail archiving
    
    def end_interview(self, interview_id: str) -> Dict[str, Any]:
        """
        End a video interview session early.
        
        Args:
            interview_id: Interview session ID
            
        Returns:
            Dictionary with interview summary
            
        Raises:
            NotFoundError: If interview not found
        """
        try:
            interview = self.active_interviews.get(interview_id)
            if not interview:
                raise NotFoundError(f"Interview not found: {interview_id}")
            
            # Calculate summary
            questions = interview["questions"]
            responses = interview["responses"]
            
            total_questions = len(questions)
            questions_answered = len(responses)
            
            # Calculate average score
            if responses:
                total_score = sum(r["evaluation"]["overall_score"] for r in responses)
                avg_score = total_score / len(responses)
            else:
                avg_score = 0
            
            summary = {
                "interview_id": interview_id,
                "user_id": interview["user_id"],
                "file_id": interview["file_id"],
                "total_questions": total_questions,
                "questions_answered": questions_answered,
                "questions_skipped": total_questions - questions_answered,
                "average_score": round(avg_score, 2),
                "started_at": interview["started_at"],
                "ended_at": datetime.utcnow().isoformat(),
                "status": "ended_early"
            }
            
            # Archive interview
            self._archive_interview(interview_id)
            
            return {
                "success": True,
                "message": "Interview ended successfully",
                "summary": summary
            }
            
        except NotFoundError:
            raise
        except Exception as e:
            raise ServiceError(f"Failed to end interview: {str(e)}")