# import os
# from typing import Optional, List, Dict, Any
# from pydantic import BaseSettings, Field, validator
# from pydantic_settings import BaseSettings as NewBaseSettings


# class SDKConfig(NewBaseSettings):
#     """
#     Configuration for the Reckomate SDK.
    
#     Can be instantiated from environment variables or passed directly.
#     Environment variables are prefixed with 'RECKOMATE_'.
#     """
    
#     # OpenAI Configuration
#     openai_api_key: str = Field(
#         ...,  # Required
#         description="OpenAI API key for LLM operations"
#     )
#     openai_base_url: Optional[str] = Field(
#         None,
#         description="OpenAI API base URL (for custom endpoints)"
#     )
    
#     # Qdrant Configuration
#     qdrant_url: str = Field(
#         "http://localhost:6333",
#         description="Qdrant vector database URL"
#     )
#     qdrant_api_key: Optional[str] = Field(
#         None,
#         description="Qdrant API key (optional for local)"
#     )
#     qdrant_collection_name: str = Field(
#         "global_collection",
#         description="Qdrant collection name"
#     )
#     qdrant_prefer_grpc: bool = Field(
#         False,
#         description="Use gRPC for Qdrant communication"
#     )
    
#     # MongoDB Configuration
#     mongo_uri: str = Field(
#         "mongodb://localhost:27017",
#         description="MongoDB connection URI"
#     )
#     mongo_db_name: str = Field(
#         "rekomate",
#         description="Database name"
#     )
#     mongo_max_pool_size: int = Field(
#         100,
#         description="MongoDB connection pool size"
#     )
    
#     # Embedding Configuration
#     embed_model: str = Field(
#         "all-MiniLM-L6-v2",
#         description="Sentence transformer model name"
#     )
#     embed_device: str = Field(
#         "cpu",
#         description="Device for embedding model (cpu/cuda)"
#     )
    
#     # Model Configuration
#     openai_model_fast: str = Field(
#         "gpt-4o-mini",
#         description="Fast OpenAI model for quick responses"
#     )
#     openai_model_strict: str = Field(
#         "gpt-4o",
#         description="Strict OpenAI model for complex tasks"
#     )
#     openai_timeout: int = Field(
#         30,
#         description="OpenAI API timeout in seconds"
#     )
#     openai_max_retries: int = Field(
#         3,
#         description="OpenAI API max retries"
#     )
    
#     # File Processing Configuration
#     upload_dir: str = Field(
#         "uploads",
#         description="Directory for uploaded files"
#     )
#     upload_audio_dir: str = Field(
#         "uploads/audio",
#         description="Directory for audio uploads"
#     )
#     upload_image_dir: str = Field(
#         "uploads/images",
#         description="Directory for image uploads"
#     )
#     max_file_size_mb: int = Field(
#         100,
#         description="Maximum file size in MB"
#     )
    
#     # OCR Configuration
#     tesseract_cmd: Optional[str] = Field(
#         None,
#         description="Path to Tesseract OCR executable"
#     )
#     ocr_languages: str = Field(
#         "eng",
#         description="OCR languages (comma-separated)"
#     )
    
#     # Chunking Configuration
#     chunk_size: int = Field(
#         600,
#         description="Default chunk size for text splitting"
#     )
#     chunk_overlap: int = Field(
#         80,
#         description="Default chunk overlap"
#     )
    
#     # JWT Configuration
#     jwt_secret_key: str = Field(
#         "your-secret-key-change-in-production",
#         description="JWT secret key"
#     )
#     jwt_algorithm: str = Field(
#         "HS256",
#         description="JWT algorithm"
#     )
#     access_token_expire_minutes: int = Field(
#         60,
#         description="Access token expiration in minutes"
#     )
#     refresh_token_expire_days: int = Field(
#         7,
#         description="Refresh token expiration in days"
#     )
    
#     # WebSocket Configuration (optional)
#     enable_websocket: bool = Field(
#         False,
#         description="Enable WebSocket notifications"
#     )
#     websocket_host: str = Field(
#         "0.0.0.0",
#         description="WebSocket host"
#     )
#     websocket_port: int = Field(
#         8000,
#         description="WebSocket port"
#     )
    
#     # Firebase Configuration (optional)
#     firebase_credentials_path: Optional[str] = Field(
#         None,
#         description="Path to Firebase credentials JSON file"
#     )
#     firebase_project_id: Optional[str] = Field(
#         None,
#         description="Firebase project ID"
#     )
    
#     # Logging Configuration
#     log_level: str = Field(
#         "INFO",
#         description="Logging level"
#     )
#     log_format: str = Field(
#         "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
#         description="Log format"
#     )
#     log_file: Optional[str] = Field(
#         None,
#         description="Log file path"
#     )
    
#     # Performance Configuration
#     max_workers: int = Field(
#         4,
#         description="Maximum worker threads for async operations"
#     )
#     cache_ttl: int = Field(
#         300,
#         description="Cache time-to-live in seconds"
#     )
    
#     class Config:
#         env_prefix = "RECKOMATE_"
#         case_sensitive = False
#         env_file = ".env"
#         env_file_encoding = "utf-8"
    
#     @validator("openai_api_key")
#     def validate_openai_key(cls, v):
#         if not v or len(v) < 20:
#             raise ValueError("OpenAI API key must be provided and valid")
#         return v
    
#     @validator("mongo_uri")
#     def validate_mongo_uri(cls, v):
#         if not v.startswith("mongodb://") and not v.startswith("mongodb+srv://"):
#             raise ValueError("MongoDB URI must start with mongodb:// or mongodb+srv://")
#         return v
    
#     @validator("upload_dir", "upload_audio_dir", "upload_image_dir")
#     def create_directories(cls, v):
#         """Ensure upload directories exist"""
#         os.makedirs(v, exist_ok=True)
#         return v
    
#     def validate(self) -> bool:
#         """Validate configuration"""
#         try:
#             # Check required fields
#             if not self.openai_api_key:
#                 return False
#             if not self.mongo_uri:
#                 return False
            
#             # Validate OpenAI key format
#             if len(self.openai_api_key) < 20:
#                 return False
            
#             # Validate MongoDB URI
#             if not self.mongo_uri.startswith("mongodb://") and not self.mongo_uri.startswith("mongodb+srv://"):
#                 return False
            
#             return True
            
#         except Exception:
#             return False
    
#     def get_qdrant_client_kwargs(self) -> Dict[str, Any]:
#         """Get Qdrant client initialization kwargs"""
#         kwargs = {
#             "url": self.qdrant_url,
#             "prefer_grpc": self.qdrant_prefer_grpc,
#             "timeout": 60,
#         }
#         if self.qdrant_api_key:
#             kwargs["api_key"] = self.qdrant_api_key
#         return kwargs
    
#     def get_mongo_client_kwargs(self) -> Dict[str, Any]:
#         """Get MongoDB client initialization kwargs"""
#         return {
#             "host": self.mongo_uri,
#             "maxPoolSize": self.mongo_max_pool_size,
#             "connectTimeoutMS": 30000,
#             "socketTimeoutMS": 30000,
#         }
    
#     def get_openai_client_kwargs(self) -> Dict[str, Any]:
#         """Get OpenAI client initialization kwargs"""
#         kwargs = {
#             "api_key": self.openai_api_key,
#             "timeout": self.openai_timeout,
#             "max_retries": self.openai_max_retries,
#         }
#         if self.openai_base_url:
#             kwargs["base_url"] = self.openai_base_url
#         return kwargs



# reckomate_sdk/config/settings.py
import os
from typing import Optional, List, Dict, Any
from pydantic_settings import BaseSettings


class SDKConfig(BaseSettings):
    """
    Configuration for the Reckomate SDK.
    
    Can be instantiated from environment variables or passed directly.
    Environment variables are prefixed with 'RECKOMATE_'.
    """
    
    # API Configuration (for SDK client)
    base_url: str = "http://localhost:8000"
    api_key: Optional[str] = None
    timeout: int = 30
    verify_ssl: bool = True
    
    # OpenAI Configuration
    openai_api_key: str = ""
    openai_base_url: Optional[str] = None
    
    # Qdrant Configuration
    qdrant_url: str = "http://localhost:6333"
    qdrant_api_key: Optional[str] = None
    qdrant_collection_name: str = "global_collection"
    qdrant_prefer_grpc: bool = False
    
    # MongoDB Configuration
    mongo_uri: str = "mongodb://localhost:27017"
    mongo_db_name: str = "rekomate"
    mongo_max_pool_size: int = 100
    
    # Embedding Configuration
    embed_model: str = "all-MiniLM-L6-v2"
    embed_device: str = "cpu"
    
    # Model Configuration
    openai_model_fast: str = "gpt-4o-mini"
    openai_model_strict: str = "gpt-4o"
    openai_timeout: int = 30
    openai_max_retries: int = 3
    
    # File Processing Configuration
    upload_dir: str = "uploads"
    upload_audio_dir: str = "uploads/audio"
    upload_image_dir: str = "uploads/images"
    max_file_size_mb: int = 100
    
    # OCR Configuration
    tesseract_cmd: Optional[str] = None
    ocr_languages: str = "eng"
    
    # Chunking Configuration
    chunk_size: int = 600
    chunk_overlap: int = 80
    
    # JWT Configuration
    jwt_secret_key: str = "your-secret-key-change-in-production"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 60
    refresh_token_expire_days: int = 7
    
    # WebSocket Configuration (optional)
    enable_websocket: bool = False
    websocket_host: str = "0.0.0.0"
    websocket_port: int = 8000
    
    # Firebase Configuration (optional)
    firebase_credentials_path: Optional[str] = None
    firebase_project_id: Optional[str] = None
    
    # Logging Configuration
    log_level: str = "INFO"
    log_format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    log_file: Optional[str] = None
    
    # Performance Configuration
    max_workers: int = 4
    cache_ttl: int = 300
    
    class Config:
        env_prefix = "RECKOMATE_"
        case_sensitive = False
        env_file = ".env"
        env_file_encoding = "utf-8"
    
    def validate_openai_key(self) -> bool:
        """Validate OpenAI API key"""
        return bool(self.openai_api_key and len(self.openai_api_key) > 20)
    
    def validate_mongo_uri(self) -> bool:
        """Validate MongoDB URI"""
        return self.mongo_uri.startswith("mongodb://") or self.mongo_uri.startswith("mongodb+srv://")
    
    def ensure_directories(self):
        """Ensure upload directories exist"""
        os.makedirs(self.upload_dir, exist_ok=True)
        os.makedirs(self.upload_audio_dir, exist_ok=True)
        os.makedirs(self.upload_image_dir, exist_ok=True)
    
    def is_valid(self) -> bool:
        """Check if configuration is valid"""
        try:
            self.ensure_directories()
            
            # Validate required fields
            if not self.base_url:
                return False
            
            # Only validate OpenAI key if it's provided (it's not always required for SDK)
            if self.openai_api_key and not self.validate_openai_key():
                return False
                
            return True
        except Exception:
            return False
    
    def get_client_config(self) -> Dict[str, Any]:
        """Get configuration for HTTP client"""
        return {
            "base_url": self.base_url,
            "api_key": self.api_key,
            "timeout": self.timeout,
            "verify_ssl": self.verify_ssl
        }
    
    def get_qdrant_client_kwargs(self) -> Dict[str, Any]:
        """Get Qdrant client initialization kwargs"""
        kwargs = {
            "url": self.qdrant_url,
            "prefer_grpc": self.qdrant_prefer_grpc,
            "timeout": 60,
        }
        if self.qdrant_api_key:
            kwargs["api_key"] = self.qdrant_api_key
        return kwargs
    
    def get_openai_client_kwargs(self) -> Dict[str, Any]:
        """Get OpenAI client initialization kwargs"""
        kwargs = {
            "api_key": self.openai_api_key,
            "timeout": self.openai_timeout,
            "max_retries": self.openai_max_retries,
        }
        if self.openai_base_url:
            kwargs["base_url"] = self.openai_base_url
        return kwargs


# Global configuration instance
_config: Optional[SDKConfig] = None

def get_config() -> SDKConfig:
    """Get global SDK configuration"""
    global _config
    if _config is None:
        _config = SDKConfig()
        _config.ensure_directories()
    return _config

def set_config(config: SDKConfig):
    """Set global SDK configuration"""
    global _config
    _config = config
    _config.ensure_directories()