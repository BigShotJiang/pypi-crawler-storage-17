# reckomate_sdk/client.py
import httpx
import logging
from typing import Dict, Any, Optional, List
from dataclasses import dataclass

from .config.settings import SDKConfig, get_config
from .exceptions import SDKError, APIError
from .services.proxy_services import (
    UserService, AdminService, MCQService, RAGService,
    ChatService, AudioQuizService, VideoInterviewService,
    QdrantService, IngestService, ScanService, TokenService
)

logger = logging.getLogger(__name__)


@dataclass
class ServiceRegistry:
    """Container for all SDK services"""
    user: UserService
    admin: AdminService
    mcq: MCQService
    rag: RAGService
    chat: ChatService
    audio: AudioQuizService
    video: VideoInterviewService
    qdrant: QdrantService
    ingest: IngestService
    scan: ScanService
    token: TokenService


class ReckomateSDK:
    """
    Complete SDK proxy for Reckomate Backend API.
    
    Mirrors ALL backend routes as Python methods.
    
    Usage:
        >>> from reckomate_sdk import ReckomateSDK
        >>> sdk = ReckomateSDK()  # Uses config from environment
        >>> # Or with custom config
        >>> sdk = ReckomateSDK.from_config(config_dict)
        >>> # User routes
        >>> sdk.user.register("+1234567890", "password")
        >>> sdk.user.login("+1234567890", "password")
        >>> # MCQ routes
        >>> sdk.mcq.generate(query="climate", admin_id="admin1", file_id="file1")
        >>> # RAG routes
        >>> sdk.rag.ask_easy(user_id="user1", prompt="What is...?", file_id="file1")
    """
    
    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: Optional[int] = None,
        verify_ssl: Optional[bool] = None,
        auto_refresh_token: bool = False,
        config: Optional[SDKConfig] = None
    ):
        """
        Initialize SDK.
        
        Args:
            base_url: API base URL (overrides config)
            api_key: API key for authentication (overrides config)
            timeout: Request timeout in seconds (overrides config)
            verify_ssl: Verify SSL certificates (overrides config)
            auto_refresh_token: Auto-refresh expired tokens
            config: SDKConfig instance (alternative to individual params)
        """
        
        # Get configuration
        if config:
            self.config = config
        else:
            self.config = get_config()
        
        # Override config with explicit parameters if provided
        self.base_url = base_url or self.config.base_url
        self.api_key = api_key or self.config.api_key
        self.timeout = timeout or self.config.timeout
        self.verify_ssl = verify_ssl if verify_ssl is not None else self.config.verify_ssl
        
        # Ensure URL doesn't have trailing slash
        self.base_url = self.base_url.rstrip('/')
        
        self.auto_refresh_token = auto_refresh_token
        self.access_token: Optional[str] = None
        self.refresh_token: Optional[str] = None
        
        # Validate config
        if not self.base_url:
            raise ValueError("Base URL is required. Set RECKOMATE_BASE_URL or pass base_url parameter")
        
        # Create HTTP client
        self.client = httpx.Client(
            base_url=self.base_url,
            timeout=self.timeout,
            verify=self.verify_ssl,
            headers=self._get_headers()
        )
        
        # Initialize ALL services
        self._services = ServiceRegistry(
            user=UserService(self),
            admin=AdminService(self),
            mcq=MCQService(self),
            rag=RAGService(self),
            chat=ChatService(self),
            audio=AudioQuizService(self),
            video=VideoInterviewService(self),
            qdrant=QdrantService(self),
            ingest=IngestService(self),
            scan=ScanService(self),
            token=TokenService(self)
        )
        
        logger.info(f"ReckomateSDK initialized with base_url: {self.base_url}")
        logger.info(f"Services available: {len(self._services.__dataclass_fields__)}")
    
    @classmethod
    def from_config(cls, config: SDKConfig, **kwargs) -> 'ReckomateSDK':
        """
        Create SDK instance from SDKConfig.
        
        Args:
            config: SDKConfig instance
            **kwargs: Additional parameters to override config
        
        Returns:
            ReckomateSDK instance
        """
        return cls(
            base_url=kwargs.get('base_url', config.base_url),
            api_key=kwargs.get('api_key', config.api_key),
            timeout=kwargs.get('timeout', config.timeout),
            verify_ssl=kwargs.get('verify_ssl', config.verify_ssl),
            config=config
        )
    
    @classmethod
    def from_env(cls, **kwargs) -> 'ReckomateSDK':
        """
        Create SDK instance from environment variables.
        
        Args:
            **kwargs: Parameters to override environment config
        
        Returns:
            ReckomateSDK instance
        """
        config = get_config()
        return cls.from_config(config, **kwargs)
    
    def _get_headers(self) -> Dict[str, str]:
        headers = {
            "User-Agent": f"Reckomate-SDK/1.0.0",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        
        # Use api_key, access_token, or config's api_key in that order
        auth_token = self.api_key or self.access_token or self.config.api_key
        if auth_token:
            headers["Authorization"] = f"Bearer {auth_token}"
        
        return headers
    
    def set_auth_tokens(self, access_token: str, refresh_token: Optional[str] = None):
        """Set authentication tokens for subsequent requests"""
        self.access_token = access_token
        if refresh_token:
            self.refresh_token = refresh_token
        
        # Update client headers
        self.client.headers.update({"Authorization": f"Bearer {access_token}"})
    
    def clear_auth_tokens(self):
        """Clear authentication tokens"""
        self.access_token = None
        self.refresh_token = None
        if "Authorization" in self.client.headers:
            # Only remove if it's not using api_key
            if not self.api_key:
                del self.client.headers["Authorization"]
    
    def request(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> Dict[str, Any]:
        """Make HTTP request to backend"""
        try:
            # Auto-refresh token if expired
            if (self.auto_refresh_token and self.refresh_token and 
                kwargs.get('requires_auth', True)):
                # Check if token might be expired (simplified)
                # In production, you'd decode JWT and check expiry
                pass
            
            response = self.client.request(
                method=method.upper(),
                url=endpoint,
                **kwargs
            )
            
            # Handle token expiration
            if response.status_code == 401 and self.auto_refresh_token and self.refresh_token:
                try:
                    # Try to refresh token
                    refresh_response = self.token.refresh(self.refresh_token)
                    if 'access_token' in refresh_response:
                        self.set_auth_tokens(
                            refresh_response['access_token'],
                            refresh_response.get('refresh_token', self.refresh_token)
                        )
                        # Retry the original request
                        response = self.client.request(
                            method=method.upper(),
                            url=endpoint,
                            **kwargs
                        )
                except Exception:
                    pass
            
            response.raise_for_status()
            
            # Handle empty responses
            if response.status_code == 204:
                return {"success": True, "message": "No content"}
            
            return response.json()
            
        except httpx.HTTPStatusError as e:
            error_msg = f"API error {e.response.status_code}"
            try:
                error_data = e.response.json()
                error_msg = f"{error_msg}: {error_data.get('detail', error_data)}"
            except:
                error_msg = f"{error_msg}: {e.response.text}"
            
            logger.error(error_msg)
            raise APIError(error_msg)
            
        except httpx.TimeoutException:
            error_msg = f"Request timeout after {self.timeout} seconds"
            logger.error(error_msg)
            raise APIError(error_msg)
            
        except Exception as e:
            logger.error(f"Request failed: {e}")
            raise APIError(f"Request failed: {e}")
    
    def get(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("GET", endpoint, **kwargs)
    
    def post(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("POST", endpoint, **kwargs)
    
    def put(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("PUT", endpoint, **kwargs)
    
    def delete(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("DELETE", endpoint, **kwargs)
    
    def patch(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("PATCH", endpoint, **kwargs)
    
    # Property accessors for all services
    @property
    def user(self):
        return self._services.user
    
    @property
    def admin(self):
        return self._services.admin
    
    @property
    def mcq(self):
        return self._services.mcq
    
    @property
    def rag(self):
        return self._services.rag
    
    @property
    def chat(self):
        return self._services.chat
    
    @property
    def audio(self):
        return self._services.audio
    
    @property
    def video(self):
        return self._services.video
    
    @property
    def qdrant(self):
        return self._services.qdrant
    
    @property
    def ingest(self):
        return self._services.ingest
    
    @property
    def scan(self):
        return self._services.scan
    
    @property
    def token(self):
        return self._services.token
    
    def health_check(self) -> bool:
        """Check if backend is reachable"""
        try:
            response = self.client.get("/health", timeout=5)
            return response.status_code == 200
        except Exception:
            return False
    
    def list_all_methods(self) -> Dict[str, List[str]]:
        """List all available SDK methods (for Postman/testing)"""
        methods = {}
        for service_name in self._services.__dataclass_fields__.keys():
            service = getattr(self, service_name)
            service_methods = [
                method for method in dir(service) 
                if not method.startswith('_') and callable(getattr(service, method))
            ]
            methods[service_name] = sorted(service_methods)
        
        return methods
    
    def get_endpoint_count(self) -> Dict[str, int]:
        """Get count of endpoints per service"""
        methods = self.list_all_methods()
        return {service: len(methods_list) for service, methods_list in methods.items()}
    
    def get_config_info(self) -> Dict[str, Any]:
        """Get current configuration info"""
        return {
            "base_url": self.base_url,
            "timeout": self.timeout,
            "verify_ssl": self.verify_ssl,
            "has_api_key": bool(self.api_key or self.access_token or self.config.api_key),
            "services": list(self._services.__dataclass_fields__.keys()),
            "total_methods": sum(self.get_endpoint_count().values())
        }
    
    def close(self):
        """Close HTTP client"""
        self.client.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()