from typing import Any, Union, List, Dict
from bson import ObjectId


def serialize_mongo(obj: Any) -> Any:
    """
    Recursively convert MongoDB ObjectId values to strings.
    
    Args:
        obj: Object to serialize (can be dict, list, or single value)
        
    Returns:
        Serialized object with ObjectId converted to strings
    """
    if isinstance(obj, ObjectId):
        return str(obj)
    
    if isinstance(obj, list):
        return [serialize_mongo(item) for item in obj]
    
    if isinstance(obj, dict):
        return {key: serialize_mongo(value) for key, value in obj.items()}
    
    return obj


def deserialize_mongo(obj: Any) -> Any:
    """
    Convert string IDs back to ObjectId where appropriate.
    Note: Use with caution, as not all strings should be ObjectId.
    
    Args:
        obj: Object to deserialize
        
    Returns:
        Deserialized object with string IDs as ObjectId where applicable
    """
    if isinstance(obj, str):
        # Check if string looks like an ObjectId (24 hex characters)
        if len(obj) == 24 and all(c in "0123456789abcdefABCDEF" for c in obj):
            try:
                return ObjectId(obj)
            except:
                pass
        return obj
    
    if isinstance(obj, list):
        return [deserialize_mongo(item) for item in obj]
    
    if isinstance(obj, dict):
        return {key: deserialize_mongo(value) for key, value in obj.items()}
    
    return obj