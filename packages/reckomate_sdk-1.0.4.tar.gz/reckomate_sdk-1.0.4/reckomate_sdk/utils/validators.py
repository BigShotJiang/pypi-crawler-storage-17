import re
from typing import Optional
from email_validator import validate_email as validate_email_lib, EmailNotValidError


def validate_phone(phone: str) -> bool:
    """
    Validate phone number format.
    
    Args:
        phone: Phone number to validate
        
    Returns:
        True if valid, False otherwise
    """
    # Basic international phone number pattern
    pattern = r'^\+?[1-9]\d{9,14}$'
    return bool(re.match(pattern, phone))


def validate_email(email: str) -> bool:
    """
    Validate email address format.
    
    Args:
        email: Email address to validate
        
    Returns:
        True if valid, False otherwise
    """
    try:
        validate_email_lib(email)
        return True
    except EmailNotValidError:
        return False


def validate_password_strength(password: str) -> Dict[str, Any]:
    """
    Validate password strength.
    
    Args:
        password: Password to validate
        
    Returns:
        Dictionary with validation results
    """
    results = {
        "valid": True,
        "errors": [],
        "score": 0
    }
    
    # Check length
    if len(password) < 8:
        results["valid"] = False
        results["errors"].append("Password must be at least 8 characters long")
    else:
        results["score"] += 1
    
    # Check for uppercase
    if not re.search(r'[A-Z]', password):
        results["valid"] = False
        results["errors"].append("Password must contain at least one uppercase letter")
    else:
        results["score"] += 1
    
    # Check for lowercase
    if not re.search(r'[a-z]', password):
        results["valid"] = False
        results["errors"].append("Password must contain at least one lowercase letter")
    else:
        results["score"] += 1
    
    # Check for digits
    if not re.search(r'\d', password):
        results["valid"] = False
        results["errors"].append("Password must contain at least one digit")
    else:
        results["score"] += 1
    
    # Check for special characters
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        results["errors"].append("Consider adding special characters for better security")
    else:
        results["score"] += 1
    
    # Calculate strength
    if results["score"] >= 4:
        results["strength"] = "strong"
    elif results["score"] >= 3:
        results["strength"] = "medium"
    else:
        results["strength"] = "weak"
    
    return results


def validate_url(url: str) -> bool:
    """
    Validate URL format.
    
    Args:
        url: URL to validate
        
    Returns:
        True if valid, False otherwise
    """
    pattern = r'^https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+(/[-\w._~:/?#[\]@!$&\'()*+,;=]*)?$'
    return bool(re.match(pattern, url))


def sanitize_input(text: str, max_length: Optional[int] = None) -> str:
    """
    Sanitize user input.
    
    Args:
        text: Text to sanitize
        max_length: Optional maximum length
        
    Returns:
        Sanitized text
    """
    # Remove leading/trailing whitespace
    sanitized = text.strip()
    
    # Remove excessive whitespace
    sanitized = re.sub(r'\s+', ' ', sanitized)
    
    # Truncate if max_length specified
    if max_length and len(sanitized) > max_length:
        sanitized = sanitized[:max_length]
    
    return sanitized