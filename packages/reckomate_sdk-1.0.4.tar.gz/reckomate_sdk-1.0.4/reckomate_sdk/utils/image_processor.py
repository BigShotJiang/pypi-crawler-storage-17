from typing import List, Tuple
from PIL import Image


def chunk_image(
    image_path: str,
    chunk_size: int = 256
) -> Tuple[List[Image.Image], Tuple[int, int]]:
    """
    Split an image into square chunks.
    
    Args:
        image_path: Path to the image file
        chunk_size: Size of each chunk in pixels
        
    Returns:
        Tuple of (list of image chunks, (original_width, original_height))
    """
    img = Image.open(image_path).convert("RGB")
    width, height = img.size
    
    chunks: List[Image.Image] = []
    
    for top in range(0, height, chunk_size):
        for left in range(0, width, chunk_size):
            box = (
                left,
                top,
                min(left + chunk_size, width),
                min(top + chunk_size, height)
            )
            chunk = img.crop(box)
            chunks.append(chunk)
    
    return chunks, (width, height)