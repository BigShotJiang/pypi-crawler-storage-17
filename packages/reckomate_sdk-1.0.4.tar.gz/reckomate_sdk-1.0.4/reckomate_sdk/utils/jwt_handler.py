from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from jose import jwt, JWTError

# Default configuration
SECRET_KEY = "your-secret-key-change-in-production"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60
REFRESH_TOKEN_EXPIRE_DAYS = 7


def create_access_token(
    data: Dict[str, Any],
    secret_key: Optional[str] = None,
    expires_minutes: Optional[int] = None
) -> str:
    """
    Create a JWT access token.
    
    Args:
        data: Token payload data
        secret_key: Optional custom secret key
        expires_minutes: Optional custom expiration minutes
        
    Returns:
        JWT access token
    """
    payload = data.copy()
    payload["type"] = "access"
    payload["exp"] = datetime.utcnow() + timedelta(
        minutes=expires_minutes or ACCESS_TOKEN_EXPIRE_MINUTES
    )
    return jwt.encode(
        payload,
        secret_key or SECRET_KEY,
        algorithm=ALGORITHM
    )


def create_refresh_token(
    data: Dict[str, Any],
    secret_key: Optional[str] = None,
    expires_days: Optional[int] = None
) -> str:
    """
    Create a JWT refresh token.
    
    Args:
        data: Token payload data
        secret_key: Optional custom secret key
        expires_days: Optional custom expiration days
        
    Returns:
        JWT refresh token
    """
    payload = data.copy()
    payload["type"] = "refresh"
    payload["exp"] = datetime.utcnow() + timedelta(
        days=expires_days or REFRESH_TOKEN_EXPIRE_DAYS
    )
    return jwt.encode(
        payload,
        secret_key or SECRET_KEY,
        algorithm=ALGORITHM
    )


def verify_token(
    token: str,
    secret_key: Optional[str] = None
) -> Optional[Dict[str, Any]]:
    """
    Verify and decode a JWT token.
    
    Args:
        token: JWT token to verify
        secret_key: Optional custom secret key
        
    Returns:
        Decoded token payload or None if invalid
    """
    try:
        payload = jwt.decode(
            token,
            secret_key or SECRET_KEY,
            algorithms=[ALGORITHM]
        )
        return payload
    except JWTError:
        return None


def is_token_expired(token: str, secret_key: Optional[str] = None) -> bool:
    """
    Check if a token is expired.
    
    Args:
        token: JWT token to check
        secret_key: Optional custom secret key
        
    Returns:
        True if expired, False otherwise
    """
    payload = verify_token(token, secret_key)
    if not payload:
        return True
    
    exp = payload.get("exp")
    if not exp:
        return True
    
    return datetime.utcnow() > datetime.fromtimestamp(exp)


def refresh_access_token(
    refresh_token: str,
    secret_key: Optional[str] = None
) -> Optional[str]:
    """
    Create a new access token from a refresh token.
    
    Args:
        refresh_token: Valid refresh token
        secret_key: Optional custom secret key
        
    Returns:
        New access token or None if refresh token is invalid
    """
    payload = verify_token(refresh_token, secret_key)
    if not payload or payload.get("type") != "refresh":
        return None
    
    # Remove refresh-specific fields
    data = {k: v for k, v in payload.items() if k not in ["exp", "iat", "type"]}
    
    return create_access_token(data, secret_key)