from pydantic import BaseModel
from typing import List, Optional


class AskEasyRequest(BaseModel):
    user_id: str
    prompt: str
    file_id: str
    top_k: int = 3


class AskIntelligentRequest(BaseModel):
    user_id: str
    prompt: str
    file_id: str
    top_k: int = 5


class AskResponse(BaseModel):
    user_id: str
    answer: str
    sources: List[str]


class RAGContextRequest(BaseModel):
    user_id: str
    file_id: str
    top_k: int = 10


class QueryRewriteRequest(BaseModel):
    query: str