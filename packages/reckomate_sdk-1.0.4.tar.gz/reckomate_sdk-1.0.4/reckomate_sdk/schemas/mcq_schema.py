from pydantic import BaseModel
from typing import List, Optional, Literal


class MCQRequest(BaseModel):
    query: str
    admin_id: str
    file_id: str
    top_k: int = 1
    num_choices: int = 4
    difficulty: Literal["easy", "medium", "harder"] = "medium"


class McqAnswer(BaseModel):
    question: str
    selected_answer: str
    correct_answer: Optional[str] = None


class StoreResultBody(BaseModel):
    userId: str
    mcqId: str
    arrayofMcq: List[McqAnswer]


class MCQResponse(BaseModel):
    question: str
    options: dict
    answer_label: str
    answer: str


class MCQGenerationResponse(BaseModel):
    admin_id: str
    file_id: str
    mcq_id: str
    mcqs: List[MCQResponse]
    difficulty: str