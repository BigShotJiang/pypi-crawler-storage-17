from pydantic import BaseModel, EmailStr


class AdminRegister(BaseModel):
    email: EmailStr
    password: str


class AdminLogin(BaseModel):
    email: EmailStr
    password: str


class AdminResponse(BaseModel):
    success: bool
    admin_id: str
    email: str
    access_token: str
    refresh_token: str
    token_type: str = "bearer"