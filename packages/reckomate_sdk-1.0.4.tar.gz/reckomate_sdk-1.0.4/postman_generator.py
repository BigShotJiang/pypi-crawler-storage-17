# reckomate_sdk/postman_generator.py
import json
import importlib
import inspect
from pathlib import Path
from typing import Dict, List, Any, Optional
import httpx

def analyze_routes_module(module_path: str) -> List[Dict[str, Any]]:
    """
    Analyze a routes module to extract API endpoints.
    This is a simplified version - in production you'd use AST parsing.
    """
    try:
        # For now, we'll use a mapping based on filename
        filename = Path(module_path).name
        
        if "user_routes" in filename:
            return [
                {"method": "GET", "path": "/api/users", "name": "Get All Users"},
                {"method": "GET", "path": "/api/users/{user_id}", "name": "Get User by ID"},
                {"method": "POST", "path": "/api/users/register", "name": "Register User"},
                {"method": "POST", "path": "/api/users/login", "name": "Login User"},
                {"method": "GET", "path": "/api/users/{user_id}/mcqs", "name": "Get User's MCQs"},
                {"method": "GET", "path": "/api/users/{user_id}/results", "name": "Get User's Results"},
                {"method": "POST", "path": "/api/users/{user_id}/mcqs", "name": "Generate MCQs for User"},
                {"method": "POST", "path": "/api/users/store_results", "name": "Store User Results"}
            ]
        elif "admin_routes" in filename:
            return [
                {"method": "POST", "path": "/api/admin/register", "name": "Register Admin"},
                {"method": "POST", "path": "/api/admin/login", "name": "Login Admin"},
                {"method": "POST", "path": "/api/admin/upload", "name": "Upload File"},
                {"method": "GET", "path": "/api/admin/{admin_id}/files", "name": "Get Admin Files"},
                {"method": "POST", "path": "/api/admin/link-mobile", "name": "Link Mobile to File"}
            ]
        elif "mcq_routes" in filename:
            return [
                {"method": "GET", "path": "/api/mcqs", "name": "Get All MCQs"},
                {"method": "GET", "path": "/api/mcqs/{mcq_id}", "name": "Get MCQ by ID"},
                {"method": "POST", "path": "/api/mcqs/generate", "name": "Generate MCQs"},
                {"method": "GET", "path": "/api/mcqs/counts", "name": "Get MCQ Counts"},
                {"method": "POST", "path": "/api/mcqs/store", "name": "Store Generated MCQs"}
            ]
        elif "rag_routes" in filename:
            return [
                {"method": "POST", "path": "/api/rag/easy", "name": "Ask Easy Question"},
                {"method": "POST", "path": "/api/rag/intelligent", "name": "Ask Intelligent Question"},
                {"method": "GET", "path": "/api/rag/context", "name": "Get Context"},
                {"method": "POST", "path": "/api/rag/rewrite", "name": "Rewrite Query"}
            ]
        elif "audio_quiz_routes" in filename:
            return [
                {"method": "POST", "path": "/api/audio-quiz/start", "name": "Start Audio Quiz"},
                {"method": "POST", "path": "/api/audio-quiz/answer", "name": "Submit Answer"},
                {"method": "GET", "path": "/api/audio-quiz/{session_id}/status", "name": "Get Quiz Status"},
                {"method": "POST", "path": "/api/audio-quiz/{session_id}/end", "name": "End Quiz Session"}
            ]
        elif "video_interview_routes" in filename:
            return [
                {"method": "POST", "path": "/api/video-interview/start", "name": "Start Video Interview"},
                {"method": "POST", "path": "/api/video-interview/response", "name": "Submit Video Response"},
                {"method": "GET", "path": "/api/video-interview/{interview_id}/status", "name": "Get Interview Status"}
            ]
        elif "qdrant_routes" in filename:
            return [
                {"method": "GET", "path": "/api/qdrant/collections", "name": "Get Collections"},
                {"method": "DELETE", "path": "/api/qdrant/collection", "name": "Delete Collection"},
                {"method": "DELETE", "path": "/api/qdrant/all", "name": "Delete All Collections"},
                {"method": "GET", "path": "/api/qdrant/search", "name": "Search Vectors"}
            ]
        elif "upload_routes" in filename:
            return [
                {"method": "POST", "path": "/api/upload/file", "name": "Upload File"},
                {"method": "POST", "path": "/api/upload/audio", "name": "Upload Audio File"}
            ]
        elif "token_routes" in filename:
            return [
                {"method": "POST", "path": "/api/token/refresh", "name": "Refresh Token"},
                {"method": "POST", "path": "/api/token/verify", "name": "Verify Token"},
                {"method": "POST", "path": "/api/token/revoke", "name": "Revoke Token"}
            ]
        elif "user_scan_routes" in filename:
            return [
                {"method": "POST", "path": "/api/scan/store", "name": "Store User Scan"},
                {"method": "GET", "path": "/api/scan/{user_id}", "name": "Get User Scans"},
                {"method": "GET", "path": "/api/scan/search", "name": "Search User Scans"}
            ]
        elif "results_routes" in filename:
            return [
                {"method": "GET", "path": "/api/results", "name": "Get All Results"},
                {"method": "GET", "path": "/api/results/{result_id}", "name": "Get Result by ID"},
                {"method": "POST", "path": "/api/results/analyze", "name": "Analyze Results"}
            ]
        elif "mobile_links" in filename:
            return [
                {"method": "GET", "path": "/api/mobile/links", "name": "Get Mobile Links"},
                {"method": "POST", "path": "/api/mobile/link", "name": "Create Mobile Link"},
                {"method": "DELETE", "path": "/api/mobile/link/{link_id}", "name": "Delete Mobile Link"}
            ]
        elif "chunk_routes" in filename:
            return [
                {"method": "GET", "path": "/api/chunks", "name": "Get All Chunks"},
                {"method": "GET", "path": "/api/chunks/{chunk_id}", "name": "Get Chunk by ID"},
                {"method": "POST", "path": "/api/chunks/process", "name": "Process Chunks"}
            ]
        elif "debug_rag_routes" in filename:
            return [
                {"method": "GET", "path": "/api/debug/rag", "name": "Debug RAG"},
                {"method": "POST", "path": "/api/debug/rag/test", "name": "Test RAG"}
            ]
        else:
            return []
    except Exception as e:
        print(f"Error analyzing {module_path}: {e}")
        return []

def get_example_body(endpoint_name: str, method: str, path: str) -> Dict[str, Any]:
    """Generate example request body based on endpoint"""
    
    body_templates = {
        # User endpoints
        "Register User": {"phone": "+1234567890", "password": "password123"},
        "Login User": {"phone": "+1234567890", "password": "password123", "fcm_token": "optional_token"},
        "Register Admin": {"email": "admin@example.com", "password": "admin123"},
        "Login Admin": {"email": "admin@example.com", "password": "admin123"},
        
        # MCQ endpoints
        "Generate MCQs": {"query": "climate change", "admin_id": "admin123", "file_id": "file456"},
        "Generate MCQs for User": {"query": "machine learning", "file_id": "file789", "difficulty": "medium"},
        "Store Generated MCQs": {"user_id": "user123", "mcqs": [{"question": "Q1?", "options": ["A", "B", "C", "D"], "answer": "A"}]},
        
        # RAG endpoints
        "Ask Easy Question": {"user_id": "user123", "prompt": "What is artificial intelligence?", "file_id": "file456"},
        "Ask Intelligent Question": {"user_id": "user123", "prompt": "Explain quantum computing", "file_id": "file456"},
        "Rewrite Query": {"query": "AI machine learning deep neural networks"},
        
        # Audio Quiz endpoints
        "Start Audio Quiz": {"user_id": "user123", "file_id": "file456", "difficulty": "beginner"},
        "Submit Answer": {"session_id": "session123", "question_id": "q456", "user_answer": "Paris"},
        
        # Video Interview endpoints
        "Start Video Interview": {"user_id": "user123", "file_id": "file456", "duration": 300},
        "Submit Video Response": {"interview_id": "int123", "question_id": "q789", "video_url": "https://example.com/video.mp4"},
        
        # Scan endpoints
        "Store User Scan": {"user_id": "user123", "scan_text": "Lorem ipsum dolor sit amet", "scan_type": "document"},
        
        # Token endpoints
        "Refresh Token": {"refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."},
        "Verify Token": {"token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."},
        "Revoke Token": {"token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."},
        
        # Qdrant endpoints
        "Delete Collection": {"admin_id": "admin123", "collection_name": "documents"},
        "Search Vectors": {"query": "search query", "collection": "documents", "limit": 10},
        
        # Mobile link endpoints
        "Link Mobile to File": {"admin_id": "admin123", "mobile": "+1234567890", "file_id": "file456"},
        "Create Mobile Link": {"admin_id": "admin123", "user_id": "user456", "file_id": "file789"},
        
        # Upload endpoints
        "Upload File": {"admin_id": "admin123", "filename": "document.pdf"},
        "Upload Audio File": {"user_id": "user123", "filename": "audio.mp3"},
        
        # Results endpoints
        "Store User Results": {"userId": "user123", "mcqId": "mcq456", "arrayofMcq": [{"questionId": "q1", "selectedOption": "A", "isCorrect": True}]},
        "Analyze Results": {"user_id": "user123", "time_range": "last_week"}
    }
    
    if endpoint_name in body_templates:
        return body_templates[endpoint_name]
    
    # Default body for POST/PUT/PATCH requests
    if method in ["POST", "PUT", "PATCH"]:
        if "{user_id}" in path:
            return {"user_id": "user123"}
        elif "{admin_id}" in path:
            return {"admin_id": "admin123"}
        elif "{file_id}" in path:
            return {"file_id": "file456"}
        else:
            return {"data": "example_data"}
    
    return {}

def generate_postman_collection(
    sdk, 
    collection_name: str = "Reckomate API", 
    routes_dir: str = "."  # Directory containing route files
) -> Dict:
    """
    Generate Postman collection from actual route files.
    
    Args:
        sdk: ReckomateSDK instance
        collection_name: Name of the Postman collection
        routes_dir: Directory containing route Python files
    
    Returns:
        Postman collection JSON structure
    """
    
    # Base collection structure
    collection = {
        "info": {
            "name": collection_name,
            "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json",
            "description": "Complete Reckomate API Collection - Auto-generated from route files"
        },
        "variable": [
            {
                "key": "base_url",
                "value": sdk.base_url.rstrip('/'),
                "type": "string"
            },
            {
                "key": "auth_token",
                "value": "",
                "type": "string"
            }
        ],
        "item": []
    }
    
    # Organize endpoints by category
    categories = {}
    
    # Find all route files
    routes_path = Path(routes_dir)
    route_files = list(routes_path.glob("*_routes.py")) + list(routes_path.glob("*_routes.cpython-*.pyc"))
    
    print(f"Found {len(route_files)} route files")
    
    # Process each route file
    all_endpoints = []
    for route_file in route_files:
        if route_file.suffix == '.pyc':
            # Skip .pyc files
            continue
            
        filename = route_file.name
        category = filename.replace('_routes.py', '').replace('.py', '')
        
        print(f"Processing {filename} -> category: {category}")
        
        # Analyze the module
        endpoints = analyze_routes_module(str(route_file))
        
        if endpoints:
            categories[category] = endpoints
            all_endpoints.extend(endpoints)
    
    print(f"\nExtracted {len(all_endpoints)} endpoints across {len(categories)} categories")
    
    # Create Postman collection structure with folders
    for category, endpoints in categories.items():
        folder = {
            "name": category.replace('_', ' ').title() + " API",
            "description": f"Endpoints for {category} operations",
            "item": []
        }
        
        for endpoint in endpoints:
            method = endpoint["method"]
            path = endpoint["path"]
            name = endpoint["name"]
            
            # Determine if authentication is needed
            requires_auth = True
            if "login" in name.lower() or "register" in name.lower():
                requires_auth = False
            
            # Generate example body for non-GET methods
            body = {}
            if method in ["POST", "PUT", "PATCH"]:
                body = get_example_body(name, method, path)
            
            # Create request item
            item = {
                "name": name,
                "request": {
                    "method": method,
                    "header": [
                        {
                            "key": "Content-Type",
                            "value": "application/json",
                            "type": "text"
                        }
                    ],
                    "url": {
                        "raw": "{{base_url}}" + path,
                        "host": ["{{base_url}}"],
                        "path": path.strip("/").split("/"),
                        "variable": self._extract_path_variables(path)
                    }
                },
                "response": []
            }
            
            # Add authentication if required
            if requires_auth:
                item["request"]["auth"] = {
                    "type": "bearer",
                    "bearer": [
                        {
                            "key": "token",
                            "value": "{{auth_token}}",
                            "type": "string"
                        }
                    ]
                }
            
            # Add body for non-GET methods
            if body and method in ["POST", "PUT", "PATCH"]:
                item["request"]["body"] = {
                    "mode": "raw",
                    "raw": json.dumps(body, indent=2),
                    "options": {
                        "raw": {
                            "language": "json"
                        }
                    }
                }
            
            folder["item"].append(item)
        
        collection["item"].append(folder)
    
    # Add a pre-request script to handle authentication
    collection["event"] = [
        {
            "listen": "prerequest",
            "script": {
                "type": "text/javascript",
                "exec": [
                    "// Auto-set authentication if we have a token",
                    "if (pm.variables.get('auth_token') && pm.variables.get('auth_token') !== '') {",
                    "    pm.request.headers.add({",
                    "        key: 'Authorization',",
                    "        value: 'Bearer ' + pm.variables.get('auth_token')",
                    "    });",
                    "}"
                ]
            }
        },
        {
            "listen": "test",
            "script": {
                "type": "text/javascript",
                "exec": [
                    "// Test to extract token from login responses",
                    "try {",
                    "    var jsonData = pm.response.json();",
                    "    if (jsonData.access_token) {",
                    "        pm.variables.set('auth_token', jsonData.access_token);",
                    "        console.log('Auth token set from response');",
                    "    }",
                    "} catch (e) {",
                    "    console.log('No JSON in response or no access token');",
                    "}"
                ]
            }
        }
    ]
    
    return collection

def _extract_path_variables(path: str) -> List[Dict[str, str]]:
    """Extract path variables from a route path"""
    variables = []
    parts = path.strip("/").split("/")
    
    for part in parts:
        if part.startswith("{") and part.endswith("}"):
            var_name = part[1:-1]
            example_value = self._get_example_variable_value(var_name)
            variables.append({
                "key": var_name,
                "value": example_value,
                "description": f"Example {var_name} value"
            })
    
    return variables

def _get_example_variable_value(variable_name: str) -> str:
    """Get example value for a path variable"""
    examples = {
        "user_id": "user123",
        "admin_id": "admin123",
        "mcq_id": "mcq456",
        "file_id": "file789",
        "session_id": "session123",
        "interview_id": "int456",
        "result_id": "res789",
        "chunk_id": "chunk123",
        "link_id": "link456"
    }
    
    return examples.get(variable_name, "example_id")

def export_postman_collection(routes_dir: str = "."):
    """Export Postman collection for all SDK endpoints"""
    try:
        # Import the SDK dynamically
        from reckomate_sdk.client import ReckomateSDK
        
        sdk = ReckomateSDK(base_url="http://localhost:8000")
        
        # Get all available methods from SDK
        methods = sdk.list_all_methods()
        
        print("=== Available SDK Methods ===")
        total_methods = 0
        for service_name, service_methods in methods.items():
            print(f"\n{service_name.upper()} Service ({len(service_methods)} methods):")
            for method in service_methods:
                print(f"  • {method}")
                total_methods += 1
        
        print(f"\nTotal SDK methods available: {total_methods}")
        
        # Generate Postman collection from route files
        print(f"\n📂 Scanning route files in: {routes_dir}")
        collection = generate_postman_collection(sdk, "Reckomate API", routes_dir)
        
        # Save to file
        filename = "reckomate_postman_collection.json"
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(collection, f, indent=2)
        
        # Count total endpoints in collection
        total_endpoints = 0
        for folder in collection["item"]:
            total_endpoints += len(folder["item"])
        
        print(f"\n✅ Postman collection exported: {filename}")
        print(f"📊 Collection stats:")
        print(f"   • Folders: {len(collection['item'])}")
        print(f"   • Total endpoints: {total_endpoints}")
        print(f"   • Base URL: {sdk.base_url}")
        print("\n📁 Import this file into Postman to test all API endpoints!")
        print("\n🔐 Authentication tips:")
        print("   1. First call Login/Register endpoints")
        print("   2. Copy the 'access_token' from response")
        print("   3. Set it as 'auth_token' variable in Postman")
        print("   4. All other endpoints will auto-include the token")
        
        sdk.close()
        
        return filename
        
    except ImportError as e:
        print(f"Error importing SDK: {e}")
        print("Make sure reckomate_sdk is installed or in PYTHONPATH")
        return None
    except Exception as e:
        print(f"Error generating collection: {e}")
        return None

def generate_collection_from_live_api(base_url: str = "http://localhost:8000"):
    """
    Generate Postman collection by querying a live API's OpenAPI/Swagger endpoint.
    This is an alternative approach if the API has documentation endpoints.
    """
    try:
        client = httpx.Client(base_url=base_url, timeout=10)
        
        # Try to get OpenAPI/Swagger documentation
        endpoints_to_try = [
            "/docs",
            "/redoc", 
            "/openapi.json",
            "/swagger.json",
            "/api/docs",
            "/api/schema"
        ]
        
        schema = None
        for endpoint in endpoints_to_try:
            try:
                response = client.get(endpoint)
                if response.status_code == 200:
                    content_type = response.headers.get('content-type', '')
                    if 'json' in content_type:
                        schema = response.json()
                        print(f"Found API schema at {endpoint}")
                        break
            except:
                continue
        
        if not schema:
            print("Could not find API schema. Using static route analysis.")
            return export_postman_collection()
        
        # Parse OpenAPI schema and generate collection
        # (This would be a more advanced implementation)
        print("OpenAPI schema found, but parsing not fully implemented.")
        print("Falling back to static route analysis.")
        
        return export_postman_collection()
        
    except Exception as e:
        print(f"Error querying live API: {e}")
        return export_postman_collection()

if __name__ == "__main__":
    print("=" * 60)
    print("Reckomate Postman Collection Generator")
    print("=" * 60)
    
    # You can either:
    # 1. Generate from route files (default)
    result = export_postman_collection()
    
    # 2. Or generate from a live API (if available)
    # result = generate_collection_from_live_api("http://localhost:8000")
    
    if result:
        print(f"\n🎉 Collection generated successfully: {result}")
    else:
        print("\n❌ Failed to generate collection")