# reckomate_sdk/generate_sdk.py
import os
import re
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import inspect

def extract_routes_from_file(file_path: Path) -> List[Dict]:
    """
    Extract route definitions from a FastAPI route file.
    """
    routes = []
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Look for @router decorators
    router_pattern = r'@router\.(get|post|put|delete|patch)\(["\']([^"\']+)["\']'
    matches = re.finditer(router_pattern, content)
    
    for match in matches:
        http_method = match.group(1)  # get, post, etc.
        endpoint = match.group(2)     # /api/users, /api/mcqs/generate
        
        # Look for function definition after the decorator
        lines = content.split('\n')
        for i, line in enumerate(lines):
            if match.start() < len('\n'.join(lines[:i])):
                # Find next function definition
                for j in range(i, min(i+5, len(lines))):
                    if lines[j].strip().startswith('async def ') or lines[j].strip().startswith('def '):
                        func_line = lines[j]
                        func_name = func_line.split('def ')[1].split('(')[0].strip()
                        
                        # Try to extract parameter names
                        params = []
                        param_match = re.search(r'\((.*?)\)', func_line)
                        if param_match:
                            params_text = param_match.group(1)
                            params = [p.strip().split(':')[0].split('=')[0].strip() 
                                     for p in params_text.split(',') if p.strip() and p.strip() != 'self']
                        
                        routes.append({
                            'file': file_path.name,
                            'method': http_method.upper(),
                            'endpoint': endpoint,
                            'func_name': func_name,
                            'params': params,
                            'full_path': f"/api{endpoint}" if not endpoint.startswith('/api') else endpoint
                        })
                        break
                break
    
    return routes

def generate_service_class(route_file: Path, routes: List[Dict]) -> str:
    """
    Generate a service class from routes.
    """
    file_name = route_file.stem.replace('_routes', '').replace('_router', '')
    class_name = f"{file_name.title().replace('_', '')}Service"
    
    methods = []
    
    for route in routes:
        if route['file'] != route_file.name:
            continue
            
        # Convert endpoint to method name
        endpoint_parts = route['endpoint'].strip('/').split('/')
        method_name_parts = []
        
        for part in endpoint_parts:
            if part.startswith('{') and part.endswith('}'):
                # Path parameter
                param_name = part[1:-1]
                method_name_parts.append(f"by_{param_name}")
            else:
                # Regular part
                method_name_parts.append(part.replace('-', '_'))
        
        method_name = '_'.join(method_name_parts)
        if not method_name:
            method_name = route['func_name']
        
        # Handle duplicate method names
        existing_methods = [m['name'] for m in methods]
        if method_name in existing_methods:
            method_name = f"{method_name}_{route['method'].lower()}"
        
        # Generate method signature
        params = route['params'].copy()
        
        # Remove request/response params
        params = [p for p in params if p not in ['request', 'response', 'db', 'current_user']]
        
        # Add path parameters
        path_params = re.findall(r'\{(\w+)\}', route['endpoint'])
        for param in path_params:
            if param not in params:
                params.append(param)
        
        # Generate method
        method_code = f"""
    def {method_name}(self, {', '.join(params) if params else ''}):
        \"\"\"
        {route['method']} {route['full_path']}
        \"\"\"
        return self.sdk.{route['method'].lower()}("{route['full_path']}"
    """
        
        methods.append({
            'name': method_name,
            'code': method_code,
            'route': route
        })
    
    # Generate class
    class_code = f"""
class {class_name}(BaseService):
    \"\"\"Proxy to {file_name.replace('_', ' ')} API endpoints\"\"\"
    
"""
    
    for method in methods:
        class_code += method['code']
    
    return class_code

def main():
    # Path to your backend routes
    routes_dir = Path("E:/Reckomate_SDK/app/routes")
    
    if not routes_dir.exists():
        print(f"Routes directory not found: {routes_dir}")
        return
    
    all_routes = []
    
    # Collect all routes
    for route_file in routes_dir.glob("*.py"):
        if route_file.name.startswith('__'):
            continue
            
        print(f"Processing {route_file.name}...")
        routes = extract_routes_from_file(route_file)
        all_routes.extend(routes)
    
    # Group by file
    routes_by_file = {}
    for route in all_routes:
        if route['file'] not in routes_by_file:
            routes_by_file[route['file']] = []
        routes_by_file[route['file']].append(route)
    
    # Generate service classes
    services = []
    for route_file, routes in routes_by_file.items():
        service_code = generate_service_class(Path(route_file), routes)
        services.append(service_code)
        
        print(f"\n=== Generated from {route_file} ===")
        for route in routes:
            print(f"  {route['method']} {route['full_path']} -> {route['func_name']}")
    
    # Generate complete proxy_services.py
    proxy_code = '''"""
AUTOGENERATED PROXY SERVICES
Generated from FastAPI route files.

Usage in SDK:
    sdk.user.register(...)  # Calls POST /api/users/register
    sdk.mcq.generate(...)   # Calls POST /api/mcqs/generate
"""

import logging
from typing import Dict, Any, List, Optional
from ..exceptions import APIError

logger = logging.getLogger(__name__)


class BaseService:
    """Base service for all proxy services"""
    
    def __init__(self, sdk):
        self.sdk = sdk

'''
    
    for service in services:
        proxy_code += service + "\n\n"
    
    # Save to file
    output_path = Path(__file__).parent / "services" / "proxy_services.py"
    output_path.parent.mkdir(exist_ok=True)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(proxy_code)
    
    print(f"\n✅ Generated {len(all_routes)} routes in {output_path}")
    print(f"📊 Routes by method:")
    methods_count = {}
    for route in all_routes:
        methods_count[route['method']] = methods_count.get(route['method'], 0) + 1
    
    for method, count in methods_count.items():
        print(f"  {method}: {count}")

if __name__ == "__main__":
    main()