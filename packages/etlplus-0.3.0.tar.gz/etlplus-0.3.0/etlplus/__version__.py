"""
etlplus.__version__ module.

Stores the current version of the package.
"""

__version__ = '0.3.0'
