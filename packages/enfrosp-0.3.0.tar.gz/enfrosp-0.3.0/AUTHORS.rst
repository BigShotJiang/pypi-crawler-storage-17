=======
Credits
=======

Development Lead
----------------

* Daniel Scheffler <danschef@gfz.de> (Python implementation)
* Alexander Kokhanosvky <kokhanov@gfz.de> (algorithm)
* Karl Segl <segl@gfz.de> (algorithm)

Contributors
------------

None yet. Why not be the first?
