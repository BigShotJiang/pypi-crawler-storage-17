"""Generators for creating output from transcription results."""
