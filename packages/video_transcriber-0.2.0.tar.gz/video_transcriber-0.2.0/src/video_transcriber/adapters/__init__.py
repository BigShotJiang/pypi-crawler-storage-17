"""Concrete adapter implementations."""

from .opencv_video import OpenCVVideoAdapter

__all__ = ["OpenCVVideoAdapter"]