"""
Finder Enrichment AI Client Package

A lightweight package for managing AI API calls to various providers.
Supports Google Gemini AI and OpenRouter (which provides access to multiple LLM providers).
"""

from .finder_enrichment_google_ai_client import FinderEnrichmentGoogleAIClient
from .finder_enrichment_openrouter_client import FinderEnrichmentOpenRouterClient
from .config_loader import (
    load_model_config,
    get_model_config_by_name,
    get_openrouter_model_id,
    get_openrouter_base_url
)

__all__ = [
    "FinderEnrichmentGoogleAIClient",
    "FinderEnrichmentOpenRouterClient",
    "load_model_config",
    "get_model_config_by_name",
    "get_openrouter_model_id",
    "get_openrouter_base_url"
]

