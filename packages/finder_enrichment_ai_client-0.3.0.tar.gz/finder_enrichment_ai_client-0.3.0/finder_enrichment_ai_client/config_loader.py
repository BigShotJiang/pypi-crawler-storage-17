"""
Configuration loader for model mappings.
Loads config.yaml and provides helper functions to map model names to provider-specific IDs.
"""
import yaml
from pathlib import Path
from typing import Dict, Optional


def load_model_config() -> Dict:
    """
    Load the model configuration from config.yaml.
    
    Returns:
        Dictionary containing the model configuration
        
    Raises:
        FileNotFoundError: If the config file cannot be found
        yaml.YAMLError: If the config file is invalid
    """
    # Look for config.yaml at the project root (3 levels up from this file)
    config_path = Path(__file__).parent.parent.parent.parent / "config.yaml"
    
    if not config_path.exists():
        raise FileNotFoundError(
            f"Configuration file not found at: {config_path}. "
            f"Please ensure config.yaml exists in the project root."
        )
    
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    return config


def get_model_config_by_name(model_name: str) -> Optional[Dict]:
    """
    Get the full model configuration for a given model name.
    
    Args:
        model_name: The friendly model name (e.g., "claude-3-5-sonnet")
        
    Returns:
        Dictionary with model configuration including 'name', 'model_id', and 'provider'
        Returns None if model not found
    """
    config = load_model_config()
    
    for model in config.get('models', []):
        if model.get('name') == model_name:
            return model
    
    return None


def get_openrouter_model_id(model_name: str) -> str:
    """
    Look up the OpenRouter model_id for a given model name.
    
    Args:
        model_name: The friendly model name (e.g., "claude-3-5-sonnet")
        
    Returns:
        The OpenRouter model_id (e.g., "anthropic/claude-3.5-sonnet")
        
    Raises:
        ValueError: If the model name is not found in the configuration
    """
    model_config = get_model_config_by_name(model_name)
    
    if not model_config:
        # Provide helpful error message with available models
        config = load_model_config()
        available_models = [m.get('name') for m in config.get('models', []) if m.get('name')]
        raise ValueError(
            f"Model '{model_name}' not found in config.yaml. "
            f"Available models: {', '.join(available_models)}"
        )
    
    model_id = model_config.get('model_id')
    if not model_id:
        raise ValueError(f"Model '{model_name}' found in config but has no model_id")
    
    return model_id


def get_openrouter_base_url() -> str:
    """
    Get the OpenRouter base URL from config.yaml.
    
    Returns:
        The OpenRouter base URL (e.g., "https://openrouter.ai/api/v1")
    """
    config = load_model_config()
    return config.get('openrouter', {}).get('base_url', 'https://openrouter.ai/api/v1')

