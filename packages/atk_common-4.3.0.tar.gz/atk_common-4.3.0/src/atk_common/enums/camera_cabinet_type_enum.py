from enum import Enum
 
class CameraCabinetType(Enum):
    NORMAL = 1
    TUNNEL = 2
