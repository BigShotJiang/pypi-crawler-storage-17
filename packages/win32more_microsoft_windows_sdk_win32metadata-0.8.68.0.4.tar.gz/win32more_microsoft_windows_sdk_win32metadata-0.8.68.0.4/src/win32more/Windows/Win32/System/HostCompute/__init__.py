from __future__ import annotations
from win32more._prelude import *
import win32more.Windows.Win32.System.HostCompute
HCS_CALLBACK = VoidPtr


make_ready(__name__)
