from __future__ import annotations
from win32more._prelude import *
import win32more.Windows.Win32.Graphics.Hlsl
D3DCOMPILE_OPTIMIZATION_LEVEL2: UInt32 = 49152
D3D_COMPILE_STANDARD_FILE_INCLUDE: UInt32 = 1


make_ready(__name__)
