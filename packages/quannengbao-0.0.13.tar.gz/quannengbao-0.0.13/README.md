# quannengbao
### 需要显示安装全能包指定路径
- pip install --updgrade quannengbao 
### quannengbao安装完成后另外安装bytedtqs
- 内网web环境安装新版 bytedtqs
  - pip install --upgrade bytedtqs --index-url=https://bytedpypi.byted.org/simple/
- 本地环境安装旧版 bytedtqs
  - pip install bytedtqs==0.0.50 --index-url=https://bytedpypi.byted.org/simple/

