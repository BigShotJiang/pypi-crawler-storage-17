"""n8n CLI - A command-line interface for interacting with n8n."""

__version__ = "0.3.5"
