"""Tests for n8n-cli."""
