### for ep.pp.neighbors
TEMPORARY_TIMESERIES_NEIGHBORS_USE_REP_KEY = "indices_timeseries_neighbors"

### for ep.pp.filter
MISSING_VALUE_COUNT_KEY_2D = "n_nonmissing"
MISSING_VALUE_COUNT_KEY_3D = "n_nonmissing_over_time"
