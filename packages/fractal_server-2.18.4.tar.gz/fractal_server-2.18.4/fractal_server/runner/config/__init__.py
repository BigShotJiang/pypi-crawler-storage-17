from ._local import JobRunnerConfigLocal  # noqa F401
from ._slurm import JobRunnerConfigSLURM  # noqa F401
