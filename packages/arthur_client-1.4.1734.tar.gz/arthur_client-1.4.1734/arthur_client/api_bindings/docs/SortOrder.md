# SortOrder


## Enum

* `ASC` (value: `'asc'`)

* `DESC` (value: `'desc'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


