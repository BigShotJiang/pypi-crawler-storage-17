"""Models defined in fabricatio-capabilities."""
