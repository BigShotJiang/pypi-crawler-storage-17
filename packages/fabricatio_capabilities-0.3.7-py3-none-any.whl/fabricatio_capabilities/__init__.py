"""A foundational Python library providing core capabilities for building LLM-driven applications using an event-based agent structure.."""
