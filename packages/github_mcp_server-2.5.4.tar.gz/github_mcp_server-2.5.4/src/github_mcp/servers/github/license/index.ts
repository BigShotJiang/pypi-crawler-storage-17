export * from './github-license-info.js';
