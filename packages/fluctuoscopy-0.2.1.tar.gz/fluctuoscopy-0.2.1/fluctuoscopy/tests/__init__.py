"""Tests for fluctuoscopy module."""
