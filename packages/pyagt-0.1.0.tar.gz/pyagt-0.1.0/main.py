def main():
    print("Hello from agt!")


if __name__ == "__main__":
    main()
