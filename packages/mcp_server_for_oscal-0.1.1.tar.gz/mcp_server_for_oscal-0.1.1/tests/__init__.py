"""
OSCAL MCP Server tests

This package contains all tests the OSCAL MCP server.
"""
