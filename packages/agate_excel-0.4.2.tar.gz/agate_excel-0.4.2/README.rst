.. image:: https://github.com/wireservice/agate-excel/workflows/CI/badge.svg
    :target: https://github.com/wireservice/agate-excel/actions
    :alt: Build status

.. image:: https://coveralls.io/repos/wireservice/agate-excel/badge.svg?branch=master
    :target: https://coveralls.io/r/wireservice/agate-excel
    :alt: Coverage status

.. image:: https://img.shields.io/pypi/dm/agate-excel.svg
    :target: https://pypi.python.org/pypi/agate-excel
    :alt: PyPI downloads

.. image:: https://img.shields.io/pypi/v/agate-excel.svg
    :target: https://pypi.python.org/pypi/agate-excel
    :alt: Version

.. image:: https://img.shields.io/pypi/l/agate-excel.svg
    :target: https://pypi.python.org/pypi/agate-excel
    :alt: License

.. image:: https://img.shields.io/pypi/pyversions/agate-excel.svg
    :target: https://pypi.python.org/pypi/agate-excel
    :alt: Support Python versions

agate-excel adds read support for Excel files (xls and xlsx) to `agate <https://github.com/wireservice/agate>`_.

Important links:

* agate             https://agate.rtfd.org
* Documentation:    https://agate-excel.rtfd.org
* Repository:       https://github.com/wireservice/agate-excel
* Issues:           https://github.com/wireservice/agate-excel/issues
