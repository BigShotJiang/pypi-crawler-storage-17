The following individuals have contributed code to agate-excel:

* `Christopher Groskopf <https://github.com/onyxfish>`_
* `Ben Welsh <https://github.com/palewire>`_
* `James McKinney <https://github.com/jpmckinney>`_
* `Peter M. Landwehr <https://github.com/pmlandwehr>`_
* `Jani Mikkonen <https://github.com/rasjani>`_
* `Tim Freund <https://github.com/timfreund>`_
* `Loïc Corbasson <https://github.com/lcorbasson>`_
* `Robert Schütz <https://github.com/dotlambda>`_
