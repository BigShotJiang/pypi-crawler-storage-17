"""
Mediascope API library
"""
version = '1.6.2'
