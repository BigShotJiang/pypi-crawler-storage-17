"""
Main module entry point for mcp-simple-pubmed.
"""
from .server import main

if __name__ == "__main__":
    main()