"""Web routes."""

from compose_farm.web.routes import actions, api, pages

__all__ = ["actions", "api", "pages"]
