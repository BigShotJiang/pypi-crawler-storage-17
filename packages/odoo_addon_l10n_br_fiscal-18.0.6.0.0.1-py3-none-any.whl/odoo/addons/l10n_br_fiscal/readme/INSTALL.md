Para instalar o módulo l10n_br_fiscal, você precisa de instalar primeiro
os pacotes Python

- erpbrasil.base
- erpbrasil.assinatura
