from .decorators import slurm

__all__ = ["slurm"]
