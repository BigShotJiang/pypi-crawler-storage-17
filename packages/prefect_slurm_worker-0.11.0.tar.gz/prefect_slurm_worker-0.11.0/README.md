# prefect-slurm-worker (work in progress)

prefect work pool for interaction with SLURM and Apptainer

## Installation

```sh
pip install prefect-slurm-worker
```


## Features

* SLURM Worker
* Apptainer SLURM Worker
