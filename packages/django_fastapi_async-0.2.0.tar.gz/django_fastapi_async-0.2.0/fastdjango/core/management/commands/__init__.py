"""
FastDjango management commands.
"""
