"""
FastDjango contrib modules.
Similar to Django's contrib apps.
"""
