from setuptools import setup, find_packages

setup(
    name="costgov",
    packages=find_packages(),
)
