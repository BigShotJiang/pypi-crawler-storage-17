"""Tests for the nrgkick-api library."""
