from .image_text_pair_classification import AbsTaskImageTextPairClassification

__all__ = [
    "AbsTaskImageTextPairClassification",
]
