# Generated file
# - do not overwrite
# - do not include in git
from collections import namedtuple

BuildInfo = namedtuple(
    'BuildInfo',
    ['version', 'built_at', 'sha', 'branch', 'tag'],
)

BUILD_INFO = BuildInfo(
    version='v4.25.1~31a01b8',
    built_at='2025-12-19 12:48:09Z',
    sha='31a01b81b38254d1f771f4b109b60550a1debfa2',
    branch='HEAD',
    tag='v4.25.1',
)
