.. _utils:

====================================================
Utilities (`~magicctapipe.utils`)
====================================================

.. currentmodule:: magicctapipe.utils

Reference/API
=============

.. automodapi:: magicctapipe.utils
    :no-inheritance-diagram:
