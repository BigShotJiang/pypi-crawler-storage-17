.. _io:

==================================================
IO (`~magicctapipe.io`)
==================================================

.. currentmodule:: magicctapipe.io

Reference/API
=============

.. automodapi:: magicctapipe.io
    :no-inheritance-diagram:
