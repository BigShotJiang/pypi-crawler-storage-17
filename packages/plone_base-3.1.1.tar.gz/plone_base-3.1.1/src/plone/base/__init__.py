from zope.i18nmessageid import MessageFactory


# create messages in the plone domain
PloneMessageFactory = MessageFactory("plone")

# create messages in the plonelocales domain
PloneLocalesMessageFactory = MessageFactory("plonelocales")
