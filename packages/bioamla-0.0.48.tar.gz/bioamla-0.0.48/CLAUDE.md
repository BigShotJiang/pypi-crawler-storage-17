## Instructions for Claude

When implmenting new functionality.
* this repo is in alpha, do not implement backwards compatability
* make changes to core modules first
* add unit tests for core modules
* run tests on core modules
* then make changes in cli modules
* add unit tests for cli modules
* run all tests
* update readme.md