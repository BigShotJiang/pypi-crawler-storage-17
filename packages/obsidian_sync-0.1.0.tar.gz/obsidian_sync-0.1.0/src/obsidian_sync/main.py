import click
from obsidian_sync.commands.init import init
from obsidian_sync.commands.sync import push, pull
from obsidian_sync.commands.schedule import cron_setup

@click.group()
def cli():
    """
    A CLI tool to synchronize Obsidian vaults using GitHub.
    """
    pass

cli.add_command(init)
cli.add_command(push)
cli.add_command(pull)
cli.add_command(cron_setup)

if __name__ == '__main__':
    cli()
