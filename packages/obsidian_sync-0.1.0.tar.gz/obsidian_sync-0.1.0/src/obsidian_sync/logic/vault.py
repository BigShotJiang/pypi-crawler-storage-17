import platform
from pathlib import Path
from typing import Optional, List
import os

def get_obsidian_vault_paths() -> List[Path]:
    """
    Detects the default locations of Obsidian vaults based on the OS.

    Returns:
        A list of potential vault paths.
    """
    system = platform.system()
    home = Path.home()
    paths = []

    if system == "Darwin":  # macOS
        # iCloud Drive
        icloud_path = home / "Library/Mobile Documents/iCloud~md~obsidian/Documents"
        if icloud_path.exists():
            paths.append(icloud_path)
        # Standard app support
        app_support_path = home / "Library/Application Support/obsidian"
        if app_support_path.exists():
            # In macOS, vaults are often stored in the user's Documents folder or elsewhere,
            # and Obsidian's app support dir just contains settings.
            # We will look for a common pattern of a .obsidian folder inside a directory.
            # This is a heuristic and may not be perfect.
            for potential_vault in home.iterdir():
                if potential_vault.is_dir() and (potential_vault / ".obsidian").exists():
                    paths.append(potential_vault)

    elif system == "Linux":
        # Vaults are often stored in user-defined locations, but we can check common spots.
        # The .config/obsidian directory stores app-level settings, not vaults.
        # We can scan the home directory for folders containing a .obsidian directory.
        for potential_vault in home.iterdir():
            if potential_vault.is_dir() and (potential_vault / ".obsidian").exists():
                paths.append(potential_vault)

    elif system == "Windows":
        appdata_path = Path(os.getenv("APPDATA"))
        obsidian_path = appdata_path / "obsidian"
        if obsidian_path.exists():
             # Similar to other OSes, this dir often has settings, not the vault itself.
             # We scan for folders with .obsidian in common locations like Documents.
            documents = home / "Documents"
            for potential_vault in documents.iterdir():
                 if potential_vault.is_dir() and (potential_vault / ".obsidian").exists():
                    paths.append(potential_vault)

    # Return unique paths
    return list(set(paths))

def find_vault() -> Optional[Path]:
    """
    Finds the most likely Obsidian vault.

    Returns:
        The path to the vault, or None if not found.
    """
    paths = get_obsidian_vault_paths()
    if paths:
        # A simple heuristic: return the first one found.
        # A more complex implementation could ask the user if multiple are found.
        return paths[0]
    return None
