import git
from pathlib import Path

class GitOps:
    """A wrapper for core Git operations using GitPython."""

    def __init__(self, repo_path: Path):
        """
        Initializes the GitOps class.

        Args:
            repo_path: The path to the Git repository.
        """
        self.repo_path = repo_path
        self.repo = self._get_or_init_repo()

    def _get_or_init_repo(self) -> git.Repo:
        """
        Gets the Git repository object or initializes a new one if it doesn't exist.

        Returns:
            The Git repository object.
        """
        if (self.repo_path / ".git").exists():
            return git.Repo(self.repo_path)
        else:
            return git.Repo.init(self.repo_path)

    def add_all(self):
        """Stages all changes in the repository."""
        self.repo.git.add(A=True)

    def commit(self, message: str) -> git.Commit:
        """
        Commits staged changes.

        Args:
            message: The commit message.

        Returns:
            The new commit object.
        """
        return self.repo.index.commit(message)

    def push(self, remote_name: str = "origin", branch: str = "main"):
        """
        Pushes commits to a remote repository.

        Args:
            remote_name: The name of the remote to push to.
            branch: The branch to push.
        """
        self.repo.remote(remote_name).push(refspec=f"{branch}:{branch}")

    def pull(self, remote_name: str = "origin", branch: str = "main"):
        """
        Pulls changes from a remote repository.

        Args:
            remote_name: The name of the remote to pull from.
            branch: The branch to pull.
        """
        self.repo.remote(remote_name).pull(refspec=f"{branch}:{branch}")

    def get_status(self) -> str:
        """
        Gets the status of the repository.

        Returns:
            The output of `git status`.
        """
        return self.repo.git.status()

    def set_remote(self, remote_name: str, remote_url: str):
        """
        Adds or updates a remote.

        Args:
            remote_name: The name of the remote.
            remote_url: The URL of the remote.
        """
        if remote_name in [r.name for r in self.repo.remotes]:
            self.repo.delete_remote(remote_name)
        self.repo.create_remote(remote_name, remote_url)
