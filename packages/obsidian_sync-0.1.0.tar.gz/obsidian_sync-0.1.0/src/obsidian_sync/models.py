from typing import List, Optional
from pydantic import BaseModel, Field

class VaultConfig(BaseModel):
    """Represents a single vault's configuration."""
    vault_path: str = Field(..., description="The absolute path to the local Obsidian vault directory.")
    repo_url: str = Field(..., description="The SSH or HTTPS URL of the remote GitHub repository.")
    last_sync_time: Optional[str] = Field(None, description="An ISO 8601 timestamp of the last successful sync.")

class SyncConfiguration(BaseModel):
    """Represents the main configuration for the sync tool."""
    vaults: List[VaultConfig] = []
