import click
from pathlib import Path
from typing import Optional
import json

from obsidian_sync.logic.git_ops import GitOps
from obsidian_sync.models import SyncConfiguration

CONFIG_DIR = Path.home() / ".config" / "obsidian-sync"
CONFIG_FILE = CONFIG_DIR / "config.json"

def get_vault_path_from_config(vault_path_str: Optional[str]) -> Path:
    """Gets the vault path from the config file."""
    if not CONFIG_FILE.exists():
        click.echo("Error: Configuration file not found. Please run 'obsidian-sync init' first.", err=True)
        raise click.Abort()

    sync_config = SyncConfiguration.parse_file(CONFIG_FILE)
    if not sync_config.vaults:
        click.echo("Error: No vaults configured. Please run 'obsidian-sync init' first.", err=True)
        raise click.Abort()

    if vault_path_str:
        vault_path = Path(vault_path_str)
        if not any(vc.vault_path == str(vault_path) for vc in sync_config.vaults):
            click.echo(f"Error: Vault path '{vault_path}' not found in configuration.", err=True)
            raise click.Abort()
        return vault_path
    elif len(sync_config.vaults) == 1:
        return Path(sync_config.vaults[0].vault_path)
    else:
        click.echo("Error: Multiple vaults configured. Please specify which one to sync with the --vault-path option.", err=True)
        raise click.Abort()

@click.command()
@click.option("--vault-path", default=None, type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path), help="The path to the vault to sync.")
@click.option("-m", "--message", "commit_message", default="Sync from obsidian-sync", help="The commit message.")
def push(vault_path: Optional[Path], commit_message: str):
    """
    Commits and pushes local changes to the remote repository.
    """
    try:
        click.echo("Pushing local changes...")
        path = get_vault_path_from_config(str(vault_path) if vault_path else None)
        git_ops = GitOps(repo_path=path)
        
        git_ops.add_all()
        git_ops.commit(commit_message)
        click.echo(f"Committed changes with message: '{commit_message}'")
        
        git_ops.push()
        click.echo("Successfully pushed changes to remote repository.")
    except Exception as e:
        if "nothing to commit" in str(e).lower():
            click.echo("No new changes to commit.")
            return
        click.echo(f"Error during push operation: {e}", err=True)
        raise click.Abort()

@click.command()
@click.option("--vault-path", default=None, type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path), help="The path to the vault to sync.")
def pull(vault_path: Optional[Path]):
    """
    Pulls remote changes from the repository.
    """
    try:
        click.echo("Pulling remote changes...")
        path = get_vault_path_from_config(str(vault_path) if vault_path else None)
        git_ops = GitOps(repo_path=path)
        git_ops.pull()
        click.echo("Successfully pulled changes from remote repository.")
    except Exception as e:
        click.echo(f"Error during pull operation: {e}", err=True)
        click.echo("Please check for network issues or merge conflicts.", err=True)
        raise click.Abort()