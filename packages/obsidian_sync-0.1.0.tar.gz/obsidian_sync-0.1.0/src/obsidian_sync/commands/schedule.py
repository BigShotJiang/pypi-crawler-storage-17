import click
import platform
import subprocess

@click.command()
@click.option("--schedule", required=True, help="The schedule in cron format (e.g., '*/15 * * * *').")
@click.option("--vault-path", default=None, help="The path to the vault to sync.")
def cron_setup(schedule: str, vault_path: str):
    """
    Helps the user set up a scheduled task for automatic syncing.
    """
    system = platform.system()
    command_to_schedule = f"obsidian-sync push"
    if vault_path:
        command_to_schedule += f" --vault-path {vault_path}"

    click.echo(f"Setting up scheduled task for command: '{command_to_schedule}'")
    click.echo(f"Schedule: {schedule}")
    click.echo(f"System: {system}")

    if system == "Linux" or system == "Darwin":
        click.echo("\nRun the following command to open your crontab for editing:")
        click.echo("crontab -e")
        click.echo("\nThen add the following line to the file and save it:")
        click.echo(f'{schedule} {command_to_schedule}')
        # Optionally, try to add it programmatically with python-crontab
        try:
            from crontab import CronTab
            user_cron = CronTab(user=True)
            job = user_cron.new(command=command_to_schedule, comment='Obsidian Sync')
            job.setall(schedule)
            user_cron.write()
            click.echo("\nSuccessfully added the cron job automatically.")
        except ImportError:
            click.echo("\nTo add the cron job automatically, please install 'python-crontab': pip install python-crontab", err=True)
        except Exception as e:
            click.echo(f"\nCould not automatically add the cron job: {e}", err=True)
            click.echo("Please add it manually using 'crontab -e'.", err=True)

    elif system == "Windows":
        task_name = "ObsidianSync"
        # The command to run is cmd /c "path/to/obsidian-sync push"
        # We need to find the path to the obsidian-sync executable.
        # This is non-trivial and depends on the Python installation.
        # For now, we will just print the command for the user to adapt.
        
        click.echo("\nRun the following command in PowerShell or CMD to create a scheduled task:")
        # This is a simplified example; a real implementation would need to handle minutes/hourly/daily etc.
        try:
            minutes = schedule.split()[0].replace("*/", "")
            schtasks_command = f'schtasks /create /tn {task_name} /tr "obsidian-sync push" /sc minute /mo {minutes}'
            click.echo(schtasks_command)
            click.echo("\nNote: You may need to provide the full path to the 'obsidian-sync' executable in the /tr argument.")
            click.echo("Example: /tr \"C:\\Users\\YourUser\\...\\obsidian-sync.exe push\"")
        except Exception:
            click.echo("Could not parse schedule for schtasks. Please create the task manually via the Task Scheduler UI.", err=True)

    else:
        click.echo(f"\nUnsupported operating system: {system}", err=True)
        click.echo("Please set up a scheduled task manually using your OS's tools.", err=True)