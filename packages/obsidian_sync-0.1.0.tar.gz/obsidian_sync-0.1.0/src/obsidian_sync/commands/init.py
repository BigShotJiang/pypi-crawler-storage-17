import click
from pathlib import Path
from typing import Optional
import json

from obsidian_sync.logic.vault import find_vault
from obsidian_sync.logic.git_ops import GitOps
from obsidian_sync.models import SyncConfiguration, VaultConfig

CONFIG_DIR = Path.home() / ".config" / "obsidian-sync"
CONFIG_FILE = CONFIG_DIR / "config.json"

@click.command()
@click.option("--repo-url", required=True, help="The SSH or HTTPS URL of the remote GitHub repository.")
@click.option("--vault-path", default=None, type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path), help="Absolute path to the Obsidian vault. If not provided, the tool will attempt to auto-detect it.")
def init(repo_url: str, vault_path: Optional[Path]):
    """
    Initializes a new sync configuration.
    """
    click.echo("Initializing Obsidian Sync...")

    # 1. Determine vault path
    if not vault_path:
        click.echo("Vault path not provided, attempting to auto-detect...")
        vault_path = find_vault()
        if not vault_path:
            click.echo("Error: Could not automatically find your Obsidian vault. Please provide the path using the --vault-path option.", err=True)
            raise click.Abort()
        click.echo(f"Found vault at: {vault_path}")

    # 2. Handle Git repository
    try:
        git_ops = GitOps(repo_path=vault_path)
        git_ops.set_remote("origin", repo_url)
        click.echo(f"Git repository initialized in {vault_path}")
        click.echo(f"Remote 'origin' set to: {repo_url}")
    except Exception as e:
        click.echo(f"Error initializing Git repository: {e}", err=True)
        raise click.Abort()

    # 3. Create and save configuration
    try:
        CONFIG_DIR.mkdir(exist_ok=True)
        
        if CONFIG_FILE.exists():
            sync_config = SyncConfiguration.parse_file(CONFIG_FILE)
        else:
            sync_config = SyncConfiguration()

        if any(vc.vault_path == str(vault_path) for vc in sync_config.vaults):
            click.echo(f"Vault at {vault_path} is already configured. Updating remote URL.")
            for vc in sync_config.vaults:
                if vc.vault_path == str(vault_path):
                    vc.repo_url = repo_url
                    break
        else:
            new_vault_config = VaultConfig(vault_path=str(vault_path), repo_url=repo_url)
            sync_config.vaults.append(new_vault_config)

        with open(CONFIG_FILE, "w") as f:
            f.write(sync_config.json(indent=4))
        click.echo(f"Configuration saved to {CONFIG_FILE}")
    except Exception as e:
        click.echo(f"Error: Failed to create or update configuration file at {CONFIG_FILE}.", err=True)
        click.echo(f"Details: {e}", err=True)
        raise click.Abort()

    # 4. Initial commit and push
    click.echo("Performing initial sync...")
    try:
        git_ops.add_all()
        git_ops.commit("Initial commit from obsidian-sync")
        click.echo("Committed all files.")
        git_ops.push()
        click.echo("Successfully pushed initial vault contents to remote repository.")
    except Exception as e:
        if "nothing to commit" in str(e).lower():
            click.echo("No new changes to commit. Vault is already up to date.")
        else:
            click.echo(f"Error: Failed during initial git operation.", err=True)
            click.echo(f"Details: {e}", err=True)
            click.echo("Please ensure your repository URL is correct, you have the necessary permissions, and your vault is not empty.", err=True)
            raise click.Abort()
            
    click.echo("Initialization complete!")