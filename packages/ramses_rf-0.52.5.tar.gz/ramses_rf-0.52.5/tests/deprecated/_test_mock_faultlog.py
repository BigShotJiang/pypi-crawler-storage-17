# TODO: get_faultlog()
# TODO: get_faultlog(force_refresh=True)
