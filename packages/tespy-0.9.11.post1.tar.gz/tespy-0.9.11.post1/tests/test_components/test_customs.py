# -*- coding: utf-8

"""Module for testing components of type orc evaporator.
This file is part of project TESPy (github.com/oemof/tespy). It's copyrighted
by the contributors recorded in the version control history of the file,
available from its original location
tests/test_components/test_customs.py
SPDX-License-Identifier: MIT
"""
