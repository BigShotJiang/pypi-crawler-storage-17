.. _support_label:

#######
Support
#######

If you need professional support on a frequent basis, e.g. to implement custom
models, integrate tespy models in toolchains or build applications based on
tespy, you can contact
`me directly <https://github.com/oemof/tespy/blob/dev/pyproject.toml#L31>`__.
