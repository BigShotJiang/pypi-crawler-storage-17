##########################
Carrier Subdivision Module
##########################

The *Carrier Subdivision Module* adds the subdivisions as criteria for carrier
selection.

.. toctree::
   :maxdepth: 2

   design
   releases
