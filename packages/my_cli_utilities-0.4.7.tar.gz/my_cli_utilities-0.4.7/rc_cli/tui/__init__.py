"""TUI modules for rc_cli.

This package contains Textual apps and shared UI assets.
"""


