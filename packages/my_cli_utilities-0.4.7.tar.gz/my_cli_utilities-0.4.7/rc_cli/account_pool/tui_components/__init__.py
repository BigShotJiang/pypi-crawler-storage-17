"""Account Pool TUI components (internal).

The public entrypoint remains `rc_cli.account_pool.tui`.
"""


