# -*- coding: utf-8 -*-

"""FFS TUI module - exports run_tui function."""

from .app import run_tui

__all__ = ["run_tui"]

