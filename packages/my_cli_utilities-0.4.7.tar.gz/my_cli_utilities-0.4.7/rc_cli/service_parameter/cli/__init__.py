"""CLI command registration for Service Parameter module."""


