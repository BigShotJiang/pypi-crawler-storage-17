.. _c_earnings_per_share_ref:

c_earnings_per_share
====================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_earnings_per_share
   :no-index:
