.. _c_last_twelve_months_revenue_ref:

c_last_twelve_months_revenue
============================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_last_twelve_months_revenue
   :no-index:
