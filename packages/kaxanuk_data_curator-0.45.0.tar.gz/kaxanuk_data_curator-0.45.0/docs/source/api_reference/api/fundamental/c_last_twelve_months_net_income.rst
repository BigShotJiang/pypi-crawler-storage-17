.. _c_last_twelve_months_net_income_ref:

c_last_twelve_months_net_income
===============================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_last_twelve_months_net_income
   :no-index:
