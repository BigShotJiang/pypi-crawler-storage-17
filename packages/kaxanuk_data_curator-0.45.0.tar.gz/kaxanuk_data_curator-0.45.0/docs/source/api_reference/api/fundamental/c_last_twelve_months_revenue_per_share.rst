.. _c_last_twelve_months_revenue_per_share_ref:

c_last_twelve_months_revenue_per_share
======================================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_last_twelve_months_revenue_per_share
   :no-index:
