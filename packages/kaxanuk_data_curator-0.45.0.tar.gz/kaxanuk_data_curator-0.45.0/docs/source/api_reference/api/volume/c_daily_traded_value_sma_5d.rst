.. _c_daily_traded_value_sma_5d_ref:

c_daily_traded_value_sma_5d
===========================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_daily_traded_value_sma_5d
   :no-index:
