def c_sum_mhigh_and_mlow(
    m_high,
    m_low
):
    return m_high + m_low


def c_multiply_sum_by_mclose(
    c_sum_mhigh_and_mlow,
    m_close
):
    return c_sum_mhigh_and_mlow * m_close
