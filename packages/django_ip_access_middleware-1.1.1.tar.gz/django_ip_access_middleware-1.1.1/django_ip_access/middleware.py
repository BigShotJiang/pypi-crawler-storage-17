"""
Middleware module - convenience import
"""
from django_ip_access.ip_access_middleware import IPAccessMiddleware

__all__ = ['IPAccessMiddleware']

