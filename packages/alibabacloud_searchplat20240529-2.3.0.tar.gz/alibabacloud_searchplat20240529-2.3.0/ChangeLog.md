2025-06-26 Version: 2.2.0
- Support API CreateAudioAsrTask.
- Support API CreateVideoSnapshotTask.
- Support API GetAudioAsrTaskStatus.
- Support API GetVideoSnapshotTaskStatus.
- Update API GetWebSearch: add request parameters body.content_type.
- Update API GetWebSearch: add request parameters body.history.
- Update API GetWebSearch: add request parameters body.query_rewrite.


2025-05-20 Version: 2.1.0
- Support API GetMultiModalEmbedding.


2025-04-09 Version: 2.0.1
- Update API CreateDocumentAnalyzeTask: add request parameters body.strategy.


2025-03-21 Version: 2.0.0
- Support API GetWebSearch.
- Update API GetTextGeneration: update param body.
- Update API GetTextGeneration: update response param.


2025-01-06 Version: 1.4.0
- Support API GetEmbeddingTuning.
- Support API GetPrediction.


2024-11-15 Version: 1.3.0
- Support API GetEmbeddingTuning.


2024-09-12 Version: 1.2.0
- Support API CreateImageAnalyzeTask.
- Support API GetImageAnalyzeTaskStatus.
- Support API GetQueryAnalysis.
- Update API GetDocumentAnalyzeTaskStatus: update response param.


2024-07-09 Version: 1.1.0
- Support API CreateImageAnalyzeTask.
- Support API GetImageAnalyzeTaskStatus.
- Support API GetQueryAnalysis.
- Update API GetDocumentAnalyzeTaskStatus: update response param.


2024-06-21 Version: 1.0.0
- Generated python 2024-05-29 for Searchplat.

