import os
import zipfile
from pathlib import Path
from typing import Optional, Union


class UnsafeZipError(Exception):
    """Raised when the zip archive looks unsafe to extract."""

    pass


def _is_within_directory(directory: Path, target: Path) -> bool:
    """Return True if target is inside directory (after resolving symlinks)."""
    try:
        directory = directory.resolve()
        target = target.resolve()
    except FileNotFoundError:
        # If target doesn't exist yet, resolve the parent and compare.
        directory = directory.resolve()
        target = target.parent.resolve() / target.name
    return str(target).startswith(str(directory) + os.sep) or str(target) == str(
        directory
    )


def _extract_zipfile_safe(
    zf: zipfile.ZipFile,
    dest_dir: Union[str, Path],
    *,
    members=None,
    max_files: Optional[int] = 100,
    max_file_size: int = 1 * 1024 * 1024 * 1024,  # 1 GB per file
    max_total_size: int = 10 * 1024 * 1024 * 1024,  # 10 GB total
    max_compression_ratio: float = 50.0,
    pwd: Optional[bytes] = None,
) -> None:
    """
    Safely extract zip archive into dest_dir.

    Parameters
    ----------
    zip_path : str | Path
        Path to the zip file.
    dest_dir : str | Path
        Destination directory where files will be extracted.
    max_files : int
        Maximum number of entries allowed in the archive.
    max_file_size : int
        Maximum uncompressed size allowed for any single file (bytes).
    max_total_size : int
        Maximum total uncompressed size across all files (bytes).
    max_compression_ratio : float
        Maximum allowed uncompressed_size / compressed_size ratio for any entry.
        Very high ratios may indicate a zip bomb.
        If compressed_size is 0 (e.g. stored or empty), ratio checks use safe logic.
    Raises
    ------
    UnsafeZipError
        If the archive violates any safety checks.
    """
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)

    total_uncompressed = 0
    file_count = 0

    infos = zf.infolist()

    if members is None:
        selected_infos = infos
        # Quick check on number of files in the archive when extracting everything
        if max_files is not None and len(infos) > max_files:
            raise UnsafeZipError(
                f"Archive contains too many entries: {len(infos)} > {max_files}"
            )
    else:
        # Normalise members like the stdlib: allow names or ZipInfo objects.
        def _normalize_members():
            for m in members:
                if isinstance(m, zipfile.ZipInfo):
                    yield m
                else:
                    yield zf.getinfo(m)

        selected_infos = _normalize_members()

    for info in selected_infos:
        filename = info.filename

        # Skip meta entries like __MACOSX/ or entries that are explicitly empty names
        if filename.strip() == "":
            continue

        # Normalize the path: use forward slashes inside zip
        # Build target path under dest_dir
        # Use PurePosixPath splitting to handle zip-internal separators
        parts = Path(Path(filename).as_posix()).parts
        # Defensive: reject any path with parent traversal components
        if any(part == ".." for part in parts):
            raise UnsafeZipError(f"Entry uses path traversal: {filename}")

        # Reject absolute paths and drive-letter windows paths
        if Path(filename).is_absolute() or (len(parts) > 0 and parts[0].endswith(":")):
            raise UnsafeZipError(f"Entry has absolute or drive-letter path: {filename}")

        target_path = dest_dir.joinpath(*parts)

        # Ensure final path is within dest_dir
        if not _is_within_directory(dest_dir, target_path):
            raise UnsafeZipError(f"Extraction would escape destination: {filename}")

        file_count += 1
        if max_files is not None and file_count > max_files:
            raise UnsafeZipError(f"Too many extracted entries (exceeded {max_files}).")

        uncompressed_size = info.file_size or 0
        compressed_size = info.compress_size or 0

        # Basic size limits
        if uncompressed_size > max_file_size:
            raise UnsafeZipError(
                f"File {filename} uncompressed size {uncompressed_size} exceeds limit {max_file_size} bytes"
            )

        # Compression ratio check to defend against zip bombs
        if compressed_size > 0:
            ratio = (
                uncompressed_size / compressed_size if compressed_size else float("inf")
            )
            if ratio > max_compression_ratio:
                raise UnsafeZipError(
                    f"File {filename} has suspicious compression ratio {ratio:.1f} (> {max_compression_ratio})"
                )
        else:
            # compressed_size == 0: allow only small uncompressed files (likely stored or empty)
            if (
                uncompressed_size > 10 * 1024 * 1024
            ):  # arbitrary: don't allow huge stored files
                raise UnsafeZipError(
                    f"File {filename} is stored (compress_size=0) but large ({uncompressed_size} bytes)."
                )

        total_uncompressed += uncompressed_size
        if total_uncompressed > max_total_size:
            raise UnsafeZipError(
                f"Total uncompressed data would exceed limit {max_total_size} bytes"
            )

        # Now extract safely
        # If entry is a directory (zip uses trailing slash), create dir
        if filename.endswith("/") or info.is_dir():
            target_path.mkdir(parents=True, exist_ok=True)
            continue

        # For non-directories: read the file bytes then write them out
        # This avoids allowing any weird zipinfo attributes (like symlinks)
        target_path.parent.mkdir(parents=True, exist_ok=True)

        # Prevent extraction of symlinks: some zips store symlinks via special external attributes.
        # We will NOT honor external attributes; we will write the entry's data as a regular file.
        with zf.open(info, "r", pwd=pwd) as src, open(target_path, "wb") as dst:
            # Stream copy in chunks to avoid huge memory use
            bytes_written = 0
            CHUNK = 64 * 1024
            while True:
                chunk = src.read(CHUNK)
                if not chunk:
                    break
                dst.write(chunk)
                bytes_written += len(chunk)
                # Defensive runtime check: stop if file grows beyond max_file_size (shouldn't happen)
                if bytes_written > max_file_size:
                    raise UnsafeZipError(
                        f"File {filename} grew beyond allowed size during extraction."
                    )
        # Set safe file permissions: readable and writable by owner only
        try:
            os.chmod(target_path, 0o600)
        except Exception:
            # If chmod is not supported on platform, ignore
            pass


class ZipFile(zipfile.ZipFile):
    """
    A drop-in replacement for :class:`zipfile.ZipFile` with a safer ``extractall``.
    """

    def extractall(
        self,
        path: Optional[Union[str, Path]] = None,
        members=None,
        pwd: Optional[bytes] = None,
        *,
        max_files: Optional[int] = 500,
        max_file_size: int = 1 * 1024 * 1024 * 1024,
        max_total_size: int = 10 * 1024 * 1024 * 1024,
        max_compression_ratio: float = 100.0,
    ) -> None:
        dest_dir: Path
        if path is None:
            dest_dir = Path.cwd()
        else:
            dest_dir = Path(path)

        _extract_zipfile_safe(
            self,
            dest_dir,
            members=members,
            max_files=max_files,
            max_file_size=max_file_size,
            max_total_size=max_total_size,
            max_compression_ratio=max_compression_ratio,
            pwd=pwd,
        )


__all__ = ["ZipFile", "UnsafeZipError"]
