# safezipfile: A safe zipfile extract library for python

## Summary

This library simply overrides the `extractall` method of the python `ZipFile` class
with additional checks to prevent zip-slip and zip-bomb attacks. It can be used the same
way as the usual `extractall` method but also accepts additional arguments to limit the number 
of allowed files in the archive, limit the size of each extract file, the total extracted file
size and also the maximum allowed compression ratio (zip bombs have a very high compression ratio). 

To make the base use case safe it already starts with some quite relaxed limits of:
* 500 files in a zip
* 1GB extracted file size
* 10GB total extracted file size

But they can all be configured:


```py
import safezipfile

# Base use case
with safezipfile.ZipFile("test.zip", "r") as zf:
    zf.extractall("./outdir")

# Or configure the limits
with safezipfile.ZipFile("test.zip", "r") as zf:
    zf.extractall(
        "./outdir", 
        max_files = 500, 
        max_file_size = 1 * 1024 * 1024 * 1024,
        max_total_size = 10 * 1024 * 1024 * 1024,
        max_compression_ratio = 100.0
    )
```