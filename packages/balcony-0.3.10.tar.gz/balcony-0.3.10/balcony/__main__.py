from cli import run_app
from . import main
run_app()