"""This module contains wunderkafka consumer's boilerplate."""
