from wunderkafka.serdes.jsonmodel.derive import derive

__all__ = [
    "derive",
]
