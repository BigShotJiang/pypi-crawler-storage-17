from wunderkafka.serdes.avromodel.derive.current import derive

__all__ = [
    "derive",
]
