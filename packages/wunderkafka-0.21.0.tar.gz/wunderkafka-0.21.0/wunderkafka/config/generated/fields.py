######################################################################
########### THIS FILE IS GENERATED, DO NOT EDIT MANUALLY!!! ##########
########### THIS FILE IS GENERATED, DO NOT EDIT MANUALLY!!! ##########
########### THIS FILE IS GENERATED, DO NOT EDIT MANUALLY!!! ##########
########### THIS FILE IS GENERATED, DO NOT EDIT MANUALLY!!! ##########
########### THIS FILE IS GENERATED, DO NOT EDIT MANUALLY!!! ##########
######################################################################


from wunderkafka import librdkafka


if librdkafka.__version__ >= (2, 0, 0):
    from wunderkafka.config.generated.v2_0_0.fields import *  # type: ignore[assignment]
if librdkafka.__version__ >= (2, 1, 0):
    from wunderkafka.config.generated.v2_1_0.fields import *  # type: ignore[assignment]
if librdkafka.__version__ >= (2, 2, 0):
    from wunderkafka.config.generated.v2_2_0.fields import *  # type: ignore[assignment]
if librdkafka.__version__ >= (2, 3, 0):
    from wunderkafka.config.generated.v2_3_0.fields import *  # type: ignore[assignment]
if librdkafka.__version__ >= (2, 4, 0):
    from wunderkafka.config.generated.v2_4_0.fields import *  # type: ignore[assignment]
if librdkafka.__version__ >= (2, 5, 0):
    from wunderkafka.config.generated.v2_5_0.fields import *  # type: ignore[assignment]
if librdkafka.__version__ >= (2, 6, 0):
    from wunderkafka.config.generated.v2_6_0.fields import *  # type: ignore[assignment]
if librdkafka.__version__ >= (2, 7, 0):
    from wunderkafka.config.generated.v2_7_0.fields import *  # type: ignore[assignment]
if librdkafka.__version__ >= (2, 8, 0):
    from wunderkafka.config.generated.v2_8_0.fields import *  # type: ignore[assignment]
if librdkafka.__version__ >= (2, 9, 0):
    from wunderkafka.config.generated.v2_9_0.fields import *  # type: ignore[assignment]
if librdkafka.__version__ >= (2, 10, 0):
    from wunderkafka.config.generated.v2_10_0.fields import *  # type: ignore[assignment]
if librdkafka.__version__ >= (2, 11, 0):
    from wunderkafka.config.generated.v2_11_0.fields import *  # type: ignore[assignment]
if librdkafka.__version__ >= (2, 12, 0):
    from wunderkafka.config.generated.v2_12_0.fields import *  # type: ignore[assignment]
