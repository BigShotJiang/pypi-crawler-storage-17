"""This module contains wunderkafka producer's boilerplate."""
