import logging

logger = logging.getLogger("wunderkafka")
logging.basicConfig(level=logging.WARNING)
