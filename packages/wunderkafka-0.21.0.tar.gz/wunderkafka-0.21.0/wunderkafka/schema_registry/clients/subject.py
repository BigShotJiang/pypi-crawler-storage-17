# ToDo (tribunsky.kir): re-implement or write adapter for confluent-kafka'
