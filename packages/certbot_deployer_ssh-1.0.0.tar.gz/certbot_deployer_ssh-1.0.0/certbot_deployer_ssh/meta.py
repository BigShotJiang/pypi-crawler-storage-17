"""
Package metadata
"""

__author__ = "IAS"
__version__ = "1.0.0"
__title__ = "certbot_deployer_ssh"
__license__ = "License :: OSI Approved :: MIT License"
__description__ = "Certbot Deployer plugin for deploying certificate bundles over SSH"
