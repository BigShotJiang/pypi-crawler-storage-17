#####################################
Account Invoice Secondary Unit Module
#####################################

The *Account Invoice Secondary Unit Module* adds a secondary unit of measure to
invoice lines.

.. toctree::
   :maxdepth: 2

   design
   releases
