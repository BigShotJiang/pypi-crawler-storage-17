"""Platform-specific implementations."""
