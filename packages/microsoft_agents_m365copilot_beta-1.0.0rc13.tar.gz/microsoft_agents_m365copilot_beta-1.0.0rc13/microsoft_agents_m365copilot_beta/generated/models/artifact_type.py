from enum import Enum

class ArtifactType(str, Enum):
    Transcript = "transcript",
    UnknownFutureValue = "unknownFutureValue",

