# pycottas Documentation

## Deployment ⚙️

The documentation is hosted in [Read the Docs](https://pycottas.readthedocs.io). Commits to the main branch automatically build the documentation and deploy it.

## License :unlock:

This documentation is licensed under **[CC-BY-SA-4.0](https://creativecommons.org/licenses/by-sa/4.0)**.
