2025-12-15 Version: 2.2.0
- Support API ListRegions.
- Update API GetCluster: add response parameters Body.Manager.ManagerNode.AutoRenew.
- Update API GetCluster: add response parameters Body.Manager.ManagerNode.AutoRenewPeriod.
- Update API GetCluster: add response parameters Body.Manager.ManagerNode.Duration.
- Update API GetCluster: add response parameters Body.Manager.ManagerNode.EnableHt.
- Update API GetCluster: add response parameters Body.Manager.ManagerNode.ImageId.
- Update API GetCluster: add response parameters Body.Manager.ManagerNode.Period.
- Update API GetCluster: add response parameters Body.Manager.ManagerNode.PeriodUnit.
- Update API GetCluster: add response parameters Body.Manager.ManagerNode.SpotPriceLimit.
- Update API GetCluster: add response parameters Body.Manager.ManagerNode.SpotStrategy.
- Update API GetCluster: add response parameters Body.Manager.ManagerNode.SystemDisk.


2025-05-16 Version: 2.1.0
- Support API AttachNodes.


2025-02-12 Version: 2.0.3
- Update API CreateNodes: add param DeploymentSetId.
- Update API CreateNodes: add param ReservedNodePoolId.
- Update API GetCluster: update response param.
- Update API GetQueue: update response param.
- Update API ListJobs: update param JobFilter.
- Update API ListJobs: update response param.
- Update API ListNodes: update response param.
- Update API UpdateCluster: add param MonitorSpec.
- Update API UpdateCluster: add param SchedulerSpec.
- Update API UpdateQueue: update param Queue.


2025-01-07 Version: 2.0.2
- Update API CreateNodes: add param DeploymentSetId.
- Update API GetCluster: update response param.
- Update API ListJobs: update param JobFilter.
- Update API ListJobs: update response param.
- Update API ListNodes: update response param.
- Update API UpdateCluster: add param MonitorSpec.
- Update API UpdateCluster: add param SchedulerSpec.


2024-12-09 Version: 2.0.1
- Update API CreateNodes: add param DeploymentSetId.
- Update API GetCluster: update response param.
- Update API ListJobs: update param JobFilter.
- Update API ListJobs: update response param.
- Update API ListNodes: update response param.
- Update API UpdateCluster: add param MonitorSpec.


2024-10-18 Version: 2.0.0
- Support API CreateJob.
- Support API GetJob.
- Support API GetJobLog.
- Support API ListJobs.
- Support API StopJobs.
- Delete API DeleteJobs.


2024-09-06 Version: 1.0.0
- Generated python 2024-07-30 for EHPC.

