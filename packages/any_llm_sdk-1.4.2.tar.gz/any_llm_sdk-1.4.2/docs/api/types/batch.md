## Batch Types

Data models and types for batch operations.

::: any_llm.types.batch
