Error by absent Binding
=====================

Minimal example to reproduce error due to absense of import Bindining
in "parser.py" script. Created from a copy of example derivedtype.

In previous version of f90wrap (version 0.2.2 dos not give this issue)
I used to write by myself the procedure where class is replaced by
tpye and in the example derivedtype.


To generate the error use the included ```Makefile```:

```
make
```

Author
------

Enrico Facca: <enrico.facca@gmail.com>

