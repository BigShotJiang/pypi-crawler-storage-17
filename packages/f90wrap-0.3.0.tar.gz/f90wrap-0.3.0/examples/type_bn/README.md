Regression test case for issue Github #30

https://github.com/jameskermode/f90wrap/issues/30

