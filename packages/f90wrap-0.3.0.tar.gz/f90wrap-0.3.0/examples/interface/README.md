Test case for issue #32
