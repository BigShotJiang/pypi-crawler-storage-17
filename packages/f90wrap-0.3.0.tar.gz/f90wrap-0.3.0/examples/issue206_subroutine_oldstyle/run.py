#!/usr/bin/env python
import itest

# Does nothing, but doesn't fail either
itest.routine_with_oldstyle_asterisk()
