f90wrap.fortrantype module
==========================

.. automodule:: f90wrap.fortrantype
    :members:
    :undoc-members:
    :show-inheritance:
