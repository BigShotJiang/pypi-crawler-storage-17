"""
Package collecting neural network building facilities
"""
