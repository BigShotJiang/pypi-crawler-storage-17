"""
AWS-tee: 標準入力をそのまま標準出力に流しつつ、
同じ内容を CloudWatch Logs と S3 に送る tee 風コマンド
"""

__version__ = "0.1.0"

