"""Utilities used by the attackcti package."""

