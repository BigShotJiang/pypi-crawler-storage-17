default_app_config = "django_whatsapp_api_wrapper.whatsapp_cloud_api.media"
"""Media endpoints for WhatsApp Cloud API wrapper."""
