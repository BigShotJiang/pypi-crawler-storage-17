#!/bin/bash

set -e

python3 -m pylint seal5 examples
