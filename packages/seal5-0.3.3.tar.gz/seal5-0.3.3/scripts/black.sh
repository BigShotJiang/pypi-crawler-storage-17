#!/bin/bash

set -e

python3 -m black -l120 seal5 examples
