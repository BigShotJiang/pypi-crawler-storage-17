from iolanta.facets.textual_default.facets import (
    InverseProperties,
    TextualDefaultFacet,
)

__all__ = ['TextualDefaultFacet', 'InverseProperties']
