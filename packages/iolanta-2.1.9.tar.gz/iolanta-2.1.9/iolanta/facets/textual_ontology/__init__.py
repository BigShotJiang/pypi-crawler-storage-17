from iolanta.facets.textual_ontology.facets import OntologyFacet

__all__ = ['OntologyFacet']
