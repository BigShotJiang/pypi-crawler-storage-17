Hierarchical structures
=======================

In these examples, we show how :func:`tyro.cli` can be used to instantiate
hierarchical structures. This can enable modular, reusable, and composable CLI
interfaces.
