# Generate Gens data

Collection of tools to generate input data to Gens (https://github.com/SMD-Bioinformatics-Lund/gens).

Usage:

```
>>> from gens_input_data_tools import generate_cov_and_baf
```