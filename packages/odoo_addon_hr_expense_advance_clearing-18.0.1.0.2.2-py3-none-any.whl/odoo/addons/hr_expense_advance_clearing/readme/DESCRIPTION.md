Standard Expenses module allow employee to do the expense reimbursement
only after the expense has been made. In other world, employee will need
to pay first and reimburse later.

This module, allow company to advance an amount to the employee.
Employee can then use that advance amount to purchase product/service
first, then back to company and do the clearing.

There can be 3 scenarios for advance and clearing

- When clearing amount = advance amount, no other operation is required.
- When clearing amount \> advance amount, company will pay the extra to
  employee.
- When clearing amount \< advance amount, employee will return the
  remain to company.
