This module will create a new product "Employee Advance" automatically.
You will need to setup the Expense Account of this product to your
Employee Advance account manually.

- Open Product window and search for "Employee Advance"
- On Accounting tab, select appropriate employee advance account from
  your chart of account

Note:

- You will need the "Show Full Accounting Features" to see accounting
  data
- Employee Advance account code, if not already exists, you can create
  one. Use type = Current Asset and check Allow Reconciliation.
