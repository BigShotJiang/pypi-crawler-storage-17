#####################
French Account Module
#####################

The *French Account Module* defines the standard chart of account and reports
for France.

.. toctree::
   :maxdepth: 2

   configuration
   design
   releases
