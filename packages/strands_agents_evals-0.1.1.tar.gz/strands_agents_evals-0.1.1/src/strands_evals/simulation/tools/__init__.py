"""Tools for actor simulation."""

from .goal_completion import get_conversation_goal_completion

__all__ = ["get_conversation_goal_completion"]
