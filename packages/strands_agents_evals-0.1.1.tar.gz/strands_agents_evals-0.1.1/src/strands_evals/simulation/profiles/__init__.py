"""Profile templates for actor simulation."""

from .actor_profile import DEFAULT_USER_PROFILE_SCHEMA

__all__ = ["DEFAULT_USER_PROFILE_SCHEMA"]
