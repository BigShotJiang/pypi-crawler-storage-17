"""Libraries of common functions that used in xonsh components as well as modules borrowed from other projects."""
