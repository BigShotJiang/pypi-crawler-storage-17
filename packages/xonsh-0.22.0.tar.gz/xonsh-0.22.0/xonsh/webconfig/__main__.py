from xonsh.webconfig.main import main

main()
