# Fix https://github.com/xonsh/xonsh/pull/5437
from xonsh.procs import proxies  # noqa
