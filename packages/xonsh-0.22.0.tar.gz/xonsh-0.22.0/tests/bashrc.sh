export EMERALD="SWORD"
alias ll='ls -a -lF'
alias la='ls -A'
export MIGHTY=WARRIOR
alias l='ls -CF'
