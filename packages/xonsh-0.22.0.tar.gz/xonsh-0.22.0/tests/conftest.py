# when xonsh is not installed in the current env
# pytest_plugins = ("xonsh.pytest.plugin",)
