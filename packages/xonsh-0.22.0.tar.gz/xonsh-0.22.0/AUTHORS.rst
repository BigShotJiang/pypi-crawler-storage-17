All of the people who have made at least one contribution to xonsh.
Authors are sorted by number of commits.

* Anthony Scopatz
* Adam Hartz
* Gil Forsyth
* Morten Enemark Lund
* Konstantinos Tsakiltzidis
* Noortheen Raja
* Jamie Bliss
* a
* Hugo Wang
* David Strobach
* Bob Hyman
* anki-code
* BlahGeek
* pre-commit-ci[bot]
* Daniel Shimon
* Gyuri Horak
* Jean-Benoist Leger
* christopher
* Klaus Alexander Seistrup
* Leonardo Santagada
* Burak Yiğit Kaya
* Matthias Bussonnier
* Aaron Griffin
* Peter Ye
* Rob Brewer
* virus
* Sagar Tewari
* Gordon Ball
* Eadaen1
* Konstantin Molchanov
* Guillaume Leclerc
* Travis Shirk
* Carmen Bianca Bakker
* Danny Sepler
* Joel Gerber
* vaaaaanquish
* Bernardas Ališauskas
* David Dotson
* Derek Thomas
* con-f-use
* VHarisop
* JohnLunzer
* Paul Goelz
* Jason R. Coombs
* cryzed
* Frank Sachsenheim
* Kurtis Rader
* Evgeny
* Brian Visel
* cafehaine
* Andrew Hundt
* Jonathan Slenders
* Justin Moen
* Raphael Das Gupta
* Caleb Hattingh
* Stephan Fitzpatrick
* dev2718
* Will S
* dependabot[bot]
* K.-Michael Aye
* halloleo
* Will Wykeham
* Oleh Prypin
* Brian Skinn
* Wendell Turner
* Alessio Bogon
* Yohei Tamura
* Maximilian Köhl
* Alexander Sosedkin
* doronz88
* Cody Scott
* Jake Hedman
* traverseda
* Andre Weltsch
* Jeremy Donahue
* Raphael Gaschignard
* Nathan Goldbaum
* mel
* Jared Crawford
* Mike Crowe
* Vasilis Gerakaris
* Angus Hollands
* JuanPablo
* Ollie Terrance
* Marcel Bollmann
* mdraw
* Mattias Ugelvik
* Ryan Gonzalez
* David Gros
* Andrea D'Amore
* James Elías
* anula
* Jay Tuckey
* Alexander Steffen
* Achim Herwig
* Randy Syring
* Lucas Inojosa
* adam j hartz
* Nickolay Bukreyev
* Alexey
* Alexandre Ferland
* Marvin Steadfast
* Aaron Meurer
* Matteo Bertini
* anatoly techtonik
* AaronV77
* Erick Tucto
* Tyler Goodlet
* Paul Barton
* 74th
* Mickaël Schoentgen
* Steven Silvester
* Robert DeFriesse
* Justin Calamari
* Thomas Marquart
* Benjamin Pollack
* Sardorbek Imomaliev
* Jakub Nowak
* selepo
* Fabien Dubosson
* Kale Kundert
* Andrés García García
* Sean Farley
* Marduk Bolaños
* Marius van Niekerk
* Stefano Rivera
* Lie Ryan
* Jan Schulz
* Samuel Dion-Girardeau
* Michael Droettboom
* guillearch
* javValverde
* Shahin
* Nico Lehmann
* Sebastian Wagner
* yuqing
* Rahiel Kasim
* SanketDG
* Mark Bestley
* David
* Danmou
* Niklas Hambüchen
* Sébastien Pierre
* Eddie Peters
* shadow-light
* Jan Chren
* Samuel Lotz
* Jerzy Drozdz
* omjadas
* Jeremy Schlatter
* Samuel Dion-Girardeau
* Oliver Bestwalter
* Ivan Ogasawara
* jfmontanaro
* Łukasz Langa
* Mark Wiebe
* Nathan Hoad
* Eric Dill
* neruok
* Domenic Barbuzzi
* metamind
* Qiushi Pan
* josh
* TobalJackson
* Greg Thole
* Min RK
* Nicolas Avrutin
* Kevin Yokley
* Ollie Ford
* Michał Zając
* Emre Ates
* Romain Bignon
* Owen Campbell
* Steven Kryskalla
* cclauss
* Ke Zhang
* László Vaskó
* Allan Crooks
* micimize
* Chris Lasher
* Edmund Miller
* Gabriel Vogel
* anki
* Faris A Chugthai
* Asaf Fisher
* Gabriele N. Tornetta
* cmidkiff87
* jbw3
* Naveen
* Blake Ramsdell
* JamesParrott
* jyn
* Dan Allan
* Ned Letcher
* Zach Crownover
* Miguel de Val-Borro
* Hirotomo Moriwaki
* Phil Elson
* Erin Call
* Trevor Bekolay
* Tzu-ping Chung
* Andrew Toskin
* torgny
* William Woodall
* ariel faigon
* Nigel Tea
* Mark Szumowski
* The Gitter Badger
* Cameron Bates
* Kermit Alexander II
* Richard Kim
* Brian S. Corbin
* Erez Shinan
* Nakada Takumi
* Ross Nomann
* eyalzek
* Pedro Rodriguez
* Eric Harris
* Austin Bingham
* jlunz
* dragon788
* Jonathan Hogg
* Andrei
* Daniel Hahler
* Mark Harfouche
* Carol Willing
* Kilte Leichnam
* Raniere Silva
* Thomas Kluyver
* Donne Martin
* Alexey Shrub
* Jean-Christophe Fillion-Robin
* Charlie Arnold
* Nate Tangsurat
* Michael Ensslin
* dbxnr
* sushobhana
* Florian Mounier
* Glen Zangirolami
* adamheins
* Joseph Paul
* Daniel Milde
* Katriel Cohn-Gordon
* Chad Kennedy
* stonebig
* Ronny Pfannschmidt
* Troy de Freitas
* Rodrigo Oliveira
* Daniel Smith
* Nils ANDRÉ-CHANG
* chengxuncc
* nedsociety
* fanosta
* David Kalliecharan
* Sylvain Corlay
* Marcio Mazza
* Manor Askenazi
* Stefane Fermigier
* swedneck
* Feng Tian
* paugier
* Wendell CTR Turner
* Will Shanks
* Dominic Ward
* Leandro Emmanuel Reina Kiperman
* Henré Botha
* Aneesh Durg
* colons
* yggdr
* Gao, Xiang
* Tejasvi S Tomar
* Adam Schwalm
* Nate Simon
* jmoranos
* Walter A. Boring IV
* bhawkins
* JackofSpades707
* Luiz Antonio Lazoti
* francium
* FranzAtGithub
* IJR222
* Shanmukha Vishnu
* Ali Uneri
* Eleni E
* Kaarel Pärtel
* Michael Ramsey
* circuit10
* Ryan Delaney
* E Pluribus Unum
* ylmrx
* Hierosme
* Kyllingene
* zzj
* Daniel
* Ganer
* mattmc3
* Evan Hubinger
* Italo Cunha
* Timmy Welch
* Hannes Römer
* jgart
* Michael Panitz (at Cascadia College)
* Tim Gates
* amukher3
* Ashish Kurmi
* Justin
* yotamolenik
* austin-yang
* Marco Rubin
* Qyriad
* Tobias Becker
* AkshayWarrier
* Thomas Hess
* kouhe3
* HackTheOxidation
* Cosine Chen
* mgunyho
* ShalokShalom
* Wilfried Pollan
* Jacqueline Leykam
* Joshix-1
* Nathan Monfils
* Airat Makhmutov
* Matthieu LAURENT
* Daniel Saunders
* Andrew
* l-no
* amacfie-tc
* lunrenyi
* Spencer Bliven
* Niraj Kulkarni
* Aidan Courtney
* Max Nordlund
* Shawn Wallace
* Faidon Liambotis
* Jueun Lee
* Simon Billinge
* Bala
* Artur Manuel
* Đỗ Trung Nguyên
* Ahmed
* goodboy
* Atsushi Morimoto
* slacksystem
