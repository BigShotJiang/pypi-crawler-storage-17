const a={CLASSIFICATION:"classification"},o={VIDEO:"video",VIDEO_FRAME:"video_frame",IMAGE:"image",ANNOTATION:"annotation",CAPTION:"caption"};export{a as A,o as S};
