import{R as e,H as o}from"./CYgJF_JY.js";function i(r,t){throw new o(r,t)}function c(r,t){throw new e(r,t.toString())}new TextEncoder;export{i as e,c as r};
