import{l as o,f as r}from"../chunks/xGHZQ1pe.js";export{o as load_css,r as start};
