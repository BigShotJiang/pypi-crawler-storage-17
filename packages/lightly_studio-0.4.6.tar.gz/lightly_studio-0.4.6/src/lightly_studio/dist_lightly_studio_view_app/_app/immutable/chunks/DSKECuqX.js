import"./CWj6FrbW.js";import{p as f,f as A,j as u,a as v,c as b,r as x,g as D,b as T}from"./DkbXUtyG.js";import{c as M,a as c,f as y}from"./CmLg0ys7.js";import{s as o}from"./VqWvU2yF.js";import{s as F,r as h,p as m,b as k}from"./DuUalyFS.js";import{I,k as N,W}from"./CGY1p9L4.js";import{b as P,g as q}from"./C8mfFM-u.js";import{i as V}from"./B_1cpokE.js";function $(s,e){f(e,!0);/**
 * @license @lucide/svelte v0.482.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */let t=h(e,["$$slots","$$events","$$legacy"]);const l=[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5"}],["path",{d:"M3 12A9 3 0 0 0 21 12"}]];I(s,F({name:"database"},()=>t,{get iconNode(){return l},children:(a,n)=>{var r=M(),_=A(r);o(_,()=>e.children??u),c(a,r)},$$slots:{default:!0}})),v()}function ee(s,e){f(e,!0);/**
 * @license @lucide/svelte v0.482.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */let t=h(e,["$$slots","$$events","$$legacy"]);const l=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"}]];I(s,F({name:"house"},()=>t,{get iconNode(){return l},children:(a,n)=>{var r=M(),_=A(r);o(_,()=>e.children??u),c(a,r)},$$slots:{default:!0}})),v()}var E=y("<nav><!></nav>");function ae(s,e){f(e,!0);let t=m(e,"ref",15),l=h(e,["$$slots","$$events","$$legacy","ref","class","children"]);var a=E();P(a,()=>({class:e.class,"aria-label":"breadcrumb",...l}));var n=b(a);o(n,()=>e.children??u),x(a),k(a,r=>t(r),()=>t()),c(s,a),v()}var G=y("<li><!></li>");function re(s,e){f(e,!0);let t=m(e,"ref",15,null),l=h(e,["$$slots","$$events","$$legacy","ref","class","children"]);var a=G();P(a,r=>({class:r,...l}),[()=>N("inline-flex items-center gap-1.5",e.class)]);var n=b(a);o(n,()=>e.children??u),x(a),k(a,r=>t(r),()=>t()),c(s,a),v()}var J=y("<li><!></li>");function te(s,e){f(e,!0);let t=m(e,"ref",15,null),l=h(e,["$$slots","$$events","$$legacy","ref","class","children"]);var a=J();P(a,i=>({role:"presentation","aria-hidden":"true",class:i,...l}),[()=>N("[&>svg]:size-3.5",e.class)]);var n=b(a);{var r=i=>{var B=M(),H=A(B);o(H,()=>e.children??u),c(i,B)},_=i=>{W(i,{})};V(n,i=>{e.children?i(r):i(_,!1)})}x(a),k(a,i=>t(i),()=>t()),c(s,a),v()}var K=y("<a><!></a>");function se(s,e){f(e,!0);let t=m(e,"ref",15,null),l=m(e,"href",3,void 0),a=h(e,["$$slots","$$events","$$legacy","ref","class","href","child","children"]);const n=T(()=>({class:N("hover:text-foreground transition-colors",e.class),href:l(),...a})),r=q(),[_,i]=r;var B=M(),H=A(B);{var j=g=>{var d=M(),w=A(d);o(w,()=>e.child,()=>({props:D(n)})),c(g,d)},C=g=>{var d=K();P(d,z=>({...z}),[()=>i({...D(n)},[{attribute_name:"href",lang_attribute_name:"hreflang"}])]);var w=b(d);o(w,()=>e.children??u),x(d),k(d,z=>t(z),()=>t()),c(g,d)};V(H,g=>{e.child?g(j):g(C,!1)})}c(s,B),v()}var L=y("<ol><!></ol>");function le(s,e){f(e,!0);let t=m(e,"ref",15,null),l=h(e,["$$slots","$$events","$$legacy","ref","class","children"]);var a=L();P(a,r=>({class:r,...l}),[()=>N("text-muted-foreground flex flex-wrap items-center gap-1.5 break-words text-sm sm:gap-2.5",e.class)]);var n=b(a);o(n,()=>e.children??u),x(a),k(a,r=>t(r),()=>t()),c(s,a),v()}var O=y("<span><!></span>");function ne(s,e){f(e,!0);let t=m(e,"ref",15,null),l=h(e,["$$slots","$$events","$$legacy","ref","class","children"]);var a=O();P(a,r=>({role:"link","aria-disabled":"true","aria-current":"page",class:r,...l}),[()=>N("text-foreground font-normal",e.class)]);var n=b(a);o(n,()=>e.children??u),x(a),k(a,r=>t(r),()=>t()),c(s,a),v()}export{ae as B,$ as D,ee as H,le as a,re as b,se as c,te as d,ne as e};
