import{A as o,E as f,B as i,j as p,C as c,D as d,F as h}from"./DkbXUtyG.js";function _(e,n,...t){var s=e,r=p,a;o(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=i(()=>r(s,...t)))},f),d&&(s=h)}export{_ as s};
