import nes_zelda_walking_tour

if __name__ == '__main__':
    nes_zelda_walking_tour.main()
