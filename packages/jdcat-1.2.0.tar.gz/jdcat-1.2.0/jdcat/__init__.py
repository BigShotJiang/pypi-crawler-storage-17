"""
JDCat - Sensitive Check Local Service Package

This package provides a pip-installable version of the sensitive-check-local service.
"""

__version__ = "1.0.0"
__author__ = "Sensitive Check Team"
__description__ = "JDCat local service (pip package) bundling sensitive_check_local and CLI entry"