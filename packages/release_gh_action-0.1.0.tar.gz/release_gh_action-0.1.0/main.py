def main():
    print("Hello from release-gh-action!")


if __name__ == "__main__":
    main()
