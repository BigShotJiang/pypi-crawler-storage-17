-- Initialize test database
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
