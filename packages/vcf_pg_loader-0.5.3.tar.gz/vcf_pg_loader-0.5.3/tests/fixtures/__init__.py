"""Test fixtures for VCF-PG-Loader."""
