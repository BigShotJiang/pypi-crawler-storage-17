"""Vendored test utilities from external projects."""
