"""VCF to PostgreSQL loader with clinical-grade compliance."""

__version__ = "0.4.0"
