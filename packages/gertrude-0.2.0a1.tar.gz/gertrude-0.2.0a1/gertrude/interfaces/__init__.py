# Gertrude --- GTD done right
# Copyright © 2025 Tanguy Le Carrour <tanguy@bioneland.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import datetime
from pathlib import Path
from typing import Any, Sequence

import markdown
from jinja2 import Environment, FileSystemLoader, select_autoescape
from jinja2_fragments import render_block

from gertrude.domain import Project, Task, TaskStates

ENVIRONMENT = Environment(
    loader=FileSystemLoader([Path(__file__).parent / "templates"]),
    autoescape=select_autoescape(),
    extensions=["pypugjs.ext.jinja.PyPugJSExtension"],
    cache_size=0,  # FIXME: disable it only in dev environment.
)


class PugPresenter:
    def __init__(
        self, template_name: str, context: dict[str, Any] | None = None
    ) -> None:
        self.__template, self.__fragment = self.__template_parts(template_name)
        self.__context = context or {}

    def __template_parts(self, template: str) -> tuple[str, str]:
        fragment = ""
        if "#" in template:
            template, fragment = template.split("#", 2)
        return f"{template}.pug" if template else "", fragment

    def __str__(self) -> str:
        if self.__fragment:
            return render_block(
                ENVIRONMENT, self.__template, self.__fragment, **self.__context
            )
        if self.__template:
            return ENVIRONMENT.get_template(self.__template).render(self.__context)
        return ""


class OrganizeTasks(PugPresenter):
    def __init__(
        self,
        tasks: Sequence[Task],
        projects: Sequence[Project] | None = None,
        state: TaskStates | None = None,
        sorting_key: str = "",
    ) -> None:
        PAST = datetime.date(1980, 1, 1)
        if sorting_key == "state":
            tasks = sorted(tasks, key=lambda t: t.state)
        if sorting_key == "scheduled_on":
            tasks = sorted(tasks, key=lambda t: t.scheduled_on or PAST)
        context = {
            "tasks": tasks,
            "projects_by_id": {p.id: p for p in projects or []},
            "states": [s.value for s in TaskStates],
        }
        if state:
            context["selected_state"] = state.value
        if sorting_key:
            context["selected_sorting_key"] = sorting_key
        super().__init__("tasks/organize", context)


class TasksPresenter(PugPresenter):
    TEMPLATE = ""

    def __init__(self, tasks: Sequence[Task], projects: Sequence[Project]) -> None:
        context = {
            "tasks": tasks,
            "projects_by_id": {p.id: p for p in projects or []},
        }
        super().__init__(self.TEMPLATE, context)


class CapturedTasks(TasksPresenter):
    TEMPLATE = "tasks/captured"


class ScheduledTasks(TasksPresenter):
    TEMPLATE = "tasks/scheduled"

    def __init__(self, tasks: Sequence[Task], projects: Sequence[Project]) -> None:
        super().__init__(
            sorted(tasks, key=lambda t: t.scheduled_on), projects  # type: ignore
        )


class DelegatedTasks(TasksPresenter):
    TEMPLATE = "tasks/delegated"


class IncubatedTasks(TasksPresenter):
    TEMPLATE = "tasks/incubated"


class NextTasks(TasksPresenter):
    TEMPLATE = "tasks/next"

    def __init__(self, tasks: Sequence[Task], projects: Sequence[Project]) -> None:
        super().__init__(
            sorted(
                [t for t in tasks if t.scheduled_on],
                key=lambda t: (t.scheduled_on, t.title),
            )
            + sorted([t for t in tasks if not t.scheduled_on], key=lambda t: t.title),
            projects,
        )


class CaptureTask(PugPresenter):
    def __init__(self) -> None:
        super().__init__("tasks/_capture")


class TaskPresenter(PugPresenter):
    TEMPLATE = ""

    def __init__(self, task: Task, projects: Sequence[Project] | None = None) -> None:
        context = {"task": task, "projects_by_id": {p.id: p for p in projects or []}}
        super().__init__(self.TEMPLATE, context)


class ViewTask(TaskPresenter):
    TEMPLATE = "tasks/_view"


class EditTask(TaskPresenter):
    TEMPLATE = "tasks/_edit"


class AssignTask(TaskPresenter):
    TEMPLATE = "tasks/_assign"


class ScheduleTask(TaskPresenter):
    TEMPLATE = "tasks/_schedule"


class ViewProjects(PugPresenter):
    def __init__(self, projects: Sequence[Project]) -> None:
        super().__init__("projects/index", {"projects": projects})


class ViewProject(PugPresenter):
    def __init__(self, project: Project, tasks: list[Task]) -> None:
        super().__init__(
            "projects/view",
            {"project": project, "tasks": sorted(tasks, key=lambda t: t.state)},
        )


class EditProject(PugPresenter):
    def __init__(self, project: Project) -> None:
        super().__init__("projects/edit", {"project": project})


def register_template_variable(name: str, value: Any) -> None:
    ENVIRONMENT.globals[name] = value


def md_to_html(text: str) -> str:
    return markdown.markdown(text)


ENVIRONMENT.filters["md_to_html"] = md_to_html
