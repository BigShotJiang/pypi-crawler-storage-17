# Gertrude --- GTD done right
# Copyright © 2025 Tanguy Le Carrour <tanguy@bioneland.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

from typing import Sequence

from sqlalchemy import Column, Date, String, Table, select
from sqlalchemy.orm import Session, registry

from gertrude.domain import Project, Projects, Task, Tasks

REGISTRY = registry()


class SqlTasks(Tasks):
    def __init__(self, session: Session) -> None:
        self.__session = session

    def save(self, task: Task) -> None:
        self.__session.add(task)

    def all(self) -> Sequence[Task]:
        return self.__session.scalars(select(Task)).all()

    def get(self, id: str) -> Task:
        return self.__session.scalars(
            select(Task).where(Task.id == id)  # type: ignore[arg-type]
        ).one()


class SqlProjects(Projects):
    def __init__(self, session: Session) -> None:
        self.__session = session

    def save(self, task: Project) -> None:
        self.__session.add(task)

    def all(self) -> Sequence[Project]:
        return self.__session.scalars(select(Project)).all()

    def get(self, id: str) -> Project:
        return self.__session.scalars(
            select(Project).where(Project.id == id)  # type: ignore[arg-type]
        ).one()

    def delete(self, project: Project) -> None:
        self.__session.delete(project)


tasks_table = Table(
    "tasks",
    REGISTRY.metadata,
    Column("id", String, primary_key=True),
    Column("title", String),
    Column("description", String),
    Column("state", String),
    Column("belongs_to", String),
    Column("assigned_to", String, default=None),
    Column("delegated_to", String, default=None),
    Column("scheduled_on", Date, default=None),
)
REGISTRY.map_imperatively(Task, tasks_table)

projects_table = Table(
    "projects",
    REGISTRY.metadata,
    Column("id", String, primary_key=True),
    Column("name", String, unique=True),
    Column("short_name", String, unique=True),
    Column("description", String),
)
REGISTRY.map_imperatively(Project, projects_table)
