# Gertrude --- GTD done right
# Copyright © 2025 Tanguy Le Carrour <tanguy@bioneland.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

from typing import Any

import typer
from sqlalchemy import create_engine

from gertrude import __version__

app = typer.Typer(context_settings={"help_option_names": ["-h", "--help"]})


@app.command()
def version() -> None:
    "Display application version."
    typer.echo(__version__)
    raise typer.Exit()


@app.command()
def initialise(ctx: typer.Context) -> None:
    """Initialise database schema."""

    from gertrude.infrastructure.sqlalchemy import REGISTRY

    typer.echo("Initialising schema…", nl=False)
    engine = create_engine(ctx.obj["DSN"])
    REGISTRY.metadata.create_all(engine)
    typer.echo(" OK !")


def build_cli(config: dict[str, str]) -> Any:
    return app(obj=config)
