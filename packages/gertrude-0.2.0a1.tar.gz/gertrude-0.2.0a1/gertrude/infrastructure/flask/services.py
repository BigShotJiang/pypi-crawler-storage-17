# Gertrude --- GTD done right
# Copyright © 2025 Tanguy Le Carrour <tanguy@bioneland.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

from flask import current_app, g
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from gertrude.domain import Projects, Tasks
from gertrude.infrastructure.sqlalchemy import SqlProjects, SqlTasks

SESSION_KEY = "session"


def get_session() -> Session:
    if SESSION_KEY not in g:
        engine = create_engine(current_app.config["DSN"])
        g.setdefault(SESSION_KEY, sessionmaker(bind=engine)())
    return g.get(SESSION_KEY)  # type: ignore[no-any-return]


def close_session(exception: BaseException | None) -> None:
    if session := g.pop(SESSION_KEY, None):
        if exception:
            session.rollback()
        else:
            session.commit()
        session.close()


def tasks() -> Tasks:
    return SqlTasks(get_session())


def projects() -> Projects:
    return SqlProjects(get_session())
