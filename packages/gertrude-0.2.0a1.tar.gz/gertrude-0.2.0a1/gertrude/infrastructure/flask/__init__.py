# Gertrude --- GTD done right
# Copyright © 2025 Tanguy Le Carrour <tanguy@bioneland.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

from flask import Flask, make_response, redirect, request, url_for
from sqlalchemy.exc import NoResultFound
from werkzeug import Response

from gertrude import __version__
from gertrude.interfaces import register_template_variable

from . import services
from .projects import blueprint as projects
from .tasks import blueprint as tasks


def build_wsgi(config: dict[str, str]) -> Flask:
    app = Flask(__name__, static_folder="./static/")
    app.config.update(**config)
    app.url_map.strict_slashes = False

    app.teardown_appcontext(services.close_session)

    app.register_blueprint(tasks, url_prefix="/tasks")
    app.register_blueprint(projects, url_prefix="/projects")

    app.register_error_handler(NoResultFound, handle_not_found)

    register_template_variable("version", __version__)
    register_template_variable("url_for", url_for)

    @app.route("/")
    def root() -> Response:
        return redirect(url_for("tasks.captured"))

    @app.before_request
    def _() -> None:
        current_url = request.path
        if query_string := request.query_string.decode():
            current_url += f"?{query_string}"
        register_template_variable("current_url", current_url)

    return app


def handle_not_found(exc: NoResultFound) -> Response:
    return make_response("Resources not found!", 404)
