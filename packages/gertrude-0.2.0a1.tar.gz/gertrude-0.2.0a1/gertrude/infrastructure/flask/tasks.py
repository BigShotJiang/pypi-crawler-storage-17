# Gertrude --- GTD done right
# Copyright © 2025 Tanguy Le Carrour <tanguy@bioneland.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import datetime
from http import HTTPStatus as HTTP
from uuid import uuid4

from flask import Blueprint, request
from werkzeug import Response

from gertrude import interfaces as presenters
from gertrude.domain import Task, TaskStates

from .services import projects, tasks

blueprint = Blueprint("tasks", __name__)


@blueprint.get("/captured")
def captured() -> str:
    return str(
        presenters.CapturedTasks(
            [t for t in tasks().all() if t.state == TaskStates.CAPTURED.value],
            projects().all(),
        )
    )


@blueprint.get("/__count__")
def count() -> str:
    if nb := len([t for t in tasks().all() if t.state == TaskStates.CAPTURED.value]):
        return str(nb)
    return ""


@blueprint.get("/organize")
def organize() -> str:
    state = TaskStates(s) if (s := request.args.get("state")) else None
    return str(
        presenters.OrganizeTasks(
            [t for t in tasks().all() if not state or t.state == state.value],
            projects().all(),
            state,
            sorting_key=request.args.get("sorting_key", ""),
        )
    )


@blueprint.get("/scheduled")
def scheduled() -> str:
    return str(
        presenters.ScheduledTasks(
            [t for t in tasks().all() if t.state == TaskStates.SCHEDULED.value],
            projects().all(),
        )
    )


@blueprint.get("/delegated")
def delegated() -> str:
    return str(
        presenters.DelegatedTasks(
            [t for t in tasks().all() if t.state == TaskStates.DELEGATED.value],
            projects().all(),
        )
    )


@blueprint.get("/incubated")
def incubated() -> str:
    return str(
        presenters.IncubatedTasks(
            [t for t in tasks().all() if t.state == TaskStates.INCUBATED.value],
            projects().all(),
        )
    )


@blueprint.get("/next")
def next() -> str:
    TODAY = datetime.date.today()

    def is_next(task: Task) -> bool:
        if task.state == TaskStates.ACTIONABLE.value:
            return True
        if (
            task.state == TaskStates.SCHEDULED.value
            and (task.scheduled_on or TODAY) <= TODAY
        ):
            return True
        return False

    return str(
        presenters.NextTasks([t for t in tasks().all() if is_next(t)], projects().all())
    )


@blueprint.get("/__capture__")
def capture() -> str:
    return str(presenters.CaptureTask())


@blueprint.post("/__capture__")
def capture_() -> Response:
    task = Task(
        str(uuid4()),
        request.form["title"],
        request.form.get("description", ""),
        "captured",
    )
    tasks().save(task)
    return build_response(presenters.ViewTask(task, projects().all()))


@blueprint.get("/<id>")
def view(id: str) -> str:
    return str(presenters.ViewTask(tasks().get(id), projects().all()))


@blueprint.get("/<id>/__edit__")
def edit(id: str) -> str:
    return str(presenters.EditTask(tasks().get(id)))


@blueprint.post("/<id>/__edit__")
def edit_(id: str) -> str | Response:
    task = tasks().get(id)
    task.title = request.form["title"]
    task.description = request.form.get("description", "")
    return build_response(presenters.ViewTask(task, projects().all()))


@blueprint.post("/<id>/__state__")
def change_state(id: str) -> Response:
    task = tasks().get(id)
    next_state = TaskStates(request.form["next"])
    task.state = next_state.value
    if next_state != TaskStates.SCHEDULED:
        task.scheduled_on = None
    return build_response(presenters.ViewTask(tasks().get(id), projects().all()))


@blueprint.get("/<id>/__assign__")
def assign(id: str) -> str:
    return str(presenters.AssignTask(tasks().get(id), projects().all()))


@blueprint.post("/<id>/__assign__")
def assign_(id: str) -> Response:
    task = tasks().get(id)
    if p_id := request.form["project"]:
        task.assigned_to = projects().get(p_id).id
    else:
        task.assigned_to = None
    return build_response(presenters.ViewTask(task, projects().all()))


@blueprint.get("/<id>/__schedule__")
def schedule(id: str) -> str:
    return str(presenters.ScheduleTask(tasks().get(id), projects().all()))


@blueprint.post("/<id>/__schedule__")
def schedule_(id: str) -> Response:
    task = tasks().get(id)
    if date := request.form["date"]:
        task.scheduled_on = datetime.datetime.strptime(date, "%Y-%m-%d").date()
        task.state = TaskStates.SCHEDULED.value
    return build_response(presenters.ViewTask(task, projects().all()))


def build_response(presenter: presenters.PugPresenter) -> Response:
    return Response(
        response=str(presenter),
        status=HTTP.OK,
        headers={"HX-Trigger": "dataUpdated"},
    )
