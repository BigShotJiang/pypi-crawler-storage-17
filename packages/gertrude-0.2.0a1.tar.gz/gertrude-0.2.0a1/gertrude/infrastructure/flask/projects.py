# Gertrude --- GTD done right
# Copyright © 2025 Tanguy Le Carrour <tanguy@bioneland.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

from uuid import uuid4

from flask import Blueprint, redirect, request, url_for
from werkzeug import Response

from gertrude.domain import Project
from gertrude.interfaces import EditProject, ViewProject, ViewProjects

from .services import projects, tasks

blueprint = Blueprint("projects", __name__)


@blueprint.get("/")
def index() -> str:
    return str(ViewProjects(projects().all()))


@blueprint.post("/")
def create() -> Response:
    project = Project(
        str(uuid4()),
        request.form["name"],
        request.form["short_name"],
        request.form.get("description", ""),
    )
    projects().save(project)
    return redirect(url_for("projects.view", id=project.id))


@blueprint.get("/<id>")
def view(id: str) -> str:
    project = projects().get(id)
    return str(
        ViewProject(project, [t for t in tasks().all() if t.assigned_to == project.id])
    )


@blueprint.post("/<id>")
def edit(id: str) -> str | Response:
    project = projects().get(id)
    if request.form:
        project.name = request.form["name"]
        project.short_name = request.form["short_name"]
        project.description = request.form.get("description", "")
        return redirect(url_for("projects.view", id=project.id))
    return str(EditProject(project))


@blueprint.post("/<id>/__delete__")
def delete(id: str) -> str | Response:
    project = projects().get(id)
    assert not [t for t in tasks().all() if t.assigned_to == project.id]
    projects().delete(project)
    return redirect(url_for("projects.index"))
