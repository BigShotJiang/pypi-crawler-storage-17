# Gertrude --- GTD done right
# Copyright © 2025 Tanguy Le Carrour <tanguy@bioneland.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date
from enum import Enum
from typing import Sequence


class TaskStates(Enum):
    CAPTURED = "captured"
    DONE = "done"
    DELEGATED = "delegated"
    ACTIONABLE = "actionable"
    SCHEDULED = "scheduled"
    FILED = "filed"
    INCUBATED = "incubated"
    ELIMINATED = "eliminated"


@dataclass
class Task:
    id: str = ""
    title: str = ""
    description: str = ""
    state: str = ""
    delegated_to: str | None = None
    assigned_to: str | None = None
    scheduled_on: date | None = None

    @property
    def is_due(self) -> bool:
        return bool(self.scheduled_on and self.scheduled_on <= date.today())


class Tasks(ABC):
    @abstractmethod
    def save(self, task: Task) -> None: ...

    @abstractmethod
    def all(self) -> Sequence[Task]: ...

    @abstractmethod
    def get(self, id: str) -> Task: ...


@dataclass
class Project:
    id: str
    name: str
    short_name: str
    description: str


class Projects(ABC):
    @abstractmethod
    def save(self, project: Project) -> None: ...

    @abstractmethod
    def all(self) -> Sequence[Project]: ...

    @abstractmethod
    def get(self, id: str) -> Project: ...

    @abstractmethod
    def delete(self, project: Project) -> None: ...
