# Gertrude --- GTD done right
# Copyright © 2025 Tanguy Le Carrour <tanguy@bioneland.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import os
from typing import Any

from flask import Flask


def wsgi() -> Flask:
    from gertrude.infrastructure.flask import build_wsgi

    return build_wsgi(configuration())


def cli() -> Any:
    from gertrude.infrastructure.typer import build_cli

    return build_cli(configuration())


def configuration() -> dict[str, str]:
    prefix = "GERTRUDE_"
    return {
        k.removeprefix(prefix).upper(): v
        for k, v in os.environ.items()
        if k.startswith(prefix)
    }
