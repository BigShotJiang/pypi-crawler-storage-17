# Gertrude – GTD done right!

## Configure

```shell
export GERTRUDE_SECRET_KEY="12345"
export GERTRUDE_DSN="sqlite:///db.sqlite"
```

## Initialise

```shell
gertrude initialise
```

## Run

```shell
gunicorn --access-logfile="-" -w 4 -b 127.0.0.1:3000 "gertrude.configuration:wsgi()"
```

## Learn more

See [documentation](docs/index.md).


## Contribute

See <CONTRIBUTING.md>.
