import time

message = "Where there is a Will, there is a Way! " * 10


for c in message:
    print(c, end="", flush=True)
    # time.sleep(0.02)
