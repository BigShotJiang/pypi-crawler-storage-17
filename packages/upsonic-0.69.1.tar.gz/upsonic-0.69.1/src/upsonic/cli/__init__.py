"""Upsonic CLI module."""

from upsonic.cli.main import main

__all__ = ["main"]

