# This file was generated automatically. DO NOT CHANGE.
VERSION = '1.179.0'
