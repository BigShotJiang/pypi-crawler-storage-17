from .template import SummarizationTemplate
