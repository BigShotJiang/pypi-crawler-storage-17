from enum import Enum


class ARCMode(Enum):
    CHALLENGE = "ARC-Challenge"
    EASY = "ARC-Easy"
