from .handler import instrument_llama_index


__all__ = [
    "instrument_llama_index",
]
