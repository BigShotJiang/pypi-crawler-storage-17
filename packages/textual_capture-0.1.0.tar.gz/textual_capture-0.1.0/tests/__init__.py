"""Tests for textual-capture."""
