"""textual-capture: Sequenced screen capture for Textual applications."""

__version__ = "0.1.0"
__all__ = []  # No public API - CLI tool only
