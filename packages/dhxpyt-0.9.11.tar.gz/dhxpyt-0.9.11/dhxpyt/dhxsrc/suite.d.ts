export as namespace dhx;

export * from "./types/ts-all/sources/entry";
