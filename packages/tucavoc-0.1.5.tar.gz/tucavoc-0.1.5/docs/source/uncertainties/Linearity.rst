.. This file is made to explain Linearity Uncertainty. 



