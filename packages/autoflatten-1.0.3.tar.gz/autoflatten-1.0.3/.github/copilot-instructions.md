Docstrings are written in NumPy format.
Pytest is used for testing.
