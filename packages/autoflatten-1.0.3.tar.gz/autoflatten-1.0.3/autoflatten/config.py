from pathlib import Path

HERE = Path(__file__).parent
DEFAULT_TEMPLATE_DIR = HERE / "default_templates"

fsaverage_cut_template = DEFAULT_TEMPLATE_DIR / "fsaverage_cuts_template.json"
