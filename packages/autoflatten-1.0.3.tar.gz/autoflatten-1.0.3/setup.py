#!/usr/bin/env python
# -*- coding: utf-8 -*-
# This file is kept for backward compatibility with older pip versions.
# Configuration is in pyproject.toml.

from setuptools import setup

setup()
