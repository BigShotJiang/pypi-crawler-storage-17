"""Relativistic Spin Polarized toolkit (RSPt) package."""
