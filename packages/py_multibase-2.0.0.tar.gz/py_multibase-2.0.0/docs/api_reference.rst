API Reference
-------------

.. py:currentmodule:: multibase

.. autofunction:: encode

.. autofunction:: decode

.. autofunction:: get_codec

.. autofunction:: is_encoded
