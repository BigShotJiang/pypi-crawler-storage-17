# Ultralytics YOLO 🚀, AGPL-3.0 license

from .yolo import YOLO, YOLOE

__all__ = "YOLO", "YOLOE"  # allow simpler import
