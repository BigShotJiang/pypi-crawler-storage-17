# Ultralytics YOLO 🚀, AGPL-3.0 license

from .predict import DetectionPredictor

__all__ = "DetectionPredictor",
