# Ultralytics YOLO 🚀, AGPL-3.0 license

from .predict_vp import YOLOEVPSegPredictor

__all__ = ["YOLOEVPSegPredictor"]
