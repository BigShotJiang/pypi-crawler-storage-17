# dora-arm-so101
dora-arm-so101 node

## TODO

- Robot Calibrate

## Acknowledgment

- Thanks to dora-rs 🤗, [dora](https://github.com/dora-rs/dora).
- Thanks to TheRobotStudio 🤗, [SO101](https://github.com/TheRobotStudio/SO-ARM100).
- Thanks to LeRobot team 🤗, [LeRobot](https://github.com/huggingface/lerobot).


## Cite
