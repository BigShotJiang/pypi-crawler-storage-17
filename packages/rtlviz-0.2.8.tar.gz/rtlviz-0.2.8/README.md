# RTLViz - AI-Powered RTL Diagram Generator

> ⚠️ **RtlViz can make mistakes, so double-check it.**

An MCP (Model Context Protocol) server that enables AI assistants to generate publication-quality RTL block diagrams from Verilog/SystemVerilog code.

## Installation

```bash
pip install rtlviz
rtlviz-setup
```

That's it! The setup command auto-configures your AI IDE (Claude Desktop or VS Code).

### Manual Setup (Alternative)

If auto-setup doesn't work for your IDE, configure manually:

<details>
<summary><b>Claude Desktop</b> — <code>claude_desktop_config.json</code></summary>

**Windows:** `%APPDATA%\Claude\claude_desktop_config.json`  
**macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`  
**Linux:** `~/.config/claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "rtlviz": {
      "command": "rtlviz-server"
    }
  }
}
```
</details>

<details>
<summary><b>Claude Code</b> (VS Code Extension) — <code>~/.claude/settings.json</code></summary>

```json
{
  "mcpServers": {
    "rtlviz": {
      "command": "rtlviz-server"
    }
  }
}
```
</details>

<details>
<summary><b>VS Code Copilot</b> — <code>.vscode/mcp.json</code></summary>

```json
{
  "servers": {
    "rtlviz": {
      "command": "rtlviz-server"
    }
  }
}
```
</details>

<details>
<summary><b>Cursor</b> — <code>~/.cursor/mcp.json</code></summary>

```json
{
  "mcpServers": {
    "rtlviz": {
      "command": "rtlviz-server"
    }
  }
}
```
</details>

<details>
<summary><b>Windsurf</b> — <code>~/.codeium/windsurf/mcp_config.json</code></summary>

```json
{
  "mcpServers": {
    "rtlviz": {
      "command": "rtlviz-server"
    }
  }
}
```
</details>

## Quick Start Guide

### Step 1: Install the Package

```bash
pip install rtlviz
```

### Step 2: Run Setup

```bash
rtlviz-setup
```

This automatically configures RTLViz for all your AI IDEs (Claude Desktop, Claude Code, VS Code Copilot, Cursor, Windsurf).

### Step 3: Ask Your AI to Generate a Diagram

Open your AI IDE and ask:

> **"use rtlviz to generate block diagram for [your-project-path]"**

![Step 3: Ask your AI to generate a diagram](https://gist.github.com/user-attachments/assets/5efbeee5-62bd-4e30-a2f0-a393637c9b56)

### Step 4: Get Your Interactive Block Diagram

The AI analyzes your RTL code and generates a publication-quality block diagram:

![Step 4: Generated RISC-V CPU block diagram](https://gist.github.com/user-attachments/assets/373537c6-c83c-48f3-b416-79b423bf9242)

> 💡 **Recommended**: Works best with latest AI models like **Claude Opus 4.5** or **Claude Sonnet 4.5** for accurate RTL analysis.

## How It Works

RTLViz uses the **Model Context Protocol (MCP)** to seamlessly integrate with your AI IDE:

1. **Local MCP Server** — A lightweight server runs locally, exposing RTL analysis capabilities to your AI assistant
2. **Skill Injection** — The AI dynamically loads the `rtlviz://prompt` resource, which contains expert RTL analysis heuristics
3. **Semantic RTL Parsing** — The AI performs deep analysis of your Verilog/SystemVerilog, tracing signal dependencies and identifying pipeline stages
4. **Graphviz DOT Generation** — Architecture is encoded as DOT with semantic clustering, orthogonal routing, and component-specific styling
5. **Interactive Rendering** — The `render_diagram` tool generates a zoomable, pannable HTML5 viewer with Viz.js

**Zero infrastructure. No API keys. 100% local execution.**

## Enterprise & Privacy

- **Safe for Work**: All RTL analysis happens locally or via your enterprise-approved LLM provider.
- **Telemetry**: We collect minimal, anonymous usage data (version, session ID) to improve the tool.
  - **No IP addresses** or personal data.
  - **No file contents** or code.
- **Opt-Out**: Set the environment variable `RTLVIZ_TELEMETRY=0` to disable all network calls.
  - **Firewall Friendly**: If blocked, the tool fails silently and continues working.

## Developing & Releasing

### Analytics Setup
To enable your own analytics dashboard:
1. Deploy `analytics/google_apps_script.js` as a Google Web App (Execute as Me, Access: Anyone).
2. Set `RTLVIZ_TELEMETRY_URL` in `src/rtlviz/telemetry.py` to your Web App URL.

### Publishing to PyPI
1. **Bump Version**: Update `pyproject.toml` and `src/rtlviz/telemetry.py`.
2. **Build**: `python -m build`
3. **Upload**: `twine upload dist/*`

## Developers

- **Naveen Venkat** - [naveenvenkat1711@gmail.com](mailto:naveenvenkat1711@gmail.com)
- **Hariharan** - [hari.ayyaps@gmail.com](mailto:hari.ayyaps@gmail.com)

## License

MIT
