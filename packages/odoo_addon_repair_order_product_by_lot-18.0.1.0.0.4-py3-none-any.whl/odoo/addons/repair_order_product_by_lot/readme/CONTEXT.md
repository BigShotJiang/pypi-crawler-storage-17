Currently, in the “Repairs”, if we need to repair a product with a serial number, we must first select the product and then the specific serial number.

In some repair processes, for example, if product acceptance is handled using a barcode scanner, it is more convenient when the user can select the serial number directly, without searching for the product.
