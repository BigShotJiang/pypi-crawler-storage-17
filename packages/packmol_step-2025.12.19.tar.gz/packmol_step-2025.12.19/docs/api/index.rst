API Documentation
=================

Contents:

.. toctree::
   :maxdepth: 2

   modules


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
