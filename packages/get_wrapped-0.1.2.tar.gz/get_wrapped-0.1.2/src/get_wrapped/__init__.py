from get_wrapped.wrapped import generate_wrapped

__all__ = ["generate_wrapped"]
