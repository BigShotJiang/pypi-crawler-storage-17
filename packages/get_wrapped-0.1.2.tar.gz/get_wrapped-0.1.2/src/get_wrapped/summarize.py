def simple_summary(data) -> dict:
    """
    Minimal helper to wrap raw user data into a summary dict.
    Intentionally opinionated and optional.
    """
    return {"data": data}
