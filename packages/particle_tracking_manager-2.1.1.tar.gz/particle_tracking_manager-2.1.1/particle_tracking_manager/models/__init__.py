"""Options for models."""

from .opendrift import *
