# This page moved

The guide is now at: [API versions & SDK routing](api-versions-and-routing.md).
