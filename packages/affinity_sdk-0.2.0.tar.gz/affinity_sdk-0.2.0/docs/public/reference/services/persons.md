# Persons

::: affinity.services.persons.PersonService

::: affinity.services.persons.AsyncPersonService
