# Files (V1)

::: affinity.services.v1_only.EntityFileService
