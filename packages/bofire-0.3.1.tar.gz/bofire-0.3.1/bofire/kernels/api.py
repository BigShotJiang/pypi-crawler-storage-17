from bofire.kernels.mapper import map  # noqa: F401
