from bofire.outlier_detection.mapper import map
from bofire.outlier_detection.outlier_detection import (
    IterativeTrimming,
    OutlierDetection,
)
