from bofire.priors.mapper import map
