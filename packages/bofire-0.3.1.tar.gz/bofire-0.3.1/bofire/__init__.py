try:
    from bofire.version import version as __version__
except Exception:
    __version__ = "Unknown"
