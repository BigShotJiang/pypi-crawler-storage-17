from typing import Any

from bofire.data_models.base import BaseModel


class Transform(BaseModel):
    type: Any
