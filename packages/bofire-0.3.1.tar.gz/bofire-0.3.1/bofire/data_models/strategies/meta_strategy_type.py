from bofire.data_models.strategies.stepwise.stepwise import StepwiseStrategy


# Meta strategies compositions of other strategies.
# currently, we only have the Stepwise strategy as meta strategy.
MetaStrategy = StepwiseStrategy
