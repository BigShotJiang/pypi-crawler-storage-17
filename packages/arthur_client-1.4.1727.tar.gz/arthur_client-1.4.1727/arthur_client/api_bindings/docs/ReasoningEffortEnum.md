# ReasoningEffortEnum


## Enum

* `NONE` (value: `'none'`)

* `MINIMAL` (value: `'minimal'`)

* `LOW` (value: `'low'`)

* `MEDIUM` (value: `'medium'`)

* `HIGH` (value: `'high'`)

* `DEFAULT` (value: `'default'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


