# Typed Paradex

> A fully typed, validated async client for the Paradex API

Use *autocomplete* instead of documentation.

🚧 Under construction.