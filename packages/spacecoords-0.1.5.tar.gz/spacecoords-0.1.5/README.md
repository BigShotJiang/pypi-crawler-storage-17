# spacecoords

A collection of coordinate transforms for convenient use across our applications to avoid
duplication
