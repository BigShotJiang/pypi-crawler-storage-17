"""This does advanced spice things that jplephem can not do

#TODO: impalement what is needed here
"""

import spiceypy as spice

# spice.furnsh("./cassMetaK.txt")
