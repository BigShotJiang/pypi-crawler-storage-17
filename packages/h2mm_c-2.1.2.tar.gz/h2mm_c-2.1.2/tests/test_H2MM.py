#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 29 09:12:55 2021
Tests for verification of H2MM_C functions
@author: Paul David Harris
"""

import numpy as np
from itertools import product

import pytest
import H2MM_C as h2

rnd = np.random.default_rng(seed=13371)


def model_almost_equal(model1,model2):
    """
    Compare two models are essentially the same
    """
    prior = np.all(np.abs(model1.prior - model2.prior) < 0.1)
    trans_check = model1.trans / model2.trans
    trans = np.all(trans_check < 5) * np.all(trans_check > 0.5)
    obs = np.all(np.abs(model1.obs - model2.obs) < 0.1)
    return prior * trans * obs


def true_size(inp):
    """
    Small function that returns the size of an object as a tuple
    """
    if isinstance(inp, (list, tuple)):
        return (len(inp), )
    elif isinstance(inp, np.ndarray):
        return inp.shape
    else:
        return (-1, )


def true_iter(inp):
    """
    Iterate over list, tuple or numpy array elements
    """
    if isinstance(inp, (list, tuple)):
        return iter(inp)
    elif isinstance(inp, np.ndarray):
        return inp.ravel()
    else:
        return iter([inp, ])


def limits_func_system_converged(new, current, old):
    new.prior = np.ones(new.prior.size)/new.prior.size
    return new


def limits_func_user_converged(new, current, old, bound):
    if current.niter > bound:
        return new, 1
    if current.loglik <= old.loglik - 1e-6:
        return new, 2
    new.prior = np.ones(new.prior.size)/new.prior.size
    return new, 0


def limits_func_bad_size(new, current, old):
    return h2.factory_h2mm_model(current.nstate+1, current.ndet+1)


def limits_func_bad_return(new, current, old, bound):
    return {'prior':np.array([1,2.]), 'trans':np.array([[2., 4,],[9.,3]]), 'obs':np.array([2,3])}


def print_func_str(new, current, old, titer, ttotal, *args):
    return str(new) + "\n"


def print_func_num(new, current, old, titer, ttotal, *args):
    return 32


def print_func_exception(new, current, old, titer, ttotal, *args):
    raise ValueError("this is a dummy exception")


def data_gen_list():
    times = [np.array([   20,   50,   90,   95,  190,  230,  350,  800], dtype=np.int32),
             np.array([  820,  850,  990,  995, 1055, 1130, 1290, 1525]),
             np.array([ 1750, 1820, 1950, 1985, 2055, 2110, 2220, 2325])]
    dets =  [np.array([    1,    1,    0,    1,    0,    1,    0,    1], dtype=np.uint8),
             np.array([    0,    0,    0,    1,    1,    1,    1,    0], dtype=np.int32),
             np.array([    1,    0,    1,    1,    0,    1,    0,    1])]
    nphot = sum(t.size for t in times)
    return (dets, times, nphot)


def data_gen_tuple():
    dets, times, nphot = data_gen_list()
    dets, times = tuple(dets), tuple(times)
    return (dets, times, nphot)


def data_gen_np():
    dets, times, nphot = data_gen_list()
    det, time = np.empty(len(dets), dtype=object), np.empty(len(dets), dtype=object)
    for i in range(len(dets)):
        det[i], time[i] = dets[i], times[i]
    return (det, time, nphot)


@pytest.fixture(scope="module")
def simple_data_list():
    return data_gen_list()


@pytest.fixture(scope="module")
def simple_data_tuple():
    return data_gen_tuple()


@pytest.fixture(scope="module")
def simple_data_np():
    return data_gen_np()


@pytest.fixture(scope="module", params=[data_gen_np, data_gen_list, data_gen_tuple])
def simple_data_all(request):
    dets, times, nphot = request.param()
    return dets, times, nphot


def test_MakeModel():
    """
    Test proper model values assigned when making new model
    """
    prior = np.ones(3)
    trans = np.array([[0.999,0.0005,0.005],[0.0005,0.999,0.0005],[0.0005,0.0005,0.999]])
    obs = np.array([[0.1,0.2,0.7],[0.5,0.3,0.2],[0.4,0.4,0.2]])
    model = h2.h2mm_model(prior,trans,obs)
    assert model.nstate == 3
    assert model.ndet == 3
    assert pytest.approx(1.0) == model.prior.sum()
    assert np.allclose(model.trans.sum(axis=1), 1.0)
    assert np.allclose(model.obs.sum(axis=1), 1.0)
    assert model.k == 14


def test_Factory():
    """
    Ensure factory_h2mm_model returns correct values
    """
    model = h2.factory_h2mm_model(3,2)
    assert type(model) == h2.h2mm_model
    assert model.nstate == 3
    assert model.ndet == 2
    assert model.k == 11


def test_Model_access():
    """
    Test setting of model arrays works
    """
    model = h2.factory_h2mm_model(4,3)
    with pytest.warns(UserWarning):
        model.prior = np.linspace(0,5,4)
    with pytest.warns(UserWarning):
        model.trans = np.array([[1.6, 1.2, 0.5, 0.1],[0.5, 9.8, 1.1, 0.2],[0.5,0.9,7.2, 1.2],[0.5,0.5,0.6,9.5]])
    with pytest.warns(UserWarning):
        model.obs = np.ones((4,3))
    assert pytest.approx(1.0) == model.prior.sum(), "Prior non-stochastic"
    assert np.allclose(model.trans.sum(axis=1), 1.0), "trans not row-stochastic"
    assert np.allclose(model.obs.sum(axis=1), 1.0), "obs not row-stochastic"


def test_InputType(simple_data_all):
    """
    Test all types of data input work
    """
    # test optimization
    dets, times, nphot = simple_data_all
    out = h2.EM_H2MM_C(h2.factory_h2mm_model(2,2), dets, times)
    assert isinstance(out, h2.h2mm_model)
    assert out.ndet == 2, 'number of detectors changed'
    assert out.nstate == 2, 'number of states changed'
    assert out.nphot == nphot, "nphot not updated chorectly"
    assert out.loglik < 0.0, 'positive/0 loglik after optimization'
    

@pytest.fixture(scope="module", params=(2,3,4))
def opt_model(request):
    nstate = request.param
    dets, times, nphot = data_gen_list()
    return h2.EM_H2MM_C(h2.factory_h2mm_model(nstate,2), dets, times, max_iter=20)


def test_model_norm(opt_model):
    assert np.allclose(opt_model.prior.sum(), 1.0)
    assert np.allclose(opt_model.trans.sum(axis=1), 1.0)
    assert np.allclose(opt_model.obs.sum(axis=1), 1.0)


def model_opt():
    dets, times, nphot = data_gen_list()
    out1 = h2.EM_H2MM_C(h2.factory_h2mm_model(2,2), dets, times, max_iter=10, opt_array=True, num_cores=1)
    out2 = h2.EM_H2MM_C(h2.factory_h2mm_model(3,2), dets, times, max_iter=10, opt_array=True, num_cores=1)
    out3 = np.concatenate([out1, out2])
    for model in reversed(out1):
        out = model
        if out.conv_code & h2.convcode.output:
            break
    yield out
    yield out2
    yield out3


@pytest.fixture(scope='module', params=[out for out in model_opt()])
def model_array(request):
    return request.param


def test_H2MM_arr(model_array,simple_data_all):
    """
    Test H2MM_arr function
    """
    dets, times, nphot = simple_data_all
    arr_out = h2.H2MM_arr(model_array, dets, times, num_cores=1)
    assert isinstance(model_array,  h2.h2mm_model) == isinstance(arr_out, h2.h2mm_model), 'ouput of different type han input'
    arr_out = np.array([arr_out,], dtype=np.object_) if isinstance(arr_out, h2.h2mm_model) else arr_out
    model_array = np.array([model_array,], dtype=np.object_) if isinstance(model_array, h2.h2mm_model) else model_array
    assert arr_out.shape == model_array.shape, "input h2mm_model array and output array different size"
    assert np.allclose([m.loglik for m in true_iter(arr_out)], [m.loglik for m in true_iter(model_array)]), "logliks significantly changed"

# dllclose(g.sum(axis=1), 1.0) 
    
def test_Viterbi(opt_model,simple_data_all):
    """
    Smoke test for viterbi and path_loglik functions
    > Note that is uses single core due to error in pytest that cannot be
    > reproduced outside pytest
    """
    dets, times, nphot = simple_data_all
    path, scale, ll, icl = h2.viterbi_path(opt_model, dets, times, num_cores=1)
    assert true_size(path) == true_size(scale) == true_size(dets)
    for p, s, t, d in zip(true_iter(path), true_iter(scale),true_iter(times), true_iter(dets)):
        assert np.issubdtype(p.dtype, np.integer)
        assert np.all(p < opt_model.nstate)
        assert p.shape == s.shape == t.shape
        assert np.issubdtype(s.dtype, np.floating)
        assert np.all(s <= 1.0), f"{(opt_model.prior*opt_model.obs[:,d[0]]).sum()}"
        assert np.all(s >= 0.0)
    for BIC, LL, log, logpath in product(*((False, True) for _ in  range(4))):
        if sum((BIC, LL, log, logpath)) == 0:
            continue
        out = h2.path_loglik(opt_model, dets, times, path, BIC=BIC, total_loglik=LL, loglikarray=log, loglikpath=logpath)
        if sum((BIC, LL, log, logpath)) == 1:
            out = (out, )
        cur_pos = 0
        if BIC:
            bic = out[cur_pos]
            cur_pos += 1
            assert bic > 0.0
        if LL:
            ll = out[cur_pos]
            cur_pos += 1
            assert ll < 0.0
            if BIC and LL:
                assert np.allclose(bic, np.log(nphot)*opt_model.k-2*ll)
        if log:
            lg = out[cur_pos]
            cur_pos += 1
            assert np.all(lg < 0.0)
            assert true_size(lg) == true_size(dets)
            assert np.issubdtype(lg.dtype, np.floating)
            if log and LL:
                assert np.allclose(lg.sum(), ll)
        if logpath:
            lp = out[cur_pos]
            assert isinstance(lp, np.ndarray) and lp.dtype == np.object_, f"wrong logpath dtype: {type(lp)}"
            assert all(np.all(lpa < 0.0) for lpa in lp), "loglik improperly calculated"
            if log:
                assert np.allclose(np.array([l.sum() for l in lp]), lg)
    lg = h2.path_loglik(opt_model, dets, times, path, BIC=False, total_loglik=False, loglikarray=True, loglikpath=False)
    lp = h2.path_loglik(opt_model, dets, times, path, BIC=False, total_loglik=False, loglikarray=False, loglikpath=True)
    assert np.allclose(lg, np.array([l.sum() for l in lp])), "loglik by array and path differ in result"
    

###############################################################################
### The following function is a better verification.
### It checks that single and multi-core viterbi calculations are consistent.
### However, I have been unable to reproduce failures of this test when not
### using pytest.
### Specifically only the scale array has errors when using multiple cores.
### Oddly, the loglik is not affected, even though in the code the loglik
### is a running log sum of scale.
### My best guess is that pytest is interfering with one or more mutexes, or
### otherwise intercepting and scrambling the arrays.
### Uncomment this when running non-ci tests, ideally the problem will be found
### and dealt with so all runs are consistent
###############################################################################
# def test_Viterbi_multi_core(opt_model,simple_data_all):
#     """
#     Smoke test for viterbi and path_loglik functions
#     """
#     dets, times, nphot = simple_data_all
#     path, scale, ll, icl = h2.viterbi_path(opt_model, dets, times, num_cores=3)
#     path1, scale1, ll1, icl1 = h2.viterbi_path(opt_model, dets, times, num_cores=1)
#     llm = np.allclose(ll, ll1)
#     iclm = np.allclose(icl, icl1)
#     assert type(path) == type(scale) == type(times)
#     assert true_size(path) == true_size(scale) == true_size(dets)
#     values = {"pathmatch":list(), "scalematch":list(), "scaleupper":list(), "scalelower":list(), "scale1upper":list(), "scale1lower":list()}
#     for p, s, p1, s1, t, d in zip(true_iter(path), true_iter(scale), true_iter(path1), true_iter(scale1),true_iter(times), true_iter(dets)):
#         assert p.shape == s.shape == t.shape, "path and shape arrays not the same as times/dets"
#         assert np.issubdtype(p.dtype, np.integer), "wrong path dtype"
#         assert np.issubdtype(s.dtype, np.floating), "wrong scale dtype"
#         assert np.all(p < opt_model.nstate), "out of bounds path index"
#         values['pathmatch'].append(None if np.all(p == p1) else (s1-s)[:np.argwhere(p != p1)[-1,0]+1])
#         values['scalematch'].append(None if np.allclose(s, s1) else s1 - s)
#         values['scaleupper'].append(None if np.all(s <= 1.0) else s)
#         values['scalelower'].append(None if np.all(s >= 0.0) else s)
#         values['scale1upper'].append(None if np.all(s1 <= 1.0) else s1)
#         values['scale1lower'].append(None if np.all(s1 >= 0.0) else s1)
#     values = {k:[v for v in val if v is not None] for k, val in values.items()}
#     values = {k:v for k, v in values.items() if v}
#     assert len(values)==0 and llm and iclm, f'll:{ll-ll1}, icl:{icl-icl1}, {values}'
#     for BIC, LL, log in combinations_with_replacement((True, False), 3):
#         if sum((BIC, LL, log)) == 0:
#             continue
#         out = h2.path_loglik(opt_model, dets, times, path, BIC=BIC, total_loglik=LL, loglikarray=log)
#         if sum((BIC, LL, log)) == 1:
#             out = (out, )
#         cur_pos = 0
#         if BIC:
#             bic = out[cur_pos]
#             assert bic > 0.0
#             cur_pos += 1
#         if LL:
#             ll = out[cur_pos]
#             assert ll < 0.0
#             cur_pos += 1
#             if BIC and LL:
#                 assert np.allclose(bic, np.log(nphot)*opt_model.k-2*ll)
#         if log:
#             lg = out[cur_pos]
#             assert np.all(lg < 0.0)
#             assert true_size(lg) == true_size(dets)
#             assert np.issubdtype(lg.dtype, np.floating)
#             if log and LL:
#                 assert np.allclose(lg.sum(), ll)
        
def test_Limits(simple_data_list):
    """
    Ensure basic limits functions work properly
    """
    dets, times, nphot = simple_data_list
    limits = h2.h2mm_limits(min_trans=1e-7, max_trans=1e-1)
    for lim in ('minmax', 'revert', 'revert_old'):
        out = h2.EM_H2MM_C(h2.factory_h2mm_model(2,2), dets, times, bounds=limits, bounds_func=lim)
        assert np.all(out.trans[np.eye(2) < 1] < 1e-1), "trans rates smaller than allowed by bounds"
        assert np.all(out.trans[np.eye(2) < 1] > 1e-7), "trans rates larger than allowed by trans"
    

def test_Limits_usr(opt_model, simple_data_list):
    """
    Smoke test for user defined limits functprint_model(out_arr)
            ion
    """
    dets, times, nphot = simple_data_list
    out = h2.EM_H2MM_C(opt_model, dets, times, bounds_func=limits_func_system_converged)
    assert isinstance(out, h2.h2mm_model), "EM_H2MM_C returned wrong type"
    out = h2.EM_H2MM_C(opt_model, dets, times, bounds_func=limits_func_user_converged, bounds=10)
    assert isinstance(out, h2.h2mm_model)
    assert out.niter == 10


def test_User_print_str(opt_model, simple_data_list):
    """
    Smoke test for print func returning a string
    """
    dets, times, nphot = simple_data_list
    h2.EM_H2MM_C(opt_model, dets, times, print_func=print_func_str)
    h2.EM_H2MM_C(opt_model, dets, times, print_func=print_func_num)
    with pytest.raises(Exception):
        h2.EM_H2MM_C(opt_model, dets, times, print_func=print_func_exception)


def test_Sim():
    """
    Simulate a trajectory with simulation function, then check if optimization finds
    a model with similar results
    """
    times = [np.cumsum(np.ceil(rnd.exponential(1000,size=(75)))).astype('L') for i in range(10000)]
    prior_init = np.array([1/3,1/3,1/3])
    trans_init = np.array([[1-1.5e-6,1e-6,5e-7],[1e-6,1-1.5e-6,5e-7],[5e-7,5e-7,1-1e-6]])
    obs_init = np.array([[0.2,0.8],[0.5,0.5],[0.8,0.2]])
    model_init = h2.h2mm_model(prior_init,trans_init,obs_init)
    sim_traj = [h2.sim_phtraj_from_times(model_init,tm) for tm in times]
    paths, colors = [], []
    for path, color in sim_traj:
        paths.append(path)
        colors.append(color)
    limits = h2.h2mm_limits(min_prior=0.001,max_prior=0.999,min_trans=1e-10,max_trans=1-1e-10,min_obs=0.001,max_obs=0.999)
    model_test = h2.factory_h2mm_model(3,2).optimize(colors,times,bounds=limits,bounds_func='revert',max_iter=3000)
    assert model_almost_equal(model_test,model_init)


def test_BadData(opt_model):
    """
    Test errors raised when bad data is passed to array
    """
    dets, time = data_gen_list()[0].copy(), data_gen_list()[1].copy()
    time[0][1] = 0
    with pytest.raises(ValueError):
        h2.EM_H2MM_C(opt_model, dets, time)
    dets = data_gen_list()[0].copy()
    dets[0][0] = 2
    with pytest.raises(Exception):
        h2.EM_H2MM_C(opt_model, dets, data_gen_list()[1])
    dets[0] = np.concatenate([dets[0], [1]])
    with pytest.raises(ValueError):
        h2.EM_H2MM_C(opt_model, dets, time)
    dets, time = data_gen_list()[0].copy(), data_gen_list()[1].copy()
    with pytest.raises(Exception):
        h2.EM_H2MM_C(opt_model, time, dets)


def test_BadLimits(opt_model, simple_data_list):
    """
    Check errors raised when bad limits func is passed
    """
    dets, times, nphot = simple_data_list
    with pytest.raises(ValueError):
        h2.EM_H2MM_C(opt_model, dets, times, bounds_func=limits_func_bad_size)
    with pytest.raises(TypeError):
        h2.EM_H2MM_C(opt_model, dets, times, bounds_func=limits_func_bad_return)


def test_OOp(simple_data_all):
    """
    Smoke tests to ensure basic oop operations on models work as expected
    """
    dets, times, nphot = simple_data_all
    in_mod = h2.factory_h2mm_model(3,2)
    out_mod = in_mod.optimize(dets, times, inplace=False)
    assert in_mod is not out_mod
    assert np.all(in_mod.prior != out_mod.prior)
    assert np.all(in_mod.trans != out_mod.trans)
    assert np.all(in_mod.obs != out_mod.obs)
    out_mod = in_mod.optimize(dets, times, inplace=True)
    assert np.all(in_mod.prior == out_mod.prior)
    assert np.all(in_mod.trans == out_mod.trans)
    assert np.all(in_mod.obs == out_mod.obs)
    in_mod = h2.factory_h2mm_model(3,2)
    ev_mod = in_mod.evaluate(dets, times, inplace=False)
    assert ev_mod is not in_mod
    assert ev_mod.loglik < 0 and not np.isinf(ev_mod.loglik)
    assert ev_mod.nphot == nphot
    ev_mod = in_mod.evaluate(dets, times, inplace=True)
    assert in_mod.loglik < 0 and not np.isinf(in_mod.loglik)
    assert in_mod.nphot == nphot


def test_hash():
    m1 = h2.h2mm_model(np.array([0.2,0.5,0.3]), 
                       np.array([[0.99, 0.005, 0.005],
                                 [0.001, 0.998, 0.001],
                                 [0.002, 0.002, 0.996]]),
                       np.array([[0.5, 0.5],
                                 [0.3, 0.7],
                                 [0.7, 0.3]]))
    with pytest.raises(TypeError):
        hash(m1)
    mh1 = m1.sort_states()
    hash(mh1)
    assert mh1 == m1
    m2 = h2.factory_h2mm_model(3,2).sort_states()
    assert m2 != mh1


def verify_allmodel(model, nstate, ndet, nphot, niter, conv, ll, prior, trans, obs):
    assert model.nstate == nstate, "nstate changed"
    assert model.ndet == ndet, "ndet changed"
    assert model.nphot == nphot, "nphot changed"
    assert model.niter == niter, "niter changed"
    assert model.conv_code == conv, "conv_code changed"
    if model.nphot == 0:
        with pytest.warns():
            assert (np.isnan(model.loglik) and np.isnan(ll)) or model.loglik == ll, "loglik changed"
    else:
        assert (np.isnan(model.loglik) and np.isnan(ll)) or model.loglik == ll, "loglik changed"
    assert np.all(model.prior == prior), "prior changed"
    assert np.all(model.trans == trans), "trans changed"
    assert np.all(model.obs == obs), "obs changed"


def test_immutable(simple_data_np):
    dets, times, nphot = simple_data_np
    m1 = h2.factory_h2mm_model(2, 3).sort_states()
    m1nstate = m1.nstate
    m1ndet = m1.ndet
    m1nphot = m1.nphot
    m1niter = m1.niter
    m1conv = m1.conv_code
    if m1.nphot == 0:
        with pytest.warns():
            m1ll = m1.loglik
    else:
        m1ll = m1.loglik
    m1prior = m1.prior
    m1trans = m1.trans
    m1obs = m1.obs
    h2.H2MM_arr(m1, dets, times)
    verify_allmodel(m1, m1nstate, m1ndet, m1nphot, m1niter, m1conv, m1ll, m1prior, m1trans, m1obs)
    m1.evaluate(dets, times, inplace=False)
    verify_allmodel(m1, m1nstate, m1ndet, m1nphot, m1niter, m1conv, m1ll, m1prior, m1trans, m1obs)
    with pytest.raises(TypeError):
        m1.evaluate(dets, times, inplace=True)
    verify_allmodel(m1, m1nstate, m1ndet, m1nphot, m1niter, m1conv, m1ll, m1prior, m1trans, m1obs)
    m2 = h2.EM_H2MM_C(m1, dets, times)
    verify_allmodel(m1, m1nstate, m1ndet, m1nphot, m1niter, m1conv, m1ll, m1prior, m1trans, m1obs)
    m3 = m1.optimize(dets, times, inplace = False)
    verify_allmodel(m1, m1nstate, m1ndet, m1nphot, m1niter, m1conv, m1ll, m1prior, m1trans, m1obs)
    with pytest.raises(TypeError):
        m1.optimize(dets, times, inplace=True)
    h2.H2MM_arr([m1, m2, m3], dets, times)
    verify_allmodel(m1, m1nstate, m1ndet, m1nphot, m1niter, m1conv, m1ll, m1prior, m1trans, m1obs)
    path, _, _ , _ = h2.viterbi_path(m1, dets, times)
    verify_allmodel(m1, m1nstate, m1ndet, m1nphot, m1niter, m1conv, m1ll, m1prior, m1trans, m1obs)
    h2.path_loglik(m1, dets, times, path)
    verify_allmodel(m1, m1nstate, m1ndet, m1nphot, m1niter, m1conv, m1ll, m1prior, m1trans, m1obs)
    with pytest.raises(AttributeError):
        m1.prior = np.ones(m1.nstate) / m1.nstate
    with pytest.raises(AttributeError):
        m1.trans = np.ones((m1.nstate, m1.nstate)) / m1.nstate
    with pytest.raises(AttributeError):
        m1.prior = np.ones((m1.nstate, m1.ndet)) / m1.ndet


def test_bytes(opt_model):
    bt = opt_model.tobytes()
    bmodel = h2.h2mm_model.frombytes(bt)
    assert bmodel.nstate == opt_model.nstate, "nstate not re-created"
    assert bmodel.ndet == opt_model.ndet, "ndet not re-created"
    assert bmodel.nphot == opt_model.nphot, "nphot not re-created"
    assert bmodel.niter == opt_model.niter, "niter not re-created"
    assert bmodel.conv_code == opt_model.conv_code, "conv_code not re-created"
    assert bmodel.loglik == opt_model.loglik, "loglik not re-created"
    assert bmodel.conv_code == opt_model.conv_code, "conv_code not re-created"
    assert np.all(bmodel.prior == opt_model.prior), "prior not re-created"
    assert np.all(bmodel.trans == opt_model.trans), "trans no re-created"
    assert np.all(bmodel.obs == opt_model.obs), "obs not re-created"



if __name__ == '__main__':
    pytest.main(['-x, -v, tests/test_H2MM.py'])
