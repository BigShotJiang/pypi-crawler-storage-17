from ..speaker import Speaker

class Thomas(Speaker):
    name = "Thomas"