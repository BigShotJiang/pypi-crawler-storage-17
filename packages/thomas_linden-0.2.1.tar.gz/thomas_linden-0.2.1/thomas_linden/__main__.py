from .speakers import Thomas

def main():
    Thomas().print_name()

if __name__ == "__main__":
    main()