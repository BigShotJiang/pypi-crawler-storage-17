def print_me():
    print("hi, my name is thomas")