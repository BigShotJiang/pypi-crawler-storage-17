from .latex import generate_image, generate_table

__all__ = ["generate_table", "generate_image"]
