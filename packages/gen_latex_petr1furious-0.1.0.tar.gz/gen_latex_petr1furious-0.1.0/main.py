from gen_latex.cli import app


if __name__ == "__main__":
    app()
