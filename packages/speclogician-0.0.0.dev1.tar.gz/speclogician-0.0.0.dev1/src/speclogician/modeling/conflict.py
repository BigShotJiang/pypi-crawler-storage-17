#
#   Imandra Inc.    
#
#   conflict.py
#

from pydantic import BaseModel

class Conflict(BaseModel):
    """
    """
    pass