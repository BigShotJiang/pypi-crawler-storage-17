#
#   Imandra Inc.
#
#   reports.py
#

from pydantic import BaseModel


class TestFormalization(BaseModel):
    pass