#
#   Imandra Inc.
#
#   utils/__init__.py
#

from rich.console import Console

console = Console()
