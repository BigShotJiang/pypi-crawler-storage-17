# SpecLogician
SpecLogicain AI framework for data-driven formal program specification synthesis, verification and analysis


www.speclogician.dev