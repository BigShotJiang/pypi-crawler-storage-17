from.game import TicTacToe


__all__ = ["TicTacToe"]
__version__ = "2.0.0"

