# 🎮 Tic Tac Toe

Features:
- Easy & Hard AI (Minimax)
- Emoji + Colors
- CLI
- Tested with pytest

## Install
pip install eldar-tic-tac-toe

## Play
tic-tac-toe --ai hard
