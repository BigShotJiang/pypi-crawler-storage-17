#!/usr/bin/env python3
# Import the CLI from the new modular structure
from .cli import cli

if __name__ == '__main__':
    cli()