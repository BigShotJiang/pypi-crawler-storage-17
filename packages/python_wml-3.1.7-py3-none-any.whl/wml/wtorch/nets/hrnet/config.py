from yacs.config import CfgNode as CN
_C = CN(new_allowed=True)
