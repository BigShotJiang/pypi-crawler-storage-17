import importlib.metadata

__version__ = importlib.metadata.version("compress_pptx")
