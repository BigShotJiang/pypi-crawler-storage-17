"""
Constants for extension app labels.
"""

# Prefix for all django-cfg extension app labels
APP_LABEL_PREFIX = "ext_"
