"""Interactive functionality classes."""

from __future__ import annotations

from .config import InteractiveConfig
from .utils import InteractionStatus
