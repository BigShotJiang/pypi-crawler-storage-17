"""Meltano."""  # noqa: I002

import importlib.metadata

__version__ = importlib.metadata.version("meltano")
