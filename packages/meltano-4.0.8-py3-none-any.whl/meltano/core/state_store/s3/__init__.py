"""S3 state store."""
