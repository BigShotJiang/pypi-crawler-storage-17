"""JSON Schemas used by Meltano."""
