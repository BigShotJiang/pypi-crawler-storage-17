# Eldar Math Duel 🎯

Terminal üçün 2 oyunçulu riyaziyyat dueli oyunu.

## Qaydalar
- Təsadüfi riyazi suallar
- Düz cavab = 1 xal
- exit yazaraq oyunu dayandırmaq olar

## İstifadə

```python
from eldar_math_duel import MathDuel

MathDuel().play()
