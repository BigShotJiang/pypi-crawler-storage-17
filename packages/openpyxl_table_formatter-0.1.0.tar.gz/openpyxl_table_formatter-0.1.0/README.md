# openpyxl_table_formatter

A simple package to help export pandas DataFrame to Excel files.

Please note this package is still in early development and only 3 themes are available:
- Medium 1 - grey accent
- Medium 2 - blue accent
- Medium 3 - orange accent

## Instalation

- with pip:
`pip install openpyxl-table-formatter`

- with uv:
`uv add openpyxl-table-formatter`
