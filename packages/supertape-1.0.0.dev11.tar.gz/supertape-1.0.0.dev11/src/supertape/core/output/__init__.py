"""Output stream abstraction for supertape."""
