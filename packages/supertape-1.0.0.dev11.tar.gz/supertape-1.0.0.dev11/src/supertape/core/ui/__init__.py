"""UI-related utilities and constants for Supertape interfaces."""
