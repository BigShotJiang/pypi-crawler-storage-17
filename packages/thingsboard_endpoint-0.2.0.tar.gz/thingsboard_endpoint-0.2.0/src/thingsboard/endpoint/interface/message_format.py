# -*- coding: utf-8 -*-

from abc import ABCMeta, abstractmethod


class MessageFormat(object):
    """
    The MessageFormat interface declares the methods that are used by the {@link Endpoint}
    implementation in order to encode and decode attribute changes into MQTT messages.
    """
    __metaclass__ = ABCMeta

    @abstractmethod
    def serialize_endpoint(self, endpoint):
        """A MessageFormat implementation should return the encoded payload of the serialization of the
           given endpoint.

        :param endpoint: Endpoint to serialize.
        :type endpoint: Endpoint
        :return: Raw data representation of the endpoint.
        :rtype: bytearray
        """
        pass

    @abstractmethod
    def serialize_node(self, node):
        """A MessageFormat implementation should return the encoded payload of the serialization of the
           given node.

        :param node: Node to serialize.
        :type node: Node
        :return: Raw data representation of the node.
        :rtype: bytearray
        """
        pass

    @abstractmethod
    def serialize_attribute(self, attribute):
        """A MessageFormat implementation should return the encoded payload of the serialization of the
           given attribute.

        :param attribute: Attribute to serialize.
        :type attribute: Attribute
        :return: Raw data representation of the attribute.
        :rtype: bytearray
        """
        pass

    @abstractmethod
    def deserialize_attribute(self, data, attribute):
        """A MessageFormat implementation should parse the data payload and update the given attribute
           according to the data.

        :param data: Data received in the MQTT message.
        :type data: bytearray
        :param attribute: Attribute to update using the raw message data.
        :type attribute: Attribute
        """
        pass
