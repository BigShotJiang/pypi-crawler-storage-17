# -*- coding: utf-8 -*-

from ..interface.message_format import MessageFormat


class JsonZipMessageFormat(MessageFormat):
    pass
    # TODO: Implement
