export FOO=bar
