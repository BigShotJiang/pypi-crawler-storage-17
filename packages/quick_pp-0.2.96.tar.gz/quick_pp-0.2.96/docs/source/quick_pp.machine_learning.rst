Predict Pipeline module
--------------------------------------------

.. automodule:: quick_pp.machine_learning.predict_pipeline
   :members:
   :undoc-members:
   :show-inheritance:

Train Pipeline module
------------------------------------------

.. automodule:: quick_pp.machine_learning.train_pipeline
   :members:
   :undoc-members:
   :show-inheritance:

Utils module
--------------------------------

.. automodule:: quick_pp.machine_learning.utils
   :members:
   :undoc-members:
   :show-inheritance:
