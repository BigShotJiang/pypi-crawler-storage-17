=======
History
=======

0.1.0 (2023-10-08)
------------------
* First release on PyPI.

0.1.5 (2024-06-05)
------------------
* Add core calibration module.

0.1.11 (2024-07-17)
-------------------
* Update requirements to fix security risks.

0.1.13 (2024-10-04)
-------------------
* Add hydrocarbon typing based on gas composition.
* Add geomechanics module.
* Add quick compare function.
* Update estimate vsh_gr function.
* Update porosity and qaqc module.

0.1.18 (2024-11-14)
-------------------
* Add stick plot.
* Update rock typing module.
* Add skelt harrison saturation function.
* Add sensitivity analysis in ressum module.

0.2.1 (2025-05-20)
-------------------
* Refactor the API module.
* Add ML modelling module.
* Add cli using click.
* Refactor the well log plotter module.

0.2.2 (2025-05-23)
-------------------
* Add qpp_assistant module based on chainlit.
* Updated the requirements to use Python 3.11.
* Updated the readme and documentation.
