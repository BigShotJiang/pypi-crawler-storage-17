Geomechanics module
--------------------------------------------

.. automodule:: quick_pp.rock_physics.geomechanics
   :members:
   :undoc-members:
   :show-inheritance:

Geophysics module
--------------------------------------------

.. automodule:: quick_pp.rock_physics.geophysics
   :members:
   :undoc-members:
   :show-inheritance:

Rock Physics Model module
--------------------------------------------

.. automodule:: quick_pp.rock_physics.rpm
   :members:
   :undoc-members:
   :show-inheritance:
