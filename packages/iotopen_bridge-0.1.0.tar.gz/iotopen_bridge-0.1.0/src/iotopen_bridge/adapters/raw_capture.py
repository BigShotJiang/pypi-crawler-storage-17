# File: src/iotopen_bridge/adapters/raw_capture.py
# SPDX-License-Identifier: MIT
from __future__ import annotations

import contextlib
import os
import threading
import time
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RawCaptureConfig:
    enabled: bool = False
    directory: str = "./state/capture"
    max_bytes_per_file: int = 5_000_000
    prefix: str = "mqtt"


class RawCapture:
    """Best-effort raw capture of MQTT payloads (RX/TX) to rotating files.

    This is intentionally simple and dependency-free.
    """

    def __init__(self, cfg: RawCaptureConfig) -> None:
        self.cfg = cfg
        self._lock = threading.RLock()
        self._fh: object | None = None
        self._path: Path | None = None
        self._written = 0

    def _open_if_needed(self) -> None:
        if not self.cfg.enabled:
            return

        with self._lock:
            if self._fh is not None:
                return

            Path(self.cfg.directory).mkdir(parents=True, exist_ok=True)
            ts = time.strftime("%Y%m%d-%H%M%S")
            fname = f"{self.cfg.prefix}-{ts}-{os.getpid()}.log"
            path = Path(self.cfg.directory) / fname
            self._path = path
            self._fh = open(path, "ab", buffering=0)  # noqa: SIM115
            self._written = 0

    def _rotate_if_needed(self) -> None:
        if not self.cfg.enabled:
            return
        with self._lock:
            if self._fh is None:
                return
            if self._written < int(self.cfg.max_bytes_per_file):
                return
            with contextlib.suppress(Exception):
                self._fh.close()
            self._fh = None
            self._path = None
            self._written = 0

    def _write_line(self, line: bytes) -> None:
        if not self.cfg.enabled:
            return
        self._open_if_needed()
        with self._lock:
            if self._fh is None:
                return
            with contextlib.suppress(Exception):
                self._fh.write(line)
                self._written += len(line)
        self._rotate_if_needed()

    def capture_rx(self, topic: str, payload: bytes, qos: int, retain: bool) -> None:
        if not self.cfg.enabled:
            return
        meta = f"RX topic={topic} qos={qos} retain={retain} bytes={len(payload)}\n".encode("utf-8", "ignore")
        self._write_line(meta + payload + b"\n\n")

    def capture_tx(self, topic: str, payload: bytes, qos: int, retain: bool) -> None:
        if not self.cfg.enabled:
            return
        meta = f"TX topic={topic} qos={qos} retain={retain} bytes={len(payload)}\n".encode("utf-8", "ignore")
        self._write_line(meta + payload + b"\n\n")
