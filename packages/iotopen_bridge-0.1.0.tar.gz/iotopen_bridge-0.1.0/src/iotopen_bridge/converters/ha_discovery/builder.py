# File: src/iotopen_bridge/converters/ha_discovery/builder.py
# SPDX-License-Identifier: MIT
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..mapping.entities import HAEntitySpec
from .topics import discovery_config_topic


@dataclass(frozen=True)
class DiscoveryMessage:
    topic: str
    payload: dict[str, Any]


def _availability_list(entity: HAEntitySpec) -> list[str]:
    """Normalize availability into a list of topics."""
    av_multi = getattr(entity, "availability_topics", None)
    if isinstance(av_multi, list):
        return [str(t).strip() for t in av_multi if isinstance(t, str) and str(t).strip()]

    av_single = getattr(entity, "availability_topic", None)
    if isinstance(av_single, str) and av_single.strip():
        return [av_single.strip()]

    return []


def build_discovery(entity: HAEntitySpec, *, discovery_prefix: str) -> DiscoveryMessage:
    """Build Home Assistant MQTT discovery config (payload + topic) from HAEntitySpec.

    Intentionally:
      - stable keys/behavior (avoid breaking discovery snapshot hashes)
      - permissive: ignore unknown fields
      - strict where HA requires (e.g. switch/button command_topic)
    """
    dp = str(discovery_prefix).strip("/")
    comp = entity.component
    obj = entity.object_id
    topic = discovery_config_topic(dp, comp, obj)

    payload: dict[str, Any] = {
        "name": entity.name,
        "unique_id": entity.unique_id,
        "qos": int(getattr(entity, "qos", 0) or 0),
        "retain": bool(getattr(entity, "retain", False)),
    }

    # State topic is not used by MQTT button; keep optional.
    if getattr(entity, "state_topic", None):
        payload["state_topic"] = entity.state_topic

    # Device block
    dev = getattr(entity, "device", None)
    if dev is not None:
        payload["device"] = {
            "identifiers": list(dev.identifiers),
            "name": dev.name,
            "manufacturer": dev.manufacturer,
            "model": dev.model,
        }
        if getattr(dev, "sw_version", None):
            payload["device"]["sw_version"] = dev.sw_version

    # Optional classification
    for k in ("device_class", "unit_of_measurement", "state_class", "icon", "entity_category"):
        v = getattr(entity, k, None)
        if v is not None and v != "":
            payload[k] = v

    # Attributes
    if getattr(entity, "json_attributes_topic", None):
        payload["json_attributes_topic"] = entity.json_attributes_topic

    # Availability
    av = _availability_list(entity)
    if av:
        payload["payload_available"] = "online"
        payload["payload_not_available"] = "offline"

    if len(av) == 1:
        payload["availability_topic"] = av[0]
    elif len(av) >= 2:
        payload["availability"] = [{"topic": t} for t in av]
        payload["availability_mode"] = getattr(entity, "availability_mode", None) or "all"

    # Expiry
    if getattr(entity, "expire_after_seconds", None) is not None:
        payload["expire_after"] = int(entity.expire_after_seconds)

    # ---- component specifics ----

    if comp == "switch":
        if not getattr(entity, "command_topic", None):
            raise ValueError("switch requires command_topic")
        payload["command_topic"] = entity.command_topic

        p_on = getattr(entity, "payload_on", None)
        p_off = getattr(entity, "payload_off", None)
        if p_on is not None:
            payload["state_on"] = p_on
        if p_off is not None:
            payload["state_off"] = p_off

    elif comp == "light":
        if not getattr(entity, "command_topic", None):
            raise ValueError("light requires command_topic")
        payload["command_topic"] = entity.command_topic

        if getattr(entity, "brightness_state_topic", None):
            payload["brightness_state_topic"] = entity.brightness_state_topic
        if getattr(entity, "brightness_command_topic", None):
            payload["brightness_command_topic"] = entity.brightness_command_topic
        if getattr(entity, "brightness_scale", None) is not None:
            payload["brightness_scale"] = int(entity.brightness_scale)

        if getattr(entity, "color_temp_state_topic", None):
            payload["color_temp_state_topic"] = entity.color_temp_state_topic
        if getattr(entity, "color_temp_command_topic", None):
            payload["color_temp_command_topic"] = entity.color_temp_command_topic
        if getattr(entity, "min_mireds", None) is not None:
            payload["min_mireds"] = int(entity.min_mireds)
        if getattr(entity, "max_mireds", None) is not None:
            payload["max_mireds"] = int(entity.max_mireds)

    elif comp == "cover":
        if getattr(entity, "command_topic", None):
            payload["command_topic"] = entity.command_topic
        if getattr(entity, "position_topic", None):
            payload["position_topic"] = entity.position_topic
        if getattr(entity, "set_position_topic", None):
            payload["set_position_topic"] = entity.set_position_topic

        payload["payload_open"] = getattr(entity, "payload_open", "OPEN")
        payload["payload_close"] = getattr(entity, "payload_close", "CLOSE")
        payload["payload_stop"] = getattr(entity, "payload_stop", "STOP")
        payload["position_open"] = int(getattr(entity, "position_open", 100))
        payload["position_closed"] = int(getattr(entity, "position_closed", 0))

    elif comp == "climate":
        if getattr(entity, "mode_state_topic", None):
            payload["mode_state_topic"] = entity.mode_state_topic
        if getattr(entity, "mode_command_topic", None):
            payload["mode_command_topic"] = entity.mode_command_topic
        if getattr(entity, "modes", None):
            payload["modes"] = list(entity.modes)

        if getattr(entity, "temperature_state_topic", None):
            payload["temperature_state_topic"] = entity.temperature_state_topic
        if getattr(entity, "temperature_command_topic", None):
            payload["temperature_command_topic"] = entity.temperature_command_topic

        if getattr(entity, "min_temp", None) is not None:
            payload["min_temp"] = float(entity.min_temp)
        if getattr(entity, "max_temp", None) is not None:
            payload["max_temp"] = float(entity.max_temp)
        if getattr(entity, "temp_step", None) is not None:
            payload["temp_step"] = float(entity.temp_step)

    elif comp == "number":
        if not getattr(entity, "command_topic", None) or not getattr(entity, "state_topic", None):
            raise ValueError("number requires command_topic and state_topic")
        payload["command_topic"] = entity.command_topic
        payload["state_topic"] = entity.state_topic
        payload["min"] = float(getattr(entity, "min_value", 0.0) or 0.0)
        payload["max"] = float(getattr(entity, "max_value", 100.0) or 100.0)
        payload["step"] = float(getattr(entity, "step", 1.0) or 1.0)
        if getattr(entity, "number_mode", None):
            payload["mode"] = str(entity.number_mode)

    elif comp == "select":
        if not getattr(entity, "command_topic", None) or not getattr(entity, "state_topic", None):
            raise ValueError("select requires command_topic and state_topic")
        payload["command_topic"] = entity.command_topic
        payload["state_topic"] = entity.state_topic
        payload["options"] = list(getattr(entity, "options", None) or [])

    elif comp == "button":
        if not getattr(entity, "command_topic", None):
            raise ValueError("button requires command_topic")
        payload["command_topic"] = entity.command_topic
        payload["payload_press"] = getattr(entity, "payload_press", "PRESS")

    # Advanced: merge any freeform discovery keys provided by mapper/overrides
    extra = getattr(entity, "extra", None)
    if isinstance(extra, dict) and extra:
        payload.update(extra)

    return DiscoveryMessage(topic=topic, payload=payload)
