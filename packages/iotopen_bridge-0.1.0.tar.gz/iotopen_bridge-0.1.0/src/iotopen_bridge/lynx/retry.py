# placeholder
# File: src/iotopen_bridge/lynx/retry.py