from .commands import register as register_commands
from .health import register as register_health
from .inventory import register as register_inventory

__all__ = ["register_commands", "register_health", "register_inventory"]
