# File: src/iotopen_bridge/observability/metrics.py
# SPDX-License-Identifier: MIT
from __future__ import annotations

import threading
from collections.abc import Mapping
from dataclasses import dataclass, field


def _escape_label_value(v: str) -> str:
    """
    Prometheus label value escaping (text exposition format):
    escape backslash, double-quote, and newlines.
    """
    return (
        v.replace("\\", "\\\\")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace('"', '\\"')
    )


@dataclass
class Metrics:
    """
    Minimal metrics surface:

      - iotopen_bridge_mqtt_rx_messages_total
      - iotopen_bridge_mqtt_messages_total{topic="..."}

    Tests call:
      - metrics.on_mqtt_message(topic=...)
      - metrics.render_prometheus()
    """

    # When disabled, hooks become no-ops and rendered output stays valid but static.
    enabled: bool = True

    _lock: threading.RLock = field(default_factory=threading.RLock, init=False)
    _mqtt_rx_total: int = field(default=0, init=False)
    _per_topic: dict[str, int] = field(default_factory=dict, init=False)

    def on_mqtt_message(self, *, topic: str) -> None:
        if not bool(self.enabled):
            return
        t = str(topic or "")
        with self._lock:
            self._mqtt_rx_total += 1
            self._per_topic[t] = int(self._per_topic.get(t, 0)) + 1

    # Backwards/alt hook name (runtime tries both)
    def mqtt_on_message(self, topic: str) -> None:
        self.on_mqtt_message(topic=str(topic))

    def snapshot(self) -> Mapping[str, object]:
        """Useful for debugging / unit tests."""
        with self._lock:
            return {
                "mqtt_rx_total": int(self._mqtt_rx_total),
                "per_topic": dict(self._per_topic),
            }

    def render_prometheus(self) -> str:
        """
        Render Prometheus text format.
        The unlabeled counter must always appear (even at 0).
        """
        snap = self.snapshot()
        rx = int(snap["mqtt_rx_total"])
        per = dict(snap["per_topic"])  # type: ignore[arg-type]

        lines: list[str] = []
        lines.append("# HELP iotopen_bridge_mqtt_rx_messages_total Total MQTT messages received by the bridge.")
        lines.append("# TYPE iotopen_bridge_mqtt_rx_messages_total counter")
        lines.append(f"iotopen_bridge_mqtt_rx_messages_total {rx}")

        lines.append("# HELP iotopen_bridge_mqtt_messages_total Total MQTT messages received by topic.")
        lines.append("# TYPE iotopen_bridge_mqtt_messages_total counter")
        for topic, count in sorted(per.items()):
            tv = _escape_label_value(str(topic))
            lines.append(f'iotopen_bridge_mqtt_messages_total{{topic="{tv}"}} {int(count)}')

        return "\n".join(lines) + "\n"
