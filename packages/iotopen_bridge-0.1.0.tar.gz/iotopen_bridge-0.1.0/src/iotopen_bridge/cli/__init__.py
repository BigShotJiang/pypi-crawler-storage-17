# SPDX-License-Identifier: MIT
# File: src/iotopen_bridge/cli/__init__.py
from __future__ import annotations

from .main import main

__all__ = ["main"]
