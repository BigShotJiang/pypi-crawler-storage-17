from importlib.metadata import entry_points


def load_entrypoint_group(group:str):
    eps=entry_points()
    group_eps = eps.select(group=group) if hasattr(eps,'select') else eps.get(group, [])
    out=[]
    for ep in group_eps:
        try:
            out.append(ep.load())
        except Exception:
            continue
    return out
