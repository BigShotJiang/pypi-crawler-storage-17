"""Tests for generation services."""
