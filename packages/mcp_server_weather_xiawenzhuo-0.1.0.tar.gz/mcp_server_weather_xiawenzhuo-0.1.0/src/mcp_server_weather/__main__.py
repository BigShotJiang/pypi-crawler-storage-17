from mcp_server_weather import main
main()