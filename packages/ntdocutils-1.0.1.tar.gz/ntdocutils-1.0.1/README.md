[![pypi](https://img.shields.io/pypi/v/ntDocutils.svg)](https://pypi.python.org/pypi/ntDocutils)

**ntDocutils** is a theme manager for [Docutils](http://docutils.sourceforge.net/).
It acts as a wrapper for the `rst2html5.py` frontend, and that enables the
customization possibility of the resulting file.

See <https://ntrrg.dev/en/projects/ntdocutils/>

