- Anular envío al SII
- Opción de envío de la sesión de forma resumida (desde pedido, hasta
  pedido)
- Sólo se ha contemplado el caso en que se enviarán al SII los pedidos
  en estado 'done' como F2, y al ser factura simplificada, se envía al
  SII sin especificar la contraparte. Si un cliente se quiere desgravar
  un pedido, se deberá generar la factura desde el pos, y esa será la
  que se envíe al SII.
- En cuanto a la fecha que se envía al SII, dado que no ha habido
  consenso, se envía la del pedido. Pero al estar modulado en un método,
  cada uno puede adaptarlo a sus necesidades.
