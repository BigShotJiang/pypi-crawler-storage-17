need to account for:

the general principle is that there is only on structure per dataset, but there can be multiple 'states' of that structure.
states are for example; 
- one structure, multiple 'states' per structure (ie one per chain)
- one structure, different ph/temperature conditions per state



structure

- one structural model
- state1:
    - chain a/b
        - peptides ph x temperature y, partially deuterated
        - peptides ph x temperature z, fully deuterated
        - peptides ph x temperature z, non deuterated
        - peptides ph x temperature z, partially deuterated
    - chain c/d
