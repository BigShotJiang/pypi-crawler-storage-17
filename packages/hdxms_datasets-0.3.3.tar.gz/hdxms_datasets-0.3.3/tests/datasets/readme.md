# Testing datasets


HDX_3BAE2080
SecA DynamX cluster data

HDX_C1198C76
SecA DynamX state data

HDX_D9096080
SecB DynamX state data

HDX_2E335A82
ecDHFR HXMS format data