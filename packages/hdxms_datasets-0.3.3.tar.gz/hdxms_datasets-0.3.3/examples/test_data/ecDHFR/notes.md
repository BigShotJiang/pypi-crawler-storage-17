The DOI in the example resolves to the PIGEON-FEATHER manuscript, yet the data comes from 
the HXMS file format manuscript. 

Correct source: 
https://www.biorxiv.org/content/10.1101/2025.10.14.682397v1.supplementary-material



ecDHFR tutorial.csv
Source: https://huggingface.co/spaces/glasgow-lab/PFLink
