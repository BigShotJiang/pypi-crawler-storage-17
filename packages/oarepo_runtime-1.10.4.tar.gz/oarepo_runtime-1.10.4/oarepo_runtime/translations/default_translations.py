from oarepo_runtime.i18n import lazy_gettext as _

_("Newest")
_("Oldest")
_("Best match")
_("Contact")
