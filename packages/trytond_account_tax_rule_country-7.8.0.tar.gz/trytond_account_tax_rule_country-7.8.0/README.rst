###############################
Account Tax Rule Country Module
###############################

The *Account Tax Rule Country Module* adds the country and subdivision of
origin and destination as criteria for the tax rule.

.. toctree::
   :maxdepth: 2

   design
   releases
