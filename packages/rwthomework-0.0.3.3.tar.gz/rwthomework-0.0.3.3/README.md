# rwthomework
A python package for streamlining physics homework at the RWTH Aachen
