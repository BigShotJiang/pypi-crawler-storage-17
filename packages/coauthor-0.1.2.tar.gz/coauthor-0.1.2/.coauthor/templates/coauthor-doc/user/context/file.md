# Context

File content: :{{task['frontmatter-item']['file'] }}
Content:

{{task['frontmatter-item']['file'] | include_file_content }}
