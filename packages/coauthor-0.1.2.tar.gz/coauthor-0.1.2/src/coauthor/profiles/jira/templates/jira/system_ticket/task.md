- Limit the text to max 150 words.
- Use the following template for the `description` of a `Task` ticket. For example:

  ```jira
  A detailed description of the task, including any relevant context, requirements, and constraints.

  h4. Acceptatie-criteria

  - criteria 1
  - criteria 2

  h4. Taken

  - Description of task
  - Description of task
  ```
