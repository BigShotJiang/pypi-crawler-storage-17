"""Data models for Immich migration."""
