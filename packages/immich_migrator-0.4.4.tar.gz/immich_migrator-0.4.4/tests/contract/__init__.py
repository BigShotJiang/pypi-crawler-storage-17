"""Test __init__ for contract tests."""
