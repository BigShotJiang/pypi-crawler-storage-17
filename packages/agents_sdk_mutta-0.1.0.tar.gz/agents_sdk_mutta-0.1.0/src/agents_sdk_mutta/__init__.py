"""
agents-sdk-mutta: CLI scaffolding tool for OpenAI Agents SDK projects.

Following the Mutta conventions for building agent services.
"""

__version__ = "0.1.0"

