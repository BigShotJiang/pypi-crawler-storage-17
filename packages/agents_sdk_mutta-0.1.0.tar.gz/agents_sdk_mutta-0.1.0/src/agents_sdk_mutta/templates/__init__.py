"""Templates for scaffolding agent projects."""

from . import service_templates
from . import agents_sdk_readme

__all__ = ["service_templates", "agents_sdk_readme"]
