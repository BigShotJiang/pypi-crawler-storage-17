"""
PassFX - A secure, stylish terminal password manager.

Your secrets are safe with us. Probably.
"""

__version__ = "1.0.1"
__author__ = "PassFX Team"
