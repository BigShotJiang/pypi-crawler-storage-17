"""EIP-712 helpers (deprecated - LockProof signing moved to verifier).

This file is kept for backward compatibility but is no longer used.
LockRequest EIP-712 signing is now handled server-side by the verifier.
"""

__all__: list[str] = []
