import asyncio
import os
import json
import sys  # 补充导入sys（原代码main函数用到但未提前导入）
from typing import Optional, List, Dict, Any
from contextlib import AsyncExitStack
from openai import OpenAI
from dotenv import load_dotenv
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
import pandas as pd
from pathlib import Path
import time
from datetime import datetime
import re

# 加载 .env 文件，确保 API Key 受到保护
load_dotenv()

class MCPClient:
    def __init__(self):
        """初始化 MCP 客户端"""
        self.openai_api_key = os.getenv("OPENAI_API_KEY") # 读取 OpenAI API Key
        self.base_url = os.getenv("BASE_URL") # 读取 BASE URL（修正原拼写错误）
        self.model = os.getenv("MODEL") # 读取 model
        if not self.openai_api_key:
            raise ValueError("❌ 未找到 OpenAI API Key，请在 .env 文件中设置OPENAI_API_KEY")
        
        self.client = OpenAI(api_key=self.openai_api_key, base_url=self.base_url)
        self.session: Optional[ClientSession] = None
        self.exit_stack = AsyncExitStack()

    async def connect_to_server(self, server_script_path: str):
        """连接到 MCP 服务器并列出可用工具"""
        is_python = server_script_path.endswith('.py')
        is_js = server_script_path.endswith('.js')
        if not (is_python or is_js):
            raise ValueError("服务器脚本必须是 .py 或 .js 文件")
        command = "python" if is_python else "node"
        server_params = StdioServerParameters(
        command=command,
        args=[server_script_path],
        env=None
        )
        # 启动 MCP 服务器并建立通信
        stdio_transport = await self.exit_stack.enter_async_context(stdio_client(server_params))
        self.stdio, self.write = stdio_transport
        self.session = await self.exit_stack.enter_async_context(ClientSession(self.stdio, self.write))
        await self.session.initialize()

        # 列出 MCP 服务器上的工具
        response = await self.session.list_tools()
        tools = response.tools
        print("\n已连接到服务器，支持以下工具:", [tool.name for tool in tools])

    async def process_query(self, query: str, prompt: Optional[str] = None) -> dict:

        prompt = """
            你是一个车载领域的智能助手，运行在车机上，为用户服务。你可以通过 MCP 提供的工具完成具体操作。
            
            	

                ### 1. 意图识别与工具调用
                1. 当用户的指令意图是控制车载功能或查询与车辆相关的信息时，应优先考虑调用相应工具完成操作。
                2. 当用户只是闲聊、咨询概念性问题或不需要实际操作时，不要调用工具，只用自然语言回复。
                3. 当用户出现多个工具调用意图时,你可以根据用户的意图调用多个工具,全部执行

                ### 2. 操作对象与槽位补全
                1. 如果用户的指令中**操作对象不明确**，且已有工具支持多个可能对象：
                * 必须先通过**简短的澄清问题**确认操作对象。
                * 得到用户确认后再调用对应工具。
                2. 对于工具声明为必填的关键参数，如果用户没有给出或表达不清，
                * 不要擅自猜测或随意填入默认值，
                * 必须先向用户进行**二次确认**（一句简短的问题）
                3. 如果工具明确给出了参数的合法取值范围或离散枚举值：
                * 如无法判断或存在明显风险，先用一句话向用户确认。
                4. 如果用户回答的是简单补充，直接据此完成工具调用，不要重复追问同一内容。

                ### 3. 对用户的回复风格
                1. 面向用户的回复要**简洁、口语化、自然**，优先控制在 **1 句** 内，确有必要时最多 **2 句**。
                2. 控制类指令的回复只需描述**结果**，不要向用户暴露 MCP 协议、字段名或内部参数结构。
                3. 除非用户主动询问细节，不要长篇解释你的决策过程、工具名称或参数映射逻辑。
                4. 如果因为缺少信息向用户追问，只用一小句直接问关键点，不要带额外解释。

                ### 4. 工具调用结果处理
                1. 工具调用成功（根据工具返回结果中的成功标志或无错误信息）时，
                * 只需给出**正向确认**，不要说“好像有点问题”“不太确定是否成功”。
                2. 只有在以下情况时才可以向用户澄清：
                * 与前置条件明显冲突。
                3. 当工具部分成功、部分失败时，要**清晰区分**
                """
        
        if prompt is None:
            prompt = """
            你是一个车载领域的智能助手, 你的任务是根据用户的指令进行回复,如果用户的指令意图是想调用工具,你可以使用已提供的工具，
            如果用户意图对于操作对象不明确,请询问操作对象后再调用工具, 比如"打开加热"或者"打开制热", 没有说明具体操作对象是"空调"还是"座椅",
            此时需要根据已有工具所操作的对象来询问用户,如果指定了所能取的值的范围请在范围内选一个最合适的值
            """

        messages = [
            {"role": "system", "content": prompt},
            {"role": "user", "content": query}
        ]
        start_time = time.time()

        # 获取工具列表
        response = await self.session.list_tools()
        available_tools = [{
            "type": "function",
            "function": {
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.inputSchema 
            }
        } for tool in response.tools]

        # 第一次调用
        response1 = self.client.chat.completions.create(
            model=self.model,
            # temperature=1,
            messages=messages,
            tools=available_tools,
            # extra_body={"thinking": {"type": "enabled"}}
        )
        content = response1.choices[0]
        

        # ========== 新增：提取第一次调用的Token使用量 ==========
        response1_usage = response1.usage
        token_info = {
            "prompt_tokens_1": response1_usage.prompt_tokens,
            "completion_tokens_1": response1_usage.completion_tokens,
            "total_tokens_1": response1_usage.total_tokens,
            "prompt_tokens_2": 0,
            "completion_tokens_2": 0,
            "total_tokens_2": 0,
            "total_tokens": response1_usage.total_tokens  # 初始总Token
        }

        response1_time = time.time()
        response1_use_time = response1_time - start_time

        tool_calls_info = [] # 改为列表，存储多个工具调用信息
        final_response = ""

        if content.finish_reason == "tool_calls":
            # 1. 首先将助手想调用工具的意图（包含 tool_calls 列表）加入历史消息
            messages.append(content.message.model_dump())
            
            # 2. 遍历所有工具调用请求
            for tool_call in content.message.tool_calls:
                tool_name = tool_call.function.name
                tool_args = json.loads(tool_call.function.arguments)
                tool_id = tool_call.id

                # 记录调用信息
                tool_calls_info.append({
                    "tool_name": tool_name,
                    "tool_args": tool_args
                })

                # 执行工具
                result = await self.session.call_tool(tool_name, tool_args)

                # 3. 将每个工具的执行结果分别加入历史消息
                messages.append({
                    "role": "tool",
                    "content": result.content[0].text,
                    "tool_call_id": tool_id,
                })

            # 4. 所有工具执行完毕后，第二次调用生成最终回复
            response2 = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
            )
            final_response = response2.choices[0].message.content or ""
            
            # ========== 提取第二次调用的Token使用量 ==========
            response2_usage = response2.usage
            token_info["prompt_tokens_2"] = response2_usage.prompt_tokens
            token_info["completion_tokens_2"] = response2_usage.completion_tokens
            token_info["total_tokens_2"] = response2_usage.total_tokens
            token_info["total_tokens"] = token_info["total_tokens_1"] + token_info["total_tokens_2"]

        else:
            final_response = content.message.content or ""

        final_response_time = time.time()
        final_use_time = final_response_time-start_time


        # ========== 返回token_info ==========
        return {
            # "final_response": user_reply,
            "slot_response": content,
            "final_response": final_response,
            "tool_call_info": tool_calls_info,
            "used_prompt": prompt.strip(),
            "token_info": token_info  # 新增Token信息字段
        }, response1_use_time, final_use_time
    

    async def batch_process(self, input_file: str):
        """
        批量处理查询并保存结果到 Excel
        新增：记录每条语料的Token使用量到Excel
        """
        queries = []
        df = pd.read_excel(input_file)
        for idx, row in df.iterrows():
            text = row["text"]
            queries.append(text)

        results = []

        for i, query in enumerate(queries, 1):
            
            print(f"\n[{i}/{len(queries)}] Processing: {query}")

            try:
                result, response1_use_time, final_use_time = await self.process_query(query)

                response_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                
                # thinking = result["slot_response"].message.reasoning_content
                
                
                # 处理多个工具的参数，用于展示
                all_tool_args = []
                for info in result["tool_call_info"]:
                    args = info.get("tool_args", {})
                    if "query" in args:
                        del args["query"]
                    all_tool_args.append(args)

                # ========== 新增：添加Token相关字段到结果 ==========
                results.append({
                    "text": query,
                    "目标协议": json.dumps(all_tool_args, ensure_ascii=False) if all_tool_args else "[]",
                    # "思考": thinking,
                    "模型回复语": result["final_response"],
                    "本条语料提槽耗时": round(response1_use_time, 2),
                    "本条语料语耗时": round(final_use_time, 2),
                    "所用Prompt": result["used_prompt"],
                    "模型回复时间": response_time,
                    # Token相关字段
                    "第一次调用Prompt Token数": result["token_info"]["prompt_tokens_1"],
                    "第一次调用Completion Token数": result["token_info"]["completion_tokens_1"],
                    "第一次调用总Token数": result["token_info"]["total_tokens_1"],
                    "第二次调用Prompt Token数": result["token_info"]["prompt_tokens_2"],
                    "第二次调用Completion Token数": result["token_info"]["completion_tokens_2"],
                    "第二次调用总Token数": result["token_info"]["total_tokens_2"],
                    "本条语料总Token数": result["token_info"]["total_tokens"]
                })

                print(f"本条语料耗时: {response1_use_time:.2f}s | 总Token数: {result['token_info']['total_tokens']}")

            except Exception as e:
                print(f"❌ Error on query '{query}': {e}")
                # 异常时Token字段置空
                results.append({
                    "text": query,
                    "目标协议": f"ERROR: {str(e)}",
                    "模型回复语": "",
                    "本条语料提槽耗时": "",
                    "本条语料回复语耗时": "",
                    "所用Prompt": "",
                    "模型回复时间": "",
                    "第一次调用Prompt Token数": "",
                    "第一次调用Completion Token数": "",
                    "第一次调用总Token数": "",
                    "第二次调用Prompt Token数": "",
                    "第二次调用Completion Token数": "",
                    "第二次调用总Token数": "",
                    "本条语料总Token数": ""
                })

        return results
    

    async def chat_loop(self):
        """运行交互式聊天循环
        新增：打印每条查询的Token使用量
        """
        print("\n🤖 MCP 客户端已启动！输入 'quit' 退出")
        while True:
            try:
                query = input("\nQuery: ").strip()
                if query.lower() == 'quit':
                    break
                start_time = time.time()
                
                response_data, response1_use_time, final_use_time = await self.process_query(query)
                
                # 提取多个工具的参数用于打印
                all_args = []
                for info in response_data["tool_call_info"]:
                    all_args.append(info.get("tool_args", {}))
                # thinking = response_data["slot_response"].message.reasoning_content
                # print(think)
                # exit()
                final_resp = response_data["final_response"]
                # ========== 新增：提取Token信息 ==========
                token_info = response_data["token_info"]
                
                end_time = time.time()
                used_time = end_time - start_time
                
                # 打印结果 + Token信息
                print(f"\n目标协议 (工具调用列表): {json.dumps(all_args, ensure_ascii=False, indent=2)}")
                # print(f"think:{thinking}")
                print(f"\n🤖 OpenAI: {final_resp}")
                print(f"\n⏱️  总耗时: {used_time:.3f}s")
                print(f"🔢 Token使用量:")
                print(f"  ├─ 第一次调用 - Prompt: {token_info['prompt_tokens_1']} | Completion: {token_info['completion_tokens_1']} | 总计: {token_info['total_tokens_1']}")
                if token_info['total_tokens_2'] > 0:
                    print(f"  ├─ 第二次调用 - Prompt: {token_info['prompt_tokens_2']} | Completion: {token_info['completion_tokens_2']} | 总计: {token_info['total_tokens_2']}")
                print(f"  └─ 本条语料总Token数: {token_info['total_tokens']}")

            except Exception as e:
                print(f"\n⚠️  发生错误: {str(e)}")

    async def cleanup(self):
        """清理资源"""
        await self.exit_stack.aclose()


# 新增：非法字符清理函数
def clean_illegal_chars(text: Any) -> str:
    if not isinstance(text, str):
        return str(text) if text is not None else ""
    illegal_chars = re.compile(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]')
    cleaned_text = illegal_chars.sub('', text)
    cleaned_text = cleaned_text.replace('\u2028', ' ').replace('\u2029', ' ')
    return cleaned_text.strip()

# 修改后的保存函数
def save_results_to_excel(results: list[dict], output_path: str) -> None:
    df = pd.DataFrame(results)
    # 清理所有列的非法字符
    for col in df.columns:
        df[col] = df[col].apply(clean_illegal_chars)
    try:
        df.to_excel(output_path, index=False, engine='openpyxl')
        print(f"✅ 结果已成功保存到: {output_path}")
    except Exception as e:
        print(f"❌ 保存 Excel 失败: {str(e)}")
        csv_path = output_path.replace('.xlsx', '.csv')
        df.to_csv(csv_path, index=False, encoding='utf-8-sig')
        print(f"📌 已备用保存到 CSV: {csv_path}")

async def main():
    before = time.time()
    if len(sys.argv) < 2:
        print("Usage:")
        print("   Interactive: python client.py <server_script>")
        print("   Batch:       python client.py <server_script> --batch <input.xlsx> <output.xlsx>")
        sys.exit(1)

    server_script = sys.argv[1]

    if len(sys.argv) >= 5 and sys.argv[2] == "--batch":
        input_file = sys.argv[3]
        output_excel = sys.argv[4]
        client = MCPClient()
        try:
            await client.connect_to_server(server_script)
            results = await client.batch_process(input_file)
            save_results_to_excel(results, output_excel)
            after = time.time()
            use_time = after - before
            print(f"\n📊 批量处理完成！总耗时: {use_time:.2f} 秒")
            
            # 统计总Token数（可选）
            total_tokens = sum(
                r["本条语料总Token数"] for r in results 
                if isinstance(r["本条语料总Token数"], int)
            )
            print(f"📈 所有语料总Token消耗: {total_tokens}")
        finally:
            await client.cleanup()
    else:
        # 原有交互模式
        client = MCPClient()
        try:
            await client.connect_to_server(server_script)
            await client.chat_loop()
        finally:
            await client.cleanup()
    
if __name__ == "__main__":
    asyncio.run(main())