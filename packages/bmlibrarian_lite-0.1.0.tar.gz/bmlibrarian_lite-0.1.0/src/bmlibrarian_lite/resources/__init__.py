"""
Resources module for BMLibrarian Lite.

Contains styling and other resources for the application.
"""
