# ruff: noqa
from tpu_inference.platforms.tpu_platform import TpuPlatform
