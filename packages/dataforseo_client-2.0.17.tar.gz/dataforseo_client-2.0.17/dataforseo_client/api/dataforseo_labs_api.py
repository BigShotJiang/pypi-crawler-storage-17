import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from typing import List, Optional

if TYPE_CHECKING:
    from dataforseo_client.models.dataforseo_labs_id_list_request_info import DataforseoLabsIdListRequestInfo
    from dataforseo_client.models.dataforseo_labs_id_list_response_info import DataforseoLabsIdListResponseInfo
    from dataforseo_client.models.dataforseo_labs_status_response_info import DataforseoLabsStatusResponseInfo
    from dataforseo_client.models.dataforseo_labs_errors_request_info import DataforseoLabsErrorsRequestInfo
    from dataforseo_client.models.dataforseo_labs_errors_response_info import DataforseoLabsErrorsResponseInfo
    from dataforseo_client.models.dataforseo_labs_available_filters_response_info import DataforseoLabsAvailableFiltersResponseInfo
    from dataforseo_client.models.dataforseo_labs_locations_and_languages_response_info import DataforseoLabsLocationsAndLanguagesResponseInfo
    from dataforseo_client.models.dataforseo_labs_categories_response_info import DataforseoLabsCategoriesResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_available_history_response_info import DataforseoLabsGoogleAvailableHistoryResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_keywords_for_site_live_request_info import DataforseoLabsGoogleKeywordsForSiteLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_keywords_for_site_live_response_info import DataforseoLabsGoogleKeywordsForSiteLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_related_keywords_live_request_info import DataforseoLabsGoogleRelatedKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_related_keywords_live_response_info import DataforseoLabsGoogleRelatedKeywordsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_keyword_suggestions_live_request_info import DataforseoLabsGoogleKeywordSuggestionsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_keyword_suggestions_live_response_info import DataforseoLabsGoogleKeywordSuggestionsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_keyword_ideas_live_request_info import DataforseoLabsGoogleKeywordIdeasLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_keyword_ideas_live_response_info import DataforseoLabsGoogleKeywordIdeasLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_bulk_keyword_difficulty_live_request_info import DataforseoLabsGoogleBulkKeywordDifficultyLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_bulk_keyword_difficulty_live_response_info import DataforseoLabsGoogleBulkKeywordDifficultyLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_search_intent_live_request_info import DataforseoLabsGoogleSearchIntentLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_search_intent_live_response_info import DataforseoLabsGoogleSearchIntentLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_categories_for_keywords_languages_response_info import DataforseoLabsGoogleCategoriesForKeywordsLanguagesResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_categories_for_domain_live_request_info import DataforseoLabsGoogleCategoriesForDomainLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_categories_for_domain_live_response_info import DataforseoLabsGoogleCategoriesForDomainLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_categories_for_keywords_live_request_info import DataforseoLabsGoogleCategoriesForKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_categories_for_keywords_live_response_info import DataforseoLabsGoogleCategoriesForKeywordsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_keywords_for_categories_live_request_info import DataforseoLabsGoogleKeywordsForCategoriesLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_keywords_for_categories_live_response_info import DataforseoLabsGoogleKeywordsForCategoriesLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_domain_metrics_by_categories_live_request_info import DataforseoLabsGoogleDomainMetricsByCategoriesLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_domain_metrics_by_categories_live_response_info import DataforseoLabsGoogleDomainMetricsByCategoriesLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_top_searches_live_request_info import DataforseoLabsGoogleTopSearchesLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_top_searches_live_response_info import DataforseoLabsGoogleTopSearchesLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_domain_whois_overview_live_request_info import DataforseoLabsGoogleDomainWhoisOverviewLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_domain_whois_overview_live_response_info import DataforseoLabsGoogleDomainWhoisOverviewLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_ranked_keywords_live_request_info import DataforseoLabsGoogleRankedKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_ranked_keywords_live_response_info import DataforseoLabsGoogleRankedKeywordsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_serp_competitors_live_request_info import DataforseoLabsGoogleSerpCompetitorsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_serp_competitors_live_response_info import DataforseoLabsGoogleSerpCompetitorsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_competitors_domain_live_request_info import DataforseoLabsGoogleCompetitorsDomainLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_competitors_domain_live_response_info import DataforseoLabsGoogleCompetitorsDomainLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_domain_intersection_live_request_info import DataforseoLabsGoogleDomainIntersectionLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_domain_intersection_live_response_info import DataforseoLabsGoogleDomainIntersectionLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_subdomains_live_request_info import DataforseoLabsGoogleSubdomainsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_subdomains_live_response_info import DataforseoLabsGoogleSubdomainsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_relevant_pages_live_request_info import DataforseoLabsGoogleRelevantPagesLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_relevant_pages_live_response_info import DataforseoLabsGoogleRelevantPagesLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_domain_rank_overview_live_request_info import DataforseoLabsGoogleDomainRankOverviewLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_domain_rank_overview_live_response_info import DataforseoLabsGoogleDomainRankOverviewLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_historical_serps_live_request_info import DataforseoLabsGoogleHistoricalSerpsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_historical_serps_live_response_info import DataforseoLabsGoogleHistoricalSerpsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_historical_rank_overview_live_request_info import DataforseoLabsGoogleHistoricalRankOverviewLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_historical_rank_overview_live_response_info import DataforseoLabsGoogleHistoricalRankOverviewLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_page_intersection_live_request_info import DataforseoLabsGooglePageIntersectionLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_page_intersection_live_response_info import DataforseoLabsGooglePageIntersectionLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_bulk_traffic_estimation_live_request_info import DataforseoLabsGoogleBulkTrafficEstimationLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_bulk_traffic_estimation_live_response_info import DataforseoLabsGoogleBulkTrafficEstimationLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info import DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_historical_bulk_traffic_estimation_live_response_info import DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_historical_keyword_data_live_request_info import DataforseoLabsGoogleHistoricalKeywordDataLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_historical_keyword_data_live_response_info import DataforseoLabsGoogleHistoricalKeywordDataLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_keyword_overview_live_request_info import DataforseoLabsGoogleKeywordOverviewLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_keyword_overview_live_response_info import DataforseoLabsGoogleKeywordOverviewLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_amazon_bulk_search_volume_live_request_info import DataforseoLabsAmazonBulkSearchVolumeLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_amazon_bulk_search_volume_live_response_info import DataforseoLabsAmazonBulkSearchVolumeLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_amazon_related_keywords_live_request_info import DataforseoLabsAmazonRelatedKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_amazon_related_keywords_live_response_info import DataforseoLabsAmazonRelatedKeywordsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_amazon_ranked_keywords_live_request_info import DataforseoLabsAmazonRankedKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_amazon_ranked_keywords_live_response_info import DataforseoLabsAmazonRankedKeywordsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_amazon_product_rank_overview_live_request_info import DataforseoLabsAmazonProductRankOverviewLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_amazon_product_rank_overview_live_response_info import DataforseoLabsAmazonProductRankOverviewLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_amazon_product_competitors_live_request_info import DataforseoLabsAmazonProductCompetitorsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_amazon_product_competitors_live_response_info import DataforseoLabsAmazonProductCompetitorsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_amazon_product_keyword_intersections_live_request_info import DataforseoLabsAmazonProductKeywordIntersectionsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_amazon_product_keyword_intersections_live_response_info import DataforseoLabsAmazonProductKeywordIntersectionsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info import DataforseoLabsBingBulkKeywordDifficultyLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_bulk_keyword_difficulty_live_response_info import DataforseoLabsBingBulkKeywordDifficultyLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_bing_bulk_traffic_estimation_live_request_info import DataforseoLabsBingBulkTrafficEstimationLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_bulk_traffic_estimation_live_response_info import DataforseoLabsBingBulkTrafficEstimationLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_bing_competitors_domain_live_request_info import DataforseoLabsBingCompetitorsDomainLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_competitors_domain_live_response_info import DataforseoLabsBingCompetitorsDomainLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_bing_domain_intersection_live_request_info import DataforseoLabsBingDomainIntersectionLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_domain_intersection_live_response_info import DataforseoLabsBingDomainIntersectionLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_bing_domain_rank_overview_live_request_info import DataforseoLabsBingDomainRankOverviewLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_domain_rank_overview_live_response_info import DataforseoLabsBingDomainRankOverviewLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_bing_page_intersection_live_request_info import DataforseoLabsBingPageIntersectionLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_page_intersection_live_response_info import DataforseoLabsBingPageIntersectionLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_bing_ranked_keywords_live_request_info import DataforseoLabsBingRankedKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_ranked_keywords_live_response_info import DataforseoLabsBingRankedKeywordsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_bing_related_keywords_live_request_info import DataforseoLabsBingRelatedKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_related_keywords_live_response_info import DataforseoLabsBingRelatedKeywordsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_bing_relevant_pages_live_request_info import DataforseoLabsBingRelevantPagesLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_relevant_pages_live_response_info import DataforseoLabsBingRelevantPagesLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_bing_serp_competitors_live_request_info import DataforseoLabsBingSerpCompetitorsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_serp_competitors_live_response_info import DataforseoLabsBingSerpCompetitorsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_bing_subdomains_live_request_info import DataforseoLabsBingSubdomainsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_subdomains_live_response_info import DataforseoLabsBingSubdomainsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_bulk_app_metrics_live_request_info import DataforseoLabsGoogleBulkAppMetricsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_bulk_app_metrics_live_response_info import DataforseoLabsGoogleBulkAppMetricsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_keywords_for_app_live_request_info import DataforseoLabsGoogleKeywordsForAppLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_keywords_for_app_live_response_info import DataforseoLabsGoogleKeywordsForAppLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_app_competitors_live_request_info import DataforseoLabsGoogleAppCompetitorsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_app_competitors_live_response_info import DataforseoLabsGoogleAppCompetitorsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_google_app_intersection_live_request_info import DataforseoLabsGoogleAppIntersectionLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_app_intersection_live_response_info import DataforseoLabsGoogleAppIntersectionLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_apple_bulk_app_metrics_live_request_info import DataforseoLabsAppleBulkAppMetricsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_apple_bulk_app_metrics_live_response_info import DataforseoLabsAppleBulkAppMetricsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_apple_keywords_for_app_live_request_info import DataforseoLabsAppleKeywordsForAppLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_apple_keywords_for_app_live_response_info import DataforseoLabsAppleKeywordsForAppLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_apple_app_competitors_live_request_info import DataforseoLabsAppleAppCompetitorsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_apple_app_competitors_live_response_info import DataforseoLabsAppleAppCompetitorsLiveResponseInfo
    from dataforseo_client.models.dataforseo_labs_apple_app_intersection_live_request_info import DataforseoLabsAppleAppIntersectionLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_apple_app_intersection_live_response_info import DataforseoLabsAppleAppIntersectionLiveResponseInfo

from dataforseo_client.api_client import ApiClient, RequestSerialized
from dataforseo_client.api_response import ApiResponse
from dataforseo_client.rest import RESTResponseType

class DataforseoLabsApi:

    def __init__(self, api_client=None) -> None:
        if api_client is None:
            api_client = ApiClient.get_default()
        self.api_client = api_client

    

    from dataforseo_client.models.dataforseo_labs_id_list_request_info import DataforseoLabsIdListRequestInfo
    from dataforseo_client.models.dataforseo_labs_id_list_response_info import DataforseoLabsIdListResponseInfo
    @validate_call
    def dataforseo_labs_id_list(
        self,
        list_optional_dataforseo_labs_id_list_request_info: 'List[Optional[DataforseoLabsIdListRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsIdListResponseInfo:

        _param = self._dataforseo_labs_id_list_serialize(
            list_optional_dataforseo_labs_id_list_request_info=list_optional_dataforseo_labs_id_list_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsIdListResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def dataforseo_labs_id_list_with_http_info(
        self,
        list_optional_dataforseo_labs_id_list_request_info: 'List[Optional[DataforseoLabsIdListRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsIdListResponseInfo]':

        _param = self._dataforseo_labs_id_list_serialize(
            list_optional_dataforseo_labs_id_list_request_info=list_optional_dataforseo_labs_id_list_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsIdListResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def dataforseo_labs_id_list_without_preload_content(
        self,
        list_optional_dataforseo_labs_id_list_request_info: 'List[Optional[DataforseoLabsIdListRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._dataforseo_labs_id_list_serialize(
            list_optional_dataforseo_labs_id_list_request_info=list_optional_dataforseo_labs_id_list_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsIdListResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _dataforseo_labs_id_list_serialize(
        self,
        list_optional_dataforseo_labs_id_list_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsIdListRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_id_list_request_info is not None:
            _body_params = list_optional_dataforseo_labs_id_list_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/id_list',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_status_response_info import DataforseoLabsStatusResponseInfo
    @validate_call
    def status(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsStatusResponseInfo:

        _param = self._status_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsStatusResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data

    @validate_call
    def status_with_http_info(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsStatusResponseInfo]':

        _param = self._status_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsStatusResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )

    @validate_call
    def status_without_preload_content(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._status_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsStatusResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _status_serialize(
        self,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None


        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='GET',
            resource_path='/v3/dataforseo_labs/status',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_errors_request_info import DataforseoLabsErrorsRequestInfo
    from dataforseo_client.models.dataforseo_labs_errors_response_info import DataforseoLabsErrorsResponseInfo
    @validate_call
    def dataforseo_labs_errors(
        self,
        list_optional_dataforseo_labs_errors_request_info: 'List[Optional[DataforseoLabsErrorsRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsErrorsResponseInfo:

        _param = self._dataforseo_labs_errors_serialize(
            list_optional_dataforseo_labs_errors_request_info=list_optional_dataforseo_labs_errors_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsErrorsResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def dataforseo_labs_errors_with_http_info(
        self,
        list_optional_dataforseo_labs_errors_request_info: 'List[Optional[DataforseoLabsErrorsRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsErrorsResponseInfo]':

        _param = self._dataforseo_labs_errors_serialize(
            list_optional_dataforseo_labs_errors_request_info=list_optional_dataforseo_labs_errors_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsErrorsResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def dataforseo_labs_errors_without_preload_content(
        self,
        list_optional_dataforseo_labs_errors_request_info: 'List[Optional[DataforseoLabsErrorsRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._dataforseo_labs_errors_serialize(
            list_optional_dataforseo_labs_errors_request_info=list_optional_dataforseo_labs_errors_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsErrorsResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _dataforseo_labs_errors_serialize(
        self,
        list_optional_dataforseo_labs_errors_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsErrorsRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_errors_request_info is not None:
            _body_params = list_optional_dataforseo_labs_errors_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/errors',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_available_filters_response_info import DataforseoLabsAvailableFiltersResponseInfo
    @validate_call
    def available_filters(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsAvailableFiltersResponseInfo:

        _param = self._available_filters_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAvailableFiltersResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data

    @validate_call
    def available_filters_with_http_info(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsAvailableFiltersResponseInfo]':

        _param = self._available_filters_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAvailableFiltersResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )

    @validate_call
    def available_filters_without_preload_content(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._available_filters_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAvailableFiltersResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _available_filters_serialize(
        self,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None


        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='GET',
            resource_path='/v3/dataforseo_labs/available_filters',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_locations_and_languages_response_info import DataforseoLabsLocationsAndLanguagesResponseInfo
    @validate_call
    def locations_and_languages(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsLocationsAndLanguagesResponseInfo:

        _param = self._locations_and_languages_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsLocationsAndLanguagesResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data

    @validate_call
    def locations_and_languages_with_http_info(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsLocationsAndLanguagesResponseInfo]':

        _param = self._locations_and_languages_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsLocationsAndLanguagesResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )

    @validate_call
    def locations_and_languages_without_preload_content(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._locations_and_languages_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsLocationsAndLanguagesResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _locations_and_languages_serialize(
        self,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None


        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='GET',
            resource_path='/v3/dataforseo_labs/locations_and_languages',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_categories_response_info import DataforseoLabsCategoriesResponseInfo
    @validate_call
    def categories(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsCategoriesResponseInfo:

        _param = self._categories_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsCategoriesResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data

    @validate_call
    def categories_with_http_info(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsCategoriesResponseInfo]':

        _param = self._categories_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsCategoriesResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )

    @validate_call
    def categories_without_preload_content(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._categories_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsCategoriesResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _categories_serialize(
        self,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None


        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='GET',
            resource_path='/v3/dataforseo_labs/categories',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_available_history_response_info import DataforseoLabsGoogleAvailableHistoryResponseInfo
    @validate_call
    def google_available_history(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleAvailableHistoryResponseInfo:

        _param = self._google_available_history_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleAvailableHistoryResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data

    @validate_call
    def google_available_history_with_http_info(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleAvailableHistoryResponseInfo]':

        _param = self._google_available_history_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleAvailableHistoryResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )

    @validate_call
    def google_available_history_without_preload_content(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_available_history_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleAvailableHistoryResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_available_history_serialize(
        self,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None


        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='GET',
            resource_path='/v3/dataforseo_labs/google/available_history',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_keywords_for_site_live_request_info import DataforseoLabsGoogleKeywordsForSiteLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_keywords_for_site_live_response_info import DataforseoLabsGoogleKeywordsForSiteLiveResponseInfo
    @validate_call
    def google_keywords_for_site_live(
        self,
        list_optional_dataforseo_labs_google_keywords_for_site_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordsForSiteLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleKeywordsForSiteLiveResponseInfo:

        _param = self._google_keywords_for_site_live_serialize(
            list_optional_dataforseo_labs_google_keywords_for_site_live_request_info=list_optional_dataforseo_labs_google_keywords_for_site_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordsForSiteLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_keywords_for_site_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_keywords_for_site_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordsForSiteLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleKeywordsForSiteLiveResponseInfo]':

        _param = self._google_keywords_for_site_live_serialize(
            list_optional_dataforseo_labs_google_keywords_for_site_live_request_info=list_optional_dataforseo_labs_google_keywords_for_site_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordsForSiteLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_keywords_for_site_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_keywords_for_site_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordsForSiteLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_keywords_for_site_live_serialize(
            list_optional_dataforseo_labs_google_keywords_for_site_live_request_info=list_optional_dataforseo_labs_google_keywords_for_site_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordsForSiteLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_keywords_for_site_live_serialize(
        self,
        list_optional_dataforseo_labs_google_keywords_for_site_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleKeywordsForSiteLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_keywords_for_site_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_keywords_for_site_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/keywords_for_site/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_related_keywords_live_request_info import DataforseoLabsGoogleRelatedKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_related_keywords_live_response_info import DataforseoLabsGoogleRelatedKeywordsLiveResponseInfo
    @validate_call
    def google_related_keywords_live(
        self,
        list_optional_dataforseo_labs_google_related_keywords_live_request_info: 'List[Optional[DataforseoLabsGoogleRelatedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleRelatedKeywordsLiveResponseInfo:

        _param = self._google_related_keywords_live_serialize(
            list_optional_dataforseo_labs_google_related_keywords_live_request_info=list_optional_dataforseo_labs_google_related_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleRelatedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_related_keywords_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_related_keywords_live_request_info: 'List[Optional[DataforseoLabsGoogleRelatedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleRelatedKeywordsLiveResponseInfo]':

        _param = self._google_related_keywords_live_serialize(
            list_optional_dataforseo_labs_google_related_keywords_live_request_info=list_optional_dataforseo_labs_google_related_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleRelatedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_related_keywords_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_related_keywords_live_request_info: 'List[Optional[DataforseoLabsGoogleRelatedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_related_keywords_live_serialize(
            list_optional_dataforseo_labs_google_related_keywords_live_request_info=list_optional_dataforseo_labs_google_related_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleRelatedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_related_keywords_live_serialize(
        self,
        list_optional_dataforseo_labs_google_related_keywords_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleRelatedKeywordsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_related_keywords_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_related_keywords_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/related_keywords/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_keyword_suggestions_live_request_info import DataforseoLabsGoogleKeywordSuggestionsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_keyword_suggestions_live_response_info import DataforseoLabsGoogleKeywordSuggestionsLiveResponseInfo
    @validate_call
    def google_keyword_suggestions_live(
        self,
        list_optional_dataforseo_labs_google_keyword_suggestions_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordSuggestionsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleKeywordSuggestionsLiveResponseInfo:

        _param = self._google_keyword_suggestions_live_serialize(
            list_optional_dataforseo_labs_google_keyword_suggestions_live_request_info=list_optional_dataforseo_labs_google_keyword_suggestions_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordSuggestionsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_keyword_suggestions_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_keyword_suggestions_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordSuggestionsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleKeywordSuggestionsLiveResponseInfo]':

        _param = self._google_keyword_suggestions_live_serialize(
            list_optional_dataforseo_labs_google_keyword_suggestions_live_request_info=list_optional_dataforseo_labs_google_keyword_suggestions_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordSuggestionsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_keyword_suggestions_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_keyword_suggestions_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordSuggestionsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_keyword_suggestions_live_serialize(
            list_optional_dataforseo_labs_google_keyword_suggestions_live_request_info=list_optional_dataforseo_labs_google_keyword_suggestions_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordSuggestionsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_keyword_suggestions_live_serialize(
        self,
        list_optional_dataforseo_labs_google_keyword_suggestions_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleKeywordSuggestionsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_keyword_suggestions_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_keyword_suggestions_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/keyword_suggestions/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_keyword_ideas_live_request_info import DataforseoLabsGoogleKeywordIdeasLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_keyword_ideas_live_response_info import DataforseoLabsGoogleKeywordIdeasLiveResponseInfo
    @validate_call
    def google_keyword_ideas_live(
        self,
        list_optional_dataforseo_labs_google_keyword_ideas_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordIdeasLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleKeywordIdeasLiveResponseInfo:

        _param = self._google_keyword_ideas_live_serialize(
            list_optional_dataforseo_labs_google_keyword_ideas_live_request_info=list_optional_dataforseo_labs_google_keyword_ideas_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordIdeasLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_keyword_ideas_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_keyword_ideas_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordIdeasLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleKeywordIdeasLiveResponseInfo]':

        _param = self._google_keyword_ideas_live_serialize(
            list_optional_dataforseo_labs_google_keyword_ideas_live_request_info=list_optional_dataforseo_labs_google_keyword_ideas_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordIdeasLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_keyword_ideas_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_keyword_ideas_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordIdeasLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_keyword_ideas_live_serialize(
            list_optional_dataforseo_labs_google_keyword_ideas_live_request_info=list_optional_dataforseo_labs_google_keyword_ideas_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordIdeasLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_keyword_ideas_live_serialize(
        self,
        list_optional_dataforseo_labs_google_keyword_ideas_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleKeywordIdeasLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_keyword_ideas_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_keyword_ideas_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/keyword_ideas/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_bulk_keyword_difficulty_live_request_info import DataforseoLabsGoogleBulkKeywordDifficultyLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_bulk_keyword_difficulty_live_response_info import DataforseoLabsGoogleBulkKeywordDifficultyLiveResponseInfo
    @validate_call
    def google_bulk_keyword_difficulty_live(
        self,
        list_optional_dataforseo_labs_google_bulk_keyword_difficulty_live_request_info: 'List[Optional[DataforseoLabsGoogleBulkKeywordDifficultyLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleBulkKeywordDifficultyLiveResponseInfo:

        _param = self._google_bulk_keyword_difficulty_live_serialize(
            list_optional_dataforseo_labs_google_bulk_keyword_difficulty_live_request_info=list_optional_dataforseo_labs_google_bulk_keyword_difficulty_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleBulkKeywordDifficultyLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_bulk_keyword_difficulty_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_bulk_keyword_difficulty_live_request_info: 'List[Optional[DataforseoLabsGoogleBulkKeywordDifficultyLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleBulkKeywordDifficultyLiveResponseInfo]':

        _param = self._google_bulk_keyword_difficulty_live_serialize(
            list_optional_dataforseo_labs_google_bulk_keyword_difficulty_live_request_info=list_optional_dataforseo_labs_google_bulk_keyword_difficulty_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleBulkKeywordDifficultyLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_bulk_keyword_difficulty_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_bulk_keyword_difficulty_live_request_info: 'List[Optional[DataforseoLabsGoogleBulkKeywordDifficultyLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_bulk_keyword_difficulty_live_serialize(
            list_optional_dataforseo_labs_google_bulk_keyword_difficulty_live_request_info=list_optional_dataforseo_labs_google_bulk_keyword_difficulty_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleBulkKeywordDifficultyLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_bulk_keyword_difficulty_live_serialize(
        self,
        list_optional_dataforseo_labs_google_bulk_keyword_difficulty_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleBulkKeywordDifficultyLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_bulk_keyword_difficulty_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_bulk_keyword_difficulty_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/bulk_keyword_difficulty/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_search_intent_live_request_info import DataforseoLabsGoogleSearchIntentLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_search_intent_live_response_info import DataforseoLabsGoogleSearchIntentLiveResponseInfo
    @validate_call
    def google_search_intent_live(
        self,
        list_optional_dataforseo_labs_google_search_intent_live_request_info: 'List[Optional[DataforseoLabsGoogleSearchIntentLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleSearchIntentLiveResponseInfo:

        _param = self._google_search_intent_live_serialize(
            list_optional_dataforseo_labs_google_search_intent_live_request_info=list_optional_dataforseo_labs_google_search_intent_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleSearchIntentLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_search_intent_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_search_intent_live_request_info: 'List[Optional[DataforseoLabsGoogleSearchIntentLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleSearchIntentLiveResponseInfo]':

        _param = self._google_search_intent_live_serialize(
            list_optional_dataforseo_labs_google_search_intent_live_request_info=list_optional_dataforseo_labs_google_search_intent_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleSearchIntentLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_search_intent_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_search_intent_live_request_info: 'List[Optional[DataforseoLabsGoogleSearchIntentLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_search_intent_live_serialize(
            list_optional_dataforseo_labs_google_search_intent_live_request_info=list_optional_dataforseo_labs_google_search_intent_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleSearchIntentLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_search_intent_live_serialize(
        self,
        list_optional_dataforseo_labs_google_search_intent_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleSearchIntentLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_search_intent_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_search_intent_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/search_intent/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_categories_for_keywords_languages_response_info import DataforseoLabsGoogleCategoriesForKeywordsLanguagesResponseInfo
    @validate_call
    def google_categories_for_keywords_languages(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleCategoriesForKeywordsLanguagesResponseInfo:

        _param = self._google_categories_for_keywords_languages_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleCategoriesForKeywordsLanguagesResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data

    @validate_call
    def google_categories_for_keywords_languages_with_http_info(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleCategoriesForKeywordsLanguagesResponseInfo]':

        _param = self._google_categories_for_keywords_languages_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleCategoriesForKeywordsLanguagesResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )

    @validate_call
    def google_categories_for_keywords_languages_without_preload_content(
        self,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_categories_for_keywords_languages_serialize(
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleCategoriesForKeywordsLanguagesResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_categories_for_keywords_languages_serialize(
        self,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None


        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='GET',
            resource_path='/v3/dataforseo_labs/google/categories_for_keywords/languages',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_categories_for_domain_live_request_info import DataforseoLabsGoogleCategoriesForDomainLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_categories_for_domain_live_response_info import DataforseoLabsGoogleCategoriesForDomainLiveResponseInfo
    @validate_call
    def google_categories_for_domain_live(
        self,
        list_optional_dataforseo_labs_google_categories_for_domain_live_request_info: 'List[Optional[DataforseoLabsGoogleCategoriesForDomainLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleCategoriesForDomainLiveResponseInfo:

        _param = self._google_categories_for_domain_live_serialize(
            list_optional_dataforseo_labs_google_categories_for_domain_live_request_info=list_optional_dataforseo_labs_google_categories_for_domain_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleCategoriesForDomainLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_categories_for_domain_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_categories_for_domain_live_request_info: 'List[Optional[DataforseoLabsGoogleCategoriesForDomainLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleCategoriesForDomainLiveResponseInfo]':

        _param = self._google_categories_for_domain_live_serialize(
            list_optional_dataforseo_labs_google_categories_for_domain_live_request_info=list_optional_dataforseo_labs_google_categories_for_domain_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleCategoriesForDomainLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_categories_for_domain_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_categories_for_domain_live_request_info: 'List[Optional[DataforseoLabsGoogleCategoriesForDomainLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_categories_for_domain_live_serialize(
            list_optional_dataforseo_labs_google_categories_for_domain_live_request_info=list_optional_dataforseo_labs_google_categories_for_domain_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleCategoriesForDomainLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_categories_for_domain_live_serialize(
        self,
        list_optional_dataforseo_labs_google_categories_for_domain_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleCategoriesForDomainLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_categories_for_domain_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_categories_for_domain_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/categories_for_domain/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_categories_for_keywords_live_request_info import DataforseoLabsGoogleCategoriesForKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_categories_for_keywords_live_response_info import DataforseoLabsGoogleCategoriesForKeywordsLiveResponseInfo
    @validate_call
    def google_categories_for_keywords_live(
        self,
        list_optional_dataforseo_labs_google_categories_for_keywords_live_request_info: 'List[Optional[DataforseoLabsGoogleCategoriesForKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleCategoriesForKeywordsLiveResponseInfo:

        _param = self._google_categories_for_keywords_live_serialize(
            list_optional_dataforseo_labs_google_categories_for_keywords_live_request_info=list_optional_dataforseo_labs_google_categories_for_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleCategoriesForKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_categories_for_keywords_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_categories_for_keywords_live_request_info: 'List[Optional[DataforseoLabsGoogleCategoriesForKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleCategoriesForKeywordsLiveResponseInfo]':

        _param = self._google_categories_for_keywords_live_serialize(
            list_optional_dataforseo_labs_google_categories_for_keywords_live_request_info=list_optional_dataforseo_labs_google_categories_for_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleCategoriesForKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_categories_for_keywords_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_categories_for_keywords_live_request_info: 'List[Optional[DataforseoLabsGoogleCategoriesForKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_categories_for_keywords_live_serialize(
            list_optional_dataforseo_labs_google_categories_for_keywords_live_request_info=list_optional_dataforseo_labs_google_categories_for_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleCategoriesForKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_categories_for_keywords_live_serialize(
        self,
        list_optional_dataforseo_labs_google_categories_for_keywords_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleCategoriesForKeywordsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_categories_for_keywords_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_categories_for_keywords_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/categories_for_keywords/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_keywords_for_categories_live_request_info import DataforseoLabsGoogleKeywordsForCategoriesLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_keywords_for_categories_live_response_info import DataforseoLabsGoogleKeywordsForCategoriesLiveResponseInfo
    @validate_call
    def google_keywords_for_categories_live(
        self,
        list_optional_dataforseo_labs_google_keywords_for_categories_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordsForCategoriesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleKeywordsForCategoriesLiveResponseInfo:

        _param = self._google_keywords_for_categories_live_serialize(
            list_optional_dataforseo_labs_google_keywords_for_categories_live_request_info=list_optional_dataforseo_labs_google_keywords_for_categories_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordsForCategoriesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_keywords_for_categories_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_keywords_for_categories_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordsForCategoriesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleKeywordsForCategoriesLiveResponseInfo]':

        _param = self._google_keywords_for_categories_live_serialize(
            list_optional_dataforseo_labs_google_keywords_for_categories_live_request_info=list_optional_dataforseo_labs_google_keywords_for_categories_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordsForCategoriesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_keywords_for_categories_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_keywords_for_categories_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordsForCategoriesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_keywords_for_categories_live_serialize(
            list_optional_dataforseo_labs_google_keywords_for_categories_live_request_info=list_optional_dataforseo_labs_google_keywords_for_categories_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordsForCategoriesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_keywords_for_categories_live_serialize(
        self,
        list_optional_dataforseo_labs_google_keywords_for_categories_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleKeywordsForCategoriesLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_keywords_for_categories_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_keywords_for_categories_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/keywords_for_categories/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_domain_metrics_by_categories_live_request_info import DataforseoLabsGoogleDomainMetricsByCategoriesLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_domain_metrics_by_categories_live_response_info import DataforseoLabsGoogleDomainMetricsByCategoriesLiveResponseInfo
    @validate_call
    def google_domain_metrics_by_categories_live(
        self,
        list_optional_dataforseo_labs_google_domain_metrics_by_categories_live_request_info: 'List[Optional[DataforseoLabsGoogleDomainMetricsByCategoriesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleDomainMetricsByCategoriesLiveResponseInfo:

        _param = self._google_domain_metrics_by_categories_live_serialize(
            list_optional_dataforseo_labs_google_domain_metrics_by_categories_live_request_info=list_optional_dataforseo_labs_google_domain_metrics_by_categories_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleDomainMetricsByCategoriesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_domain_metrics_by_categories_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_domain_metrics_by_categories_live_request_info: 'List[Optional[DataforseoLabsGoogleDomainMetricsByCategoriesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleDomainMetricsByCategoriesLiveResponseInfo]':

        _param = self._google_domain_metrics_by_categories_live_serialize(
            list_optional_dataforseo_labs_google_domain_metrics_by_categories_live_request_info=list_optional_dataforseo_labs_google_domain_metrics_by_categories_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleDomainMetricsByCategoriesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_domain_metrics_by_categories_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_domain_metrics_by_categories_live_request_info: 'List[Optional[DataforseoLabsGoogleDomainMetricsByCategoriesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_domain_metrics_by_categories_live_serialize(
            list_optional_dataforseo_labs_google_domain_metrics_by_categories_live_request_info=list_optional_dataforseo_labs_google_domain_metrics_by_categories_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleDomainMetricsByCategoriesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_domain_metrics_by_categories_live_serialize(
        self,
        list_optional_dataforseo_labs_google_domain_metrics_by_categories_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleDomainMetricsByCategoriesLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_domain_metrics_by_categories_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_domain_metrics_by_categories_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/domain_metrics_by_categories/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_top_searches_live_request_info import DataforseoLabsGoogleTopSearchesLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_top_searches_live_response_info import DataforseoLabsGoogleTopSearchesLiveResponseInfo
    @validate_call
    def google_top_searches_live(
        self,
        list_optional_dataforseo_labs_google_top_searches_live_request_info: 'List[Optional[DataforseoLabsGoogleTopSearchesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleTopSearchesLiveResponseInfo:

        _param = self._google_top_searches_live_serialize(
            list_optional_dataforseo_labs_google_top_searches_live_request_info=list_optional_dataforseo_labs_google_top_searches_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleTopSearchesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_top_searches_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_top_searches_live_request_info: 'List[Optional[DataforseoLabsGoogleTopSearchesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleTopSearchesLiveResponseInfo]':

        _param = self._google_top_searches_live_serialize(
            list_optional_dataforseo_labs_google_top_searches_live_request_info=list_optional_dataforseo_labs_google_top_searches_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleTopSearchesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_top_searches_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_top_searches_live_request_info: 'List[Optional[DataforseoLabsGoogleTopSearchesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_top_searches_live_serialize(
            list_optional_dataforseo_labs_google_top_searches_live_request_info=list_optional_dataforseo_labs_google_top_searches_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleTopSearchesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_top_searches_live_serialize(
        self,
        list_optional_dataforseo_labs_google_top_searches_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleTopSearchesLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_top_searches_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_top_searches_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/top_searches/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_domain_whois_overview_live_request_info import DataforseoLabsGoogleDomainWhoisOverviewLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_domain_whois_overview_live_response_info import DataforseoLabsGoogleDomainWhoisOverviewLiveResponseInfo
    @validate_call
    def google_domain_whois_overview_live(
        self,
        list_optional_dataforseo_labs_google_domain_whois_overview_live_request_info: 'List[Optional[DataforseoLabsGoogleDomainWhoisOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleDomainWhoisOverviewLiveResponseInfo:

        _param = self._google_domain_whois_overview_live_serialize(
            list_optional_dataforseo_labs_google_domain_whois_overview_live_request_info=list_optional_dataforseo_labs_google_domain_whois_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleDomainWhoisOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_domain_whois_overview_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_domain_whois_overview_live_request_info: 'List[Optional[DataforseoLabsGoogleDomainWhoisOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleDomainWhoisOverviewLiveResponseInfo]':

        _param = self._google_domain_whois_overview_live_serialize(
            list_optional_dataforseo_labs_google_domain_whois_overview_live_request_info=list_optional_dataforseo_labs_google_domain_whois_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleDomainWhoisOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_domain_whois_overview_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_domain_whois_overview_live_request_info: 'List[Optional[DataforseoLabsGoogleDomainWhoisOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_domain_whois_overview_live_serialize(
            list_optional_dataforseo_labs_google_domain_whois_overview_live_request_info=list_optional_dataforseo_labs_google_domain_whois_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleDomainWhoisOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_domain_whois_overview_live_serialize(
        self,
        list_optional_dataforseo_labs_google_domain_whois_overview_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleDomainWhoisOverviewLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_domain_whois_overview_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_domain_whois_overview_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/domain_whois_overview/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_ranked_keywords_live_request_info import DataforseoLabsGoogleRankedKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_ranked_keywords_live_response_info import DataforseoLabsGoogleRankedKeywordsLiveResponseInfo
    @validate_call
    def google_ranked_keywords_live(
        self,
        list_optional_dataforseo_labs_google_ranked_keywords_live_request_info: 'List[Optional[DataforseoLabsGoogleRankedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleRankedKeywordsLiveResponseInfo:

        _param = self._google_ranked_keywords_live_serialize(
            list_optional_dataforseo_labs_google_ranked_keywords_live_request_info=list_optional_dataforseo_labs_google_ranked_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleRankedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_ranked_keywords_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_ranked_keywords_live_request_info: 'List[Optional[DataforseoLabsGoogleRankedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleRankedKeywordsLiveResponseInfo]':

        _param = self._google_ranked_keywords_live_serialize(
            list_optional_dataforseo_labs_google_ranked_keywords_live_request_info=list_optional_dataforseo_labs_google_ranked_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleRankedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_ranked_keywords_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_ranked_keywords_live_request_info: 'List[Optional[DataforseoLabsGoogleRankedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_ranked_keywords_live_serialize(
            list_optional_dataforseo_labs_google_ranked_keywords_live_request_info=list_optional_dataforseo_labs_google_ranked_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleRankedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_ranked_keywords_live_serialize(
        self,
        list_optional_dataforseo_labs_google_ranked_keywords_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleRankedKeywordsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_ranked_keywords_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_ranked_keywords_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/ranked_keywords/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_serp_competitors_live_request_info import DataforseoLabsGoogleSerpCompetitorsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_serp_competitors_live_response_info import DataforseoLabsGoogleSerpCompetitorsLiveResponseInfo
    @validate_call
    def google_serp_competitors_live(
        self,
        list_optional_dataforseo_labs_google_serp_competitors_live_request_info: 'List[Optional[DataforseoLabsGoogleSerpCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleSerpCompetitorsLiveResponseInfo:

        _param = self._google_serp_competitors_live_serialize(
            list_optional_dataforseo_labs_google_serp_competitors_live_request_info=list_optional_dataforseo_labs_google_serp_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleSerpCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_serp_competitors_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_serp_competitors_live_request_info: 'List[Optional[DataforseoLabsGoogleSerpCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleSerpCompetitorsLiveResponseInfo]':

        _param = self._google_serp_competitors_live_serialize(
            list_optional_dataforseo_labs_google_serp_competitors_live_request_info=list_optional_dataforseo_labs_google_serp_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleSerpCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_serp_competitors_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_serp_competitors_live_request_info: 'List[Optional[DataforseoLabsGoogleSerpCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_serp_competitors_live_serialize(
            list_optional_dataforseo_labs_google_serp_competitors_live_request_info=list_optional_dataforseo_labs_google_serp_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleSerpCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_serp_competitors_live_serialize(
        self,
        list_optional_dataforseo_labs_google_serp_competitors_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleSerpCompetitorsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_serp_competitors_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_serp_competitors_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/serp_competitors/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_competitors_domain_live_request_info import DataforseoLabsGoogleCompetitorsDomainLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_competitors_domain_live_response_info import DataforseoLabsGoogleCompetitorsDomainLiveResponseInfo
    @validate_call
    def google_competitors_domain_live(
        self,
        list_optional_dataforseo_labs_google_competitors_domain_live_request_info: 'List[Optional[DataforseoLabsGoogleCompetitorsDomainLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleCompetitorsDomainLiveResponseInfo:

        _param = self._google_competitors_domain_live_serialize(
            list_optional_dataforseo_labs_google_competitors_domain_live_request_info=list_optional_dataforseo_labs_google_competitors_domain_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleCompetitorsDomainLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_competitors_domain_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_competitors_domain_live_request_info: 'List[Optional[DataforseoLabsGoogleCompetitorsDomainLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleCompetitorsDomainLiveResponseInfo]':

        _param = self._google_competitors_domain_live_serialize(
            list_optional_dataforseo_labs_google_competitors_domain_live_request_info=list_optional_dataforseo_labs_google_competitors_domain_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleCompetitorsDomainLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_competitors_domain_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_competitors_domain_live_request_info: 'List[Optional[DataforseoLabsGoogleCompetitorsDomainLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_competitors_domain_live_serialize(
            list_optional_dataforseo_labs_google_competitors_domain_live_request_info=list_optional_dataforseo_labs_google_competitors_domain_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleCompetitorsDomainLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_competitors_domain_live_serialize(
        self,
        list_optional_dataforseo_labs_google_competitors_domain_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleCompetitorsDomainLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_competitors_domain_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_competitors_domain_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/competitors_domain/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_domain_intersection_live_request_info import DataforseoLabsGoogleDomainIntersectionLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_domain_intersection_live_response_info import DataforseoLabsGoogleDomainIntersectionLiveResponseInfo
    @validate_call
    def google_domain_intersection_live(
        self,
        list_optional_dataforseo_labs_google_domain_intersection_live_request_info: 'List[Optional[DataforseoLabsGoogleDomainIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleDomainIntersectionLiveResponseInfo:

        _param = self._google_domain_intersection_live_serialize(
            list_optional_dataforseo_labs_google_domain_intersection_live_request_info=list_optional_dataforseo_labs_google_domain_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleDomainIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_domain_intersection_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_domain_intersection_live_request_info: 'List[Optional[DataforseoLabsGoogleDomainIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleDomainIntersectionLiveResponseInfo]':

        _param = self._google_domain_intersection_live_serialize(
            list_optional_dataforseo_labs_google_domain_intersection_live_request_info=list_optional_dataforseo_labs_google_domain_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleDomainIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_domain_intersection_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_domain_intersection_live_request_info: 'List[Optional[DataforseoLabsGoogleDomainIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_domain_intersection_live_serialize(
            list_optional_dataforseo_labs_google_domain_intersection_live_request_info=list_optional_dataforseo_labs_google_domain_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleDomainIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_domain_intersection_live_serialize(
        self,
        list_optional_dataforseo_labs_google_domain_intersection_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleDomainIntersectionLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_domain_intersection_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_domain_intersection_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/domain_intersection/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_subdomains_live_request_info import DataforseoLabsGoogleSubdomainsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_subdomains_live_response_info import DataforseoLabsGoogleSubdomainsLiveResponseInfo
    @validate_call
    def google_subdomains_live(
        self,
        list_optional_dataforseo_labs_google_subdomains_live_request_info: 'List[Optional[DataforseoLabsGoogleSubdomainsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleSubdomainsLiveResponseInfo:

        _param = self._google_subdomains_live_serialize(
            list_optional_dataforseo_labs_google_subdomains_live_request_info=list_optional_dataforseo_labs_google_subdomains_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleSubdomainsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_subdomains_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_subdomains_live_request_info: 'List[Optional[DataforseoLabsGoogleSubdomainsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleSubdomainsLiveResponseInfo]':

        _param = self._google_subdomains_live_serialize(
            list_optional_dataforseo_labs_google_subdomains_live_request_info=list_optional_dataforseo_labs_google_subdomains_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleSubdomainsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_subdomains_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_subdomains_live_request_info: 'List[Optional[DataforseoLabsGoogleSubdomainsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_subdomains_live_serialize(
            list_optional_dataforseo_labs_google_subdomains_live_request_info=list_optional_dataforseo_labs_google_subdomains_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleSubdomainsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_subdomains_live_serialize(
        self,
        list_optional_dataforseo_labs_google_subdomains_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleSubdomainsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_subdomains_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_subdomains_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/subdomains/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_relevant_pages_live_request_info import DataforseoLabsGoogleRelevantPagesLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_relevant_pages_live_response_info import DataforseoLabsGoogleRelevantPagesLiveResponseInfo
    @validate_call
    def google_relevant_pages_live(
        self,
        list_optional_dataforseo_labs_google_relevant_pages_live_request_info: 'List[Optional[DataforseoLabsGoogleRelevantPagesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleRelevantPagesLiveResponseInfo:

        _param = self._google_relevant_pages_live_serialize(
            list_optional_dataforseo_labs_google_relevant_pages_live_request_info=list_optional_dataforseo_labs_google_relevant_pages_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleRelevantPagesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_relevant_pages_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_relevant_pages_live_request_info: 'List[Optional[DataforseoLabsGoogleRelevantPagesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleRelevantPagesLiveResponseInfo]':

        _param = self._google_relevant_pages_live_serialize(
            list_optional_dataforseo_labs_google_relevant_pages_live_request_info=list_optional_dataforseo_labs_google_relevant_pages_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleRelevantPagesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_relevant_pages_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_relevant_pages_live_request_info: 'List[Optional[DataforseoLabsGoogleRelevantPagesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_relevant_pages_live_serialize(
            list_optional_dataforseo_labs_google_relevant_pages_live_request_info=list_optional_dataforseo_labs_google_relevant_pages_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleRelevantPagesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_relevant_pages_live_serialize(
        self,
        list_optional_dataforseo_labs_google_relevant_pages_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleRelevantPagesLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_relevant_pages_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_relevant_pages_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/relevant_pages/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_domain_rank_overview_live_request_info import DataforseoLabsGoogleDomainRankOverviewLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_domain_rank_overview_live_response_info import DataforseoLabsGoogleDomainRankOverviewLiveResponseInfo
    @validate_call
    def google_domain_rank_overview_live(
        self,
        list_optional_dataforseo_labs_google_domain_rank_overview_live_request_info: 'List[Optional[DataforseoLabsGoogleDomainRankOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleDomainRankOverviewLiveResponseInfo:

        _param = self._google_domain_rank_overview_live_serialize(
            list_optional_dataforseo_labs_google_domain_rank_overview_live_request_info=list_optional_dataforseo_labs_google_domain_rank_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleDomainRankOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_domain_rank_overview_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_domain_rank_overview_live_request_info: 'List[Optional[DataforseoLabsGoogleDomainRankOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleDomainRankOverviewLiveResponseInfo]':

        _param = self._google_domain_rank_overview_live_serialize(
            list_optional_dataforseo_labs_google_domain_rank_overview_live_request_info=list_optional_dataforseo_labs_google_domain_rank_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleDomainRankOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_domain_rank_overview_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_domain_rank_overview_live_request_info: 'List[Optional[DataforseoLabsGoogleDomainRankOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_domain_rank_overview_live_serialize(
            list_optional_dataforseo_labs_google_domain_rank_overview_live_request_info=list_optional_dataforseo_labs_google_domain_rank_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleDomainRankOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_domain_rank_overview_live_serialize(
        self,
        list_optional_dataforseo_labs_google_domain_rank_overview_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleDomainRankOverviewLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_domain_rank_overview_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_domain_rank_overview_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/domain_rank_overview/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_historical_serps_live_request_info import DataforseoLabsGoogleHistoricalSerpsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_historical_serps_live_response_info import DataforseoLabsGoogleHistoricalSerpsLiveResponseInfo
    @validate_call
    def google_historical_serps_live(
        self,
        list_optional_dataforseo_labs_google_historical_serps_live_request_info: 'List[Optional[DataforseoLabsGoogleHistoricalSerpsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleHistoricalSerpsLiveResponseInfo:

        _param = self._google_historical_serps_live_serialize(
            list_optional_dataforseo_labs_google_historical_serps_live_request_info=list_optional_dataforseo_labs_google_historical_serps_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleHistoricalSerpsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_historical_serps_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_historical_serps_live_request_info: 'List[Optional[DataforseoLabsGoogleHistoricalSerpsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleHistoricalSerpsLiveResponseInfo]':

        _param = self._google_historical_serps_live_serialize(
            list_optional_dataforseo_labs_google_historical_serps_live_request_info=list_optional_dataforseo_labs_google_historical_serps_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleHistoricalSerpsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_historical_serps_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_historical_serps_live_request_info: 'List[Optional[DataforseoLabsGoogleHistoricalSerpsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_historical_serps_live_serialize(
            list_optional_dataforseo_labs_google_historical_serps_live_request_info=list_optional_dataforseo_labs_google_historical_serps_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleHistoricalSerpsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_historical_serps_live_serialize(
        self,
        list_optional_dataforseo_labs_google_historical_serps_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleHistoricalSerpsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_historical_serps_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_historical_serps_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/historical_serps/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_historical_rank_overview_live_request_info import DataforseoLabsGoogleHistoricalRankOverviewLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_historical_rank_overview_live_response_info import DataforseoLabsGoogleHistoricalRankOverviewLiveResponseInfo
    @validate_call
    def google_historical_rank_overview_live(
        self,
        list_optional_dataforseo_labs_google_historical_rank_overview_live_request_info: 'List[Optional[DataforseoLabsGoogleHistoricalRankOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleHistoricalRankOverviewLiveResponseInfo:

        _param = self._google_historical_rank_overview_live_serialize(
            list_optional_dataforseo_labs_google_historical_rank_overview_live_request_info=list_optional_dataforseo_labs_google_historical_rank_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleHistoricalRankOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_historical_rank_overview_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_historical_rank_overview_live_request_info: 'List[Optional[DataforseoLabsGoogleHistoricalRankOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleHistoricalRankOverviewLiveResponseInfo]':

        _param = self._google_historical_rank_overview_live_serialize(
            list_optional_dataforseo_labs_google_historical_rank_overview_live_request_info=list_optional_dataforseo_labs_google_historical_rank_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleHistoricalRankOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_historical_rank_overview_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_historical_rank_overview_live_request_info: 'List[Optional[DataforseoLabsGoogleHistoricalRankOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_historical_rank_overview_live_serialize(
            list_optional_dataforseo_labs_google_historical_rank_overview_live_request_info=list_optional_dataforseo_labs_google_historical_rank_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleHistoricalRankOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_historical_rank_overview_live_serialize(
        self,
        list_optional_dataforseo_labs_google_historical_rank_overview_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleHistoricalRankOverviewLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_historical_rank_overview_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_historical_rank_overview_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/historical_rank_overview/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_page_intersection_live_request_info import DataforseoLabsGooglePageIntersectionLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_page_intersection_live_response_info import DataforseoLabsGooglePageIntersectionLiveResponseInfo
    @validate_call
    def google_page_intersection_live(
        self,
        list_optional_dataforseo_labs_google_page_intersection_live_request_info: 'List[Optional[DataforseoLabsGooglePageIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGooglePageIntersectionLiveResponseInfo:

        _param = self._google_page_intersection_live_serialize(
            list_optional_dataforseo_labs_google_page_intersection_live_request_info=list_optional_dataforseo_labs_google_page_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGooglePageIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_page_intersection_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_page_intersection_live_request_info: 'List[Optional[DataforseoLabsGooglePageIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGooglePageIntersectionLiveResponseInfo]':

        _param = self._google_page_intersection_live_serialize(
            list_optional_dataforseo_labs_google_page_intersection_live_request_info=list_optional_dataforseo_labs_google_page_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGooglePageIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_page_intersection_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_page_intersection_live_request_info: 'List[Optional[DataforseoLabsGooglePageIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_page_intersection_live_serialize(
            list_optional_dataforseo_labs_google_page_intersection_live_request_info=list_optional_dataforseo_labs_google_page_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGooglePageIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_page_intersection_live_serialize(
        self,
        list_optional_dataforseo_labs_google_page_intersection_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGooglePageIntersectionLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_page_intersection_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_page_intersection_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/page_intersection/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_bulk_traffic_estimation_live_request_info import DataforseoLabsGoogleBulkTrafficEstimationLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_bulk_traffic_estimation_live_response_info import DataforseoLabsGoogleBulkTrafficEstimationLiveResponseInfo
    @validate_call
    def google_bulk_traffic_estimation_live(
        self,
        list_optional_dataforseo_labs_google_bulk_traffic_estimation_live_request_info: 'List[Optional[DataforseoLabsGoogleBulkTrafficEstimationLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleBulkTrafficEstimationLiveResponseInfo:

        _param = self._google_bulk_traffic_estimation_live_serialize(
            list_optional_dataforseo_labs_google_bulk_traffic_estimation_live_request_info=list_optional_dataforseo_labs_google_bulk_traffic_estimation_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleBulkTrafficEstimationLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_bulk_traffic_estimation_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_bulk_traffic_estimation_live_request_info: 'List[Optional[DataforseoLabsGoogleBulkTrafficEstimationLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleBulkTrafficEstimationLiveResponseInfo]':

        _param = self._google_bulk_traffic_estimation_live_serialize(
            list_optional_dataforseo_labs_google_bulk_traffic_estimation_live_request_info=list_optional_dataforseo_labs_google_bulk_traffic_estimation_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleBulkTrafficEstimationLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_bulk_traffic_estimation_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_bulk_traffic_estimation_live_request_info: 'List[Optional[DataforseoLabsGoogleBulkTrafficEstimationLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_bulk_traffic_estimation_live_serialize(
            list_optional_dataforseo_labs_google_bulk_traffic_estimation_live_request_info=list_optional_dataforseo_labs_google_bulk_traffic_estimation_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleBulkTrafficEstimationLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_bulk_traffic_estimation_live_serialize(
        self,
        list_optional_dataforseo_labs_google_bulk_traffic_estimation_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleBulkTrafficEstimationLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_bulk_traffic_estimation_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_bulk_traffic_estimation_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/bulk_traffic_estimation/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info import DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_historical_bulk_traffic_estimation_live_response_info import DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveResponseInfo
    @validate_call
    def google_historical_bulk_traffic_estimation_live(
        self,
        list_optional_dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info: 'List[Optional[DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveResponseInfo:

        _param = self._google_historical_bulk_traffic_estimation_live_serialize(
            list_optional_dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info=list_optional_dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_historical_bulk_traffic_estimation_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info: 'List[Optional[DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveResponseInfo]':

        _param = self._google_historical_bulk_traffic_estimation_live_serialize(
            list_optional_dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info=list_optional_dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_historical_bulk_traffic_estimation_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info: 'List[Optional[DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_historical_bulk_traffic_estimation_live_serialize(
            list_optional_dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info=list_optional_dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_historical_bulk_traffic_estimation_live_serialize(
        self,
        list_optional_dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleHistoricalBulkTrafficEstimationLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_historical_bulk_traffic_estimation_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/historical_bulk_traffic_estimation/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_historical_keyword_data_live_request_info import DataforseoLabsGoogleHistoricalKeywordDataLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_historical_keyword_data_live_response_info import DataforseoLabsGoogleHistoricalKeywordDataLiveResponseInfo
    @validate_call
    def google_historical_keyword_data_live(
        self,
        list_optional_dataforseo_labs_google_historical_keyword_data_live_request_info: 'List[Optional[DataforseoLabsGoogleHistoricalKeywordDataLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleHistoricalKeywordDataLiveResponseInfo:

        _param = self._google_historical_keyword_data_live_serialize(
            list_optional_dataforseo_labs_google_historical_keyword_data_live_request_info=list_optional_dataforseo_labs_google_historical_keyword_data_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleHistoricalKeywordDataLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_historical_keyword_data_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_historical_keyword_data_live_request_info: 'List[Optional[DataforseoLabsGoogleHistoricalKeywordDataLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleHistoricalKeywordDataLiveResponseInfo]':

        _param = self._google_historical_keyword_data_live_serialize(
            list_optional_dataforseo_labs_google_historical_keyword_data_live_request_info=list_optional_dataforseo_labs_google_historical_keyword_data_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleHistoricalKeywordDataLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_historical_keyword_data_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_historical_keyword_data_live_request_info: 'List[Optional[DataforseoLabsGoogleHistoricalKeywordDataLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_historical_keyword_data_live_serialize(
            list_optional_dataforseo_labs_google_historical_keyword_data_live_request_info=list_optional_dataforseo_labs_google_historical_keyword_data_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleHistoricalKeywordDataLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_historical_keyword_data_live_serialize(
        self,
        list_optional_dataforseo_labs_google_historical_keyword_data_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleHistoricalKeywordDataLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_historical_keyword_data_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_historical_keyword_data_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/historical_keyword_data/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_keyword_overview_live_request_info import DataforseoLabsGoogleKeywordOverviewLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_keyword_overview_live_response_info import DataforseoLabsGoogleKeywordOverviewLiveResponseInfo
    @validate_call
    def google_keyword_overview_live(
        self,
        list_optional_dataforseo_labs_google_keyword_overview_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleKeywordOverviewLiveResponseInfo:

        _param = self._google_keyword_overview_live_serialize(
            list_optional_dataforseo_labs_google_keyword_overview_live_request_info=list_optional_dataforseo_labs_google_keyword_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_keyword_overview_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_keyword_overview_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleKeywordOverviewLiveResponseInfo]':

        _param = self._google_keyword_overview_live_serialize(
            list_optional_dataforseo_labs_google_keyword_overview_live_request_info=list_optional_dataforseo_labs_google_keyword_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_keyword_overview_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_keyword_overview_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_keyword_overview_live_serialize(
            list_optional_dataforseo_labs_google_keyword_overview_live_request_info=list_optional_dataforseo_labs_google_keyword_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_keyword_overview_live_serialize(
        self,
        list_optional_dataforseo_labs_google_keyword_overview_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleKeywordOverviewLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_keyword_overview_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_keyword_overview_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/keyword_overview/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_amazon_bulk_search_volume_live_request_info import DataforseoLabsAmazonBulkSearchVolumeLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_amazon_bulk_search_volume_live_response_info import DataforseoLabsAmazonBulkSearchVolumeLiveResponseInfo
    @validate_call
    def amazon_bulk_search_volume_live(
        self,
        list_optional_dataforseo_labs_amazon_bulk_search_volume_live_request_info: 'List[Optional[DataforseoLabsAmazonBulkSearchVolumeLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsAmazonBulkSearchVolumeLiveResponseInfo:

        _param = self._amazon_bulk_search_volume_live_serialize(
            list_optional_dataforseo_labs_amazon_bulk_search_volume_live_request_info=list_optional_dataforseo_labs_amazon_bulk_search_volume_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonBulkSearchVolumeLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def amazon_bulk_search_volume_live_with_http_info(
        self,
        list_optional_dataforseo_labs_amazon_bulk_search_volume_live_request_info: 'List[Optional[DataforseoLabsAmazonBulkSearchVolumeLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsAmazonBulkSearchVolumeLiveResponseInfo]':

        _param = self._amazon_bulk_search_volume_live_serialize(
            list_optional_dataforseo_labs_amazon_bulk_search_volume_live_request_info=list_optional_dataforseo_labs_amazon_bulk_search_volume_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonBulkSearchVolumeLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def amazon_bulk_search_volume_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_amazon_bulk_search_volume_live_request_info: 'List[Optional[DataforseoLabsAmazonBulkSearchVolumeLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._amazon_bulk_search_volume_live_serialize(
            list_optional_dataforseo_labs_amazon_bulk_search_volume_live_request_info=list_optional_dataforseo_labs_amazon_bulk_search_volume_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonBulkSearchVolumeLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _amazon_bulk_search_volume_live_serialize(
        self,
        list_optional_dataforseo_labs_amazon_bulk_search_volume_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsAmazonBulkSearchVolumeLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_amazon_bulk_search_volume_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_amazon_bulk_search_volume_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/amazon/bulk_search_volume/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_amazon_related_keywords_live_request_info import DataforseoLabsAmazonRelatedKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_amazon_related_keywords_live_response_info import DataforseoLabsAmazonRelatedKeywordsLiveResponseInfo
    @validate_call
    def amazon_related_keywords_live(
        self,
        list_optional_dataforseo_labs_amazon_related_keywords_live_request_info: 'List[Optional[DataforseoLabsAmazonRelatedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsAmazonRelatedKeywordsLiveResponseInfo:

        _param = self._amazon_related_keywords_live_serialize(
            list_optional_dataforseo_labs_amazon_related_keywords_live_request_info=list_optional_dataforseo_labs_amazon_related_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonRelatedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def amazon_related_keywords_live_with_http_info(
        self,
        list_optional_dataforseo_labs_amazon_related_keywords_live_request_info: 'List[Optional[DataforseoLabsAmazonRelatedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsAmazonRelatedKeywordsLiveResponseInfo]':

        _param = self._amazon_related_keywords_live_serialize(
            list_optional_dataforseo_labs_amazon_related_keywords_live_request_info=list_optional_dataforseo_labs_amazon_related_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonRelatedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def amazon_related_keywords_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_amazon_related_keywords_live_request_info: 'List[Optional[DataforseoLabsAmazonRelatedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._amazon_related_keywords_live_serialize(
            list_optional_dataforseo_labs_amazon_related_keywords_live_request_info=list_optional_dataforseo_labs_amazon_related_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonRelatedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _amazon_related_keywords_live_serialize(
        self,
        list_optional_dataforseo_labs_amazon_related_keywords_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsAmazonRelatedKeywordsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_amazon_related_keywords_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_amazon_related_keywords_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/amazon/related_keywords/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_amazon_ranked_keywords_live_request_info import DataforseoLabsAmazonRankedKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_amazon_ranked_keywords_live_response_info import DataforseoLabsAmazonRankedKeywordsLiveResponseInfo
    @validate_call
    def amazon_ranked_keywords_live(
        self,
        list_optional_dataforseo_labs_amazon_ranked_keywords_live_request_info: 'List[Optional[DataforseoLabsAmazonRankedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsAmazonRankedKeywordsLiveResponseInfo:

        _param = self._amazon_ranked_keywords_live_serialize(
            list_optional_dataforseo_labs_amazon_ranked_keywords_live_request_info=list_optional_dataforseo_labs_amazon_ranked_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonRankedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def amazon_ranked_keywords_live_with_http_info(
        self,
        list_optional_dataforseo_labs_amazon_ranked_keywords_live_request_info: 'List[Optional[DataforseoLabsAmazonRankedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsAmazonRankedKeywordsLiveResponseInfo]':

        _param = self._amazon_ranked_keywords_live_serialize(
            list_optional_dataforseo_labs_amazon_ranked_keywords_live_request_info=list_optional_dataforseo_labs_amazon_ranked_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonRankedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def amazon_ranked_keywords_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_amazon_ranked_keywords_live_request_info: 'List[Optional[DataforseoLabsAmazonRankedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._amazon_ranked_keywords_live_serialize(
            list_optional_dataforseo_labs_amazon_ranked_keywords_live_request_info=list_optional_dataforseo_labs_amazon_ranked_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonRankedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _amazon_ranked_keywords_live_serialize(
        self,
        list_optional_dataforseo_labs_amazon_ranked_keywords_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsAmazonRankedKeywordsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_amazon_ranked_keywords_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_amazon_ranked_keywords_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/amazon/ranked_keywords/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_amazon_product_rank_overview_live_request_info import DataforseoLabsAmazonProductRankOverviewLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_amazon_product_rank_overview_live_response_info import DataforseoLabsAmazonProductRankOverviewLiveResponseInfo
    @validate_call
    def amazon_product_rank_overview_live(
        self,
        list_optional_dataforseo_labs_amazon_product_rank_overview_live_request_info: 'List[Optional[DataforseoLabsAmazonProductRankOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsAmazonProductRankOverviewLiveResponseInfo:

        _param = self._amazon_product_rank_overview_live_serialize(
            list_optional_dataforseo_labs_amazon_product_rank_overview_live_request_info=list_optional_dataforseo_labs_amazon_product_rank_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonProductRankOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def amazon_product_rank_overview_live_with_http_info(
        self,
        list_optional_dataforseo_labs_amazon_product_rank_overview_live_request_info: 'List[Optional[DataforseoLabsAmazonProductRankOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsAmazonProductRankOverviewLiveResponseInfo]':

        _param = self._amazon_product_rank_overview_live_serialize(
            list_optional_dataforseo_labs_amazon_product_rank_overview_live_request_info=list_optional_dataforseo_labs_amazon_product_rank_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonProductRankOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def amazon_product_rank_overview_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_amazon_product_rank_overview_live_request_info: 'List[Optional[DataforseoLabsAmazonProductRankOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._amazon_product_rank_overview_live_serialize(
            list_optional_dataforseo_labs_amazon_product_rank_overview_live_request_info=list_optional_dataforseo_labs_amazon_product_rank_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonProductRankOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _amazon_product_rank_overview_live_serialize(
        self,
        list_optional_dataforseo_labs_amazon_product_rank_overview_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsAmazonProductRankOverviewLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_amazon_product_rank_overview_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_amazon_product_rank_overview_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/amazon/product_rank_overview/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_amazon_product_competitors_live_request_info import DataforseoLabsAmazonProductCompetitorsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_amazon_product_competitors_live_response_info import DataforseoLabsAmazonProductCompetitorsLiveResponseInfo
    @validate_call
    def amazon_product_competitors_live(
        self,
        list_optional_dataforseo_labs_amazon_product_competitors_live_request_info: 'List[Optional[DataforseoLabsAmazonProductCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsAmazonProductCompetitorsLiveResponseInfo:

        _param = self._amazon_product_competitors_live_serialize(
            list_optional_dataforseo_labs_amazon_product_competitors_live_request_info=list_optional_dataforseo_labs_amazon_product_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonProductCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def amazon_product_competitors_live_with_http_info(
        self,
        list_optional_dataforseo_labs_amazon_product_competitors_live_request_info: 'List[Optional[DataforseoLabsAmazonProductCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsAmazonProductCompetitorsLiveResponseInfo]':

        _param = self._amazon_product_competitors_live_serialize(
            list_optional_dataforseo_labs_amazon_product_competitors_live_request_info=list_optional_dataforseo_labs_amazon_product_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonProductCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def amazon_product_competitors_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_amazon_product_competitors_live_request_info: 'List[Optional[DataforseoLabsAmazonProductCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._amazon_product_competitors_live_serialize(
            list_optional_dataforseo_labs_amazon_product_competitors_live_request_info=list_optional_dataforseo_labs_amazon_product_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonProductCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _amazon_product_competitors_live_serialize(
        self,
        list_optional_dataforseo_labs_amazon_product_competitors_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsAmazonProductCompetitorsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_amazon_product_competitors_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_amazon_product_competitors_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/amazon/product_competitors/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_amazon_product_keyword_intersections_live_request_info import DataforseoLabsAmazonProductKeywordIntersectionsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_amazon_product_keyword_intersections_live_response_info import DataforseoLabsAmazonProductKeywordIntersectionsLiveResponseInfo
    @validate_call
    def amazon_product_keyword_intersections_live(
        self,
        list_optional_dataforseo_labs_amazon_product_keyword_intersections_live_request_info: 'List[Optional[DataforseoLabsAmazonProductKeywordIntersectionsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsAmazonProductKeywordIntersectionsLiveResponseInfo:

        _param = self._amazon_product_keyword_intersections_live_serialize(
            list_optional_dataforseo_labs_amazon_product_keyword_intersections_live_request_info=list_optional_dataforseo_labs_amazon_product_keyword_intersections_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonProductKeywordIntersectionsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def amazon_product_keyword_intersections_live_with_http_info(
        self,
        list_optional_dataforseo_labs_amazon_product_keyword_intersections_live_request_info: 'List[Optional[DataforseoLabsAmazonProductKeywordIntersectionsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsAmazonProductKeywordIntersectionsLiveResponseInfo]':

        _param = self._amazon_product_keyword_intersections_live_serialize(
            list_optional_dataforseo_labs_amazon_product_keyword_intersections_live_request_info=list_optional_dataforseo_labs_amazon_product_keyword_intersections_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonProductKeywordIntersectionsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def amazon_product_keyword_intersections_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_amazon_product_keyword_intersections_live_request_info: 'List[Optional[DataforseoLabsAmazonProductKeywordIntersectionsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._amazon_product_keyword_intersections_live_serialize(
            list_optional_dataforseo_labs_amazon_product_keyword_intersections_live_request_info=list_optional_dataforseo_labs_amazon_product_keyword_intersections_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAmazonProductKeywordIntersectionsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _amazon_product_keyword_intersections_live_serialize(
        self,
        list_optional_dataforseo_labs_amazon_product_keyword_intersections_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsAmazonProductKeywordIntersectionsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_amazon_product_keyword_intersections_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_amazon_product_keyword_intersections_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/amazon/product_keyword_intersections/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info import DataforseoLabsBingBulkKeywordDifficultyLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_bulk_keyword_difficulty_live_response_info import DataforseoLabsBingBulkKeywordDifficultyLiveResponseInfo
    @validate_call
    def bing_bulk_keyword_difficulty_live(
        self,
        list_optional_dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info: 'List[Optional[DataforseoLabsBingBulkKeywordDifficultyLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsBingBulkKeywordDifficultyLiveResponseInfo:

        _param = self._bing_bulk_keyword_difficulty_live_serialize(
            list_optional_dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info=list_optional_dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingBulkKeywordDifficultyLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def bing_bulk_keyword_difficulty_live_with_http_info(
        self,
        list_optional_dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info: 'List[Optional[DataforseoLabsBingBulkKeywordDifficultyLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsBingBulkKeywordDifficultyLiveResponseInfo]':

        _param = self._bing_bulk_keyword_difficulty_live_serialize(
            list_optional_dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info=list_optional_dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingBulkKeywordDifficultyLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def bing_bulk_keyword_difficulty_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info: 'List[Optional[DataforseoLabsBingBulkKeywordDifficultyLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._bing_bulk_keyword_difficulty_live_serialize(
            list_optional_dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info=list_optional_dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingBulkKeywordDifficultyLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _bing_bulk_keyword_difficulty_live_serialize(
        self,
        list_optional_dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsBingBulkKeywordDifficultyLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_bing_bulk_keyword_difficulty_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/bing/bulk_keyword_difficulty/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_bing_bulk_traffic_estimation_live_request_info import DataforseoLabsBingBulkTrafficEstimationLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_bulk_traffic_estimation_live_response_info import DataforseoLabsBingBulkTrafficEstimationLiveResponseInfo
    @validate_call
    def bing_bulk_traffic_estimation_live(
        self,
        list_optional_dataforseo_labs_bing_bulk_traffic_estimation_live_request_info: 'List[Optional[DataforseoLabsBingBulkTrafficEstimationLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsBingBulkTrafficEstimationLiveResponseInfo:

        _param = self._bing_bulk_traffic_estimation_live_serialize(
            list_optional_dataforseo_labs_bing_bulk_traffic_estimation_live_request_info=list_optional_dataforseo_labs_bing_bulk_traffic_estimation_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingBulkTrafficEstimationLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def bing_bulk_traffic_estimation_live_with_http_info(
        self,
        list_optional_dataforseo_labs_bing_bulk_traffic_estimation_live_request_info: 'List[Optional[DataforseoLabsBingBulkTrafficEstimationLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsBingBulkTrafficEstimationLiveResponseInfo]':

        _param = self._bing_bulk_traffic_estimation_live_serialize(
            list_optional_dataforseo_labs_bing_bulk_traffic_estimation_live_request_info=list_optional_dataforseo_labs_bing_bulk_traffic_estimation_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingBulkTrafficEstimationLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def bing_bulk_traffic_estimation_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_bing_bulk_traffic_estimation_live_request_info: 'List[Optional[DataforseoLabsBingBulkTrafficEstimationLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._bing_bulk_traffic_estimation_live_serialize(
            list_optional_dataforseo_labs_bing_bulk_traffic_estimation_live_request_info=list_optional_dataforseo_labs_bing_bulk_traffic_estimation_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingBulkTrafficEstimationLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _bing_bulk_traffic_estimation_live_serialize(
        self,
        list_optional_dataforseo_labs_bing_bulk_traffic_estimation_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsBingBulkTrafficEstimationLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_bing_bulk_traffic_estimation_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_bing_bulk_traffic_estimation_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/bing/bulk_traffic_estimation/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_bing_competitors_domain_live_request_info import DataforseoLabsBingCompetitorsDomainLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_competitors_domain_live_response_info import DataforseoLabsBingCompetitorsDomainLiveResponseInfo
    @validate_call
    def bing_competitors_domain_live(
        self,
        list_optional_dataforseo_labs_bing_competitors_domain_live_request_info: 'List[Optional[DataforseoLabsBingCompetitorsDomainLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsBingCompetitorsDomainLiveResponseInfo:

        _param = self._bing_competitors_domain_live_serialize(
            list_optional_dataforseo_labs_bing_competitors_domain_live_request_info=list_optional_dataforseo_labs_bing_competitors_domain_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingCompetitorsDomainLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def bing_competitors_domain_live_with_http_info(
        self,
        list_optional_dataforseo_labs_bing_competitors_domain_live_request_info: 'List[Optional[DataforseoLabsBingCompetitorsDomainLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsBingCompetitorsDomainLiveResponseInfo]':

        _param = self._bing_competitors_domain_live_serialize(
            list_optional_dataforseo_labs_bing_competitors_domain_live_request_info=list_optional_dataforseo_labs_bing_competitors_domain_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingCompetitorsDomainLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def bing_competitors_domain_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_bing_competitors_domain_live_request_info: 'List[Optional[DataforseoLabsBingCompetitorsDomainLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._bing_competitors_domain_live_serialize(
            list_optional_dataforseo_labs_bing_competitors_domain_live_request_info=list_optional_dataforseo_labs_bing_competitors_domain_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingCompetitorsDomainLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _bing_competitors_domain_live_serialize(
        self,
        list_optional_dataforseo_labs_bing_competitors_domain_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsBingCompetitorsDomainLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_bing_competitors_domain_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_bing_competitors_domain_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/bing/competitors_domain/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_bing_domain_intersection_live_request_info import DataforseoLabsBingDomainIntersectionLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_domain_intersection_live_response_info import DataforseoLabsBingDomainIntersectionLiveResponseInfo
    @validate_call
    def bing_domain_intersection_live(
        self,
        list_optional_dataforseo_labs_bing_domain_intersection_live_request_info: 'List[Optional[DataforseoLabsBingDomainIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsBingDomainIntersectionLiveResponseInfo:

        _param = self._bing_domain_intersection_live_serialize(
            list_optional_dataforseo_labs_bing_domain_intersection_live_request_info=list_optional_dataforseo_labs_bing_domain_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingDomainIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def bing_domain_intersection_live_with_http_info(
        self,
        list_optional_dataforseo_labs_bing_domain_intersection_live_request_info: 'List[Optional[DataforseoLabsBingDomainIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsBingDomainIntersectionLiveResponseInfo]':

        _param = self._bing_domain_intersection_live_serialize(
            list_optional_dataforseo_labs_bing_domain_intersection_live_request_info=list_optional_dataforseo_labs_bing_domain_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingDomainIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def bing_domain_intersection_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_bing_domain_intersection_live_request_info: 'List[Optional[DataforseoLabsBingDomainIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._bing_domain_intersection_live_serialize(
            list_optional_dataforseo_labs_bing_domain_intersection_live_request_info=list_optional_dataforseo_labs_bing_domain_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingDomainIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _bing_domain_intersection_live_serialize(
        self,
        list_optional_dataforseo_labs_bing_domain_intersection_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsBingDomainIntersectionLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_bing_domain_intersection_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_bing_domain_intersection_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/bing/domain_intersection/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_bing_domain_rank_overview_live_request_info import DataforseoLabsBingDomainRankOverviewLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_domain_rank_overview_live_response_info import DataforseoLabsBingDomainRankOverviewLiveResponseInfo
    @validate_call
    def bing_domain_rank_overview_live(
        self,
        list_optional_dataforseo_labs_bing_domain_rank_overview_live_request_info: 'List[Optional[DataforseoLabsBingDomainRankOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsBingDomainRankOverviewLiveResponseInfo:

        _param = self._bing_domain_rank_overview_live_serialize(
            list_optional_dataforseo_labs_bing_domain_rank_overview_live_request_info=list_optional_dataforseo_labs_bing_domain_rank_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingDomainRankOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def bing_domain_rank_overview_live_with_http_info(
        self,
        list_optional_dataforseo_labs_bing_domain_rank_overview_live_request_info: 'List[Optional[DataforseoLabsBingDomainRankOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsBingDomainRankOverviewLiveResponseInfo]':

        _param = self._bing_domain_rank_overview_live_serialize(
            list_optional_dataforseo_labs_bing_domain_rank_overview_live_request_info=list_optional_dataforseo_labs_bing_domain_rank_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingDomainRankOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def bing_domain_rank_overview_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_bing_domain_rank_overview_live_request_info: 'List[Optional[DataforseoLabsBingDomainRankOverviewLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._bing_domain_rank_overview_live_serialize(
            list_optional_dataforseo_labs_bing_domain_rank_overview_live_request_info=list_optional_dataforseo_labs_bing_domain_rank_overview_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingDomainRankOverviewLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _bing_domain_rank_overview_live_serialize(
        self,
        list_optional_dataforseo_labs_bing_domain_rank_overview_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsBingDomainRankOverviewLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_bing_domain_rank_overview_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_bing_domain_rank_overview_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/bing/domain_rank_overview/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_bing_page_intersection_live_request_info import DataforseoLabsBingPageIntersectionLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_page_intersection_live_response_info import DataforseoLabsBingPageIntersectionLiveResponseInfo
    @validate_call
    def bing_page_intersection_live(
        self,
        list_optional_dataforseo_labs_bing_page_intersection_live_request_info: 'List[Optional[DataforseoLabsBingPageIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsBingPageIntersectionLiveResponseInfo:

        _param = self._bing_page_intersection_live_serialize(
            list_optional_dataforseo_labs_bing_page_intersection_live_request_info=list_optional_dataforseo_labs_bing_page_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingPageIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def bing_page_intersection_live_with_http_info(
        self,
        list_optional_dataforseo_labs_bing_page_intersection_live_request_info: 'List[Optional[DataforseoLabsBingPageIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsBingPageIntersectionLiveResponseInfo]':

        _param = self._bing_page_intersection_live_serialize(
            list_optional_dataforseo_labs_bing_page_intersection_live_request_info=list_optional_dataforseo_labs_bing_page_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingPageIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def bing_page_intersection_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_bing_page_intersection_live_request_info: 'List[Optional[DataforseoLabsBingPageIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._bing_page_intersection_live_serialize(
            list_optional_dataforseo_labs_bing_page_intersection_live_request_info=list_optional_dataforseo_labs_bing_page_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingPageIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _bing_page_intersection_live_serialize(
        self,
        list_optional_dataforseo_labs_bing_page_intersection_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsBingPageIntersectionLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_bing_page_intersection_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_bing_page_intersection_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/bing/page_intersection/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_bing_ranked_keywords_live_request_info import DataforseoLabsBingRankedKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_ranked_keywords_live_response_info import DataforseoLabsBingRankedKeywordsLiveResponseInfo
    @validate_call
    def bing_ranked_keywords_live(
        self,
        list_optional_dataforseo_labs_bing_ranked_keywords_live_request_info: 'List[Optional[DataforseoLabsBingRankedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsBingRankedKeywordsLiveResponseInfo:

        _param = self._bing_ranked_keywords_live_serialize(
            list_optional_dataforseo_labs_bing_ranked_keywords_live_request_info=list_optional_dataforseo_labs_bing_ranked_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingRankedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def bing_ranked_keywords_live_with_http_info(
        self,
        list_optional_dataforseo_labs_bing_ranked_keywords_live_request_info: 'List[Optional[DataforseoLabsBingRankedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsBingRankedKeywordsLiveResponseInfo]':

        _param = self._bing_ranked_keywords_live_serialize(
            list_optional_dataforseo_labs_bing_ranked_keywords_live_request_info=list_optional_dataforseo_labs_bing_ranked_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingRankedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def bing_ranked_keywords_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_bing_ranked_keywords_live_request_info: 'List[Optional[DataforseoLabsBingRankedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._bing_ranked_keywords_live_serialize(
            list_optional_dataforseo_labs_bing_ranked_keywords_live_request_info=list_optional_dataforseo_labs_bing_ranked_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingRankedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _bing_ranked_keywords_live_serialize(
        self,
        list_optional_dataforseo_labs_bing_ranked_keywords_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsBingRankedKeywordsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_bing_ranked_keywords_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_bing_ranked_keywords_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/bing/ranked_keywords/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_bing_related_keywords_live_request_info import DataforseoLabsBingRelatedKeywordsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_related_keywords_live_response_info import DataforseoLabsBingRelatedKeywordsLiveResponseInfo
    @validate_call
    def bing_related_keywords_live(
        self,
        list_optional_dataforseo_labs_bing_related_keywords_live_request_info: 'List[Optional[DataforseoLabsBingRelatedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsBingRelatedKeywordsLiveResponseInfo:

        _param = self._bing_related_keywords_live_serialize(
            list_optional_dataforseo_labs_bing_related_keywords_live_request_info=list_optional_dataforseo_labs_bing_related_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingRelatedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def bing_related_keywords_live_with_http_info(
        self,
        list_optional_dataforseo_labs_bing_related_keywords_live_request_info: 'List[Optional[DataforseoLabsBingRelatedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsBingRelatedKeywordsLiveResponseInfo]':

        _param = self._bing_related_keywords_live_serialize(
            list_optional_dataforseo_labs_bing_related_keywords_live_request_info=list_optional_dataforseo_labs_bing_related_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingRelatedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def bing_related_keywords_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_bing_related_keywords_live_request_info: 'List[Optional[DataforseoLabsBingRelatedKeywordsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._bing_related_keywords_live_serialize(
            list_optional_dataforseo_labs_bing_related_keywords_live_request_info=list_optional_dataforseo_labs_bing_related_keywords_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingRelatedKeywordsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _bing_related_keywords_live_serialize(
        self,
        list_optional_dataforseo_labs_bing_related_keywords_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsBingRelatedKeywordsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_bing_related_keywords_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_bing_related_keywords_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/bing/related_keywords/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_bing_relevant_pages_live_request_info import DataforseoLabsBingRelevantPagesLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_relevant_pages_live_response_info import DataforseoLabsBingRelevantPagesLiveResponseInfo
    @validate_call
    def bing_relevant_pages_live(
        self,
        list_optional_dataforseo_labs_bing_relevant_pages_live_request_info: 'List[Optional[DataforseoLabsBingRelevantPagesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsBingRelevantPagesLiveResponseInfo:

        _param = self._bing_relevant_pages_live_serialize(
            list_optional_dataforseo_labs_bing_relevant_pages_live_request_info=list_optional_dataforseo_labs_bing_relevant_pages_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingRelevantPagesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def bing_relevant_pages_live_with_http_info(
        self,
        list_optional_dataforseo_labs_bing_relevant_pages_live_request_info: 'List[Optional[DataforseoLabsBingRelevantPagesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsBingRelevantPagesLiveResponseInfo]':

        _param = self._bing_relevant_pages_live_serialize(
            list_optional_dataforseo_labs_bing_relevant_pages_live_request_info=list_optional_dataforseo_labs_bing_relevant_pages_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingRelevantPagesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def bing_relevant_pages_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_bing_relevant_pages_live_request_info: 'List[Optional[DataforseoLabsBingRelevantPagesLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._bing_relevant_pages_live_serialize(
            list_optional_dataforseo_labs_bing_relevant_pages_live_request_info=list_optional_dataforseo_labs_bing_relevant_pages_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingRelevantPagesLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _bing_relevant_pages_live_serialize(
        self,
        list_optional_dataforseo_labs_bing_relevant_pages_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsBingRelevantPagesLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_bing_relevant_pages_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_bing_relevant_pages_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/bing/relevant_pages/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_bing_serp_competitors_live_request_info import DataforseoLabsBingSerpCompetitorsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_serp_competitors_live_response_info import DataforseoLabsBingSerpCompetitorsLiveResponseInfo
    @validate_call
    def bing_serp_competitors_live(
        self,
        list_optional_dataforseo_labs_bing_serp_competitors_live_request_info: 'List[Optional[DataforseoLabsBingSerpCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsBingSerpCompetitorsLiveResponseInfo:

        _param = self._bing_serp_competitors_live_serialize(
            list_optional_dataforseo_labs_bing_serp_competitors_live_request_info=list_optional_dataforseo_labs_bing_serp_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingSerpCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def bing_serp_competitors_live_with_http_info(
        self,
        list_optional_dataforseo_labs_bing_serp_competitors_live_request_info: 'List[Optional[DataforseoLabsBingSerpCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsBingSerpCompetitorsLiveResponseInfo]':

        _param = self._bing_serp_competitors_live_serialize(
            list_optional_dataforseo_labs_bing_serp_competitors_live_request_info=list_optional_dataforseo_labs_bing_serp_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingSerpCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def bing_serp_competitors_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_bing_serp_competitors_live_request_info: 'List[Optional[DataforseoLabsBingSerpCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._bing_serp_competitors_live_serialize(
            list_optional_dataforseo_labs_bing_serp_competitors_live_request_info=list_optional_dataforseo_labs_bing_serp_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingSerpCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _bing_serp_competitors_live_serialize(
        self,
        list_optional_dataforseo_labs_bing_serp_competitors_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsBingSerpCompetitorsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_bing_serp_competitors_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_bing_serp_competitors_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/bing/serp_competitors/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_bing_subdomains_live_request_info import DataforseoLabsBingSubdomainsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_bing_subdomains_live_response_info import DataforseoLabsBingSubdomainsLiveResponseInfo
    @validate_call
    def bing_subdomains_live(
        self,
        list_optional_dataforseo_labs_bing_subdomains_live_request_info: 'List[Optional[DataforseoLabsBingSubdomainsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsBingSubdomainsLiveResponseInfo:

        _param = self._bing_subdomains_live_serialize(
            list_optional_dataforseo_labs_bing_subdomains_live_request_info=list_optional_dataforseo_labs_bing_subdomains_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingSubdomainsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def bing_subdomains_live_with_http_info(
        self,
        list_optional_dataforseo_labs_bing_subdomains_live_request_info: 'List[Optional[DataforseoLabsBingSubdomainsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsBingSubdomainsLiveResponseInfo]':

        _param = self._bing_subdomains_live_serialize(
            list_optional_dataforseo_labs_bing_subdomains_live_request_info=list_optional_dataforseo_labs_bing_subdomains_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingSubdomainsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def bing_subdomains_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_bing_subdomains_live_request_info: 'List[Optional[DataforseoLabsBingSubdomainsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._bing_subdomains_live_serialize(
            list_optional_dataforseo_labs_bing_subdomains_live_request_info=list_optional_dataforseo_labs_bing_subdomains_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsBingSubdomainsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _bing_subdomains_live_serialize(
        self,
        list_optional_dataforseo_labs_bing_subdomains_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsBingSubdomainsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_bing_subdomains_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_bing_subdomains_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/bing/subdomains/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_bulk_app_metrics_live_request_info import DataforseoLabsGoogleBulkAppMetricsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_bulk_app_metrics_live_response_info import DataforseoLabsGoogleBulkAppMetricsLiveResponseInfo
    @validate_call
    def google_bulk_app_metrics_live(
        self,
        list_optional_dataforseo_labs_google_bulk_app_metrics_live_request_info: 'List[Optional[DataforseoLabsGoogleBulkAppMetricsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleBulkAppMetricsLiveResponseInfo:

        _param = self._google_bulk_app_metrics_live_serialize(
            list_optional_dataforseo_labs_google_bulk_app_metrics_live_request_info=list_optional_dataforseo_labs_google_bulk_app_metrics_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleBulkAppMetricsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_bulk_app_metrics_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_bulk_app_metrics_live_request_info: 'List[Optional[DataforseoLabsGoogleBulkAppMetricsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleBulkAppMetricsLiveResponseInfo]':

        _param = self._google_bulk_app_metrics_live_serialize(
            list_optional_dataforseo_labs_google_bulk_app_metrics_live_request_info=list_optional_dataforseo_labs_google_bulk_app_metrics_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleBulkAppMetricsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_bulk_app_metrics_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_bulk_app_metrics_live_request_info: 'List[Optional[DataforseoLabsGoogleBulkAppMetricsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_bulk_app_metrics_live_serialize(
            list_optional_dataforseo_labs_google_bulk_app_metrics_live_request_info=list_optional_dataforseo_labs_google_bulk_app_metrics_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleBulkAppMetricsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_bulk_app_metrics_live_serialize(
        self,
        list_optional_dataforseo_labs_google_bulk_app_metrics_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleBulkAppMetricsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_bulk_app_metrics_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_bulk_app_metrics_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/bulk_app_metrics/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_keywords_for_app_live_request_info import DataforseoLabsGoogleKeywordsForAppLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_keywords_for_app_live_response_info import DataforseoLabsGoogleKeywordsForAppLiveResponseInfo
    @validate_call
    def google_keywords_for_app_live(
        self,
        list_optional_dataforseo_labs_google_keywords_for_app_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordsForAppLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleKeywordsForAppLiveResponseInfo:

        _param = self._google_keywords_for_app_live_serialize(
            list_optional_dataforseo_labs_google_keywords_for_app_live_request_info=list_optional_dataforseo_labs_google_keywords_for_app_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordsForAppLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_keywords_for_app_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_keywords_for_app_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordsForAppLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleKeywordsForAppLiveResponseInfo]':

        _param = self._google_keywords_for_app_live_serialize(
            list_optional_dataforseo_labs_google_keywords_for_app_live_request_info=list_optional_dataforseo_labs_google_keywords_for_app_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordsForAppLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_keywords_for_app_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_keywords_for_app_live_request_info: 'List[Optional[DataforseoLabsGoogleKeywordsForAppLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_keywords_for_app_live_serialize(
            list_optional_dataforseo_labs_google_keywords_for_app_live_request_info=list_optional_dataforseo_labs_google_keywords_for_app_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleKeywordsForAppLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_keywords_for_app_live_serialize(
        self,
        list_optional_dataforseo_labs_google_keywords_for_app_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleKeywordsForAppLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_keywords_for_app_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_keywords_for_app_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/keywords_for_app/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_app_competitors_live_request_info import DataforseoLabsGoogleAppCompetitorsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_app_competitors_live_response_info import DataforseoLabsGoogleAppCompetitorsLiveResponseInfo
    @validate_call
    def google_app_competitors_live(
        self,
        list_optional_dataforseo_labs_google_app_competitors_live_request_info: 'List[Optional[DataforseoLabsGoogleAppCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleAppCompetitorsLiveResponseInfo:

        _param = self._google_app_competitors_live_serialize(
            list_optional_dataforseo_labs_google_app_competitors_live_request_info=list_optional_dataforseo_labs_google_app_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleAppCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_app_competitors_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_app_competitors_live_request_info: 'List[Optional[DataforseoLabsGoogleAppCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleAppCompetitorsLiveResponseInfo]':

        _param = self._google_app_competitors_live_serialize(
            list_optional_dataforseo_labs_google_app_competitors_live_request_info=list_optional_dataforseo_labs_google_app_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleAppCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_app_competitors_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_app_competitors_live_request_info: 'List[Optional[DataforseoLabsGoogleAppCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_app_competitors_live_serialize(
            list_optional_dataforseo_labs_google_app_competitors_live_request_info=list_optional_dataforseo_labs_google_app_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleAppCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_app_competitors_live_serialize(
        self,
        list_optional_dataforseo_labs_google_app_competitors_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleAppCompetitorsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_app_competitors_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_app_competitors_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/app_competitors/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_google_app_intersection_live_request_info import DataforseoLabsGoogleAppIntersectionLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_google_app_intersection_live_response_info import DataforseoLabsGoogleAppIntersectionLiveResponseInfo
    @validate_call
    def google_app_intersection_live(
        self,
        list_optional_dataforseo_labs_google_app_intersection_live_request_info: 'List[Optional[DataforseoLabsGoogleAppIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsGoogleAppIntersectionLiveResponseInfo:

        _param = self._google_app_intersection_live_serialize(
            list_optional_dataforseo_labs_google_app_intersection_live_request_info=list_optional_dataforseo_labs_google_app_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleAppIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def google_app_intersection_live_with_http_info(
        self,
        list_optional_dataforseo_labs_google_app_intersection_live_request_info: 'List[Optional[DataforseoLabsGoogleAppIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsGoogleAppIntersectionLiveResponseInfo]':

        _param = self._google_app_intersection_live_serialize(
            list_optional_dataforseo_labs_google_app_intersection_live_request_info=list_optional_dataforseo_labs_google_app_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleAppIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def google_app_intersection_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_google_app_intersection_live_request_info: 'List[Optional[DataforseoLabsGoogleAppIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._google_app_intersection_live_serialize(
            list_optional_dataforseo_labs_google_app_intersection_live_request_info=list_optional_dataforseo_labs_google_app_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsGoogleAppIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _google_app_intersection_live_serialize(
        self,
        list_optional_dataforseo_labs_google_app_intersection_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsGoogleAppIntersectionLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_google_app_intersection_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_google_app_intersection_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/google/app_intersection/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_apple_bulk_app_metrics_live_request_info import DataforseoLabsAppleBulkAppMetricsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_apple_bulk_app_metrics_live_response_info import DataforseoLabsAppleBulkAppMetricsLiveResponseInfo
    @validate_call
    def apple_bulk_app_metrics_live(
        self,
        list_optional_dataforseo_labs_apple_bulk_app_metrics_live_request_info: 'List[Optional[DataforseoLabsAppleBulkAppMetricsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsAppleBulkAppMetricsLiveResponseInfo:

        _param = self._apple_bulk_app_metrics_live_serialize(
            list_optional_dataforseo_labs_apple_bulk_app_metrics_live_request_info=list_optional_dataforseo_labs_apple_bulk_app_metrics_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAppleBulkAppMetricsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def apple_bulk_app_metrics_live_with_http_info(
        self,
        list_optional_dataforseo_labs_apple_bulk_app_metrics_live_request_info: 'List[Optional[DataforseoLabsAppleBulkAppMetricsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsAppleBulkAppMetricsLiveResponseInfo]':

        _param = self._apple_bulk_app_metrics_live_serialize(
            list_optional_dataforseo_labs_apple_bulk_app_metrics_live_request_info=list_optional_dataforseo_labs_apple_bulk_app_metrics_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAppleBulkAppMetricsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def apple_bulk_app_metrics_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_apple_bulk_app_metrics_live_request_info: 'List[Optional[DataforseoLabsAppleBulkAppMetricsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._apple_bulk_app_metrics_live_serialize(
            list_optional_dataforseo_labs_apple_bulk_app_metrics_live_request_info=list_optional_dataforseo_labs_apple_bulk_app_metrics_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAppleBulkAppMetricsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _apple_bulk_app_metrics_live_serialize(
        self,
        list_optional_dataforseo_labs_apple_bulk_app_metrics_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsAppleBulkAppMetricsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_apple_bulk_app_metrics_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_apple_bulk_app_metrics_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/apple/bulk_app_metrics/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_apple_keywords_for_app_live_request_info import DataforseoLabsAppleKeywordsForAppLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_apple_keywords_for_app_live_response_info import DataforseoLabsAppleKeywordsForAppLiveResponseInfo
    @validate_call
    def apple_keywords_for_app_live(
        self,
        list_optional_dataforseo_labs_apple_keywords_for_app_live_request_info: 'List[Optional[DataforseoLabsAppleKeywordsForAppLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsAppleKeywordsForAppLiveResponseInfo:

        _param = self._apple_keywords_for_app_live_serialize(
            list_optional_dataforseo_labs_apple_keywords_for_app_live_request_info=list_optional_dataforseo_labs_apple_keywords_for_app_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAppleKeywordsForAppLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def apple_keywords_for_app_live_with_http_info(
        self,
        list_optional_dataforseo_labs_apple_keywords_for_app_live_request_info: 'List[Optional[DataforseoLabsAppleKeywordsForAppLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsAppleKeywordsForAppLiveResponseInfo]':

        _param = self._apple_keywords_for_app_live_serialize(
            list_optional_dataforseo_labs_apple_keywords_for_app_live_request_info=list_optional_dataforseo_labs_apple_keywords_for_app_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAppleKeywordsForAppLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def apple_keywords_for_app_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_apple_keywords_for_app_live_request_info: 'List[Optional[DataforseoLabsAppleKeywordsForAppLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._apple_keywords_for_app_live_serialize(
            list_optional_dataforseo_labs_apple_keywords_for_app_live_request_info=list_optional_dataforseo_labs_apple_keywords_for_app_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAppleKeywordsForAppLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _apple_keywords_for_app_live_serialize(
        self,
        list_optional_dataforseo_labs_apple_keywords_for_app_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsAppleKeywordsForAppLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_apple_keywords_for_app_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_apple_keywords_for_app_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/apple/keywords_for_app/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_apple_app_competitors_live_request_info import DataforseoLabsAppleAppCompetitorsLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_apple_app_competitors_live_response_info import DataforseoLabsAppleAppCompetitorsLiveResponseInfo
    @validate_call
    def apple_app_competitors_live(
        self,
        list_optional_dataforseo_labs_apple_app_competitors_live_request_info: 'List[Optional[DataforseoLabsAppleAppCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsAppleAppCompetitorsLiveResponseInfo:

        _param = self._apple_app_competitors_live_serialize(
            list_optional_dataforseo_labs_apple_app_competitors_live_request_info=list_optional_dataforseo_labs_apple_app_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAppleAppCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def apple_app_competitors_live_with_http_info(
        self,
        list_optional_dataforseo_labs_apple_app_competitors_live_request_info: 'List[Optional[DataforseoLabsAppleAppCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsAppleAppCompetitorsLiveResponseInfo]':

        _param = self._apple_app_competitors_live_serialize(
            list_optional_dataforseo_labs_apple_app_competitors_live_request_info=list_optional_dataforseo_labs_apple_app_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAppleAppCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def apple_app_competitors_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_apple_app_competitors_live_request_info: 'List[Optional[DataforseoLabsAppleAppCompetitorsLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._apple_app_competitors_live_serialize(
            list_optional_dataforseo_labs_apple_app_competitors_live_request_info=list_optional_dataforseo_labs_apple_app_competitors_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAppleAppCompetitorsLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _apple_app_competitors_live_serialize(
        self,
        list_optional_dataforseo_labs_apple_app_competitors_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsAppleAppCompetitorsLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_apple_app_competitors_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_apple_app_competitors_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/apple/app_competitors/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )

    from dataforseo_client.models.dataforseo_labs_apple_app_intersection_live_request_info import DataforseoLabsAppleAppIntersectionLiveRequestInfo
    from dataforseo_client.models.dataforseo_labs_apple_app_intersection_live_response_info import DataforseoLabsAppleAppIntersectionLiveResponseInfo
    @validate_call
    def apple_app_intersection_live(
        self,
        list_optional_dataforseo_labs_apple_app_intersection_live_request_info: 'List[Optional[DataforseoLabsAppleAppIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> DataforseoLabsAppleAppIntersectionLiveResponseInfo:

        _param = self._apple_app_intersection_live_serialize(
            list_optional_dataforseo_labs_apple_app_intersection_live_request_info=list_optional_dataforseo_labs_apple_app_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAppleAppIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        ).data


    
    @validate_call
    def apple_app_intersection_live_with_http_info(
        self,
        list_optional_dataforseo_labs_apple_app_intersection_live_request_info: 'List[Optional[DataforseoLabsAppleAppIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> 'ApiResponse[DataforseoLabsAppleAppIntersectionLiveResponseInfo]':

        _param = self._apple_app_intersection_live_serialize(
            list_optional_dataforseo_labs_apple_app_intersection_live_request_info=list_optional_dataforseo_labs_apple_app_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAppleAppIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        response_data.read()
        return self.api_client.response_deserialize(
            response_data=response_data,
            response_types_map=_response_types_map,
        )


    @validate_call
    def apple_app_intersection_live_without_preload_content(
        self,
        list_optional_dataforseo_labs_apple_app_intersection_live_request_info: 'List[Optional[DataforseoLabsAppleAppIntersectionLiveRequestInfo]]' = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> RESTResponseType:

        _param = self._apple_app_intersection_live_serialize(
            list_optional_dataforseo_labs_apple_app_intersection_live_request_info=list_optional_dataforseo_labs_apple_app_intersection_live_request_info,
            _request_auth=_request_auth,
            _content_type=_content_type,
            _headers=_headers,
            _host_index=_host_index
        )

        _response_types_map: Dict[str, Optional[str]] = {
            '200': "DataforseoLabsAppleAppIntersectionLiveResponseInfo",
        }
        response_data = self.api_client.call_api(
            *_param,
            _request_timeout=_request_timeout
        )
        return response_data.response


    def _apple_app_intersection_live_serialize(
        self,
        list_optional_dataforseo_labs_apple_app_intersection_live_request_info,
        _request_auth,
        _content_type,
        _headers,
        _host_index,
    ) -> RequestSerialized:

        _host = None

        _collection_formats: Dict[str, str] = {
            'List[Optional[DataforseoLabsAppleAppIntersectionLiveRequestInfo]]': '',
        }

        _path_params: Dict[str, str] = {}
        _query_params: List[Tuple[str, str]] = []
        _header_params: Dict[str, Optional[str]] = _headers or {}
        _form_params: List[Tuple[str, str]] = []
        _files: Dict[str, Union[str, bytes]] = {}
        _body_params: Optional[bytes] = None

        # process the path parameters
        # process the query parameters
        # process the header parameters
        # process the form parameters
        # process the body parameter
        if list_optional_dataforseo_labs_apple_app_intersection_live_request_info is not None:
            _body_params = list_optional_dataforseo_labs_apple_app_intersection_live_request_info


        # set the HTTP header `Accept`
        if 'Accept' not in _header_params:
            _header_params['Accept'] = self.api_client.select_header_accept(
                [
                    'application/json'
                ]
            )

        # set the HTTP header `Content-Type`
        if _content_type:
            _header_params['Content-Type'] = _content_type
        else:
            _default_content_type = (
                self.api_client.select_header_content_type(
                    [
                        'application/json'
                    ]
                )
            )
            if _default_content_type is not None:
                _header_params['Content-Type'] = _default_content_type

        # authentication setting
        _auth_settings: List[str] = [
            'basicAuth'
        ]

        return self.api_client.param_serialize(
            method='POST',
            resource_path='/v3/dataforseo_labs/apple/app_intersection/live',
            path_params=_path_params,
            query_params=_query_params,
            header_params=_header_params,
            body=_body_params,
            post_params=_form_params,
            files=_files,
            auth_settings=_auth_settings,
            collection_formats=_collection_formats,
            _host=_host,
            _request_auth=_request_auth
        )