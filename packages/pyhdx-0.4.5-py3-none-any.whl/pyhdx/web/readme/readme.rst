README
------

This folder contains information on the stucture of the pyhdx web applications

tables_list:
list of tables