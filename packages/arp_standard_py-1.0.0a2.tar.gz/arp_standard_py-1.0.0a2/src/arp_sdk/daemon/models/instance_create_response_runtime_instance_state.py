from enum import Enum

class InstanceCreateResponseRuntimeInstanceState(str, Enum):
    BUSY = "busy"
    ERROR = "error"
    READY = "ready"
    STARTING = "starting"
    STOPPED = "stopped"
    STOPPING = "stopping"

    def __str__(self) -> str:
        return str(self.value)
