"""Module for buttons"""
# pylint: disable=no-name-in-module, trailing-whitespace, too-many-branches, too-many-statements


import sys
import os
import time
import re
import glob
import shutil
from PyQt5.QtWidgets import QApplication 
from PyQt5.QtWidgets import (
    QWidget, QButtonGroup, QPushButton, QLabel, QGroupBox, QGridLayout,
    QFileDialog, QProgressDialog, QRadioButton, QSizePolicy, QSlider)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from semapp.Processing.processing import Process
from semapp.Processing.klarf_reader import extract_wafer_ids_from_sp3, organize_sp3_files, extract_sp3_from_directory, extract_positions
from semapp.Layout.styles import (
    RADIO_BUTTON_STYLE,
    SETTINGS_BUTTON_STYLE,
    RUN_BUTTON_STYLE,
    GROUP_BOX_STYLE,
    WAFER_BUTTON_DEFAULT_STYLE,
    WAFER_BUTTON_EXISTING_STYLE,
    WAFER_BUTTON_MISSING_STYLE,
    SELECT_BUTTON_STYLE,
    PATH_LABEL_STYLE,
)
from semapp.Layout.settings import SettingsWindow
from semapp.Layout.tool_detection import (
    check_complus4t_in_dirname,
    check_kronos_in_dirname,
    check_sp3_in_dirname,
    check_sica_in_dirname,
    is_sica_format,
    organize_sica_files_automatically,
    organize_complus4t_files_automatically,
    organize_sp3_files_automatically,
    organize_kronos_files_automatically,
    launch_detection_automatically
)

class ButtonFrame(QWidget):
    """Class to create the various buttons of the interface"""

    def __init__(self, layout):
        super().__init__()
        self.layout = layout
        self.folder_path = None
        self.check_vars = {}
        self.common_class = None
        self.folder_path_label = None
        self.radio_vars = {} 
        self.selected_option = None
        self.selected_image = None
        self.table_data = None
        self.table_vars = None
        self.image_slider = None  # Slider for COMPLUS4T mode
        self.slider_value = 0  # Current slider value
        self.image_group_box = None  # Store reference to image type group box
        self.plot_frame = None  # Reference to plot frame for updates
        self.frame_wafer = None  # Store reference to "Functions (Wafer)" group box
        self.frame_lot = None  # Store reference to "Functions (Lot)" group box
        self.frame_other = None  # Store reference to "Functions (Other)" group box
        self.frame_dir = None  # Store reference to "Directory" group box
        self.wafer_group_box = None  # Store reference to "Wafer Slots" group box
        
        # Threshold slider components
        self.threshold_slider = None  # Slider for threshold (0-255)
        self.threshold_value = 255  # Current threshold value (default 255)
        self.threshold_label = None  # Label for threshold value
        
        # Min size slider components
        self.min_size_slider = None  # Slider for minimum particle size (1-100)
        self.min_size_value = 2  # Current min size value
        self.min_size_label = None  # Label for min size value
        
        # Store references to all buttons for enabling/disabling
        self.all_buttons = []
        self.all_radio_buttons = []

        self.split_rename = QRadioButton("Split .tif and rename (w/ tag)")
        self.split_rename_all = QRadioButton("Split .tif and rename (w/ tag)")
        self.clean = QRadioButton("Clean")
        self.clean_all = QRadioButton("Clean Batch")
        self.create_folder = QRadioButton("Create folders")
        
        # New threshold and mapping buttons
        self.threshold = QRadioButton("Threshold")
        self.mapping = QRadioButton("Mapping")
        self.threshold_all = QRadioButton("Threshold")
        self.mapping_all = QRadioButton("Mapping")
        
        self.line_edits = {}

        tool_radiobuttons = [self.split_rename,
                             self.split_rename_all, self.clean_all,
                             self.create_folder, self.threshold, self.mapping,
                             self.threshold_all, self.mapping_all, self.clean]

        for radiobutton in tool_radiobuttons:
            radiobutton.setStyleSheet(RADIO_BUTTON_STYLE)
            # Store reference for enabling/disabling
            self.all_radio_buttons.append(radiobutton)
        

        # Example of adding them to a layout
        self.entries = {}
        self.dirname = None
        # self.dirname = None

        # Initialize display_text to avoid AttributeError
        self.display_text = ""
        max_characters = 30  # Set character limit
        if self.dirname:
            self.display_text = self.dirname if len(
                self.dirname) <= max_characters else self.dirname[
                                                     :max_characters] + '...'

        # Get the user's folder path (C:\Users\XXXXX)
        self.user_folder = os.path.expanduser(
            "~")  # This gets C:\Users\XXXXX

        # Define the new folder you want to create
        self.new_folder = os.path.join(self.user_folder, "SEM")


        # Create the folder if it doesn't exist
        self.create_directory(self.new_folder)

        self.button_group = QButtonGroup(self)

        self.init_ui()

    def create_directory(self, path):
        """Create the directory if it does not exist."""
        if not os.path.exists(path):
            os.makedirs(path)

    def init_ui(self):
        """Initialize the user interface"""
        # Add widgets to the grid layout provided by the main window

        self.settings_window = SettingsWindow()
        self.dir_box()
        self.create_wafer()
        self.create_radiobuttons_other()
        # Only create Wafer and Lot radio buttons if not in SP3/SICA mode
        # (they will be created later when folder is selected if needed)
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        if not (is_sp3 or is_sica):
            self.create_radiobuttons()
            self.create_radiobuttons_all()
        self.image_radiobuttons()
        self.create_threshold_slider()
        self.add_settings_button()
        self.create_run_button()
        self.update_wafer()
        self.settings_window.data_updated.connect(self.refresh_radiobuttons)


    def add_settings_button(self):
        """Add a Settings button that opens a new dialog"""
        self.settings_button = QPushButton("Settings")
        self.settings_button.setStyleSheet(SETTINGS_BUTTON_STYLE)
        self.settings_button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.settings_button.clicked.connect(self.open_settings_window)
        
        # Store reference for enabling/disabling
        self.all_buttons.append(self.settings_button)

        self.layout.addWidget(self.settings_button, 0, 4, 1, 1)
        
        # Hide Settings button for COMPLUS4T and SP3/SICA modes
        self._update_settings_button_visibility()

    def open_settings_window(self):
        """Open the settings window"""

        self.settings_window.exec_()

    def dir_box(self):
        """Create a smaller directory selection box"""

        # Create layout for this frame
        frame_dir = QGroupBox("Directory")
        self.frame_dir = frame_dir  # Store reference
        frame_dir.setStyleSheet(GROUP_BOX_STYLE)
        
        # Check mode for sizing
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        
        # Reduce size for SP3/SICA mode
        if is_sp3 or is_sica:
            frame_dir.setMaximumWidth(250)  # Smaller width for SP3/SICA mode

        # Button for selecting folder
        self.select_folder_button = QPushButton("Select Parent Folder...")
        self.select_folder_button.setStyleSheet(SELECT_BUTTON_STYLE)
        
        # Store reference for enabling/disabling
        self.all_buttons.append(self.select_folder_button)

        # Create layout for the frame and reduce its margins
        frame_dir_layout = QGridLayout()
        frame_dir_layout.setContentsMargins(5, 20, 5, 5)  # Reduced margins
        frame_dir.setLayout(frame_dir_layout)

        # label for folder path
        if self.dirname:
            # Recalculate display_text if dirname exists
            max_characters = 30  # Set character limit
            display_text = self.dirname if len(
                self.dirname) <= max_characters else self.dirname[
                                                     :max_characters] + '...'
            self.display_text = display_text
            self.folder_path_label = QLabel(self.display_text)
        else:
            self.folder_path_label = QLabel()

        self.folder_path_label.setStyleSheet(PATH_LABEL_STYLE)

        # Connect the button to folder selection method
        self.select_folder_button.clicked.connect(self.on_select_folder_and_update)

        # Add widgets to layout
        frame_dir_layout.addWidget(self.select_folder_button, 0, 0, 1, 1)
        frame_dir_layout.addWidget(self.folder_path_label, 1, 0, 1, 1)

        # Check mode for layout positioning
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        
        # Add frame to the main layout - different position for SP3/SICA mode
        if is_sp3 or is_sica:
            self.layout.addWidget(frame_dir, 0, 0, 2, 1)  # (0,0,2,1) for SP3/SICA
        else:
            self.layout.addWidget(frame_dir, 0, 0)  # Normal position

    def folder_var_changed(self):
        """Update parent folder"""
        return self.dirname

    def on_select_folder_and_update(self):
        """Method to select folder and update checkbuttons"""
        # Store old directory for comparison
        old_dirname = self.dirname
        
        # First, select the new folder
        self.select_folder()
        
        # Check for SP3 and organize files + extract/compress automatically if found
        is_sp3_before = self._check_sp3_in_dirname()
        if is_sp3_before:
            # First, organize files into subdirectories
            organize_sp3_files_automatically(self.dirname)
            QApplication.processEvents()
            
            # Then, extract and compress SP3 data automatically
            try:
                print("\n" + "="*60)
                print("SP3 DETECTED - Extracting and compressing data automatically")
                print("="*60)
                metadata, defects = extract_sp3_from_directory(self.dirname, output_dir=self.dirname)
                if metadata is not None:
                    print(f"✓ Metadata extracted: {len(metadata)} lines")
                if defects is not None and not defects.empty:
                    print(f"✓ Defects database created: {len(defects)} defects")
                print("="*60 + "\n")
            except Exception as e:
                print(f"Error during SP3 extraction: {e}")
                import traceback
                traceback.print_exc()
            QApplication.processEvents()
        
        # Check for SICA and organize files + extract/compress automatically if found
        is_sica_before = self._check_sica_in_dirname()
        if is_sica_before:
            # First, organize files into subdirectories
            organize_sica_files_automatically(self.dirname)
            QApplication.processEvents()
            
            # Then, extract and compress SICA data automatically (uses same function as SP3)
            try:
                print("\n" + "="*60)
                print("SICA DETECTED - Extracting and compressing data automatically")
                print("="*60)
                metadata, defects = extract_sp3_from_directory(self.dirname, output_dir=self.dirname)
                if metadata is not None:
                    print(f"✓ Metadata extracted: {len(metadata)} lines")
                if defects is not None and not defects.empty:
                    print(f"✓ Defects database created: {len(defects)} defects")
                print("="*60 + "\n")
            except Exception as e:
                print(f"Error during SICA extraction: {e}")
                import traceback
                traceback.print_exc()
            QApplication.processEvents()
        
        # Check for COMPLUS4T and create folders + mapping.csv for all wafers automatically
        is_complus4t_before = self._check_complus4t_in_dirname()
        if is_complus4t_before:
            organize_complus4t_files_automatically(self.dirname)
            QApplication.processEvents()
        
        # Refresh radio buttons and settings button visibility based on mode
        # This recreates widgets, so must be done before updating wafer styles
        self._refresh_ui_for_mode()
        
        # Update wafer buttons AFTER all file organization and UI refresh is complete
        # This ensures wafers are detected from subdirectories or defects_database
        # and styles are applied to the newly created radio buttons
        self.update_wafer()
        
        # Update Overview button position in PlotFrame if it exists
        if self.plot_frame and hasattr(self.plot_frame, '_position_overview_button'):
            self.plot_frame._position_overview_button()
        
        # Process events to ensure UI updates
        QApplication.processEvents()
        
        # Check for KRONOS and organize files if found
        if self._check_kronos_in_dirname():
            organize_kronos_files_automatically(self.dirname)
            launch_detection_automatically(self.dirname)
            QApplication.processEvents()
            # Update wafer buttons again after KRONOS organization
            self.update_wafer()
        
        # After ALL file organization, extraction, and UI updates, re-detect mode
        # This ensures the correct mode instance is created for the new directory
        # Must be done AFTER all operations including KRONOS
        if self.plot_frame:
            # Re-detect mode when directory changes (AFTER all file operations and UI updates)
            if hasattr(self.plot_frame, '_recreate_mode_instance_if_needed'):
                try:
                    self.plot_frame._recreate_mode_instance_if_needed()
                except Exception:
                    pass

    def update_wafer(self):
        """Update the appearance of radio buttons based on the existing
        subdirectories in the specified directory."""
        if self.dirname:
            # List the subdirectories in the specified directory
            subdirs = [d for d in os.listdir(self.dirname) if
                       os.path.isdir(os.path.join(self.dirname, d))]

            # Check for SP3/SICA mode - detect wafers from defects_database
            wafer_ids = []
            is_sp3 = self._check_sp3_in_dirname()
            is_sica = self._check_sica_in_dirname()
            
            if is_sp3 or is_sica:
                # For SP3/SICA, load wafers from defects_database
                wafer_ids = self._get_wafer_ids_from_defects_database()
            elif not subdirs:
                # If there are no subdirectories, search for wafers in KLARF files
                wafer_ids = self.extract_wafer_ids_from_klarf()

            # Update the style of radio buttons based on the subdirectory presence
            for number in range(1, 27):
                radio_button = self.radio_vars.get(number)
                if radio_button:
                    # Check if wafer exists: either in subdirs OR in wafer_ids
                    wafer_exists = str(number) in subdirs or number in wafer_ids
                    if wafer_exists:
                        radio_button.setStyleSheet(WAFER_BUTTON_EXISTING_STYLE)
                    else:
                        radio_button.setStyleSheet(WAFER_BUTTON_MISSING_STYLE)
        else:
            # Default style for all radio buttons if no directory is specified
            for number in range(1, 27):
                radio_button = self.radio_vars.get(number)
                if radio_button:
                    radio_button.setStyleSheet(WAFER_BUTTON_MISSING_STYLE)
    
    def _get_wafer_ids_from_defects_database(self):
        """Extract wafer IDs from defects_database for SP3/SICA modes."""
        wafer_ids = []
        
        if not self.dirname:
            return wafer_ids
        
        try:
            import pandas as pd
            
            # Try to load defects_database (parquet, csv.gz, or csv)
            parquet_path = os.path.join(self.dirname, "defects_database.parquet")
            csv_gz_path = os.path.join(self.dirname, "defects_database.csv.gz")
            csv_path = os.path.join(self.dirname, "defects_database.csv")
            
            defects_df = None
            
            if os.path.exists(parquet_path):
                try:
                    defects_df = pd.read_parquet(parquet_path)
                except Exception:
                    pass
            
            if defects_df is None and os.path.exists(csv_gz_path):
                try:
                    defects_df = pd.read_csv(csv_gz_path, compression='gzip')
                except Exception:
                    pass
            
            if defects_df is None and os.path.exists(csv_path):
                try:
                    defects_df = pd.read_csv(csv_path)
                except Exception:
                    pass
            
            if defects_df is not None and 'wafer_id' in defects_df.columns:
                # Get unique wafer IDs
                unique_wafers = defects_df['wafer_id'].unique()
                wafer_ids = [int(w) for w in unique_wafers if 1 <= int(w) <= 26]
                wafer_ids = sorted(list(set(wafer_ids)))  # Remove duplicates and sort
                
        except Exception:
            pass
        
        return wafer_ids

    def extract_wafer_ids_from_klarf(self):
        """Extract wafer IDs from KLARF files (.001) that contain COMPLUS4T, SP3, or SICA."""
        wafer_ids = []
        
        if not self.dirname:
            return wafer_ids
        
        # Search for .001 files
        try:
            files = [f for f in os.listdir(self.dirname) 
                    if f.endswith('.001') and os.path.isfile(os.path.join(self.dirname, f))]
            
            for file in files:
                file_path = os.path.join(self.dirname, file)
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                        
                        # Check if file contains "COMPLUS4T"
                        if 'COMPLUS4T' in content:
                            # Search for all lines with WaferID
                            # Pattern to extract number in quotes after WaferID
                            pattern = r'WaferID\s+"@(\d+)"'
                            matches = re.findall(pattern, content)
                            
                            # Add found IDs (converted to int)
                            for match in matches:
                                wafer_id = int(match)
                                if wafer_id not in wafer_ids and 1 <= wafer_id <= 26:
                                    wafer_ids.append(wafer_id)
                        
                        # Check if file contains "SP3"
                        elif 'SP3' in content:
                            # Search for all lines with WaferID (various formats for SP3)
                            patterns = [
                                r'WaferID\s+"(\d+)"',  # WaferID "11"
                                r'WaferID\s+(\d+)',    # WaferID 11
                                r'WaferID\s+"@(\d+)"', # WaferID "@11"
                            ]
                            
                            for pattern in patterns:
                                matches = re.findall(pattern, content)
                                for match in matches:
                                    wafer_id = int(match)
                                    if wafer_id not in wafer_ids and 1 <= wafer_id <= 26:
                                        wafer_ids.append(wafer_id)
                        
                        # Check if file contains "SICA" (in InspectionStationID or format)
                        elif 'SICA' in content or is_sica_format(content):
                            # Search for all lines with WaferID (SICA format: "waferIDnumber23" or Slot)
                            patterns = [
                                r'WaferID\s+"[^"]*(\d+)[^"]*"',  # WaferID "waferIDnumber23" (SICA format)
                                r'WaferID\s+"(\d+)"',  # WaferID "11"
                                r'WaferID\s+(\d+)',    # WaferID 11
                                r'Slot\s+(\d+)',       # Slot 23 (fallback for SICA)
                            ]
                            
                            for pattern in patterns:
                                matches = re.findall(pattern, content)
                                for match in matches:
                                    wafer_id = int(match)
                                    if wafer_id not in wafer_ids and 1 <= wafer_id <= 26:
                                        wafer_ids.append(wafer_id)
                except Exception as e:
                    pass  # Error reading file
        
        except Exception as e:
            pass  # Error listing files
        
        return wafer_ids

    def create_wafer(self):
        """Create a grid of radio buttons for wafer slots with exclusive selection."""
        group_box = QGroupBox("Wafer Slots")  # Add a title to the group
        self.wafer_group_box = group_box  # Store reference
        group_box.setStyleSheet(GROUP_BOX_STYLE)  
        
        # Check mode for sizing
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        
        # Adjust size for SP3/SICA mode - make it more compact
        if is_sp3 or is_sica:
            group_box.setMaximumWidth(750)  # Wider width for SP3/SICA mode to show all checkboxes

        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)  # Reduce internal margins
        wafer_layout.setSpacing(5)  # Reduce spacing between widgets

        

        # Add radio buttons from 1 to 24, with 12 buttons per row
        for number in range(1, 27):
            radio_button = QRadioButton(str(number))
            radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)

            # Connect the radio button to a handler for exclusive selection
            radio_button.toggled.connect(self.get_selected_option)
            self.radio_vars[number] = radio_button

            # Calculate the row and column for each radio button in the layout
            row = (number - 1) // 13  # Row starts at 0
            col = (number - 1) % 13  # Column ranges from 0 to 12

            wafer_layout.addWidget(radio_button, row, col)

        group_box.setLayout(wafer_layout)

        # Check mode for layout positioning
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        
        # Add the QGroupBox to the main layout - different position for SP3/SICA mode
        if is_sp3 or is_sica:
            self.layout.addWidget(group_box, 0, 2, 2, 2)  # (0,2,2,2) for SP3/SICA - takes 2 columns
        else:
            self.layout.addWidget(group_box, 1, 0, 2, 3)  # Normal position
        


    def get_selected_option(self):
        """Ensure only one radio button is selected at a time and track the selected button."""
        selected_number = None  # Variable to store the selected radio button number

        # Iterate over all radio buttons
        for number, radio_button in self.radio_vars.items():
            if radio_button.isChecked():
                selected_number = number  # Track the currently selected radio button

        if selected_number is not None:
            # Only trigger auto-open if the wafer has actually changed
            wafer_changed = (self.selected_option != selected_number)
            self.selected_option = selected_number  # Store the selected option for further use
            
            # Print selected wafer number
            if wafer_changed:
                print(f"Wafer {selected_number}")
            
            # Check if auto_open_wafer exists (try direct access first, then hasattr)
            has_auto_open = False
            if self.plot_frame:
                try:
                    # Try to get the method directly
                    method = getattr(self.plot_frame, 'auto_open_wafer', None)
                    has_auto_open = callable(method)
                except Exception:
                    pass
            
            # Automatically open TIFF or plot mapping when wafer is selected (only if changed)
            if wafer_changed and self.plot_frame:
                try:
                    if has_auto_open:
                        # Use QTimer.singleShot to avoid blocking the UI during selection
                        from PyQt5.QtCore import QTimer
                        QTimer.singleShot(100, self.plot_frame.auto_open_wafer)
                except Exception:
                    pass
            
            return self.selected_option

    def image_radiobuttons(self):
        """Create a grid of radio buttons or slider for image type selection."""
        # Remove old widget if it exists
        if self.image_group_box is not None:
            self.layout.removeWidget(self.image_group_box)
            self.image_group_box.deleteLater()
            self.image_group_box = None
        
        # Reset variables
        self.image_slider = None
        self.table_vars = None
        # Initialize slider_value based on mode (will be set correctly below)
        self.slider_value = 0
        
        # Check if COMPLUS4T mode
        is_complus4t = self._check_complus4t_in_dirname()
        # Check if KRONOS mode
        is_kronos = self._check_kronos_in_dirname()
        # Check if SP3 mode
        is_sp3 = self._check_sp3_in_dirname()
        # Check if SICA mode
        is_sica = self._check_sica_in_dirname()
        
        # Store SP3/SICA mode for later use
        self.is_sp3_mode = is_sp3 or is_sica
        
        # Change title based on mode - use nm for SP3/SICA, um for others
        if is_complus4t or is_kronos or is_sp3 or is_sica:
            if is_sp3 or is_sica:
                title = "Defect Size (nm)"
            else:
                title = "Defect Size (um)"
        else:
            title = "Image type"
        group_box = QGroupBox(title)
        group_box.setStyleSheet(GROUP_BOX_STYLE)
        self.image_group_box = group_box
        
        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)
        wafer_layout.setSpacing(5)
        
        if is_complus4t or is_kronos or is_sp3 or is_sica:
            # COMPLUS4T/KRONOS/SP3/SICA mode: create slider
            # For SP3/SICA mode, use vertical slider
            if is_sp3 or is_sica:
                self.image_slider = QSlider(Qt.Vertical)
            else:
                self.image_slider = QSlider(Qt.Horizontal)
            
            if is_sp3 or is_sica:
                # SP3/SICA: slider from 50 nm to 1000 nm (1 µm)
                self.image_slider.setMinimum(50)
                self.image_slider.setMaximum(1000)
                self.image_slider.setValue(50)
                self.image_slider.setTickPosition(QSlider.TicksRight)  # Ticks on the right for vertical slider
                self.image_slider.setTickInterval(100)  # Tick every 100 nm
                initial_value = 50
                self.slider_value = 50  # Initialize slider_value
                unit = "nm"
            else:
                # COMPLUS4T/KRONOS: slider from 0 to 100
                self.image_slider.setMinimum(0)
                self.image_slider.setMaximum(100)
                self.image_slider.setValue(0)
                self.image_slider.setTickPosition(QSlider.TicksBelow)
                self.image_slider.setTickInterval(10)
                initial_value = 0
                self.slider_value = 0  # Initialize slider_value
                unit = "um"
            # Enable clicking directly on the slider track
            self.image_slider.setPageStep(1)  # Allow single step jumps when clicking
            # Connect valueChanged for label update only (real-time)
            self.image_slider.valueChanged.connect(self.on_slider_value_changed)
            # Connect sliderReleased for plot update (only when released)
            self.image_slider.sliderReleased.connect(self.on_slider_released)
            
            self.slider_value_label = QLabel(f"{initial_value} {unit}")
            self.slider_value_label.setStyleSheet("color: black; font-size: 20px; font-weight: bold; background-color: white;")
            self.slider_value_label.setFixedWidth(80)  # Fixed width for label
            
            if is_sp3 or is_sica:
                # Vertical slider layout: label on top, slider below
                wafer_layout.addWidget(self.slider_value_label, 0, 0, 1, 1)
                wafer_layout.addWidget(self.image_slider, 1, 0, 1, 1)
            else:
                # Horizontal slider layout: slider and label side by side
                wafer_layout.addWidget(self.image_slider, 0, 0, 1, 1)
                wafer_layout.addWidget(self.slider_value_label, 0, 1, 1, 1)
        else:
            # Normal mode: create radio buttons
            self.table_data = self.settings_window.get_table_data()
            number = len(self.table_data)
            
            self.table_vars = {}
            
            for i in range(number):
                label = str(self.table_data[i]["Scale"]) + " - " + str(
                    self.table_data[i]["Image Type"])
                radio_button = QRadioButton(label)
                radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
                radio_button.toggled.connect(self.get_selected_image)
                self.table_vars[i] = radio_button
                
                row = (i) // 4
                col = (i) % 4
                wafer_layout.addWidget(radio_button, row, col)
        
        group_box.setLayout(wafer_layout)
        
        # For SP3/SICA mode, position at (0,5,4,1) - takes 4 rows, 1 column
        # For COMPLUS4T, use 1 column starting from column 3
        # For other modes (KRONOS, normal), use column 4 with 1 column width
        if is_sp3 or is_sica:
            self.layout.addWidget(group_box, 0, 5, 4, 1)  # (0,5,4,1) for SP3/SICA
        elif is_complus4t:
            self.layout.addWidget(group_box, 1, 3, 2, 1)  # Takes 2 rows, 1 column starting from column 3
        else:
            self.layout.addWidget(group_box, 1, 4, 2, 1)  # Takes 2 rows, 1 column at column 4
    
    def create_threshold_slider(self):
        """Create a threshold slider for image processing (1-255)."""
        # Check if SP3, SICA, or COMPLUS4T mode - don't create threshold slider for these modes
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        is_complus4t = self._check_complus4t_in_dirname()
        if is_sp3 or is_sica or is_complus4t:
            # Remove old threshold slider if it exists
            if self.threshold_slider is not None or self.min_size_slider is not None:
                # Find and remove the threshold group box from layout
                for i in range(self.layout.count()):
                    widget = self.layout.itemAt(i).widget()
                    if widget and hasattr(widget, 'title') and widget.title() == "Threshold":
                        self.layout.removeWidget(widget)
                        widget.deleteLater()
                        break
            # Reset variables
            self.threshold_slider = None
            self.min_size_slider = None
            return  # Don't create threshold slider for SP3
        
        # Remove old threshold slider if it exists
        if self.threshold_slider is not None or self.min_size_slider is not None:
            # Find and remove the threshold group box from layout
            for i in range(self.layout.count()):
                widget = self.layout.itemAt(i).widget()
                if widget and hasattr(widget, 'title') and widget.title() == "Threshold":
                    self.layout.removeWidget(widget)
                    widget.deleteLater()
                    break
        
        group_box = QGroupBox("Threshold")
        group_box.setStyleSheet(GROUP_BOX_STYLE)
        
        threshold_layout = QGridLayout()
        threshold_layout.setContentsMargins(2, 20, 2, 2)
        threshold_layout.setSpacing(5)
        
        # Create threshold slider (0-255)
        self.threshold_slider = QSlider(Qt.Horizontal)
        self.threshold_slider.setMinimum(0)
        self.threshold_slider.setMaximum(255)
        self.threshold_slider.setTickPosition(QSlider.TicksBelow)
        self.threshold_slider.setTickInterval(25)
        
        # Initialize threshold value and label BEFORE connecting signal
        self.threshold_value = 255  # Initialize threshold value to match slider default
        self.threshold_label = QLabel("255")
        self.threshold_label.setStyleSheet("color: black; font-size: 20px; font-weight: bold; background-color: #F5F5F5;")
        self.threshold_label.setFixedWidth(50)  # Fixed width for label
        
        # Connect signals: valueChanged for label update only (real-time)
        # sliderReleased for image update (only when released)
        self.threshold_slider.valueChanged.connect(self.on_threshold_value_changed)
        self.threshold_slider.sliderReleased.connect(self.on_threshold_released)
        
        # Set slider value AFTER connecting signal
        self.threshold_slider.setValue(255)  # Default threshold
        
        # Create label for threshold range (0-255) to the right of value label
        self.threshold_range_label = QLabel("(0-255)")
        self.threshold_range_label.setStyleSheet("color: black; font-size: 20px; background-color: #F5F5F5;")
        
        # Create min size slider (1-100)
        self.min_size_slider = QSlider(Qt.Horizontal)
        self.min_size_slider.setMinimum(1)
        self.min_size_slider.setMaximum(100)
        self.min_size_slider.setValue(2)  # Default min size
        self.min_size_slider.setTickPosition(QSlider.TicksBelow)
        self.min_size_slider.setTickInterval(10)
        # Connect signals: valueChanged for label update only (real-time)
        # sliderReleased for image update (only when released)
        self.min_size_slider.valueChanged.connect(self.on_min_size_value_changed)
        self.min_size_slider.sliderReleased.connect(self.on_min_size_released)
        
        # Create label for min size value (to the right of slider)
        self.min_size_label = QLabel("2")
        self.min_size_label.setStyleSheet("color: black; font-size: 20px; font-weight: bold; background-color: #F5F5F5;")
        self.min_size_label.setFixedWidth(50)  # Fixed width for label
        
        # Create label for min size unit (um) to the right of value label
        self.min_size_unit_label = QLabel("(um)")
        self.min_size_unit_label.setStyleSheet("color: black; font-size: 20px; background-color: #F5F5F5;")
        
        # Add widgets to layout - labels to the right
        threshold_layout.addWidget(self.threshold_slider, 0, 0, 1, 1)
        threshold_layout.addWidget(self.threshold_label, 0, 1, 1, 1)
        threshold_layout.addWidget(self.threshold_range_label, 0, 2, 1, 1)
        threshold_layout.addWidget(self.min_size_slider, 1, 0, 1, 1)
        threshold_layout.addWidget(self.min_size_label, 1, 1, 1, 1)
        threshold_layout.addWidget(self.min_size_unit_label, 1, 2, 1, 1)
        
        group_box.setLayout(threshold_layout)
        
        # Add to main layout in position (1,3,2,1) - takes 2 rows
        self.layout.addWidget(group_box, 1, 3, 2, 1)
    
    def on_threshold_value_changed(self, value):
        """Handle threshold slider value changes - update label only (real-time)."""
        self.threshold_value = value
        self.threshold_label.setText(str(value))
    
    def on_threshold_released(self):
        """Handle threshold slider release - update image (only when released)."""
        # Trigger plot update if plot_frame is available
        if self.plot_frame and hasattr(self.plot_frame, '_update_plot'):
            self.plot_frame._update_plot()
        
        # Trigger image update if plot_frame is available
        if self.plot_frame and hasattr(self.plot_frame, 'show_image'):
            self.plot_frame.show_image()
    
    def on_min_size_value_changed(self, value):
        """Handle min size slider value changes - update label only (real-time)."""
        self.min_size_value = value
        self.min_size_label.setText(str(value))
    
    def on_min_size_released(self):
        """Handle min size slider release - update image (only when released)."""
        # Trigger plot update if plot_frame is available
        if self.plot_frame and hasattr(self.plot_frame, '_update_plot'):
            self.plot_frame._update_plot()
        
        # Trigger image update if plot_frame is available
        if self.plot_frame and hasattr(self.plot_frame, 'show_image'):
            self.plot_frame.show_image()
    
    
    def get_threshold_value(self):
        """Get the current threshold value."""
        return self.threshold_value
    
    def get_min_size_value(self):
        """Get the current min size value."""
        return self.min_size_value
    
    def get_processing_parameters(self):
        """Get all processing parameters including threshold and min size."""
        return {
            'threshold': self.threshold_value,
            'min_size': self.min_size_value,
            'defect_size_threshold': self.slider_value if self.image_slider else None
        }
    
    def _check_complus4t_in_dirname(self):
        """Check if COMPLUS4T is present - wrapper for tool_detection module."""
        return check_complus4t_in_dirname(self.dirname)
    
    def _check_kronos_in_dirname(self):
        """Check if KRONOS is present - wrapper for tool_detection module."""
        return check_kronos_in_dirname(self.dirname)
    
    def _check_sp3_in_dirname(self):
        """Check if SP3 is present - wrapper for tool_detection module."""
        return check_sp3_in_dirname(self.dirname)
    
    def _check_sica_in_dirname(self):
        """Check if SICA is present - wrapper for tool_detection module."""
        return check_sica_in_dirname(self.dirname)
    
    def _is_sica_format(self, content):
        """Check if content matches SICA format - wrapper for tool_detection module."""
        return is_sica_format(content)
    
    def on_slider_value_changed(self, value):
        """Handle slider value changes - update label only (real-time)."""
        self.slider_value = value
        
        # Use nm for SP3/SICA, um for others
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        unit = "nm" if (is_sp3 or is_sica) else "um"
        self.slider_value_label.setText(f"{value} {unit}")
        
        # Do NOT update histogram/mapping in real-time - only update label
    
    def on_slider_released(self):
        """Handle slider release - update plot, histogram, and mappings when slider is released."""
        # Trigger plot refresh if plot_frame exists
        if self.plot_frame is not None:
            self.plot_frame._update_plot()
            # Update histogram and mappings if in SP3/SICA mode (only when released)
            is_sp3 = self._check_sp3_in_dirname()
            is_sica = self._check_sica_in_dirname()
            if is_sp3 or is_sica:
                if hasattr(self.plot_frame, 'is_sp3_mode') and self.plot_frame.is_sp3_mode:
                    self.plot_frame._create_defect_size_histogram()
                # Also update mappings when slider is released
                if hasattr(self.plot_frame, '_update_plot'):
                    self.plot_frame._update_plot()

    def refresh_radiobuttons(self):
        """Recreates the radio buttons after updating the data in Settings."""
        self.image_radiobuttons()  # Call your method to recreate the radio buttons
    
    def _update_settings_button_visibility(self):
        """Update Settings button visibility based on mode."""
        if not hasattr(self, 'settings_button'):
            return
        
        is_complus4t = self._check_complus4t_in_dirname()
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        
        # Hide Settings button for COMPLUS4T and SP3/SICA modes
        if is_complus4t or is_sp3 or is_sica:
            self.settings_button.setVisible(False)
        else:
            self.settings_button.setVisible(True)
    
    def _refresh_ui_for_mode(self):
        """Refresh UI elements visibility based on current mode."""
        # Update Settings button visibility
        self._update_settings_button_visibility()
        
        # Check mode
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        
        # Remove existing "Functions (Wafer)" and "Functions (Lot)" group boxes if they exist
        # These should be completely hidden in SP3/SICA mode
        # First, try to find and remove them from the layout
        widgets_to_find_and_remove = []
        for i in range(self.layout.count()):
            item = self.layout.itemAt(i)
            if item and item.widget():
                widget = item.widget()
                if isinstance(widget, QGroupBox):
                    if widget.title() in ["Functions (Wafer)", "Functions (Lot)"]:
                        widgets_to_find_and_remove.append(widget)
        
        # Remove found widgets
        for widget in widgets_to_find_and_remove:
            try:
                self.layout.removeWidget(widget)
                widget.setParent(None)
                widget.deleteLater()
            except (RuntimeError, AttributeError):
                pass
        
        # Clear references
        if is_sp3 or is_sica:
            self.frame_wafer = None
            self.frame_lot = None
            
            # Remove buttons from button group for SP3/SICA mode
            try:
                if self.threshold in self.button_group.buttons():
                    self.button_group.removeButton(self.threshold)
                if self.mapping in self.button_group.buttons():
                    self.button_group.removeButton(self.mapping)
                if self.threshold_all in self.button_group.buttons():
                    self.button_group.removeButton(self.threshold_all)
                if self.mapping_all in self.button_group.buttons():
                    self.button_group.removeButton(self.mapping_all)
            except (RuntimeError, AttributeError):
                pass
        else:
            # Also remove if they exist but we're not in SP3/SICA mode (cleanup)
            if self.frame_wafer is not None:
                try:
                    self.layout.removeWidget(self.frame_wafer)
                    self.frame_wafer.setParent(None)
                    self.frame_wafer.deleteLater()
                except (RuntimeError, AttributeError):
                    pass
                self.frame_wafer = None
            
            if self.frame_lot is not None:
                try:
                    self.layout.removeWidget(self.frame_lot)
                    self.frame_lot.setParent(None)
                    self.frame_lot.deleteLater()
                except (RuntimeError, AttributeError):
                    pass
                self.frame_lot = None
        
        # Remove existing group boxes if they exist to reposition them
        # Also find and remove Run Function button by searching the layout
        widgets_to_remove = []
        
        # Find Run Function button in layout
        for i in range(self.layout.count()):
            item = self.layout.itemAt(i)
            if item and item.widget():
                widget = item.widget()
                if isinstance(widget, QPushButton):
                    # Check if it's the Run Function button by its text
                    if hasattr(widget, 'text') and widget.text() == "Run function":
                        widgets_to_remove.append(widget)
        
        # Add other widgets to remove
        if self.frame_other is not None:
            widgets_to_remove.append(self.frame_other)
        if self.frame_dir is not None:
            widgets_to_remove.append(self.frame_dir)
        if self.wafer_group_box is not None:
            widgets_to_remove.append(self.wafer_group_box)
        if self.image_group_box is not None:
            widgets_to_remove.append(self.image_group_box)
        if hasattr(self, 'run_button') and self.run_button is not None:
            # Only add if not already in the list
            if self.run_button not in widgets_to_remove:
                widgets_to_remove.append(self.run_button)
        
        # Remove all widgets from layout
        for widget in widgets_to_remove:
            if widget:
                try:
                    self.layout.removeWidget(widget)
                    widget.setParent(None)
                    widget.deleteLater()
                except (RuntimeError, AttributeError):
                    pass
        
        # Reset references
        self.frame_other = None
        self.frame_dir = None
        self.wafer_group_box = None
        self.image_group_box = None
        if hasattr(self, 'run_button'):
            self.run_button = None
        
        # Recreate radio buttons if they were deleted (Qt deletes child widgets when parent is deleted)
        # Check if radio buttons still exist, if not, recreate them
        def safe_recreate_radio(attr_name, text):
            """Safely recreate a radio button if it was deleted."""
            try:
                existing = getattr(self, attr_name, None)
                # Try to access a property to check if object still exists
                if existing is None:
                    setattr(self, attr_name, QRadioButton(text))
                else:
                    try:
                        _ = existing.text()  # Try to access property
                    except (RuntimeError, AttributeError):
                        # Object was deleted, recreate it
                        setattr(self, attr_name, QRadioButton(text))
            except (RuntimeError, AttributeError):
                setattr(self, attr_name, QRadioButton(text))
        
        safe_recreate_radio('threshold', "Threshold")
        safe_recreate_radio('mapping', "Mapping")
        safe_recreate_radio('threshold_all', "Threshold")
        safe_recreate_radio('mapping_all', "Mapping")
        safe_recreate_radio('split_rename', "Split .tif and rename (w/ tag)")
        safe_recreate_radio('split_rename_all', "Split .tif and rename (w/ tag)")
        
        # Recreate widgets with correct positions
        self.dir_box()
        self.create_radiobuttons_other()
        self.create_wafer()
        self.image_radiobuttons()
        self.create_threshold_slider()  # Recreate threshold slider
        self.create_run_button()
        
        # Recreate radio buttons with correct visibility (only if not SP3/SICA)
        # These GroupBox should NOT exist in SP3/SICA mode
        if not (is_sp3 or is_sica):
            self.create_radiobuttons()
            self.create_radiobuttons_all()
        else:
            # Ensure they are None in SP3/SICA mode
            self.frame_wafer = None
            self.frame_lot = None

    def get_selected_image(self):
        """Track the selected radio button or slider value."""
        # Check if in COMPLUS4T mode (slider)
        if self.image_slider is not None:
            # Return slider value (0-100) as image type
            return self.slider_value, 1
        
        # Normal mode: radio buttons
        selected_number = None
        if self.table_vars:
            n_types = len(self.table_vars.items())
            # Iterate over all radio buttons
            for number, radio_button in self.table_vars.items():
                if radio_button.isChecked():
                    selected_number = number
            
            if selected_number is not None:
                self.selected_image = selected_number
                
                # If image type changed and there's a last clicked position, update image
                # Use a flag to prevent recursion when calling get_selected_image from _update_image_at_last_position
                if not hasattr(self, '_updating_image_position'):
                    self._updating_image_position = False
                
                if not self._updating_image_position:
                    if self.plot_frame and hasattr(self.plot_frame, 'last_clicked_position'):
                        last_pos = self.plot_frame.last_clicked_position
                        if last_pos is not None and self.plot_frame.coordinates is not None:
                            try:
                                if not self.plot_frame.coordinates.empty:
                                    # Update image at the last clicked position with new image type
                                    self._update_image_at_last_position()
                            except (AttributeError, RuntimeError):
                                pass  # Skip if coordinates is invalid
                
                return self.selected_image, n_types
        
        return None
    
    def _update_image_at_last_position(self):
        """Update the image at the last clicked position when image type changes."""
        if not self.plot_frame or not hasattr(self.plot_frame, 'last_clicked_position'):
            return
        
        last_pos = self.plot_frame.last_clicked_position
        if last_pos is None:
            return
        
        # Set flag to prevent recursion
        self._updating_image_position = True
        
        try:
            x_pos, y_pos = last_pos
            
            # Get the image type and number type directly from selected_image to avoid recursion
            if self.selected_image is None:
                return
            
            # Get n_types from table_vars
            if not self.table_vars:
                return
            
            n_types = len(self.table_vars.items())
            image_type = self.selected_image
            number_type = n_types
            self.plot_frame.image_type = image_type
            self.plot_frame.self_number_type = number_type
            
            # Find closest point to last clicked position
            coordinates = self.plot_frame.coordinates
            if coordinates is None:
                return
            
            try:
                if coordinates.empty:
                    return
            except (AttributeError, RuntimeError):
                return
            
            # Apply the same filtering as in plot_mapping_tpl
            import pandas as pd
            if 'defect_area' in coordinates.columns:
                if getattr(self.plot_frame, 'is_kronos_mode', False):
                    valid_mask = (
                        (coordinates['defect_size'] != 0.0) &
                        (~coordinates['X'].isna()) &
                        (~coordinates['Y'].isna())
                    )
                else:
                    valid_mask = (
                        (~coordinates['X'].isna()) &
                        (~coordinates['Y'].isna())
                    )
            else:
                valid_mask = (
                    (~coordinates['X'].isna()) &
                    (~coordinates['Y'].isna())
                )
            
            filtered_coords = coordinates[valid_mask]
            if len(filtered_coords) == 0:
                return
            
            # Calculate distances to find closest point
            import numpy as np
            distances = np.sqrt((filtered_coords['X'] - x_pos) ** 2 +
                               (filtered_coords['Y'] - y_pos) ** 2)
            closest_idx = distances.idxmin()
            closest_pt = filtered_coords.loc[closest_idx]
            
            # Calculate current_index based on the closest point (same logic as on_click)
            if getattr(self.plot_frame, 'is_complus4t_mode', False):
                defect_id = int(closest_pt['defect_id'])
                result = defect_id - 1
            else:
                if 'defect_id' in closest_pt:
                    defect_id = int(closest_pt['defect_id'])
                    matching_rows = coordinates[coordinates['defect_id'] == defect_id]
                    if len(matching_rows) > 0:
                        original_idx = matching_rows.index[0]
                        result = image_type + (original_idx * number_type)
                    else:
                        result = image_type + (closest_idx * number_type)
                else:
                    result = image_type + (closest_idx * number_type)
            
            self.plot_frame.current_index = result
            
            # Update image if index is valid
            if hasattr(self.plot_frame, 'image_list') and self.plot_frame.image_list:
                if 0 <= self.plot_frame.current_index < len(self.plot_frame.image_list):
                    if hasattr(self.plot_frame, 'show_image'):
                        self.plot_frame.show_image()
        finally:
            # Reset flag after update
            self._updating_image_position = False

    def create_radiobuttons(self):
        """Create radio buttons for tools and a settings button."""
        # Check mode
        is_complus4t = self._check_complus4t_in_dirname()
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        
        # Hide completely for SP3/SICA mode
        if is_sp3 or is_sica:
            return

        # Create a QGroupBox for "Functions (Wafer)"
        frame = QGroupBox("Functions (Wafer)")
        frame.setStyleSheet(GROUP_BOX_STYLE)
        self.frame_wafer = frame  # Store reference

        frame_layout = QGridLayout(frame)

        # Add radio buttons to the frame layout
        frame_layout.addWidget(self.split_rename, 0, 0)
        
        # Hide Threshold and Mapping for COMPLUS4T mode
        if not is_complus4t:
            frame_layout.addWidget(self.threshold, 1, 0)
            frame_layout.addWidget(self.mapping, 2, 0)
        else:
            # Hide Threshold and Mapping buttons for COMPLUS4T
            self.threshold.setVisible(False)
            self.mapping.setVisible(False)
        
        frame_layout.setContentsMargins(5, 20, 5, 5)
        # Add the frame to the main layout
        self.layout.addWidget(frame, 0, 2)  # Add frame to main layout

        # Add buttons to the shared button group
        self.button_group.addButton(self.split_rename)
        if not is_complus4t:
            self.button_group.addButton(self.threshold)
            self.button_group.addButton(self.mapping)

    def create_radiobuttons_all(self):
        """Create radio buttons for tools and a settings button."""
        # Check mode
        is_complus4t = self._check_complus4t_in_dirname()
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        
        # Hide completely for SP3/SICA mode
        if is_sp3 or is_sica:
            return

        # Create a QGroupBox for "Functions (Lot)"
        frame = QGroupBox("Functions (Lot)")
        frame.setStyleSheet(GROUP_BOX_STYLE)
        self.frame_lot = frame  # Store reference

        frame_layout = QGridLayout(frame)

        # Add radio buttons to the frame layout
        frame_layout.addWidget(self.split_rename_all, 0, 0)
        
        # Hide Threshold and Mapping for COMPLUS4T mode
        if not is_complus4t:
            frame_layout.addWidget(self.threshold_all, 1, 0)
            frame_layout.addWidget(self.mapping_all, 2, 0)
        else:
            # Hide Threshold and Mapping buttons for COMPLUS4T
            self.threshold_all.setVisible(False)
            self.mapping_all.setVisible(False)

        frame_layout.setContentsMargins(5, 20, 5, 5)
        # Add the frame to the main layout
        self.layout.addWidget(frame, 0, 3)  # Add frame to main layout

        # Add buttons to the shared button group
        self.button_group.addButton(self.split_rename_all)
        if not is_complus4t:
            self.button_group.addButton(self.threshold_all)
            self.button_group.addButton(self.mapping_all)

    
    def create_radiobuttons_other(self):
        """Create radio buttons for tools and a settings button."""
        # Check mode
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()

        # Create a QGroupBox - different title for SP3/SICA mode
        if is_sp3 or is_sica:
            frame = QGroupBox("Function")
        else:
            frame = QGroupBox("Functions (Other)")
        frame.setStyleSheet(GROUP_BOX_STYLE)
        self.frame_other = frame  # Store reference
        
        # Reduce size for SP3/SICA mode
        if is_sp3 or is_sica:
            frame.setMaximumWidth(150)  # Smaller width for SP3/SICA mode

        frame_layout = QGridLayout(frame)

        # Add radio buttons to the frame layout
        frame_layout.addWidget(self.create_folder, 0, 0)
        frame_layout.addWidget(self.clean, 1, 0)
        frame_layout.addWidget(self.clean_all, 2, 0)
        frame_layout.setContentsMargins(5, 20, 5, 5)

        # Add the frame to the main layout - different position for SP3/SICA mode
        if is_sp3 or is_sica:
            self.layout.addWidget(frame, 0, 1, 2, 1)  # (0,1,2,1) for SP3/SICA
        else:
            self.layout.addWidget(frame, 0, 1)  # Normal position

        # Add buttons to the shared button group
        self.button_group.addButton(self.create_folder)
        self.button_group.addButton(self.clean)
        self.button_group.addButton(self.clean_all)

    def select_folder(self):
        """Select a parent folder"""
        folder = QFileDialog.getExistingDirectory(self, "Select a Folder")

        if folder:
            self.dirname = folder
            max_characters = 30  # Set character limit (consistent with dir_box)

            # Truncate text if it exceeds the limit
            display_text = self.dirname if len(
                self.dirname) <= max_characters else self.dirname[
                                                     :max_characters] + '...'
            self.display_text = display_text  # Update display_text
            if hasattr(self, 'folder_path_label') and self.folder_path_label:
                self.folder_path_label.setText(display_text)

    def create_run_button(self):
        """Create a button to run data processing"""
        # First, remove any existing Run Function button to avoid duplicates
        # Find and remove all "Run function" buttons from layout
        buttons_to_remove = []
        for i in range(self.layout.count()):
            item = self.layout.itemAt(i)
            if item and item.widget():
                widget = item.widget()
                if isinstance(widget, QPushButton):
                    # Check if it's the Run Function button by its text
                    if hasattr(widget, 'text') and widget.text() == "Run function":
                        buttons_to_remove.append(widget)
        
        # Remove found buttons
        for button in buttons_to_remove:
            try:
                # Remove from all_buttons list if present
                if button in self.all_buttons:
                    self.all_buttons.remove(button)
                self.layout.removeWidget(button)
                button.setParent(None)
                button.deleteLater()
            except (RuntimeError, AttributeError):
                pass
        
        # Clear reference if it exists
        if hasattr(self, 'run_button') and self.run_button is not None:
            try:
                if self.run_button in self.all_buttons:
                    self.all_buttons.remove(self.run_button)
            except (RuntimeError, AttributeError, ValueError):
                pass
            self.run_button = None

        # Create the QPushButton
        self.run_button = QPushButton("Run function")
        self.run_button.setStyleSheet(RUN_BUTTON_STYLE)
        
        # Check mode for layout positioning and sizing
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        is_complus4t = self._check_complus4t_in_dirname()
        
        # Set size policy and constraints based on mode
        if is_sp3 or is_sica:
            # For SP3/SICA mode: fixed width of 250px
            self.run_button.setFixedWidth(250)
            self.run_button.setMaximumHeight(100)
        elif is_complus4t:
            # For COMPLUS4T mode: expand to fill grid cell vertically with padding
            self.run_button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            # Remove height restriction to allow full vertical expansion
            self.run_button.setMaximumHeight(16777215)  # Qt's default maximum
            # Update style with padding of 10px and remove fixed height
            complus_run_button_style = """
                QPushButton {
                    font-size: 16px;
                    background-color: #ffcc80;
                    border: 2px solid #8c8c8c;
                    border-radius: 10px;
                    padding: 10px;
                }
                QPushButton:hover {
                    background-color: #ffb74d;
                }
            """
            self.run_button.setStyleSheet(complus_run_button_style)
        else:
            # For normal mode: expand to fill grid cell vertically with padding
            self.run_button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            # Remove height restriction to allow full vertical expansion
            self.run_button.setMaximumHeight(16777215)  # Qt's default maximum
            # Update style with padding of 10px and remove fixed height
            normal_run_button_style = """
                QPushButton {
                    font-size: 16px;
                    background-color: #ffcc80;
                    border: 2px solid #8c8c8c;
                    border-radius: 10px;
                    padding: 10px;
                }
                QPushButton:hover {
                    background-color: #ffb74d;
                }
            """
            self.run_button.setStyleSheet(normal_run_button_style)
        
        self.run_button.clicked.connect(self.run_data_processing)
        
        # Store reference for enabling/disabling
        self.all_buttons.append(self.run_button)
        
        # Add the button to the layout - different position for SP3/SICA and COMPLUS4T modes
        # WaferSlot is at (0,2,2,2), so Run Function should be at (0,4,1,1) - column 4, after Defect Size
        if is_sp3 or is_sica:
            self.layout.addWidget(self.run_button, 0, 4, 1, 1)  # (0,4,1,1) for SP3/SICA
        elif is_complus4t:
            # For COMPLUS4T mode: button takes only the first row
            self.layout.addWidget(self.run_button, 0, 4, 1, 1)  # (0,4,1,1) for COMPLUS4T - first row only
        else:
            # For normal mode: button takes only the first row
            self.layout.addWidget(self.run_button, 0, 5, 1, 1)  # (0,5,1,1) for Normal - first row only
    
    def set_buttons_enabled(self, enabled):
        """
        Enable or disable all buttons and radio buttons.
        
        Args:
            enabled: Boolean, True to enable, False to disable
        """
        # Enable/disable all push buttons
        buttons_to_remove = []
        for button in self.all_buttons:
            if button:
                try:
                    button.setEnabled(enabled)
                except RuntimeError:
                    # Button has been deleted, mark for removal
                    buttons_to_remove.append(button)
        
        # Remove deleted buttons from list
        for button in buttons_to_remove:
            if button in self.all_buttons:
                self.all_buttons.remove(button)
        
        # Enable/disable all radio buttons
        radio_buttons_to_remove = []
        for radio_button in self.all_radio_buttons:
            if radio_button:
                try:
                    radio_button.setEnabled(enabled)
                except RuntimeError:
                    # Radio button has been deleted, mark for removal
                    radio_buttons_to_remove.append(radio_button)
        
        # Remove deleted radio buttons from list
        for radio_button in radio_buttons_to_remove:
            if radio_button in self.all_radio_buttons:
                self.all_radio_buttons.remove(radio_button)
        
        # Enable/disable tool radio buttons
        tool_radiobuttons = [
            self.split_rename, self.split_rename_all, self.clean_all,
            self.create_folder, self.threshold, self.mapping,
            self.threshold_all, self.mapping_all, self.clean
        ]
        for radiobutton in tool_radiobuttons:
            if radiobutton:
                try:
                    radiobutton.setEnabled(enabled)
                except RuntimeError:
                    # Radio button has been deleted, skip it
                    pass
        
        # Enable/disable wafer radio buttons
        for radio_button in self.radio_vars.values():
            if radio_button:
                try:
                    radio_button.setEnabled(enabled)
                except RuntimeError:
                    # Radio button has been deleted, skip it
                    pass

    def run_data_processing(self):
        """Handles photoluminescence data processing and updates progress."""

        scale_data = self.new_folder + os.sep + "settings_data.json"
        wafer_number= self.get_selected_option()


        if not self.dirname or not any([self.clean.isChecked()
                                        or not self.split_rename.isChecked()
                                        or not self.clean_all.isChecked()
                                        or not self.split_rename_all.isChecked()
                                        or self.threshold.isChecked()
                                        or self.mapping.isChecked()
                                        or self.threshold_all.isChecked()
                                        or self.mapping_all.isChecked()
                                        ]):
            return
        
        # Disable all buttons and set wait cursor
        self.set_buttons_enabled(False)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        
        try:

            # Initialize processing classes
            sem_class = Process(self.dirname, wafer=wafer_number, scale = scale_data)
            total_steps = 0
            if self.split_rename.isChecked():
                total_steps = 3
            if self.clean.isChecked():
                total_steps = 1

            if self.split_rename_all.isChecked():
                total_steps = 3
            if self.clean_all.isChecked():
                total_steps = 1
            if self.create_folder.isChecked():
                total_steps = 1

            if self.threshold.isChecked():
                total_steps = 1
            if self.mapping.isChecked():
                total_steps = 1
            if self.threshold_all.isChecked():
                total_steps = 1
            if self.mapping_all.isChecked():
                total_steps = 1


            # Progress dialog removed - no popup
            progress_dialog = None

            def execute_with_timer(task_name, task_function, *args, **kwargs):
                """Executes a task and displays the time taken."""
                start_time = time.time()
                if progress_dialog:
                    progress_dialog.setLabelText(task_name)
                QApplication.processEvents()  # Ensures the interface is updated
                
                # For long-running tasks, we need to process events periodically
                # This is especially important for rename operations
                task_function(*args, **kwargs)
                
                # Process events one more time after task completion
                QApplication.processEvents()
                
                elapsed_time = time.time() - start_time
                pass  # Task completed

            if self.split_rename.isChecked():
                execute_with_timer("Cleaning of folders", sem_class.clean)
                execute_with_timer("Create folders",
                                   sem_class.organize_and_rename_files)

                execute_with_timer("Split w/ tag", sem_class.split_tiff)
                execute_with_timer("Rename w/ tag", sem_class.rename)
                self.update_wafer()

            if self.split_rename_all.isChecked():
                execute_with_timer("Cleaning of folders", sem_class.clean_all)
                execute_with_timer("Create folders",
                                   sem_class.organize_and_rename_files)

                execute_with_timer("Split w/ tag", sem_class.split_tiff_all)
                execute_with_timer("Rename w/ tag", sem_class.rename_all)
                self.update_wafer()

            if self.clean.isChecked():
                execute_with_timer("Cleaning of folders", sem_class.clean)

            if self.clean_all.isChecked():
                execute_with_timer("Cleaning of folders", sem_class.clean_all)

            if self.create_folder.isChecked():
                execute_with_timer("Create folders", sem_class.organize_and_rename_files)
                self.update_wafer()

            if self.threshold.isChecked():
                execute_with_timer("Threshold processing", self.process_threshold_wafer)
            
            if self.mapping.isChecked():
                execute_with_timer("Mapping processing", self.process_mapping_wafer)
            
            if self.threshold_all.isChecked():
                execute_with_timer("Threshold processing (all)", self.process_threshold_all)
            
            if self.mapping_all.isChecked():
                execute_with_timer("Mapping processing (all)", self.process_mapping_all)

            if progress_dialog:
                progress_dialog.close()
            

        
        except Exception as e:
            print(f"Error in run_data_processing: {e}")
        
        finally:
            # Re-enable all buttons and restore cursor
            self.set_buttons_enabled(True)
            QApplication.restoreOverrideCursor()

    def process_threshold_wafer(self):
        """Process threshold for selected wafer."""
        selected_wafer = self.get_selected_option()
        if not selected_wafer:
            print("No wafer selected")
            return
        
        # Get parameters from sliders
        threshold = self.get_threshold_value()
        min_size = self.get_min_size_value()
        
        # Get image size from settings data
        image_size_um = 5.0  # Default value
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    try:
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0
        
        # Create wafer path
        wafer_path = os.path.join(self.dirname, str(selected_wafer))
        
        if not os.path.exists(wafer_path):
            print(f"Wafer directory not found: {wafer_path}")
            return
        
        print(f"Processing threshold for wafer {selected_wafer}")
        print(f"Parameters: threshold={threshold}, min_size={min_size}, image_size={image_size_um}")
        print(f"Path: {wafer_path}")
        
        # Create processor with parameters from sliders
        from semapp.Processing.threshold import SEMThresholdProcessor
        processor = SEMThresholdProcessor(
            threshold=threshold,
            min_size=min_size,
            image_size_um=image_size_um,
            save_results=True,
            verbose=True
        )
        
        # Get coordinates and image settings from plot_frame
        if not hasattr(self.plot_frame, 'coordinates') or self.plot_frame.coordinates is None:
            print("No coordinates available in plot_frame")
            return
        
        # Get image type settings
        image_result = self.get_selected_image()
        if image_result is None:
            print("No image type selected")
            return
        
        image_type, number_type = image_result
        
        # Get scale from settings
        scale = "5x5"  # Default scale
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale = first_entry["Scale"]
        
        # Process directory (without plot_sem_data)
        results = processor.process_merged_tiff_directory(
            wafer_path, 
            self.plot_frame.coordinates,
            image_type,
            number_type,
            scale,
            show_results=False
        )
        
        # Consolidate CSV files
        consolidated_path = processor.consolidate_csv_files(wafer_path)
        
        print(f"Threshold processing completed for wafer {selected_wafer}")
        print(f"Consolidated CSV saved to: {consolidated_path}")
    
    def process_mapping_wafer(self):
        """Process mapping for selected wafer."""
        selected_wafer = self.get_selected_option()
        if not selected_wafer:
            print("No wafer selected")
            return
        
        # Get parameters from sliders
        threshold = self.get_threshold_value()
        min_size = self.get_min_size_value()
        
        # Get image size from settings data
        image_size_um = 5.0  # Default value
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    try:
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0
        
        # Create wafer path
        wafer_path = os.path.join(self.dirname, str(selected_wafer))
        
        if not os.path.exists(wafer_path):
            print(f"Wafer directory not found: {wafer_path}")
            return
        
        print(f"Processing mapping for wafer {selected_wafer}")
        print(f"Parameters: threshold={threshold}, min_size={min_size}, image_size={image_size_um}")
        print(f"Path: {wafer_path}")
        
        # Create processor with parameters from sliders
        from semapp.Processing.threshold import SEMThresholdProcessor
        processor = SEMThresholdProcessor(
            threshold=threshold,
            min_size=min_size,
            image_size_um=image_size_um,
            save_results=True,
            verbose=True
        )
        
        # Check if SP3 or SICA mode - for SP3/SICA, KLARF files are in parent directory
        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        
        # Consolidate CSV files before mapping
        print("Consolidating CSV files before mapping...")
        # For SP3/SICA, search in parent directory (which contains all wafer subdirectories)
        # For normal mode, search in wafer directory
        search_directory = self.dirname if (is_sp3 or is_sica) else wafer_path
        consolidated_path = processor.consolidate_csv_files(search_directory)
        if consolidated_path:
            print(f"Consolidated CSV created: {consolidated_path}")
        else:
            print("Warning: No CSV files found to consolidate")
        
        # Plot SEM data (mapping)
        # For SP3/SICA, the consolidated CSV is in parent directory, but we want to plot for specific wafer
        # So we need to check if consolidated CSV exists in wafer_path, if not, check parent
        if is_sp3 or is_sica:
            # For SP3/SICA, consolidated CSV should be in parent directory
            # But we want to plot only for this wafer, so check wafer_path first
            wafer_consolidated = os.path.join(wafer_path, "consolidated_results.csv")
            if os.path.exists(wafer_consolidated):
                plot_directory = wafer_path
            else:
                # If not in wafer folder, use parent (but this will plot all wafers)
                # Better to create wafer-specific consolidated CSV
                plot_directory = wafer_path
        else:
            plot_directory = wafer_path
        
        plot_files = processor.plot_sem_data(plot_directory, show_results=False)
        
        print(f"Mapping processing completed for wafer {selected_wafer}")
        print(f"Plot files created: {plot_files}")
    
    def process_threshold_all(self):
        """Process threshold for all wafers."""
        # Get parameters from sliders
        threshold = self.get_threshold_value()
        min_size = self.get_min_size_value()
        
        # Get image size from settings data
        image_size_um = 5.0  # Default value
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    try:
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0
        
        print(f"Processing threshold for all wafers")
        print(f"Parameters: threshold={threshold}, min_size={min_size}, image_size={image_size_um}")
        print(f"Parent directory: {self.dirname}")
        
        # Create processor with parameters from sliders
        from semapp.Processing.threshold import SEMThresholdProcessor
        processor = SEMThresholdProcessor(
            threshold=threshold,
            min_size=min_size,
            image_size_um=image_size_um,
            save_results=True,
            verbose=True
        )
        
        # Get coordinates and image settings from plot_frame
        if not hasattr(self.plot_frame, 'coordinates') or self.plot_frame.coordinates is None:
            print("No coordinates available in plot_frame")
            return
        
        # Get image type settings
        image_result = self.get_selected_image()
        if image_result is None:
            print("No image type selected")
            return
        
        image_type, number_type = image_result
        
        # Get scale from settings
        scale = "5x5"  # Default scale
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale = first_entry["Scale"]
        
        # Process parent directory (all wafers)
        results = processor.process_merged_tiff_directory(
            self.dirname, 
            self.plot_frame.coordinates,
            image_type,
            number_type,
            scale,
            show_results=False
        )
        
        # Consolidate CSV files
        consolidated_path = processor.consolidate_csv_files(self.dirname)
        
        print(f"Threshold processing completed for all wafers")
        print(f"Consolidated CSV saved to: {consolidated_path}")
    
    def process_mapping_all(self):
        """Process mapping for all wafers."""
        # Get parameters from sliders
        threshold = self.get_threshold_value()
        min_size = self.get_min_size_value()
        
        # Get image size from settings data
        image_size_um = 5.0  # Default value
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    try:
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0
        
        print(f"Processing mapping for all wafers")
        print(f"Parameters: threshold={threshold}, min_size={min_size}, image_size={image_size_um}")
        print(f"Parent directory: {self.dirname}")
        
        # Create processor with parameters from sliders
        from semapp.Processing.threshold import SEMThresholdProcessor
        processor = SEMThresholdProcessor(
            threshold=threshold,
            min_size=min_size,
            image_size_um=image_size_um,
            save_results=True,
            verbose=True
        )
        
        # Consolidate CSV files before mapping
        print("Consolidating CSV files before mapping...")
        consolidated_path = processor.consolidate_csv_files(self.dirname)
        if consolidated_path:
            print(f"Consolidated CSV created: {consolidated_path}")
        else:
            print("Warning: No CSV files found to consolidate")
        
        # Plot SEM data (mapping) for all wafers
        plot_files = processor.plot_sem_data(self.dirname, show_results=False)
        
        print(f"Mapping processing completed for all wafers")
        print(f"Plot files created: {plot_files}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    settings_window = SettingsWindow()
    settings_window.show()
    sys.exit(app.exec_())
