"""
Overview window for normal, KRONOS, and COMPLUS4T modes.
"""

import os
import numpy as np
import pandas as pd
import glob
from PIL import Image
from PyQt5.QtWidgets import QGroupBox, QGridLayout, QRadioButton, QVBoxLayout, QHBoxLayout
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QGuiApplication
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
import matplotlib.pyplot as plt

from semapp.Plot.overview_window_base import OverviewWindowBase


class OverviewWindowNormal(OverviewWindowBase):
    """
    Overview window for normal, KRONOS, and COMPLUS4T modes.
    """
    
    def __init__(self, coordinates, image_list, tiff_path, is_complus4t_mode=False, 
                 dirname=None, image_type=None, number_type=None, button_frame=None, parent=None):
        """
        Initialize the overview window for normal/KRONOS/COMPLUS4T modes.
        
        Args:
            coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
            image_list: List of PIL Images from the TIFF file
            tiff_path: Path to the TIFF file
            is_complus4t_mode: Boolean indicating if in COMPLUS4T mode
            dirname: Directory path
            image_type: Image type index (for normal mode)
            number_type: Number of image types (for normal mode)
            button_frame: Reference to button frame for getting image settings
            parent: Parent widget
        """
        super().__init__(coordinates, image_list, tiff_path, dirname, 
                        image_type, number_type, button_frame, parent)
        
        self.is_complus4t_mode = is_complus4t_mode
        
        # For non-SP3 modes, detect available wafers and store current wafer
        self.available_wafers = []
        self.selected_wafer_id = None
        self.wafer_radio_vars = {}
        if self.dirname:
            self.available_wafers = self._detect_available_wafers()
            # Get current wafer from tiff_path or button_frame
            if self.button_frame and hasattr(self.button_frame, 'selected_option'):
                self.selected_wafer_id = self.button_frame.selected_option
            elif self.tiff_path:
                # Try to extract wafer ID from path
                self.selected_wafer_id = self._extract_wafer_from_path(self.tiff_path)
        
        self._setup_ui()
        self._create_overview_plot()
        
        # Connect click event to canvas
        self.canvas.mpl_connect('button_press_event', self._on_click)
    
    def _on_click(self, event):
        """Handle mouse click events on the canvas to show full-size image."""
        if not hasattr(self, 'ax') or self.ax is None:
            return
            
        if event.inaxes != self.ax:
            return
        
        # Check if click is near any annotation box
        click_x, click_y = event.xdata, event.ydata
        
        if click_x is None or click_y is None:
            return
        
        if self.coordinates is None or self.coordinates.empty:
            return
        
        # Find the closest annotation box to the click
        min_distance = float('inf')
        closest_image_idx = None
        
        # Get scaled coordinates
        x_coords_scaled = self.coordinates['X'].values * 10
        y_coords_scaled = self.coordinates['Y'].values * 10
        
        for idx, (x, y) in enumerate(zip(x_coords_scaled, y_coords_scaled)):
            # Calculate distance from click to annotation box center
            distance = np.sqrt((click_x - x)**2 + (click_y - y)**2)
            
            # Use a threshold based on the radius of the plot
            # Calculate approximate threshold (thumbnail size in data coordinates)
            # Estimate: thumbnail_size pixels / (plot width in data units)
            plot_width = self.ax.get_xlim()[1] - self.ax.get_xlim()[0]
            plot_height = self.ax.get_ylim()[1] - self.ax.get_ylim()[0]
            # Approximate: assume thumbnail takes about 5% of plot width
            threshold = max(plot_width, plot_height) * 0.05
            
            if distance < threshold and distance < min_distance:
                min_distance = distance
                closest_image_idx = idx
        
        # If we found a close annotation box, show the image
        if closest_image_idx is not None:
            self._show_full_image(closest_image_idx)
    
    def _detect_available_wafers(self):
        """Detect all available wafers in the directory."""
        if not self.dirname or not os.path.exists(self.dirname):
            return []
        
        available_wafers = []
        
        if self.is_complus4t_mode:
            # COMPLUS4T mode: check .001 files for wafer IDs
            matching_files = glob.glob(os.path.join(self.dirname, '*.001'))
            
            for file_path in matching_files:
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                        if 'COMPLUS4T' in content or 'COMPLUS' in content:
                            # Extract all wafer IDs from the file
                            wafer_ids = self._extract_wafer_ids_from_klarf(file_path)
                            available_wafers.extend(wafer_ids)
                except Exception:
                    continue
        else:
            # Normal mode: check subdirectories
            for item in os.listdir(self.dirname):
                item_path = os.path.join(self.dirname, item)
                if os.path.isdir(item_path):
                    try:
                        wafer_num = int(item)
                        # Check if this wafer has a .001 file and data.tif
                        klarf_files = glob.glob(os.path.join(item_path, '*.001'))
                        tiff_path = os.path.join(item_path, "data.tif")
                        if klarf_files and os.path.isfile(tiff_path):
                            available_wafers.append(wafer_num)
                    except ValueError:
                        continue
        
        return sorted(set(available_wafers))
    
    def _extract_wafer_ids_from_klarf(self, filepath):
        """Extract all wafer IDs from a COMPLUS4T KLARF file."""
        wafer_ids = []
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                # Pattern for COMPLUS4T: WaferID "@16";
                import re
                pattern = r'WaferID\s+"@(\d+)"'
                matches = re.findall(pattern, content)
                for match in matches:
                    try:
                        wafer_ids.append(int(match))
                    except ValueError:
                        continue
        except Exception:
            pass
        return wafer_ids
    
    def _create_wafer_sidebar(self):
        """Create a sidebar with radio buttons for wafer navigation."""
        from semapp.Layout.styles import GROUP_BOX_STYLE, WAFER_BUTTON_DEFAULT_STYLE
        
        # Create group box for wafer slots
        group_box = QGroupBox("Wafer Slots")
        group_box.setStyleSheet(GROUP_BOX_STYLE)
        group_box.setFixedWidth(150)  # Fixed width for sidebar
        
        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)
        wafer_layout.setSpacing(5)
        
        # Add radio buttons for each available wafer
        for idx, wafer_id in enumerate(self.available_wafers):
            row = idx // 1  # 1 button per row
            col = idx % 1
            
            radio_button = QRadioButton(str(wafer_id))
            radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
            radio_button.toggled.connect(self._on_wafer_selection_changed)
            
            # Check if this is the currently selected wafer
            if wafer_id == self.selected_wafer_id:
                radio_button.setChecked(True)
            
            self.wafer_radio_vars[wafer_id] = radio_button
            wafer_layout.addWidget(radio_button, row, col)
        
        group_box.setLayout(wafer_layout)
        return group_box
    
    def _on_wafer_selection_changed(self):
        """Handle wafer selection change - load new wafer data and update plot."""
        # Find which wafer is selected
        selected_wafer = None
        for wafer_id, radio_button in self.wafer_radio_vars.items():
            if radio_button.isChecked():
                selected_wafer = wafer_id
                break
        
        if selected_wafer is None or selected_wafer == self.selected_wafer_id:
            return  # No change or no selection
        
        # Update selected wafer
        self.selected_wafer_id = selected_wafer
        
        # Ensure image_type is up to date (get from button_frame if available)
        if self.button_frame and not self.is_complus4t_mode:
            result = self.button_frame.get_selected_image()
            if result is not None:
                self.image_type, self.number_type = result
        
        # Load data for the selected wafer
        self._load_wafer_data(selected_wafer)
        
        # Refresh the plot
        self._create_overview_plot()
    
    def _load_wafer_data(self, wafer_id):
        """Load coordinates and images for a specific wafer."""
        if not self.dirname:
            return
        
        try:
            from semapp.Processing.klarf_reader import extract_positions
            
            if self.is_complus4t_mode:
                # COMPLUS4T mode: .001 file in parent directory, .tiff in parent
                matching_files = glob.glob(os.path.join(self.dirname, '*.001'))
                recipe_path = None
                
                for file_path in matching_files:
                    if self._is_wafer_in_klarf(file_path, wafer_id):
                        recipe_path = file_path
                        break
                
                if not recipe_path:
                    return
                
                # Find the .tiff file in parent directory
                tiff_files = glob.glob(os.path.join(self.dirname, '*.tiff'))
                if not tiff_files:
                    tiff_files = glob.glob(os.path.join(self.dirname, '*.tif'))
                
                if not tiff_files:
                    return
                
                tiff_path = tiff_files[0]
                
                # Extract positions for the specific wafer
                self.coordinates = extract_positions(recipe_path, wafer_id=wafer_id)
            else:
                # Normal mode: subfolders
                folder_path = os.path.join(self.dirname, str(wafer_id))
                
                # Find the first .001 file in the selected folder
                matching_files = glob.glob(os.path.join(folder_path, '*.001'))
                if matching_files:
                    recipe_path = matching_files[0]
                else:
                    recipe_path = None
                
                tiff_path = os.path.join(folder_path, "data.tif")
                
                if not os.path.isfile(tiff_path):
                    return
                
                # Extract all positions (normal mode)
                self.coordinates = extract_positions(recipe_path)
            
            # Load TIFF images
            self._load_tiff(tiff_path)
            self.tiff_path = tiff_path
            
        except Exception as e:
            print(f"Error loading wafer {wafer_id}: {e}")
            import traceback
            traceback.print_exc()
    
    def _is_wafer_in_klarf(self, filepath, wafer_id):
        """Check if a wafer ID exists in a KLARF file."""
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                # Pattern for COMPLUS4T: WaferID "@16";
                import re
                pattern = r'WaferID\s+"@(\d+)"'
                matches = re.findall(pattern, content)
                for match in matches:
                    if int(match) == wafer_id:
                        return True
        except Exception:
            pass
        return False
    
    def _setup_ui(self):
        """Set up the UI components."""
        # Get screen size for figure sizing
        screen = QGuiApplication.primaryScreen().geometry()
        
        # Create main layout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create common buttons
        self._create_common_ui_buttons(main_layout)
        
        # Create horizontal layout for sidebar and plot
        content_layout = QHBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)
        
        # Create sidebar for wafer navigation
        if len(self.available_wafers) > 0:
            sidebar = self._create_wafer_sidebar()
            content_layout.addWidget(sidebar)
        
        # Create matplotlib figure and canvas
        self.figure = Figure(figsize=(screen.width()/100, screen.height()/100), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        content_layout.addWidget(self.canvas, 1)  # Stretch factor = 1 to take remaining space
        
        main_layout.addLayout(content_layout)
    
    def _create_overview_plot(self):
        """Create the overview plot with image thumbnails."""
        # Clear annotation boxes list
        self.annotation_boxes = []
        
        # Normal mode: single plot
        if self.coordinates is None or self.coordinates.empty:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No coordinates available', 
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return
        
        self.ax = self.figure.add_subplot(111)
        self.ax.set_xlabel('X (mm)', fontsize=32)
        self.ax.set_ylabel('Y (mm)', fontsize=32)
        
        # Double the font size for tick labels
        self.ax.tick_params(axis='both', which='major', labelsize=32)
        
        # Get coordinates
        x_coords = self.coordinates['X'].values
        y_coords = self.coordinates['Y'].values
        
        # Apply *10 scaling factor for display (convert cm to mm)
        x_coords_scaled = x_coords * 10
        y_coords_scaled = y_coords * 10
        
        # Calculate radius for scaling (also scaled by 10)
        max_val = max(abs(x_coords_scaled).max(), abs(y_coords_scaled).max())
        
        if pd.isna(max_val) or not np.isfinite(max_val):
            radius = 100  # 10 * 10
        elif max_val <= 50:  # 5 * 10
            radius = 50
        elif max_val <= 75:  # 7.5 * 10
            radius = 75
        elif max_val <= 100:  # 10 * 10
            radius = 100
        elif max_val <= 150:  # 15 * 10
            radius = 150
        else:
            radius = max_val
        
        # Set limits (scaled by 10)
        self.ax.set_xlim(-radius - 10, radius + 10)
        self.ax.set_ylim(-radius - 10, radius + 10)
        
        # Draw circle (radius scaled by 10)
        circle = plt.Circle((0, 0), radius, color='black', fill=False, linewidth=1)
        self.ax.add_patch(circle)
        self.ax.set_aspect('equal')
        
        # Place image thumbnails at each coordinate (using scaled coordinates)
        self._place_image_thumbnails(x_coords_scaled, y_coords_scaled, radius)
        
        self.figure.subplots_adjust(left=0.1, right=0.95, top=0.95, bottom=0.1)
        self.canvas.draw()
    
    def _place_image_thumbnails(self, x_coords, y_coords, radius):
        """
        Place image thumbnails at each coordinate position.
        
        Args:
            x_coords: Array of X coordinates
            y_coords: Array of Y coordinates
            radius: Radius for scaling
        """
        if not self.image_list or len(self.image_list) == 0:
            # If no images, just show points
            self.ax.scatter(x_coords, y_coords, color='blue', marker='o', s=50, alpha=0.5)
            return
        
        # Place thumbnails
        for idx, (x, y) in enumerate(zip(x_coords, y_coords)):
            try:
                # Get the corresponding image
                if self.is_complus4t_mode:
                    # COMPLUS4T: use defect_id to get image
                    defect_id = int(self.coordinates.iloc[idx]['defect_id'])
                    image_idx = defect_id - 1  # defect_id starts at 1, index starts at 0
                else:
                    # Normal mode: use image_type and number_type if available
                    if self.image_type is not None and self.number_type is not None:
                        image_idx = self.image_type + (idx * self.number_type)
                    else:
                        # Fallback: try to get from button_frame or use stored values
                        if self.button_frame:
                            result = self.button_frame.get_selected_image()
                            if result is not None:
                                img_type, num_type = result
                                # Update stored values
                                self.image_type = img_type
                                self.number_type = num_type
                                image_idx = img_type + (idx * num_type)
                            elif self.image_type is not None and self.number_type is not None:
                                # Use stored values
                                image_idx = self.image_type + (idx * self.number_type)
                            else:
                                image_idx = idx
                        elif self.image_type is not None and self.number_type is not None:
                            # Use stored values
                            image_idx = self.image_type + (idx * self.number_type)
                        else:
                            image_idx = idx
                
                # Check if image index is valid
                if 0 <= image_idx < len(self.image_list):
                    pil_image = self.image_list[image_idx]
                    
                    # Resize image to thumbnail size
                    thumbnail = pil_image.resize(
                        (self.thumbnail_size, self.thumbnail_size),
                        Image.Resampling.LANCZOS
                    )
                    
                    # Convert PIL to numpy array
                    img_array = np.array(thumbnail.convert('RGB'))
                    
                    # Create OffsetImage for matplotlib
                    im = OffsetImage(img_array, zoom=1.0)
                    
                    # Create AnnotationBbox to place image at coordinate
                    ab = AnnotationBbox(im, (x, y), frameon=False, pad=0)
                    self.ax.add_artist(ab)
                    
                    # Store annotation box and image index for click detection
                    self.annotation_boxes.append((ab, image_idx))
                else:
                    # If image not available, show a small point
                    self.ax.scatter([x], [y], color='gray', marker='o', s=20, alpha=0.5)
                    
            except Exception as e:
                # If error loading image, show a small point
                print(f"Error loading image for coordinate ({x}, {y}): {e}")
                self.ax.scatter([x], [y], color='gray', marker='o', s=20, alpha=0.5)
        
        # Also show points for reference (semi-transparent)
        self.ax.scatter(x_coords, y_coords, color='red', marker='o', s=5, alpha=0.2)

