"""
Utility functions for frame management and screenshot functionality.

This module provides functions to create save buttons and manage frame layouts
in the application. It includes functionality for capturing and saving
combined screenshots of multiple frames.
"""

import os
import csv
import pandas as pd
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QPushButton, QFileDialog
from PyQt5.QtGui import QPixmap, QPainter

# Style constants
SAVE_BUTTON_STYLE = """
    QPushButton {
        font-size: 16px;
        background-color: #e1bee7;
        border: 2px solid #8c8c8c;
        border-radius: 10px;
        padding: 5px;
        height: 20px;
    }
    QPushButton:hover {
        background-color: #ce93d8;
    }
"""

BUTTON_POSITION = {
    'row': 5,  # Shifted down by 1 row
    'column': 0,
    'row_span': 1,
    'column_span': 6
}


def normalize_filename_for_comparison(filename):
    """
    Normalize filename for comparison by converting numbers like 1.0 to 1, -0.0 to 0, etc.
    
    Args:
        filename: Filename string to normalize
        
    Returns:
        Normalized filename string
    """
    import re
    
    # Convert to string and lowercase
    normalized = str(filename).strip().lower()
    
    # Normalize numbers: convert 1.0 to 1, -0.0 to 0, etc.
    # Pattern to match numbers (including negative and decimals)
    def normalize_number(match):
        num_str = match.group(0)
        try:
            num = float(num_str)
            # Convert to int if it's a whole number, otherwise keep as float
            if num.is_integer():
                return str(int(num))
            else:
                return str(num)
        except ValueError:
            return num_str
    
    # Match numbers in the filename (including negative numbers)
    normalized = re.sub(r'-?\d+\.?\d*', normalize_number, normalized)
    
    return normalized


def update_merged_csv_results(wafer_folder, filename, result, image_size_um):
    """
    Update the merged_threshold_results.csv file by replacing the row with the same filename.
    
    Args:
        wafer_folder: Path to the wafer folder containing the CSV
        filename: Name of the processed image file
        result: Result dictionary from SEMThresholdProcessor.process_single_image
        image_size_um: Image size in micrometers
    """
    csv_path = os.path.join(wafer_folder, "merged_threshold_results.csv")
    
    # Calculate statistics from the result
    particles = result['detected_particles']
    binary_image = result['binary_image']
    
    # Calculate statistics for this file
    import numpy as np
    import cv2
    
    mask_particles = np.zeros_like(binary_image, dtype=np.uint8)
    for particle in particles:
        cv2.fillPoly(mask_particles, [particle['contour']], 200)
    
    num_particles = len(particles)
    total_area_pixels = int(np.count_nonzero(mask_particles == 200))
    avg_area_pixels = total_area_pixels / num_particles if num_particles > 0 else 0
    
    # Calculate areas in µm²
    height, width = binary_image.shape
    pixel_area_um2 = (image_size_um ** 2) / (height * width)
    
    total_area_um2 = total_area_pixels * pixel_area_um2
    avg_area_um2 = avg_area_pixels * pixel_area_um2
    total_area_percentage = (total_area_pixels / (height * width)) * 100
    
    # Calculate density
    surface_area_um2 = image_size_um ** 2
    density = num_particles / surface_area_um2 if surface_area_um2 > 0 else 0
    
    # Create new row data
    new_row = {
        'Filename': filename,
        'Page_Index': 1,  # Single image, so page index is 1
        'Density': density,
        'Avg_area_um2': avg_area_um2,
        'Total_area_percentage': total_area_percentage,
        'Num_particles': num_particles,
        'Total_area_um2': total_area_um2
    }
    
    # Check if CSV file exists
    if os.path.exists(csv_path):
        # Read existing CSV
        df = pd.read_csv(csv_path)
        
        # Debug: Check if 'Filename' column exists
        if 'Filename' not in df.columns:
            print(f"Warning: 'Filename' column not found in CSV. Columns: {df.columns.tolist()}")
            # Try to find a similar column name
            filename_col = None
            for col in df.columns:
                if 'filename' in col.lower() or 'file' in col.lower():
                    filename_col = col
                    break
            if filename_col:
                print(f"Using column '{filename_col}' instead")
                df = df.rename(columns={filename_col: 'Filename'})
            else:
                print("Error: Cannot find filename column in CSV")
                return
        
        # Check if filename already exists (normalize numbers: 1.0 -> 1, -0.0 -> 0, etc.)
        # Normalize both the existing filenames and the new filename for comparison
        df['Filename_normalized'] = df['Filename'].astype(str).apply(normalize_filename_for_comparison)
        filename_normalized = normalize_filename_for_comparison(filename)
        
        # Debug: Print existing filenames for comparison
        existing_filenames = df['Filename_normalized'].tolist()
        print(f"Debug: Looking for '{filename_normalized}' in existing filenames:")
        print(f"Debug: Original filename: '{filename}'")
        print(f"Debug: Normalized filename: '{filename_normalized}'")
        if len(existing_filenames) > 0:
            print(f"Debug: First few existing (normalized): {existing_filenames[:3]}")
        
        existing_row_index = df[df['Filename_normalized'] == filename_normalized].index
        
        if len(existing_row_index) > 0:
            # Filename already exists - update all columns except Page_Index
            existing_page_index = df.loc[existing_row_index[0], 'Page_Index']  # Keep original Page_Index
            
            # Update all columns except Page_Index
            for col in new_row.keys():
                if col != 'Page_Index':
                    df.loc[existing_row_index[0], col] = new_row[col]
            
            # Keep the original Page_Index
            df.loc[existing_row_index[0], 'Page_Index'] = existing_page_index
            
            # Remove the temporary normalized column before saving
            df = df.drop(columns=['Filename_normalized'])
            df.to_csv(csv_path, index=False)
            print(f"Updated existing row for {filename} in merged_threshold_results.csv (Page_Index preserved: {existing_page_index})")
        else:
            # Add new row only if filename doesn't exist
            # Remove the temporary normalized column before adding
            df = df.drop(columns=['Filename_normalized'])
            df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
            df.to_csv(csv_path, index=False)
            print(f"Added new row for {filename} in merged_threshold_results.csv")
    else:
        # Create new CSV file
        df = pd.DataFrame([new_row])
        df.to_csv(csv_path, index=False)
        print(f"Created new CSV file: {csv_path}")


def create_savebutton(layout, frame_left, frame_right, button_frame=None):
    """
    Create save buttons to capture frames and process images.

    Args:
        layout: The layout where the save buttons will be added
        frame_left: The left frame to capture
        frame_right: The right frame to capture
        button_frame: Reference to button frame for accessing sliders and parameters

    Returns:
        None
    """
    def save_image():
        """
        Capture and save specific frames as a combined image.

        Creates a screenshot of both left and right frames, combines them
        horizontally and saves the result as a PNG file.
        """
        screen_left = frame_left.grab()
        screen_right = frame_right.grab()

        file_name, _ = QFileDialog.getSaveFileName(
            parent=None,
            caption="Save screenshot",
            directory="",
            filter="PNG Files (*.png);;All Files (*)"
        )

        if file_name:
            combined_width = screen_left.width() + screen_right.width()
            combined_height = max(screen_left.height(), screen_right.height())
            combined_pixmap = QPixmap(combined_width, combined_height)

            # Fill the combined QPixmap with a white background
            combined_pixmap.fill(Qt.white)

            painter = QPainter(combined_pixmap)
            painter.drawPixmap(0, 0, screen_left)
            painter.drawPixmap(screen_left.width(), 0, screen_right)
            painter.end()

            # Save the combined image
            combined_pixmap.save(file_name, "PNG")

    def save_processed_image():
        """
        Process and save the current image using SEMThresholdProcessor.
        """
        if not button_frame:
            return
        
        # Get parameters from sliders
        threshold = button_frame.get_threshold_value()
        min_size = button_frame.get_min_size_value()
        
        # Get image size from settings data
        image_size_um = 5.0  # Default value
        if hasattr(button_frame, 'settings_window') and button_frame.settings_window:
            settings_data = button_frame.settings_window.data
            if settings_data and len(settings_data) > 0:
                # Get the first entry's scale value
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    # Extract numeric value from scale (e.g., "5x5" -> 5.0)
                    try:
                        # Handle formats like "5x5", "5", "5.0x5.0"
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0  # Fallback to default
                    print(f"Using image size from settings: {image_size_um} um")
                else:
                    print("No Scale found in settings data")
            else:
                print("No settings data available")
        else:
            print("No settings window available")
        
        # Get selected wafer
        selected_wafer = button_frame.get_selected_option()
        if not selected_wafer:
            return
        
        # Get current image path from plot frame
        current_image_path = None
        if hasattr(button_frame, 'plot_frame') and button_frame.plot_frame:
            current_image_path = button_frame.plot_frame.get_current_image_path()
        
        if current_image_path:
            # Get current position from plot frame
            current_x = None
            current_y = None
            if hasattr(button_frame, 'plot_frame') and button_frame.plot_frame:
                # Try to get the last clicked position
                if hasattr(button_frame.plot_frame, 'last_clicked_position'):
                    current_x, current_y = button_frame.plot_frame.last_clicked_position
                else:
                    print("No clicked position available")
                    return
            
            if current_x is not None and current_y is not None:
                # Create custom filename using template (without "pos")
                filename = f"{image_size_um}_{current_x:.1f}_{current_y:.1f}.tiff"
                
                # Check if COMPLUS4T mode - don't create wafer subfolder for COMPLUS4T
                is_complus4t = False
                if hasattr(button_frame, '_check_complus4t_in_dirname'):
                    is_complus4t = button_frame._check_complus4t_in_dirname()
                
                # Save in wafer subfolder with custom filename (except for COMPLUS4T)
                if is_complus4t:
                    # For COMPLUS4T, save directly in parent directory
                    custom_path = os.path.join(button_frame.dirname, filename)
                else:
                    # For other modes, save in wafer subfolder
                    wafer_folder = os.path.join(button_frame.dirname, str(selected_wafer))
                    os.makedirs(wafer_folder, exist_ok=True)
                    custom_path = os.path.join(wafer_folder, filename)
                
                # Get the currently displayed image (with threshold applied)
                if hasattr(button_frame.plot_frame, 'image_list') and button_frame.plot_frame.image_list:
                    current_index = button_frame.plot_frame.current_index
                    if 0 <= current_index < len(button_frame.plot_frame.image_list):
                        # Get the processed image (with threshold applied)
                        processed_image = button_frame.plot_frame.image_list[current_index]
                        
                        # Apply threshold processing to get the final image
                        thresholded_image = button_frame.plot_frame._apply_threshold(processed_image, threshold)
                        
                        # Save the thresholded image directly
                        thresholded_image.save(custom_path)
                        print(f"Processed image saved to: {custom_path}")
                        
                        # Now process with SEMThresholdProcessor to generate CSV
                        from semapp.Processing.threshold import SEMThresholdProcessor
                        processor = SEMThresholdProcessor(
                            threshold=threshold,
                            min_size=min_size,
                            image_size_um=image_size_um,
                            save_results=True,
                            verbose=True
                        )
                        
                        # Process the saved image to generate CSV
                        result = processor.process_single_image(custom_path, show_result=False)
                        if result:
                            print(f"CSV results saved for: {custom_path}")
                            
                            # Update the merged_threshold_results.csv file
                            update_merged_csv_results(wafer_folder, filename, result, image_size_um)
                        else:
                            print("Failed to generate CSV results")
                    else:
                        print("Invalid image index")
                else:
                    print("No image list available")
            else:
                print("No valid position coordinates available")

    # First, remove any existing save buttons to avoid duplicates
    buttons_to_remove = []
    for i in range(layout.count()):
        item = layout.itemAt(i)
        if item and item.widget():
            widget = item.widget()
            if isinstance(widget, QPushButton):
                widget_text = widget.text() if hasattr(widget, 'text') else ""
                if widget_text in ["Save processed image", "Screenshot"]:
                    buttons_to_remove.append(widget)
    
    # Remove found buttons
    for button in buttons_to_remove:
        try:
            layout.removeWidget(button)
            button.setParent(None)
            button.deleteLater()
        except (RuntimeError, AttributeError):
            pass
    
    # Create and configure the save buttons
    processed_button = QPushButton("Save processed image")
    processed_button.setStyleSheet(SAVE_BUTTON_STYLE)
    processed_button.clicked.connect(save_processed_image)
    
    # Set size for "Save processed image" button to match frame_left width
    # frame_left has FRAME_SIZE+100 width (700 pixels)
    from semapp.Plot.frame_attributes import FRAME_SIZE
    processed_button.setFixedWidth(FRAME_SIZE + 100)  # Match frame_left width (700 pixels)
    
    save_button = QPushButton("Screenshot")
    save_button.setStyleSheet(SAVE_BUTTON_STYLE)
    save_button.clicked.connect(save_image)
    # Set fixed width for Screenshot button to match processed button
    save_button.setFixedWidth(FRAME_SIZE + 100)  # Same width as processed button
    
    # Add buttons to the layout
    layout.addWidget(
        processed_button,
        BUTTON_POSITION['row'],
        BUTTON_POSITION['column'],
        1,  # row_span
        3   # column_span (half width)
    )
    
    layout.addWidget(
        save_button,
        BUTTON_POSITION['row'],
        BUTTON_POSITION['column'] + 3,  # Start after processed button
        1,  # row_span
        3   # column_span (half width)
    )
