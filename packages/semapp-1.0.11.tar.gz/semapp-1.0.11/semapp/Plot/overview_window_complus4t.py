"""
Overview window for COMPLUS4T mode in Quantitative mode.
"""

import os
import numpy as np
import pandas as pd
from PyQt5.QtWidgets import QGroupBox, QGridLayout, QCheckBox, QPushButton, QScrollArea
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QGuiApplication
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt

from semapp.Plot.overview_window_base import OverviewWindowBase


class OverviewWindowCOMPLUS4T(OverviewWindowBase):
    """
    Overview window for COMPLUS4T mode in Quantitative mode.
    """
    
    def __init__(self, coordinates, image_list, tiff_path, dirname=None, 
                 image_type=None, number_type=None, button_frame=None, parent=None):
        """
        Initialize the overview window for COMPLUS4T Quantitative mode.
        
        Args:
            coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"] (not used)
            image_list: List of PIL Images from the TIFF file (not used)
            tiff_path: Path to the TIFF file (not used)
            dirname: Directory path for COMPLUS4T mode (to load all wafers)
            image_type: Image type index (not used)
            number_type: Number of image types (not used)
            button_frame: Reference to button frame for getting image settings
            parent: Parent widget
        """
        super().__init__(coordinates, image_list, tiff_path, dirname, 
                        image_type, number_type, button_frame, parent)
        
        # For COMPLUS4T, load all wafers data from mapping_all_defect.csv
        if self.dirname:
            self.all_wafers_data = self._load_all_complus4t_wafers()
            # Initialize selected wafers list (all selected by default)
            if self.all_wafers_data:
                self.selected_wafers_complus4t = sorted(self.all_wafers_data.keys())
            else:
                self.selected_wafers_complus4t = []
            self.wafer_checkbox_vars = {}  # Store checkboxes
        else:
            self.all_wafers_data = None
            self.selected_wafers_complus4t = []
            self.wafer_checkbox_vars = {}
        
        self._setup_ui()
        self._create_overview_plot()
    
    def _create_complus4t_wafer_sidebar(self):
        """Create a sidebar with checkboxes for wafer selection (COMPLUS4T mode)."""
        from semapp.Layout.styles import GROUP_BOX_STYLE
        
        # Create group box for wafer slots
        group_box = QGroupBox("Wafer Selection")
        group_box.setStyleSheet(GROUP_BOX_STYLE)
        group_box.setFixedWidth(180)  # Fixed width for sidebar
        
        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)
        wafer_layout.setSpacing(5)
        
        # Add "Select All" and "Deselect All" buttons
        select_all_button = QPushButton("Select All")
        select_all_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: 1px solid #388E3C;
                border-radius: 3px;
                padding: 4px 8px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #388E3C;
            }
        """)
        select_all_button.clicked.connect(self._select_all_wafers_complus4t)
        wafer_layout.addWidget(select_all_button, 0, 0, 1, 1)
        
        deselect_all_button = QPushButton("Deselect All")
        deselect_all_button.setStyleSheet("""
            QPushButton {
                background-color: #F44336;
                color: white;
                border: 1px solid #D32F2F;
                border-radius: 3px;
                padding: 4px 8px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #D32F2F;
            }
        """)
        deselect_all_button.clicked.connect(self._deselect_all_wafers_complus4t)
        wafer_layout.addWidget(deselect_all_button, 0, 1, 1, 1)
        
        # Get available wafers from all_wafers_data
        if self.all_wafers_data:
            available_wafers = sorted(self.all_wafers_data.keys())
        else:
            available_wafers = []
        
        # Add checkboxes for each available wafer
        for idx, wafer_id in enumerate(available_wafers):
            row = (idx // 2) + 1  # 2 checkboxes per row, starting from row 1
            col = idx % 2
            
            checkbox = QCheckBox(f"Slot {wafer_id}")
            checkbox.setStyleSheet("""
                QCheckBox {
                    spacing: 0px;
                    font-size: 16px;
                }
                QCheckBox::indicator {
                    width: 25px;
                    height: 25px;
                }
                QCheckBox::indicator:checked {
                    background-color: #ccffcc;
                    border: 2px solid black;
                }
                QCheckBox::indicator:unchecked {
                    background-color: white;
                    border: 2px solid #ccc;
                }
            """)
            
            # Block signals during initialization
            checkbox.blockSignals(True)
            
            # Check if this wafer is selected (default: all selected)
            if wafer_id in self.selected_wafers_complus4t:
                checkbox.setChecked(True)
            
            # Re-enable signals and connect
            checkbox.blockSignals(False)
            checkbox.stateChanged.connect(self._on_complus4t_wafer_selection_changed)
            
            self.wafer_checkbox_vars[wafer_id] = checkbox
            wafer_layout.addWidget(checkbox, row, col)
        
        group_box.setLayout(wafer_layout)
        return group_box
    
    def _select_all_wafers_complus4t(self):
        """Select all wafers in COMPLUS4T mode."""
        if self.all_wafers_data:
            self.selected_wafers_complus4t = sorted(self.all_wafers_data.keys())
            # Update checkboxes
            for wafer_id, checkbox in self.wafer_checkbox_vars.items():
                checkbox.blockSignals(True)
                checkbox.setChecked(True)
                checkbox.blockSignals(False)
            # Refresh plot
            if hasattr(self, 'figure') and self.figure is not None:
                self._create_overview_plot()
    
    def _deselect_all_wafers_complus4t(self):
        """Deselect all wafers in COMPLUS4T mode."""
        self.selected_wafers_complus4t = []
        # Update checkboxes
        for wafer_id, checkbox in self.wafer_checkbox_vars.items():
            checkbox.blockSignals(True)
            checkbox.setChecked(False)
            checkbox.blockSignals(False)
        # Refresh plot
        if hasattr(self, 'figure') and self.figure is not None:
            self._create_overview_plot()
    
    def _on_complus4t_wafer_selection_changed(self):
        """Handle wafer checkbox selection change in COMPLUS4T mode."""
        # Update selected wafers list
        self.selected_wafers_complus4t = []
        for wafer_id, checkbox in self.wafer_checkbox_vars.items():
            if checkbox.isChecked():
                self.selected_wafers_complus4t.append(wafer_id)
        
        # Sort selected wafers
        self.selected_wafers_complus4t = sorted(self.selected_wafers_complus4t)
        
        # Refresh plot
        if hasattr(self, 'figure') and self.figure is not None:
            self._create_overview_plot()
    
    def _load_all_complus4t_wafers(self):
        """Load all COMPLUS4T wafers data from mapping_all_defect.csv files."""
        if not self.dirname or not os.path.exists(self.dirname):
            return None
        
        all_wafers_data = {}  # {wafer_id: {'coordinates': df, 'defect_sizes': array}}
        
        # Find all wafer subdirectories
        for item in os.listdir(self.dirname):
            wafer_path = os.path.join(self.dirname, item)
            if os.path.isdir(wafer_path):
                try:
                    wafer_id = int(item)  # Try to parse as wafer ID
                except ValueError:
                    continue  # Skip if not a number
                
                # Look for mapping_all_defect.csv in this wafer folder
                mapping_all_path = os.path.join(wafer_path, "mapping_all_defect.csv")
                if os.path.isfile(mapping_all_path):
                    try:
                        coords = pd.read_csv(mapping_all_path)
                        
                        # Check required columns
                        required_cols = ['defect_id', 'X', 'Y', 'defect_size']
                        if all(col in coords.columns for col in required_cols):
                            # Filter out NaN values
                            valid_mask = (
                                (~pd.isna(coords['X'])) &
                                (~pd.isna(coords['Y']))
                            )
                            coords = coords[valid_mask]
                            
                            if len(coords) > 0:
                                all_wafers_data[wafer_id] = {
                                    'coordinates': coords,
                                    'defect_sizes': coords['defect_size'].values
                                }
                    except Exception as e:
                        print(f"Error loading mapping_all_defect.csv for wafer {wafer_id}: {e}")
                        continue
        
        return all_wafers_data
    
    def _setup_ui(self):
        """Set up the UI components."""
        # Create main layout
        from PyQt5.QtWidgets import QVBoxLayout, QHBoxLayout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create common buttons
        self._create_common_ui_buttons(main_layout)
        
        # Create horizontal layout for sidebar and plot
        content_layout = QHBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)
        
        # Create sidebar for wafer navigation
        if self.all_wafers_data and len(self.all_wafers_data) > 0:
            sidebar = self._create_complus4t_wafer_sidebar()
            content_layout.addWidget(sidebar)
        
        # Create matplotlib figure and canvas
        self.figure = Figure(figsize=(16, 12), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        
        # Create scroll area
        scroll_area = QScrollArea()
        scroll_area.setWidget(self.canvas)
        scroll_area.setWidgetResizable(True)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setFrameShape(QScrollArea.NoFrame)
        
        content_layout.addWidget(scroll_area, 1)  # Stretch factor = 1
        
        main_layout.addLayout(content_layout)
    
    def _create_overview_plot(self):
        """Create the COMPLUS4T overview plot."""
        self._create_complus4t_overview_plot()
    
    def _create_complus4t_overview_plot(self):
        """Create COMPLUS4T overview plot with distinct mappings and histograms for each selected wafer."""
        # Check if figure and canvas are initialized
        if not hasattr(self, 'figure') or self.figure is None:
            return
        if not hasattr(self, 'canvas') or self.canvas is None:
            return
        
        # Clear the figure first
        self.figure.clear()
        
        if not self.all_wafers_data or len(self.all_wafers_data) == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No COMPLUS4T wafer data available', 
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return
        
        # Get selected wafer IDs
        if not self.selected_wafers_complus4t or len(self.selected_wafers_complus4t) == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No wafers selected\nPlease select wafers from the sidebar', 
                        ha='center', va='center', transform=self.ax.transAxes, fontsize=16)
            self.canvas.draw()
            return
        
        # Filter to only selected wafers that exist in data
        sorted_wafer_ids = sorted([w for w in self.selected_wafers_complus4t if w in self.all_wafers_data])
        num_wafers = len(sorted_wafer_ids)
        
        if num_wafers == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No valid wafers selected', 
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return
        
        # Calculate number of groups (max 3 wafers per row)
        max_wafers_per_row = 3
        num_groups = (num_wafers + max_wafers_per_row - 1) // max_wafers_per_row
        
        # Structure: First all mappings, then all histograms
        total_rows = 2 * num_groups
        total_cols = max_wafers_per_row + 1  # 3 wafers + 1 column for charts
        
        # Update figure size
        base_height = 4.5
        mapping_height = base_height * num_groups
        histogram_height = base_height * num_groups
        figure_height = mapping_height + histogram_height
        
        # Calculate figure width
        screen = QGuiApplication.primaryScreen().geometry()
        sidebar_width = 180
        margin_padding = 50
        available_width_pixels = screen.width() - sidebar_width - margin_padding
        dpi = self.figure.dpi
        figure_width = available_width_pixels / dpi
        
        self.figure.set_size_inches(figure_width, figure_height)
        self.canvas.updateGeometry()
        QGuiApplication.processEvents()
        
        # Create width ratios
        width_ratios = [1.0] * max_wafers_per_row + [1]  # Wafer columns + charts column
        
        # Create height ratios
        height_ratios = [base_height] * num_groups + [base_height] * num_groups
        
        gs = self.figure.add_gridspec(total_rows, total_cols, hspace=0.6, wspace=0.3, 
                                     height_ratios=height_ratios,
                                     width_ratios=width_ratios)
        
        # Get threshold from slider (in µm for Quantitative)
        threshold = 0.0  # Default threshold (in µm)
        threshold_display = 0.0  # Threshold for display (in µm)
        if self.button_frame and hasattr(self.button_frame, 'get_selected_image'):
            result = self.button_frame.get_selected_image()
            if result is not None:
                threshold = result[0]  # Slider value (in µm for Quantitative)
                threshold_display = threshold
        
        # Collect all defect sizes for combined boxplot
        all_defect_sizes_combined = []
        wafer_labels_for_boxplot = []
        
        # Plot each wafer separately
        for wafer_idx, wafer_id in enumerate(sorted_wafer_ids):
            data = self.all_wafers_data[wafer_id]
            coords = data['coordinates']
            
            # Calculate group and position
            group_idx = wafer_idx // max_wafers_per_row
            col_in_group = wafer_idx % max_wafers_per_row
            
            mapping_row = group_idx
            histogram_row = num_groups + group_idx
            
            defect_sizes = coords['defect_size'].values
            
            # Collect data for combined boxplot
            if len(defect_sizes) > 0:
                filtered_defect_sizes = defect_sizes[defect_sizes >= threshold]
                if len(filtered_defect_sizes) > 0:
                    all_defect_sizes_combined.append(filtered_defect_sizes)
                    wafer_labels_for_boxplot.append(f'Slot {wafer_id}')
            
            # Create mapping subplot
            ax_map = self.figure.add_subplot(gs[mapping_row, col_in_group])
            ax_map.set_title(f'Slot {wafer_id}', fontsize=18, fontweight='bold', pad=10)
            
            if len(coords) > 0:
                # Get all defect sizes for calculating fixed color ranges
                all_defect_sizes = coords['defect_size'].values
                
                # Calculate fixed color ranges from ALL defects
                _, size_ranges = self._get_color_by_size_quantitative(pd.Series(all_defect_sizes))
                color_palette = [
                    '#1f77b4',  # Blue
                    '#2ca02c',  # Green
                    '#ff7f0e',  # Orange
                    '#d62728',  # Red
                    '#9467bd',  # Purple
                    '#8c564b',  # Brown
                    '#e377c2',  # Pink
                    '#7f7f7f',  # Gray
                    '#bcbd22',  # Olive
                ]
                
                x_coords = coords['X'].values * 10  # Convert cm to mm
                y_coords = coords['Y'].values * 10
                defect_sizes = coords['defect_size'].values
                
                # Assign colors using fixed size ranges
                colors_all = []
                for size in defect_sizes:
                    color_assigned = False
                    for i, (min_val, max_val) in enumerate(size_ranges):
                        if i == len(size_ranges) - 1:
                            if min_val <= size <= max_val:
                                colors_all.append(color_palette[i])
                                color_assigned = True
                                break
                        else:
                            if min_val <= size < max_val:
                                colors_all.append(color_palette[i])
                                color_assigned = True
                                break
                    
                    if not color_assigned:
                        colors_all.append(color_palette[-1])
                
                # Apply threshold: points with size < threshold become white
                edge_colors = []
                face_colors = []
                for i, size in enumerate(defect_sizes):
                    if size < threshold:
                        face_colors.append('white')
                        edge_colors.append('black')
                    else:
                        face_colors.append(colors_all[i])
                        edge_colors.append('black')
                
                # Calculate radius
                max_val = max(abs(x_coords).max(), abs(y_coords).max())
                
                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 100
                elif max_val <= 50:
                    radius = 50
                elif max_val <= 75:
                    radius = 75
                elif max_val <= 100:
                    radius = 100
                elif max_val <= 150:
                    radius = 150
                else:
                    radius = max_val
                
                # Set limits
                ax_map.set_xlim(-radius - 10, radius + 10)
                ax_map.set_ylim(-radius - 10, radius + 10)
                
                # Draw circle
                circle = plt.Circle((0, 0), radius, color='black', fill=False, linewidth=1)
                ax_map.add_patch(circle)
                
                # Plot points
                ax_map.scatter(x_coords, y_coords, c=face_colors, edgecolors=edge_colors,
                             linewidths=0.5, marker='o', s=5, alpha=0.6)
                
                ax_map.margins(x=0.01, y=0.01)
                
                if col_in_group == 0:
                    ax_map.set_ylabel('Y (mm)', fontsize=16)
                ax_map.set_xlabel('X (mm)', fontsize=16)
                ax_map.tick_params(axis='both', which='major', labelsize=12)
                ax_map.set_aspect('equal')
                ax_map.grid(True, alpha=0.3)
            else:
                ax_map.text(0.5, 0.5, 'No defects', ha='center', va='center', 
                           transform=ax_map.transAxes, fontsize=14)
            
            # Create histogram subplot
            ax_hist = self.figure.add_subplot(gs[histogram_row, col_in_group])
            
            if len(defect_sizes) > 0:
                # Calculate fixed color ranges from ALL defects
                _, size_ranges = self._get_color_by_size_quantitative(pd.Series(defect_sizes))
                color_palette = [
                    '#1f77b4',  # Blue
                    '#2ca02c',  # Green
                    '#ff7f0e',  # Orange
                    '#d62728',  # Red
                    '#9467bd',  # Purple
                    '#8c564b',  # Brown
                    '#e377c2',  # Pink
                    '#7f7f7f',  # Gray
                    '#bcbd22',  # Olive
                ]
                
                # Filter by threshold (threshold is in µm, defect_sizes are in µm)
                filtered_defect_sizes = defect_sizes[defect_sizes >= threshold]
                
                # Get slider range for histogram limits
                slider_min_um = 0.0  # Default minimum
                slider_max_um = 1000.0  # Default maximum
                slider_current_um = slider_min_um
                if self.button_frame and hasattr(self.button_frame, 'image_slider') and self.button_frame.image_slider:
                    slider_min_um = float(self.button_frame.image_slider.minimum())
                    slider_max_um = float(self.button_frame.image_slider.maximum())
                    slider_current_um = float(self.button_frame.image_slider.value())
                
                # Calculate mean and std for xmax offset
                if len(filtered_defect_sizes) > 0:
                    mean_um = np.mean(filtered_defect_sizes)
                    std_um = np.std(filtered_defect_sizes)
                    xmax_um = slider_max_um + 2 * std_um
                else:
                    xmax_um = slider_max_um
                
                xmin_um = slider_current_um
                hist_range = (xmin_um, xmax_um)  # Range in µm
                
                if len(filtered_defect_sizes) > 0:
                    # Create histogram (defect_sizes are already in µm)
                    counts, bins, patches = ax_hist.hist(filtered_defect_sizes, bins=50, range=hist_range, 
                                                        edgecolor='black', alpha=0.7)
                    
                    # Set x-axis limits
                    ax_hist.set_xlim(xmin_um, xmax_um)
                    
                    # Color each bar based on bin center
                    for i, patch in enumerate(patches):
                        bin_center_um = (bins[i] + bins[i+1]) / 2
                        for j, (min_val, max_val) in enumerate(size_ranges):
                            if j == len(size_ranges) - 1:
                                if min_val <= bin_center_um <= max_val:
                                    patch.set_facecolor(color_palette[j])
                                    break
                            else:
                                if min_val <= bin_center_um < max_val:
                                    patch.set_facecolor(color_palette[j])
                                    break
                    
                    ax_hist.margins(x=0.01, y=0.01)
                    
                    if col_in_group == 0:
                        ax_hist.set_ylabel('Counts', fontsize=16)
                    ax_hist.set_xlabel('Defect Size (µm)', fontsize=16)
                    ax_hist.tick_params(axis='both', which='major', labelsize=12)
                    ax_hist.grid(True, alpha=0.3, linestyle='--')
                    
                    # Align histogram position with mapping
                    ax_map_pos = ax_map.get_position()
                    hist_pos = ax_hist.get_position()
                    reduced_width = ax_map_pos.width * (2.0 / 3.0)
                    centered_x0 = ax_map_pos.x0 + (ax_map_pos.width - reduced_width) / 2.0
                    ax_hist.set_position([centered_x0, hist_pos.y0, reduced_width, hist_pos.height])
                else:
                    ax_hist.text(0.5, 0.5, f'No data ≥ {threshold_display:.0f} µm', ha='center', va='center', 
                                transform=ax_hist.transAxes, fontsize=14)
            else:
                ax_hist.text(0.5, 0.5, 'No data', ha='center', va='center', 
                            transform=ax_hist.transAxes, fontsize=14)
        
        # Collect defect counts for all wafers
        wafer_ids_for_count = []
        defect_counts = []
        
        for wafer_id in sorted_wafer_ids:
            data = self.all_wafers_data[wafer_id]
            coords = data['coordinates']
            defect_sizes = coords['defect_size'].values
            
            if len(defect_sizes) > 0:
                filtered_defect_sizes = defect_sizes[defect_sizes >= threshold]
                count = len(filtered_defect_sizes)
                wafer_ids_for_count.append(wafer_id)
                defect_counts.append(count)
        
        # Create defect count bar chart
        if len(defect_counts) > 0:
            ax_count = self.figure.add_subplot(gs[0, max_wafers_per_row])
            
            x_positions = np.arange(len(wafer_ids_for_count))
            bars = ax_count.bar(x_positions, defect_counts, color='#4CAF50', 
                               edgecolor='black', linewidth=1.5, width=0.6)
            
            ax_count.set_ylabel('Defect Count', fontsize=14, fontweight='bold')
            ax_count.set_xlabel('Wafer Slot', fontsize=14, fontweight='bold')
            ax_count.set_xticks(x_positions)
            ax_count.set_xticklabels([f'Slot {wid}' for wid in wafer_ids_for_count], 
                                    fontsize=11, rotation=45, ha='right')
            ax_count.tick_params(axis='y', which='major', labelsize=12)
            ax_count.grid(True, alpha=0.3, linestyle='--', axis='y')
            
            # Add count text on top of each bar
            for i, (bar, count) in enumerate(zip(bars, defect_counts)):
                ax_count.text(bar.get_x() + bar.get_width()/2, count, str(count), 
                            ha='center', va='bottom', fontsize=12, fontweight='bold')
        else:
            ax_count = self.figure.add_subplot(gs[0, max_wafers_per_row])
            ax_count.text(0.5, 0.5, 'No data', ha='center', va='center', 
                         transform=ax_count.transAxes, fontsize=14)
            ax_count.set_axis_off()
        
        # Create combined boxplot
        if len(all_defect_sizes_combined) > 0:
            ax_box = self.figure.add_subplot(gs[1, max_wafers_per_row])
            
            # Filter each wafer's data to 10-90 percentile
            filtered_for_boxplot = []
            for wafer_sizes_um in all_defect_sizes_combined:
                if len(wafer_sizes_um) > 0:
                    p10 = np.percentile(wafer_sizes_um, 10)
                    p90 = np.percentile(wafer_sizes_um, 90)
                    filtered_sizes = wafer_sizes_um[(wafer_sizes_um >= p10) & (wafer_sizes_um <= p90)]
                    if len(filtered_sizes) > 0:
                        filtered_for_boxplot.append(filtered_sizes)
                else:
                    filtered_for_boxplot.append(wafer_sizes_um)
            
            if len(filtered_for_boxplot) > 0:
                bp = ax_box.boxplot(filtered_for_boxplot, vert=True, patch_artist=True, 
                                   widths=0.6, showmeans=True, meanline=True)
                
                # Style the boxplot
                import matplotlib.cm as cm
                colors = cm.get_cmap('tab20')(np.linspace(0, 1, len(filtered_for_boxplot)))
                
                for patch, color in zip(bp['boxes'], colors):
                    patch.set_facecolor(color)
                    patch.set_alpha(0.7)
                
                for element in ['whiskers', 'fliers', 'means', 'medians', 'caps']:
                    plt.setp(bp[element], color='black', linewidth=1.5)
                
                ax_box.set_ylabel('Defect Size (µm)', fontsize=16)
                ax_box.set_xticklabels(wafer_labels_for_boxplot, fontsize=12, rotation=45, ha='right')
                ax_box.tick_params(axis='y', which='major', labelsize=12)
                ax_box.grid(True, alpha=0.3, linestyle='--', axis='y')
                title_text = f'All Wafers (≥ {threshold_display:.0f} µm, 10-90 percentile)'
                ax_box.set_title(title_text, fontsize=18, fontweight='bold', pad=10)
            else:
                ax_box.text(0.5, 0.5, 'No data after filtering', ha='center', va='center', 
                           transform=ax_box.transAxes, fontsize=14)
                ax_box.set_axis_off()
        else:
            ax_box = self.figure.add_subplot(gs[1, max_wafers_per_row])
            ax_box.text(0.5, 0.5, 'No data', ha='center', va='center', 
                       transform=ax_box.transAxes, fontsize=14)
            ax_box.set_axis_off()
        
        # Adjust spacing
        self.figure.subplots_adjust(left=0.05, right=0.98, top=0.96, bottom=0.04, wspace=0.0)
        self.canvas.draw()
        
        # Adjust canvas size
        self.canvas.setMinimumSize(self.canvas.sizeHint())
    
    def _get_color_by_size_quantitative(self, defect_sizes):
        """
        Assign colors to defects based on fixed size ranges for Quantitative mode (COMPLUS4T).
        Uses fixed ranges: 0-25, 25-50, 50-75, 75-100, 100-150, 150-200, 200-300, 300-500, 500-1000 µm.
        Same function as in frame_attributes.py for consistency.
        
        Args:
            defect_sizes: Series or array of defect sizes (in µm)
        
        Returns:
            tuple: (colors_list, size_ranges) where colors_list is a list of color strings
                   and size_ranges is a list of tuples (min, max) for each range (in µm)
        """
        if len(defect_sizes) == 0:
            return [], []
        
        # Define 9 distinct colors (one for each range)
        color_palette = [
            '#1f77b4',  # Blue
            '#2ca02c',  # Green
            '#ff7f0e',  # Orange
            '#d62728',  # Red
            '#9467bd',  # Purple
            '#8c564b',  # Brown
            '#e377c2',  # Pink
            '#7f7f7f',  # Gray
            '#bcbd22',  # Olive
        ]
        
        # Fixed size ranges in µm
        size_ranges = [
            (0.0, 25.0),    # 0-25 µm
            (25.0, 50.0),   # 25-50 µm
            (50.0, 75.0),   # 50-75 µm
            (75.0, 100.0), # 75-100 µm
            (100.0, 150.0), # 100-150 µm
            (150.0, 200.0), # 150-200 µm
            (200.0, 300.0), # 200-300 µm
            (300.0, 500.0), # 300-500 µm
            (500.0, 1000.0) # 500-1000 µm
        ]
        
        # Assign colors based on fixed size ranges
        colors = []
        for size in defect_sizes:
            color_assigned = False
            for i, (min_val, max_val) in enumerate(size_ranges):
                if i == len(size_ranges) - 1:
                    if min_val <= size <= max_val:
                        colors.append(color_palette[i])
                        color_assigned = True
                        break
                else:
                    if min_val <= size < max_val:
                        colors.append(color_palette[i])
                        color_assigned = True
                        break
            
            if not color_assigned:
                colors.append(color_palette[-1])
        
        return colors, size_ranges

