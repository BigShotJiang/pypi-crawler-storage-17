"""
Base class for overview windows with common functionality.
"""

import os
import numpy as np
import pandas as pd
from PIL import Image
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QMessageBox, QPushButton, QHBoxLayout, QFileDialog
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QGuiApplication
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas


class OverviewWindowBase(QWidget):
    """
    Base class for overview windows with common functionality.
    """
    
    def __init__(self, coordinates, image_list, tiff_path, dirname=None, 
                 image_type=None, number_type=None, button_frame=None, parent=None):
        """
        Initialize the base overview window.
        
        Args:
            coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
            image_list: List of PIL Images from the TIFF file
            tiff_path: Path to the TIFF file
            dirname: Directory path
            image_type: Image type index (for normal mode)
            number_type: Number of image types (for normal mode)
            button_frame: Reference to button frame for getting image settings
            parent: Parent widget
        """
        super().__init__(parent)
        
        # Set window flags FIRST, before creating any widgets
        self.setWindowFlags(Qt.Window | Qt.WindowStaysOnTopHint)
        
        self.coordinates = coordinates
        self.image_list = image_list
        self.tiff_path = tiff_path
        self.dirname = dirname
        self.image_type = image_type
        self.number_type = number_type
        self.button_frame = button_frame
        
        # Get directory path if not provided
        if not self.dirname and self.button_frame:
            self.dirname = self.button_frame.folder_var_changed()
        
        # Thumbnail size (adjust based on number of images)
        self.thumbnail_size = self._calculate_thumbnail_size()
        
        # Store annotation boxes for click detection
        self.annotation_boxes = []  # List of (AnnotationBbox, image_idx) tuples
        
        self.setWindowTitle("Overview - Wafer Mapping")
    
    def keyPressEvent(self, event):
        """Handle key press events - close on Escape key."""
        if event.key() == Qt.Key_Escape:
            self.close()
        else:
            super().keyPressEvent(event)
    
    def _show_full_image(self, image_idx):
        """Show the full-size image in a new window."""
        try:
            # Get the image index based on mode
            if hasattr(self, 'is_complus4t_mode') and self.is_complus4t_mode:
                defect_id = int(self.coordinates.iloc[image_idx]['defect_id'])
                actual_image_idx = defect_id - 1
            else:
                # Normal mode: use image_type and number_type if available
                if self.image_type is not None and self.number_type is not None:
                    actual_image_idx = self.image_type + (image_idx * self.number_type)
                else:
                    # Fallback: try to get from button_frame
                    if self.button_frame:
                        result = self.button_frame.get_selected_image()
                        if result is not None:
                            img_type, num_type = result
                            actual_image_idx = img_type + (image_idx * num_type)
                        else:
                            actual_image_idx = image_idx
                    else:
                        actual_image_idx = image_idx
            
            # Check if image index is valid
            if 0 <= actual_image_idx < len(self.image_list):
                pil_image = self.image_list[actual_image_idx]
                
                # Get coordinate information
                coord_text = ""
                if image_idx < len(self.coordinates):
                    coord_info = self.coordinates.iloc[image_idx]
                    coord_text = f"X: {coord_info['X']:.2f} / Y: {coord_info['Y']:.2f}"
                
                # Create a new window to display the full image
                from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel
                from PyQt5.QtGui import QPixmap, QPainter, QFont, QColor
                from PyQt5.QtCore import Qt as QtCore, QObject, QEvent, QPoint
                
                dialog = QDialog(self)
                dialog.setWindowTitle("")  # No title
                # Remove window frame (no title bar, no borders)
                dialog.setWindowFlags(QtCore.FramelessWindowHint | QtCore.WindowStaysOnTopHint)
                
                # Make dialog close on click outside
                dialog.setAttribute(QtCore.WA_TranslucentBackground, False)
                
                # Use a main widget to handle clicks
                from PyQt5.QtWidgets import QWidget
                main_widget = QWidget(dialog)
                layout = QVBoxLayout(main_widget)
                layout.setContentsMargins(0, 0, 0, 0)
                layout.setSpacing(0)
                
                # Convert PIL image to QPixmap
                from io import BytesIO
                buf = BytesIO()
                pil_image.save(buf, format='PNG')
                pixmap = QPixmap()
                pixmap.loadFromData(buf.getvalue())
                
                # Scale pixmap to fit screen (max 80% of screen size)
                screen = QGuiApplication.primaryScreen().geometry()
                max_width = int(screen.width() * 0.8)
                max_height = int(screen.height() * 0.8)
                
                if pixmap.width() > max_width or pixmap.height() > max_height:
                    pixmap = pixmap.scaled(max_width, max_height, 
                                         QtCore.KeepAspectRatio, 
                                         QtCore.SmoothTransformation)
                
                # Draw coordinate text on the pixmap (top left, white)
                if coord_text:
                    painter = QPainter(pixmap)
                    painter.setRenderHint(QPainter.Antialiasing)
                    
                    # Set white font
                    font = QFont()
                    font.setPointSize(16)
                    font.setBold(True)
                    painter.setFont(font)
                    painter.setPen(QColor(255, 255, 255))  # White color
                    
                    # Draw text with a slight shadow for better visibility
                    # Shadow (black, slightly offset)
                    painter.setPen(QColor(0, 0, 0, 180))  # Semi-transparent black
                    painter.drawText(12, 32, coord_text)  # Shadow offset
                    
                    # Main text (white)
                    painter.setPen(QColor(255, 255, 255))  # White
                    painter.drawText(10, 30, coord_text)  # Main text
                    
                    painter.end()
                
                # Create label to display image
                image_label = QLabel(main_widget)
                image_label.setPixmap(pixmap)
                image_label.setAlignment(QtCore.AlignCenter)
                image_label.setStyleSheet("background-color: black;")
                
                # Make label clickable to close dialog
                def close_dialog(event):
                    dialog.close()
                
                image_label.mousePressEvent = close_dialog
                
                layout.addWidget(image_label)
                
                # Set main widget as central widget
                dialog_layout = QVBoxLayout(dialog)
                dialog_layout.setContentsMargins(0, 0, 0, 0)
                dialog_layout.addWidget(main_widget)
                
                # Make the main widget close dialog on click
                def close_on_click(event):
                    dialog.close()
                
                main_widget.mousePressEvent = close_on_click
                
                dialog.resize(pixmap.width(), pixmap.height())
                
                # Install event filter to catch clicks outside the dialog
                class ClickOutsideFilter(QObject):
                    def __init__(self, dialog):
                        super().__init__()
                        self.dialog = dialog
                    
                    def eventFilter(self, obj, event):
                        if event.type() == QEvent.MouseButtonPress:
                            try:
                                # Get global position of the click
                                if hasattr(event, 'globalPos'):
                                    global_pos = event.globalPos()
                                elif hasattr(event, 'globalX') and hasattr(event, 'globalY'):
                                    global_pos = QPoint(event.globalX(), event.globalY())
                                else:
                                    return super().eventFilter(obj, event)
                                
                                # Check if click is outside the dialog
                                dialog_rect = self.dialog.geometry()
                                if not dialog_rect.contains(global_pos):
                                    self.dialog.close()
                                    return True
                            except Exception:
                                # If we can't determine position, allow normal processing
                                pass
                        return super().eventFilter(obj, event)
                
                # Install event filter on the application
                from PyQt5.QtWidgets import QApplication
                app = QApplication.instance()
                click_filter = ClickOutsideFilter(dialog)
                app.installEventFilter(click_filter)
                
                # Store filter reference to prevent garbage collection
                dialog._click_filter = click_filter
                
                dialog.exec_()
                
                # Remove event filter when dialog closes
                app.removeEventFilter(click_filter)
            else:
                print(f"Invalid image index: {actual_image_idx} (max: {len(self.image_list) - 1})")
        except Exception as e:
            print(f"Error showing full image: {e}")
            import traceback
            traceback.print_exc()
    
    def save_overview(self):
        """Save the overview plot to a file using the canvas."""
        # Disable save button during save operation
        save_button = self.findChild(QPushButton, "save_button")
        if save_button:
            save_button.setEnabled(False)
            save_button.setText("Saving...")
        
        # Process events to update UI
        from PyQt5.QtWidgets import QApplication
        QApplication.processEvents()
        
        # Open file dialog to choose save location
        file_path, selected_filter = QFileDialog.getSaveFileName(
            self,
            "Save Overview",
            "overview.png",
            "PNG Files (*.png);;PDF Files (*.pdf);;SVG Files (*.svg);;All Files (*)"
        )
        
        if file_path:
            try:
                # Determine DPI based on file format (lower for memory efficiency)
                if file_path.lower().endswith('.pdf'):
                    dpi = 150  # Lower DPI for PDF
                elif file_path.lower().endswith('.svg'):
                    dpi = 100  # SVG is vector, DPI less critical
                else:
                    dpi = 150  # Reduced from 300 for PNG to save memory
                
                # Save using canvas print_figure (more efficient than figure.savefig)
                self.canvas.print_figure(
                    file_path,
                    dpi=dpi,
                    bbox_inches='tight',  # Remove extra whitespace
                    facecolor='white',  # White background
                    edgecolor='none',
                    format=None,  # Let matplotlib determine format from extension
                    pad_inches=0.1  # Small padding
                )
                
                # Force garbage collection
                import gc
                gc.collect()
            except Exception as e:
                pass
                import traceback
                traceback.print_exc()
                # Show error message
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Critical)
                msg.setText(f"Error saving overview:\n{str(e)}")
                msg.setWindowTitle("Save Error")
                msg.exec_()
            finally:
                # Re-enable save button
                if save_button:
                    save_button.setEnabled(True)
                    save_button.setText("💾 Save")
    
    def _calculate_thumbnail_size(self):
        """Calculate appropriate thumbnail size based on number of images."""
        if self.coordinates is None or len(self.coordinates) == 0:
            return 50
        
        num_images = len(self.coordinates)
        
        # Adjust thumbnail size based on number of images
        if num_images < 50:
            return 80
        elif num_images < 100:
            return 60
        elif num_images < 200:
            return 40
        else:
            return 30
    
    def _load_tiff(self, tiff_path):
        """Load and prepare TIFF images for display."""
        try:
            img = Image.open(tiff_path)
            self.image_list = []
            
            # Load all TIFF pages and resize them
            while True:
                resized_img = img.resize((200, 200), Image.Resampling.LANCZOS)
                self.image_list.append(resized_img)
                try:
                    img.seek(img.tell() + 1)  # Move to next page
                except EOFError:
                    break
        except Exception as e:
            print(f"Error loading TIFF: {e}")
            self.image_list = []
    
    def _extract_wafer_from_path(self, path):
        """Extract wafer ID from file path."""
        try:
            # For normal mode: path contains subdirectory with wafer number
            # e.g., /path/to/dir/16/data.tif
            parts = path.split(os.sep)
            for part in reversed(parts):
                try:
                    wafer_num = int(part)
                    return wafer_num
                except ValueError:
                    continue
        except Exception:
            pass
        return None
    
    def _create_common_ui_buttons(self, main_layout):
        """Create common UI buttons (Save and Close)."""
        # Create button layout for buttons (top right)
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(10, 10, 10, 10)
        button_layout.addStretch()  # Push buttons to the right
        
        # Create save button
        save_button = QPushButton("💾 Save")
        save_button.setObjectName("save_button")  # Set object name for later reference
        save_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: 2px solid #388E3C;
                border-radius: 5px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #388E3C;
            }
            QPushButton:pressed {
                background-color: #2E7D32;
            }
            QPushButton:disabled {
                background-color: #CCCCCC;
                color: #666666;
            }
        """)
        save_button.clicked.connect(self.save_overview)
        save_button.setFixedSize(100, 35)
        button_layout.addWidget(save_button)
        
        # Create close button
        close_button = QPushButton("✕ Close")
        close_button.setStyleSheet("""
            QPushButton {
                background-color: #F44336;
                color: white;
                border: 2px solid #D32F2F;
                border-radius: 5px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #D32F2F;
            }
            QPushButton:pressed {
                background-color: #B71C1C;
            }
        """)
        close_button.clicked.connect(self.close)
        close_button.setFixedSize(100, 35)
        button_layout.addWidget(close_button)
        
        main_layout.addLayout(button_layout)

