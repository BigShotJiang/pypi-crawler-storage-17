"""
Overview window for SP3 mode.
"""

import os
import numpy as np
import pandas as pd
from PyQt5.QtWidgets import QGroupBox, QGridLayout, QCheckBox, QPushButton, QScrollArea
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QGuiApplication
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt

from semapp.Plot.overview_window_base import OverviewWindowBase


class OverviewWindowSP3(OverviewWindowBase):
    """
    Overview window for SP3 mode.
    """
    
    def __init__(self, coordinates, image_list, tiff_path, dirname=None, 
                 image_type=None, number_type=None, button_frame=None, parent=None):
        """
        Initialize the overview window for SP3 mode.
        
        Args:
            coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"] (not used in SP3)
            image_list: List of PIL Images from the TIFF file (not used in SP3)
            tiff_path: Path to the TIFF file (not used in SP3)
            dirname: Directory path for SP3 mode (to load all wafers)
            image_type: Image type index (not used in SP3)
            number_type: Number of image types (not used in SP3)
            button_frame: Reference to button frame for getting image settings
            parent: Parent widget
        """
        super().__init__(coordinates, image_list, tiff_path, dirname, 
                        image_type, number_type, button_frame, parent)
        
        # For SP3, load all wafers data
        if self.dirname:
            self.all_wafers_data = self._load_all_sp3_wafers()
            # Initialize selected wafers list (all selected by default for SP3)
            if self.all_wafers_data:
                self.selected_wafers_sp3 = sorted(self.all_wafers_data.keys())
            else:
                self.selected_wafers_sp3 = []
            self.wafer_checkbox_vars = {}  # Store checkboxes for SP3 mode
        else:
            self.all_wafers_data = None
            self.selected_wafers_sp3 = []
            self.wafer_checkbox_vars = {}
        
        self._setup_ui()
        self._create_overview_plot()
    
    def _create_sp3_wafer_sidebar(self):
        """Create a sidebar with checkboxes for wafer selection (SP3 mode)."""
        from semapp.Layout.styles import GROUP_BOX_STYLE, WAFER_BUTTON_DEFAULT_STYLE
        
        # Create group box for wafer slots
        group_box = QGroupBox("Wafer Selection")
        group_box.setStyleSheet(GROUP_BOX_STYLE)
        group_box.setFixedWidth(180)  # Fixed width for sidebar
        
        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)
        wafer_layout.setSpacing(5)
        
        # Add "Select All" and "Deselect All" buttons
        select_all_button = QPushButton("Select All")
        select_all_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: 1px solid #388E3C;
                border-radius: 3px;
                padding: 4px 8px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #388E3C;
            }
        """)
        select_all_button.clicked.connect(self._select_all_wafers_sp3)
        wafer_layout.addWidget(select_all_button, 0, 0, 1, 1)
        
        deselect_all_button = QPushButton("Deselect All")
        deselect_all_button.setStyleSheet("""
            QPushButton {
                background-color: #F44336;
                color: white;
                border: 1px solid #D32F2F;
                border-radius: 3px;
                padding: 4px 8px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #D32F2F;
            }
        """)
        deselect_all_button.clicked.connect(self._deselect_all_wafers_sp3)
        wafer_layout.addWidget(deselect_all_button, 0, 1, 1, 1)
        
        # Get available wafers from all_wafers_data
        if self.all_wafers_data:
            available_wafers = sorted(self.all_wafers_data.keys())
        else:
            available_wafers = []
        
        # Add checkboxes for each available wafer
        for idx, wafer_id in enumerate(available_wafers):
            row = (idx // 2) + 1  # 2 checkboxes per row, starting from row 1
            col = idx % 2
            
            checkbox = QCheckBox(f"Slot {wafer_id}")
            # Use the same style as radio buttons but adapted for checkboxes
            checkbox.setStyleSheet("""
                QCheckBox {
                    spacing: 0px;
                    font-size: 16px;
                }
                QCheckBox::indicator {
                    width: 25px;
                    height: 25px;
                }
                QCheckBox::indicator:checked {
                    background-color: #ccffcc;
                    border: 2px solid black;
                }
                QCheckBox::indicator:unchecked {
                    background-color: white;
                    border: 2px solid #ccc;
                }
            """)
            
            # Block signals during initialization to prevent premature callbacks
            checkbox.blockSignals(True)
            
            # Check if this wafer is selected (default: all selected)
            if wafer_id in self.selected_wafers_sp3:
                checkbox.setChecked(True)
            
            # Re-enable signals and connect after initialization
            checkbox.blockSignals(False)
            checkbox.stateChanged.connect(self._on_sp3_wafer_selection_changed)
            
            self.wafer_checkbox_vars[wafer_id] = checkbox
            wafer_layout.addWidget(checkbox, row, col)
        
        group_box.setLayout(wafer_layout)
        return group_box
    
    def _select_all_wafers_sp3(self):
        """Select all wafers in SP3 mode."""
        if self.all_wafers_data:
            self.selected_wafers_sp3 = sorted(self.all_wafers_data.keys())
            # Update checkboxes (block signals to avoid multiple callbacks)
            for wafer_id, checkbox in self.wafer_checkbox_vars.items():
                checkbox.blockSignals(True)
                checkbox.setChecked(True)
                checkbox.blockSignals(False)
            # Refresh plot only if figure is already created
            if hasattr(self, 'figure') and self.figure is not None:
                self._create_overview_plot()
    
    def _deselect_all_wafers_sp3(self):
        """Deselect all wafers in SP3 mode."""
        self.selected_wafers_sp3 = []
        # Update checkboxes (block signals to avoid multiple callbacks)
        for wafer_id, checkbox in self.wafer_checkbox_vars.items():
            checkbox.blockSignals(True)
            checkbox.setChecked(False)
            checkbox.blockSignals(False)
        # Refresh plot only if figure is already created
        if hasattr(self, 'figure') and self.figure is not None:
            self._create_overview_plot()
    
    def _on_sp3_wafer_selection_changed(self):
        """Handle wafer checkbox selection change in SP3 mode."""
        # Update selected wafers list
        self.selected_wafers_sp3 = []
        for wafer_id, checkbox in self.wafer_checkbox_vars.items():
            if checkbox.isChecked():
                self.selected_wafers_sp3.append(wafer_id)
        
        # Sort selected wafers
        self.selected_wafers_sp3 = sorted(self.selected_wafers_sp3)
        
        # Refresh plot only if figure is already created
        if hasattr(self, 'figure') and self.figure is not None:
            self._create_overview_plot()
    
    def _load_all_sp3_wafers(self):
        """Load all SP3 wafers data from defects_database."""
        if not self.dirname or not os.path.exists(self.dirname):
            return None
        
        all_wafers_data = {}  # {wafer_id: {'coordinates': df, 'defect_sizes': array}}
        
        # Load defects database
        all_defects = self._load_defects_database(self.dirname)
        if all_defects is None:
            print(f"defects_database not found in {self.dirname}")
            return None
        
        # Check required columns
        if 'wafer_id' not in all_defects.columns:
            print("defects_database does not contain 'wafer_id' column")
            return None
        
        # Get all unique wafer IDs
        wafer_ids = sorted(all_defects['wafer_id'].unique())
        
        for wafer_id in wafer_ids:
            # Filter for this wafer
            wafer_defects = all_defects[all_defects['wafer_id'] == wafer_id].copy()
            
            if len(wafer_defects) == 0:
                continue
            
            # Convert to coordinates format
            # defects_database has: defect_id, X, Y, defect_area, defect_size, wafer_id
            # We need: defect_id, X, Y, defect_size, defect_area
            if 'defect_size' not in wafer_defects.columns:
                # Fallback: use defect_area as defect_size if defect_size is not available
                wafer_defects['defect_size'] = wafer_defects['defect_area']
            
            # Create coordinates DataFrame
            coords = pd.DataFrame({
                'defect_id': wafer_defects['defect_id'],
                'X': wafer_defects['X'],
                'Y': wafer_defects['Y'],
                'defect_size': wafer_defects['defect_size'],
                'defect_area': wafer_defects['defect_area'] if 'defect_area' in wafer_defects.columns else wafer_defects['defect_size']
            })
            
            # No filtering - keep all defects
            
            if len(coords) > 0:
                all_wafers_data[wafer_id] = {
                    'coordinates': coords,
                    'defect_sizes': coords['defect_size'].values
                }
        
        return all_wafers_data
    
    def _load_defects_database(self, dirname):
        """
        Load defects database from defects_database.parquet or defects_database.csv.gz.
        
        Args:
            dirname: Directory path where defects_database file should be located
        
        Returns:
            pd.DataFrame: DataFrame with defects data, or None if file not found
        """
        # Try Parquet first (best compression)
        parquet_path = os.path.join(dirname, "defects_database.parquet")
        if os.path.exists(parquet_path):
            try:
                df = pd.read_parquet(parquet_path)
                print(f"Loaded defects database from Parquet: {parquet_path}")
                return df
            except ImportError:
                print("Parquet not available, trying CSV...")
            except Exception as e:
                print(f"Error reading Parquet: {e}, trying CSV...")
        
        # Try compressed CSV
        csv_gz_path = os.path.join(dirname, "defects_database.csv.gz")
        if os.path.exists(csv_gz_path):
            try:
                df = pd.read_csv(csv_gz_path, compression='gzip')
                print(f"Loaded defects database from compressed CSV: {csv_gz_path}")
                return df
            except Exception as e:
                print(f"Error reading compressed CSV: {e}")
        
        # Try regular CSV (fallback) - but check if it's actually compressed
        csv_path = os.path.join(dirname, "defects_database.csv")
        if os.path.exists(csv_path):
            try:
                # Helper function to check if file is gzip compressed
                def is_gzip_file(path):
                    try:
                        with open(path, 'rb') as f:
                            return f.read(2) == b'\x1f\x8b'  # Gzip magic number
                    except:
                        return False
                
                # Check if file is actually gzip compressed
                if is_gzip_file(csv_path):
                    # File is compressed but doesn't have .gz extension
                    df = pd.read_csv(csv_path, compression='gzip')
                    print(f"Loaded defects database from compressed CSV (no .gz extension): {csv_path}")
                else:
                    # Regular CSV file
                    df = pd.read_csv(csv_path)
                    print(f"Loaded defects database from CSV: {csv_path}")
                return df
            except Exception as e:
                # If it fails, it might be compressed
                if 'UnicodeDecodeError' in str(type(e).__name__) or 'codec' in str(e).lower():
                    try:
                        df = pd.read_csv(csv_path, compression='gzip')
                        print(f"Loaded defects database from compressed CSV (detected): {csv_path}")
                        return df
                    except:
                        pass
                print(f"Error reading CSV: {e}")
        
        return None
    
    def _setup_ui(self):
        """Set up the UI components."""
        # Create main layout
        from PyQt5.QtWidgets import QVBoxLayout, QHBoxLayout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create common buttons
        self._create_common_ui_buttons(main_layout)
        
        # Create horizontal layout for sidebar and plot
        content_layout = QHBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)
        
        # Create sidebar for wafer navigation
        if self.all_wafers_data and len(self.all_wafers_data) > 0:
            sidebar = self._create_sp3_wafer_sidebar()
            content_layout.addWidget(sidebar)
        
        # Create matplotlib figure and canvas
        # For SP3 mode: larger figure size for bigger mappings, with scrollbar
        # Calculate figure size based on number of wafers (will be updated in _create_sp3_overview_plot)
        self.figure = Figure(figsize=(16, 12), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        
        # Create scroll area for SP3 mode
        scroll_area = QScrollArea()
        scroll_area.setWidget(self.canvas)
        scroll_area.setWidgetResizable(True)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setFrameShape(QScrollArea.NoFrame)
        
        content_layout.addWidget(scroll_area, 1)  # Stretch factor = 1 to take remaining space
        
        main_layout.addLayout(content_layout)
    
    def _create_overview_plot(self):
        """Create the SP3 overview plot."""
        self._create_sp3_overview_plot()
    
    def _create_sp3_overview_plot(self):
        """Create SP3 overview plot with distinct mappings and histograms for each selected wafer."""
        # Check if figure and canvas are initialized
        if not hasattr(self, 'figure') or self.figure is None:
            return
        if not hasattr(self, 'canvas') or self.canvas is None:
            return
        
        # Clear the figure first
        self.figure.clear()
        
        if not self.all_wafers_data or len(self.all_wafers_data) == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No SP3 wafer data available', 
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return
        
        # Get selected wafer IDs (only plot selected wafers)
        if not self.selected_wafers_sp3 or len(self.selected_wafers_sp3) == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No wafers selected\nPlease select wafers from the sidebar', 
                        ha='center', va='center', transform=self.ax.transAxes, fontsize=16)
            self.canvas.draw()
            return
        
        # Filter to only selected wafers that exist in data
        sorted_wafer_ids = sorted([w for w in self.selected_wafers_sp3 if w in self.all_wafers_data])
        num_wafers = len(sorted_wafer_ids)
        
        if num_wafers == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No valid wafers selected', 
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return
        
        # Calculate number of groups (max 3 wafers per row)
        max_wafers_per_row = 3
        num_groups = (num_wafers + max_wafers_per_row - 1) // max_wafers_per_row  # Ceiling division
        
        # Structure: First all mappings, then all histograms
        # Total rows: num_groups (mappings) + num_groups (histograms) = 2 * num_groups
        total_rows = 2 * num_groups
        total_cols = max_wafers_per_row + 1  # 3 wafers + 1 column for defect count and boxplot charts
        
        # Histogram dimensions - same as mappings
        # Update figure size based on number of rows (bigger mappings)
        # Each row needs more space, so increase height
        base_height = 4.5  # Base height per row for mappings (increased for larger figures and more spacing)
        mapping_height = base_height * num_groups  # Total height for mapping rows
        histogram_height = base_height * num_groups  # Total height for histogram rows (same as mappings)
        figure_height = mapping_height + histogram_height  # Total figure height
        
        # Calculate figure width to take full screen width (minus sidebar)
        # Get screen width and subtract sidebar width (180 pixels as defined in _create_sp3_wafer_sidebar)
        screen = QGuiApplication.primaryScreen().geometry()
        sidebar_width = 180  # Sidebar width in pixels (from _create_sp3_wafer_sidebar)
        # Also account for window margins and padding (approximately 50 pixels)
        margin_padding = 50
        available_width_pixels = screen.width() - sidebar_width - margin_padding
        
        # Convert pixels to inches (using DPI)
        dpi = self.figure.dpi
        figure_width = available_width_pixels / dpi
        
        self.figure.set_size_inches(figure_width, figure_height)
        # Force canvas to update its size after figure size change
        # This ensures the canvas resizes correctly when wafers are added/removed
        self.canvas.updateGeometry()
        QGuiApplication.processEvents()  # Process events to ensure resize happens
        
        # Create width ratios: same width for mappings and histograms
        mapping_width_ratio = 1.0  # Width ratio for mapping columns
        # Note: width_ratios applies to all rows, so we use mapping_width for all wafer columns
        width_ratios = [mapping_width_ratio] * max_wafers_per_row + [1]  # Wafer columns + charts column
        
        # Create height ratios: mappings and histograms have the same dimensions
        # First num_groups rows are mappings, last num_groups rows are histograms
        # Calculate ratios based on actual heights (same for both)
        mapping_height_ratio = base_height  # Height ratio for mapping rows
        histogram_height_ratio = base_height  # Height ratio for histogram rows (same as mappings)
        height_ratios = [mapping_height_ratio] * num_groups + [histogram_height_ratio] * num_groups
        
        gs = self.figure.add_gridspec(total_rows, total_cols, hspace=0.6, wspace=0.3, 
                                     height_ratios=height_ratios,
                                     width_ratios=width_ratios)
        
        # Get threshold from slider (if available) - need to get it early for filtering
        # For SP3: slider is in nm, defect_size is in µm, so convert threshold from nm to µm
        threshold = 0.0  # Default threshold (in µm for comparison)
        threshold_display = 0.0  # Threshold for display (in nm)
        if self.button_frame and hasattr(self.button_frame, 'get_selected_image'):
            result = self.button_frame.get_selected_image()
            if result is not None:
                threshold_nm = result[0]  # Slider value (in nm for SP3)
                threshold = threshold_nm / 1000.0  # Convert nm to µm for comparison
                threshold_display = threshold_nm  # Keep in nm for display
        
        # Collect all defect sizes from all wafers for the combined boxplot
        all_defect_sizes_combined = []
        wafer_labels_for_boxplot = []
        
        # Plot each wafer separately (mapping and histogram)
        for wafer_idx, wafer_id in enumerate(sorted_wafer_ids):
            data = self.all_wafers_data[wafer_id]
            coords = data['coordinates']
            
            # Calculate which group this wafer belongs to and its position within the group
            group_idx = wafer_idx // max_wafers_per_row  # Which group (0, 1, 2, ...)
            col_in_group = wafer_idx % max_wafers_per_row  # Position within group (0-2)
            
            # Calculate row indices: 
            # Mappings are on rows 0 to num_groups-1
            # Histograms are on rows num_groups to 2*num_groups-1
            mapping_row = group_idx  # 0, 1, 2, ... (first num_groups rows)
            histogram_row = num_groups + group_idx  # num_groups, num_groups+1, ... (last num_groups rows)
            
            # No filtering - keep all defects (same as frame_attributes)
            
            defect_sizes = coords['defect_size'].values
            
            # Collect data for combined boxplot - filter by threshold
            if len(defect_sizes) > 0:
                # Filter: keep only defects with size >= threshold (threshold is in µm)
                filtered_defect_sizes = defect_sizes[defect_sizes >= threshold]
                if len(filtered_defect_sizes) > 0:
                    all_defect_sizes_combined.append(filtered_defect_sizes)
                    wafer_labels_for_boxplot.append(f'Slot {wafer_id}')
            
            # Create mapping subplot (top row of this group)
            ax_map = self.figure.add_subplot(gs[mapping_row, col_in_group])
            
            # Add wafer slot number as title
            ax_map.set_title(f'Slot {wafer_id}', fontsize=18, fontweight='bold', pad=10)
            
            if len(coords) > 0:
                # Get all defect sizes for calculating fixed color ranges (before filtering)
                all_defect_sizes = coords['defect_size'].values
                
                # Calculate fixed color ranges from ALL defects (for matching with main mapping)
                _, size_ranges = self._get_color_by_size_sp3(pd.Series(all_defect_sizes))
                color_palette = [
                    '#1f77b4',  # Blue
                    '#2ca02c',  # Green
                    '#ff7f0e',  # Orange
                    '#d62728',  # Red
                    '#9467bd',  # Purple
                    '#8c564b',  # Brown
                    '#e377c2',  # Pink
                    '#7f7f7f',  # Gray
                    '#bcbd22',  # Olive
                    '#17becf',  # Cyan
                    '#aec7e8',  # Light Blue
                    '#ffbb78',  # Light Orange
                    '#98df8a',  # Light Green
                    '#ff9896'   # Light Red
                ]
                
                # Don't filter coordinates - show all points, but apply threshold coloring
                x_coords = coords['X'].values * 10  # Convert cm to mm
                y_coords = coords['Y'].values * 10
                defect_sizes = coords['defect_size'].values
                
                # Assign colors to all defects using fixed size ranges
                colors_all = []
                for size in defect_sizes:
                    color_assigned = False
                    for i, (min_val, max_val) in enumerate(size_ranges):
                        if i == len(size_ranges) - 1:
                            if min_val <= size <= max_val:
                                colors_all.append(color_palette[i])
                                color_assigned = True
                                break
                        else:
                            if min_val <= size < max_val:
                                colors_all.append(color_palette[i])
                                color_assigned = True
                                break
                    
                    # If no color assigned (size > 1.0 µm), use the last color (purple) for values > 1.0 µm
                    if not color_assigned:
                        colors_all.append(color_palette[-1])  # Use last color for values outside range
                
                # Apply threshold: points with size < threshold become white with black edge
                # threshold is in µm, defect_sizes are in µm
                edge_colors = []
                face_colors = []
                for i, size in enumerate(defect_sizes):
                    if size < threshold:
                        # White fill with black edge for points below threshold
                        face_colors.append('white')
                        edge_colors.append('black')
                    else:
                        # Keep original color with black edge for points above threshold
                        face_colors.append(colors_all[i])
                        edge_colors.append('black')
                
                # Calculate radius for this wafer (using all coordinates)
                max_val = max(abs(x_coords).max(), abs(y_coords).max())
                
                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 100
                elif max_val <= 50:
                    radius = 50
                elif max_val <= 75:
                    radius = 75
                elif max_val <= 100:
                    radius = 100
                elif max_val <= 150:
                    radius = 150
                else:
                    radius = max_val
                
                # Set limits
                ax_map.set_xlim(-radius - 10, radius + 10)
                ax_map.set_ylim(-radius - 10, radius + 10)
                
                # Draw circle
                circle = plt.Circle((0, 0), radius, color='black', fill=False, linewidth=1)
                ax_map.add_patch(circle)
                
                # Plot points with colors and edges (smaller points for overview)
                ax_map.scatter(x_coords, y_coords, c=face_colors, edgecolors=edge_colors,
                             linewidths=0.5, marker='o', s=5, alpha=0.6)
                
                # Reduce margins to minimize spacing between mappings
                ax_map.margins(x=0.01, y=0.01)
                
                # Set labels only for first column of each group
                if col_in_group == 0:
                    ax_map.set_ylabel('Y (mm)', fontsize=16)
                ax_map.set_xlabel('X (mm)', fontsize=16)
                ax_map.tick_params(axis='both', which='major', labelsize=12)
                ax_map.set_aspect('equal')
                ax_map.grid(True, alpha=0.3)
            else:
                ax_map.text(0.5, 0.5, 'No defects', ha='center', va='center', 
                           transform=ax_map.transAxes, fontsize=14)
            
            # Create histogram subplot (bottom row of this group)
            ax_hist = self.figure.add_subplot(gs[histogram_row, col_in_group])
            
            # Filter defect sizes by threshold (threshold already retrieved earlier)
            if len(defect_sizes) > 0:
                # Calculate fixed color ranges from ALL defects (before threshold filtering)
                # This ensures colors match between mapping and histogram
                _, size_ranges = self._get_color_by_size_sp3(pd.Series(defect_sizes))
                color_palette = [
                    '#1f77b4',  # Blue
                    '#2ca02c',  # Green
                    '#ff7f0e',  # Orange
                    '#d62728',  # Red
                    '#9467bd',  # Purple
                    '#8c564b',  # Brown
                    '#e377c2',  # Pink
                    '#7f7f7f',  # Gray
                    '#bcbd22',  # Olive
                    '#17becf',  # Cyan
                    '#aec7e8',  # Light Blue
                    '#ffbb78',  # Light Orange
                    '#98df8a',  # Light Green
                    '#ff9896'   # Light Red
                ]
                
                # Filter by threshold (threshold is in µm, defect_sizes are in µm)
                filtered_defect_sizes = defect_sizes[defect_sizes >= threshold]
                
                # Convert to nm for display
                filtered_defect_sizes_nm = filtered_defect_sizes * 1000.0
                
                # Get slider range for histogram limits
                slider_min_nm = 50.0  # Default minimum from slider
                slider_max_nm = 1000.0  # Default maximum from slider
                if self.button_frame and hasattr(self.button_frame, 'image_slider') and self.button_frame.image_slider:
                    slider_min_nm = float(self.button_frame.image_slider.minimum())
                    slider_max_nm = float(self.button_frame.image_slider.maximum())
                
                hist_range = (slider_min_nm, slider_max_nm)  # Range in nm
                
                if len(filtered_defect_sizes_nm) > 0:
                    # Create histogram for this wafer (filtered data, displayed in nm)
                    counts, bins, patches = ax_hist.hist(filtered_defect_sizes_nm, bins=50, range=hist_range, edgecolor='black', alpha=0.7)
                    
                    # Set x-axis limits to match slider range
                    ax_hist.set_xlim(slider_min_nm, slider_max_nm)
                    
                    # Color each bar based on its bin center using FIXED size ranges (from all defects)
                    # size_ranges are in µm, bin_center is in nm, so convert bin_center to µm for comparison
                    for i, patch in enumerate(patches):
                        bin_center_nm = (bins[i] + bins[i+1]) / 2
                        bin_center_um = bin_center_nm / 1000.0  # Convert nm to µm for comparison
                        # Find which range this bin belongs to (using fixed ranges)
                        for j, (min_val, max_val) in enumerate(size_ranges):
                            if j == len(size_ranges) - 1:
                                if min_val <= bin_center_um <= max_val:
                                    patch.set_facecolor(color_palette[j])
                                    break
                            else:
                                if min_val <= bin_center_um < max_val:
                                    patch.set_facecolor(color_palette[j])
                                    break
                    
                    # Reduce margins to match mappings and minimize spacing
                    ax_hist.margins(x=0.01, y=0.01)
                    
                    # Set labels only for first column of each group
                    if col_in_group == 0:
                        ax_hist.set_ylabel('Counts', fontsize=16)
                    ax_hist.set_xlabel('Defect Size (nm)', fontsize=16)
                    ax_hist.tick_params(axis='both', which='major', labelsize=12)
                    ax_hist.grid(True, alpha=0.3, linestyle='--')
                    
                    # Align histogram position with mapping position, but reduce width by 1/3
                    # Do this after all labels and ticks are set
                    ax_map_pos = ax_map.get_position()
                    hist_pos = ax_hist.get_position()
                    # Reduce histogram width to 2/3 of mapping width (reduce by 1/3)
                    reduced_width = ax_map_pos.width * (2.0 / 3.0)
                    # Center the reduced histogram within the mapping width space to avoid being stuck to edges
                    centered_x0 = ax_map_pos.x0 + (ax_map_pos.width - reduced_width) / 2.0
                    ax_hist.set_position([centered_x0, hist_pos.y0, 
                                         reduced_width, hist_pos.height])
                else:
                    ax_hist.text(0.5, 0.5, f'No data ≥ {threshold_display} nm', ha='center', va='center', 
                                transform=ax_hist.transAxes, fontsize=14)
            else:
                ax_hist.text(0.5, 0.5, 'No data', ha='center', va='center', 
                            transform=ax_hist.transAxes, fontsize=14)
        
        # Collect defect counts for all wafers
        wafer_ids_for_count = []
        defect_counts = []
        
        for wafer_id in sorted_wafer_ids:
            data = self.all_wafers_data[wafer_id]
            coords = data['coordinates']
            
            # No filtering - keep all defects (same as frame_attributes)
            
            defect_sizes = coords['defect_size'].values
            
            # Count defects above threshold (threshold is in µm, defect_sizes are in µm)
            if len(defect_sizes) > 0:
                filtered_defect_sizes = defect_sizes[defect_sizes >= threshold]
                count = len(filtered_defect_sizes)
                wafer_ids_for_count.append(wafer_id)
                defect_counts.append(count)
        
        # Create defect count bar chart on first row (row 0), right column
        # Defect count chart is now a separate figure on row 0
        if len(defect_counts) > 0:
            ax_count = self.figure.add_subplot(gs[0, max_wafers_per_row])
            
            # Create bar chart with wafer IDs on x-axis and counts on y-axis
            x_positions = np.arange(len(wafer_ids_for_count))
            bars = ax_count.bar(x_positions, defect_counts, color='#4CAF50', 
                               edgecolor='black', linewidth=1.5, width=0.6)
            
            ax_count.set_ylabel('Defect Count', fontsize=14, fontweight='bold')
            ax_count.set_xlabel('Wafer Slot', fontsize=14, fontweight='bold')
            ax_count.set_xticks(x_positions)
            ax_count.set_xticklabels([f'Slot {wid}' for wid in wafer_ids_for_count], 
                                    fontsize=11, rotation=45, ha='right')
            ax_count.tick_params(axis='y', which='major', labelsize=12)
            ax_count.grid(True, alpha=0.3, linestyle='--', axis='y')
            
            # Add count text on top of each bar
            for i, (bar, count) in enumerate(zip(bars, defect_counts)):
                ax_count.text(bar.get_x() + bar.get_width()/2, count, str(count), 
                            ha='center', va='bottom', fontsize=12, fontweight='bold')
        else:
            ax_count = self.figure.add_subplot(gs[0, max_wafers_per_row])
            ax_count.text(0.5, 0.5, 'No data', ha='center', va='center', 
                         transform=ax_count.transAxes, fontsize=14)
            ax_count.set_axis_off()
        
        # Create combined boxplot on second row (row 1), right column
        # Boxplot is now a separate figure on row 1
        if len(all_defect_sizes_combined) > 0:
            ax_box = self.figure.add_subplot(gs[1, max_wafers_per_row])
            
            # Convert defect sizes to nm for display in boxplot
            all_defect_sizes_combined_nm = [sizes * 1000.0 for sizes in all_defect_sizes_combined]
            
            # Filter each wafer's data to 10-90 percentile to reduce outliers
            filtered_for_boxplot = []
            for wafer_sizes_nm in all_defect_sizes_combined_nm:
                if len(wafer_sizes_nm) > 0:
                    # Calculate 10th and 90th percentiles
                    p10 = np.percentile(wafer_sizes_nm, 10)
                    p90 = np.percentile(wafer_sizes_nm, 90)
                    # Filter to keep only values between 10th and 90th percentile
                    filtered_sizes = wafer_sizes_nm[(wafer_sizes_nm >= p10) & (wafer_sizes_nm <= p90)]
                    if len(filtered_sizes) > 0:
                        filtered_for_boxplot.append(filtered_sizes)
                else:
                    filtered_for_boxplot.append(wafer_sizes_nm)
            
            # Create boxplot with filtered data (10-90 percentile)
            if len(filtered_for_boxplot) > 0:
                bp = ax_box.boxplot(filtered_for_boxplot, vert=True, patch_artist=True, 
                                   widths=0.6, showmeans=True, meanline=True)
                
                # Style the boxplot - use different colors for each wafer
                import matplotlib.cm as cm
                colors = cm.get_cmap('tab20')(np.linspace(0, 1, len(filtered_for_boxplot)))
                
                for patch, color in zip(bp['boxes'], colors):
                    patch.set_facecolor(color)
                    patch.set_alpha(0.7)
                
                for element in ['whiskers', 'fliers', 'means', 'medians', 'caps']:
                    plt.setp(bp[element], color='black', linewidth=1.5)
                
                ax_box.set_ylabel('Defect Size (nm)', fontsize=16)
                ax_box.set_xticklabels(wafer_labels_for_boxplot, fontsize=12, rotation=45, ha='right')
                ax_box.tick_params(axis='y', which='major', labelsize=12)
                ax_box.grid(True, alpha=0.3, linestyle='--', axis='y')
                title_text = f'All Wafers (≥ {threshold_display} nm, 10-90 percentile)'
                ax_box.set_title(title_text, fontsize=18, fontweight='bold', pad=10)
            else:
                ax_box.text(0.5, 0.5, 'No data after filtering', ha='center', va='center', 
                           transform=ax_box.transAxes, fontsize=14)
                ax_box.set_axis_off()
        else:
            ax_box = self.figure.add_subplot(gs[1, max_wafers_per_row])
            ax_box.text(0.5, 0.5, 'No data', ha='center', va='center', 
                       transform=ax_box.transAxes, fontsize=14)
            ax_box.set_axis_off()
        
        # Reduce horizontal spacing by adjusting margins
        # left/right control horizontal margins, reduce them to make mappings closer
        self.figure.subplots_adjust(left=0.05, right=0.98, top=0.96, bottom=0.04, wspace=0.0)
        self.canvas.draw()
        
        # Adjust canvas size to fit the figure content (important for scroll area)
        self.canvas.setMinimumSize(self.canvas.sizeHint())
    
    def _get_color_by_size_sp3(self, defect_sizes):
        """
        Assign colors to defects based on fixed size ranges for SP3 mode.
        Uses fixed ranges: 0-50, 50-100, 100-150, 150-200, 200-250, 250-300, 300-350, 350-400 nm (50 nm steps),
        then 400-500, 500-600, 600-700, 700-800, 800-900, 900-1000 nm (100 nm steps).
        Same function as in frame_attributes.py for consistency.
        
        Args:
            defect_sizes: Series or array of defect sizes (in µm for SP3)
        
        Returns:
            tuple: (colors_list, size_ranges) where colors_list is a list of color strings
                   and size_ranges is a list of tuples (min, max) for each range (in µm)
        """
        if len(defect_sizes) == 0:
            return [], []
        
        # Define 14 distinct colors (well visible) - one for each range
        color_palette = [
            '#1f77b4',  # Blue
            '#2ca02c',  # Green
            '#ff7f0e',  # Orange
            '#d62728',  # Red
            '#9467bd',  # Purple
            '#8c564b',  # Brown
            '#e377c2',  # Pink
            '#7f7f7f',  # Gray
            '#bcbd22',  # Olive
            '#17becf',  # Cyan
            '#aec7e8',  # Light Blue
            '#ffbb78',  # Light Orange
            '#98df8a',  # Light Green
            '#ff9896'   # Light Red
        ]
        
        # Fixed size ranges in nm, converted to µm for comparison (defect_sizes are in µm)
        # 0-400 nm: 50 nm steps (0.05 µm)
        # 400-1000 nm: 100 nm steps (0.1 µm)
        size_ranges = [
            (0.0, 0.05),   # 0-50 nm
            (0.05, 0.1),   # 50-100 nm
            (0.1, 0.15),   # 100-150 nm
            (0.15, 0.2),   # 150-200 nm
            (0.2, 0.25),   # 200-250 nm
            (0.25, 0.3),   # 250-300 nm
            (0.3, 0.35),   # 300-350 nm
            (0.35, 0.4),   # 350-400 nm
            (0.4, 0.5),    # 400-500 nm
            (0.5, 0.6),    # 500-600 nm
            (0.6, 0.7),    # 600-700 nm
            (0.7, 0.8),    # 700-800 nm
            (0.8, 0.9),    # 800-900 nm
            (0.9, 1.0)     # 900-1000 nm
        ]
        
        # Assign colors based on fixed size ranges
        colors = []
        for size in defect_sizes:
            color_assigned = False
            for i, (min_val, max_val) in enumerate(size_ranges):
                # For the last range, include the max value
                if i == len(size_ranges) - 1:
                    if min_val <= size <= max_val:
                        colors.append(color_palette[i])
                        color_assigned = True
                        break
                else:
                    if min_val <= size < max_val:
                        colors.append(color_palette[i])
                        color_assigned = True
                        break
            
            # If no color assigned (size > 1.0 µm), use the last color for values > 1.0 µm
            if not color_assigned:
                colors.append(color_palette[-1])  # Use last color for values outside range
        
        return colors, size_ranges

