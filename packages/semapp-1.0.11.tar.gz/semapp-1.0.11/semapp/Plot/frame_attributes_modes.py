"""
Specialized PlotFrame classes for each mode (Normal, COMPLUS4T, KRONOS, SP3/SICA).
"""

import os
import numpy as np
import glob
import re
import pandas as pd
from PIL import Image
from PyQt5.QtWidgets import QMessageBox, QSizePolicy
from PyQt5.QtCore import Qt
import matplotlib.pyplot as plt
from semapp.Processing.klarf_reader import extract_positions
from semapp.Plot.styles import MESSAGE_BOX_STYLE

# Import from frame_attributes - this will work because frame_attributes imports this module at the end
from semapp.Plot.frame_attributes import PlotFrameBase

# Constants (re-exported for convenience)
CANVAS_SIZE = 600
FRAME_SIZE = 600


class PlotFrameNormal(PlotFrameBase):
    """PlotFrame for Normal mode."""
    
    def __init__(self, layout, button_frame):
        super().__init__(layout, button_frame)
        self.is_complus4t_mode = False
        self.is_sp3_mode = False
        self.is_kronos_mode = False
        self.is_quantitative_mode = False
        self.visualization_mode_flag = "sem_visualization"
    
    def open_tiff(self):
        """Handle TIFF file opening and display for Normal mode."""
        self.selected_wafer = getattr(self.button_frame, 'selected_option', None)
        
        if not self.selected_wafer:
            self._reset_display()
            return
        
        dirname = self.button_frame.folder_var_changed()
        folder_path = os.path.join(dirname, str(self.selected_wafer))
        
        # Find the first .001 file in the selected folder
        matching_files = glob.glob(os.path.join(folder_path, '*.001'))
        
        if matching_files:
            recipe_path = matching_files[0]
        else:
            # Check parent directory for SICA/SP3 files
            parent_files = glob.glob(os.path.join(dirname, '*.001'))
            recipe_path = None
            for f in parent_files:
                if self._is_wafer_in_klarf(f, self.selected_wafer):
                    recipe_path = f
                    break
        
        if recipe_path is None:
            self._reset_display()
            return
        
        # Extract all positions (normal mode)
        self.coordinates = self.extract_positions(recipe_path)
        
        if self.coordinates is None:
            self._reset_display()
            return
        
        tiff_path = os.path.join(folder_path, "data.tif")
        
        if not os.path.isfile(tiff_path):
            self._reset_display()
            return
        
        self._load_tiff(tiff_path)
        self._update_plot()
        
        # Don't replace plot_frame reference - it should point to the master PlotFrame class
        # self.button_frame.plot_frame = self
        
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText(f"Wafer {self.selected_wafer} opened successfully")
        msg.setWindowTitle("Wafer Opened")
        msg.setStyleSheet(MESSAGE_BOX_STYLE)
        msg.exec_()
    
    def plot_mapping_tpl(self, ax):
        """Plot the mapping for Normal mode."""
        ax.set_xlabel('X (cm)', fontsize=20)
        ax.set_ylabel('Y (cm)', fontsize=20)
        
        if self.coordinates is not None:
            # Filter: only remove rows where X or Y are NaN
            valid_mask = (
                (~pd.isna(self.coordinates['X'])) &
                (~pd.isna(self.coordinates['Y']))
            )
            filtered_coords = self.coordinates[valid_mask]
            
            if len(filtered_coords) == 0:
                return
            
            x_coords = filtered_coords['X']
            y_coords = filtered_coords['Y']
            defect_size = filtered_coords['defect_size']
            
            # Normal mode: color based on fixed threshold (10 nm)
            colors = ['blue' if size > 1.0e+01 else 'red' for size in defect_size]
            point_size = 100
            
            ax.scatter(x_coords, y_coords, color=colors, marker='o',
                       s=point_size, label='Positions')
            
            # Calculate radius
            if len(self.coordinates) == 0:
                radius = 10
                max_val = 10
            else:
                x_coords_all = self.coordinates['X']
                y_coords_all = self.coordinates['Y']
                max_val = max(abs(x_coords_all).max(), abs(y_coords_all).max())
                
                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 10
                    max_val = 10
                elif max_val <= 5:
                    radius = 5
                elif max_val <= 7.5:
                    radius = 7.5
                elif max_val <= 10:
                    radius = 10
                elif max_val <= 15:
                    radius = 15
                else:
                    radius = max_val
            
            self.radius = radius
            
            ax.set_xlim(-radius - 1, radius + 1)
            ax.set_ylim(-radius - 1, radius + 1)
            
            circle = plt.Circle((0, 0), radius, color='black',
                                fill=False, linewidth=0.5)
            ax.add_patch(circle)
            ax.set_aspect('equal')
            ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
            ax.set_axisbelow(True)
        
        ax.figure.subplots_adjust(left=0.15, right=0.95, top=0.90, bottom=0.1)
        self.canvas.draw()
    
    def _is_wafer_in_klarf(self, file_path, wafer_id):
        """Check if a specific wafer ID is in the KLARF file."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                # Check for normal format: WaferID "23"
                pattern = r'WaferID\s+"' + str(wafer_id) + r'"'
                if re.search(pattern, content):
                    return True
                return False
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            return False


class PlotFrameKronos(PlotFrameBase):
    """PlotFrame for KRONOS mode."""
    
    def __init__(self, layout, button_frame):
        super().__init__(layout, button_frame)
        self.is_complus4t_mode = False
        self.is_sp3_mode = False
        self.is_kronos_mode = True
        self.is_quantitative_mode = False
        self.visualization_mode_flag = "sem_visualization"
    
    def _check_kronos_mode(self, dirname, wafer_id=None):
        """Check if we are in KRONOS mode."""
        if not dirname or not os.path.exists(dirname):
            return False
        
        if wafer_id is not None:
            wafer_path = os.path.join(dirname, str(wafer_id))
            if os.path.exists(wafer_path):
                matching_files = glob.glob(os.path.join(wafer_path, '*.001'))
                for file_path in matching_files:
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            for i, line in enumerate(f):
                                if i >= 20:
                                    break
                                if 'KRONOS' in line or re.search(r'WaferID\s+"Read Failed\.(\d+)"', line):
                                    return True
                    except Exception:
                        pass
        
        matching_files = glob.glob(os.path.join(dirname, '*.001'))
        for file_path in matching_files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    for i, line in enumerate(f):
                        if i >= 20:
                            break
                        if 'KRONOS' in line or re.search(r'WaferID\s+"Read Failed\.(\d+)"', line):
                            return True
            except Exception:
                pass
        
        return False
    
    def open_tiff(self):
        """Handle TIFF file opening and display for KRONOS mode."""
        self.selected_wafer = getattr(self.button_frame, 'selected_option', None)
        
        if not self.selected_wafer:
            self._reset_display()
            return
        
        dirname = self.button_frame.folder_var_changed()
        folder_path = os.path.join(dirname, str(self.selected_wafer))
        
        # Load coordinates from mapping.csv
        mapping_csv_path = os.path.join(folder_path, "mapping.csv")
        if os.path.isfile(mapping_csv_path):
            try:
                self.coordinates = pd.read_csv(mapping_csv_path)
            except Exception as e:
                print(f"[KRONOS] Error loading mapping.csv: {e}")
                self.coordinates = None
        else:
            # Create mapping.csv by extracting positions from .001 file
            matching_files = glob.glob(os.path.join(folder_path, '*.001'))
            if matching_files:
                recipe_path = matching_files[0]
                self.coordinates = self.extract_positions(recipe_path)
            else:
                self.coordinates = None
        
        if self.coordinates is None:
            self._reset_display()
            return
        
        # Find the .tif file (not necessarily "data.tif")
        tiff_files = glob.glob(os.path.join(folder_path, '*.tif'))
        if not tiff_files:
            tiff_files = glob.glob(os.path.join(folder_path, '*.tiff'))
        
        if tiff_files:
            tiff_path = tiff_files[0]
        else:
            self._reset_display()
            return
        
        self._load_tiff(tiff_path)
        self._update_plot()
        
        # Don't replace plot_frame reference - it should point to the master PlotFrame class
        # self.button_frame.plot_frame = self
        
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText(f"Wafer {self.selected_wafer} opened successfully")
        msg.setWindowTitle("Wafer Opened")
        msg.setStyleSheet(MESSAGE_BOX_STYLE)
        msg.exec_()
    
    def plot_mapping_tpl(self, ax):
        """Plot the mapping for KRONOS mode."""
        ax.set_xlabel('X (cm)', fontsize=20)
        ax.set_ylabel('Y (cm)', fontsize=20)
        
        if self.coordinates is not None:
            # Filter: filter defect_size == 0 and NaN X/Y for KRONOS
            valid_mask = (
                (self.coordinates['defect_size'] != 0.0) &
                (~pd.isna(self.coordinates['X'])) &
                (~pd.isna(self.coordinates['Y']))
            )
            filtered_coords = self.coordinates[valid_mask]
            
            if len(filtered_coords) == 0:
                return
            
            x_coords = filtered_coords['X']
            y_coords = filtered_coords['Y']
            defect_size = filtered_coords['defect_size']
            
            # Normal mode: color based on fixed threshold (10 nm)
            colors = ['blue' if size > 1.0e+01 else 'red' for size in defect_size]
            point_size = 100
            
            ax.scatter(x_coords, y_coords, color=colors, marker='o',
                       s=point_size, label='Positions')
            
            # Calculate radius
            if len(self.coordinates) == 0:
                radius = 10
                max_val = 10
            else:
                x_coords_all = self.coordinates['X']
                y_coords_all = self.coordinates['Y']
                max_val = max(abs(x_coords_all).max(), abs(y_coords_all).max())
                
                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 10
                    max_val = 10
                elif max_val <= 5:
                    radius = 5
                elif max_val <= 7.5:
                    radius = 7.5
                elif max_val <= 10:
                    radius = 10
                elif max_val <= 15:
                    radius = 15
                else:
                    radius = max_val
            
            self.radius = radius
            
            ax.set_xlim(-radius - 1, radius + 1)
            ax.set_ylim(-radius - 1, radius + 1)
            
            circle = plt.Circle((0, 0), radius, color='black',
                                fill=False, linewidth=0.5)
            ax.add_patch(circle)
            ax.set_aspect('equal')
            ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
            ax.set_axisbelow(True)
        
        ax.figure.subplots_adjust(left=0.15, right=0.95, top=0.90, bottom=0.1)
        self.canvas.draw()


class PlotFrameComplus4T(PlotFrameBase):
    """PlotFrame for COMPLUS4T mode."""
    
    def __init__(self, layout, button_frame):
        super().__init__(layout, button_frame)
        self.is_complus4t_mode = True
        self.is_sp3_mode = False
        self.is_kronos_mode = False
        self.is_quantitative_mode = False
        self.visualization_mode_flag = "sem_visualization"
    
    def _check_complus4t_mode(self, dirname):
        """Check if we are in COMPLUS4T mode."""
        if not dirname or not os.path.exists(dirname):
            return False
        
        matching_files = glob.glob(os.path.join(dirname, '*.001'))
        for file_path in matching_files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    if 'COMPLUS4T' in content:
                        return True
            except Exception:
                pass
        
        return False
    
    def _is_wafer_in_klarf(self, file_path, wafer_id):
        """Check if a specific wafer ID is in the KLARF file."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                # Check for COMPLUS4T format: WaferID "@23"
                pattern_complus4t = r'WaferID\s+"@' + str(wafer_id) + r'"'
                if re.search(pattern_complus4t, content):
                    return True
                return False
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            return False
    
    def _update_visualization_buttons_visibility(self):
        """Update visibility and state of visualization buttons for COMPLUS4T mode."""
        if not hasattr(self, 'quantitative_button') or not hasattr(self, 'sem_visualization_button'):
            return
        
        # COMPLUS4T mode: Show both buttons (user can switch between modes)
        self.quantitative_button.show()
        self.sem_visualization_button.show()
        
        # Update state based on persistent flag
        if self.visualization_mode_flag == "quantitative":
            self.quantitative_button.blockSignals(True)
            self.sem_visualization_button.blockSignals(True)
            self.quantitative_button.setChecked(True)
            self.quantitative_button.setStyleSheet(self._get_visualization_button_style(True))
            self.sem_visualization_button.setChecked(False)
            self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(False))
            self.quantitative_button.blockSignals(False)
            self.sem_visualization_button.blockSignals(False)
        else:
            self.quantitative_button.blockSignals(True)
            self.sem_visualization_button.blockSignals(True)
            self.sem_visualization_button.setChecked(True)
            self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(True))
            self.quantitative_button.setChecked(False)
            self.quantitative_button.setStyleSheet(self._get_visualization_button_style(False))
            self.quantitative_button.blockSignals(False)
            self.sem_visualization_button.blockSignals(False)
    
    def _position_overview_button(self):
        """Position the Overview button for COMPLUS4T mode."""
        if self.overview_button is None:
            return
        
        try:
            self.layout.removeWidget(self.overview_button)
        except (RuntimeError, AttributeError):
            pass
        
        # For COMPLUS4T: Image Type is at (1,3,2,1), Run Function is at (0,4,1,1)
        # Place Overview at (1,4,1,1) to be below Run Function, second row only
        self.layout.addWidget(self.overview_button, 1, 4, 1, 1)
    
    def open_tiff(self):
        """Handle TIFF file opening and display for COMPLUS4T mode."""
        self.selected_wafer = getattr(self.button_frame, 'selected_option', None)
        
        if not self.selected_wafer:
            self._reset_display()
            return
        
        dirname = self.button_frame.folder_var_changed()
        
        # Check visualization mode from persistent flag
        visualization_mode = getattr(self, 'visualization_mode_flag', 'sem_visualization')
        
        if visualization_mode == "quantitative":
            # Quantitative mode: load mapping_all_defect.csv and show histogram
            wafer_folder = os.path.join(dirname, str(self.selected_wafer))
            mapping_all_path = os.path.join(wafer_folder, "mapping_all_defect.csv")
            
            if os.path.isfile(mapping_all_path):
                try:
                    self.coordinates = pd.read_csv(mapping_all_path)
                except Exception as e:
                    print(f"[COMPLUS4T Quantitative] ERROR loading mapping_all_defect.csv: {e}")
                    self.coordinates = None
            else:
                self.coordinates = None
            
            # Don't load TIFF images for quantitative mode
            self.image_list = []
            self.current_index = 0
            
            # Update plot with coordinates
            if self.coordinates is not None and len(self.coordinates) > 0:
                self._update_plot()
                self._create_defect_size_histogram()
                # Don't replace plot_frame reference - it should point to the master PlotFrame class
        # self.button_frame.plot_frame = self
                
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Information)
                msg.setText(f"Quantitative mode: {len(self.coordinates)} defects loaded from mapping_all_defect.csv")
                msg.setWindowTitle("Quantitative Mode")
                msg.exec_()
            else:
                self._reset_display()
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText(f"mapping_all_defect.csv not found for wafer {self.selected_wafer}")
                msg.setWindowTitle("File Not Found")
                msg.exec_()
            
            return
        else:
            # SEM visualization mode: normal behavior (load TIFF and mapping.csv)
            matching_files = glob.glob(os.path.join(dirname, '*.001'))
            recipe_path = None
            
            for file_path in matching_files:
                if self._is_wafer_in_klarf(file_path, self.selected_wafer):
                    recipe_path = file_path
                    break
            
            if recipe_path is None:
                self._reset_display()
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText(f"No .001 file found for wafer {self.selected_wafer}")
                msg.setWindowTitle("File Not Found")
                msg.exec_()
                return
            
            # Find the only .tiff file in the parent directory
            tiff_files = glob.glob(os.path.join(dirname, '*.tiff'))
            if not tiff_files:
                tiff_files = glob.glob(os.path.join(dirname, '*.tif'))
            if not tiff_files:
                self._reset_display()
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText(f"No TIFF file found in {dirname}")
                msg.setWindowTitle("File Not Found")
                msg.exec_()
                return
            
            tiff_path = tiff_files[0]
            
            # Extract positions for the specific wafer (uses mapping.csv)
            self.coordinates = self.extract_positions(recipe_path, wafer_id=self.selected_wafer)
            
            if self.coordinates is None:
                self._reset_display()
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText(f"Failed to extract coordinates for wafer {self.selected_wafer}")
                msg.setWindowTitle("Error")
                msg.exec_()
                return
            
            self._load_tiff(tiff_path)
            self._update_plot()
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setText(f"Wafer {self.selected_wafer} opened successfully")
            msg.setWindowTitle("Wafer Opened")
            msg.setStyleSheet(MESSAGE_BOX_STYLE)
            msg.exec_()
    
    def plot_mapping_tpl(self, ax):
        """Plot the mapping for COMPLUS4T mode."""
        ax.set_xlabel('X (cm)', fontsize=20)
        ax.set_ylabel('Y (cm)', fontsize=20)
        
        if self.coordinates is not None:
            # Filter: only remove rows where X or Y are NaN
            valid_mask = (
                (~pd.isna(self.coordinates['X'])) &
                (~pd.isna(self.coordinates['Y']))
            )
            filtered_coords = self.coordinates[valid_mask]
            
            if len(filtered_coords) == 0:
                return
            
            x_coords = filtered_coords['X']
            y_coords = filtered_coords['Y']
            defect_size = filtered_coords['defect_size']
            
            # Check if we're in quantitative mode
            if hasattr(self, 'is_quantitative_mode') and self.is_quantitative_mode:
                # Quantitative mode: use fixed color ranges
                colors, size_ranges = self._get_color_by_size_quantitative(defect_size)
                point_size = 100
                
                # Get threshold from slider
                threshold = 0.0
                if self.button_frame and hasattr(self.button_frame, 'get_selected_image'):
                    result = self.button_frame.get_selected_image()
                    if result is not None:
                        threshold = result[0]
                
                # Apply threshold: points with size < threshold become white with black edge
                edge_colors = []
                face_colors = []
                for i, size in enumerate(defect_size):
                    if size < threshold:
                        face_colors.append('white')
                        edge_colors.append('black')
                    else:
                        face_colors.append(colors[i])
                        edge_colors.append('black')
                
                ax.scatter(x_coords, y_coords, c=face_colors, edgecolors=edge_colors,
                          linewidths=1.0, marker='o', s=point_size, label='Positions')
            else:
                # SEM visualization mode: color based on slider threshold
                threshold = 0.0
                result = self.button_frame.get_selected_image()
                if result is not None:
                    threshold = result[0]
                
                # Red if size >= threshold, blue otherwise
                colors = ['blue' if size >= threshold else 'red' for size in defect_size]
                point_size = 100
                ax.scatter(x_coords, y_coords, color=colors, marker='o',
                           s=point_size, label='Positions')
            
            # Calculate radius
            if len(self.coordinates) == 0:
                radius = 10
                max_val = 10
            else:
                x_coords_all = self.coordinates['X']
                y_coords_all = self.coordinates['Y']
                max_val = max(abs(x_coords_all).max(), abs(y_coords_all).max())
                
                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 10
                    max_val = 10
                elif max_val <= 5:
                    radius = 5
                elif max_val <= 7.5:
                    radius = 7.5
                elif max_val <= 10:
                    radius = 10
                elif max_val <= 15:
                    radius = 15
                else:
                    radius = max_val
            
            self.radius = radius
            
            ax.set_xlim(-radius - 1, radius + 1)
            ax.set_ylim(-radius - 1, radius + 1)
            
            circle = plt.Circle((0, 0), radius, color='black',
                                fill=False, linewidth=0.5)
            ax.add_patch(circle)
            ax.set_aspect('equal')
            ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
            ax.set_axisbelow(True)
        
        ax.figure.subplots_adjust(left=0.15, right=0.95, top=0.90, bottom=0.1)
        self.canvas.draw()
    
    def on_quantitative_clicked(self):
        """Handle click on Quantitative button."""
        if not self.button_frame:
            return
        
        self.quantitative_button.blockSignals(True)
        self.sem_visualization_button.blockSignals(True)
        
        self.quantitative_button.setChecked(True)
        self.sem_visualization_button.setChecked(False)
        
        self.visualization_mode_flag = "quantitative"
        self.is_quantitative_mode = True
        self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(False))
        self.quantitative_button.setStyleSheet(self._get_visualization_button_style(True))
        
        self.quantitative_button.blockSignals(False)
        self.sem_visualization_button.blockSignals(False)
        
        # Load mapping_all_defect.csv
        dirname = self.button_frame.folder_var_changed()
        if not dirname or not self.selected_wafer:
            return
        
        wafer_folder = os.path.join(dirname, str(self.selected_wafer))
        mapping_all_path = os.path.join(wafer_folder, "mapping_all_defect.csv")
        
        if os.path.isfile(mapping_all_path):
            try:
                self.coordinates = pd.read_csv(mapping_all_path)
                self.plot_mapping_tpl(self.ax)
                self._create_defect_size_histogram()
                self.canvas.draw()
            except Exception as e:
                pass
    
    def on_sem_visualization_clicked(self):
        """Handle click on SEM visualization button."""
        if not self.button_frame:
            return
        
        self.quantitative_button.blockSignals(True)
        self.sem_visualization_button.blockSignals(True)
        
        self.sem_visualization_button.setChecked(True)
        self.quantitative_button.setChecked(False)
        
        self.visualization_mode_flag = "sem_visualization"
        self.is_quantitative_mode = False
        self.quantitative_button.setStyleSheet(self._get_visualization_button_style(False))
        self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(True))
        
        self.quantitative_button.blockSignals(False)
        self.sem_visualization_button.blockSignals(False)
        
        if hasattr(self.button_frame, 'selected_option'):
            self.selected_wafer = self.button_frame.selected_option
            if self.selected_wafer:
                self.open_tiff()


class PlotFrameSP3(PlotFrameBase):
    """PlotFrame for SP3/SICA mode."""
    
    def __init__(self, layout, button_frame):
        super().__init__(layout, button_frame)
        self.is_complus4t_mode = False
        self.is_sp3_mode = True
        self.is_kronos_mode = False
        self.is_quantitative_mode = False
        self.visualization_mode_flag = "sem_visualization"
    
    def _load_defects_database(self, dirname):
        """Load defects database from defects_database.parquet or defects_database.csv.gz."""
        def is_gzip_file(path):
            try:
                with open(path, 'rb') as f:
                    return f.read(2) == b'\x1f\x8b'
            except:
                return False
        
        # Try Parquet first
        parquet_path = os.path.join(dirname, "defects_database.parquet")
        if os.path.exists(parquet_path):
            try:
                df = pd.read_parquet(parquet_path)
                return df
            except ImportError:
                pass
            except Exception:
                pass
        
        # Try compressed CSV
        csv_gz_path = os.path.join(dirname, "defects_database.csv.gz")
        if os.path.exists(csv_gz_path):
            try:
                df = pd.read_csv(csv_gz_path, compression='gzip')
                return df
            except Exception:
                pass
        
        # Try regular CSV
        csv_path = os.path.join(dirname, "defects_database.csv")
        if os.path.exists(csv_path):
            try:
                if is_gzip_file(csv_path):
                    df = pd.read_csv(csv_path, compression='gzip')
                else:
                    df = pd.read_csv(csv_path)
                return df
            except Exception:
                pass
        
        return None
    
    def _update_visualization_buttons_visibility(self):
        """Update visibility and state of visualization buttons for SP3 mode."""
        if not hasattr(self, 'quantitative_button') or not hasattr(self, 'sem_visualization_button'):
            return
        
        # SP3 mode: Show only Quantitative button, hide SEM visualization
        self.quantitative_button.show()
        self.sem_visualization_button.hide()
        self.quantitative_button.blockSignals(True)
        self.quantitative_button.setChecked(True)
        self.quantitative_button.setStyleSheet(self._get_visualization_button_style(True))
        self.quantitative_button.blockSignals(False)
        self.visualization_mode_flag = "quantitative"
        self.is_quantitative_mode = True
    
    def _configure_overview_button(self):
        """Configure overview button size for SP3 mode."""
        self.overview_button.setFixedWidth(250)
        self.overview_button.setMaximumHeight(100)
    
    def _position_overview_button(self):
        """Position the Overview button for SP3 mode."""
        if self.overview_button is None:
            return
        
        try:
            self.layout.removeWidget(self.overview_button)
        except (RuntimeError, AttributeError):
            pass
        
        # For SP3/SICA: (1,4,1,1) - below Run function
        self.layout.addWidget(self.overview_button, 1, 4, 1, 1)
    
    def _is_wafer_in_klarf(self, file_path, wafer_id):
        """Check if a specific wafer ID is in the KLARF file."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
                # Check for SP3 format: WaferID "W_23" or WaferID "23"
                pattern_sp3_w = r'WaferID\s+"W_' + str(wafer_id) + r'"'
                pattern_sp3 = r'WaferID\s+"' + str(wafer_id) + r'"'
                if re.search(pattern_sp3_w, content) or re.search(pattern_sp3, content):
                    return True
                
                # Check for SICA format: WaferID "waferIDnumber23" (extract number from string)
                pattern_sica_waferid = r'WaferID\s+"[^"]*' + str(wafer_id) + r'[^"]*"'
                if re.search(pattern_sica_waferid, content):
                    return True
                
                # Check for SICA format: Slot 23 (fallback)
                pattern_sica_slot = r'Slot\s+' + str(wafer_id)
                if re.search(pattern_sica_slot, content):
                    return True
                
                return False
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            return False
    
    def open_tiff(self):
        """Handle plot mapping for SP3/SICA mode - load from defects_database and plot mapping."""
        if not self.button_frame:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("Button frame not available")
            msg.setWindowTitle("Error")
            msg.exec_()
            return
        
        self.selected_wafer = getattr(self.button_frame, 'selected_option', None)
        
        if not self.selected_wafer:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("Please select a wafer first")
            msg.setWindowTitle("Error")
            msg.exec_()
            return
        
        dirname = self.button_frame.folder_var_changed()
        if not dirname:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("No directory selected")
            msg.setWindowTitle("Error")
            msg.exec_()
            return
        
        # Load defects database
        all_defects = self._load_defects_database(dirname)
        if all_defects is None:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText(f"defects_database file not found in {dirname}\nPlease run extraction first.")
            msg.setWindowTitle("Error")
            msg.exec_()
            return
        
        # Filter for selected wafer
        if 'wafer_id' not in all_defects.columns:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("defects_database does not contain 'wafer_id' column")
            msg.setWindowTitle("Error")
            msg.exec_()
            return
        
        wafer_defects = all_defects[all_defects['wafer_id'] == self.selected_wafer].copy()
        
        if len(wafer_defects) == 0:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText(f"No defects found for wafer {self.selected_wafer} in defects_database")
            msg.setWindowTitle("Error")
            msg.exec_()
            return
        
        # Convert to coordinates format
        if 'defect_size' not in wafer_defects.columns:
            wafer_defects['defect_size'] = wafer_defects['defect_area']
        
        self.coordinates = pd.DataFrame({
            'defect_id': wafer_defects['defect_id'],
            'X': wafer_defects['X'],
            'Y': wafer_defects['Y'],
            'defect_size': wafer_defects['defect_size'],
            'defect_area': wafer_defects['defect_area'] if 'defect_area' in wafer_defects.columns else wafer_defects['defect_size']
        })
        
        # Create histogram of defect sizes
        self._create_defect_size_histogram()
        
        # Try to load TIFF images from wafer subdirectory
        wafer_path = os.path.join(dirname, str(self.selected_wafer))
        tiff_path = os.path.join(wafer_path, "data.tif")
        if os.path.isfile(tiff_path):
            self._load_tiff(tiff_path)
        else:
            self.image_list = []
            self.current_index = 0
        
        # Update plot with extracted coordinates
        self._update_plot()
        
        # Don't replace plot_frame reference - it should point to the master PlotFrame class
        # self.button_frame.plot_frame = self
        
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText(f"Mapping for wafer {self.selected_wafer} loaded successfully\n{len(self.coordinates)} defects found")
        msg.setWindowTitle("Mapping Loaded")
        msg.setStyleSheet(MESSAGE_BOX_STYLE)
        msg.exec_()
    
    def plot_mapping_tpl(self, ax):
        """Plot the mapping for SP3 mode."""
        ax.set_xlabel('X (cm)', fontsize=20)
        ax.set_ylabel('Y (cm)', fontsize=20)
        
        if self.coordinates is not None:
            # Filter: only remove rows where X or Y are NaN
            valid_mask = (
                (~pd.isna(self.coordinates['X'])) &
                (~pd.isna(self.coordinates['Y']))
            )
            filtered_coords = self.coordinates[valid_mask]
            
            if len(filtered_coords) == 0:
                return
            
            x_coords = filtered_coords['X']
            y_coords = filtered_coords['Y']
            defect_size = filtered_coords['defect_size']
            
            # SP3 mode: use 5 color ranges based on defect size
            colors, size_ranges = self._get_color_by_size_sp3(defect_size)
            point_size = 20
            
            # Get threshold from slider (threshold is in nm for SP3)
            threshold = 0.0
            if self.button_frame and hasattr(self.button_frame, 'get_selected_image'):
                result = self.button_frame.get_selected_image()
                if result is not None:
                    threshold_nm = result[0]
                    threshold = threshold_nm / 1000.0  # Convert nm to µm
            
            # Apply threshold: points with size < threshold become white with black edge
            edge_colors = []
            face_colors = []
            for i, size in enumerate(defect_size):
                if size < threshold:
                    face_colors.append('white')
                    edge_colors.append('black')
                else:
                    face_colors.append(colors[i])
                    edge_colors.append('black')
            
            ax.scatter(x_coords, y_coords, c=face_colors, edgecolors=edge_colors,
                      linewidths=1.0, marker='o', s=point_size, label='Positions')
            
            # Calculate radius
            if len(self.coordinates) == 0:
                radius = 10
                max_val = 10
            else:
                x_coords_all = self.coordinates['X']
                y_coords_all = self.coordinates['Y']
                max_val = max(abs(x_coords_all).max(), abs(y_coords_all).max())
                
                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 10
                    max_val = 10
                elif max_val <= 5:
                    radius = 5
                elif max_val <= 7.5:
                    radius = 7.5
                elif max_val <= 10:
                    radius = 10
                elif max_val <= 15:
                    radius = 15
                else:
                    radius = max_val
            
            self.radius = radius
            
            ax.set_xlim(-radius - 1, radius + 1)
            ax.set_ylim(-radius - 1, radius + 1)
            
            circle = plt.Circle((0, 0), radius, color='black',
                                fill=False, linewidth=0.5)
            ax.add_patch(circle)
            ax.set_aspect('equal')
            ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
            ax.set_axisbelow(True)
        
        ax.figure.subplots_adjust(left=0.15, right=0.95, top=0.90, bottom=0.1)
        self.canvas.draw()

