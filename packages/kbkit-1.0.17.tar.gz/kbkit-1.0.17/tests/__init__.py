"""Tests for the kbkit package."""
