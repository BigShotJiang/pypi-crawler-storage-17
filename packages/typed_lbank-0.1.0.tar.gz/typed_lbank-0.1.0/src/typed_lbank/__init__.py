"""
### Typed Lbank
> A fully typed, validated async client for the Lbank API

- Details
"""