# Typed Lbank

> A fully typed, validated async client for the Lbank API

Use *autocomplete* instead of documentation.

🚧 Under construction.