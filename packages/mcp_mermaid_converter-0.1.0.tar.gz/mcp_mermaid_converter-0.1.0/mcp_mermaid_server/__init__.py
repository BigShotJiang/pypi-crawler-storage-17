"""MCP Mermaid转图片服务

这是一个基于MCP协议的服务，可以将Mermaid图表转换为图片格式。
"""

__version__ = "0.1.0"

