"""安装脚本（用于向后兼容）"""

from setuptools import setup

# 主要配置在pyproject.toml中
# 这个文件仅用于向后兼容
setup()

