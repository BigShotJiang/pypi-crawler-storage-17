"""
Central place to define the version of chemomae.
This file is read by setup/pyproject and by chemomae.__init__.
"""

__version__ = "0.1.5"
