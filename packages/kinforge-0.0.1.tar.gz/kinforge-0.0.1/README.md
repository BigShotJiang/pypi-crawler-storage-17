# kinforge

**Kinforge** is an upcoming open-source tool to generate robot and simulation
models (SDF, URDF, and others) from validated JSON specifications.

🚧 This is a placeholder release to reserve the project name.