from sotoki.constants import VERSION


def test_dummy():
    assert VERSION
