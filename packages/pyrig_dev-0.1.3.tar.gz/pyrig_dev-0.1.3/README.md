# pyrig-dev

This is a minimal package that contains pyrigs dev dependecies.
This simplifies pyrigs handling of dev deps and keeps pyproject.toml clean.