if __name__ == '__main__':
    from .cbr import main
    main()