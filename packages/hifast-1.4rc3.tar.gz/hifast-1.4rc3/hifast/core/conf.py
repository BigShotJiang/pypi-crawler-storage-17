
## FAST location
height  = 1110.03  # meter
long = 1.8650006658875442 # radian
lat = 0.44772847428643703 # radian
## line
restfreq = 1420.405751768 # Mhz
## constant
vlight = 299792.458 # km/s