# HiFAST

**HiFAST** is a pipeline designed for the calibration and imaging of HI (neutral hydrogen) data from the Five-hundred-meter Aperture Spherical radio Telescope (FAST).

Documentation: https://hifast.readthedocs.io/