"""Tests for core modules."""

