"""Tests for signal modules."""

