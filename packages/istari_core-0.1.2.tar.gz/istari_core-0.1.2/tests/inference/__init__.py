"""Tests for inference modules."""

