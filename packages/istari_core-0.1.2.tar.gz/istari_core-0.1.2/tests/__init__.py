"""Tests for Istari."""

