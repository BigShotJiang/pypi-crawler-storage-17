## Description

OpenVoiceOS Microphone Files plugin

Will monitor `~/file_microphone` for new files, feed them as audio for the microphone, and delete them after consumption

## Install

`pip install ovos-microphone-plugin-files`
