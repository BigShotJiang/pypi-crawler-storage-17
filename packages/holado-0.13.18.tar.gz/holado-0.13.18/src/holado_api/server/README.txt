Article comparing 20 frameworks:
	https://zuplo.com/blog/2024/11/04/top-20-python-api-frameworks-with-openapi

For API-First developement with OpenAPI:
	Connexion
	With FastAPI: https://medium.com/@georgedimitropulos/generate-python-fastapi-server-from-openapi-file-099bfa944d3b
	PyAPI: https://pyapi-server.readthedocs.io/en/latest/
