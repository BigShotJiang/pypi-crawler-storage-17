"""
Anything to do with the library system: https://kegs.oliverasp.co.uk/
"""
# It may potentially be more efficient to webscrape this using selenium
from .news import get_news
