# SAP Datasphere MCP Server
# File: __init__.py
# Version: v1

"""Top-level package for the SAP Datasphere MCP Server."""

__all__ = ["__version__"]

__version__ = "0.1.0"
