from .evaluator import evaluate_syllable_segmentation, evaluate_segmentation

__all__ = ["evaluate_syllable_segmentation", "evaluate_segmentation"]
