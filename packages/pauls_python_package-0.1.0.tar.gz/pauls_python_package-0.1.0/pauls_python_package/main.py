def add(x: int, y: int):
    return x + y


if __name__ == "__main__":
    print("Hello, world!")
    print("Did you know that 2 + 3 =", add(2, 3))
