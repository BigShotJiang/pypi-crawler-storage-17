# SPDX-FileCopyrightText: 2023-present Oori Data <info@oori.dev>
# SPDX-License-Identifier: Apache-2.0
# onya.cli

'''
Command-line interfaces for Onya.

The canonical console script is `onya`, configured via `pyproject.toml`.
'''

