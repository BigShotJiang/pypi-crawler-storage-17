"""
Label-sync (or related) decoders
"""
