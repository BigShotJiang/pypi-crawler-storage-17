"""Protocol handler interfaces for omnibase_spi v0.3.0."""

from omnibase_spi.protocols.handlers.protocol_handler import ProtocolHandler

__all__ = ["ProtocolHandler"]
