# sysom_pai_client/__init__.py
__version__ = "1.0.0"
__author__ = "Your Name"