"""Basic tests for strands_tools package."""

import strands_tools


def test_package_import():
    """Test that the package can be imported."""
    assert strands_tools is not None
