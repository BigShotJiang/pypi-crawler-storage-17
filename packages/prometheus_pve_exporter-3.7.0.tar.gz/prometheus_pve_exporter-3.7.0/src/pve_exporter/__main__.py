"""
Proxmox VE exporter for the Prometheus monitoring system.
"""

from pve_exporter.cli import main
main()
