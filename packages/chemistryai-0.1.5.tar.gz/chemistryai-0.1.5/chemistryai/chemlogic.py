from rdkit import Chem
from rdkit.Chem import AllChem, Draw

# ============================================================
# Chemical Graph
# ============================================================

class GraphNode:
    def __init__(self):
        self.nodes = {}        # node_id -> atom symbol
        self.node_tags = {}    # node_id -> set(tags)
        self.edges = {}        # i -> j -> {"bond": int, "tags": set}
        self._next_id = 0

    # ---------- Nodes ----------
    def add_node(self, atom, tags=None):
        idx = self._next_id
        self.nodes[idx] = atom
        self.node_tags[idx] = set(tags) if tags else set()
        self.edges[idx] = {}
        self._next_id += 1
        return idx

    # ---------- Edges ----------
    def add_edge(self, i, j, bond=1, tags=None):
        if bond not in (1, 2, 3):
            raise ValueError("Bond must be 1, 2, or 3")
        data = {"bond": bond, "tags": set(tags) if tags else set()}
        self.edges[i][j] = data
        self.edges[j][i] = data

    # ---------- Cycle Detection ----------
    def find_cycle(self):
        """
        Find a single cycle in the graph using DFS.
        Returns list of node IDs forming the cycle, or None if acyclic.
        """
        visited = set()
        parent = {}
        
        def dfs(v, p):
            visited.add(v)
            parent[v] = p
            
            for neighbor in self.edges[v]:
                if neighbor == p:  # skip parent edge
                    continue
                if neighbor in visited:
                    # Found cycle - reconstruct it
                    cycle = [neighbor]
                    curr = v
                    while curr != neighbor:
                        cycle.append(curr)
                        curr = parent[curr]
                    return cycle
                else:
                    result = dfs(neighbor, v)
                    if result:
                        return result
            return None
        
        # Try from each unvisited node
        for node in self.nodes:
            if node not in visited:
                cycle = dfs(node, None)
                if cycle:
                    return cycle
        return None

    def has_cycle(self):
        """Check if graph contains a cycle"""
        return self.find_cycle() is not None

    def tag_mainchain(self, atom="C", tag="mainchain"):
        """
        Select principal chain with strict priority:
        1️⃣ Aldehyde carbon gets lowest locant
        2️⃣ Alcohol carbon gets next priority
        """
        # Identify functional group carbons
        aldehyde_carbons = set()
        alcohol_carbons = set()
        
        for node_id, symbol in self.nodes.items():
            if symbol == "O":
                for nbr, edge in self.edges[node_id].items():
                    if self.nodes.get(nbr) == "C":
                        if edge.get("bond") == 2:  # C=O → aldehyde
                            aldehyde_carbons.add(nbr)
                        else:  # single bond → alcohol
                            alcohol_carbons.add(nbr)

        carbons = [i for i, sym in self.nodes.items() if sym == atom]
        raw_chains = []

        # DFS to get all acyclic chains
        def dfs(v, visited, path):
            visited.add(v)
            path.append(v)
            extended = False
            for n in self.edges[v]:
                if n not in visited and self.nodes[n] == atom:
                    dfs(n, visited, path)
                    extended = True
            if not extended:
                raw_chains.append(path.copy())
            path.pop()
            visited.remove(v)

        for c in carbons:
            dfs(c, set(), [])

        if not raw_chains:
            return [], {}

        # Only chains containing aldehyde/alcohol carbons
        priority_carbons = aldehyde_carbons or alcohol_carbons
        candidate_chains = [ch for ch in raw_chains if set(ch) & priority_carbons] or raw_chains

        # Choose longest chains
        max_len = max(len(ch) for ch in candidate_chains)
        long_chains = [ch for ch in candidate_chains if len(ch) == max_len]

        # Score chains (unsaturation, substituents)
        def score_chain(chain):
            bonds = [self.edges[chain[i]][chain[i+1]].get("bond", 1) for i in range(len(chain)-1)]
            unsat_count = sum(b > 1 for b in bonds)
            substituents = sum(
                1 for i, atom_id in enumerate(chain)
                if any(nbr not in chain for nbr in self.edges[atom_id])
            )
            return (unsat_count, -substituents)  # more unsaturation, more substituents preferred

        best_chain = min(long_chains, key=score_chain)

        # Orient chain to give lowest locant to aldehyde (then alcohol)
        def get_priority_positions(chain):
            for group in (aldehyde_carbons, alcohol_carbons):
                locs = [i for i, atom_id in enumerate(chain) if atom_id in group]
                if locs:
                    return locs
            return []

        priority_positions = get_priority_positions(best_chain)
        if priority_positions:
            # Flip if highest-priority group is closer to end
            if min(priority_positions) > len(best_chain) - 1 - max(priority_positions):
                best_chain = best_chain[::-1]

        # Assign numbering
        numbering = {}
        for pos, atom_id in enumerate(best_chain, 1):
            self.node_tags.setdefault(atom_id, set()).add(tag)
            numbering[atom_id] = pos

        return best_chain, numbering



    def _tag_cyclic_mainchain(self, cycle, tag="mainchain"):
        """
        Number a monocyclic ring according to IUPAC rules.
        Special handling for phenols: carbon bearing -OH fixed at position 1.
        """
        L = len(cycle)

        # Find carbon attached to -OH (if any)
        phenol_carbon = None
        cycle_set = set(cycle)
        for atom in cycle:
            for nbr in self.edges[atom]:
                if nbr not in cycle_set and self.nodes.get(nbr) == "O":
                    phenol_carbon = atom
                    break
            if phenol_carbon:
                break

        def get_ring_bonds(oriented):
            return [self.edges[oriented[i]][oriented[(i + 1) % L]].get("bond", 1) for i in range(L)]

        def unsat_locants(bonds):
            return tuple(sorted(i + 1 for i, b in enumerate(bonds) if b > 1))

        def double_locants(bonds):
            return tuple(sorted(i + 1 for i, b in enumerate(bonds) if b == 2))

        def substituent_locants(oriented):
            locs = []
            ring_set = set(oriented)
            for i, atom in enumerate(oriented):
                if any(nbr not in ring_set for nbr in self.edges[atom]):
                    locs.append(i + 1)
            return tuple(sorted(locs))

        best = cycle
        best_score = ((999,),) * 10

        for start in range(L):
            for direction in [1, -1]:
                oriented = [cycle[(start + direction * i) % L] for i in range(L)]
                bonds = get_ring_bonds(oriented)

                # For phenols: force the OH-bearing carbon to position 1
                if phenol_carbon is not None and oriented[0] != phenol_carbon:
                    continue

                # Aromatic rings: ignore unsaturation, only substituent locants
                is_aromatic = (bonds.count(2) == 3 and bonds.count(1) == 3)
                if is_aromatic:
                    score = (substituent_locants(oriented),)
                else:
                    score = (
                        unsat_locants(bonds),
                        double_locants(bonds),
                        substituent_locants(oriented),
                    )

                if score < best_score:
                    best_score = score
                    best = oriented

        # Tag and number
        numbering = {}
        for pos, atom_id in enumerate(best, 1):
            self.node_tags[atom_id].add(tag)
            numbering[atom_id] = pos

        return best, numbering


    def collect_subgraph(self, start_node, exclude=None):
        """
        Recursively collect all nodes connected to start_node, excluding nodes in `exclude`.
        """
        if exclude is None:
            exclude = set()
        seen = set()

        def dfs(node):
            if node in seen or node in exclude:
                return
            seen.add(node)
            for nbr in self.edges[node]:
                dfs(nbr)

        dfs(start_node)
        return list(seen)

    # ---------- Subgraph extraction ----------
    def subgraph(self, node_ids):
        sub = GraphNode()
        m = {}

        for i in node_ids:
            m[i] = sub.add_node(self.nodes[i], self.node_tags[i])

        for i in node_ids:
            for j, e in self.edges[i].items():
                if j in node_ids and m[i] < m[j]:
                    sub.add_edge(m[i], m[j], e["bond"], e["tags"])

        return sub

    def get_substituents(self, mainchain):
        """
        Return a dictionary mapping each main-chain atom to a list of subgraphs
        representing substituents (everything attached to that atom that's not on mainchain),
        including cyclic substituents.
        """
        attachments = {}
        main_set = set(mainchain)

        for atom in mainchain:
            subs = []

            for neighbor in self.edges[atom]:
                if neighbor in main_set:
                    continue  # skip main chain atoms

                # Collect full connected subgraph starting from this neighbor
                sub_nodes = self.collect_subgraph(neighbor, exclude=main_set)
                subgraph = self.subgraph(sub_nodes)

                # Include all subgraphs, cyclic or acyclic
                subs.append(subgraph)

            if subs:
                attachments[atom] = subs

        return attachments



# ============================================================
# Tree Node (Chemical AST)
# ============================================================

class TreeNode:
    def __init__(self, pos, chain_length, nodes=None, label="", bonds=None, is_cyclic=False, atom=None):
        """
        pos: position on parent chain
        chain_length: length of this chain segment
        nodes: list of node indices
        label: "mainchain", "substituent", or "cycle"
        bonds: list of bond orders between consecutive nodes
        is_cyclic: True if this represents a ring structure
        """
        self.pos = pos
        self.chain_length = chain_length
        self.nodes = nodes or []
        self.label = label
        self.bonds = bonds or [1] * (len(self.nodes) - 1)
        self.is_cyclic = is_cyclic
        self.children = []
        self.atom = atom
    def add_child(self, c):
        self.children.append(c)

    def __repr__(self, level=0):
        ind = "  " * level
        s = f"{ind}TreeNode(pos={self.pos}, chain_length={self.chain_length}"
        if self.label:
            s += f", label={self.label}"
        if self.is_cyclic:
            s += f", cyclic=True"
        if self.nodes:
            s += f", nodes={self.nodes}"
        if self.bonds:
            s += f", bonds={self.bonds}"
        s += ")"
        for c in self.children:
            s += "\n" + c.__repr__(level + 1)
        return s


# ============================================================
# IUPAC NAMING CONSTANTS
# ============================================================

ALKANE = {
    1: "meth",
    2: "eth",
    3: "prop",
    4: "but",
    5: "pent",
    6: "hex",
    7: "hept",
    8: "oct",
    9: "non",
    10: "dec"
}

MULTIPLIER = {
    2: "di",
    3: "tri",
    4: "tetra",
    5: "penta",
    6: "hexa",
    7: "hepta"
}

HALOGEN = {
    "F": "fluoro",
    "Cl": "chloro",
    "Br": "bromo",
    "I": "iodo"
}
HETERO = {
    "O": "oxy"
}

# ============================================================
# Tree Building Functions
# ============================================================
def _build_substituent_tree(graph, attach_atom, start_atom, mainchain_set, visited=None):
    """
    Build a substituent TreeNode starting from start_atom.
    Handles:
      - Linear chains
      - Alcohols (-OH)
      - Halogens
      - Cyclic substituents (phenyl, cyclohexyl, etc.)
    """
    if visited is None:
        visited = set()
    visited.add(start_atom)

    atom_symbol = graph.nodes[start_atom]

    # Terminal halogen
    if atom_symbol in HALOGEN:
        return TreeNode(pos=0, chain_length=1, nodes=[start_atom], label="halogen", atom=atom_symbol, bonds=[])

    # Terminal oxygen (-OH)
    if atom_symbol == "O":
        return TreeNode(pos=0, chain_length=1, nodes=[start_atom], label="alcohol", atom="O", bonds=[])

    # Collect full subgraph excluding mainchain
    sub_nodes = graph.collect_subgraph(start_atom, exclude=mainchain_set)
    subgraph = graph.subgraph(sub_nodes)

    # Check if subgraph is cyclic
    cycle = subgraph.find_cycle()
    if cycle:
        # Substituent is a cycle
        return _build_cyclic_tree(subgraph, cycle)

    # Otherwise, treat as acyclic chain
    # Build longest carbon chain starting from start_atom
    def dfs_chain(v, parent):
        best = [v]
        for n in subgraph.edges[v]:
            if n == parent or n in visited or subgraph.nodes[n] != "C":
                continue
            path = [v] + dfs_chain(n, v)
            if len(path) > len(best):
                best = path
        return best

    chain = dfs_chain(start_atom, attach_atom)
    chain_set = set(chain)

    bonds = [subgraph.edges[chain[i]][chain[i + 1]].get("bond", 1) for i in range(len(chain)-1)]
    node = TreeNode(pos=0, chain_length=len(chain), nodes=chain, label="substituent", bonds=bonds)

    # Recursively attach branches (halogens, alcohols, further carbons)
    for i, atom in enumerate(chain):
        atom_neighbors = [n for n in subgraph.edges[atom] if n not in chain_set and n not in visited]

        for h in [n for n in atom_neighbors if subgraph.nodes[n] in HALOGEN]:
            visited.add(h)
            node.add_child(TreeNode(pos=i+1, chain_length=1, nodes=[h], label="halogen", atom=subgraph.nodes[h]))

        for o in [n for n in atom_neighbors if subgraph.nodes[n] == "O"]:
            visited.add(o)
            node.add_child(TreeNode(pos=i+1, chain_length=1, nodes=[o], label="alcohol", atom="O"))

        for c in [n for n in atom_neighbors if subgraph.nodes[n] == "C"]:
            child_node = _build_substituent_tree(subgraph, atom, c, mainchain_set=set(), visited=visited)
            child_node.pos = i+1
            node.add_child(child_node)

    return node

def build_tree_recursive(graph: GraphNode) -> TreeNode:
    """
    Correct parent selection: prefer chain with principal group (-OH)
    """
    # Find alcohol-bearing carbons
    alcohol_carbons = set()
    for node_id, symbol in graph.nodes.items():
        if symbol == "O":
            for nbr in graph.edges[node_id]:
                if graph.nodes.get(nbr) == "C":
                    alcohol_carbons.add(nbr)
                    break

    cycle = graph.find_cycle()

    # Only use ring as parent for phenols (-OH on ring) or no -OH
    if cycle and (not alcohol_carbons or any(c in set(cycle) for c in alcohol_carbons)):
        return _build_cyclic_tree(graph, cycle)

    # All other cases: acyclic chain (includes -OH if present)
    return _build_acyclic_tree(graph)

def _build_acyclic_tree(graph: GraphNode) -> TreeNode:
    """Build tree for acyclic structure with correct main chain selection,
    handles aldehydes by temporarily removing aldehyde oxygens."""
    
    # 1️⃣ Identify main chain
    mainchain, numbering = graph.tag_mainchain()
    #print(mainchain)
    if not mainchain:
        raise ValueError("No main chain found")

    L = len(mainchain)
    bonds = [
        graph.edges[mainchain[i]][mainchain[i + 1]].get("bond", 1)
        for i in range(L - 1)
    ]

    root = TreeNode(
        pos=0,
        chain_length=L,
        nodes=mainchain[:],
        label="mainchain",
        bonds=bonds
    )

    # 2️⃣ Detect aldehyde oxygens (C=O)
    aldehyde_pairs = []  # list of (carbon, oxygen)
    for c in mainchain:
        for nbr, edge in graph.edges[c].items():
            if graph.nodes.get(nbr) == "O" and edge.get("bond") == 2:
                aldehyde_pairs.append((c, nbr))

    # 3️⃣ Temporarily remove aldehyde oxygens from graph
    removed_nodes = []
    removed_edges = []

    for c, o in aldehyde_pairs:
        # Save edges
        removed_edges.append((c, o, graph.edges[c][o]))
        removed_edges.append((o, c, graph.edges[o][c]))

        # Remove edges
        del graph.edges[c][o]
        del graph.edges[o][c]

        # Save and remove oxygen node
        removed_nodes.append((o, graph.nodes[o]))
        del graph.nodes[o]
        del graph.edges[o]

    # 4️⃣ Build normal substituents without aldehyde oxygens
    attachments = graph.get_substituents(mainchain)
    for atom_id in mainchain:
        attach_pos = numbering[atom_id]
        subgraphs = attachments.get(atom_id, [])
        for subgraph in subgraphs:
            if not subgraph.nodes:
                continue
            start_atom = next(iter(subgraph.nodes))
            sub_root = _build_substituent_tree(
                graph=subgraph,
                attach_atom=None,
                start_atom=start_atom,
                mainchain_set=set()
            )
            if sub_root:
                sub_root.pos = attach_pos
                root.add_child(sub_root)

    # 5️⃣ Add carbonyls as child nodes, relabeling internal as ketone
    terminal_carbons = {mainchain[0], mainchain[-1]}  # only terminal carbons are aldehyde

    for c, _ in aldehyde_pairs:
        label = "aldehyde" if c in terminal_carbons else "ketone"
        root.add_child(
            TreeNode(
                pos=numbering[c],
                chain_length=1,
                nodes=[c],
                label=label,
                bonds=[]
            )
        )


    # 6️⃣ Restore aldehyde oxygens to graph (no effect on mainchain)
    for o, symbol in removed_nodes:
        graph.nodes[o] = symbol
        graph.edges[o] = {}

    for a, b, edge in removed_edges:
        graph.edges.setdefault(a, {})[b] = edge

    # 7️⃣ Sort children: maintain mainchain order
    root.children.sort(key=lambda x: (x.pos, x.label))
    return root


def _build_cyclic_tree(graph: GraphNode, cycle: list) -> TreeNode:
    """
    Build tree for monocyclic structure with correct IUPAC numbering.
    - Aromatic rings (benzene-like) treated specially
    - Phenols: carbon attached to -OH fixed at position 1
    - Lowest locants for unsaturation, then substituents
    """
    L = len(cycle)
    cycle_set = set(cycle)

    # Detect aromaticity (all aromatic tags or Kekulé alternating doubles)
    ring_bonds = [graph.edges[cycle[i]][cycle[(i + 1) % L]].get("bond", 1) for i in range(L)]
    ring_tags = [graph.edges[cycle[i]][cycle[(i + 1) % L]].get("tags", set()) for i in range(L)]
    is_aromatic = all("aromatic" in t for t in ring_tags) or (ring_bonds.count(2) == 3 and ring_bonds.count(1) == 3)

    # Find substituent positions (any non-ring attachment)
    substituents_dict = {}  # atom_id -> True if has substituent
    for atom_id in cycle:
        for neighbor in graph.edges[atom_id]:
            if neighbor not in cycle_set:
                substituents_dict[atom_id] = True
                break

    # Find phenol carbon (ring carbon attached to oxygen = -OH)
    phenol_carbon = None
    for atom_id in cycle:
        for neighbor in graph.edges[atom_id]:
            if neighbor not in cycle_set and graph.nodes.get(neighbor) == "O":
                phenol_carbon = atom_id
                break
        if phenol_carbon:
            break

    # Orient the cycle
    oriented_cycle = _orient_cycle(graph, cycle, substituents_dict, is_aromatic, phenol_carbon)

    # Re-compute bonds in the final orientation
    bonds = [graph.edges[oriented_cycle[i]][oriented_cycle[(i + 1) % L]].get("bond", 1)
             for i in range(L)]

    root = TreeNode(
        pos=0,
        chain_length=L,
        nodes=oriented_cycle,
        label="cycle",
        bonds=bonds,
        is_cyclic=True
    )

    # Attach substituents
    attachments = graph.get_substituents(oriented_cycle)
    for atom_id, subgraphs in attachments.items():
        for subgraph in subgraphs:
            sub_root = _build_substituent_tree(
                subgraph,
                attach_atom=None,
                start_atom=next(iter(subgraph.nodes)),  # first node
                mainchain_set=set()
            )
            sub_root.pos = oriented_cycle.index(atom_id) + 1
            root.add_child(sub_root)

    root.children.sort(key=lambda x: x.pos)
    return root


def _orient_cycle(graph: GraphNode, cycle: list, substituents_dict: dict,
                  is_aromatic: bool = False, phenol_carbon=None):
    """
    Return the best oriented cycle list according to IUPAC rules.
    """
    L = len(cycle)

    def get_cycle_bonds(oriented):
        return [graph.edges[oriented[i]][oriented[(i + 1) % L]].get("bond", 1)
                for i in range(L)]

    def unsat_locants(bonds):
        return tuple(i + 1 for i, b in enumerate(bonds) if b > 1)

    def double_locants(bonds):
        return tuple(i + 1 for i, b in enumerate(bonds) if b == 2)

    def substituent_locants(oriented):
        return tuple(i + 1 for i, a in enumerate(oriented) if a in substituents_dict)

    def substituent_alpha_sequence(oriented):
        seq = []
        for i, atom in enumerate(oriented):
            if atom in substituents_dict:
                for nbr in graph.edges[atom]:
                    if nbr not in oriented:
                        sym = graph.nodes[nbr]
                        name = HALOGEN.get(sym, sym)
                        seq.append((i + 1, name))
        return tuple(sorted(seq, key=lambda x: (x[1], x[0])))

    best = cycle
    best_score = None

    for start in range(L):
        for direction in (1, -1):
            oriented = [cycle[(start + direction * i) % L] for i in range(L)]
            bonds = get_cycle_bonds(oriented)

            # Phenol rule
            if phenol_carbon is not None and oriented[0] != phenol_carbon:
                continue

            if is_aromatic:
                score = (
                    substituent_locants(oriented),
                    substituent_alpha_sequence(oriented),
                )
            else:
                score = (
                    unsat_locants(bonds),
                    double_locants(bonds),
                    substituent_locants(oriented),
                    substituent_alpha_sequence(oriented),
                )

            if best_score is None or score < best_score:
                best_score = score
                best = oriented

    return best

# ============================================================
# IUPAC Naming Functions
# ============================================================

def needs_parentheses(name: str) -> bool:
    """
    Check if a substituent name needs parentheses in the IUPAC name.
    
    According to IUPAC recommendations:
    - Parentheses are required when the substituent name contains locants
      (commas or hyphens for numbers) or is itself a complex name with hyphens.
    - Simple alkyl (ethyl, propyl) or single-word prefixes do not need them.
    - Unsaturated substituents like "prop-1-en-1-yl" need them.
    - "hydroxymethyl" does NOT need parentheses (treated as simple prefix).
    
    Returns True if parentheses are needed.
    """
    if name == "hydroxymethyl":
        return False  # special case: no parentheses for hydroxymethyl
    
    # Needs parentheses if:
    # - Contains a comma (multiple locants inside, e.g., "1,1-dichloroethyl")
    # - Contains a hyphen followed by digit (unsaturation locant: "prop-1-enyl")
    # - Contains hyphen but not just a multiplier (e.g., "di" or "tri" alone is okay, but "1-enyl" is not)
    if "," in name:
        return True
    if "-" in name:
        # Split to check if any part after hyphen is numeric (locant)
        parts = name.split("-")
        if any(part.isdigit() or (len(part) > 1 and part[0].isdigit()) for part in parts):
            return True
        # If it has hyphen but no digits, it's likely a complex base like "cyclohexyl" — no parens needed
        # But unsaturated always have digits → already covered
        return False
    
    return False


import re

VOWEL_STARTING_SUFFIXES = (
    "ol", "al", "one", "oic", "amine", "amide", "thiol", "hydroxy"
)

def elide_unsaturation_e(name: str) -> str:
    """
    Removes the terminal 'e' from 'ene' or 'yne' ONLY when
    followed by a vowel-starting suffix (IUPAC vowel elision).
    
    Examples:
    - prop-2-ene-1-ol  -> prop-2-en-1-ol
    - but-1-yne-3-ol   -> but-1-yn-3-ol
    - prop-1-ene       -> unchanged
    - benzene          -> unchanged
    """

    # Never touch benzene or substituted benzenes
    if "benzene" in name:
        return name

    for suf in VOWEL_STARTING_SUFFIXES:
        # ene → en
        name = re.sub(
            rf"ene(-\d+)?-{suf}",
            lambda m: f"en{m.group(1) or ''}-{suf}",
            name
        )

        # yne → yn
        name = re.sub(
            rf"yne(-\d+)?-{suf}",
            lambda m: f"yn{m.group(1) or ''}-{suf}",
            name
        )

    return name


def tree_to_iupac(root):
    """
    Convert TreeNode to IUPAC name.
    Handles both acyclic and cyclic structures.
    """
    return elide_unsaturation_e(iupac_name(root))
def iupac_name(root: TreeNode) -> str:
    """
    Bottom-up IUPAC naming.
    Node-type driven (never infers from chain_length alone).
    Aldehydes and ketones are treated like alcohols, but use 'al' or 'one' as suffix.
    Alcohols are converted to 'hydroxy' if aldehyde or ketone is present or if part of a substituent.
    """

    from collections import defaultdict

    # ============================================================
    # 1. CORE (parent chain / ring)
    # ============================================================
    cyclic = getattr(root, "is_cyclic", False)
    is_benzene = (
        cyclic
        and root.chain_length == 6
        and root.bonds.count(2) == 3
        and root.bonds.count(1) == 3
    )

    if is_benzene:
        stem = "benzene"
    elif cyclic:
        stem = "cyclo" + ALKANE[root.chain_length]
    else:
        stem = ALKANE[root.chain_length]

    # ============================================================
    # 2. UNSATURATION
    # ============================================================
    double_locs = [i + 1 for i, b in enumerate(root.bonds) if b == 2]
    triple_locs = [i + 1 for i, b in enumerate(root.bonds) if b == 3]

    unsat_parts = []
    if not is_benzene:
        if double_locs:
            mult = MULTIPLIER[len(double_locs)] if len(double_locs) > 1 else ""
            unsat_parts.append(f"{','.join(map(str, double_locs))}-{mult}ene")
        if triple_locs:
            mult = MULTIPLIER[len(triple_locs)] if len(triple_locs) > 1 else ""
            unsat_parts.append(f"{','.join(map(str, triple_locs))}-{mult}yne")

    unsaturation = "-".join(unsat_parts)

    # ============================================================
    # 3. ALCOHOLS / ALDEHYDES / KETONES
    # ============================================================
    alcohol_locs = sorted(c.pos for c in root.children if c.label == "alcohol")
    aldehyde_locs = sorted(c.pos for c in root.children if c.label == "aldehyde")
    ketone_locs = sorted(c.pos for c in root.children if c.label == "ketone")

    has_carbonyl = bool(aldehyde_locs or ketone_locs)

    # Alcohol suffix only if no aldehyde/ketone
    alcohol_suffix = ""
    if alcohol_locs and not is_benzene and not has_carbonyl:
        mult = MULTIPLIER[len(alcohol_locs)] if len(alcohol_locs) > 1 else ""
        alcohol_suffix = f"-{','.join(map(str, alcohol_locs))}-{mult}ol"

    # Aldehyde suffix
    aldehyde_suffix = ""
    if aldehyde_locs and not is_benzene:
        mult = MULTIPLIER[len(aldehyde_locs)] if len(aldehyde_locs) > 1 else ""
        aldehyde_suffix = f"-{','.join(map(str, aldehyde_locs))}-{mult}al"

    # Ketone suffix
    ketone_suffix = ""
    if ketone_locs and not is_benzene:
        mult = MULTIPLIER[len(ketone_locs)] if len(ketone_locs) > 1 else ""
        ketone_suffix = f"-{','.join(map(str, ketone_locs))}-{mult}one"

    # ============================================================
    # 4. FLATTEN SUBSTITUENTS
    # ============================================================
    substituents = []
    stack = list(root.children)

    while stack:
        node = stack.pop()

        # ---------- HALOGEN ----------
        if node.label == "halogen":
            substituents.append((node.pos, HALOGEN[node.atom]))
            continue

        # ---------- ALCOHOL ----------
        if node.label == "alcohol":
            if is_benzene or has_carbonyl:
                substituents.append((node.pos, "hydroxy"))
            continue  # otherwise handled as suffix

        # ---------- ALDEHYDE ----------
        if node.label == "aldehyde":
            if is_benzene:
                substituents.append((node.pos, "formyl"))
            continue  # otherwise handled as suffix

        # ---------- KETONE ----------
        if node.label == "ketone":
            if is_benzene:
                substituents.append((node.pos, "oxo"))
            continue  # otherwise handled as suffix

        # ---------- CARBON / CYCLE ----------
        hal_count = defaultdict(int)
        non_hal_children = []

        for c in node.children:
            if c.label == "halogen":
                hal_count[c.atom] += 1
            else:
                non_hal_children.append(c)

        hal_prefix = ""
        for atom in sorted(hal_count, key=lambda a: HALOGEN[a]):
            count = hal_count[atom]
            mult = MULTIPLIER[count] if count > 1 else ""
            hal_prefix += f"{mult}{HALOGEN[atom]}"

        # Determine base name
        if node.label == "cycle":
            if node.chain_length == 6 and node.bonds.count(2) == 3:
                base = "phenyl"
            else:
                base = "cyclo" + ALKANE[node.chain_length][:-1]
        else:
            # Check for alcohol children → hydroxy-alkyl
            if any(c.label == "alcohol" for c in node.children):
                base = "hydroxy" + ALKANE[node.chain_length] + "yl"
            else:
                base = ALKANE[node.chain_length] + "yl"

        name = hal_prefix + base

        if non_hal_children:
            name = f"({name})"
            stack.extend(non_hal_children)

        substituents.append((node.pos, name))

    # ============================================================
    # 5. GROUP + MULTIPLICITY
    # ============================================================
    grouped = defaultdict(list)
    for pos, name in substituents:
        grouped[name].append(pos)

    prefixes = []
    for name in sorted(grouped, key=str.lower):
        locs = sorted(grouped[name])
        mult = MULTIPLIER[len(locs)] if len(locs) > 1 else ""
        prefixes.append(f"{','.join(map(str, locs))}-{mult}{name}")

    # ============================================================
    # 6. ASSEMBLE CORE NAME
    # ============================================================
    core = stem
    if not is_benzene:
        if unsaturation:
            core += "-" + unsaturation
        # Suffix priority: aldehyde > ketone > alcohol
        if aldehyde_suffix:
            if not unsaturation:
                core += "an"  # add 'an' before 'al'
            core += aldehyde_suffix
        elif ketone_suffix:
            if not unsaturation:
                core += "an"  # add 'an' before 'one'
            core += ketone_suffix
        elif alcohol_suffix:
            if not unsaturation:
                core += "an"  # add 'an' before 'ol'
            core += alcohol_suffix
        else:
            if not unsaturation:
                core += "ane"

    # ============================================================
    # 7. FINAL NAME
    # ============================================================
    if is_benzene and len(prefixes) == 1 and prefixes[0].startswith("1-"):
        prefixes[0] = prefixes[0][2:]

    return "-".join(prefixes) + core if prefixes else core


# RDKit Conversion Functions
# ============================================================

def graphnode_to_rdkit_mol(graph):
    rw_mol = Chem.RWMol()
    id_map = {}

    for node_id, atom_symbol in graph.nodes.items():
        atom = Chem.Atom(atom_symbol)
        idx = rw_mol.AddAtom(atom)
        id_map[node_id] = idx

    added = set()
    for i, neighbors in graph.edges.items():
        for j, data in neighbors.items():
            if (j, i) in added:
                continue

            bond_order = data.get("bond", 1)
            bond_type = {1: Chem.BondType.SINGLE,
                         2: Chem.BondType.DOUBLE,
                         3: Chem.BondType.TRIPLE}.get(bond_order, Chem.BondType.SINGLE)
            rw_mol.AddBond(id_map[i], id_map[j], bond_type)
            added.add((i, j))

    mol = rw_mol.GetMol()

    # --- Skip full sanitization ---
    try:
        Chem.SanitizeMol(mol, sanitizeOps=Chem.SanitizeFlags.SANITIZE_ALL ^ Chem.SanitizeFlags.SANITIZE_PROPERTIES)
        # ^ this sanitizes structure but ignores valence errors
    except Exception as e:
        print("Warning: skipped valence sanitization:", e)

    return mol


def graphnode_to_smiles(graph, canonical=True):
    mol = graphnode_to_rdkit_mol(graph)
    return Chem.MolToSmiles(mol, canonical=canonical)


def smiles_to_graphnode(smiles: str) -> GraphNode:
    """Convert a SMILES string into a GraphNode structure, handling aromaticity."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Invalid SMILES string: {smiles}")

    Chem.Kekulize(mol, clearAromaticFlags=False)  # preserve aromatic info if needed

    graph = GraphNode()
    idx_map = {}

    # Add atoms
    for atom in mol.GetAtoms():
        symbol = atom.GetSymbol()
        # Optional: mark aromatic atoms
        if atom.GetIsAromatic():
            symbol = symbol.lower()  # lowercase to indicate aromatic (e.g., 'c' for benzene)
        node_id = graph.add_node(symbol)
        idx_map[atom.GetIdx()] = node_id

    # Add bonds
    for bond in mol.GetBonds():
        i = idx_map[bond.GetBeginAtomIdx()]
        j = idx_map[bond.GetEndAtomIdx()]

        bt = bond.GetBondType()
        if bt == Chem.BondType.SINGLE:
            order = 1
        elif bt == Chem.BondType.DOUBLE:
            order = 2
        elif bt == Chem.BondType.TRIPLE:
            order = 3
        elif bt == Chem.BondType.AROMATIC:
            order = 1  # Treat aromatic bonds as single for GraphNode; can add flag if needed
        else:
            order = 1

        tags = set()
        if bond.GetIsAromatic():
            tags.add("aromatic")

        graph.add_edge(i, j, bond=order, tags=tags)

    return graph

def draw_graph_with_rdkit(graph, filename="compound.png", size=(600, 400)):
    rw_mol = Chem.RWMol()
    atom_map = {}

    for node_id, atom_symbol in graph.nodes.items():
        # Keep halogens properly capitalized
        symbol = atom_symbol if atom_symbol in {"Cl", "Br", "I", "F"} else atom_symbol.upper()
        atom = Chem.Atom(symbol)
        # Mark aromatic atom if symbol is lowercase in GraphNode
        if atom_symbol.islower() and atom_symbol not in {"c", "n", "o"}:  # only carbons/hetero
            atom.SetIsAromatic(True)
        atom_map[node_id] = rw_mol.AddAtom(atom)

    added = set()
    for i, nbrs in graph.edges.items():
        for j, data in nbrs.items():
            key = tuple(sorted((i, j)))
            if key in added:
                continue

            bond_order = data.get("bond", 1)
            # Map bond order, mark aromatic if bond has "aromatic" tag
            if "aromatic" in data.get("tags", set()):
                bond_type = Chem.BondType.AROMATIC
            else:
                bond_type = {1: Chem.BondType.SINGLE,
                             2: Chem.BondType.DOUBLE,
                             3: Chem.BondType.TRIPLE}.get(bond_order, Chem.BondType.SINGLE)

            rw_mol.AddBond(atom_map[i], atom_map[j], bond_type)
            added.add(key)

    mol = rw_mol.GetMol()
    try:
        Chem.SanitizeMol(mol)
    except Exception as e:
        print("Sanitization failed:", e)

    AllChem.Compute2DCoords(mol)
    img = Draw.MolToImage(mol, size=size, kekulize=False, wedgeBonds=True)
    img.save(filename)
    print(f"Saved {filename}")

def iupac(graph):
    tmp = build_tree_recursive(graph)
    #print(tmp)
    return tree_to_iupac(tmp)
def smiles(string):
    return smiles_to_graphnode(string)
def draw(graph, filename="compound.png", size=(600, 400)):
    draw_graph_with_rdkit(graph, filename, size)

