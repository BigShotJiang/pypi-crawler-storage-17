from __future__ import annotations

from pathlib import Path

VIBE_ROOT = Path(__file__).parent
__version__ = "1.2.1"
