from chalk.sink._models import SinkIntegrationProtocol

__all__ = [
    "SinkIntegrationProtocol",
]
