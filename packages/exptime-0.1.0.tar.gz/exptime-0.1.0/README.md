# Expections

A simple Python module that allows you to create **custom exceptions** for specific commands.

## Features

- Easily define and raise custom exceptions.
- Simple and lightweight.
- Perfect for beginners learning how to handle errors in Python.

## Installation

You can install the module via PyPI:

```bash
pip install expections