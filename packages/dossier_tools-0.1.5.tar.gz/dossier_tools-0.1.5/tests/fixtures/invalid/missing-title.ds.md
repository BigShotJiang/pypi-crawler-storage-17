---
schema_version: "1.0.0"
name: "missing-title"
version: "1.0.0"
status: "stable"
objective: "Missing the required title field"
checksum:
  algorithm: "sha256"
  hash: "216ab7bb905f8c7f082e45237e2c6e93da18e2eef863408a10f7dd4c04a359be"
authors:
  - name: "Test Author"
---

# Missing Title

This dossier is missing the title field.
