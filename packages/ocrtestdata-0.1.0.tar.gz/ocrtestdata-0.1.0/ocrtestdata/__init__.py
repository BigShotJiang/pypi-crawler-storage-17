"""
ocrtestdata package

Provides functions to generate image-based PDF test data for OCR testing.
"""
__all__ = ["cli", "generator", "io_utils"]
__version__ = '0.1.0'