import os

API_ENDPOINT = os.environ.get("TEAMTV_API_ENDPOINT", "https://api.teamtvsport.com")
