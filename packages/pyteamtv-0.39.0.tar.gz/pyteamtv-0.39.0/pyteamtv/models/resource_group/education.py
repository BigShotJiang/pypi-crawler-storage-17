from . import _ResourceGroup


class EducationResourceGroup(_ResourceGroup):
    pass
