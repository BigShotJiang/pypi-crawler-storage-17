from . import _ResourceGroup


class LearningGroupResourceGroup(_ResourceGroup):
    pass
