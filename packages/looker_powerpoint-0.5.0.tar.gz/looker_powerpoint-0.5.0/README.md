![PyPI - Version](https://img.shields.io/pypi/v/looker-powerpoint) ![PyPI - Downloads](https://img.shields.io/pypi/dd/looker-powerpoint)




# Looker Powerpoint CLI (lppt)
## integrate looker looks with microsoft powerpoint presentations
