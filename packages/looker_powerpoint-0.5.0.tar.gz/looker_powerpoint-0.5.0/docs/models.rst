Data Models
===========

The Looker PowerPoint CLI uses Pydantic models to validate and structure data for PowerPoint shape integration.

LookerReference
---------------

.. autopydantic_model:: looker_powerpoint.models.LookerReference
   :members:
   :undoc-members:
   :show-inheritance:
