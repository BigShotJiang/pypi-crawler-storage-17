API Reference
=============

Looker Client
-------------

.. autoclass:: looker_powerpoint.looker.LookerClient
   :members:
   :undoc-members:
   :show-inheritance:

Shape Discovery Tools
---------------------

.. automodule:: looker_powerpoint.tools.find_alt_text
   :members:
   :undoc-members:
   :show-inheritance: