import rattler_build

if __name__ == "__main__":
    print(rattler_build.rattler_build_version())
