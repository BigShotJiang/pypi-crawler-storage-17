pub mod checks;
pub mod menuinst;
pub mod package_nature;
pub mod path_checks;
pub mod python;
pub mod regex_replacements;
pub mod relink;
