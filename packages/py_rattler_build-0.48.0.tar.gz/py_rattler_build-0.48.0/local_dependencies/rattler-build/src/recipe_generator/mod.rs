//! Module for generating recipes for Python (PyPI), R (CRAN), Perl (CPAN), or Lua (LuaRocks) packages

// Re-export everything from the rattler_build_recipe_generator crate
pub use rattler_build_recipe_generator::*;
