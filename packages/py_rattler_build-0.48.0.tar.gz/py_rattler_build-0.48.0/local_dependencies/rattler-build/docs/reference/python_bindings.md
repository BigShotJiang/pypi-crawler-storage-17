# Python bindings

These are the API docs for the `rattler_build` Python bindings.

::: rattler_build
    options:
        members:
            - build_recipes
            - test_package
            - upload_package_to_quetz
            - upload_package_to_artifactory
            - upload_package_to_prefix
            - upload_package_to_anaconda
            - upload_packages_to_conda_forge
