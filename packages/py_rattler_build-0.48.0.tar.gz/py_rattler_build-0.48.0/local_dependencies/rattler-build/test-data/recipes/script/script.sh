touch $PREFIX/script-executed.txt
