console.log("NodeJS script with auto-detection working!");
console.log("File extension: .js detected");
