#!/bin/bash
echo "Hello from BASH!"
