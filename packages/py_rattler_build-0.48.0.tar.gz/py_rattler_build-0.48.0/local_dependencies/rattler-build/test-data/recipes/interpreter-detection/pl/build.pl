print "Hello from Perl!\n";
