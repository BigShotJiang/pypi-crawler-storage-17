#include <stdio.h>

void absolute();
void relative();

int main() {
  printf("hello from test_link\n");
  absolute();
  relative();
}
