#include <stdio.h>

void absolute() {
  printf("hello from absolute\n");
}
