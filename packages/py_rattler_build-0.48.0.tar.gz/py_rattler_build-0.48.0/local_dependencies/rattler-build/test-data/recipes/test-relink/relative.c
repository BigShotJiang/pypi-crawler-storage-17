#include <stdio.h>

void relative() {
  printf("hello from relative\n");
}
