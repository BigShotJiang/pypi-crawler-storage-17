puts "Ruby script with auto-detection working!"
puts "File extension: .rb detected"
