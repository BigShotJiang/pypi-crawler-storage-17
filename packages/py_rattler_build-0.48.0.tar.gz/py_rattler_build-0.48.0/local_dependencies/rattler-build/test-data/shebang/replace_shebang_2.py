#!/conda-bld/bla/_placeholder_path/bin/python
# -*- coding: utf-8 -*-
import sys

print(sys.argv)

# etc
