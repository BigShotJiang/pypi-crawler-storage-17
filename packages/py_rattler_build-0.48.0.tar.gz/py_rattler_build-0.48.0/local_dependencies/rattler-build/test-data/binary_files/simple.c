// Simple C file to generate a test object file
int add(int a, int b) {
    return a + b;
}

int multiply(int x, int y) {
    return x * y;
}
