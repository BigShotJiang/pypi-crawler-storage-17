"""API routes for the AI Startup Diagnosis service."""

