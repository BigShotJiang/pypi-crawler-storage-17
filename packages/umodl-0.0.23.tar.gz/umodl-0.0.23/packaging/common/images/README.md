# files

Files used in khiops.jar:
- khiops_about.gif
- khiops_coclustering_about.gif
- khiops_coclustering.gif
- khiops.gif

Files used in packages:
- khiops_coclustering.png
- khiops.png