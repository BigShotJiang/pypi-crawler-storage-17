"""
`mnistvit` is a package providing a vision transformer for training on MNIST.

The package includes functions for training and evaluation, as well as hyperparameter
optimization.
"""
