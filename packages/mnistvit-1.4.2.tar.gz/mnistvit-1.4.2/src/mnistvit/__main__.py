from .predict import main

main()
