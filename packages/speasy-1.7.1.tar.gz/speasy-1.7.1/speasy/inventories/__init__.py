from types import SimpleNamespace
from speasy.core.inventory import FlatInventories

flat_inventories = FlatInventories()
tree = SimpleNamespace()
data_tree = tree

