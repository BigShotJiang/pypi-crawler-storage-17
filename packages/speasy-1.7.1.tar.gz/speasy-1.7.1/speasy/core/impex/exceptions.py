class MissingCredentials(Exception):
    pass


class UnavailableEndpoint(Exception):
    pass


class BadTemplateArgDefinition(Exception):
    pass
