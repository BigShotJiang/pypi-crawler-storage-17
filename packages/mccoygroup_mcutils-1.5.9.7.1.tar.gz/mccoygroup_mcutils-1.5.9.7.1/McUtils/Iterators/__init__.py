"""
Useful little iteration tools
"""

__all__ = []
from .core import *; from .core import __all__ as exposed
__all__ += exposed