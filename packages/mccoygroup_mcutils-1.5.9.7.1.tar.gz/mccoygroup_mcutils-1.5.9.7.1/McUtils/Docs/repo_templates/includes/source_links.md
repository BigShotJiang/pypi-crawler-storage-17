<div class="docs-source-link" markdown="1">
[[source](https://github.com/{gh_username}/{gh_repo}/blob/{gh_branch}/{file_url}#L{lineno})/
[edit](https://github.com/{gh_username}/{gh_repo}/edit/{gh_branch}/{file_url}#L{lineno}?message=Update%20Docs)]
</div>