from .function import durable

__all__ = ["durable"]
