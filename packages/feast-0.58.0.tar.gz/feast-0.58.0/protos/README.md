# Feast Protos

## Overview

Shared protobuf files across Feast components.
