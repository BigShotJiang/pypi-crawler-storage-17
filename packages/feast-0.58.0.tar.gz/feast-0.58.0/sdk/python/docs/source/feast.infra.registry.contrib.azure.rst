feast.infra.registry.contrib.azure package
==========================================

Submodules
----------

feast.infra.registry.contrib.azure.azure\_registry\_store module
----------------------------------------------------------------

.. automodule:: feast.infra.registry.contrib.azure.azure_registry_store
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: feast.infra.registry.contrib.azure
   :members:
   :undoc-members:
   :show-inheritance:
