feast.infra.registry package
============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   feast.infra.registry.contrib

Submodules
----------

feast.infra.registry.base\_registry module
------------------------------------------

.. automodule:: feast.infra.registry.base_registry
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.registry.caching\_registry module
---------------------------------------------

.. automodule:: feast.infra.registry.caching_registry
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.registry.file module
--------------------------------

.. automodule:: feast.infra.registry.file
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.registry.gcs module
-------------------------------

.. automodule:: feast.infra.registry.gcs
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.registry.proto\_registry\_utils module
--------------------------------------------------

.. automodule:: feast.infra.registry.proto_registry_utils
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.registry.registry module
------------------------------------

.. automodule:: feast.infra.registry.registry
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.registry.registry\_store module
-------------------------------------------

.. automodule:: feast.infra.registry.registry_store
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.registry.remote module
----------------------------------

.. automodule:: feast.infra.registry.remote
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.registry.s3 module
------------------------------

.. automodule:: feast.infra.registry.s3
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.registry.snowflake module
-------------------------------------

.. automodule:: feast.infra.registry.snowflake
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.registry.sql module
-------------------------------

.. automodule:: feast.infra.registry.sql
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: feast.infra.registry
   :members:
   :undoc-members:
   :show-inheritance:
