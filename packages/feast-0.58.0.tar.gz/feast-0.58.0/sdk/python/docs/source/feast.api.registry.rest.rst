feast.api.registry.rest package
===============================

Submodules
----------

feast.api.registry.rest.codegen\_utils module
---------------------------------------------

.. automodule:: feast.api.registry.rest.codegen_utils
   :members:
   :undoc-members:
   :show-inheritance:

feast.api.registry.rest.data\_sources module
--------------------------------------------

.. automodule:: feast.api.registry.rest.data_sources
   :members:
   :undoc-members:
   :show-inheritance:

feast.api.registry.rest.entities module
---------------------------------------

.. automodule:: feast.api.registry.rest.entities
   :members:
   :undoc-members:
   :show-inheritance:

feast.api.registry.rest.feature\_services module
------------------------------------------------

.. automodule:: feast.api.registry.rest.feature_services
   :members:
   :undoc-members:
   :show-inheritance:

feast.api.registry.rest.feature\_views module
---------------------------------------------

.. automodule:: feast.api.registry.rest.feature_views
   :members:
   :undoc-members:
   :show-inheritance:

feast.api.registry.rest.features module
---------------------------------------

.. automodule:: feast.api.registry.rest.features
   :members:
   :undoc-members:
   :show-inheritance:

feast.api.registry.rest.lineage module
--------------------------------------

.. automodule:: feast.api.registry.rest.lineage
   :members:
   :undoc-members:
   :show-inheritance:

feast.api.registry.rest.metrics module
--------------------------------------

.. automodule:: feast.api.registry.rest.metrics
   :members:
   :undoc-members:
   :show-inheritance:

feast.api.registry.rest.permissions module
------------------------------------------

.. automodule:: feast.api.registry.rest.permissions
   :members:
   :undoc-members:
   :show-inheritance:

feast.api.registry.rest.projects module
---------------------------------------

.. automodule:: feast.api.registry.rest.projects
   :members:
   :undoc-members:
   :show-inheritance:

feast.api.registry.rest.rest\_registry\_server module
-----------------------------------------------------

.. automodule:: feast.api.registry.rest.rest_registry_server
   :members:
   :undoc-members:
   :show-inheritance:

feast.api.registry.rest.rest\_utils module
------------------------------------------

.. automodule:: feast.api.registry.rest.rest_utils
   :members:
   :undoc-members:
   :show-inheritance:

feast.api.registry.rest.saved\_datasets module
----------------------------------------------

.. automodule:: feast.api.registry.rest.saved_datasets
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: feast.api.registry.rest
   :members:
   :undoc-members:
   :show-inheritance:
