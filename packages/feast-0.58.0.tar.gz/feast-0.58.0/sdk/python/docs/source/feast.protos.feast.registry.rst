feast.protos.feast.registry package
===================================

Submodules
----------

feast.protos.feast.registry.RegistryServer\_pb2 module
------------------------------------------------------

.. automodule:: feast.protos.feast.registry.RegistryServer_pb2
   :members:
   :undoc-members:
   :show-inheritance:

feast.protos.feast.registry.RegistryServer\_pb2\_grpc module
------------------------------------------------------------

.. automodule:: feast.protos.feast.registry.RegistryServer_pb2_grpc
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: feast.protos.feast.registry
   :members:
   :undoc-members:
   :show-inheritance:
