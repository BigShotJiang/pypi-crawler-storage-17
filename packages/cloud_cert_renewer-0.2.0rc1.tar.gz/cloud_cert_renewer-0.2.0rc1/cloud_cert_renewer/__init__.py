"""Cloud Certificate Renewer - Automated HTTPS certificate renewal tool for cloud services."""  # noqa: E501

__version__ = "0.2.0-rc1"
__author__ = "analyser"
__email__ = "analyser@gmail.com"
