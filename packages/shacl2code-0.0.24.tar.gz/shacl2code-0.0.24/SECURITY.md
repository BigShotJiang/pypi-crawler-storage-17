# Security Policy

## Supported Versions

These version of shacl2code are currently receiving security fixes:

| Version | Supported          |
| ------- | ------------------ |
| 0.0.x   | :white_check_mark: |

## Reporting a Vulnerability

Security issues can be reported in the [GitHub Issues](https://github.com/JPEWdev/shacl2code/issues). If accepted, the `security` label will be able to the issue
