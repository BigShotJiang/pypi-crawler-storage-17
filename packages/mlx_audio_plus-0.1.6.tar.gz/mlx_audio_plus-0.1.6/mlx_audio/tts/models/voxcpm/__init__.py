from .config import ModelArgs
from .voxcpm import Model

ModelConfig = ModelArgs
