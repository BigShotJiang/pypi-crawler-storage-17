"""CosyVoice2 conversion scripts."""
