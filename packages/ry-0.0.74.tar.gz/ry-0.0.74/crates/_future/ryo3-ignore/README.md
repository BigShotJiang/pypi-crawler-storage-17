# `ryo3-ignore`

python + `ignore` crate.

`ignore`:

- [crates.io](https://crates.io/crates/ignore)
- [docs.rs](https://docs.rs/ignore)
