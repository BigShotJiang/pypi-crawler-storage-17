# `ryo3-std`

pyo3 shims/wrappers for rust `std` library
