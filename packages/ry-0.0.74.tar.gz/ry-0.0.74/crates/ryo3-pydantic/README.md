# `ryo3-pydantic`

pydantic integration
