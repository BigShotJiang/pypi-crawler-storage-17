from tomlkit.container import Container


class TOMLDocument(Container):
    """
    A TOML document.
    """
