from cordon.segmentation.windower import SlidingWindowSegmenter

__all__ = ["SlidingWindowSegmenter"]
