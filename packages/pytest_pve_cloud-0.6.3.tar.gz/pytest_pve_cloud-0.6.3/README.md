# Python pkg - pytest-pve-cloud

Pytest project for pve cloud, contains basic methods needed in all e2e and tddog tests.

## Development

Run `pip install -e .` to dynamically work with the package.
