## 按需安装依赖

主要是有些模块太大了,不方便, 因此可选性安装,基本每个模块都可以单独使用


```bash
pip install ultralytics pycorrector cfundata ddddocr

```

