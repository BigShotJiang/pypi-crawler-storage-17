from py4swiss.engines.dubov.criteria.quality.c5 import C5
from py4swiss.engines.dubov.criteria.quality.c6 import C6
from py4swiss.engines.dubov.criteria.quality.c7 import C7
from py4swiss.engines.dubov.criteria.quality.c8 import C8
from py4swiss.engines.dubov.criteria.quality.c9 import C9
from py4swiss.engines.dubov.criteria.quality.c10 import C10

__all__ = ["C5", "C6", "C7", "C8", "C9", "C10"]
