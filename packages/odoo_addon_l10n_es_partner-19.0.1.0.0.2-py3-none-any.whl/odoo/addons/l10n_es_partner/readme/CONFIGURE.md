Para añadir cuentas bancarias a la compañía, el mejor camino es ir a
Contabilidad \> Configuración \> Contabilidad \> Cuentas bancarias.

Para añadir cuentas bancarias a los clientes/proveedores, hay que ir a
la lista de empresas desde cualquiera de los accesos, y pulsar sobre el
enlace "n Cuenta(s) bancaria(s)" que hay en la pestaña "Ventas y
compras".

Para definir el patrón del nombre a mostrar en empresas, hay que ir a
Configuración \> Técnico \> Parámetros \> Parámetros del sistema
Seleccionar la clave l10n_es_partner.name_pattern Definir el patron
utilizando las etiquetas *%(name)s* para nombre y *%(comercial_name)s*
para nombre comercial.

Para importar los datos de los bancos españoles hay que ir a 
Facturación \> Configuración \> Import spanish bank data