Incluye la siguiente funcionalidad:

- Añade el campo *Nombre comercial* a las empresas y permite buscar por
  él.
- Permite definir un patrón del nombre a mostrar a partir del nombre y
  el nombre comercial de la empresa.
- Añade los campos nombre largo, NIF y web a los bancos.
- Añade los datos de los bancos españoles extraídos del registro oficial
  del Banco de España (<http://goo.gl/mtx6ic>). El asistente realiza la
  descarga automática de Internet, pero si por cualquier razón hay algún
  problema, existe una copia local cuya última actualización fue el
  26/10/2017.
