Elasticipy.tensors.thermal_expansion
============================================

.. automodule:: elasticipy.tensors.thermal_expansion
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
