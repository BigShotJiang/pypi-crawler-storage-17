Elasticipy.interfaces.PRISMS
====================================

.. automodule:: elasticipy.interfaces.PRISMS
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
