from setuptools import setup, find_packages

setup(
    name="termella",
    version="0.0.1a",
    description="A Python library for rich text and beautiful formatting in the terminal.",
    author="codewithzaqar",
    packages=find_packages(),
    python_requires=">=3.6",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Console",
        "Programming Language :: Python :: 3",
    ],
)