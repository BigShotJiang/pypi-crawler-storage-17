from .ansi import COLORS, BG_COLORS, STYLES, RESET

class Text:
    """Represents a styled string."""

    def __init__(self, content: str):
        self.content = content
        self._codes = []

    def style(self, color=None, bg=None, styles=None):
        """Apply styles to the text object."""
        if color in COLORS:
            self._codes.append(COLORS[color])

        if bg in BG_COLORS:
            self._codes.append(BG_COLORS[bg])

        if styles:
            if isinstance(styles, str):
                styles = [styles]
            for s in styles:
                if s in STYLES:
                    self._codes.append(STYLES[s])
        return self
    
    def __str__(self):
        """Render the final ANSI string."""
        if not self._codes:
            return self.content
        
        code_str = ";".join(self._codes)
        return f"\033[{code_str}m{self.content}{RESET}"
    
    def __add__(self, other):
        return str(self) + str(other)