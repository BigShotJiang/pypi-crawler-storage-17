#########################################
Account Stock Shipment Cost Weight Module
#########################################

The *Account Stock Shipment Cost Weight Module* adds the "By Weight" as
allocation method on shipment cost.

.. toctree::
   :maxdepth: 2

   releases
