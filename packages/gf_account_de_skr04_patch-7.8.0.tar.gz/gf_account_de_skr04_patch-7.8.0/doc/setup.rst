*****
Setup
*****

.. to remove, see https://www.tryton.org/develop/guidelines/documentation#setup.rst
