******
Design
******

.. to remove, see https://www.tryton.org/develop/guidelines/documentation#design.rst
