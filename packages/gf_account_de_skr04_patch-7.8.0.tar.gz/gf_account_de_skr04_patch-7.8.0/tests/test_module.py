
from trytond.tests.test_tryton import ModuleTestCase


class AccountDeSkr04PatchTestCase(ModuleTestCase):
    "Test Account De Skr04 Patch module"
    module = 'account_de_skr04_patch'


del ModuleTestCase
