# Pacote de Teste
Esta é uma versão inicial para validar a publicação no PyPI.