"""Prompt templates bundled with Marx."""
