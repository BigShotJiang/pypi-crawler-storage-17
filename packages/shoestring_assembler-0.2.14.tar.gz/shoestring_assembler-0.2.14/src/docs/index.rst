Welcome to Shoestring Assembler's documentation!
======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   usage
   modules
   contributing
   authors
   history
   file_structure
   recipe
   sources
   user_config
   setup
   api

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
