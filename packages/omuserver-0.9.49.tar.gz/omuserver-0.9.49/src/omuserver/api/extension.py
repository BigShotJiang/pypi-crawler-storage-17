from __future__ import annotations

import abc


class Extension(abc.ABC): ...
