from .extension import (
    LoggerExtension,
)

__all__ = [
    "LoggerExtension",
]
