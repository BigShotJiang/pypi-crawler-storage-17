"""JavaScript/TypeScript AST extractor."""
