"""AST extraction utilities."""
