"""TheAuditor - Offline, air-gapped CLI for repo indexing and evidence checking."""

from importlib.metadata import version

__version__ = version("theauditor")
