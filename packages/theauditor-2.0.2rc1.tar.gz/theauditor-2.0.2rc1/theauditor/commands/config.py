"""Command configuration constants."""

DB_PATH = ".pf/repo_index.db"
WORKSET_PATH = ".pf/workset.json"
LINT_TIMEOUT = 300
