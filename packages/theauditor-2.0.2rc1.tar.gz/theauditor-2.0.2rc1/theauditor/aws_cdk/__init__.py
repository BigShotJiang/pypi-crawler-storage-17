"""AWS CDK Infrastructure-as-Code security analysis module."""

from .analyzer import AWSCdkAnalyzer

__all__ = ["AWSCdkAnalyzer"]
