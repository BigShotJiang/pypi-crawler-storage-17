import warnings

warnings.simplefilter('ignore', UserWarning)
__version__ = '1.6.1'
