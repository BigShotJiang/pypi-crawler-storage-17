# tests/test_cli.py

from pathlib import Path

from pypdf import PdfWriter

# Prefer Typer's test utility, but fall back to Click's if unavailable.
try:
    from typer.testing import CliRunner  # Typer re-exports click.testing.CliRunner
except Exception:  # pragma: no cover - robust to environments lacking typer.testing
    from click.testing import CliRunner

from textwrap import dedent

from sigdetect.cli import app


def _write_blank_pdf(path: Path) -> None:
    writer = PdfWriter()
    writer.add_blank_page(200, 200)
    with open(path, "wb") as handle:
        writer.write(handle)


def test_version():
    r = CliRunner().invoke(app, ["version"])
    assert r.exit_code == 0
    assert r.stdout.strip()


def test_detect_respects_out_dir_none(tmp_path: Path):
    pdf_root = tmp_path / "pdfs"
    pdf_root.mkdir()

    sample_pdf = pdf_root / "example.pdf"
    _write_blank_pdf(sample_pdf)

    config_path = tmp_path / "config.yml"
    config_path.write_text(
        dedent(
            f"""
            pdf_root: {pdf_root}
            out_dir: null
            engine: pypdf2
            profile: hipaa
            pseudo_signatures: true
            recurse_xobjects: true
            """
        ).strip()
    )

    runner = CliRunner()
    result = runner.invoke(app, ["detect", "--config", str(config_path)])

    assert result.exit_code == 0
    assert "Detection completed with output disabled" in result.stdout
    assert not (pdf_root / "results.json").exists()


def test_detect_recurses_by_default(tmp_path: Path):
    pdf_root = tmp_path / "pdfs"
    nested = pdf_root / "nested"
    nested.mkdir(parents=True)

    sample_pdf = nested / "example.PDF"
    _write_blank_pdf(sample_pdf)

    config_path = tmp_path / "config.yml"
    out_dir = tmp_path / "out"
    config_path.write_text(
        dedent(
            f"""
            pdf_root: {pdf_root}
            out_dir: {out_dir}
            engine: pypdf2
            profile: hipaa
            pseudo_signatures: true
            recurse_xobjects: true
            """
        ).strip()
    )

    runner = CliRunner()
    result = runner.invoke(app, ["detect", "--config", str(config_path)])

    assert result.exit_code == 0
    payload = (out_dir / "results.json").read_text()
    assert "example.PDF" in payload


def test_detect_supports_non_recursive_scan(tmp_path: Path):
    pdf_root = tmp_path / "pdfs"
    nested = pdf_root / "nested"
    nested.mkdir(parents=True)

    sample_pdf = nested / "example.pdf"
    _write_blank_pdf(sample_pdf)

    config_path = tmp_path / "config.yml"
    out_dir = tmp_path / "out"
    config_path.write_text(
        dedent(
            f"""
            pdf_root: {pdf_root}
            out_dir: {out_dir}
            engine: pypdf2
            profile: hipaa
            pseudo_signatures: true
            recurse_xobjects: true
            """
        ).strip()
    )

    runner = CliRunner()
    result = runner.invoke(app, ["detect", "--config", str(config_path), "--no-recursive"])

    assert result.exit_code != 0
    combined_output = result.stdout + getattr(result, "stderr", "")
    assert "No PDFs found" in combined_output


def test_detect_unknown_engine_errors(tmp_path: Path):
    pdf_root = tmp_path / "pdfs"
    pdf_root.mkdir()

    sample_pdf = pdf_root / "example.pdf"
    _write_blank_pdf(sample_pdf)

    config_path = tmp_path / "config.yml"
    config_path.write_text(
        dedent(
            f"""
            pdf_root: {pdf_root}
            out_dir: {tmp_path}
            engine: unknown_engine
            profile: hipaa
            pseudo_signatures: true
            recurse_xobjects: true
            """
        ).strip()
    )

    runner = CliRunner()
    result = runner.invoke(app, ["detect", "--config", str(config_path)])

    assert result.exit_code != 0
    assert result.exception is not None
    assert "Input should be 'pypdf2', 'pypdf', 'pymupdf' or 'auto'" in str(result.exception)
