from pathlib import Path

from pypdf import PdfWriter

from sigdetect.config import DetectConfiguration
from sigdetect.detector.file_result_model import FileResult
from sigdetect.wet_detection import (
    _image_candidates,
    apply_wet_detection,
    should_run_wet_pipeline,
)


def _blank_pdf(path: Path) -> None:
    writer = PdfWriter()
    writer.add_blank_page(200, 200)
    with open(path, "wb") as handle:
        writer.write(handle)


def _empty_file_result(filename: str) -> FileResult:
    return FileResult(
        File=filename,
        SizeKilobytes=None,
        PageCount=0,
        ElectronicSignatureFound=False,
        ScannedPdf=True,
        MixedContent=False,
        SignatureCount=0,
        SignaturePages="",
        Roles="unknown",
        Hints="",
        Signatures=[],
    )


def test_should_run_wet_pipeline_flagged_when_no_esignatures() -> None:
    result = _empty_file_result("doc.pdf")
    assert should_run_wet_pipeline(result) is True

    result.ElectronicSignatureFound = True
    result.SignatureCount = 1
    assert should_run_wet_pipeline(result) is False


def test_apply_wet_detection_marks_manual_review_when_unavailable(monkeypatch, tmp_path: Path) -> None:
    pdf_path = tmp_path / "doc.pdf"
    _blank_pdf(pdf_path)
    configuration = DetectConfiguration(
        pdf_root=tmp_path,
        out_dir=tmp_path,
        engine="pypdf2",
        detect_wet_signatures=True,
    )
    file_result = _empty_file_result("doc.pdf")

    # Force dependency check to fail without requiring actual Tesseract install.
    monkeypatch.setattr("sigdetect.wet_detection.fitz", None)
    applied = apply_wet_detection(pdf_path, configuration, file_result)

    assert applied is False
    assert "ManualReview" in file_result.Hints


def test_apply_wet_detection_noop_when_disabled(tmp_path: Path) -> None:
    pdf_path = tmp_path / "doc.pdf"
    _blank_pdf(pdf_path)
    configuration = DetectConfiguration(
        pdf_root=tmp_path,
        out_dir=tmp_path,
        engine="pypdf2",
        detect_wet_signatures=False,
    )
    file_result = _empty_file_result("doc.pdf")

    applied = apply_wet_detection(pdf_path, configuration, file_result)

    assert applied is False
    assert file_result.Signatures == []
    assert "ManualReview" not in file_result.Hints


def test_image_candidate_detection_infers_role_from_nearby_text() -> None:
    class Rect:
        def __init__(self, x0, y0, x1, y1):
            self.x0, self.y0, self.x1, self.y1 = x0, y0, x1, y1
            self.width = x1 - x0
            self.height = y1 - y0

    class DummyPage:
        def __init__(self):
            self.rect = Rect(0, 0, 612, 792)

        def get_image_info(self, xrefs=True):
            return [{"bbox": Rect(360.0, 600.0, 440.0, 640.0)}]

        def get_text(self, mode):
            assert mode == "words"
            # Token near the image with client keyword to drive role inference
            return [
                (350.0, 595.0, 420.0, 605.0, "Client", 0, 0, 0, 0),
                (100.0, 100.0, 150.0, 110.0, "Unrelated", 0, 0, 0, 0),
            ]

    candidates = _image_candidates(DummyPage())

    assert candidates, "Expected image-based wet signature candidate"
    candidate = candidates[0]
    assert candidate.Role == "client"
    assert candidate.Score >= 0.84
    assert "image_signature:true" in candidate.Evidence
