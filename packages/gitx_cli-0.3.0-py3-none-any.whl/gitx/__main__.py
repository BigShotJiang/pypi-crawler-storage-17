from gitx.main import app


def main() -> None:
    app()


if __name__ == "__main__":  # pragma: no cover - module entry
    main()
