import logging

APP_NAME = 'reoxide'
APP_AUTHOR = 'reoxide'

log = logging.getLogger(APP_NAME)
