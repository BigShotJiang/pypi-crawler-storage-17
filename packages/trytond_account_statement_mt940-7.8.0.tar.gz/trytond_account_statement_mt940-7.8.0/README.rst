##############################
Account Statement MT940 Module
##############################

The *Account Statement MT940 Module* implements the import of `MT940
<https://en.wikipedia.org/wiki/MT940>`_ files as statements.

.. toctree::
   :maxdepth: 2

   releases
