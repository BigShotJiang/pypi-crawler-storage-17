from pyDatabases.auxfuncs import *
from pyDatabases.gpyDB import *