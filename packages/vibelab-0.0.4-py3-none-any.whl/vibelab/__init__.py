"""VibeLab - Rigorous evaluation tool for comparing LLM coding agents."""

__version__ = "0.0.4"
