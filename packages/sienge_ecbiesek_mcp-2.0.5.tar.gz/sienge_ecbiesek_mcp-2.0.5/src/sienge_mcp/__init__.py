"""
Sienge MCP Server Package
Model Context Protocol integration for Sienge API
"""

__version__ = "1.5.2"
__author__ = "ECBIESEK"
__email__ = "ti@ecbiesek.com"
__description__ = "🏗️ Model Context Protocol (MCP) server for Sienge API integration - Brazilian construction ERP system"
