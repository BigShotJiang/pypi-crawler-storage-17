# V1LeaderboardView

- result - leaderboard_table - leaderboard_summary  - LEADERBOARD_VIEW_FULL: Full view of the Leaderboard. No fields are omitted.  - LEADERBOARD_VIEW_BASIC_WITH_TABLE: View of the Leaderboard that is the same as LEADERBOARD_VIEW_BASIC but it includes the leaderboard_table field.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


