# V1LeaderboardType

 - LEADERBOARD_TYPE_UNSPECIFIED: Unspecified type.  - LEADERBOARD_TYPE_STANDALONE: Standalone leaderboard.  - LEADERBOARD_TYPE_DASHBOARD: Leaderboard is part of a dashboard.  - LEADERBOARD_TYPE_SERVICE: Leaderboard created by other service such as h2oGPTe.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


