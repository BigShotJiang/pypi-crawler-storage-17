This module only introduces the main data model and can be used as is to
manually store DNS records. It provides the main objects.

Additional modules for specific connectors need to be added to manage
the service provider connection.
