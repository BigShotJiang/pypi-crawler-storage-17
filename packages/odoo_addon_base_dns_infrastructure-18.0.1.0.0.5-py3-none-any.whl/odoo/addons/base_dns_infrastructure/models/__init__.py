# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import dns_record_type
from . import dns_domain_zone
from . import dns_record
from . import res_partner
