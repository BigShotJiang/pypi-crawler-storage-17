"""
Scikit-learn encoding feature groups.

This module provides feature groups for categorical encoding transformations
using scikit-learn encoders.
"""
