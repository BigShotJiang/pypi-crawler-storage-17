"""
Scikit-learn pipeline feature groups.

This module provides feature groups that wrap entire scikit-learn pipelines
as single features, demonstrating mloda's pipeline management capabilities.
"""
