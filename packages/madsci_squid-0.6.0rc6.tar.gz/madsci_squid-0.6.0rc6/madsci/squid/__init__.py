"""The MADSci Squid server and workcell engine."""
