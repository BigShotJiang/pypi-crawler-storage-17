"""File Generation Skill - Provides file generation capabilities."""
from .skill import FileGenerationSkill

__all__ = ["FileGenerationSkill"]
