from .core import analyze_speaker_emotion

__all__ = ["analyze_speaker_emotion"]