"""Lifelogger - Personal activity tracking daemon with LLM summarization."""

__version__ = "0.1.2"
