"""Daemon management for background operation."""

from .runner import LifeloggerDaemon

__all__ = ["LifeloggerDaemon"]
