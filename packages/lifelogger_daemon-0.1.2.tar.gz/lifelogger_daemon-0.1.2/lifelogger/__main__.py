"""Allow running lifelogger as a module: python -m lifelogger"""

from lifelogger.cli import main

if __name__ == "__main__":
    main()
