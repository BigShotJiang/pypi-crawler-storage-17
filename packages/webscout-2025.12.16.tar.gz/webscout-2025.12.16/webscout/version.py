__version__ = "2025.12.16"
__prog__ = "webscout"
