from django.apps import AppConfig


class MigrationApiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "utg_base.migration"
