fn main(){}

use std::{slice::Iter, cmp::{max, self}, mem::replace, collections::{HashSet, HashMap}, ops::Index, ascii::AsciiExt};
use rand::Rng;
use regex::Regex;
use md5;
use std::any::{Any, TypeId};

/*
You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    
*/
fn cycpattern_check(a: &str, b: &str) -> bool {


    for i in 0..b.len() {
        let rotate = format!("{}{}", &b[i..], &b[..i]);
        if a.contains(&rotate) {
            return true;
        }
    }
    false
}

