# Get Started with Microsoft Agent Framework Ollama

Please install this package as the extra for `agent-framework`:

```bash
pip install agent-framework-ollama --pre
```

and see the [README](https://github.com/microsoft/agent-framework/tree/main/python/README.md) for more information.

# Run samples with the Ollama Conector

You can find samples how to run the connector under the [Getting_started] (./getting_started/README.md) folder 
