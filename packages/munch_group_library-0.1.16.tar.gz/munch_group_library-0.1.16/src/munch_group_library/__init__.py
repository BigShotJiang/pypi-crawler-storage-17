
from .modulename import functionname