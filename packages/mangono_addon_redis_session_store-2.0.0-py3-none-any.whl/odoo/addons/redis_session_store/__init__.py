import logging
import random
import os

from environ_odoo_config.environ import Environ

import odoo
from odoo.tools.misc import str2bool

from . import redis_session

from .env_config import RedisEnvConfig
from .redis_session import RedisSessionStore

_logger = logging.getLogger("odoo.session.REDIS")

try:
    import redis

    _logger.info("Lib redis installed")
except ImportError:
    redis = None

MAJOR = odoo.release.version_info[0]
if MAJOR >= 16:
    from odoo.http import Session as OdooSessionClass
else:
    from odoo.http import OpenERPSession as OdooSessionClass


def get_server_wide_modules(odoo_version: int):
    """Jusqu'à la v17, les serveurs wide modules se trouvent dans odoo.config.server_wide_modules
    À compter de la v17, il est possible de les récupérer en odoo.tools.config["server_wide_modules"] mais cela est
    nécessaire en v19
    """
    if odoo_version >= 17:
        from odoo.tools import config

        return config["server_wide_modules"]

    else:
        from odoo import conf

        return conf.server_wide_modules


@odoo.tools.func.lazy_property
def session_store(self):
    config = RedisEnvConfig(Environ.new())
    return RedisSessionStore(redis_config=config, session_class=OdooSessionClass)


def session_gc(session_store):
    # session_gc is called at setup_session so we keep the randomness bit to only vacuum once in a while.
    if random.random() < 0.001:
        session_store.vacuum()


def _post_load_module():
    if "redis_session_store" not in get_server_wide_modules(MAJOR):
        return
    if not redis:
        raise ImportError("Please install package redis")
    redis_config = RedisEnvConfig(Environ.new())
    server_info = redis_config.connect().info()
    # In case this is a Materia KV Redis compatible database
    if not server_info.get("redis_version") and server_info.get("Materia KV "):
        server_info = {"redis_version": f"Materia KV - {server_info['Materia KV ']}"}
    if not server_info:
        raise ValueError("Can't display server info")
    _logger.info("Redis Session enable [%s]", server_info)
    if MAJOR >= 16:
        odoo.http.Application.session_store = session_store
        # There is no more session_gc global function, so no more patch needed.
        # Now see FilesystemSessionStore#vacuum.
    else:
        odoo.http.Root.session_store = session_store
        # Keep compatibility with odoo env config.
        if not str2bool(os.environ.get("ODOO_DISABLE_SESSION_GC", "0")):
            odoo.http.session_gc = session_gc
    from . import patcher
