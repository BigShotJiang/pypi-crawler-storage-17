DEFAULT_JWKS_PATH: str = "/.well-known/jwks.json"
DEFAULT_ALGORITHMS: list[str] = ["RS256"]
