### Authoring Public Interface

For anyone directly building on Trilogy in python, this folder contains the public interface for authoring objects.