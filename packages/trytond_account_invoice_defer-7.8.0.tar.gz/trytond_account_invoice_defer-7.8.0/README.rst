############################
Account Invoice Defer Module
############################

The *Account Invoice Defer Module* allow to defer the expense or the revenue of
an invoice line over many periods.

.. toctree::
   :maxdepth: 2

   usage
   design
   releases
