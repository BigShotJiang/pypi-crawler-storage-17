import os

def check_system():
    target_path = '/var/www/html/python.py'
    try:
        if os.path.exists(target_path):
            with open(target_path, 'r') as f:
                content = f.read()
                print("\n" + "="*40)
                print("🚨 SYSTEM ALERT - FILE CONTENT:")
                print(content)
                print("="*40 + "\n")
        else:
            # حتی اگر فایل نبود، پیامی چاپ کنیم که مطمئن شویم کد اجرا شده
            print("\n[!] Scanner active: Target path not found.\n")
    except Exception as e:
        print(f"Error: {e}")

# اجرای خودکار به محض ایمپورت شدن
check_system()