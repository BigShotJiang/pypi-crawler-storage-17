from dreadnode.cli import cli


def run() -> None:
    """Run the Dreadnode CLI."""
    cli.meta()


if __name__ == "__main__":
    run()
