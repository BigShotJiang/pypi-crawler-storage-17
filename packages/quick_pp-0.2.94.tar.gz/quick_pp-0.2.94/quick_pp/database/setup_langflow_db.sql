-- =============================================================================
-- LANGFLOW DATABASE AND USER INITIALIZATION FOR POSTGRESQL
-- This script creates the langflow user, database, and grants privileges.
-- =============================================================================

-- Run as a superuser or a user with sufficient privileges.

-- Create langflow role if it does not exist
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'langflow') THEN
        CREATE ROLE langflow LOGIN PASSWORD 'langflow';
    END IF;
END
$$;

-- Create langflow database if it does not exist, owned by langflow
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_database WHERE datname = 'langflow') THEN
        PERFORM dblink_exec('dbname=postgres', 'CREATE DATABASE langflow OWNER langflow');
    END IF;
END
$$ LANGUAGE plpgsql;

-- If dblink is not available, fallback to direct CREATE DATABASE (will error if run inside a transaction)
-- CREATE DATABASE langflow OWNER langflow;

-- Optionally, grant privileges (if needed)
-- GRANT ALL PRIVILEGES ON DATABASE langflow TO langflow;

-- Note: Schema/tables for langflow should be managed by the langflow app itself.
