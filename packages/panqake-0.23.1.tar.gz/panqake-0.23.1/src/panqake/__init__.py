"""Panqake - CLI for Git stacking."""

__version__ = "0.16.0"
