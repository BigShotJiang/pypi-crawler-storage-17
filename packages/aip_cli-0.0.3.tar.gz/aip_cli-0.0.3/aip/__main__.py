import os
import sys

if os.environ.get("LC_CTYPE", "") == "UTF-8":
    os.environ["LC_CTYPE"] = "en_US.UTF-8"
from aip.driver import driver

if __name__ == "__main__":
    sys.exit(driver())
