"""aip.cli"""

from .cli import cli_group

__all__ = ["cli_group"]