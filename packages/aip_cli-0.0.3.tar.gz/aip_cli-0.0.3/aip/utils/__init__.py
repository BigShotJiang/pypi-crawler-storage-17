"""aip.utils"""
from .utils import CACHE_DIR, can_launch_browser, open_page_in_browser

__all__ = ["CACHE_DIR", "can_launch_browser", "open_page_in_browser"]