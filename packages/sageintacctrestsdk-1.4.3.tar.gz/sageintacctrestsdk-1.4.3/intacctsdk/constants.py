BASE_URL = 'https://api.intacct.com/ia/api/v1'
TOKEN_URL = f'{BASE_URL}/oauth2/token'
PAGE_SIZE = 2000
