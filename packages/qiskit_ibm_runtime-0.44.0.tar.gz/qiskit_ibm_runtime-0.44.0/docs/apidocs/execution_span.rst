.. automodule:: qiskit_ibm_runtime.execution_span
   :no-members:
   :no-inherited-members:
   :no-special-members:
