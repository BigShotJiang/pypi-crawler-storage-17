"""Session management package."""
