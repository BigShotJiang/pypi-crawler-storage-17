"""SEOKit - Claude Code toolkit for SEO articles."""
__version__ = "1.0.0"
