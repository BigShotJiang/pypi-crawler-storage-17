Installation
============


Install from PyPI
-----------------

.. note::

    CASM is built for macOS x86_64 (Intel), macOS arm64 (Apple Silicon), Linux x86_64, and Linux aarch64.

The latest release of libcasm-clexulator can be installed with:

    pip install libcasm-clexulator


Install from source
-------------------

See the `libcasm contribution guide`_.


For contributors
----------------

See the `libcasm contribution guide`_.


.. _`libcasm contribution guide`: https://prisms-center.github.io/CASMcode_docs/pages/contributing_to_libcasm_packages/
