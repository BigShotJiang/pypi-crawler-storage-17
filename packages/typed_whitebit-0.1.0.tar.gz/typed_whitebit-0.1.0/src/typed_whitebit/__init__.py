"""
### Typed Whitebit
> A fully typed, validated async client for the Whitebit API

- Details
"""