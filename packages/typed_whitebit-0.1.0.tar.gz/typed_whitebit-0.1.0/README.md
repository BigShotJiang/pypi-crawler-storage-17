# Typed Whitebit

> A fully typed, validated async client for the Whitebit API

Use *autocomplete* instead of documentation.

🚧 Under construction.