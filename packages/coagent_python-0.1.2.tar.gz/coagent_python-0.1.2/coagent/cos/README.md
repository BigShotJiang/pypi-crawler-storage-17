# CoS

**Co**agent as a **S**ervice.

<p align="center">
<img src="../../assets/coagent-cos.png" height="800">
</p>
