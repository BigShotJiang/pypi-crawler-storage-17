"""Integration tests for Docker container detection."""
