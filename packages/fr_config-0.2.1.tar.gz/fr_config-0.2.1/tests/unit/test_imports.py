def test_imports():
    from fr_config import ConfigLoader, ConfigWriter
