# Changelog

## [0.2.1] - 2025-12-17

### Fixed

- Corrected GitHub repository URL from `Floating-Rock-Studio` to `FloatingRockStudio`

## [0.2.0] - 2025-12-16

- Initial public release
- Hierarchical cascading configuration resolution
- JSON Schema-based validation with custom type system
- Version management with tags (published, latest, deprecated, etc.)
- Configurable cascade modes (replace, update, append, prepend)
- Multi-variant support for different configuration variants
