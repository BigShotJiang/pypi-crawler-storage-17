"""EnvSeal - Manage encrypted .env files across repositories."""

__version__ = "0.1.0"
