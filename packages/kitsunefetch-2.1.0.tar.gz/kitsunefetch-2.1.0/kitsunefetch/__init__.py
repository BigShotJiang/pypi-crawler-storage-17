from .main import query_protein, search_database

__version__ = "2.1.0"
__author__ = "Elisa Rioual"
