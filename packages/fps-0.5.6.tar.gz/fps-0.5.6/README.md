[![Build Status](https://github.com/jupyter-server/fps/actions/workflows/test.yml/badge.svg?query=branch%3Amain++)](https://github.com/jupyter-server/fps/actions/workflows/test.yml/badge.svg?query=branch%3Amain++)
[![Code Coverage](https://img.shields.io/badge/coverage-100%25-green)](https://img.shields.io/badge/coverage-100%25-green)

# FPS

A system for creating modular, configurable, pluggable and concurrent applications.
