"""ETLR CLI - Command-line interface for ETLR workflows."""

__version__ = "0.1.0"

API_BASE_URL = "https://waoxdzbwliheyqujfzyq.supabase.co/functions/v1/etlr-api"
