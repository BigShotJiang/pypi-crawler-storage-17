from .common import Resource
from .v21 import URL

__all__ = [
    "Resource",
    "URL",
]
