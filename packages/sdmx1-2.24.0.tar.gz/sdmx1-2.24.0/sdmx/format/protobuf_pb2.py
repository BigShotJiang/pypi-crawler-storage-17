def Envelope():
    raise NotImplementedError(__name__)
