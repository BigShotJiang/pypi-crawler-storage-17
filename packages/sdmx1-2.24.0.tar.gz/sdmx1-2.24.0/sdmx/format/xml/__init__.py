from .common import validate_xml

__all__ = [
    "validate_xml",
]
