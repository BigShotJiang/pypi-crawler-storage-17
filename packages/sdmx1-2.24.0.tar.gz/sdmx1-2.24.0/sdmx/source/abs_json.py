from .abs import Source as ABS


class Source(ABS):
    _id = "ABS_JSON"
