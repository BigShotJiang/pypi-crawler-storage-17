pytest_plugins = ["sdmx.testing"]
