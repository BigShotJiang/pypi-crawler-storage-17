<p align="center">
  <img src="https://raw.githubusercontent.com/rahulsingh3292/paradedb-django/main/docs/assets/logo.png" width="500" alt="logo" />
</p>

<p align="center">
  <strong>Bring the full power of ParadeDB into Django.</strong>
</p>

<p align="center">
  Build sophisticated, composable search queries effortlessly, and leverage
  advanced indexing, search, and ranking at blazing speed — all inside PostgreSQL.
</p>

<p align="center">
  📘 <a href="https://rahulsingh3292.github.io/paradedb-django/
  ">See the Documentation</a>
</p>
