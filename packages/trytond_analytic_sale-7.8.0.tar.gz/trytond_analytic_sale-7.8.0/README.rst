####################
Analytic Sale Module
####################

The *Analytic Sale Module* adds analytic accounts to the sale lines.

.. toctree::
   :maxdepth: 2

   design
   releases
