//! Record parsing and value extraction.

pub mod parser;

pub use parser::RecordParser;
