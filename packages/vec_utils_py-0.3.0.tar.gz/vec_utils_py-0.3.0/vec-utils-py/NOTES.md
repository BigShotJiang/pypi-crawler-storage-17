
intersperse benchmark: https://play.rust-lang.org/?version=nightly&mode=debug&edition=2018&gist=50bda743d1955e8ae94d9f5c03d59f9f
