# Vec-utils-py

This is a python library exposing much of my rust vec-utils crate.
Included objects:
* 3d Vectors
* Quaternions
* Angles
* Circles
* Some intersections

Only available from pytohn is also the VecList struct. It can be used for faster operations on many Vec3d objects










