The following individuals have contributed code to agate-remote:

* `Christopher Groskopf <https://github.com/onyxfish>`_
* `Peter M. Landwehr <https://github.com/pmlandwehr>`_
* `James McKinney <https://github.com/jpmckinney>`_
* `Josh Renaud <https://github.com/Kirkman>`_
