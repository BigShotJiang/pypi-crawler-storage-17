0.2.3 - December 15, 2025
-------------------------

* Add Python 3.13 and 3.14 support. Drop support for end-of-life versions 3.8 and 3.9.

0.2.2 - February 23, 2024
-------------------------

* Add Python 3.12 support.
* Drop Python 3.7 support (end-of-life was June 27, 2023).

0.2.1 - July 13, 2021
---------------------

* Add ``requests_encoding`` keyword argument to ``from_url``.

0.2.0 - December 19, 2016
-------------------------

* Remove deprecated monkeypatching pattern.
* Upgrade agate requirement to version ``1.5.0``.
* Fix docstring for binary argument. (#8)

0.1.1 - February 28, 2016
-------------------------

* Fixes to documentation.
* Update agate requirement to 1.3.0.

0.1.0 - February 5, 2016
------------------------

* Initial version.
