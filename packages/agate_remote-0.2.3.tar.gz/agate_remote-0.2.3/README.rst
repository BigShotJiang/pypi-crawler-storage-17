.. image:: https://github.com/wireservice/agate-remote/workflows/CI/badge.svg
    :target: https://github.com/wireservice/agate-remote/actions
    :alt: Build status

.. image:: https://coveralls.io/repos/wireservice/agate-remote/badge.svg?branch=master
    :target: https://coveralls.io/r/wireservice/agate-remote
    :alt: Coverage status

.. image:: https://img.shields.io/pypi/dm/agate-remote.svg
    :target: https://pypi.python.org/pypi/agate-remote
    :alt: PyPI downloads

.. image:: https://img.shields.io/pypi/v/agate-remote.svg
    :target: https://pypi.python.org/pypi/agate-remote
    :alt: Version

.. image:: https://img.shields.io/pypi/l/agate-remote.svg
    :target: https://pypi.python.org/pypi/agate-remote
    :alt: License

.. image:: https://img.shields.io/pypi/pyversions/agate-remote.svg
    :target: https://pypi.python.org/pypi/agate-remote
    :alt: Support Python versions

agate-remote adds read support for remote files to `agate <https://github.com/wireservice/agate>`_.

Important links:

* agate             https://agate.rtfd.org
* Documentation:    https://agate-remote.rtfd.org
* Repository:       https://github.com/wireservice/agate-remote
* Issues:           https://github.com/wireservice/agate-remote/issues
