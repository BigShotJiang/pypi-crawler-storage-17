# Obfuscator test suite
