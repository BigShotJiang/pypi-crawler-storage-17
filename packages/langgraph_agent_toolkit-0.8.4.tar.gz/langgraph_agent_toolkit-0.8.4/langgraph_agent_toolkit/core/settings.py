from langgraph_agent_toolkit.core._base_settings import Settings


settings = Settings()
settings.setup()
