############################
Account Invoice Stock Module
############################

The *Account Invoice Stock Module* links together invoice lines and stock
moves.
This allows a stock move's unit price to be updated from the average price
of the linked invoice lines.

.. toctree::
   :maxdepth: 2

   releases
