# SDS Client | `spectrumx.client.Client`

## ::: spectrumx.client.Client

    handler: python
    options:
        show_submodules: false
