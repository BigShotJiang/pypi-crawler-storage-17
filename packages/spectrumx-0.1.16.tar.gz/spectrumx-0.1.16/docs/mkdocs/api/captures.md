# Captures API | `<Client>.captures`

## ::: spectrumx.api.captures
