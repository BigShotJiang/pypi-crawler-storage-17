1. Go to Settings > Technical > Reporting > PDF Form Reports and create a new record.
2. Link with dedicated Report and empty QWeb template
3. Define how to fille the PDF fields using Odoo fields.
