Add a dedicated report type to avoid having to define a qweb template and 
have everything on ir.actions.report.
