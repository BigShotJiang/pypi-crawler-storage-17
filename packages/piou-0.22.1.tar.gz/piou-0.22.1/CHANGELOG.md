## 0.22.1 (2025-12-19)

### Fix

- remove legacy scripts config
