msg = 'This is a dummy module that should never be installed.'
raise RuntimeError(msg)
