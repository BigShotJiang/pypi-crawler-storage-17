"""Tests for comfygit-deploy package."""
