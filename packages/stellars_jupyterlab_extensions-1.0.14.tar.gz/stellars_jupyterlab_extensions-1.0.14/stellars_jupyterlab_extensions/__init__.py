"""Stellars JupyterLab Extensions metapackage.

Installs all Stellars JupyterLab extensions as dependencies.
"""

__version__ = "1.0.14"
