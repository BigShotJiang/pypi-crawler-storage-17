"""CUDA and GPU tests"""

