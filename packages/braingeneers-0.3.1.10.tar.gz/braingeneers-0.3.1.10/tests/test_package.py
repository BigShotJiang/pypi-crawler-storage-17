import unittest

import braingeneers as m


def test_version():
    assert m.__version__


if __name__ == "__main__":
    unittest.main()
