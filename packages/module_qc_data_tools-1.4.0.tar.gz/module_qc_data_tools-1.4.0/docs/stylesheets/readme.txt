These fonts were added as described in https://how-to.docs.cern.ch/advanced/google-fonts/.
