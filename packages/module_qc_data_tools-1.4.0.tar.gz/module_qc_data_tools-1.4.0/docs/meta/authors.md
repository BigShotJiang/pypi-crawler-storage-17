# Authors

---

## Maintainers

- Lingxin Meng (@lmeng)
- Elisabetta Pianori (@epianori)
- Giordon Stark (@gstark) [:material-web:](https://giordonstark.com)
  [:material-github:](https://github.com/kratsg)
  [:material-twitter:](https://twitter.com/kratsg)

## Contributors

- Emily Anne Thompson (@emily)
- Giordon Stark (@gstark)
- Lingxin Meng (@lmeng)
- Elisabetta Pianori (@epianori)
- Marianna Liberatore (@liberato)
- Jay Chan (@cchan)
- Dima Maneuski (@maneuski)
