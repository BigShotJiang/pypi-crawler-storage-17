"""Entry point for python -m devrules."""

from devrules.cli import app

if __name__ == "__main__":
    app()
