"""Tests for DevRules."""
