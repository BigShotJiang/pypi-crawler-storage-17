# xml-sanitizer

Safely escape illegal ampersands in XML without double-encoding.

## Installation

```bash
pip install xml-sanitizer
```
