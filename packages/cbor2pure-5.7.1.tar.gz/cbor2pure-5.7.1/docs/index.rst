CBOR2
=====

.. include:: ../README.rst
   :start-line: 16

Table of contents
-----------------

.. toctree::
   :maxdepth: 2

   usage
   customizing
   api
   versionhistory
