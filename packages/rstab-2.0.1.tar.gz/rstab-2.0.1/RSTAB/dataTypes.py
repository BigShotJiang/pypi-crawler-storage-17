# Specific data types

inf = float('inf')
nan = float('nan')
