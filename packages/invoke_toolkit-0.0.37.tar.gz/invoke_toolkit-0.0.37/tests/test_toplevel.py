from invoke_toolkit import run


def test_run():
    run("ls")
