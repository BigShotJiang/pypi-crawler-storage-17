"""Config class"""

from .config import ToolkitConfig, get_config_value  # noqa: F401
