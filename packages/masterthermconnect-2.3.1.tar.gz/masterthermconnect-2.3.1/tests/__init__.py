"""Python API wrapper for Mastertherm Connect."""
