"""Python API wrapper for Mastertherm Connect."""

__version__ = "2.3.1"
