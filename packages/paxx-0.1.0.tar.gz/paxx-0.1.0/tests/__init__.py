"""Facet test suite."""
