cd tmp/test-project

rm test_feature.db
rm db/migrations/versions/*.py