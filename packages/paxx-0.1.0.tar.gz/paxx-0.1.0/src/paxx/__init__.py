"""Facet - A domain-oriented Python web framework built on top of FastAPI."""

__version__ = "0.1.0"
