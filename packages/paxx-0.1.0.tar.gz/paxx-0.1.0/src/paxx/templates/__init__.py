"""Facet templates for project and feature scaffolding."""
