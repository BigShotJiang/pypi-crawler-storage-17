I want you to implement point 1.1 from ## Implementation Plan. Write a brief note of what you did in docs/02-implementation.md

---

I want you to implement point 1.2 from ## Implementation Plan from docs/idea.md. Write a brief note of what you did in docs/02-implementation.md

---

I want you to implement point 1.4 from ## Implementation Plan from docs/idea.md. Write a brief note of what you did in docs/02-implementation.md. mark Phase 1 as implemented.

---

I want you to implement point 2.4 from ## Implementation Plan from docs/idea.md. Write a brief note of what you did in docs/02-implementation.md. 2.1, 2.2 and 2.3 I skip for now. add placeholders for these phases in docs/02-implementation.md.

---

See docs/02-implementation.md. I skipped:

- [ ] **3.3 Example Feature: Users**
  - [ ] Complete implementation as reference
  - [ ] User model, schemas, routes, services
  - [ ] Registration, login, profile endpoints
  - [ ] Full test coverage

I would like to have "users" as some kind of add onm like in django there is admin panel, users etc. how could we implement it in paxx?

---

I want you to do refactoring: rename "shared" dir in paxx template to "core". Update all other necessary places.