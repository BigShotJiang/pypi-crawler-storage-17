"""Integration tests for :mod:`esmf_regrid.esmf_regridder`."""
