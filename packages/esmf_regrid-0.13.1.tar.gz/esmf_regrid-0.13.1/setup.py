#!/usr/bin/env python

"""Iris-esmf-regrid setuptools packaging."""

from setuptools import setup

setup()
