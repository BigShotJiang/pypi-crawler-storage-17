# Typed Bitvavo

> A fully typed, validated async client for the Bitvavo API

Use *autocomplete* instead of documentation.

🚧 Under construction.