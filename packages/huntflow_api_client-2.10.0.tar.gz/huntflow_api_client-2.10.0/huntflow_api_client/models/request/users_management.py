from huntflow_api_client.models.common import ForeignUser


class ForeignUserRequest(ForeignUser):
    pass
