"""
AitoCoder - An AI-powered coding agent from the terminal

autocoder/ contains all the functionality, while
login_modules/ handles login & authentication
"""
