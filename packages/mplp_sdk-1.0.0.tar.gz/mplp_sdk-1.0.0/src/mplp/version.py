# MPLP v1.0.0 FROZEN
# Governance: MPGC

__version__ = "1.0.0"
MPLP_PROTOCOL_VERSION = "1.0.0"
