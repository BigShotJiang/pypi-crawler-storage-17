# MPLP v1.0.0 FROZEN
# Governance: MPGC

# MPLP SDK
__version__ = "1.0.0rc1"
MPLP_PROTOCOL_VERSION = "1.0.0"
