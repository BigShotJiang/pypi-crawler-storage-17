import unittest
from memmap import *
from general import *
from features import *
# These have some user input, uncomment if you're human.
# from pwm import *
# from leds import *
from thermal import *


if __name__ == '__main__':
    unittest.main()
