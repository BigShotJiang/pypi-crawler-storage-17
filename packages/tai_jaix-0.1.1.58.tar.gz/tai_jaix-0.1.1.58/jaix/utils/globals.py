from ttex.log import LOGGER_NAME as LOGGER_NAME

WANDB_LOGGER_NAME = "wandb_logger"
COCO_LOGGER_NAME = "coco_logger"
