class Optimiser:
    @property
    def name(self):
        raise NotImplementedError()
