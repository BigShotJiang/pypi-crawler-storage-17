[![codecov](https://codecov.io/gh/brews/muuttaa/graph/badge.svg?token=BU7RCYZGMP)](https://codecov.io/gh/brews/muuttaa)
[![Python package](https://github.com/brews/muuttaa/actions/workflows/pythonpackage.yml/badge.svg)](https://github.com/brews/muuttaa/actions/workflows/pythonpackage.yml)
# muuttaa

Minimalist xarray-based climate impact framework.

> [!CAUTION]
> This is a toy. Don't use this in production. Expect it to break.
