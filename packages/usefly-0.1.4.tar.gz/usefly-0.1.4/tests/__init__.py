"""Tests for Usefly application."""
