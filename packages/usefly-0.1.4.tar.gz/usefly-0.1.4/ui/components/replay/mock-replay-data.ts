// DEPRECATED - Use API client instead
// Replay functionality to be implemented with real API data
