// DEPRECATED - Use API client instead
// Import from @/lib/api-client for real data
