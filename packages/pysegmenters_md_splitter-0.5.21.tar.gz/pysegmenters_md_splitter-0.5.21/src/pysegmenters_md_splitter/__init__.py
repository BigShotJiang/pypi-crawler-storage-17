"""Markdown splitter"""
__version__ = "0.5.21"
