"""Claude-Linear Automation CLI.

A command-line tool for setting up and managing Claude-Linear automation.
"""

__version__ = "0.1.0"
