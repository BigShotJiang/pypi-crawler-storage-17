from .listeners import (
    test_res_partner_listener,
)
from .models import (
    test_res_partner,
)
from .services import (
    test_change_partner_emails,
)
from .wizards import (
    test_partner_check_somoffice_email,
    test_partner_email_change,
)
