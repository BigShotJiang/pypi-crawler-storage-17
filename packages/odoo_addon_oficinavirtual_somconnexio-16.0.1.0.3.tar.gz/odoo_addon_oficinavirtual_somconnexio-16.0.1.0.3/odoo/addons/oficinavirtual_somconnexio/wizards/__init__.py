from . import (
    partner_check_somoffice_email,
    partner_email_change,
)
