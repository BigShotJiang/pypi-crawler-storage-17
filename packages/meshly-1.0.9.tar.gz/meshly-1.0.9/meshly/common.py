# Common type definitions
from pathlib import Path
from typing import Union


PathLike = Union[str, Path]