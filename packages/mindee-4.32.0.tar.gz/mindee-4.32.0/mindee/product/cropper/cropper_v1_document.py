from mindee.parsing.common.prediction import Prediction


class CropperV1Document(Prediction):
    """Cropper API version 1.1 document data."""

    def __str__(self) -> str:
        return ""
