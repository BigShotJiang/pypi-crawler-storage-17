{{ fullname | escape | underline }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
   :members:

.. _sphx_glr_backreferences_{{ fullname }}:

.. minigallery:: {{ fullname }}
    :add-heading:
