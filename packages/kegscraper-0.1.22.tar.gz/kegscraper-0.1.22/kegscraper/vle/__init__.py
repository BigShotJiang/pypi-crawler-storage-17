"""
Anything to do with the vle website, aka kegsnet: https://vle.kegs.org.uk/
"""


from .session import Session, login, login_by_moodle
from .file import File
