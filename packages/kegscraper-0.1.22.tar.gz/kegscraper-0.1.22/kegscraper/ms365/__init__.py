from __future__ import annotations

from .session import Session, login

# _result = os.system(f"\"{sys.executable}\" -m playwright install")
