# vsdmitri LaTeX utils

Simple library with utils for latex. Supports images and tables generation.
