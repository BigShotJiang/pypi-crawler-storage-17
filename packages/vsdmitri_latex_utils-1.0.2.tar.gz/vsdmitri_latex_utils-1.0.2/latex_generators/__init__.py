from .generators import generate_table, generate_image, generate_document_template
