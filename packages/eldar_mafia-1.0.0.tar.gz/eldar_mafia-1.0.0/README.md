# Eldar Mafia Game

CLI Mafia Game (Group Moderator Game)

## Install
```bash
pip install eldar-mafia
