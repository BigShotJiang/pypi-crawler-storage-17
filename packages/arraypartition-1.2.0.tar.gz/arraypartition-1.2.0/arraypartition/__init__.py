from .partition import (
    ArrayLike,
    SuperLazyArrayLike,
    ArrayPartition,
)