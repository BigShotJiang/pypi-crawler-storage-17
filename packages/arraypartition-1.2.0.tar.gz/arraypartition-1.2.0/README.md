# Array Partition

![Static Badge](https://img.shields.io/badge/Xarray%20Engine%20Component-1E4B23)
[![PyPI version](https://badge.fury.io/py/ArrayPartition.svg)](https://pypi.python.org/pypi/ArrayPartition/)

Required submodule for other libraries:
 - CFAPyX
 - XarrayActive

Not typically used on its own so there are no usage instructions.

## Documentation

See the [Documentation](https://html-preview.github.io/?url=https://github.com/dwest77a/ArrayPartition/blob/main/docs/build/html/index.html) for developers.
