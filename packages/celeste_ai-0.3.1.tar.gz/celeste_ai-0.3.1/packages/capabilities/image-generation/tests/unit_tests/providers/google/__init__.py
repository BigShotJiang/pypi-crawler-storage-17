"""Google provider unit tests for image-generation."""
