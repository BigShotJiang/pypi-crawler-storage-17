"""Image generation integration test module."""
