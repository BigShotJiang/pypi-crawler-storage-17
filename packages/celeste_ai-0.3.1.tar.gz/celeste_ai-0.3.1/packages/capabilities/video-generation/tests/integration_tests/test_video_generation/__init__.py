"""Video generation integration test module."""
