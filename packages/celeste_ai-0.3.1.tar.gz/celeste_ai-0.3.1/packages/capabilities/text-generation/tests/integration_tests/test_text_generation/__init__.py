"""Text generation integration test module."""
