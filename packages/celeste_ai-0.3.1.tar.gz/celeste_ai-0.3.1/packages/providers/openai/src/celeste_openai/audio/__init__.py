"""OpenAI Audio API provider package."""
