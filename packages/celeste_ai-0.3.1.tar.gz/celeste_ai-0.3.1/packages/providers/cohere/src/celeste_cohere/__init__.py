"""Cohere provider package for Celeste AI."""

__all__: list[str] = []
