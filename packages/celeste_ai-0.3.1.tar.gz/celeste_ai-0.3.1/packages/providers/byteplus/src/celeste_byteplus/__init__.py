"""BytePlus provider package for Celeste AI."""
