"""Google provider package for Celeste AI."""
