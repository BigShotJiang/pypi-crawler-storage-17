"""Amazing Marvin Model Context Provider"""


__version__ = "0.1.0"
