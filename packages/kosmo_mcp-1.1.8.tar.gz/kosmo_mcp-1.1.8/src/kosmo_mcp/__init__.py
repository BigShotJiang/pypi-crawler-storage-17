"""KOSMO MCP Server - Zero-Install Agentic Protocol"""

__version__ = "1.0.0"
