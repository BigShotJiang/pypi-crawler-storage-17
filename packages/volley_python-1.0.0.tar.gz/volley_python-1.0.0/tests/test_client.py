"""Unit tests for VolleyClient."""

import pytest
from unittest.mock import Mock, patch
from volley import VolleyClient, VolleyException


def test_client_initialization():
    """Test client initialization."""
    client = VolleyClient("test-token")
    assert client.api_token == "test-token"
    assert client.base_url == "https://api.volleyhooks.com"
    assert client.organization_id is None


def test_client_initialization_with_options():
    """Test client initialization with options."""
    client = VolleyClient(
        "test-token",
        base_url="https://api.example.com",
        organization_id=123,
        timeout=60,
    )
    assert client.base_url == "https://api.example.com"
    assert client.organization_id == 123
    assert client.timeout == 60


def test_client_requires_token():
    """Test that client requires an API token."""
    with pytest.raises(ValueError, match="API token is required"):
        VolleyClient("")


def test_set_organization_id():
    """Test setting organization ID."""
    client = VolleyClient("test-token")
    client.set_organization_id(123)
    assert client.get_organization_id() == 123


def test_clear_organization_id():
    """Test clearing organization ID."""
    client = VolleyClient("test-token", organization_id=123)
    client.clear_organization_id()
    assert client.get_organization_id() is None


def test_client_has_resource_clients():
    """Test that client has all resource clients."""
    client = VolleyClient("test-token")
    assert client.organizations is not None
    assert client.projects is not None
    assert client.sources is not None
    assert client.destinations is not None
    assert client.connections is not None
    assert client.events is not None
    assert client.delivery_attempts is not None
    assert client.webhooks is not None


@patch("volley.client.requests.Session")
def test_request_success(mock_session_class):
    """Test successful request."""
    mock_session = Mock()
    mock_response = Mock()
    mock_response.ok = True
    mock_response.json.return_value = {"id": 1, "name": "Test"}
    mock_response.content = b'{"id": 1, "name": "Test"}'
    mock_session.request.return_value = mock_response
    mock_session_class.return_value = mock_session

    client = VolleyClient("test-token")
    result = client.request("GET", "/api/org")

    assert result == {"id": 1, "name": "Test"}
    mock_session.request.assert_called_once()


@patch("volley.client.requests.Session")
def test_request_with_organization_header(mock_session_class):
    """Test request includes organization header when set."""
    mock_session = Mock()
    mock_response = Mock()
    mock_response.ok = True
    mock_response.json.return_value = {}
    mock_response.content = b"{}"
    mock_session.request.return_value = mock_response
    mock_session_class.return_value = mock_session

    client = VolleyClient("test-token", organization_id=123)
    client.request("GET", "/api/projects")

    call_kwargs = mock_session.request.call_args[1]
    assert call_kwargs["headers"]["X-Organization-ID"] == "123"


@patch("volley.client.requests.Session")
def test_request_error(mock_session_class):
    """Test request error handling."""
    mock_session = Mock()
    mock_response = Mock()
    mock_response.ok = False
    mock_response.status_code = 404
    mock_response.json.return_value = {"error": "Not found"}
    mock_response.content = b'{"error": "Not found"}'
    mock_session.request.return_value = mock_response
    mock_session_class.return_value = mock_session

    client = VolleyClient("test-token")
    with pytest.raises(VolleyException) as exc_info:
        client.request("GET", "/api/org")

    assert exc_info.value.status_code == 404
    assert "Not found" in str(exc_info.value)

