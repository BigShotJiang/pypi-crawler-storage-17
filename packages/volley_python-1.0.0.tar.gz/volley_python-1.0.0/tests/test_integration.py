"""Integration tests that make real API calls.

These tests are skipped unless VOLLEY_API_TOKEN is set.
"""

import os
import pytest
from volley import VolleyClient


@pytest.mark.skipif(
    not os.getenv("VOLLEY_API_TOKEN"),
    reason="VOLLEY_API_TOKEN environment variable not set",
)
def test_list_organizations():
    """Test listing organizations."""
    api_token = os.getenv("VOLLEY_API_TOKEN")
    client = VolleyClient(api_token)

    orgs = client.organizations.list()
    assert isinstance(orgs, list)
    # May be empty for new accounts, which is OK


@pytest.mark.skipif(
    not os.getenv("VOLLEY_API_TOKEN"),
    reason="VOLLEY_API_TOKEN environment variable not set",
)
def test_get_organization():
    """Test getting an organization."""
    api_token = os.getenv("VOLLEY_API_TOKEN")
    client = VolleyClient(api_token)

    orgs = client.organizations.list()
    if not orgs:
        pytest.skip("No organizations available")

    org = client.organizations.get(orgs[0].id)
    assert org.id == orgs[0].id


@pytest.mark.skipif(
    not os.getenv("VOLLEY_API_TOKEN"),
    reason="VOLLEY_API_TOKEN environment variable not set",
)
def test_list_projects():
    """Test listing projects."""
    api_token = os.getenv("VOLLEY_API_TOKEN")
    client = VolleyClient(api_token)

    orgs = client.organizations.list()
    if not orgs:
        pytest.skip("No organizations available")

    client.set_organization_id(orgs[0].id)
    projects = client.projects.list()
    assert isinstance(projects, list)
    # May be empty, which is OK


@pytest.mark.skipif(
    not os.getenv("VOLLEY_API_TOKEN"),
    reason="VOLLEY_API_TOKEN environment variable not set",
)
def test_list_sources():
    """Test listing sources."""
    api_token = os.getenv("VOLLEY_API_TOKEN")
    client = VolleyClient(api_token)

    orgs = client.organizations.list()
    if not orgs:
        pytest.skip("No organizations available")

    client.set_organization_id(orgs[0].id)
    projects = client.projects.list()
    if not projects:
        pytest.skip("No projects available")

    sources = client.sources.list(projects[0].id)
    assert isinstance(sources, list)
    # May be empty, which is OK

