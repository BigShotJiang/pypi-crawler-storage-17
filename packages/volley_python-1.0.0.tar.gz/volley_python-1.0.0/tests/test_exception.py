"""Unit tests for VolleyException."""

import pytest
from volley import VolleyException


def test_exception_creation():
    """Test exception creation."""
    exc = VolleyException("Test error", 400)
    assert exc.message == "Test error"
    assert exc.status_code == 400


def test_exception_string_representation():
    """Test exception string representation."""
    exc = VolleyException("Test error", 400)
    assert "Test error" in str(exc)
    assert "400" in str(exc)

    exc_no_status = VolleyException("Test error")
    assert str(exc_no_status) == "Test error"


def test_is_unauthorized():
    """Test is_unauthorized check."""
    exc = VolleyException("Unauthorized", 401)
    assert exc.is_unauthorized() is True
    assert exc.is_forbidden() is False


def test_is_forbidden():
    """Test is_forbidden check."""
    exc = VolleyException("Forbidden", 403)
    assert exc.is_forbidden() is True
    assert exc.is_unauthorized() is False


def test_is_not_found():
    """Test is_not_found check."""
    exc = VolleyException("Not found", 404)
    assert exc.is_not_found() is True


def test_is_rate_limited():
    """Test is_rate_limited check."""
    exc = VolleyException("Rate limited", 429)
    assert exc.is_rate_limited() is True


def test_is_server_error():
    """Test is_server_error check."""
    exc = VolleyException("Server error", 500)
    assert exc.is_server_error() is True

    exc_502 = VolleyException("Bad gateway", 502)
    assert exc_502.is_server_error() is True

    exc_400 = VolleyException("Bad request", 400)
    assert exc_400.is_server_error() is False

