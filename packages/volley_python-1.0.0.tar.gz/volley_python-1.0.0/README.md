# Volley Python SDK

Official Python SDK for the Volley API. This SDK provides a convenient way to interact with the Volley webhook infrastructure API.

[Volley](https://volleyhooks.com) is a webhook infrastructure platform that provides reliable webhook delivery, rate limiting, retries, monitoring, and more.

## Resources

- **Documentation**: [https://docs.volleyhooks.com](https://docs.volleyhooks.com)
- **Getting Started Guide**: [https://docs.volleyhooks.com/getting-started](https://docs.volleyhooks.com/getting-started)
- **API Reference**: [https://docs.volleyhooks.com/api](https://docs.volleyhooks.com/api)
- **Authentication Guide**: [https://docs.volleyhooks.com/authentication](https://docs.volleyhooks.com/authentication)
- **Security Guide**: [https://docs.volleyhooks.com/security](https://docs.volleyhooks.com/security)
- **Console**: [https://app.volleyhooks.com](https://app.volleyhooks.com)
- **Website**: [https://volleyhooks.com](https://volleyhooks.com)

## Installation

```bash
pip install volley-python
```

or with poetry:

```bash
poetry add volley-python
```

## Quick Start

```python
from volley import VolleyClient

# Create a client with your API token
client = VolleyClient("your-api-token")

# Optionally set organization context
client.set_organization_id(123)

# List organizations
orgs = client.organizations.list()
for org in orgs:
    print(f"Organization: {org.name} (ID: {org.id})")
```

## Authentication

Volley uses API tokens for authentication. These are long-lived tokens designed for programmatic access.

### Getting Your API Token

1. Log in to the [Volley Console](https://app.volleyhooks.com)
2. Navigate to **Settings → Account → API Token**
3. Click **View Token** (you may need to verify your password)
4. Copy the token and store it securely

**Important**: API tokens are non-expiring and provide full access to your account. Keep them secure and rotate them if compromised. See the [Security Guide](https://docs.volleyhooks.com/security) for best practices.

```python
client = VolleyClient("your-api-token")
```

For more details on authentication, API tokens, and security, see the [Authentication Guide](https://docs.volleyhooks.com/authentication) and [Security Guide](https://docs.volleyhooks.com/security).

## Organization Context

When you have multiple organizations, you need to specify which organization context to use for API requests. The API verifies that resources (like projects) belong to the specified organization.

You can set the organization context in two ways:

```python
# Method 1: Set organization ID for all subsequent requests
client.set_organization_id(123)

# Method 2: Create client with organization ID
client = VolleyClient("your-api-token", organization_id=123)

# Clear organization context (uses first accessible organization)
client.clear_organization_id()
```

**Note**: If you don't set an organization ID, the API uses your first accessible organization by default. For more details, see the [API Reference - Organization Context](https://docs.volleyhooks.com/api#organization-context).

## Examples

### Organizations

```python
from volley import VolleyClient
from volley.models import CreateOrganizationRequest

# List all organizations
orgs = client.organizations.list()

# Get current organization
org = client.organizations.get()  # None = use default

# Create organization
new_org = client.organizations.create(
    CreateOrganizationRequest(name="My Organization")
)
```

### Projects

```python
from volley.models import CreateProjectRequest, UpdateProjectRequest

# List projects
projects = client.projects.list()

# Create project
project = client.projects.create(
    CreateProjectRequest(name="My Project")
)

# Update project
updated = client.projects.update(
    project.id,
    UpdateProjectRequest(name="Updated Name")
)

# Delete project
client.projects.delete(project.id)
```

### Sources

```python
from volley.models import CreateSourceRequest, UpdateSourceRequest

# List sources in a project
sources = client.sources.list(project_id)

# Create source
source = client.sources.create(
    project_id,
    CreateSourceRequest(
        slug="stripe-webhooks",
        type="stripe",
        eps=10,
        auth_type="none"
    )
)

# Get source details
source = client.sources.get(project_id, source_id)

# Update source
updated = client.sources.update(
    project_id,
    source_id,
    UpdateSourceRequest(
        slug="updated-slug",
        eps=20
    )
)

# Delete source
client.sources.delete(project_id, source_id)
```

### Destinations

```python
from volley.models import CreateDestinationRequest, UpdateDestinationRequest

# List destinations
destinations = client.destinations.list(project_id)

# Create destination
dest = client.destinations.create(
    project_id,
    CreateDestinationRequest(
        name="Production Endpoint",
        url="https://api.example.com/webhooks",
        eps=5
    )
)

# Get destination
dest = client.destinations.get(project_id, destination_id)

# Update destination
updated = client.destinations.update(
    project_id,
    destination_id,
    UpdateDestinationRequest(
        name="Updated Name",
        eps=10
    )
)

# Delete destination
client.destinations.delete(project_id, destination_id)
```

### Connections

```python
from volley.models import CreateConnectionRequest, UpdateConnectionRequest

# Create connection
conn = client.connections.create(
    project_id,
    CreateConnectionRequest(
        source_id=source_id,
        destination_id=dest_id,
        status="enabled",
        eps=5,
        max_retries=3
    )
)

# Get connection
conn = client.connections.get(project_id, connection_id)

# Update connection
updated = client.connections.update(
    project_id,
    connection_id,
    UpdateConnectionRequest(
        status="paused",
        eps=10
    )
)

# Delete connection
client.connections.delete(project_id, connection_id)
```

### Events

```python
from volley.models import ReplayEventRequest

# List events with filters
events_response = client.events.list(
    project_id,
    source_id=source_id,
    status="failed",
    limit=50,
    offset=0
)

# Get event details
event = client.events.get(request_id)

# Replay failed event
result = client.events.replay(
    ReplayEventRequest(event_id="evt_abc123def456")
)
```

### Delivery Attempts

```python
# List delivery attempts with filters
attempts_response = client.delivery_attempts.list(
    project_id,
    event_id="evt_abc123def456",
    connection_id=connection_id,
    status="failed",
    limit=50,
    offset=0
)
```

### Webhooks

```python
from volley.models import SendWebhookRequest

# Send a webhook
result = client.webhooks.send(
    SendWebhookRequest(
        source_id=source_id,
        destination_id=destination_id,
        body={"event": "test", "data": "example"},
        headers={"X-Custom-Header": "value"}
    )
)
```

## Error Handling

The SDK throws `VolleyException` for API errors:

```python
from volley import VolleyClient, VolleyException

try:
    org = client.organizations.get(org_id)
except VolleyException as e:
    if e.is_unauthorized():
        print("Authentication failed")
    elif e.is_forbidden():
        print("Access denied")
    elif e.is_not_found():
        print("Resource not found")
    elif e.is_rate_limited():
        print("Rate limit exceeded")
    else:
        print(f"Error: {e.message} (Status: {e.status_code})")
```

## Client Options

You can customize the client with various options:

```python
import requests

# Custom base URL
client = VolleyClient(
    "your-api-token",
    base_url="https://api-staging.volleyhooks.com"
)

# Custom timeout
client = VolleyClient(
    "your-api-token",
    timeout=60  # 60 seconds
)

# Custom session with retry strategy
session = requests.Session()
client = VolleyClient(
    "your-api-token",
    session=session
)
```

## Requirements

- Python 3.8 or higher
- requests >= 2.31.0

## Development

### Setup

```bash
# Clone the repository
git clone https://github.com/volleyhq/volley-python.git
cd volley-python

# Install in development mode
pip install -e ".[dev]"
```

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=volley --cov-report=html

# Run integration tests (requires VOLLEY_API_TOKEN)
VOLLEY_API_TOKEN=your-token pytest tests/test_integration.py
```

### Code Formatting

```bash
# Format code
black volley tests examples

# Check formatting
black --check volley tests examples
```

## License

MIT License - See [LICENSE](LICENSE) file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

---

**Built with ❤️ by the Volley team**

