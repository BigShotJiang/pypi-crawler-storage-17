"""Organizations API methods."""

from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from volley.client import VolleyClient

from volley.models import (
    Organization,
    ListOrganizationsResponse,
    CreateOrganizationRequest,
)


class Organizations:
    """Organizations API methods."""

    def __init__(self, client: "VolleyClient"):
        """
        Initialize Organizations API client.

        Args:
            client: VolleyClient instance
        """
        self.client = client

    def list(self) -> list[Organization]:
        """
        List all organizations the user has access to.

        Returns:
            List of organizations
        """
        response = self.client.request("GET", "/api/org/list")
        orgs_data = response.get("organizations", [])
        return [Organization(**org) if isinstance(org, dict) else org for org in orgs_data]

    def get(self, organization_id: Optional[int] = None) -> Organization:
        """
        Get the current organization.

        Args:
            organization_id: Optional organization ID. If None, uses default organization.

        Returns:
            Organization details
        """
        original_org_id = self.client.get_organization_id()
        if organization_id is not None:
            self.client.set_organization_id(organization_id)

        try:
            response = self.client.request("GET", "/api/org")
            # GetOrganization returns id, name, slug, role (not account_id, created_at)
            # So we need to handle missing fields
            org_data = {
                "id": response.get("id"),
                "name": response.get("name"),
                "slug": response.get("slug"),
                "role": response.get("role"),
                "account_id": response.get("account_id"),
                "created_at": response.get("created_at"),
            }
            return Organization(**org_data)
        finally:
            if original_org_id is not None:
                self.client.set_organization_id(original_org_id)
            else:
                self.client.clear_organization_id()

    def create(self, request: CreateOrganizationRequest) -> Organization:
        """
        Create a new organization.

        Args:
            request: CreateOrganizationRequest with organization name

        Returns:
            Created organization
        """
        data = {"name": request.name}
        response = self.client.request("POST", "/api/org", data=data)
        return Organization(**response)

