"""Data models for the Volley API."""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field


@dataclass
class Organization:
    """Organization model."""

    id: int
    name: str
    slug: str
    role: str
    account_id: Optional[int] = None  # Not always present in GetOrganization response
    created_at: Optional[str] = None  # Not always present in GetOrganization response


@dataclass
class Project:
    """Project model."""

    id: int
    name: str
    organization_id: int
    user_id: Optional[int] = None  # User who created the project
    is_default: bool = False
    created_at: str = ""
    updated_at: str = ""


@dataclass
class Source:
    """Source model."""

    id: int
    slug: str
    ingestion_id: str
    type: str
    eps: int
    status: str
    connection_count: int
    auth_type: str
    verify_signature: bool
    webhook_secret_set: bool
    auth_username: Optional[str] = None
    auth_key_name: Optional[str] = None
    created_at: str = ""
    updated_at: str = ""


@dataclass
class Destination:
    """Destination model."""

    id: int
    name: str
    url: str
    eps: int
    status: str
    created_at: str
    updated_at: str


@dataclass
class Connection:
    """Connection model."""

    id: int
    source_id: int
    destination_id: int
    status: str
    eps: int
    max_retries: int
    created_at: str
    updated_at: str


@dataclass
class DeliveryAttempt:
    """Delivery Attempt model."""

    id: int
    event_id: str
    connection_id: int
    status: str
    status_code: int
    error_reason: Optional[str] = None
    duration_ms: int = 0
    created_at: str = ""


@dataclass
class Event:
    """Event model."""

    id: int
    event_id: str
    source_id: int
    project_id: int
    raw_body: str
    headers: Dict[str, Any]
    status: str
    delivery_attempts: Optional[List[DeliveryAttempt]] = None
    created_at: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Event":
        """Create Event from dictionary, converting nested delivery_attempts."""
        data = data.copy()
        if "delivery_attempts" in data and data["delivery_attempts"]:
            data["delivery_attempts"] = [
                DeliveryAttempt(**da) if isinstance(da, dict) else da
                for da in data["delivery_attempts"]
            ]
        return cls(**data)


# Request/Response models
@dataclass
class CreateOrganizationRequest:
    """Request to create an organization."""

    name: str


@dataclass
class CreateProjectRequest:
    """Request to create a project."""

    name: str


@dataclass
class UpdateProjectRequest:
    """Request to update a project."""

    name: str


@dataclass
class CreateSourceRequest:
    """Request to create a source."""

    slug: str
    type: str
    eps: Optional[int] = None
    auth_type: Optional[str] = None
    auth_username: Optional[str] = None
    auth_key: Optional[str] = None
    verify_signature: Optional[bool] = None
    webhook_secret: Optional[str] = None


@dataclass
class UpdateSourceRequest:
    """Request to update a source."""

    slug: Optional[str] = None
    eps: Optional[int] = None
    auth_type: Optional[str] = None
    auth_username: Optional[str] = None
    auth_key: Optional[str] = None
    verify_signature: Optional[bool] = None
    webhook_secret: Optional[str] = None


@dataclass
class CreateDestinationRequest:
    """Request to create a destination."""

    name: str
    url: str
    eps: Optional[int] = None


@dataclass
class UpdateDestinationRequest:
    """Request to update a destination."""

    name: Optional[str] = None
    url: Optional[str] = None
    eps: Optional[int] = None


@dataclass
class CreateConnectionRequest:
    """Request to create a connection."""

    source_id: int
    destination_id: int
    status: Optional[str] = None
    eps: Optional[int] = None
    max_retries: Optional[int] = None


@dataclass
class UpdateConnectionRequest:
    """Request to update a connection."""

    status: Optional[str] = None
    eps: Optional[int] = None
    max_retries: Optional[int] = None


@dataclass
class ReplayEventRequest:
    """Request to replay an event."""

    event_id: str
    destination_id: Optional[int] = None
    connection_id: Optional[int] = None


@dataclass
class SendWebhookRequest:
    """Request to send a webhook."""

    source_id: int
    destination_id: int
    body: Dict[str, Any]
    headers: Optional[Dict[str, str]] = None


# Response models
@dataclass
class ListOrganizationsResponse:
    """Response for listing organizations."""

    organizations: List[Organization]


@dataclass
class ListProjectsResponse:
    """Response for listing projects."""

    projects: List[Project]


@dataclass
class ListSourcesResponse:
    """Response for listing sources."""

    sources: List[Source]


@dataclass
class ListDestinationsResponse:
    """Response for listing destinations."""

    destinations: List[Destination]


@dataclass
class ListConnectionsResponse:
    """Response for listing connections."""

    connections: List[Connection]


@dataclass
class ListEventsResponse:
    """Response for listing events."""

    requests: List[Event]
    total: int
    limit: int
    offset: int


@dataclass
class GetEventResponse:
    """Response for getting an event."""

    request: Event


@dataclass
class ReplayEventResponse:
    """Response for replaying an event."""

    message: str
    delivery_attempt_id: Optional[int] = None


@dataclass
class ListDeliveryAttemptsResponse:
    """Response for listing delivery attempts."""

    attempts: List[DeliveryAttempt]
    total: int
    limit: int
    offset: int


@dataclass
class SendWebhookResponse:
    """Response for sending a webhook."""

    message: str
    event_id: Optional[str] = None

