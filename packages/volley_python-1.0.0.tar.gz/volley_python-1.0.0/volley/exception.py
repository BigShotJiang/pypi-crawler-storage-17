"""Exception classes for the Volley SDK."""


class VolleyException(Exception):
    """Base exception for all Volley API errors."""

    def __init__(self, message: str, status_code: int = 0):
        """
        Initialize a VolleyException.

        Args:
            message: Error message
            status_code: HTTP status code (0 if not available)
        """
        super().__init__(message)
        self.message = message
        self.status_code = status_code

    def is_unauthorized(self) -> bool:
        """Check if the error is due to unauthorized access (401)."""
        return self.status_code == 401

    def is_forbidden(self) -> bool:
        """Check if the error is due to forbidden access (403)."""
        return self.status_code == 403

    def is_not_found(self) -> bool:
        """Check if the error is due to resource not found (404)."""
        return self.status_code == 404

    def is_rate_limited(self) -> bool:
        """Check if the error is due to rate limiting (429)."""
        return self.status_code == 429

    def is_server_error(self) -> bool:
        """Check if the error is a server error (5xx)."""
        return 500 <= self.status_code < 600

    def __str__(self) -> str:
        if self.status_code > 0:
            return f"{self.message} (Status: {self.status_code})"
        return self.message

