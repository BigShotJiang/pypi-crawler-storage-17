"""Destinations API methods."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from volley.client import VolleyClient

from volley.models import (
    Destination,
    ListDestinationsResponse,
    CreateDestinationRequest,
    UpdateDestinationRequest,
)


class Destinations:
    """Destinations API methods."""

    def __init__(self, client: "VolleyClient"):
        """
        Initialize Destinations API client.

        Args:
            client: VolleyClient instance
        """
        self.client = client

    def list(self, project_id: int) -> list[Destination]:
        """
        List all destinations for a project.

        Args:
            project_id: Project ID

        Returns:
            List of destinations
        """
        response = self.client.request("GET", f"/api/projects/{project_id}/destinations")
        destinations_data = response.get("destinations", [])
        return [Destination(**dest) for dest in destinations_data]

    def create(self, project_id: int, request: CreateDestinationRequest) -> Destination:
        """
        Create a new destination.

        Args:
            project_id: Project ID
            request: CreateDestinationRequest with destination details

        Returns:
            Created destination
        """
        data = {
            "name": request.name,
            "url": request.url,
        }
        if request.eps is not None:
            data["eps"] = request.eps

        response = self.client.request(
            "POST", f"/api/projects/{project_id}/destinations", data=data
        )
        return Destination(**response)

    def get(self, project_id: int, destination_id: int) -> Destination:
        """
        Get a destination by ID.

        Args:
            project_id: Project ID
            destination_id: Destination ID

        Returns:
            Destination details
        """
        response = self.client.request(
            "GET", f"/api/projects/{project_id}/destinations/{destination_id}"
        )
        return Destination(**response)

    def update(
        self, project_id: int, destination_id: int, request: UpdateDestinationRequest
    ) -> Destination:
        """
        Update a destination.

        Args:
            project_id: Project ID
            destination_id: Destination ID
            request: UpdateDestinationRequest with updated fields

        Returns:
            Updated destination
        """
        data = {}
        if request.name is not None:
            data["name"] = request.name
        if request.url is not None:
            data["url"] = request.url
        if request.eps is not None:
            data["eps"] = request.eps

        response = self.client.request(
            "PUT", f"/api/projects/{project_id}/destinations/{destination_id}", data=data
        )
        return Destination(**response)

    def delete(self, project_id: int, destination_id: int) -> None:
        """
        Delete a destination.

        Args:
            project_id: Project ID
            destination_id: Destination ID to delete
        """
        self.client.request("DELETE", f"/api/projects/{project_id}/destinations/{destination_id}")

