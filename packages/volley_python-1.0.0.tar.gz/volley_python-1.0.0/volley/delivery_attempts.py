"""Delivery Attempts API methods."""

from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from volley.client import VolleyClient

from volley.models import (
    DeliveryAttempt,
    ListDeliveryAttemptsResponse,
)


class DeliveryAttempts:
    """Delivery Attempts API methods."""

    def __init__(self, client: "VolleyClient"):
        """
        Initialize DeliveryAttempts API client.

        Args:
            client: VolleyClient instance
        """
        self.client = client

    def list(
        self,
        project_id: int,
        event_id: Optional[str] = None,
        connection_id: Optional[int] = None,
        status: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> ListDeliveryAttemptsResponse:
        """
        List delivery attempts for a project with optional filters.

        Args:
            project_id: Project ID
            event_id: Filter by event ID
            connection_id: Filter by connection ID
            status: Filter by status
            limit: Maximum number of results
            offset: Offset for pagination

        Returns:
            ListDeliveryAttemptsResponse with attempts and pagination info
        """
        params = {}
        if event_id is not None:
            params["event_id"] = event_id
        if connection_id is not None:
            params["connection_id"] = str(connection_id)
        if status is not None:
            params["status"] = status
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)

        response = self.client.request(
            "GET", f"/api/projects/{project_id}/delivery-attempts", params=params
        )
        attempts_data = response.get("attempts", [])
        attempts = [DeliveryAttempt(**att) for att in attempts_data]
        return ListDeliveryAttemptsResponse(
            attempts=attempts,
            total=response.get("total", 0),
            limit=response.get("limit", 0),
            offset=response.get("offset", 0),
        )

