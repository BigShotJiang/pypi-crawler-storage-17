"""Webhooks API methods."""

from typing import Dict, Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from volley.client import VolleyClient

from volley.models import (
    SendWebhookRequest,
    SendWebhookResponse,
)


class Webhooks:
    """Webhooks API methods."""

    def __init__(self, client: "VolleyClient"):
        """
        Initialize Webhooks API client.

        Args:
            client: VolleyClient instance
        """
        self.client = client

    def send(self, request: SendWebhookRequest) -> SendWebhookResponse:
        """
        Send a webhook to a destination.

        Args:
            request: SendWebhookRequest with source, destination, body, and headers

        Returns:
            SendWebhookResponse with result
        """
        data = {
            "source_id": request.source_id,
            "destination_id": request.destination_id,
            "body": request.body,
        }
        if request.headers is not None:
            data["headers"] = request.headers

        response = self.client.request("POST", "/api/webhooks/send", data=data)
        return SendWebhookResponse(
            message=response.get("message", ""),
            event_id=response.get("event_id"),
        )

