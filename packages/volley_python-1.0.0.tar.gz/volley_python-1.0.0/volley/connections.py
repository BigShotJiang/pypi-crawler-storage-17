"""Connections API methods."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from volley.client import VolleyClient

from volley.models import (
    Connection,
    CreateConnectionRequest,
    UpdateConnectionRequest,
)


class Connections:
    """Connections API methods."""

    def __init__(self, client: "VolleyClient"):
        """
        Initialize Connections API client.

        Args:
            client: VolleyClient instance
        """
        self.client = client

    def create(self, project_id: int, request: CreateConnectionRequest) -> Connection:
        """
        Create a new connection.

        Args:
            project_id: Project ID
            request: CreateConnectionRequest with connection details

        Returns:
            Created connection
        """
        data = {
            "source_id": request.source_id,
            "destination_id": request.destination_id,
        }
        if request.status is not None:
            data["status"] = request.status
        if request.eps is not None:
            data["eps"] = request.eps
        if request.max_retries is not None:
            data["max_retries"] = request.max_retries

        response = self.client.request(
            "POST", f"/api/projects/{project_id}/connections", data=data
        )
        return Connection(**response)

    def get(self, project_id: int, connection_id: int) -> Connection:
        """
        Get a connection by ID.

        Args:
            project_id: Project ID
            connection_id: Connection ID

        Returns:
            Connection details
        """
        response = self.client.request(
            "GET", f"/api/projects/{project_id}/connections/{connection_id}"
        )
        return Connection(**response)

    def update(
        self, project_id: int, connection_id: int, request: UpdateConnectionRequest
    ) -> Connection:
        """
        Update a connection.

        Args:
            project_id: Project ID
            connection_id: Connection ID
            request: UpdateConnectionRequest with updated fields

        Returns:
            Updated connection
        """
        data = {}
        if request.status is not None:
            data["status"] = request.status
        if request.eps is not None:
            data["eps"] = request.eps
        if request.max_retries is not None:
            data["max_retries"] = request.max_retries

        response = self.client.request(
            "PUT", f"/api/projects/{project_id}/connections/{connection_id}", data=data
        )
        return Connection(**response)

    def delete(self, project_id: int, connection_id: int) -> None:
        """
        Delete a connection.

        Args:
            project_id: Project ID
            connection_id: Connection ID to delete
        """
        self.client.request("DELETE", f"/api/projects/{project_id}/connections/{connection_id}")

