"""Projects API methods."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from volley.client import VolleyClient

from volley.models import (
    Project,
    ListProjectsResponse,
    CreateProjectRequest,
    UpdateProjectRequest,
)


class Projects:
    """Projects API methods."""

    def __init__(self, client: "VolleyClient"):
        """
        Initialize Projects API client.

        Args:
            client: VolleyClient instance
        """
        self.client = client

    def list(self) -> list[Project]:
        """
        List all projects in the current organization.

        Returns:
            List of projects
        """
        response = self.client.request("GET", "/api/projects")
        projects_data = response.get("projects", [])
        # Handle projects that may have extra fields
        projects = []
        for proj in projects_data:
            if isinstance(proj, dict):
                # Extract only the fields we need, ignoring extra fields
                project_data = {
                    "id": proj.get("id"),
                    "name": proj.get("name"),
                    "organization_id": proj.get("organization_id"),
                    "user_id": proj.get("user_id"),
                    "is_default": proj.get("is_default", False),
                    "created_at": proj.get("created_at", ""),
                    "updated_at": proj.get("updated_at", ""),
                }
                projects.append(Project(**project_data))
            else:
                projects.append(proj)
        return projects

    def create(self, request: CreateProjectRequest) -> Project:
        """
        Create a new project.

        Args:
            request: CreateProjectRequest with project name

        Returns:
            Created project
        """
        data = {"name": request.name}
        response = self.client.request("POST", "/api/projects", data=data)
        return Project(**response)

    def update(self, project_id: int, request: UpdateProjectRequest) -> Project:
        """
        Update a project.

        Args:
            project_id: Project ID
            request: UpdateProjectRequest with updated fields

        Returns:
            Updated project
        """
        data = {}
        if request.name is not None:
            data["name"] = request.name

        response = self.client.request("PUT", f"/api/projects/{project_id}", data=data)
        return Project(**response)

    def delete(self, project_id: int) -> None:
        """
        Delete a project.

        Args:
            project_id: Project ID to delete
        """
        self.client.request("DELETE", f"/api/projects/{project_id}")

