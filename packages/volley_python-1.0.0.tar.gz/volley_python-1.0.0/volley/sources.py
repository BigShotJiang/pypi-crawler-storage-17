"""Sources API methods."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from volley.client import VolleyClient

from volley.models import (
    Source,
    ListSourcesResponse,
    CreateSourceRequest,
    UpdateSourceRequest,
)


class Sources:
    """Sources API methods."""

    def __init__(self, client: "VolleyClient"):
        """
        Initialize Sources API client.

        Args:
            client: VolleyClient instance
        """
        self.client = client

    def list(self, project_id: int) -> list[Source]:
        """
        List all sources for a project.

        Args:
            project_id: Project ID

        Returns:
            List of sources
        """
        response = self.client.request("GET", f"/api/projects/{project_id}/sources")
        sources_data = response.get("sources", [])
        return [Source(**src) for src in sources_data]

    def create(self, project_id: int, request: CreateSourceRequest) -> Source:
        """
        Create a new source.

        Args:
            project_id: Project ID
            request: CreateSourceRequest with source details

        Returns:
            Created source
        """
        data = {
            "slug": request.slug,
            "type": request.type,
        }
        if request.eps is not None:
            data["eps"] = request.eps
        if request.auth_type is not None:
            data["auth_type"] = request.auth_type
        if request.auth_username is not None:
            data["auth_username"] = request.auth_username
        if request.auth_key is not None:
            data["auth_key"] = request.auth_key
        if request.verify_signature is not None:
            data["verify_signature"] = request.verify_signature
        if request.webhook_secret is not None:
            data["webhook_secret"] = request.webhook_secret

        response = self.client.request("POST", f"/api/projects/{project_id}/sources", data=data)
        return Source(**response)

    def get(self, project_id: int, source_id: int) -> Source:
        """
        Get a source by ID.

        Args:
            project_id: Project ID
            source_id: Source ID

        Returns:
            Source details
        """
        response = self.client.request("GET", f"/api/projects/{project_id}/sources/{source_id}")
        return Source(**response)

    def update(self, project_id: int, source_id: int, request: UpdateSourceRequest) -> Source:
        """
        Update a source.

        Args:
            project_id: Project ID
            source_id: Source ID
            request: UpdateSourceRequest with updated fields

        Returns:
            Updated source
        """
        data = {}
        if request.slug is not None:
            data["slug"] = request.slug
        if request.eps is not None:
            data["eps"] = request.eps
        if request.auth_type is not None:
            data["auth_type"] = request.auth_type
        if request.auth_username is not None:
            data["auth_username"] = request.auth_username
        if request.auth_key is not None:
            data["auth_key"] = request.auth_key
        if request.verify_signature is not None:
            data["verify_signature"] = request.verify_signature
        if request.webhook_secret is not None:
            data["webhook_secret"] = request.webhook_secret

        response = self.client.request(
            "PUT", f"/api/projects/{project_id}/sources/{source_id}", data=data
        )
        return Source(**response)

    def delete(self, project_id: int, source_id: int) -> None:
        """
        Delete a source.

        Args:
            project_id: Project ID
            source_id: Source ID to delete
        """
        self.client.request("DELETE", f"/api/projects/{project_id}/sources/{source_id}")

