"""Main client for interacting with the Volley API."""

from typing import Optional, Dict, Any
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from volley.exception import VolleyException
from volley.organizations import Organizations
from volley.projects import Projects
from volley.sources import Sources
from volley.destinations import Destinations
from volley.connections import Connections
from volley.events import Events
from volley.delivery_attempts import DeliveryAttempts
from volley.webhooks import Webhooks

DEFAULT_BASE_URL = "https://api.volleyhooks.com"
DEFAULT_TIMEOUT = 30  # 30 seconds


class VolleyClient:
    """Main client for interacting with the Volley API."""

    def __init__(
        self,
        api_token: str,
        base_url: Optional[str] = None,
        organization_id: Optional[int] = None,
        timeout: Optional[int] = None,
        session: Optional[requests.Session] = None,
    ):
        """
        Initialize a VolleyClient.

        Args:
            api_token: Your Volley API token
            base_url: Custom base URL (defaults to https://api.volleyhooks.com)
            organization_id: Organization ID for all requests
            timeout: Request timeout in seconds (defaults to 30)
            session: Custom requests.Session (optional)
        """
        if not api_token:
            raise ValueError("API token is required")

        self.api_token = api_token
        self.base_url = base_url or DEFAULT_BASE_URL
        self.organization_id = organization_id
        self.timeout = timeout or DEFAULT_TIMEOUT

        # Create or use provided session
        if session:
            self.session = session
        else:
            self.session = requests.Session()
            # Configure retry strategy
            retry_strategy = Retry(
                total=3,
                backoff_factor=1,
                status_forcelist=[429, 500, 502, 503, 504],
            )
            adapter = HTTPAdapter(max_retries=retry_strategy)
            self.session.mount("http://", adapter)
            self.session.mount("https://", adapter)

        # Set default headers
        self.session.headers.update(
            {
                "Authorization": f"Bearer {self.api_token}",
                "Content-Type": "application/json",
            }
        )

        # Initialize API resource clients
        self.organizations = Organizations(self)
        self.projects = Projects(self)
        self.sources = Sources(self)
        self.destinations = Destinations(self)
        self.connections = Connections(self)
        self.events = Events(self)
        self.delivery_attempts = DeliveryAttempts(self)
        self.webhooks = Webhooks(self)

    def set_organization_id(self, organization_id: int) -> None:
        """
        Set the organization ID for subsequent requests.

        Args:
            organization_id: The organization ID to use
        """
        self.organization_id = organization_id

    def clear_organization_id(self) -> None:
        """Clear the organization ID (uses default organization)."""
        self.organization_id = None

    def get_organization_id(self) -> Optional[int]:
        """
        Get the current organization ID.

        Returns:
            The organization ID, or None if not set
        """
        return self.organization_id

    def request(
        self,
        method: str,
        path: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Perform an HTTP request with authentication.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            path: API path (e.g., /api/org)
            data: Request body data (for POST/PUT)
            params: Query parameters

        Returns:
            Response data as a dictionary

        Raises:
            VolleyException: If the request fails
        """
        url = f"{self.base_url}{path}"

        # Add organization ID header if set
        headers = {}
        if self.organization_id is not None:
            headers["X-Organization-ID"] = str(self.organization_id)

        try:
            response = self.session.request(
                method=method,
                url=url,
                json=data,
                params=params,
                headers=headers,
                timeout=self.timeout,
            )

            # Handle errors
            if not response.ok:
                error_message = "Request failed"
                try:
                    error_data = response.json()
                    error_message = error_data.get("error") or error_data.get("message") or error_message
                except (ValueError, KeyError):
                    error_message = response.text or error_message

                raise VolleyException(error_message, response.status_code)

            # Return JSON response
            if response.content:
                return response.json()
            return {}

        except requests.exceptions.RequestException as e:
            raise VolleyException(f"Request failed: {str(e)}", 0) from e
        except VolleyException:
            raise
        except Exception as e:
            raise VolleyException(f"Unexpected error: {str(e)}", 0) from e

