"""Events API methods."""

from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from volley.client import VolleyClient

from volley.models import (
    Event,
    ListEventsResponse,
    GetEventResponse,
    ReplayEventRequest,
    ReplayEventResponse,
)


class Events:
    """Events API methods."""

    def __init__(self, client: "VolleyClient"):
        """
        Initialize Events API client.

        Args:
            client: VolleyClient instance
        """
        self.client = client

    def list(
        self,
        project_id: int,
        source_id: Optional[int] = None,
        connection_id: Optional[int] = None,
        destination_id: Optional[int] = None,
        status: Optional[str] = None,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        search: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> ListEventsResponse:
        """
        List all events/requests for a project with optional filters.

        Args:
            project_id: Project ID
            source_id: Filter by source ID
            connection_id: Filter by connection ID
            destination_id: Filter by destination ID
            status: Filter by status
            start_time: Filter by start time (ISO 8601)
            end_time: Filter by end time (ISO 8601)
            search: Search query
            limit: Maximum number of results
            offset: Offset for pagination

        Returns:
            ListEventsResponse with events and pagination info
        """
        params = {}
        if source_id is not None:
            params["source_id"] = str(source_id)
        if connection_id is not None:
            params["connection_id"] = str(connection_id)
        if destination_id is not None:
            params["destination_id"] = str(destination_id)
        if status is not None:
            params["status"] = status
        if start_time is not None:
            params["start_time"] = start_time
        if end_time is not None:
            params["end_time"] = end_time
        if search is not None:
            params["search"] = search
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)

        response = self.client.request(
            "GET", f"/api/projects/{project_id}/requests", params=params
        )
        events_data = response.get("requests", [])
        events = [Event.from_dict(evt) if isinstance(evt, dict) else evt for evt in events_data]
        return ListEventsResponse(
            requests=events,
            total=response.get("total", 0),
            limit=response.get("limit", 0),
            offset=response.get("offset", 0),
        )

    def get(self, request_id: int) -> Event:
        """
        Get detailed information about a specific event by its database ID.

        Args:
            request_id: Request/Event database ID

        Returns:
            Event details
        """
        response = self.client.request("GET", f"/api/requests/{request_id}")
        event_data = response.get("request", response)
        return Event.from_dict(event_data)

    def replay(self, request: ReplayEventRequest) -> ReplayEventResponse:
        """
        Replay a failed event by its event_id.

        Args:
            request: ReplayEventRequest with event_id and optional filters

        Returns:
            ReplayEventResponse with result
        """
        data = {"event_id": request.event_id}
        if request.destination_id is not None:
            data["destination_id"] = request.destination_id
        if request.connection_id is not None:
            data["connection_id"] = request.connection_id

        response = self.client.request("POST", "/api/replay-event", data=data)
        return ReplayEventResponse(
            message=response.get("message", ""),
            delivery_attempt_id=response.get("delivery_attempt_id"),
        )

