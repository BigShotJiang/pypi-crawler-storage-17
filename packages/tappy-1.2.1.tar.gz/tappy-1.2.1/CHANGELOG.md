## 1.2.1 (2025-12-17)

### Fix

- trying yet again to have tappy work on windows
- use 'with' context manager to write
- no longer write log files to /tmp so should run on windows

## 1.2.0 (2024-09-16)

### Fix

- fixed imports and move to toolbox_utils as git submodule
- for the time-being get rid of ephemeris file because of size

### Feat

- begin using skyfield

## 1.1.0 (2024-03-31)

### Refactor

- begin of refactore of tidal filters

### Feat

- begin using skyfield

## 1.0.5 (2023-12-16)

### Refactor

- refactor

## 1.0.4 (2023-07-26)

## 1.0.3 (2023-07-26)

## 1.0.2 (2023-07-26)

## 1.0.1 (2023-07-26)

## 1.0.0 (2023-06-20)

### Refactor

- complete refactor to match approach with other toolboxes

## 0.10.4 (2023-04-29)

### Fix

- **sparser.py**: getiteritems was deprecated for iter in python 3.9
- under some conditions it wasn't finding the parsing definition file

### Refactor

- small refactors from black, isort, and ruff

## 0.10.3 (2023-01-16)

## 0.10.2 (2023-01-08)

## 0.10.1 (2022-09-29)

### Refactor

- updated pyproject.toml

## 0.10.0 (2022-07-16)

### Feat

- uses tstoolbox read to support csv, wdm, hdf5, and xlsx files
- use tstoolbox.read

## 0.9.6 (2022-07-13)

### Fix

- needed an __init__.py to identify the package

## 0.9.5 (2022-07-04)

### Refactor

- complete refactor to style i use in the toolboxes plus several fixes
- removed __future__

## 0.9.4 (2022-04-16)

### Fix

- removed filelike library as a dependency
- **setup.py**: fixed location of scripts and packages in setup.py

## 0.9.3 (2022-04-16)

### Fix

- **2to3**: edited to support python 3, no longer supporting python 2
