.. include:: ../BADGES.rst
License
=======

.. literalinclude:: ../LICENSE.txt
