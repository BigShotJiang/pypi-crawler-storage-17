.. include:: ../BADGES.rst

Python API Function Summary
===========================

.. autosummary::
    :toctree: _function_autosummary

    tappy.tappy.analysis
    tappy.tappy.prediction
