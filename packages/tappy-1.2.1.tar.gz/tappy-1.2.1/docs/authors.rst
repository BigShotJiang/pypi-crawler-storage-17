.. include:: ../BADGES.rst
.. include:: ../AUTHORS.rst
