.. include:: ../BADGES.rst

Command Line
============

Help::

    tappy --help

analysis
~~~~~~~~
.. program-output:: tappy analysis --help
   :prompt:

prediction
~~~~~~~~~~
.. program-output:: tappy prediction --help
   :prompt:
