.. include:: ../BADGES.rst
.. include:: ../CONTRIBUTING.rst
