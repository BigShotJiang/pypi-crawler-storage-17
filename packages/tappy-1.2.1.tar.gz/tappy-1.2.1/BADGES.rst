.. image:: https://github.com/timcera/tappy/actions/workflows/pypi-package.yml/badge.svg
    :alt: Tests
    :target: https://github.com/timcera/tappy/actions/workflows/pypi-package.yml
    :height: 20

.. image:: https://img.shields.io/coveralls/github/timcera/tappy
    :alt: Test Coverage
    :target: https://coveralls.io/r/timcera/tappy?branch=master
    :height: 20

.. image:: https://img.shields.io/pypi/v/tappy.svg
    :alt: Latest release
    :target: https://pypi.python.org/pypi/tappy/
    :height: 20

.. image:: https://img.shields.io/pypi/l/tappy.svg
    :alt: BSD-3 clause license
    :target: https://pypi.python.org/pypi/tappy/
    :height: 20

.. image:: https://img.shields.io/pypi/pyversions/tappy
    :alt: PyPI - Python Version
    :target: https://pypi.org/project/tappy/
    :height: 20
