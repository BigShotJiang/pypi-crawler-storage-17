# Historical notes

## KRM code from Clay & Horne (1994)

The original Basic language code for the KRM model is available as part of echoSMs [here](https://github.com/ices-tools-dev/echoSMs/tree/main/src/otherCode/Clay_Files). Also included there are the original shape data for the four cod fish used in the paper.

## PSMS code from Furusawa (1988)

The HP Basic language code for the PSMS model is available as part of echoSMs [here](https://github.com/ices-tools-dev/echoSMs/tree/main/src/otherCode/Furusawa_PSM). Also included is a modified version of the code that can run on a Windows computer with HTBasic.
