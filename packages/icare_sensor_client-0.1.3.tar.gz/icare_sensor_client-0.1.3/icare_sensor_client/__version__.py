"""Version information for iCare Sensor Client."""

__version__ = "0.1.0"
