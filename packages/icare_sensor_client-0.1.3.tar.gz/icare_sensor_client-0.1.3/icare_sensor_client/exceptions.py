"""
Exception classes for iCare Sensor Client.

This module defines custom exceptions used by the sensor client library
to provide clear error handling and diagnostics.
"""


class SensorClientError(Exception):
    """Base exception for sensor client errors."""
    pass


class SensorNotInitializedError(SensorClientError):
    """Raised when the sensor is not initialized on the server."""
    pass


class ConnectionError(SensorClientError):
    """Raised when unable to connect to the sensor agent."""
    pass
