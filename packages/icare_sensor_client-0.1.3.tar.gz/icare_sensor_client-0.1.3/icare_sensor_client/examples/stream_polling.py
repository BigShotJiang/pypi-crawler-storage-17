"""
Stream state polling example for iCare Sensor Client.

This example demonstrates:
- High-frequency stream state polling
- Using client-side caching to reduce HTTP overhead
- Handling different stream states
- Graceful shutdown with keyboard interrupt
"""

import time
from datetime import datetime
from icare_sensor_client import (
    SensorClient,
    SensorClientError,
    SensorNotInitializedError,
    ConnectionError
)


def format_timestamp():
    """Return formatted timestamp for logging."""
    return datetime.now().strftime("%H:%M:%S.%f")[:-3]


def get_state_description(state):
    """
    Convert stream state code to human-readable description.
    
    Args:
        state: Stream state value (0, 1, 2, or None)
    
    Returns:
        Tuple of (description, emoji) for display
    """
    if state == 0:
        return "NOT STREAMING", "⭕"
    elif state == 1:
        return "ACTIVE", "✅"
    elif state == 2:
        return "TIMED OUT", "⏱️"
    elif state is None:
        return "UNAVAILABLE", "❓"
    else:
        return f"UNKNOWN ({state})", "❔"


def poll_stream_state(sensor_url, poll_interval=0.1, cache_ttl=0.05):
    """
    Poll stream state continuously with caching.
    
    Args:
        sensor_url: URL of the sensor agent
        poll_interval: Time between polls in seconds (default: 0.1 = 100ms)
        cache_ttl: Cache time-to-live in seconds (default: 0.05 = 50ms)
    
    The cache_ttl should be less than poll_interval for optimal performance.
    This allows multiple rapid checks within the poll interval to use cached data.
    """
    
    print("=" * 70)
    print("iCare Sensor Client - Stream State Polling Example")
    print("=" * 70)
    print()
    print(f"Sensor URL: {sensor_url}")
    print(f"Poll Interval: {poll_interval * 1000:.0f}ms")
    print(f"Cache TTL: {cache_ttl * 1000:.0f}ms")
    print()
    print("Stream States:")
    print("  0 = Not streaming (initial state)")
    print("  1 = Streaming active")
    print("  2 = Stream timed out (after 60 seconds of inactivity)")
    print()
    print("Press Ctrl+C to stop polling")
    print("=" * 70)
    print()
    
    try:
        # Create client with custom cache TTL for high-frequency polling
        # The cache reduces HTTP requests when polling frequently
        client = SensorClient(sensor_url, timeout=5, cache_ttl=cache_ttl)
        
        # Verify connection
        print(f"[{format_timestamp()}] Connecting to sensor agent...")
        info = client.get_info()
        print(f"[{format_timestamp()}] Connected to: {info.get('service', 'Unknown')}")
        print()
        
        # Track state changes
        previous_state = None
        poll_count = 0
        state_change_count = 0
        
        # Start polling loop
        print("Starting stream state monitoring...")
        print()
        
        while True:
            poll_count += 1
            
            # Get stream state (uses cache if available)
            # If called within cache_ttl, this will NOT make an HTTP request
            current_state = client.get_stream_state()
            
            # Get human-readable description
            description, emoji = get_state_description(current_state)
            
            # Check if state changed
            if current_state != previous_state:
                state_change_count += 1
                
                # Log state change with timestamp
                print(f"[{format_timestamp()}] {emoji} Stream State: {description} (code: {current_state})")
                
                # Additional info on state changes
                if current_state == 1 and previous_state == 0:
                    print(f"                  → Stream started")
                elif current_state == 2 and previous_state == 1:
                    print(f"                  → Stream timed out (no activity for 60s)")
                elif current_state == 0 and previous_state in [1, 2]:
                    print(f"                  → Stream stopped/reset")
                
                print()
                
                previous_state = current_state
            
            # Periodic status update (every 50 polls)
            if poll_count % 50 == 0:
                print(f"[{format_timestamp()}] Status: {description} | "
                      f"Polls: {poll_count} | State Changes: {state_change_count}")
            
            # Wait before next poll
            time.sleep(poll_interval)
        
    except SensorNotInitializedError:
        print()
        print("ERROR: Sensor is not initialized on the server")
        print("Please initialize the sensor before monitoring stream state.")
        return 1
        
    except ConnectionError as e:
        print()
        print(f"ERROR: Unable to connect to sensor agent at {sensor_url}")
        print(f"Details: {e}")
        print()
        print("Please check that the sensor agent is running and accessible.")
        return 1
        
    except SensorClientError as e:
        print()
        print(f"ERROR: API error occurred")
        print(f"Details: {e}")
        return 1
        
    except KeyboardInterrupt:
        # Graceful shutdown on Ctrl+C
        print()
        print()
        print("=" * 70)
        print("Polling stopped by user")
        print(f"Total polls: {poll_count}")
        print(f"State changes detected: {state_change_count}")
        print("=" * 70)
        return 0
        
    except Exception as e:
        print()
        print(f"UNEXPECTED ERROR: {type(e).__name__}")
        print(f"Details: {e}")
        return 1
        
    finally:
        # Always clean up
        try:
            client.close()
            print("Connection closed")
        except:
            pass


def demonstrate_caching_benefit():
    """
    Demonstrate the performance benefit of client-side caching.
    
    This function shows how caching reduces HTTP requests when
    polling frequently.
    """
    
    print()
    print("=" * 70)
    print("Caching Benefit Demonstration")
    print("=" * 70)
    print()
    
    SENSOR_URL = "http://localhost:8000"
    
    try:
        # Test 1: Without caching (cache_ttl=0)
        print("Test 1: Polling WITHOUT caching (cache_ttl=0)")
        print("Making 10 rapid calls...")
        
        client_no_cache = SensorClient(SENSOR_URL, cache_ttl=0)
        start_time = time.time()
        
        for i in range(10):
            state = client_no_cache.get_stream_state()
        
        no_cache_time = time.time() - start_time
        client_no_cache.close()
        
        print(f"Time taken: {no_cache_time * 1000:.2f}ms")
        print(f"Average per call: {no_cache_time * 100:.2f}ms")
        print()
        
        # Test 2: With caching (cache_ttl=0.1)
        print("Test 2: Polling WITH caching (cache_ttl=0.1)")
        print("Making 10 rapid calls...")
        
        client_with_cache = SensorClient(SENSOR_URL, cache_ttl=0.1)
        start_time = time.time()
        
        for i in range(10):
            state = client_with_cache.get_stream_state()
        
        with_cache_time = time.time() - start_time
        client_with_cache.close()
        
        print(f"Time taken: {with_cache_time * 1000:.2f}ms")
        print(f"Average per call: {with_cache_time * 100:.2f}ms")
        print()
        
        # Show improvement
        improvement = ((no_cache_time - with_cache_time) / no_cache_time) * 100
        print(f"Performance improvement: {improvement:.1f}%")
        print(f"Speedup: {no_cache_time / with_cache_time:.1f}x faster")
        print()
        print("Note: With caching, only the first call makes an HTTP request.")
        print("      Subsequent calls within cache_ttl use the cached value.")
        print()
        
    except Exception as e:
        print(f"Error during demonstration: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    # Configuration
    SENSOR_URL = "http://localhost:8000"
    POLL_INTERVAL = 0.1  # 100ms between polls
    CACHE_TTL = 0.05     # 50ms cache lifetime
    
    # Run the main polling example
    exit_code = poll_stream_state(SENSOR_URL, POLL_INTERVAL, CACHE_TTL)
    
    # Optionally demonstrate caching benefit
    # Uncomment the line below to see caching performance comparison
    # exit_code = demonstrate_caching_benefit()
    
    exit(exit_code)
