"""
Python client library for iCare Sensor Communication Agent API.

This module provides a simple interface for interacting with the sensor
communication agent without having to manually craft HTTP requests.

Example:
    >>> from icare_sensor_client import SensorClient
    >>> client = SensorClient("http://localhost:8000")
    >>> client.send_alert("Patient fall detected", "high", "camera", 1)
"""

import requests
from typing import Dict, Any, Optional
from dataclasses import dataclass

from .exceptions import (
    SensorClientError,
    SensorNotInitializedError,
    ConnectionError
)


@dataclass
class SensorStatus:
    """Sensor status information."""
    sensor_id: Optional[str]
    shared_variable: Optional[int]
    reset_scene: Optional[bool]
    update_available: Optional[bool]


class SensorClient:
    """
    Client for interacting with the iCare Sensor Communication Agent API.
    
    Args:
        base_url: Base URL of the agent API (default: http://localhost:8000)
        timeout: Request timeout in seconds (default: 10)
        cache_ttl: Cache time-to-live in seconds for stream state (default: 0.1 = 100ms)
                  Set to 0 to disable caching
        raise_on_error: If False (default), returns error dict instead of raising exceptions.
                       If True, raises exceptions on errors (legacy behavior).
    
    Example:
        >>> # Safe mode (default) - won't crash your app
        >>> client = SensorClient("http://10.42.0.1:8000")
        >>> result = client.send_alert("Fall detected", "high", "camera", 1)
        >>> if result.get('error'):
        ...     print(f"Alert failed: {result['error']}")
        
        >>> # Strict mode - raises exceptions
        >>> client = SensorClient("http://localhost:8000", raise_on_error=True)
        >>> client.send_alert("Fall detected", "high", "camera", 1)  # May raise exception
        
        >>> # With custom cache TTL for high-frequency polling
        >>> client = SensorClient("http://localhost:8000", cache_ttl=0.05)  # 50ms cache
    """
    
    def __init__(self, base_url: str = "http://localhost:8000", timeout: int = 10, cache_ttl: float = 0.1, raise_on_error: bool = False):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.cache_ttl = cache_ttl
        self.raise_on_error = raise_on_error
        self.session = requests.Session()
        
        # Cache for stream state
        self._stream_state_cache = None
        self._stream_state_cache_time = 0
    
    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """
        Make an HTTP request to the API.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            **kwargs: Additional arguments to pass to requests
        
        Returns:
            Response JSON as dictionary, or error dict if raise_on_error=False
        
        Raises:
            SensorNotInitializedError: If sensor is not initialized (only if raise_on_error=True)
            SensorClientError: For other API errors (only if raise_on_error=True)
            ConnectionError: If unable to connect to the agent (only if raise_on_error=True)
        """
        url = f"{self.base_url}{endpoint}"
        kwargs.setdefault('timeout', self.timeout)
        
        try:
            response = self.session.request(method, url, **kwargs)
            
            # Handle specific status codes
            if response.status_code == 503:
                error = SensorNotInitializedError("Sensor is not initialized on the server")
                if self.raise_on_error:
                    raise error
                return {"error": str(error), "error_type": "SensorNotInitializedError"}
            
            # Raise for other HTTP errors
            response.raise_for_status()
            
            return response.json()
            
        except requests.exceptions.ConnectionError as e:
            error = ConnectionError(f"Unable to connect to sensor agent at {self.base_url}: {e}")
            if self.raise_on_error:
                raise error
            return {"error": str(error), "error_type": "ConnectionError"}
        except requests.exceptions.Timeout as e:
            error = SensorClientError(f"Request timeout after {self.timeout}s: {e}")
            if self.raise_on_error:
                raise error
            return {"error": str(error), "error_type": "TimeoutError"}
        except requests.exceptions.HTTPError as e:
            # Include response body for debugging validation errors (422)
            error_detail = ""
            if hasattr(e.response, 'text'):
                error_detail = f"\nResponse: {e.response.text}"
            error = SensorClientError(f"HTTP error: {e}{error_detail}")
            if self.raise_on_error:
                raise error
            return {"error": str(error), "error_type": "HTTPError"}
        except requests.exceptions.RequestException as e:
            error = SensorClientError(f"Request failed: {e}")
            if self.raise_on_error:
                raise error
            return {"error": str(error), "error_type": "RequestError"}
    
    def get_info(self) -> Dict[str, Any]:
        """
        Get API service information.
        
        Returns:
            Dictionary containing service name, version, and status
        
        Example:
            >>> info = client.get_info()
            >>> print(f"{info['service']} v{info['version']}")
        """
        return self._request('GET', '/')
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check sensor health status.
        
        Returns:
            Dictionary with health status and sensor ID
        
        Raises:
            SensorNotInitializedError: If sensor is not initialized
        
        Example:
            >>> health = client.health_check()
            >>> if health['ok']:
            ...     print(f"Sensor {health['sensor_id']} is healthy")
        """
        return self._request('GET', '/health')
    
    def send_alert(
        self,
        content: str,
        severity: str,
        source_type: str,
        source_id: int
    ) -> Dict[str, Any]:
        """
        Send an alert through the sensor component.
        
        Args:
            content: Alert message content
            severity: Alert severity level (e.g., "low", "medium", "high", "critical")
            source_type: Type of source generating the alert (e.g., "camera", "sensor")
            source_id: Unique identifier of the source
        
        Returns:
            Success confirmation dictionary
        
        Example:
            >>> client.send_alert(
            ...     content="Patient fall detected",
            ...     severity="high",
            ...     source_type="camera",
            ...     source_id=1
            ... )
            {'ok': True, 'message': 'Alert sent successfully'}
        """
        payload = {
            "content": content,
            "severity": severity,
            "source_type": source_type,
            "source_id": source_id
        }
        return self._request('POST', '/alert', json=payload)
    
    def send_coordinates(
        self,
        patient_coords,
        bed_coords,
        dimension
    ) -> Dict[str, Any]:
        """
        Send coordinate data through the sensor component.
        
        Args:
            patient_coords: Patient coordinates. Can be:
                - Dict: {"x": 100, "y": 200, "z": 0}
                - List: List of patient coordinate objects
                - Empty list: [] when no patients detected
            bed_coords: Bed/furniture coordinates. Can be:
                - Dict: {"x": 50, "y": 150, "z": 0}
                - List: List of furniture objects with 'id', 'cord', 'type' keys
            dimension: Room dimensions. Can be:
                - Dict: {"width": 500, "height": 400, "depth": 300}
                - List: [height, width] - will be converted to dict format
        
        Returns:
            Success confirmation dictionary
        
        Example:
            >>> # Using dict format
            >>> client.send_coordinates(
            ...     patient_coords={"x": 120, "y": 180, "z": 0},
            ...     bed_coords={"x": 50, "y": 150, "z": 0},
            ...     dimension={"width": 500, "height": 400, "depth": 300}
            ... )
            {'ok': True, 'message': 'Coordinates sent successfully'}
            
            >>> # Using list format (for compatibility)
            >>> client.send_coordinates(
            ...     patient_coords=[],
            ...     bed_coords=[{"id": 0, "cord": [0, 50, 198, 479], "type": "bed"}],
            ...     dimension=[480, 640]  # [height, width]
            ... )
            {'ok': True, 'message': 'Coordinates sent successfully'}
        """
      
        
        payload = {
            "patient_coord_obj": patient_coords,
            "bed_coord_obj": bed_coords,
            "dimension": dimension
        }
        print(f"payload before sending {payload}")
        return self._request('POST', '/coords', json=payload)
    
    def upload_video(self) -> Dict[str, Any]:
        """
        Trigger video file upload to hub.
        
        Returns:
            Success confirmation dictionary
        
        Example:
            >>> result = client.upload_video()
            >>> if result['ok']:
            ...     print("Video uploaded successfully")
        """
        return self._request('POST', '/video/upload')
    
    def get_status(self) -> SensorStatus:
        """
        Get current sensor status.
        
        Returns:
            SensorStatus object with current status information
        
        Example:
            >>> status = client.get_status()
            >>> print(f"Sensor ID: {status.sensor_id}")
            >>> print(f"Stream State: {status.shared_variable}")  # 0=stopped, 1=active, 2=timed out
        """
        data = self._request('GET', '/status')
        return SensorStatus(
            sensor_id=data.get('sensor_id'),
            shared_variable=data.get('shared_variable'),
            reset_scene=data.get('reset_scene'),
            update_available=data.get('update_available')
        )
    
    def get_stream_state(self) -> Optional[int]:
        """
        Get the current stream state (with client-side caching).
        
        This method caches the result to reduce HTTP overhead when polling frequently.
        The cache TTL is configurable via the cache_ttl parameter in __init__.
        
        Returns:
            Stream state value:
            - 0: Not streaming (initial state)
            - 1: Streaming started/active
            - 2: Stream stopped (timed out after 60 seconds)
            - None: Not available
        
        Example:
            >>> client = SensorClient("http://localhost:8000", cache_ttl=0.1)
            >>> 
            >>> # First call - makes HTTP request
            >>> stream_state = client.get_stream_state()  # HTTP call
            >>> if stream_state == 1:
            ...     print("Stream is ACTIVE")
            >>> 
            >>> # Subsequent calls within 100ms - uses cache (no HTTP)
            >>> for i in range(100):
            ...     state = client.get_stream_state()  # Cached!
        """
        import time
        
        # Check if caching is enabled and cache is still fresh
        if self.cache_ttl > 0:
            now = time.time()
            cache_age = now - self._stream_state_cache_time
            
            if cache_age < self.cache_ttl and self._stream_state_cache is not None:
                # Return cached value
                return self._stream_state_cache
        
        # Cache miss or expired - fetch fresh value
        data = self._request('GET', '/status')
        fresh_value = data.get('shared_variable')
        
        # Update cache
        if self.cache_ttl > 0:
            self._stream_state_cache = fresh_value
            self._stream_state_cache_time = time.time()
        
        return fresh_value
    
    def reset_scene(self) -> Dict[str, Any]:
        """
        Request scene reset.
        
        Returns:
            Success confirmation dictionary
        
        Example:
            >>> client.reset_scene()
            {'ok': True, 'message': 'Scene reset confirmed'}
        """
        return self._request('POST', '/scene/reset')
    
    def close(self):
        """Close the session and cleanup resources."""
        self.session.close()
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
