"""
Setup script for iCare Sensor Client package.

This setup.py provides backward compatibility with older pip versions
that don't fully support pyproject.toml. Modern installations should
use pyproject.toml directly.
"""

from setuptools import setup, find_packages
import os

# Read version from __version__.py
version = {}
version_file = os.path.join(os.path.dirname(__file__), 'icare_sensor_client', '__version__.py')
with open(version_file) as f:
    exec(f.read(), version)

# Read long description from README
readme_file = os.path.join(os.path.dirname(__file__), 'README.md')
long_description = ""
if os.path.exists(readme_file):
    with open(readme_file, 'r', encoding='utf-8') as f:
        long_description = f.read()

setup(
    name="icare-sensor-client",
    version=version['__version__'],
    description="Python client library for iCare Sensor Communication Agent API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="iCare Development Team",
    author_email="dev@icare.example.com",
    url="https://github.com/icare/sensor-client",
    packages=find_packages(exclude=["tests", "tests.*"]),
    package_data={
        'icare_sensor_client': ['py.typed'],
    },
    install_requires=[
        "requests>=2.31.0",
    ],
    extras_require={
        'dev': [
            "pytest>=7.0.0",
            "hypothesis>=6.0.0",
            "responses>=0.23.0",
            "build>=0.10.0",
            "twine>=4.0.0",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Monitoring",
    ],
    keywords="icare sensor client api healthcare monitoring",
    project_urls={
        "Documentation": "https://github.com/icare/sensor-client#readme",
        "Source": "https://github.com/icare/sensor-client",
        "Issues": "https://github.com/icare/sensor-client/issues",
    },
)
