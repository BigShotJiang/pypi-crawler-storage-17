"""Compose Farm Web UI."""

from __future__ import annotations

from compose_farm.web.app import create_app

__all__ = ["create_app"]
