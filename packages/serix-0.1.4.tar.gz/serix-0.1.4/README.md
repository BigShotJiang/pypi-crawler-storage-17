> **🚧 Status: Pre-Alpha / Active Development**
>
> *Serix is currently in heavy development. Breaking changes are expected until v1.0.0 (Release Target: Dec 20).*
