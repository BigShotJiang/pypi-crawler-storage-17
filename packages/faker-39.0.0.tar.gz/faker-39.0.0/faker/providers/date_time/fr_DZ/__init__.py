from ..fr_FR import Provider as fr_FRProvider


class Provider(fr_FRProvider):
    pass
