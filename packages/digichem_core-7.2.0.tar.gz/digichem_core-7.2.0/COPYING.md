Copyright (C) 2024  Digichem.
The Digichem-core repository is free, open-source software.

The main code base is licensed under the BSD-3-Clause license, see [`LICENSE`](LICENSE) for full details.

Code distributed under the [`digichem/data/batoms`](digichem/data/batoms) directory is licensed separately under the GNU General Public License V3, see [`digichem/data/batoms/LICENSE`](digichem/data/batoms/LICENSE) for full license details.

The Digichem logo and banner is not licensed for use, and remains Copyright (C) 2024  Digichem.

Code distributed under the [`digichem/data/tachyon`](digichem/data/tachyon) directory is Copyright (c) 1994-2013 John E. Stone, and is licensed separately under the BSD-3-Clause license, see [`digichem/data/tachyon/LICENSE`](digichem/data/tachyon/LICENSE) for full license details. The Tachyon ray-tracer and  John E. Stone are in no-way affiliated with Digichem.