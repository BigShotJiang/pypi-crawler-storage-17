# from .base import Config
from .base import Digichem_options, Auto_type
from .locations import master_config_path, user_config_location, system_config_location
from .parse import Config_file_parser
from .util import get_config