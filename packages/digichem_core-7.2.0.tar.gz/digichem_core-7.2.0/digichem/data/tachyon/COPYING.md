The Tachyon ray-tracer is Copyright (c) 1994-2013 John E. Stone.

It is distributed under the BSD-3-Clause license, see [LICENSE](LICENSE)

See https://github.com/thesketh/Tachyon for more information.
