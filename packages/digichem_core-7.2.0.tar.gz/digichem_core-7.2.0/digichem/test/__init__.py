"""Unit tests for digichem"""

from pathlib import Path

import digichem.log
digichem.log.set_logging_level("DEBUG")