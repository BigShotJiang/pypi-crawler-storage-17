from ftl_extract.__version__ import __version__
from ftl_extract.code_extractor import extract_fluent_keys

__all__ = ("__version__", "extract_fluent_keys")
