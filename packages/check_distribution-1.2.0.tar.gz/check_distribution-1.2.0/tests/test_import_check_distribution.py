def test_import_check_distribution():
    from check_distribution import check_distribution
