"""
Constants for timetree_exporter
"""

API_BASEURI = "https://timetreeapp.com/api/v1"
API_USER_AGENT = "web/2.1.0/en"
