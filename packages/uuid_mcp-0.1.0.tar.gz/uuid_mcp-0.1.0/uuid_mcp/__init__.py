"""UUID MCP Tool - A simple MCP server for generating UUIDs."""

__version__ = "0.1.0"

