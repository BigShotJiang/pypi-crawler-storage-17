from .._colored._time import sleep as sleep, timeout as timeout
from .._time import time as time
