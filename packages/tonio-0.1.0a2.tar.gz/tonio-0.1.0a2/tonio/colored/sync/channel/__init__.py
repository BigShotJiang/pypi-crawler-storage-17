from ...._colored._sync import channel as channel, unbounded_channel as unbounded


__all__ = ['channel', 'unbounded']
