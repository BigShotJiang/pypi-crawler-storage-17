from ._time import sleep as sleep, time as time, timeout as timeout
