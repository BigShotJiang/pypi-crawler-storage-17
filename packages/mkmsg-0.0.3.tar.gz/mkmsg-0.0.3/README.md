# msg-sender

Python library to send:
- WhatsApp messages via WhatsApp Web
- Plain text emails
- HTML emails (Gmail)

## Installation
```bash
pip install mkmsg
