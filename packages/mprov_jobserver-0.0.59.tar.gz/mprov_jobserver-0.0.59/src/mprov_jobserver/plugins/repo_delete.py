from .plugin import JobServerPlugin
class repo_delete(JobServerPlugin):
  jobModule='repo-delete'
  pass