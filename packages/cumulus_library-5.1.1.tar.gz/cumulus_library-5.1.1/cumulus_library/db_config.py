# Variables in this file should only be written to by databases.py, and should be
# treated as read only elsewhere (and really only by jinja envrionments)
# TODO: Consider moving to config object passed down from main cli to builders
db_type = None
