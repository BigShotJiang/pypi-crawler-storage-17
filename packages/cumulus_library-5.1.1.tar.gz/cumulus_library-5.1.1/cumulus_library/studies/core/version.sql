CREATE TABLE core__meta_version AS
SELECT 4 AS data_package_version;
