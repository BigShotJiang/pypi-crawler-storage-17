# Examples

## Exploration

![plots ex 1](plots_explo.png)

## Optimisation

![plots ex 2 fvalue](plot_f.png)
![plots ex 2](plot_fit.png)
