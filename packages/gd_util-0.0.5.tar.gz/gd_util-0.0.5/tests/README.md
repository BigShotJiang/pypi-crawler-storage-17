# gd-util

```bash
pip install gd-utils
# or
pip install gd-utils[mesh]

uv sync

uv sync --extra mesh



uv sync --group dev
uv run pytest


git add .
git commit -m "init"
git push origin main

git tag v0.0.4
git push origin v0.0.4



find . -path "./.venv" -prune -o -name "*.py" -exec cat {} + > out.txt
```



