# UEDGE toolbox (UEtools) 
Version: 1.3.2rc1

## Website (beta)
http://software.llnl.gov/UETOOLS/

## Authors
Andreas Holm, Ben Dudson, William H. Meyer, Yichen Fu, Jerome Guterl

## Release 

UEDGE Toolbox is released under an LGPL license.  For more details see the
NOTICE and LICENSE files.

``LLNL-CODE-846751``
