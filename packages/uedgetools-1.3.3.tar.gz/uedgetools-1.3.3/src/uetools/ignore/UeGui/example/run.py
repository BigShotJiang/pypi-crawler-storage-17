import threading
import uetools
import uedge
import rd_d3dHsm_in
import uedge

uedge.bbb.exmain()
import uedge.uedgeplots as up

gui = uetools.UeGui.CmdGui("plots.yaml")
