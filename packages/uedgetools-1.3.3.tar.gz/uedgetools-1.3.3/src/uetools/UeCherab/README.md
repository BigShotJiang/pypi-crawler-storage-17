# UETOOLS - Cherab interface

This is an interface to the [Cherab](https://www.cherab.info/index.html) raytracing
library for forward modelling of diagnostics based on spectroscopic plasma emission.
