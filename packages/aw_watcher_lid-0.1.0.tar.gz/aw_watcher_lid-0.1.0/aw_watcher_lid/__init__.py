"""ActivityWatch watcher for laptop lid events and system suspend/resume."""

__version__ = "0.1.0"
