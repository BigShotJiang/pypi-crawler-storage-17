"""Common functions, tools and objects used throughout Matchbox."""
