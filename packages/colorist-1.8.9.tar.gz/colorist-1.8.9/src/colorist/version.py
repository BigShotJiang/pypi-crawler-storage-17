# Copyright 2022 – present, Jakob Bagterp. BSD 3-Clause license and refer to LICENSE file.

__version_info__ = (1, 8, 9)
__version__ = ".".join(map(str, __version_info__))
