from enum import Enum

class ParameterValueType(Enum):
    STRING = "String"
    BOOLEAN = "Boolean"
    DOUBLE = "Double"
    INTEGER = "Integer"
    OTHER = "Other"

