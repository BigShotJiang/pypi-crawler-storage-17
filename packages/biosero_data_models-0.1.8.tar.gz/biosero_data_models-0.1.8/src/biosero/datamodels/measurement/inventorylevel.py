# from sqlalchemy import Column, Integer, String, Sequence

# class InventoryLevel(Base):
#     __tablename__ = 'inventory_level'
#     Key = Column(Integer, Sequence('key_seq'), primary_key=True)
#     LocationId = Column(String(50))
#     ItemTypeId = Column(String(50))
#     Quantity = Column(Integer)