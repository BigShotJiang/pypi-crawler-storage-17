"""Extensions to the Lightkube package."""
