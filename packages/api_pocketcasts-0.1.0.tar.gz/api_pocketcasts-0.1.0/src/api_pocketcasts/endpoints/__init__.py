# Mark endpoints as a package
