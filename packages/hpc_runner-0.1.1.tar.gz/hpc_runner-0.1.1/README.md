# hpc-tools

A collection of tools aimed at abstracting the intricacies of HPC job schedulers from the user.  Having writen tools like this in every job I've had, I thought it about time to write one to rule them all.  With some help from my mate Claude.
