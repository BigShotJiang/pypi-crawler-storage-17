"""CLI for hpc-tools."""
