# GraphQL Schema & Custom Operations

⚠️ **Hinweis:** Das Automation-Package verwendet einen **manuell implementierten GraphQL Client** mit **generierten Pydantic-Modellen**.

- **Code-Generator:** [`datamodel-code-generator`](https://github.com/koxudaxi/datamodel-code-generator) (NICHT ariadne-codegen)
- **Generiert:** Nur Pydantic-Modelle aus SDL-Schema
- **Manuell:** Client-Logik, Transport, Operations

## Workflow

### 1. Schema aktualisieren

Falls sich das Backend-Schema ändert:
```bash
packages/automation/schema/automation.sdl
```

### 2. Pydantic-Modelle regenerieren

```bash
cd packages/automation
uv run python scripts/generate_models.py
```

Generierte Datei:
- `src/questra_automation/generated/models.py` - Pydantic-Modelle für alle GraphQL Types

### 3. Custom Operations (Optional)

Die Datei `custom_operations.graphql` ist für **zukünftige Erweiterungen** vorgesehen und wird aktuell **nicht verwendet**.

Potenzielle Verwendung:
- Dokumentation häufiger Queries
- Code-Snippets für manuelle Client-Implementierung
- Zukunft: Query-Validierung gegen Schema

### 4. Client verwenden

```python
from questra_automation import QuestraAutomation

client = QuestraAutomation(
    graphql_url="https://api.example.com/graphql",
    auth_client=auth_client
)

# Type-safe API mit generierten Modellen
workspaces = client.queries.get_workspaces(first=10)
# Returns: WorkspacesConnection (Pydantic model)

for workspace in workspaces.nodes:
    print(workspace.name)  # Autocomplete funktioniert!
```
## Architektur

### Manueller Client mit generierten Typen

- **`src/questra_automation/client.py`**: Haupt-Client `QuestraAutomation`
- **`src/questra_automation/operations.py`**: Query/Mutation Operations
- **`src/questra_automation/transport.py`**: GraphQL Transport Layer
- **`src/questra_automation/generated/models.py`**: Pydantic-Modelle (generiert)

### Vorteil dieses Ansatzes

1. **Volle Kontrolle** über Client-API (Methoden-Namen, Parameter, Error-Handling)
2. **Type-Safety** durch generierte Pydantic-Modelle
3. **Synchrone API** (kein async/await erforderlich)
4. **Einfacher** als vollständig generierte Clients

## Code-Generierung Konfiguration

Die Modell-Generierung erfolgt in `scripts/generate_models.py`:

```python
subprocess.run([
    "uv", "run", "datamodel-codegen",
    "--input", "schema/automation.sdl",
    "--input-file-type", "graphql",
    "--output", "src/questra_automation/generated/models.py",
    "--output-model-type", "pydantic_v2.BaseModel",
    "--snake-case-field",
    "--field-constraints",
    "--use-standard-collections",
    "--use-union-operator",
    "--target-python-version", "3.10",
], check=True)
```

### Post-Processing

Das Skript führt automatisch Post-Processing durch:
- Scalar-Typ-Mappings (`DateTime` → `datetime`, `UUID` → `UUID`, etc.)
- Import-Optimierungen
- Ruff formatting & linting

## Migration von ariadne-codegen (Historisch)

**Alt** (bis v0.1.3):
- ariadne-codegen für vollständigen async Client
- Manueller Sync-Wrapper

**Neu** (ab v0.1.4):
- datamodel-code-generator nur für Modelle
- Manueller synchroner Client mit generierten Typen
- Bessere Kontrolle, einfachere Wartung
