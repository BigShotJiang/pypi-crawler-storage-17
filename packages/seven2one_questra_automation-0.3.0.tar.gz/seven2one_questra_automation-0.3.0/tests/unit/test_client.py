"""Unit tests for QuestraAutomation client."""

from __future__ import annotations

from unittest.mock import MagicMock, patch
from uuid import UUID

import pytest
from seven2one.questra.automation import (
    AutomationBuildStatusViewData,
    AutomationExecutionStatusViewData,
    ExecutionInitiator,
    QuestraAutomation,
    RepositoryAuthenticationMethod,
    RepositoryAuthenticationMethodViewData,
)


@pytest.mark.unit
class TestClientInitialization:
    """Tests for client initialization."""

    def test_init_with_authenticated_client(self, mock_auth_client):
        """Test client initialization with authenticated auth client."""
        client = QuestraAutomation(
            graphql_url="https://automation.example.com/graphql",
            auth_client=mock_auth_client,
        )

        assert client.graphql_url == "https://automation.example.com/graphql"
        assert client.is_authenticated()
        mock_auth_client.is_authenticated.assert_called()

    def test_init_with_unauthenticated_client(self, mock_auth_client):
        """Test client initialization fails with unauthenticated auth client."""
        mock_auth_client.is_authenticated.return_value = False

        with pytest.raises(
            ValueError, match="QuestraAuthentication is not authenticated"
        ):
            QuestraAutomation(
                graphql_url="https://automation.example.com/graphql",
                auth_client=mock_auth_client,
            )


@pytest.mark.unit
class TestClientWorkspaces:
    """Tests for workspaces query."""

    def test_get_workspaces(self, mock_auth_client, workspaces_response):
        """Test get workspaces query."""
        with patch(
            "seven2one.questra.automation.transport.GraphQLTransport.execute"
        ) as mock_exec:
            mock_exec.return_value = workspaces_response["data"]

            client = QuestraAutomation(
                graphql_url="https://automation.example.com/graphql",
                auth_client=mock_auth_client,
            )

            result = client.queries.get_workspaces(first=10)

            # Verify response structure
            assert result.nodes is not None
            assert result.total_count == 3
            assert len(result.nodes) == 3

            # Verify first workspace
            ws1 = result.nodes[0]
            assert ws1.name == "dev-workspace"
            assert ws1.repository_name == "main-repo"
            assert ws1.build_status == AutomationBuildStatusViewData.SUCCEEDED
            assert len(ws1.build_errors) == 0

            # Verify second workspace (running)
            ws2 = result.nodes[1]
            assert ws2.name == "staging-workspace"
            assert ws2.build_status == AutomationBuildStatusViewData.RUNNING
            assert ws2.build_finished_at is None

            # Verify third workspace (failed with errors)
            ws3 = result.nodes[2]
            assert ws3.name == "failed-workspace"
            assert ws3.build_status == AutomationBuildStatusViewData.FAILED
            assert len(ws3.build_errors) == 1
            assert ws3.build_errors[0].code == "BUILD_ERROR_001"


@pytest.mark.unit
class TestClientRepositories:
    """Tests for repositories query."""

    def test_get_repositories(self, mock_auth_client, repositories_response):
        """Test get repositories query."""
        with patch(
            "seven2one.questra.automation.transport.GraphQLTransport.execute"
        ) as mock_exec:
            mock_exec.return_value = repositories_response["data"]

            client = QuestraAutomation(
                graphql_url="https://automation.example.com/graphql",
                auth_client=mock_auth_client,
            )

            result = client.queries.get_repositories(first=10)

            assert result.nodes is not None
            assert result.total_count == 2
            assert len(result.nodes) == 2

            # First repository (username/password)
            repo1 = result.nodes[0]
            assert repo1.name == "main-repo"
            assert repo1.url == "https://github.com/example/main-repo.git"
            assert (
                repo1.authentication_method
                == RepositoryAuthenticationMethodViewData.USERNAME_PASSWORD
            )
            assert repo1.username == "deploy-user"
            assert repo1.ssh_public_key is None

            # Second repository (SSH key)
            repo2 = result.nodes[1]
            assert repo2.name == "test-repo"
            assert (
                repo2.authentication_method
                == RepositoryAuthenticationMethodViewData.SSH_KEY
            )
            assert repo2.username is None
            assert repo2.ssh_public_key is not None


@pytest.mark.unit
class TestClientAutomations:
    """Tests for automations query."""

    def test_get_automations(self, mock_auth_client, automations_response):
        """Test get automations query."""
        with patch(
            "seven2one.questra.automation.transport.GraphQLTransport.execute"
        ) as mock_exec:
            mock_exec.return_value = automations_response["data"]

            client = QuestraAutomation(
                graphql_url="https://automation.example.com/graphql",
                auth_client=mock_auth_client,
            )

            result = client.queries.get_automations(first=10)

            assert result.nodes is not None
            assert result.total_count == 2
            assert len(result.nodes) == 2

            # First automation (with arguments)
            auto1 = result.nodes[0]
            assert auto1.workspace_name == "dev-workspace"
            assert auto1.path == "scripts/daily_sync.py"
            assert auto1.allow_parallel_execution is False
            assert len(auto1.argument_definitions) == 3

            # Check argument definitions
            arg1 = auto1.argument_definitions[0]
            assert arg1.name == "source"
            assert arg1.mandatory is True

            # Second automation (without arguments)
            auto2 = result.nodes[1]
            assert auto2.path == "scripts/cleanup.py"
            assert auto2.allow_parallel_execution is True
            assert len(auto2.argument_definitions) == 0


@pytest.mark.unit
class TestClientExecutions:
    """Tests for executions query."""

    def test_get_executions(self, mock_auth_client, executions_response):
        """Test get executions query."""
        with patch(
            "seven2one.questra.automation.transport.GraphQLTransport.execute"
        ) as mock_exec:
            mock_exec.return_value = executions_response["data"]

            client = QuestraAutomation(
                graphql_url="https://automation.example.com/graphql",
                auth_client=mock_auth_client,
            )

            result = client.queries.get_executions(first=10)

            assert result.nodes is not None
            assert result.total_count == 3
            assert len(result.nodes) == 3

            # First execution (succeeded, manual)
            exec1 = result.nodes[0]
            assert isinstance(exec1.id, UUID)
            assert str(exec1.id) == "12345678-1234-1234-1234-123456789012"
            assert exec1.workspace_name == "dev-workspace"
            assert exec1.automation_path == "scripts/daily_sync.py"
            assert exec1.status == AutomationExecutionStatusViewData.SUCCEEDED
            assert exec1.finished_at is not None

            # Second execution (running)
            exec2 = result.nodes[1]
            assert exec2.status == AutomationExecutionStatusViewData.RUNNING
            assert exec2.finished_at is None

            # Third execution (failed)
            exec3 = result.nodes[2]
            assert exec3.status == AutomationExecutionStatusViewData.FAILED
            assert exec3.output is not None


@pytest.mark.unit
class TestClientSchedules:
    """Tests for schedules query."""

    def test_get_schedules(self, mock_auth_client, schedules_response):
        """Test get schedules query."""
        with patch(
            "seven2one.questra.automation.transport.GraphQLTransport.execute"
        ) as mock_exec:
            mock_exec.return_value = schedules_response["data"]

            client = QuestraAutomation(
                graphql_url="https://automation.example.com/graphql",
                auth_client=mock_auth_client,
            )

            result = client.queries.get_schedules(first=10)

            assert result.nodes is not None
            assert result.total_count == 2
            assert len(result.nodes) == 2

            # First schedule (active)
            sched1 = result.nodes[0]
            assert sched1.automation_path == "scripts/daily_sync.py"
            assert sched1.name == "daily-sync-schedule"
            assert sched1.cron == "0 2 * * *"
            assert sched1.active is True
            assert len(sched1.argument_instances) == 2

            # Second schedule (inactive)
            sched2 = result.nodes[1]
            assert sched2.name == "weekly-cleanup"
            assert sched2.active is False


@pytest.mark.unit
class TestClientErrorCodes:
    """Tests for error codes query."""

    def test_get_error_codes(self, mock_auth_client, error_codes_response):
        """Test get error codes query."""
        with patch(
            "seven2one.questra.automation.transport.GraphQLTransport.execute"
        ) as mock_exec:
            mock_exec.return_value = error_codes_response["data"]

            client = QuestraAutomation(
                graphql_url="https://automation.example.com/graphql",
                auth_client=mock_auth_client,
            )

            result = client.queries.get_error_codes(first=10)

            assert result.nodes is not None
            assert result.total_count == 10
            assert len(result.nodes) == 10

            # First error code
            err1 = result.nodes[0]
            assert err1.code == "AUTOMATION_ARGUMENT_DUPLICATE"
            assert err1.message_template is not None
            assert "Duplicate argument" in err1.message_template
            assert "ArgumentName" in err1.parameters


@pytest.mark.unit
class TestClientServiceInfo:
    """Tests for service info query."""

    def test_get_service_info(self, mock_auth_client, service_info_response):
        """Test get service info query."""
        with patch(
            "seven2one.questra.automation.transport.GraphQLTransport.execute"
        ) as mock_exec:
            mock_exec.return_value = service_info_response["data"]

            client = QuestraAutomation(
                graphql_url="https://automation.example.com/graphql",
                auth_client=mock_auth_client,
            )

            result = client.queries.get_service_info()

            assert result.name == "Questra Automation Service"
            assert result.version == "1.2.3"
            assert result.informational_version is not None
            assert "1.2.3+build." in result.informational_version


@pytest.mark.unit
class TestClientMutations:
    """Tests for mutations."""

    def test_execute_automation(self, mock_auth_client, execute_success_response):
        """Test execute automation mutation."""
        with patch(
            "seven2one.questra.automation.transport.GraphQLTransport.execute"
        ) as mock_exec:
            mock_exec.return_value = execute_success_response["data"]

            client = QuestraAutomation(
                graphql_url="https://automation.example.com/graphql",
                auth_client=mock_auth_client,
            )

            result = client.mutations.execute_automation(
                workspace_name="dev-workspace",
                automation_path="scripts/daily_sync.py",
                initiator_type=ExecutionInitiator.MANUAL,
                arguments=[{"name": "source", "value": "system-a"}],
            )

            assert result.id is not None
            assert isinstance(result.id, UUID)
            assert str(result.id) == "12345678-1234-1234-1234-123456789012"

    def test_create_workspace(
        self, mock_auth_client, create_workspace_success_response
    ):
        """Test create workspace mutation."""
        with patch(
            "seven2one.questra.automation.transport.GraphQLTransport.execute"
        ) as mock_exec:
            mock_exec.return_value = create_workspace_success_response["data"]

            client = QuestraAutomation(
                graphql_url="https://automation.example.com/graphql",
                auth_client=mock_auth_client,
            )

            result = client.mutations.create_workspace(
                repository_name="main-repo",
                name="new-workspace",
                branch_name="main",
                commit="abc123",
            )

            assert result.name == "new-workspace"


@pytest.mark.unit
class TestClientRawQuery:
    """Tests for raw query execution."""

    def test_execute_raw(self, mock_auth_client):
        """Test execute raw GraphQL query."""
        with patch(
            "seven2one.questra.automation.transport.GraphQLTransport.execute"
        ) as mock_exec:
            mock_exec.return_value = {
                "automationServiceInfo": {
                    "name": "Test Service",
                    "version": "1.0.0",
                    "informationalVersion": "1.0.0+test",
                }
            }

            client = QuestraAutomation(
                graphql_url="https://automation.example.com/graphql",
                auth_client=mock_auth_client,
            )

            result = client.execute_raw(
                """
                query {
                    automationServiceInfo {
                        name
                        version
                        informationalVersion
                    }
                }
                """
            )

            assert result["automationServiceInfo"]["name"] == "Test Service"
            mock_exec.assert_called()
