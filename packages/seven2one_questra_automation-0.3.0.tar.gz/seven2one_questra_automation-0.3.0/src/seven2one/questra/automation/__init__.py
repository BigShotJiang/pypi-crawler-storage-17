"""
Questra Automation - Python Client for Automation GraphQL API.

Provides a type-safe interface to the Questra Automation service with automatic
OAuth2 token management through QuestraAuthentication.

Example:
    ```python
    from seven2one.questra.authentication import QuestraAuthentication
    from seven2one.questra.automation import QuestraAutomation, ExecutionInitiator

    # Create QuestraAuthentication
    auth = QuestraAuthentication(
        url="https://authentik.dev.example.com",
        username="ServiceUser",
        password="secret_password",
        oidc_discovery_paths=["/application/o/automation"],
    )

    # Initialize QuestraAutomation
    automation = QuestraAutomation(
        graphql_url="https://automation.dev.example.com/graphql",
        auth_client=auth,
    )

    # Query workspaces
    workspaces = automation.queries.get_workspaces(first=10)
    for workspace in workspaces.nodes:
        print(f"Workspace: {workspace.name}")

    # Execute to automation
    result = automation.mutations.execute_automation(
        workspace_name="my-workspace",
        automation_path="scripts/example.py",
        initiator_type=ExecutionInitiator.MANUAL,
        arguments=[{"name": "param1", "value": "value1"}],
    )
    print(f"Execution ID: {result.id}")
    ```
"""

# Main client
from .client import QuestraAutomation

# Exceptions
from .exceptions import QuestraAutomationError, QuestraAutomationGraphQLError

# Re-export commonly used types from generated models
from .generated.models import (
    AutomationBuildStatusViewData,
    AutomationExecutionDomainStatusViewData,
    AutomationExecutionStatusViewData,
    AutomationInitiatorTypeViewData,
    ExecutionInitiator,
    RepositoryAuthenticationMethod,
    RepositoryAuthenticationMethodViewData,
)

__version__ = "0.1.4"

__all__ = [
    # Main client
    "QuestraAutomation",
    # Exceptions
    "QuestraAutomationError",
    "QuestraAutomationGraphQLError",
    # Enums
    "ExecutionInitiator",
    "AutomationBuildStatusViewData",
    "AutomationExecutionDomainStatusViewData",
    "AutomationExecutionStatusViewData",
    "AutomationInitiatorTypeViewData",
    "RepositoryAuthenticationMethod",
    "RepositoryAuthenticationMethodViewData",
]
