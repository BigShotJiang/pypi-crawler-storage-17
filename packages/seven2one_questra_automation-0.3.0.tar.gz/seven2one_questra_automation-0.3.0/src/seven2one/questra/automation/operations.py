"""GraphQL Operations for Questra Automation."""

from __future__ import annotations

import logging
from collections.abc import Callable
from datetime import datetime
from typing import Any

from .generated.models import (
    AutomationsConnection,
    CreateRepositoryPayload,
    CreateSchedulePayload,
    CreateWorkspacePayload,
    DeleteRepositoryPayload,
    DeleteSchedulePayload,
    DeleteWorkspacePayload,
    ErrorCodesConnection,
    ExecutePayload,
    ExecutionInitiator,
    ExecutionsConnection,
    RenewRepositorySshKeyPayload,
    RepositoriesConnection,
    RepositoryAuthenticationMethod,
    ScheduledExecutionsConnection,
    SchedulesConnection,
    ServiceInfo,
    SynchronizeWorkspacePayload,
    UpdateRepositoryPayload,
    UpdateSchedulePayload,
    UpdateWorkspacePayload,
    WorkspacesConnection,
)

logger = logging.getLogger(__name__)


class QueryOperations:
    """Query operations for Automation GraphQL API."""

    def __init__(self, execute_func: Callable[..., dict[str, Any]]):
        """
        Initialize query operations.

        Args:
            execute_func: Function to execute GraphQL queries
        """
        self._execute = execute_func

    def get_automations(
        self,
        first: int | None = None,
        after: str | None = None,
        last: int | None = None,
        before: str | None = None,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
    ) -> AutomationsConnection:
        """
        Retrieve a paginated, filterable, and sortable list of automations.

        Args:
            first: Returns the first n elements from the list
            after: Returns the elements in the list that come after the specified cursor
            last: Returns the last n elements from the list
            before: Returns the elements in the list that come before the specified cursor
            where: Filter conditions
            order: Sort order

        Returns:
            AutomationsConnection with automations
        """
        logger.debug(
            "Getting automations: first=%s, after=%s, last=%s, before=%s",
            first,
            after,
            last,
            before,
        )

        query = """
            query GetAutomations(
                $first: Int
                $after: String
                $last: Int
                $before: String
                $where: AutomationViewFilterInput
                $order: [AutomationViewSortInput!]
            ) {
                automations(
                    first: $first
                    after: $after
                    last: $last
                    before: $before
                    where: $where
                    order: $order
                ) {
                    pageInfo {
                        hasNextPage
                        hasPreviousPage
                        startCursor
                        endCursor
                    }
                    edges {
                        cursor
                        node {
                            workspaceName
                            path
                            description
                            environment
                            allowParallelExecution
                            argumentDefinitions {
                                name
                                description
                                mandatory
                            }
                        }
                    }
                    totalCount
                }
            }
        """

        variables = {
            "first": first,
            "after": after,
            "last": last,
            "before": before,
            "where": where,
            "order": order,
        }

        result = self._execute(query, variables)
        return AutomationsConnection.model_validate(result["automations"])

    def get_executions(
        self,
        first: int | None = None,
        after: str | None = None,
        last: int | None = None,
        before: str | None = None,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
    ) -> ExecutionsConnection:
        """
        Retrieve a paginated, filterable, and sortable list of automation executions.

        Args:
            first: Returns the first n elements from the list
            after: Returns the elements in the list that come after the specified cursor
            last: Returns the last n elements from the list
            before: Returns the elements in the list that come before the specified cursor
            where: Filter conditions
            order: Sort order

        Returns:
            ExecutionsConnection with executions
        """
        logger.debug(
            "Getting executions: first=%s, after=%s, last=%s, before=%s",
            first,
            after,
            last,
            before,
        )

        query = """
            query GetExecutions(
                $first: Int
                $after: String
                $last: Int
                $before: String
                $where: AutomationExecutionViewFilterInput
                $order: [AutomationExecutionViewSortInput!]
            ) {
                executions(
                    first: $first
                    after: $after
                    last: $last
                    before: $before
                    where: $where
                    order: $order
                ) {
                    pageInfo {
                        hasNextPage
                        hasPreviousPage
                        startCursor
                        endCursor
                    }
                    edges {
                        cursor
                        node {
                            id
                            branch
                            commit
                            workspaceName
                            repositoryName
                            repositoryUrl
                            automationPath
                            environment
                            initiatorType
                            initiatorReference
                            argumentInstances {
                                name
                                value
                            }
                            status
                            output
                            domainStatus
                            domainStatusMessage
                            createdAt
                            startedAt
                            finishedAt
                            duration
                        }
                    }
                    totalCount
                }
            }
        """

        variables = {
            "first": first,
            "after": after,
            "last": last,
            "before": before,
            "where": where,
            "order": order,
        }

        result = self._execute(query, variables)
        return ExecutionsConnection.model_validate(result["executions"])

    def get_error_codes(
        self,
        first: int | None = None,
        after: str | None = None,
        last: int | None = None,
        before: str | None = None,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
    ) -> ErrorCodesConnection:
        """
        Retrieve all available error codes in the automation system.

        Args:
            first: Returns the first n elements from the list
            after: Returns the elements in the list that come after the specified cursor
            last: Returns the last n elements from the list
            before: Returns the elements in the list that come before the specified cursor
            where: Filter conditions
            order: Sort order

        Returns:
            ErrorCodesConnection with error codes
        """
        logger.debug(
            "Getting error codes: first=%s, after=%s, last=%s, before=%s",
            first,
            after,
            last,
            before,
        )

        query = """
            query GetErrorCodes(
                $first: Int
                $after: String
                $last: Int
                $before: String
                $where: ErrorCodeViewFilterInput
                $order: [ErrorCodeViewSortInput!]
            ) {
                errorCodes(
                    first: $first
                    after: $after
                    last: $last
                    before: $before
                    where: $where
                    order: $order
                ) {
                    pageInfo {
                        hasNextPage
                        hasPreviousPage
                        startCursor
                        endCursor
                    }
                    edges {
                        cursor
                        node {
                            code
                            messageTemplate
                            parameters
                        }
                    }
                    totalCount
                }
            }
        """

        variables = {
            "first": first,
            "after": after,
            "last": last,
            "before": before,
            "where": where,
            "order": order,
        }

        result = self._execute(query, variables)
        return ErrorCodesConnection.model_validate(result["errorCodes"])

    def get_repositories(
        self,
        first: int | None = None,
        after: str | None = None,
        last: int | None = None,
        before: str | None = None,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
    ) -> RepositoriesConnection:
        """
        Retrieve a paginated, filterable, and sortable list of repositories.

        Args:
            first: Returns the first n elements from the list
            after: Returns the elements in the list that come after the specified cursor
            last: Returns the last n elements from the list
            before: Returns the elements in the list that come before the specified cursor
            where: Filter conditions
            order: Sort order

        Returns:
            RepositoriesConnection with repositories
        """
        logger.debug(
            "Getting repositories: first=%s, after=%s, last=%s, before=%s",
            first,
            after,
            last,
            before,
        )

        query = """
            query GetRepositories(
                $first: Int
                $after: String
                $last: Int
                $before: String
                $where: RepositoryViewFilterInput
                $order: [RepositoryViewSortInput!]
            ) {
                repositories(
                    first: $first
                    after: $after
                    last: $last
                    before: $before
                    where: $where
                    order: $order
                ) {
                    pageInfo {
                        hasNextPage
                        hasPreviousPage
                        startCursor
                        endCursor
                    }
                    edges {
                        cursor
                        node {
                            name
                            url
                            createdAt
                            changedAt
                            authenticationMethod
                            username
                            sshPublicKey
                        }
                    }
                    totalCount
                }
            }
        """

        variables = {
            "first": first,
            "after": after,
            "last": last,
            "before": before,
            "where": where,
            "order": order,
        }

        result = self._execute(query, variables)
        return RepositoriesConnection.model_validate(result["repositories"])

    def get_schedules(
        self,
        first: int | None = None,
        after: str | None = None,
        last: int | None = None,
        before: str | None = None,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
    ) -> SchedulesConnection:
        """
        Retrieve a paginated, filterable, and sortable list of schedules.

        Args:
            first: Returns the first n elements from the list
            after: Returns the elements in the list that come after the specified cursor
            last: Returns the last n elements from the list
            before: Returns the elements in the list that come before the specified cursor
            where: Filter conditions
            order: Sort order

        Returns:
            SchedulesConnection with schedules
        """
        logger.debug(
            "Getting schedules: first=%s, after=%s, last=%s, before=%s",
            first,
            after,
            last,
            before,
        )

        query = """
            query GetSchedules(
                $first: Int
                $after: String
                $last: Int
                $before: String
                $where: ScheduleViewFilterInput
                $order: [ScheduleViewSortInput!]
            ) {
                schedules(
                    first: $first
                    after: $after
                    last: $last
                    before: $before
                    where: $where
                    order: $order
                ) {
                    pageInfo {
                        hasNextPage
                        hasPreviousPage
                        startCursor
                        endCursor
                    }
                    edges {
                        cursor
                        node {
                            automationPath
                            name
                            description
                            cron
                            timezone
                            active
                            argumentInstances {
                                name
                                value
                            }
                            version
                        }
                    }
                    totalCount
                }
            }
        """

        variables = {
            "first": first,
            "after": after,
            "last": last,
            "before": before,
            "where": where,
            "order": order,
        }

        result = self._execute(query, variables)
        return SchedulesConnection.model_validate(result["schedules"])

    def get_scheduled_executions(
        self,
        from_time: datetime | None = None,
        to_time: datetime | None = None,
        first: int | None = None,
        after: str | None = None,
        last: int | None = None,
        before: str | None = None,
    ) -> ScheduledExecutionsConnection:
        """
        Retrieve a paginated list of scheduled executions within a specified time range.

        Args:
            from_time: Start time for scheduled executions (defaults to current time if not specified)
            to_time: End time for scheduled executions (optional)
            first: Returns the first n elements from the list
            after: Returns the elements in the list that come after the specified cursor
            last: Returns the last n elements from the list
            before: Returns the elements in the list that come before the specified cursor

        Returns:
            ScheduledExecutionsConnection with scheduled executions
        """
        logger.debug(
            "Getting scheduled executions: from=%s, to=%s, first=%s",
            from_time,
            to_time,
            first,
        )

        query = """
            query GetScheduledExecutions(
                $from: DateTime
                $to: DateTime
                $first: Int
                $after: String
                $last: Int
                $before: String
            ) {
                scheduledExecutions(
                    from: $from
                    to: $to
                    first: $first
                    after: $after
                    last: $last
                    before: $before
                ) {
                    pageInfo {
                        hasNextPage
                        hasPreviousPage
                        startCursor
                        endCursor
                    }
                    edges {
                        cursor
                        node {
                            name
                            description
                            cron
                            timezone
                            automationPath
                            fireTime
                            argumentInstances {
                                name
                                value
                            }
                        }
                    }
                }
            }
        """

        variables = {
            "from": from_time.isoformat() if from_time else None,
            "to": to_time.isoformat() if to_time else None,
            "first": first,
            "after": after,
            "last": last,
            "before": before,
        }

        result = self._execute(query, variables)
        return ScheduledExecutionsConnection.model_validate(
            result["scheduledExecutions"]
        )

    def get_workspaces(
        self,
        first: int | None = None,
        after: str | None = None,
        last: int | None = None,
        before: str | None = None,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
    ) -> WorkspacesConnection:
        """
        Retrieve a paginated, filterable, and sortable list of workspaces.

        Args:
            first: Returns the first n elements from the list
            after: Returns the elements in the list that come after the specified cursor
            last: Returns the last n elements from the list
            before: Returns the elements in the list that come before the specified cursor
            where: Filter conditions
            order: Sort order

        Returns:
            WorkspacesConnection with workspaces
        """
        logger.debug(
            "Getting workspaces: first=%s, after=%s, last=%s, before=%s",
            first,
            after,
            last,
            before,
        )

        query = """
            query GetWorkspaces(
                $first: Int
                $after: String
                $last: Int
                $before: String
                $where: WorkspaceViewFilterInput
                $order: [WorkspaceViewSortInput!]
            ) {
                workspaces(
                    first: $first
                    after: $after
                    last: $last
                    before: $before
                    where: $where
                    order: $order
                ) {
                    pageInfo {
                        hasNextPage
                        hasPreviousPage
                        startCursor
                        endCursor
                    }
                    edges {
                        cursor
                        node {
                            name
                            repositoryName
                            buildStatus
                            buildErrors {
                                code
                                messageTemplate
                                data {
                                    key
                                    value
                                }
                            }
                            buildBranch
                            buildCommit
                            buildStartedAt
                            buildFinishedAt
                            buildDuration
                            activeBranch
                            activeCommit
                            createdAt
                            changedAt
                        }
                    }
                    totalCount
                }
            }
        """

        variables = {
            "first": first,
            "after": after,
            "last": last,
            "before": before,
            "where": where,
            "order": order,
        }

        result = self._execute(query, variables)
        return WorkspacesConnection.model_validate(result["workspaces"])

    def get_service_info(self) -> ServiceInfo:
        """
        Retrieve information about the automation service.

        Returns:
            ServiceInfo with service details
        """
        logger.debug("Getting service info")

        query = """
            query GetServiceInfo {
                automationServiceInfo {
                    name
                    version
                    informationalVersion
                }
            }
        """

        result = self._execute(query)
        return ServiceInfo.model_validate(result["automationServiceInfo"])


class MutationOperations:
    """Mutation operations for Automation GraphQL API."""

    def __init__(self, execute_func: Callable[..., dict[str, Any]]):
        """
        Initialize mutation operations.

        Args:
            execute_func: Function to execute GraphQL mutations
        """
        self._execute = execute_func

    def execute_automation(
        self,
        workspace_name: str,
        automation_path: str,
        initiator_type: ExecutionInitiator,
        arguments: list[dict[str, str]] | None = None,
        initiator_reference: str | None = None,
    ) -> ExecutePayload:
        """
        Execute to automation in a specified workspace with the provided arguments.

        Args:
            workspace_name: Name of the workspace containing the automation
            automation_path: Path to the automation script
            initiator_type: Type of initiator (Manual, Script, or Schedule)
            arguments: Arguments to pass to the automation
            initiator_reference: Optional reference to the initiator

        Returns:
            ExecutePayload with execution ID
        """
        logger.info(
            "Executing automation: workspace=%s, path=%s, initiator=%s",
            workspace_name,
            automation_path,
            initiator_type,
        )

        mutation = """
            mutation ExecuteAutomation($input: ExecuteInput!) {
                execute(input: $input) {
                    id
                }
            }
        """

        variables = {
            "input": {
                "workspaceName": workspace_name,
                "automationPath": automation_path,
                "initiatorType": initiator_type.value,
                "arguments": arguments or [],
                "initiatorReference": initiator_reference,
            }
        }

        result = self._execute(mutation, variables)
        return ExecutePayload.model_validate(result["execute"])

    def create_repository(
        self,
        name: str,
        url: str,
        credentials_method: RepositoryAuthenticationMethod,
        username: str | None = None,
        password: str | None = None,
    ) -> CreateRepositoryPayload:
        """
        Create a new repository with the specified name and remote configuration.

        Args:
            name: Repository name
            url: URL of the remote repository
            credentials_method: Authentication method (UsernamePassword or SshKey)
            username: Username for authentication (optional)
            password: Password or token for authentication (optional)

        Returns:
            CreateRepositoryPayload with repository name
        """
        logger.info("Creating repository: name=%s, url=%s", name, url)

        mutation = """
            mutation CreateRepository($input: CreateRepositoryInput!) {
                createRepository(input: $input) {
                    name
                }
            }
        """

        variables = {
            "input": {
                "name": name,
                "remote": {
                    "url": url,
                    "credentials": {
                        "method": credentials_method.value,
                        "username": username,
                        "password": password,
                    },
                },
            }
        }

        result = self._execute(mutation, variables)
        return CreateRepositoryPayload.model_validate(result["createRepository"])

    def update_repository(
        self,
        name: str,
        new_name: str | None = None,
        url: str | None = None,
        credentials_method: RepositoryAuthenticationMethod | None = None,
        username: str | None = None,
        password: str | None = None,
    ) -> UpdateRepositoryPayload:
        """
        Update to existing repository's name or remote configuration.

        Args:
            name: Current repository name
            new_name: New repository name (optional)
            url: New URL of the remote repository (optional)
            credentials_method: New authentication method (optional)
            username: New username for authentication (optional)
            password: New password or token for authentication (optional)

        Returns:
            UpdateRepositoryPayload with repository name
        """
        logger.info("Updating repository: name=%s, new_name=%s", name, new_name)

        mutation = """
            mutation UpdateRepository($input: UpdateRepositoryInput!) {
                updateRepository(input: $input) {
                    name
                }
            }
        """

        remote = None
        if url or credentials_method:
            remote = {
                "url": url,
                "credentials": {
                    "method": credentials_method.value if credentials_method else None,
                    "username": username,
                    "password": password,
                },
            }

        variables = {
            "input": {
                "name": name,
                "newName": new_name,
                "remote": remote,
            }
        }

        result = self._execute(mutation, variables)
        return UpdateRepositoryPayload.model_validate(result["updateRepository"])

    def delete_repository(self, name: str) -> DeleteRepositoryPayload:
        """
        Delete a repository by name.

        Args:
            name: Repository name

        Returns:
            DeleteRepositoryPayload with repository name
        """
        logger.info("Deleting repository: name=%s", name)

        mutation = """
            mutation DeleteRepository($input: DeleteRepositoryInput!) {
                deleteRepository(input: $input) {
                    name
                }
            }
        """

        variables = {"input": {"name": name}}

        result = self._execute(mutation, variables)
        return DeleteRepositoryPayload.model_validate(result["deleteRepository"])

    def renew_repository_ssh_key(self, name: str) -> RenewRepositorySshKeyPayload:
        """
        Renew the SSH key for a repository.

        Args:
            name: Repository name

        Returns:
            RenewRepositorySshKeyPayload with repository name
        """
        logger.info("Renewing repository SSH key: name=%s", name)

        mutation = """
            mutation RenewRepositorySshKey($input: RenewRepositorySshKeyInput!) {
                renewRepositorySshKey(input: $input) {
                    name
                }
            }
        """

        variables = {"input": {"name": name}}

        result = self._execute(mutation, variables)
        return RenewRepositorySshKeyPayload.model_validate(
            result["renewRepositorySshKey"]
        )

    def create_schedule(
        self,
        workspace_name: str,
        automation_path: str,
        name: str,
        description: str,
        cron: str,
        timezone: str,
        active: bool,
        arguments: list[dict[str, str]] | None = None,
    ) -> CreateSchedulePayload:
        """
        Create a new schedule for automated execution of to automation.

        Args:
            workspace_name: Name of the workspace containing the automation
            automation_path: Path to the automation script
            name: Name of the schedule
            description: Description of the schedule
            cron: Cron expression defining the schedule
            timezone: Timezone for the schedule
            active: Whether the schedule is active
            arguments: Arguments to pass to the automation

        Returns:
            CreateSchedulePayload with schedule details
        """
        logger.info(
            "Creating schedule: workspace=%s, path=%s, name=%s",
            workspace_name,
            automation_path,
            name,
        )

        mutation = """
            mutation CreateSchedule($input: CreateScheduleInput!) {
                createSchedule(input: $input) {
                    name
                    workspaceName
                    automationPath
                }
            }
        """

        variables = {
            "input": {
                "workspaceName": workspace_name,
                "automationPath": automation_path,
                "name": name,
                "description": description,
                "cron": cron,
                "timezone": timezone,
                "active": active,
                "arguments": arguments or [],
            }
        }

        result = self._execute(mutation, variables)
        return CreateSchedulePayload.model_validate(result["createSchedule"])

    def update_schedule(
        self,
        workspace_name: str,
        automation_path: str,
        name: str,
        new_name: str | None = None,
        description: str | None = None,
        cron: str | None = None,
        timezone: str | None = None,
        active: bool | None = None,
        arguments: list[dict[str, str]] | None = None,
    ) -> UpdateSchedulePayload:
        """
        Update to existing schedule's configuration.

        Args:
            workspace_name: Name of the workspace containing the automation
            automation_path: Path to the automation script
            name: Current name of the schedule
            new_name: New name of the schedule (optional)
            description: New description of the schedule (optional)
            cron: New cron expression (optional)
            timezone: New timezone (optional)
            active: New active state (optional)
            arguments: New arguments (optional)

        Returns:
            UpdateSchedulePayload with schedule details
        """
        logger.info(
            "Updating schedule: workspace=%s, path=%s, name=%s",
            workspace_name,
            automation_path,
            name,
        )

        mutation = """
            mutation UpdateSchedule($input: UpdateScheduleInput!) {
                updateSchedule(input: $input) {
                    name
                    workspaceName
                    automationPath
                }
            }
        """

        variables = {
            "input": {
                "workspaceName": workspace_name,
                "automationPath": automation_path,
                "name": name,
                "newName": new_name,
                "description": description,
                "cron": cron,
                "timezone": timezone,
                "active": active,
                "arguments": arguments,
            }
        }

        result = self._execute(mutation, variables)
        return UpdateSchedulePayload.model_validate(result["updateSchedule"])

    def delete_schedule(
        self, workspace_name: str, automation_path: str, name: str
    ) -> DeleteSchedulePayload:
        """
        Delete a schedule.

        Args:
            workspace_name: Name of the workspace containing the automation
            automation_path: Path to the automation script
            name: Name of the schedule

        Returns:
            DeleteSchedulePayload with schedule details
        """
        logger.info(
            "Deleting schedule: workspace=%s, path=%s, name=%s",
            workspace_name,
            automation_path,
            name,
        )

        mutation = """
            mutation DeleteSchedule($input: DeleteScheduleInput!) {
                deleteSchedule(input: $input) {
                    name
                    workspaceName
                    automationPath
                }
            }
        """

        variables = {
            "input": {
                "workspaceName": workspace_name,
                "automationPath": automation_path,
                "name": name,
            }
        }

        result = self._execute(mutation, variables)
        return DeleteSchedulePayload.model_validate(result["deleteSchedule"])

    def create_workspace(
        self, repository_name: str, name: str, branch_name: str, commit: str
    ) -> CreateWorkspacePayload:
        """
        Create a new workspace in a repository with the specified branch.

        Args:
            repository_name: Repository name
            name: Workspace name
            branch_name: Name of the branch
            commit: Commit hash to checkout

        Returns:
            CreateWorkspacePayload with workspace name
        """
        logger.info(
            "Creating workspace: repo=%s, name=%s, branch=%s",
            repository_name,
            name,
            branch_name,
        )

        mutation = """
            mutation CreateWorkspace($input: CreateWorkspaceInput!) {
                createWorkspace(input: $input) {
                    name
                }
            }
        """

        variables = {
            "input": {
                "repositoryName": repository_name,
                "name": name,
                "branch": {"name": branch_name, "commit": commit},
            }
        }

        result = self._execute(mutation, variables)
        return CreateWorkspacePayload.model_validate(result["createWorkspace"])

    def update_workspace(
        self,
        name: str,
        new_name: str | None = None,
        branch_name: str | None = None,
        commit: str | None = None,
    ) -> UpdateWorkspacePayload:
        """
        Update to existing workspace's name or branch configuration.

        Args:
            name: Current workspace name
            new_name: New workspace name (optional)
            branch_name: New branch name (optional)
            commit: New commit hash to checkout (optional)

        Returns:
            UpdateWorkspacePayload with workspace name
        """
        logger.info("Updating workspace: name=%s, new_name=%s", name, new_name)

        mutation = """
            mutation UpdateWorkspace($input: UpdateWorkspaceInput!) {
                updateWorkspace(input: $input) {
                    name
                }
            }
        """

        branch = None
        if branch_name and commit:
            branch = {"name": branch_name, "commit": commit}

        variables = {
            "input": {
                "name": name,
                "newName": new_name,
                "branch": branch,
            }
        }

        result = self._execute(mutation, variables)
        return UpdateWorkspacePayload.model_validate(result["updateWorkspace"])

    def delete_workspace(self, name: str) -> DeleteWorkspacePayload:
        """
        Delete a workspace by name.

        Args:
            name: Workspace name

        Returns:
            DeleteWorkspacePayload with workspace name
        """
        logger.info("Deleting workspace: name=%s", name)

        mutation = """
            mutation DeleteWorkspace($input: DeleteWorkspaceInput!) {
                deleteWorkspace(input: $input) {
                    name
                }
            }
        """

        variables = {"input": {"name": name}}

        result = self._execute(mutation, variables)
        return DeleteWorkspacePayload.model_validate(result["deleteWorkspace"])

    def synchronize_workspace(self, name: str) -> SynchronizeWorkspacePayload:
        """
        Synchronize a workspace with its remote repository.

        Args:
            name: Workspace name

        Returns:
            SynchronizeWorkspacePayload with workspace name
        """
        logger.info("Synchronizing workspace: name=%s", name)

        mutation = """
            mutation SynchronizeWorkspace($input: SynchronizeWorkspaceInput!) {
                synchronizeWorkspace(input: $input) {
                    name
                }
            }
        """

        variables = {"input": {"name": name}}

        result = self._execute(mutation, variables)
        return SynchronizeWorkspacePayload.model_validate(
            result["synchronizeWorkspace"]
        )
