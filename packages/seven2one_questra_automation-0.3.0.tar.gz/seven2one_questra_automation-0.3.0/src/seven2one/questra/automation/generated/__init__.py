"""Generated GraphQL types and models."""
