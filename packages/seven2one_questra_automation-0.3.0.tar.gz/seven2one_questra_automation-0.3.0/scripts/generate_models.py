"""Generate Pydantic models from automation.sdl with custom scalar mappings."""

from __future__ import annotations

from pathlib import Path

from questra_codegen import CodeGenerator
from questra_codegen.processors import SDLProcessor


def generate_models() -> None:
    """Generate Pydantic models using datamodel-code-generator."""
    package_dir = Path(__file__).parent.parent
    schema_file = package_dir / "schema" / "automation.sdl"
    output_file = (
        package_dir
        / "src"
        / "seven2one"
        / "questra"
        / "automation"
        / "generated"
        / "models.py"
    )

    # Configure SDL processor with automation-specific scalar mappings
    processor = SDLProcessor(
        scalar_mappings={
            "DateTime": "DateTime = datetime",
            "TimeSpan": "TimeSpan = timedelta",
            "Long": "Long = int",
            # Remove UUID TypeAlias (imported from uuid)
            "UUID": "",
            # Keep IntBetweenZeroAndOneThousand as TypeAliasType with int base
            "IntBetweenZeroAndOneThousand": 'IntBetweenZeroAndOneThousand = TypeAliasType("IntBetweenZeroAndOneThousand", int)',
        },
        extra_imports=[
            "from datetime import datetime, timedelta",
            "from typing import Literal",
            "from uuid import UUID",
        ],
    )

    # Create generator
    generator = CodeGenerator(
        output_file=output_file,
        post_processor=processor,
        run_formatter=True,
        run_linter=True,
    )

    # Generate from GraphQL SDL
    generator.generate_from_graphql(schema_file)


if __name__ == "__main__":
    generate_models()
