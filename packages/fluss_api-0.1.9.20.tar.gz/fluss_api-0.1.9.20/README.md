Building the file:

```text
python -m pip install --upgrade build
```

then run: 
```text
python -m build
```


