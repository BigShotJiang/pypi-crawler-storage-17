from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any
from collections.abc import Mapping

import numpy as np
import pandas as pd

from dsr_data_tools.enums import (
    RecommendationType,
    EncodingStrategy,
    MissingValueStrategy,
    OutlierStrategy,
    ImbalanceStrategy,
    InteractionType,
)


@dataclass
class Recommendation(ABC):
    """
    Abstract base class for dataset preparation recommendations.

    Each recommendation represents a suggested action to improve data quality
    or prepare the dataset for machine learning.
    """

    type: RecommendationType
    column_name: str
    description: str

    @abstractmethod
    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply this recommendation to a dataset.

        Args:
            df: Input DataFrame

        Returns:
            Modified DataFrame with recommendation applied
        """
        pass

    @abstractmethod
    def info(self) -> None:
        """Display formatted information about this recommendation."""
        pass


@dataclass
class NonInformativeRecommendation(Recommendation):
    """Recommendation to remove non-informative columns."""

    reason: str
    """Explanation for why column is non-informative (e.g., 'High cardinality', 'Unique count == row count')"""

    def __post_init__(self):
        """Set type to NON_INFORMATIVE."""
        self.type = RecommendationType.NON_INFORMATIVE

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Remove the non-informative column.

        Args:
            df: Input DataFrame

        Returns:
            DataFrame with column removed
        """
        return df.drop(columns=[self.column_name])

    def info(self) -> None:
        """Display recommendation information."""
        print(f"  Recommendation: NON_INFORMATIVE")
        print(f"    Reason: {self.reason}")
        print(f"    Action: Drop column '{self.column_name}'")


@dataclass
class MissingValuesRecommendation(Recommendation):
    """Recommendation for handling missing values with editable strategy.

    The strategy and fill_value are editable before applying the recommendation.
    """

    missing_count: int
    """Number of missing values in the column"""

    missing_percentage: float
    """Percentage of missing values (0-100)"""

    strategy: MissingValueStrategy
    """Strategy for handling missing values (EDITABLE before apply)"""

    fill_value: str | int | float | None = None
    """Fill value for FILL_VALUE strategy. Only used when strategy=FILL_VALUE (EDITABLE)"""

    def __post_init__(self):
        """Set type to MISSING_VALUES."""
        self.type = RecommendationType.MISSING_VALUES

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply missing value strategy to the column.

        Args:
            df: Input DataFrame

        Returns:
            DataFrame with missing value strategy applied
        """
        result = df.copy()

        if self.strategy == MissingValueStrategy.DROP_ROWS:
            result = result.dropna(subset=[self.column_name])

        elif self.strategy == MissingValueStrategy.DROP_COLUMN:
            result = result.drop(columns=[self.column_name])

        elif self.strategy == MissingValueStrategy.IMPUTE:
            # Default to median for numeric, mode for categorical
            if pd.api.types.is_numeric_dtype(result[self.column_name]):
                fill_value = result[self.column_name].median()
                result[self.column_name] = result[self.column_name].fillna(
                    fill_value)
            else:
                mode_value = result[self.column_name].mode()
                if len(mode_value) > 0:
                    result[self.column_name] = result[self.column_name].fillna(
                        mode_value[0])
                else:
                    result[self.column_name] = result[self.column_name].fillna(
                        'Unknown')

        elif self.strategy == MissingValueStrategy.FILL_VALUE:
            if self.fill_value is not None:
                result[self.column_name] = result[self.column_name].fillna(
                    self.fill_value)

        # MissingValueStrategy.LEAVE_AS_NA: Do nothing

        return result

    def info(self) -> None:
        """Display recommendation information including editable parameters."""
        print(f"  Recommendation: {self.type.name}")
        print(
            f"    Missing count: {self.missing_count} ({self.missing_percentage:.1f}%)")
        print(f"    Strategy: {self.strategy.value} (EDITABLE)")
        if self.strategy == MissingValueStrategy.FILL_VALUE:
            print(f"    Fill value: {self.fill_value} (EDITABLE)")
        print(f"    Action: {self._get_action_description()}")

    def _get_action_description(self) -> str:
        """Get a human-readable description of the action."""
        if self.strategy == MissingValueStrategy.DROP_ROWS:
            return f"Remove {self.missing_count} rows with missing values"
        elif self.strategy == MissingValueStrategy.DROP_COLUMN:
            return f"Drop column '{self.column_name}' entirely"
        elif self.strategy == MissingValueStrategy.IMPUTE:
            return f"Impute missing values using mean/median/mode"
        elif self.strategy == MissingValueStrategy.FILL_VALUE:
            return f"Fill missing values with: {self.fill_value}"
        elif self.strategy == MissingValueStrategy.LEAVE_AS_NA:
            return f"Leave {self.missing_count} missing values as-is"
        return ""


@dataclass
class EncodingRecommendation(Recommendation):
    """Recommendation for encoding categorical columns with editable strategy.

    The encoder_type is editable before applying the recommendation.
    """

    encoder_type: EncodingStrategy
    """Encoding strategy (EDITABLE before apply)"""

    unique_values: int
    """Number of unique values in the column"""

    def __post_init__(self):
        """Set type to ENCODING."""
        self.type = RecommendationType.ENCODING

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply encoding strategy to the column.

        Args:
            df: Input DataFrame

        Returns:
            DataFrame with column encoded or converted to categorical
        """
        result = df.copy()

        if self.encoder_type == EncodingStrategy.CATEGORICAL:
            # Convert to categorical dtype (memory optimization)
            result[self.column_name] = result[self.column_name].astype(
                'category')

        elif self.encoder_type == EncodingStrategy.ONEHOT:
            # One-hot encode - creates binary columns for each category
            result = pd.get_dummies(
                result, columns=[self.column_name], drop_first=False)

            # Normalize one-hot encoded column names to lowercase snake_case
            # (e.g., "region_East" -> "region_east")
            onehot_cols = [col for col in result.columns if col.startswith(
                self.column_name + '_')]
            rename_map = {col: col.lower() for col in onehot_cols}
            result = result.rename(columns=rename_map)

        elif self.encoder_type == EncodingStrategy.LABEL:
            # Label encode - assigns integer to each category
            from sklearn.preprocessing import LabelEncoder
            le = LabelEncoder()
            # Handle potential NaN values
            mask = result[self.column_name].notna()
            encoded_values = le.fit_transform(
                result.loc[mask, self.column_name].astype(str))
            # Create new series with encoded values and NaN for masked rows
            new_values = pd.Series(
                index=result.index, dtype='Int64')  # nullable int
            new_values[mask] = encoded_values
            result[self.column_name] = new_values

        elif self.encoder_type == EncodingStrategy.ORDINAL:
            # Ordinal encode - preserves order
            from sklearn.preprocessing import OrdinalEncoder
            oe = OrdinalEncoder(
                handle_unknown='use_encoded_value', unknown_value=-1)
            result[self.column_name] = oe.fit_transform(
                result[[self.column_name]])

        return result

    def info(self) -> None:
        """Display recommendation information including editable parameters."""
        print(f"  Recommendation: {self.type.name}")
        print(f"    Unique values: {self.unique_values}")
        print(f"    Encoder type: {self.encoder_type.value} (EDITABLE)")
        print(f"    Action: {self._get_action_description()}")

    def _get_action_description(self) -> str:
        """Get a human-readable description of the encoding action."""
        if self.encoder_type == EncodingStrategy.CATEGORICAL:
            return f"Convert '{self.column_name}' to categorical dtype (memory optimization)"
        elif self.encoder_type == EncodingStrategy.ONEHOT:
            return f"Apply one-hot encoding to '{self.column_name}' ({self.unique_values} categories)"
        elif self.encoder_type == EncodingStrategy.LABEL:
            return f"Apply label encoding to '{self.column_name}'"
        elif self.encoder_type == EncodingStrategy.ORDINAL:
            return f"Apply ordinal encoding to '{self.column_name}'"
        return ""


@dataclass
class ClassImbalanceRecommendation(Recommendation):
    """Recommendation for handling class imbalance in target variable."""

    majority_percentage: float
    """Percentage of majority class"""

    strategy: ImbalanceStrategy
    """Recommended strategy for handling imbalance"""

    def __post_init__(self):
        """Set type to CLASS_IMBALANCE."""
        self.type = RecommendationType.CLASS_IMBALANCE

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply class imbalance strategy.

        Note: This is a simplified implementation. SMOTE and upsampling/downsampling
        should be applied during cross-validation to prevent data leakage.

        Args:
            df: Input DataFrame

        Returns:
            DataFrame (or recommendation for model configuration)
        """
        # This recommendation is typically handled at model training time,
        # not during data preparation. Return df unchanged as a placeholder.
        return df

    def info(self) -> None:
        """Display recommendation information."""
        print(f"  Recommendation: CLASS_IMBALANCE")
        print(f"    Majority class: {self.majority_percentage:.2f}%")
        print(f"    Strategy: {self.strategy.value}")
        print(f"    Action: Apply {self.strategy.value} during model training")


@dataclass
class OutlierDetectionRecommendation(Recommendation):
    """Recommendation for handling outliers."""

    strategy: OutlierStrategy
    """Recommended strategy for handling outliers"""

    max_value: float
    """Maximum value in the column"""

    mean_value: float
    """Mean value of the column"""

    def __post_init__(self):
        """Set type to OUTLIER_DETECTION."""
        self.type = RecommendationType.OUTLIER_DETECTION

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply outlier handling strategy to the column.

        Args:
            df: Input DataFrame

        Returns:
            DataFrame with outlier strategy applied
        """
        result = df.copy()

        if self.strategy == OutlierStrategy.SCALING:
            from sklearn.preprocessing import StandardScaler
            scaler = StandardScaler()
            # Handle NaN values
            mask = result[self.column_name].notna()
            scaled_values = scaler.fit_transform(
                result.loc[mask, [self.column_name]])
            # Convert to float64 to avoid dtype incompatibility
            result[self.column_name] = result[self.column_name].astype(
                'float64')
            result.loc[mask, self.column_name] = scaled_values.flatten()

        elif self.strategy == OutlierStrategy.ROBUST_SCALER:
            from sklearn.preprocessing import RobustScaler
            scaler = RobustScaler()
            # Handle NaN values
            mask = result[self.column_name].notna()
            scaled_values = scaler.fit_transform(
                result.loc[mask, [self.column_name]])
            # Convert to float64 to avoid dtype incompatibility
            result[self.column_name] = result[self.column_name].astype(
                'float64')
            result.loc[mask, self.column_name] = scaled_values.flatten()

        elif self.strategy == OutlierStrategy.REMOVE:
            # Remove rows where value exceeds 1.5 * IQR beyond quartiles
            Q1 = result[self.column_name].quantile(0.25)
            Q3 = result[self.column_name].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            result = result[(result[self.column_name] >= lower_bound) &
                            (result[self.column_name] <= upper_bound)].reset_index(drop=True)

        return result

    def info(self) -> None:
        """Display recommendation information."""
        print(f"  Recommendation: OUTLIER_DETECTION")
        print(
            f"    Max value: {self.max_value:.2f}, Mean: {self.mean_value:.2f}")
        print(f"    Strategy: {self.strategy.value}")
        print(
            f"    Action: Apply {self.strategy.value} to handle outliers in '{self.column_name}'")


@dataclass
class BooleanClassificationRecommendation(Recommendation):
    """Recommendation to treat numeric column as boolean."""

    values: list[Any]
    """The two unique values in the column"""

    def __post_init__(self):
        """Set type to BOOLEAN_CLASSIFICATION."""
        self.type = RecommendationType.BOOLEAN_CLASSIFICATION

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Convert numeric column to boolean type.

        Args:
            df: Input DataFrame

        Returns:
            DataFrame with column converted to boolean
        """
        result = df.copy()
        result[self.column_name] = result[self.column_name].astype(bool)
        return result

    def info(self) -> None:
        """Display recommendation information."""
        print(f"  Recommendation: BOOLEAN_CLASSIFICATION")
        print(f"    Values: {self.values}")
        print(f"    Action: Convert '{self.column_name}' to boolean type")


@dataclass
class BinningRecommendation(Recommendation):
    """Recommendation to bin numeric column into categorical ranges."""

    bins: list[float]
    """Bin edges for pd.cut()"""

    labels: list[str]
    """Labels for each bin"""

    def __post_init__(self):
        """Set type to BINNING."""
        self.type = RecommendationType.BINNING

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Bin the numeric column into categorical ranges.

        Args:
            df: Input DataFrame

        Returns:
            DataFrame with column binned and one-hot encoded
        """
        result = df.copy()
        try:
            result[self.column_name] = pd.cut(
                result[self.column_name],
                bins=self.bins,
                labels=self.labels,
                right=True,
                include_lowest=True
            )
        except Exception as e:
            print(f"Warning: Could not bin column '{self.column_name}': {e}")
            return result

        # One-hot encode the binned column
        result = pd.get_dummies(
            result, columns=[self.column_name], drop_first=False)
        return result

    def info(self) -> None:
        """Display recommendation information."""
        print(f"  Recommendation: BINNING")
        print(f"    Bins: {self.bins}")
        print(f"    Labels: {self.labels}")
        print(
            f"    Action: Bin '{self.column_name}' into {len(self.labels)} categories and encode")


@dataclass
class IntegerConversionRecommendation(Recommendation):
    """Recommendation to convert float64 column with only integer values to int64."""

    integer_count: int
    """Number of integer values in the column"""

    def __post_init__(self):
        """Set type to INT64_CONVERSION."""
        self.type = RecommendationType.INT64_CONVERSION

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Convert the float64 column to int64.

        Args:
            df: Input DataFrame

        Returns:
            DataFrame with column converted to int64
        """
        result = df.copy()
        try:
            # Handle NaN values by converting to Int64 (nullable integer type)
            if result[self.column_name].isna().any():
                result[self.column_name] = result[self.column_name].astype(
                    'Int64')
            else:
                result[self.column_name] = result[self.column_name].astype(
                    'int64')
        except Exception as e:
            print(
                f"Warning: Could not convert column '{self.column_name}' to int64: {e}")
            return result
        return result

    def info(self) -> None:
        """Display recommendation information."""
        print(f"  Recommendation: INT64_CONVERSION")
        print(f"    Integer values: {self.integer_count}")
        print(
            f"    Action: Convert '{self.column_name}' from float64 to int64")


@dataclass
class DecimalPrecisionRecommendation(Recommendation):
    """Recommendation to optimize decimal precision in float columns.

    This recommendation identifies float columns where decimal precision can be
    reduced. The max_decimal_places parameter is editable, allowing the user to
    adjust precision before applying the recommendation. If max_decimal_places is 0
    and all values are integers after rounding, the column can be converted to int64.
    """

    max_decimal_places: int
    """Maximum number of decimal places to retain (user-editable)"""

    min_value: float
    """Minimum value in the column (for reference)"""

    max_value: float
    """Maximum value in the column (for reference)"""

    convert_to_int: bool = False
    """Whether to convert to int64 if max_decimal_places is 0 and all values are integers"""

    def __post_init__(self):
        """Set type to DECIMAL_PRECISION_OPTIMIZATION."""
        self.type = RecommendationType.DECIMAL_PRECISION_OPTIMIZATION

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply decimal precision optimization to the column.

        Args:
            df: Input DataFrame

        Returns:
            DataFrame with column rounded to specified precision, optionally converted to int64
        """
        result = df.copy()
        try:
            if self.max_decimal_places >= 0:
                # Round to specified decimal places
                result[self.column_name] = result[self.column_name].round(
                    self.max_decimal_places)

                # If max_decimal_places is 0 and convert_to_int is True, convert to int64
                if self.max_decimal_places == 0 and self.convert_to_int:
                    if result[self.column_name].isna().any():
                        result[self.column_name] = result[self.column_name].astype(
                            'Int64')
                    else:
                        result[self.column_name] = result[self.column_name].astype(
                            'int64')
        except Exception as e:
            print(
                f"Warning: Could not optimize decimal precision for column '{self.column_name}': {e}")
            return result
        return result

    def info(self) -> None:
        """Display recommendation information."""
        print(f"  Recommendation: DECIMAL_PRECISION_OPTIMIZATION")
        print(f"    Column: '{self.column_name}'")
        print(f"    Range: {self.min_value} to {self.max_value}")
        print(f"    Max decimal places: {self.max_decimal_places} (EDITABLE)")
        if self.max_decimal_places == 0:
            print(f"    Convert to int64: {self.convert_to_int}")
        print(
            f"    Action: Round '{self.column_name}' to {self.max_decimal_places} decimal places")
        if self.max_decimal_places == 0 and self.convert_to_int:
            print(f"           Then convert to int64")


def create_recommendation(
    rec_type: RecommendationType,
    column_name: str,
    description: str,
    **kwargs
) -> Recommendation:
    """
    Factory function to create appropriate Recommendation subclass.

    Args:
        rec_type: Type of recommendation to create
        column_name: Name of the column this recommendation applies to
        description: Human-readable description of the recommendation
        **kwargs: Additional type-specific keyword arguments

    Returns:
        Recommendation instance of the appropriate subclass

    Raises:
        ValueError: If rec_type is not recognized
    """
    recommendation_classes = {
        RecommendationType.NON_INFORMATIVE: NonInformativeRecommendation,
        RecommendationType.MISSING_VALUES: MissingValuesRecommendation,
        RecommendationType.ENCODING: EncodingRecommendation,
        RecommendationType.CLASS_IMBALANCE: ClassImbalanceRecommendation,
        RecommendationType.OUTLIER_DETECTION: OutlierDetectionRecommendation,
        RecommendationType.BOOLEAN_CLASSIFICATION: BooleanClassificationRecommendation,
        RecommendationType.BINNING: BinningRecommendation,
    }

    if rec_type not in recommendation_classes:
        raise ValueError(f"Unknown recommendation type: {rec_type}")

    recommendation_class = recommendation_classes[rec_type]
    return recommendation_class(
        type=rec_type,
        column_name=column_name,
        description=description,
        **kwargs
    )


@dataclass
class ValueReplacementRecommendation(Recommendation):
    """Recommendation for replacing non-numeric placeholder values with NaN.

    Detects columns with non-numeric string placeholders (like 'tbd', 'N/A')
    that should be numeric. The values to replace and replacement value are
    editable before applying.
    """

    non_numeric_values: list[str]
    """List of non-numeric placeholder values found in column (e.g., ['tbd'])"""

    non_numeric_count: int
    """Total count of non-numeric values"""

    replacement_value: float | str = np.nan
    """Value to replace non-numeric placeholders with (EDITABLE, default: np.nan)"""

    def __post_init__(self):
        """Set type to VALUE_REPLACEMENT."""
        self.type = RecommendationType.VALUE_REPLACEMENT

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Replace non-numeric placeholder values with specified replacement value.

        Args:
            df: Input DataFrame

        Returns:
            DataFrame with non-numeric values replaced
        """
        result = df.copy()

        # Replace each non-numeric value with the replacement value
        for val in self.non_numeric_values:
            result[self.column_name] = result[self.column_name].replace(
                val, self.replacement_value)

        return result

    def info(self) -> None:
        """Display recommendation information including editable parameters."""
        print(f"  Recommendation: {self.type.name}")
        print(f"    Non-numeric values: {self.non_numeric_values}")
        print(f"    Count: {self.non_numeric_count}")
        print(f"    Replacement value: {self.replacement_value} (EDITABLE)")
        print(f"    Action: {self._get_action_description()}")

    def _get_action_description(self) -> str:
        """Get a human-readable description of the replacement action."""
        values_str = "', '".join(self.non_numeric_values)
        if pd.isna(self.replacement_value):
            return f"Replace '{values_str}' with NaN in '{self.column_name}'"
        else:
            return f"Replace '{values_str}' with '{self.replacement_value}' in '{self.column_name}'"


def apply_recommendations(
    df: pd.DataFrame,
    recommendations: Mapping[str, Mapping[str, Recommendation]
                             | Recommendation] | None,
    exclude_types: list[RecommendationType] | None = None,
    target_column: str | None = None
) -> pd.DataFrame:
    """
    Apply all recommendations from a dictionary to a DataFrame.

    Handles both flat dictionaries (column_name -> Recommendation) and nested
    dictionaries (column_name -> recommendation_type -> Recommendation).
    If recommendations is None, returns the DataFrame unchanged.

    Applies each recommendation sequentially, with each subsequent 
    recommendation working on the output of the previous one.

    Args:
        df: Input DataFrame. Should be the ORIGINAL, untransformed DataFrame.
        recommendations: Mapping of column names to Recommendation objects.
            Can be flat (str -> Recommendation) or nested (str -> Mapping -> Recommendation),
            or None to skip applying recommendations.
        exclude_types: Optional list of RecommendationType values to exclude from being applied.
            For example, [RecommendationType.BINNING] would skip binning recommendations.
        target_column: Optional name of the target column. If provided, no recommendations
            will be applied to this column to preserve its discrete class values for
            classification tasks.

    Returns:
        DataFrame with all recommendations applied (except excluded types)

    Warning:
        Only apply this function to the original, untransformed DataFrame. Applying
        recommendations to an already-transformed DataFrame can cause errors or unexpected
        behavior, as some transformations (e.g., dropping columns, encoding) cannot be
        safely applied multiple times.

        For multiple analysis phases with different recommendation sets, always apply
        recommendations to the original DataFrame:

        Example:
            >>> # CORRECT: Each phase starts from the original DataFrame
            >>> df_baseline = ddt.apply_recommendations(df_original, recs,
            ...     exclude_types=[ddt.RecommendationType.BINNING], target_column='Exited')
            >>> df_with_binning = ddt.apply_recommendations(df_original, recs, target_column='Exited')
            >>>
            >>> # INCORRECT: Applying recommendations to already-transformed data
            >>> df_v1 = ddt.apply_recommendations(df_original, recs, target_column='Exited')
            >>> df_v2 = ddt.apply_recommendations(df_v1, recs, target_column='Exited')  # Don't do this!

    Example:
        >>> # Apply all recommendations except binning, preserving target column
        >>> result_df = apply_recommendations(df, recs, exclude_types=[RecommendationType.BINNING],
        ...     target_column='target')
    """
    result_df = df.copy()

    # Handle None case
    if recommendations is None:
        return result_df

    # Default to empty list if not provided
    if exclude_types is None:
        exclude_types = []

    for column_name, value in recommendations.items():
        # Skip target column to preserve discrete class values
        if target_column is not None and column_name == target_column:
            continue

        # Handle nested dictionary structure
        if isinstance(value, dict):
            for rec_type, recommendation in value.items():
                # Skip excluded recommendation types
                if recommendation.type in exclude_types:
                    continue
                try:
                    result_df = recommendation.apply(result_df)
                except Exception as e:
                    print(f"Warning: Failed to apply {recommendation.type.value} "
                          f"recommendation for '{column_name}': {str(e)}")
        # Handle flat dictionary structure
        else:
            recommendation = value
            # Skip excluded recommendation types
            if recommendation.type in exclude_types:
                continue
            try:
                result_df = recommendation.apply(result_df)
            except Exception as e:
                print(f"Warning: Failed to apply {recommendation.type.value} "
                      f"recommendation for '{column_name}': {str(e)}")
    return result_df


@dataclass
class FeatureInteractionRecommendation(Recommendation):
    """Recommendation to create a feature interaction between two columns.

    Suggests creating derived features by combining two columns based on
    statistical patterns (e.g., binary × continuous, continuous / continuous).
    """

    column_name_2: str
    """Second column name for the interaction"""

    interaction_type: InteractionType
    """Type of interaction (STATUS_IMPACT, RESOURCE_DENSITY, PRODUCT_UTILIZATION)"""

    operation: str
    """Operation to perform: '*' (multiply), '/' (divide)"""

    rationale: str
    """Explanation for why this interaction is recommended"""

    derived_name: str = ""
    """Name for the derived feature (EDITABLE)"""

    type: RecommendationType = field(
        default=RecommendationType.FEATURE_INTERACTION, init=False)
    """Recommendation type (automatically set to FEATURE_INTERACTION)"""

    def __post_init__(self):
        """Auto-generate derived_name if not set."""
        if not self.derived_name:
            if self.operation == "*":
                self.derived_name = f"{self.column_name}_{self.column_name_2}"
            else:
                self.derived_name = f"{self.column_name}_vs_{self.column_name_2}"

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create the interaction feature in the dataset.

        Args:
            df: Input DataFrame

        Returns:
            DataFrame with new interaction column added
        """
        if self.column_name not in df.columns or self.column_name_2 not in df.columns:
            raise ValueError(
                f"Column '{self.column_name}' or '{self.column_name_2}' not found in DataFrame"
            )

        df = df.copy()
        if self.operation == "*":
            df[self.derived_name] = df[self.column_name] * df[self.column_name_2]
        elif self.operation == "/":
            # Avoid division by zero
            df[self.derived_name] = df[self.column_name] / df[self.column_name_2].replace(
                0, np.nan
            )
        else:
            raise ValueError(f"Unknown operation: {self.operation}")

        return df

    def info(self) -> None:
        """Display recommendation information."""
        operation_name = (
            "multiply"
            if self.operation == "*"
            else "divide"
            if self.operation == "/"
            else self.operation
        )
        print(f"  Recommendation: FEATURE_INTERACTION")
        print(f"    Type: {self.interaction_type.value}")
        print(
            f"    Operation: {operation_name} ('{self.column_name}' {self.operation} '{self.column_name_2}')")
        print(f"    New Feature: '{self.derived_name}' (EDITABLE)")
        print(f"    Rationale: {self.rationale}")
