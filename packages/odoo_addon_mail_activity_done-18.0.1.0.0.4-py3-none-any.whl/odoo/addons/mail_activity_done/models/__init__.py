from . import mail_activity_type
