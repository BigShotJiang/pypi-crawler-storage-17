- Jordi Ballester \<<jordi.ballester@forgeflow.com>\>
  (www.forgeflow.com)
- Eduardo Magdalena \<<emagdalena@c2i.es>\> (C2i Change 2 improve
  <http://www.c2i.es>)
- Radovan Skolnik \<<radovan@skolnik.info>\> (<https://www.kema.sk>)
- Manuel Regidor \<<manuel.regidor@sygel.es>\> (<https://www.sygel.es>)
- Bernat Puig \<<bernat.puig@forgeflow.com>\> (www.forgeflow.com)
- Stefan Rijnhart \<<stefan@opener.amsterdam>\>
