To use this module, you do not need to do anything.
