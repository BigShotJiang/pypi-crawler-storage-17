"""Image Interlacement Program - A Python CLI tool for image interlacing operations."""

__version__ = "0.5.7"
__author__ = "e. couture"
__description__ = "A simple image interlacement/interleavment program created to aid in creating weave structures for the TC2 loom."
