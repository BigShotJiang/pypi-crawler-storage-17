"""
ToolBoxV2 MCP Server - Test Suite
=================================
Comprehensive unit and E2E tests for all components.
"""
