from .test_main_page import *

in_valid_session_tests = []
valid_session_tests = [contact_page_interactions, installer_interactions]
loot_session_tests = []
