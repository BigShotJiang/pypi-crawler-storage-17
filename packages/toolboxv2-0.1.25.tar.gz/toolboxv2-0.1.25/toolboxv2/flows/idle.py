NAME = "idle"


async def run(_, __):
    await _.a_idle()
