#from .module import version, Name
#from .arXivCrawler import ArXivPDFProcessor
#from .tests import TestTruthSeeker
#from .htmxui import get_main_ui
#from .newui import MOD_NAME

NAME = "TruthSeeker"
