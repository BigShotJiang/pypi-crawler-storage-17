from .wiget_test import get_widget

Name = 'TestWidget'
version = '0.0.1'
