from .tb_adapter import Tools
from .tb_adapter import Tools as DB
from .ui import db_manager_ui

Name = "DB"
Tools = Tools

version = Tools.version
# private = True

