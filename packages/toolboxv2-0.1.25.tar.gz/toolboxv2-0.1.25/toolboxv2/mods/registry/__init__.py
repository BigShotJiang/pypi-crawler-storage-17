from .server import Name

version = "0.0.1"
Name = Name
