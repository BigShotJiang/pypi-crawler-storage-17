# from .module import version, Name, on_start

# version = version
Name = "WhatsAppTb"
