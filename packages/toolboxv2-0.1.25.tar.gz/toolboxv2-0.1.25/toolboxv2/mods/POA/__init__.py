from .module import Name as MOD_NAME
from .module import version as VERSION

version = VERSION
Name = MOD_NAME
