from .kernelcoos import Name as name, VERSION, Tools

Name = name
version = VERSION
tools = Tools
