import toolboxv2
from toolboxv2.utils.toolbox import get_app

BROWSER = 'chrome'  # firefox 'chrome'
