from .board_widget import BoardWidget as Tools
from .module import open_widget
from .StorageUtil import get_names

Name = 'WidgetsProvider'
version = '0.0.1'
