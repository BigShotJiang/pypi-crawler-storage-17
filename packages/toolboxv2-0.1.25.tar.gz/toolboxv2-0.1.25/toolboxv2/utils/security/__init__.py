from .cryp import Code

__all__ = ['Code']
