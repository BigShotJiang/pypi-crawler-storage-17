"""Various utility functions."""

from griptape_nodes.utils.async_utils import call_function

__all__ = ["call_function"]
