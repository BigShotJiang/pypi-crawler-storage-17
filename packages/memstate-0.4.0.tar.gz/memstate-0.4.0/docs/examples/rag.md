# RAG hook demo

```python
--8<-- "examples/rag_hook_demo.py"
```
