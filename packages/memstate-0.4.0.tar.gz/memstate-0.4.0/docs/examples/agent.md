# Pizza agent demo

```python
--8<-- "examples/pizza_agent_demo.py"
```
