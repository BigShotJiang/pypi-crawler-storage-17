# API Reference

Here's the reference or code API, the classes, functions, parameters, attributes, and
all the MemState parts you can use in your applications.
