class WrapperError(Exception):
    pass


