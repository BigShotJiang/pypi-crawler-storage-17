
__packagename__ = "FastOMA"
__version__ = "0.5.1"

import logging
logger = logging.getLogger("FastOMA")
