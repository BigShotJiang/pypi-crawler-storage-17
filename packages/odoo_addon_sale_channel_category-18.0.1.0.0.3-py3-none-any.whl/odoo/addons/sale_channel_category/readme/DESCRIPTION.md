Simple module that adds the posibility to link the product category to a
sale channel.
