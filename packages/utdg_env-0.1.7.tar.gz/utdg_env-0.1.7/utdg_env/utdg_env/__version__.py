"""Version information for UTDG Gym."""

__version__ = "0.1.7"
