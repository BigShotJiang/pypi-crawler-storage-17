## Contexte

## Fonctionnement actuel

## Nouvelle foncionnalité attendue
