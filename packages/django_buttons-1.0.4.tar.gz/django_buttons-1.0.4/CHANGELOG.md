# 0.4.0b4 2017-11-24
+ Include package files

# 0.4.0b2 2017-11-24
+ Fixes buggy template for `name` and `value` support

# 0.4.0b1 2017-11-23
+ Add support for `name` and `value` on (submit) buttons
