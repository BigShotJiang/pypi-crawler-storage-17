buttons.templatetags.buttons\_tags module
=========================================

.. automodule:: buttons.templatetags.buttons_tags
   :members:
   :undoc-members:
   :show-inheritance:
