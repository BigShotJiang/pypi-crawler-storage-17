buttons package
===============

.. automodule:: buttons
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   buttons.templatetags

Submodules
----------

.. toctree::
   :maxdepth: 4

   buttons.apps
   buttons.conf
   buttons.models
