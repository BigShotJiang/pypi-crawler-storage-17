Welcome to django-buttons's documentation!
==========================================


**django-buttons** provides template tags to render some buttons in a django application. It uses bootstrap to display the buttons and fontawesome for icons.



.. toctree::
   :maxdepth: 2
   :caption: Contents:

   buttons

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
