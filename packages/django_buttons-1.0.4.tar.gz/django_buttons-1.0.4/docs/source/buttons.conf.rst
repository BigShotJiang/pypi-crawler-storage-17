buttons.conf module
===================

.. automodule:: buttons.conf
   :members:
   :undoc-members:
   :show-inheritance:
