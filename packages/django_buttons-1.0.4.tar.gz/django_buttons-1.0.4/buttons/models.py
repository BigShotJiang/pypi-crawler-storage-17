"""Models for the :mod:`buttons` application."""
