"""Template tags for the :mod:`buttons` application."""
