"""Simple django application to button templates."""

from buttons.__about__ import __version__

VERSION = __version__
default_app_config = "buttons.apps.ButtonsAppConfig"
