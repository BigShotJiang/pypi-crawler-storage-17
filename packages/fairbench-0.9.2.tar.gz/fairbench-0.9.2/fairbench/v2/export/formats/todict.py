class ToDict:
    def direct_show(self, value):
        return value.to_dict()
