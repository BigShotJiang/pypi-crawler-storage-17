from fairbench.bench.vision.datasets.mnist.biased import BiasedMNIST
from fairbench.bench.vision.datasets.mnist.color import BiasedMNISTColor
from fairbench.bench.vision.datasets.mnist.single import BiasedMNISTSingle
