from fairbench.bench.tabular.adult import adult
from fairbench.bench.tabular.bank import bank
from fairbench.bench.tabular.compas import compas
