from fairbench.bench.text.datasets import simplequestions, LLMDatasetGenerator
from fairbench.bench.text.models import Transformer, Ollama
