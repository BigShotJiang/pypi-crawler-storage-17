from fairbench import v1
from fairbench import v2
from fairbench.v2 import *
