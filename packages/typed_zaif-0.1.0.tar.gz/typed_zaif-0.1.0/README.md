# Typed Zaif

> A fully typed, validated async client for the Zaif API

Use *autocomplete* instead of documentation.

🚧 Under construction.