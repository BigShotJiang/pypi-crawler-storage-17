dict2rel documentation
======================


.. automodule:: dict2rel
    :no-index:


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   package
   examples
   releases
