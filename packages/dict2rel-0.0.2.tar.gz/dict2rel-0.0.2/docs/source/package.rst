Package Reference
==================

.. automodule:: dict2rel
    :members:
    :no-docstring:
