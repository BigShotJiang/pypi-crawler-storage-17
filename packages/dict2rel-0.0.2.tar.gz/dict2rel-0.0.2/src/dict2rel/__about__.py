# SPDX-FileCopyrightText: 2025-present Jacob Morris <blendingjake@gmail.com>
#
# SPDX-License-Identifier: MIT

__author__ = "Jacob Morris"
__email__ = "blendingjake@gmail.com"
__summary__ = "Convert nested JSON into tables and then back again"
__title__ = "dict2rel"
__version__ = "0.0.2"
