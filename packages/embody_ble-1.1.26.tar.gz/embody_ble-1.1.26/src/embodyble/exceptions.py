"""Exceptions specific to this labrary."""


class EmbodyBleError(Exception):
    """Exception used as base exception for package errors."""

    ...
