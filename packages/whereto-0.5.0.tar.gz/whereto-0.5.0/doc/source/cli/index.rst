================================
Command line interface reference
================================

.. autoprogram:: whereto.app:argument_parser
   :prog: whereto
