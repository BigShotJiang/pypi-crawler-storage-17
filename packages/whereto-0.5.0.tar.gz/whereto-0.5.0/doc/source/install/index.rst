============================
 whereto installation guide
============================

The whereto package should be installed via ``pip``:

.. code-block:: console

   $ pip install whereto
