========================================
 whereto: Testing Apache Redirect Rules
========================================

whereto is an app for testing redirect rules like what may appear in a
.htaccess file for Apache. It provides a way to test those rules in CI
jobs.

:Source: https://opendev.org/openstack/whereto
:Bugs: https://bugs.launchpad.net/openstack-doc-tools/

.. toctree::
   :maxdepth: 2

   install/index
   contributor/index
   cli/index
   user/index
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
