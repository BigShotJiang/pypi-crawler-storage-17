=========
 whereto
=========

Test Apache redirect rules.

whereto is an app for testing redirect rules like what may appear in a
.htaccess file for Apache. It provides a way to test those rules in CI
jobs.

* Free software: Apache license
* Documentation: https://docs.openstack.org/whereto/latest/
* Source: http://opendev.org/openstack/whereto
* Bugs: https://bugs.launchpad.net/openstack-doc-tools/
