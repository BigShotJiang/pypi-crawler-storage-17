from django.apps import AppConfig
from django.contrib.admin import site


class DjangoAdminRangeConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_admin_range"
    verbose_name = "Django Admin Range Filters"

    def ready(self):
        original_each_context = site.each_context

        def each_context_with_media(request):
            context = original_each_context(request)
            if not hasattr(context, "media_css"):
                context["media_css"] = []
                context["media_js"] = []

            context["media_css"].append("django_admin_range/css/range_filter.css")
            context["media_js"].append("django_admin_range/js/range_filter.js")

            return context

        site.each_context = each_context_with_media
