#! /usr/bin/env bash

function test_bluer_objects_mlflow_test() {
    local options=$1

    bluer_objects_mlflow_test "$@"
}
