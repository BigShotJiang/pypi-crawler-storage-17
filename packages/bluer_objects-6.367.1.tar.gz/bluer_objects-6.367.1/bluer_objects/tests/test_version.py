from bluer_objects import VERSION


def test_version():
    assert VERSION
