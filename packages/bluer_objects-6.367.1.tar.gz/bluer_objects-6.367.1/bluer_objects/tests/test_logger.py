from bluer_objects.logger import logger


def test_logger():
    logger.info("testing")
