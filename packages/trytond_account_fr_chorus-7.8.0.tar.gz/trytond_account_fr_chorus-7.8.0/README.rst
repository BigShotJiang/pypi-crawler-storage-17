############################
Account French Chorus Module
############################

The *Account French Chorus Module* allows to send invoices through the `Chorus
Pro <https://portail.chorus-pro.gouv.fr/>`_ portal.

.. toctree::
   :maxdepth: 2

   setup
   usage
   design
   releases
