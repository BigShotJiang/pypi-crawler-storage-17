"""Marvel Scheduler - Telescope Observation Scheduling."""


from marvel_schedule_maker.__version__ import __version__
from marvel_schedule_maker.main import main

__all__ = ["main", "__version__"]