from imports import *
from imports.src.abstract_webtools.managers.videoDownloader import *

url = "https://www.facebook.com/share/v/1A5JMu3YiW/"
input(downloadvideo(url).get('id'))

