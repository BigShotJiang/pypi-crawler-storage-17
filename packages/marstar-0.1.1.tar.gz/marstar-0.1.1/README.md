# MarStar

    An ultimate game platform,available for Tic-Tac-Toe game and Murphy,the best number game ever.Use marstar.guide() to view the guide of this game,required NumPy.

Developer:              Marcy  huazii@gmail.com
