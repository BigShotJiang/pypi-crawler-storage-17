"""Shared utilities - Cross-cutting concerns and type definitions."""
