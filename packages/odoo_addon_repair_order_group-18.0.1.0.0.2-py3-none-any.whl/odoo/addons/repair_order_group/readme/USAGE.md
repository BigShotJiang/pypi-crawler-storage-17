Create the first repair order.
Click the "Add Another Repair" button in the header.
A new order will be created with the same partner and same order group.
