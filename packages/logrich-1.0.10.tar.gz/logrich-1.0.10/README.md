# LogRich - Расширенный логгер с Rich форматированием

[![Python](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![Rich](https://img.shields.io/badge/rich-13.0+-green.svg)](https://github.com/Textualize/rich)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

[Screenshot logger](https://disk.yandex.ru/i/JexFefETxnJavA)  
[Screenshot logger2](https://disk.yandex.ru/i/ubvT0kZbfS-Guw)

## ![Screenshot logger](wiki/logrich_screenshot.png?raw=True "Screenshot")

![Screenshot logger too](wiki/logrich_screenshot2.png?raw=True "Screenshot")

**LogRich** - это мощный и гибкий логгер для Python, построенный на основе библиотеки Rich. Он предоставляет красивое цветное форматирование, табличный вывод и динамические методы логирования.

## ✨ Особенности

- 🎨 **Цветной вывод** с поддержкой Rich разметки
- 📊 **Табличное форматирование** с информацией о файле и строке
- 🔧 **Динамические методы** - вызывайте `log.любое_слово()` для создания цветных логов
- ⚙️ **Гибкая конфигурация** через переменные окружения
- 📝 **Поддержка сложных объектов** - красивый вывод dict, list, tuple
- 🎯 **255+ предустановленных уровней** логирования
- 🔍 **Автоматическое определение** места вызова (файл, строка)

## 🚀 Быстрый старт

### Установка

```bash
pip install logrich
```

### Базовое использование

```python
from logrich import log

# Стандартные методы
log.info("Информационное сообщение")
log.error("Ошибка в приложении")
log.success("Операция выполнена успешно")

# Динамические методы
log.api("API запрос выполнен")
log.database("Подключение к БД")
log.custom_level("Любой текст")

# Вывод сложных объектов
data = {"user": "admin", "status": "active"}
log.debug(data, title="Данные пользователя")
```

## 📖 Подробное использование

### Стандартные уровни логирования

```python
from logrich import log

log.trace("Детальная отладочная информация")
log.debug("Отладочная информация")
log.info("Общая информация")
log.success("Успешное выполнение")
log.warning("Предупреждение")
log.error("Ошибка")
log.fatal("Критическая ошибка")
```

### Динамические методы

LogRich автоматически создает методы для любых слов:

```python
# Программные термины
log.api("REST API вызов")
log.sql("Выполнение запроса")
log.cache("Кэш обновлен")
log.auth("Аутентификация пройдена")

# Пользовательские уровни
log.start("Начало процесса")
log.end("Завершение процесса")
log.test("Тестовое сообщение")
```

### Вывод сложных объектов

```python
# Словари и списки
user_data = {
    "id": 123,
    "name": "Иван Иванов",
    "roles": ["admin", "user"]
}
log.info(user_data, title="Информация о пользователе")

# Кортежи
coordinates = (55.7558, 37.6176)
log.debug(coordinates, title="Координаты Москвы")
```

### Дополнительные параметры

```python
# Кастомный заголовок
log.info("Сообщение", title="Мой заголовок")

# Указание файла и строки
log.error("Ошибка", file_name="custom.py", line=42)
```

### Примеры использования

Смотрите полные примеры в [тестах](tests/test_1.py)

## ⚙️ Конфигурация

### Основные настройки

```bash
# Включение/выключение LogRich
LGR_LOGRICH_ON=1  # 1 - включен, 0 - выключен

# Настройки ширины
LGR_LEVEL_MAX_WITH=15        # Максимальная ширина плашки уровня
LGR_LEVEL_MIN_WITH=9         # Минимальная ширина плашки уровня
LGR_CONSOLE_WITH=120         # Общая ширина консоли (по умолчанию COLUMNS)
LGR_LEN_FILE_NAME_SECTION=20 # Ширина секции с именем файла

# Пропорции колонок
LGR_RATIO_FILE_NAME=55       # Доля ширины для имени файла (%)
LGR_RATIO_MESSAGE=100        # Доля ширины для сообщения (%)
LGR_REDUCE_DEVIDER_LEN=25    # Уменьшение длины разделителя
```

### Настройка стилей уровней

```bash
# Стандартные уровни
LOG_LEVEL_INFO_TPL="[reverse blue] INFO   [/]"
LOG_LEVEL_ERROR_TPL="[reverse red] ERROR  [/]"
LOG_LEVEL_SUCCESS_TPL="[reverse green] SUCCESS[/]"
LOG_LEVEL_WARNING_TPL="[reverse yellow] WARN   [/]"
LOG_LEVEL_DEBUG_TPL="[reverse #AB343A] DEBUG  [/]"

# Пользовательские уровни
LOG_LEVEL_START_TPL="[reverse i dark_orange] START  [/]"
LOG_LEVEL_API_TPL="[reverse i color(1)] API    [/]"
LOG_LEVEL_SQL_TPL="[reverse i color(33)] SQL    [/]"

# Отключение конкретного уровня
LOG_LEVEL_DEBUG_TPL=''  # Пустая строка отключает вывод
```

### Совместимость с Loguru

```bash
LOGURU_DIAGNOSE=NO      # Отключение диагностики Loguru
LOGURU_DATETIME_SHOW=1  # Показ времени в Loguru
```

## 🎨 Доступные цвета и стили

LogRich поддерживает все возможности Rich разметки:

```bash
# Цвета
"[red]текст[/]"           # Красный текст
"[blue]текст[/]"          # Синий текст
"[#FF5733]текст[/]"       # HEX цвет
"[color(196)]текст[/]"    # 256-цветная палитра

# Стили
"[bold]жирный[/]"         # Жирный
"[italic]курсив[/]"       # Курсив
"[reverse]инверсия[/]"    # Инверсия цветов
"[underline]подчерк[/]"   # Подчеркивание

# Комбинации
"[reverse bold red] КРИТИЧНО [/]"  # Комбинированный стиль
```

## 📋 Предустановленные уровни

LogRich включает 255+ предустановленных уровней:

### Программные термины

- `api`, `app`, `sql`, `css`, `html`, `json`, `xml`
- `git`, `npm`, `pip`, `docker`, `nginx`
- `auth`, `cache`, `debug`, `error`, `trace`

### Системные термины

- `cpu`, `ram`, `disk`, `net`, `tcp`, `udp`
- `file`, `dir`, `path`, `url`, `port`

### Пользовательские

- `start`, `end`, `test`, `dev`, `prod`
- `success`, `fail`, `warn`, `info`

Полный список методов с автодополнением и подсказками типов доступен в [interface](logrich/app.pyi)

## 🔧 Расширенные возможности

### Создание собственных уровней

```python
# Любое слово автоматически становится методом
log.my_custom_level("Пользовательское сообщение")
log.business_logic("Бизнес-логика выполнена")
log.performance("Время выполнения: 0.5с")
```

### Условное логирование

```python
# Отключение через конфигурацию
if config.DEBUG_MODE:
    log.debug("Отладочная информация")

# Отключение конкретного уровня через переменную окружения
# LOG_LEVEL_VERBOSE_TPL='' - отключит log.verbose()
```

### Интеграция с существующим кодом

```python
# Замена стандартного логгера
import logging
from logrich import log

# Вместо logging.info()
log.info("Сообщение")

# Сохранение совместимости
logging.info = log.info
logging.error = log.error
```

## 🧪 Тестирование

```bash
# Запуск всех тестов
pytest

# Запуск с мониторингом изменений
ptw

# Запуск конкретного теста
pytest tests/test_1.py::test_one -v

# Запуск с покрытием
pytest --cov=logrich
```

## 📦 Зависимости

- **Python** >= 3.8
- **Rich** >= 13.0.0
- **Loguru** (опционально, для совместимости)

## 🤝 Вклад в проект

1. Форкните репозиторий
2. Создайте ветку для новой функции (`git checkout -b feature/amazing-feature`)
3. Зафиксируйте изменения (`git commit -m 'Add amazing feature'`)
4. Отправьте в ветку (`git push origin feature/amazing-feature`)
5. Откройте Pull Request

## 📄 Лицензия

Этот проект лицензирован под MIT License - см. файл [LICENSE](LICENSE) для деталей.

## 🔗 Полезные ссылки

- [Rich Documentation](https://rich.readthedocs.io/)
- [Loguru Documentation](https://loguru.readthedocs.io/)
- [Python Logging HOWTO](https://docs.python.org/3/howto/logging.html)

## 📸 Больше скриншотов

- [Пример 1: Базовое использование](https://disk.yandex.ru/i/JexFefETxnJavA)
- [Пример 2: Сложные объекты](https://disk.yandex.ru/i/ubvT0kZbfS-Guw)

---

**LogRich** - делает логирование красивым и удобным! 🎨✨
