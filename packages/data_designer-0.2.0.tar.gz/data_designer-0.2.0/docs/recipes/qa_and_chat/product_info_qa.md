[Download Code :octicons-download-24:](../../../assets/recipes/qa_and_chat/product_info_qa.py){ .md-button download="product_info_qa.py" }

```python
--8<-- "assets/recipes/qa_and_chat/product_info_qa.py"
```
