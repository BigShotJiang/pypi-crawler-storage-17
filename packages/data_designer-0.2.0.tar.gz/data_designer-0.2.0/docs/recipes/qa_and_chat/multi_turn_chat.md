[Download Code :octicons-download-24:](../../../assets/recipes/qa_and_chat/multi_turn_chat.py){ .md-button download="multi_turn_chat.py" }

```python
--8<-- "assets/recipes/qa_and_chat/multi_turn_chat.py"
```
