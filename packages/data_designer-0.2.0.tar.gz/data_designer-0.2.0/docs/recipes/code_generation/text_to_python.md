[Download Code :octicons-download-24:](../../../assets/recipes/code_generation/text_to_python.py){ .md-button download="text_to_python.py" }

```python
--8<-- "assets/recipes/code_generation/text_to_python.py"
```
