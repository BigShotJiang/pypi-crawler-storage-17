# -*- coding: utf-8 -*-
# author: NhanDD3 <hp.duongducnhan@gmail.com>

from .installer import setup_open_telemetry

__all__ = [
    "setup_open_telemetry",
]
