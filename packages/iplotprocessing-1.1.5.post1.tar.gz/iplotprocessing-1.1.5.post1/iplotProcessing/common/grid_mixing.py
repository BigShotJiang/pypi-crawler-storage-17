# Description: Define grid alignment modes.
# Author: Jaswant Sai Panchumarti

class GridAlignmentMode:
    INTERSECTION = "intersection"
    UNION = "union"
