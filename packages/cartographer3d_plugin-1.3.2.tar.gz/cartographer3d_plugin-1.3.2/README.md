# Cartographer3D Plugin

![PyPI - License](https://img.shields.io/pypi/l/cartographer3d-plugin)
![PyPI - Version](https://img.shields.io/pypi/v/cartographer3d-plugin)
![PyPI - Downloads](https://img.shields.io/pypi/dm/cartographer3d-plugin)
![GitHub known bugs](https://img.shields.io/github/issues-search/Cartographer3D/cartographer3d-plugin?query=is%3Aissue%20is%3Aopen%20type%3ABug&label=known%20bugs)

The official Cartographer3D plugin.

Documentation can be found at [https://docs.cartographer3d.com/](https://docs.cartographer3d.com/)
