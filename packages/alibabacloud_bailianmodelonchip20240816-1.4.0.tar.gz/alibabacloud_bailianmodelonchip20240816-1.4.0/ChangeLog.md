2025-11-26 Version: 1.3.0
- Support API ActiveInteractionEuCreate.
- Support API OmniRealtimeConversationEU.


2025-11-07 Version: 1.2.0
- Support API ModelTypeDetermine.


2025-10-24 Version: 1.1.0
- Support API ActiveInteractionCreate.


2025-06-12 Version: 1.0.2
- Update API DeviceRegister: add request parameters appId.
- Update API DeviceRegister: add response parameters Body.data.appId.
- Update API GetToken: add request parameters appId.
- Update API GetToken: add response parameters Body.data.appId.


2025-05-29 Version: 1.0.1
- Generated python 2024-08-16 for BailianModelOnChip.

2025-05-29 Version: 1.0.0
- Generated python 2024-08-16 for BailianModelOnChip.

