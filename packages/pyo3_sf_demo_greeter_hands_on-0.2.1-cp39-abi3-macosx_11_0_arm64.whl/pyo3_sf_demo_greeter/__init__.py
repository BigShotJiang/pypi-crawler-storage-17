from ._core import greet

__all__ = ["greet"]
