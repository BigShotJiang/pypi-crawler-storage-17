import unittest
import inspect
import files_sdk
from tests.base import TestBase
from files_sdk.models import FileAction
from files_sdk import file_action

class FileActionTest(TestBase):
    pass 
    # Instance Methods

    # Static Methods
if __name__ == '__main__':
    unittest.main()