import unittest
import inspect
import files_sdk
from tests.base import TestBase
from files_sdk.models import Auto
from files_sdk import auto

class AutoTest(TestBase):
    pass 
    # Instance Methods

    # Static Methods
if __name__ == '__main__':
    unittest.main()