from typing import Literal

type PlotType = Literal["plotly", "matplotlib", "seaborn", "ggplot"]
