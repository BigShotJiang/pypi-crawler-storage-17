def main() -> None:
    print("Hello from karl-jiang-mcp-demo!")
