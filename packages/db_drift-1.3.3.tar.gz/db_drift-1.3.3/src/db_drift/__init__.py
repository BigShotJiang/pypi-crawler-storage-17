from db_drift.__main__ import main  # noqa: F401
