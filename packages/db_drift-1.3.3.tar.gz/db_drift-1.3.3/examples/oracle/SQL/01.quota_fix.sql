alter user <your_user> quota unlimited on users; -- Locally I used testadmin as <your_user>
