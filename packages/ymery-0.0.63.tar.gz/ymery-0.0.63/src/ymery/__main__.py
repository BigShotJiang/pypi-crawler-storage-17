"""
Entry point for running ymery as a module: python -m ymery
"""

from ymery.app import main

if __name__ == "__main__":
    main()
