"""Utilities for component_model."""
