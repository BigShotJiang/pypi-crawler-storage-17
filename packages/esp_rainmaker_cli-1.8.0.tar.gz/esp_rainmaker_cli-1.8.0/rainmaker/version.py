#!/usr/bin/env python3
#
# SPDX-FileCopyrightText: 2020-2025 Espressif Systems (Shanghai) CO LTD
#
# SPDX-License-Identifier: Apache-2.0

# This file contains the version information for the ESP RainMaker CLI
VERSION = "1.8.0"
