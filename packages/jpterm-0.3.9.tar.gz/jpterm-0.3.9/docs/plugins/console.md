## Key bindings

The console allows typing code and executing it. When you type code, hiting `Enter` doesn't execute it but instead creates a new line, so that you can continue typing and have a multi-line block of code. To execute the code, just hit `Ctrl-R`.
