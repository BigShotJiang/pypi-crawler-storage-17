# TXL plugin for a file browser

This is almost a copy of https://github.com/Textualize/textual/blob/main/src/textual/widgets/_directory_tree.py
