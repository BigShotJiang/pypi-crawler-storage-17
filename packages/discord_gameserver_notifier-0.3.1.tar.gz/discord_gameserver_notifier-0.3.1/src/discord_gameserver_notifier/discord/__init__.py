"""
Discord integration package
""" 