"""
Discord Gameserver Notifier Test Suite

This package contains unit tests for the Discord Gameserver Notifier application.
"""

