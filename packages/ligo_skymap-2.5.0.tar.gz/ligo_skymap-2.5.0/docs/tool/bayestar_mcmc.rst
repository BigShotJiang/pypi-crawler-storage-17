Markov-Chain Monte Carlo Localization (`bayestar-mcmc`)
=======================================================

.. argparse::
    :module: ligo.skymap.tool.bayestar_mcmc
    :func: parser
