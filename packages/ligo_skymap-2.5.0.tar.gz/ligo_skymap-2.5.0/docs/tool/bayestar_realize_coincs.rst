Simulate Triggers (`bayestar-realize-coincs`)
=============================================

.. argparse::
    :module: ligo.skymap.tool.bayestar_realize_coincs
    :func: parser
