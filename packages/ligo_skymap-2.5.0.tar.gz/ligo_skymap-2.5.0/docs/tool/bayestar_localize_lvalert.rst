.. highlight:: sh

Online Localization `bayestar-localize-lvalert`
===============================================

.. argparse::
    :module: ligo.skymap.tool.bayestar_localize_lvalert
    :func: parser
