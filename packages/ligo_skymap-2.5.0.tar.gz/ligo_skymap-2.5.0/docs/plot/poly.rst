Spherical Polygons (`ligo.skymap.plot.poly`)
============================================

.. automodule:: ligo.skymap.plot.poly
    :members:
    :show-inheritance:
