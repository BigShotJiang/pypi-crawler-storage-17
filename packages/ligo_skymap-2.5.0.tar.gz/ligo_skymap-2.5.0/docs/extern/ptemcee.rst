Parallel-Tempered MCMC (`ligo.skymap.extern.ptemcee`)
=====================================================

A parallel-tempered version of emcee, adapted from
https://github.com/willvousden/ptemcee. See :doc:`/licenses/PTEMCEE_LICENSE`.

.. automodule:: ligo.skymap.extern.ptemcee
    :members:
