Posterior Samples I/O (`ligo.skymap.io.hdf5`)
=============================================

.. automodule:: ligo.skymap.io.hdf5
    :members:
    :show-inheritance:
