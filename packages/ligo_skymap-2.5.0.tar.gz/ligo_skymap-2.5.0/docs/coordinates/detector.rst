Detector Frame (`ligo.skymap.coordinates.detector`)
===================================================

.. automodule:: ligo.skymap.coordinates.detector
    :members:
    :show-inheritance:
