=======
Credits
=======

Development
-----------

* Niels Bassler - Stockholm University, Sweden
* Leszek Grzanka - IFJ-PAN, Poland <leszek.grzanka@ifj.edu.pl>
* Jakob Toftegaard - Aarhus University Hospital, Denmark

Contributors
------------

None yet. Why not be the first?

How to cite PyTRiP98
--------------------

If you use PyTRiP for your research, please cite:

.. [1] Toftegaard et al. "PyTRiP - a toolbox and GUI for the proton/ion therapy planning system TRiP", *Journal of Physics: Conference Series* **489** (2014) 012045. `doi: 10.1088/1742-6596/489/1/012045 <http://doi.org/10.1088/1742-6596/489/1/012045>`_

Others
------

PyTRiP is using cntr.c code from matplotlib v2.1.2 (code is copied into PyTRiP sources).
