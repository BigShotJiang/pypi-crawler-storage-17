::: albert.resources.entity_types
