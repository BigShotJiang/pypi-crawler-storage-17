::: albert.resources.hazards
