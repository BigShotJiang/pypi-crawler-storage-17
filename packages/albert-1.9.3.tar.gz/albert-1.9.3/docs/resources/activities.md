::: albert.resources.activities
