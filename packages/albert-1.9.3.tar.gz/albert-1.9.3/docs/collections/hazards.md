::: albert.collections.hazards.HazardsCollection
