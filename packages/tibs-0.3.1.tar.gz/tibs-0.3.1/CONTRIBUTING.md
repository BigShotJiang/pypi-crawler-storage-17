
# Contributing

The project is currently in its alpha phase, and I am not accepting code contributions at this time.