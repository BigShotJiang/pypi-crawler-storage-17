.. currentmodule:: tibs

Examples
--------

Some examples using the Tibs library. The code for these can be found in the ``examples/`` directory of the repo.


.. toctree::
    :maxdepth: 1

    example_sieve
    example_construct

