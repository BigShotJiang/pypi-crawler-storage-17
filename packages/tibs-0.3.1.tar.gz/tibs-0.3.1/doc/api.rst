.. currentmodule:: tibs

API
---

The API docs are generated from the docs strings, so are also available via the ``help()``
function in a Python interpreted session.

.. toctree::
    :maxdepth: 1

    tibs
    mutibs