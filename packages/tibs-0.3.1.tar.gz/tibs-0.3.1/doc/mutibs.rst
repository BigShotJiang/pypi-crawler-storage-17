.. currentmodule:: tibs

Mutibs
------

.. autoclass:: tibs.Mutibs
   :members:
   :member-order: groupwise
   :undoc-members: