***************
Example Gallery
***************

This gallery contains examples of how to use ``ndcube``.
Most of these examples require the ``sunpy`` sample data, which you can download by running::

     >>> import sunpy.data.sample

Once downloaded the data will be stored in your user directory and you will not need to download it again.
