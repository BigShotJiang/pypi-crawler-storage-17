
This release of ndcube contains 518 commits in 21 merged pull requests closing 5 issues from 12 people, 6 of which are first-time contributors to ndcube.

* 518 commits have been added since 2.2
* 5 issues have been closed since 2.2
* 21 pull requests have been merged since 2.2
* 12 people have contributed since 2.2
* 6 of which are new contributors

The people who have contributed to the code for this release are:

-  Daniel Ryan
-  Junyan Huo  *
-  Laura Hayes
-  Mihail Bankov  *
-  Nabil Freij
-  Sam Van Kooten  *
-  Samuel Bennett  *
-  Sanvi Sharma  *
-  Shane Maloney  *
-  Stuart Mumford
-  Will Barnes

Where a * indicates that this release contains their first contribution to ndcube.
