********************
meta (`ndcube.meta`)
********************

.. automodapi:: ndcube.meta
