************************
mixins (`ndcube.mixins`)
************************

.. automodapi:: ndcube.mixins
