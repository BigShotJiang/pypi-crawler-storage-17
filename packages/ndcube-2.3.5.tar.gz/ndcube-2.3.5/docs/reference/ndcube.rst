*****************
ndcube (`ndcube`)
*****************

.. automodapi:: ndcube
   :inherited-members:

.. automodapi:: ndcube.ndcube
