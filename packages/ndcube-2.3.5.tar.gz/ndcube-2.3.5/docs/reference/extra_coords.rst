************************************
extra_coords (`ndcube.extra_coords`)
************************************

.. automodapi:: ndcube.extra_coords
