.. _explaining:

*********************
Explaining ``ndcube``
*********************

.. toctree::
   :maxdepth: 2

   data_classes
   metadata
   slicing
   coordinates
   tabular_coordinates
   reproject
   visualization
