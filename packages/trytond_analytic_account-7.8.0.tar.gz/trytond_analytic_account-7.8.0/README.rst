#######################
Analytic Account Module
#######################

The *Analytic Account Module* adds the fundamentals required to analyse
accounting using multiple different axes.

.. toctree::
   :maxdepth: 2

   design
   releases
