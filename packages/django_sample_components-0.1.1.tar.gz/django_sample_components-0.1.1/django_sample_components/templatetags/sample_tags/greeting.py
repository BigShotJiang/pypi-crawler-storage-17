def greeting(name):
    return f"Hello, {name}!"
