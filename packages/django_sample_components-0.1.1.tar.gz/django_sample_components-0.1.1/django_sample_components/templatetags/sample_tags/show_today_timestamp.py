import time


def show_today_timestamp():
    return str(int(time.time()))
