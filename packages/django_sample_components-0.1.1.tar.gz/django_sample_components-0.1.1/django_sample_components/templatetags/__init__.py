# Esta linha é vital para que outros projetos Django possam importar sua AppConfig
default_app_config = 'django_sample_components.apps.DjangoSampleComponents'

# Defina a versão aqui (boa prática)
__version__ = '0.1.0'
