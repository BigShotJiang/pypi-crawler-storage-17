# This line is vital so that other Django projects can import your AppConfig
default_app_config = 'django_sample_components.apps.DjangoSampleComponents'
