"""Security Rating service endpoint"""

from .security_rating import SecurityRating

__all__ = ["SecurityRating"]
