####################################
Stock Quantity Early Planning Module
####################################

The *Stock Quantity Early Planning Module* helps reducing stock level by
proposing to consume earlier.

.. toctree::
   :maxdepth: 2

   usage
   design
   releases
