*****
Usage
*****

.. _Generate stock quantity early planning:

Generate stock quantity early planning
======================================

You can run the wizard `Generate Stock Quantity Early Planning
<wizard-stock.quantity.early_plan.generate>` at any time to calculate or update
the planning.
