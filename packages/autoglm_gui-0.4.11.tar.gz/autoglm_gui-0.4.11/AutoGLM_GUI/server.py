"""AutoGLM-GUI Backend API Server."""

from AutoGLM_GUI.api import app

__all__ = ["app"]
