// Copyright Valkey GLIDE Project Contributors - SPDX Identifier: Apache-2.0

pub fn add_script(_script: &[u8]) -> String {
    "abc".to_string()
}

pub fn remove_script(_hash: &str) {}

