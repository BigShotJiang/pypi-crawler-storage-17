fn main() {
    println!("Dummy source to bypass ORT OSS Tool virtual workspace restrictions.");
}
