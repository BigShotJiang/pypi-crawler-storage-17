from .Ridge2Regressor import Ridge2Regressor

__all__ = ["Ridge2Regressor"]
