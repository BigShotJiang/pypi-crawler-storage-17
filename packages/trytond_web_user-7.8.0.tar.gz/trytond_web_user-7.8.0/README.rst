###############
Web User Module
###############

The *Web User Module* provides facilities to manage external users who are
accessing Tryton from the web.

.. toctree::
   :maxdepth: 2

   configuration
   design
   releases
