"""Tests for the delete_file tool."""

from importlib import import_module

DELETE_FILE_MODULE = import_module("clippy.tools.delete_file")
