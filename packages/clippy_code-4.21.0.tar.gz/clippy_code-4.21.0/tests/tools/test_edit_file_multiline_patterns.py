"""Tests for edit_file tool - multi-line pattern matching."""
