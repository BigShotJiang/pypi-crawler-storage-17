"""Tests for fuzzy matching functionality in edit_file tool.

These tests validate that the fuzzy matching fallback (using Jaro-Winkler similarity)
works correctly when exact regex matching fails.
"""
