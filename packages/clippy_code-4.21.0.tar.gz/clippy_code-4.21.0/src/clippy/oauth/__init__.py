"""OAuth authentication utilities for Claude Code."""
