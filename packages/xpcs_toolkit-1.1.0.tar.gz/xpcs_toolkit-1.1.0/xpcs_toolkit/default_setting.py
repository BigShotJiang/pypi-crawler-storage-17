from xpcs_toolkit.utils.logging_config import get_logger

logger = get_logger(__name__)

setting = {"window_size_w": 1024, "window_size_h": 800}

logger.debug("Default settings loaded")
