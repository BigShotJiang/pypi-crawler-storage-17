User Guide
==========

Installation, usage, and workflows for XPCS Toolkit.

.. toctree::
   :maxdepth: 2

   installation
   quickstart
   examples
