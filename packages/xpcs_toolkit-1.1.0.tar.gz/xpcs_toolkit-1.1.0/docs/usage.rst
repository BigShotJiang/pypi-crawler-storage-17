=====
Usage
=====

To use XPCS Toolkit in a project::

    import xpcs_toolkit
