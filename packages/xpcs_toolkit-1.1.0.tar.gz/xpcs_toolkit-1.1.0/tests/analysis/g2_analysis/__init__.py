"""G2 correlation analysis tests for XPCS Toolkit.

This package contains all tests related to G2 correlation function analysis,
fitting algorithms, and validation of correlation analysis results.
"""
