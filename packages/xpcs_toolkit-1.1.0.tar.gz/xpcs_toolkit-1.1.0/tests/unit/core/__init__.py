"""Core component unit tests for XPCS Toolkit."""
