"""Unit tests for XPCS-TOOLKIT GUI components."""
