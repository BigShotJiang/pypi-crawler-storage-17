"""Qt validation test suite for XPCS Toolkit.

This package consolidates all Qt-related validation tests including
cross-platform compatibility, compliance checks, and integration testing.
"""
