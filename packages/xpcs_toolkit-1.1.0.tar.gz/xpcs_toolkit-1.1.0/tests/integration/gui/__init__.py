"""Integration tests for XPCS-TOOLKIT GUI components."""
