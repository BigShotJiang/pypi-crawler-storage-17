########################
Account Statement Module
########################

The *Account Statement Module* provides facilities to book statements.
Statements can be used for bank statements, cash daybooks etc.

.. toctree::
   :maxdepth: 2

   configuration
   design
   releases
