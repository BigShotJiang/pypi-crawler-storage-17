"""API adapters - Python library public API."""
