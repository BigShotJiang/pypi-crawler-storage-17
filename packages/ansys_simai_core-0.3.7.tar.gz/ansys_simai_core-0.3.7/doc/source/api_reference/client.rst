.. _simai_client:

Client
======

.. py:module:: ansys.simai.core.client

.. autoclass:: SimAIClient
    :members:
