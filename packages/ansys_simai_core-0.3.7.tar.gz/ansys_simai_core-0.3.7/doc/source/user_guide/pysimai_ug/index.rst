.. _ref_pysimai_guide:

Run a physics prediction
========================================================

These sections teach you how to use particular features of PySimAI.

.. toctree::
   :maxdepth: 2

   building_a_model
   data_exploration
   best_practices