.. _ref_configuration_guide:

Configure your instance
========================================================

.. toctree::
   :maxdepth: 2

   installation
   configuration
   config_file
   proxy
