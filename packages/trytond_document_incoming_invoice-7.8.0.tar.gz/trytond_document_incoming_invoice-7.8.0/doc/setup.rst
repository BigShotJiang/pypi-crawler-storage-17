*****
Setup
*****

.. _Setting default supplier:

Setting default supplier
========================

When the *Document Incoming Invoice Module* is activated, you must setup a
default supplier in the `Configuration
<document_incoming:model-document.incoming.configuration>` so an invoice can
always be created even if no supplier is deduced.
