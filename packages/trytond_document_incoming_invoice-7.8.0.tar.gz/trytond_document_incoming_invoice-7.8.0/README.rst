################################
Document Incoming Invoice Module
################################

The *Document Incoming Invoice Module* creates supplier invoice from incoming
documents.

.. toctree::
   :maxdepth: 2

   setup
   releases
