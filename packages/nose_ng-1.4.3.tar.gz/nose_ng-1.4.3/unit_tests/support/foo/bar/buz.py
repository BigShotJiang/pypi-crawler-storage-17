from foo import boodle

def afunc():
    """This is a doctest
    >>> 2 + 3
    5
    """
    pass
