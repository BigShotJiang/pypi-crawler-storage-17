"""
Top level
---------

Let's run a test.

    >>> foo(1)
    2
    >>> 2 + 2
    4
"""
def foo(a):
    """
    >>> foo(2)
    3
    """
    return a + 1
