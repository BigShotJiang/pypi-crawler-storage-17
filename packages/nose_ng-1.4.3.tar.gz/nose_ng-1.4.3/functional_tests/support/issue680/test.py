def test_foo():
    print("abc€")
