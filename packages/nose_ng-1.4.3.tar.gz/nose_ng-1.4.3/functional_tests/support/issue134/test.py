def test():
    print("something")
    raise OSError(42, "test")
