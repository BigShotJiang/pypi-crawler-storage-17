#from . import counter
from time import sleep
#_multiprocess_can_split_ = True
class Test1:
    def test1(self):
        sleep(1)
        pass
class Test2:
    def test2(self):
        sleep(1)
        pass
