def setup():
    print('package2c setup')
