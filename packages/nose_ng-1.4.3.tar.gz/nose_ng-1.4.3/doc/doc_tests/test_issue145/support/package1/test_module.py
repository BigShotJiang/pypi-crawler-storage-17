import unittest

def test_function():
    pass

class TestClass:
    def test_class(self):
        pass

class TestCase(unittest.TestCase):
    def test(self):
        pass
