def cat(a, b):
    return "{}{}".format(a, b)
