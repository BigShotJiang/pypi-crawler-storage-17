Attrib: tag and select tests with attributes
============================================

.. autoplugin :: nose.plugins.attrib
