# hyperquant

hyperquant is a minimalistic framework for quantitative trading strategies. It allows users to quickly validate their strategy ideas with ease and efficiency.
