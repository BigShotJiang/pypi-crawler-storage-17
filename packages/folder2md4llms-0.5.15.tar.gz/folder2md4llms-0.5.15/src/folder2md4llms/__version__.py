"""Version information for folder2md4llms.

This file is the single source of truth for version information.
Do not create __about__.py - use only this __version__.py file.
"""

__version__ = "0.5.15"
__version_tuple__ = (0, 5, 15)
