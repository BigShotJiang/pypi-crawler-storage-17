"""CLI commands for folder2md4llms."""

from .changelog import changelog

__all__ = ["changelog"]
