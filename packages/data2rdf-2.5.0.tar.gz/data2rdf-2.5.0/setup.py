"""This file is required for editable installs of the package."""
from setuptools import setup

setup()
