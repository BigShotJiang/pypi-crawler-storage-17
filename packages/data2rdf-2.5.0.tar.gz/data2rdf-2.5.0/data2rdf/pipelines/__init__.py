"""Data2rdf pipelines"""

from .main import Data2RDF

__all__ = ["Data2RDF"]
