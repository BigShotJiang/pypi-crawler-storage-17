from typing import Union

from typing import List

from box_sdk_gen.box.errors import BoxSDKError

MetadataInstanceValue = Union[str, int, float, List[str]]
