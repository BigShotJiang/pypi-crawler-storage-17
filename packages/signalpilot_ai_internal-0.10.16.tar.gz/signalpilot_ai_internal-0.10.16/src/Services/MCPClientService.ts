import { URLExt } from '@jupyterlab/coreutils';
import { ServerConnection } from '@jupyterlab/services';
import {
  IMCPServer,
  IMCPServerConfig,
  IMCPServerInfo,
  IMCPTool
} from '../Components/MCPManagerWidget/types';

/**
 * Service for managing MCP client connections and tool calls
 * Handles communication between frontend and backend MCP proxy
 */
export class MCPClientService {
  private static instance: MCPClientService;
  private settings: ServerConnection.ISettings;
  private connectedServers: Map<string, IMCPServerInfo> = new Map();
  private allToolsCache: IMCPTool[] = [];
  private lastToolsUpdate: number = 0;
  private readonly CACHE_DURATION = 5000; // 5 seconds

  private constructor() {
    this.settings = ServerConnection.makeSettings();
  }

  static getInstance(): MCPClientService {
    if (!MCPClientService.instance) {
      MCPClientService.instance = new MCPClientService();
    }
    return MCPClientService.instance;
  }

  /**
   * Get all configured MCP servers
   */
  async getServers(): Promise<IMCPServer[]> {
    try {
      const url = URLExt.join(
        this.settings.baseUrl,
        'signalpilot-ai-internal/mcp/servers'
      );
      const response = await ServerConnection.makeRequest(
        url,
        {},
        this.settings
      );
      const data = await response.json();
      return data.servers || [];
    } catch (error) {
      console.error('Error fetching MCP servers:', error);
      return [];
    }
  }

  /**
   * Save MCP server configuration
   */
  async saveServer(config: IMCPServerConfig): Promise<void> {
    const url = URLExt.join(
      this.settings.baseUrl,
      'signalpilot-ai-internal/mcp/servers'
    );
    const response = await ServerConnection.makeRequest(
      url,
      {
        method: 'POST',
        body: JSON.stringify(config)
      },
      this.settings
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to save server configuration');
    }
  }

  /**
   * Delete MCP server configuration
   */
  async deleteServer(serverId: string): Promise<void> {
    const url = URLExt.join(
      this.settings.baseUrl,
      `signalpilot-ai-internal/mcp/servers/${serverId}`
    );
    const response = await ServerConnection.makeRequest(
      url,
      {
        method: 'DELETE'
      },
      this.settings
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to delete server');
    }

    // Remove from connected servers
    this.connectedServers.delete(serverId);
    this.invalidateToolsCache();
  }

  /**
   * Connect to MCP server
   */
  async connect(serverId: string): Promise<IMCPServerInfo> {
    console.log(`[MCP Client] Attempting to connect to server: ${serverId}`);
    
    const url = URLExt.join(
      this.settings.baseUrl,
      'signalpilot-ai-internal/mcp/connect'
    );
    
    try {
      const response = await ServerConnection.makeRequest(
        url,
        {
          method: 'POST',
          body: JSON.stringify({ server_id: serverId })
        },
        this.settings
      );

      if (!response.ok) {
        let errorData: any;
        try {
          errorData = await response.json();
        } catch (e) {
          console.error('[MCP Client] Failed to parse error response:', e);
          throw new Error(`Failed to connect to MCP server (HTTP ${response.status})`);
        }
        
        console.error('[MCP Client] Connection error details:', errorData);
        
        // Create detailed error message
        const errorMsg = errorData.error || 'Failed to connect to MCP server';
        const errorType = errorData.errorType || 'Unknown';
        const details = errorData.details || '';
        const stackTrace = errorData.stackTrace || '';
        
        let fullError = `[${errorType}] ${errorMsg}`;
        if (details) {
          fullError += `\n\nDetails: ${details}`;
        }
        if (stackTrace) {
          console.error('[MCP Client] Server stack trace:\n', stackTrace);
        }
        
        throw new Error(fullError);
      }

      const data = await response.json();
      const serverInfo = data.server as IMCPServerInfo;

      // Cache connection info
      this.connectedServers.set(serverId, serverInfo);
      this.invalidateToolsCache();

      console.log(`[MCP Client] Successfully connected to ${serverId}`);
      return serverInfo;
    } catch (error) {
      console.error(`[MCP Client] Error connecting to server ${serverId}:`, error);
      throw error;
    }
  }

  /**
   * Disconnect from MCP server
   */
  async disconnect(serverId: string): Promise<void> {
    const url = URLExt.join(
      this.settings.baseUrl,
      `signalpilot-ai-internal/mcp/servers/${serverId}/disconnect`
    );
    const response = await ServerConnection.makeRequest(
      url,
      {
        method: 'POST'
      },
      this.settings
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to disconnect from MCP server');
    }

    // Remove from cache
    this.connectedServers.delete(serverId);
    this.invalidateToolsCache();
  }

  /**
   * Get available tools from a specific connected server
   */
  async getTools(serverId: string): Promise<IMCPTool[]> {
    try {
      const url = URLExt.join(
        this.settings.baseUrl,
        `signalpilot-ai-internal/mcp/servers/${serverId}/tools`
      );
      const response = await ServerConnection.makeRequest(
        url,
        {},
        this.settings
      );

      if (!response.ok) {
        throw new Error('Failed to fetch tools');
      }

      const data = await response.json();
      return data.tools || [];
    } catch (error) {
      console.error(`Error fetching tools for server ${serverId}:`, error);
      return [];
    }
  }

  /**
   * Get all tools from all connected servers
   * Uses caching to avoid excessive backend calls
   */
  async getAllTools(forceRefresh: boolean = false): Promise<IMCPTool[]> {
    const now = Date.now();

    // Return cached tools if still valid
    if (
      !forceRefresh &&
      this.allToolsCache.length > 0 &&
      now - this.lastToolsUpdate < this.CACHE_DURATION
    ) {
      return this.allToolsCache;
    }

    try {
      const url = URLExt.join(
        this.settings.baseUrl,
        'signalpilot-ai-internal/mcp/tools'
      );
      const response = await ServerConnection.makeRequest(
        url,
        {},
        this.settings
      );

      if (!response.ok) {
        throw new Error('Failed to fetch all tools');
      }

      const data = await response.json();
      this.allToolsCache = data.tools || [];
      this.lastToolsUpdate = now;

      return this.allToolsCache;
    } catch (error) {
      console.error('Error fetching all MCP tools:', error);
      return [];
    }
  }

  /**
   * Call a tool via backend proxy
   */
  async callTool(serverId: string, toolName: string, args: any): Promise<any> {
    const url = URLExt.join(
      this.settings.baseUrl,
      'signalpilot-ai-internal/mcp/call-tool'
    );
    const response = await ServerConnection.makeRequest(
      url,
      {
        method: 'POST',
        body: JSON.stringify({
          server_id: serverId,
          tool_name: toolName,
          arguments: args
        })
      },
      this.settings
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to call tool');
    }

    const data = await response.json();
    return data.result;
  }

  /**
   * Convert MCP tools to Anthropic tool format
   */
  convertToAnthropicTools(mcpTools: IMCPTool[]): any[] {
    return mcpTools.map(tool => ({
      name: tool.name,
      description: tool.description || `Tool from ${tool.serverName}`,
      input_schema: tool.inputSchema
    }));
  }

  /**
   * Check if a tool name belongs to an MCP server
   */
  isMCPTool(toolName: string): boolean {
    return this.allToolsCache.some(tool => tool.name === toolName);
  }

  /**
   * Get the server ID for a given tool name
   */
  getServerIdForTool(toolName: string): string | null {
    const tool = this.allToolsCache.find(t => t.name === toolName);
    return tool ? tool.serverId : null;
  }

  /**
   * Get connection status for all servers
   */
  getConnectionStatus(): Map<string, 'connected' | 'disconnected'> {
    const status = new Map<string, 'connected' | 'disconnected'>();
    for (const [serverId, _] of this.connectedServers) {
      status.set(serverId, 'connected');
    }
    return status;
  }

  /**
   * Invalidate the tools cache
   */
  private invalidateToolsCache(): void {
    this.allToolsCache = [];
    this.lastToolsUpdate = 0;
  }

  /**
   * Refresh all tools from backend
   */
  async refreshTools(): Promise<IMCPTool[]> {
    return this.getAllTools(true);
  }
}

// Export singleton instance getter
export const getMCPClientService = () => MCPClientService.getInstance();

