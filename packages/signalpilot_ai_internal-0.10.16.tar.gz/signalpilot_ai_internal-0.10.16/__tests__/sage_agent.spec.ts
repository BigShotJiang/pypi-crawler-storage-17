/**
 * Example of [Jest](https://jestjs.io/docs/getting-started) unit tests
 */

describe('signalpilot-ai-internal', () => {
  it('should be tested', () => {
    expect(1 + 1).toEqual(2);
  });
});
