"""
### Typed Okxus
> A fully typed, validated async client for the Okxus API

- Details
"""