# Summary
These txt hash files are generated from VPDQ. These are used for regression test to check if the hashes created locally match with the original implementation.
# Format
Each line in txt file: FrameNumber, Quality, PDQHash
