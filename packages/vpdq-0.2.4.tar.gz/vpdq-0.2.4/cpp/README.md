# Documentation

See the [README](https://github.com/facebook/ThreatExchange/blob/main/vpdq/README.md) in the main vpdq directory for build instructions.

See the [README](https://github.com/facebook/ThreatExchange/blob/main/README.md) in the main ThreatExchange directory for more information about the project.

See [hashing.pdf](https://github.com/facebook/ThreatExchange/blob/main/hashing/hashing.pdf) in ThreatExchange/hashing for an indepth explanation of the algorithm.
