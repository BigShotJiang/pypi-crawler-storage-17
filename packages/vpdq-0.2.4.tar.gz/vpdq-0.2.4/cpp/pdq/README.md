Vendored PDQ CPP Implementation

PDQ is maintained here as a separate full src independent of the main location in order to ease the complexity of the VPDQs build system and to avoid version conflicts.

If VPDQ or PDQ are moved to their own repositories in the future, VPDQ's build system will still continue to function without modification.
