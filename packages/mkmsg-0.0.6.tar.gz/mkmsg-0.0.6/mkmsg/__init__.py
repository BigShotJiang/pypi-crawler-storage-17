from .mk import (
    send_whats_msg,
    send_mail,
    send_html_mail,
    generate_otp
    )