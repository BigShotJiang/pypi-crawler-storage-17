"""Infrastructure helpers for the CLI runtime."""
