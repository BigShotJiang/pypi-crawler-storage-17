"""Sandbox utilities for temporary workspaces."""
