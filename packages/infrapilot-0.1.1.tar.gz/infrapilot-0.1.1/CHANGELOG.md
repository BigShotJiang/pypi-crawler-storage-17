# Changelog

## 0.1.1 - Unreleased
- Enforced authentication on startup; removed the `--skip-auth` flag (CLI always requires login).
- Expanded CLI documentation with install options (pip/pipx/uv), secure token storage, AWS/GitHub integration, and full command reference.
