"""Top-level package for django-UrlConfChecks."""

__author__ = """ali sayyah"""
__email__ = 'ali.sayyah2@gmail.com'
__version__ = '0.12.0'
