"""Unit test package for django-urlconfchecks."""
