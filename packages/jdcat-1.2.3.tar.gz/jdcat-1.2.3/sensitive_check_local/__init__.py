"""
Local helper CLI for sensitive-check project.
"""

from typing import Final

__version__: Final[str] = "1.2.3"