class MalformedAgeVerificationException(Exception):
    pass
