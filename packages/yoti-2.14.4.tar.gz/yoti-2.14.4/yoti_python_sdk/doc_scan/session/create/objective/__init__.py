from .proof_of_address_objective import ProofOfAddressObjectiveBuilder

__all__ = [
    "ProofOfAddressObjectiveBuilder",
]
