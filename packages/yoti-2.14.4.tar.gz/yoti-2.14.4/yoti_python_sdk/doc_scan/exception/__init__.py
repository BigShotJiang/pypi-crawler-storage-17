from .doc_scan_exception import DocScanException

__all__ = ["DocScanException"]
