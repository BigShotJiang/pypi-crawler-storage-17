# -*- coding: utf-8 -*-

# Copyright (c) 2016-2023 by University of Kassel and Fraunhofer Institute for Energy Economics
# and Energy System Technology (IEE), Kassel. All rights reserved.



VM = 0
VM_STD = 1
P = 2
P_STD = 3
Q = 4
Q_STD = 5
VM_IDX = 6
P_IDX = 7
Q_IDX = 8
ZERO_INJ_FLAG = 9
VA = 10
VA_STD = 11
VA_IDX = 12

bus_cols_se = 13
