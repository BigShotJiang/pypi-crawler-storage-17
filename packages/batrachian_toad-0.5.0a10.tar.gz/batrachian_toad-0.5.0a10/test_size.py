import os
width, height = os.get_terminal_size()

print(width*"-")
print(width)
