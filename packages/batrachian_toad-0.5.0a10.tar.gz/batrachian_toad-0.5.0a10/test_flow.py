print("".join("📦" + str(n) * 3 for n in range(10)))
