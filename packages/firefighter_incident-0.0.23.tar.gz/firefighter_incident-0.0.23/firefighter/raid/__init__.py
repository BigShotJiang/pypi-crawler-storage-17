"""RAID is ManoMano's internal issue dispatcher.

It works with Slack and Jira to create, update and close issues.

It is currently not configurable.
"""
