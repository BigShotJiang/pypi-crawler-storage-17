"""Service Account credentials abstractions."""
