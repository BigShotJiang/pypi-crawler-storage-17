import setuptools_scm  # noqa: F401
from setuptools import setup

setup()
