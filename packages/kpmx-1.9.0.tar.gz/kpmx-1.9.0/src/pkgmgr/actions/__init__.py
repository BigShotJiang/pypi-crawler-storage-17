from __future__ import annotations

# expose subpackages for patch() / resolve_name() friendliness
from . import release as release  # noqa: F401

__all__ = ["release"]
