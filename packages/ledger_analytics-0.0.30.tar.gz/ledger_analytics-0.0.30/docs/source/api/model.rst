``LedgerModel`` class
=========================

..  automodule:: ledger_analytics.model
    :members:
