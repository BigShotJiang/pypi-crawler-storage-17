``TriangleInterface`` and ``ModelInterface`` classes
=========================================================

..  automodule:: ledger_analytics.interface
    :members:
