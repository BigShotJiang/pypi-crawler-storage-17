API documentation
=====================

..  toctree::
    :maxdepth: 2

    api.rst
    triangle.rst
    model.rst
    interface.rst
    development.rst
    tail.rst
    forecast.rst
