Forecast model configurations
===================================

``AR1``
----------------------

.. autoclass:: ledger_analytics.AR1
   :members:
   :exclude-members: model_config

``SSM``
----------------------

.. autoclass:: ledger_analytics.SSM
   :members:
   :exclude-members: model_config

``TraditionalGCC``
----------------------

.. autoclass:: ledger_analytics.TraditionalGCC
   :members:
   :exclude-members: model_config
