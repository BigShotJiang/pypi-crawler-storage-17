``Triangle`` class
=========================

..  automodule:: ledger_analytics.triangle
    :members:
