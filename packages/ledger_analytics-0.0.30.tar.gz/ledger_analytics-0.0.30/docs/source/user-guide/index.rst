User Guide
===============

.. toctree::
   :maxdepth: 2

   overview.rst
   modeling.rst
   autofit.rst
   development.rst
   tail.rst
   forecast.rst
