---
name: New compiler pass
about: Suggest a new compilation pass to integrate into UCC
title: "[NEW PASS]"
labels: feature, compiler_pass
assignees: ''

---
<!-- _This is the template to use if you'd like to share an idea for a new quantum compiler pass to go into UCC._ -->

### Short description
**Technique name:**

<!-- Describe the basic functioning of you compiler pass porposal. If your compiler pass is from a paper, you can paste the abstract here -->

#### Source of technique
<!-- Provide links to the following, as applicable. If it's just an idea from your head, feel free to say that :) -->
Scientific/white-paper:  
Code repository:

---
### Full proposal (optional)
If you want to actively work on integrating this pass, please fill out our formal
[New Compiler Pass Proposal](https://github.com/unitaryfoundation/ucc/discussions/new?category=new-compiler-pass) discussion template and link it here:
