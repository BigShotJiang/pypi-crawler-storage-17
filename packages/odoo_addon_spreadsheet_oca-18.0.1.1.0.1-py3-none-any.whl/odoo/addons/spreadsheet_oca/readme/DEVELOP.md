If you want to develop custom business functions, you can add others,
based on the file
<https://github.com/odoo/odoo/blob/16.0/addons/spreadsheet_account/static/src/accounting_functions.js>
