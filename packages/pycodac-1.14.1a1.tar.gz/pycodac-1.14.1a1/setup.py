# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['PyCODAC']

package_data = \
{'': ['*']}

extras_require = \
{':python_version == "2.7" or python_version >= "3.5" and python_version < "4.0"': ['pyc-core>=1.14',
                                                                                    'pyx-core>=1.28'],
 ':python_version >= "3.10" and python_version < "4.0"': ['pyx-webservice>=1.28'],
 ':python_version >= "3.7" and python_version < "4.0"': ['pyc-webservice>=1.14'],
 'all:python_version >= "3.10" and python_version < "4.0"': ['pyc-client>=1.14'],
 'client:python_version >= "3.10" and python_version < "4.0"': ['pyc-client>=1.14']}

setup_kwargs = {
    'name': 'pycodac',
    'version': '1.14.1a1',
    'description': 'PyCODAC as a standalone application.',
    'long_description': 'None',
    'author': 'Garbade, Marc',
    'author_email': 'marc.garbade@dlr.de',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://gitlab.com/dlr-sy/pycodac',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'extras_require': extras_require,
    'python_requires': '>=2.7, !=3.0.*, !=3.1.*, !=3.2.*, !=3.3.*, !=3.4.*',
}
from config.build import *
build(setup_kwargs)

setup(**setup_kwargs)
