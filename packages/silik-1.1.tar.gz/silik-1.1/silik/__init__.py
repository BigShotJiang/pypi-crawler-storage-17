"""Silik Base Kernel : Multi Kernel Interaction"""

__version__ = "1.1"

from .kernel import SilikBaseKernel  # noqa: F401
