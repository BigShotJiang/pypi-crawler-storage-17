# pyvikunja
A python library for interfacing with a Vikunja instance
