from enum import IntEnum


class RepeatMode(IntEnum):
    DEFAULT = 0
    MONTHLY = 1
    FROM_CURRENT_DATE = 2
