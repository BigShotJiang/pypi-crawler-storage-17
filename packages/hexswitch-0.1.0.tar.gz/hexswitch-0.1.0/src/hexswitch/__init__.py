# HexSwitch - Hexagonal runtime switchboard for config-driven microservices

__version__ = "0.1.0"

from hexswitch.shared.envelope import Envelope

__all__ = ["Envelope"]

