"""Shared kernel - envelope, config, observability, and helpers."""

from hexswitch.shared.envelope import Envelope

__all__ = ["Envelope"]

