"""Service abstractions for HexSwitch framework."""

from hexswitch.domain.services.base_service import BaseService

__all__ = [
    "BaseService",
]

