default_app_config = "lacrei_models.client.apps.ClientConfig"
