def hi():
    print("Hello from pip package!")