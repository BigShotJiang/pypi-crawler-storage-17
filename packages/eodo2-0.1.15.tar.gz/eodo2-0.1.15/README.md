# eodo2

EdgeOneDynamicOrigin

## Installation

```bash
pip install -e .
```

## Usage

Run the application:

```bash
python -m eodo2.app
```
