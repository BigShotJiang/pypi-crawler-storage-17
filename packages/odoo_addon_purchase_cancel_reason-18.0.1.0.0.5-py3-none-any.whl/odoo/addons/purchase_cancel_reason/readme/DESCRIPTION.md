When a purchase order is canceled, a reason must be given, it is chosen
from a configured list.
