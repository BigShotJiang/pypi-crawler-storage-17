import logging

import sdmx

sdmx.log.setLevel(logging.DEBUG)
