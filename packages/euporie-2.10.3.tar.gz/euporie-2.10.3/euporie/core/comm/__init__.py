"""Sub-module for handling kernel Comm messages."""
