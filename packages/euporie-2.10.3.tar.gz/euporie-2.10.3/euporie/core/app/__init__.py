"""Concerns defining and launching applications."""

APP_ALIASES = {"edit": "notebook"}
