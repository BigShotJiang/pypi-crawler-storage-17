"""A euporie app for previewing notebook files."""
