---

version.txt file on this site

- when i send that chat is most recent

Some issues to add:

- When looking at the UI, I sometimes see my messages as empty. It shows the data and time, but no text. If i look at my phone, I can see text. 
- When someone does something like pressing thumbs up on a message, its rendered as `Liked “(ignore)”`. Can you figure out how to render this appropriately in the UI and read it correctly and make inferences.
- Send images?
- Contact names
- I dont think images is actually working. Create a test for parsing one?

- uv package binary when wheels plus also auto-update script
- cache and slow load. dynamic update. paginate
- config option for chrome notifs
- open most recent chat by default
- auto scroll to bottom



/Users/generativist/iuselinux/imessage_gateway/bin/ContactLookup.app/Contents/MacOS/contact_lookup --request-permission

- All permissions (request and stats) in settings

Create issues and epics where necessary for the following:

- When the app loads right now, it seems like all messages have to populate. Change it so that they populate via streaming, so that there isn't a long lag time. Also not all messages need to populate. Have it so that only the most recent do, and then chats paginate by going to the bottom of the scroll. make it clear in the ui that more are loading. do that for pages of size 20
- When a new message in a chat arrives, the order of the chats should change (i.e. it should make that chat go to the top)
- When the ui is openned, it automatically opens the most recent chat on load.
- When a chat is selected, it automatically scrolls to the bottom. For new messages make it so the ui automatically keeps scrolling. unless you had already scrolled up manually, in which case there should be a "New Message; scroll to bottom" style alert (text cant be more appropriate). if you press it you go to bottom and autoscroll is reenagaged.
- Add a configuration option that lets you select whether the ui sends chrome notifications for new messages. By default, it is on.
- The tapback emojis right now are rendered in their own messages. They shuold be like iMessage — sort of annotating the actual message


- Update about page

----

- Image click modal 80% of screen
- unread icon?

- urls?

Some more issues:

- Support for sending images
- Multiple images
- When I get a new message for a new chat, the UI doesn't update it. how could i fix this?

----

- is there auto resume connection
- what does default chats to return default chat limit in api do?
- what about message limit?
- where is advanced?

----

Add double click tap back to the UI. Is this psosible though? How would I send thie tap back? If not possible tell me

----

-- Still has lag
-- install-as-service
