---
description: Bump pypi version
---

Bump version but first update toml and uv.lock and commit and push with git add tag to trigger pypi release ci worfflow new version is