"""
Bundled non-code assets (schemas + starter policies).

These ship in wheels/sdists so `pip install lumyn` works without needing the repo checkout.
"""
