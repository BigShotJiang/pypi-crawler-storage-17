"""FastAPI service wrapper for Lumyn."""
