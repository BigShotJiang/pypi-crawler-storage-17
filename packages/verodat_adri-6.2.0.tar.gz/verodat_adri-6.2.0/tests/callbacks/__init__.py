"""Tests for ADRI async callback system."""
