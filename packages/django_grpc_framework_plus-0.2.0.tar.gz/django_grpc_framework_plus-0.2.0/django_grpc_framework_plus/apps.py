from django.apps import AppConfig


class DjangoGrpcFrameworkPlusConfig(AppConfig):
    name = "django_grpc_framework_plus"
    verbose_name = "Django gRPC framework plus"
