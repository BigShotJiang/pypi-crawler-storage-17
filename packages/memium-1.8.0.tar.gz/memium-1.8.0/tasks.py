from memium.tasks.smoketest import smoketest_cli  # noqa: F401 # type: ignore
