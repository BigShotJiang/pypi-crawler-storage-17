from .main import map_image

__all__ = [
    "map_image"
]
