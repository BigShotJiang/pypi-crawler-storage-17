from enum import Enum

RenderMode = Enum("RenderMode", ["Figure", "FigureOnce"])
