from ..core import RewardFunction
from .weighted_sum_of_errors import WeightedSumOfErrors
