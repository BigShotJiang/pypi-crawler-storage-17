"""MachineryEncasedJournalBearing"""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from mastapy._private._internal.dataclasses import extended_dataclass
from mastapy._private._internal.exceptions import CastException
from mastapy._private._internal.python_net import python_net_import

from mastapy._private._internal import utility
from mastapy._private.bearings.bearing_designs.fluid_film import _2440

_MACHINERY_ENCASED_JOURNAL_BEARING = python_net_import(
    "SMT.MastaAPI.Bearings.BearingDesigns.FluidFilm", "MachineryEncasedJournalBearing"
)

if TYPE_CHECKING:
    from typing import Any, Type, TypeVar

    Self = TypeVar("Self", bound="MachineryEncasedJournalBearing")
    CastSelf = TypeVar(
        "CastSelf",
        bound="MachineryEncasedJournalBearing._Cast_MachineryEncasedJournalBearing",
    )


__docformat__ = "restructuredtext en"
__all__ = ("MachineryEncasedJournalBearing",)


@extended_dataclass(frozen=True, slots=True, weakref_slot=True)
class _Cast_MachineryEncasedJournalBearing:
    """Special nested class for casting MachineryEncasedJournalBearing to subclasses."""

    __parent__: "MachineryEncasedJournalBearing"

    @property
    def plain_journal_housing(self: "CastSelf") -> "_2440.PlainJournalHousing":
        return self.__parent__._cast(_2440.PlainJournalHousing)

    @property
    def machinery_encased_journal_bearing(
        self: "CastSelf",
    ) -> "MachineryEncasedJournalBearing":
        return self.__parent__

    def __getattr__(self: "CastSelf", name: str) -> "Any":
        try:
            return self.__getattribute__(name)
        except AttributeError:
            class_name = utility.camel(name)
            raise CastException(
                f'Detected an invalid cast. Cannot cast to type "{class_name}"'
            ) from None


@extended_dataclass(frozen=True, slots=True, weakref_slot=True, eq=False)
class MachineryEncasedJournalBearing(_2440.PlainJournalHousing):
    """MachineryEncasedJournalBearing

    This is a mastapy class.
    """

    TYPE: ClassVar["Type"] = _MACHINERY_ENCASED_JOURNAL_BEARING

    wrapped: "Any"

    def __post_init__(self: "Self") -> None:
        """Override of the post initialisation magic method."""
        if not hasattr(self.wrapped, "reference_count"):
            self.wrapped.reference_count = 0

        self.wrapped.reference_count += 1

    @property
    def cast_to(self: "Self") -> "_Cast_MachineryEncasedJournalBearing":
        """Cast to another type.

        Returns:
            _Cast_MachineryEncasedJournalBearing
        """
        return _Cast_MachineryEncasedJournalBearing(self)
