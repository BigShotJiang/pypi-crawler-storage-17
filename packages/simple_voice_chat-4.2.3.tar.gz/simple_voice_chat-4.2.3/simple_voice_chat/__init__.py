# This file makes the 'simple_voice_chat' directory a Python package.
