from satispy.io.dimacs_cnf import *
