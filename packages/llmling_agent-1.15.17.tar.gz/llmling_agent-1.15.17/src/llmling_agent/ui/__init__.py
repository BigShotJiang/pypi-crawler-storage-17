# src/llmling_agent/interfaces/__init__.py
"""Interface definitions for LLMling agent."""
