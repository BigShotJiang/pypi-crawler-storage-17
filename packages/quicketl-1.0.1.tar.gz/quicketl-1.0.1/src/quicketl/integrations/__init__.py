"""QuickETL integrations with external systems."""

from quicketl.integrations.airflow import quicketl_task

__all__ = ["quicketl_task"]
