class SDKConfig:
    """Global configuration for the SDK"""
    HOST = "127.0.0.1"
    PORT = 8128
    RATE_LIMIT_ENABLED = True
