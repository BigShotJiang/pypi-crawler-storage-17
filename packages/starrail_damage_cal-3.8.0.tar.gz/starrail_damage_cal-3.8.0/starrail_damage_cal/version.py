StarRail_version = "3.7.0"
