"""
Script to train an agent using GAIL (Generative Adversarial Imitation Learning).

How to run:
    python train_gail.py

Requirements:
    pip install imitation
"""
import logging
import os
import sys

# Ensure local project import works even without pip install -e .
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import gymnasium as gym
import numpy as np
from gymnasium.wrappers import FlattenObservation
from omegaconf import DictConfig, OmegaConf
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv, VecMonitor
from stable_baselines3.common.evaluation import evaluate_policy
from imitation.algorithms.adversarial.gail import GAIL
from imitation.rewards.reward_nets import BasicRewardNet
from imitation.util.networks import RunningNorm
from imitation.data import rollout, serialize

from utdg_env.utils.hydra_loader import load_config, pretty_print_cfg
from utdg_env.env.registry import make_env
from utdg_env.launcher import GodotWebLauncher, GodotNativeLauncher

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


def setup_launcher(cfg, logger: logging.Logger):
    """Setup and start Godot launcher for any runtime mode.

    Copied from trainer.py to maintain consistency.
    """
    mode = cfg.runtime.mode
    launcher_enabled = cfg.runtime.launcher.get("enabled", False)

    if not launcher_enabled:
        logger.info("Launcher disabled - expecting manual Godot client connection")
        return None, None

    if mode == "native":
        godot_path = cfg.runtime.get("godot_path", "builds/UTDG-macOS.app")
        headless = cfg.runtime.launcher.get("headless", False)

        logger.info("[1/2] Launching native Godot application...")
        launcher = GodotNativeLauncher(
            godot_path=godot_path,
            headless=headless,
        )
        launcher.launch()
        logger.info("  ✓ Godot app launched from %s", godot_path)
        return launcher, None

    elif mode.startswith("web"):
        launcher_mode = cfg.runtime.launcher.get("mode", "local-dev")
        build_dir = cfg.runtime.web.get("path", "builds/web")
        http_port = cfg.runtime.web.get("http_port", 8080)
        ws_port = cfg.runtime.server.port
        headless = cfg.runtime.launcher.get("headless", False)
        open_browser = cfg.runtime.launcher.get("browser", True)

        logger.info("[1/4] Starting Godot web launcher (mode=%s)...", launcher_mode)

        launcher = GodotWebLauncher.from_mode(
            launcher_mode,
            build_dir=build_dir,
            http_port=http_port,
            ws_host="localhost",
            ws_port=ws_port,
            headless=headless,
            open_browser=open_browser,
        )

        http_url, _ = launcher.launch()
        logger.info("  ✓ Web launcher started at %s", http_url)
        return launcher, http_url

    else:
        logger.warning("Unknown runtime mode: %s - no launcher configured", mode)
        return None, None


def create_environment(cfg, logger: logging.Logger) -> DummyVecEnv:
    """Create and configure the vectorized environment.

    Args:
        cfg: Hydra configuration object.
        logger: Logger instance for output messages.

    Returns:
        Configured DummyVecEnv with flattened observations.
    """
    def make_env_fn():
        env = make_env(cfg)
        # Flatten Dict observations to a single Box space
        # This is required for compatibility with imitation library
        env = FlattenObservation(env)
        return env

    venv = DummyVecEnv([make_env_fn])
    venv = VecMonitor(venv)

    logger.info("  ✓ Environment created (with FlattenObservation wrapper)")
    logger.info("  Observation space: %s", venv.observation_space)
    logger.info("  Action space: %s", venv.action_space)

    return venv


def cleanup_resources(venv, launcher, logger: logging.Logger):
    """Cleanup environment and launcher resources."""
    logger.info("[cleanup] Shutting down resources...")

    if venv is not None:
        try:
            venv.close()
            logger.info("  ✓ Environment closed")
        except Exception as e:
            logger.warning("  ⚠ Failed to close environment: %s", e)

    if launcher is not None:
        try:
            launcher.stop()
            logger.info("  ✓ Launcher stopped")
        except Exception as e:
            logger.warning("  ⚠ Failed to stop launcher: %s", e)


def train_gail() -> None:
    """Train an agent using GAIL."""

    logger.info("=" * 60)
    logger.info("UTDG GAIL Training Pipeline")
    logger.info("=" * 60)

    # Load config using the same method as trainer.py
    overrides = [arg for arg in sys.argv[1:] if "=" in arg]
    cfg = load_config(overrides=overrides)
    print(pretty_print_cfg(cfg))

    venv = None
    launcher = None

    try:
        # ------------------------------------------------------------
        # Load Demonstrations
        # ------------------------------------------------------------
        trajectory_path = "human_demonstrations.pkl"
        logger.info(f"\n[1/6] Loading demonstrations from {trajectory_path}...")

        try:
            demonstrations = serialize.load(trajectory_path)
        except FileNotFoundError:
            logger.error(f"Demonstration file {trajectory_path} not found!")
            logger.error("Please run record_demos.py first to collect human demonstrations.")
            return

        logger.info(f"  ✓ Loaded {len(demonstrations)} trajectories")

        # ------------------------------------------------------------
        # Setup launcher
        # ------------------------------------------------------------
        logger.info("\n[2/6] Setting up launcher...")
        launcher, connection_info = setup_launcher(cfg, logger)

        # ------------------------------------------------------------
        # Create environment
        # ------------------------------------------------------------
        logger.info("\n[3/6] Creating environment...")
        venv = create_environment(cfg, logger)

        if launcher is not None:
            logger.info("  ⏳ Waiting for Godot client to connect...")

        # ------------------------------------------------------------
        # Setup GAIL
        # ------------------------------------------------------------
        logger.info("\n[4/6] Setting up GAIL...")

        # Define Reward Network (GAIL uses basic reward network)
        reward_net = BasicRewardNet(
            observation_space=venv.observation_space,
            action_space=venv.action_space,
            normalize_input_layer=RunningNorm,
        )
        logger.info("  ✓ Reward network created")

        # Define Generator (Policy)
        # Using MlpPolicy for Flattened observation spaces
        learner = PPO(
            env=venv,
            policy="MlpPolicy",
            batch_size=cfg.model.get("batch_size", 64),
            ent_coef=cfg.model.get("ent_coef", 0.0),
            learning_rate=cfg.model.get("learning_rate", 0.0003),
            n_epochs=cfg.model.get("n_epochs", 10),
            verbose=cfg.training.get("verbose", 1),
        )
        logger.info("  ✓ PPO learner created")

        # Initialize GAIL Trainer
        # Check sufficient demonstrations
        total_transitions = sum(len(t) for t in demonstrations)
        if total_transitions < 1024:
            logger.warning(f"  ⚠ Few demonstrations: {total_transitions} transitions. Reducing batch size.")
            demo_batch_size = total_transitions
        else:
            demo_batch_size = 1024

        gail_trainer = GAIL(
            demonstrations=demonstrations,
            demo_batch_size=demo_batch_size,
            gen_replay_buffer_capacity=2048,
            n_disc_updates_per_round=4,
            venv=venv,
            gen_algo=learner,
            reward_net=reward_net,
            allow_variable_horizon=True,
        )
        logger.info("  ✓ GAIL trainer initialized")

        # ------------------------------------------------------------
        # Train
        # ------------------------------------------------------------
        total_timesteps = cfg.training.get("total_timesteps", 100_000)

        logger.info("\n[5/6] Starting GAIL training...")
        logger.info(f"  Total timesteps: {total_timesteps:,}")
        logger.info("=" * 60)

        gail_trainer.train(total_timesteps=total_timesteps)

        logger.info("=" * 60)
        logger.info("  ✓ Training complete")

        # ------------------------------------------------------------
        # Save and Evaluate
        # ------------------------------------------------------------
        logger.info("\n[6/6] Saving and evaluating...")

        # Save the trained policy
        save_path = "gail_policy"
        learner.save(save_path)
        logger.info(f"  ✓ Model saved to {save_path}")

        # Save the learned reward network
        reward_save_path = "gail_reward_net.pt"
        import torch
        torch.save(reward_net.state_dict(), reward_save_path)
        logger.info(f"  ✓ Reward network saved to {reward_save_path}")

        # Evaluate
        logger.info("\n  Evaluating trained policy...")
        mean_reward, std_reward = evaluate_policy(learner, venv, n_eval_episodes=5)
        logger.info(f"  Mean Reward: {mean_reward:.2f} +/- {std_reward:.2f}")

        logger.info("\n" + "=" * 60)
        logger.info("GAIL Training Pipeline Completed Successfully")
        logger.info("=" * 60)

    except KeyboardInterrupt:
        logger.info("\nTraining interrupted by user (Ctrl+C)")

    except Exception as e:
        logger.error(f"\nTraining failed: {e}")
        import traceback
        traceback.print_exc()

    finally:
        # Cleanup
        logger.info("")
        cleanup_resources(venv, launcher, logger)
        logger.info("Done.")


if __name__ == "__main__":
    train_gail()
