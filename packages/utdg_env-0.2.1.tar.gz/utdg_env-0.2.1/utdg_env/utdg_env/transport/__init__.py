"""
Transport module for UTDG.

Provides runtime-selectable client/server WebSocket backends.

Running as a module:

    python -m utdg_env.transport check [mode]
"""
