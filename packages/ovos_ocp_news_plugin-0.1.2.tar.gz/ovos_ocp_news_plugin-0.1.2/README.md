# OCP News Plugin

allows OCP to play urls for some news providers, this plugin will extract the real stream at playback time