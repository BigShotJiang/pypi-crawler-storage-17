"""Entry point for `python -m crossref_cite`."""

from crossref_cite.server import main

if __name__ == "__main__":
    main()
