Place any Oodle binaries in this folder for HGPAKtool to pick them up.
