XRTProductRequest API
=====================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

MODULE
------

.. automodule:: xrt_prods
  :members:
  :no-undoc-members:

.. autofunction:: listOldJobs

.. autofunction:: countActiveJobs


CLASS
-----


.. autoclass:: xrt_prods.XRTProductRequest
   :members:
