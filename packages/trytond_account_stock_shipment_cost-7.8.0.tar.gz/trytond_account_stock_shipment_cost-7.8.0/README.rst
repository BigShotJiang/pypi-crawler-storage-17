##################################
Account Stock Shipment Cost Module
##################################

The *Account Stock Shipment Cost Module* allocates shipment cost based on
invoice.

.. toctree::
   :maxdepth: 2

   design
   releases
