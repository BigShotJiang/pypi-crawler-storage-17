import fastlabel

client = fastlabel.Client()

client.delete_dataset(dataset_id="YOUR_DATASET_ID")
