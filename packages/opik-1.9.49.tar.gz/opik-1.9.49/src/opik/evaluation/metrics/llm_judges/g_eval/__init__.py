"""Public exports for the GEval metric package."""

from .metric import GEval

__all__ = ["GEval"]
