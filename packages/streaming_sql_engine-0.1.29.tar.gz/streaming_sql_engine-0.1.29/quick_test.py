from streaming_sql_engine import Engine
e = Engine()
print('✓ Engine imports and initializes')
print(f'✓ Default use_polars: {e.use_polars}')
print('✓ Ready for 1.0.0 release')

