from bluer_ugv.README.ugvs.comparison.features.classes import Feature


class ConcealmentFeature(Feature):
    nickname = "concealment"
    long_name = "قابلیت استتار و کمین درازمدت"

    comparison_as_str = {}
