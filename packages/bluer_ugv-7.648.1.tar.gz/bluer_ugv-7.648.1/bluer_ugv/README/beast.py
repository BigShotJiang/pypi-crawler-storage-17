docs = [
    {
        "path": "../docs/beast",
    },
]
