docs = [
    {
        "path": "../docs/aliases",
    },
    {
        "path": "../docs/aliases/swallow.md",
    },
    {
        "path": "../docs/aliases/ugv.md",
    },
]
