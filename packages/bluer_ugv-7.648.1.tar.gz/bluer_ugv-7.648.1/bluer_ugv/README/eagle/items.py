from bluer_objects.README.items import ImageItems

from bluer_ugv.README.eagle.consts import eagle_assets2

items = ImageItems(
    {
        f"{eagle_assets2}/file_0000000007986246b45343b0c06325dd.png": "",
        f"{eagle_assets2}/20250727_182113.jpg": "",
        f"{eagle_assets2}/20250726_171953.jpg": "",
    }
)
