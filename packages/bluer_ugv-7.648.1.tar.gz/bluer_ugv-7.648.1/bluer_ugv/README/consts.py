from bluer_objects.README.consts import assets_url, github_kamangir


algo_docs = f"{github_kamangir}/bluer-algo/blob/main/bluer_algo/docs"

bluer_ugv_assets = assets_url("bluer-ugv")

bluer_ugv_assets2 = assets_url(
    suffix="bluer-ugv",
    volume=2,
)
