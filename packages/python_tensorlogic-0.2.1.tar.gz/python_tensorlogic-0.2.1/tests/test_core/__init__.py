"""Tests for core tensor logic operations."""
