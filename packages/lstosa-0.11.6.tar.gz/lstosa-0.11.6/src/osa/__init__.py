"""
lstosa - Prototype pipeline for the LST on-site data processing

Licensed under a 3-clause BSD style license - see LICENSE
"""

from .version import __version__


__all__ = ["__version__"]
