`acmax24` is a python library for managing the AVPro Edge AC-MAX-24 Audio Matrix.  This is a 24 input, 24 output audio matrix device, designed for whole home audio.

This library was created to enable the the `hass-acmax24` Home Assistant integration, which makes the AC-MAX-24 Audio Matrix appear as a set of MediaPlayer entities in Home Assistant. 


