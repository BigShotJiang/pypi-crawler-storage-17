"""Shared test data modules.

Import sample configs using module-level objects in `python_object_samples`.
"""
