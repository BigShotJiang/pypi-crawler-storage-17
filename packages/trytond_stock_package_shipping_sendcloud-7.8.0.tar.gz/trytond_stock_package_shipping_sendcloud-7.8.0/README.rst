#######################################
Stock Package Shipping Sendcloud Module
#######################################

The *Stock Package Shipping Sendcloud Module* allows package labels to be
generated for shipments made by any of `Sendcloud's
<https://www.sendcloud.com/>`_ supported carriers.

.. toctree::
   :maxdepth: 2

   configuration
   design
   releases
