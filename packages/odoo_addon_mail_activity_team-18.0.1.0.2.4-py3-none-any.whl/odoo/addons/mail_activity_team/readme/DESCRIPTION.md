This module adds the possibility to assign teams to activities.
