"""Client components for taskman (REST adapters)."""

