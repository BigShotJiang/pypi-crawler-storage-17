# Default Globus Compute Executor configuration
DEFAULT_USER_CONFIG = {
    "worker_init": "",
    "endpoint_setup": "",
}

# default maximum execution time for remote functions (in seconds)
DEFAULT_WALLTIME_SEC = 300
