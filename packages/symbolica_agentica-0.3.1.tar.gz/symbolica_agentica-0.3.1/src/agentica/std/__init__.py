from agentica_internal.warpc import forbidden

forbidden.whitelist_modules("agentica.std.")
