"""
让托管平台可以用 `python -m stock_mcp` 一条命令拉起服务
"""

from stock_mcp.app import main

if __name__ == "__main__":
    main()
