
tensorial
=========

.. image:: https://codecov.io/gh/muhrin/tensorial/branch/develop/graph/badge.svg
    :target: https://codecov.io/gh/muhrin/tensorial
    :alt: Coverage

.. image:: https://github.com/muhrin/tensorial/actions/workflows/ci.yml/badge.svg
    :target: https://github.com/muhrin/tensorial/actions/workflows/ci.yml
    :alt: Tests

.. image:: https://readthedocs.org/projects/tensorial/badge/
    :target: https://tensorial.readthedocs.io/
    :alt: Documentation

.. image:: https://img.shields.io/pypi/v/tensorial.svg
    :target: https://pypi.python.org/pypi/tensorial/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/pyversions/tensorial.svg
    :target: https://pypi.python.org/pypi/tensorial/

.. image:: https://img.shields.io/pypi/l/tensorial.svg
    :target: https://pypi.python.org/pypi/tensorial/

.. image:: https://img.shields.io/badge/code%20style-black-000000.svg
    :target: https://github.com/psf/black

Library for machine learning on physical tensors
