See https://time-machine.readthedocs.io/en/latest/changelog.html
