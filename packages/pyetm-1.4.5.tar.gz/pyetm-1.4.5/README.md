# pyETM
Connect to the Energy Transition Model via Python. 

## Energy Transition Model
See https://energytransitionmodel.com/ for more information.

## Installation
pyETM is available through pip and is compatible with Python 3.

``pip install pyetm``
