"""IO utilities and glyph outline helpers."""
