from osm_shortlink._lib import shortlink_decode, shortlink_encode

__all__ = (
    'shortlink_decode',
    'shortlink_encode',
)
