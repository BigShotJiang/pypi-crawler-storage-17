"""__init__ module for winipyside6.core."""
