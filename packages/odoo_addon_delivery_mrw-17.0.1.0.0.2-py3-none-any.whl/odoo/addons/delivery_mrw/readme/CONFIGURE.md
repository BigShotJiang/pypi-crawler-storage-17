Para configurar el transportista:

1.  Vaya a *Inventario \> Configuración \> Entrega \> Método de envío* y
    cree uno nuevo.
2.  Escoja *MRW* Como proveedor.
3.  Configure los datos de servicio que tiene contratados y el producto
    de envío que desea utilizar.

Si no tiene credenciales todavía, puede usar el transportista de demo
"MRW Test".

Se debe tener en cuenta que este método de envío solo está disponible
para envío con origen y destino dentro de España y que la API no
facilita métodos para cotizar el coste real de los envíos.
