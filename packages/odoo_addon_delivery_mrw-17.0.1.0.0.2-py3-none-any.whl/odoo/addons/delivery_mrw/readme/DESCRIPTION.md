Este módulo integra la API de MRW España con Odoo. No es válido para
integraciones de MRW en otros países, que podrían usar otras APIs.
