- En la documentación SAGEC versión 2.5 se recoge la información
  necesaria para crear un envío internacional.

  Pero en la documentación más reciente (v 4.1) parece que esta
  funcionalidad ya no se soporta. De todas formas, se ha mantenido el
  código por si lo volvieran a incluir y se ha escondido el botón "Envío
  Internacional" del formulario del método de envío para que no pueda
  ser seleccionado y evitar confusiones.
