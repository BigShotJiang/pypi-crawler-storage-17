"""Test fixtures für questra-data."""
