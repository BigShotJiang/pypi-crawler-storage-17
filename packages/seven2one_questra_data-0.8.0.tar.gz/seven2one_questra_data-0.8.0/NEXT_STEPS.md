# Nächste Schritte

- questra-client auslagern, damit Code-base nicht zu groß wird
- Zeitreihenwerte lesen: Verbindung Items-Abfrage der ZR-Properties zu intern REST-API
- Test: Relationen setzen, Arrays setzen
- mutations, queries intern behalten, dafür bessere Abfragen direkt auf client
- Typisierung bei ZR-Werte lesen
