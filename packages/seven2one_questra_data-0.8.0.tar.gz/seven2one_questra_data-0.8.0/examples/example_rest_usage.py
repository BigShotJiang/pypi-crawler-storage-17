"""
Beispiel für die Verwendung der Dyno REST-API.

Demonstriert die wichtigsten REST-Operationen:
- TimeSeries: Daten abrufen and setzen, Quotierungen abrufen
- Files: Dateien hochladen and herunterladen
- Audit: Audit-Daten abrufen
"""

from __future__ import annotations

import os
from datetime import datetime, timedelta

from seven2one.questra.authentication import QuestraAuthentication

from seven2one.questra.data import (  # TimeSeries-Modelle (gemeinsam genutzt of GraphQL and REST); REST-spezifische Modelle
    Aggregation,
    Interval,
    Quality,
    QuestraDataCore,
    SetTimeSeriesDataInput,
    TimeSeriesValue,
    TimeUnit,
)


def main():
    """Hauptfunktion with Beispielen für REST-API."""

    # QuestraAuthentication für Authentifizierung erstellen
    auth_client = QuestraAuthentication(
        url="https://authentik.dev.techstack.s2o.dev",
        username=os.getenv("DATA_USERNAME", "ServiceUser"),
        password=os.getenv("DATA_PASSWORD", "secret"),
        oidc_discovery_paths=["/application/o/dyno"],
    )

    # QuestraDataCore initialisieren
    client = QuestraDataCore(
        graphql_url="https://dev.techstack.s2o.dev/dynamic-objects-v2/graphql",
        rest_base_url="https://dev.techstack.s2o.dev/dynamic-objects-v2/",
        auth_client=auth_client,
    )

    print(f"QuestraDataCore initialisiert: {client}")
    print(f"REST Base URL: {client.rest_base_url}")
    print()

    # ===== TimeSeries Beispiele =====
    print("=" * 60)
    print("TimeSeries Beispiele")
    print("=" * 60)

    # Beispiel 1: Zeitreihen-Daten abrufen
    print("\n1. Zeitreihen-Daten abrufen")
    try:
        from_time = datetime(2024, 1, 1)
        to_time = datetime(2024, 1, 31)

        data = client.timeseries.get_data(
            time_series_ids=[123, 456],
            from_time=from_time,
            to_time=to_time,
            aggregation=Aggregation.AVERAGE,
            exclude_qualities=[Quality.FAULTY],
        )

        print(f"Daten für {len(data.data)} TimeSeries abgerufen")
        for ts_data in data.data:
            values_count = len(ts_data.values) if ts_data.values else 0
            print(f"  - TimeSeries {ts_data.time_series_id}: {values_count} Werte")
            if ts_data.values:
                first_value = ts_data.values[0]
                print(f"    Erster Wert: {first_value.time} = {first_value.value}")

    except Exception as e:
        print(f"Fehler beim Abrufen of Zeitreihen-Daten: {e}")

    # Beispiel 2: Zeitreihen-Daten setzen
    print("\n2. Zeitreihen-Daten setzen")
    try:
        now = datetime.now()
        values = [
            TimeSeriesValue(
                time=now - timedelta(hours=i),
                value=100.0 + i * 5,
                quality=Quality.VALID,
            )
            for i in range(5)
        ]

        data_input = SetTimeSeriesDataInput(  # type: ignore[call-arg]
            timeSeriesId=123,
            values=values,
            interval=Interval(timeUnit=TimeUnit.HOUR, multiplier=1),  # type: ignore[call-arg]
        )

        client.timeseries.set_data([data_input])
        print(f"{len(values)} Werte erfolgreich gesetzt")

    except Exception as e:
        print(f"Fehler beim Setzen of Zeitreihen-Daten: {e}")

    # Beispiel 3: Quotierungen abrufen
    print("\n3. Quotierungen abrufen")
    try:
        quotations = client.timeseries.get_quotations(
            time_series_ids=[123],
            from_time=datetime(2024, 1, 1),
            to_time=datetime(2024, 1, 31),
            aggregated=False,
        )

        print(f"Quotierungen für {len(quotations.items)} TimeSeries abgerufen")
        for quot in quotations.items:
            values_count = len(quot.values) if quot.values else 0
            print(f"  - TimeSeries {quot.time_series_id}: {values_count} Quotierungen")

    except Exception as e:
        print(f"Fehler beim Abrufen of Quotierungen: {e}")

    # ===== File Beispiele =====
    print("\n" + "=" * 60)
    print("File Beispiele")
    print("=" * 60)

    # Beispiel 4: Datei hochladen
    print("\n4. Datei hochladen")
    try:
        # Erstelle temporäre Test-Datei
        test_file = "test_document.txt"
        with open(test_file, "w") as f:
            f.write("Dies ist ein Test-Dokument für den Dyno REST-API Upload.")

        uploaded_file = client.files.upload_single(
            name="MyNamespace.MyInventory.DocumentProperty",
            file_data=test_file,
            filename="test_document.txt",
            content_type="text/plain",
        )

        print(f"Datei hochgeladen: ID={uploaded_file.id}, Name={uploaded_file.name}")
        print(f"  Größe: {uploaded_file.size} bytes")
        print(
            f"  Hash: {uploaded_file.hash_algorithm} = {str(uploaded_file.hash_base64)[:20]}..."
        )

        # Cleanup
        os.remove(test_file)

        # Beispiel 5: Datei herunterladen
        print("\n5. Datei herunterladen")
        downloaded_content = client.files.download(uploaded_file.id)
        print(f"Datei heruntergeladen: {len(downloaded_content)} bytes")
        print(f"Inhalt: {downloaded_content[:100].decode('utf-8')}...")

    except Exception as e:
        print(f"Fehler at File-Operationen: {e}")

    # ===== Audit Beispiele =====
    print("\n" + "=" * 60)
    print("Audit Beispiele")
    print("=" * 60)

    # Beispiel 6: TimeSeries Audit-Metadaten abrufen
    print("\n6. TimeSeries Audit-Metadaten abrufen")
    try:
        ts_metadata = client.audit.get_timeseries(time_series_id=123)
        print("TimeSeries Metadaten:")
        print(f"  ID: {ts_metadata.id}")
        print(
            f"  Interval: {ts_metadata.interval.multiplier} {ts_metadata.interval.time_unit.value}"
        )
        print(f"  Unit: {ts_metadata.unit}")
        print(f"  Aggregation: {ts_metadata.default_aggregation.value}")
        print(f"  Audit aktiviert: {ts_metadata.audit_enabled}")

    except Exception as e:
        print(f"Fehler beim Abrufen of Audit-Metadaten: {e}")

    # Beispiel 7: TimeSeries Audit-Daten abrufen
    print("\n7. TimeSeries Audit-Daten abrufen")
    try:
        audit_data = client.audit.get_timeseries_data(
            time_series_id=123,
            from_time=datetime(2024, 1, 1),
            to_time=datetime(2024, 1, 31),
            audit_time=datetime(2024, 1, 15, 12, 0, 0),
            audit_exactly_at=False,  # Letzte Audit-Version vor dem Zeitpunkt
        )

        print(f"Audit-Daten für {len(audit_data.data)} TimeSeries abgerufen")
        for ts_data in audit_data.data:
            values_count = len(ts_data.values) if ts_data.values else 0
            print(
                f"  - TimeSeries {ts_data.time_series_id}: {values_count} Auditvalues"
            )

    except Exception as e:
        print(f"Fehler beim Abrufen of Audit-Daten: {e}")

    # Beispiel 8: File Audit-Daten abrufen
    print("\n8. File Audit-Daten abrufen")
    try:
        file_audit = client.audit.get_file(file_id=456)
        print(f"File Audit-Daten abgerufen: {len(file_audit)} bytes")

    except Exception as e:
        print(f"Fehler beim Abrufen of File-Audit-Daten: {e}")

    print("\n" + "=" * 60)
    print("REST-API Beispiele abgeschlossen!")
    print("=" * 60)


if __name__ == "__main__":
    main()
