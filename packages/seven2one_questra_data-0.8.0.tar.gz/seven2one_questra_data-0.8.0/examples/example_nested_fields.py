"""
Beispiel für die Verwendung of verschachtelten Properties with Punkt-Notation.

Zeigt like TimeSeries-Properties and andere verschachtelte Objekte abgefragt werden können.
"""

from __future__ import annotations

from seven2one.questra.authentication import QuestraAuthentication

from seven2one.questra.data import QuestraDataCore


def main():
    """Beispiel für verschachtelte Properties."""

    # Client initialisieren
    auth_client = QuestraAuthentication(
        url="https://authentik.dev.example.com",
        username="ServiceUser",
        password="secret",
    )

    client = QuestraDataCore(
        graphql_url="https://dev.example.com/dynamic-objects/graphql/",
        auth_client=auth_client,
    )

    print("=" * 60)
    print("Beispiel: Verschachtelte Properties with Punkt-Notation")
    print("=" * 60)
    print()

    # Beispiel 1: TimeSeries-Properties abfragen
    print("1. TimeSeries-Properties abfragen")
    print("-" * 60)
    try:
        result = client.inventory.list(
            inventory_name="TestUser",
            namespace_name="TestNamespace",
            properties=[
                "_id",
                "_rowVersion",
                "Name",
                "Email",
                # TimeSeries-Properties with Punkt-Notation
                "BodyBattery.id",  # ID der TimeSeries
                "BodyBattery.unit",  # Einheit (z.B. "kW")
                "BodyBattery.interval.timeUnit",  # Zeiteinheit (MINUTE, HOUR, etc.)
                "BodyBattery.interval.multiplier",  # Multiplikator (z.B. 15 für 15 Minuten)
                "BodyBattery.valueAlignment",  # Wert-Ausrichtung
                "BodyBattery.defaultAggregation",  # Standard-Aggregation
            ],
            first=5,
        )

        print(f"Anzahl Ergebnisse: {len(result['nodes'])}")
        print()

        for item in result["nodes"]:
            print(f"Item ID: {item['_id']}")
            print(f"  Name: {item.get('Name', 'N/A')}")
            print(f"  Email: {item.get('Email', 'N/A')}")

            # Zugriff auf verschachtelte TimeSeries-Daten
            body_battery = item.get("BodyBattery", {})
            if body_battery:
                print("  BodyBattery:")
                print(f"    ID: {body_battery.get('id')}")
                print(f"    Unit: {body_battery.get('unit')}")

                interval = body_battery.get("interval", {})
                if interval:
                    print(
                        f"    Interval: {interval.get('multiplier')} {interval.get('timeUnit')}"
                    )

                print(f"    ValueAlignment: {body_battery.get('valueAlignment')}")
                print(
                    f"    DefaultAggregation: {body_battery.get('defaultAggregation')}"
                )
            print()

    except Exception as e:
        print(f"Fehler: {e}")
        print()

    # Beispiel 2: Mehrere verschachtelte Objekte
    print("2. Mehrere verschachtelte Objekte abfragen")
    print("-" * 60)
    try:
        result = client.inventory.list(
            inventory_name="EnergyData",
            namespace_name="TestNamespace",
            properties=[
                "_id",
                "Name",
                "PowerOutput.id",
                "PowerOutput.unit",
                "PowerOutput.interval.timeUnit",
                "EnergyConsumption.id",
                "EnergyConsumption.unit",
                "EnergyConsumption.interval.timeUnit",
            ],
            first=3,
        )

        for item in result["nodes"]:
            print(f"Energy Data: {item.get('Name')}")

            power = item.get("PowerOutput", {})
            if power:
                interval = power.get("interval", {})
                print(
                    f"  PowerOutput: {power.get('unit')} - {interval.get('timeUnit')}"
                )

            consumption = item.get("EnergyConsumption", {})
            if consumption:
                interval = consumption.get("interval", {})
                print(
                    f"  EnergyConsumption: {consumption.get('unit')} - {interval.get('timeUnit')}"
                )
            print()

    except Exception as e:
        print(f"Fehler: {e}")
        print()

    # Beispiel 3: Tief verschachtelte Properties (3+ Ebenen)
    print("3. Tief verschachtelte Strukturen")
    print("-" * 60)
    print("Unterstützt beliebig tiefe Verschachtelung:")
    print("  - Ebene 1: BodyBattery")
    print("  - Ebene 2: BodyBattery.interval")
    print("  - Ebene 3: BodyBattery.interval.timeUnit")
    print()
    print("GraphQL-Query wird automatisch generiert:")
    print("  bodyBattery {")
    print("    interval {")
    print("      timeUnit")
    print("    }")
    print("  }")
    print()

    # Beispiel 4: Gemischte Properties
    print("4. Gemischte einfache and verschachtelte Properties")
    print("-" * 60)
    try:
        result = client.inventory.list(
            inventory_name="TestUser",
            namespace_name="TestNamespace",
            properties=[
                # Einfache Properties
                "_id",
                "Name",
                "Email",
                "Age",
                "IsActive",
                # Verschachtelte Properties
                "BodyBattery.id",
                "BodyBattery.unit",
            ],
            where={"isActive": {"eq": True}},
            first=10,
        )

        print(f"Aktive Benutzer with BodyBattery: {len(result['nodes'])}")

    except Exception as e:
        print(f"Fehler: {e}")

    print()
    print("=" * 60)
    print("Beispiele abgeschlossen!")
    print("=" * 60)


if __name__ == "__main__":
    main()
