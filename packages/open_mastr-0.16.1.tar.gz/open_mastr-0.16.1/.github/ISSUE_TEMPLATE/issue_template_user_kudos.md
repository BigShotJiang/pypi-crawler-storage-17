---
name: User Kudos
about: Share appreciation for the project!
title: Add new user to USERS.cff
labels: user
assignees: ''

---

Thanks for supporting the project and helping to improve its recognition by joining USERS.cff.
It helps the project quite a bit!

We will add you to the list of valued users.

Please, insert your information below - fill out at minimum affiliation :purple_heart:

:pencil2: **Spaces** and the following special characters are allowed: @ ? ! | . , : ; - _ [ / ( ) \ ] § $ % & = + < >

family-names: 
given-names: 
alias: 
affiliation: 
orcid: 

Thank you!
