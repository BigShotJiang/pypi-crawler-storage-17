## Release notes and version history

### API download versions

#### dataversion-2022-05-16-BA
- Complete restructure of the software
- Include XML download
- Switch to CalVer for data versioning #221
- Update to OEMetadata v1.5.1

#### dataversion-2.2.0 (2019-12-05)
- Code version [v0.9.0](https://github.com/OpenEnergyPlatform/open-MaStR/releases/tag/v0.9.0)
- Includes: wind; hydro; biomass
- new power-unit download: true
#### dataversion-2.1.2 
- Code version [v0.9.0](https://github.com/OpenEnergyPlatform/open-MaStR/releases/tag/v0.9.0)
- Includes: wind; hydro; biomass
####  dataversion-1.5
- Includes: wind-permits; storages; solar; basic postprocessing
####  dataversion-1.4 
 - Includes: permit data for wind and updated metadata
####  dataversion-1.3
####  dataversion-1.2
####  dataversion-1.1
####  dataversion-1.0
Test version





