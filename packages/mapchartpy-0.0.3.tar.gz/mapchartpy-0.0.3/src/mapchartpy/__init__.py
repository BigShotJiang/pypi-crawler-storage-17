from .savefile import *
from .save import Save as Map

schema = savefile

__version__ = "0.0.3"
__all__ = [
    "Map"
]