To use this module, you need to:

1.  Have Manager rights for Sales group to create tags.
2.  Go to the sales order form and add the necessary tags.
