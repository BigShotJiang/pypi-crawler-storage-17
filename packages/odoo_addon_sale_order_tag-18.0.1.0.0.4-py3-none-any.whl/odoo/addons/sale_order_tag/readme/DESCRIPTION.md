This module adds tags to Sales Orders that are not related to
Opportunity.
