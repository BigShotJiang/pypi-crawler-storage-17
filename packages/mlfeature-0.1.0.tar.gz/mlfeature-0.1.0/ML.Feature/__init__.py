"""ML.Feature - A machine learning feature engineering package."""

__version__ = "0.1.0"

from .run import main

__all__ = ["__version__", "main"]
