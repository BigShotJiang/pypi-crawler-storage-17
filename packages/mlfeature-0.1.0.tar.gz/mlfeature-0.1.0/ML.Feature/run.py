# Core module for ML.Feature package
# This is the main entry point for the package


def main():
    """Main entry point for the ML.Feature package."""
    print("Welcome to ML.Feature package!")
    pass


if __name__ == "__main__":
    main()
