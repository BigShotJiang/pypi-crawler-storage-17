# MLFeature

A machine learning feature engineering package.

## Installation

```bash
pip install MLFeature
```

## Usage

```python
import ML.Feature
from ML.Feature import main

# Use the package
main()
```

## License

MIT License
