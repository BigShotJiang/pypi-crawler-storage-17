from __future__ import annotations

from logging import getLogger

LOGGER = getLogger("uv_publish")


__all__ = ["LOGGER"]
