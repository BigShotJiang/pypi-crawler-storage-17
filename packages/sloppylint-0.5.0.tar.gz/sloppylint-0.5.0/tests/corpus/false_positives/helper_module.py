"""Helper module for local import tests."""


def helper_function() -> str:
    """Return a helper string."""
    return "helper"
