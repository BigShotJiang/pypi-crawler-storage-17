# Be nice to each other

Everyone participating in the _sqlparse_ project and especially in the
issue tracker, discussion forums, pull requests, is expected to treat
other people with respect and more generally to follow the guidelines 
articulated in the 
[Python Community Code of Conduct](https://www.python.org/psf/codeofconduct/).