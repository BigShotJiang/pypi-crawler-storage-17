# Contributing to `sqlparse`

Thanks for your interest in contributing to the `sqlparse` project!

All contributors are expected to follow the 
[Python Community Code of Conduct](https://www.python.org/psf/codeofconduct/).

Head over to the 
[Discussions Page](https://github.com/andialbrecht/sqlparse/discussions) if
you have any questions. We're still working on a more elaborate 
developer guide.