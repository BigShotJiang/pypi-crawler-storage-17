from .finetune_executor import FinetuneExecutor


def get_object():
    return FinetuneExecutor()
