# mlmanagement

implementation of model pattern, dataset