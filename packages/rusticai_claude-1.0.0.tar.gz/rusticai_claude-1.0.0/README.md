# claude

Claude Integration

## Configure claude code to use vertex ai
Set the following environment variables:

```bash
export CLAUDE_CODE_USE_VERTEX=1
export CLOUD_ML_REGION=global
export ANTHROPIC_VERTEX_PROJECT_ID=YOUR-PROJECT-ID
```

refer docs for more info: https://code.claude.com/docs/en/google-vertex-ai