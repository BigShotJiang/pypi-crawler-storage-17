import logging

logger = logging.getLogger("tracerite")
logger.setLevel(logging.INFO)
