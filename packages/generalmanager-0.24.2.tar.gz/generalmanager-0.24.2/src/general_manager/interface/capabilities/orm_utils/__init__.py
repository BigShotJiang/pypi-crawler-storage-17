"""ORM capability support utilities (field descriptors, payload normalization)."""

__all__ = [
    "django_manager_utils",
    "field_descriptors",
    "payload_normalizer",
]
