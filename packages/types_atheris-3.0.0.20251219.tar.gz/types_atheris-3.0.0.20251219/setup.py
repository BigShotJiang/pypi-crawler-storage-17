
from setuptools import setup

setup(package_data={'atheris-stubs': ['__init__.pyi', 'function_hooks.pyi', 'import_hook.pyi', 'instrument_bytecode.pyi', 'utils.pyi', 'version_dependent.pyi', 'METADATA.toml', 'py.typed']})
