## 3.0.0.20251219 (2025-12-19)

[atheris] Update to 3.0.* ([#15141](https://github.com/python/typeshed/pull/15141))

Restore atheris stubs ([#15140](https://github.com/python/typeshed/pull/15140))

## 2.3.0.20250306 (2025-03-06)

Update tools versions in `stubtest` workflow (#13582)

## 2.3.0.20240831 (2024-08-31)

Added types for atheris (#12462)

