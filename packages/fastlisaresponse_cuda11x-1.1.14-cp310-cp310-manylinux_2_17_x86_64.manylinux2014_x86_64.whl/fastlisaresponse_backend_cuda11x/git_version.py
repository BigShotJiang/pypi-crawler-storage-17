"""Metadata deduced from git at build time."""

id: str
short_id: str

id = "b73cffeda71e2653428d8e35022a8be1c71a579f"
short_id = "b73cffe"
