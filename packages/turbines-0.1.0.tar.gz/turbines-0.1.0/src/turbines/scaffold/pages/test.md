---
title: Example Markdown Page
author: Turbines Tester
date: 2024-06-11
template: base.html
---

## Example Markdown Page

This is a test page.
It uses a template.
The title should be "Test".

This is some more content.

Let's see if it works.

## my favorite things

Here is a list:

-   Item 1
-   Item 2
-   Item 3
-   Item 4
-   Item 5

And a link: [OpenAI](https://www.openai.com)

Thank you for testing!

### Subsection

This is a subsection under "my favorite things".

### Conclusion

That's all for now.
