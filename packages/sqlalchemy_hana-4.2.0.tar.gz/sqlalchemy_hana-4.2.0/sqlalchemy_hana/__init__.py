"""SQLAlchemy dialect for SAP HANA."""

from __future__ import annotations
