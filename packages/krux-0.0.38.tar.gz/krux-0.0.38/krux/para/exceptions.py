class MissingRequiredParaField(Exception): pass
class ParaFieldValueOutOfBound(Exception): pass

class InvalidParaField(Exception): pass