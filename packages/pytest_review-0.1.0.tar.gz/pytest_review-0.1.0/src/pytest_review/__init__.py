"""pytest-review: A pytest plugin that reviews the quality of tests."""

__version__ = "0.1.0"
