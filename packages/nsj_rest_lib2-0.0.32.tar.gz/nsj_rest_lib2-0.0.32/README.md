# nsj_rest_lib2

Biblioteca para permitir a distribuição de rotas dinâmicas numa API, configuradas por meio de EDLs declarativos (em formato JSON).

[ESPECIFICAÇÃO DO MODELO DE ENTIDADES](docs/especificacao.md)

