# Copyright (C) 2025 Intel Corporation
# SPDX-License-Identifier: MIT
"""Module for MFD Host."""

from .base import Host
