"""
PostgreSQL storage module initialization
"""

from .pgvector import PGVectorStore

__all__ = ["PGVectorStore"]
