# NOTE: Needed for type-checking
