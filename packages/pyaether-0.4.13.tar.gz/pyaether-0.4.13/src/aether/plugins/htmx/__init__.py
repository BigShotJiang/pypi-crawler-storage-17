# https://htmx.org/reference/#attributes and https://htmx.org/reference/#attributes-additional

from ._base import HTMXAttributes

__all__ = ["HTMXAttributes"]
