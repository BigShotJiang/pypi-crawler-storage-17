# Changelog

## [1.0.2](https://github.com/CoreySpohn/exosims-plugins/compare/v1.0.1...v1.0.2) (2025-12-16)


### Bug Fixes

* Update trig_solver to use the proper level with recent orbix updates ([3d13aa3](https://github.com/CoreySpohn/exosims-plugins/commit/3d13aa3a16ee089110d9762ddc4e5ac1ad328b6e))

## [1.0.1](https://github.com/CoreySpohn/exosims-plugins/compare/v1.0.0...v1.0.1) (2025-12-15)


### Bug Fixes

* Add intervaltree dependency to pyproject.toml ([09225f5](https://github.com/CoreySpohn/exosims-plugins/commit/09225f547749689eee094e20c1a0e84e354604ef))

## 1.0.0 (2025-10-07)


### Features

* Full implementation of orbix modules ([18450cb](https://github.com/CoreySpohn/exosims-plugins/commit/18450cb083a4d8d93f267d7f15923f3ec433efce))
