# Typed Blockchaincom

> A fully typed, validated async client for the Blockchaincom API

Use *autocomplete* instead of documentation.

🚧 Under construction.