******
Design
******

The *Sale Rental Progress Invoice Module* extends the following concepts.

.. _model-sale.rental:

Rental
======

When *Sale Rental Progress Invoice Module* is activated, the rental gains
properties to store progresses to invoice.

Wizards
-------

.. _wizard-sale.rental.add_progress:

Add Progress
^^^^^^^^^^^^

The *Add Progress* wizard calculate a duration to invoice for each line base on
the provided date.
