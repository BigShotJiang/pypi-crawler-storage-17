###################################
Sale Rental Progress Invoice Module
###################################

The *Sale Rental Progress Invoice Module* allow creating progress invoices for
rental orders.

.. toctree::
   :maxdepth: 2

   design
   releases
