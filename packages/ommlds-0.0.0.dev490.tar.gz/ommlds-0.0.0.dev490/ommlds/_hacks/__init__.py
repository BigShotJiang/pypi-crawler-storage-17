"""
Currently, and ideally, the only thing this codebase will ever interact with requiring these kinds of awful hacks is ML
code - thus these 'helpers' are kept here, not in the core library.
"""
