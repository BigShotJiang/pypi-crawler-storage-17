"""
Routir - A flexible search and retrieval service framework.

This package provides infrastructure for building search services with support
for multiple engines, processors, and pipeline configurations.
"""

# from .models import Engine
