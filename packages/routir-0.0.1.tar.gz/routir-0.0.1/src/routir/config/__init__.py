"""Configuration module for routir service."""

from .config import ColllectionConfig, Config, ServiceConfig
