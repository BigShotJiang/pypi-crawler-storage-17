from inference.models.sam.segment_anything import SegmentAnything
