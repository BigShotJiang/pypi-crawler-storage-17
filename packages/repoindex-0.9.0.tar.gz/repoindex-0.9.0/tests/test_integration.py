"""
Integration tests for ghops CLI commands
"""
import unittest
import tempfile
import os
import shutil
import subprocess
import json
from pathlib import Path
from unittest.mock import patch


class TestCLIIntegration(unittest.TestCase):
    """Integration tests for the CLI interface"""
    
    def setUp(self):
        """Set up test environment"""
        self.temp_dir = tempfile.mkdtemp()
        self.original_cwd = os.getcwd()
        os.chdir(self.temp_dir)
        
        # Create a fake git repository
        self.test_repo = os.path.join(self.temp_dir, "test_repo")
        os.makedirs(self.test_repo)
        os.makedirs(os.path.join(self.test_repo, ".git"))
        
        # Create a pyproject.toml file
        pyproject_content = """
[project]
name = "test-package"
version = "1.0.0"
description = "A test package"
"""
        with open(os.path.join(self.test_repo, "pyproject.toml"), "w") as f:
            f.write(pyproject_content)
        
        # Create a LICENSE file
        license_content = "MIT License\n\nCopyright (c) 2023 Test User"
        with open(os.path.join(self.test_repo, "LICENSE"), "w") as f:
            f.write(license_content)
    
    def tearDown(self):
        """Clean up test environment"""
        os.chdir(self.original_cwd)
        shutil.rmtree(self.temp_dir)
    
    def run_ghops_command(self, *args):
        """Helper to run ghops commands"""
        cmd = ["python", "-m", "repoindex.cli"] + list(args)
        env = os.environ.copy()
        # Add the project root to PYTHONPATH so the module can be found
        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        env['PYTHONPATH'] = project_root + (os.pathsep + env.get('PYTHONPATH', ''))
        result = subprocess.run(
            cmd,
            cwd=self.temp_dir,
            capture_output=True,
            text=True,
            env=env
        )
        return result
    
    def test_status_command_json_output(self):
        """Test status command with JSONL output"""
        # Use -d to specify the temp directory containing our test repo
        result = self.run_ghops_command("status", "-d", self.temp_dir, "--no-pypi", "--no-pages", "--no-table")

        self.assertEqual(result.returncode, 0)

        # Parse JSONL output (each line should be valid JSON)
        lines = result.stdout.strip().split('\n')
        if lines and lines[0]:  # If there's output
            for line in lines:
                if line.strip():  # Skip empty lines
                    try:
                        repo_data = json.loads(line)
                        self.assertIn('name', repo_data)
                        self.assertIn('status', repo_data)
                    except json.JSONDecodeError:
                        self.fail(f"Line is not valid JSON: {line}")
    
    def test_config_generate(self):
        """Test config generation"""
        result = self.run_ghops_command("config", "generate")
        
        self.assertEqual(result.returncode, 0)
        self.assertIn("example configuration", result.stdout.lower())
        
        # Check that example file was created in the temp_dir
        example_file = Path.home() / ".repoindexrc"
        self.assertTrue(example_file.exists())
    
    def test_config_show(self):
        """Test config show command"""
        result = self.run_ghops_command("config", "show")
        
        self.assertEqual(result.returncode, 0)
        
        # Should output JSON configuration
        try:
            config_data = json.loads(result.stdout)
            self.assertIn('pypi', config_data)
            self.assertIn('social_media', config_data)
            self.assertIn('logging', config_data)
        except json.JSONDecodeError:
            self.fail(f"Config show did not output valid JSON: {result.stdout}")
    
    def test_command_help(self):
        """Test that help is displayed for various commands"""
        # Main help
        result = self.run_ghops_command("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Collection-aware metadata index", result.stdout)
        
        # Status help
        result = self.run_ghops_command("status", "--help")
        self.assertEqual(result.returncode, 0)
        self.assertNotIn("--json", result.stdout)  # --json option removed
        
        # Config help
        result = self.run_ghops_command("config", "--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("generate", result.stdout)  # Check for config-specific options
    
    def test_invalid_command(self):
        """Test handling of invalid commands"""
        result = self.run_ghops_command("invalid_command")
        
        self.assertNotEqual(result.returncode, 0)
    
    def test_status_with_performance_flags(self):
        """Test status command with performance optimization flags"""
        # Use -d to specify the temp directory
        result = self.run_ghops_command("status", "-d", self.temp_dir, "--no-pypi", "--no-pages")

        self.assertEqual(result.returncode, 0)
        # Should complete faster without external API calls


class TestCLIErrorHandling(unittest.TestCase):
    """Test CLI error handling scenarios"""
    
    def setUp(self):
        """Set up test environment"""
        self.temp_dir = tempfile.mkdtemp()
        self.original_cwd = os.getcwd()
        os.chdir(self.temp_dir)
    
    def tearDown(self):
        """Clean up test environment"""
        os.chdir(self.original_cwd)
        shutil.rmtree(self.temp_dir)
    
    def run_ghops_command(self, *args):
        """Helper to run ghops commands"""
        cmd = ["python", "-m", "repoindex.cli"] + list(args)
        env = os.environ.copy()
        # Add the project root to PYTHONPATH so the module can be found
        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        env['PYTHONPATH'] = project_root + (os.pathsep + env.get('PYTHONPATH', ''))
        result = subprocess.run(
            cmd,
            cwd=self.temp_dir,
            capture_output=True,
            text=True,
            env=env
        )
        return result
    
    def test_status_no_repositories(self):
        """Test status command when no repositories are found"""
        # Use -d to specify the temp directory (which has no git repos)
        result = self.run_ghops_command("status", "-d", self.temp_dir, "--no-pypi", "--no-pages", "--no-table")

        # Exit code 64 = NO_REPOS_FOUND (expected when no repos in directory)
        self.assertEqual(result.returncode, 64)
        # Output should be a JSON error message
        try:
            error_data = json.loads(result.stdout)
            self.assertIn('error', error_data)
            self.assertEqual(error_data['type'], 'NoReposFoundError')
        except json.JSONDecodeError:
            self.fail(f"Output is not valid JSON: {result.stdout}")
    


if __name__ == '__main__':
    unittest.main()
