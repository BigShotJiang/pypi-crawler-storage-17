"""Embedded reference datasets shipped with PlasmidKit."""
