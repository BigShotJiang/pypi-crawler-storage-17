"""Tests that communicate with container plugin via the v3 API."""
