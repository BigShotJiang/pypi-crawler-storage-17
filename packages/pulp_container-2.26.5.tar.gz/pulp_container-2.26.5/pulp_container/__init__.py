default_app_config = "pulp_container.app.PulpContainerPluginAppConfig"
