nectar.wallet module
====================

.. automodule:: nectar.wallet
   :members:
   :show-inheritance:
   :undoc-members:
