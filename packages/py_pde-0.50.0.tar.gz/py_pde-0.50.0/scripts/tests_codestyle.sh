#!/usr/bin/env bash
#
# This script checks the code format of this package without changing files
#

./run_tests.py --style