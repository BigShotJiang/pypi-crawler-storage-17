Examples
========

These are example scripts using the `py-pde` package, which illustrates some of the most
important features of the package.


.. include:: /examples_gallery/fields/index.rst
.. include:: /examples_gallery/simple_pdes/index.rst
.. include:: /examples_gallery/output/index.rst
.. include:: /examples_gallery/advanced_pdes/index.rst

