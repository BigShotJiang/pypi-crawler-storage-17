# -*- coding: utf-8 -*-


from typing import Any


class BlockEntityData(object):
    def __getitem__(self, key):
        # type: (str) -> Any
        pass

    def __setitem__(self, key, value):
        # type: (str, Any) -> None
        pass
