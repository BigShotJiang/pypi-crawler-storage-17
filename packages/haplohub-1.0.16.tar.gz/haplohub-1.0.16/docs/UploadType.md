# UploadType


## Enum

* `RESULT` (value: `'result'`)

* `VCF` (value: `'vcf'`)

* `CSV` (value: `'csv'`)

* `FASTQ` (value: `'fastq'`)

* `ARCHIVE_23ANDME` (value: `'archive_23andme'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


