# AlgorithmResultId


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from haplohub.models.algorithm_result_id import AlgorithmResultId

# TODO update the JSON string below
json = "{}"
# create an instance of AlgorithmResultId from a JSON string
algorithm_result_id_instance = AlgorithmResultId.from_json(json)
# print the JSON string representation of the object
print AlgorithmResultId.to_json()

# convert the object into a dict
algorithm_result_id_dict = algorithm_result_id_instance.to_dict()
# create an instance of AlgorithmResultId from a dict
algorithm_result_id_from_dict = AlgorithmResultId.from_dict(algorithm_result_id_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


