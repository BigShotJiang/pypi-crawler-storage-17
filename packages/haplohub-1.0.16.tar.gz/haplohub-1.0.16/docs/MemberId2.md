# MemberId2


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from haplohub.models.member_id2 import MemberId2

# TODO update the JSON string below
json = "{}"
# create an instance of MemberId2 from a JSON string
member_id2_instance = MemberId2.from_json(json)
# print the JSON string representation of the object
print MemberId2.to_json()

# convert the object into a dict
member_id2_dict = member_id2_instance.to_dict()
# create an instance of MemberId2 from a dict
member_id2_from_dict = MemberId2.from_dict(member_id2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


