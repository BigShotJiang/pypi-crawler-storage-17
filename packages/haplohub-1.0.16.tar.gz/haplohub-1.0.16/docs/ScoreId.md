# ScoreId


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from haplohub.models.score_id import ScoreId

# TODO update the JSON string below
json = "{}"
# create an instance of ScoreId from a JSON string
score_id_instance = ScoreId.from_json(json)
# print the JSON string representation of the object
print ScoreId.to_json()

# convert the object into a dict
score_id_dict = score_id_instance.to_dict()
# create an instance of ScoreId from a dict
score_id_from_dict = ScoreId.from_dict(score_id_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


