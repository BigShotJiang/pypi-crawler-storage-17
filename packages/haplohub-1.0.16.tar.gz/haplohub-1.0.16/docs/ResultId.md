# ResultId


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from haplohub.models.result_id import ResultId

# TODO update the JSON string below
json = "{}"
# create an instance of ResultId from a JSON string
result_id_instance = ResultId.from_json(json)
# print the JSON string representation of the object
print ResultId.to_json()

# convert the object into a dict
result_id_dict = result_id_instance.to_dict()
# create an instance of ResultId from a dict
result_id_from_dict = ResultId.from_dict(result_id_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


