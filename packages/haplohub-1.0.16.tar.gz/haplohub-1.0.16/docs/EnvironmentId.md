# EnvironmentId


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from haplohub.models.environment_id import EnvironmentId

# TODO update the JSON string below
json = "{}"
# create an instance of EnvironmentId from a JSON string
environment_id_instance = EnvironmentId.from_json(json)
# print the JSON string representation of the object
print EnvironmentId.to_json()

# convert the object into a dict
environment_id_dict = environment_id_instance.to_dict()
# create an instance of EnvironmentId from a dict
environment_id_from_dict = EnvironmentId.from_dict(environment_id_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


