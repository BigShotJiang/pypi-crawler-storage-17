# SampleId2


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from haplohub.models.sample_id2 import SampleId2

# TODO update the JSON string below
json = "{}"
# create an instance of SampleId2 from a JSON string
sample_id2_instance = SampleId2.from_json(json)
# print the JSON string representation of the object
print SampleId2.to_json()

# convert the object into a dict
sample_id2_dict = sample_id2_instance.to_dict()
# create an instance of SampleId2 from a dict
sample_id2_from_dict = SampleId2.from_dict(sample_id2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


