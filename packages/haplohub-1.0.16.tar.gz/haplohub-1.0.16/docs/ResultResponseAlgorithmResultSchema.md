# ResultResponseAlgorithmResultSchema


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | [optional] 
**result** | [**AlgorithmResultSchema**](AlgorithmResultSchema.md) |  | 

## Example

```python
from haplohub.models.result_response_algorithm_result_schema import ResultResponseAlgorithmResultSchema

# TODO update the JSON string below
json = "{}"
# create an instance of ResultResponseAlgorithmResultSchema from a JSON string
result_response_algorithm_result_schema_instance = ResultResponseAlgorithmResultSchema.from_json(json)
# print the JSON string representation of the object
print ResultResponseAlgorithmResultSchema.to_json()

# convert the object into a dict
result_response_algorithm_result_schema_dict = result_response_algorithm_result_schema_instance.to_dict()
# create an instance of ResultResponseAlgorithmResultSchema from a dict
result_response_algorithm_result_schema_from_dict = ResultResponseAlgorithmResultSchema.from_dict(result_response_algorithm_result_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


