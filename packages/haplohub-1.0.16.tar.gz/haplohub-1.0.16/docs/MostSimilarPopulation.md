# MostSimilarPopulation


## Enum

* `AFR` (value: `'AFR'`)

* `AMR` (value: `'AMR'`)

* `CSA` (value: `'CSA'`)

* `EAS` (value: `'EAS'`)

* `EUR` (value: `'EUR'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


