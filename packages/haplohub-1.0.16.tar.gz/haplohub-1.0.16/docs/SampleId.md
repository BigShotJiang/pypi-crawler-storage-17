# SampleId


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from haplohub.models.sample_id import SampleId

# TODO update the JSON string below
json = "{}"
# create an instance of SampleId from a JSON string
sample_id_instance = SampleId.from_json(json)
# print the JSON string representation of the object
print SampleId.to_json()

# convert the object into a dict
sample_id_dict = sample_id_instance.to_dict()
# create an instance of SampleId from a dict
sample_id_from_dict = SampleId.from_dict(sample_id_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


