# ReportTemplateId


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from haplohub.models.report_template_id import ReportTemplateId

# TODO update the JSON string below
json = "{}"
# create an instance of ReportTemplateId from a JSON string
report_template_id_instance = ReportTemplateId.from_json(json)
# print the JSON string representation of the object
print ReportTemplateId.to_json()

# convert the object into a dict
report_template_id_dict = report_template_id_instance.to_dict()
# create an instance of ReportTemplateId from a dict
report_template_id_from_dict = ReportTemplateId.from_dict(report_template_id_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


