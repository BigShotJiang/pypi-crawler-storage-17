# PredictionStatus


## Enum

* `PENDING` (value: `'pending'`)

* `RUNNING` (value: `'running'`)

* `FAILED` (value: `'failed'`)

* `STOPPED` (value: `'stopped'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


