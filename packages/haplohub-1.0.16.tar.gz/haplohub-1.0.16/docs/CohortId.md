# CohortId


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from haplohub.models.cohort_id import CohortId

# TODO update the JSON string below
json = "{}"
# create an instance of CohortId from a JSON string
cohort_id_instance = CohortId.from_json(json)
# print the JSON string representation of the object
print CohortId.to_json()

# convert the object into a dict
cohort_id_dict = cohort_id_instance.to_dict()
# create an instance of CohortId from a dict
cohort_id_from_dict = CohortId.from_dict(cohort_id_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


