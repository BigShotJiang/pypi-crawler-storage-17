# AlgorithmVersionId


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from haplohub.models.algorithm_version_id import AlgorithmVersionId

# TODO update the JSON string below
json = "{}"
# create an instance of AlgorithmVersionId from a JSON string
algorithm_version_id_instance = AlgorithmVersionId.from_json(json)
# print the JSON string representation of the object
print AlgorithmVersionId.to_json()

# convert the object into a dict
algorithm_version_id_dict = algorithm_version_id_instance.to_dict()
# create an instance of AlgorithmVersionId from a dict
algorithm_version_id_from_dict = AlgorithmVersionId.from_dict(algorithm_version_id_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


