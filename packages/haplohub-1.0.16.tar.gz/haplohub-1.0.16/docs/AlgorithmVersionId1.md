# AlgorithmVersionId1


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from haplohub.models.algorithm_version_id1 import AlgorithmVersionId1

# TODO update the JSON string below
json = "{}"
# create an instance of AlgorithmVersionId1 from a JSON string
algorithm_version_id1_instance = AlgorithmVersionId1.from_json(json)
# print the JSON string representation of the object
print AlgorithmVersionId1.to_json()

# convert the object into a dict
algorithm_version_id1_dict = algorithm_version_id1_instance.to_dict()
# create an instance of AlgorithmVersionId1 from a dict
algorithm_version_id1_from_dict = AlgorithmVersionId1.from_dict(algorithm_version_id1_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


