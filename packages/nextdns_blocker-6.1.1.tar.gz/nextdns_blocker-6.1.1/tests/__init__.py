# Tests for nextdns-blocker
