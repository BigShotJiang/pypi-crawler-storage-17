2025-10-29 Version: 2.2.3
- Generated python 2020-03-06 for companyreg.

2025-10-29 Version: 2.2.2
- Generated python 2020-03-06 for companyreg.

2025-10-29 Version: 2.2.1
- Update API RecordCallCenterEventForPartner: add request parameters EmployeeCode.
- Update API RecordCallCenterEventForPartner: add request parameters TenantId.


2025-10-22 Version: 2.2.0
- Support API OperateCallCenterForPartner.
- Support API RecordCallCenterEventForPartner.


2025-08-07 Version: 2.1.1
- Update API QueryCallRecordList: add response parameters Body.Data.$.ContactDisposition.
- Update API QueryCallRecordList: add response parameters Body.Data.$.taskId.


2025-08-06 Version: 2.1.0
- Support API QueryCallRecordList.


2025-05-22 Version: 2.0.0
- Support API SubmitIntentionForPartner.
- Delete API QueryCommodityConfig.
- Update API ListIntentionNote: add request parameters BizType.
- Update API ListUserSolutions: add request parameters BizType.
- Update API RejectSolution: add request parameters BizType.
- Update API SubmitIntentionNote: add request parameters BizType.


2024-03-28 Version: 1.0.2
- Generated python 2020-03-06 for companyreg.

2024-03-28 Version: 1.0.2
- Generated python 2020-03-06 for companyreg.

2023-11-08 Version: 1.0.1
- Generated python 2020-03-06 for companyreg.

2023-03-02 Version: 1.0.0
- Ini V2 SDK .

