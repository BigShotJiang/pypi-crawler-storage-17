# Copyright Modal Labs 2025
"""Supplies the current version of the modal client library."""

__version__ = "1.2.6"
