from .dependency_registry import LeagueManager

__all__ = ["LeagueManager"]
