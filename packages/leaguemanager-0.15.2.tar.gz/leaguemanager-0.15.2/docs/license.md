# Functional Source License

```{rubric} Version 1.1, MIT Future License
:heading-level: 3
```

```{include} ../LICENSE
:start-after: Functional Source License, Version 1.1, MIT Future License
```
