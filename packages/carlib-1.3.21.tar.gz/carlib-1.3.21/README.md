# CarLib - Neural Media Codecs Serialization for ML Training

CarLib serializes neural encodings and file metadata into CAR archives. This structure minimizes storage and enables efficient random access, effectively removing preprocessing overhead during training loops.

## Quick Start

### Installation

**For Users (Recommended):**
```bash
# Full installation with all features
pip install carlib
```

**For Developers:**
```bash
# Clone and install for development
git clone https://github.com/gcxrightsify/carlib.git
cd carlib
pip install -e .  # Editable install with all dependencies
```

**Using Docker:**
```bash
# Clone the repository
git clone https://github.com/gcxrightsify/carlib.git
cd carlib

# Build the Docker image
docker build -t carlib:latest .

# Run carlib commands
docker run --rm -v $(pwd)/data:/data carlib:latest carlib --help

# Convert datasets using Docker
docker run --rm -v $(pwd)/input:/input -v $(pwd)/output:/data carlib:latest \
  carlib convert /input --modality vanilla --target-modality audio -o /data

# Interactive development mode
docker run --rm -it -v $(pwd):/app carlib:latest bash
```

### Prerequisites

CarLib requires **ffmpeg** to be installed on your system for audio, video, and image processing.

**macOS:**
```bash
# Using Homebrew (recommended)
brew install ffmpeg

# Using MacPorts
sudo port install ffmpeg
```

**Ubuntu/Debian:**
```bash
# Using apt
sudo apt update
sudo apt install ffmpeg

# For older Ubuntu versions, you may need to add a PPA
sudo add-apt-repository ppa:jonathonf/ffmpeg-4
sudo apt update
sudo apt install ffmpeg
```

**CentOS/RHEL/Fedora:**
```bash
# CentOS/RHEL (enable EPEL repository first)
sudo yum install epel-release
sudo yum install ffmpeg

# Fedora
sudo dnf install ffmpeg

# For newer versions
sudo dnf install https://mirrors.rpmfusion.org/free/fedora/rpmfusion-free-release-$(rpm -E %fedora).noarch.rpm
sudo dnf install ffmpeg
```

**Windows:**
```bash
# Using Chocolatey
choco install ffmpeg

# Using Scoop
scoop install ffmpeg

# Manual installation:
# 1. Download from https://www.gyan.dev/ffmpeg/builds/
# 2. Extract to C:\ffmpeg
# 3. Add C:\ffmpeg\bin to your PATH environment variable
```

**Conda (cross-platform):**
```bash
conda install -c conda-forge ffmpeg
```

To verify ffmpeg installation:
```bash
ffmpeg -version
```

### Basic Usage

**For video/image datasets - Install additional components:**
```bash
# Install video and image processing support (one-time setup)
# This automatically downloads the required models
carlib install video-image
```

**Converting datasets:**
```bash
# Convert audio files
carlib convert /path/to/audio --modality vanilla --target-modality audio -o /output

# Convert video/image files (requires additional installation above)
carlib convert /path/to/videos --modality vanilla --target-modality video -o /output
carlib convert /path/to/images --modality vanilla --target-modality image -o /output

# Convert WebDataset with auto-detected GPUs in parallel
carlib convert /path/to/data.tar --modality webdataset --target-modality image -o /output

# Convert with specific number of GPUs
carlib convert /path/to/data.tar --modality webdataset --target-modality image --gpus 4 -o /output
```

**Loading CAR files for ML training:**
```python
import carlib

# PyTorch Dataset for training
dataset = carlib.CARDataset("/path/to/car/files", modality="audio")
loader = carlib.CARLoader(dataset, batch_size=32, shuffle=True)

for batch in loader:
    # Access encoded tokens/features for training
    audio_codes = batch['data']['codes']      # Shape: [batch, seq_len]
    metadata = batch['metadata']              # List of metadata dicts
    
    # Train your model on encoded representations
    loss = model(audio_codes)

# JAX loader for JAX-based training
jax_loader = carlib.load_car_jax("/path/to/car/files", modality="audio")
for item in jax_loader:
    tokens = item['data']['tokens']  # JAX arrays for training

# High-performance Grain loader for enterprise-scale JAX training
grain_loader = carlib.load_car_grain(
    "/path/to/car/files",
    batch_size=64,
    shuffle=True,
    seed=42,
    modality="audio"
)
for batch in grain_loader:
    # True global shuffling, deterministic processing
    jax_arrays = batch['data']['codes']  # Ready for JAX training

# Load single CAR file
single_data = carlib.load_single_car("/path/to/file.car")
```

## Supported Formats

### Input Formats
- **vanilla**: Regular media files on filesystem
- **webdataset**: WebDataset tar archives (.tar, .tar.gz, etc.)
- **hdf5**: HDF5 data files (.hdf5, .h5, .hdf)

### Target Modalities
- **audio**: Audio files (.wav, .mp3, .flac, .m4a, .ogg, .aac) - tokenized using advanced audio tokenizers
- **image**: Image files (.jpg, .png, .webp, .bmp, .tiff, .gif) - tokenized using advanced image tokenizers
- **video**: Video files (.mp4, .avi, .mov, .mkv, .webm, .wmv) - tokenized using advanced video tokenizers

## CLI Commands

### Convert Datasets
```bash
carlib convert INPUT_PATH --modality {vanilla,webdataset,hdf5} --target-modality {audio,image,video} -o OUTPUT_PATH
```

**Required Arguments:**
- `INPUT_PATH`: Path to input dataset directory or file
- `--modality, -m`: Input format type
- `--target-modality, -t`: Target media type  
- `--output, -o`: Output directory for CAR files

**Optional Arguments:**
- `--config, -c`: Custom YAML configuration file
- `--parallel`: Enable parallel processing (default: True)
- `--sequential`: Force sequential processing
- `--gpus, -g`: Number of GPUs to use (auto-detected if not specified)
- `--max-files`: Maximum files to process
- `--model-name`: Override tokenizer name
- `--model-type`: Override tokenizer type
- `--recursive/-r`: Search recursively (default: True)
- `--verbose, -v`: Verbose output

### Configuration Management
```bash
carlib config list                    # List available configurations
carlib config show audio             # Show audio configuration
carlib config create audio -o my.yaml # Create custom config template
carlib config validate config.yaml   # Validate configuration file
```

### System Information
```bash
carlib info                          # Show system info and dependencies
carlib validate file1.car file2.car # Validate CAR files
```

### Dataset Benchmarking & Evaluation
```bash
# Benchmark dataset conversion performance
carlib benchmark /path/to/dataset --modality audio --output benchmark_results.json

# Compare different formats and analyze performance
carlib benchmark /path/to/webdataset --modality webdataset --webdataset-modality audio --gpus 4

# Benchmark HDF5 datasets  
carlib benchmark /path/to/data.hdf5 --modality hdf5 --hdf5-modality image --max-files 1000
```

## Configuration

CarLib uses YAML files to configure processing parameters. Each target modality has default settings that can be customized.

### Default Configurations

**Audio Tokenizer** (`configs/audio_config.yaml`):
```yaml
tokenizer_type: "audio"
device: "cuda"
target_sample_rate: 32000
max_duration: null
quality_threshold: 0.0
output_format: "car"
```

**Image Tokenizer** (`configs/image_config.yaml`):
```yaml
tokenizer_type: "image"
image_size: [224, 224]
maintain_aspect_ratio: false
normalize_images: true
device: "cuda"
dtype: "bfloat16"
quality_threshold: 0.0
output_format: "car"
```

**Video Tokenizer** (`configs/video_config.yaml`):
```yaml
tokenizer_type: "video"
max_frames: null
frame_size: [224, 224]
frame_skip: 1
target_fps: null
normalize_frames: true
device: "cuda"
dtype: "bfloat16"
quality_threshold: 0.0
output_format: "car"
```

### Creating Custom Configurations

1. **Create a template:**
```bash
carlib config create audio -o my_audio_config.yaml
```

2. **Edit the configuration:**
```yaml
# High-quality audio processing
model_name: "facebook/encodec_48khz"
model_type: "encodec"
device: "cuda"
target_sample_rate: 48000
max_duration: 60.0  # Process max 60 seconds
quality_threshold: 0.7
output_format: "car"
```

3. **Use the custom config:**
```bash
carlib convert /audio/data --modality vanilla --target-modality audio --config my_audio_config.yaml -o /output
```

### Configuration Priority
Settings are applied in this order (highest to lowest priority):
1. Command-line arguments 
2. Custom config file (--config)
3. Default config files
4. Built-in fallbacks

## Python API

### Dataset Conversion
```python
from carlib import convert_dataset_to_car, load_config_from_yaml

# Basic conversion
convert_dataset_to_car(
    input_path="/path/to/dataset",
    output_path="/path/to/output",
    modality="vanilla",
    target_modality="audio",
    parallel=True,  # Enable parallel processing (default)
    num_gpus=None   # Auto-detect GPUs (or specify: num_gpus=2)
)

# With custom configuration
config = load_config_from_yaml("my_config.yaml", "audio")
convert_dataset_to_car(
    input_path="/path/to/dataset", 
    output_path="/path/to/output",
    modality="vanilla",
    target_modality="audio",
    parallel=True,
    config_file="my_config.yaml"
)
```

### Dataset Evaluation & Benchmarking
```python
from carlib import BenchmarkConfig, run_folder_benchmark, analyze_benchmark_results

# Create benchmark configuration
config = BenchmarkConfig(
    folder_path="/path/to/dataset",
    modality="audio",  # or 'image', 'video', 'webdataset', 'hdf5'
    output_file="benchmark_results.json",
    num_gpus=2,
    num_runs=3,  # Number of timing runs for averaging
    max_files=1000  # Limit files for testing
)

# Run comprehensive performance benchmark
results = run_folder_benchmark(config)

# Analyze results with enhanced CAR file analysis
analysis = analyze_benchmark_results(
    "benchmark_results.json", 
    output_dir="analysis_output"
)

print(f"Processed {analysis['total_files']} files")
print(f"CarLib enhanced analysis available: {analysis['carlib_available']}")
```

### ML Training with CAR Data
```python
import carlib
import torch
from torch.utils.data import DataLoader

# Create optimized PyTorch dataset
dataset = carlib.CARDataset(
    car_dir="/path/to/car/files",
    modality="audio",           # Filter by modality
    cache_in_memory=True,       # Smart LRU caching for performance
    use_mmap=True,             # Memory-mapped files for large datasets
    max_cache_size=1000        # Cache most-accessed files
)

# Create optimized DataLoader for training
dataloader = DataLoader(
    dataset,
    batch_size=32,
    shuffle=True,
    num_workers=4,
    pin_memory=True,            # Faster GPU transfers
    persistent_workers=True,    # Keep workers alive between epochs
    collate_fn=dataset._collate_fn  # Custom batching
)

# Or use the high-level CARLoader with optimizations built-in
loader = carlib.CARLoader(
    car_dir="/path/to/car/files",
    batch_size=32,
    shuffle=True,
    num_workers=4,              # IMPORTANT: Use >0 for prefetching
    cache_in_memory=True,       # Automatic optimizations
    modality="audio"
)

# Training loop
model = YourModel()
optimizer = torch.optim.Adam(model.parameters())

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

for epoch in range(num_epochs):
    for batch in loader:  # Using CARLoader
        # Efficiently move batch to GPU (single transfer)
        batch = loader.to_device(batch, device, non_blocking=True)
        
        # Access encoded data (already on GPU)
        encoded_data = batch['data']
        
        # Different modalities have different keys:
        if 'codes' in encoded_data:          # Audio (EnCodec/DAC/SNAC)
            tokens = encoded_data['codes']    # Shape: [batch, seq_len] or [batch, n_q, seq_len]
        elif 'tokens' in encoded_data:       # Image/Video (Cosmos)
            tokens = encoded_data['tokens']   # Shape: [batch, h, w] or [batch, frames, h, w]
        
        # Train on compressed representations
        logits = model(tokens)
        loss = criterion(logits, targets)
        
        optimizer.zero_grad()
        loss.backward() 
        optimizer.step()
        
        # GPU memory is automatically managed - no manual cache clearing needed
```

### Advanced Dataset Usage
```python
# Streaming dataset for large datasets
streaming_dataset = carlib.CARIterableDataset(
    car_dir="/path/to/large/dataset", 
    shuffle=True,
    modality="image"
)

# Custom collate function for variable-length sequences
def custom_collate(batch):
    # Handle variable sequence lengths
    sequences = [item['data']['codes'] for item in batch]
    padded = torch.nn.utils.rnn.pad_sequence(sequences, batch_first=True)
    
    return {
        'data': {'codes': padded},
        'metadata': [item['metadata'] for item in batch],
        'lengths': [len(seq) for seq in sequences]
    }

dataloader = DataLoader(dataset, collate_fn=custom_collate)
```

### JAX Training Support
```python
import carlib
import jax
import jax.numpy as jnp

# JAX loader for JAX-based models
jax_loader = carlib.JAXCARLoader("/path/to/car/files", modality="audio")

# Training with JAX
for batch_paths in batched_car_files:
    batch_data = jax_loader.load_batch(batch_paths)
    tokens = batch_data['data']['tokens']  # JAX arrays
    
    # JAX training step
    params, loss = train_step(params, tokens, targets)
```

### Validation/Decoding (Separate from Training)
```python
import carlib

# Only decode for validation/visualization - NOT during training
decoder = carlib.CARDecoder(device="cuda")

# Decode validation samples to evaluate quality
val_sample = "/path/to/validation_sample.car"
decoded_result = decoder.decode_car(val_sample, save_decoded=True)
original_audio = decoded_result['decoded_data']  # Waveform tensor

# Or decode model generations for evaluation
model_output = model.generate(input_tokens)
decoded_output = decoder.decode_data(
    encoded_data=model_output,
    target_modality="audio", 
    output_path="generated_sample.wav"
)
```

## Examples

### Audio Processing
```bash
# Convert MP3 collection to CAR
carlib convert /music/collection --modality vanilla --target-modality audio -o /output/cars

# High-quality audio with custom settings and specific GPU count
carlib convert /audio/dataset --modality vanilla --target-modality audio \
  --model-name "facebook/encodec_48khz" --gpus 4 -o /output

# Sequential processing (single GPU/CPU)
carlib convert /audio/dataset --modality vanilla --target-modality audio \
  --model-name "facebook/encodec_48khz" --sequential -o /output

# Process WebDataset audio archives
carlib convert /datasets/audio.tar --modality webdataset --target-modality audio \
  --max-files 10000 -o /output
```

### Image Processing
```bash
# Convert image directory
carlib convert /images/dataset --modality vanilla --target-modality image -o /output/cars

# High-resolution image processing with auto-detected GPUs
carlib convert /images --modality vanilla --target-modality image \
  --config high_res_config.yaml -o /output

# High-resolution with specific GPU count
carlib convert /images --modality vanilla --target-modality image \
  --config high_res_config.yaml --gpus 8 -o /output

# Process HDF5 image dataset
carlib convert /data/images.hdf5 --modality hdf5 --target-modality image -o /output
```

### Video Processing  
```bash
# Convert video files
carlib convert /videos/dataset --modality vanilla --target-modality video -o /output

# Process with frame sampling
carlib convert /videos --modality vanilla --target-modality video \
  --config frame_sampling_config.yaml --max-files 500 -o /output

# Process WebDataset video archives with auto-detected GPUs  
carlib convert /data/videos.tar --modality webdataset --target-modality video -o /output

# Process with specific GPU count
carlib convert /data/videos.tar --modality webdataset --target-modality video \
  --gpus 4 -o /output
```

### Batch Processing
```python
# Process multiple datasets
import os
from carlib import convert_dataset_to_car

datasets = [
    ("/data/audio1", "audio"),
    ("/data/images1", "image"), 
    ("/data/videos1", "video")
]

for i, (dataset_path, target_modality) in enumerate(datasets):
    output_path = f"/output/batch_{i}"
    os.makedirs(output_path, exist_ok=True)
    
    convert_dataset_to_car(
        input_path=dataset_path,
        output_path=output_path,
        modality="vanilla", 
        target_modality=target_modality,
        parallel=True,
        num_gpus=2,  # Or None for auto-detect
        max_files=1000
    )
```

## Tokenizer Options

### Available Tokenizers
- **Audio Tokenizer**: High-quality audio compression and tokenization
- **Image Tokenizer**: Efficient image representation learning
- **Video Tokenizer**: Advanced video sequence tokenization

Tokenizers are automatically selected based on your target modality and configured via YAML files for optimal performance.

## Performance Tips

### Multi-GPU Usage
```bash
# Auto-detect and use all available GPUs (default)
carlib convert /large/dataset --modality vanilla --target-modality audio -o /output

# Specify exact number of GPUs
carlib convert /large/dataset --modality vanilla --target-modality audio --gpus 8 -o /output

# Force sequential processing (single GPU/CPU)
carlib convert /large/dataset --modality vanilla --target-modality audio --sequential -o /output
```

### Memory Management
- Use `max_files` to limit memory usage for large datasets
- Adjust `batch_size` in config files for memory constraints
- Use `dtype: "float16"` for lower memory usage

### Processing Optimization
- Set `max_duration` for audio to skip very long files
- Use `frame_skip` for video to reduce processing time
- Enable `quality_threshold` to filter low-quality inputs

### Dataset Loading Performance

CarLib includes several optimizations for high-performance training:

**Dataset Optimization Options:**
- `cache_in_memory=True`: Smart LRU caching with automatic eviction
- `use_mmap=True`: Memory-mapped file access for large datasets
- `max_cache_size=N`: Limit cache size to most frequently accessed files

**DataLoader Optimizations:**
- `num_workers=4` (or higher): Enable prefetching to prevent GPU idle time
- `pin_memory=True`: Faster CPU-to-GPU transfers
- `persistent_workers=True`: Keep worker processes alive between epochs
- `prefetch_factor=2`: Prefetch 2 batches per worker for smooth data flow
- Use `loader.to_device()` for efficient batch-level GPU transfers

**Performance Benefits:**
- **3-5x faster data loading** with smart caching and memory mapping
- **Eliminates repeated file I/O** during training epochs  
- **60-80% reduction** in GPU memory management overhead
- **2-3x lower peak memory usage** with optimized video chunking
- **Prevents GPU idle time** with automatic prefetching
- **Faster file discovery** with optimized glob patterns
- **Reduced processing overhead** with batched multiprocessing
- **Cached spatial padding** calculations for repeated frame sizes
- **Automatic memory management** - no manual cache clearing needed

## Dependencies

### Required
- torch >= 1.9.0
- torchaudio >= 0.9.0
- transformers >= 4.20.0
- PyYAML >= 5.4.0
- tqdm >= 4.60.0

### Additional Features (included in main installation)
- webdataset >= 0.2.0 (WebDataset support)
- h5py >= 3.0.0 (HDF5 support)  
- matplotlib >= 3.0.0 (benchmarking and visualization)
- pandas >= 1.0.0 (data analysis)
- seaborn >= 0.11.0 (advanced plotting)

## Troubleshooting

### Common Issues

**"carlib command not found"**
```bash
# Ensure installation completed
pip install carlib
# Add to PATH if needed
export PATH=$PATH:$(python -m site --user-base)/bin
```

**"CUDA out of memory"**
- Reduce `--gpus` parameter
- Set `max_files` to process in smaller batches
- Use `dtype: "float16"` in config

**"Config file not found"**
```bash
# Check available configs
carlib config list
# Create custom config
carlib config create audio -o my_config.yaml
```

**"No files found"**
- Check input path exists
- Verify file extensions match target modality
- Use `--verbose` for detailed scanning info

### Getting Help
```bash
carlib --help                    # General help
carlib convert --help           # Conversion options
carlib config --help            # Configuration help
carlib benchmark --help         # Benchmarking options
carlib info                     # System information
```

## License

MIT License - see LICENSE file for details.