from typing import Literal

TTSEncoding = Literal["pcm_s16le",]
STTEncoding = Literal["pcm_s16le",]
