"""
### Typed Bybit
> A fully typed, validated async client for the Bybit API

- Details
"""