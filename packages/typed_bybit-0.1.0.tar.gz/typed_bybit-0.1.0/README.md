# Typed Bybit

> A fully typed, validated async client for the Bybit API

Use *autocomplete* instead of documentation.

🚧 Under construction.