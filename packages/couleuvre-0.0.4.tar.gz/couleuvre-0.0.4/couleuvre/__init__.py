from couleuvre.server import server  # noqa: F401

__all__ = ["server"]
