#######################################
Account Stock Landed Cost Weight Module
#######################################

The *Account Stock Landed Cost Weight Module* adds an allocation method based
on weight to the landed costs.

.. toctree::
   :maxdepth: 2

   design
   releases
