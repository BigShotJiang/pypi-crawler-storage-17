"""Version information for Chloros SDK"""

__title__ = 'chloros-sdk'
__description__ = 'Official Python SDK for MAPIR Chloros image processing'
__version__ = '1.0.0'
__author__ = 'MAPIR Inc.'
__author_email__ = 'info@mapir.camera'
__license__ = 'Proprietary'
__copyright__ = 'Copyright 2025 MAPIR Inc.'
__url__ = 'https://www.mapir.camera'









