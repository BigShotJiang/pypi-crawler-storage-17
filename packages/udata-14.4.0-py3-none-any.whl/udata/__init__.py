#!/usr/bin/env python

"""
udata
"""

__description__ = "Open data portal"
