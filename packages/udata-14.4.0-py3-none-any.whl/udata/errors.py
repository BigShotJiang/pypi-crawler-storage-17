class ConfigError(ValueError):
    """Exception raised when an error is detected into the configuration"""

    pass
