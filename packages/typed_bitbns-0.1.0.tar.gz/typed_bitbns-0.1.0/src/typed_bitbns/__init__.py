"""
### Typed Bitbns
> A fully typed, validated async client for the Bitbns API

- Details
"""