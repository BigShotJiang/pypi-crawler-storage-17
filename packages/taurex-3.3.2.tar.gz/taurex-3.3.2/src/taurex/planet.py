"""Alias module imports"""
from taurex.data.planet import BasePlanet, Planet
