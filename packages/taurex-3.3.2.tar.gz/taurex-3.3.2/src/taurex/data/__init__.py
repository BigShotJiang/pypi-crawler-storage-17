"""Main taurex data module."""
from .planet import Planet

__all__ = ["Planet"]
