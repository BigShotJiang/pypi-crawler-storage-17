"""TauREx Exception classes."""


class InvalidModelException(Exception):  # noqa: N818
    """Exception raised when a model is invalid."""

    pass
