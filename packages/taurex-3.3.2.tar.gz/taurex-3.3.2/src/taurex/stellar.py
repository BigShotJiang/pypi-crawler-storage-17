from taurex.data.stellar.star import Star, BlackbodyStar
from taurex.data.stellar.phoenix import PhoenixStar
