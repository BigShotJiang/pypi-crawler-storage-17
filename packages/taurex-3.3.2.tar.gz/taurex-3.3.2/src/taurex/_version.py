"""Version information for TauREx."""
import importlib.metadata

__version__ = release = importlib.metadata.version("taurex")
