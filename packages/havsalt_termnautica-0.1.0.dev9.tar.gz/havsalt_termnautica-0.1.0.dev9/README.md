# Termnautica

Underwater game made using `charz`

![Underwater world with fish](./images/fish.png)

---

![Underwater world with structure](./images/building.png)

## License

MIT
