#!/bin/bash
#SBATCH -J vtissue_preprocess
#SBATCH -p gpu
#SBATCH --gres=gpu:1
#SBATCH -c 4
#SBATCH --mem=32G
#SBATCH -t 00:05:00
#SBATCH -o logs/vtissue_preprocess.%j.out
#SBATCH -e logs/vtissue_preprocess.%j.err
#SBATCH --mail-type=END
#SBATCH --mail-user=anirmal@bwh.harvard.edu

set -euo pipefail

# IMPORTANT on O2: do NOT override CUDA_VISIBLE_DEVICES (Slurm sets it)
# See O2 GPU docs: use -p gpu/gpu_quad/gpu_requeue and --gres=gpu:N, load cuda module. :contentReference[oaicite:0]{index=0}

mkdir -p logs

module load gcc/14.2.0
module load cuda/12.8
conda activate vtissue

# Run from your project root (adjust as needed)
python -m vtissue.preprocessing.preprocess \
  --input "/n/scratch/users/a/ajn16/vtissue/data/orion.h5ad" \
  --input-layer log
