
from .component_proxy import UvmComponentProxy

class Uvm2Py(UvmComponentProxy):
    """
    Extracts type definitions from UVM and outputs Python 'mock' classes
    """

    def build_phase(self):
        pass

    pass