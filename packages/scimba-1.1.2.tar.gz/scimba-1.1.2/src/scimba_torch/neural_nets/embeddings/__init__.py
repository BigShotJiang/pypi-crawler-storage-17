"""Embeddings modules for neural networks."""
