"""Defines neural networks."""
