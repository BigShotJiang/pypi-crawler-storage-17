"""Utility functions for scimba plots."""
