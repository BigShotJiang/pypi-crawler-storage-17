"""Scimba optimizers and losses."""
