"""Models for kinetic partial differential equations."""
