"""Models for elliptic partial differential equations."""
