"""A module to check the current environment."""

import shutil
import sys


def is_jupyter_notebook() -> bool:
    """Check if code is run within a jupyter notebook.

    Returns:
        True if running inside a Jupyter-like environment
        (Notebook, JupyterLab, VSCode notebooks, ...?)
    """
    return "ipykernel" in sys.modules


def is_google_colab() -> bool:
    """Check if code is run within google.colab.

    Returns:
        True if running inside google.colab)
    """
    return "google.colab" in sys.modules


def is_static_width_environment() -> bool:
    """Check if one can trust dynamic width for tqdm.

    Returns:
        True if one can not trust dynamic width for tqdm.
        Return False if running in a normal terminal.
    """
    # return False
    return is_jupyter_notebook() or is_google_colab()


def get_static_terminal_width() -> int:
    """Get the width of the current terminal.

    Returns:
        the width of the current terminal
    """
    return shutil.get_terminal_size()[0]
