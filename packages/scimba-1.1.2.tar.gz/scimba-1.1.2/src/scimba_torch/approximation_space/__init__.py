"""Defines the approximation space and its components."""
