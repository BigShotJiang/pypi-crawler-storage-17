---
title: Vendor Tips & Tricks
parent: ETL
nav_order: 30
# audience: engineer familiar with the project
# type: howto
---

# Vendor Tips & Tricks

EHR vendors have different features and performance.

We collect advice for common vendors in our
[Discussions](https://github.com/smart-on-fhir/cumulus/discussions) forum.
Check them out, and if you have your own suggestions, let us know!

- [Cerner Tips](https://github.com/smart-on-fhir/cumulus/discussions/6)
- [Epic Tips](https://github.com/smart-on-fhir/cumulus/discussions/5)
