These DocRefs note texts were grabbed from curated (non-PHI) examples in the
[ctakes-examples](https://github.com/Machine-Learning-for-Medical-Language/ctakes-examples)
repo.

The filename used is the DocRef `id` field. 

I chose four notes that had symptoms only caught by our custom bsv file
and one note that had no symptoms found, for variety.
