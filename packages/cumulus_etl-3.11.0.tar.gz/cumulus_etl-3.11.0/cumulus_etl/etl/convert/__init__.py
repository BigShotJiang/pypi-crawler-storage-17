"""Subcommand to convert output folder formats"""

from .cli import run_convert
