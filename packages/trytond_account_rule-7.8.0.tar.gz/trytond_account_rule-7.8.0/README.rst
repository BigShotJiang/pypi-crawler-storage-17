###################
Account Rule Module
###################

The *Account Rule Module* allows rules which substitute default accounts with
other accounts.

.. toctree::
   :maxdepth: 2

   design
   releases
