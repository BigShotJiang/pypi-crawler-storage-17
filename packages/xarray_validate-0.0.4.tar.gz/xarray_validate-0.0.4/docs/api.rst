API reference
=============

.. automodule:: xarray_validate
    :autosummary:
    :members:
    :show-inheritance:
    :inherited-members:
