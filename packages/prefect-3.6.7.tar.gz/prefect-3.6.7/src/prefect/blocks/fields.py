from prefect.types import SecretDict

__all__ = ["SecretDict"]
