Services
========

.. automodule:: curies.cli

.. toctree::
    :maxdepth: 1
    :caption: Services:

    resolver_service
    mapping_service
