class NumpyLayer:
    pass
