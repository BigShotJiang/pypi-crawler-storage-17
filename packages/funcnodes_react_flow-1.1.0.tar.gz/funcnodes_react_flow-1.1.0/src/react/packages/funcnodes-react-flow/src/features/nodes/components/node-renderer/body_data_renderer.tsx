import { useBodyDataRendererForIo } from "../../hooks";

export { useBodyDataRendererForIo };
