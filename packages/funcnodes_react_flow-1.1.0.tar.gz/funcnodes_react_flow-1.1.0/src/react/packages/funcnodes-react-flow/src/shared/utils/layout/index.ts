export { fitTextToContainer } from "./txt";
export type { ResizeTextOptions } from "./txt";
