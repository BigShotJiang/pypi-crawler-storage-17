"""Demo CLI commands.

Commands for running and copying demo task apps.
"""

from synth_ai.cli.demos.demo import demo_cmd

__all__ = [
    "demo_cmd",
]


