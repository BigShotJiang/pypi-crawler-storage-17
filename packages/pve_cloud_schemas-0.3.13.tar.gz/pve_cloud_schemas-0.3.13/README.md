# Python pkg - pve-cloud-schemas

Contains schema definitions for custom ansible inventories and extensions for various core pve cloud playbooks.
