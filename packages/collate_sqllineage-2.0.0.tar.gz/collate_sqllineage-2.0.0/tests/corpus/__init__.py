"""
Test corpus from real SQL queries.

Sources:
- servicenow/: Snowflake queries
"""
