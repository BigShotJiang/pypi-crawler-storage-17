"""
ServiceNow Snowflake query tests.
"""
