This module is a technical base module to allow defining excluded
locations on an Odoo model.
