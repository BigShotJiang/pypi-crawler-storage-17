from . import test_stock_exclude_location
