"""Tests for blockbom."""
