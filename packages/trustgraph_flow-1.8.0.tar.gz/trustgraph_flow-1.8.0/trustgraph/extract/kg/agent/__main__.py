from .extract import Processor

if __name__ == "__main__":
    Processor.run()