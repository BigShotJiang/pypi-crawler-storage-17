#!/usr/bin/env python3

from . write import run

if __name__ == '__main__':
    run()

