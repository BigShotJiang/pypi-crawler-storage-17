from .test_matriculation import MatriculationTestCase

__all__ = ['MatriculationTestCase']
