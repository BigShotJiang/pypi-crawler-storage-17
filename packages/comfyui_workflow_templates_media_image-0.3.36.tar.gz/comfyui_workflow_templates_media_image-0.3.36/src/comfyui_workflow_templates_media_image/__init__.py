"""
Media bundle: image-centric workflows.

Static assets live under `templates/` within this package. Content is
populated during the build step.
"""
