from .dump import main

main()
