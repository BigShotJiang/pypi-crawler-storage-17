1.  On a chatter where recipients can be suggested (e.g., any contact),
    click on 'Send Message'.
2.  The suggested recipient will not be checked by default.
3.  If the box is checked the email will be sent to the suggested
    recipient.
