"""
Constants for Code Interpreter module.
"""

DEFAULT_TEMPLATE = "code-interpreter"
JUPYTER_PORT = 49999
DEFAULT_TIMEOUT = 300
