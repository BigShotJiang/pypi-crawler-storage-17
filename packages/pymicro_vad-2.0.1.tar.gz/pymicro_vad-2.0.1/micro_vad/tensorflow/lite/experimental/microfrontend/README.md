This directory contains the subset of functionality that is needed to run the
micro_speech example with TFLM.

The source of truth for the experimental microfrontend in TfLite is at:
https://github.com/tensorflow/tflite-micro/blob/main/tensorflow/lite/experimental/microfrontend

