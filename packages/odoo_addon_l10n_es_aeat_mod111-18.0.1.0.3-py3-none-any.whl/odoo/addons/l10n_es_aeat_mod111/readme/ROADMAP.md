El modelo 111 no está preparado para compañías que están acogidas al
régimen de caja
