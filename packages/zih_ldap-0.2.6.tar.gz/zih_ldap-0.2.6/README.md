# zih_ldap

Wrapper integrating LDAP and Pydantic for TU Dresden
