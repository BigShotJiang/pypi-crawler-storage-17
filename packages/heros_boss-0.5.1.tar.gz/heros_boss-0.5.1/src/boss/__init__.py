__version__ = "0.5.1"

from .boss import BOSS

__all__ = ["BOSS"]
