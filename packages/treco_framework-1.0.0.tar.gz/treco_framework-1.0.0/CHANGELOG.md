# Changelog

All notable changes to TRECO will be documented in this file.

## [Unreleased]

### Added
- Initial release
