"""Tools for agents."""

from .web_search_tool import web_search

__all__ = ["web_search"]

