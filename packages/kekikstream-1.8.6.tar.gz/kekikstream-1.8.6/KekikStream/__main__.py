# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from . import basla

if __name__ == "__main__":
    basla()