__version__ = "3.4.0"

from jupytercad_lab import CadDocument  # noqa
