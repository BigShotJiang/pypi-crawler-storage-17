# Beekeeper readers extension - Docling

## Installation 

```bash
pip install beekeeper-readers-docling
```
