"""Domain Layer - Core business logic and entities"""
