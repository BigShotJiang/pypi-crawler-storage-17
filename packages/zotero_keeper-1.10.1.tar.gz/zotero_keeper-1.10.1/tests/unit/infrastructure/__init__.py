"""Unit tests for infrastructure layer."""
