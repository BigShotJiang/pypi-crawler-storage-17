"""
Tests for Zotero Keeper MCP Server
"""
