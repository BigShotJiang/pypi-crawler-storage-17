---
name: 🚀 Feature request
about: Suggest an idea for this project 💡
labels: enhancement
---

## Context
<!--
Please let us know what you are trying to do and how you would want to do it differently?
Is it something you currently cannot do?
Is this related to an issue/problem?
-->

## Alternatives
<!--
Can you achieve the same result doing it in an alternative way?
Is the alternative considerable?
-->
