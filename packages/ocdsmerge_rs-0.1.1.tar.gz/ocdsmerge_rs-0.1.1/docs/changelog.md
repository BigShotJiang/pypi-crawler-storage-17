# Changelog

## 0.1.1

- Enable the `arbitrary_precision` feature on the `serde_json` crate.

## 0.1.0

First release.
