"""
Endpoints module for Aegis Web API.
"""
