from collections import namedtuple


SelectorColorStates = namedtuple("state", ["idle", "highlight", "action"])
