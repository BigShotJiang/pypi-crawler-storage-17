# Typed Btcbox

> A fully typed, validated async client for the Btcbox API

Use *autocomplete* instead of documentation.

🚧 Under construction.