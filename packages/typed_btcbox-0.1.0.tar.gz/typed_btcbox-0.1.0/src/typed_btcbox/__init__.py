"""
### Typed Btcbox
> A fully typed, validated async client for the Btcbox API

- Details
"""