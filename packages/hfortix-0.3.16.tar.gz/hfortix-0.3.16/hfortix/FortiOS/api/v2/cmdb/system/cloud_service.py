"""
FortiOS CMDB - Cmdb System Cloud Service

Configuration endpoint for managing cmdb system cloud service objects.

API Endpoints:
    GET    /cmdb/system/cloud_service
    POST   /cmdb/system/cloud_service
    GET    /cmdb/system/cloud_service
    PUT    /cmdb/system/cloud_service/{identifier}
    DELETE /cmdb/system/cloud_service/{identifier}

Example Usage:
    >>> from hfortix.FortiOS import FortiOS
    >>> fgt = FortiOS(host="192.168.1.99", token="your-api-token")
    >>>
    >>> # List all items
    >>> items = fgt.api.cmdb.system.cloud_service.get()
    >>>
    >>> # Get specific item (if supported)
    >>> item = fgt.api.cmdb.system.cloud_service.get(name="item_name")
    >>>
    >>> # Create new item (use POST)
    >>> result = fgt.api.cmdb.system.cloud_service.post(
    ...     name="new_item",
    ...     # ... additional parameters
    ... )
    >>>
    >>> # Update existing item (use PUT)
    >>> result = fgt.api.cmdb.system.cloud_service.put(
    ...     name="existing_item",
    ...     # ... parameters to update
    ... )
    >>>
    >>> # Delete item
    >>> result = fgt.api.cmdb.system.cloud_service.delete(name="item_name")

Important:
    - Use **POST** to create new objects (404 error if already exists)
    - Use **PUT** to update existing objects (404 error if doesn't exist)
    - Use **GET** to retrieve configuration (no changes made)
    - Use **DELETE** to remove objects (404 error if doesn't exist)
"""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ....http_client_interface import IHTTPClient


class CloudService:
    """
    Cloudservice Operations.

    Provides CRUD operations for FortiOS cloudservice configuration.

    Methods:
        get(): Retrieve configuration objects
        post(): Create new configuration objects
        put(): Update existing configuration objects
        delete(): Remove configuration objects

    Important:
        - POST creates new objects (404 if name already exists)
        - PUT updates existing objects (404 if name doesn't exist)
        - GET retrieves objects without making changes
        - DELETE removes objects (404 if name doesn't exist)
    """

    def __init__(self, client: "IHTTPClient"):
        """
        Initialize CloudService endpoint.

        Args:
            client: HTTPClient instance for API communication
        """
        self._client = client

    def get(
        self,
        name: str | None = None,
        payload_dict: dict[str, Any] | None = None,
        attr: str | None = None,
        skip_to_datasource: dict | None = None,
        acs: int | None = None,
        search: str | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Select a specific entry from a CLI table.

        Args:
            name: Object identifier (optional for list, required for specific)
            attr: Attribute name that references other table (optional)
            skip_to_datasource: Skip to provided table's Nth entry. E.g {datasource: 'firewall.address', pos: 10, global_entry: false} (optional)
            acs: If true, returned result are in ascending order. (optional)
            search: If present, the objects will be filtered by the search value. (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        params = payload_dict.copy() if payload_dict else {}

        # Build endpoint path
        if name:
            endpoint = f"/system/cloud-service/{name}"
        else:
            endpoint = "/system/cloud-service"
        if attr is not None:
            params["attr"] = attr
        if skip_to_datasource is not None:
            params["skip_to_datasource"] = skip_to_datasource
        if acs is not None:
            params["acs"] = acs
        if search is not None:
            params["search"] = search
        params.update(kwargs)
        return self._client.get(
            "cmdb", endpoint, params=params, vdom=vdom, raw_json=raw_json
        )

    def put(
        self,
        name: str | None = None,
        payload_dict: dict[str, Any] | None = None,
        before: str | None = None,
        after: str | None = None,
        vendor: str | None = None,
        traffic_vdom: str | None = None,
        gck_service_account: str | None = None,
        gck_private_key: str | None = None,
        gck_keyid: str | None = None,
        gck_access_token_lifetime: int | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Update this specific resource.

        Args:
            payload_dict: Optional dictionary of all parameters (can be passed as first positional arg)
            name: Object identifier (required)
            before: If *action=move*, use *before* to specify the ID of the resource that this resource will be moved before. (optional)
            after: If *action=move*, use *after* to specify the ID of the resource that this resource will be moved after. (optional)
            name: Name. (optional)
            vendor: Cloud service vendor. (optional)
            traffic_vdom: Vdom used to communicate with cloud service. (optional)
            gck_service_account: Service account (e.g. "account-id@sampledomain.com"). (optional)
            gck_private_key: Service account private key in PEM format (e.g. "-----BEGIN PRIVATE KEY-----\\ (optional)
            gck_keyid: Key id, also referred as "kid". (optional)
            gck_access_token_lifetime: Lifetime of automatically generated access tokens in minutes (default is 60 minutes). (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        data_payload = payload_dict.copy() if payload_dict else {}
        params = {}

        # Build endpoint path
        if not name:
            raise ValueError("name is required for put()")
        endpoint = f"/system/cloud-service/{name}"
        if before is not None:
            data_payload["before"] = before
        if after is not None:
            data_payload["after"] = after
        if name is not None:
            data_payload["name"] = name
        if vendor is not None:
            data_payload["vendor"] = vendor
        if traffic_vdom is not None:
            data_payload["traffic-vdom"] = traffic_vdom
        if gck_service_account is not None:
            data_payload["gck-service-account"] = gck_service_account
        if gck_private_key is not None:
            data_payload["gck-private-key"] = gck_private_key
        if gck_keyid is not None:
            data_payload["gck-keyid"] = gck_keyid
        if gck_access_token_lifetime is not None:
            data_payload["gck-access-token-lifetime"] = (
                gck_access_token_lifetime
            )
        data_payload.update(kwargs)
        return self._client.put(
            "cmdb", endpoint, data=data_payload, vdom=vdom, raw_json=raw_json
        )

    def delete(
        self,
        name: str | None = None,
        payload_dict: dict[str, Any] | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Delete this specific resource.

        Args:
            name: Object identifier (required)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        params = payload_dict.copy() if payload_dict else {}

        # Build endpoint path
        if not name:
            raise ValueError("name is required for delete()")
        endpoint = f"/system/cloud-service/{name}"
        params.update(kwargs)
        return self._client.delete(
            "cmdb", endpoint, params=params, vdom=vdom, raw_json=raw_json
        )

    def post(
        self,
        payload_dict: dict[str, Any] | None = None,
        nkey: str | None = None,
        name: str | None = None,
        vendor: str | None = None,
        traffic_vdom: str | None = None,
        gck_service_account: str | None = None,
        gck_private_key: str | None = None,
        gck_keyid: str | None = None,
        gck_access_token_lifetime: int | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Create object(s) in this table.

        Args:
            payload_dict: Optional dictionary of all parameters (can be passed as first positional arg)
            nkey: If *action=clone*, use *nkey* to specify the ID for the new resource to be created. (optional)
            name: Name. (optional)
            vendor: Cloud service vendor. (optional)
            traffic_vdom: Vdom used to communicate with cloud service. (optional)
            gck_service_account: Service account (e.g. "account-id@sampledomain.com"). (optional)
            gck_private_key: Service account private key in PEM format (e.g. "-----BEGIN PRIVATE KEY-----\\ (optional)
            gck_keyid: Key id, also referred as "kid". (optional)
            gck_access_token_lifetime: Lifetime of automatically generated access tokens in minutes (default is 60 minutes). (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        data_payload = payload_dict.copy() if payload_dict else {}
        params = {}
        endpoint = "/system/cloud-service"
        if nkey is not None:
            data_payload["nkey"] = nkey
        if name is not None:
            data_payload["name"] = name
        if vendor is not None:
            data_payload["vendor"] = vendor
        if traffic_vdom is not None:
            data_payload["traffic-vdom"] = traffic_vdom
        if gck_service_account is not None:
            data_payload["gck-service-account"] = gck_service_account
        if gck_private_key is not None:
            data_payload["gck-private-key"] = gck_private_key
        if gck_keyid is not None:
            data_payload["gck-keyid"] = gck_keyid
        if gck_access_token_lifetime is not None:
            data_payload["gck-access-token-lifetime"] = (
                gck_access_token_lifetime
            )
        data_payload.update(kwargs)
        return self._client.post(
            "cmdb", endpoint, data=data_payload, vdom=vdom, raw_json=raw_json
        )
