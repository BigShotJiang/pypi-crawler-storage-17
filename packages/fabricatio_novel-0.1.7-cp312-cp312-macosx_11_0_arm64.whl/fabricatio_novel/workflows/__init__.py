"""Workflows defined in fabricatio-novel."""

from fabricatio_core.utils import cfg

cfg(feats=["workflows"])
