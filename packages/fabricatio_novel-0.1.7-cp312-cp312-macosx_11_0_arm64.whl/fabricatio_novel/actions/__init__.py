"""Actions defined in fabricatio-novel."""
