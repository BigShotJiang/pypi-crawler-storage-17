# Changelog

<!--
   You should *NOT* be adding new change log entries to this file.
   You should create a file in the news directory instead.
   For helpful instructions, please see:
   https://github.com/plone/plone.releaser/blob/master/ADD-A-NEWS-ITEM.rst
-->

<!-- towncrier release notes start -->

## 1.0.0 (2025-12-16)


### Internal:

- Initial release. @arybakov05 [#1](https://github.com/interaktivgmbh/interaktiv.alttexts/issues/1)
