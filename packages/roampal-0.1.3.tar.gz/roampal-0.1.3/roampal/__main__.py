"""Entry point for `python -m roampal`."""

from roampal.cli import main

if __name__ == "__main__":
    main()
