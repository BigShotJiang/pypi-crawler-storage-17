Examples
============

Every example has arguments that can be passed using a cli. Type ``-h`` for help.

.. toctree::
   :maxdepth: 4

   example_read_udbf
   example_connect_controller
   example_write_online_values
   example_read_online_values
   example_continuous_online_reading
   example_calculate_online_value
   example_read_gidata_stream
   example_write_gidata_stream
   example_buffer_to_CSV
   example_get_CSV
   example_CSV_to_buffer
   example_write_websocket
   example_websocketstream