.. giutility documentation master file, created by
   sphinx-quickstart on Tue May 12 15:53:31 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

GInsapy (python) — Beta
=======================

.. toctree::
    :maxdepth: 2

    intro
    ginsapy
    examples
    modules

..
   Indices and tables
   ==================
   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
