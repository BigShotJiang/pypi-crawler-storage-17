giutility
=================

C-header file
-------------

For a complete description about the called C functions and input/output parameteres, please refer to the ``eGateHighSpeedPort.h`` file.


Subpackages
-----------

.. toctree::
   :maxdepth: 4

   giutility.buffer
   giutility.connect


