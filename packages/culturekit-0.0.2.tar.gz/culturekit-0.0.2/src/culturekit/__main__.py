if __name__ == "__main__":
    from culturekit.cli import app

    app()
