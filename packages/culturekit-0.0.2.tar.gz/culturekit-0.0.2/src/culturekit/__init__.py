"""
CultureKit: A toolkit for evaluating the culture of large language models (LLMs) on the CD Eval benchmark.
"""

__version__ = "0.0.2"
__author__ = "devanshg03 <devansh@decisionslab.io>"
