# prefect-dbt

<p align="center">
    <a href="https://pypi.python.org/pypi/prefect-dbt/" alt="PyPI version">
        <img alt="PyPI" src="https://img.shields.io/pypi/v/prefect-dbt?color=26272B&labelColor=090422"></a>0
    <a href="https://pepy.tech/badge/prefect-dbt/" alt="Downloads">
        <img src="https://img.shields.io/pypi/dm/prefect-dbt?color=26272B&labelColor=090422" /></a>
</p>

See the docs at [https://docs.prefect.io/integrations/prefect-dbt](https://docs.prefect.io/integrations/prefect-dbt) for more information.
