"""Version information for rumoca Python package."""

__version__ = "0.7.25"
