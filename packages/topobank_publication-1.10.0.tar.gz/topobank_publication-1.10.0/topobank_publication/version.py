from DiscoverVersion import get_version

__version__ = get_version('topobank-publication', __file__)
