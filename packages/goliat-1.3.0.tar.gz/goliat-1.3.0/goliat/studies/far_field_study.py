import os
import traceback
from typing import TYPE_CHECKING

from ..logging_manager import add_simulation_log_handlers, remove_simulation_log_handlers
from ..results_extractor import ResultsExtractor
from ..setups.far_field_setup import FarFieldSetup
from ..utils import profile
from .base_study import BaseStudy

if TYPE_CHECKING:
    pass


class FarFieldStudy(BaseStudy):
    """Manages far-field simulation campaigns.

    Runs plane wave simulations across phantoms, frequencies, directions, and
    polarizations. Handles setup, run, and extraction phases with progress tracking.
    """

    def _run_study(self):
        """Executes the complete far-field study campaign.

        Iterates through all configured phantoms, frequencies, incident directions,
        and polarizations. For each combination, runs setup, simulation, and
        extraction. Tracks progress and validates execution control settings.
        """
        config_filename = os.path.basename(self.config.config_path)
        self._log(
            f"--- Starting Far-Field Study: {config_filename} ---",
            level="progress",
            log_type="header",
        )

        do_setup, do_run, do_extract = self._get_execution_control_flags()
        auto_cleanup = self.config.get_auto_cleanup_previous_results()

        if not self._validate_execution_control(do_setup, do_run, do_extract):
            return

        if not do_setup and do_run:
            self._log(
                "WARNING: Running simulations without setup is not a standard workflow and might lead to issues.",
                log_type="warning",
            )

        # Sanity check for auto_cleanup_previous_results
        self._validate_auto_cleanup_config(do_setup, do_run, do_extract, auto_cleanup)

        phantoms = self.config["phantoms"] or []
        if not isinstance(phantoms, list):
            phantoms = [phantoms]
        frequencies = self.config["frequencies_mhz"] or []
        if not isinstance(frequencies, list):
            frequencies = [frequencies]

        # Parse multi-sine frequency groups (e.g., "700+2450" -> [700, 2450])
        parsed_frequencies = []
        for freq in frequencies:
            if isinstance(freq, str) and "+" in freq:
                # Multi-sine group: "700+2450" -> [700, 2450]
                freq_list = [int(f.strip()) for f in freq.split("+")]
                parsed_frequencies.append(freq_list)
                self._log(f"Multi-sine frequency group detected: {freq_list} MHz", log_type="info")
            else:
                parsed_frequencies.append(int(freq) if isinstance(freq, str) else freq)
        frequencies = parsed_frequencies

        far_field_params = self.config["far_field_setup.environmental"] or {}
        incident_directions = far_field_params.get("incident_directions", []) if far_field_params else []
        polarizations = far_field_params.get("polarizations", []) if far_field_params else []

        total_simulations = len(phantoms) * len(frequencies) * len(incident_directions) * len(polarizations)
        self.profiler.set_total_simulations(total_simulations)
        self._set_initial_profiler_phase(do_setup, do_run, do_extract)

        self._iterate_far_field_simulations(
            phantoms, frequencies, incident_directions, polarizations, total_simulations, do_setup, do_run, do_extract
        )

    def _iterate_far_field_simulations(
        self,
        phantoms: list,
        frequencies: list,
        incident_directions: list,
        polarizations: list,
        total_simulations: int,
        do_setup: bool,
        do_run: bool,
        do_extract: bool,
    ):
        """Iterates through all far-field simulation combinations.

        Args:
            phantoms: List of phantom names.
            frequencies: List of frequencies in MHz.
            incident_directions: List of incident direction names.
            polarizations: List of polarization names.
            total_simulations: Total number of simulations.
            do_setup: Whether setup phase is enabled.
            do_run: Whether run phase is enabled.
            do_extract: Whether extract phase is enabled.
        """
        simulation_count = 0
        for phantom_name in phantoms:  # type: ignore
            for freq in frequencies:  # type: ignore
                for direction_name in incident_directions:
                    for polarization_name in polarizations:
                        simulation_count += 1
                        self._process_single_far_field_simulation(
                            phantom_name,
                            freq,
                            direction_name,
                            polarization_name,
                            simulation_count,
                            total_simulations,
                            do_setup,
                            do_run,
                            do_extract,
                        )

    def _process_single_far_field_simulation(
        self,
        phantom_name: str,
        freq: int | list[int],
        direction_name: str,
        polarization_name: str,
        simulation_count: int,
        total_simulations: int,
        do_setup: bool,
        do_run: bool,
        do_extract: bool,
    ):
        """Processes a single far-field simulation.

        Args:
            phantom_name: Name of the phantom.
            freq: Frequency in MHz.
            direction_name: Name of the incident direction.
            polarization_name: Name of the polarization.
            simulation_count: Current simulation count.
            total_simulations: Total number of simulations.
            do_setup: Whether setup phase is enabled.
            do_run: Whether run phase is enabled.
            do_extract: Whether extract phase is enabled.
        """
        self._check_for_stop_signal()
        # Format frequency for display
        freq_display = f"{'+'.join(str(f) for f in freq)}" if isinstance(freq, list) else str(freq)
        self._log(
            f"\n--- Processing Simulation {simulation_count}/{total_simulations}: "
            f"{phantom_name}, {freq_display}MHz, {direction_name}, {polarization_name} ---",
            level="progress",
            log_type="header",
        )
        if self.gui:
            self.gui.update_simulation_details(
                simulation_count,
                total_simulations,
                f"{phantom_name}, {freq_display}MHz, {direction_name}, {polarization_name}",
            )
        self._run_single_simulation(
            phantom_name,
            freq,
            direction_name,
            polarization_name,
            do_setup,  # type: ignore
            do_run,  # type: ignore
            do_extract,  # type: ignore
        )
        self.profiler.simulation_completed()
        if self.gui:
            self.gui.update_overall_progress(simulation_count, total_simulations)

    def _run_single_simulation(
        self,
        phantom_name: str,
        freq: int | list[int],
        direction_name: str,
        polarization_name: str,
        do_setup: bool,
        do_run: bool,
        do_extract: bool,
    ):
        """Runs a full simulation for a single far-field case."""
        sim_log_handlers = None
        # Format frequency for naming/paths
        freq_str = f"{'+'.join(str(f) for f in freq)}" if isinstance(freq, list) else str(freq)
        try:
            simulation = None

            # 1. Setup Phase
            if do_setup:
                with profile(self, "setup"):
                    verification_status = self.project_manager.create_or_open_project(
                        phantom_name,
                        freq,
                        "environmental",
                        polarization_name,
                        direction_name,
                    )
                    # Add simulation-specific log handlers after project directory is created
                    if self.project_manager.project_path:
                        project_dir = os.path.dirname(self.project_manager.project_path)
                        sim_log_handlers = add_simulation_log_handlers(project_dir)
                    needs_setup = not verification_status["setup_done"]

                    # Mark profiler if setup was cached/skipped
                    if not needs_setup:
                        self.profiler.phase_skipped = True

                    if needs_setup:
                        self.project_manager.create_new()

                        setup = FarFieldSetup(
                            self.config,
                            phantom_name,
                            freq,
                            direction_name,
                            polarization_name,
                            self.project_manager,
                            self.verbose_logger,
                            self.progress_logger,
                            self.profiler,
                            self.gui,
                        )

                        with self.subtask("setup_simulation", instance_to_profile=setup) as wrapper:
                            if wrapper:
                                simulation = wrapper(setup.run_full_setup)(self.project_manager)
                            else:
                                simulation = setup.run_full_setup(self.project_manager)

                        if not simulation:
                            self._log(
                                f"ERROR: Setup failed for {direction_name}_{polarization_name}. Cannot proceed.",
                                level="progress",
                                log_type="error",
                            )
                            return

                    # Always ensure metadata is written, even if setup is skipped
                    # But preserve setup_timestamp if setup wasn't done
                    surgical_config = self.config.build_simulation_config(
                        phantom_name=phantom_name,
                        frequency_mhz=freq,
                        direction_name=direction_name,
                        polarization_name=polarization_name,
                    )
                    if self.project_manager.project_path:
                        self.project_manager.write_simulation_metadata(
                            os.path.join(os.path.dirname(self.project_manager.project_path), "config.json"),
                            surgical_config,
                            update_setup_timestamp=needs_setup,  # Update timestamp only if setup was done
                        )

                    # Update do_run and do_extract based on verification
                    if verification_status["run_done"]:
                        do_run = False
                        self._log("Skipping run phase, deliverables found.", log_type="info")
                    if verification_status["extract_done"]:
                        do_extract = False
                        self._log("Skipping extract phase, deliverables found.", log_type="info")
                        # Upload results if reupload flag is set and running as assignment
                        if self._should_reupload_results() and self.project_manager.project_path:
                            project_dir = os.path.dirname(self.project_manager.project_path)
                            self._upload_results_if_assignment(project_dir)

                    if self.gui:
                        self.gui.update_stage_progress("Setup", 1, 1)
            else:
                verification_status = self.project_manager.create_or_open_project(
                    phantom_name,
                    freq,
                    "environmental",
                    polarization_name,
                    direction_name,
                )
                # Add simulation-specific log handlers after project directory is created
                if self.project_manager.project_path:
                    project_dir = os.path.dirname(self.project_manager.project_path)
                    sim_log_handlers = add_simulation_log_handlers(project_dir)

            # Get a fresh simulation handle from the document if we need to run or extract
            # If everything is done, we don't need the simulation handle
            if do_run or do_extract:
                import s4l_v1.document

                if s4l_v1.document.AllSimulations:
                    sim_name = f"EM_FDTD_{phantom_name}_{freq_str}MHz_{direction_name}_{polarization_name}"
                    simulation = next(
                        (s for s in s4l_v1.document.AllSimulations if s.Name == sim_name),
                        None,
                    )

                if not simulation:
                    self._log(
                        f"ERROR: No simulation found for {direction_name}_{polarization_name}.",
                        log_type="error",
                    )
                    return

            # 2. Run Phase
            if do_run:
                with profile(self, "run"):
                    self._execute_run_phase(simulation)  # type: ignore

            # 3. Extraction Phase
            if do_extract:
                with profile(self, "extract"):
                    # Verify run deliverables exist before starting extraction
                    if not self._verify_run_deliverables_before_extraction():
                        self._log(
                            f"Skipping extraction for {direction_name}_{polarization_name} - run deliverables not found.",
                            log_type="warning",
                        )
                        return

                    self.project_manager.reload_project()
                    sim_name = simulation.Name  # type: ignore[attr-defined]
                    reloaded_simulation = next(
                        (s for s in s4l_v1.document.AllSimulations if s.Name == sim_name),  # type: ignore[possibly-unbound]
                        None,
                    )
                    if not reloaded_simulation:
                        raise RuntimeError(f"Could not find simulation '{sim_name}' after reloading.")

                    # For multi-sine, extract at each frequency separately
                    if isinstance(freq, list):
                        self._log(f"  - Multi-sine extraction: extracting at each frequency {freq} MHz", log_type="info")
                        for single_freq in freq:
                            self._log(f"    - Extracting at {single_freq} MHz...", log_type="progress")
                            try:
                                with self.subtask(f"extract_results_{single_freq}MHz"):
                                    extractor = ResultsExtractor.from_params(
                                        config=self.config,
                                        simulation=reloaded_simulation,  # type: ignore
                                        phantom_name=phantom_name,
                                        frequency_mhz=single_freq,  # Extract at single frequency
                                        scenario_name="environmental",
                                        position_name=polarization_name,
                                        orientation_name=direction_name,
                                        study_type="far_field",
                                        verbose_logger=self.verbose_logger,
                                        progress_logger=self.progress_logger,
                                        gui=self.gui,  # type: ignore
                                        study=self,
                                    )
                                    extractor.extract()
                            except Exception as freq_error:
                                self._log(
                                    f"    - ERROR extracting at {single_freq} MHz: {freq_error}. Continuing to next frequency.",
                                    log_type="error",
                                )
                                self.verbose_logger.error(traceback.format_exc())
                    else:
                        with self.subtask("extract_results_total"):
                            extractor = ResultsExtractor.from_params(
                                config=self.config,
                                simulation=reloaded_simulation,  # type: ignore
                                phantom_name=phantom_name,
                                frequency_mhz=freq,
                                scenario_name="environmental",
                                position_name=polarization_name,
                                orientation_name=direction_name,
                                study_type="far_field",
                                verbose_logger=self.verbose_logger,
                                progress_logger=self.progress_logger,
                                gui=self.gui,  # type: ignore
                                study=self,
                            )
                            extractor.extract()
                    self._verify_and_update_metadata("extract")
                    self.project_manager.save()
                    if self.gui:
                        self.gui.update_stage_progress("Extracting Results", 1, 1)

        except Exception as e:
            self._log(f"ERROR during simulation: {e}", log_type="error")
            self.verbose_logger.error(traceback.format_exc())
        finally:
            # Remove simulation-specific log handlers
            if sim_log_handlers:
                remove_simulation_log_handlers(sim_log_handlers)
            if self.project_manager and hasattr(self.project_manager.document, "IsOpen") and self.project_manager.document.IsOpen():  # type: ignore
                self.project_manager.close()
