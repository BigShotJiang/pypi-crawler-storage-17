"""Plot modules for SAR analysis visualization.

This package contains modular plot generators organized by plot type.
"""
