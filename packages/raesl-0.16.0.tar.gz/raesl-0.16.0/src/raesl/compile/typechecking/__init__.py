"""Type checking for ESL."""
