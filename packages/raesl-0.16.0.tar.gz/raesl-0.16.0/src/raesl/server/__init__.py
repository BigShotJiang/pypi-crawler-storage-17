"""Language server module impemented according to the Language Server Protocol.

Reference:
    https://microsoft.github.io/language-server-protocol/
"""
