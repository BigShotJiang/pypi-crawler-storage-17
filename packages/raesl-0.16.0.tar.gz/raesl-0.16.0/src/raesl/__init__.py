"""Ratio ESL

Ratio ESL support in Python.
"""

__version__ = "0.16.0"


import logging

logger = logging.getLogger("raesl")
logger.setLevel(logging.INFO)
