"""Tests for doc module."""
