"""Contract tests for MCP response schema validation."""
