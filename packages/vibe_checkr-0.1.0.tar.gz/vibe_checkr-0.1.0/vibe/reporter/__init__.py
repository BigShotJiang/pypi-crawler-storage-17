"""Reporter module - Output analysis results in various formats."""

from vibe.reporter.console import ConsoleReporter

__all__ = ["ConsoleReporter"]
