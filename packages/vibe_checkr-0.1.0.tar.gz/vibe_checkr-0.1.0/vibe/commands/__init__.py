"""Command implementations for Vibe Check CLI."""
