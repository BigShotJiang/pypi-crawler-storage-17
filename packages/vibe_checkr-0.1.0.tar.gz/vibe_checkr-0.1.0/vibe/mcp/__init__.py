"""MCP server module - AI enforcement via Model Context Protocol."""
