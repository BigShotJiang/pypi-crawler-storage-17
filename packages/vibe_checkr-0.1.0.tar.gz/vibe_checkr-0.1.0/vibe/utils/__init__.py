"""Utility functions for Vibe Check."""
