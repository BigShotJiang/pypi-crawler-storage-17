if __name__ == '__main__':
    raise ImportError("This module is for import only and cannot be executed directly.")