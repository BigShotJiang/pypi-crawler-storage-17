"""ConsoleMod version information."""

__version__ = "0.1.0"
__author__ = "404Development LLC"
__email__ = "consolemod@404development.dev"
__license__ = "404_CM-v1.0"
