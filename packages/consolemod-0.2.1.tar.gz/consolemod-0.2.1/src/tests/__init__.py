"""ConsoleMod test suite."""
