"""Lyrics Translation Agent"""

from .agent import LyricsTranslationAgent

__all__ = ["LyricsTranslationAgent"]
