"""Soramimi Translation Agent"""

from .load_mapping import load_mapping

__all__ = ["load_mapping"]
