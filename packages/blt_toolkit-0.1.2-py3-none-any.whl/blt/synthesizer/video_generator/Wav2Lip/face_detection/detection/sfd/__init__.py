from .sfd_detector import SFDDetector as FaceDetector
