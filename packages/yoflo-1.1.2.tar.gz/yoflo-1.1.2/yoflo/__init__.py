# __init__.py

from .yoflo import main
