from evo_cli.base import NAME


def test_base():
    assert NAME == "evo_cli"
