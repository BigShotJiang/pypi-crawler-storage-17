"""Entry point for evo_cli."""

from evo_cli.cli import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    main()
