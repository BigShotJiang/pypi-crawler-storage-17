import streamlit as st
from proletract.modules.viz import display
from proletract.modules.viz import plots


class Visualization:
    def __init__(self):
        pass

    def visulize_region(self):
        return display.visulize_region()

    def visulize_cohort(self):
        return display.visulize_cohort()
    