from example.app.main import MainApplication

# TODO: Mejorar el ejemplo incluyendo: interaction, persistence y performance
if __name__ == "__main__":
    app = MainApplication()
    app.main_loop()
