#!/usr/bin/env python

"""Tests for `geocif` package."""


import unittest


class TestGeocif(unittest.TestCase):
    """Tests for `geocif` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
