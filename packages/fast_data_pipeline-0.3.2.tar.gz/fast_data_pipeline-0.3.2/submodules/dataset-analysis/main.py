def main():
    print("Hello from dataset-analysis!")


if __name__ == "__main__":
    main()
