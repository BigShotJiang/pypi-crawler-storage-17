"""
Init for the AnnotatableBlock.
"""

from .annotatable import AnnotatableBlock
