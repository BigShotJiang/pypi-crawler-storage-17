"""
Init for the VideoBlock.
"""

from .video import VideoBlock
