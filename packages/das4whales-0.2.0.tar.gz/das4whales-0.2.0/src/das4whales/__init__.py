from das4whales import data_handle, dsp, plot, dask_wrap, tools, detect, improcess, loc, map, spatial, assoc
__version__ = "0.2.0"
__author__ = 'Léa Bouffaut, Quentin Goestchel'

