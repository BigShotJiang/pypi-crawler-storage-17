# coding:utf-8

__project__ = "rio-xpw"
__version__ = "0.1"
__urlhome__ = "https://github.com/bondbox/rio-xpw/"
__description__ = "Rio access control based on xpw"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
