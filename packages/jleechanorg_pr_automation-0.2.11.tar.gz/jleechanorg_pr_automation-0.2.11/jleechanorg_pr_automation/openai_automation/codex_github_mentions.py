#!/usr/bin/env python3
"""
OpenAI Codex GitHub Mentions Automation

Connects to existing Chrome browser, logs into OpenAI, finds all "GitHub mention"
tasks in Codex, and clicks "Update PR" on each one.

Uses Chrome DevTools Protocol (CDP) to connect to existing browser instance,
avoiding detection as automation.

Usage:
    # Start Chrome with remote debugging (if not already running):
    ./scripts/openai_automation/start_chrome_debug.sh

    # Run this script:
    python3 scripts/openai_automation/codex_github_mentions.py

    # With custom CDP port:
    python3 scripts/openai_automation/codex_github_mentions.py --cdp-port 9222
"""

import argparse
import asyncio
import logging
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from playwright.async_api import (
    Browser,
    BrowserContext,
    Page,
    Playwright,
    TimeoutError as PlaywrightTimeoutError,
    async_playwright,
)


# Set up logging to /tmp
def setup_logging():
    """Set up logging to /tmp directory."""
    log_dir = Path("/tmp/automate_codex_update")
    log_dir.mkdir(parents=True, exist_ok=True)

    log_file = log_dir / "codex_automation.log"

    # Create logger
    logger = logging.getLogger("codex_automation")
    logger.setLevel(logging.INFO)

    # File handler
    fh = logging.FileHandler(log_file)
    fh.setLevel(logging.INFO)

    # Console handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)

    # Formatter
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)

    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger


logger = setup_logging()

# Storage state path for persisting authentication
AUTH_STATE_PATH = Path.home() / ".chatgpt_codex_auth_state.json"


class CodexGitHubMentionsAutomation:
    """Automates finding and updating GitHub mention tasks in OpenAI Codex."""

    def __init__(
        self,
        cdp_url: Optional[str] = None,
        headless: bool = False,
        task_limit: Optional[int] = 50,
        user_data_dir: Optional[str] = None,
        debug: bool = False,
        all_tasks: bool = False,
    ):
        """
        Initialize the automation.

        Args:
            cdp_url: Chrome DevTools Protocol WebSocket URL (None = launch new browser)
            headless: Run in headless mode (not recommended - may be detected)
            task_limit: Maximum number of tasks to process (default: 50, None = all GitHub Mention tasks)
            user_data_dir: Chrome profile directory for persistent login (default: ~/.chrome-codex-automation)
            debug: Enable debug mode (screenshots, HTML dump, keep browser open)
        """
        self.cdp_url = cdp_url
        self.headless = headless
        self.task_limit = task_limit
        self.user_data_dir = user_data_dir or str(Path.home() / ".chrome-codex-automation")
        self.debug = debug
        self.all_tasks = all_tasks
        self.playwright: Optional[Playwright] = None
        self.browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.page: Optional[Page] = None

    async def start_playwright(self) -> Playwright:
        if self.playwright is None:
            self.playwright = await async_playwright().start()
        return self.playwright

    async def connect_to_existing_browser(self) -> bool:
        """Connect to an existing Chrome instance over CDP."""
        await self.start_playwright()

        if not self.cdp_url:
            self.cdp_url = "http://127.0.0.1:9222"

        print(f"🔌 Connecting to existing Chrome at {self.cdp_url}...")
        logger.info(f"Connecting to Chrome at {self.cdp_url}")

        try:
            self.browser = await self.playwright.chromium.connect_over_cdp(self.cdp_url)
            print(f"✅ Connected to Chrome (version: {self.browser.version})")
            logger.info(f"Successfully connected to Chrome (version: {self.browser.version})")

            contexts = self.browser.contexts
            if contexts:
                self.context = contexts[0]
                print(f"📱 Using existing context with {len(self.context.pages)} page(s)")
            else:
                self.context = await self.browser.new_context()
                print("📱 Created new browser context")

            # Always create a new page to avoid browser UI elements (Omnibox, Extensions, etc.)
            self.page = await self.context.new_page()
            print("📄 Created new page for automation")
            return True
        except Exception as e:
            print(f"❌ Failed to connect via CDP: {e}")
            logger.warning(f"CDP connection failed: {e}")
            return False

    async def setup(self) -> bool:
        """Set up browser connection (connect or launch new)."""
        await self.start_playwright()

        connected = False
        if self.cdp_url:
            connected = await self.connect_to_existing_browser()

        if not connected:
            # Check if we have saved authentication state
            storage_state = None
            if AUTH_STATE_PATH.exists():
                print(f"📂 Found saved authentication state at {AUTH_STATE_PATH}")
                logger.info(f"Loading authentication state from {AUTH_STATE_PATH}")
                storage_state = str(AUTH_STATE_PATH)

            # Launch browser (not persistent context - use storage state instead)
            print(f"🚀 Launching Chrome...")
            logger.info(f"Launching Chrome")

            self.browser = await self.playwright.chromium.launch(
                headless=self.headless,
            )

            # Create context with storage state if available
            if storage_state:
                self.context = await self.browser.new_context(storage_state=storage_state)
                print("✅ Restored previous authentication state")
                logger.info("Restored authentication state from storage")
            else:
                self.context = await self.browser.new_context()
                print("🆕 Creating new authentication state (will save after login)")
                logger.info("Creating new browser context")

            # Create page
            self.page = await self.context.new_page()

        return True

    async def ensure_openai_login(self):
        """Navigate to OpenAI and ensure user is logged in."""
        print("\n🔐 Checking OpenAI login status...")

        # Create or use existing page
        if self.context.pages:
            self.page = self.context.pages[0]
        else:
            self.page = await self.context.new_page()

        # Navigate to OpenAI
        await self.page.goto("https://chatgpt.com/", wait_until="networkidle")
        await asyncio.sleep(2)

        try:
            await self.page.wait_for_selector(
                'button[aria-label*="User"], [data-testid="profile-button"]',
                timeout=5000,
            )
            print("✅ Already logged in to OpenAI")

            # Save authentication state if not already saved
            if not AUTH_STATE_PATH.exists():
                await self.context.storage_state(path=str(AUTH_STATE_PATH))
                print(f"💾 Authentication state saved to {AUTH_STATE_PATH}")
                logger.info(f"Saved authentication state to {AUTH_STATE_PATH}")

            return True
        except PlaywrightTimeoutError:
            try:
                await self.page.wait_for_selector(
                    'text="Log in", button:has-text("Log in")',
                    timeout=3000,
                )
                print("⚠️  Not logged in to OpenAI")

                # Check if running in non-interactive mode (cron/CI)
                import sys
                if not sys.stdin.isatty():
                    print("❌ ERROR: Authentication required but running in non-interactive mode")
                    print("   Solution: Log in manually via Chrome with CDP enabled, then run again")
                    print(f"   The script will save auth state to {AUTH_STATE_PATH}")
                    return False

                print("\n🚨 MANUAL ACTION REQUIRED:")
                print("   1. Log in to OpenAI in the browser window")
                print("   2. Wait for login to complete")
                print("   3. Press Enter here to continue...")
                input()

                # After manual login, save the authentication state immediately
                result = await self.ensure_openai_login()
                if result:
                    await self.context.storage_state(path=str(AUTH_STATE_PATH))
                    print(f"💾 New authentication state saved to {AUTH_STATE_PATH}")
                    logger.info(f"Saved new authentication state after manual login to {AUTH_STATE_PATH}")
                return result

            except Exception:
                print("⚠️  Could not determine login status")
                print("   Assuming you're logged in and continuing...")
                return True
            except Exception as login_error:
                print(f"⚠️  Unexpected login detection error: {login_error}")
                return False
        except Exception as user_menu_error:
            print(f"⚠️  Unexpected login check error: {user_menu_error}")
            return False

    async def navigate_to_codex(self):
        """Navigate to OpenAI Codex tasks page."""
        print("\n📍 Navigating to Codex...")
        logger.info("Navigating to Codex...")

        codex_url = "https://chatgpt.com/codex"

        await self.page.goto(codex_url, wait_until="domcontentloaded", timeout=30000)

        # Wait for Cloudflare challenge to complete
        print("   Waiting for Cloudflare challenge (if any)...")
        max_wait = 30  # 30 seconds max wait
        waited = 0
        while waited < max_wait:
            title = await self.page.title()
            if title != "Just a moment...":
                break
            await asyncio.sleep(2)
            waited += 2
            if waited % 10 == 0:
                print(f"   Still waiting... ({waited}s)")

        # Extra wait for dynamic content to load after Cloudflare
        await asyncio.sleep(5)

        final_title = await self.page.title()
        print(f"✅ Navigated to {codex_url} (title: {final_title})")
        logger.info(f"Successfully navigated to {codex_url} (title: {final_title})")

    async def find_github_mention_tasks(self) -> List[Dict[str, str]]:
        """
        Find task links in Codex.

        By default, filters for "GitHub Mention" tasks and applies task_limit.
        If all_tasks is True, collects the first N Codex tasks regardless of title.
        """
        if self.task_limit == 0:
            print("⚠️  Task limit set to 0 - skipping")
            return []

        try:
            print("   Waiting for content to load...")
            await asyncio.sleep(5)

            locator_selector = (
                'a[href*="/codex/"]' if self.all_tasks else 'a:has-text("GitHub Mention:")'
            )
            print(f"\n🔍 Searching for tasks using selector: {locator_selector}")

            if self.debug:
                debug_dir = Path("/tmp/automate_codex_update")
                debug_dir.mkdir(parents=True, exist_ok=True)

                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                screenshot_path = debug_dir / f"debug_screenshot_{timestamp}.png"
                html_path = debug_dir / f"debug_html_{timestamp}.html"

                await self.page.screenshot(path=str(screenshot_path))
                html_content = await self.page.content()
                html_path.write_text(html_content)

                print(f"🐛 Debug: Screenshot saved to {screenshot_path}")
                print(f"🐛 Debug: HTML saved to {html_path}")
                print(f"🐛 Debug: Current URL: {self.page.url}")
                print(f"🐛 Debug: Page title: {await self.page.title()}")

            # Find all task links - use more specific selector to exclude navigation
            # Use /codex/tasks/ to exclude navigation links like Settings, Docs
            locator = self.page.locator('a[href*="/codex/tasks/"]')
            task_count = await locator.count()

            if task_count == 0:
                print("⚠️  No tasks found, retrying after short wait...")
                await asyncio.sleep(5)
                task_count = await locator.count()
                if task_count == 0:
                    print("⚠️  Still no tasks found")
                    return []

            limit = task_count if self.task_limit is None else min(task_count, self.task_limit)
            tasks: List[Dict[str, str]] = []
            for idx in range(limit):
                item = locator.nth(idx)
                href = await item.get_attribute("href") or ""
                text = (await item.text_content()) or ""
                tasks.append({"href": href, "text": text})

            print(f"✅ Prepared {len(tasks)} task link(s) for processing")
            logger.info(f"Prepared {len(tasks)} task link(s) using selector {locator_selector}")
            return tasks

        except Exception as e:
            print(f"❌ Error finding tasks: {e}")
            logger.error(f"Error finding tasks: {e}")
            return []

    async def update_pr_for_task(self, task_link: Dict[str, str]):
        """
        Open task and click 'Update branch' button to update the PR.

        Args:
            task_link: Mapping containing href and text preview for the task
        """
        href = task_link.get("href", "")
        task_text_raw = task_link.get("text", "")
        task_text = (task_text_raw or "").strip()[:80] or "(no text)"

        try:
            target_url = href if href.startswith("http") else f"https://chatgpt.com{href}"
            print(f"   Navigating to task: {task_text}")
            await self.page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(3)

            update_branch_btn = self.page.locator('button:has-text("Update branch")').first

            if await update_branch_btn.count() > 0:
                await update_branch_btn.click()
                print("  ✅ Clicked 'Update branch' button")
                await asyncio.sleep(2)
            else:
                print("  ⚠️  'Update branch' button not found")
                return False

            await self.page.goto("https://chatgpt.com/codex", wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(3)
            return True

        except Exception as e:
            print(f"  ❌ Failed to update PR: {e}")
            try:
                await self.page.goto("https://chatgpt.com/codex", wait_until="domcontentloaded", timeout=30000)
                await asyncio.sleep(3)
            except Exception as nav_err:
                print(f"  ⚠️ Failed to navigate back to Codex after error: {nav_err}")
            return False

    async def process_all_github_mentions(self):
        """Find all GitHub mention tasks and update their PRs."""
        tasks = await self.find_github_mention_tasks()

        if not tasks:
            print("\n🎯 No GitHub mention tasks to process")
            logger.info("No tasks found to process")
            return 0

        print(f"\n🎯 Processing {len(tasks)} task(s)...")
        success_count = 0

        for i, task in enumerate(tasks, 1):
            print(f"\n📝 Task {i}/{len(tasks)}:")

            try:
                raw_text = task.get("text", "") if isinstance(task, dict) else ""
                task_text = (raw_text or "").strip()
                preview = task_text[:100] + "..." if len(task_text) > 100 else (task_text or "(no text)")
                print(f"   {preview}")
            except Exception as text_error:
                print(f"   (Could not extract task text: {text_error})")

            if await self.update_pr_for_task(task):
                success_count += 1

            await asyncio.sleep(1)

        print(f"\n✅ Successfully updated {success_count}/{len(tasks)} task(s)")
        logger.info(f"Successfully updated {success_count}/{len(tasks)} tasks")
        return success_count

    async def run(self):
        """Main automation workflow."""
        print("🤖 OpenAI Codex GitHub Mentions Automation")
        print("=" * 60)
        logger.info("Starting Codex automation workflow")

        try:
            # Step 1: Setup browser (connect or launch)
            await self.setup()

            # Step 2: Ensure logged in to OpenAI (will save auth state on first login)
            await self.ensure_openai_login()

            # Step 3: Navigate to Codex if not already there
            current_url = self.page.url
            if "chatgpt.com/codex" in current_url:
                print(f"\n✅ Already on Codex page: {current_url}")
                logger.info(f"Already on Codex page: {current_url}")
                await asyncio.sleep(3)
            else:
                await self.navigate_to_codex()

            # Step 4: Process all GitHub mention tasks
            count = await self.process_all_github_mentions()

            print("\n" + "=" * 60)
            print(f"✅ Automation complete! Processed {count} task(s)")
            logger.info(f"Automation completed successfully - processed {count} task(s)")
            return True

        except KeyboardInterrupt:
            print("\n⚠️  Automation interrupted by user")
            logger.warning("Automation interrupted by user")
            return False

        except Exception as e:
            print(f"\n❌ Automation failed: {e}")
            logger.error(f"Automation failed: {e}")
            traceback.print_exc()
            return False

        finally:
            # Close context or browser depending on how it was created
            if self.debug:
                print("\n🐛 Debug mode: Keeping browser open for inspection")
                print("   Press Ctrl+C to exit when done inspecting")
                try:
                    await asyncio.sleep(3600)  # Wait 1 hour for inspection
                except KeyboardInterrupt:
                    print("\n🐛 Debug inspection complete")

            if not self.cdp_url and not self.debug:
                # Close both context and browser (we launched them both)
                print("\n🔒 Closing browser (launched by automation)")
                if self.context:
                    await self.context.close()
                if self.browser:
                    await self.browser.close()
            else:
                print("\n💡 Browser left open (CDP mode or debug mode)")

            await self.cleanup()

    async def cleanup(self):
        """Clean up Playwright client resources."""
        if self.playwright:
            await self.playwright.stop()
            self.playwright = None


async def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Automate OpenAI Codex GitHub mention tasks",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Default (connects to Chrome on port 9222)
    python3 %(prog)s

    # Custom CDP port
    python3 %(prog)s --cdp-port 9223

    # Verbose mode
    python3 %(prog)s --verbose
        """
    )

    parser.add_argument(
        "--cdp-port",
        type=int,
        default=9222,
        help="Chrome DevTools Protocol port (default: 9222)"
    )

    parser.add_argument(
        "--use-existing-browser",
        action="store_true",
        help="Connect to existing Chrome (requires start_chrome_debug.sh)"
    )

    parser.add_argument(
        "--cdp-host",
        default="127.0.0.1",
        help="CDP host (default: 127.0.0.1)"
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose logging"
    )

    parser.add_argument(
        "--limit",
        type=int,
        default=50,
        help="Maximum number of tasks to process (default: 50)"
    )

    parser.add_argument(
        "--all-tasks",
        action="store_true",
        help="Process all Codex tasks (not just GitHub Mention tasks)",
    )

    parser.add_argument(
        "--profile-dir",
        help="Chrome profile directory for persistent login (default: ~/.chrome-codex-automation)"
    )

    parser.add_argument(
        "--debug",
        action="store_true",
        help="Debug mode: take screenshots, save HTML, keep browser open"
    )

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)
        for handler in logger.handlers:
            handler.setLevel(logging.DEBUG)

    # Build CDP URL only if using existing browser
    cdp_url = f"http://{args.cdp_host}:{args.cdp_port}" if args.use_existing_browser else None

    # Run automation
    automation = CodexGitHubMentionsAutomation(
        cdp_url=cdp_url,
        task_limit=args.limit,
        user_data_dir=args.profile_dir,
        debug=args.debug,
        all_tasks=args.all_tasks,
    )

    try:
        success = await automation.run()
        sys.exit(0 if success else 1)
    finally:
        await automation.cleanup()


if __name__ == "__main__":
    asyncio.run(main())
