# ColourfulPrint

**A cross-platform Python tool to print text in vibrant, high-intensity rainbow colors.**

ColourfulPrint is a modern, improved version of the classic `lolcat` for Linux, now fully optimized for **Windows**, **Linux**, and **macOS**. It uses high-intensity ANSI 256-color modes to generate bright, neon-like gradients and supports animated output, random color seeds, and piped input.

---

## 🚀 Features

- **Cross-Platform Compatibility:** Works perfectly on Windows (CMD & PowerShell), Linux, and macOS.
- **High-Intensity Colors:** Uses a specialized 256-color mapping formula for brighter, more vivid text than standard ANSI tools.
- **Randomized Start:** Every run starts with a different color phase, ensuring a fresh look every time.
- **Animation Mode:** Support for "Typewriter" style animation with customizable speeds.
- **Pipe Support:** Works seamlessly with piped input (e.g., `echo "Hello" | colourfulprint`).
- **Customizable:** Tweak the rainbow spread, frequency, and seed to get the exact gradient you want.

---

## 🖥️ Requirements

- Python 3.6 or higher
- [Colorama](https://pypi.org/project/colorama/) (Required for Windows ANSI support)

---

## 📦 Installation & Setup

1. **Install Python 3.6+** if you haven't already. Download it from [python.org](https://www.python.org/downloads/).
2. **Install it from PyPI** using pip :
   ```bash
   pip install colourfulprint
   ```
   or clone the repository and **install manually :**
   ```bash
    git clone https://github.com/Nishant2009/ColourFulPrint
    cd ColourFulPrint
    pip install .
    ```
3. **Verify the installation** by running:
   ```bash
   colourfulprint --version
    ```

---

## 🛠️ Usage

You can use **ColourfulPrint** in two ways: reading from a file or piping text directly into it.

### 1. Pipe Text (Echo)
Great for simple messages or system output.

**Windows (PowerShell):**
```powershell
echo "Welcome to the Windows" | colourfulprint
```

**Linux / Mac:**
```bash
echo "Welcome to the Linux" | colourfulprint
```

### 2. Read from File
Colorize an entire text file instantly.

```bash
colourfulprint my_text_file.txt
```

### 3. Animated Output
Add the `-a` flag to enable the typewriter animation effect.

```bash
echo "Loading System..." | colourfulprint -a -s 30
```

---

## ⚙️ Configuration Options

| Flag | Long Option | Description | Default |
| :--- | :--- | :--- | :--- |
| `-p` | `--spread` | Controls how wide the rainbow bands are (Lower = wider). | `3.0` |
| `-F` | `--freq` | Controls the rainbow frequency (cycle rate). | `0.1` |
| `-S` | `--seed` | Manually set the color start point. `0` means random. | `0` |
| `-a` | `--animate` | Enables the typing animation effect. | `False` |
| `-s` | `--speed` | Sets the animation speed (higher is faster). | `20.0` |
| `-v` | `--version` | Shows the current version info. | 2.0 |

### Example with Custom Settings:
```bash
# Wide spread, fast animation
colourfulprint myfile.txt -p 1.0 -a -s 50
```

---

## 📂 Project Structure

```
.
├── colourfulprint.py      # Main script
├── setup.py               # Setup script
└── README.md              # Documentation
```

---

## 💡 Troubleshooting

- **Colors look dull on Windows?** Ensure you are running the script in a modern terminal like **Windows Terminal**, **PowerShell**, or **CMD** on Windows 10/11. The script automatically handles ANSI codes via `colorama`.

- **"ModuleNotFoundError: No module named 'colorama'":** You might have uninstalled the dependency. Run `pip install colorama` to reinstall it.

---

## 🤝 Contributing

Pull requests are welcome! If you have ideas for new animation styles or color maps, feel free to open an issue or submit a PR.

---

## 📜 License

This project is open-source. Feel free to modify and distribute it.

---

## 👨‍💻 Author

**Coded by Nishant !!!**

[![GitHub](https://img.shields.io/badge/GitHub-Nishant2009-181717?style=for-the-badge&logo=github)](https://github.com/Nishant2009)

