"""
Config package
"""

from .config_accessor import ConfigAccessor

__all__ = ["ConfigAccessor"]
