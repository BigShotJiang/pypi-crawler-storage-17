"""
Test fixtures package
"""

# This directory contains test data and fixtures
