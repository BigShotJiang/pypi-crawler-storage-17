"""Supervisor agent nodes."""

from agents.supervisor.nodes.supervisor import supervisor

__all__ = ["supervisor"]

