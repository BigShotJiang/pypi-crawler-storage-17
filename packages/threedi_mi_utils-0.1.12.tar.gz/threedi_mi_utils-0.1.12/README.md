# threedi-mi-utils
Python package with utilities for the 3Di Modeller Interface

# Local development

  $ docker-compose build

  $ docker-compose run --rm qgis-desktop pytest