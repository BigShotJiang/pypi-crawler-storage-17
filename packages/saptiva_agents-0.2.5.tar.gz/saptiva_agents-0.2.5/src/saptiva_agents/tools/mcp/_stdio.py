from autogen_ext.tools.mcp import StdioMcpToolAdapter


class StdioMcpToolAdapter(StdioMcpToolAdapter):
    pass