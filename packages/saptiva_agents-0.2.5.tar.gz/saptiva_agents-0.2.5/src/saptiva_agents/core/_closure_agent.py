from autogen_core import ClosureContext, ClosureAgent


class ClosureContext(ClosureContext):
    pass
