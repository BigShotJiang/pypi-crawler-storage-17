class SpringGeneratorError(Exception):
    """Raised when Spring Boot generation fails."""
    pass
