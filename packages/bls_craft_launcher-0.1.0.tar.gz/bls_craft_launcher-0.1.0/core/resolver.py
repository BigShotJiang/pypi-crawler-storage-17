import platform
import os

class RuleResolver:
    @staticmethod
    def allowed(rules):
        if not rules:
            return True
        system = platform.system().lower()
        for rule in rules:
            os_rule = rule.get("os")
            action = rule["action"]
            if os_rule and os_rule.get("name") != system:
                continue
            if action == "disallow":
                return False
        return True

def extract_natives(version_json, natives_dir):
    """Extract native libraries (OS-specific)"""
    for lib in version_json.get("libraries", []):
        natives = lib.get("natives")
        if not natives:
            continue
        system = platform.system().lower()
        if system in natives:
            # Здесь можно распаковать .jar с natives в natives_dir
            pass
