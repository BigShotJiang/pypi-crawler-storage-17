import requests

class ManifestManager:
    URL = "https://piston-meta.mojang.com/mc/game/version_manifest.json"

    def fetch(self):
        """Fetch full version manifest"""
        resp = requests.get(self.URL)
        resp.raise_for_status()
        return resp.json()

    def list_versions(self, kind=None):
        """Return version IDs filtered by type (release, snapshot, old_alpha, old_beta)"""
        manifest = self.fetch()
        if kind is None:
            return [v["id"] for v in manifest["versions"]]
        return [v["id"] for v in manifest["versions"] if v["type"] == kind]

    def get_version_json(self, version_id):
        """Get specific version.json"""
        manifest = self.fetch()
        for v in manifest["versions"]:
            if v["id"] == version_id:
                resp = requests.get(v["url"])
                resp.raise_for_status()
                return resp.json()
        raise ValueError(f"Version {version_id} not found")
