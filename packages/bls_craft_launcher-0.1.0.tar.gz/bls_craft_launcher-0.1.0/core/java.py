import shutil

class JavaManager:
    @staticmethod
    def find_java():
        java = shutil.which("java")
        if java is None:
            raise RuntimeError("Java not found! Install Java 8+ and add to PATH.")
        return java
