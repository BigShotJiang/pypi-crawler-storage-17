import os
from .downloader import Downloader

def download_libraries(version_json, base_dir):
    dl = Downloader()
    for lib in version_json.get("libraries", []):
        if "downloads" in lib and "artifact" in lib["downloads"]:
            art = lib["downloads"]["artifact"]
            path = os.path.join(base_dir, "libraries", art["path"])
            dl.download(art["url"], path, art.get("sha1"))
