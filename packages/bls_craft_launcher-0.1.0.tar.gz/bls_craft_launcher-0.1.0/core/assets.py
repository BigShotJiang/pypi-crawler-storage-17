import os
import requests

def download_assets(version_json, assets_dir):
    index_url = version_json["assetIndex"]["url"]
    index = requests.get(index_url).json()
    for name, obj in index["objects"].items():
        h = obj["hash"]
        sub = h[:2]
        url = f"https://resources.download.minecraft.net/{sub}/{h}"
        path = os.path.join(assets_dir, "objects", sub, h)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if not os.path.exists(path):
            with open(path, "wb") as f:
                f.write(requests.get(url).content)
