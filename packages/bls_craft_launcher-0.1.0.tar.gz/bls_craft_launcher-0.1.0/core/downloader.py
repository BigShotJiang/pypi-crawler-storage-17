import os
import requests
import hashlib

class Downloader:
    def download(self, url, path, sha1=None):
        """Download file if not exists, verify sha1 if provided"""
        if os.path.exists(path):
            if sha1:
                with open(path, "rb") as f:
                    if hashlib.sha1(f.read()).hexdigest() == sha1:
                        return
            else:
                return

        os.makedirs(os.path.dirname(path), exist_ok=True)
        r = requests.get(url, stream=True)
        r.raise_for_status()
        with open(path, "wb") as f:
            for chunk in r.iter_content(8192):
                f.write(chunk)
