.. pygeos documentation master file, created by
   sphinx-quickstart on Mon Jul 22 11:02:13 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README.rst

API Reference
=============

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    usage
    files
    examples
    Example notebooks <https://github.com/nens/threedi-api-client/blob/master/examples/README.md>
