def test_dummy_pass() -> None:
    assert True
