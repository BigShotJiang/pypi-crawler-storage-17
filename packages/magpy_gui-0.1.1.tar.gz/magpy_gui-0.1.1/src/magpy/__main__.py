"""Entry point for running magpy as a module: python -m magpy"""
from magpy.app import main

if __name__ == "__main__":
    main()