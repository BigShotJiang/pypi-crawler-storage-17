"""MagPy screens - multi-screen workspace views."""

from .terminal import TerminalScreen

__all__ = [
    "TerminalScreen",
]