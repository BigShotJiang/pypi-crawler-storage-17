

def test():
    print("hello")