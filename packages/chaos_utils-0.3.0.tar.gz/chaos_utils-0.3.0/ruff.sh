#!/bin/sh

uv run ruff check --fix
uv run ruff format
