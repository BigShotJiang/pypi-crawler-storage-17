from importlib import metadata

VERSION = metadata.version('parts2kicad')