from .frechet import compute_loop_frechet  # type: ignore[import-not-found]
