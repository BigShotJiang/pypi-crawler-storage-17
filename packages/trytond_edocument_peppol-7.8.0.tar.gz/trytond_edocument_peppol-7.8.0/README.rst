#######################
EDocument Peppol Module
#######################

The *EDocument Peppol Module* provides the foundation for sending and receiving
electronic documents on the `Peppol network <https://peppol.org/>`_.


.. toctree::
   :maxdepth: 2

   setup
   configuration
   design
   releases
