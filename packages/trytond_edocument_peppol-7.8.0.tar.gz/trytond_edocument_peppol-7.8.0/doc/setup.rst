*****
Setup
*****

.. _Setting Peppol services:

Setting Peppol services
=======================

When the *EDocument Peppol Module* is activated, you must setup at least one
`service provider <model-edocument.peppol.service>`.
The first matching services will be used by default to send the pending
document.
