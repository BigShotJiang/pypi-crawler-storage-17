Stock Supply Forecast Module
############################

The stock supply forecast module takes forecast into account to compute
purchase requests.
