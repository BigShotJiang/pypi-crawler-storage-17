"""Rent Manager integration module."""

from flo.rent_manager.client import RentManagerClient

__all__ = ["RentManagerClient"]
