# Flo Integration Modules

Python integration modules for Flo workflows running in Modal containers. These modules provide easy access to QuickBooks, Plaid, Jobber, Buildium, Rent Manager, and Hostaway integrations from within your Python workflows, with credentials automatically injected by the backend.

## Overview

The Clyr backend automatically injects data source credentials into every workflow execution through a global `__data_sources__` dictionary. Workflow developers can use these modules without worrying about credential management.

## Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [Available Modules](#available-modules)
  - [QuickBooks](#quickbooks-flo_integrationsquickbooks)
  - [Plaid](#plaid-flo_integrationsplaid)
  - [Jobber](#jobber-flo_integrationsjobber)
  - [Buildium](#buildium-flo_integrationsbuildium)
  - [Rent Manager](#rent-manager-flo_integrationsrent_manager)
  - [Hostaway](#hostaway-flo_integrationshostaway)
- [Data Types](#data-types)
- [How Credentials Work](#how-credentials-work)
- [Error Handling](#error-handling)
- [Local Development](#local-development)
- [Deployment](#deployment)
- [Architecture](#architecture)

## Installation

### For Local Development

```bash
cd python-modules
pip install -e .
```

### In Modal Workflows

The module is pre-installed in the Modal base image. Simply import and use:

```python
from flo.quickbooks import QuickBooksClient
```

## Quick Start

```python
from flo.quickbooks import QuickBooksClient

# Automatically uses injected credentials (no parameters needed!)
qb = QuickBooksClient()

# Get vendors
vendors = qb.get_vendors()
print(f"Found {len(vendors)} vendors")

# Create a vendor
new_vendor = qb.create_vendor(
    name="New Supplier LLC",
    email="billing@newsupplier.com",
    phone="555-1234"
)
print(f"Created vendor: {new_vendor.name} ({new_vendor.foreign_id})")

# Access vendor data
for vendor in vendors:
    print(f"- {vendor.name}: {vendor.email}")
    # Convert to dict for JSON serialization
    vendor_dict = vendor.to_dict()
```

## Available Modules

### QuickBooks (`flo.quickbooks`)

Access QuickBooks data via Rutter API:

#### `QuickBooksClient()`

Initialize the client. Credentials are automatically loaded from injected data sources.

**Methods:**

- **`get_vendors(limit=500)`**: Get all vendors from QuickBooks
  - Returns: `List[Vendor]`
  - Automatically handles pagination
  
- **`create_vendor(name, email=None, phone=None, status='active', currency='USD', contact_name=None)`**: Create a new vendor
  - Returns: `Vendor`
  - Handles both sync and async Rutter responses

- **`get_customers(limit=500)`**: Get all customers from QuickBooks
  - Returns: `List[Customer]`
  - Automatically handles pagination

- **`get_accounts(limit=500)`**: Get all chart of accounts entries
  - Returns: `List[Account]`
  - Automatically handles pagination

- **`get_invoices(limit=500)`**: Get all invoices from QuickBooks
  - Returns: `List[Invoice]`
  - Automatically handles pagination

- **`get_classes(limit=500)`**: Get all classes from QuickBooks
  - Returns: `List[Dict[str, Any]]`

- **`get_items(limit=500)`**: Get all items from QuickBooks
  - Returns: `List[Dict[str, Any]]`

- **`get_tax_rates(limit=500)`**: Get all tax rates from QuickBooks
  - Returns: `List[Dict[str, Any]]`

### Plaid (`flo.plaid`)

Access bank account and transaction data via Plaid API:

#### `PlaidClient()`

Initialize the client. Credentials are automatically loaded from injected data sources.

**Methods:**

- **`get_accounts()`**: Get all bank accounts
  - Returns: `List[Account]`

- **`get_transactions(start_date, end_date, account_ids=None)`**: Get transactions for a date range
  - Returns: `List[Transaction]`
  - Args:
    - `start_date`: `datetime` or `date` object
    - `end_date`: `datetime` or `date` object
    - `account_ids`: Optional list of account IDs to filter by

- **`get_balance(account_ids=None)`**: Get account balances
  - Returns: `Dict[str, Any]` with balance information
  - Args: `account_ids` - Optional list of account IDs

- **`get_institution(institution_id)`**: Get institution details
  - Returns: `Institution`
  - Args: `institution_id` - Plaid institution ID

- **`get_item()`**: Get Plaid item information
  - Returns: `Dict[str, Any]` with item details

### Jobber (`flo.jobber`)

Access Jobber field service management data via GraphQL API:

#### `JobberClient()`

Initialize the client. Credentials are automatically loaded from injected data sources.

**Methods:**

- **`get_users()`**: Get all users from Jobber
  - Returns: `List[JobberUser]`
  - Automatically handles pagination

- **`get_clients(extra_ids=None)`**: Get all clients from Jobber
  - Returns: `List[JobberClient]`
  - Args: `extra_ids` - Optional list of additional client IDs to fetch
  - Automatically handles pagination

- **`get_jobs()`**: Get all jobs from Jobber
  - Returns: `List[JobberJob]`
  - Automatically handles pagination

- **`get_expenses()`**: Get all expenses from Jobber
  - Returns: `List[JobberExpense]`
  - Automatically handles pagination

- **`get_expense(expense_id)`**: Get a specific expense by ID
  - Returns: `Optional[JobberExpense]`
  - Args: `expense_id` - Jobber expense ID

### Buildium (`flo.buildium`)

Access Buildium property management data:

#### `BuildiumClient()`

Initialize the client. Credentials are automatically loaded from injected data sources.

**Methods:**

- **`get_users()`**: Get all users from Buildium
  - Returns: `List[BuildiumUser]`
  - Automatically handles pagination

- **`get_vendors()`**: Get all vendors from Buildium
  - Returns: `List[BuildiumVendor]`
  - Automatically handles pagination

- **`get_gl_accounts()`**: Get all GL accounts from Buildium
  - Returns: `List[BuildiumGlAccount]`
  - Automatically handles pagination

- **`get_bills(paid_status=None)`**: Get bills from Buildium
  - Returns: `List[BuildiumBill]`
  - Args: `paid_status` - Optional filter (e.g., "Unpaid", "Paid")
  - Automatically handles pagination

- **`get_rentals()`**: Get all rental properties from Buildium
  - Returns: `List[BuildiumRental]`

- **`get_rental_owners()`**: Get all rental owners from Buildium
  - Returns: `List[BuildiumRentalOwner]`

- **`get_rental_units()`**: Get all rental units from Buildium
  - Returns: `List[BuildiumRentalUnit]`

- **`get_associations()`**: Get all associations from Buildium
  - Returns: `List[BuildiumAssociation]`

- **`get_association_owners()`**: Get all association owners from Buildium
  - Returns: `List[BuildiumAssociationOwner]`

- **`get_association_units()`**: Get all association units from Buildium
  - Returns: `List[BuildiumAssociationUnit]`

- **`get_work_orders()`**: Get all work orders from Buildium
  - Returns: `List[BuildiumWorkOrder]`

### Rent Manager (`flo.rent_manager`)

Access Rent Manager property management data:

#### `RentManagerClient()`

Initialize the client. Credentials are automatically loaded from injected data sources.

**Methods:**

- **`get_users()`**: Get all users from Rent Manager
  - Returns: `List[RentManagerUser]`
  - Automatically handles pagination

- **`get_owners()`**: Get all owners from Rent Manager
  - Returns: `List[RentManagerOwner]`
  - Automatically handles pagination

- **`get_properties()`**: Get all properties from Rent Manager
  - Returns: `List[RentManagerProperty]`
  - Automatically handles pagination

- **`get_units()`**: Get all units from Rent Manager
  - Returns: `List[RentManagerUnit]`
  - Automatically handles pagination

- **`get_jobs()`**: Get all jobs from Rent Manager
  - Returns: `List[RentManagerJob]`
  - Automatically handles pagination

- **`get_credit_cards()`**: Get all credit cards from Rent Manager
  - Returns: `List[RentManagerCreditCard]`
  - Automatically handles pagination

- **`get_issues()`**: Get all issues from Rent Manager
  - Returns: `List[RentManagerIssue]`
  - Automatically handles pagination (PageSize=500)

- **`get_gl_accounts()`**: Get all GL accounts from Rent Manager
  - Returns: `List[RentManagerGlAccount]`
  - Automatically handles pagination

- **`get_vendors()`**: Get all vendors from Rent Manager
  - Returns: `List[RentManagerVendor]`
  - Automatically handles pagination (PageSize=100)

### Hostaway (`flo.hostaway`)

Access Hostaway vacation rental management data:

#### `HostawayClient()`

Initialize the client. Credentials are automatically loaded from injected data sources.

**Methods:**

- **`get_listings()`**: Get all listings from Hostaway
  - Returns: `List[HostawayListing]`
  - Automatically handles pagination

- **`get_owners()`**: Get all owners from Hostaway
  - Returns: `List[HostawayOwner]`
  - Automatically handles pagination

- **`get_users()`**: Get all users from Hostaway
  - Returns: `List[HostawayUser]`
  - Automatically handles pagination

- **`get_units()`**: Get all units from Hostaway
  - Returns: `List[HostawayUnit]`
  - Automatically handles pagination

## Data Types

All data types are available in their respective modules (e.g., `flo.quickbooks.models`, `flo.plaid.models`). Each model includes a `.to_dict()` method that returns camelCase dictionaries matching the backend's DTO format.

### QuickBooks Models

- `Vendor` - Vendor information
- `Customer` - Customer information
- `Account` - Chart of accounts entry
- `Invoice` - Invoice data
- `Expense` - Expense data

### Plaid Models

- `Account` - Bank account information
- `Transaction` - Transaction data
- `Institution` - Financial institution details

### Jobber Models

- `JobberUser` - User information
- `JobberClient` - Client information
- `JobberJob` - Job/work order data
- `JobberExpense` - Expense data

### Buildium Models

- `BuildiumUser`, `BuildiumVendor`, `BuildiumGlAccount`, `BuildiumBill`
- `BuildiumRental`, `BuildiumRentalOwner`, `BuildiumRentalUnit`
- `BuildiumAssociation`, `BuildiumAssociationOwner`, `BuildiumAssociationUnit`
- `BuildiumWorkOrder`

### Rent Manager Models

- `RentManagerUser`, `RentManagerOwner`, `RentManagerProperty`, `RentManagerUnit`
- `RentManagerJob`, `RentManagerCreditCard`, `RentManagerIssue`
- `RentManagerGlAccount`, `RentManagerVendor`

### Hostaway Models

- `HostawayListing` - Property listing information
- `HostawayOwner` - Owner information
- `HostawayUser` - User information
- `HostawayUnit` - Unit information

## How Credentials Work

The Clyr backend automatically injects a `__data_sources__` global variable into every workflow execution:

```python
__data_sources__ = {
    "rutter": {
        "id": "ds_xxx",
        "platform": "quickbooks",
        "access_token": "rutter_token_xxx",
        "team_id": "team_yyy"
    },
    "plaid": {
        "id": "ds_zzz",
        "platform": "plaid",
        "access_token": "plaid_token_xxx",
        "item_id": "item_xxx",
        "team_id": "team_yyy"
    },
    "jobber": {
        "id": "ds_aaa",
        "platform": "jobber",
        "access_token": "jobber_token_xxx",
        "team_id": "team_yyy"
    }
}
```

All clients automatically read from this dictionary, so you never need to handle credentials manually.

## Error Handling

```python
from flo.exceptions import (
    QuickBooksError,
    PlaidError,
    JobberError,
    BuildiumError,
    RentManagerError,
    HostawayError,
    AuthenticationError,
    APIError,
    DataSourceNotFoundError
)

try:
    qb = QuickBooksClient()
    vendors = qb.get_vendors()
except DataSourceNotFoundError as e:
    print(f"Data source not found: {e}")
except AuthenticationError as e:
    print(f"Authentication failed: {e}")
except QuickBooksError as e:
    print(f"QuickBooks error: {e}")
except APIError as e:
    print(f"API error: {e}")
```

## Context Manager

Use with context manager for automatic cleanup:

```python
with QuickBooksClient() as qb:
    vendors = qb.get_vendors()
    # Session automatically closed
```

## Manual Initialization (Testing)

For testing purposes, you can manually provide credentials:

```python
qb = QuickBooksClient(
    access_token="your_token",
    team_id="team_id",
    data_source_id="ds_id"
)
```

## Local Development

### Setup

1. **Set up Jupyter kernel** (automatically done when deploying Modal image):

```bash
# From backend package directory
cd packages/backend
bun run deploy:modal
```

Or manually:
```bash
python3 packages/backend/scripts/setup-jupyter-kernel.py
```

This creates a virtual environment and Jupyter kernel matching the Modal container environment exactly.

2. **Configure backend API URL** (optional):

Create a `.env.local` file in `python-modules/` if you need a custom backend URL:

```bash
API_BASE_URL=http://localhost:3000
```

If not set, defaults to `http://localhost:3000`.

**Prerequisites:**
- Backend server must be running
- Backend must have access to the database and configured with all required environment variables (PLAID_CLIENT_ID, PLAID_SECRET, RUTTER_CLIENT_ID, etc.)
- You need a valid `team_id` to fetch data sources

**Note:** Environment variables (like `PLAID_CLIENT_ID`, `PLAID_SECRET`, etc.) are automatically fetched from the backend and injected into your local Python environment, matching the Modal container behavior exactly. No need to configure them locally!

### Jupyter Notebook Development

1. Start Jupyter from the `python-modules` directory:

```bash
cd python-modules
jupyter notebook
```

2. When creating a new notebook, select the **"Python (Flo Workflows)"** kernel

3. In your notebook:

```python
# At the start of your notebook
from dev_utils.jupyter_helper import load_team_data_sources

# Load data sources for your team
load_team_data_sources("team_123...")

# Now use the clients normally - credentials are automatically injected
from flo.plaid import PlaidClient
plaid = PlaidClient()
accounts = plaid.get_accounts()

from flo.jobber import JobberClient
jobber = JobberClient()
clients = jobber.get_clients()
```

**Note**: The Jupyter kernel uses the same Python packages and versions as Modal containers, ensuring your local development matches production exactly.

### CLI Script Development

For running standalone Python scripts:

```bash
python dev_utils/cli_loader.py --team-id team_123... --script my_workflow.py
```

Or interactively:

```bash
python dev_utils/cli_loader.py --team-id team_123...
```

### Programmatic Usage

```python
from dev_utils.data_source_loader import inject_data_sources

# Load and inject data sources
inject_data_sources("team_123...")

# Your workflow code here
from flo.plaid import PlaidClient
plaid = PlaidClient()
```

### Example Workflows

See the `examples/` directory for complete workflow examples:

- `quickbooks/quickbooks_vendor_workflow.py` - List and create vendors
- `quickbooks/quickbooks_invoice_report.py` - Generate invoice summary report
- `plaid/plaid_transactions_workflow.py` - Fetch and analyze transactions
- `jobber/get_jobber_expenses.py` - Get Jobber expenses
- `buildium/get_buildium_vendors.py` - Get Buildium vendors
- `rent_manager/get_rent_manager_properties.py` - Get Rent Manager properties
- `hostaway/get_hostaway_listings.py` - Get Hostaway listings

## Deployment

### Adding to Modal Image

The `flo_integrations` package is automatically included in the Modal runtime image. To deploy or update:

```bash
# From backend package directory
cd packages/backend
bun run deploy:modal
```

Or manually:
```bash
# From monorepo root
modal deploy packages/backend/scripts/build-modal-image.py
python3 packages/backend/scripts/setup-jupyter-kernel.py
```

This will:
1. Build the Modal image with all Python dependencies from `requirements.txt`
2. Include the `flo_integrations` package from `python-modules/`
3. Create/update a Jupyter kernel matching the Modal environment
4. Output an image ID (e.g., `im-xxx...`)

**Important**: 
- The Modal image uses packages from `python-modules/requirements.txt` (single source of truth)
- The Jupyter kernel uses `python-modules/requirements-dev.txt` (includes production + dev tools)
- Note: The system now uses per-workflow-version images. Each workflow version builds its own image with the required dependencies.

## Architecture

This package mirrors the functionality of the TypeScript backend integration modules (`packages/backend/src/modules/integrations/`) to provide consistent data access patterns for Python workflows.

The `.to_dict()` methods on all data types return camelCase dictionaries that match the backend's DTO format, making it easy to pass data between Python workflows and the backend.

### Package Structure

```
python-modules/
├── flo_integrations/           # Main package
│   ├── quickbooks/        # QuickBooks integration
│   ├── plaid/             # Plaid integration
│   ├── jobber/            # Jobber integration
│   ├── buildium/          # Buildium integration
│   ├── rent_manager/      # Rent Manager integration
│   ├── hostaway/          # Hostaway integration
│   └── exceptions.py      # Custom exceptions
├── dev_utils/             # Development utilities
│   ├── data_source_loader.py  # Load data sources from backend
│   ├── jupyter_helper.py      # Jupyter notebook helpers
│   └── cli_loader.py          # CLI script runner
├── examples/              # Example workflow scripts
├── requirements.txt       # Production dependencies
├── requirements-dev.txt   # Development dependencies
└── setup.py               # Package setup configuration
```

## License

MIT
