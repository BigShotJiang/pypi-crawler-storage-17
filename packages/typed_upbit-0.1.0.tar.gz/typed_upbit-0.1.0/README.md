# Typed Upbit

> A fully typed, validated async client for the Upbit API

Use *autocomplete* instead of documentation.

🚧 Under construction.