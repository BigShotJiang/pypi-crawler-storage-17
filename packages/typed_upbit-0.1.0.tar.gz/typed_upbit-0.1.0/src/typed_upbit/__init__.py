"""
### Typed Upbit
> A fully typed, validated async client for the Upbit API

- Details
"""