from .version import __version__

print("\n\nGhostVision v{}\n\n".format(__version__))