from synalinks.src.programs.functional import Functional
from synalinks.src.programs.program import Program
from synalinks.src.programs.sequential import Sequential
