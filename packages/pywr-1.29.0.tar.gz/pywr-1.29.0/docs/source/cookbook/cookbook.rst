Pywr cookbook examples
======================

.. toctree::
   :maxdepth: 2

   Demand restrictions <demand_saving.rst>
   External data <dataframes.rst>
   Aggregated parameters <aggregated_parameter.rst>
   Aggregated nodes <aggregated_node.rst>
   Control curves <control_curves.rst>
