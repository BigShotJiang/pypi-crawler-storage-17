Optimisation
============

Submodules
----------

Platypus (pywr.optimisation.platypus)
-------------------------------------

.. automodule:: pywr.optimisation.platypus
    :members:
    :undoc-members:
    :show-inheritance:


Pygmo (pywr.optimisation.pygmo)
-------------------------------

.. automodule:: pywr.optimisation.pygmo
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: pywr.optimisation
    :members:
    :undoc-members:
    :show-inheritance:
