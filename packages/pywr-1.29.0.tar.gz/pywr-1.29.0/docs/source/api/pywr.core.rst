Core classes
============

.. currentmodule:: pywr.core

Core classes to

.. autosummary::
   :toctree: generated/

   Timestep
   Scenario
   ScenarioCollection
   ScenarioIndex
