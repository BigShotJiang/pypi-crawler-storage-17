Notebook Utilities
==================

.. currentmodule:: pywr.notebook

The notebook module contains some utility functions that can be used to visualise pywr networks in a Juyter notebook

.. autofunction:: pywr_model_to_d3_json

.. autofunction:: pywr_json_to_d3_json

.. autofunction:: draw_graph
