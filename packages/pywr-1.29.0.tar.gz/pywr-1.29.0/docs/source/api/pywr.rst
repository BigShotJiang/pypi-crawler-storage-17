Pywr reference documentation.
=============================

.. toctree::
   :maxdepth: 2

   pywr.core
   pywr.nodes
   pywr.optimisation
   pywr.parameters
   pywr.recorders
   pywr.solvers
   pywr.notebook
   pywr.utils

