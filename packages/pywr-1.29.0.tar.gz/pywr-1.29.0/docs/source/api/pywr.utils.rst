Utilities
=========

Bisection Search (pywr.utils.bisect)
-------------------------------------

.. automodule:: pywr.utils.bisect
    :members:
    :undoc-members:
    :show-inheritance:
