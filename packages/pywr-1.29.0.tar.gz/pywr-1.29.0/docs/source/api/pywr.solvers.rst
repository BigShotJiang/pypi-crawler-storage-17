Solvers
=======

Submodules
----------

pywr.solvers.cython_glpk module
-------------------------------

.. automodule:: pywr.solvers.cython_glpk
    :members:
    :undoc-members:
    :show-inheritance:

pywr.solvers.cython_lpsolve module
----------------------------------

.. automodule:: pywr.solvers.cython_lpsolve
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: pywr.solvers
    :members:
    :undoc-members:
    :show-inheritance:
