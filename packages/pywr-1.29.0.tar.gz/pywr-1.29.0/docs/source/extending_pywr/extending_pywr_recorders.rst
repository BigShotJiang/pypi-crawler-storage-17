.. _extending-pywr-recorders:

Extending Pywr with custom Recorders
------------------------------------

TBC
