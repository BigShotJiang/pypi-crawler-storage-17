# Test running two sub-models as a single integrated simulation

The models interact in a very simple way. 
