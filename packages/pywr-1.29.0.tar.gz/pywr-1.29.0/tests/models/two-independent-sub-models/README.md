# Test running two sub-models as a single integrated simulation

The models do not interact in this example.
