if __name__ == "__main__":
    from smtp_dane_verify.cli import main

    main()
