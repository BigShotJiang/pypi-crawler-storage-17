# pro/_generated/__init__.py
"""
Generated files directory.

This package contains auto-generated files created during the build process.
In development mode, these files may not exist.
"""
