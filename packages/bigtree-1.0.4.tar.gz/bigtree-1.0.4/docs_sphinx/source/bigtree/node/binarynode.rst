|:cherry_blossom:| BinaryNode
============================================

.. automodule:: bigtree.node.binarynode
   :members:
   :show-inheritance:
