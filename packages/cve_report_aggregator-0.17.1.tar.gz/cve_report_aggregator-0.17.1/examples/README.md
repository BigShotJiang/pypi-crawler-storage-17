# CVE Report Aggregator Examples

This directory contains example configurations and scripts demonstrating how to use the CVE Report Aggregator library.

## Example Files

- [.cve-aggregator.example.yaml](./.cve-aggregator.example.yaml): An example configuration file for setting up the CVE
  Report Aggregator.
- _TODO_: Add more example files as needed:
  - `simple_aggregator.py`: A basic example showing how to aggregate CVE reports from multiple sources.
  - `custom_filter.py`: An example demonstrating how to apply custom filters to CVE reports during aggregation.
  - `output_formats.py`: An example illustrating how to output aggregated CVE reports in different formats (JSON, CSV,
    etc.).
  - `scheduled_aggregation.py`: An example of how to set up scheduled aggregation tasks using the library.
  - `error_handling_demo.py`: A script demonstrating error handling during the aggregation process.
