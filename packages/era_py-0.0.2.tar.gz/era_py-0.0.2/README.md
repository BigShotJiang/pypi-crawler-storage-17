# era_py

Helpers for the Python port of *Empirical Research in Accounting: Tools and Methods*.

## Install
pip install era_py

## Usage
```python
from era_py import ols_dropcollinear
```