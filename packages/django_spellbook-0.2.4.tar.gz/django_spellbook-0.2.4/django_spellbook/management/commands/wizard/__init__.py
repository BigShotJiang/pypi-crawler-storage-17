# django_spellbook/management/commands/wizard/__init__.py
