"""For using as 'python3 -m webscout'."""
from .cli import main

if __name__ == "__main__":
    main()
