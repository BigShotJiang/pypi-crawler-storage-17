__version__ = "2025.12.17.1"
__prog__ = "webscout"
