class Order:
    """Ascending sort order."""

    ASCENDING = 1
    """Descending sort order."""
    DESCENDING = -1
