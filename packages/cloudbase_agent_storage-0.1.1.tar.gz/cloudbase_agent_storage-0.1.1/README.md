# cloudbase-agent-storage

Cloudbase Agent Python SDK - Framework-agnostic storage implementations

## Installation

```bash
pip install cloudbase-agent-storage
```

## Usage

```python
from cloudbase_agent import ...
```

## License

Apache-2.0
