skosprovider_atramhasis
=======================

A `Skosprovider <http://skosprovider.readthedocs.org>`_ that can talk to an
`Atramhasis <http://atramhasis.readthedocs.org>`_ instance.

.. image:: https://travis-ci.org/OnroerendErfgoed/skosprovider_atramhasis.png?branch=master
        :target: https://travis-ci.org/OnroerendErfgoed/skosprovider_atramhasis
.. image:: https://coveralls.io/repos/OnroerendErfgoed/skosprovider_atramhasis/badge.png?branch=master
        :target: https://coveralls.io/r/OnroerendErfgoed/skosprovider_atramhasis

.. image:: https://readthedocs.org/projects/skosprovider-atramhasis/badge/?version=latest
        :target: https://readthedocs.org/projects/skosprovider-atramhasis/?badge=latest
.. image:: https://badge.fury.io/py/skosprovider_atramhasis.png
        :target: http://badge.fury.io/py/skosprovider_atramhasis

