"""Entry point for python -m murmurai."""

from murmurai_server.main import run

if __name__ == "__main__":
    run()
