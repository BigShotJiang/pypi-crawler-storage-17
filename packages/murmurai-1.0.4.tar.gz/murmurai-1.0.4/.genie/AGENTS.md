---
name: Base
label: 🧞 Base
description: Global agents (orchestration, QA, analysis, maintenance)
github_url: https://github.com/namastexlabs/automagik-genie/tree/main/.genie
---

# Base Genie Agents

**Global agents available across all collectives.**

For complete orchestration framework and instructions, see:
@AGENTS.md
