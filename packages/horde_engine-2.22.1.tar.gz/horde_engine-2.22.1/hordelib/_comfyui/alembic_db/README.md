## Generate new revision

1. Update models in `/app/database/models.py`
2. Run `alembic revision --autogenerate -m "{your message}"`
