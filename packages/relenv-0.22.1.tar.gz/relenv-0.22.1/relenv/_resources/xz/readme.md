The config.h file was removed from XZ-Utils tarting with version 5.5.0.
XZ-Utils seems to build just fine with the config.h file from 5.4.7, so we're
including it here. This will be copied into the src/windows directory in the
extracted source for XZ-Utils.
