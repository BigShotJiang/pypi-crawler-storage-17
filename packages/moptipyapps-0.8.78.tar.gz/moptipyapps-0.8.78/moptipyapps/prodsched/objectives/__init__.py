"""Objectives for the production scheduling problem."""
