"""Initialize the app"""

__version__ = "3.2.2"
__title__ = "BigBrother"
