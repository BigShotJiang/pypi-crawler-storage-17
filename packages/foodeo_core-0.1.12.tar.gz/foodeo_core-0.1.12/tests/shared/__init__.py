# Marks shared tests as a package for discovery.
