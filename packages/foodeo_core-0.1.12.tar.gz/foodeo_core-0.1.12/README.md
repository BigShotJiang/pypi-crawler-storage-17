# foodeo-core
Proyecto de librería de clase de dominio de foodeo


### 1- Correr tests:

```bash
python3 -m unittest
```