import os

# Package name
PACKAGE_NAME = "jhub-swarmspawner"

default_base_path = os.path.join(os.path.expanduser("~"), ".{}".format(PACKAGE_NAME))
