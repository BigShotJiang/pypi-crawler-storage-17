"""
Tests for julee use cases.

This package contains test modules for all use cases in the julee
domain, following the Clean Architecture testing patterns established in
the sample application.
"""
