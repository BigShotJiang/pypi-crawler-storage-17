"""
Services tests for the polling contrib module infrastructure.

This module contains unit tests for service implementations in the
infrastructure layer of the polling contrib module.
"""
