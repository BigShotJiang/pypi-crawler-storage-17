"""
Temporal infrastructure tests for the polling contrib module.

This module contains unit tests for the temporal-specific infrastructure
implementations of the polling contrib module, including polling managers,
workflow proxies, and activity implementations.
"""
