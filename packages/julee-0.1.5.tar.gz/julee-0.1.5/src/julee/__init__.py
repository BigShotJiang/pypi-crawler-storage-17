"""Julee - Clean architecture for accountable and transparent digital supply chains."""

__version__ = "0.1.5"
