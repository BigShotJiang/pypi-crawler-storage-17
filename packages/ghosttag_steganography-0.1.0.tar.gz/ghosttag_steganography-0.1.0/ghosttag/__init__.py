from .core import GhostTag

__version__ = "0.1.0"
__author__ = "BitLoss Team"