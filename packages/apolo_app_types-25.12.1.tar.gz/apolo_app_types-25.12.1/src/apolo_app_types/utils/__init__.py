"""Utility functions for apolo_app_types."""
