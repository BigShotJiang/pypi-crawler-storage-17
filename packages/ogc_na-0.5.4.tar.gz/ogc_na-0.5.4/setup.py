#!/usr/bin/env python3

import setuptools

if __name__ == "__main__":
    setuptools.setup()
