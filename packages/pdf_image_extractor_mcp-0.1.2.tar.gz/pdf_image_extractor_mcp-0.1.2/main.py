def main():
    print("Hello from pdf-image-mcp!")


if __name__ == "__main__":
    main()
