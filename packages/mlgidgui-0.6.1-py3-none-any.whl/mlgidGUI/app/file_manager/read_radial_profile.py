from .object_file_manager import _ObjectFileManager
from pathlib import Path


class _ReadRadialProfile(_ObjectFileManager):
    NAME = 'radial_profiles'