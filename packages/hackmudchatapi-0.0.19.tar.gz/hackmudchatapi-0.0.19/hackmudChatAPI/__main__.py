from .hackmudChatAPI import token_refresh

if __name__ == "__main__":
    token_refresh()
