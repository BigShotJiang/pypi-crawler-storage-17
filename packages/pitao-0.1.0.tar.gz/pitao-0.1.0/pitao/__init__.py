"""
Pitão - Python com palavras reservadas em Português

Um preprocessador que traduz código Python escrito em Português
para código Python padrão executável.
"""

VERSION_NUMBER = "0.1.0"
