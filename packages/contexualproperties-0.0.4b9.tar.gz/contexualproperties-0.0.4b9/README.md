# contextual-properties

Toolkit for creating dynamic data layers for python classes