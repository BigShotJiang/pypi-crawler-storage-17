from linkmerce.core.coupang.advertising.common import CoupangAds
