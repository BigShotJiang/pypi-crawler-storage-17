Validators
----------

Validators check that the data and constraints have the appropriate shape and content.

.. autofunction:: mff.validators.can_forecast

.. autofunction:: mff.validators.is_consistent_shape

.. autofunction:: mff.validators.is_consistent_intercept
