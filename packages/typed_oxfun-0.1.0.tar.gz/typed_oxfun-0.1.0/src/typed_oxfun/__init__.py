"""
### Typed Oxfun
> A fully typed, validated async client for the Oxfun API

- Details
"""