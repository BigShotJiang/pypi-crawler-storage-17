# Typed Oxfun

> A fully typed, validated async client for the Oxfun API

Use *autocomplete* instead of documentation.

🚧 Under construction.