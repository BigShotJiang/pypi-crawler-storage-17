"""Template engine for job script generation."""

from hpc_runner.templates.engine import render_template

__all__ = ["render_template"]
