"""Core models and abstractions for hpc-tools."""
