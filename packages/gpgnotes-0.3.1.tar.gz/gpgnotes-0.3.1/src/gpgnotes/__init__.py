"""GPGNotes - A CLI note-taking tool with encryption, tagging, and Git sync."""

__version__ = "0.3.1"
