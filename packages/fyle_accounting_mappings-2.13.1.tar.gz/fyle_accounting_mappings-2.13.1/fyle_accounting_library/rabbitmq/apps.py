from django.apps import AppConfig


class FyleAccountingLibraryRabbitmqConfig(AppConfig):
    name = 'fyle_accounting_library.rabbitmq'
