from django.apps import AppConfig


class FyleAccountingLibraryCommonResourcesConfig(AppConfig):
    name = 'fyle_accounting_library.common_resources'
