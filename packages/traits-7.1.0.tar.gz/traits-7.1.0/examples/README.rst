This folder contains examples for demonstration and documentation purposes.

To aid discovery, symbolic links are created for files hosted in the package
in order to be included as package data.
