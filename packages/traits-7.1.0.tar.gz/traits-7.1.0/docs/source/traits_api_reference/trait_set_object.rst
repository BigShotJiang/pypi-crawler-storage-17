:mod:`traits.trait_set_object` Module
=====================================

.. automodule:: traits.trait_set_object
    :no-members:

Classes
-------

.. autoclass:: TraitSetEvent

.. autoclass:: TraitSet

.. autoclass:: TraitSetObject
