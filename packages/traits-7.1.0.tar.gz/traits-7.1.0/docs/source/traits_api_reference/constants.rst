:mod:`traits.constants` Module
==============================

.. automodule:: traits.constants
    :no-members:

Classes
-------

.. autodata:: TraitKind

.. autodata:: ValidateTrait

.. autodata:: DefaultValue

.. autodata:: ComparisonMode

.. autodata:: NO_COMPARE

.. autodata:: OBJECT_IDENTITY_COMPARE

.. autodata:: RICH_COMPARE
