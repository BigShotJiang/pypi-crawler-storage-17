:mod:`traits.trait_handlers` Module
===================================

.. automodule:: traits.trait_handlers
    :no-members:

Classes
-------

.. autoclass:: TraitCoerceType

.. autoclass:: TraitCastType

.. autoclass:: TraitInstance

.. autoclass:: TraitFunction

.. autoclass:: TraitEnum

.. autoclass:: TraitCompound

.. autoclass:: TraitMap


Private Functions
-----------------

.. autofunction:: traits.trait_handlers._undefined_get

.. autofunction:: traits.trait_handlers._undefined_set
