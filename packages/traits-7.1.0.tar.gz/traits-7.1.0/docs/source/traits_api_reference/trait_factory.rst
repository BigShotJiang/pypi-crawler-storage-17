:mod:`traits.trait_factory` Module
==================================

.. automodule:: traits.trait_factory
    :no-members:

.. currentmodule:: traits.trait_factory

Classes
-------

.. autoclass:: TraitFactory

.. autoclass:: TraitImportError


Functions
---------

.. autofunction:: trait_factory
