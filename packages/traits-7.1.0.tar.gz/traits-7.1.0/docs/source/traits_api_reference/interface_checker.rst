:mod:`traits.interface_checker` Module
======================================

.. automodule:: traits.interface_checker
    :no-members:

Classes
-------

.. autoclass:: InterfaceError

.. autoclass:: InterfaceChecker

Function
--------

.. autofunction:: check_implements
