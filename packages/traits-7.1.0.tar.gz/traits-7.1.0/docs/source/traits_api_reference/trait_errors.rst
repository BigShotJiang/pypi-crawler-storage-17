:mod:`traits.trait_errors` Module
=================================

.. automodule:: traits.trait_errors
    :no-members:

Functions
---------

.. autofunction:: repr_type

Classes
-------

.. autoclass:: TraitError

.. autoclass:: TraitNotificationError

.. autoclass:: DelegationError
