:mod:`traits.trait_type` Module
===============================

.. automodule:: traits.trait_type
    :no-members:

Classes
-------

.. autodata:: NoDefaultSpecified

.. autoclass:: TraitType

Private Functions
-----------------
.. autofunction:: traits.trait_type._infer_default_value_type

.. autofunction:: traits.trait_type._write_only

.. autofunction:: traits.trait_type._read_only
