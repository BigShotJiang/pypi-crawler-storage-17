:mod:`traits.trait_dict_object` Module
======================================

.. automodule:: traits.trait_dict_object
    :no-members:

Classes
-------

.. autoclass:: TraitDictEvent

.. autoclass:: TraitDict

.. autoclass:: TraitDictObject
