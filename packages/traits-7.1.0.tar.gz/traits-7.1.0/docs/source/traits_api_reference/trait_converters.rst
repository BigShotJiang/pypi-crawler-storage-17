:mod:`traits.trait_converters` Module
=====================================

.. automodule:: traits.trait_converters
    :no-members:

.. currentmodule:: traits.trait_converters


Functions
---------

.. autofunction:: as_ctrait

.. autofunction:: check_trait

.. autofunction:: trait_cast

.. autofunction:: trait_from

.. autofunction:: trait_for

.. autofunction:: mapped_trait_for
