:mod:`traits.ctraits` Module
============================

.. automodule:: traits.ctraits
    :no-members:

Classes
-------

.. autoclass:: CHasTraits

   .. automethod:: _class_traits

   .. automethod:: _instance_traits

.. autoclass:: cTrait
