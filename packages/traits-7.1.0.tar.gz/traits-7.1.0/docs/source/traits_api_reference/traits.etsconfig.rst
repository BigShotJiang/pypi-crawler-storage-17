:mod:`traits.etsconfig` Package
===============================

.. automodule:: traits.etsconfig
    :no-members:

:mod:`traits.etsconfig.etsconfig` Module
----------------------------------------

.. automodule:: traits.etsconfig.etsconfig
    :no-members:

.. autoclass:: ETSConfigType

.. autodata:: ETSConfig
