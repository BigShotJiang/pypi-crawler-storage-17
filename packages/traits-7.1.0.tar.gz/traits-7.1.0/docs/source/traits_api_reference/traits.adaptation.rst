:mod:`traits.adaptation` Package
================================

.. automodule:: traits.adaptation
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`traits.adaptation.adaptation_error` Module
------------------------------------------------

.. automodule:: traits.adaptation.adaptation_error
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`traits.adaptation.adaptation_manager` Module
--------------------------------------------------

.. automodule:: traits.adaptation.adaptation_manager
    :members:
    :undoc-members:
    :show-inheritance:


:mod:`traits.adaptation.adaptation_offer` Module
------------------------------------------------

.. automodule:: traits.adaptation.adaptation_offer
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`traits.adaptation.adapter` Module
---------------------------------------

.. automodule:: traits.adaptation.adapter
    :members:
    :undoc-members:
    :show-inheritance:
