:mod:`traits.traits` Module
===========================

.. automodule:: traits.traits
    :no-members:

.. currentmodule:: traits.traits

Classes
-------

.. autoclass:: Default

.. autoclass:: ForwardProperty


Functions
---------

.. autofunction:: Trait

.. autofunction:: Property


Private Classes
---------------

.. autoclass:: traits.traits._InstanceArgs

.. autoclass:: traits.traits._TraitMaker
