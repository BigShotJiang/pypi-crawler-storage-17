:mod:`traits.version` Module
============================

.. automodule:: traits.version
    :no-members:

Attributes
----------

.. autodata:: version

.. autodata:: git_revision
