:mod:`traits.trait_numeric` Module
==================================

.. automodule:: traits.trait_numeric
    :no-members:

Classes
-------

.. autoclass:: AbstractArray
   :show-inheritance:

.. autoclass:: Array
   :show-inheritance:

.. autoclass:: ArrayOrNone
   :show-inheritance:

.. autoclass:: CArray
   :show-inheritance:

Function
--------

.. autofunction:: dtype2trait
