:mod:`traits.ctrait` Module
===========================

.. automodule:: traits.ctrait
    :no-members:

.. currentmodule:: traits.ctrait

Classes
-------

.. autoclass:: CTrait
