:mod:`traits.editor_factories` Module
=====================================

.. automodule:: traits.editor_factories
    :no-members:

.. currentmodule:: traits.editor_factories

Functions
---------

.. autofunction:: bytes_editor

.. autofunction:: code_editor

.. autofunction:: date_editor

.. autofunction:: datetime_editor

.. autofunction:: html_editor

.. autofunction:: list_editor

.. autofunction:: multi_line_text_editor

.. autofunction:: password_editor

.. autofunction:: shell_editor

.. autofunction:: time_editor
