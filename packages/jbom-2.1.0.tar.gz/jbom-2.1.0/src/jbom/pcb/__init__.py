"""PCB integration package (placeholder).

Future modules will live here: board_loader, model, position, check, etc.
"""
__all__: list[str] = []
