"""
Run the server with: python -m gemini_video_assemble
"""

from video_app.cli import main

if __name__ == "__main__":
    main()
