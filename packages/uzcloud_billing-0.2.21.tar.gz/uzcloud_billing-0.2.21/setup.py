from setuptools import setup

setup(
    install_requires=["requests", "PyJWT", "djangorestframework"],
)
