# Type

The nature of the tag - whether the tag is dynamically assigned to products based on a filter rule or statically assigned to specified products.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


