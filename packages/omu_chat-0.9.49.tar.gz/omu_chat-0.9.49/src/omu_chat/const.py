from omu.identifier import Identifier

PLUGIN_ID = Identifier.from_key("com.omuapps:chat")
