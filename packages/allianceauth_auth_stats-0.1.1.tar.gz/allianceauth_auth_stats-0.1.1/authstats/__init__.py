"""
    Configurable Report Framework for corporate level aggregation of any data
"""
__version__ = "0.1.1"
__title__ = "AuthStats"
__url__ = "https://github.com/Solar-Helix-Independent-Transport/allianceauth-auth-reports"
