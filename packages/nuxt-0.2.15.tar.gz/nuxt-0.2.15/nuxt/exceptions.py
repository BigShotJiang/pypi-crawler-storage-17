from werkzeug.exceptions import HTTPException as SyncHTTPException
from werkzeug.exceptions import InternalServerError as SyncInternalServerError
from werkzeug.exceptions import NotFound as SyncNotFound
from starlette.websockets import WebSocketDisconnect
