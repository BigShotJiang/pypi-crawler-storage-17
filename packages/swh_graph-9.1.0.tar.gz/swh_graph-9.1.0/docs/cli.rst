.. _swh-graph-cli:

Command-line interface
======================

.. click:: swh.graph.cli:graph_cli_group
  :prog: swh graph
  :show-nested:
