Acknowledgments
===============

Dallinger is sponsored by the Defense Advanced Research Projects Agency through
the NGS2 program. The contents of this documentation does not necessarily
reflect the position or the policy of the Government and no official
endorsement should be inferred.

Dallinger's predecessor, Wallace, was supported in part by the National Science
Foundation through grants 1456709 and 1408652.
