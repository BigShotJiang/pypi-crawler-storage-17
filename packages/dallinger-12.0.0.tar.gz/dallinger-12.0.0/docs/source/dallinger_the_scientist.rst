Dallinger's incubator
=============================

Dallinger was one of the first scientists to perform experimental evolution. See his Wikipedia article for the specifics of his `incubation experiments <https://en.wikipedia.org/wiki/William_Dallinger>`__.
