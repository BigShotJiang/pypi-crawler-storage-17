"""Dallinger version number."""

__version__ = "12.0.0"
