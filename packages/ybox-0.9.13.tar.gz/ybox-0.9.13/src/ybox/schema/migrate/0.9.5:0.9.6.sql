-- include the new 'package_repos' table
SOURCE '../0.9.6-added.sql';
