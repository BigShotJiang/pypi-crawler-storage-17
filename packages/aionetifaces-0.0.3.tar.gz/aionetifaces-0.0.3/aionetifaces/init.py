raise ImportError(
    "The package 'aionetifaces' is a placeholder.\n"
    "The real package is named 'aionetiface'.\n"
    "Install it with:\n"
    "  pip install aionetiface\n"
)
