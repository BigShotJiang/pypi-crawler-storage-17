# aionetifaces?

The package you are looking for is called "aionetiface".
This is registered simply to prevent malicious squatting.
