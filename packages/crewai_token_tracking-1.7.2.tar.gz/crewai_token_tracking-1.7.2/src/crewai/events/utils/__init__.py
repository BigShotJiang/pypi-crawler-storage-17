"""Event utilities for crewAI."""
