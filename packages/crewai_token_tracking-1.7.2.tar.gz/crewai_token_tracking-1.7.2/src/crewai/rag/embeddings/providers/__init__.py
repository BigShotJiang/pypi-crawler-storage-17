"""Embedding provider implementations."""
