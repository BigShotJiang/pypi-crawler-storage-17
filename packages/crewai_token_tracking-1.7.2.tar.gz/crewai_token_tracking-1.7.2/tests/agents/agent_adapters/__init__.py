"""Tests for agent adapters."""
