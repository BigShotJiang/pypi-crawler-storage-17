"""Tests for agent builder."""
