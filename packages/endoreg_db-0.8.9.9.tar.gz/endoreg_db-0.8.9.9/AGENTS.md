# Endoreg-db Agents.md

Case Generator and Requirements Module:

- Prefer yaml config
- Reference load_base_db_data

API and Integration

- No camelCase whatsoever
- LX-Annotate has automatic conversion as is expected from other api accessors.