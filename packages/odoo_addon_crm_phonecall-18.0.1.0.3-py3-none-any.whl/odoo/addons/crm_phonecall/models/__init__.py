from . import crm_phonecall
from . import calendar
from . import res_partner
from . import crm_lead
from . import res_config_settings
