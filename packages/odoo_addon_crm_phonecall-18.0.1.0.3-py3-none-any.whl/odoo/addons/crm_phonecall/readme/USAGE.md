To use this module, you need to:

1.  Go to *CRM \> Phone Calls \> Logged Calls \> New*.
2.  If your user has *Show Scheduled Calls Menu* permission, you will
    see scheduled calls menu too.
3.  In any moment you can schedule another call, schedule a meeting or
    convert call contact to opportunity.
4.  Calls can be categorized and you can manage categories in *CRM \>
    Configuration \> Phone Calls \> Categories*.
5.  Calls can be analyzed in *CRM \> Reporting \> Phone Calls Analysis*.
