"""Tests for prefect-aws CLI commands."""
