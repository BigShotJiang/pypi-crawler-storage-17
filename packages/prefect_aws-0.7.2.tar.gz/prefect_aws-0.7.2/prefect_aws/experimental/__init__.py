from .decorators import ecs

__all__ = ["ecs"]
