---
title: Article supposément rédigé dans le passé
subtitle: Article supposément rédigé dans le passé pour tests
authors:
    - Jane Doe
categories:
    - article
comments: true
date: 2012-12-21
description: Article supposément rédigé dans le passé
icon: octicons/server-16
license: beerware
robots: index, follow
tags:
    - Fromage
    - OSM
    - QGIS
---

# Article supposément rédigé dans le futur