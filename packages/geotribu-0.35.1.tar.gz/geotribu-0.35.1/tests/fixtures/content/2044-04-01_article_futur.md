---
title: Article supposément rédigé dans le futur
subtitle: Article supposément rédigé dans le futur pour tests
authors:
    - Jane Doe
categories:
    - article
comments: true
date: 2044-04-01
icon: octicons/server-16
license: gnu-gpl-3
robots: index, follow
tags:
    - Fromage
    - IGN
    - QGIS
    - OSM
---

# Article supposément rédigé dans le futur