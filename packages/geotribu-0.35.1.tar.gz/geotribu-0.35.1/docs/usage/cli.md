# Utilisation en ligne de commande

Une fois l'outil installé, il est appelable en ligne de commande : *{{ cli_name }}*.

## Fonctionnement général

{{ cli_usage }}

```{sphinx_argparse_cli}
  :module: geotribu_cli.cli
  :hook:
  :func: main
  :prog: geotribu
  :title: Commandes et options
```
