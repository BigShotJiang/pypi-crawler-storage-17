# Tests

## Prérequis

```sh
pip install -U -e .[test]
```

## Exécution

```sh
pytest
```
