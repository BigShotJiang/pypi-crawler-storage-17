# Crédits

Outil développé en [Python 3](https://www.python.org/) à l'aide de bibliothèques open source qui font un travail formidable et qui sont nommées ici.

## Dépendances

> Généré avec [pipdeptree](https://pypi.org/project/pipdeptree/) sur les dépendances packagées (c'est-à-dire sans celles propres au développpement, documentation, test et packaging).

```{include} dependencies.md

```

## Licences

> Généré avec [pip-licenses](https://pypi.org/project/pip-licenses/) sur les dépendances packagées (c'est-à-dire sans celles propres au développpement, documentation, test et packaging).

```{include} licenses.md

```
