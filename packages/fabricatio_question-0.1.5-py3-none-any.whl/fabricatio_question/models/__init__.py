"""Models defined in fabricatio-question."""
