"""Module entry point for ``python -m deepseek_ocr``."""

from .cli import main


if __name__ == "__main__":
    main()

