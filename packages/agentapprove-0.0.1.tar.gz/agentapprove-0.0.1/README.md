# AgentApprove

Approve AI coding agent commands from your iPhone or Apple Watch.

## Status

This package is **coming soon**. We're currently in active development.

## What it does

AgentApprove lets you approve or reject commands from AI coding agents (like Claude Code and Cursor) directly from your mobile device. Instead of being locked to your computer, you can:

- Review pending agent actions from anywhere
- Approve safe commands with a tap
- Reject risky operations before they execute
- Stay productive while keeping control

## Supported agents

- Claude Code
- Cursor
- Gemini CLI
- Additional agents in development

## Get notified

Sign up for launch updates:

- Website: https://agentapprove.com
- Email: jim@agentapprove.com

## License

Proprietary. See LICENSE file for details.
