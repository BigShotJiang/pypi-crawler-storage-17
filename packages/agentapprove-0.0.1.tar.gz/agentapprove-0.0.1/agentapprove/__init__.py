"""
AgentApprove - Approve AI coding agent commands from your iPhone or Apple Watch.

Coming Soon!
"""

__version__ = "0.0.1"


def main():
    message = """
AgentApprove
============

Approve AI coding agent commands from your iPhone or Apple Watch.

Status: Coming Soon

This package is a placeholder. The full release is in active development
and will support:

  - Claude Code
  - Cursor
  - Gemini CLI
  - Additional agents

Get notified at https://agentapprove.com
"""
    print(message)


if __name__ == "__main__":
    main()
