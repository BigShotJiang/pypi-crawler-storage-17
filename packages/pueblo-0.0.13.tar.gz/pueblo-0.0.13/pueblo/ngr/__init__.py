"""
Next Generation Runner (ngr): Effortless invoke programs and test harnesses.
"""
