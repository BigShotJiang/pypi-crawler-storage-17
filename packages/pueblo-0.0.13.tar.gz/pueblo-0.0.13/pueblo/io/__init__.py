# ruff: noqa: A005
from .universal import to_io
