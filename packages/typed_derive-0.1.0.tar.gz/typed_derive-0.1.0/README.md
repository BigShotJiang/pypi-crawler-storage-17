# Typed Derive

> A fully typed, validated async client for the Derive API

Use *autocomplete* instead of documentation.

🚧 Under construction.