"""
### Typed Derive
> A fully typed, validated async client for the Derive API

- Details
"""