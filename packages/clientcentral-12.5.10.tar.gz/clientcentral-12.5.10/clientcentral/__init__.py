# -*- coding: utf-8 -*-
"""Top-level package for src."""

__author__ = """Thomas Scholtz, Monté Bouwer"""
__email__ = "thomas@labs.epiuse.com"
__version__ = "12.4.1"
