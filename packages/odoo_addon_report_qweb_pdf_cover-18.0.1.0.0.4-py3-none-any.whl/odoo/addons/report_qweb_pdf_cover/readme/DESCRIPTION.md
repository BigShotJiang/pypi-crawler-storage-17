This module allows for front and back covers to be added to the
generated PDF reports. They can be added as a separate page, at the
beginning or the end of the report, but they can also overlap the first
and last page of the actual report, respectively.
