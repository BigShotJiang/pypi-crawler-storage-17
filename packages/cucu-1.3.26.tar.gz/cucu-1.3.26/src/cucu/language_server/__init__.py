# flake8: noqa
# nopycln: file
from cucu.language_server.core import start
