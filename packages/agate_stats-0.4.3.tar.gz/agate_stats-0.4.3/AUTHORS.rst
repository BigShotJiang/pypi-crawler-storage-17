The following individuals have contributed code to agate-stats:

* `Christopher Groskopf <https://github.com/onyxfish/>`_
* `James McKinney <https://github.com/jpmckinney>`_
