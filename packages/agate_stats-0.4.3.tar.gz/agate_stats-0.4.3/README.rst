.. image:: https://github.com/wireservice/agate-stats/workflows/CI/badge.svg
    :target: https://github.com/wireservice/agate-stats/actions
    :alt: Build status

.. image:: https://coveralls.io/repos/wireservice/agate-stats/badge.svg?branch=master
    :target: https://coveralls.io/r/wireservice/agate-stats
    :alt: Coverage status

.. image:: https://img.shields.io/pypi/dw/agate-stats.svg
    :target: https://pypi.python.org/pypi/agate-stats
    :alt: PyPI downloads

.. image:: https://img.shields.io/pypi/v/agate-stats.svg
    :target: https://pypi.python.org/pypi/agate-stats
    :alt: Version

.. image:: https://img.shields.io/pypi/l/agate-stats.svg
    :target: https://pypi.python.org/pypi/agate-stats
    :alt: License

.. image:: https://img.shields.io/pypi/pyversions/agate-stats.svg
    :target: https://pypi.python.org/pypi/agate-stats
    :alt: Support Python versions

agate-stats adds statistical methods to `agate <https://github.com/wireservice/agate>`_.

Important links:

* agate             https://agate.rtfd.org
* Documentation:    https://agate-stats.rtfd.org
* Repository:       https://github.com/wireservice/agate-stats
* Issues:           https://github.com/wireservice/agate-stats/issues
