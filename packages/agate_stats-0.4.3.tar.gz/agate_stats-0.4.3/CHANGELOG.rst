0.4.3 - December 15, 2025
-------------------------

* Add Python 3.13 and 3.14 support. Drop support for end-of-life versions 3.8 and 3.9.

0.4.2 - February 23, 2024
-------------------------

* Add Python 3.8, 3.9, 3.10, 3.11, 3.12 support.
* Drop support for Python 2.7 (EOL 2020-01-01), 3.4 (2019-03-18), 3.5 (2020-09-13), 3.6 (2021-12-23), 3.7 (2023-06-27).

0.4.1 - October 3, 2023
-----------------------

* Remove six dependency.
* Fix :meth:`.ZScores.run` method.

0.4.0 - December 19, 2016
-------------------------

* Update :class:`.ZScores` to use new :class:`.Computation` interface.
* Remove monkey patching.
* Upgrade agate dependency to ``1.5.0``.

0.3.1 - November 5, 2015
------------------------

* Fix packaging issue.

0.3.0 - November 5, 2015
------------------------

* Added usage documentation.
* Convert :class:`.PearsonCorrelation` to an aggregation.
* Update required version of agate to 1.1.0.
* Removed Python 2.6 support.

0.2.0 - October 22, 2015
------------------------

* Update to support agate 1.0.0.

0.1.0 - October 6, 2015
-----------------------

* Initial version.
