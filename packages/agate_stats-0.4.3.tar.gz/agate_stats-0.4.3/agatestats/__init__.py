import agatestats.table
import agatestats.tableset
from agatestats.aggregations import PearsonCorrelation
from agatestats.computations import ZScores
