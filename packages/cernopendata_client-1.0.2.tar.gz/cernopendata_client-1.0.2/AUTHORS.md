# Authors

The list of contributors in alphabetical order:

- [Adam Novorolnik](https://github.com/ANovorolnik)
- [Alex Mieth](https://github.com/AlexMieth)
- [Dana Alsharif](https://github.com/danaalsharif)
- [Daniel Prelipcean](https://orcid.org/0000-0002-4855-194X)
- [Jan Okraska](https://orcid.org/0000-0002-1416-3244)
- [Jiri Kuncar](https://github.com/jirikuncar)
- [Joud Masoud](https://github.com/joudmas)
- [Mohammad Doleh](https://github.com/d0leh)
- [Pablo Saiz](https://github.com/psaiz)
- [Parth Shandilya](https://github.com/ParthS007)
- [Tibor Simko](https://orcid.org/0000-0001-7202-5803)
