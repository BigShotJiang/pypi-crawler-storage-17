Functionalitati

Daca este instalat modulul l10n\_ro\_stock\_account se genereaza note
contabile la fiecare miscare iesire stoc. Acest modul nu mai genereaza
in nota contabla de inchiderea a sesiunii POS liniile aferente iesirii
din gestiune.

Afisare mesaje de avertizare pentru vanzare cu numerar mai mare de 5000.
