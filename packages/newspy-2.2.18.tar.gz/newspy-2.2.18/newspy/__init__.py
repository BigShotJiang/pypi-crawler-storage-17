from newspy import shared
from newspy.newsorg import client as newsorg  # noqa
from newspy.rss import client as rss  # noqa

del shared
