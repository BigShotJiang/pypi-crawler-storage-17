import funcnodes as fn

import unittest


class TestGraph(unittest.TestCase):
    def setUp(self) -> None:
        self.ns = fn.NodeSpace()
