from pathlib import Path


ICON_ICO = Path(__file__).with_name("icon.ico")
ICON_PNG = Path(__file__).with_name("icon.png")
ICON_ICNS = Path(__file__).with_name("icon.icns")
