import render from "./anywidget/JsonSchemaNodeWidget";

export default { render };

