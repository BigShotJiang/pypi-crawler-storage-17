"""Test suite for PyNodeWidget."""
