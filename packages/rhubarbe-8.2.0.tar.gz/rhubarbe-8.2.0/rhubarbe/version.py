import importlib
import importlib.metadata

# from pyproject.toml
__version__ = importlib.metadata.version("rhubarbe")
