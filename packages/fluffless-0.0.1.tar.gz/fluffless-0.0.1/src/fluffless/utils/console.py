""" Importable singleton instance of a Rich Console object. """
from rich.console import Console

console = Console(color_system="auto")
