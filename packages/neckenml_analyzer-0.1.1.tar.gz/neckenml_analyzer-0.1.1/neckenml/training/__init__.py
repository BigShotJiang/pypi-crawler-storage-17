"""Model training components."""

from neckenml.training.trainer import TrainingService

__all__ = ["TrainingService"]
