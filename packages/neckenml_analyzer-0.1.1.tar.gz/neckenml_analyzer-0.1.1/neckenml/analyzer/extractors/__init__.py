"""Feature extraction modules for audio analysis."""
