# Docker module for dimensionality reduction models
