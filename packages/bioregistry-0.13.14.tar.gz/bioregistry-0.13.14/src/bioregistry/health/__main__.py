"""A central CLI for Bioregistry health checks."""

from .cli import main

if __name__ == "__main__":
    main()
