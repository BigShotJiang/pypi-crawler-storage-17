class BS5Customization:
    """
// Custom Sass variables
    $primary: #007bff;
    $font-family-base: 'Custom Font', sans-serif;

    // Custom CSS
    .custom-class {
    color: $primary;
    font-family: $font-family-base;
    }
    """