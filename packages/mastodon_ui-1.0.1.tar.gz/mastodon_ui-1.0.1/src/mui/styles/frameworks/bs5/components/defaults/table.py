from mui import (
    table,
    thead,
    tr,
    td,
    th,
    tbody,
    )

class DefaultTable:
    def __init__(self):
        pass

    def render(self):
        return 
'''
 
'''