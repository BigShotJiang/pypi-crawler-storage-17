from mui.templates.default_templates import base_template
from mui.templates.resolver import TemplateResolver

__all__ = [
    'base_template',
    'TemplateResolver',
]