# ArviZ governance

ArviZ governance is available on our website: https://www.arviz.org/en/latest/governance/
