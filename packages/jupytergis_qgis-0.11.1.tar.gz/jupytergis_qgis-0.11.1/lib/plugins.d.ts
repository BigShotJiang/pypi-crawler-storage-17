import { JupyterFrontEndPlugin } from '@jupyterlab/application';
export declare const qgisplugin: JupyterFrontEndPlugin<void>;
