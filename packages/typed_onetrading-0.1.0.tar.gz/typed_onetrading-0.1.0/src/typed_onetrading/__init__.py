"""
### Typed Onetrading
> A fully typed, validated async client for the Onetrading API

- Details
"""