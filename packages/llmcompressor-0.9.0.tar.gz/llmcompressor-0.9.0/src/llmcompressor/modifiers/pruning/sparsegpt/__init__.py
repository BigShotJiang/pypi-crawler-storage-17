# ruff: noqa

from .base import SparseGPTModifier

__all__ = ["SparseGPTModifier"]
