# Sequential Pipeline #
The sequential pipeline is a data pipeline, primarily used for compressing models with the
[GPTQModifier](/src/llmcompressor/modifiers/quantization/gptq/base.py) or the
[SparseGPTModifier](/src/llmcompressor/modifiers/pruning/sparsegpt/base.py).
