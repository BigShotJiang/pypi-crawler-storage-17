API Reference
-------------

.. py:currentmodule:: multicodec

.. autofunction:: add_prefix
   :no-index:

.. autofunction:: remove_prefix
   :no-index:

.. autofunction:: get_codec
   :no-index:

.. autofunction:: get_prefix
   :no-index:

.. autofunction:: is_codec
   :no-index:

.. autofunction:: extract_prefix
   :no-index:
