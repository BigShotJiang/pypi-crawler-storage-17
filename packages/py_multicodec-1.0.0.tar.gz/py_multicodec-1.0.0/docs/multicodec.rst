multicodec package
==================

Submodules
----------

multicodec.code module
----------------------

.. automodule:: multicodec.code
   :members:
   :show-inheritance:
   :undoc-members:

multicodec.code\_table module
-----------------------------

.. automodule:: multicodec.code_table
   :members:
   :show-inheritance:
   :undoc-members:

multicodec.constants module
---------------------------

.. automodule:: multicodec.constants
   :members:
   :show-inheritance:
   :undoc-members:

multicodec.exceptions module
----------------------------

.. automodule:: multicodec.exceptions
   :members:
   :show-inheritance:
   :undoc-members:

multicodec.multicodec module
----------------------------

.. automodule:: multicodec.multicodec
   :members:
   :show-inheritance:
   :undoc-members:

multicodec.serialization module
-------------------------------

.. automodule:: multicodec.serialization
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: multicodec
   :members:
   :show-inheritance:
   :undoc-members:
