=====
Usage
=====

To use py-multicodec in a project::

    import multicodec
