# flake8: noqa

# import apis into api package
from istari_digital_client.v3.api.v3_api import V3Api
