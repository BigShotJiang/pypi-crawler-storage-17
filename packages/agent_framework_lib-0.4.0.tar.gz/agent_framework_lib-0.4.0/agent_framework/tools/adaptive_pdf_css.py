"""
Adaptive CSS generation for PDF images.

This module provides the AdaptivePDFCSS class for generating CSS rules
that ensure images are properly sized, centered, and spaced within PDF documents.
"""

from dataclasses import dataclass
from typing import Literal

from .sizing_config import ImageSizingConfig


# Type alias for size preferences
SizePreference = Literal["small", "medium", "large", "full"]


@dataclass
class PDFImageConfig:
    """Configuration for image embedding in PDF.

    Attributes:
        size_preference: Desired size ("small", "medium", "large", "full")
        center_images: Whether to center images horizontally
        vertical_margin_px: Vertical margin above and below images in pixels
        maintain_aspect_ratio: Whether to preserve aspect ratio when scaling
    """

    size_preference: SizePreference = "large"
    center_images: bool = True
    vertical_margin_px: int = 20
    maintain_aspect_ratio: bool = True


class AdaptivePDFCSS:
    """Generates adaptive CSS for PDF images.

    This class provides methods to generate CSS rules for:
    - Image sizing based on size preferences (small=50%, medium=75%, large/full=100%)
    - Horizontal centering of images
    - Consistent vertical spacing between images
    - Maximum width constraints to prevent overflow

    Example:
        css_generator = AdaptivePDFCSS()

        # Generate CSS for medium-sized images
        image_css = css_generator.generate_image_css(size_preference="medium")

        # Generate container CSS for centering
        container_css = css_generator.generate_container_css()

        # Get complete CSS for PDF
        full_css = css_generator.generate_complete_css(
            size_preference="large",
            vertical_margin_px=30
        )
    """

    # Size preference to percentage mapping
    SIZE_PERCENTAGES: dict[str, int] = {
        "small": 50,
        "medium": 75,
        "large": 100,
        "full": 100,
    }

    def __init__(self, config: ImageSizingConfig | None = None):
        """Initialize the CSS generator with optional custom configuration.

        Args:
            config: Custom sizing configuration. If None, uses defaults.
        """
        self.config = config or ImageSizingConfig()

    def get_size_percentage(self, size_preference: SizePreference = "large") -> int:
        """Get the percentage for a given size preference.

        Args:
            size_preference: Desired size ("small", "medium", "large", "full")

        Returns:
            Percentage as an integer (50, 75, or 100)
        """
        return self.SIZE_PERCENTAGES.get(size_preference, 100)

    def generate_image_css(
        self,
        size_preference: SizePreference = "large",
        vertical_margin_px: int = 20,
    ) -> str:
        """Generate CSS for image sizing and centering.

        Creates CSS rules that:
        - Set image width based on size preference percentage
        - Enforce maximum width to prevent page overflow
        - Center images horizontally using auto margins
        - Add vertical margins for spacing
        - Maintain aspect ratio with height: auto

        Args:
            size_preference: Desired size ("small", "medium", "large", "full")
            vertical_margin_px: Vertical margin in pixels (default: 20)

        Returns:
            CSS string for image styling
        """
        percentage = self.get_size_percentage(size_preference)

        css = f"""
/* Adaptive image sizing - {size_preference} ({percentage}% width) */
img {{
    width: {percentage}%;
    max-width: 100%;
    height: auto;
    display: block;
    margin-left: auto;
    margin-right: auto;
    margin-top: {vertical_margin_px}px;
    margin-bottom: {vertical_margin_px}px;
}}
"""
        return css.strip()

    def generate_container_css(
        self,
        vertical_margin_px: int = 20,
    ) -> str:
        """Generate CSS for image container.

        Creates CSS rules for a container element that:
        - Centers its content horizontally
        - Provides consistent vertical spacing
        - Ensures proper text alignment for captions

        Args:
            vertical_margin_px: Vertical margin in pixels (default: 20)

        Returns:
            CSS string for container styling
        """
        css = f"""
/* Image container for centering and spacing */
.image-container {{
    text-align: center;
    margin-top: {vertical_margin_px}px;
    margin-bottom: {vertical_margin_px}px;
    width: 100%;
}}

.image-container img {{
    margin-top: 0;
    margin-bottom: 0;
}}

/* Figure element styling for images with captions */
figure {{
    text-align: center;
    margin: {vertical_margin_px}px auto;
    padding: 0;
}}

figure img {{
    margin-bottom: 10px;
}}

figcaption {{
    font-size: 0.9em;
    color: #666;
    font-style: italic;
}}
"""
        return css.strip()

    def generate_complete_css(
        self,
        size_preference: SizePreference = "large",
        vertical_margin_px: int = 20,
        include_base_styles: bool = True,
    ) -> str:
        """Generate complete CSS for PDF with images.

        Combines image CSS, container CSS, and optional base styles
        into a complete stylesheet for PDF generation.

        Args:
            size_preference: Desired size ("small", "medium", "large", "full")
            vertical_margin_px: Vertical margin in pixels (default: 20)
            include_base_styles: Whether to include base page styles (default: True)

        Returns:
            Complete CSS string for PDF styling
        """
        parts = []

        if include_base_styles:
            parts.append(self._generate_base_styles())

        parts.append(self.generate_image_css(size_preference, vertical_margin_px))
        parts.append(self.generate_container_css(vertical_margin_px))

        return "\n\n".join(parts)

    def _generate_base_styles(self) -> str:
        """Generate base styles for PDF document.

        Returns:
            CSS string with base document styles
        """
        css = """
/* Base PDF document styles */
@page {
    size: A4;
    margin: 2cm;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    font-size: 12pt;
    line-height: 1.5;
    color: #333;
}

h1, h2, h3, h4, h5, h6 {
    margin-top: 1em;
    margin-bottom: 0.5em;
    page-break-after: avoid;
}

p {
    margin-bottom: 1em;
}

/* Prevent page breaks inside images */
img {
    page-break-inside: avoid;
}
"""
        return css.strip()

    def generate_inline_style(
        self,
        size_preference: SizePreference = "large",
        vertical_margin_px: int = 20,
    ) -> str:
        """Generate inline style attribute for a single image.

        Useful when you need to apply styles directly to an img tag
        rather than using a stylesheet.

        Args:
            size_preference: Desired size ("small", "medium", "large", "full")
            vertical_margin_px: Vertical margin in pixels (default: 20)

        Returns:
            Style attribute value (without the style="" wrapper)
        """
        percentage = self.get_size_percentage(size_preference)

        style_parts = [
            f"width: {percentage}%",
            "max-width: 100%",
            "height: auto",
            "display: block",
            "margin-left: auto",
            "margin-right: auto",
            f"margin-top: {vertical_margin_px}px",
            f"margin-bottom: {vertical_margin_px}px",
        ]

        return "; ".join(style_parts)


__all__ = ["AdaptivePDFCSS", "PDFImageConfig", "SizePreference"]
