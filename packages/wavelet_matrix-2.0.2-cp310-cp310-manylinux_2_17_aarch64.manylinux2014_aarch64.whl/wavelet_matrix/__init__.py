from .wavelet_matrix import *

__doc__ = wavelet_matrix.__doc__
if hasattr(wavelet_matrix, "__all__"):
    __all__ = wavelet_matrix.__all__