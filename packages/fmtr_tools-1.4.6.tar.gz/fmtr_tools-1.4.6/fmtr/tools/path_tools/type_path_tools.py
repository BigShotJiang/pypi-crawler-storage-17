import filetype

guess = filetype.guess
