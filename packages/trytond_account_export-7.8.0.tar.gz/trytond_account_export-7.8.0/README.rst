#####################
Account Export Module
#####################

The *Account Export Module* provides the basis to export accounting moves to
external accounting software.

.. toctree::
   :maxdepth: 2

   configuration
   design
   releases
