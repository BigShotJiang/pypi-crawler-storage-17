"""Tests for the `benchmark_modules` subpackage."""
