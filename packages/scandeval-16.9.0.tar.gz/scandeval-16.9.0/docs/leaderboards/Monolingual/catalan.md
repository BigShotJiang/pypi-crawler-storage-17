---
hide:
    - toc
---
# <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Flag_of_Catalonia.svg/960px-Flag_of_Catalonia.svg.png" width="35" alt="Flag of Catalonia"/> Catalan

See the [leaderboard page](/leaderboards) for more information about all the columns.

/// tab | Generative Leaderboard
<iframe title="" aria-label="Table" id="datawrapper-chart-pC6Eu" src="https://datawrapper.dwcdn.net/pC6Eu/2/" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="886" data-external="1"></iframe><script type="text/javascript">window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}});</script>
///

/// tab | NLU Leaderboard
<iframe title="" aria-label="Table" id="datawrapper-chart-rYG8W" src="https://datawrapper.dwcdn.net/rYG8W/2/" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="902" data-external="1"></iframe><script type="text/javascript">window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}});</script>
///

/// tab | Generative Scatter Plot
<iframe title="Performance of Generative Language Models on Catalan Tasks by Model Size" aria-label="Scatter Plot" id="datawrapper-chart-noEdf" src="https://datawrapper.dwcdn.net/noEdf" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="687" data-external="1"></iframe><script type="text/javascript">window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}});</script>
///

/// tab | NLU Scatter Plot
<iframe title="Performance of Language Models on Catalan NLU Tasks by Model Size" aria-label="Scatter Plot" id="datawrapper-chart-DH0vi" src="https://datawrapper.dwcdn.net/DH0vi" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="687" data-external="1"></iframe><script type="text/javascript">window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}});</script>
///

<!-- This disables the requirement that all lines must be shorter than 88 characters -->
<!-- markdownlint-configure-file { "MD013": false } -->
