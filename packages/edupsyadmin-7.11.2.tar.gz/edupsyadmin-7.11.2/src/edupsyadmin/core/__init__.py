"""Core implementation package."""
