Fachtheoretischer Unterricht:

- Religionslehre und Religionspädagogik, Ethik und ethische Erziehung
- Englisch
- Sozialkunde und Berufskunde
- Ökologie und Gesundheit
- Rechtskunde
- Mathematisch-naturwissenschaftliche Erziehung
- Säuglingsbetreuung
- Deutsch und Kommunikation
- Pädagogik und Psychologie

Fachpraktischer Unterricht

- Praxis- und Methodenlehre und Medienerziehung
- Werkerziehung und Gestaltung
- Musik und Musikerziehung
- Sport- und Bewegungserziehung
- Hauswirtschaftliche Erziehung


Prüfungsfächer

- Deutsch und Kommunikation
- Pädagogik und Psychologie
