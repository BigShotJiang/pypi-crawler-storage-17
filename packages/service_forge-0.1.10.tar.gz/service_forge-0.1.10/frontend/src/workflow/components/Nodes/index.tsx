import type { NodeTypes } from '@xyflow/react';

import { BaseNode } from './BaseNode';

export const kNodeTypes: NodeTypes = {
  base: BaseNode,
};
