from .service_router import service_router, set_service, get_service

__all__ = ["service_router", "set_service", "get_service"]

