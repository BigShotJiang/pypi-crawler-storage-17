"""HTML export for Rich tables.

Export metrics tables to HTML format using Rich Console.
"""

from __future__ import annotations
