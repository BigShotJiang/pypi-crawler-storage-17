"""Main comprehensive dashboard.

Full HTML dashboard with all metrics, interactive plots, and analysis tools.
"""

from __future__ import annotations
