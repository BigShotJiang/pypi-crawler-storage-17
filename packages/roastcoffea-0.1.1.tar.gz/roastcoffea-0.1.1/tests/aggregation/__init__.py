"""Tests for aggregation modules."""
