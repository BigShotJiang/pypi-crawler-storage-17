"""titiler.mosaic"""

__version__ = "1.0.0"

from . import errors, factory  # noqa
from .factory import MosaicTilerFactory  # noqa
