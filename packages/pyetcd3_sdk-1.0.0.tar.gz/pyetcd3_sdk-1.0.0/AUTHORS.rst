=======
Credits
=======

Development Lead
----------------

* wwyoyo03 <wwyoyo03@gmail.com>
* XuanYang-cn <jumpthepig@gmail.com>
* Louis Taylor <louis@kragniz.eu>

Contributors
------------

* Giuseppe Lavagetto <glavagetto@wikimedia.org>
* InvalidInterrupt <invalidinterrupt@users.noreply.github.com>
