"""MCP resources for AI context (syntax help, query examples, knowledge)."""

from . import examples, knowledge, syntax_help  # noqa: F401
