from mgraph_db.mgraph.schemas.Schema__MGraph__Edge import Schema__MGraph__Edge


class Schema__Graph_RAG__Edge__Confidence          (Schema__MGraph__Edge): pass

class Schema__Graph_RAG__Edge__Direct_Relationship (Schema__MGraph__Edge): pass
class Schema__Graph_RAG__Edge__Direct_Relationships(Schema__MGraph__Edge): pass

class Schema__Graph_RAG__Edge__Domain_Relationship (Schema__MGraph__Edge): pass

class Schema__Graph_RAG__Edge__Concept              (Schema__MGraph__Edge): pass
class Schema__Graph_RAG__Edge__Category             (Schema__MGraph__Edge): pass
class Schema__Graph_RAG__Edge__Entity               (Schema__MGraph__Edge): pass
class Schema__Graph_RAG__Edge__Relationship_Type    (Schema__MGraph__Edge): pass
class Schema__Graph_RAG__Edge__Strength             (Schema__MGraph__Edge): pass