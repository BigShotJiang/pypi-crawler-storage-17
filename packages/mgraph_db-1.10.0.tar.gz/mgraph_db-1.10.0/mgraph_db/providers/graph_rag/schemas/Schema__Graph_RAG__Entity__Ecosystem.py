from typing                             import List
from osbot_utils.type_safe.Type_Safe    import Type_Safe

class Schema__Graph_RAG__Entity__Ecosystem(Type_Safe):
    platforms    : List[str]
    standards    : List[str]
    technologies : List[str]

 # Related platforms
 # Related standards
 # Related technologies