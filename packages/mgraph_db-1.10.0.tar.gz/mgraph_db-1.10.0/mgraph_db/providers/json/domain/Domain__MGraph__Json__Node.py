from mgraph_db.mgraph.domain.Domain__MGraph__Node              import Domain__MGraph__Node
from mgraph_db.providers.json.models.Model__MGraph__Json__Node import Model__MGraph__Json__Node

class Domain__MGraph__Json__Node(Domain__MGraph__Node):
    node: Model__MGraph__Json__Node                                                              # Reference to node model