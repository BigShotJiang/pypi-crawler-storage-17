"""Configuration constants for PaperMC Plugin Manager."""


class Config:
    """Central configuration for the PaperMC Plugin Manager."""

    # Default settings
    DEFAULT_SOURCE: str = "not_set"
