## v0.2.0 (2025-12-18)

### Feat

- **dependencies**: add commitizen for conventional commits support

### Fix

- **publish**: trigger on version tags, update actions and better uv sync
- add permissions to test workflow

## v0.1.0 (2025-08-07)
