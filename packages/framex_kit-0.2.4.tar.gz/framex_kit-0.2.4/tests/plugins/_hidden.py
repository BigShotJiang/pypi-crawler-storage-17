import pytest

pytest.fail("should not be imported")
