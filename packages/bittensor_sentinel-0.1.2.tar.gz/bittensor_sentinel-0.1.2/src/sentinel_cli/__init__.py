"""Sentinel CLI - Command line interface for the Sentinel package."""
