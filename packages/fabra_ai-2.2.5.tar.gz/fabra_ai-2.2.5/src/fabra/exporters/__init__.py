"""Export Context Record evidence to where incidents live (logs, OTEL, tickets)."""
