from SimbioReader.sr import SimbioReader, DataStructure, Data, Detector, HK
from SimbioReader.sr import __version__