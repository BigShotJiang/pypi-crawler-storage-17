###############################
Account Payment Clearing Module
###############################

The *Account Payment Clearing Module* allows to generate account move when a
payment is succeeded between the receivable/payable account to a clearing
account defined on the payment journal.

.. toctree::
   :maxdepth: 2

   design
   releases
