"""
AitoCoder - An AI-powered coding agent from the terminal

autocoder/ contains all the functionality, while
login_modules/ handles login & authentication
"""

# Suppress all warnings early (before any other imports)
import warnings
warnings.filterwarnings("ignore")
