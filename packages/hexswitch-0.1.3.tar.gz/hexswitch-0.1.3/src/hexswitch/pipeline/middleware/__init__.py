"""Middleware module for pipeline processing."""

from hexswitch.pipeline.middleware.base import Middleware

__all__ = ["Middleware"]

