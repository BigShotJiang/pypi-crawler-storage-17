# Typed Bitflyer

> A fully typed, validated async client for the Bitflyer API

Use *autocomplete* instead of documentation.

🚧 Under construction.