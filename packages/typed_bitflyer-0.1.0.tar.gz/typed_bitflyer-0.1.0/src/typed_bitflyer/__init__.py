"""
### Typed Bitflyer
> A fully typed, validated async client for the Bitflyer API

- Details
"""