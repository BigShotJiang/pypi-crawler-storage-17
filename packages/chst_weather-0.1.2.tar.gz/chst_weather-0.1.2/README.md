# A Simple MCP Weather Server written in Python

mcp-name: io.modelcontextprotocol.anonymous/weather-server-python

See the [Quickstart](https://modelcontextprotocol.io/quickstart) tutorial for more information.
