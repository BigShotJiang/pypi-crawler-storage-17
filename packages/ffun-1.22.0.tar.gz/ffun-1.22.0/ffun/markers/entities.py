import enum


class Marker(int, enum.Enum):
    read = 1
