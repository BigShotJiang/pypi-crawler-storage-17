# Backend for Feeds Fun

- Web-based news reader. Self-hosted, if it is your way.
- Automatically assigns tags to news entries.
- You create rules to score news by tags.
- Then filter and sort news how you want.

Service is up and running at https://feeds.fun

Documentation can be found in the repository: https://github.com/Tiendil/feeds.fun
