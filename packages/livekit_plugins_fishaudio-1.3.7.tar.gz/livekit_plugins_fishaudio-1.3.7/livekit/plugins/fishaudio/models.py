from typing import Literal

OutputFormat = Literal["wav", "pcm", "mp3"]

LatencyMode = Literal["normal", "balanced"]
