# Jelka Python API

Python API for Jelka FMF patterns.

## Note

If you want to contribute your own Jelka FMF patterns, you should check out the [Storži](https://github.com/Jelka-FMF/Storzi) repository for full instructions about developing and contributing patterns.

## Documentation

The documentation is currently in development. You can check out the source code for more information and Storži repository for existing patterns.
