from enum import Enum


class Status(Enum):
    OK = "OK"
    #  no idea what other statuses can be returned
