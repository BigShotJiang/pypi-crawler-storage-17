# 允许使用 python -m ali_ops 方式运行
from . import main

if __name__ == "__main__":
    main()