# Changelog

## 0.1.0 (2025-12-17)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/RobertCraigie/robert-test-24-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([f229ef3](https://github.com/RobertCraigie/robert-test-24-python/commit/f229ef3819e46a91a9fcfde240503069d8281828))


### Chores

* **internal:** codegen related update ([49421aa](https://github.com/RobertCraigie/robert-test-24-python/commit/49421aa6da001d72efc5f13f4f8a815c139ea309))
* **internal:** codegen related update ([6b24bcd](https://github.com/RobertCraigie/robert-test-24-python/commit/6b24bcd9bc48dfd36f5c8971f6b9264775dfd293))
* **internal:** codegen related update ([298c932](https://github.com/RobertCraigie/robert-test-24-python/commit/298c932949f947212f80d4098202ec8261d76050))
* **internal:** codegen related update ([1dff2e4](https://github.com/RobertCraigie/robert-test-24-python/commit/1dff2e4c3ed704cdf7c51592154f25b8f8376235))
* **internal:** codegen related update ([84f7f64](https://github.com/RobertCraigie/robert-test-24-python/commit/84f7f64f6e7b8732e3e3c25a4796fb2d5c15e3d9))
* **internal:** codegen related update ([b9a2cd5](https://github.com/RobertCraigie/robert-test-24-python/commit/b9a2cd560ebf2014dc92b11c88da49921d11bfd9))
* **internal:** codegen related update ([a7d37f0](https://github.com/RobertCraigie/robert-test-24-python/commit/a7d37f0853c51323bf70db6eeb3e611562350855))
* **internal:** codegen related update ([ea9691b](https://github.com/RobertCraigie/robert-test-24-python/commit/ea9691ba6be8de359fbe068ee374275c69cb5a4f))
* update SDK settings ([bc20237](https://github.com/RobertCraigie/robert-test-24-python/commit/bc202371b3024ebab8492f059a0678b81d94a8c0))
* update SDK settings ([f74be1c](https://github.com/RobertCraigie/robert-test-24-python/commit/f74be1cbffb6b3cc12124aec0ce39157926bf930))
