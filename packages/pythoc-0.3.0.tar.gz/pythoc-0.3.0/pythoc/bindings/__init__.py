"""
C Header Parser - A complete C header file parser written in PythoC

This tool parses C header files and generates PythoC bindings.
"""
