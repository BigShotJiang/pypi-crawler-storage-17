"""Standard library for PythoC"""
