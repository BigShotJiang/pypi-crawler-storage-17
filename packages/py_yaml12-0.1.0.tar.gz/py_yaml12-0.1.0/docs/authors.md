# Authors and Citation

## Authors

- **Tomasz Kalinowski** - Author, maintainer.
- **Posit Software, PBC** - Copyright holder, funder.

## Citation

Kalinowski T (2025). *yaml12: Fast YAML 1.2 Parser and Formatter for
Python*. Python package version 0.1.0.

```
@software{kalinowski_yaml12_python_2025,
  title   = {yaml12: Fast YAML 1.2 Parser and Formatter for Python},
  author  = {Tomasz Kalinowski},
  year    = {2025},
  version = {0.1.0},
  url     = {https://github.com/posit-dev/py-yaml12}
}
```
