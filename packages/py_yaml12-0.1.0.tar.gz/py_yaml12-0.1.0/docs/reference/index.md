# Reference

## All functions

- [`parse_yaml()`](parse_yaml.md) and
  [`read_yaml()`](parse_yaml.md): Parse YAML 1.2 text or files into
  Python structures.
- [`format_yaml()`](format_yaml.md) and
  [`write_yaml()`](format_yaml.md): Format or write Python objects as
  YAML 1.2.
