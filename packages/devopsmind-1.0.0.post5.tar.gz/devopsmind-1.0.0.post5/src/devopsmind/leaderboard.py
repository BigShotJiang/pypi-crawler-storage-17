from pathlib import Path
import json
import urllib.request
from rich.table import Table
from rich.text import Text

# -------------------------------------------------
# Paths & Sources
# -------------------------------------------------
CACHE_PATH = Path.home() / ".devopsmind" / "leaderboard.json"

REMOTE_LEADERBOARD_URL = (
    "https://raw.githubusercontent.com/"
    "InfraForgeLabs/DevOpsMind/leaderboard/leaderboard/leaderboard.json"
)


# -------------------------------------------------
# Internal helpers
# -------------------------------------------------
def _fetch_remote_leaderboard():
    """
    Fetch leaderboard.json from the official DevOpsMind repository.
    This is optional and only used if local cache is missing.
    """
    try:
        with urllib.request.urlopen(REMOTE_LEADERBOARD_URL, timeout=5) as response:
            data = json.loads(response.read().decode("utf-8"))

        CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(CACHE_PATH, "w") as f:
            json.dump(data, f, indent=2)

        return data
    except Exception:
        return None


# -------------------------------------------------
# Public API
# -------------------------------------------------
def show_leaderboards():
    data = None

    # 1️⃣ Prefer local cached leaderboard
    if CACHE_PATH.exists():
        try:
            with open(CACHE_PATH, "r") as f:
                data = json.load(f)
        except Exception:
            data = None

    # 2️⃣ Fallback to remote leaderboard (non-fatal)
    if data is None:
        data = _fetch_remote_leaderboard()

    # 3️⃣ Still nothing? Show original message
    if not data:
        return Text(
            "Leaderboard not synced yet.\nRun devopsmind sync first.",
            style="yellow"
        )

    players = data.get("players", [])

    table = Table(title="Global Leaderboard")
    table.add_column("#", justify="right")
    table.add_column("Gamer")
    table.add_column("Username", style="dim")
    table.add_column("XP", justify="right")
    table.add_column("Rank")

    players = sorted(players, key=lambda p: p.get("xp", 0), reverse=True)

    for idx, player in enumerate(players, start=1):
        table.add_row(
            str(idx),
            player.get("handle", "-"),
            player.get("username", "-"),
            str(player.get("xp", 0)),
            player.get("rank", "-"),
        )

    return table
