Task:
1. Initialize a git repository in the current directory (if not already initialized).
2. Create a file named README.md containing exactly:
   DevOpsMind Git
3. Stage and commit the file with the commit message:
   Initial commit

The validator checks that .git exists, README.md exists with correct content, and that the most recent commit message is exactly 'Initial commit'.
