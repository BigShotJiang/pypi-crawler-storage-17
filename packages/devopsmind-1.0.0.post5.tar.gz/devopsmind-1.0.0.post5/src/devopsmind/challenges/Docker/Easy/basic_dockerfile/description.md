Create a file named Dockerfile.

Requirements:
- Base image must be: python:3.10-slim
- Container should run a command that prints exactly: Hello Docker
- You may use CMD ["echo", "Hello Docker"] or ENTRYPOINT.

Validator checks Dockerfile syntax (static analysis) — no actual Docker build required.
