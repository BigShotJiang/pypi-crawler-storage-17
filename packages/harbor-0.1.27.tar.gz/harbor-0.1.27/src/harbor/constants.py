from pathlib import Path

CACHE_DIR = Path("~/.cache/harbor/tasks").expanduser()
