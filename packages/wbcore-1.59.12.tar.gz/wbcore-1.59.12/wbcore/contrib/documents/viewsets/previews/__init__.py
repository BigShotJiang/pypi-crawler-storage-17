from .documents import DocumentPreviewConfig
