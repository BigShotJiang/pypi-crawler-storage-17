# Mimical (Modelling the Intensity of Multiply Imaged CelestiAl light)

