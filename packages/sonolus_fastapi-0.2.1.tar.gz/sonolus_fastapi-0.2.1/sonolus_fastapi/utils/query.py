class Query:
    def __init__(self, raw: dict):
        self.raw = raw