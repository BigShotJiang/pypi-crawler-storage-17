ebm4subjects package
====================

.. automodule:: ebm4subjects
   :members:
   :show-inheritance:
   :undoc-members:

ebm4subjects.analyzer module
----------------------------

.. automodule:: ebm4subjects.analyzer
   :members:
   :show-inheritance:
   :undoc-members:

ebm4subjects.chunker module
---------------------------

.. automodule:: ebm4subjects.chunker
   :members:
   :show-inheritance:
   :undoc-members:

ebm4subjects.duckdb\_client module
----------------------------------

.. automodule:: ebm4subjects.duckdb_client
   :members:
   :show-inheritance:
   :undoc-members:

ebm4subjects.ebm\_logging module
--------------------------------

.. automodule:: ebm4subjects.ebm_logging
   :members:
   :show-inheritance:
   :undoc-members:

ebm4subjects.ebm\_model module
------------------------------

.. automodule:: ebm4subjects.ebm_model
   :members:
   :show-inheritance:
   :undoc-members:

ebm4subjects.embedding\_generator module
----------------------------------------

.. automodule:: ebm4subjects.embedding_generator
   :members:
   :show-inheritance:
   :undoc-members:

ebm4subjects.prepare\_data module
---------------------------------

.. automodule:: ebm4subjects.prepare_data
   :members:
   :show-inheritance:
   :undoc-members:
