def test_hello():
    assert 1 + 1 == 2