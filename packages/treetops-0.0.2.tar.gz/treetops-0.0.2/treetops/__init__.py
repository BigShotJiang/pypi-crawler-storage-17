"""Treetops - A simple Python package template."""

__version__ = "0.0.2"

