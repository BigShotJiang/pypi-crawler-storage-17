The following individuals have contributed code to proof:

* `Christopher Groskopf <https://github.com/onyxfish/>`_
* `Jean Jordaan <https://github.com/jean>`__
* `Peter M. Landwehr <https://github.com/pmlandwehr>`_
* `James McKinney <https://github.com/jpmckinney>`_
