from proof.analysis import Analysis, never_cache
