Creative Commons Attribution-NonCommercial 4.0 International

Copyright (c) 2025 EOMAP

This work is licensed under the Creative Commons Attribution-NonCommercial 4.0 
International License.

You are free to:
- Share — copy and redistribute the material in any medium or format
- Adapt — remix, transform, and build upon the material

Under the following terms:
- Attribution — You must give appropriate credit, provide a link to the license, 
  and indicate if changes were made.
- NonCommercial — You may not use the material for commercial purposes.

The licensor cannot revoke these freedoms as long as you follow the license terms.

Full license text: https://creativecommons.org/licenses/by-nc/4.0/legalcode

NO WARRANTIES: This work is provided "AS IS" without warranties of any kind, 
either express or implied, including but not limited to warranties of 
merchantability, fitness for a particular purpose, or non-infringement.