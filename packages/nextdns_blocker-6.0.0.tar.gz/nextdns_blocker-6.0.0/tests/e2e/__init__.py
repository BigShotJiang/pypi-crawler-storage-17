"""End-to-end tests for nextdns-blocker."""
