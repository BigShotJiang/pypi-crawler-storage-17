from django.contrib import admin

# Register your models here.
# You can add custom admin interfaces for payment tracking models here

# Example:
# from .models import Transaction
# 
# @admin.register(Transaction)
# class TransactionAdmin(admin.ModelAdmin):
#     list_display = ['trans_ref', 'amount', 'status', 'created_at']
#     list_filter = ['status', 'created_at']
#     search_fields = ['trans_ref', 'email']
