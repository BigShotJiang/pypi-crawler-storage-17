__author__ = "Ivan Begtin"
__version__ = "1.0.7"
__licence__ = "MIT"
__doc__ = "Iterable data processing Python library"



from .helpers.detect import open_iterable

open_it = open_iterable