#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright 2024-2025 NXP
#
# SPDX-License-Identifier: BSD-3-Clause
"""Top-level package for NXP Python CodeCheck."""

__author__ = """NXP"""
__email__ = "spsdk@nxp.com"
__version__ = "0.3.16"
