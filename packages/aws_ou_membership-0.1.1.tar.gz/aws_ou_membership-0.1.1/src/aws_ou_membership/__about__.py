# SPDX-FileCopyrightText: 2025-present Neil Smith <neil@nsmith.net>
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.1"
