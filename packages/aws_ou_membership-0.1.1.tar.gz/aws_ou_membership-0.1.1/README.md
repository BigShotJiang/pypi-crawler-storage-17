# AWS Account OU Membership

> [!WARNING]
> This repository is no longer maintained.

Please use **aws-org-view** instead, which provides the same functionality and is actively maintained:  
👉 https://github.com/nsmithuk/aws-org-view
