# Instructions

L'élève propose *la requête SQL* suivante :
```sql
{{requete}}
```

Que fait cette requête ? Explique le fonctionnement ainsi que les opérateurs utilisés pour cette requête.
