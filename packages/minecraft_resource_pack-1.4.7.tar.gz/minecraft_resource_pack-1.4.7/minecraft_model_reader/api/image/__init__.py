import os

default_pack_icon_path = os.path.join(
    os.path.dirname(__file__), "missing_pack_java.png"
)
missing_no_path = os.path.join(os.path.dirname(__file__), "missing_no.png")
