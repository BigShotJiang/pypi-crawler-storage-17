import time


class AIAgentErrorEngine:
    def __init__(self, train_data, handler, model):
        self.rule_provider = train_data
        self.error_reader = handler
        self.model = model

    def run(self, window_name: str, cycles: int, executor):
        """
        Runs intelligent error handling.
        Returns a list of all detected error payloads
        after retries are completed.
        """

        detected_errors = []

        for step in range(1, cycles + 1):
            payload = self._wait_for_error(window_name)

            if not payload:
                print("[INFO] No error detected, stopping engine")
                return detected_errors   # ✅ RETURN HERE

            print(f"[ERROR DETECTED] Step {step}: {payload}")

            detected_errors.append(payload)  # ✅ COLLECT ERROR

            rule = self._match_rule(payload)

            if not rule:
                raise Exception(
                    "Unhandled application error:\n"
                    "----------------------------\n"
                    f"{payload}"
                )

            actions = {
                k: v() if callable(v) else v
                for k, v in rule["action"].items()
            }

            executor(window_name, actions)

            time.sleep(0.3)

        raise Exception("Maximum error-handling attempts exceeded")


    def _wait_for_error(self, window_name, timeout=3.0, poll=0.2):
        end = time.time() + timeout
        while time.time() < end:
            payload = self.error_reader(window_name)
            if payload:
                return payload
            time.sleep(poll)
        return None

    def _match_rule(self, payload: dict):
        code = payload.get("code")
        doc = (payload.get("document") or "").lower()

        for rule in self.rule_provider():
            r_code = rule.get("code")
            r_doc = (rule.get("document") or "").lower()
            cond = (rule.get("condition") or "any").lower()

            code_match = r_code is not None and r_code == code
            doc_match = bool(r_doc) and r_doc in doc

            # ---------------------------
            # NEW CONDITION MODEL
            # ---------------------------
            if cond == "any":  # OR
                if code_match or doc_match:
                    return rule

            elif cond == "and":  # AND
                checks = []
                if r_code is not None:
                    checks.append(code_match)
                if r_doc:
                    checks.append(doc_match)

                if checks and all(checks):
                    return rule

            # ---------------------------
            # BACKWARD COMPATIBILITY
            # ---------------------------
            elif cond == "code" and code_match:
                return rule

            elif cond == "document" and doc_match:
                return rule

            elif cond == "both" and code_match and doc_match:
                return rule

        return None

