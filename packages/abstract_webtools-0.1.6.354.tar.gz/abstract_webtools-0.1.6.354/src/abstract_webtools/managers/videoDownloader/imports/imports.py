from ..imports import *
get_corrected_url == get_video_url
