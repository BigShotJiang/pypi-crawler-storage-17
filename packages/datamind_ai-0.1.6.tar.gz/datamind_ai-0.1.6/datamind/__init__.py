"""DataMind - AI-powered data analysis and dashboard generator."""

__version__ = "0.1.6"
__author__ = "Saidjon Ravshanov"
__github__ = "https://github.com/SaidjonRavshanov"
