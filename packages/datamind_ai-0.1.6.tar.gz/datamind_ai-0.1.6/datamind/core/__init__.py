"""Core data processing modules."""
