"""Dashboard generation modules."""
