__description__ = "Update HOWARD databases"
__version__ = "0.1.0"
__enabled__ = True
__main_file__ = "__main__"
__main_function__ = "main"
