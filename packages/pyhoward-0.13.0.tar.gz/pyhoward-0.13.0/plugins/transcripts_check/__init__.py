__description__ = "Check if a list of transcript is present in a generated transcript table from a VCF file"
__version__ = "1.0.0"
__enabled__ = True
__main_file__ = "__main__"
__main_function__ = "main"
