import logging

logger = logging
logger.basicConfig(format="%(message)s", level=logging.INFO)
