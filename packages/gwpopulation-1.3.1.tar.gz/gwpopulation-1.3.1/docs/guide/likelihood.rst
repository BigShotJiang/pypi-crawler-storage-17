Population likelihood
=====================

.. automodule:: gwpopulation.hyperpe
    :noindex: