Setting the Backend
===================

.. automodule:: gwpopulation.backend
    :noindex: