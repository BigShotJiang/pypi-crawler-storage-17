Code of Conduct
---------------

We closely follow the `Contributor Covenant Code of Conduct <https://www.contributor-covenant.org/version/2/0/code_of_conduct/>`_
as described in the `code of conduct <https://github.com/ColmTalbot/GWPopulation/CODE_OF_CONDUCT.md>`_.
Please read the full text so that you can understand what actions will and will not be tolerated.