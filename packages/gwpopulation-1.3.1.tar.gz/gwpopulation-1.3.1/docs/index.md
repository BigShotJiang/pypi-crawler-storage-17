```{include} ../README.md
```

```{toctree}
   :hidden:

   User Guide <guide/index>
   Examples <examples/index>
   Contributing <contributing/index>
   Changelog <https://github.com/ColmTalbot/gwpopulation/releases>
```