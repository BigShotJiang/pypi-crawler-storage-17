"""
Test package: schema_v1_2_0_pkg
"""

def main():
    """Main entry point for schema_v1_2_0_pkg."""
    print("Hello from schema_v1_2_0_pkg!")
    return "schema_v1_2_0_pkg executed successfully"

if __name__ == "__main__":
    main()
