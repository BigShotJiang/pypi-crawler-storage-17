# Installation

To install ESSnmx and all of its dependencies, use

`````{tab-set}
````{tab-item} pip
```sh
pip install essnmx
```
````
````{tab-item} conda
```sh
conda install -c conda-forge essnmx
```
````
`````
