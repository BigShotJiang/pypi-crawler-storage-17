# User Guide

```{toctree}
---
maxdepth: 1
---

workflow
mcstas_workflow
mcstas_workflow_chunk
scaling_workflow
installation
```
