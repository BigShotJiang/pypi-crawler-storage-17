from .transform import CobaltTransformer as Transformer

assert Transformer
