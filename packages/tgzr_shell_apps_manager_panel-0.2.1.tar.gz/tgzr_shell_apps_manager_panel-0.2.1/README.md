# tgzr.shell.manager_panel
The Manager Panel let you manage your TGZR installations and their configuration.
