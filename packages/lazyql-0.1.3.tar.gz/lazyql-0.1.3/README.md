# 🦥 LazyQL

![LazyQL Logo](docs/assets/logo.png)
[![PyPI version](https://img.shields.io/pypi/v/lazyql.svg)](https://pypi.org/project/lazyql/)
[![Python versions](https://img.shields.io/pypi/pyversions/lazyql.svg)](https://pypi.org/project/lazyql/)
[![License](https://img.shields.io/pypi/l/lazyql.svg)](https://gitlab.com/creibaud/lazyql/-/blob/main/LICENSE)
[![pipeline status](https://gitlab.com/creibaud/lazyql/badges/main/pipeline.svg)](https://gitlab.com/creibaud/lazyql/-/commits/main)
[![coverage report](https://gitlab.com/creibaud/lazyql/badges/main/coverage.svg)](https://gitlab.com/creibaud/lazyql/-/commits/main)
[![Code style: ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://gitlab.com/astral-sh/ruff)
[![Checked with mypy](https://www.mypy-lang.org/static/mypy_badge.svg)](https://mypy-lang.org/)

**LazyQL** is a powerful Python library designed to instantly generate full-featured GraphQL CRUD APIs using **Pydantic** models and **MongoDB** (via Motor).

It automates the tedious parts of backend development—schema generation, resolvers, filtering, and database interactions—while providing built-in enterprise-grade features like audit logging, soft deletes, and field-level permissions.

---

## 🚀 Key Features

- **Instant CRUD**: Generate Strawberry GraphQL `Query` and `Mutation` types directly from Pydantic models.
- **MongoDB & Async**: Built on top of `motor` for high-performance asynchronous database interactions.
- **Advanced Filtering**: Built-in support for rich filters (e.g., `name_contains`, `age_gte`, `tags_in`).
- **Audit Logging**: Automatic tracking of all changes (Create, Update, Delete, Restore) in a Time Series collection.
- **Soft Deletes**: Native support for soft deletion and restoration of documents.
- **Permissions**: Granular permission system for `create`, `update`, `delete`, and `list` operations.
- **ACID Transactions**: Support for MongoDB transactions when a client session is available.
- **Extensible**: Easily customize and extend generated resolvers and schemas.

---

## 📦 Installation

```bash
pip install lazyql
```

---

## ⚡ Quick Start

Define your data model and generate a GraphQL API in seconds.

### 1. Define your Model

Inherit from `BaseDBModel` to get automatic ID, timestamps (`created_at`, `updated_at`), and audit fields.

```python
from lazyql import BaseDBModel
from pydantic import Field

class User(BaseDBModel):
    name: str
    email: str
    role: str = Field(default="user")
    age: int
```

### 2. Generate GraphQL Schema

Use `create_crud_api` to build the Query and Mutation classes.

```python
import strawberry
from lazyql import create_crud_api

# Generate CRUD resolvers
Query, Mutation = create_crud_api(
    model=User,
    collection_name="users"
)

# Create the executable schema
schema = strawberry.Schema(query=Query, mutation=Mutation)
```

### 3. Run It

Integrate with your favorite ASGI framework (e.g., FastAPI, Starlette).

---

## 📄 License

LazyQL is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
