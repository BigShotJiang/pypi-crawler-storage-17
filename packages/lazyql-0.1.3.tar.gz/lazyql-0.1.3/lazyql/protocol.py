from typing import Any, Protocol, TypeVar

from pydantic import BaseModel


class HasToPydantic(Protocol):
    def to_pydantic(self) -> BaseModel: ...


class HasFromPydantic(Protocol):
    @classmethod
    def from_pydantic(cls, instance: Any) -> Any: ...


TInput = TypeVar("TInput", bound=HasToPydantic)
TOutput = TypeVar("TOutput", bound=HasFromPydantic)
TFilter = TypeVar("TFilter")
