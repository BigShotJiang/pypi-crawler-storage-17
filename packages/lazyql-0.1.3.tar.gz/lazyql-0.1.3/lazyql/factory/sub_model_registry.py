from typing import Type

import strawberry
from pydantic import BaseModel

from ..models import BaseDBModel


def register_sub_model(model: Type[BaseModel]):
    """
    Register nested Pydantic model for GraphQL schema.
    """
    model_name = model.__name__
    is_db_model = issubclass(model, BaseDBModel)

    # 1. Préparation dynamique des champs
    # On évite de définir deux classes entières.
    namespace = {}
    if is_db_model:
        # On injecte 'id' seulement si c'est un modèle DB
        namespace["__annotations__"] = {"id": strawberry.ID}
        namespace["id"] = strawberry.field(name="id")

    # 2. Création unique de la classe
    # On crée la classe python nativement avec type()
    RawOutputType = type(f"{model_name}Output", (), namespace)

    # 3. Application du décorateur Strawberry
    # Le décorateur s'applique comme une fonction normale
    output_type = strawberry.experimental.pydantic.type(
        model=model, all_fields=True, name=f"{model_name}Output"
    )(RawOutputType)

    # InputType ne change pas car il n'a pas de logique conditionnelle
    @strawberry.experimental.pydantic.input(
        model=model, all_fields=True, name=f"{model_name}Input"
    )
    class InputType:
        pass

    return output_type, InputType
