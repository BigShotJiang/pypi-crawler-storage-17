from strawberry.types import Info

from .permissions import PermissionChecker


def is_authenticated(info: Info) -> bool:
    """
    Check if user is authenticated.

    Expects info.context["user"] to be set and not "anonymous".
    """
    user = info.context.get("user")
    return user is not None and user != "anonymous"


def is_admin(info: Info) -> bool:
    """
    Check if user has admin role.

    Expects info.context["roles"] to contain "admin".
    """
    roles = info.context.get("roles", [])
    return "admin" in roles


def has_role(role: str) -> PermissionChecker:
    """
    Create a permission checker for a specific role.

    Args:
        role: Role name to check for

    Returns:
        Permission checker function

    Example:
        permissions = {
            "delete": has_role("admin"),
            "create": has_role("editor")
        }
    """

    def checker(info: Info) -> bool:
        roles = info.context.get("roles", [])
        return role in roles

    return checker


def has_any_role(*required_roles: str) -> PermissionChecker:
    """
    Check if user has any of the specified roles.

    Example:
        permissions = {"delete": has_any_role("admin", "moderator")}
    """

    def checker(info: Info) -> bool:
        roles = info.context.get("roles", [])
        return any(role in roles for role in required_roles)

    return checker


def has_all_roles(*required_roles: str) -> PermissionChecker:
    """
    Check if user has all of the specified roles.

    Example:
        permissions = {"delete": has_all_roles("admin", "verified")}
    """

    def checker(info: Info) -> bool:
        roles = info.context.get("roles", [])
        return all(role in roles for role in required_roles)

    return checker
