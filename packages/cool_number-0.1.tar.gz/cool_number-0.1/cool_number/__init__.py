import main
print('Critical error, import again')
