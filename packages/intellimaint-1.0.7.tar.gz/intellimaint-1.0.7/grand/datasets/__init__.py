__author__ = "Mohamed-Rafik Bouguelia"
__license__ = "MIT"
__email__ = "mohamed-rafik.bouguelia@hh.se"

from .data_loader import load_vehicles
from .data_loader import load_artificial
from .data_loader import load_taxi
