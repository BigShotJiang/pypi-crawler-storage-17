#  Copyright (c) Akretion 2020
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl)
from . import sale_channel
from . import sale_order
from . import account_move
from . import sale_channel_owner
