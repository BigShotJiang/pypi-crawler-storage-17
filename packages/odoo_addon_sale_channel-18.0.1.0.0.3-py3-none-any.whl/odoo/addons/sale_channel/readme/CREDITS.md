The development of this module has been financially supported by:

- Akretion \<www.akretion.com\>
