This module is the base for the notion of a sale channel, used for
eCommerce purposes. For example, you might have an "ebay" channel and an
"amazon" channel, and want to register a sale and know which channel it
comes from.
