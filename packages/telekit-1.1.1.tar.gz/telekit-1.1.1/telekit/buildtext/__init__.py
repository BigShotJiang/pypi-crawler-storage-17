# Copyright (c) 2025 Ving Studio, Romashka
# Licensed under the MIT License. See LICENSE file for full terms.

from . import styles
from .styles import Styles

__all__ = [
    "styles",
    "Styles"
]