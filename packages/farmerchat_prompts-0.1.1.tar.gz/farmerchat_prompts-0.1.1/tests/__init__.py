"""
Tests for farmerchat-prompts package
"""
