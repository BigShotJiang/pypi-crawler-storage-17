from django.apps import AppConfig


class AdminitaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "adminita"
    verbose_name = "Adminita"
