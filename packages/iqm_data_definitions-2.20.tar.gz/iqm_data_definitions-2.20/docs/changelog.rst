.. _changes:

=========
Changelog
=========

.. include:: ../CHANGELOG.rst
