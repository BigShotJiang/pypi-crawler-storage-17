import structlog

default_logger = structlog.get_logger("logicblocks.event.processing.consumers")
