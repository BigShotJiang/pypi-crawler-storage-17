package plugins.big.bigsnake3d.snake;

public enum ShapeSpaceTypeBrain {
	SIMILARITY, AFFINE
}
