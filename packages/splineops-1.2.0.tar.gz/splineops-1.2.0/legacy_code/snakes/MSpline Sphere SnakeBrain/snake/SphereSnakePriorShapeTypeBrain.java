package plugins.big.bigsnake3d.snake;

public enum SphereSnakePriorShapeTypeBrain {
	NONE, CUSTOM
}
