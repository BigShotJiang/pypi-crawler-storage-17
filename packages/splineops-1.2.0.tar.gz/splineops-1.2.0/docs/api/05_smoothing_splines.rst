.. splineops/docs/api/05_smoothing_splines.rst

.. _api-smoothing_splines:

Smoothing Splines
=================

Functions to smooth data.

.. automodule:: splineops.smoothing_splines.smoothing_spline
   :members:
   :undoc-members:
   :show-inheritance: