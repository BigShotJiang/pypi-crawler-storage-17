# splineops/src/splineops/spline_interpolation/bases/linear_basis.py

from .bspline1_basis import BSpline1Basis

LinearBasis = BSpline1Basis
