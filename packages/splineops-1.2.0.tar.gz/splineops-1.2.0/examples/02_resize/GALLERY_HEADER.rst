.. splineops/examples/02_resize/GALLERY_HEADER.rst

Resize Examples
===============

Examples using the Resize module on multidimensional samples, specially 1D and 2D.
We also show the equivalence with the Spline Interpolation module methods where relevant.