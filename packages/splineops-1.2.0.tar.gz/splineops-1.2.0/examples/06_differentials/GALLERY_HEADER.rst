.. splineops/examples/06_differentials/GALLERY_HEADER.rst

Differentials Examples
======================

Examples using the Differentials module.