Examples
========

Explore the example gallery to see how to use the SplineOps library.

All real-world images used in these examples come from the Kodak image
dataset, available at:

https://r0k.us/graphics/kodak/

We gratefully acknowledge the work of the author and curator of this dataset
for making these images publicly available.