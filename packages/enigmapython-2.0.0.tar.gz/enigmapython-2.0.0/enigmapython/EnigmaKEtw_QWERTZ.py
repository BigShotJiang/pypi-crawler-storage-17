from .EtwQWERTZ import EtwQWERTZ

class EnigmaKEtw_QWERTZ(EtwQWERTZ):
    """Enigma K ETW with QWERTZ keyboard layout"""
    pass
