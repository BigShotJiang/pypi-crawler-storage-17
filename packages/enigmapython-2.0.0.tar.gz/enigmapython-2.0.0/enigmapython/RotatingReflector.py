from .Rotor import Rotor
from .Reflector import Reflector

class RotatingReflector(Rotor, Reflector):
    pass