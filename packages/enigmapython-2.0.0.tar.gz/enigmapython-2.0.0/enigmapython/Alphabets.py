class Alphabets:
    lookup = {
        'latin_i18n_26chars_lowercase': 'abcdefghijklmnopqrstuvwxyz',
        'enigma_b_a133_28chars_lowercase': 'abcdefghijklmnopqrstuvxyzåäö',
        'enigma_z_10chars_numbers': '1234567890'
    }