from .EtwQWERTZ import EtwQWERTZ

class EnigmaDEtw_QWERTZ(EtwQWERTZ):
    """Enigma D ETW with QWERTZ keyboard layout"""
    pass