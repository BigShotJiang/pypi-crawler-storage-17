# extergram/utils.py

import re

def escape_markdown_v2(text: str) -> str:
    """Экранирует специальные символы для разметки MarkdownV2."""
    escape_chars = r'_*[]()~`>#+-=|{}.!'
    return re.sub(f'([{re.escape(escape_chars)}])', r'\\\1', text)

class Markdown:
    """
    Класс-заглушка для возможной будущей реализации
    удобной работы с Markdown-разметкой.
    """
    def __init__(self, text=""):
        self.text = text

    def bold(self, text: str) -> 'Markdown':
        self.text += f"*{text}*"
        return self

    def italic(self, text: str) -> 'Markdown':
        self.text += f"_{text}_"
        return self
    
    def __str__(self):
        return self.text