# extergram/ext/message_handler.py

from .base import BaseHandler
from ..api_types import Update

class MessageHandler(BaseHandler):
    """Обработчик для входящих сообщений."""
    def check_update(self, update: Update) -> bool:
        return update.message is not None