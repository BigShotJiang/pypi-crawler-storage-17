# Extergram (v0.4.2)

A simple and convenient library for creating Telegram bots in Python.

## Installation

`pip install extergram`

## Example Usage

Here is a complete example of a simple bot. Create a file named `main.py`:

```python
import extergram
from extergram import Bot, ButtonsDesign, Message, CallbackQuery
from extergram.ext import CommandHandler, CallbackQueryHandler, MessageHandler
import datetime

# IMPORTANT: Replace 'YOUR_BOT_TOKEN' with your actual token
bot = Bot('YOUR_BOT_TOKEN')

# Create a keyboard we will use
main_menu = ButtonsDesign().add_row(
    ButtonsDesign.create_button("Show time", "show_time"),
    ButtonsDesign.create_button("About", "about")
).add_row(
    ButtonsDesign.create_button("Delete this message", "delete")
)

# Handler for the /start command
def start(bot_instance: Bot, message: Message):
    user_name = message.from_user.first_name
    text = f"Hello, {user_name}! I am your new bot."

    bot_instance.send_message(
        chat_id=message.chat.id,
        text=text,
        reply_markup=main_menu
    )

# Handler for any other text message
def echo(bot_instance: Bot, message: Message):
    bot_instance.send_message(
        chat_id=message.chat.id,
        text=f"You wrote: {message.text}"
    )

# Handler for inline button clicks
def handle_callbacks(bot_instance: Bot, callback: CallbackQuery):
    # First, answer the callback to remove the "loading" state
    bot_instance.answer_callback_query(callback.id)

    if callback.data == 'show_time':
        now = datetime.datetime.now().strftime("%H:%M:%S")
        bot_instance.edit_message_text(
            chat_id=callback.message.chat.id,
            message_id=callback.message.message_id,
            text=f"The current time is: {now}",
            reply_markup=main_menu
        )
    elif callback.data == 'about':
        bot_instance.edit_message_text(
            chat_id=callback.message.chat.id,
            message_id=callback.message.message_id,
            text="This bot was created using the Extergram library!",
            reply_markup=main_menu
        )
    elif callback.data == 'delete':
        bot_instance.delete_message(
            chat_id=callback.message.chat.id,
            message_id=callback.message.message_id
        )

def main():
    # Register handlers
    bot.add_handler(CommandHandler("start", start))
    bot.add_handler(CallbackQueryHandler(handle_callbacks))
    bot.add_handler(MessageHandler(echo)) # Must be after CommandHandler

    # Start the bot
    bot.polling()

if __name__ == '__main__':
    main()```

## Running the Bot

`python main.py`