---
name: project-skill
description: A project-specific skill
---
# Project Skill
This skill is specific to this project.
