---
name: plugin-agent
description: An agent from a plugin
tools: Read, Write
---
# Plugin Agent
This agent comes from the example-plugin.
