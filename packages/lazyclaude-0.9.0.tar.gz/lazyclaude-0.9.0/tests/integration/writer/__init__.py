"""Writer integration tests."""
