# Project Guidelines

After modifying Python files, run `pyright` on them to check for type errors.
