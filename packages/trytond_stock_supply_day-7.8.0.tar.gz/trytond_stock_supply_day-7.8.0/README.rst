Stock Supply Day Module
#######################

The Stock Supply Day module adds a Week Days list on the Product
Supplier form. This allow to restrict the supply week days for each
supplier on each product. If no days are defined for a supplier a
supplying may happens at any day of the week.

For example, those week days are taken into account when computing the
planned date of stock moves created by the purchase (defined in the
Purchase module) and by the scheduler that generates the Purchase
Requests (defined in the Stock Supply module).
