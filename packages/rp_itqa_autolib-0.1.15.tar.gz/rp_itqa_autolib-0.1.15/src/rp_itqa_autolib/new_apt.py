from unittest import result
from robot.api.deco import keyword, not_keyword
from robot.api import logger
import typing
from robot.libraries.BuiltIn import BuiltIn
from db import *
import random
from new_patient_transaction import new_patient_transaction

class new_apt(new_patient_transaction):
    def __init__(self):
        self.Tcid=''
        self.Name=''
        self.Mrn=''
        self.AptNum=''
        self.AptDate=''
        self.Provider=''
        self.Department=''
        self.ApptType=''
        self.Location=''
        self.InterType=''
        self.RefProv=''
        self.AttendSvc=''
        self.AttendBillProv=''
        self.Dob=''
        self.CurSex=''
        self.BirthSex=''
        self.Address=''
        self.PrimPhone=''
        self.CreatedDate=''
        self.Pronouns=''   # NOT USED
        self.ZipCode=''    # NOT USED
        self.Race=''       # NOT USED
        self.Ethnicity=''  # NOT USED

    def create_apt_obj(self,tcidBase): 
        tcidBase = tcidBase.strip()
        
        q = f"""    SELECT 
           A.TCID, A.SearchID, A.Provider, A.Department, A.ApptType, A.Location
          ,AGI.InteractionType, AGI.ReferringProvider, AGI.AttendingService, AGI.AttendingBillingProvider
          ,'' AS DOB, '' AS CurSex, '' AS BirSex, '' AS Address, '' AS PrimPhone, '' AS CreatedDate, '' AS Pronouns, '' AS ZipCode, '' AS Race, '' AS Ethnicity
    FROM  td.Appt_00NewAppt A
    JOIN  td.Appt_01ApptGeneralInfo AGI ON AGI.TCID = A.TCID
    WHERE A.ActiveTestCase = 'A' 
          AND A.TCID LIKE '{tcidBase}%' """
        
        queryResult = query(q)
        newAptList = self.build_new_apt_list(queryResult,tcidBase)
        randomApt = self.get_random_apt(newAptList,tcidBase)
        return randomApt

    [not_keyword]
    def get_random_apt(self,newAptList:list,tcidBase):
        logger.console(f"\n   --------------------------------------------------------------------------------")
        logger.console(f"    Random Apt Variation ...[py]")
        logger.console(f"   --------------------------------------------------------------------------------")
        
        if not newAptList:
            logger.console(f"    ---WARNING--- NO APTS FOUND FOR TCID '{tcidBase}'")
            logger.console(f"    (PLEASE RUN JENKINS JOB 'Athena-Data-Creation-<MODULE>')\n")
            return

        randApt:new_apt = random.choice(newAptList)
        tcid_variation_len= randApt.Tcid.rfind("_") # EHR-Interfaces_001_001
        tcid_variation = randApt.Tcid[0:tcid_variation_len] 
        tcid_variation_count = randApt.Tcid[tcid_variation_len+1:]# EHR-Interfaces_001
        
        q = f"""    SELECT 
           A.TCID, A.SearchID, A.Provider, A.Department, A.ApptType, A.Location 
          ,AGI.InteractionType, AGI.ReferringProvider, AGI.AttendingService, AGI.AttendingBillingProvider
          ,F.TCID, F.DOB, F.CurSex, F.BirSex, F.Address, F.PrimPhone, F.CreatedDate, F.Pronouns, F.ZipCode, F.Race, F.Ethnicity
    FROM  td.Appt_00NewAppt A
    JOIN  td.Appt_01ApptGeneralInfo AGI ON AGI.TCID = A.TCID
    JOIN  (SELECT TCID + '_{tcid_variation_count}' AS TCID, DOB, CurSex, BirSex, Address, PrimPhone, CreatedDate, Pronouns, ZipCode, Race, Ethnicity
           FROM td.FullReg_01Registration
           WHERE TCID = '{tcid_variation}') AS F ON A.TCID = F.TCID
    WHERE  A.ActiveTestCase = 'A'  
           AND A.TCID = '{randApt.Tcid}' """


        newApt:list  = queryOne(q)
        randApt= self.parse_apt_to_newAptObj(newApt)

        return randApt


    [not_keyword]
    def build_new_apt_list(self,queryResult:list,tcidBase)->list:
        logger.console(f"\n   --------------------------------------------------------------------------------")
        logger.console(f"   Print All Apt Variations ...[py]")
        logger.console(f"   --------------------------------------------------------------------------------")

        if not queryResult:
            logger.console(f"    ---WARNING--- NO APTS FOUND FOR TCID '{tcidBase}'")
            logger.console(f"    (PLEASE RUN JENKINS JOB 'Athena-Data-Creation-<MODULE>')\n")
            return

        newAptList : list[new_apt] = []

        for apt in queryResult:  # {('<apptdt:04/05/2024>;<apptnum:10000011100>;<mrn:1016828>;<name:AUTO-Berg,Reva>,)}
            aptObj= self.parse_apt_to_newAptObj(apt)
            newAptList.append(aptObj)

        return newAptList

    [not_keyword]
    def parse_apt_to_newAptObj(self,result: list):
        result.CurSex = self.changeSexToOneChar(result.CurSex)
        result.BirSex = self.changeSexToOneChar(result.BirSex)
        result.DOB = self.Assign_DOB_When_Exists(result.DOB)
        searchIdString =  result.SearchID
        aptStr = searchIdString.replace("('","")
        aptStr = str(aptStr).replace("',)","") 
        aptStr = str(aptStr).replace("<","")
        aptStr = str(aptStr).replace(">","")
        aptList = aptStr.split(";")
        apt = new_apt()
        apt.Tcid = result.TCID
         
        if "apptdt:" in str(aptList[0]):
            dateCreated = str(aptList[0].replace("apptdt:","").replace(">",""))
            apt.AptDate = dateCreated
            
        if "apptnum:" in str(aptList[1]):
            aptNum = str(aptList[1].replace("apptnum:","").replace(">",""))
            apt.AptNum= aptNum
            
        if "mrn:" in str(aptList[2]):
            mrn = str(aptList[2].replace("mrn:","").replace(">",""))
            apt.Mrn= mrn
            
        if "name:" in str(aptList[3]):
            name = str(aptList[3].replace("name:","").replace(">",""))
            apt.Name= name.upper()

        apt.Provider= result.Provider
        apt.Department= result.Department
        apt.ApptType = result.ApptType
        apt.Location= result.Location
        apt.InterType= result.InteractionType
        apt.ReferProv= result.ReferringProvider
        apt.AttendSvc= result.AttendingService
        apt.AttendBillProv=result.AttendingBillingProvider
        apt.Dob= result.DOB
        apt.Address= result.Address
        apt.PrimPhone= result.PrimPhone
        apt.CurSex= result.CurSex
        apt.BirthSex= result.BirSex
        apt.Race= result.Race
        apt.Ethnicity= result.Ethnicity
        apt.CreatedDate= result.CreatedDate

        logger.console(f"   Appt_00NewAppt     ('{apt.Name}', '{apt.Mrn}','{apt.AptNum}', '{apt.AptDate}', '{apt.Provider}', '{apt.Department}', '{apt.Location}')")
        logger.console(f"   Appt_01ApptGenInfo ('{apt.InterType}','{apt.ReferProv}','{apt.AttendSvc}','{apt.AttendBillProv}')")

        if  len((apt.Address).strip()) > 0:
            logger.console(f"   FullReg_01Reg      ('{apt.Dob}','{apt.CurSex}','{apt.BirthSex}','{apt.Address}','{apt.Race}','{apt.Ethnicity}','{apt.CreatedDate}')\n")
        
        logger.console(f"")

        return apt

if __name__ == '__main__':
    newApt = new_apt()
    newApt.create_apt_obj('EHR-Interfaces_DFT_Msgs_001')
