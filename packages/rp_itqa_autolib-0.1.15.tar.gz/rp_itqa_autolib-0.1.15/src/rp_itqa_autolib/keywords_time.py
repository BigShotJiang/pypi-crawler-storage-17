from datetime import datetime, timedelta
from robot.api import logger


def get_time_delta_between_py(time1, time2):
    timeFormat =  "%I:%M%p"
    year=datetime.now().year
    month=datetime.now().month
    day=datetime.now().day
    time1Obj = datetime.strptime(time1,timeFormat).replace(year,month,day)
    time2Obj = datetime.strptime(time2,timeFormat).replace(year,month,day)
    #time1  = datetime.now()
    #minuteAdd = timedelta(minutes=10)
    #time2 =   time1+ minuteAdd
    logger.console(f"   Allscripts Time = {time1Obj}")
    logger.console(f"   Athena IDX Time = {time2Obj}")
    
    deltaTime = time2Obj - time1Obj   # Time difference
    deltaSeconds = int(deltaTime.total_seconds())
    deltaMinutes = abs(int(deltaSeconds / 60)) # always get magnitude
    
    logger.console(f"   Total Minute Delta = {deltaMinutes}\n")
    return deltaMinutes


if __name__ == '__main__':
    get_time_delta_between_py('01:00AM','02:05AM')