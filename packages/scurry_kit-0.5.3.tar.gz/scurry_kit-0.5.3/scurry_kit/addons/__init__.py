# scurry_kit/addons

from .commands import SlashCommandAddon
from .events import EventsAddon
from .hooks import HooksAddon
from .prefix import PrefixAddon

__all__ = [
    "SlashCommandAddon",
    "EventsAddon",
    "HooksAddon",
    "PrefixAddon"
]
