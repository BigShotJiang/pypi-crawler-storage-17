"""Integration tests for deliberate."""
