"""Tests for deliberate."""
