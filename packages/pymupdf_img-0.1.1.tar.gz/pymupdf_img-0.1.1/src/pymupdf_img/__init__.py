from .core import convert_pdf
from .const import MAX_RES, MAX_SIZE, MAX_QUAL, IMG_PATH

__version__ = "0.1.0"
__all__ = ["convert_pdf", "MAX_RES", "MAX_SIZE", "MAX_QUAL", "IMG_PATH"]
