from .amazon import AmazonHandler
from .best_buy import BestbuyHandler
from .fake_amazon import FakeAmazonHandler
from .fake_flipkart import FakeFlipkartHandler
from .flipkart import FlipkartHandler
from .walmart import WalmartHandler
