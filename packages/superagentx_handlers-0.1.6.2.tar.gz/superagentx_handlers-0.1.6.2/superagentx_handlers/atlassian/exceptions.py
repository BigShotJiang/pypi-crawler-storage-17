class SprintException(Exception):
    pass


class ProjectException(Exception):
    pass


class TaskException(Exception):
    pass


class AuthException(Exception):
    pass
