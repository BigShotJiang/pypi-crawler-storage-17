'''This file contains core program constants.'''
CHAR_ARRAY = "char[]"
DOUBLE_PTR = "double *"
LONG_PTR = "long *"
UTF_ENCODING = "utf-8"
