from .data_processing_functions import DataProcessing


class Tools(DataProcessing):
    pass
