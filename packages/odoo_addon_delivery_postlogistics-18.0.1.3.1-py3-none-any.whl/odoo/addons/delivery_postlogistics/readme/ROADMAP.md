- Integration of price webservice :
  <https://www.post.ch/en/customer-center/all-online-services/preise-berechnen/info>
- Not sure if the recursive patch of suds is still needed as there's no
  need to use the integration WS anymore. However we still want to patch
  open to get meaningful error messages.
