This module uses [PostLogistics BarCodes
WebService](https://www.post.ch/en/business/a-z-of-subjects/dropping-off-mail-items/business-sending-letters/sending-consignments-web-service-barcode)
to generate labels for your Delivery Orders.

It adds a Create label button on Delivery Orders. A generated label will
be an attachement of your Delivery Order.

To see it, please install documents module.

You can create multiple delivery method to match your diffent package
types.
