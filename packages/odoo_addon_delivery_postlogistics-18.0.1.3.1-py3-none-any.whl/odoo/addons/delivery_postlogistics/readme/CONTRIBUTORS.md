- Yannick Vaucher \<<yannick.vaucher@camptocamp.com>\>

- Guewen Baconnier \<<guewen.baconnier@camptocamp.com>\>

- Akim Juillerat \<<akim.juillerat@camptocamp.com>\>

- Julien Coux \<<julien.coux@camptocamp.com>\>

- Dung Tran \<<dungtd@trobz.com>\>

- Phuc Tran \<<phuc@trobz.com>\>

- Jacques-Etienne Baudoux \<<je@bcim.be>\>

- [Trobz](https://trobz.com):
  - Jack Le \<<anlh@trobz.com>\>

- Stéphane Mangin <stephane.mangin@camptocamp.com>
