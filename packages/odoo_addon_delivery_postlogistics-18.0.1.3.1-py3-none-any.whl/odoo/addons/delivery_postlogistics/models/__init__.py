from . import delivery_carrier_template_option
from . import delivery_carrier
from . import stock_package_type
from . import postlogistics_license
from . import stock_picking
from . import stock_quant_package
from . import stock_move
from . import res_partner
