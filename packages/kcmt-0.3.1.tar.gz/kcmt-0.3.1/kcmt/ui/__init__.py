"""UI assets for kcmt."""
