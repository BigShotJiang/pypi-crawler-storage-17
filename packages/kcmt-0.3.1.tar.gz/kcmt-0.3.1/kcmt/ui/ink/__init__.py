"""Ink application entry point."""
