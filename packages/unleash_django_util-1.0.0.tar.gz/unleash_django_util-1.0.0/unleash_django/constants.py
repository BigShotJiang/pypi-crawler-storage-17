
UNLEASH_TOKEN = 'default:development.unleash-insecure-api-token'
UNLEASH_URL = 'https://app.unleash-hosted.com/demo/api/'
UNLEASH_APP_NAME = 'miare'