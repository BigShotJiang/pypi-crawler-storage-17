.. _mc_design:

**********************
Model Component Design
**********************

.. toctree::
   :maxdepth: 2

   model_component
   dependencies
   mc_install
   mc_examples
   repository

