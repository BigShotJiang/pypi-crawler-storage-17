# Licensing

```{include} ../../../DISCLAIMER.md
```

## Notice
```{include} ../../../NOTICE
```

```{include} ../../../LICENSE
```
