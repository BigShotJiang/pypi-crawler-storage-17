*****************************
VM Resource Schedule Explorer
*****************************

This tool allows a user to upload a schedule file in order to visualize and understand the :ref:`vm-resource-schedule`.
This tool is completely self contained and process the data locally on a users computer within the users browser and can even be run offline if desired.

.. raw:: html

    <h3>Access the standalone tool <a href="_static/vmr_exp.html"><b>HERE</b></a>.</h3>

