Citing Xsuite
-------------

If you wish to cite Xsuite in your article, please refer to the following publication (`INSPIRE entry <https://inspirehep.net/literature/2705250>`_):

   G. Iadarola, R. De Maria, S. Łopaciuk, A. Abramov, X. Buffat, D. Demetriadou, L. Deniau, P. Hermes, P. Kicsiny, P. Kruyt, A. Latina, L. Mether, K. Paraschou, G. Sterbini, F. F. Van Der Veken, P. Belanger, P. Niedermayer, D. Di Croce, T. Pieloni, L. Van Riesen-Haupt, M. Seidel. `“Xsuite: An Integrated Beam Physics Simulation Framework,” <https://inspirehep.net/literature/2705250>`_ JACoW HB2023 (2024), TUA2I1.
