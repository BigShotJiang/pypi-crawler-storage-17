# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2025/12/14 15:49
# Description:


beg_date = "2025-01-01"
end_date = "2025-06-01"
times = ["09:31:00", "10:01:00", "10:31:00"]

