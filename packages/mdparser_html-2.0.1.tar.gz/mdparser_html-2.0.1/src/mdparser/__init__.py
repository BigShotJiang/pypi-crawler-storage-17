from mdparser.parsers.htmlParser.parse import parse_markdown 
 

__version__ = "2.0.0" 



__all__ = ["parse_markdown"]
