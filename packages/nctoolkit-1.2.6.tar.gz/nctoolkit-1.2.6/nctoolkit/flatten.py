def str_flatten(L, sep=","):
    result = sep.join(str(x) for x in L)
    return result
