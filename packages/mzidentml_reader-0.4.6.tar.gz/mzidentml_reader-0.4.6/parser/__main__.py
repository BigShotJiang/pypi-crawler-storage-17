from parser.process_dataset import main

if __name__ == "__main__":
    main()
