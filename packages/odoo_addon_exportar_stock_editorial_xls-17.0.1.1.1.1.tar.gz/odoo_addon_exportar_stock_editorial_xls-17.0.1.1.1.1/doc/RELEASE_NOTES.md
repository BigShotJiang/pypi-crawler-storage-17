## Module <export_stockinfo_xls>

#### 01.11.2019
#### Version 13.0.1.0.0
#### ADD
Initial Commit  Export Product Stock in Excel


#### 05.12.2019
#### Version 13.0.1.1.0
#### FIX
Updation Of Export Product Stock in Excel


#### 05.02.2020
#### Version 13.0.1.1.1
#### UPDT
Changed to query

#### 05.02.2020
#### Version 13.0.1.1.2
#### UPDT
Set Timezone 'UTC' for default




