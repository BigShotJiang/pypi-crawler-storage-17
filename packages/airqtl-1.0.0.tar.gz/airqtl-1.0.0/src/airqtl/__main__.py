#!/usr/bin/python3
# Copyright 2025, Lingfei Wang
#
# This file is part of airqtl.

if __name__ == "__main__":
	import airqtl
	airqtl.main()
