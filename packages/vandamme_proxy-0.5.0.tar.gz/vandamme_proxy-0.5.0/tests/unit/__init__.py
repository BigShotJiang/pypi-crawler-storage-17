"""Unit tests for Vandamme Proxy."""
