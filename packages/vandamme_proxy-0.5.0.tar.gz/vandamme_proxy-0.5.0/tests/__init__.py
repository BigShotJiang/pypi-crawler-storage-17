"""Tests for Vandamme Proxy."""
