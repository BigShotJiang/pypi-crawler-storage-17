## 📦 Installation

```bash
pip install django-ninja-aio-crud
```

**Requirements:**
- Python 3.8+
- Django 4.1+ (for async ORM support)
- django-ninja
