"""
### Typed Deribit
> A fully typed, validated async client for the Deribit API

- Details
"""