# Typed Deribit

> A fully typed, validated async client for the Deribit API

Use *autocomplete* instead of documentation.

🚧 Under construction.