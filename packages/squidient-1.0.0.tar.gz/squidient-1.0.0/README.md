# Squidient

Squidient is a scheduler for testing, benchmarking and deploying HPC programs on SLURM machines.

