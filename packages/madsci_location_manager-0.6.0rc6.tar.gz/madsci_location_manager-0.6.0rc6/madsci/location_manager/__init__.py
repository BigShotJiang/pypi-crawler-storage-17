"""LocationManager - Dedicated service for location management in MADSci."""
