"""Analysis operations for ROOT data."""

from .operations import AnalysisOperations

__all__ = ["AnalysisOperations"]
