"""Entry"""

from .version import __version__
from .entry import PipenCliRequirePlugin
from .require import parse_proc_requirements
