# Package for BIDS template resources
