#!/bin/bash
# WF 2024-04-27
# see https://www.mediawiki.org/wiki/Manual:How_to_use_DjVu_with_MediaWiki
apt-get update
apt install -y djvulibre-bin netpbm
