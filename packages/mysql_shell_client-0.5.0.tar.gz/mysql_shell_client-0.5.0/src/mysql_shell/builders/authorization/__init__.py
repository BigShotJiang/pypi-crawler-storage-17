# Copyright 2025 Canonical Ltd.
# See LICENSE file for licensing details.

from .base import BaseAuthorizationQueryBuilder
from .charm import CharmAuthorizationQueryBuilder
