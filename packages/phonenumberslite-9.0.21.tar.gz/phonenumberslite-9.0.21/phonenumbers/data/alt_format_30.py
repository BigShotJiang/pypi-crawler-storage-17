"""Auto-generated file, do not edit by hand. 30 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_30 = [NumberFormat(pattern='(\\d{3})(\\d{3})(\\d{4})', format='\\1 \\2 \\3', leading_digits_pattern=['21'])]
