from .votingregressor import MedianVotingRegressor

__all__ = ["MedianVotingRegressor"]
