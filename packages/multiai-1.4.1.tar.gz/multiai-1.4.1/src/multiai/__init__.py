"""init.py."""
from .entry import entry
from .multiai import Prompt, Provider
from .printlong import print_long
