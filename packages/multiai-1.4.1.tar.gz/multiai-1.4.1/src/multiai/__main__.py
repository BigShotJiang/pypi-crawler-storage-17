from .entry import entry

if __name__ == "__main__":
    entry()
