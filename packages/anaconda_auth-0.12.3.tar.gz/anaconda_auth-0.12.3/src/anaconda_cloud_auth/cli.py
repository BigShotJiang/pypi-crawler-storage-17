from anaconda_auth.cli import app

__all__ = ["app"]
