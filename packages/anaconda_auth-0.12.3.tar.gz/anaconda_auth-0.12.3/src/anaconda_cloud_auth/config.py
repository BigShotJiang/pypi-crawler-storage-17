from anaconda_auth.config import (
    _OLD_OIDC_REQUEST_HEADERS as OIDC_REQUEST_HEADERS,  # noqa: F401
)
from anaconda_auth.config import AnacondaCloudConfig  # noqa: F401
from anaconda_cloud_auth import warn

warn()
