from pydantic import Field
from fustor_common.models import TokenResponse, LogoutResponse, Password