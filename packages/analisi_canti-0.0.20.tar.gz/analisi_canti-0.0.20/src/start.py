from analisi_canti import main
main.run()
