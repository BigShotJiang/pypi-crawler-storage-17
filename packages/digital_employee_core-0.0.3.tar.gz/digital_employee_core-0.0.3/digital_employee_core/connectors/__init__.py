"""Connectors module for digital employee Core.

This module contains various connectors and integration components.
"""
