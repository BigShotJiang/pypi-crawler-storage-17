"""
### Typed P2b
> A fully typed, validated async client for the P2b API

- Details
"""