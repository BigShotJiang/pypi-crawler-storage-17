# Built-Ins
from dataclasses import dataclass


@dataclass
class CursorInfo:
    x: float
    y: float
    xint: int
    yint: int
    val: float
