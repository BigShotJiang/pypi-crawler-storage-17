# ACE-X CLIENT

This client is used for communication with the ACEX-API and is used within
the cli, worker and more. 

## Installation

```bash
pip install acex-client
```

See the [main documentation](../README.md) for more information.

