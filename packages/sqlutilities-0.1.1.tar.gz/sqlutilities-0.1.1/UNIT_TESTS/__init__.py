"""
SQLUtils Unit Tests Package

Comprehensive test suite for SQLUtils-Python library.
"""

__version__ = "1.0.0"
