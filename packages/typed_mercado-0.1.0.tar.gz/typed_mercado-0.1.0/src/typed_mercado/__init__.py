"""
### Typed Mercado
> A fully typed, validated async client for the Mercado API

- Details
"""