# -*- coding: utf-8 -*-
"""The object types in agentscope."""
from typing import List

Embedding = List[float]
