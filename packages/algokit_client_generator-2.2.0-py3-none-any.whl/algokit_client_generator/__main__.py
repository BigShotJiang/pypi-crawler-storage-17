from algokit_client_generator.cli import main

main()
