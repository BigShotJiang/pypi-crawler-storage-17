# defermi-gui
User interface for `defermi`, made with `streamlit`.

It can be installed with 

```python
pip install defermi-gui
```
