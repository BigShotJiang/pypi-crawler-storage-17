#!/home/zzd/anaconda3/envs/yolov5/bin/python
# coding=utf-8

def test_module():
    print('test_module')


def test_script():
    print('test_script')


def test_io():
    print('test_io')
