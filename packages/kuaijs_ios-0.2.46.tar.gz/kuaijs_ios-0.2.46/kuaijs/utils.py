"""工具函数"""


def timeFormat(format: str) -> str:
    """时间格式化（如 "yyyy-MM-dd HH:mm:ss"）"""
    return ""


def random(min: int, max: int) -> int:
    """生成随机数（闭区间）"""
    return min


def takeMeToFront() -> bool:
    """将应用切到前台"""
    return True
