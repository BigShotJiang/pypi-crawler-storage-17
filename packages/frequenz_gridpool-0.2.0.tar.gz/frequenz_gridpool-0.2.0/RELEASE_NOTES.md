# Frequenz Gridpool Library Release Notes

## Summary

<!-- Here goes a general summary of what this release is about -->

## Upgrading
* Microgrid_config is updated from AC_ACTIVE_POWER to AC_POWER_ACTIVE in accordance with the update in client-reporting - v0.20.0
<!-- Here goes notes on how to upgrade from previous versions, including deprecations and what they should be replaced with -->

## New Features

* Add CLI tool to print formulas from assets API component graph.

<!-- Here goes the main new features and examples or instructions on how to use them -->

## Bug Fixes

<!-- Here goes notable bug fixes that are worth a special mention or explanation -->
