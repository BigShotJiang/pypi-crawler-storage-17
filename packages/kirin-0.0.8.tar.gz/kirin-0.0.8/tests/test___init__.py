"""Tests for kirin."""
