"""Widgets for interactive Kirin UI components."""
