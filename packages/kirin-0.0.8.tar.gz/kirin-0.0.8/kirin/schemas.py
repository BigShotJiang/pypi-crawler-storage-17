"""DataFrame schemas for kirin.

DataFrame schemas are written using `pandera`.
Check out `pandera` docs for more information.

    https://pandera.readthedocs.io/en/stable/

"""
