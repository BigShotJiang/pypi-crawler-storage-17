
def test_import():
    # This is based on all the imports found in the various tutorial notebooks
    from mapreader import (
        Annotator,
        ClassifierContainer,
        load_patches,
        AnnotationsLoader,
        loader,
        MapImages,
        PatchDataset,
        PatchContextDataset,
        Downloader,
        SheetDownloader,
        IIIFDownloader,
    )
