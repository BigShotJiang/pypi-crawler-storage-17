#include "base.hpp"

std::string base_return_string(const std::string &s) {
    return std::string("This function returns a string containing '") + s + "' as a substring";
}
