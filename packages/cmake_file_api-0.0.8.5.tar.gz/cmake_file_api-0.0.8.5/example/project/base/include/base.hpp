#pragma once

#include <string>

std::string base_return_string(const std::string &s);
