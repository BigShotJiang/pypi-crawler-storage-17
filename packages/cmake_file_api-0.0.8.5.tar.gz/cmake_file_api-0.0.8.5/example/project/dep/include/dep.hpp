#pragma once

#include <string>

void dep_print_string(const std::string &s);
