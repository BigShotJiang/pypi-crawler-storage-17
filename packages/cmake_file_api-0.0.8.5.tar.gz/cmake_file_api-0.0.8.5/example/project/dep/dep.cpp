#include "dep.hpp"

#include <base.hpp>

#include <iostream>

void dep_print_string(const std::string &s) {
    std::cout << base_return_string(s) << "\n";
}
