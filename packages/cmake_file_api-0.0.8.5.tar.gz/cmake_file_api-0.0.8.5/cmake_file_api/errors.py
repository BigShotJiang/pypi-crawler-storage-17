class CMakeException(Exception):
    pass
