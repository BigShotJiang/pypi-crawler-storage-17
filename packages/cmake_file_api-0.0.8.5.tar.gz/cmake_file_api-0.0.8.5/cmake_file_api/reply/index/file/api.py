from .v1 import CMakeReplyFileReferenceV1


REPLY_FILE_API = {
    1: CMakeReplyFileReferenceV1,
}
