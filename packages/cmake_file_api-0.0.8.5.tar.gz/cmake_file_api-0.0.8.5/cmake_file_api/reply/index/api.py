from .v1 import CMakeReplyFileV1


INDEX_API = {
    1: CMakeReplyFileV1,
}
