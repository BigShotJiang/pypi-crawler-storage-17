from .v1.api import CMakeFileApiV1


REPLY_API = {
    1: CMakeFileApiV1,
}
