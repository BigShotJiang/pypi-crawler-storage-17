import pickle
from typing import Any

import pandas as pd


def unpack_request(request: dict) -> dict:
    """Unpack a request from a genai datalab module call into keyword arguments.

    Args:
        request (dict): The request dictionary to unpack.

    Returns:
        dict: A dictionary of keyword arguments extracted from the request.
    """
    request_data = request.get("body", b"")
    kwargs = pickle.loads(request_data) if request_data else {}
    if not isinstance(kwargs, dict):
        raise ValueError(
            "Unpacked request data is not a dictionary of keyword arguments. Only keyword arguments are supported."
        )
    return kwargs


def pack_response(response: Any) -> dict:
    """Pack a response into bytes and add appropriate headers.
    Args:
        response (Any): The response object to pack.
    Returns:
        dict: A dict with the correct headers and packed response data.
    """

    # strip the spy attribute since we don't need it on the receiving end
    if isinstance(response, pd.DataFrame):
        if hasattr(response, "spy"):
            response.spy = None

    headers = {"Content-Type": "application/octet-stream"}
    response_data = pickle.dumps(response)

    return {"headers": headers, "data": response_data}
