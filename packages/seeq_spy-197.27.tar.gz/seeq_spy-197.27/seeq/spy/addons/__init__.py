from seeq.spy.addons._install import install
from seeq.spy.addons._search import search
from seeq.spy.addons._uninstall import uninstall

__all__ = ['search', 'install', 'uninstall']
