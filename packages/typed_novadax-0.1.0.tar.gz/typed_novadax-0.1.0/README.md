# Typed Novadax

> A fully typed, validated async client for the Novadax API

Use *autocomplete* instead of documentation.

🚧 Under construction.