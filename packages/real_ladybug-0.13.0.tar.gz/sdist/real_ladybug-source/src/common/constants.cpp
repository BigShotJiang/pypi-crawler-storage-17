namespace lbug {
namespace common {

const char* LBUG_VERSION = LBUG_CMAKE_VERSION;
}
} // namespace lbug
