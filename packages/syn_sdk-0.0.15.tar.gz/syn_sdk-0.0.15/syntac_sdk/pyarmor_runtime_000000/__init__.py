# Pyarmor 8.5.12 (trial), 000000, 2025-12-17T20:28:50.837001
from .pyarmor_runtime import __pyarmor__
