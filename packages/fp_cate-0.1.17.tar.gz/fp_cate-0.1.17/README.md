# fp-cate

A functional programming library for Python. Currently still working in progress.
