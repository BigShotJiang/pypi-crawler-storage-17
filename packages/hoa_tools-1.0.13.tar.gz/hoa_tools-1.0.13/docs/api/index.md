# API reference

These pages contain reference documentation for the classes and functions
in `hoa-tools`.

- [`hoa_tools.dataset`](dataset.md)
- [`hoa_tools.inventory`](inventory.md)
- [`hoa_tools.metadata`](metadata.md)
- [`hoa_tools.types`](types.md)
- [`hoa_tools.voi`](voi.md)
