"""Core Showtime functionality"""
