"""
Various utilities, typically to support use of external modules etc
"""
