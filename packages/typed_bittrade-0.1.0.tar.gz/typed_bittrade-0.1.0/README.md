# Typed Bittrade

> A fully typed, validated async client for the Bittrade API

Use *autocomplete* instead of documentation.

🚧 Under construction.