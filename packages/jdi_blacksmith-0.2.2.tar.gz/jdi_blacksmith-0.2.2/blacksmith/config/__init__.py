"""Configuration system for Blacksmith."""

