# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

VERSION = '1.1.0b5.dev1'
