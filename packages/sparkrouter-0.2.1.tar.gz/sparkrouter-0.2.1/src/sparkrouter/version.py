__version__ = "0.2.1"  # Keep in sync with pyproject.toml
