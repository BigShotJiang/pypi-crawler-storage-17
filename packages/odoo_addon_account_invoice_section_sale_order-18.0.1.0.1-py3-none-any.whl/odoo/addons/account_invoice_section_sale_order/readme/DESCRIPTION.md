When invoicing multiple sale orders at the same time, sale orders may be
grouped by customer into a single invoice. Unfortunately when this
happens, it is hard to know which invoice line belongs to which sale
order.

This module helps by grouping invoicing lines into sections with the
name of the targeted sale order. This is only done when an invoice
targets multiple sale order.
