from . import account_move
from . import res_company
from . import res_config_settings
from . import res_partner
from . import sale_order
