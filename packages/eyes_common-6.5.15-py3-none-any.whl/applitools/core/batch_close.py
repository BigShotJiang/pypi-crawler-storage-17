from __future__ import absolute_import, division, print_function, unicode_literals

from ..common import deprecated
from ..common.batch_close import BatchClose

deprecated.module(__name__)
__all__ = ("BatchClose",)
