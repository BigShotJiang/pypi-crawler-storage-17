from __future__ import absolute_import, division, print_function, unicode_literals

from ..common import deprecated
from ..common.extract_text import OCRRegion, TextRegion, TextRegionSettings

deprecated.module(__name__)
__all__ = "OCRRegion", "TextRegion", "TextRegionSettings"
