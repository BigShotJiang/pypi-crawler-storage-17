from magicgui import magic_factory
from napari.types import ImageData, LabelsData
from napari import Viewer
from .segmentation import segment_dic_image
from .processing import apply_mask

@magic_factory(
    call_button="Apply",
    model_type={
        "choices": ["cyto3", "finetune", "custom"]
    }
)
def image_processing(
    dic_layer: ImageData,
    brillouin_layer: ImageData,
    model_type: str,
    viewer: Viewer
) -> LabelsData:

    # 1) segmentation DIC → masque
    mask = segment_dic_image(dic_layer, model_type=model_type)
    viewer.add_labels(mask, name="Mask")

    # 2) application du masque sur Brillouin
    masked_img = apply_mask(brillouin_layer, mask[0])
    
    return viewer.add_image(masked_img, name="Brillouin_masked")
