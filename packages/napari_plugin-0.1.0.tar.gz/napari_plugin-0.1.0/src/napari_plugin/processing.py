import numpy as np
import cv2

def apply_mask(brillouin_image, mask):
    if brillouin_image.shape != mask.shape:
        mask = cv2.resize(mask, (brillouin_image.shape[1], brillouin_image.shape[0]), interpolation=cv2.INTER_NEAREST)
    masked = brillouin_image * (mask > 0)[:, :, np.newaxis]
    print(type(mask))
    print(type(np.array(mask)))
    return masked
