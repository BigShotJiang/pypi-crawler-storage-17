# SPDX-FileCopyrightText: 2024 Vladimir Shtarev, Jetbrains Research
#
# SPDX-License-Identifier: MIT
"""Starfive boards defenition"""
