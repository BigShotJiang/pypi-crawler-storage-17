from enum import auto
from .auto_name import AutoName

class ButtonLocationType(AutoName):
    PICKER = auto()
    "..."

    VIEW = auto()
    "..."