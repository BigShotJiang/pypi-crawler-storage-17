from dbt.tests.adapter.incremental.test_incremental_merge_exclude_columns import (
    BaseMergeExcludeColumns,
)


class TestMergeExcludeColumns(BaseMergeExcludeColumns):
    pass
