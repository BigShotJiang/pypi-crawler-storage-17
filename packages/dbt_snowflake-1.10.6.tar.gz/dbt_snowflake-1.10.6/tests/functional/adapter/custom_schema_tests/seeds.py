seed_csv = """
id,first_name,last_name,email,gender,ip_address
1,Jack,Hunter,jhunter0@pbs.org,Male,59.80.20.168
2,Kathryn,Walker,kwalker1@ezinearticles.com,Female,194.121.179.35
3,Gerald,Ryan,gryan2@com.com,Male,11.3.212.243
""".lstrip()

seed_agg_csv = """
last_name,count
Hunter,2
Walker,2
Ryan,2
""".lstrip()
