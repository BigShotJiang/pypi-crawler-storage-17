from dbt.adapters.snowflake.record.cursor.cursor import SnowflakeRecordReplayCursor
from dbt.adapters.snowflake.record.handle import SnowflakeRecordReplayHandle
