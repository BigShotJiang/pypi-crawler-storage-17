# Copyright (C) 2024 Floating Rock Studio Ltd
from ._internal.implementation.loader import ConfigLoader
from ._internal.implementation.writer import ConfigWriter

# Aliases for backward compatibility
Config = ConfigLoader
