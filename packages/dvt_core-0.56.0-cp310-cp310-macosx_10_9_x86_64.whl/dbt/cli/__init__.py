from .main import cli as dbt_cli  # noqa
