"""
DVT Profile Task

Data profiling task with DAG-based execution for sources and models.
Works like 'dvt run' with full selector support and DVT compute rules.

v0.56.0: Initial implementation with 4 profiling modes.

Modes:
- minimal: Basic stats (null%, distinct%, min/max) [DEFAULT]
- explorative: Full profiling (distributions, patterns, correlations)
- sensitive: Redacted profiling (masks PII-like columns)
- time-series: Temporal analysis (ACF, PACF, seasonality)
"""

import json
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import click

from dbt.artifacts.schemas.run import RunStatus
from dbt.config.runtime import RuntimeConfig
from dbt.contracts.graph.manifest import Manifest
from dbt.contracts.graph.nodes import SourceDefinition, ModelNode
from dbt.task.base import BaseTask


@dataclass
class ColumnProfile:
    """Profile result for a single column."""
    column_name: str
    data_type: str

    # Basic metrics (all modes)
    row_count: int = 0
    null_count: int = 0
    null_percent: float = 0.0
    distinct_count: int = 0
    distinct_percent: float = 0.0

    # Numeric metrics (explorative+)
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    mean_value: Optional[float] = None
    median_value: Optional[float] = None
    stddev_value: Optional[float] = None
    p25: Optional[float] = None
    p50: Optional[float] = None
    p75: Optional[float] = None

    # String metrics (explorative+)
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    avg_length: Optional[float] = None

    # Distribution data (JSON)
    histogram: Optional[List[Dict]] = None
    top_values: Optional[List[Dict]] = None

    # Quality alerts
    alerts: List[Dict] = field(default_factory=list)

    # Metadata
    duration_ms: int = 0


@dataclass
class TableProfile:
    """Profile result for a table."""
    source_name: str
    table_name: str
    connection_name: str
    row_count: int
    column_count: int
    columns: List[ColumnProfile]
    profile_mode: str
    profiled_at: datetime
    duration_ms: int
    alerts: List[Dict] = field(default_factory=list)
    status: str = "success"
    error: Optional[str] = None


@dataclass
class ProfileExecutionResult:
    """Result of profile execution."""
    tables_profiled: int = 0
    total_rows: int = 0
    total_columns: int = 0
    total_alerts: int = 0
    duration_ms: int = 0
    profiles: List[TableProfile] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class ProfileTask(BaseTask):
    """
    DAG-based profiling task for DVT.

    Execution flow:
    1. Parse selectors (--select, --exclude)
    2. Build execution list (sources + models)
    3. For each node:
       a. Determine compute strategy (pushdown vs federated)
       b. Execute profiling query
       c. Store results in metadata_store.duckdb
    4. Display summary (PipeRider-style)
    """

    def __init__(
        self,
        flags: Any,
        runtime_config: RuntimeConfig,
        manifest: Manifest,
    ):
        super().__init__(flags)  # BaseTask only takes flags, sets self.args
        self.runtime_config = runtime_config
        self.manifest = manifest
        self.profile_mode = getattr(self.args, "MODE", "minimal") or "minimal"

    def run(self) -> ProfileExecutionResult:
        """Execute profiling on selected sources and models."""
        start_time = time.time()
        result = ProfileExecutionResult()

        # Print header
        click.echo("\nDVT Profile - Capturing Data Profiles")
        click.echo("=" * 80)
        click.echo(f"Mode: {self.profile_mode}")
        click.echo("")

        # Get selected nodes
        nodes = self._get_selected_nodes()

        if not nodes:
            click.echo("No sources or models selected for profiling.")
            click.echo("Use --select to specify targets, e.g.: dvt profile --select 'source:*'")
            return result

        # Profile each node
        for i, node in enumerate(nodes, 1):
            profile = self._profile_node(node, i, len(nodes))
            if profile:
                result.profiles.append(profile)
                result.tables_profiled += 1
                result.total_rows += profile.row_count
                result.total_columns += profile.column_count
                result.total_alerts += len(profile.alerts)
                for col in profile.columns:
                    result.total_alerts += len(col.alerts)

                # Store in metadata_store.duckdb
                self._store_profile(profile)

        # Calculate duration
        result.duration_ms = int((time.time() - start_time) * 1000)

        # Print summary
        self._print_summary(result)

        return result

    def _get_selected_nodes(self) -> List[Any]:
        """Get list of nodes to profile based on selectors."""
        nodes = []

        # If no selection, default to all sources
        selector = getattr(self.args, "SELECT", None)
        exclude = getattr(self.args, "EXCLUDE", None)

        if not selector:
            # Default: profile all sources
            for source_id, source in self.manifest.sources.items():
                nodes.append(source)
        else:
            # Parse selection
            for sel in selector:
                if isinstance(sel, tuple):
                    for s in sel:
                        nodes.extend(self._parse_selector(s))
                else:
                    nodes.extend(self._parse_selector(sel))

        # Apply exclusions
        if exclude:
            excluded = set()
            for exc in exclude:
                if isinstance(exc, tuple):
                    for e in exc:
                        excluded.update(self._get_excluded_ids(e))
                else:
                    excluded.update(self._get_excluded_ids(exc))
            nodes = [n for n in nodes if self._get_node_id(n) not in excluded]

        return nodes

    def _parse_selector(self, selector: str) -> List[Any]:
        """Parse a selector string into nodes."""
        nodes = []

        if selector.startswith("source:"):
            # Source selector: source:* or source:postgres.*
            pattern = selector[7:]  # Remove "source:" prefix
            for source_id, source in self.manifest.sources.items():
                if self._matches_pattern(source, pattern):
                    nodes.append(source)

        elif selector.startswith("model:"):
            # Model selector: model:* or model:staging.*
            pattern = selector[6:]  # Remove "model:" prefix
            for node_id, node in self.manifest.nodes.items():
                if hasattr(node, "resource_type") and node.resource_type.value == "model":
                    if self._matches_pattern(node, pattern):
                        nodes.append(node)

        elif "*" in selector:
            # Wildcard - match both sources and models
            pattern = selector
            for source_id, source in self.manifest.sources.items():
                if self._matches_pattern(source, pattern):
                    nodes.append(source)
            for node_id, node in self.manifest.nodes.items():
                if hasattr(node, "resource_type") and node.resource_type.value == "model":
                    if self._matches_pattern(node, pattern):
                        nodes.append(node)

        else:
            # Exact match by name
            for source_id, source in self.manifest.sources.items():
                if source.name == selector or source.identifier == selector:
                    nodes.append(source)
            for node_id, node in self.manifest.nodes.items():
                if hasattr(node, "name") and node.name == selector:
                    nodes.append(node)

        return nodes

    def _matches_pattern(self, node: Any, pattern: str) -> bool:
        """Check if a node matches a glob pattern."""
        import fnmatch

        if pattern == "*":
            return True

        name = getattr(node, "name", "")
        identifier = getattr(node, "identifier", name)
        source_name = getattr(node, "source_name", "")

        # Try matching against different attributes
        full_name = f"{source_name}.{identifier}" if source_name else identifier
        return (
            fnmatch.fnmatch(name, pattern) or
            fnmatch.fnmatch(identifier, pattern) or
            fnmatch.fnmatch(full_name, pattern)
        )

    def _get_excluded_ids(self, exclude_str: str) -> Set[str]:
        """Get IDs of nodes matching exclusion pattern."""
        ids = set()
        nodes = self._parse_selector(exclude_str)
        for node in nodes:
            ids.add(self._get_node_id(node))
        return ids

    def _get_node_id(self, node: Any) -> str:
        """Get unique ID for a node."""
        if hasattr(node, "unique_id"):
            return node.unique_id
        return getattr(node, "name", str(node))

    def _profile_node(self, node: Any, index: int, total: int) -> Optional[TableProfile]:
        """Profile a single node (source or model)."""
        start_time = time.time()

        # Get node info
        if isinstance(node, SourceDefinition):
            source_name = node.source_name
            table_name = node.identifier
            connection_name = getattr(node, "config", {}).get("target", "default")
            node_type = "source"
        else:
            source_name = "models"
            table_name = node.name
            connection_name = getattr(node.config, "target", "default") if hasattr(node, "config") else "default"
            node_type = "model"

        # Print progress
        click.echo(f"Profiling {node_type}: {source_name}")
        click.echo(f"  [{index}/{total}] {table_name} ", nl=False)

        try:
            # Execute profiling
            columns = self._execute_profile(node)

            duration_ms = int((time.time() - start_time) * 1000)

            # Calculate totals
            row_count = columns[0].row_count if columns else 0

            # Collect alerts
            alerts = []
            for col in columns:
                alerts.extend(col.alerts)

            profile = TableProfile(
                source_name=source_name,
                table_name=table_name,
                connection_name=connection_name,
                row_count=row_count,
                column_count=len(columns),
                columns=columns,
                profile_mode=self.profile_mode,
                profiled_at=datetime.now(),
                duration_ms=duration_ms,
                alerts=alerts,
                status="success",
            )

            # Print result
            duration_sec = duration_ms / 1000
            click.echo(f".... OK ({duration_sec:.1f}s)")
            click.echo(f"        Rows: {row_count:,} | Columns: {len(columns)} | Alerts: {len(alerts)}")

            return profile

        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            click.echo(f".... FAILED ({str(e)})")
            return TableProfile(
                source_name=source_name,
                table_name=table_name,
                connection_name=connection_name,
                row_count=0,
                column_count=0,
                columns=[],
                profile_mode=self.profile_mode,
                profiled_at=datetime.now(),
                duration_ms=duration_ms,
                status="error",
                error=str(e),
            )

    def _execute_profile(self, node: Any) -> List[ColumnProfile]:
        """Execute profiling query on a node.

        Connects to the source database and executes SQL profiling queries.
        """
        columns = []

        # Get table info
        if isinstance(node, SourceDefinition):
            schema = node.schema
            table = node.identifier
            database = getattr(node, "database", None)
            target_name = node.config.get("target") if hasattr(node, "config") else None
        else:
            schema = node.schema
            table = node.alias or node.name
            database = getattr(node, "database", None)
            target_name = getattr(node.config, "target", None) if hasattr(node, "config") else None

        # Get adapter for connection
        adapter = self._get_adapter(target_name)

        # Get column info - either from node definition or by querying database
        node_columns = getattr(node, "columns", {})

        if not node_columns:
            # Query database for column info
            column_info = self._get_columns_from_db(adapter, database, schema, table)
        else:
            column_info = [
                (col_name, getattr(col_info, "data_type", "VARCHAR") or "VARCHAR")
                for col_name, col_info in node_columns.items()
            ]

        if not column_info:
            # Fallback: profile as single row count only
            row_count = self._get_row_count(adapter, database, schema, table)
            return [ColumnProfile(
                column_name="_table_",
                data_type="TABLE",
                row_count=row_count,
            )]

        # Get row count once for all columns
        row_count = self._get_row_count(adapter, database, schema, table)

        # Profile each column
        for col_name, col_type in column_info:
            profile = self._profile_column_sql(
                adapter, database, schema, table,
                col_name, col_type, row_count
            )
            columns.append(profile)

        return columns

    def _get_adapter(self, target_name: Optional[str] = None):
        """Get adapter for the specified target or default."""
        from dbt.adapters.factory import get_adapter

        # Get adapter from runtime config
        adapter = get_adapter(self.runtime_config)
        return adapter

    def _get_columns_from_db(
        self, adapter, database: Optional[str], schema: str, table: str
    ) -> List[tuple]:
        """Query database to get column names and types."""
        try:
            # Use adapter's get_columns_in_relation
            from dbt.adapters.base import BaseRelation

            relation = adapter.Relation.create(
                database=database,
                schema=schema,
                identifier=table,
            )

            with adapter.connection_named("profile"):
                columns = adapter.get_columns_in_relation(relation)
                return [(col.name, col.dtype) for col in columns]
        except Exception:
            return []

    def _get_row_count(
        self, adapter, database: Optional[str], schema: str, table: str
    ) -> int:
        """Get row count from table."""
        try:
            fqn = self._build_fqn(adapter, database, schema, table)
            sql = f"SELECT COUNT(*) as cnt FROM {fqn}"

            with adapter.connection_named("profile"):
                _, result = adapter.execute(sql, fetch=True)
                if result and len(result) > 0:
                    return int(result[0][0])
        except Exception:
            pass
        return 0

    def _build_fqn(
        self, adapter, database: Optional[str], schema: str, table: str
    ) -> str:
        """Build fully qualified table name."""
        parts = []
        if database:
            parts.append(adapter.quote(database))
        if schema:
            parts.append(adapter.quote(schema))
        parts.append(adapter.quote(table))
        return ".".join(parts)

    def _profile_column_sql(
        self, adapter, database: Optional[str], schema: str, table: str,
        col_name: str, col_type: str, row_count: int
    ) -> ColumnProfile:
        """Profile a single column using SQL queries."""
        start_time = time.time()

        profile = ColumnProfile(
            column_name=col_name,
            data_type=col_type,
            row_count=row_count,
        )

        fqn = self._build_fqn(adapter, database, schema, table)
        quoted_col = adapter.quote(col_name)

        try:
            # Basic metrics (all modes): null count, distinct count
            basic_sql = f"""
                SELECT
                    COUNT(*) - COUNT({quoted_col}) as null_count,
                    COUNT(DISTINCT {quoted_col}) as distinct_count
                FROM {fqn}
            """

            with adapter.connection_named("profile"):
                _, result = adapter.execute(basic_sql, fetch=True)
                if result and len(result) > 0:
                    profile.null_count = int(result[0][0] or 0)
                    profile.distinct_count = int(result[0][1] or 0)

            # Calculate percentages
            if row_count > 0:
                profile.null_percent = (profile.null_count / row_count) * 100
                profile.distinct_percent = (profile.distinct_count / row_count) * 100

            # Extended metrics for explorative/time-series modes
            if self.profile_mode in ["explorative", "time-series", "sensitive"]:
                self._profile_extended_metrics(
                    adapter, fqn, quoted_col, col_type, profile
                )

        except Exception as e:
            # If SQL fails, return what we have
            profile.alerts.append({
                "type": "PROFILE_ERROR",
                "severity": "warning",
                "message": f"Could not profile column: {str(e)[:100]}",
            })

        # Generate quality alerts
        profile.alerts.extend(self._generate_alerts(profile))

        profile.duration_ms = int((time.time() - start_time) * 1000)
        return profile

    def _profile_extended_metrics(
        self, adapter, fqn: str, quoted_col: str, col_type: str, profile: ColumnProfile
    ) -> None:
        """Add extended metrics for explorative/time-series modes."""
        col_type_lower = col_type.lower()

        # Numeric metrics
        is_numeric = any(t in col_type_lower for t in [
            "int", "numeric", "decimal", "float", "double", "real", "number"
        ])

        if is_numeric:
            try:
                stats_sql = f"""
                    SELECT
                        MIN({quoted_col}) as min_val,
                        MAX({quoted_col}) as max_val,
                        AVG(CAST({quoted_col} AS DOUBLE)) as mean_val,
                        STDDEV(CAST({quoted_col} AS DOUBLE)) as stddev_val
                    FROM {fqn}
                    WHERE {quoted_col} IS NOT NULL
                """
                with adapter.connection_named("profile"):
                    _, result = adapter.execute(stats_sql, fetch=True)
                    if result and len(result) > 0:
                        row = result[0]
                        profile.min_value = float(row[0]) if row[0] is not None else None
                        profile.max_value = float(row[1]) if row[1] is not None else None
                        profile.mean_value = float(row[2]) if row[2] is not None else None
                        profile.stddev_value = float(row[3]) if row[3] is not None else None

                # Try to get percentiles (may not work on all databases)
                try:
                    percentile_sql = f"""
                        SELECT
                            PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY {quoted_col}) as p25,
                            PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY {quoted_col}) as p50,
                            PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY {quoted_col}) as p75
                        FROM {fqn}
                        WHERE {quoted_col} IS NOT NULL
                    """
                    with adapter.connection_named("profile"):
                        _, result = adapter.execute(percentile_sql, fetch=True)
                        if result and len(result) > 0:
                            row = result[0]
                            profile.p25 = float(row[0]) if row[0] is not None else None
                            profile.p50 = float(row[1]) if row[1] is not None else None
                            profile.p75 = float(row[2]) if row[2] is not None else None
                            profile.median_value = profile.p50
                except Exception:
                    # Percentiles not supported on this database
                    pass

            except Exception:
                pass

        # String metrics
        is_string = any(t in col_type_lower for t in [
            "char", "varchar", "text", "string", "clob"
        ])

        if is_string:
            try:
                length_sql = f"""
                    SELECT
                        MIN(LENGTH({quoted_col})) as min_len,
                        MAX(LENGTH({quoted_col})) as max_len,
                        AVG(LENGTH({quoted_col})) as avg_len
                    FROM {fqn}
                    WHERE {quoted_col} IS NOT NULL
                """
                with adapter.connection_named("profile"):
                    _, result = adapter.execute(length_sql, fetch=True)
                    if result and len(result) > 0:
                        row = result[0]
                        profile.min_length = int(row[0]) if row[0] is not None else None
                        profile.max_length = int(row[1]) if row[1] is not None else None
                        profile.avg_length = float(row[2]) if row[2] is not None else None
            except Exception:
                pass

        # Top values (not for sensitive mode)
        if self.profile_mode != "sensitive" and profile.distinct_count and profile.distinct_count <= 100:
            try:
                top_sql = f"""
                    SELECT {quoted_col} as val, COUNT(*) as cnt
                    FROM {fqn}
                    WHERE {quoted_col} IS NOT NULL
                    GROUP BY {quoted_col}
                    ORDER BY cnt DESC
                    LIMIT 10
                """
                with adapter.connection_named("profile"):
                    _, result = adapter.execute(top_sql, fetch=True)
                    if result:
                        profile.top_values = [
                            {"value": str(row[0]), "count": int(row[1])}
                            for row in result
                        ]
            except Exception:
                pass

    def _generate_alerts(self, profile: ColumnProfile) -> List[Dict]:
        """Generate quality alerts for a column profile."""
        alerts = []

        # High cardinality alert
        if profile.distinct_percent > 99:
            alerts.append({
                "type": "HIGH_CARDINALITY",
                "severity": "info",
                "message": f"Column is {profile.distinct_percent:.1f}% unique",
            })

        # High null rate alert
        if profile.null_percent > 20:
            alerts.append({
                "type": "MISSING",
                "severity": "warning",
                "message": f"Column has {profile.null_percent:.1f}% null values",
            })

        # Low cardinality (possible category)
        if profile.distinct_count < 10 and profile.row_count > 1000:
            alerts.append({
                "type": "LOW_CARDINALITY",
                "severity": "info",
                "message": f"Column has only {profile.distinct_count} distinct values",
            })

        return alerts

    def _store_profile(self, profile: TableProfile) -> None:
        """Store profile results in metadata_store.duckdb."""
        try:
            from dbt.compute.metadata import ProjectMetadataStore, ColumnProfileResult

            project_root = Path(self.runtime_config.project_root)
            store = ProjectMetadataStore(project_root)
            store.initialize()

            for col in profile.columns:
                result = ColumnProfileResult(
                    source_name=profile.source_name,
                    table_name=profile.table_name,
                    column_name=col.column_name,
                    profile_mode=profile.profile_mode,
                    row_count=col.row_count,
                    null_count=col.null_count,
                    null_percent=col.null_percent,
                    distinct_count=col.distinct_count,
                    distinct_percent=col.distinct_percent,
                    min_value=col.min_value,
                    max_value=col.max_value,
                    mean_value=col.mean_value,
                    median_value=col.median_value,
                    stddev_value=col.stddev_value,
                    p25=col.p25,
                    p50=col.p50,
                    p75=col.p75,
                    min_length=col.min_length,
                    max_length=col.max_length,
                    avg_length=col.avg_length,
                    histogram=json.dumps(col.histogram) if col.histogram else None,
                    top_values=json.dumps(col.top_values) if col.top_values else None,
                    alerts=json.dumps(col.alerts) if col.alerts else None,
                    profiled_at=profile.profiled_at,
                    duration_ms=col.duration_ms,
                )
                store.save_profile_result(result)

            store.close()

        except Exception as e:
            # Log but don't fail if storage fails
            click.echo(f"  Warning: Could not store profile results: {e}")

    def _print_summary(self, result: ProfileExecutionResult) -> None:
        """Print PipeRider-style summary."""
        click.echo("")
        click.echo("=" * 80)
        click.echo("Summary:")
        click.echo(f"  Tables profiled: {result.tables_profiled}")
        click.echo(f"  Total rows: {result.total_rows:,}")
        click.echo(f"  Total columns: {result.total_columns}")
        click.echo(f"  Alerts: {result.total_alerts}")

        # List alerts by type
        if result.total_alerts > 0:
            click.echo("")
            click.echo("Alerts:")
            for profile in result.profiles:
                for col in profile.columns:
                    for alert in col.alerts:
                        severity_icon = "!" if alert["severity"] == "warning" else "-"
                        click.echo(f"    {severity_icon} {alert['type']}: {profile.table_name}.{col.column_name} ({alert['message']})")

        click.echo("")
        click.echo(f"Results saved to: .dvt/metadata_store.duckdb")
        click.echo("View report: dvt docs serve")

    def interpret_results(self, result: ProfileExecutionResult) -> bool:
        """Interpret results to determine success/failure."""
        if not result.profiles:
            return False
        # Success if at least one profile completed
        return any(p.status == "success" for p in result.profiles)
