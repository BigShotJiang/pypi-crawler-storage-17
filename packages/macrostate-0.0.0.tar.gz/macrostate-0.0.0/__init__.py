# -*- coding: utf-8 -*-
"""macrostate modules."""