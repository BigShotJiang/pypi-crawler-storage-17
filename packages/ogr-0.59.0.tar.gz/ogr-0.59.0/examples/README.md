# Jupyter examples for `ogr`

- [User's repositories on GitHub](user_owned_repositories.ipynb)
- [Releases in 2020 on GitLab](releases.ipynb)
- [Patches to open pull requests on Pagure](list_pr_patches.ipynb)
- [Listing all pull requests since specific release on GitHub](list_prs_since_release.ipynb)
- [Actions on issues on GitHub](working_with_issues.ipynb)
- [Syncing the labels on GitHub](syncing_labels.ipynb)
