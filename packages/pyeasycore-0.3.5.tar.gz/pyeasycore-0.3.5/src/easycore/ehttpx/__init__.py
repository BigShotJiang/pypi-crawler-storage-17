# -*- coding: utf-8 -*-
# author: NhanDD3 <hp.duongducnhan@gmail.com>

from .log_patcher import monkey_patch_httpx

__all__ = [
    "monkey_patch_httpx",
]
