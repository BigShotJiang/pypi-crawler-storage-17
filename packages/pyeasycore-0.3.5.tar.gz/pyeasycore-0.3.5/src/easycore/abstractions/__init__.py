# -*- coding: utf-8 -*-
# author: NhanDD3 <hp.duongducnhan@gmail.com>

from .singleton_class import SingletonMeta

__all__ = [
    "SingletonMeta",
]
