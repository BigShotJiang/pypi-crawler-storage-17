# 🚢 cruise-llm 

**The fastest way to build, chain, and reuse LLM agents and flows.**

```python
from cruise_llm import LLM

# That's it. Start chatting.
LLM().user("Explain quantum computing").chat()
```

More documentation coming soon. This project is in active development