RANKINGS = ['gpt-5.2-pro','gemini/gemini-3-pro-preview', 'claude-opus-4-5-20251101', 'claude-sonnet-4-5-20250929', 
'gpt-5.1-2025-11-13','claude-haiku-4-5-20251001', 'gemini/gemini-flash-latest', 'gpt-4o-search-preview', 
'gpt-5-pro-2025-10-06','o3-pro-2025-06-10', 'o3-deep-research-2025-06-26']
