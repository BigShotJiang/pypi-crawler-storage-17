"""
Tests for Sticky Note Organizer
"""