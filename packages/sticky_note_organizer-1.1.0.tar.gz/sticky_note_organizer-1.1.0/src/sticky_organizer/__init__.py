"""
Sticky Note Organizer - A powerful tool to extract and organize Microsoft Sticky Notes
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"