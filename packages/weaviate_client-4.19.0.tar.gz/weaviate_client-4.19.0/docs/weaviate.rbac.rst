weaviate.rbac
=============

.. automodule:: weaviate.rbac
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.rbac.models
^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.rbac.models
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.rbac.roles
^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.rbac.roles
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

.. weaviate.rbac.sync
.. ^^^^^^^^^^^^^^^^^^

.. .. automodule:: weaviate.rbac.sync
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:
