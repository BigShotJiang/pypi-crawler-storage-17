from basil_core.__version__ import __version__
