from basil_core.astro.relations.GSMF.Fontana import Fontana_GSMF
from basil_core.astro.relations.GSMF.Fontana import Cole_GSMF
from basil_core.astro.relations.GSMF.Navarro import Navarro_GSMF
from basil_core.astro.relations.GSMF.Weibel import Weibel_GSMF
from basil_core.astro.relations.GSMF.Furlong2015 import Furlong2015_GSMF
