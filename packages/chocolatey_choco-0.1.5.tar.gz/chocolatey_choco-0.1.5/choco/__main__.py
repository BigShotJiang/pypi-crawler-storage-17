"""Entry point for ``python -m`` invocation."""
from __future__ import annotations

from .main import main

main()
