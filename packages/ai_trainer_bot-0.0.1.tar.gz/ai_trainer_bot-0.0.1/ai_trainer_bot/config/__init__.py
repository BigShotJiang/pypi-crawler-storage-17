"""ai_trainer_bot config package."""
