#!/bin/bash
pytest --durations=0