"""
### Typed Latoken
> A fully typed, validated async client for the Latoken API

- Details
"""