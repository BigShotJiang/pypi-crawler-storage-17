# Typed Latoken

> A fully typed, validated async client for the Latoken API

Use *autocomplete* instead of documentation.

🚧 Under construction.