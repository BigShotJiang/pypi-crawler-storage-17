"""Kubernetes cluster management commands package."""

from .commands import command

__all__ = ["command"]
