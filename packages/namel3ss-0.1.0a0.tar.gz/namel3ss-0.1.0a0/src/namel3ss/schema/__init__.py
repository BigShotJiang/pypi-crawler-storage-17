"""Schema definitions for Namel3ss records."""

