# {{PROJECT_NAME}} (AI Assistant)

Ask an AI assistant over saved notes. Includes an echo tool, memory config, and a notes page with a call-to-action button.

Run it with:
- `n3 app.ai check`
- `n3 app.ai studio`
- `n3 app.ai actions`

Put any API keys in a local `.env` (not committed).
