"""Sony Automator Controls - TCP to HTTP command bridge for Sony devices."""

__version__ = "1.1.1"
__app_name__ = "Sony Automator Controls"
