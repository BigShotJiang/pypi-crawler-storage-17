"""Agentic Workflow - Multi-agent planning system."""
__version__ = "1.0.6"

