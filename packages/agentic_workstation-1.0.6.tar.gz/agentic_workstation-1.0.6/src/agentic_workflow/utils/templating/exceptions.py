"""Exceptions for the templating package."""

from agentic_workflow.core.exceptions import TemplateError

__all__ = ["TemplateError"]