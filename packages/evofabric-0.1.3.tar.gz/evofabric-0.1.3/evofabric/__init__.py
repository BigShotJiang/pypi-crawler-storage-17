# -*- coding: utf-8 -*-
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.

__version__ = '0.1.3'

from .plugin_manager import init_plugins

init_plugins()
