from typing import TypeAlias
from ...schemas import TimeEntry

GetCurrentResponse: TypeAlias = TimeEntry