from typing import TypeAlias
from ..._schemas import Organization

GetOrganizationResponse: TypeAlias = Organization