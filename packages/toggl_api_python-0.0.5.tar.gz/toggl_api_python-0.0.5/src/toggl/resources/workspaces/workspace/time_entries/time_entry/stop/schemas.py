from typing import TypeAlias
from ......_schemas import TimeEntry

PatchStopResponse: TypeAlias = TimeEntry