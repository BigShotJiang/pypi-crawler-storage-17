# -*- coding: utf-8 -*-
"""Tocount modules."""

from .params import TOCOUNT_VERSION
from .functions import estimate_text_tokens, TextEstimator
__version__ = TOCOUNT_VERSION
