"""
### Typed Bitcoin
> A fully typed, validated async client for the Bitcoin API

- Details
"""