# Typed Bitcoin

> A fully typed, validated async client for the Bitcoin API

Use *autocomplete* instead of documentation.

🚧 Under construction.