"""Click payment gateway implementation."""
from .client import ClickGateway  # noqa: F401