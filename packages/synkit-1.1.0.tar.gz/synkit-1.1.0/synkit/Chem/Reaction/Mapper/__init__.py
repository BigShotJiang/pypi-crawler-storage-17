import warnings

warnings.warn(
    "synkit.Reaction.Mapper is under active development and may be unstable. "
    "APIs and behaviour may change without notice.",
    UserWarning,
    stacklevel=2,
)
