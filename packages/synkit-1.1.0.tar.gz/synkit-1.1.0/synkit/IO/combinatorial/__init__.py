import warnings

warnings.warn(
    "⚠️ This module is under active development and may be unstable. "
    "APIs, behaviors, or outputs are subject to change without notice.",
    category=UserWarning,
    stacklevel=2,
)
