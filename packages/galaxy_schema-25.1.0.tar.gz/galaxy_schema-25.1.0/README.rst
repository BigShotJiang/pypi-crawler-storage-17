
.. image:: https://badge.fury.io/py/galaxy-schema.svg
   :target: https://pypi.org/project/galaxy-schema/



Overview
--------

The Galaxy_ API schema objects.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
