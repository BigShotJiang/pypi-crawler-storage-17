# -*- coding: UTF-8 -*-
# @Time : 2023/9/27 17:02 
# @Author : 刘洪波
install_requires = [
    'httpx>=0.27.0',
    'loguru>=0.7.2',
    'openai>=1.100.1',
    'tenacity>=8.2.3',
]
