"""Localization API - 本地化"""

from .localization import LocalizationAPI

__all__ = ["LocalizationAPI"]

