"""Partner Opportunities API"""
from .partner_opportunities import PartnerOpportunitiesAPI

__all__ = ["PartnerOpportunitiesAPI"]

