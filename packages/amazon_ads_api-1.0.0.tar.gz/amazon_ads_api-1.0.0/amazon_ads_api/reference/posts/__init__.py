"""Posts API - 帖子管理"""

from .posts import PostsAPI

__all__ = ["PostsAPI"]

