"""Brand Associations API - 品牌关联"""

from .brand_associations import BrandAssociationsAPI

__all__ = ["BrandAssociationsAPI"]

