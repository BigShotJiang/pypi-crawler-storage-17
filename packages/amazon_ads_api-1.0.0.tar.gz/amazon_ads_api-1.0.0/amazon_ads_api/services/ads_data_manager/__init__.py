"""Ads Data Manager API - 广告数据管理器"""

from .ads_data_manager import AdsDataManagerAPI

__all__ = ["AdsDataManagerAPI"]

