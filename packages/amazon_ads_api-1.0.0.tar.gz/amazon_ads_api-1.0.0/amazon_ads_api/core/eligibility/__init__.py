"""Eligibility API模块"""

from .eligibility import EligibilityAPI

__all__ = ["EligibilityAPI"]

