# tink-http-python
[![tag](https://img.shields.io/github/tag/namelivia/tink-http-python.svg)](https://github.com/namelivia/tink-http-python/releases) [![build](https://github.com/namelivia/tink-http-python/actions/workflows/build.yml/badge.svg)](https://github.com/namelivia/tink-http-python/actions/workflows/build.yml) [![codecov](https://codecov.io/gh/namelivia/tink-http-python/branch/main/graph/badge.svg?token=NlsLE3qD4V)](https://codecov.io/gh/namelivia/tink-http-python)
 [![Lint](https://github.com/namelivia/tink-http-python/actions/workflows/black.yml/badge.svg)](https://github.com/namelivia/tink-http-python/actions/workflows/black.yml)


Retrieve bank accounts information using python
