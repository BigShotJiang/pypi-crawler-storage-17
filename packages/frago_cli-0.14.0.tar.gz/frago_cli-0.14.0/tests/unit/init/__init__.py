"""Unit tests for frago.init module"""
