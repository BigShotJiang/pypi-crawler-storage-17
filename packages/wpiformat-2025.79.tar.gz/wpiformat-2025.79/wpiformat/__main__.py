#!/usr/bin/env python3

import wpiformat

wpiformat.main()
