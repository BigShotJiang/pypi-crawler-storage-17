"""For when someone really wants to type a lot."""

if __name__ == "__main__":
    from ._internal.cli import main

    main()
