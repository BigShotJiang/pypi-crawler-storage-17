"""A simple number adder package."""

__version__ = "0.1.0"


def add(a: float, b: float) -> float:
    """Add two numbers and return the result."""
    return a + b
