# number-adder

A simple CLI tool that adds two numbers.

## Installation

```bash
pip install number-adder
```

## Usage

```bash
number-adder 5 7
# Output: 12.0
```
