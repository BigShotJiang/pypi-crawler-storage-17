"""Command line interface for prometh-cortex."""

from prometh_cortex.cli.main import main

__all__ = ["main"]