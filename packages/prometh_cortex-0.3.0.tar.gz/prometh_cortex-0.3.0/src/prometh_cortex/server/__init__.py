"""FastAPI MCP server for RAG queries."""

from prometh_cortex.server.app import create_app

__all__ = ["create_app"]