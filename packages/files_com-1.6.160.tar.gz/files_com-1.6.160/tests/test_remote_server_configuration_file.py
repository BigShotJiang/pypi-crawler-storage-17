import unittest
import inspect
import files_sdk
from tests.base import TestBase
from files_sdk.models import RemoteServerConfigurationFile
from files_sdk import remote_server_configuration_file

class RemoteServerConfigurationFileTest(TestBase):
    pass 
    # Instance Methods

    # Static Methods
if __name__ == '__main__':
    unittest.main()