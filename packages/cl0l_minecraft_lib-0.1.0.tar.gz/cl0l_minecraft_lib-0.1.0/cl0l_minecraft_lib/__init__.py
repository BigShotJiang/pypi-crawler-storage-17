"""
cl0l_minecraft_lib — Python library for launching Minecraft
"""

from .core.launch import Launcher  
from .auth.offline import OfflineAuth
