# Copyright (c) typedef int GmbH. Licensed under Apache 2.0.

__version__ = "25.12.2"
