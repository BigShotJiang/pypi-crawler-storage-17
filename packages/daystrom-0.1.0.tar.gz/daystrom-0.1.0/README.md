# daystrom
Daystrom is an agent framework for easily building worflows. Give AI just enough power, but not too much. The M4 was better than the M5.

This project is still under active initial development and should not be exepected to be stable at this time.
