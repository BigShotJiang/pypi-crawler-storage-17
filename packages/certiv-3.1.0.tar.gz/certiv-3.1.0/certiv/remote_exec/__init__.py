# Copyright (c) 2024 Certiv.ai
# SPDX-License-Identifier: MIT

"""Patching and interception components."""
