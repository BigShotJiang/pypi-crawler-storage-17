"""DynamoDB backend for InLayers models."""

from .services import DynamoDBBackend

__all__ = ["DynamoDBBackend"]
