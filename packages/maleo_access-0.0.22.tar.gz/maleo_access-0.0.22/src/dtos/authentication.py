from ..mixins.authentication import RefreshToken, AccessToken, TokenType, ExpiresIn


class AuthenticationDTO(
    ExpiresIn,
    TokenType,
    AccessToken,
    RefreshToken,
):
    pass
