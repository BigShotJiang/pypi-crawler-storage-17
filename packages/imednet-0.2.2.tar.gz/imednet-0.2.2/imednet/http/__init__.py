"""HTTP transport primitives."""
