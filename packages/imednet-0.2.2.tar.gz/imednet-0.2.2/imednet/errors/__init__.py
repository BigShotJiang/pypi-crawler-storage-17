"""Exception hierarchy."""
