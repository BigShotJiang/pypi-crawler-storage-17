"""Authentication helpers."""
