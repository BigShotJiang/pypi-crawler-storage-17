from __future__ import annotations

from typing import Iterator, Sequence, overload


@overload
def chunked(iterable: str, n: int) -> Iterator[str]: ...


@overload
def chunked(iterable: bytes, n: int) -> Iterator[bytes]: ...


@overload
def chunked[T](iterable: Sequence[T], n: int) -> Iterator[Sequence[T]]: ...


def chunked[T](iterable: Sequence[T], n: int) -> Iterator[Sequence[T]]:
    for i in range(0, len(iterable), n):
        yield iterable[i : i + n]


ADJUST_POSITION_BY_VERSION: tuple[tuple[int, ...], ...] = (
    (),
    (6, 18),
    (6, 22),
    (6, 26),
    (6, 30),
    (6, 34),
    (6, 22, 38),
    (6, 24, 42),
    (6, 26, 46),
    (6, 28, 50),
    (6, 30, 54),
    (6, 32, 58),
    (6, 34, 62),
    (6, 26, 46, 66),
    (6, 26, 48, 70),
    (6, 26, 50, 74),
    (6, 30, 54, 78),
    (6, 30, 56, 82),
    (6, 30, 58, 86),
    (6, 34, 62, 90),
    (6, 28, 50, 72, 94),
    (6, 26, 50, 74, 98),
    (6, 30, 54, 78, 102),
    (6, 28, 54, 80, 106),
    (6, 32, 58, 84, 110),
    (6, 30, 58, 86, 114),
    (6, 34, 62, 90, 118),
    (6, 26, 50, 74, 98, 122),
    (6, 30, 54, 78, 102, 126),
    (6, 26, 52, 78, 104, 130),
    (6, 30, 56, 82, 108, 134),
    (6, 34, 60, 86, 112, 138),
    (6, 30, 58, 86, 114, 142),
    (6, 34, 62, 90, 118, 146),
    (6, 30, 54, 78, 102, 126, 150),
    (6, 24, 50, 76, 102, 128, 154),
    (6, 28, 54, 80, 106, 132, 158),
    (6, 32, 58, 84, 110, 136, 162),
    (6, 26, 54, 82, 110, 138, 166),
    (6, 30, 58, 86, 114, 142, 170),
)

G15 = (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0)
G18 = (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0)
G15_MASK = (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1)


def bch_type_info(data: int):
    bch_g15 = bch_digit(G15)
    d = data << 10
    while bch_digit(d) - bch_g15 >= 0:
        d ^= G15 << (bch_digit(d) - bch_g15)

    return ((data << 10) | d) ^ G15_MASK


def bch_type_number(data: int):
    bch_g18 = bch_digit(G18)
    d = data << 12
    while bch_digit(d) - bch_g18 >= 0:
        d ^= G18 << (bch_digit(d) - bch_g18)
    return (data << 12) | d


def bch_digit(data: int):
    digit = 0
    while data != 0:
        digit += 1
        data >>= 1
    return digit


def get_adjust_pattern_pos(version: int):
    return ADJUST_POSITION_BY_VERSION[version - 1]
