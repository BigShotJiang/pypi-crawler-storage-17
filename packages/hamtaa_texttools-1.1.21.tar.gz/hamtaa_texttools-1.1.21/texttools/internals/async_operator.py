from typing import TypeVar, Type
from collections.abc import Callable

from openai import AsyncOpenAI
from pydantic import BaseModel

from texttools.internals.models import OperatorOutput
from texttools.internals.operator_utils import OperatorUtils
from texttools.internals.prompt_loader import PromptLoader
from texttools.internals.exceptions import (
    TextToolsError,
    LLMError,
    ValidationError,
    PromptError,
)

# Base Model type for output models
T = TypeVar("T", bound=BaseModel)


class AsyncOperator:
    """
    Core engine for running text-processing operations with an LLM.
    """

    def __init__(self, client: AsyncOpenAI, model: str):
        self._client = client
        self._model = model

    async def _analyze_completion(self, analyze_prompt: str, temperature: float) -> str:
        try:
            if not analyze_prompt:
                raise PromptError("Analyze template is empty")

            analyze_message = OperatorUtils.build_user_message(analyze_prompt)

            completion = await self._client.chat.completions.create(
                model=self._model,
                messages=analyze_message,
                temperature=temperature,
            )

            if not completion.choices:
                raise LLMError("No choices returned from LLM")

            analysis = completion.choices[0].message.content.strip()

            if not analysis:
                raise LLMError("Empty analysis response")

            return analysis

        except Exception as e:
            if isinstance(e, (PromptError, LLMError)):
                raise
            raise LLMError(f"Analysis failed: {e}")

    async def _parse_completion(
        self,
        main_prompt: str,
        output_model: Type[T],
        temperature: float,
        logprobs: bool,
        top_logprobs: int,
        priority: int,
    ) -> tuple[T, object]:
        """
        Parses a chat completion using OpenAI's structured output format.
        Returns both the parsed object and the raw completion for logprobs.
        """
        try:
            main_message = OperatorUtils.build_user_message(main_prompt)

            request_kwargs = {
                "model": self._model,
                "messages": main_message,
                "response_format": output_model,
                "temperature": temperature,
            }

            if logprobs:
                request_kwargs["logprobs"] = True
                request_kwargs["top_logprobs"] = top_logprobs

            if priority:
                request_kwargs["extra_body"] = {"priority": priority}

            completion = await self._client.beta.chat.completions.parse(
                **request_kwargs
            )

            if not completion.choices:
                raise LLMError("No choices returned from LLM")

            parsed = completion.choices[0].message.parsed

            if not parsed:
                raise LLMError("Failed to parse LLM response")

            return parsed, completion

        except Exception as e:
            if isinstance(e, LLMError):
                raise
            raise LLMError(f"Completion failed: {e}")

    async def run(
        self,
        # User parameters
        text: str,
        with_analysis: bool,
        output_lang: str | None,
        user_prompt: str | None,
        temperature: float,
        logprobs: bool,
        top_logprobs: int,
        validator: Callable[[object], bool] | None,
        max_validation_retries: int | None,
        priority: int,
        # Internal parameters
        prompt_file: str,
        output_model: Type[T],
        mode: str | None,
        **extra_kwargs,
    ) -> OperatorOutput:
        """
        Execute the LLM pipeline with the given input text. (Sync)
        """
        try:
            prompt_loader = PromptLoader()

            prompt_configs = prompt_loader.load(
                prompt_file=prompt_file,
                text=text.strip(),
                mode=mode,
                **extra_kwargs,
            )

            main_prompt = ""
            analysis = ""

            if with_analysis:
                analysis = await self._analyze_completion(
                    prompt_configs["analyze_template"], temperature
                )
                main_prompt += f"Based on this analysis:\n{analysis}\n"

            if output_lang:
                main_prompt += f"Respond only in the {output_lang} language.\n"

            if user_prompt:
                main_prompt += f"Consider this instruction {user_prompt}\n"

            main_prompt += prompt_configs["main_template"]

            if logprobs and (not isinstance(top_logprobs, int) or top_logprobs < 2):
                raise ValueError("top_logprobs should be an integer greater than 1")

            parsed, completion = await self._parse_completion(
                main_prompt, output_model, temperature, logprobs, top_logprobs, priority
            )

            # Retry logic if validation fails
            if validator and not validator(parsed.result):
                if (
                    not isinstance(max_validation_retries, int)
                    or max_validation_retries < 1
                ):
                    raise ValueError(
                        "max_validation_retries should be a positive integer"
                    )

                succeeded = False
                for _ in range(max_validation_retries):
                    # Generate a new temperature to retry
                    retry_temperature = OperatorUtils.get_retry_temp(temperature)

                    try:
                        parsed, completion = await self._parse_completion(
                            main_prompt,
                            output_model,
                            retry_temperature,
                            logprobs,
                            top_logprobs,
                            priority=priority,
                        )

                        # Check if retry was successful
                        if validator(parsed.result):
                            succeeded = True
                            break

                    except LLMError:
                        pass

                if not succeeded:
                    raise ValidationError("Validation failed after all retries")

            operator_output = OperatorOutput(
                result=parsed.result,
                analysis=analysis if with_analysis else None,
                logprobs=OperatorUtils.extract_logprobs(completion)
                if logprobs
                else None,
            )

            return operator_output

        except (PromptError, LLMError, ValidationError):
            raise
        except Exception as e:
            raise TextToolsError(f"Unexpected error in operator: {e}")
