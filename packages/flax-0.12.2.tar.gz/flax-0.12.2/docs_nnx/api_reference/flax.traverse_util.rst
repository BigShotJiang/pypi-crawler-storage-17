flax.traverse_util package
============================

.. currentmodule:: flax.traverse_util

.. automodule:: flax.traverse_util

Dict utils
------------

.. autofunction:: flatten_dict

.. autofunction:: unflatten_dict

.. autofunction:: path_aware_map
