object
------------------------

.. automodule:: flax.nnx
.. currentmodule:: flax.nnx

.. autoclass:: Pytree
   :members:
.. autoclass:: Object
   :members:
.. autofunction:: data
.. autodata:: Data
   :annotation:
.. autofunction:: static
.. autodata:: Static
   :annotation:
.. autofunction:: is_data
.. autofunction:: register_data_type
.. autofunction:: check_pytree