module
------------------------

.. automodule:: flax.nnx
    :members: iter_children, iter_modules
.. currentmodule:: flax.nnx
.. autoclass:: Module
   :members:
