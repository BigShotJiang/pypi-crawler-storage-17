### Do we need another JAX NN library?

Hello, today I want to talk to you about a new JAX library that I have been working on, but before I do that, I wanted to discuss the topic: Do we need another JAX NN library?

### JAX Libraries

JAX NN libraries come in a wide variety ranging from functional like Flax and Haiku, to Pytree-based like Equinox.