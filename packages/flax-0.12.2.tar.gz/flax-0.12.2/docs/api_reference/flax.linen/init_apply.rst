
Init/Apply
==============

.. currentmodule:: flax.linen

.. autofunction:: apply
.. autofunction:: init
.. autofunction:: init_with_output
