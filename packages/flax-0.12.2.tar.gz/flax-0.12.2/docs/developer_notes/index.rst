Developer notes
===============

.. toctree::
   :maxdepth: 1

   module_lifecycle
   lift
   FLIPs <https://github.com/google/flax/tree/main/docs/flip>
