- Start Date: (fill me in with today's date, YYYY-MM-DD)
- FLIP PR: [#0000](https://github.com/google/flax/pull/0000)
- FLIP Issue: [#0000](https://github.com/google/flax/issues/0000)

(Below sections are just a possible structure - please adapt to your FLIP.)

# Summary
[summary]: #summary

One paragraph explanation of the FLIP.

# Motivation
[motivation]: #motivation

Why are we doing this? What use cases does it support? What is the expected outcome?

# Implementation
[implementation]: #implementation

The technical part.

# Discussion
[discussion]: #discussion

Summarize the discussion from the original issue and from the pull request.
