"""uQCme - Microbial Quality Control Dashboard"""

__version__ = "0.7.0"
__description__ = "Microbial Quality Control Dashboard"
__author__ = "SSI-DK"
