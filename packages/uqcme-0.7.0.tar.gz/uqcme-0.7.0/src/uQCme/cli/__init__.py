"""CLI module for uQCme."""

from uQCme.cli.main import main

__all__ = ["main"]
