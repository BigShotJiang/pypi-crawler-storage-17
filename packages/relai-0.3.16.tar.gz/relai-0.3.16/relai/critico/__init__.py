from .critico import Critico

__all__ = ["Critico"]
