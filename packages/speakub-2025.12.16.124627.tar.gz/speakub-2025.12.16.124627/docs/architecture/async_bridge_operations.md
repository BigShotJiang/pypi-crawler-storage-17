# SpeakUB AsyncBridge 操作目錄

## 📋 概述

本文檔詳細記錄SpeakUB中AsyncBridge的所有操作類型、分類和使用規範。基於保守的安全策略，明確哪些操作必須同步等待，哪些可以異步執行。

**核心原則：橋接操作的分類決定了用戶體驗的一致性，任何錯誤分類都可能導致UI/播放不同步。**

---

## 🏗️ AsyncBridge架構

### 設計目的

AsyncBridge是SpeakUB混合並發架構的核心組件，負責：
- 同步上下文與異步上下文間的安全通訊
- 事件狀態的橋接
- 協程的執行和委派
- 操作的性能監控

### 操作分類

| 分類 | 同步等待 | 典型用例 | 用戶體驗影響 |
|------|----------|----------|--------------|
| **關鍵操作** | ✅ 必須等待 | 狀態變更、UI更新、播放控制 | 立即響應，確保一致性 |
| **背景操作** | ❌ Fire-and-forget | 資源清理、統計收集、緩存更新 | 非阻塞，提升響應性 |

---

## 🔑 關鍵操作 (必須同步等待)

這些操作影響用戶可見的狀態或行為，必須等待完成確保一致性。

### 1. 狀態轉換操作

```python
# 播放控制 - 影響用戶體驗
async def handle_tts_play_pause():
    # 必須等待狀態變更完成
    result = await async_bridge.run_coroutine(change_playback_state())
    update_ui_immediately(result)
```

**包含操作**：
- `handle_tts_play_pause()` - 播放/暫停切換
- `stop_speaking()` - 停止播放
- `set_tts_status_safe()` - 狀態機轉換

**超時設定**：1秒
**失敗處理**：拋出異常，中斷操作

### 2. UI狀態同步

```python
# UI更新 - 確保視覺一致性
async def update_tts_progress():
    # 必須等待UI更新完成
    await async_bridge.run_coroutine(update_progress_display())
    # 此時UI已更新，用戶看到最新狀態
```

**包含操作**：
- `update_tts_progress()` - 進度顯示更新
- `notify_user()` - 用戶通知
- 狀態顯示同步

**超時設定**：1秒
**失敗處理**：記錄警告，繼續執行

### 3. 事件橋接

```python
# 事件狀態同步 - 確保線程間協調
def bridge_event_operation():
    # 必須等待事件狀態確實改變
    success = async_bridge.event_set(playback_ready_event)
    if success:
        # 現在可以安全地依賴事件狀態
        start_next_operation()
```

**包含操作**：
- `event_set()` / `event_clear()` - 事件狀態設定
- 播放就緒事件
- 合成完成事件

**超時設定**：1秒
**失敗處理**：返回布林值，由調用者處理

---

## 🌊 背景操作 (Fire-and-forget)

這些操作不影響用戶立即體驗，可以非阻塞執行。

### 1. 資源清理

```python
# 資源清理 - 不阻塞用戶操作
def cleanup_resources():
    # Fire-and-forget，不等待完成
    async_bridge.run_async_task(cleanup_temp_files())
    # 用戶操作立即繼續，不受清理影響
```

**包含操作**：
- `cleanup_orphaned_temp_files()` - 臨時文件清理
- `cancel_pending_tasks()` - 任務取消
- 資源釋放操作

**執行模式**：非阻塞任務
**失敗處理**：僅記錄日誌，不影響主要流程

### 2. 統計收集

```python
# 統計收集 - 背景執行，不影響用戶體驗
def collect_statistics():
    # Fire-and-forget
    async_bridge.run_async_task(update_performance_stats())
    # 用戶體驗不受影響
```

**包含操作**：
- 性能指標收集
- 使用統計更新
- 診斷信息記錄

**執行模式**：非阻塞任務
**失敗處理**：靜默失敗，不記錄錯誤

### 3. 預載操作

```python
# 預載 - 提前準備，但不阻塞當前操作
def start_preloading():
    # Fire-and-forget，提前合成下一段內容
    async_bridge.run_async_task(preload_next_segment())
    # 用戶繼續當前播放，不受影響
```

**包含操作**：
- 播放列表預載
- 內容預合成
- 緩存預熱

**執行模式**：非阻塞任務
**失敗處理**：記錄警告，不中斷主要流程

---

## 📊 性能監控與統計

### 自動收集指標

AsyncBridge自動監控所有操作的性能：

1. **操作計數**
   - 事件操作總數
   - 協程操作總數
   - 成功/失敗率

2. **性能指標**
   - 平均執行時間
   - 超時發生率
   - 事件循環可用性

3. **分類統計**
   - 關鍵操作 vs 背景操作
   - 直接執行 vs 線程安全執行

### 監控命令

```bash
# 檢查橋接統計
python tools/deadlock_monitor.py status

# 查看詳細統計
python -c "
from speakub.tts.integration import TTSIntegration
# 實例化後檢查 bridge.get_bridge_stats()
"
```

---

## 🚨 錯誤處理與恢復

### 關鍵操作失敗

```python
try:
    # 關鍵操作必須等待
    result = async_bridge.run_coroutine(critical_operation(), timeout=1.0)
    handle_success(result)
except asyncio.TimeoutError:
    # 超時 - 記錄並通知用戶
    logger.error("Critical operation timeout")
    notify_user_operation_failed()
except Exception as e:
    # 其他錯誤 - 記錄並嘗試降級
    logger.error(f"Critical operation failed: {e}")
    handle_graceful_degradation()
```

### 背景操作失敗

```python
try:
    # 背景操作不等待，不檢查結果
    async_bridge.run_async_task(background_operation())
except Exception as e:
    # 靜默失敗，只記錄調試信息
    logger.debug(f"Background operation failed (non-critical): {e}")
```

---

## 🔍 操作分類檢查表

### 新增橋接操作時的檢查

**對於任何新的AsyncBridge操作調用**：

#### 決定分類
- [ ] **用戶體驗影響**：操作結果是否立即影響用戶？
- [ ] **狀態依賴**：後續操作是否依賴此操作的完成？
- [ ] **失敗影響**：操作失敗是否會破壞用戶體驗？

#### 關鍵操作 (必須等待)
- [ ] 使用 `run_coroutine()` 方法
- [ ] 設定適當超時 (通常1秒)
- [ ] 處理所有異常情況
- [ ] 確保操作完成後狀態一致

#### 背景操作 (Fire-and-forget)
- [ ] 使用 `run_async_task()` 或 `delegate_to_async_task()` 方法
- [ ] 不檢查返回值
- [ ] 失敗時靜默或只記錄調試信息
- [ ] 不影響主要用戶流程

---

## 📝 代碼示例

### 正確的關鍵操作使用

```python
def handle_user_pause_request(self):
    """用戶請求暫停 - 關鍵操作"""
    try:
        # 必須等待狀態變更完成
        self.async_bridge.run_coroutine(
            self._change_playback_state("PAUSED"),
            timeout=1.0
        )
        # 現在可以安全地更新UI
        self.update_ui_status("PAUSED")
    except Exception as e:
        logger.error(f"Failed to pause playback: {e}")
        self.notify_user("Pause failed, please try again")
```

### 正確的背景操作使用

```python
def on_playback_completed(self):
    """播放完成 - 背景清理"""
    # 不等待，立即返回
    self.async_bridge.run_async_task(self._cleanup_playback_resources())
    # 不檢查結果，用戶體驗不受影響

    # 繼續處理下一首
    self.start_next_track()
```

---

## 🚫 常見錯誤模式

### 錯誤：關鍵操作使用Fire-and-forget

```python
# ❌ 錯誤 - UI會不同步
def handle_pause_button():
    # Fire-and-forget 但這是關鍵操作
    self.async_bridge.run_async_task(self._pause_playback())
    # UI立即更新，但實際播放可能還沒停止
    self.update_ui_status("PAUSED")  # 狀態不一致！
```

### 錯誤：背景操作等待結果

```python
# ❌ 錯誤 - 阻塞不必要的操作
def cleanup_after_playback():
    # 等待背景清理完成 - 沒意義
    await self.async_bridge.run_coroutine(self._cleanup_resources())
    # 用戶必須等待清理完成才能繼續
```

---

## 📚 相關文檔

- [鎖定使用規範指南](locking_guidelines.md) - 鎖定層次結構
- [混合異步架構設計](hybrid_async_architecture.md) - 整體架構設計
- [Voice Selector引擎切換跳章分析](../../documents/VOICE_SELECTOR_ENGINE_SWITCH_CHAPTER_JUMP_ANALYSIS.md) - 分類錯誤的後果

## 🔧 維護指南

### 定期審查

每季度審查一次AsyncBridge操作分類：
- [ ] 檢查是否有操作分類錯誤
- [ ] 驗證超時設定是否合理
- [ ] 評估性能指標是否正常
- [ ] 更新文檔以反映新操作

### 添加新操作

添加新的橋接操作時：
1. 確定操作分類（關鍵 vs 背景）
2. 選擇適當的方法
3. 更新此文檔
4. 添加到開發者檢查清單

---

## 📝 變更歷史

- **2025-12-13**: 初始版本，建立AsyncBridge操作分類規範
- **基於**: 混合架構設計原則和用戶體驗一致性需求

---

**本文檔確保SpeakUB的橋接操作既安全又高效。如有新操作需求，請在此文檔中記錄並分類。**
