# SpeakUB Project Empty Cup 監控指南

🔍 SpeakUB Project Empty Cup 監控指南

1. 日誌監控指標:
   • INFO: "TTS Initial buffering" - 正常啟動行為
   • WARNING: "TTS Underrun detected" - 真正的播放中斷
   • WARNING: "high_cpu_usage" - 持續性性能問題

2. 性能指標:
   • CPU 使用率應 < 80% (持續性)
   • 啟動期間 CPU 尖峰被抑制
   • 緩衝狀態正確顯示

3. 用戶體驗指標:
   • 播放按鈕 → BUFFERING... → PLAYING
   • 啟動時間 < 預期值
   • 無不必要的警告訊息

4. 警報規則:
   • 啟動前 10 秒忽略 CPU 警報
   • 只對連續 5 次高負載發警報
   • Underrun 只在非初始緩衝期間記錄
