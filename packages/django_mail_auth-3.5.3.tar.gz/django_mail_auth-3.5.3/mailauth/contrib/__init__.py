"""Secure login links; no passwords required."""
