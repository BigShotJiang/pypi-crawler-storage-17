export { Image } from "./Image";
export { DataTable } from "./DataTable";
export { default as Descr } from "./Descr.svelte";
export { default as Iframe } from "./Iframe.svelte";
export { default as Plotly } from "./Plotly.svelte";
export { default as Math } from "./Math.svelte";
