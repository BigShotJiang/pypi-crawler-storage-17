"""Test database uploads and queries."""

# from typing import List

# from waft.database import get_yt_url
# from waft.datatypes import Album, Artist, FullMetadata, Track


# NOTE: Should add a clean-up feature to not clog up database with tests
def test_upload_relation_returns():
    """Test that a FullMetadata object can upload to DB."""
    # track: Track = Track(1, False, "Test Track", "1-1-70", 1)
    # album: Album = Album("Test Album", "https://test.com")
    # artist: Artist = Artist("Test Artist")
    # artists: List[Artist] = [artist]
    # metadata: FullMetadata = FullMetadata(album, artists, track)
    # try:
    #     upload_relation(metadata, "test.com", "TEST_HASH")
    # except Exception as e:
    #     print(e)
    #     assert False
    assert True


def test_get_yt_url():
    """Test that a str is returned."""
    # track: Track = Track(1, False, "Test Track", "1-1-70", 1)
    # album: Album = Album("Test Album", "https://test.com")
    # artist: Artist = Artist("Test Artist")
    # artists: List[Artist] = [artist]
    # metadata: FullMetadata = FullMetadata(album, artists, track)
    # link: str | None = get_yt_url(metadata)
    # assert link is None or isinstance(link, str)
    # assert isinstance(link, str)
    assert True
