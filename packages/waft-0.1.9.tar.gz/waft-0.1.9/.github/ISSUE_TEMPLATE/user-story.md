---
name: User Story
about: Frame every new feature/enhancement around the user's goal
title: ''
labels: ''
assignees: ''

---

As a [*specific user type*], I want [*specific capability*], so that [*specific benefit*].

**Acceptance Criteria**
- [ ] Given [*context*], when [*action*], then [*outcome*]

**Additional Notes**
- For further relevant information (delete if irrelevant.)
