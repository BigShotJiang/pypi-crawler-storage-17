"""Resources package"""
