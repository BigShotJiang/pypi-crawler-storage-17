from speckle2graph.models.geometry import GeometryNode
from speckle2graph.models.logical import LogicalNode

__all__ = ["GeometryNode", "LogicalNode"]
