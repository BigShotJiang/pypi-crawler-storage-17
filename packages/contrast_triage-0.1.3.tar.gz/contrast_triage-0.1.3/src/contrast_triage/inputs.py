from sarif_pydantic import Sarif, Result


def load_sarif_file(sarif_file: str) -> Sarif:
    with open(sarif_file, "r") as f:
        sarif = Sarif.model_validate_json(f.read())

    return sarif


def relativize_sarif_uri(result: Result) -> None:
    # relativize location data if its an absolute path
    # TODO: This is just a hack until I add in more robust file system handling
    locs = result.locations
    loc = locs[0] if locs and len(locs) > 0 else None

    if loc is None:
        raise ValueError("No location data found in SARIF result")

    if (
        loc.physical_location is not None
        and loc.physical_location.artifact_location is not None
        and loc.physical_location.artifact_location.uri is not None
    ):
        uri = loc.physical_location.artifact_location.uri
        loc.physical_location.artifact_location.uri = (
            uri[1:] if uri.startswith("/") else uri
        )
        print(f"    uri: {loc.physical_location.artifact_location.uri}")  # type: ignore
        print(f"    line: {loc.physical_location.region.start_line}")  # type: ignore
