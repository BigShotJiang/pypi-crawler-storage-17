from langchain_core.tools import tool, InjectedToolCallId
from pydantic import BaseModel, Field
from typing import Optional, List, Annotated
from langgraph.types import Command
from langchain_core.messages import ToolMessage
from models import AgentState, Task
from langgraph.prebuilt import InjectedState


class ReadFileSnippetResponse(BaseModel):
    file_path: str = Field(description="The path to the file.")
    start_line: int = Field(description="The starting line number of the snippet")
    end_line: int = Field(description="The ending line number of the snippet")
    content: List[str] = Field(description="The content of the file snippet.")


@tool()  # response_format="content_and_artifact"
def read_file_snippet(
    file_path: Annotated[str, "The path to the file"],
    start_line: Annotated[int, "The starting line number (1-based)"],
    end_line: Annotated[int, "The ending line number (1-based)"],
) -> ReadFileSnippetResponse:
    """Read a snippet of a file from start_line to end_line (inclusive)."""
    if start_line < 1 or end_line < start_line:
        raise ValueError("Invalid line range specified.")
    with open(file_path, "r") as f:
        lines = f.readlines()
        # Adjust for 0-based index
        response = ReadFileSnippetResponse(
            file_path=file_path,
            start_line=start_line,
            end_line=end_line,
            content=lines[start_line - 1 : end_line],
        )
        return response


class SearchHitInFilesResponse(BaseModel):
    """A single search hit"""

    path: str = Field(..., description="The file path where the pattern was found.")
    line_number: int = Field(
        ..., description="The line number where the pattern was found."
    )
    line_content: str = Field(
        ..., description="The content of the line where the pattern was found."
    )


@tool()
def search_in_files(
    pattern: Annotated[str, "The regex pattern to search for"],
    directory: Annotated[str, "The directory to search in"],
    extensions: Annotated[
        Optional[str],
        'Comma-separated list of file extensions to include (e.g., ".java,.js,.py").',
    ],
) -> List[SearchHitInFilesResponse]:
    """Search for a pattern in files within a directory with given extensions."""
    import os
    import re

    if extensions:
        exts = [ext.strip() for ext in extensions.split(",")]
    else:
        exts = None

    matches: List[SearchHitInFilesResponse] = []
    regex = re.compile(pattern)

    for root, _, files in os.walk(directory):
        for file in files:
            if exts and not any(file.endswith(ext) for ext in exts):
                continue
            file_path = os.path.join(root, file)
            with open(file_path, "r") as f:
                for i, line in enumerate(f, 1):
                    if regex.search(line):
                        matches.append(
                            SearchHitInFilesResponse(
                                path=file_path, line_number=i, line_content=line.strip()
                            )
                        )
                        #

    return matches


@tool()
def search_in_file(
    pattern: Annotated[str, "The regex pattern to search for"],
    file_path: Annotated[str, "The specific file to search within"],
) -> List[SearchHitInFilesResponse]:
    """Search for a pattern within a specific file"""
    import re

    matches: List[SearchHitInFilesResponse] = []
    regex = re.compile(pattern)
    with open(file_path, "r") as f:
        for i, line in enumerate(f, 1):
            if regex.search(line):
                matches.append(
                    SearchHitInFilesResponse(
                        path=file_path, line_number=i, line_content=line.strip()
                    )
                )
    return matches


class FsHelpers:
    def __init__(self, working_dir):
        self.working_dir = working_dir

    def readlines(self):
        pass

    def get_tools(self):
        return [self.readlines]


@tool
def todo_write(
    task: Task,
    tool_call_id: Annotated[str, InjectedToolCallId],
) -> Command:
    """Add a task to the overall plan for the agent"""
    print(f"adding task '{task}' to plan")
    ret = Command(
        update={
            "plan": [task],
            "thing": "bar",
            "messages": [
                ToolMessage("Successfully added task", tool_call_id=tool_call_id)
            ],
        }
    )
    print(f".  returning {ret}")
    return ret
