try:
    from ._version import __version__
except ImportError:
    try:
        from importlib.metadata import version, PackageNotFoundError

        try:
            __version__ = version("contrast-triage")
        except PackageNotFoundError:
            __version__ = "0.0.0+unknown"
    except ImportError:
        __version__ = "0.0.0+unknown"

__all__ = ["__version__"]
