# Contrast Triage

An AI-powered triage system that automatically analyzes security vulnerability findings from SARIF
files to classify them as true positives or false positives. The system uses advanced AI agents
built on LangGraph to read source code, understand business logic context, and provide detailed
justifications for each classification.

## Features

- **Automated Vulnerability Analysis**: Processes SARIF (Static Analysis Results Interchange Format) files from SAST tools
- **AI-Powered Classification**: Uses LLM agents to determine if findings are true positives or false positives
- **Contextual Understanding**: Reads and analyzes source code to understand business logic around vulnerabilities
- **Detailed Justification**: Provides reasoning and confidence levels for each classification
- **Cost Tracking**: Tracks token usage and costs across multiple LLM invocations
- **Streaming Output**: Real-time progress feedback with Rich console formatting
- **Multiple Model Support**: Works with various AWS Bedrock models (Claude, Nova, Llama, etc.)

## Prerequisites

- **Python 3.13+** (required)
- **AWS Account** with Bedrock access enabled
- **AWS Credentials** configured with appropriate permissions

## Installation

### Quick Install (Recommended)

Install directly from PyPI using `uv` (recommended) or `pipx`:

```bash
# Using uv (recommended)
uv tool install contrast-triage

# Or using pipx
pipx install contrast-triage
```

This installs the `contrast-triage` command in an isolated environment and makes it available on your PATH.

Verify the installation:

```bash
contrast-triage --version
```

### Developer Installation (From Source)

If you want to contribute or modify the code:

#### 1. Install uv

```bash
brew install uv
```

#### 2. Clone the Repository

```bash
git clone https://github.com/Contrast-Security-Inc/contrast-triage.git
cd contrast-triage
```

#### 3. Install Dependencies

```bash
# Builds the venv and a wheel dist artifact
make
```

#### 4. Run from Source

```bash
# Run commands directly from source
uv run contrast-triage --help
```

## AWS Bedrock Setup

To use a Contrast-approved LLM provider, you will need to set up your aws credentials in the env.

### 2. Configure AWS Credentials

Set up your AWS credentials using one of these methods:

#### Option A: Environment Variables (Recommended for Development)

```bash
export AWS_ACCESS_KEY_ID="your-access-key-id"
export AWS_SECRET_ACCESS_KEY="your-secret-access-key"
export AWS_DEFAULT_REGION="us-east-1"  # or your preferred region
```

#### Option B: AWS Credentials File

Create or edit `~/.aws/credentials`:

```ini
[default]
aws_access_key_id = your-access-key-id
aws_secret_access_key = your-secret-access-key
```

And `~/.aws/config`:

```ini
[default]
region = us-east-1
```

#### Option C: Environment File (.env)

Create a `.env` file in the project root:

```bash
AWS_ACCESS_KEY_ID=your-access-key-id
AWS_SECRET_ACCESS_KEY=your-secret-access-key
AWS_DEFAULT_REGION=us-east-1
```

**Note**: Never commit `.env` files to version control!

### 3. Verify AWS Access

Test your AWS Bedrock connection:

```bash
aws bedrock list-foundation-models --region us-east-1
```

## Usage

### Basic Command Structure

```bash
contrast-triage [OPTIONS] INPUT_SARIF OUTPUT_SARIF
```

### Required Arguments

- `INPUT_SARIF`: Path to the input SARIF file containing vulnerability findings
- `OUTPUT_SARIF`: Path where the modified SARIF file will be written

### Examples

See specific examples to run against here: [real examples](examples/README.md)

#### 1. Basic Usage

Analyze all findings in a SARIF file:

```bash
contrast-triage \
  findings.sarif \
  findings-triaged.sarif \
  --srcroot /path/to/source/code
```

#### 2. Analyze a Specific Finding

Process only finding at index 5:

```bash
contrast-triage \
  findings.sarif \
  findings-triaged.sarif \
  --index 5 \
  --srcroot ./src
```

#### 3. Use a Different Model

Use Claude Haiku for faster/cheaper analysis:

```bash
contrast-triage \
  --model-provider bedrock_converse \
  --model-name us.anthropic.claude-haiku-4-5-20251001-v1:0 \
  findings.sarif \
  findings-triaged.sarif
```

#### 4. Dry Run (No LLM Costs)

Test the workflow without making LLM calls:

```bash
contrast-triage \
  --dry-run \
  findings.sarif \
  findings-triaged.sarif
```

#### 5. Custom Agent Logs

Specify a custom log file location:

```bash
contrast-triage \
  findings.sarif \
  findings-triaged.sarif \
  --agent-log /tmp/my_triage_run.log
```

## Supported Models

The following AWS Bedrock models are supported with cost tracking:

### Anthropic Claude Models
- `us.anthropic.claude-sonnet-4-5-20250929-v1:0` (Default - Best balance)
- `us.anthropic.claude-sonnet-4-20250514-v1:0`
- `us.anthropic.claude-3-5-sonnet-20240620-v1:0`
- `us.anthropic.claude-haiku-4-5-20251001-v1:0` (Fastest/Cheapest)

### Amazon Nova Models
- `us.amazon.nova-premier-v1:0`
- `us.amazon.nova-pro-v1:0`
- `us.amazon.nova-lite-v1:0`
- `us.amazon.nova-micro-v1:0`

### Other Models
- `us.meta.llama3-3-70b-instruct-v1:0`
- `us.deepseek.r1-v1:0`
- `us.deepseek.v3-v1:0`
- `us.qwen.qwen3-coder-480b-a35b-v1:0`
- `us.openai.gpt-oss-120b-1:0`

## Output Format

The tool modifies the input SARIF file by adding a `contrast.triageAnalysis` property to each analyzed finding:

```json
{
  "results": [
    {
      "ruleId": "SQL_INJECTION",
      "message": { "text": "Potential SQL injection" },
      "properties": {
        "contrast.triageAnalsysis" : {
          "classification": "FALSE_POSITIVE"
        }
      }
    }
  ]
}
```

## Cost Tracking

Token usage and costs are displayed at the end of each run:

```
Token Tracker: {
  'us.anthropic.claude-sonnet-4-5-20250929-v1:0': TokenCost(
    input_tokens=15234,
    output_tokens=2341,
    input_cost=0.0502,
    output_cost=0.0386,
    total_cost=0.0888
  )
}
```

Agent logs (JSON format) are written to `triage_agent.log` (or your specified location) for detailed debugging.

## Development

### Setting Up Pre-commit Hooks

Pre-commit hooks automatically check code formatting before each commit:

```bash
# Install pre-commit (if not already installed)
make venv

# Install the git hook scripts
uv run pre-commit install

# (Optional) Run against all files to verify setup
uv run pre-commit run --all-files
```

Once installed, pre-commit will automatically run black formatting checks before each commit. If
formatting issues are found, the commit will be blocked until you fix them.

To bypass pre-commit hooks temporarily (not recommended):
```bash
git commit --no-verify -m "your message"
```

### Running Tests

#### Easy way
```bash
make test
```

#### Runing with pytest directly
```bash
# Run all tests
PYTHONPATH=src/ uv run pytest

# Run specific test file
PYTHONPATH=src/ uv run pytest tests/contrast_triage/middleware/test_tokentracker.py

# Run with verbose output
PYTHONPATH=src/ uv run pytest -v

# Run with coverage
PYTHONPATH=src/ uv run pytest --cov=contrast_triage
```

### Code Formatting

```bash
# Format all code
make format

# Check formatting without changes
uv run black --check src/ tests/
```

## Running Evals

Evals is the evaluation framework for testing the AI semantic meaning of triage justification output.
The framework in this project uses the LLM-as-a-judge approach.

The evals tests can be run via:

```bash
make run-evals
```

See [evals](evals/README.md) for more information about it.

## Releases and Versioning

This project uses automatic versioning based on git tags. Version numbers are never manually edited in the codebase.

### How It Works

- **Version source**: Git tags in the format `vX.Y.Z` (e.g., `v0.1.0`, `v1.2.3`)
- **Automatic management**: The `hatch-vcs` plugin reads the version from git tags at build time
- **No manual updates**: You never need to edit version numbers in `pyproject.toml` or code files

### Viewing the Current Version

```bash
# Check version of installed package
uv run contrast-triage --version
# Or
uv run python -c "import contrast_triage; print(contrast_triage.__version__)"
```

### Creating a Release (Maintainers Only)

Releases are created using GitHub Actions workflows. You have two options:

#### Option 1: Auto-Increment Patch Version (Recommended for Bug Fixes)

The easiest way to create a release is to let the workflow automatically bump the patch version:

1. **Navigate to GitHub Actions**:
   - Go to your repository on GitHub
   - Click on the "Actions" tab
   - Select "Create Release Tag" from the workflow list

2. **Trigger the workflow**:
   - Click "Run workflow" button
   - Leave the "Tag version" field **empty**
   - Click "Run workflow"

3. **What happens**:
   - The workflow finds the latest release tag (e.g., `v0.1.0`)
   - Automatically increments the patch version (e.g., `v0.1.1`)
   - Creates and pushes the new tag
   - Triggers the release workflow to build and publish

If no previous tags exist, the workflow will use `v0.1.0` as the initial version.

#### Option 2: Specify a Custom Version

For minor or major version updates, you can specify the exact version:

1. **Navigate to GitHub Actions**:
   - Go to your repository on GitHub
   - Click on the "Actions" tab
   - Select "Create Release Tag" from the workflow list

2. **Trigger the workflow with a version**:
   - Click "Run workflow" button
   - Enter the desired version in the "Tag version" field:
     - `v0.2.0` (with 'v' prefix)
     - `0.2.0` (without 'v' prefix - will be added automatically)
   - Click "Run workflow"

3. **Version format must follow semantic versioning**:
   - **Patch release** (bug fixes): `v0.1.0` → `v0.1.1`
   - **Minor release** (new features): `v0.1.1` → `v0.2.0`
   - **Major release** (breaking changes): `v0.2.0` → `v1.0.0`

#### What Happens After Tag Creation

Once the tag is created, the automated release process:
1. Triggers the release workflow automatically
2. Builds the package with `hatch-vcs` (version is read from the git tag)
3. Creates a GitHub Release with auto-generated release notes
4. Attaches distribution files (wheel and source tarball)
5. Makes the release available on GitHub

#### Manual Tag Creation (Advanced)

If you prefer to create tags manually via command line:

```bash
# Create an annotated tag
git tag -a v0.2.0 -m "Release v0.2.0

New features:
- Feature A
- Feature B

Bug fixes:
- Fix for issue #123
"

# Push the tag to trigger the release workflow
git push origin v0.2.0
```

**Note**: Version numbers are automatically managed by git tags. Never manually edit version numbers in the code.

## Troubleshooting

### "No findings found in SARIF file"

Ensure your SARIF file contains at least one run with results:
```bash
# Validate SARIF structure
python -c "import json; print(json.load(open('findings.sarif'))['runs'][0]['results'])"
```

### AWS Credentials Not Found

```bash
# Verify credentials are set
aws sts get-caller-identity

# Check environment variables
echo $AWS_ACCESS_KEY_ID
echo $AWS_DEFAULT_REGION
```

### Python Version Issues

```bash
# Check Python version
python --version  # Should be 3.13+

# Use pyenv to manage Python versions
pyenv install 3.13
pyenv local 3.13
```

### High Costs

To reduce LLM costs:
- Use `--dry-run` for testing
- Use cheaper models like Claude Haiku or Nova Lite
- Process specific findings with `--index` instead of all at once
- Test on a small SARIF file first

## Contributing

1. Create a feature branch
2. Make your changes
3. Run tests: `uv run pytest`
4. Format code: `uv run black src/ tests/`
5. Submit a pull request

**Note**: Version numbers are automatically managed by git tags. Never manually edit version numbers in the code.

## License

[Add your license information here]
