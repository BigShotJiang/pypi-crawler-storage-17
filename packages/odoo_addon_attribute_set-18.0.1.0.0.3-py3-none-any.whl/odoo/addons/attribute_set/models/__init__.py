from . import attribute_attribute
from . import attribute_option
from . import attribute_set
from . import attribute_set_owner
from . import attribute_group
from . import many2one_override
