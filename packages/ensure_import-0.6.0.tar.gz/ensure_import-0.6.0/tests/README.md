## How to test:

- test peotry project
```bash
cd test_in_poetry
./test_in_poetry.py
./test_in_poetry.py
```

- test venv project
```bash
cd test_venv/test_venv
./test_venv.py
```
