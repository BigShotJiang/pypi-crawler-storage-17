=======
History
=======




Release: 1.1.1 (2025-12-17)

------------------

Patch:

* Fixed typo
* Improved help text

_______________________________

Release: 1.1.0 (2025-12-16)

------------------

New Features:

* Add an ``MNM_ID`` column to MAF files.
* Create the ``MNM_mafs`` directory, where MAF files are rewritten and each metabolite row is assigned a unique identifier.
* Add the community-mode column ``Match IDS in metabolic networks``.


_______________________________

Release: 1.0.2 (2025-11-23)

------------------

* First release on PyPI.
