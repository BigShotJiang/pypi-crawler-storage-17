# main.py
from alvoc.cli import cli

# Allow programmatic usage
if __name__ == "__main__":
    cli(prog_name="alvoc")
