__all__ = ["find_lineages"]

from alvoc.core.variants.lineages.main import find_lineages
