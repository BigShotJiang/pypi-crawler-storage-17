---
hide:
  - navigation
---

# Changelog

--8<-- "CHANGELOG.md"