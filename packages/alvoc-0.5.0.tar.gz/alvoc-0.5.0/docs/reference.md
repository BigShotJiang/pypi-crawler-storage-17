---
hide:
  - navigation
---

# CLI Reference

---

::: mkdocs-click
    :module: alvoc.cli
    :command: click_cli
    :prog_name: alvoc
    :list_subcommands: True
    :style: table
    :depth: 1

