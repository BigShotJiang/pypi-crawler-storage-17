Usage
===========

.. toctree::
   :titlesonly:
   :hidden:
   :maxdepth: 2

   notebooks/measurements.ipynb
   notebooks/waterinfo.ipynb
   minimal_example.rst
