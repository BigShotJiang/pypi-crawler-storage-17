# API reference

```{eval-rst}
.. autofunction:: streamlitrunner.run
```
