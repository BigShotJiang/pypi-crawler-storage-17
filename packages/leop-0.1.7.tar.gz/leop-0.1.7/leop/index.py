def README():
    print("欢迎使用林鼎博制作的库！")