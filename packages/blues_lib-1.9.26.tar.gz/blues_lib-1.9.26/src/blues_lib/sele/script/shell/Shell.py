from .Process import Process

# 混入更多行为模块
class Shell(Process):
  pass