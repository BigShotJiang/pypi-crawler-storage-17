## Code generation

* Always use the context7 MCP service before generating code

## Tooling

* Use `uv` to handle python dependencies

