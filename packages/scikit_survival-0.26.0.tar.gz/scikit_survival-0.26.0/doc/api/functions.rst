Functions
=========
.. currentmodule:: sksurv.functions

.. autosummary::
    :toctree: generated/

    StepFunction
