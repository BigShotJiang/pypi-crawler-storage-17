.. _mod-svm:

Survival Support Vector Machine
===============================
.. currentmodule:: sksurv.svm

.. autosummary::
    :toctree: generated/

    HingeLossSurvivalSVM
    FastKernelSurvivalSVM
    FastSurvivalSVM
    MinlipSurvivalAnalysis
    NaiveSurvivalSVM
