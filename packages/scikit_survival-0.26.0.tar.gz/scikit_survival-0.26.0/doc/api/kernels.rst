Kernels
=======
.. currentmodule:: sksurv.kernels

.. autosummary::
    :toctree: generated/

    ClinicalKernelTransform
    clinical_kernel
