Hypothesis testing
==================
.. currentmodule:: sksurv.compare

.. autosummary::
    :toctree: generated/

    compare_survival
