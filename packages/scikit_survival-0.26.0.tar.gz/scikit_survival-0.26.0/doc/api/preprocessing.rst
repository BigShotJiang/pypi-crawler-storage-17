Pre-Processing
==============
.. currentmodule:: sksurv.preprocessing

.. autosummary::
    :toctree: generated/

    OneHotEncoder

.. currentmodule:: sksurv.column

.. autosummary::
    :toctree: generated/

    categorical_to_numeric
    encode_categorical
    standardize
