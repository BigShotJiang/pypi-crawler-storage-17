Datasets
========
.. currentmodule:: sksurv.datasets

.. autosummary::
    :toctree: generated/

    get_x_y
    load_aids
    load_arff_files_standardized
    load_bmt
    load_cgvhd
    load_breast_cancer
    load_flchain
    load_gbsg2
    load_whas500
    load_veterans_lung_cancer
