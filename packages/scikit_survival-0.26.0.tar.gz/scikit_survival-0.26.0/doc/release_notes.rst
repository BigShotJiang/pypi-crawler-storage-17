Release Notes
=============

.. toctree::
  :maxdepth: 2

  release_notes/v0.26
  release_notes/v0.25
  release_notes/v0.24
  release_notes/v0.23
  release_notes/v0.22
  release_notes/v0.21
  release_notes/v0.20
  release_notes/v0.19
  release_notes/v0.18
  release_notes/v0.17
  release_notes/v0.16
  release_notes/v0.15
  release_notes/v0.14
  release_notes/v0.13
  release_notes/v0.12
  release_notes/v0.11
  release_notes/v0.10
  release_notes/v0.9
  release_notes/v0.8
  release_notes/v0.7
  release_notes/v0.6
  release_notes/v0.5
  release_notes/v0.4
  release_notes/v0.3
  release_notes/v0.2
  release_notes/v0.1
