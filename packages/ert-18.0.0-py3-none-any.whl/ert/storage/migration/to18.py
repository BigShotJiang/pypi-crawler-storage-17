from pathlib import Path

info = (
    "Added localization attributes to summary observations."
    "Added RFT observations."
    "No change to current storage, only additions. "
    "Bumping to 17 to indicate appended schema in storage."
)


def migrate(path: Path) -> None:
    pass
