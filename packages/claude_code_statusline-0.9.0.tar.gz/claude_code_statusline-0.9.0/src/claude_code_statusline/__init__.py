"""Claude Code Statusline - Context usage tracking for Claude Code."""

from importlib.metadata import version

__version__ = version("claude-code-statusline")
__all__ = ["__version__"]
