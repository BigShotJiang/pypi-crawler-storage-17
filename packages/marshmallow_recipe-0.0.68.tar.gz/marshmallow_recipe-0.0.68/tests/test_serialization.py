import dataclasses
import datetime
import decimal
import enum
import uuid
from collections.abc import Callable, Iterable, Mapping
from contextlib import nullcontext as does_not_raise
from typing import Annotated, Any, ContextManager, NewType, get_origin

import pytest

import marshmallow_recipe as mr

NewInt = NewType("NewInt", int)


class Parity(str, enum.Enum):
    ODD = "odd"
    EVEN = "even"


class Bit(int, enum.Enum):
    Zero = 0
    One = 1


def test_simple_types() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class SimpleTypesContainers:
        any_field: Any
        annotated_any_field: Annotated[Any, 0]
        str_field: str
        optional_str_field: str | None
        bool_field: bool
        optional_bool_field: bool | None
        decimal_field: decimal.Decimal
        optional_decimal_field: decimal.Decimal | None
        int_field: int
        optional_int_field: int | None
        new_int_field: NewInt
        optional_new_int_field: NewInt | None
        float_field: float
        optional_float_field: float | None
        uuid_field: uuid.UUID
        optional_uuid_field: uuid.UUID | None
        datetime_field: datetime.datetime
        optional_datetime_field: datetime.datetime | None
        time_field: datetime.time
        optional_time_field: datetime.time | None
        date_field: datetime.date
        optional_date_field: datetime.date | None
        dict_field: dict[str, Any]
        optional_dict_field: dict[str, Any] | None
        custom_dict_field: dict[datetime.date, int]
        optional_custom_dict_field: dict[datetime.date, int] | None
        list_field: list[str]
        optional_list_field: list[str] | None
        set_field: set[str]
        optional_set_field: set[str] | None
        frozenset_field: frozenset[str]
        optional_frozenset_field: frozenset[str] | None
        tuple_field: tuple[str, ...]
        optional_tuple_field: tuple[str, ...] | None
        enum_str_field: Parity
        optional_enum_str_field: Parity | None
        enum_int_field: Bit
        optional_enum_int_field: Bit | None
        str_int_union: int | str
        optional_str_int_union: int | str | None
        # with default
        str_field_with_default: str = "42"
        bool_field_with_default: bool = True
        decimal_field_with_default: decimal.Decimal = decimal.Decimal("42")
        int_field_with_default: int = 42
        float_field_with_default: float = 42.0
        uuid_field_with_default: uuid.UUID = uuid.UUID("15f75b02-1c34-46a2-92a5-18363aadea05")
        datetime_field_with_default: datetime.datetime = datetime.datetime(
            2022, 2, 20, 11, 33, 48, 607289, datetime.UTC
        )
        time_field_with_default: datetime.time = datetime.time(11, 33, 48)
        date_field_with_default: datetime.date = datetime.date(2022, 2, 20)
        enum_str_field_with_default: Parity = Parity.ODD
        enum_int_field_with_default: Bit = Bit.Zero
        str_int_union_with_default: int | str = 42
        # with default factory
        str_field_with_default_factory: str = dataclasses.field(default_factory=lambda: "42")
        bool_field_with_default_factory: bool = dataclasses.field(default_factory=lambda: True)
        decimal_field_with_default_factory: decimal.Decimal = dataclasses.field(
            default_factory=lambda: decimal.Decimal("42")
        )
        int_field_with_default_factory: float = dataclasses.field(default_factory=lambda: 42)
        float_field_with_default_factory: float = dataclasses.field(default_factory=lambda: 42.0)
        uuid_field_with_default_factory: uuid.UUID = dataclasses.field(
            default_factory=lambda: uuid.UUID("15f75b02-1c34-46a2-92a5-18363aadea05")
        )
        datetime_field_with_default_factory: datetime.datetime = dataclasses.field(
            default_factory=lambda: datetime.datetime(2022, 2, 20, 11, 33, 48, 607289, datetime.UTC)
        )
        time_field_with_default_factory: datetime.time = dataclasses.field(
            default_factory=lambda: datetime.time(11, 33, 48)
        )
        date_field_with_default_factory: datetime.date = dataclasses.field(
            default_factory=lambda: datetime.date(2022, 2, 20)
        )
        dict_field_with_default_factory: dict[str, Any] = dataclasses.field(default_factory=lambda: {})
        custom_dict_field_with_default_factory: dict[datetime.date, int] = dataclasses.field(default_factory=lambda: {})
        list_field_with_default_factory: list[str] = dataclasses.field(default_factory=lambda: [])
        set_field_with_default_factory: set[str] = dataclasses.field(default_factory=lambda: set())
        frozenset_field_with_default_factory: frozenset[str] = dataclasses.field(default_factory=lambda: frozenset())
        tuple_field_with_default_factory: tuple[str, ...] = dataclasses.field(default_factory=lambda: ())
        enum_str_field_with_default_factory: Parity = dataclasses.field(default_factory=lambda: Parity.ODD)
        enum_int_field_with_default_factory: Bit = dataclasses.field(default_factory=lambda: Bit.Zero)
        str_int_union_with_default_factory: int | str = dataclasses.field(default_factory=lambda: 42)

    raw = {
        "any_field": {},
        "annotated_any_field": {},
        "str_field": "42",
        "str_field_with_default": "42",
        "str_field_with_default_factory": "42",
        "optional_str_field": "42",
        "bool_field": True,
        "bool_field_with_default": True,
        "bool_field_with_default_factory": True,
        "optional_bool_field": True,
        "decimal_field": "42.00",
        "decimal_field_with_default": "42.00",
        "decimal_field_with_default_factory": "42.00",
        "optional_decimal_field": "42.00",
        "int_field": 42,
        "int_field_with_default": 42,
        "int_field_with_default_factory": 42,
        "optional_int_field": 42,
        "new_int_field": 42,
        "optional_new_int_field": 42,
        "float_field": 42.0,
        "float_field_with_default": 42.0,
        "float_field_with_default_factory": 42.0,
        "optional_float_field": 42.0,
        "uuid_field": "15f75b02-1c34-46a2-92a5-18363aadea05",
        "uuid_field_with_default": "15f75b02-1c34-46a2-92a5-18363aadea05",
        "uuid_field_with_default_factory": "15f75b02-1c34-46a2-92a5-18363aadea05",
        "optional_uuid_field": "15f75b02-1c34-46a2-92a5-18363aadea05",
        "datetime_field": "2022-02-20T11:33:48+00:00",
        "datetime_field_with_default": "2022-02-20T11:33:48.607289+00:00",
        "datetime_field_with_default_factory": "2022-02-20T11:33:48.607289+00:00",
        "optional_datetime_field": "2022-02-20T11:33:48.607289+00:00",
        "time_field": "11:33:48.607289",
        "time_field_with_default": "11:33:48",
        "time_field_with_default_factory": "11:33:48",
        "optional_time_field": "11:33:48",
        "date_field": "2022-02-20",
        "date_field_with_default": "2022-02-20",
        "date_field_with_default_factory": "2022-02-20",
        "optional_date_field": "2022-02-20",
        "dict_field": {"key": "value"},
        "dict_field_with_default_factory": {},
        "optional_dict_field": {"key": "value"},
        "custom_dict_field": {"2020-01-01": 42},
        "custom_dict_field_with_default_factory": {},
        "optional_custom_dict_field": {"2020-01-01": 42},
        "list_field": ["value"],
        "list_field_with_default_factory": [],
        "optional_list_field": ["value"],
        "set_field": ["value"],
        "set_field_with_default_factory": [],
        "str_int_union": 42,
        "optional_str_int_union": 42,
        "str_int_union_with_default": 42,
        "str_int_union_with_default_factory": 42,
        "optional_set_field": ["value"],
        "tuple_field": ["value"],
        "tuple_field_with_default_factory": [],
        "optional_tuple_field": ["value"],
        "frozenset_field": ["value"],
        "frozenset_field_with_default_factory": [],
        "optional_frozenset_field": ["value"],
        "enum_str_field": "odd",
        "enum_str_field_with_default": "odd",
        "enum_str_field_with_default_factory": "odd",
        "optional_enum_str_field": "even",
        "enum_int_field": 0,
        "enum_int_field_with_default": 0,
        "enum_int_field_with_default_factory": 0,
        "optional_enum_int_field": 1,
    }

    raw_no_defaults = {k: v for k, v in raw.items() if not k.endswith("default") and not k.endswith("default_factory")}

    loaded = mr.load(SimpleTypesContainers, raw)
    loaded_no_defaults = mr.load(SimpleTypesContainers, raw_no_defaults)
    dumped = mr.dump(loaded)

    assert (
        loaded_no_defaults
        == loaded
        == SimpleTypesContainers(
            any_field={},
            annotated_any_field={},
            str_field="42",
            optional_str_field="42",
            bool_field=True,
            optional_bool_field=True,
            decimal_field=decimal.Decimal("42.00"),
            optional_decimal_field=decimal.Decimal("42.00"),
            int_field=42,
            optional_int_field=42,
            new_int_field=NewInt(42),
            optional_new_int_field=NewInt(42),
            float_field=42.0,
            optional_float_field=42.0,
            uuid_field=uuid.UUID("15f75b02-1c34-46a2-92a5-18363aadea05"),
            optional_uuid_field=uuid.UUID("15f75b02-1c34-46a2-92a5-18363aadea05"),
            datetime_field=datetime.datetime(2022, 2, 20, 11, 33, 48, 0, datetime.UTC),
            optional_datetime_field=datetime.datetime(2022, 2, 20, 11, 33, 48, 607289, datetime.UTC),
            time_field=datetime.time(11, 33, 48, 607289),
            optional_time_field=datetime.time(11, 33, 48),
            date_field=datetime.date(2022, 2, 20),
            optional_date_field=datetime.date(2022, 2, 20),
            dict_field={"key": "value"},
            optional_dict_field={"key": "value"},
            custom_dict_field={datetime.date(2020, 1, 1): 42},
            optional_custom_dict_field={datetime.date(2020, 1, 1): 42},
            list_field=["value"],
            optional_list_field=["value"],
            set_field={"value"},
            optional_set_field={"value"},
            frozenset_field=frozenset({"value"}),
            optional_frozenset_field=frozenset({"value"}),
            tuple_field=("value",),
            optional_tuple_field=("value",),
            enum_str_field=Parity.ODD,
            optional_enum_str_field=Parity.EVEN,
            enum_int_field=Bit.Zero,
            optional_enum_int_field=Bit.One,
            str_int_union=42,
            optional_str_int_union=42,
            str_int_union_with_default=42,
            str_int_union_with_default_factory=42,
        )
    )

    assert dumped == raw
    assert mr.schema(SimpleTypesContainers) is mr.schema(SimpleTypesContainers)


def test_nested_dataclass() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class BoolContainer:
        bool_field: bool

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Container:
        bool_container_field: BoolContainer
        bool_container_field_with_default: BoolContainer = BoolContainer(bool_field=True)
        bool_container_field_with_default_factory: BoolContainer = dataclasses.field(
            default_factory=lambda: BoolContainer(bool_field=True)
        )

    raw = {
        "bool_container_field": {"bool_field": True},
        "bool_container_field_with_default": {"bool_field": True},
        "bool_container_field_with_default_factory": {"bool_field": True},
    }
    raw_no_defaults = {k: v for k, v in raw.items() if not k.endswith("default") or not k.endswith("default_factory")}

    loaded = mr.load(Container, raw)
    loaded_no_defaults = mr.load(Container, raw_no_defaults)
    dumped = mr.dump(loaded)

    assert loaded_no_defaults == loaded == Container(bool_container_field=BoolContainer(bool_field=True))
    assert dumped == raw

    assert mr.schema(Container) is mr.schema(Container)


def test_custom_name_bool() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class BoolContainer:
        bool_field: bool = dataclasses.field(metadata=mr.meta(name="BoolField"))

    raw = {"BoolField": False}

    loaded = mr.load(BoolContainer, raw)
    dumped = mr.dump(loaded)

    assert loaded == BoolContainer(bool_field=False)
    assert dumped == raw

    assert mr.schema(BoolContainer) is mr.schema(BoolContainer)


def test_custom_name_uuid() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class UuidContainer:
        uuid_field: uuid.UUID = dataclasses.field(metadata=mr.meta(name="UuidField"))

    raw = {"UuidField": "15f75b02-1c34-46a2-92a5-18363aadea05"}

    loaded = mr.load(UuidContainer, raw)
    dumped = mr.dump(loaded)

    assert loaded == UuidContainer(uuid_field=uuid.UUID("15f75b02-1c34-46a2-92a5-18363aadea05"))
    assert dumped == raw

    assert mr.schema(UuidContainer) is mr.schema(UuidContainer)


def test_none() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class BoolContainer:
        bool_field: bool | None = None

    raw: dict[str, Any] = {}

    loaded = mr.load(BoolContainer, raw)
    dumped = mr.dump(loaded)

    assert loaded == BoolContainer(bool_field=None)
    assert dumped == raw

    assert mr.schema(BoolContainer) is mr.schema(BoolContainer)


def test_unknown_field() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class BoolContainer:
        bool_field: bool

    loaded = mr.load(BoolContainer, {"bool_field": True, "int_field": 42})
    dumped = mr.dump(loaded)

    assert loaded == BoolContainer(bool_field=True)
    assert dumped == {"bool_field": True}

    assert mr.schema(BoolContainer) is mr.schema(BoolContainer)


def test_schema_with_default_case() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class DataClass:
        str_field: str

    origin = {"str_field": "foobar"}
    loaded = mr.load(DataClass, origin)
    dumped = mr.dump(loaded)

    assert loaded == DataClass(str_field="foobar")
    assert dumped == origin


def test_schema_with_capital_camel_case() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class DataClass:
        str_field: str

    origin = {"StrField": "foobar"}
    loaded = mr.load(DataClass, origin, naming_case=mr.CAPITAL_CAMEL_CASE)
    dumped = mr.dump(loaded, naming_case=mr.CAPITAL_CAMEL_CASE)

    assert loaded == DataClass(str_field="foobar")
    assert dumped == origin


def test_schema_with_camel_case() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class DataClass:
        str_field: str

    origin = {"strField": "foobar"}
    loaded = mr.load(DataClass, origin, naming_case=mr.CAMEL_CASE)
    dumped = mr.dump(loaded, naming_case=mr.CAMEL_CASE)

    assert loaded == DataClass(str_field="foobar")
    assert dumped == origin


def test_many() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class BoolContainer:
        bool_field: bool

    loaded = mr.load_many(BoolContainer, [{"bool_field": True}, {"bool_field": False}])
    dumped = mr.dump_many(loaded)

    assert loaded == [BoolContainer(bool_field=True), BoolContainer(bool_field=False)]
    assert dumped == [{"bool_field": True}, {"bool_field": False}]

    assert mr.schema(BoolContainer) is mr.schema(BoolContainer)


def test_many_empty() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class BoolContainer:
        bool_field: bool

    loaded = mr.load_many(BoolContainer, [])
    dumped = mr.dump_many(loaded)

    assert loaded == []
    assert dumped == []

    assert mr.schema(BoolContainer) is mr.schema(BoolContainer)


@pytest.mark.parametrize(
    "raw, dt",
    [
        ("2022-02-20T11:33:48.607289+00:00", datetime.datetime(2022, 2, 20, 11, 33, 48, 607289, datetime.UTC)),
        ("2022-02-20T11:33:48.607289", datetime.datetime(2022, 2, 20, 11, 33, 48, 607289, datetime.UTC)),
        ("2022-02-20T11:33:48", datetime.datetime(2022, 2, 20, 11, 33, 48, 0, datetime.UTC)),
        ("2022-02-20T11:33:48.607289Z", datetime.datetime(2022, 2, 20, 11, 33, 48, 607289, datetime.UTC)),
        ("2022-02-20T11:33:48Z", datetime.datetime(2022, 2, 20, 11, 33, 48, 0, datetime.UTC)),
        ("2022-02-20", datetime.datetime(2022, 2, 20, 0, 0, 0, 0, datetime.UTC)),
    ],
)
def test_datetime_field_load(raw: str, dt: datetime.datetime) -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class DateTimeContainer:
        datetime_field: datetime.datetime

    loaded = mr.load(DateTimeContainer, {"datetime_field": raw})
    assert loaded == DateTimeContainer(datetime_field=dt)


@pytest.mark.parametrize(
    "dt, raw",
    [
        (datetime.datetime(2022, 2, 20, 11, 33, 48, 607289, datetime.UTC), "2022-02-20T11:33:48.607289+00:00"),
        (datetime.datetime(2022, 2, 20, 11, 33, 48, 0, datetime.UTC), "2022-02-20T11:33:48+00:00"),
        (datetime.datetime(2022, 2, 20, 11, 33, 48, 607289, None), "2022-02-20T11:33:48.607289+00:00"),
        (datetime.datetime(2022, 2, 20, 11, 33, 48, 0, None), "2022-02-20T11:33:48+00:00"),
        (datetime.datetime(2022, 2, 20, 0, 0, 0, 0, None), "2022-02-20T00:00:00+00:00"),
    ],
)
def test_datetime_field_dump(dt: datetime.datetime, raw: str) -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class DateTimeContainer:
        datetime_field: datetime.datetime

    dumped = mr.dump(DateTimeContainer(datetime_field=dt))
    assert dumped == {"datetime_field": raw}


@pytest.mark.parametrize("value, raw", [(Parity.ODD, "odd"), (Parity.EVEN, "even")])
def test_enum_str_field_dump(value: Parity, raw: str) -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class EnumContainer:
        enum_field: Parity

    dumped = mr.dump(EnumContainer(enum_field=value))
    assert dumped == {"enum_field": raw}


@pytest.mark.parametrize("raw, value", [("odd", Parity.ODD), ("even", Parity.EVEN)])
def test_enum_str_field_load(value: Parity, raw: str) -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class EnumContainer:
        enum_field: Parity

    dumped = mr.load(EnumContainer, {"enum_field": raw})
    assert dumped == EnumContainer(enum_field=value)


@pytest.mark.parametrize("value, raw", [(Bit.Zero, 0), (Bit.One, 1)])
def test_enum_int_field_dump(value: Bit, raw: str) -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class EnumContainer:
        enum_field: Bit

    dumped = mr.dump(EnumContainer(enum_field=value))
    assert dumped == {"enum_field": raw}


@pytest.mark.parametrize("raw, value", [(0, Bit.Zero), (1, Bit.One)])
def test_enum_int_field_load(value: Bit, raw: str) -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class EnumContainer:
        enum_field: Bit

    dumped = mr.load(EnumContainer, {"enum_field": raw})
    assert dumped == EnumContainer(enum_field=value)


def test_naming_case_in_options() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    @mr.options(naming_case=mr.CAMEL_CASE)
    class TestFieldContainer:
        test_field: str

    dumped = mr.dump(TestFieldContainer(test_field="some_value"))
    assert dumped == {"testField": "some_value"}


def test_naming_case_in_options_should_not_affect_field_schemas() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Container:
        value: str

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    @mr.options(naming_case=mr.CAPITAL_CAMEL_CASE)
    class ContainerContainer:
        value: Container

    dumped = mr.dump(ContainerContainer(value=Container(value="some_value")))
    assert dumped == {"Value": {"value": "some_value"}}


def test_dict_with_complex_value() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class IdContainer:
        id: uuid.UUID

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Container:
        values: dict[str, IdContainer]

    id = uuid.uuid4()

    container = Container(values={"key": IdContainer(id=id)})

    dumped = mr.dump(container)
    assert dumped == {"values": {"key": {"id": str(id)}}}

    assert container == mr.load(Container, dumped)


def test_bake_schema_should_reuse_already_generated_schemas() -> None:
    schema_cache = getattr(getattr(mr, "bake"), "_schema_types")

    schema_cache.clear()

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Holder:
        value: int

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class HolderHolder:
        holder: Holder

    mr.bake_schema(HolderHolder)
    mr.bake_schema(Holder)

    assert len(schema_cache) == 2


@pytest.mark.parametrize("naming_case", [mr.CAMEL_CASE, None])
@pytest.mark.parametrize("none_value_handling", [mr.NoneValueHandling.INCLUDE, None])
def test_bake_schema_should_generate_schemas_per_parameters(
    naming_case: mr.NamingCase | None, none_value_handling: mr.NoneValueHandling | None
) -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Holder:
        value: int

    default_schema = mr.bake_schema(Holder)
    parametrised_schema = mr.bake_schema(Holder, naming_case=naming_case, none_value_handling=none_value_handling)

    if naming_case is None and none_value_handling is None:
        assert default_schema is parametrised_schema
    else:
        assert default_schema is not parametrised_schema


def test_legacy_collection_typings() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Container:
        list_field: list[int]
        dict_field: dict[str, Any]
        set_field: set[str]
        frozenset_field: frozenset[str]
        tuple_field: tuple[str, ...]

    assert mr.schema(Container)


def test_str_strip_whitespaces() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class StrContainer:
        value: Annotated[str, mr.str_meta(strip_whitespaces=True)]

    assert StrContainer(value="some_value") == mr.load(StrContainer, {"value": " some_value "})
    assert mr.dump(StrContainer(value=" some_value ")) == {"value": "some_value"}

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class OptionalStrContainer:
        value1: Annotated[str | None, mr.str_meta(strip_whitespaces=True)]
        value2: Annotated[str | None, mr.str_meta(strip_whitespaces=False)]

    assert OptionalStrContainer(value1=None, value2="") == mr.load(OptionalStrContainer, {"value1": "", "value2": ""})
    assert OptionalStrContainer(value1=None, value2=None) == mr.load(
        OptionalStrContainer, {"value1": None, "value2": None}
    )
    assert mr.dump(OptionalStrContainer(value1="", value2="")) == {"value2": ""}
    assert mr.dump(OptionalStrContainer(value1=None, value2=None)) == {}


def test_str_strip_whitespace_with_validation() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class StrContainer:
        value: Annotated[str | None, mr.str_meta(strip_whitespaces=True, validate=lambda x: len(x) > 0)]

    mr.load(StrContainer, {"value": ""})


def test_list_str_strip_whitespaces() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class StrContainer:
        value1: list[Annotated[str, mr.str_meta(strip_whitespaces=True)]]
        value2: list[Annotated[str, mr.str_meta(strip_whitespaces=True)]] | None

    assert StrContainer(value1=["some_value"], value2=None) == mr.load(StrContainer, {"value1": [" some_value "]})
    assert mr.dump(StrContainer(value1=[" some_value "], value2=None)) == {"value1": ["some_value"]}


def test_str_post_load() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class StrContainer:
        value1: Annotated[str, mr.str_meta(post_load=lambda x: x.replace("-", ""))]
        value2: Annotated[str | None, mr.str_meta(post_load=lambda x: x.replace("-", ""))]

    assert StrContainer(value1="111111", value2=None) == mr.load(StrContainer, {"value1": "11-11-11"})
    assert mr.dump(StrContainer(value1="11-11-11", value2=None)) == {"value1": "11-11-11"}


def test_nested_default() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class IntContainer:
        value: int = 42

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class RootContainer:
        int_container: IntContainer = dataclasses.field(default_factory=IntContainer)

    assert mr.load(RootContainer, {}) == RootContainer()


@pytest.mark.parametrize(
    "frozen, slots, get_type, context",
    [
        (False, False, lambda x: None, does_not_raise()),
        (False, False, lambda x: int, pytest.raises(ValueError, match="<class 'int'> is invalid but can be removed")),
        (True, False, lambda x: None, pytest.raises(ValueError, match="Explicit cls required for unsubscripted type")),
        (False, True, lambda x: None, pytest.raises(ValueError, match="Explicit cls required for unsubscripted type")),
        (True, True, lambda x: None, pytest.raises(ValueError, match="Explicit cls required for unsubscripted type")),
        (True, True, lambda x: get_origin(x), pytest.raises(ValueError, match=".Data'> is not subscripted version of")),
        (True, True, lambda x: list[int], pytest.raises(ValueError, match="int] is not subscripted version of")),
        (True, True, lambda x: int, pytest.raises(ValueError, match="<class 'int'> is not subscripted version of")),
        (True, True, lambda x: x, does_not_raise()),
    ],
)
def test_generic_extract_type_on_dump(
    frozen: bool, slots: bool, get_type: Callable[[type], type | None], context: ContextManager
) -> None:
    @dataclasses.dataclass(frozen=frozen, slots=slots)
    class Data[TValue]:
        value: TValue

    instance = Data[int](value=123)
    with context:
        type = get_type(Data[int])
        dumped = mr.dump(instance) if type is None else mr.dump(type, instance)
        assert dumped == {"value": 123}

    instance_many = [Data[int](value=123), Data[int](value=456)]
    with context:
        type = get_type(Data[int])
        dumped = mr.dump_many(instance_many) if type is None else mr.dump_many(type, instance_many)
        assert dumped == [{"value": 123}, {"value": 456}]


@pytest.mark.parametrize(
    "frozen, slots, get_type, context",
    [
        (False, False, lambda x: None, does_not_raise()),
        (False, True, lambda x: x, does_not_raise()),
        (True, False, lambda x: x, does_not_raise()),
        (True, True, lambda x: x, does_not_raise()),
        (False, False, lambda x: int, pytest.raises(ValueError, match="<class 'int'> is invalid but can be removed")),
        (True, True, lambda x: int, pytest.raises(ValueError, match="<class 'int'> is invalid but can be removed")),
    ],
)
def test_non_generic_extract_type_on_dump(
    frozen: bool, slots: bool, get_type: Callable[[type], type | None], context: ContextManager
) -> None:
    @dataclasses.dataclass(frozen=frozen, slots=slots)
    class Data:
        value: int

    instance = Data(value=123)
    with context:
        type = get_type(Data)
        dumped = mr.dump(instance) if type is None else mr.dump(type, instance)
        assert dumped == {"value": 123}

    instance_many = [Data(value=123), Data(value=456)]
    with context:
        type = get_type(Data)
        dumped = mr.dump_many(instance_many) if type is None else mr.dump_many(type, instance_many)
        assert dumped == [{"value": 123}, {"value": 456}]


def test_generic_in_parents() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Data[TXxx]:
        xxx: TXxx

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class ParentClass[TData]:
        value: str
        data: TData

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class ChildClass(ParentClass[Data[int]]):
        pass

    instance = ChildClass(value="vvv", data=Data(xxx=111))
    dumped = mr.dump(instance)

    assert dumped == {"value": "vvv", "data": {"xxx": 111}}
    assert mr.load(ChildClass, dumped) == instance


def test_generic_type_var_with_reuse() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class T1[T]:
        t1: T

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class T2[T](T1[int]):
        t2: T

    instance = T2[str](t1=1, t2="2")

    dumped = mr.dump(T2[str], instance)

    assert dumped == {"t1": 1, "t2": "2"}
    assert mr.load(T2[str], dumped) == instance


def test_generic_with_field_override() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Value1:
        v1: str

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Value2(Value1):
        v2: str

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class T1[TItem]:
        value: Value1
        iterable: Iterable[TItem]

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class T2[TValue: Value1, TItem](T1[TItem]):
        value: TValue
        iterable: set[TItem]

    instance = T2[Value2, int](value=Value2(v1="aaa", v2="bbb"), iterable={3, 4, 5})

    dumped = mr.dump(T2[Value2, int], instance)

    assert dumped == {"value": {"v1": "aaa", "v2": "bbb"}, "iterable": [3, 4, 5]}
    assert mr.load(T2[Value2, int], dumped) == instance


def test_generic_reuse_with_different_args() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class GenericContainer[TItem]:
        items: list[TItem]

    container_int = GenericContainer[int](items=[1, 2, 3])
    dumped = mr.dump(GenericContainer[int], container_int)

    assert dumped == {"items": [1, 2, 3]}
    assert mr.load(GenericContainer[int], dumped) == container_int

    container_str = GenericContainer[str](items=["q", "w", "e"])
    dumped = mr.dump(GenericContainer[str], container_str)

    assert dumped == {"items": ["q", "w", "e"]}
    assert mr.load(GenericContainer[str], dumped) == container_str


def test_unsubscripted_collections() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Collections:
        l: list
        s: set
        fs: frozenset
        d: dict
        m: Mapping
        t: tuple

    dumped = mr.dump(
        Collections(
            l=["str", 123, {"a": "s"}],
            s={"se", 55},
            fs=frozenset(["fs", 77]),
            d={1: 2, "dd": "va"},
            m={3: 4, "mm": "va"},
            t=(99, "xx"),
        )
    )

    assert dumped == {
        "l": ["str", 123, {"a": "s"}],
        "s": list({"se", 55}),
        "fs": list(frozenset(["fs", 77])),
        "d": {1: 2, "dd": "va"},
        "m": {3: 4, "mm": "va"},
        "t": [99, "xx"],
    }


def test_union_priority_int_str() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class ContainerIntStr:
        value: int | str

    instance = ContainerIntStr(value=123)
    dumped = mr.dump(ContainerIntStr, instance)

    assert dumped == {"value": 123}
    assert mr.load(ContainerIntStr, dumped) == ContainerIntStr(value=123)

    instance = ContainerIntStr(value="123")
    dumped = mr.dump(ContainerIntStr, instance)

    assert dumped == {"value": "123"}
    assert mr.load(ContainerIntStr, dumped) == ContainerIntStr(value=123)

    instance = ContainerIntStr(value="abc")
    dumped = mr.dump(ContainerIntStr, instance)
    assert dumped == {"value": "abc"}
    assert mr.load(ContainerIntStr, dumped) == ContainerIntStr(value="abc")


def test_union_priority_str_int() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class ContainerStrInt:
        value: str | int

    instance = ContainerStrInt(value=123)
    dumped = mr.dump(ContainerStrInt, instance)
    assert dumped == {"value": 123}
    assert mr.load(ContainerStrInt, dumped) == ContainerStrInt(value=123)

    instance = ContainerStrInt(value="123")
    dumped = mr.dump(ContainerStrInt, instance)
    assert dumped == {"value": "123"}
    assert mr.load(ContainerStrInt, dumped) == ContainerStrInt(value="123")


def test_union_str_parametrised_dict() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class ContainerStrDict:
        value: str | dict[str, Any]

    instance = ContainerStrDict(value="str")
    dumped = mr.dump(ContainerStrDict, instance)
    assert dumped == {"value": "str"}
    assert mr.load(ContainerStrDict, dumped) == instance

    instance = ContainerStrDict(value={"key": "value"})
    dumped = mr.dump(ContainerStrDict, instance)
    assert dumped == {"value": {"key": "value"}}
    assert mr.load(ContainerStrDict, dumped) == instance


def test_union_parametrised_dict_str() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class ContainerDictStr:
        value: dict[str, Any] | str

    instance = ContainerDictStr(value="str")
    dumped = mr.dump(ContainerDictStr, instance)
    assert dumped == {"value": "str"}
    assert mr.load(ContainerDictStr, dumped) == instance

    instance = ContainerDictStr(value={"key": "value"})
    dumped = mr.dump(ContainerDictStr, instance)
    assert dumped == {"value": {"key": "value"}}
    assert mr.load(ContainerDictStr, dumped) == instance


def test_union_str_dict() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class ContainerStrDict:
        value: str | dict

    instance = ContainerStrDict(value="str")
    dumped = mr.dump(ContainerStrDict, instance)
    assert dumped == {"value": "str"}
    assert mr.load(ContainerStrDict, dumped) == instance

    instance = ContainerStrDict(value={"key": "value"})
    dumped = mr.dump(ContainerStrDict, instance)
    assert dumped == {"value": {"key": "value"}}
    assert mr.load(ContainerStrDict, dumped) == instance


def test_union_dict_str() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class ContainerDictStr:
        value: dict | str

    instance = ContainerDictStr(value="str")
    dumped = mr.dump(ContainerDictStr, instance)
    assert dumped == {"value": "str"}
    assert mr.load(ContainerDictStr, dumped) == instance

    instance = ContainerDictStr(value={"key": "value"})
    dumped = mr.dump(ContainerDictStr, instance)
    assert dumped == {"value": {"key": "value"}}
    assert mr.load(ContainerDictStr, dumped) == instance


def test_union_str_generic() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class GenericContainer[T]:
        value: T

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class ContainerStrGeneric:
        value: str | GenericContainer[str]

    instance = ContainerStrGeneric(value="str")
    dumped = mr.dump(ContainerStrGeneric, instance)
    assert dumped == {"value": "str"}
    assert mr.load(ContainerStrGeneric, dumped) == instance

    instance = ContainerStrGeneric(value=GenericContainer(value="str"))
    dumped = mr.dump(ContainerStrGeneric, instance)
    assert dumped == {"value": {"value": "str"}}
    assert mr.load(ContainerStrGeneric, dumped) == instance


def test_union_generic_str() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class GenericContainer[T]:
        value: T

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class ContainerGenericStr:
        value: GenericContainer[str] | str

    instance = ContainerGenericStr(value="str")
    dumped = mr.dump(ContainerGenericStr, instance)
    assert dumped == {"value": "str"}
    assert mr.load(ContainerGenericStr, dumped) == instance
    instance = ContainerGenericStr(value=GenericContainer(value="str"))
    dumped = mr.dump(ContainerGenericStr, instance)
    assert isinstance(instance.value, GenericContainer)
    assert dumped == {"value": {"value": "str"}}
    assert mr.load(ContainerGenericStr, dumped) == instance


def test_union_int_float() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class ContainerIntFloat:
        value: int | float

    instance = ContainerIntFloat(value=13)
    dumped = mr.dump(ContainerIntFloat, instance)
    assert dumped == {"value": 13}
    assert mr.load(ContainerIntFloat, dumped) == instance

    instance = ContainerIntFloat(value=13.7)
    dumped = mr.dump(ContainerIntFloat, instance)
    assert dumped == {"value": 13.7}
    assert mr.load(ContainerIntFloat, dumped) == instance


def test_union_float_int() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class ContainerIntFloat:
        value: float | int

    instance = ContainerIntFloat(value=13)
    dumped = mr.dump(ContainerIntFloat, instance)
    assert dumped == {"value": 13}
    assert mr.load(ContainerIntFloat, dumped) == instance

    instance = ContainerIntFloat(value=13.7)
    dumped = mr.dump(ContainerIntFloat, instance)
    assert dumped == {"value": 13.7}
    assert mr.load(ContainerIntFloat, dumped) == instance


def test_integral_float() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Container:
        value: float

    instance = Container(value=1)
    dumped = mr.dump(Container, instance)
    assert dumped == {"value": 1}
    assert mr.load(Container, dumped) == instance


def test_datetime_as_date() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class DateTimeContainer:
        date_field: datetime.date

    now = datetime.datetime.now(datetime.UTC)
    dumped = mr.dump(DateTimeContainer(date_field=now))

    assert dumped == {"date_field": now.date().isoformat()}


def test_options_decimal_places() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    @mr.options(decimal_places=4)
    class Container:
        value: decimal.Decimal

    dumped = mr.dump(Container(value=decimal.Decimal("123.456789")))
    assert dumped == {"value": "123.4568"}


def test_options_decimal_places_metadata_override() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    @mr.options(decimal_places=4)
    class Container:
        value: Annotated[decimal.Decimal, mr.decimal_meta(places=1)]

    dumped = mr.dump(Container(value=decimal.Decimal("123.456789")))
    assert dumped == {"value": "123.5"}


def test_options_decimal_places_multiple_fields() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    @mr.options(decimal_places=3)
    class Container:
        decimal1: decimal.Decimal
        decimal2: decimal.Decimal
        integer: int

    instance = Container(decimal1=decimal.Decimal("123.456789"), decimal2=decimal.Decimal("987.654321"), integer=42)
    dumped = mr.dump(instance)
    assert dumped == {"decimal1": "123.457", "decimal2": "987.654", "integer": 42}


def test_options_decimal_places_mixed() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    @mr.options(decimal_places=3)
    class Container:
        global_decimal: decimal.Decimal
        field_decimal: Annotated[decimal.Decimal, mr.decimal_meta(places=1)]

    instance = Container(global_decimal=decimal.Decimal("123.456789"), field_decimal=decimal.Decimal("123.456789"))
    dumped = mr.dump(instance)
    assert dumped == {"global_decimal": "123.457", "field_decimal": "123.5"}


def test_options_decimal_places_schema_caching() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Container:
        value: decimal.Decimal

    schema_2_places = mr.bake_schema(Container, decimal_places=2)
    schema_4_places = mr.bake_schema(Container, decimal_places=4)
    schema_2_places_again = mr.bake_schema(Container, decimal_places=2)

    assert schema_2_places is not schema_4_places
    assert schema_2_places is schema_2_places_again


def test_options_decimal_places_different_values() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    @mr.options(decimal_places=3)
    class Container2:
        value: decimal.Decimal

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    @mr.options(decimal_places=4)
    class Container4:
        value: decimal.Decimal

    test_value = decimal.Decimal("123.456789")

    dumped2 = mr.dump(Container2(value=test_value))
    dumped4 = mr.dump(Container4(value=test_value))

    assert dumped2 == {"value": "123.457"}
    assert dumped4 == {"value": "123.4568"}


def test_options_decimal_places_nested_dataclass() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Inner:
        value: decimal.Decimal

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    @mr.options(decimal_places=3)
    class Outer:
        inner: Inner
        outer_value: decimal.Decimal

    instance = Outer(inner=Inner(value=decimal.Decimal("123.456789")), outer_value=decimal.Decimal("987.654321"))
    dumped = mr.dump(instance)
    assert dumped == {"inner": {"value": "123.46"}, "outer_value": "987.654"}


def test_options_decimal_places_nested_with_global_parameter() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Inner:
        value: decimal.Decimal

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Outer:
        inner: Inner
        outer_value: decimal.Decimal

    instance = Outer(inner=Inner(value=decimal.Decimal("123.456789")), outer_value=decimal.Decimal("987.654321"))
    dumped = mr.dump(instance, decimal_places=3)
    assert dumped == {"inner": {"value": "123.457"}, "outer_value": "987.654"}


def test_options_decimal_places_nested_list() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    @mr.options(decimal_places=3)
    class Item:
        price: decimal.Decimal

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Container:
        items: list[Item]

    instance = Container(items=[Item(price=decimal.Decimal("10.999")), Item(price=decimal.Decimal("20.555"))])
    dumped = mr.dump(instance)
    assert dumped == {"items": [{"price": "10.999"}, {"price": "20.555"}]}


def test_options_decimal_places_deeply_nested() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Level3:
        value: decimal.Decimal

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Level2:
        level3: Level3

    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    @mr.options(decimal_places=1)
    class Level1:
        level2: Level2

    instance = Level1(level2=Level2(level3=Level3(value=decimal.Decimal("123.456"))))
    dumped = mr.dump(instance)
    assert dumped == {"level2": {"level3": {"value": "123.46"}}}


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
@mr.options(decimal_places=3)
class CyclicWithDecimal:
    marker: str
    value: decimal.Decimal
    child: "CyclicWithDecimal | None"


def test_options_decimal_places_cyclic_reference() -> None:
    instance = CyclicWithDecimal(
        marker="level 1",
        value=decimal.Decimal("123.456"),
        child=CyclicWithDecimal(marker="level 2", value=decimal.Decimal("987.654"), child=None),
    )
    dumped = mr.dump(instance)
    assert dumped == {"marker": "level 1", "value": "123.456", "child": {"marker": "level 2", "value": "987.654"}}


def test_decimal_rounding_metadata() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Container:
        value: Annotated[decimal.Decimal, mr.decimal_meta(places=2, rounding=decimal.ROUND_UP)]

    dumped = mr.dump(Container(value=decimal.Decimal("123.454")))
    assert dumped == {"value": "123.46"}


def test_decimal_rounding_metadata_round_down() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class Container:
        value: Annotated[decimal.Decimal, mr.decimal_meta(places=2, rounding=decimal.ROUND_DOWN)]

    dumped = mr.dump(Container(value=decimal.Decimal("123.459")))
    assert dumped == {"value": "123.45"}


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Cyclic:
    marker: str
    child: "Cyclic | None"


def test_cyclic_self_reference() -> None:
    dumped = mr.dump(Cyclic(marker="level 1", child=None))
    assert dumped == {"marker": "level 1"}

    dumped = mr.dump(Cyclic(marker="level 1", child=Cyclic(marker="level 2", child=None)))
    assert dumped == {"child": {"marker": "level 2"}, "marker": "level 1"}


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CyclicParent:
    marker: str
    child: "CyclicChild"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CyclicChild:
    marker: str
    parent: CyclicParent | None


def test_cyclic_indirect_reference() -> None:
    dumped = mr.dump(CyclicParent(marker="level 1", child=CyclicChild(marker="level 2", parent=None)))
    assert dumped == {"marker": "level 1", "child": {"marker": "level 2"}}

    dumped = mr.dump(
        CyclicParent(
            marker="level 1",
            child=CyclicChild(
                marker="level 2",
                parent=CyclicParent(marker="level 3", child=CyclicChild(marker="level 4", parent=None)),
            ),
        )
    )
    assert dumped == {
        "marker": "level 1",
        "child": {"marker": "level 2", "parent": {"marker": "level 3", "child": {"marker": "level 4"}}},
    }


def test_none_value_handling_with_include() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class DataClass:
        str_field: str | None = None
        int_field: int | None = None

    data = DataClass(str_field="hello", int_field=None)
    dumped = mr.dump(data, none_value_handling=mr.NoneValueHandling.INCLUDE)
    assert dumped == {"str_field": "hello", "int_field": None}

    loaded = mr.load(DataClass, dumped, none_value_handling=mr.NoneValueHandling.INCLUDE)
    assert loaded == data


def test_none_value_handling_with_ignore() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class DataClass:
        str_field: str | None = None
        int_field: int | None = None

    data = DataClass(str_field="hello", int_field=None)
    dumped = mr.dump(data, none_value_handling=mr.NoneValueHandling.IGNORE)
    assert dumped == {"str_field": "hello"}


def test_none_value_handling_with_many() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class DataClass:
        str_field: str | None = None
        int_field: int | None = None

    data = [DataClass(str_field="hello", int_field=None), DataClass(str_field=None, int_field=42)]

    dumped_include = mr.dump_many(data, none_value_handling=mr.NoneValueHandling.INCLUDE)
    assert dumped_include == [{"str_field": "hello", "int_field": None}, {"str_field": None, "int_field": 42}]

    dumped_ignore = mr.dump_many(data, none_value_handling=mr.NoneValueHandling.IGNORE)
    assert dumped_ignore == [{"str_field": "hello"}, {"int_field": 42}]

    loaded = mr.load_many(DataClass, dumped_include, none_value_handling=mr.NoneValueHandling.INCLUDE)
    assert loaded == data


def test_none_value_handling_overrides_dataclass_options() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    @mr.options(none_value_handling=mr.NoneValueHandling.INCLUDE)
    class DataClass:
        str_field: str | None = None
        int_field: int | None = None

    data = DataClass(str_field="hello", int_field=None)

    dumped_with_override = mr.dump(data, none_value_handling=mr.NoneValueHandling.IGNORE)
    assert dumped_with_override == {"str_field": "hello"}

    dumped_without_override = mr.dump(data)
    assert dumped_without_override == {"str_field": "hello", "int_field": None}


def test_none_value_handling_schema_caching() -> None:
    @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
    class DataClass:
        str_field: str | None = None
        int_field: int | None = None

    schema_include = mr.schema(DataClass, none_value_handling=mr.NoneValueHandling.INCLUDE)
    schema_ignore = mr.schema(DataClass, none_value_handling=mr.NoneValueHandling.IGNORE)

    assert schema_include is not schema_ignore
