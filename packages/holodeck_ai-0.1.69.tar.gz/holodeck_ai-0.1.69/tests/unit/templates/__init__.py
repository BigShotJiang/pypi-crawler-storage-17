"""HoloDeck templates unit tests."""
