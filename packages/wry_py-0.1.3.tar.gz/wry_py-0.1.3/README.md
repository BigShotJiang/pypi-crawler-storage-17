# Wry Py

A Python binding for the [Wry](https://github.com/tauri-apps/wry) library, which is a lightweight webview library for building desktop applications using web technologies.
