=================================================
Definition of new Xtrack-compatible beam elements
=================================================

.. toctree::
    :maxdepth: 3

    dev_guide_xtbe_data_structure
    dev_guide_xtbe_tracking_code
    dev_guide_xtbe_internal_record
    dev_guide_xtbe_lost_part_codes