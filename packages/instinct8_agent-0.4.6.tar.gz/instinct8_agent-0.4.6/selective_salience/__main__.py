"""
Run selective_salience as a module: python -m selective_salience
"""

from .cli import main

if __name__ == '__main__':
    main()
