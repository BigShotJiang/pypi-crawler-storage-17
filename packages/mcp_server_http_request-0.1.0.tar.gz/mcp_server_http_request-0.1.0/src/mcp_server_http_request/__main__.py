# __main__.py

from mcp_server_http_request import main

main()
