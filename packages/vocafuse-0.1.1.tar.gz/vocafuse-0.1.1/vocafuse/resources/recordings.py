"""
Recordings resource for VocaFuse SDK.
"""

from typing import Dict, Any, List, Optional
from .base import BaseResource


class TranscriptionResource:
    """Nested transcription resource for a specific recording."""
    
    def __init__(self, recordings_resource, recording_id: str):
        self.recordings_resource = recordings_resource
        self.recording_id = recording_id
    
    def get(self) -> Dict[str, Any]:
        """
        Get transcription for this recording.
        
        Returns:
            Transcription data including text, confidence, words, etc.
            
        Raises:
            TranscriptionNotFoundError: If transcription not found or not ready
            RecordingNotFoundError: If recording doesn't exist
        """
        return self.recordings_resource._get(f'recordings/{self.recording_id}/transcription')


class RecordingInstance:
    """Individual recording instance with nested resource access."""
    
    def __init__(self, recordings_resource, recording_id: str):
        self.recordings_resource = recordings_resource
        self.recording_id = recording_id
        self.transcription = TranscriptionResource(recordings_resource, recording_id)
    
    def get(self) -> Dict[str, Any]:
        """Get this specific recording."""
        return self.recordings_resource.get(self.recording_id)
    
    def delete(self) -> Dict[str, Any]:
        """Delete this specific recording."""
        return self.recordings_resource.delete(self.recording_id)


class RecordingsResource(BaseResource):
    """
    Recordings resource for managing voice recordings.
    
    Usage:
        # List all recordings
        recordings = client.recordings.list()
        
        # Get specific recording
        recording = client.recordings.get('recording_id')
        
        # Get transcription (nested access)
        transcription = client.recordings('recording_id').transcription.get()
        
        # Delete recording
        client.recordings.delete('recording_id')
        
        # Or using instance access
        recording_instance = client.recordings('recording_id')
        recording_data = recording_instance.get()
        transcription = recording_instance.transcription.get()
        recording_instance.delete()
    """
    
    def __call__(self, recording_id: str) -> RecordingInstance:
        """
        Get recording instance for nested access.
        
        Args:
            recording_id: ID of the recording
            
        Returns:
            RecordingInstance with transcription access
        """
        return RecordingInstance(self, recording_id)
    
    def list(
        self,
        page: int = 0,
        limit: int = 50,
        status: Optional[str] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List recordings with optional filtering.
        
        Args:
            page: Page number (0-based)
            limit: Number of recordings per page (max 100)
            status: Filter by status (processing, completed, failed)
            date_from: Filter recordings from this date (ISO format)
            date_to: Filter recordings to this date (ISO format)
            
        Returns:
            Dict with recordings list and pagination info
        """
        params = {
            'page': page,
            'limit': min(limit, 100)  # Enforce max limit
        }
        
        # Add optional filters
        if status:
            params['status'] = status
        if date_from:
            params['date_from'] = date_from
        if date_to:
            params['date_to'] = date_to
        
        return self._get('recordings', params=params)
    
    def get(self, recording_id: str) -> Dict[str, Any]:
        """
        Get specific recording by ID.
        
        Args:
            recording_id: ID of the recording
            
        Returns:
            Recording data including metadata, status, etc.
            
        Raises:
            RecordingNotFoundError: If recording not found
        """
        return self._get(f'recordings/{recording_id}')
    
    def delete(self, recording_id: str) -> Dict[str, Any]:
        """
        Delete specific recording by ID.
        
        Args:
            recording_id: ID of the recording to delete
            
        Returns:
            Empty dict (204 No Content)
            
        Raises:
            RecordingNotFoundError: If recording not found
        """
        return self._delete(f'recordings/{recording_id}')

