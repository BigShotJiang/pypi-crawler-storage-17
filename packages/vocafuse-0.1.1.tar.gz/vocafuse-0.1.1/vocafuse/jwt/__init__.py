"""
VocaFuse JWT - Token generation utilities.
"""

from .access_token import AccessToken

__all__ = ["AccessToken"] 