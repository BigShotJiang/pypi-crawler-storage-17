# xpart
Python package for generation and analysis of particles distributions
