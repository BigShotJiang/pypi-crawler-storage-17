
class SpringManifestValidationError(Exception):
    """Raised when Spring Boot manifest validation fails."""
    pass