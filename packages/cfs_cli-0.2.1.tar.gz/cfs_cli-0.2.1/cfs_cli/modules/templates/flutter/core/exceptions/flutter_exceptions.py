
class FlutterGeneratorError(Exception):
    """Raised when Flutter generation fails."""
    pass


from typing import Dict , Any
import re

class FlutterManifestValidationError(Exception):
    """Raised when Flutter manifest validation fails."""
    pass

