User Role Module
################

The user_role module allows to assign roles to user instead of groups.
A *Role* is defined by a set of groups. When a role is added to a user, it
overrides the existing groups. A role can be added to a user for a period.
