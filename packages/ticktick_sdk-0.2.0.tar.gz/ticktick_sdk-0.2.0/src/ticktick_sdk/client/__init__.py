"""
TickTick Client Package.

This package provides the high-level TickTick client interface.
"""

from ticktick_sdk.client.client import TickTickClient

__all__ = ["TickTickClient"]
