"""Python unit tests for jupyterlab_drawio_render_extension."""
