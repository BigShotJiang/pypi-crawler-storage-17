from enum import Enum


class VarNames(Enum):
    seperator_scenario_name = "Sc_"
    column_name_scenario = "Scenario"
    column_name_model = "Model"
    column_name_id = "ID"
    model_name = "TiMBA"
    data_periods = "data_periods"