# Blank script for Base._start() to run instead of starting the REPL.
