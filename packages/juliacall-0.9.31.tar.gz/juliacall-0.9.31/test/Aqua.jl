@testitem "Aqua" begin
    import Aqua
    Aqua.test_all(PythonCall)
end
