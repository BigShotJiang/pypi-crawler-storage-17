---
name: Help & support
about: Any other questions
title: ''
labels: question
assignees: ''

---

Please direct any other questions to [github discussions](https://github.com/JuliaPy/PythonCall.jl/discussions).
