"""Output validation cosine similarity validators."""

from __future__ import annotations

from dataclasses import dataclass

from ...enums import OutputValidation, ValidatorDomain
from ...registry import register_validator
from ..base import OutputValidator


@register_validator(
    domain=ValidatorDomain.OUTPUT_VALIDATION,
    slug=OutputValidation.COSINE_SIMILARITY.value,
)
@dataclass(slots=True)
class CosineSimilarityValidator(OutputValidator):
    """Validator for calculating cosine similarity of output."""

    def __post_init__(self) -> None:
        """Set domain and slug after initialization."""
        object.__setattr__(self, "_domain", ValidatorDomain.OUTPUT_VALIDATION)
        object.__setattr__(self, "_slug", OutputValidation.COSINE_SIMILARITY.value)
