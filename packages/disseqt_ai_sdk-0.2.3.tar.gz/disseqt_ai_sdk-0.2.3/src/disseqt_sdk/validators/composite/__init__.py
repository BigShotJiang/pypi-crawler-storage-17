"""Composite score validators."""

from .evaluate import CompositeScoreEvaluator

__all__ = ["CompositeScoreEvaluator"]

