
``wuttaweb.views.people``
=========================

.. automodule:: wuttaweb.views.people
   :members:
