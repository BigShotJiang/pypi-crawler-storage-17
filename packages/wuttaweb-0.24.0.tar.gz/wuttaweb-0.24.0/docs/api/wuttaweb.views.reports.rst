
``wuttaweb.views.reports``
==========================

.. automodule:: wuttaweb.views.reports
   :members:
