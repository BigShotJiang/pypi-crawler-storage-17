
``wuttaweb.forms.schema``
=========================

.. automodule:: wuttaweb.forms.schema
   :members:
