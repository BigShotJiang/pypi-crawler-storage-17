
``wuttaweb.views.batch``
========================

.. automodule:: wuttaweb.views.batch
   :members:
