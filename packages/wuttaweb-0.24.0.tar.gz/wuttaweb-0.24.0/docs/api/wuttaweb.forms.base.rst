
``wuttaweb.forms.base``
=======================

.. automodule:: wuttaweb.forms.base
   :members:
