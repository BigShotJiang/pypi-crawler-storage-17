"""Consoul CLI commands."""

from __future__ import annotations

__all__ = ["describe"]
