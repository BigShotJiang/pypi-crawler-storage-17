#################
Commission Module
#################

The *Commission Module* allows you to manage commission for sale's agent.
A commission move is created when posting the invoice, following the agent's
commission plan.

.. toctree::
   :maxdepth: 2

   usage
   design
   releases
