from django.apps import AppConfig


class WbcrmConfig(AppConfig):
    name = "wbcrm"
