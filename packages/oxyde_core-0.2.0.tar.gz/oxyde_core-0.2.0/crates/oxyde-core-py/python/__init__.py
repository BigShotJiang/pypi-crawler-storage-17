"""Placeholder Python package for maturin editable builds.

The Rust PyO3 module exposes `_oxyde_core`, so we keep this package empty.
"""
