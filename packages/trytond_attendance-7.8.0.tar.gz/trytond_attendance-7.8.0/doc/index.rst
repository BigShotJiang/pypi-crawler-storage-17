#################
Attendance Module
#################

The *Attendance Module* allows tracking when employees arrive at, or leave, the
company's premises.

.. toctree::
   :maxdepth: 2

   design
   releases
