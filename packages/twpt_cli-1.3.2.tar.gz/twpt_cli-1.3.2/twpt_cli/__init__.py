"""ThreatWinds Pentest CLI - Python implementation."""

__version__ = "1.2.8"
__author__ = "ThreatWinds"
__email__ = "support@threatwinds.com"