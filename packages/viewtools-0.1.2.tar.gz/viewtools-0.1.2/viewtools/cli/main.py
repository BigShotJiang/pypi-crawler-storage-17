"""Main CLI entry point."""

from . import cli


def main():
    """Main CLI function."""
    cli()


if __name__ == "__main__":
    main()
