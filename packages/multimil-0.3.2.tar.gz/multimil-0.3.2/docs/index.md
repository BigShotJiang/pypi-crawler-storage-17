```{include} ../README.md

```

```{toctree}
:hidden: true
:maxdepth: 2

api.md
tutorials.md
changelog.md
contributing.md
references.md
```
