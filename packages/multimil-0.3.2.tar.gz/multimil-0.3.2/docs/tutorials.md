# Tutorials

## Prediction

```{toctree}
:maxdepth: 1

notebooks/mil_classification
notebooks/mil_regression
```
