from ._mil_torch import MILClassifierTorch

__all__ = ["MILClassifierTorch"]
