from ._mil import MILClassifier

__all__ = ["MILClassifier"]
