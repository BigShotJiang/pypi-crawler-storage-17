from ._base_components import MLP, Aggregator

__all__ = ["MLP", "Aggregator"]
