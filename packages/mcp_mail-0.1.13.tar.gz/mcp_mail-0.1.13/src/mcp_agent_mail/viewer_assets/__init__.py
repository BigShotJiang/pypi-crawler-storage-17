"""Packaged static assets for the standalone mailbox viewer."""

from __future__ import annotations

__all__ = ["__path__"]
