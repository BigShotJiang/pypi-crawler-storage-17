---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-users-jleechan-projects-worktree-worker3"
  ],
  "created": "2025-12-19T04:45:37.970482+00:00",
  "from": "codev",
  "id": 9,
  "importance": "high",
  "project": "/Users/jleechan/projects/worktree_worker3",
  "project_slug": "users-jleechan-projects-worktree-worker3",
  "subject": "PR2353: firestore_service mock cleanup audit",
  "thread_id": null,
  "to": [
    "CodevFirestore"
  ]
}
---

Please review `mvp_site/firestore_service.py` for serious issues:
- There are two `_mock_firestore_client` definitions; second shadows first.
- `_IN_MEMORY_DB` appears unused.
- `get_db()` uses `_mock_client_singleton` for MOCK_SERVICES_MODE.
Recommend minimal safe cleanup (remove dead code; ensure tests still pass). Reply with DONE/NOT DONE and patch outline.
