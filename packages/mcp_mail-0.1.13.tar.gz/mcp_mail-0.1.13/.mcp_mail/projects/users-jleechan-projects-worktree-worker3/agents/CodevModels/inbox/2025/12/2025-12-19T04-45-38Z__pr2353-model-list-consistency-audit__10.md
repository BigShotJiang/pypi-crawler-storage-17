---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-users-jleechan-projects-worktree-worker3"
  ],
  "created": "2025-12-19T04:45:38.329345+00:00",
  "from": "codev",
  "id": 10,
  "importance": "high",
  "project": "/Users/jleechan/projects/worktree_worker3",
  "project_slug": "users-jleechan-projects-worktree-worker3",
  "subject": "PR2353: model list consistency audit",
  "thread_id": null,
  "to": [
    "CodevModels"
  ]
}
---

Please review PR #2353 model selection consistency:
- `mvp_site/constants.py`:
  - `ALLOWED_CEREBRAS_MODELS` currently documents `gpt-oss-120b` but (per Cursor) may be missing the string entry.
  - `MODEL_CONTEXT_WINDOW_TOKENS` / `MODEL_MAX_OUTPUT_TOKENS`: check `gpt-oss-120b` vs `openai/gpt-oss-120b` consistency.
- `mvp_site/templates/settings.html`: UI offers `gpt-oss-120b` and may offer removed models.
- Goal: recommend either (A) remove `gpt-oss-120b` from UI and docs, OR (B) add it consistently to allowed list + token tables.
Reply with: DONE/NOT DONE + concrete patch suggestions.
