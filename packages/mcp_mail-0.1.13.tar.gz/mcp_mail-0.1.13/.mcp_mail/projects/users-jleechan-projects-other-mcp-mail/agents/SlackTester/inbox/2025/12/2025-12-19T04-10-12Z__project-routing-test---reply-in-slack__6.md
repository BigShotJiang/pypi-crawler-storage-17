---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-users-jleechan-projects-other-mcp-mail"
  ],
  "created": "2025-12-19T04:10:12.084349+00:00",
  "from": "SlackTester",
  "id": 6,
  "importance": "high",
  "project": "/Users/jleechan/projects_other/mcp_mail",
  "project_slug": "users-jleechan-projects-other-mcp-mail",
  "subject": "Project Routing Test - Reply in Slack!",
  "thread_id": null,
  "to": [
    "SlackTester"
  ]
}
---

This message was sent from the **mcp_mail** project (NOT slack-sync).

Please reply to this in Slack - your reply should land in the `mcp_mail` project, NOT in `slack-sync`.

Test timestamp: 2025-12-18 20:10 PST
