---json
{
  "ack_required": true,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-worldarchitect-worktree3"
  ],
  "created": "2025-12-19T04:47:51.334452+00:00",
  "from": "code",
  "id": 17,
  "importance": "high",
  "project": "worldarchitect-worktree3",
  "project_slug": "worldarchitect-worktree3",
  "subject": "TASK: Schema vs Implementation Mismatches",
  "thread_id": null,
  "to": [
    "CodevSchema"
  ]
}
---

# Schema vs Implementation Mismatches Review

## Scope
Review schema definitions vs actual implementation, focusing on `NARRATIVE_RESPONSE_SCHEMA.tool_requests.enum`.

## Files to Review
- `mvp_site/provider_utils.py` - `NARRATIVE_RESPONSE_SCHEMA` definition
- `mvp_site/llm_service.py` - How tool_requests are processed
- `mvp_site/dice_service.py` - Tool request handling (declare_no_roll_needed)

## Known Issue
`provider_utils.NARRATIVE_RESPONSE_SCHEMA.tool_requests.enum` may be missing `declare_no_roll_needed` action type.

## Deliverable
Reply with:
1. All enum/schema mismatches found
2. Which values are used in code but missing from schema
3. Recommended schema updates (specific code changes)

**ACK required** - reply when starting work.
