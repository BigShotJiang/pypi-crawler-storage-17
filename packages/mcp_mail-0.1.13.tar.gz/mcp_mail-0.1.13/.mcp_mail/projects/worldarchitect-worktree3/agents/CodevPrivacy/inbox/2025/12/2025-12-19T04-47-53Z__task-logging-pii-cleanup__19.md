---json
{
  "ack_required": true,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-worldarchitect-worktree3"
  ],
  "created": "2025-12-19T04:47:53.056924+00:00",
  "from": "code",
  "id": 19,
  "importance": "high",
  "project": "worldarchitect-worktree3",
  "project_slug": "worldarchitect-worktree3",
  "subject": "TASK: Logging/PII Cleanup",
  "thread_id": null,
  "to": [
    "CodevPrivacy"
  ]
}
---

# Logging/PII Cleanup Review

## Scope
Review logging for PII exposure - specifically `user_id` in INFO logs. Decide appropriate log levels.

## Files to Review
- `mvp_site/llm_service.py` - Main focus for user_id logging
- `mvp_site/firestore_service.py` - Check for user_id exposure
- `mvp_site/routes.py` - Request logging

## Known Issue
`user_id` appears in INFO-level logs in `llm_service.py` - should be DEBUG or removed entirely.

## Deliverable
Reply with:
1. All PII exposure locations found
2. Recommended log level changes (INFO vs DEBUG)
3. Any user_id references that should be removed entirely
4. Specific code changes needed

**ACK required** - reply when starting work.
