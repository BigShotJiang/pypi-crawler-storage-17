---json
{
  "ack_required": true,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-worldarchitect-worktree3"
  ],
  "created": "2025-12-19T04:49:55.905718+00:00",
  "from": "code",
  "id": 22,
  "importance": "urgent",
  "project": "worldarchitect-worktree3",
  "project_slug": "worldarchitect-worktree3",
  "subject": "REQUIRED: Register MCP Mail + ACK Bead worktree_worker3-5st",
  "thread_id": null,
  "to": [
    "CodevFirestore"
  ]
}
---

# Registration & Bead Acknowledgement Required

Before proceeding with your review, you MUST:

## 1. Register with MCP Mail
```
register_agent(
  project_key="worldarchitect-worktree3",
  name="CodevFirestore",
  program="claude-code",
  model="sonnet-4",
  task_description="Firestore mock cleanup review"
)
```

## 2. Acknowledge Your Bead
Your assigned bead: **`worktree_worker3-5st`**

Title: *PR2353: Clean up Firestore mock client duplication / dead code*

Update bead status to `in_progress`:
```
mcp__beads__update(
  issue_id="worktree_worker3-5st",
  status="in_progress",
  notes="Starting Firestore mock cleanup review"
)
```

## 3. When Complete
- Reply to this message with your findings
- Update bead with results and set status to `closed` when done

**Do not proceed with code review until registration and bead ACK are complete.**
