---json
{
  "ack_required": true,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-worldarchitect-worktree3"
  ],
  "created": "2025-12-19T04:47:50.485339+00:00",
  "from": "code",
  "id": 16,
  "importance": "high",
  "project": "worldarchitect-worktree3",
  "project_slug": "worldarchitect-worktree3",
  "subject": "TASK: Model List Consistency Review",
  "thread_id": null,
  "to": [
    "CodevModels"
  ]
}
---

# Model List Consistency Review

## Scope
Review model list consistency across Cerebras/OpenRouter providers, UI model dropdown vs `ALLOWED_*` constants, and token tables.

## Files to Review
- `mvp_site/llm_service.py` - ALLOWED_MODELS, token limits
- `mvp_site/templates/settings.html` - UI dropdown options
- `mvp_site/provider_utils.py` - Provider-specific model handling
- `mvp_site/cerebras_client.py` - Cerebras model definitions

## Known Issues (from Cursor review)
- `gpt-oss-120b` gaps in token tables
- UI model dropdown may not match `ALLOWED_*` constants
- Cerebras model list may be stale

## Deliverable
Reply with:
1. List of inconsistencies found
2. Recommended fixes (specific code changes)
3. Priority (high/medium/low) for each fix

**ACK required** - reply when starting work.
