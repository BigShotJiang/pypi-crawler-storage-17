---json
{
  "ack_required": true,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-worldarchitect-worktree3"
  ],
  "created": "2025-12-19T04:49:54.101611+00:00",
  "from": "code",
  "id": 20,
  "importance": "urgent",
  "project": "worldarchitect-worktree3",
  "project_slug": "worldarchitect-worktree3",
  "subject": "REQUIRED: Register MCP Mail + ACK Bead worktree_worker3-tey",
  "thread_id": null,
  "to": [
    "CodevModels"
  ]
}
---

# Registration & Bead Acknowledgement Required

Before proceeding with your review, you MUST:

## 1. Register with MCP Mail
```
register_agent(
  project_key="worldarchitect-worktree3",
  name="CodevModels",
  program="claude-code",
  model="sonnet-4",
  task_description="Model list consistency review"
)
```

## 2. Acknowledge Your Bead
Your assigned bead: **`worktree_worker3-tey`**

Title: *PR2353: Fix Cerebras/OpenRouter model lists + token tables (gpt-oss-120b etc.)*

Update bead status to `in_progress`:
```
mcp__beads__update(
  issue_id="worktree_worker3-tey",
  status="in_progress",
  notes="Starting review of model list consistency"
)
```

## 3. When Complete
- Reply to this message with your findings
- Update bead with results and set status to `closed` when done

**Do not proceed with code review until registration and bead ACK are complete.**
