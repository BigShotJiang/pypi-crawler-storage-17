MXIO
====

[![Language grade: Python](https://img.shields.io/lgtm/grade/python/g/michel4j/mxio.svg?logo=lgtm&logoWidth=18)](https://lgtm.com/projects/g/michel4j/mxio/context:python)

MX Diffraction Image IO Library

Handles reading of headers and data from a variety of diffraction formats.
