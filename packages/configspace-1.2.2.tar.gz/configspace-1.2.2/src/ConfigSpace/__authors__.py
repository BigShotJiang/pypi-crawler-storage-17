from __future__ import annotations

__authors__ = [
    "Matthias Feurer",
    "Katharina Eggensperger",
    "Syed Mohsin Ali",
    "Christina Hernandez Wunsch",
    "Julien-Charles Levesque",
    "Jost Tobias Springenberg",
    "Philipp Mueller",
    "Marius Lindauer",
    "Jorn Tuyls",
    "Eddie Bergman",
    "Arjun Krishnakumar",
]
