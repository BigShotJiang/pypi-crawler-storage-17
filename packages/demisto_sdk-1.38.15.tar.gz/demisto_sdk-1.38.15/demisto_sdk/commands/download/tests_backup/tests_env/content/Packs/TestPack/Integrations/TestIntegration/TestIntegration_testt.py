def test_assert():
    assert 1 == 1
