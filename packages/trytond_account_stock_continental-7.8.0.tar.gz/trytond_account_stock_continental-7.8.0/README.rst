################################
Account Stock Continental Module
################################

The *Account Stock Continental Module* provides the ability to use the
continental stock valuation method.

.. toctree::
   :maxdepth: 2

   design
   releases
