# Youtube Autonomous Web Resources module

The module in which we are able to generate web resources (images, animation frames, etc.) to be exported as images for the editor.