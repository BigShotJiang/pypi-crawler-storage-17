##############################
Account Export WinBooks Module
##############################

The *Account Export WinBooks Module* adds support to export accounting to
`WinBooks <https://www.exact.com/befr/software/exact-winbooks>`_.

.. toctree::
   :maxdepth: 2

   design
   releases
