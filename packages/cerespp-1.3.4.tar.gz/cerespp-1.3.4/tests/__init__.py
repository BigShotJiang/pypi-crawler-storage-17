"""Tests for Ceres++."""
