from django.contrib import admin

# Register your models here.
# Note: UserAdmin import removed to avoid AlreadyRegistered error
# from django.contrib.auth.admin import UserAdmin
