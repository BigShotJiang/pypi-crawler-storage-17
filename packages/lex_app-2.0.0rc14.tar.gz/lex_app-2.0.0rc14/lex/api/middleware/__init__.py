from .keycloak_permissions import KeycloakPermissionsMiddleware

__all__ = [
    'KeycloakPermissionsMiddleware',
]
