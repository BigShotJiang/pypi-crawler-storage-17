from django.contrib import admin

# API admin configurations will be added here as needed