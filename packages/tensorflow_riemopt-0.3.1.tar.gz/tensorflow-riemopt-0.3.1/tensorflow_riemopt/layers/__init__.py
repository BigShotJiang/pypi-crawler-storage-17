from tensorflow_riemopt.layers.embeddings import ManifoldEmbedding

__all__ = ["ManifoldEmbedding"]
