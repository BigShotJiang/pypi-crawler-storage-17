# Test app

Install uv

```console
pipx install uv
```

Run the app:

```console
uv run litestar --app testapp.app:create_app run --reload
```
