from __future__ import annotations

__all__ = ("DTO_INFO_KEY",)

DTO_INFO_KEY: str = "dto"
