from __future__ import annotations

__all__ = ("StrawchemyFieldError",)


class StrawchemyFieldError(Exception): ...
