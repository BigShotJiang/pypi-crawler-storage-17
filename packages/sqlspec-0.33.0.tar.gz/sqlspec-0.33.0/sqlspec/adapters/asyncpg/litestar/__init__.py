"""Litestar integration for AsyncPG adapter."""

from sqlspec.adapters.asyncpg.litestar.store import AsyncpgStore

__all__ = ("AsyncpgStore",)
