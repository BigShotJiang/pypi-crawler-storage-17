"""Litestar integration for AioSQLite adapter."""

from sqlspec.adapters.aiosqlite.litestar.store import AiosqliteStore

__all__ = ("AiosqliteStore",)
