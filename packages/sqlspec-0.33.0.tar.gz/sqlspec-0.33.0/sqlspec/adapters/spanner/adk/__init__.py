"""Spanner ADK store exports."""

from sqlspec.adapters.spanner.adk.store import SpannerSyncADKStore

__all__ = ("SpannerSyncADKStore",)
