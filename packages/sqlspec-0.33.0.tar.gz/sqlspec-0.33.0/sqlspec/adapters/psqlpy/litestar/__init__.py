"""Litestar integration for psqlpy adapter."""

from sqlspec.adapters.psqlpy.litestar.store import PsqlpyStore

__all__ = ("PsqlpyStore",)
