"""ADBC ADK integration for Google Agent Development Kit."""

from sqlspec.adapters.adbc.adk.store import AdbcADKStore

__all__ = ("AdbcADKStore",)
