"""Example integrations demonstrating SQLSpec usage."""
