<!-- Do not edit. Canonical instructions live in ../AGENTS.md -->
@../AGENTS.md
