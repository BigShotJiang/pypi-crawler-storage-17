# Test Files

The test files in this folder are simple text files that have been carted.
The original text file is also in the file for comparison sake.

These files are used to test that carting an uncarting are working.

## File list

The files have the following sha256s:

- text.txt - 4d07389cc8be738474d240946a8094be4c89db028958a8e5b28290e4502ec8e2
- text-long.txt - 25ed3194250f3fc23145ca1d51e58b50004968d31223a89a7736b09377f7be47
