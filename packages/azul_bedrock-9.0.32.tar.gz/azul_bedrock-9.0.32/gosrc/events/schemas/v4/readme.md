# Compatibility

Version 4 is compatible with version 7 of Azul.

## Changes

First Avro schema
