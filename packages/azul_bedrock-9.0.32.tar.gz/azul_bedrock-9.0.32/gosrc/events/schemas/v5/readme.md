# Compatibility

Version 5 is compatible with version 8 of Azul.

## Changes

0_support.py -> EventSource -> settings field added with default {}
