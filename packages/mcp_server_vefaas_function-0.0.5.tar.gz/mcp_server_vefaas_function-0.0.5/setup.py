from setuptools import setup

# This file is provided for compatibility with older pip versions
# The actual package configuration is in pyproject.toml

if __name__ == "__main__":
    setup()