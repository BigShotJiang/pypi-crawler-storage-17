# Nova Research Agent: MCP Server

Click [here](..) for more details on how to use the Nova Research Agent MCP Server.