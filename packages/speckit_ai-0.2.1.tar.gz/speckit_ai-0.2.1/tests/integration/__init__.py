"""Integration tests for speckit - real components."""
