## v0.2.1 - 2025-Dec-18

- Added `class="table-filters"` to the tabled form filters row to distinguish from the primary header row.
- Fixed Model title displayed on index listing pages.

## v0.2.0 - 2025-Dec-15

- Added: Add table header filters to easily filter on the column's data.
- Added: Provide a changelog for developer history.
- Changed: Use mutable sequence as return value when no filters are found.

## v0.1.0 - 2025-Nov-30

- Initial release
