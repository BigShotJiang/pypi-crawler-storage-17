"""Simulator subpackage for traffic_flow_models.

Empty package for consistency with the project layout.
"""

__all__ = []
