"""
the context module provides all things related to context.
"""
