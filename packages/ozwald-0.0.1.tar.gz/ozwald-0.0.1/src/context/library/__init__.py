"""
the library module provides data to the context builders.
"""
