# Package initializer for the ozwald CLI commands
