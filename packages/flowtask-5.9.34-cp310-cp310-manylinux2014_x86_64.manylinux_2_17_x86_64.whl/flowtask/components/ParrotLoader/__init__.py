from .loader import ParrotLoader

__all__ = (
    'ParrotLoader',
)
