from .predict import SegmentationPredictor

__all__ = "SegmentationPredictor",
