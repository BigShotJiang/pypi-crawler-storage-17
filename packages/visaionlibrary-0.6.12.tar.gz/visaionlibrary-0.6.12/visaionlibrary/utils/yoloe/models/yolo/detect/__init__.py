from .predict import DetectionPredictor

__all__ = "DetectionPredictor",
