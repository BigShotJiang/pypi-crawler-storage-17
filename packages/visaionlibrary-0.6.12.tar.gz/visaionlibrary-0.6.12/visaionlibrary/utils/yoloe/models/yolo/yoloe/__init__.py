from .predict_vp import YOLOEVPSegPredictor

__all__ = ["YOLOEVPSegPredictor"]
