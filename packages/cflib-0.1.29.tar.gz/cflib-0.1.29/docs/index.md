---
title: Home
page_id: home
---

cflib is an API written in Python that is used to communicate with the Crazyflie
and Crazyflie 2.x quadcopters. It is intended to be used by client software to
communicate with and control a Crazyflie quadcopter. For instance the [Crazyflie PC client](https://github.com/bitcraze/crazyflie-clients-python)  uses the cflib.

## Contribute

Everyone is encouraged to contribute to the CrazyFlie library by forking the Github repository and making a pull request or opening an issue.
