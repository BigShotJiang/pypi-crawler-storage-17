"""
arifos_core.governed_llm - BACKWARD COMPATIBILITY SHIM (v42)
Moved to: arifos_core/integration/adapters/governed_llm.py
This shim will be removed in v43.0.
"""
from arifos_core.integration.adapters.governed_llm import *
