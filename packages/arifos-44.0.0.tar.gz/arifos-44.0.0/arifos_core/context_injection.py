"""
arifos_core.context_injection - BACKWARD COMPATIBILITY SHIM (v42)
Moved to: arifos_core/utils/context_injection.py
This shim will be removed in v43.0.
"""
from arifos_core.utils.context_injection import *
