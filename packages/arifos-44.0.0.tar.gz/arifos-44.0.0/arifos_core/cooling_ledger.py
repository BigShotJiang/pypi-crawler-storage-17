"""
arifos_core.cooling_ledger - BACKWARD COMPATIBILITY SHIM (v42)
Moved to: arifos_core/memory/cooling_ledger.py
This shim will be removed in v43.0.
"""
from arifos_core.memory.cooling_ledger import *
