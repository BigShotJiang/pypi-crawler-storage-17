"""
arifos_core.eye_sentinel - BACKWARD COMPATIBILITY SHIM (v42)
Moved to: arifos_core/utils/eye_sentinel.py
This shim will be removed in v43.0.
"""
from arifos_core.utils.eye_sentinel import *
