"""
arifos_core.runtime_types - BACKWARD COMPATIBILITY SHIM (v42)
Moved to: arifos_core/utils/runtime_types.py
This shim will be removed in v43.0.
"""
from arifos_core.utils.runtime_types import *
