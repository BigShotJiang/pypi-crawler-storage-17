"""
arifos_core.ignition - BACKWARD COMPATIBILITY SHIM (v42)
Moved to: arifos_core/system/ignition.py
This shim will be removed in v43.0.
"""
from arifos_core.system.ignition import *
