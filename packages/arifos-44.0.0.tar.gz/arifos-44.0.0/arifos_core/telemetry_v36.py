"""
arifos_core.telemetry_v36 - BACKWARD COMPATIBILITY SHIM (v42)
Moved to: arifos_core/utils/telemetry_v36.py
This shim will be removed in v43.0.
"""
from arifos_core.utils.telemetry_v36 import *
