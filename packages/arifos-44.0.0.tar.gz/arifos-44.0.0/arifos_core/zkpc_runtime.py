"""
arifos_core.zkpc_runtime - BACKWARD COMPATIBILITY SHIM (v42)
Moved to: arifos_core/governance/zkpc_runtime.py
This shim will be removed in v43.0.
"""
from arifos_core.governance.zkpc_runtime import *
