"""
arifos_core.fag - BACKWARD COMPATIBILITY SHIM (v42)
Moved to: arifos_core/governance/fag.py
This shim will be removed in v43.0.
"""
from arifos_core.governance.fag import *
