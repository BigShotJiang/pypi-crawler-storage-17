"""
arifos_core.runtime_manifest - BACKWARD COMPATIBILITY SHIM (v42)
Moved to: arifos_core/system/runtime_manifest.py
This shim will be removed in v43.0.
"""
from arifos_core.system.runtime_manifest import *
