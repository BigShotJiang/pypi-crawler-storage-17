"""
arifos_core.llm_interface - BACKWARD COMPATIBILITY SHIM (v42)
Moved to: arifos_core/integration/adapters/llm_interface.py
This shim will be removed in v43.0.
"""
from arifos_core.integration.adapters.llm_interface import *
