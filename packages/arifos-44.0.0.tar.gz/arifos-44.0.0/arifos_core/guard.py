"""
arifos_core.guard - BACKWARD COMPATIBILITY SHIM (v42)
Moved to: arifos_core/integration/guards/guard.py
This shim will be removed in v43.0.
"""
from arifos_core.integration.guards.guard import *
