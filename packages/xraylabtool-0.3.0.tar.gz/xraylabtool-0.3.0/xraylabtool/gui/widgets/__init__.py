"""Custom widgets for the XRayLabTool GUI."""
