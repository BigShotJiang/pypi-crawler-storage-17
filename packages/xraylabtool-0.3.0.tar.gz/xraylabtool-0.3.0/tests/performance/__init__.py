"""Performance and benchmark tests for XRayLabTool."""
