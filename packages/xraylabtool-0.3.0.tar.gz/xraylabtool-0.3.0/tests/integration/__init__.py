"""Integration tests for XRayLabTool workflows."""
