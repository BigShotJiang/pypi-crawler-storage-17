"""
Perform compatability setup for python version 3.10
"""


import typing, typing_extensions

typing.Self = typing_extensions.Self