"""Unit tests for generic_units."""


class TestGenericunits:
    """Unit tests for generic_units."""
