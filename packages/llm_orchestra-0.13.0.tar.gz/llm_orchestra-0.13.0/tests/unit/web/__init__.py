"""Tests for the web module."""
