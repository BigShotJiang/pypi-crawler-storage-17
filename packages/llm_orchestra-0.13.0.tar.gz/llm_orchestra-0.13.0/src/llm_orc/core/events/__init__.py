"""Event system for llm-orc with Pydantic validation."""
