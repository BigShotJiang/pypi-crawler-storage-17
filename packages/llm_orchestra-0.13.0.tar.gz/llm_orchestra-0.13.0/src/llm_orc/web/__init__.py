"""Web UI module for llm-orc ensemble management."""

from llm_orc.web.server import create_app

__all__ = ["create_app"]
