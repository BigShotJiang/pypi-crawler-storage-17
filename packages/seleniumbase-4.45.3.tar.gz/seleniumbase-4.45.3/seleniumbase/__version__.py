# seleniumbase package
__version__ = "4.45.3"
