# Scripts
In this folder you can find a collection of scripts that I found useful for my own dev env.
