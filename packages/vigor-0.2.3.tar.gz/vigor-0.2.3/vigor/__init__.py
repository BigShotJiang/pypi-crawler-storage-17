"""vigor - A collection of useful Python scripts and CLI tools."""

__version__ = "0.2.3"
__author__ = "Ryan Liu <ryan@ryanliu6.xyz>"
