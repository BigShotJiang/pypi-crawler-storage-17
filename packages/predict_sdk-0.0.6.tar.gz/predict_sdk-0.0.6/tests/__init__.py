"""Tests for the Predict SDK."""
