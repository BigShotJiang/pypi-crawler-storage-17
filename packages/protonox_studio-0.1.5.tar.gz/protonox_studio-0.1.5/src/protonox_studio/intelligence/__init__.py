"""Intelligence analyzers used by the Protonox Studio engine."""
