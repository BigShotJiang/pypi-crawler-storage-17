__version__ = "0.0.8"
from .postfix import usearch_fix
usearch_fix()
from .core import *
from .data import *
from .utils import *
