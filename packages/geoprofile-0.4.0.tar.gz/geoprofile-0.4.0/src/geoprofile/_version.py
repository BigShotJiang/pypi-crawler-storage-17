"""Defines the (semantic) module version"""

__version__ = "0.4.0"
