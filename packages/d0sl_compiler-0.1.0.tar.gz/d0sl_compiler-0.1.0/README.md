# D0SL compiler

Delta zero semantic language (aka d0sl) is a next generation of so called Business Rules Engines (BRE). Just like regular BRE’s d0sl allows you to implement business logic of your system by using declarative logical specifications language.

## Official page is https://d0sl.org/

