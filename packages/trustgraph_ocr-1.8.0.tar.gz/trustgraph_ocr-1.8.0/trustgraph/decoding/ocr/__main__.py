#!/usr/bin/env python3

from . pdf_decoder import run

if __name__ == '__main__':
    run()

