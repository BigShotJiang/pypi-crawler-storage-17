import multiprocessing
from .cli import main

if __name__ == "__main__":
    multiprocessing.freeze_support()  # need for pyinstaller
    main()