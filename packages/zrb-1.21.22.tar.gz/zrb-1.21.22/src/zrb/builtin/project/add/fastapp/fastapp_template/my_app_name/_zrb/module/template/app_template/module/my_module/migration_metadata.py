from sqlalchemy import MetaData

metadata = MetaData()
