"""ONE Campaign Python project utilities."""

__version__ = "0.2.0"
