"""
ABI-CLI: Command line interface for ABI Framework
Provides project scaffolding and management tools
"""

__version__ = "1.1.0"