"""
Configuration templates for ABI projects
"""