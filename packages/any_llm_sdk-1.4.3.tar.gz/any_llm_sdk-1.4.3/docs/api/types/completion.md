## Completion Types

Data models and types for completion operations.

::: any_llm.types.completion
