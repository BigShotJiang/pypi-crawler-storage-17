from django.contrib import admin

from core.models import SiteProfile

admin.site.register(SiteProfile)
