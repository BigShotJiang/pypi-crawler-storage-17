from enum import StrEnum


class SystemType(StrEnum):
    CRM = "crm"
    LOGIS = "logis"
