from enum import Enum


class PassTimeOfDate(str, Enum):
    DAY = "DAY"
    NIGHT = "NIGHT"
