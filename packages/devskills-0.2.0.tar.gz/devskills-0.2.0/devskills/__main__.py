"""Entry point for running the devskills MCP server."""

from .cli import main

if __name__ == "__main__":
    main()
