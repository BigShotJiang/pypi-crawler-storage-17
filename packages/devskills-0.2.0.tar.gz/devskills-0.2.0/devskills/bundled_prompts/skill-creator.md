---
name: skill-creator
description: Create a new devskills skill with proper structure
---

I want to create a new skill. Use devskills to get the skill-creator skill and follow its instructions exactly.
