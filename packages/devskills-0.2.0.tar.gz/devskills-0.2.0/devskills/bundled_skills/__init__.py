"""Bundled skills that ship with the devskills package."""
