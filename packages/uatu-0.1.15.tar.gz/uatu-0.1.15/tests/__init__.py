"""Tests for Uatu."""
