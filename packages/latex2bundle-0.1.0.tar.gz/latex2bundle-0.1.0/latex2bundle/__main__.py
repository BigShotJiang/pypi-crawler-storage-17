from .cli import main


def _main():
    main()


if __name__ == "__main__":
    _main()
