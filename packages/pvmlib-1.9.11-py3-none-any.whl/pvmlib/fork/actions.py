class Actions:
    POST = "POST"
    GET = "GET"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
