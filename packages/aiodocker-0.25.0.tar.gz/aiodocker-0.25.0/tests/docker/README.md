Used to test build images functions.

# Dockerfile
Used for test `test_build_from_remote_file` inside `tests/test_images.py`

# docker_context.tar
Used for test `test_build_from_remote_tar` inside `tests/test_images.py`
