Exceptions
==========

.. autoclass:: aiodocker.exceptions.DockerError
    :members:
    :undoc-members:
