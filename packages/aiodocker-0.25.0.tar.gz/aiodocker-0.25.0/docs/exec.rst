Exec
====

.. autoclass:: aiodocker.execs.Exec
    :members:
    :undoc-members:
