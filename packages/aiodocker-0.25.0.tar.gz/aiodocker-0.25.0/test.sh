#! /bin/bash
# Assumes being executed inside the venv.
python3 -m pytest "$@"
