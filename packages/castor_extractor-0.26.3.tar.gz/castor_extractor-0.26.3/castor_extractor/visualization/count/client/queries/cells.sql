SELECT
    key,
    canvas_key,
    name,
    type,
    connection_key
FROM `{project_id}.{dataset_id}.cells`

