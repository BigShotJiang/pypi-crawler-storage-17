# Aifoundary

**Enterprise AI Compliance Toolkit with PII Detection and Secure RAG Guardrails**

<<<<<<< HEAD
Development
Bashpip install -e .[dev]
pytest
## Deterministic RAG Governance

Aifoundary enforces Retrieval-Augmented Generation using policy-as-code.

### Features
- Prompt injection blocking
- PII detection & redaction
- Multi-context grounding checks
- Explainable coverage failures
- Auto-rewrite + guarded retry
- Signed audit logs
- CI/CD gateable decisions

### Quick demo
```bash
aifoundary rag-check --json prompt.txt context.txt || exit 1


In `pyproject.toml`:

```toml
version = "1.0.1"
=======
Aifoundary is a production-ready Python library designed to help teams deploy AI systems safely in regulated environments. It focuses on **data protection, decision transparency, and retrieval-augmented generation (RAG) safety**.

The library is framework-agnostic and can be integrated into existing AI pipelines without replacing your models or infrastructure.

---

## Key Capabilities

- **PII Detection**
  - Hybrid detection using deterministic rules and ML-based entity recognition
  - Designed for logs, prompts, documents, and model inputs

- **Secure RAG Validation**
  - Guards against unsafe context injection
  - Ensures retrieved documents comply with policy constraints
  - Prevents accidental data leakage in generation flows

- **Audit-First Design**
  - Deterministic behavior
  - Clear failure modes
  - Designed to integrate with enterprise audit and governance systems

- **Minimal, Explicit API**
  - No hidden side effects
  - No model hosting
  - No vendor lock-in

---

## Installation

```bash
pip install aifoundary
Optional FAISS Support (Linux recommended)
bash
Copy code
pip install "aifoundary[faiss]"
Note: FAISS requires native compilation and may not install on macOS.

Command Line Interface
Aifoundary includes a lightweight CLI for validation and diagnostics.

bash
Copy code
aifoundary doctor
aifoundary scan sample.txt
aifoundary rag-check prompt.txt context.txt
Intended Use Cases
AI compliance and governance teams

Regulated industries (fintech, healthcare, enterprise SaaS)

Secure RAG pipelines

Internal AI platform teams

Author
Chandan Galani
Email: galanichandan@gmail.com
Phone: +91-9326176427

License
Apache 2.0
>>>>>>> 152c6d9 (v1.0.1: policy-as-code, explainable RAG, audit chain, simulation mode)
