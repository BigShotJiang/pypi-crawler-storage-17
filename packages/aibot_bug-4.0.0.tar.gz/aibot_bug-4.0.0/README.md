# 🤖 AIbot-bug: Beast Mode 4.0 - Ultimate AI Bug Bounty Orchestrator

AIbot-bug is a professional-grade reconnaissance and vulnerability discovery framework. It merges the raw power of industry-standard security tools with a sophisticated, multi-provider AI brain capable of rotating through 117+ models for autonomous analysis, validation, and exploit generation.

## 🌟 Core Pillars

### 🧠 Multi-AI Cognitive Engine
*   **13+ Providers:** Integrated support for Gemini, OpenAI, Claude, xAI, Groq, DeepSeek, Mistral, HuggingFace, Qwen, and more.
*   **9 Models Per Provider:** Access to 117+ specialized models for speed, context, or reasoning.
*   **Auto-Rotation:** Intelligent self-healing that switches providers upon rate-limit (429) or quota detection.

### 🤖 Robotic Automation Lab (Beast 4.0)
*   **20 Advanced Robotic Modules:** Including 403 Bypassers, JS Parameter Miners, Broken Link Checkers, and CVE Searchers.
*   **Intelligent Simulation:** Uses AI heuristics to simulate tool logic for high-fidelity discovery.

### ✅ Strong Validation & Anti-FP
*   **Robotic Deduplication:** Hash-based filtering to ensure unique results across all tools.
*   **AI False Positive Check:** Automatic verification of findings to reduce noise and highlight valid vulnerabilities.

### 📊 Clean UI & Structured Logging
*   **Itemized Menu (1-31):** A professional, numbered interface for all core and advanced features.
*   **Strict Stream Separation:** Console output is limited to clean INFO/Monitoring logs, while errors/warnings are captured in `automation.log`.

---

## 🚀 Getting Started

### 1. Installation

#### Via PIP (Recommended)
```bash
pip install aibot-bug
```

#### Via GitHub (Development)
```bash
# Clone the repository
git clone https://github.com/Lifejiggy/AIbot-bug.git
cd AIbot-bug && aibot_bug
pip install -e .
```


### 2. Configuration
Populate the `.env` file with your API keys. The tool supports manual key entry if environmental variables are missing.
```env
GEMINI_API_KEY=your_key
OPENAI_API_KEY=your_key
ANTHROPIC_API_KEY=your_key
...
```

### 3. Usage
If installed via pip, you can run the tool globally:
```bash
aibot-bug
```

Or run the local script:
```bash
python aibot_bug/main.py 
or
python main.py
```


---

## 🛠️ Feature Matrix

| Feature Category | Description |
| :--- | :--- |
| **Monitored Recon** | Parallel execution of 8+ Subdomain and 4+ Directory tools with live status. |
| **Exploit Intelligence** | AI-driven Payload Generation, Exploit Explanation, and Command Generation. |
| **Automation Hub** | 19+ AI Modules for Threat Modeling, Wordlist Generation, and Code Completion. |
| **Robotic Lab** | 20 New "Beast 4.0" features for deep, automated technical analysis. |
| **Report Engine** | Convert raw findings into Professional Executive Summaries. |

---

## 🔒 Security & Law
Usage of AIbot-bug for attacking targets without prior mutual consent is illegal. It is the end user's responsibility to obey all applicable local, state, and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program.

---
**Created by ArkhAngelLifeJiggy**
