This ideas for quality controls that are not yet implemented, when implemented they should be removed from this list.

1. Education is usually only taken in persons life before they are 80. If a person keeps educating themselves for 50+ years at the same level, that is unusal
2. Sammenlign antall rader over årganger (over periodisering i filnavn), stor endring utenfor forventninger av variasjon meldes
3. Koblinger mot register på visse identer for gyldighetskontroller (person- og organisasjonsidenter)
4. Lagre beskrivende statistikk (df.describe()) for sammenligning over årganger (over periodisering i filnavn), avvik meldes
2. None are born before 1850 in our data, and they should not be born in the future.
3.
