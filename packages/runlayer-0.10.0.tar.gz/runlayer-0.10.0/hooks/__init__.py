"""Cursor hooks for Runlayer integration."""
