"""Entry point for Tima - imports from app_flet for backward compatibility."""
from tima_timer.app_flet import main

__all__ = ['main']
