"""
Tima - Activity Timer
A desktop productivity timer that cycles through your projects.
"""

__version__ = "2.0.1"
__author__ = "Amir Rosenfeld"

from tima_timer.app_flet import main

__all__ = ['main']
