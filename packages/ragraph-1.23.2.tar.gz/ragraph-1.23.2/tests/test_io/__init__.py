"""Tests for the IO module."""
