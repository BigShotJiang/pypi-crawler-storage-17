"""# Graph analysis"""

from logging import getLogger

logger = getLogger("ragraph.analysis")
"""Logger for the graph analysis module."""
