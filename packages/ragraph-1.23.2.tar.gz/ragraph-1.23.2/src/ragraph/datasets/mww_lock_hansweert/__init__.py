"""Multi-WaterWerk project waterway lock 'Hansweert'"""

edge_weights = [
    "energy",
    "information",
    "location",
    "spatial",
]
