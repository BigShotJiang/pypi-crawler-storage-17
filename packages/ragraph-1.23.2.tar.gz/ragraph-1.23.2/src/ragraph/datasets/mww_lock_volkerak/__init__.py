"""Multi-WaterWerk project waterway lock 'Volkerak'"""
