"""A small example concerning a centrigal pump and its drive mechanism."""
