::: ragraph.generic
