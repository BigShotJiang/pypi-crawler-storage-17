"""sysmon - System Monitor for GPU, CPU, Memory, and Disk"""
__version__ = "0.1.0"
