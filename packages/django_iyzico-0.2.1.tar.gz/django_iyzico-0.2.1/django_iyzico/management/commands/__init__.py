"""
Management commands for django-iyzico package.
"""
