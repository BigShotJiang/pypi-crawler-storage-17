# Typed Binanceusdm

> A fully typed, validated async client for the Binanceusdm API

Use *autocomplete* instead of documentation.

🚧 Under construction.