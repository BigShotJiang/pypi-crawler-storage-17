"""
### Typed Binanceusdm
> A fully typed, validated async client for the Binanceusdm API

- Details
"""