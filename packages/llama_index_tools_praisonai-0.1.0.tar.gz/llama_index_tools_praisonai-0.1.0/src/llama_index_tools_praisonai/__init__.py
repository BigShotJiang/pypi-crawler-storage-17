"""LlamaIndex tool integration for PraisonAI multi-agent framework."""

from llama_index_tools_praisonai.tools import PraisonAIToolSpec

__all__ = ["PraisonAIToolSpec"]

__version__ = "0.1.0"
