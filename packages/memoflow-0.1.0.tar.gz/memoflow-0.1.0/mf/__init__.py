"""MemoFlow - Your Second Brain"""

__version__ = "0.1.0"
