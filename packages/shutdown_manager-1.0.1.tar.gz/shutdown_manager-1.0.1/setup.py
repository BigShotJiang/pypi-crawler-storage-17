from setuptools import setup, find_packages

setup(
    name="shutdown-manager",
    version="1.0.1",
    description="Safe and flexible shutdown manager for threads, processes, and asyncio tasks",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Your Name",
    author_email="your.email@example.com",
    url="https://github.com/yourusername/shutdown-manager",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        # Optional dependencies
        "psutil>=5.9.0"
    ],
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
