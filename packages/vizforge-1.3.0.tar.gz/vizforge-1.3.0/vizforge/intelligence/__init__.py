"""
VizForge Intelligence Layer

Smart automation features with ZERO API costs.
Part of VizForge v1.2.0 - ULTRA Intelligence features.
"""

from .chart_selector import ChartSelector, DataProfile
from .data_profiler import DataProfiler, DataQualityScorer
from .insights_engine import InsightsEngine, Insight
from .color_optimizer import ColorOptimizer
from .recommendation import RecommendationEngine

# NEW v1.2.0 - Pattern Detection
from .pattern_detector import (
    PatternDetector,
    Pattern,
    PatternType,
    detect_patterns,
    get_pattern_summary
)

# NEW v1.2.0 - Enhanced Auto-Insights
from .insights_advanced import (
    EnhancedInsightsEngine,
    InsightReport
)

# NEW v1.2.0 - Smart Chart Recommender v2
from .chart_recommender_v2 import (
    SmartChartRecommender,
    ChartRecommendation,
    ChartCategory,
    ChartType,
    recommend_chart,
    get_recommendation_report
)

__all__ = [
    # v1.0.0 Intelligence
    'ChartSelector',
    'DataProfile',
    'DataProfiler',
    'DataQualityScorer',
    'InsightsEngine',
    'Insight',
    'ColorOptimizer',
    'RecommendationEngine',

    # NEW v1.2.0 - Pattern Detection
    'PatternDetector',
    'Pattern',
    'PatternType',
    'detect_patterns',
    'get_pattern_summary',

    # NEW v1.2.0 - Enhanced Auto-Insights
    'EnhancedInsightsEngine',
    'InsightReport',

    # NEW v1.2.0 - Smart Chart Recommender v2
    'SmartChartRecommender',
    'ChartRecommendation',
    'ChartCategory',
    'ChartType',
    'recommend_chart',
    'get_recommendation_report',
]
