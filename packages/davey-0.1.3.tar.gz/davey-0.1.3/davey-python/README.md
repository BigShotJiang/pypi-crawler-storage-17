# Davey!

[![PyPI version](https://img.shields.io/pypi/v/davey?maxAge=3600)](https://pypi.org/project/davey/) [![PyPI supported python versions](https://img.shields.io/pypi/pyversions/davey?maxAge=3600)](https://pypi.org/project/davey/) [![discord chat](https://img.shields.io/discord/311027228177727508?logo=discord&logoColor=white&color=5865F2)](https://snaz.in/discord)

A [Discord Audio & Video End-to-End Encryption (DAVE) Protocol](https://daveprotocol.com/) implementation using [OpenMLS](https://openmls.tech/).

> Proper usage documentation does not exist yet.