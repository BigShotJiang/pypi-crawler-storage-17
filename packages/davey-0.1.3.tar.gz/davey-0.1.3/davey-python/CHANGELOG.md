# Changelog

All notable changes to this project will be documented in this file.

## Unreleased

## 0.1.2 - 2025-12-19

Support for H265, VP8, Vp9 and AV1 encryption.

## 0.1.2 - 2025-11-17

Fixes an issue with enabling passthrough mode and sets the expiry properly.

## 0.1.1 - 2025-09-23

Support for H264 encryption.

## 0.1.0 - 2025-09-08

Initial release.