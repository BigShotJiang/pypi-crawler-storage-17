# -*- coding: utf-8 -*-
"""clox modules."""
from clox.params import CLOX_VERSION
__version__ = CLOX_VERSION
