# -*- coding: utf-8 -*-
"""clox main."""
from .functions import main


if __name__ == "__main__":
    main()
