# Core Developers
----------
- [@sepandhaghighi](http://github.com/sepandhaghighi)

# Other Contributors
----------
- [@boreshnavard](https://github.com/boreshnavard) **
- [@sadrasabouri](https://github.com/sadrasabouri)


** Graphic designer