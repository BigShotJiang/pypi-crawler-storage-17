"""Test suite for netrun-cors package."""
