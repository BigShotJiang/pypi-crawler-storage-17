# -*- coding: utf-8 -*-
"""Init and utils."""

from zope.i18nmessageid import MessageFactory

import logging


_ = MessageFactory('imio.annex')
logger = logging.getLogger('imio.annex')
