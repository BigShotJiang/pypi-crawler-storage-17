from enum import Enum


class Asset(Enum):
    USD = "usd"
    BTC = "btc"
    ETH = "eth"
