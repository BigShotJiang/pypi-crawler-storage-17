from enum import Enum


class OrderType(Enum):
    LIMIT = "limit"
    MARKET = "market"
