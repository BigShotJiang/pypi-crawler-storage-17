"""LangExtract provider plugin for OpenRouter."""

from langextract_openrouter.provider import OpenRouterProvider

__all__ = ['OpenRouterProvider']
__version__ = "0.1.1"
