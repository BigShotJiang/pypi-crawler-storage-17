"""
Thin adapters to capture receipts where incidents live.

These modules are dependency-light and use optional imports so Fabra can
ship without forcing orchestration/framework dependencies.
"""
