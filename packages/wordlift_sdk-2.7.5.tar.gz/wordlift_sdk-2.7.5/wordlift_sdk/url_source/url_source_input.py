from dataclasses import dataclass
from typing import Optional, List, Union

from google.auth.credentials import Credentials
from gspread import Client

