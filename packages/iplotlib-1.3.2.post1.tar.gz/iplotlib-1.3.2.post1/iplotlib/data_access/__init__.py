"""
Real-time streaming infrastructure for iplotlib.
"""

from .streamer import CanvasStreamer

__all__ = ["CanvasStreamer"]
