"""
The matplotlib backend.
"""
