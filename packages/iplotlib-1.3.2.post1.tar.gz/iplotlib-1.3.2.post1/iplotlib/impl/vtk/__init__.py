"""
The VTK backend.
"""

from iplotlib.impl.vtk.vtkCanvas import VTKParser

__all__ = ['VTKParser']
