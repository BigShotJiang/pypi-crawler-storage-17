"""
The GUI classes that come with iplotlib.
"""
