"""
The Qt interface for iplotlib. It is implemented with PySide2
"""
