"""
Utility classes and functions used in the iplotlib Qt framework.
"""
