"""
Infrastructure for writting tests with a full blown Qt Application involving interaction and event processing
"""

from .qAppTestAdapter import QAppTestAdapter

__all__ = ['QAppTestAdapter']
