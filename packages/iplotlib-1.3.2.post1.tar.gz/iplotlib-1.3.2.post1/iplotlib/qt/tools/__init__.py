"""
This module is unused and deprecated.
"""
