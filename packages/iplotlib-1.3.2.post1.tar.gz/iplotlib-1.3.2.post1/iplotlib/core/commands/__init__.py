"""
Concrete command infrastructure for iplotlib.
"""