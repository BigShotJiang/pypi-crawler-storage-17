from cycode.cli.consts import PROGRAM_NAME
from cycode.cli.main import app

app(prog_name=PROGRAM_NAME)
