---
title: Highlight entry types with emoji styling
type: feature
authors:
- codex
created: 2025-10-23
---

Adds a dedicated 💥 *Breaking changes* section ahead of other categories,
switches feature highlights to 🚀, and keeps those emoji prefixed headings in
Markdown and JSON exports unless you toggle them off with `--no-emoji`.
