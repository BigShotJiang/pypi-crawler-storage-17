---
title: Drop implicit project metadata
type: change
authors:
- mavam
- codex
created: 2025-10-21
---

Entry files no longer store the project key; the CLI infers it from config.
