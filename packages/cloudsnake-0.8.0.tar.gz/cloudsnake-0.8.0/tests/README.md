# TESTS

* Testing typer cli: https://typer.tiangolo.com/tutorial/testing/
* Testing AWS functions: https://github.com/getmoto/moto
