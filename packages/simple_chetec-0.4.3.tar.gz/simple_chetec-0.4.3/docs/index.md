# Stellar Interpretation for Meteoritic data and PLotting (for Everyone) - SIMPLE

We are inching ever closer to the first release of SIMPLY. Once we get there this will be replaced with 
something more descriptive.