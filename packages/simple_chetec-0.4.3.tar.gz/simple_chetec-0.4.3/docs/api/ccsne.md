# The `simple.ccsne` Namespace

The *ccsne* submodule contains everything related to working with CCSNe models. 

---

::: simple.ccsne