# The `simple.norm` Namespace

The *norm* submodule contains everything related to the different normalisation schemes.

---

::: simple.norm