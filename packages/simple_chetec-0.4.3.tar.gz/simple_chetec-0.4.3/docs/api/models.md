# The `simple.models` Namespace

The *models* submodule contains everything pertaining the primary object structure which keeps track of different
models.

---

::: simple.models
    options:
        show_root_heading: false
        show_root_members_full_path: true
        show_root_toc_entry: false