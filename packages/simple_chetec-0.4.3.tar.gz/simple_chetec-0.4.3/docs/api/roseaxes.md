# The `simple.roseaxes` Namespace

This contains the `RoseAxes` class and its utility functions.

---

::: simple.roseaxes