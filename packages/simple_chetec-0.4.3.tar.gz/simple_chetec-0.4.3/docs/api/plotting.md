# The `simple.plotting` Namespace

The *plotting* submodule contains everything related to data visualisation.

Matplotlib is used as the foundation for all plotting and this library can be used to further customise the plots here,
for example via the `plt` object.

---

::: simple.plotting