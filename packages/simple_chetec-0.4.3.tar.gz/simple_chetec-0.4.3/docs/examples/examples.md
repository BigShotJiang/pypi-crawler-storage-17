# Example notebooks

This page is not shown on the website. 

Instead, link directly to the examples in the ``mkdocs.yml`` file. 

The notebooks from the ./notebooks/ folder are automatically copied to 
./docs/examples/. and can be linked using ``example/<name>.ipynb``
