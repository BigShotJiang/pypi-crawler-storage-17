# -*- coding: utf-8 -*-
"""
Created on 2021/6/18 10:36 上午
---------
@summary:
---------
@author: Boris
@email: boris_liu@foxmail.com
"""

from feapder.utils.log import log

log.debug("debug")
log.info("info")
log.success("success")
log.warning("warning")
log.error("error")
log.critical("critical")
log.exception("exception")