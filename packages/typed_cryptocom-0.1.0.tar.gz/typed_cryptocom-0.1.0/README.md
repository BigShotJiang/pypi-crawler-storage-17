# Typed Cryptocom

> A fully typed, validated async client for the Cryptocom API

Use *autocomplete* instead of documentation.

🚧 Under construction.