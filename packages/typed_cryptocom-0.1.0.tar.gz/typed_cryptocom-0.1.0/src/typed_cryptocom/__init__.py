"""
### Typed Cryptocom
> A fully typed, validated async client for the Cryptocom API

- Details
"""