from pypulsar.cli import app
app()