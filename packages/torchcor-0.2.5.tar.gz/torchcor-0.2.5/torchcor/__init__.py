import torch
from torchcor.device import set_device, get_device
float32 = torch.float32
float64 = torch.float64