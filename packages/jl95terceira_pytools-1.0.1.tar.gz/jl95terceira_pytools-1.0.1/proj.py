import os.path

PATH      = os.path.split(__file__)[0]
TOOLS_DIR = 'jl95-pytools'
TOOLS_DIR_DEPRECATED = 'jl95terceira-pytools'