ALL_LABELS = ["*"]
ALL_TYPES = ["*"]
