from graphdatascience.procedure_surface.api.catalog.scaler_config import ScalerConfig

__all__ = ["ScalerConfig"]
