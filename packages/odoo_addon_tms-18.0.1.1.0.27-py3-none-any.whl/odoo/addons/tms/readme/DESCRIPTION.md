The Transport Management Systems (TMS) module manages the workflow of creating transport
operations within Odoo. This module provides features such as creating teams, stages,
crews, routes, and vehicles, allowing businesses to efficiently handle various aspects
of their transport operations.
