"""CLI for census-lookup."""

from census_lookup.cli.commands import cli

__all__ = ["cli"]
