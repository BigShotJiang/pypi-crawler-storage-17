from f4enix.input.ww_gvr.cli import Menu

if __name__ == "__main__":
    Menu()
