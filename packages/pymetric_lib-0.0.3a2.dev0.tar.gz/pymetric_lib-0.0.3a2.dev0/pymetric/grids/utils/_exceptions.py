class GridInitializationError(Exception):
    """Exception raised when grid initialization fails."""

    pass
