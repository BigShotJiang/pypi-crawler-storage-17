"""
Differential geometry operations on sparse tensor field representations.

.. important::

    Support for sparse tensor representations is not yet implemented.

"""
