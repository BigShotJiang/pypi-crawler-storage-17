:orphan:

Auxiliary Modules: Differential Geometry
========================================

These examples showcase some of the low-level functions from the
:mod:`differential_geometry` module.

.. warning::

    In general, direct use of :mod:`differential_geometry` introduces much more
    complexity than using equivalent functions at the level of fields or grids.
