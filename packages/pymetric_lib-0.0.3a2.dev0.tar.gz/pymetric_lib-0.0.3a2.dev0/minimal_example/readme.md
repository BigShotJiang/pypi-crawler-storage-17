## Minimal Example

---

This directory contains a couple of Jupyter notebooks which demonstrate the
basic capabilities of the code base. Each will attempt to install the package from
the local source code and then run the example.

For more detailed examples and tutorials, please refer to the
[docs](https://pisces-project.github.io/PyMetric/dev/auto_examples/index.html).
