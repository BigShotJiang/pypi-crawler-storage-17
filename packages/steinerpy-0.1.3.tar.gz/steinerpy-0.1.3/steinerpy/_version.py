"""Version information for SteinerPy."""

__version__ = "0.1.3"
