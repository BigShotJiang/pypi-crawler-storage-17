# These modules are sorted by calling sequence, i.e. mail_thread calls
# mail_message, etc.
from . import res_company
from . import mail_template
from . import mail_thread
from . import mail_message
from . import ir_mail_server
from . import mail_mail
