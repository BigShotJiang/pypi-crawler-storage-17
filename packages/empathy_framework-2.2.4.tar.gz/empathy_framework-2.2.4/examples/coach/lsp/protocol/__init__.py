"""
LSP Protocol Extensions
Custom protocol definitions for Coach
"""

__version__ = "1.0.0"
