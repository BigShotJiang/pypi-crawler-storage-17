def hello(name: str):
    return f"Hello, {name}!"