"""
Builds Go Lambda functions using standard Go tooling
"""

from .workflow import GoModulesWorkflow
