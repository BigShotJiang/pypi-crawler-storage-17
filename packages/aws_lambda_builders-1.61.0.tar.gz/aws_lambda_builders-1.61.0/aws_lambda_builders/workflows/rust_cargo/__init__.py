"""
Builds Rust Lambda functions using Cargo Lambda
"""

from .workflow import RustCargoLambdaWorkflow
