from __future__ import annotations

from bfabric.entities.core.entity import Entity


class Plate(Entity):
    ENDPOINT = "plate"
