"""Run textual_logging demo when executed as a module."""

from .demo import main

if __name__ == "__main__":
    main()
