# think

A machine-learnable version of the python object system, with support for one-shot learning.

