from delta.drive.interfaces.i_drive import IDrive

__all__ = [
    'IDrive'
]
