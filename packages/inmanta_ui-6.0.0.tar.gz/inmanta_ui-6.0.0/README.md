# inmanta-ui
Inmanta UI extension for hosting the console
