lambda x: x
lambda x: x if True else y
lambda x: await x
lambda x: lambda y: x + y
lambda x: (yield x)  # Parenthesized `yield` is fine
lambda x: x, *y
