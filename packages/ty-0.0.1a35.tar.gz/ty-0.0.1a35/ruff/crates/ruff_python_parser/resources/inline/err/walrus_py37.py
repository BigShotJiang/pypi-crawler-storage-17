# parse_options: { "target-version": "3.7" }
(x := 1)
