def foo[T1, *T2(a, b):
    return a + b
x = 10
