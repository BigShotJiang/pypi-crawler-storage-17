type X[*Ts =] = int
type X[*Ts =, T2] = int
