class __debug__: ...  # class name
class C[__debug__]: ...  # type parameter name
