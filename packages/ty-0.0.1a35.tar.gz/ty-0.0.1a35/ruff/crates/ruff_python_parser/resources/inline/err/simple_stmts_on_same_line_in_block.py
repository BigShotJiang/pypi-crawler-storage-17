if True: break; continue pass; continue break
