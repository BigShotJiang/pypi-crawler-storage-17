# parse_options: {"mode": "ipython"}
with (a, ?b)
?
