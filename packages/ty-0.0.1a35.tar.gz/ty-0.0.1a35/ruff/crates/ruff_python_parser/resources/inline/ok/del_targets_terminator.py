del a, b; c, d
del a, b
c, d
