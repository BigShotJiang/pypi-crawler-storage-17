# parse_options: {"target-version": "3.8"}
# before 3.9, only emit the parse error, not the unsupported syntax error
lst[x:=1:-1]
