type X[*T: int] = int
