class Foo[T1, *T2(a, b):
    pass
x = 10
