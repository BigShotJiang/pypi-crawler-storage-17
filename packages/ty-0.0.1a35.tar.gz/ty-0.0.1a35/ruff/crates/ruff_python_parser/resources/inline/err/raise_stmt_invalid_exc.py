raise *x
raise yield x
raise x := 1
