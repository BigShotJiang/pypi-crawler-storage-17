if x
if x
    pass
a = 1
