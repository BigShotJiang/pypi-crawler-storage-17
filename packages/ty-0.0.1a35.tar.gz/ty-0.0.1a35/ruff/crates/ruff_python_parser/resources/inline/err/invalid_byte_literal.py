b'123a𝐁c'
rb"a𝐁c123"
b"""123a𝐁c"""
