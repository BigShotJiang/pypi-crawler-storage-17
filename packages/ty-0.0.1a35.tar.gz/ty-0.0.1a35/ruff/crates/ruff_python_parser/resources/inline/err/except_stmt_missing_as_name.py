try:
    pass
except Exception as:
    pass
except Exception as
    pass
