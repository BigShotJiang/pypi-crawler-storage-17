match
match != foo
(foo, match)
[foo, match]
{foo, match}
match;
match: int
match,
match.foo
match / foo
match << foo
match and foo
match is not foo
