# parse_options: { "target-version": "3.10" }
match 2:
    case 1:
        pass
