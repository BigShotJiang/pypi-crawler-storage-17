# parse_options: {"target-version": "3.14"}
try:
    pass
except x, y:
    pass
try:
    pass
except* x, y:
    pass
