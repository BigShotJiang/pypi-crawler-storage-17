global ,
global x,
global x, y,
