'hello \N{INVALID} world'
"""hello \N{INVALID} world"""
