raise x from y,
raise x from y, z
