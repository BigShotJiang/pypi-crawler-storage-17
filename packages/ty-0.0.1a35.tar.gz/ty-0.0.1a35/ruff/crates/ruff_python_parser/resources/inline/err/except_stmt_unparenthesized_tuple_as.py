try:
    pass
except x, y as exc:
    pass
try:
    pass
except* x, y as eg:
    pass
