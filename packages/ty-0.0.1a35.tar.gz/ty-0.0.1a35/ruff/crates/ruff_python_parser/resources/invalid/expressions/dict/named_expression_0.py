# Unparenthesized named expression not allowed in key

{x := 1: y, z := 2: a}

x + y