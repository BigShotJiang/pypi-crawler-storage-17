extra..dot
multiple....dots
multiple.....dots
