# Missing orelse expression, followed by a statement
x if expr else

def foo():
    pass