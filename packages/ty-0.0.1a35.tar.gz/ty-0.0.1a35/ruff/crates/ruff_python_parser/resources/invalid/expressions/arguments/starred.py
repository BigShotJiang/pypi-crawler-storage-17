call(*data for data in iter)
call(*yield x)
call(*yield from x)
