x not in y := (1, 2)
x > y := 2