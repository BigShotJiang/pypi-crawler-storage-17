lambda a, a: 1

lambda a, *, a: 1

lambda a, a=20: 1

lambda a, *a: 1

lambda a, *, **a: 1
