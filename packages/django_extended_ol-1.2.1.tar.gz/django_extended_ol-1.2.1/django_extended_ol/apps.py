from django.apps import AppConfig


class OlwidgetConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_extended_ol"
    label = "olwidget"
