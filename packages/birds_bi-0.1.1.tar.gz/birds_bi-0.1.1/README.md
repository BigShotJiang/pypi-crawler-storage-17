# bi-model-helper

A BI helper library template.
