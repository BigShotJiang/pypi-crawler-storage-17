"""
FortiOS Log FortiCloud API Module
"""

from .forticloud import FortiCloud

__all__ = ["FortiCloud"]
