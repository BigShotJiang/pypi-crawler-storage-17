"""
FortiOS Service - Packet Sniffer
Packet capture service endpoints
"""

from .sniffer import Sniffer

__all__ = ["Sniffer"]
