"""Schema validation utilities for dbsync-py.

This module provides utilities to validate model definitions against
the official Cardano DB Sync schema.
"""
