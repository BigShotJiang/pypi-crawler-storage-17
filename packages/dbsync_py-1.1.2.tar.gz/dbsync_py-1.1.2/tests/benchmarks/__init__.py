"""Benchmarking tests for dbsync-py package.

This module contains performance benchmarks for database operations,
model instantiation, and query patterns.
"""
