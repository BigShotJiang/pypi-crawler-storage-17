"""
Test package for dbsync-py.

This package contains all test modules for the dbsync-py library.
"""

__version__ = "0.1.0"
