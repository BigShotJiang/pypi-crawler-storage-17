#!/usr/bin/env python3
"""CLI module entry point for direct execution."""

from .main import main

if __name__ == "__main__":
    main()
