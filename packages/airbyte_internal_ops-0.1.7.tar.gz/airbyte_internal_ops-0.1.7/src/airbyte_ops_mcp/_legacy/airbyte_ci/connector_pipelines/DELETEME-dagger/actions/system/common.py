# #
# # Copyright (c) 2023 Airbyte, Inc., all rights reserved.
# #

# from typing import List

# from dagger import Container


# def with_debian_packages(base_container: Container, packages_to_install: List[str]) -> Container:
#     """Installs packages using apt-get.
#     Args:
#         context (Container): A alpine based container.

#     Returns:
#         Container: A container with the packages installed.

#     """
#     update_packages_command = ["apt-get", "update"]
#     package_install_command = ["apt-get", "install", "-y"]
#     return base_container.with_exec(update_packages_command).with_exec(package_install_command + packages_to_install)
