# Foobar Migration Guide

## Upgrading to 1.0.0

This is something
