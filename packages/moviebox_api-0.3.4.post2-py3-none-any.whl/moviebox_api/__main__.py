from moviebox_api.cli.interface import main

main()
