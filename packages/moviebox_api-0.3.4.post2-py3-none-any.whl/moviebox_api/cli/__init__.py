"""Commandline module"""

from moviebox_api.cli.downloader import Downloader

__all__ = ["Downloader"]
