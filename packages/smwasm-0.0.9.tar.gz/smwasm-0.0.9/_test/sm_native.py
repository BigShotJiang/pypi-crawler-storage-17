import os, sys

from smwasm import smh

# ------------------------------------------------------------

SM_DOMAIN = "native"


def _sm_heart_beat(dt):
    ret = {"text": dt["text"] + "--jzr003", "from": "---[python]---"}
    return ret

def _sm_heart0g_beat(dt):
    input_txt = dt['text']
    output_txt = input_txt + '---[python]---heart0g'
    ret = {'input': input_txt, 'output': output_txt}
    return ret

def register():
    fn = os.path.basename(__file__)
    print("--- file ---", fn)

    itdef_get_text1 = {"$usage": SM_DOMAIN + ".heart.beat", "text": ""}
    smh.register(itdef_get_text1, fn, _sm_heart_beat)

    itdef_get_text2 = {"$usage": SM_DOMAIN + ".heart0g.beat", "text": ""}
    smh.register(itdef_get_text2, fn, _sm_heart0g_beat)


register()


# ------------------------------------------------------------

if __name__ == "__main__":

    dtCall = {"$usage": "native.heart.beat", "text": "exa"}
    dtRet = smh.call(dtCall)
    print("--- test native heart ---", dtCall, "---", dtRet)

    dtCall = {"$usage": "native.heart0g.beat", "text": "exa"}
    dtRet = smh.call(dtCall)
    print("--- test native heart0g ---", dtCall, "---", dtRet)
