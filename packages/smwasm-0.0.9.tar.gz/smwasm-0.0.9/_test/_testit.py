import os, sys, time

def use_near():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    print("--- current directory --- ", current_dir)
    sys.path.append(os.path.join(current_dir, ".."))
#use_near()

from smwasm import smh, smu

import sm_native # type: ignore


# ------------------------------------------------------------


def book():
    wasm_path = "../../../web/fserver/data/page/sm/callicum.wasm"
    smh.load_wasm(wasm_path, 33)
    smh.load_wasm("../../../web/fserver/data/page/sm/smlibr_bg.wasm", 99)
    smh.load_wasm("../../../web/fserver/data/page/sm/smlibr2_bg.wasm", 99)


# ------------------------------------------------------------

TIMES = 10 * 10000
def test_python():
    dti = {"$usage": "native.heart.beat", "text": "uvw"}
    start = int(time.time() * 1000)
    for _i in range(TIMES):
        dt = smh.call(dti)
    stop = int(time.time() * 1000)
    print("--- test python --- {0} / {1} --- {2} ---".format(TIMES, stop - start, dt))

def test_rust():
    dti = {"$usage": "sys.get.ms"}
    start = int(time.time() * 1000)
    for _i in range(TIMES):
        dt = smh.call(dti)
    stop = int(time.time() * 1000)
    print("--- test rust --- {0} / {1} --- {2} ---".format(TIMES, stop - start, dt))

def test_wasm():
    dti = {"$usage": "smtest.heart.beat"}
    start = int(time.time() * 1000)
    for _i in range(TIMES):
        dt = smh.call(dti)
    stop = int(time.time() * 1000)
    print("--- test wasm --- {0} / {1} --- {2} ---".format(TIMES, stop - start, dt))

def test_wasm_rust():
    dti = {"$usage": "smtest.sys.beat"}
    start = int(time.time() * 1000)
    for _i in range(TIMES):
        dt = smh.call(dti)
    stop = int(time.time() * 1000)
    print("--- test wasm rust --- {0} / {1} --- {2} ---".format(TIMES, stop - start, dt))

def test_wasm_wasm_python():
    dti = {"$usage": "smtest.heart2g.beat", "text": "uvw"}
    start = int(time.time() * 1000)
    for _i in range(TIMES):
        dt = smh.call(dti)
    stop = int(time.time() * 1000)
    print("--- test wasm rust --- {0} / {1} --- {2} ---".format(TIMES, stop - start, dt))

def test():
    current = smu.current()
    print("--- start --- {0} ---".format(current))
    smh.log("--- log something ---")

    test_python()
    test_rust()
    test_wasm()
    test_wasm_rust()
    test_wasm_wasm_python()
    
    print(smh.info())

    dt = smh.call({"$usage": "native.heart.beat", "text": "abc"})
    print("--- native.heart.beat --- {0} ---".format(dt))

    call_text = """
    {
        "$usage": "icu.usage", "$log": false,
        "way": "MessageFormat",
        "locale": "de",
        "format": "At {1,time,::jmm} on {1,date,::dMMMM} ({1,date}), there was {2} on planet {0,number}.",
        "value1": 7,
        "value2": 1675261386000,
        "value3": "a disturbance in the Force"
    }
    """
    dtCall = smu.json_to_dict(call_text)
    dtRet = smh.call(dtCall)
    print("--- test wasm result ---", dtRet)

    call_text = """
    {
        "$usage": "smexample.heart.beat", "$log": false, "text": ">abc>def"
    }
    """
    dtCall = smu.json_to_dict(call_text)
    dtRet = smh.call(dtCall)
    print("--- test smexample.heart.beat ---", dtCall, "---", dtRet)

    info = smh.info()
    print("--- smh info ---", info)

    call_text = """
    {
        "$usage": "smtest.wrap.beat", "$log": false
    }
    """
    dtCall = smu.json_to_dict(call_text)
    dtRet = smh.call(dtCall)
    print("--- test wrap result 1 ---", dtCall, "---", dtRet)

    dtCall = smu.json_to_dict(call_text)
    dtRet = smh.call(dtCall)
    print("--- test wrap result 2 ---", dtCall, "---", dtRet)

    call_text = """
    {
        "$usage": "smtest.native.beat", "$log": false
    }
    """
    dtCall = smu.json_to_dict(call_text)
    dtRet = smh.call(dtCall)
    print("--- test native result ---", dtCall, "---", dtRet)

def teste():
    call_text = """
    {
        "$usage": "smker.get.all"
    }
    """
    dtCall = smu.json_to_dict(call_text)
    dtRet = smh.call(dtCall)
    print("--- get all sm ---", dtCall, "---", smu.dict_to_format_json(dtRet, 2))


if __name__ == "__main__":

    book()
    test()
    teste()
