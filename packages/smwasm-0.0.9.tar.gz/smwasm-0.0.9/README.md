cd smmo/python/smwasm

cargo clean
maturin develop
maturin develop --release

clean / del smwasm\*.pyd
maturin build --release
maturin upload -u __token__ -p <你的 API token> target/wheels/*

pip3 install --force-reinstall .

python _test/_testit.py
