# Eldar Wordle

Simple CLI Wordle game (5-letter guessing).

## Install
```bash
pip install eldar-wordle
