WORDS = [
    "apple", "grape", "house", "plane", "robot",
    "tiger", "snake", "eagle", "brick", "chair",
    "water", "bread", "smile", "dream", "light",
    "computer",  "market",  "smoke",  "horse"
]


