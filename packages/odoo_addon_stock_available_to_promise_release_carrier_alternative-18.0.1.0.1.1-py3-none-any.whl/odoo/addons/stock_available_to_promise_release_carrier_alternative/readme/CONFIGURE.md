Go to any delivery method in order to define its alternative delivery methods.

At release, a new carrier might be selected among alternative carriers.
This has to comply with a few rules, such as carrier max weight and volume.
You also can add extra rules by editing a delivery method's Picking Domain.
