"""
MoFox Plugin Dev Toolkit

一个用于 MoFox-Bot 插件开发的工具集
"""

__version__ = "0.2.7"
__author__ = "MoFox-Studio"
__license__ = "GPL-3.0-or-later"

__all__ = [
    "__version__",
    "__author__",
    "__license__",
]
