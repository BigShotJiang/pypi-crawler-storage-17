from sdc11073.roles import providerbase


class OperationProvider(providerbase.ProviderRole):
    """Handle operations that work on operation states.

     Empty implementation, not needed/used for sdc11073 tests.
     """
