"""HEDit CLI - Command-line interface for HED annotation generation."""

from src.cli.main import app

__all__ = ["app"]
