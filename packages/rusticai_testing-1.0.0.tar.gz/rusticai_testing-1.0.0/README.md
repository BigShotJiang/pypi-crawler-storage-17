# Rustic AI Testing

Rustic AI Testing is a collection of test utilities that can be leveraged to verify integration with Rustic AI Framework. 
**This should only be used for testing purposes and should not be used in production.**

## Installing

```shell
pip install rusticai-testing
```

## Building from Source

```shell
poetry install --with dev
poetry build
```
