import asyncio
import importlib
import os
import sys
from inspect import iscoroutinefunction
from pathlib import Path

from dotenv import load_dotenv

# Точки входа по умолчанию (можно переопределить через env BOT_ENTRY_MODULE).
DEFAULT_ENTRY_MODULES = ("bot.main", "app.bot.main")


def run_bot() -> None:
    """
    Запускает бота из ТЕКУЩЕГО репозитория.

    Ожидаемая структура проекта:
    - ./src/bot/main.py  (package "bot" с async main())

    Настройки (env):
    - PROJECT_ROOT: путь к корню проекта (по умолчанию текущая директория)
    - BOT_ENTRY_MODULE: модуль точки входа (по умолчанию пробуем "bot.main", затем "app.bot.main")
    """
    project_root = Path(os.environ.get("PROJECT_ROOT", Path.cwd())).resolve()

    # Загружаем .env из корня проекта (если есть)
    load_dotenv(project_root / ".env")

    # Даем импортам видеть код проекта (./src).
    src_root = (project_root / "src").resolve()
    if src_root.is_dir():
        src_root_str = str(src_root)
        if src_root_str not in sys.path:
            sys.path.insert(0, src_root_str)

    entry_module_env = (os.environ.get("BOT_ENTRY_MODULE") or "").strip()
    entry_modules = (entry_module_env,) if entry_module_env else DEFAULT_ENTRY_MODULES

    last_exc: Exception | None = None
    module = None
    module_name = None
    for name in entry_modules:
        if not name:
            continue
        try:
            module = importlib.import_module(name)
            module_name = name
            break
        except Exception as exc:  # noqa: BLE001
            last_exc = exc
            continue

    if module is None or module_name is None:
        tried = ", ".join(m for m in entry_modules if m)
        hint = f" (last error: {last_exc})" if last_exc else ""
        raise RuntimeError(
            "Entry module not found / failed to import.\n"
            f"Tried: {tried}\n"
            f"PROJECT_ROOT={project_root}\n"
            "Expected file like: ./src/bot/main.py with async main()."
            f"{hint}"
        )

    main_func = getattr(module, "main", None)
    if not (callable(main_func) and iscoroutinefunction(main_func)):
        raise RuntimeError(f"Module {module_name} must expose async main()")

    asyncio.run(main_func())


if __name__ == "__main__":
    run_bot()
