"""Config module for local import tests."""

VALUE = "config_value"
