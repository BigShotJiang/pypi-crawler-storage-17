"""Utils module for local import tests."""


def utility_function() -> str:
    """Return a utility string."""
    return "utility"
