#########################
Carrier Percentage Module
#########################

The *Carrier Percentage Module* adds a cost method based on percentage.

.. toctree::
   :maxdepth: 2

   design
   releases
