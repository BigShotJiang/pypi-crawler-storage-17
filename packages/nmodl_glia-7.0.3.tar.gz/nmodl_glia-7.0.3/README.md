[![Build Status](https://github.com/dbbs-lab/bsb/actions/workflows/main.yml/badge.svg)](https://github.com/dbbs-lab/bsb/actions/workflows/main.yml)
[![Documentation](https://readthedocs.org/projects/nmodl-glia/badge/?version=latest)](https://nmodl-glia.readthedocs.io/en/latest/?badge=latest)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![codecov](https://codecov.io/gh/dbbs-lab/glia/branch/main/graph/badge.svg)](https://codecov.io/gh/dbbs-lab/glia)

# Glia: NMODL asset manager

View the online documentation at [https://nmodl-glia.readthedocs.io/en/latest/](https://nmodl-glia.readthedocs.io/en/latest/)