# bluecatipreg

Python module to perform IP hostname registration and unregistration in BlueCat.

## Getting Started

### Installation

#### Install from source (development)
```bash
# Clone the repository
git clone <repository-url>
cd bluecatipreggithub

# Create and activate virtual environment
python -m venv venv
# On Windows:
venv\Scripts\activate
# On Linux/Mac:
source venv/bin/activate

# Install in development mode
pip install -e .

# Or install with development dependencies
pip install -e ".[dev]"
```

#### Build and install package
```bash
# Build the package
pip install build
python -m build

# This creates:
# - dist/bluecatipreg-0.0.1.tar.gz (source distribution)
# - dist/bluecatipreg-0.0.1-py3-none-any.whl (wheel)

# Install from built package
pip install dist/bluecatipreg-0.0.1-py3-none-any.whl
```

#### Install from PyPI (when published)
```bash
pip install bluecatipreg
```

## Usage

**NOTE:** Provided password should be base64 encrypted.

### 1. Register IP and host in Bluecat
```bash
python -m bluecatipreg add -url https://abc.com -user admin -passwd password -n test01 -fqdn test01.dev.abc.com -ipv4 6.6.6.6 -net 6.6.6.0/24 -conf playground -domain dev.abc.com -contact developer@abc.com -c "test01 dns entry"
```

### 2. Unregister IP from the Bluecat
```bash
python -m bluecatipreg delete -url https://abc.com -user admin -passwd password -conf playground -ipv4 6.6.6.6
```

## Development

### Running Unit Tests

#### Using pytest (recommended)
```bash
# Install test dependencies
pip install -r requirements_dev.txt
pip install pytest pytest-cov

# Run all tests
pytest bluecatipreg/tests -v

# Run with coverage
pytest bluecatipreg/tests -v --cov=bluecatipreg --cov-report=term-missing --cov-report=html

# Run specific test file
pytest bluecatipreg/tests/test_bluecat_utils.py -v
```

#### Using unittest (Python built-in)
```bash
python -m unittest discover -s bluecatipreg/tests -p "test_*.py" -v
```

### Code Quality

#### Linting with flake8
```bash
flake8 bluecatipreg --count --select=E9,F63,F7,F82 --show-source --statistics
flake8 bluecatipreg --count --exit-zero --max-complexity=10 --max-line-length=127 --statistics
```

#### Code formatting with black
```bash
# Check formatting
black --check bluecatipreg

# Format code
black bluecatipreg
```

## CI/CD Pipeline

The project includes a GitHub Actions CI/CD pipeline (`.github/workflows/ci.yml`) that:

1. **Runs on**: Push and pull requests to `main`, `master`, and `develop` branches
2. **Test Matrix**: Tests on multiple Python versions (3.7-3.13) across Ubuntu, Windows, and macOS
3. **Steps**:
   - Installs dependencies
   - Runs linting (flake8)
   - Checks code formatting (black)
   - Runs unit tests with coverage
   - Builds the package (on main/master branch)
   - Validates the built package

### Viewing Pipeline Status

- Go to the "Actions" tab in your GitHub repository
- Click on a workflow run to see detailed logs
- The pipeline will automatically run on every push and pull request

## Package Structure

```
bluecatipreg/
├── __init__.py          # Package initialization
├── __main__.py          # CLI entry point
├── bluecat_utils.py     # Core BlueCat API functionality
├── options.py           # Command-line argument parsing
└── tests/               # Unit tests
    ├── __init__.py
    └── test_bluecat_utils.py
```

## Requirements

- Python 3.7+
- requests

See `requirements.txt` for production dependencies and `requirements_dev.txt` for development dependencies.
