import argparse
import sys
from bluecatipreg import VERSION


def create_parser():
    parser = argparse.ArgumentParser(
        prog="bluecatipreg", description="Register the IP and host in the BlueCat"
    )
    parser.add_argument("-v", "--version", action="version", version=VERSION)
    subparser = parser.add_subparsers(dest="subparser")
    parser_add = subparser.add_parser("add", help="add IP and hostname in the BlueCat")
    parser_add.add_argument(
        "-url",
        "--urlpath",
        required=True,
        type=str,
        help="BlueCat URL",
    )
    parser_add.add_argument(
        "-user",
        "--username",
        required=True,
        type=str,
        help="API user for the authenticaiton of BlueCat",
    )
    parser_add.add_argument(
        "-passwd",
        "--password",
        required=True,
        type=str,
        help="Base64 encrypted API password for the API user of BlueCat",
    )
    parser_add.add_argument(
        "-n",
        "--name",
        required=True,
        type=str,
        help="name to reserver the hostname of BlueCat",
    )
    parser_add.add_argument(
        "-fqdn",
        "--fqdn",
        required=True,
        type=str,
        help="fully qualified name of the hostname to be mentioned in BlueCat",
    )
    parser_add.add_argument(
        "-ipv4",
        "--ipaddressv4",
        required=True,
        type=str,
        help="IPv4 of the hostname to be mentioned in BlueCat",
    )
    parser_add.add_argument(
        "-net",
        "--network",
        required=True,
        type=str,
        help="Network to be used for the IP and host reservation in BlueCat configuration.",
    )
    parser_add.add_argument(
        "-conf",
        "--configuration",
        required=True,
        type=str,
        help="Configuration to be used for the IP and host reservation in BlueCat configuration.",
    )
    parser_add.add_argument(
        "-domain",
        "--domain",
        required=True,
        type=str,
        help="Domain to be used for the IP and host reservation in BlueCat configuration.",
    )
    parser_add.add_argument(
        "-contact",
        "--contact",
        required=True,
        type=str,
        help="Person who is reservation in BlueCat configuration.",
    )
    parser_add.add_argument(
        "-c",
        "--comment",
        required=True,
        type=str,
        help="Any remark need to be classified IP host reserver in BlueCat configuration.",
    )
    parser_delete = subparser.add_parser("delete", help="delete IP from the BlueCat.")
    parser_delete.add_argument(
        "-url",
        "--urlpath",
        required=True,
        type=str,
        help="BlueCat URL",
    )
    parser_delete.add_argument(
        "-user",
        "--username",
        required=True,
        type=str,
        help="API user for the authenticaiton of BlueCat",
    )
    parser_delete.add_argument(
        "-passwd",
        "--password",
        required=True,
        type=str,
        help="Base64 encrypted API password for the API user of BlueCat",
    )
    parser_delete.add_argument(
        "-conf",
        "--configuration",
        required=True,
        type=str,
        help="Configuration to be used for the IP and host reservation in BlueCat configuration.",
    )
    parser_delete.add_argument(
        "-ipv4",
        "--ipaddressv4",
        required=True,
        type=str,
        help="IPv4 of the hostname to be deleted in BlueCat",
    )
    return parser


def parse():
    parser = create_parser()
    known, unknown = parser.parse_known_args()
    if not hasattr(known, "subparser") or known.subparser is None:
        print("Please specified right parameters")
        parser.print_help()
        sys.exit()
    if len(unknown) != 0:
        print(f"BAD Specified parameter : {unknown}")
        parser.print_help()
        sys.exit()
    return known
