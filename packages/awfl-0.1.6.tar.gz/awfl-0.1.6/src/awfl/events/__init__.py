# events package for workspace-related helpers
# Provides workspace resolution/registration utilities used by the SSE consumer.
