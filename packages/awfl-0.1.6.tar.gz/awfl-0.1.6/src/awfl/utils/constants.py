PROJECT = "topaigents"
LOCATION = "us-central1"

__all__ = ["PROJECT", "LOCATION"]
