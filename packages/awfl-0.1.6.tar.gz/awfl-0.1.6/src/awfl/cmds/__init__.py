from .router import handle_command  # re-export for consumers
