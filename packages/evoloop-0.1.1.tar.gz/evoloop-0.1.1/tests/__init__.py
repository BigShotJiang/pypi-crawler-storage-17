"""
EvoLoop test suite.
"""
