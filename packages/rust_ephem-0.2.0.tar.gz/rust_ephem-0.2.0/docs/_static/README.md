# Static assets directory

This directory is used by Sphinx for custom static files (CSS, JavaScript, images, etc.).

It must exist for Sphinx builds to succeed when `html_static_path` is configured in `conf.py`.
