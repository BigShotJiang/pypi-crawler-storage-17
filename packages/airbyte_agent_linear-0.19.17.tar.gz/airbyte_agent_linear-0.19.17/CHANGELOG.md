# Changelog

## [0.19.17] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: c4c39c27
- SDK version: 0.1.0

## [0.19.16] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: 85f4e6b0
- SDK version: 0.1.0

## [0.19.15] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: 0bfa6500
- SDK version: 0.1.0

## [0.19.14] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: ea5a02a3
- SDK version: 0.1.0

## [0.19.13] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: f13dee0a
- SDK version: 0.1.0

## [0.19.12] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: d79da1e7
- SDK version: 0.1.0

## [0.19.11] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: 06e7d5c6
- SDK version: 0.1.0

## [0.19.10] - 2025-12-13
- Updated connector definition (YAML version 0.1.1)
- Source commit: 1ab72bd8
- SDK version: 0.1.0

## [0.19.9] - 2025-12-12
- Updated connector definition (YAML version 0.1.1)
- Source commit: 4d366cb5
- SDK version: 0.1.0

## [0.19.8] - 2025-12-12
- Updated connector definition (YAML version 0.1.0)
- Source commit: dc79dc8b
- SDK version: 0.1.0

## [0.19.7] - 2025-12-12
- Updated connector definition (YAML version 0.1.0)
- Source commit: 9f7f8a98
- SDK version: 0.1.0

## [0.19.6] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 8c06aa10
- SDK version: 0.1.0

## [0.19.5] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 11427ac3
- SDK version: 0.1.0

## [0.19.4] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: bdd5df6d
- SDK version: 0.1.0

## [0.19.3] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: f2497f71
- SDK version: 0.1.0

## [0.19.2] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 7d738be5
- SDK version: 0.1.0

## [0.19.1] - 2025-12-10
- Updated connector definition (YAML version 0.1.0)
- Source commit: 76636830
- SDK version: 0.1.0

## [0.19.0] - 2025-12-08
- Updated connector definition (YAML version 0.1.0)
- Source commit: f2ad5029
- SDK version: 0.1.0

## [0.18.0] - 2025-12-08
- Updated connector definition (YAML version 0.1.0)
- Source commit: 139b0b0d
- SDK version: 0.1.0

## [0.17.0] - 2025-12-05
- Updated connector definition (YAML version 0.1.0)
- Source commit: e96bed3d
- SDK version: 0.1.0

## [0.16.0] - 2025-12-05
- Updated connector definition (YAML version 0.1.0)
- Source commit: ed697b90
- SDK version: 0.1.0

## [0.15.0] - 2025-12-05
- Updated connector definition (YAML version 1.0.0)
- Source commit: 20618410
- SDK version: 0.1.0

## [0.14.0] - 2025-12-04
- Updated connector definition (YAML version 1.0.0)
- Source commit: 4a01e446
- SDK version: 0.1.0

## [0.13.0] - 2025-12-04
- Updated connector definition (YAML version 1.0.0)
- Source commit: 5ec76dde
- SDK version: 0.1.0

## [0.12.0] - 2025-12-04
- Updated connector definition (YAML version 1.0.0)
- Source commit: df32a458
- SDK version: 0.1.0

## [0.11.0] - 2025-12-04
- Updated connector definition (YAML version 1.0.0)
- Source commit: a506b369
- SDK version: 0.1.0

## [0.10.0] - 2025-12-03
- Updated connector definition (YAML version 1.0.0)
- Source commit: 92a39ab5
- SDK version: 0.1.0

## [0.9.0] - 2025-12-03
- Updated connector definition (YAML version 1.0.0)
- Source commit: 0ce38253
- SDK version: 0.1.0

## [0.8.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: c8e326d9
- SDK version: 0.1.0

## [0.7.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: ad0b961b
- SDK version: 0.1.0

## [0.6.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: 7153780a
- SDK version: 0.1.0

## [0.5.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: 01f71cad
- SDK version: 0.1.0

## [0.4.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: 4c17f060
- SDK version: 0.1.0

## [0.3.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: 430a4e68
- SDK version: 0.1.0

## [0.2.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: cd499acd
- SDK version: 0.1.0

## [0.1.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: b261c3a2
- SDK version: 0.1.0
