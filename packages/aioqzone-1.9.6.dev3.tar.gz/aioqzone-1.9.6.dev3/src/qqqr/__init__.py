"""
QQQR is an API-level simulation of Qzone web login process. Currently this package
includes QR login and password login. A captcha verifier is also contained to pass TDC.
"""
