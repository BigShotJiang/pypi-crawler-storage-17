# Sadə nümunə sözlər, istədiyin kimi genişləndirə bilərsən
WORDS = [
    "baku", "ustan", "naxçıvan", "nəriman", "nar", "rusiya",
    "azerbaijan", "novruz", "zəfər", "rəvan", "nabat",
    "computer",  "home",  "glass",  "screen",  "comment"
]

