# Author: KrorngAI org.
# Date: December 2025


__version__ = "0.0.3"
