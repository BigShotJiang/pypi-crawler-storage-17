from .aggregator import *


class PickledChild:
    def __init__(self, age):
        self.age = age
