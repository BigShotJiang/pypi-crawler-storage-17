import uuid

from nsj_rest_lib.decorator.dto import DTO
from nsj_rest_lib.descriptor.dto_field import DTOField
from nsj_rest_lib.descriptor.dto_field_validators import DTOFieldValidators
from nsj_rest_lib.dto.dto_base import DTOBase


@DTO()
class EscopoDTO(DTOBase):

    id: uuid.UUID = DTOField(
        pk=True,
        resume=True,
        not_null=True,
        default_value=uuid.uuid4,
        strip=True,
        min=36,
        max=36,
        validator=DTOFieldValidators().validate_uuid,
    )

    codigo: str = DTOField(
        resume=True,
        not_null=True,
        strip=True,
        min=1,
        max=100,
        unique="escopo_codigo",
        candidate_key=True,
    )

    service_account: str = DTOField(
        resume=True,
        strip=True,
        min=5,
        max=320,
        validator=DTOFieldValidators().validate_email,
    )
