"""Tests for SciGlob library."""
