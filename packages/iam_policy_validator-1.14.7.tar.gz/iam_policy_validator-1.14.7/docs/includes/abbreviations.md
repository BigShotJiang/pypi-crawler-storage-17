*[IAM]: Identity and Access Management
*[ARN]: Amazon Resource Name
*[AWS]: Amazon Web Services
*[CLI]: Command Line Interface
*[SDK]: Software Development Kit
*[API]: Application Programming Interface
*[CI/CD]: Continuous Integration/Continuous Deployment
*[JSON]: JavaScript Object Notation
*[YAML]: YAML Ain't Markup Language
*[MFA]: Multi-Factor Authentication
*[STS]: Security Token Service
*[RCP]: Resource Control Policy
*[SCP]: Service Control Policy
*[OIDC]: OpenID Connect
*[SAML]: Security Assertion Markup Language
*[PR]: Pull Request
*[SHA]: Secure Hash Algorithm
