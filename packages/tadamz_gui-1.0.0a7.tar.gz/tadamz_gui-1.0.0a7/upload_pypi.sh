# !/bin/bash
python3 -m twine upload --skip-existing dist/*