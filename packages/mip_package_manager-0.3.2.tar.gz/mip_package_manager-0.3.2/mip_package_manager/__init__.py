"""mip-package-manager - pip-style package manager for MATLAB packages
"""

__version__ = '0.3.2'
