__version__ = "0.0.6"

from slack_message import messages as slack_msg
