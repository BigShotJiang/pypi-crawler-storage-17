
# http://www.soc-bdr.org/rds/authors/unit_tables_conversions_and_genetic_dictionaries/conversion_glucose_mg_dl_to_mmol_l/index_en.html
MMOLL_TO_MGDL = 18.0182
MGDL_TO_MMOLL = 0.0555