# Projects

Configs for fully replicating the training of specific models.
