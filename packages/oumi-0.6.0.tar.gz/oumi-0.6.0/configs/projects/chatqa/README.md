# ChatQA

Configs for reproducing results from the Nvidia ChatQA paper.

## References

- [ChatQA Project Website](https://chatqa-project.github.io)
- [ChatQA Paper](https://arxiv.org/abs/2401.10225)
