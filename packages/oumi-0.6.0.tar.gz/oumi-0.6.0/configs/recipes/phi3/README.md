# Phi-3

Configs for Microsoft's Phi-3 model family.
