"""Short-term memory example: custom persistence via to_dict/from_dict (Redis-like)."""

