import numpy as np
import gc
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import RobustScaler
from sklearn.mixture import GaussianMixture
from sklearn.cluster import MiniBatchKMeans
from numba import jit, prange

@jit(nopython=True, fastmath=True, parallel=True)
def _fast_manhattan_batch(X_batch, prototypes):
    n_samples = X_batch.shape[0]
    n_protos = prototypes.shape[0]
    n_feats = X_batch.shape[1]
    dists = np.zeros((n_samples, n_protos), dtype=np.float32)
    for i in prange(n_samples):
        for j in range(n_protos):
            acc = 0.0
            for f in range(n_feats):
                acc += abs(X_batch[i, f] - prototypes[j, f])
            dists[i, j] = acc
    return dists

@jit(nopython=True, fastmath=True)
def _calc_diffs_jit_numba(X_subset, protos, k):
    """Calcula las diferencias ponderadas (IDW) usando Numba"""
    n_samples = X_subset.shape[0]
    n_feats = X_subset.shape[1]
    
    dists = _fast_manhattan_batch(X_subset, protos)
    total_diff = np.zeros(n_feats, dtype=np.float32)
    epsilon = 1e-6
    
    for i in range(n_samples):
        # Top K manual para evitar overhead de np.argsort completo
        # (Para k pequeño, un sort parcial es suficiente)
        row_dists = dists[i]
        sorted_indices = np.argsort(row_dists)[:k]
        
        # IDW Weights
        weights = np.zeros(k, dtype=np.float32)
        sum_w = 0.0
        for j in range(k):
            idx = sorted_indices[j]
            w = 1.0 / (row_dists[idx] + epsilon)
            weights[j] = w
            sum_w += w
            
        # Acumular diferencias
        for j in range(k):
            idx = sorted_indices[j]
            norm_w = weights[j] / sum_w
            for f in range(n_feats):
                diff = abs(X_subset[i, f] - protos[idx, f])
                total_diff[f] += diff * norm_w
                
    return total_diff

@jit(nopython=True, parallel=True)
def _lvq_update_jit(prototypes, X_batch, y_batch, proto_labels, lr):
    n_samples = X_batch.shape[0]
    n_protos = prototypes.shape[0]
    n_features = X_batch.shape[1]
    for i in prange(n_samples):
        best_dist = np.inf
        winner_idx = -1
        for p in range(n_protos):
            dist = 0.0
            for f in range(n_features):
                dist += abs(X_batch[i, f] - prototypes[p, f])
            if dist < best_dist:
                best_dist = dist
                winner_idx = p
        
        sign = 1.0 if proto_labels[winner_idx] == y_batch[i] else -1.0
        for f in range(n_features):
            prototypes[winner_idx, f] += lr * sign * (X_batch[i, f] - prototypes[winner_idx, f])

class ReliefF_Autonomous(BaseEstimator, TransformerMixin):
    def __init__(self, mode='auto'):
        self.mode = mode
        self.feature_importances_ = None
        self.ranking_ = None
        self._clip_min = -5.0
        self._clip_max = 5.0
        self._k_protos_per_class = {}

    def _auto_tune_parameters(self, X):
        # Auto-Clip basado en estadística robusta
        if X.shape[0] > 10000:
            sample = X[np.random.choice(X.shape[0], 5000, replace=False)]
        else:
            sample = X
        q25 = np.percentile(sample, 25, axis=0)
        q75 = np.percentile(sample, 75, axis=0)
        # Fijamos clip estándar a 5 desviaciones robustas
        self._clip_min = -5.0 
        self._clip_max = 5.0

    def fit(self, X, y):
        X = np.ascontiguousarray(X, dtype=np.float32)
        y = np.ascontiguousarray(y, dtype=np.int32)
        n_samples = X.shape[0]
        classes = np.unique(y)
        
        # 1. Preprocesamiento
        if self.mode == 'auto':
            self._auto_tune_parameters(X)
        
        scaler = RobustScaler()
        X = scaler.fit_transform(X)
        X = np.clip(X, self._clip_min, self._clip_max)
        gc.collect()

        # 2. Generación de Prototipos (Lógica Híbrida)
        prototypes = {}
        BIG_DATA_THRESHOLD = 10000 # Punto de cambio de marcha

        for c in classes:
            X_c = X[y == c]
            count = X_c.shape[0]
            
            # K Dinámico
            if count > BIG_DATA_THRESHOLD:
                k_optimal = int(5 * np.log10(count)) # Crecimiento suave para Big Data
            else:
                k_optimal = int(np.sqrt(count)) # Crecimiento estándar
            k_optimal = max(3, min(100, k_optimal))
            self._k_protos_per_class[c] = k_optimal
            
            # --- EL CAMBIO DE MARCHA ---
            if count > BIG_DATA_THRESHOLD:
                # Marcha Larga: MiniBatchKMeans (Velocidad pura)
                km = MiniBatchKMeans(n_clusters=k_optimal, batch_size=2048, n_init=3)
                km.fit(X_c)
                prototypes[c] = km.cluster_centers_.astype(np.float32)
            else:
                # Marcha Corta: GMM (Precisión Geométrica)
                if count <= k_optimal:
                     prototypes[c] = X_c
                else:
                    try:
                        gmm = GaussianMixture(n_components=k_optimal, covariance_type='diag', random_state=42)
                        gmm.fit(X_c)
                        prototypes[c] = gmm.means_.astype(np.float32)
                    except:
                        km = MiniBatchKMeans(n_clusters=k_optimal, n_init=3)
                        km.fit(X_c)
                        prototypes[c] = km.cluster_centers_.astype(np.float32)

        # Preparar datos para Numba (Aplanar)
        all_protos_list = []
        all_labels_list = []
        for c, protos in prototypes.items():
            all_protos_list.append(protos)
            all_labels_list.append(np.full(len(protos), c, dtype=np.int32))
        flat_protos = np.vstack(all_protos_list)
        flat_labels = np.concatenate(all_labels_list)
        
        # 3. Refinamiento LVQ (JIT)
        _lvq_update_jit(flat_protos, X, y, flat_labels, lr=0.1)
        
        # Reconstruir diccionario
        cursor = 0
        final_protos = {}
        for c in classes:
            n_p = len(prototypes[c])
            final_protos[c] = flat_protos[cursor : cursor + n_p]
            cursor += n_p

        # 4. Cálculo de Scores (JIT + Batching)
        scores = np.zeros(X.shape[1], dtype=np.float32)
        p_classes = {c: len(X[y==c])/n_samples for c in classes}
        BATCH_SIZE = 2000 # Batch grande gracias a Numba
        
        for start in range(0, n_samples, BATCH_SIZE):
            end = min(start + BATCH_SIZE, n_samples)
            X_batch = X[start:end]
            y_batch = y[start:end]
            
            for c in classes:
                mask_c = (y_batch == c)
                if not np.any(mask_c): continue
                
                # HIT
                X_b_c = X_batch[mask_c]
                hit_diffs = _calc_diffs_jit_numba(X_b_c, final_protos[c], k=5)
                scores -= hit_diffs * p_classes[c]
                
                # MISS
                prob_not_c = 1.0 - p_classes[c]
                for other_c in classes:
                    if other_c == c: continue
                    weight = p_classes[other_c] / (prob_not_c + 1e-8)
                    miss_diffs = _calc_diffs_jit_numba(X_b_c, final_protos[other_c], k=5)
                    scores += miss_diffs * weight * p_classes[c]
                    
        self.feature_importances_ = scores
        self.ranking_ = np.argsort(-scores)
        return self

    def rank(self):
        return self.ranking_