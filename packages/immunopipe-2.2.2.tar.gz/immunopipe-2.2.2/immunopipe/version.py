__version__ = "2.2.2"

desc = (
    f"Immunopipe (v{__version__}): "
    "Integrative analysis for scRNA-seq and scTCR-/scBCR-seq data"
)
