- [Akretion](https://akretion.com):
  - Renato Lima \<<renato.lima@akretion.com.br>\>
  - Raphaël Valyi \<<raphael.valyi@akretion.com.br>\>
  - Magno Costa \<<magno.costa@akretion.com.br>\>
- [KMEE](https://www.kmee.com.br):
  - Gabriel Cardoso de Faria \<<gabriel.cardoso@kmee.com.br>\>
[APSL-Nagarro](https://www.apsl.tech):
 - Patryk Pyczko \<<ppyczko@apsl.net>\>
