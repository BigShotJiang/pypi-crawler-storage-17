- It is be possible reference multiple sale lines in only one invoice
  line, but there are a problem the field qty_invoiced in
  sale.order.line show the quantity of invoice line without consider, in
  this case, that the value is the sum of others sale lines
  <https://github.com/odoo/odoo/blob/14.0/addons/sale/models/sale.py#L1230>,
  what can make confuse the user about the real Invoiced Quantity,
  reference <https://github.com/odoo/odoo/pull/77195>
