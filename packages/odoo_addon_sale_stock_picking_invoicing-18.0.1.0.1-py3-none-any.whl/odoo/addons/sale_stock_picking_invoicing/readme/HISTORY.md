## 16.0.1.0.0 (2025-01-14)

- Migration to version 16.0

## 15.0.1.0.0 (2024-10-25)

- Migration to version 15.0 .

## 14.0.1.0.0 (2024-03-12)

- \[ADD\] Module sale_stock_picking_invoicing based in
  l10n_br_sale_stock
  <https://github.com/OCA/l10n-brazil/tree/14.0/l10n_br_sale_stock> .
