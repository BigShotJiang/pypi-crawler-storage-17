This module depends on:

- sale_management
- sale_stock
- stock_picking_invoicing
- stock_picking_invoice_link
