Define 'Sale Invoicing Policy', if the invoice should be created from
Sale Order or from Stock Picking, go to:

**Settings \> Users & Companies \> Companies**

or

**Sales \> Configuration \> Settings in Invoicing**
