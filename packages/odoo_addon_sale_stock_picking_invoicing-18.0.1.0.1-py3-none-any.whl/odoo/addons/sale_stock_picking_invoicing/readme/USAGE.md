If 'Stock Picking' is choose as Policy the creation of Invoice from Sale
Order works only for Service lines, in the case of Sale Order has
Products and Service lines will be create two Invoices.
