# Typed Bitbank

> A fully typed, validated async client for the Bitbank API

Use *autocomplete* instead of documentation.

🚧 Under construction.