# CLI test package for PassFX lifecycle and signal handling tests.
