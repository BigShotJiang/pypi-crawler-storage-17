# UI Tests
# Tests for Textual screens, navigation, and user interaction flows.
