# Security Tests
# Threat-model-driven tests validating cryptographic and access control properties.
