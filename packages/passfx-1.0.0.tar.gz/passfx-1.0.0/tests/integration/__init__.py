# Integration Tests
# Tests verifying component interactions and full encryption round-trips.
