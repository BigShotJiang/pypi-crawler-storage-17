from .client import TPLinkM7200

__all__ = ["TPLinkM7200"]
