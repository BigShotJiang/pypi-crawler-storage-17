# nicescholia
nicegui based scholia

| | |
| :--- | :--- |
| **PyPi** | [![PyPI Status](https://img.shields.io/pypi/v/nicescholia.svg)](https://pypi.python.org/pypi/nicescholia/) [![License](https://img.shields.io/github/license/WolfgangFahl/nicescholia.svg)](https://www.apache.org/licenses/LICENSE-2.0) [![pypi](https://img.shields.io/pypi/pyversions/nicescholia)](https://pypi.org/project/nicescholia/) [![format](https://img.shields.io/pypi/format/nicescholia)](https://pypi.org/project/nicescholia/) [![downloads](https://img.shields.io/pypi/dd/nicescholia)](https://pypi.org/project/nicescholia/) |
| **GitHub** | [![Github Actions Build](https://github.com/WolfgangFahl/nicescholia/actions/workflows/build.yml/badge.svg)](https://github.com/WolfgangFahl/nicescholia/actions/workflows/build.yml) [![Release](https://img.shields.io/github/v/release/WolfgangFahl/nicescholia)](https://github.com/WolfgangFahl/nicescholia/releases) [![Contributors](https://img.shields.io/github/contributors/WolfgangFahl/nicescholia)](https://github.com/WolfgangFahl/nicescholia/graphs/contributors) [![Last Commit](https://img.shields.io/github/last-commit/WolfgangFahl/nicescholia)](https://github.com/WolfgangFahl/nicescholia/commits/) [![GitHub issues](https://img.shields.io/github/issues/WolfgangFahl/nicescholia.svg)](https://github.com/WolfgangFahl/nicescholia/issues) [![GitHub closed issues](https://img.shields.io/github/issues-closed/WolfgangFahl/nicescholia.svg)](https://github.com/WolfgangFahl/nicescholia/issues/?q=is%3Aissue+is%3Aclosed) |
| **Code** | [![style-black](https://img.shields.io/badge/%20style-black-000000.svg)](https://github.com/psf/black) [![imports-isort](https://img.shields.io/badge/%20imports-isort-%231674b1)](https://pycqa.github.io/isort/) |
| **Docs** | [![API Docs](https://img.shields.io/badge/API-Documentation-blue)](https://WolfgangFahl.github.io/nicescholia/) [![formatter-docformatter](https://img.shields.io/badge/%20formatter-docformatter-fedcba.svg)](https://github.com/PyCQA/docformatter) [![style-google](https://img.shields.io/badge/%20style-google-3666d6.svg)](https://google.github.io/styleguide/pyguide.html#s3.8-comments-and-docstrings) |
[![DOI](https://zenodo.org/badge/1118183488.svg)](https://doi.org/10.5281/zenodo.17967779)

# Demo
https://nicescholia.wikidata.dbis.rwth-aachen.de/
