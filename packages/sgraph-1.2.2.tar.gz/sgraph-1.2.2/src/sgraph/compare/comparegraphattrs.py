class CompareGraphAttrs:
    CHANGE_COUNT = "_change_count"
    CHANGED_ATTRIBUTES = "_attr_diff"
    CHANGED_DEP = "_changed_dep"
    CHANGED_CHILD = "_changed_child"
    ONLY_IN = "_only_in"
