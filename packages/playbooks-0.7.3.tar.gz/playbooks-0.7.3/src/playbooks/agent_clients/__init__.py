"""Agent client interfaces.

This module provides client interfaces for connecting to external agents.
Currently empty as direct agent references are used.
"""

__all__ = []
