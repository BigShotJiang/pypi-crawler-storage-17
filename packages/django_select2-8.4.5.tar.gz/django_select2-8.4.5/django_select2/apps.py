"""Django application configuration."""

from django.apps import AppConfig


class Select2AppConfig(AppConfig):
    """Django application configuration."""

    name = "django_select2"
    verbose_name = "Select2"

    def ready(self):
        from . import conf  # noqa
