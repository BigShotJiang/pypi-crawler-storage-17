## gguf-cua

example:
```
cua --task "whats the weather in san francisco now" --headful
```