This example demonstrates a diameter client script that sets up a local node,
connects to a peer and then sends a single credit control request for charging
an SMS, waits for the answer and then exits.

This file is available as `examples/credit_control_sms_client.py`.
```python
-8<- "examples/credit_control_sms_client.py"
```