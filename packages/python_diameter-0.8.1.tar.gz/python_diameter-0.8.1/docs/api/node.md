---
shallow_toc: 3
---
API reference for `diameter.node`.

::: diameter.node.node
    options:
      show_root_heading: false
      show_root_toc_entry: false
      members:
        - Node
        - NodeStats
        - NodeError
        - NotRoutable
      filters:
        - "!^_"
      show_submodules: false