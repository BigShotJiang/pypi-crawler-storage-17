API reference for `diameter.node.application`.

::: diameter.node.application
    options:
      show_submodules: false