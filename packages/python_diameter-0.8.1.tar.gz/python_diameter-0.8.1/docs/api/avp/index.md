---
shallow_toc: 3
---
API reference for `diameter.message.avp`.

::: diameter.message.avp.avp
    options:
      show_root_heading: false
      show_root_toc_entry: false
      show_submodules: false
      members_order: alphabetical