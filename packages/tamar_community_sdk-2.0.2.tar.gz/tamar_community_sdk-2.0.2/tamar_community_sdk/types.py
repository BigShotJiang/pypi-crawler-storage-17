"""
类型定义
"""
from dataclasses import dataclass, field
from typing import Optional, Callable, Any, Awaitable, Union, List
from enum import Enum


# 进度回调类型
ProgressCallback = Callable[[float], None]
AsyncProgressCallback = Callable[[float], Awaitable[None]]


class FileCategory(str, Enum):
    """文件分类"""
    GENERAL = "general"
    VIDEO = "video"
    IMAGE = "image"
    AUDIO = "audio"
    DOCUMENT = "document"
    AVATAR = "avatar"
    COVER = "cover"


class FileStatus(str, Enum):
    """文件状态"""
    PENDING = "pending"
    UPLOADING = "uploading"
    CONFIRMED = "confirmed"
    FAILED = "failed"


class HLSVariantStatus(str, Enum):
    """HLS 变体状态"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class HLSStatus(str, Enum):
    """HLS 整体状态"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    PARTIAL = "partial"
    FAILED = "failed"


@dataclass
class HLSVariant:
    """HLS 变体信息"""
    name: str  # 变体名称，如 '360p', '720p'
    resolution: str  # 分辨率，如 '1280x720'
    bandwidth: int  # 带宽 (bps)
    status: str  # 变体状态
    playlist_key: Optional[str] = None  # OSS 中的播放列表 key
    segment_count: Optional[int] = None  # 分片数量
    url: Optional[str] = None  # 变体播放列表 URL
    error: Optional[str] = None  # 错误信息

    @classmethod
    def from_dict(cls, data: dict) -> "HLSVariant":
        """从字典创建"""
        return cls(
            name=data.get("name", ""),
            resolution=data.get("resolution", ""),
            bandwidth=data.get("bandwidth", 0),
            status=data.get("status", "pending"),
            playlist_key=data.get("playlist_key"),
            segment_count=data.get("segment_count"),
            url=data.get("url"),
            error=data.get("error"),
        )

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "name": self.name,
            "resolution": self.resolution,
            "bandwidth": self.bandwidth,
            "status": self.status,
            "playlist_key": self.playlist_key,
            "segment_count": self.segment_count,
            "url": self.url,
            "error": self.error,
        }


@dataclass
class HLSInfo:
    """HLS 播放信息"""
    file_id: str  # 文件 ID
    hls_status: Optional[str]  # HLS 整体状态
    hls_available: bool  # HLS 是否可用
    variants: List[HLSVariant]  # 变体列表
    original_url: str  # 原始视频 URL（降级使用）
    master_url: Optional[str] = None  # 主播放列表 URL

    @classmethod
    def from_dict(cls, data: dict) -> "HLSInfo":
        """从字典创建"""
        variants_data = data.get("variants", [])
        variants = [HLSVariant.from_dict(v) for v in variants_data]
        return cls(
            file_id=data.get("file_id", ""),
            hls_status=data.get("hls_status"),
            hls_available=data.get("hls_available", False),
            variants=variants,
            original_url=data.get("original_url", ""),
            master_url=data.get("master_url"),
        )

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "file_id": self.file_id,
            "hls_status": self.hls_status,
            "hls_available": self.hls_available,
            "variants": [v.to_dict() for v in self.variants],
            "original_url": self.original_url,
            "master_url": self.master_url,
        }


@dataclass
class FileInfo:
    """文件信息"""
    id: str
    file_key: str
    file_size: Optional[int] = None
    file_type: Optional[str] = None
    file_ext: Optional[str] = None
    file_hash: Optional[str] = None  # SHA-256 哈希
    bucket: Optional[str] = None
    region: Optional[str] = None
    oss_url: Optional[str] = None
    imagekit_url: Optional[str] = None
    cdn_url: Optional[str] = None
    category: str = "general"
    user_id: Optional[str] = None
    org_id: Optional[str] = None
    status: str = "pending"
    related_type: Optional[str] = None
    related_id: Optional[str] = None
    extra_metadata: dict = field(default_factory=dict)
    # HLS 相关字段
    hls_status: Optional[str] = None  # HLS 转码状态
    hls_variants: Optional[List[HLSVariant]] = None  # HLS 变体信息
    hls_url: Optional[str] = None  # HLS 主播放列表 URL
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    confirmed_at: Optional[str] = None
    deleted_at: Optional[str] = None
    deduplicated: Optional[bool] = None  # 是否命中去重（仅上传结果中存在）

    @classmethod
    def from_dict(cls, data: dict) -> "FileInfo":
        """从字典创建 FileInfo 对象"""
        # 处理 HLS 变体
        hls_variants_data = data.get("hls_variants")
        hls_variants = None
        if hls_variants_data:
            hls_variants = [HLSVariant.from_dict(v) for v in hls_variants_data]

        return cls(
            id=data.get("id", ""),
            file_key=data.get("file_key", ""),
            file_size=data.get("file_size"),
            file_type=data.get("file_type"),
            file_ext=data.get("file_ext"),
            file_hash=data.get("file_hash"),
            bucket=data.get("bucket"),
            region=data.get("region"),
            oss_url=data.get("oss_url"),
            imagekit_url=data.get("imagekit_url"),
            cdn_url=data.get("cdn_url"),
            category=data.get("category", "general"),
            user_id=data.get("user_id"),
            org_id=data.get("org_id"),
            status=data.get("status", "pending"),
            related_type=data.get("related_type"),
            related_id=data.get("related_id"),
            extra_metadata=data.get("extra_metadata", {}),
            hls_status=data.get("hls_status"),
            hls_variants=hls_variants,
            hls_url=data.get("hls_url"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
            confirmed_at=data.get("confirmed_at"),
            deleted_at=data.get("deleted_at"),
            deduplicated=data.get("deduplicated"),
        )

    def to_dict(self) -> dict:
        """转换为字典"""
        result = {
            "id": self.id,
            "file_key": self.file_key,
            "file_size": self.file_size,
            "file_type": self.file_type,
            "file_ext": self.file_ext,
            "file_hash": self.file_hash,
            "bucket": self.bucket,
            "region": self.region,
            "oss_url": self.oss_url,
            "imagekit_url": self.imagekit_url,
            "cdn_url": self.cdn_url,
            "category": self.category,
            "user_id": self.user_id,
            "org_id": self.org_id,
            "status": self.status,
            "related_type": self.related_type,
            "related_id": self.related_id,
            "extra_metadata": self.extra_metadata,
            "hls_status": self.hls_status,
            "hls_variants": [v.to_dict() for v in self.hls_variants] if self.hls_variants else None,
            "hls_url": self.hls_url,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "confirmed_at": self.confirmed_at,
            "deleted_at": self.deleted_at,
        }
        if self.deduplicated is not None:
            result["deduplicated"] = self.deduplicated
        return result


@dataclass
class UploadResult:
    """上传结果"""
    file: FileInfo
    deduplicated: bool = False  # 是否命中去重（秒传）

    @classmethod
    def from_dict(cls, data: dict, deduplicated: bool = False) -> "UploadResult":
        """从字典创建"""
        return cls(
            file=FileInfo.from_dict(data),
            deduplicated=deduplicated,
        )


@dataclass
class UploadOptions:
    """上传选项"""
    category: str = "general"
    content_type: Optional[str] = None
    part_size: Optional[int] = None
    metadata: Optional[dict] = None
    on_progress: Optional[Union[ProgressCallback, AsyncProgressCallback]] = None
    on_hash_progress: Optional[Union[ProgressCallback, AsyncProgressCallback]] = None  # SHA-256 计算进度
    # API Key 认证时可指定用户信息（覆盖客户端级别的设置）
    user_id: Optional[str] = None
    org_id: Optional[str] = None


@dataclass
class ListFilesParams:
    """文件列表查询参数"""
    category: Optional[str] = None
    status: Optional[str] = None
    page: int = 1
    page_size: int = 20


@dataclass
class PartInfo:
    """分片信息"""
    part_number: int
    start: int
    end: int
    size: int
    upload_url: Optional[str] = None
    uploaded: bool = False
    etag: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "PartInfo":
        """从字典创建"""
        return cls(
            part_number=data.get("part_number", 0),
            start=data.get("start", 0),
            end=data.get("end", 0),
            size=data.get("size", 0),
            upload_url=data.get("upload_url"),
            uploaded=data.get("uploaded", False),
            etag=data.get("etag"),
        )
