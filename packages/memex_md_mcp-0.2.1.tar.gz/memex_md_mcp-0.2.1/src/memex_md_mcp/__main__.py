from memex_md_mcp.server import main

main()
