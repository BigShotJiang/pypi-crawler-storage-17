#!/usr/bin/env python3
"""blobtoolkit version."""

__version__ = "blobtoolkit-host v4.5.0"
