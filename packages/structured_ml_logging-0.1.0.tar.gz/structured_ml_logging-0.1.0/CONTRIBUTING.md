# Contributing

## Development setup (Windows 11)

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
````

## Quality gates

```powershell
python -m ruff check . --fix
python -m ruff format .
python -m mypy src
pytest -q
```

## Principles

* Keep the event schema stable: add fields, do not rename existing ones.
* Keep sinks pluggable and isolated (SRP).
* Avoid hidden global state outside context propagation.
* Prefer deterministic behavior over background magic (until explicitly added).
