# Structured ML Logging

## Tutorial
- See `README.md` for the quickstart.

## How-to
- [Write events to a file](howto_file_sink.md)

## Reference
- [Event schema](reference_event_schema.md)

## Explanation
- This library standardizes ML experiment logging by emitting validated JSON events to pluggable sinks.
