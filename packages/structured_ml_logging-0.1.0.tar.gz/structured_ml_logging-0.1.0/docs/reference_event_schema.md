# Event schema reference

The canonical event schema is exported via:

```python
from mlog import export_json_schema

schema = export_json_schema()
````

Key fields:

* `ts` (UTC timestamp)
* `level` (`DEBUG|INFO|WARNING|ERROR|CRITICAL`)
* `message` (event type/message)
* `project`, `experiment`, `run_id`
* `metric` or (`metric_name`, `metric_value`, `metric_dims`) depending on configuration
* `param`, `tags`
* `exception` (structured)
