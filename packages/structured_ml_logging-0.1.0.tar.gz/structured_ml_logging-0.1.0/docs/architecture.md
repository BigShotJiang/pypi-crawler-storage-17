# Architecture

## Goal

Emit consistent, validated JSON events for ML experiments and route them to sinks suitable for:
- local development (stdout, file)
- ELK ingestion (logstash HTTP)
- Google Cloud Logging (optional extra)

## Core modules

- `mlog.schema`: canonical `LogEvent` model + JSON Schema export
- `mlog.context`: run-scoped metadata propagation via `ContextVar`
- `mlog.logger`: user-facing API, validation policy, enrichment, redaction
- `mlog.sinks.*`: output implementations
- `mlog.processors`: record processors (e.g., redaction)
- `mlog.utils.*`: enrichment helpers (runtime, git, index keys)

## Extension strategy

- Add new sinks without changing the logger core (OCP).
- Add new fields to `LogEvent` as optional fields to avoid breaking consumers.
