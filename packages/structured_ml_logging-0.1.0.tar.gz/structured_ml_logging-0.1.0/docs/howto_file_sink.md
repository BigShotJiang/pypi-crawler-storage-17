# How to write events to a file

This writes newline-delimited JSON (NDJSON), which is easy to ingest into ELK.

```python
from mlog import get_logger, run_context

log = get_logger(
    project="demo",
    experiment="baseline",
    sink="file",
    file_path="logs/events.ndjson",
)

with run_context(run_id="run_001"):
    log.param("lr", 0.01)
    log.metric("train.loss", 0.123, step=1)
    log.event("done")
