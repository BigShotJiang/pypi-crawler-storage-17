# Structured ML Logging

Structured (JSON) logging for ML experiments with schema validation and pluggable sinks.

## Installation (dev)

```bash
pip install -e ".[dev]"
````

## Quickstart

```python
from mlog import get_logger, run_context

log = get_logger(project="demo", experiment="baseline", sink="stdout", validation="strict")

with run_context(run_id="run_001", tags={"team": "ml"}):
    log.param("lr", 0.01)
    log.metric("train.loss", 0.123, step=1)
    log.event("done")
```