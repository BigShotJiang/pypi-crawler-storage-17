from __future__ import annotations

from mlog import get_logger, run_context


def main() -> None:
    log = get_logger(
        project="demo",
        experiment="baseline",
        sink="file",
        file_path="logs/events.ndjson",
        metric_mode="kv",
        buffered=True,
        flush_every=10,
        redact=True,
    )

    with run_context(run_id="run_001", tags={"team": "ml"}):
        log.param("lr", 0.01)
        log.metric("train.loss", 0.123, step=1, fold=0)
        log.event("checkpoint_saved", path="checkpoints/model.onnx", token="should_not_leak")

        try:
            raise RuntimeError("boom")
        except RuntimeError as e:
            log.exception("training_failed", e)

    log.close()


if __name__ == "__main__":
    main()
