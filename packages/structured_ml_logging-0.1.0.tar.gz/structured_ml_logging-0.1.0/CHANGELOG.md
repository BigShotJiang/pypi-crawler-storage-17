# Changelog

## Unreleased

### Added
- Canonical JSON event schema with JSON Schema export.
- Context propagation (`run_context`) for run-scoped metadata.
- Sinks: stdout, file (NDJSON), Logstash HTTP, optional GCP Logging.
- Metric modes: map and index-friendly key/value mode.
- Runtime + git metadata enrichment.
- Low-cardinality `index` fields for search.
- Optional buffering for stdout/file sinks.
- Optional redaction for sensitive keys.
- CLI: `mlog schema`.
- GitHub Actions CI.

### Changed
- None.

### Fixed
- None.
