from mlog import get_logger, run_context


def test_basic_logging():
    log = get_logger(project="test", experiment="exp")

    with run_context(run_id="run-1"):
        log.param("lr", 0.1)
        log.metric("loss", 0.5, step=1)
        log.event("done")
