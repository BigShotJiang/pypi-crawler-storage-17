import pytest

from mlog import get_logger, run_context


def test_validation_strict_rejects_bad_level():
    log = get_logger(project="p", experiment="e", validation="strict")
    with run_context(run_id="r1"):
        with pytest.raises(ValueError):
            log.event("x", level="NOPE")  # type: ignore[arg-type]


def test_validation_warn_keeps_training_running():
    log = get_logger(project="p", experiment="e", validation="warn")
    with run_context(run_id="r1"):
        with pytest.raises(ValueError):
            log.event("x", level="NOPE")  # type: ignore[arg-type]
