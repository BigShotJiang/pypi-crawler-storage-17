import json
import subprocess
import sys


def test_cli_schema_outputs_json():
    p = subprocess.run(
        [sys.executable, "-m", "mlog", "schema"],
        check=True,
        capture_output=True,
        text=True,
    )
    obj = json.loads(p.stdout)
    assert "properties" in obj
    assert "level" in obj["properties"]
