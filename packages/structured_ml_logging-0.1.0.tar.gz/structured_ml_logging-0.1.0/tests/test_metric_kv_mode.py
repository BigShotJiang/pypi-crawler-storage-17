import json
from pathlib import Path

from mlog import get_logger, run_context


def test_metric_kv_mode_outputs_index_friendly_fields(tmp_path: Path):
    out = tmp_path / "events.ndjson"
    log = get_logger(project="p", experiment="e", sink="file", file_path=str(out), metric_mode="kv")

    with run_context(run_id="r1"):
        log.metric("train.loss", 0.123, step=7, fold=1)

    obj = json.loads(out.read_text(encoding="utf-8").splitlines()[0])
    assert obj["message"] == "metric"
    assert obj["metric_name"] == "train.loss"
    assert obj["metric_value"] == 0.123
    assert obj["metric_dims"]["fold"] == 1
