import json
from pathlib import Path

from mlog import get_logger, run_context


def test_exception_is_structured(tmp_path: Path):
    out = tmp_path / "events.ndjson"
    log = get_logger(project="p", experiment="e", sink="file", file_path=str(out))

    with run_context(run_id="r1"):
        try:
            raise RuntimeError("boom")
        except RuntimeError as e:
            log.exception("training_failed", e)

    obj = json.loads(out.read_text(encoding="utf-8").splitlines()[0])
    assert obj["level"] == "ERROR"
    assert obj["message"] == "training_failed"
    assert obj["exception"]["type"] == "RuntimeError"
    assert "boom" in obj["exception"]["message"]
    assert "RuntimeError" in obj["exception"]["stack"]
