import pytest

from mlog import get_logger


def test_gcp_sink_requires_extra_dependency():
    with pytest.raises(ImportError):
        get_logger(project="p", experiment="e", sink="gcp")
