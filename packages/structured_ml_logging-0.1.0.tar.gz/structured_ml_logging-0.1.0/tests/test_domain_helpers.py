import json
from pathlib import Path

from mlog import get_logger, run_context


def test_dataset_model_artifact_helpers(tmp_path: Path):
    out = tmp_path / "events.ndjson"
    log = get_logger(project="p", experiment="e", sink="file", file_path=str(out))

    with run_context(run_id="r1"):
        log.dataset(name="train", version="v1", uri="s3://bucket/train.parquet", rows=123)
        log.model(name="xgb", framework="xgboost", params={"max_depth": 6})
        log.artifact(name="model.onnx", uri="file://model.onnx", kind="model", size_bytes=10)

    lines = out.read_text(encoding="utf-8").splitlines()
    objs = [json.loads(x) for x in lines]

    assert objs[0]["message"] == "dataset"
    assert objs[0]["dataset"]["name"] == "train"

    assert objs[1]["message"] == "model"
    assert objs[1]["model"]["name"] == "xgb"

    assert objs[2]["message"] == "artifact"
    assert objs[2]["artifact"]["name"] == "model.onnx"
