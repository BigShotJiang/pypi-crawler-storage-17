from mlog.utils.git import git_metadata


def test_git_metadata_returns_none_when_git_unavailable(monkeypatch):
    import mlog.utils.git as gitmod

    def _raise(*args, **kwargs):
        raise OSError("no git")

    monkeypatch.setattr(gitmod.subprocess, "run", _raise)
    assert git_metadata() is None
