import json
from pathlib import Path

from mlog import get_logger, run_context


def test_logger_context_manager_emits_summary_and_closes(tmp_path: Path):
    out = tmp_path / "events.ndjson"
    with get_logger(
        project="p", experiment="e", sink="file", file_path=str(out), buffered=True, flush_every=100
    ) as log:
        with run_context(run_id="r1"):
            log.metric("loss", 1.0, step=1)
            log.event("done")

    lines = out.read_text(encoding="utf-8").splitlines()
    assert json.loads(lines[-1])["message"] == "summary"
