import json
from pathlib import Path

from mlog import get_logger, run_context


def test_index_fields_are_present(tmp_path: Path):
    out = tmp_path / "events.ndjson"
    log = get_logger(project="p", experiment="e", sink="file", file_path=str(out))

    with run_context(run_id="r1"):
        log.event("hello")

    obj = json.loads(out.read_text(encoding="utf-8").splitlines()[0])
    assert obj["index"]["project"] == "p"
    assert obj["index"]["experiment"] == "e"
    assert obj["index"]["run_id"] == "r1"
    assert obj["index"]["event"] == "hello"
