import json
from pathlib import Path

from mlog import get_logger, run_context


def test_emit_summary_contains_best_and_last(tmp_path: Path):
    out = tmp_path / "events.ndjson"
    log = get_logger(project="p", experiment="e", sink="file", file_path=str(out), metric_mode="kv")

    with run_context(run_id="r1"):
        log.param("lr", 0.1)
        log.metric("loss", 5.0, step=1)
        log.metric("loss", 3.0, step=2)
        log.metric("acc", 0.2, step=1)
        log.metric("acc", 0.9, step=2)
        log.emit_summary()

    lines = out.read_text(encoding="utf-8").splitlines()
    last = json.loads(lines[-1])

    assert last["message"] == "summary"
    s = last["summary"]
    assert s["params"]["lr"] == 0.1
    assert s["best_min"]["loss"] == 3.0
    assert s["best_max"]["acc"] == 0.9
    assert s["last_metrics"]["loss"] == 3.0
    assert s["last_metrics"]["acc"] == 0.9
