from unittest.mock import Mock, patch

from mlog import get_logger, run_context


@patch("mlog.sinks.logstash.requests.post")
def test_logstash_http_sink_posts_json(mock_post):
    resp = Mock()
    resp.raise_for_status.return_value = None
    mock_post.return_value = resp

    log = get_logger(
        project="p", experiment="e", sink="logstash", logstash_url="http://localhost:8080/logs"
    )

    with run_context(run_id="r1"):
        log.event("hello", foo="bar")

    assert mock_post.call_count == 1
    _, kwargs = mock_post.call_args
    assert kwargs["json"]["message"] == "hello"
    assert kwargs["json"]["foo"] == "bar"
