import json
from pathlib import Path

from mlog import get_logger, run_context


def test_redaction_masks_sensitive_keys(tmp_path: Path):
    out = tmp_path / "events.ndjson"
    log = get_logger(
        project="p",
        experiment="e",
        sink="file",
        file_path=str(out),
        redact=True,
    )

    with run_context(run_id="r1"):
        log.event("hello", token="abc", nested={"password": "p", "ok": 1})

    obj = json.loads(out.read_text(encoding="utf-8").splitlines()[0])
    assert obj["token"] == "[REDACTED]"
    assert obj["nested"]["password"] == "[REDACTED]"
    assert obj["nested"]["ok"] == 1
