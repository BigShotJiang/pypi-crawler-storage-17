import json
from pathlib import Path

from mlog import get_logger, run_context


def test_file_sink_writes_ndjson(tmp_path: Path):
    out = tmp_path / "logs" / "events.ndjson"
    log = get_logger(project="p", experiment="e", sink="file", file_path=str(out))

    with run_context(run_id="r1", tags={"k": "v"}):
        log.param("lr", 0.1)
        log.metric("loss", 0.5, step=1)
        log.event("done")

    lines = out.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 3

    obj = json.loads(lines[0])
    assert obj["project"] == "p"
    assert obj["run_id"] == "r1"
    assert obj["message"] in {"param", "metric", "done"}
