import json
from pathlib import Path

from mlog import get_logger, run_context


def test_buffered_sink_flushes_on_close(tmp_path: Path):
    out = tmp_path / "events.ndjson"
    log = get_logger(
        project="p",
        experiment="e",
        sink="file",
        file_path=str(out),
        buffered=True,
        flush_every=100,
    )

    with run_context(run_id="r1"):
        log.event("a")
        log.event("b")

    assert not out.exists() or out.read_text(encoding="utf-8") == ""

    log.close()

    lines = out.read_text(encoding="utf-8").splitlines()
    assert [json.loads(x)["message"] for x in lines] == ["a", "b"]
