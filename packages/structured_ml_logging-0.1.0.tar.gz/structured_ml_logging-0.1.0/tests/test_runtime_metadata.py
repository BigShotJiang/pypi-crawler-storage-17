import json
from pathlib import Path

from mlog import get_logger, run_context


def test_runtime_metadata_is_present(tmp_path: Path):
    out = tmp_path / "events.ndjson"
    log = get_logger(project="p", experiment="e", sink="file", file_path=str(out))

    with run_context(run_id="r1"):
        log.event("hello")

    obj = json.loads(out.read_text(encoding="utf-8").splitlines()[0])
    assert "runtime" in obj
    assert "host" in obj["runtime"]
    assert "pid" in obj["runtime"]
    assert "python" in obj["runtime"]
    assert "platform" in obj["runtime"]
