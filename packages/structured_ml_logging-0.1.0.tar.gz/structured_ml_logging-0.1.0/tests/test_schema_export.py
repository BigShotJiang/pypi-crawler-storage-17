from mlog import export_json_schema


def test_export_json_schema_has_core_fields():
    s = export_json_schema()
    props = s.get("properties", {})
    assert "level" in props
    assert "message" in props
    assert "project" in props
    assert "run_id" in props
