from __future__ import annotations

import traceback
from dataclasses import dataclass, field
from typing import Any, Literal

from .config import LoggerConfig
from .context import get_context
from .processors import redact_record
from .schema import LogEvent
from .sinks.buffered import BufferedSink
from .sinks.file import FileSink
from .sinks.logstash import LogstashHttpSink
from .sinks.stdout import StdoutSink
from .summary import SummaryState
from .utils.env import runtime_metadata
from .utils.index import index_fields

_USER_RESERVED_KEYS: frozenset[str] = frozenset(
    {
        "ts",
        "level",
        "message",
        "project",
        "experiment",
        "run_id",
        "schema_version",
        "exception",
    }
)


@dataclass
class MLLogger:
    project: str
    experiment: str | None
    sink: Any
    validation: str = "strict"  # strict | warn | off
    config: LoggerConfig = LoggerConfig()
    redact: bool = False
    _summary: SummaryState = field(default_factory=SummaryState, init=False, repr=False)

    def __enter__(self) -> MLLogger:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: Any,
    ) -> Literal[False]:
        # Emit summary even if an exception happened; exceptions are still propagated.
        try:
            self.emit_summary()
        finally:
            self.close()
        return False

    def _validate(self, payload: dict[str, Any]) -> dict[str, Any]:
        if self.validation == "off":
            return payload
        try:
            ev = LogEvent(**payload)
            return ev.model_dump(mode="json")
        except Exception as e:
            if self.validation == "warn":
                payload["mlog_validation_error"] = str(e)
                return payload
            raise

    def _base(
        self,
        level_value: str,
        message_value: str,
        *,
        _internal: dict[str, Any] | None = None,
        **fields: Any,
    ) -> dict[str, Any]:
        collisions = _USER_RESERVED_KEYS.intersection(fields.keys())
        if collisions:
            raise ValueError(
                f"Reserved field name(s) used in log call: {sorted(collisions)}. "
                "Use domain fields like metric/param/tags/dataset/model/artifact instead."
            )

        ctx = get_context()
        payload: dict[str, Any] = {
            "level": level_value,
            "message": message_value,
            "project": self.project,
            "experiment": self.experiment,
            "run_id": ctx.run_id,
            "tags": ctx.tags or None,
            "runtime": runtime_metadata(),
            "index": index_fields(
                project=self.project,
                experiment=self.experiment,
                ctx=ctx,
                message=message_value,
            ),
            **fields,
        }
        if _internal:
            payload.update(_internal)

        payload = self._validate(payload)
        if self.redact:
            payload = redact_record(payload)
        return payload

    def event(self, message: str, **fields: Any) -> None:
        self.sink.emit(self._base("INFO", message, **fields))

    def metric(self, name: str, value: Any, step: int | None = None, **dims: Any) -> None:
        self._summary.track_metric(name, value)

        if self.config.metric_mode == "kv":
            payload = self._base(
                "INFO",
                "metric",
                step=step,
                metric_name=name,
                metric_value=value,
                metric_dims=dims or None,
            )
        else:
            metric = {name: value, **dims}
            payload = self._base("INFO", "metric", step=step, metric=metric)
        self.sink.emit(payload)

    def param(self, name: str, value: Any) -> None:
        self._summary.track_param(name, value)
        self.sink.emit(self._base("INFO", "param", param={name: value}))

    def dataset(
        self, *, name: str, version: str | None = None, uri: str | None = None, **meta: Any
    ) -> None:
        payload = {"name": name, "version": version, "uri": uri, **meta}
        self.sink.emit(self._base("INFO", "dataset", dataset=payload))

    def model(self, *, name: str, framework: str | None = None, **meta: Any) -> None:
        payload = {"name": name, "framework": framework, **meta}
        self.sink.emit(self._base("INFO", "model", model=payload))

    def artifact(
        self, *, name: str, uri: str | None = None, kind: str | None = None, **meta: Any
    ) -> None:
        payload = {"name": name, "uri": uri, "kind": kind, **meta}
        self.sink.emit(self._base("INFO", "artifact", artifact=payload))

    def emit_summary(self) -> None:
        self.sink.emit(self._base("INFO", "summary", summary=self._summary.as_payload()))

    def exception(self, message: str, exc: BaseException, **fields: Any) -> None:
        ex = {
            "type": exc.__class__.__name__,
            "message": str(exc),
            "stack": traceback.format_exc(),
        }
        self.sink.emit(self._base("ERROR", message, _internal={"exception": ex}, **fields))

    def flush(self) -> None:
        if hasattr(self.sink, "flush"):
            self.sink.flush()

    def close(self) -> None:
        if hasattr(self.sink, "close"):
            self.sink.close()


def get_logger(
    project: str,
    experiment: str | None = None,
    sink: str = "stdout",
    validation: str = "strict",
    file_path: str | None = None,
    metric_mode: str = "map",
    logstash_url: str | None = None,
    gcp_logger_name: str = "mlog",
    gcp_project: str | None = None,
    buffered: bool = False,
    flush_every: int = 50,
    redact: bool = False,
) -> MLLogger:
    if sink == "stdout":
        s: Any = StdoutSink()
    elif sink == "file":
        if not file_path:
            raise ValueError("file_path is required when sink='file'")
        s = FileSink(file_path)
    elif sink == "logstash":
        if not logstash_url:
            raise ValueError("logstash_url is required when sink='logstash'")
        s = LogstashHttpSink(logstash_url)
    elif sink == "gcp":
        from .sinks.gcp import GoogleCloudLoggingSink

        s = GoogleCloudLoggingSink(logger_name=gcp_logger_name, project=gcp_project)
    else:
        raise ValueError(f"Unknown sink: {sink}")

    if buffered and sink in {"stdout", "file"}:
        s = BufferedSink(s, flush_every=flush_every)

    cfg = LoggerConfig(metric_mode=metric_mode)  # type: ignore[arg-type]
    return MLLogger(
        project=project,
        experiment=experiment,
        sink=s,
        validation=validation,
        config=cfg,
        redact=redact,
    )
