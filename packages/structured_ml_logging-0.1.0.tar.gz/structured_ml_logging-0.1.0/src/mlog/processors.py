from __future__ import annotations

from collections.abc import Mapping
from typing import Any, cast

_DEFAULT_REDACT_KEYS: frozenset[str] = frozenset(
    {
        "password",
        "passwd",
        "secret",
        "token",
        "api_key",
        "apikey",
        "authorization",
        "auth",
    }
)


def redact_record(
    record: Mapping[str, Any], *, keys: frozenset[str] = _DEFAULT_REDACT_KEYS
) -> dict[str, Any]:
    def _walk(x: Any) -> Any:
        if isinstance(x, Mapping):
            out: dict[str, Any] = {}
            for k, v in x.items():
                if isinstance(k, str) and k.lower() in keys:
                    out[k] = "[REDACTED]"
                else:
                    out[k] = _walk(v)
            return out
        if isinstance(x, list):
            return [_walk(i) for i in x]
        return x

    # MyPy cannot prove _walk(record) is a dict, but we can: record is Mapping -> _walk returns dict here.
    return cast(dict[str, Any], _walk(record))
