from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

MetricMode = Literal["map", "kv"]


@dataclass(frozen=True)
class LoggerConfig:
    """
    Logger configuration.

    metric_mode:
      - "map": metric is a JSON object {name: value, ...}
      - "kv": metric_name + metric_value (+ metric_dims) for better indexing in ELK
    """

    metric_mode: MetricMode = "map"
