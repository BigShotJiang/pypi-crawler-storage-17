from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class RunContext:
    run_id: str | None = None
    experiment_id: str | None = None
    tags: dict[str, Any] = field(default_factory=dict)


_CONTEXT: ContextVar[RunContext | None] = ContextVar("mlog_run_context", default=None)


def get_context() -> RunContext:
    ctx = _CONTEXT.get()
    if ctx is None:
        ctx = RunContext()
        _CONTEXT.set(ctx)
    return ctx


@contextmanager
def run_context(
    run_id: str,
    experiment_id: str | None = None,
    tags: dict[str, Any] | None = None,
) -> Iterator[None]:
    token = _CONTEXT.set(RunContext(run_id=run_id, experiment_id=experiment_id, tags=tags or {}))
    try:
        yield
    finally:
        _CONTEXT.reset(token)
