from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class SummaryState:
    params: dict[str, Any] = field(default_factory=dict)
    last_metrics: dict[str, Any] = field(default_factory=dict)
    best_min: dict[str, Any] = field(default_factory=dict)
    best_max: dict[str, Any] = field(default_factory=dict)

    def track_param(self, name: str, value: Any) -> None:
        self.params[name] = value

    def track_metric(self, name: str, value: Any) -> None:
        self.last_metrics[name] = value

        if name not in self.best_min or value < self.best_min[name]:
            self.best_min[name] = value
        if name not in self.best_max or value > self.best_max[name]:
            self.best_max[name] = value

    def as_payload(self) -> dict[str, Any]:
        return {
            "params": dict(self.params),
            "last_metrics": dict(self.last_metrics),
            "best_min": dict(self.best_min),
            "best_max": dict(self.best_max),
        }


__all__ = ["SummaryState"]
