from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

Level = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]


class LogEvent(BaseModel):
    """
    Canonical structured log event for ML experiments.

    Notes:
    - Extra fields are allowed to keep the model extensible (OCP).
    - The schema can be exported for downstream systems (ELK/GCP).
    """

    model_config = ConfigDict(extra="allow")

    ts: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    level: Level
    message: str

    project: str
    experiment: str | None = None
    run_id: str | None = None

    step: int | None = None
    epoch: int | None = None

    metric: dict[str, Any] | None = None
    param: dict[str, Any] | None = None
    tags: dict[str, Any] | None = None

    dataset: dict[str, Any] | None = None
    model: dict[str, Any] | None = None
    artifact: dict[str, Any] | None = None

    exception: dict[str, Any] | None = None
    schema_version: str = "1.0.0"


def export_json_schema() -> dict[str, Any]:
    """
    Export the JSON Schema for LogEvent.

    This is useful for:
    - Elasticsearch index templates
    - Logstash pipelines
    - Contract validation in CI
    """
    return LogEvent.model_json_schema()
