from __future__ import annotations

import json
import sys

from .schema import export_json_schema


def main(argv: list[str] | None = None) -> int:
    args = argv if argv is not None else sys.argv
    if len(args) >= 2 and args[1] == "schema":
        sys.stdout.write(json.dumps(export_json_schema(), ensure_ascii=False, indent=2) + "\n")
        return 0

    sys.stderr.write("Usage: mlog schema\n")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
