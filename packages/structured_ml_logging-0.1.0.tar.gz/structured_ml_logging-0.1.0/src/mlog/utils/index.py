from __future__ import annotations

from typing import Any

from ..context import RunContext


def index_fields(
    *,
    project: str,
    experiment: str | None,
    ctx: RunContext,
    message: str,
) -> dict[str, Any]:
    """
    Produce low-cardinality fields for indexed search.

    Goal: make filtering easy without exploding index mappings.
    """
    return {
        "project": project,
        "experiment": experiment,
        "run_id": ctx.run_id,
        "event": message,
    }
