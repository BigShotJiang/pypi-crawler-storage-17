from __future__ import annotations

import os
import platform
import socket
import sys
from typing import Any

from .git import git_metadata


def runtime_metadata() -> dict[str, Any]:
    return {
        "host": socket.gethostname(),
        "pid": os.getpid(),
        "python": {
            "version": sys.version.split()[0],
            "implementation": platform.python_implementation(),
        },
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
        },
        "git": git_metadata(),
    }
