from __future__ import annotations

import subprocess
from typing import Any


def _run_git(args: list[str]) -> str | None:
    try:
        p = subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError:
        return None
    if p.returncode != 0:
        return None
    out = p.stdout.strip()
    return out or None


def git_metadata() -> dict[str, Any] | None:
    commit = _run_git(["rev-parse", "HEAD"])
    if commit is None:
        return None

    branch = _run_git(["rev-parse", "--abbrev-ref", "HEAD"])
    dirty = _run_git(["status", "--porcelain"]) is not None

    return {
        "commit": commit,
        "branch": branch,
        "dirty": dirty,
    }
