from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import requests


class LogstashHttpSink:
    """
    Sends events as JSON to a Logstash-compatible HTTP endpoint.

    Assumptions:
    - Endpoint accepts POST with JSON body per request.
    """

    def __init__(
        self,
        url: str,
        timeout_s: float = 5.0,
        headers: dict[str, str] | None = None,
    ) -> None:
        self._url = url
        self._timeout_s = timeout_s
        self._headers = {"Content-Type": "application/json", **(headers or {})}

    def emit(self, record: Mapping[str, Any]) -> None:
        r = requests.post(
            self._url,
            json=dict(record),
            timeout=self._timeout_s,
            headers=self._headers,
        )
        r.raise_for_status()
