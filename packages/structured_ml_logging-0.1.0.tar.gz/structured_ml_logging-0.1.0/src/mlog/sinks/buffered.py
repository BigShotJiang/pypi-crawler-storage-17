from __future__ import annotations

from collections.abc import Mapping
from typing import Any


class BufferedSink:
    """
    Wraps another sink and flushes in batches.

    This reduces overhead for file/stdout sinks while keeping deterministic behavior.
    """

    def __init__(self, inner: Any, flush_every: int = 50) -> None:
        if flush_every <= 0:
            raise ValueError("flush_every must be > 0")
        self._inner = inner
        self._flush_every = flush_every
        self._buf: list[Mapping[str, Any]] = []

    def emit(self, record: Mapping[str, Any]) -> None:
        self._buf.append(record)
        if len(self._buf) >= self._flush_every:
            self.flush()

    def flush(self) -> None:
        for r in self._buf:
            self._inner.emit(r)
        self._buf.clear()

    def close(self) -> None:
        self.flush()
