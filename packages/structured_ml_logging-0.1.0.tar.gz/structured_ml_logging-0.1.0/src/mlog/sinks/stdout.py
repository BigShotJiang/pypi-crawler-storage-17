from __future__ import annotations

import json
import sys
from collections.abc import Mapping
from typing import Any


class StdoutSink:
    """Writes one JSON object per line to stdout (NDJSON)."""

    def emit(self, record: Mapping[str, Any]) -> None:
        sys.stdout.write(json.dumps(record, ensure_ascii=False) + "\n")
        sys.stdout.flush()
