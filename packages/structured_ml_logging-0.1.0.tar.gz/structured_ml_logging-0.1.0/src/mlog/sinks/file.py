from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any


class FileSink:
    """Appends one JSON object per line to a file (NDJSON)."""

    def __init__(self, path: str | Path, encoding: str = "utf-8") -> None:
        self._path = Path(path)
        self._encoding = encoding
        self._path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, record: Mapping[str, Any]) -> None:
        line = json.dumps(record, ensure_ascii=False)
        with self._path.open("a", encoding=self._encoding, newline="\n") as f:
            f.write(line + "\n")
