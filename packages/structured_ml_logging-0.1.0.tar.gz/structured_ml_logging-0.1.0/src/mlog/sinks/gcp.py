from __future__ import annotations

import importlib
from collections.abc import Mapping
from typing import Any

_LEVEL_TO_GCP_SEVERITY: dict[str, str] = {
    "DEBUG": "DEBUG",
    "INFO": "INFO",
    "WARNING": "WARNING",
    "ERROR": "ERROR",
    "CRITICAL": "CRITICAL",
}


class GoogleCloudLoggingSink:
    """
    Google Cloud Logging sink.

    Assumptions:
    - Requires `google-cloud-logging` extra.
    - Emits structured payload via jsonPayload.
    """

    def __init__(self, logger_name: str = "mlog", project: str | None = None) -> None:
        try:
            gcl: Any = importlib.import_module("google.cloud.logging")
        except Exception as e:  # pragma: no cover
            raise ImportError(
                "google-cloud-logging is required. Install with: pip install structured-ml-logging[gcp]"
            ) from e

        client: Any = gcl.Client(project=project)
        self._logger: Any = client.logger(logger_name)

    def emit(self, record: Mapping[str, Any]) -> None:
        severity = _LEVEL_TO_GCP_SEVERITY.get(str(record.get("level", "INFO")), "INFO")
        self._logger.log_struct(dict(record), severity=severity)
