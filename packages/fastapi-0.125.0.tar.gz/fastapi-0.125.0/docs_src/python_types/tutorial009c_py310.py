def say_hi(name: str | None):
    print(f"Hey {name}!")
