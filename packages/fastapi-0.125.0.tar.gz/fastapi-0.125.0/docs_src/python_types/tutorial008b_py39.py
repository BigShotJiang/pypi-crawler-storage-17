from typing import Union


def process_item(item: Union[int, str]):
    print(item)
