"""Remote package management helpers for `blender-remote-cli pkg ...`."""
