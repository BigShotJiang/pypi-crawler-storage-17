from dementor.standalone import run_from_cli

run_from_cli()