NOTICE
======

This product includes materials from the double-entry-generator project,
which is licensed under the Apache License, Version 2.0.

- Source: <https://github.com/deb-sig/double-entry-generator>
- Copyright (c) 2019-2025 Ce Gao and contributors
- Included materials: Example bill files (CSV and XLSX formats) from the
  `example/` directory, used as bill examples.
