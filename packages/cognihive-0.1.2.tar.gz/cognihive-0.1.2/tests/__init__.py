"""Tests init files."""
