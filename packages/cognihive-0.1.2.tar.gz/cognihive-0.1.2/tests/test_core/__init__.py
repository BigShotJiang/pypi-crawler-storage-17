"""Tests for core module."""
