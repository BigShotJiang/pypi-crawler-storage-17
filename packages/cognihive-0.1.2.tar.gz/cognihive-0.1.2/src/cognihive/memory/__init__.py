"""Memory components."""

__all__ = []
