"""A plugin for pipen to draw pipeline diagrams"""

from .entry import PipenDiagram

__version__ = "1.0.0"

PipenDiagram.__version__ = __version__
