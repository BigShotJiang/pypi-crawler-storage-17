__doc__ = """
仿真模块接口
"""

from .order import *
from .wave import *
