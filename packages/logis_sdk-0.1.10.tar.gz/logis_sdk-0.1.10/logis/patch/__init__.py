__doc__ = """
logis-sdk 补丁模块
"""
