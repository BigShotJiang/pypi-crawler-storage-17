# pompy-cli
A barebones CLI utility package for Python, for making interactive programs on the terminal.
