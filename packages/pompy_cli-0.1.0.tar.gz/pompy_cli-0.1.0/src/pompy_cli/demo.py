def hello(text):
    print(f"Hello!\nYou entered: {text}")