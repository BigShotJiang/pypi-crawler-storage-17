__version__ = "0.1.0"

from .demo import hello