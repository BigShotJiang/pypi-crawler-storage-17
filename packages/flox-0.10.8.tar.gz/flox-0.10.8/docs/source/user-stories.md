# Tricks & Stories

```{eval-rst}
.. toctree::
   :maxdepth: 1

   user-stories/overlaps.md
   user-stories/climatology.ipynb
   user-stories/climatology-hourly.ipynb
   user-stories/climatology-hourly-cubed.ipynb
   user-stories/custom-aggregations.ipynb
   user-stories/nD-bins.ipynb
   user-stories/large-zonal-stats.ipynb
```
