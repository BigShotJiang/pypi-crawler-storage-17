.. contents::

Introduction
============

Products.PloneMeeting specific methods to use amqp (collective.zamqp), rely on imio.zamqp.core

