from zope.i18nmessageid import MessageFactory


_ = MessageFactory('imio.zamqp.pm')


def initialize(context):
    """Initializer called when used as a Zope 2 product."""
