# Typed Yobit

> A fully typed, validated async client for the Yobit API

Use *autocomplete* instead of documentation.

🚧 Under construction.