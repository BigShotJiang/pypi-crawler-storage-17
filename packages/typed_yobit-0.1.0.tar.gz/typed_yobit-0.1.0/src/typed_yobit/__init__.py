"""
### Typed Yobit
> A fully typed, validated async client for the Yobit API

- Details
"""