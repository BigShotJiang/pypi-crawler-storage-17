def to_uppercase(string):
    """Converts a string to uppercase."""
    return string.upper()


def to_lowercase(string):
    """Converts a string to lowercase."""
    return string.lower()
