# investify-utils v2

Shared utilities for Investify services with Polars support and PyPI publishing.

## Installation

```bash
# From PyPI (when published)
pip install investify-utils[postgres,kafka]

# From GitLab Package Registry
pip install investify-utils --index-url https://gitlab.com/api/v4/projects/PROJECT_ID/packages/pypi/simple
```

## Features

- **Polars-first PostgreSQL client** with pandas compatibility
- **Kafka producers/consumers** with Avro serialization
- **S3 client** for object storage
- **Prompt registry** with optional Langfuse integration
- **Parallel LLM processor** for batch operations

## Migration from v1

See [investify-utils-v2-refactoring.md](https://gitlab.com/investify-vn/core/data-pipelines/-/blob/master/docs/issues/investify-utils-v2-refactoring.md) for migration guide.

## Development

```bash
uv sync --all-extras
uv run pytest
uv run ruff check .
```
