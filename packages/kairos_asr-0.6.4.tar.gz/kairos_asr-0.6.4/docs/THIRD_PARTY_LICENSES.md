## GigaAM

Project: https://github.com/salute-developers/GigaAM
License: MIT License
Copyright (c) 2024 GigaChat Team

This project includes code derived from GigaAM and
uses pretrained model weights originating from GigaAM.
The original license and copyright notice are preserved
in accordance with the MIT License.