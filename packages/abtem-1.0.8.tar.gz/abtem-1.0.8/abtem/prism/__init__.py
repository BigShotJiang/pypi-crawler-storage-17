"""Module to describing scattering metrices used in the PRISM algorithm."""
