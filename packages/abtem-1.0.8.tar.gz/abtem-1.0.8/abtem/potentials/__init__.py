"""Module to describe electrostatic potentials."""
