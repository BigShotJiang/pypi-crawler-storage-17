def main():
    print("Hello from bigkinds!")


if __name__ == "__main__":
    main()
