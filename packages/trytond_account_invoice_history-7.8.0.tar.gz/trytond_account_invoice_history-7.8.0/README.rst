##############################
Account Invoice History Module
##############################

The *Account Invoice History Module* activates historization on the invoices.

.. toctree::
   :maxdepth: 2

   design
   releases
