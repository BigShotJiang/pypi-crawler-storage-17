import time

for n in range(1000):
    print(f"Scroll {n}")
    time.sleep(0.02)
