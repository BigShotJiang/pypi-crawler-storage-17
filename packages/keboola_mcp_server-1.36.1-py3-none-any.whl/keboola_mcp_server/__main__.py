"""Main entry point for the Keboola MCP server."""

from keboola_mcp_server.cli import main

if __name__ == '__main__':
    main()
