from ovos_plugin_manager.phal import find_phal_plugins, find_admin_plugins
from ovos_PHAL.service import PHAL
from ovos_PHAL.admin import AdminPHAL
