"""
Mirascope integration examples for Edda framework.

These examples demonstrate how to make durable LLM calls
using Mirascope with Edda's activity system.
"""
