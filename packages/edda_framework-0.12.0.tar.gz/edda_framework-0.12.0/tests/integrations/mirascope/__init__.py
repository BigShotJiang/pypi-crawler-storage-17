"""Tests for Edda + Mirascope integration."""
