// #include <iostream>
// #include "timings.hpp"

// int main(){
//     std::cout << "Hello world" << std::endl;
//     mim_solvers::Timer timer;
//     timer.start();
//     timer.stop();
//     std::cout << timer.elapsed().user << std::endl;
//     return 0;
// }
