"""FastAPI module for Plivo Streaming SDK"""

from plivo_stream.fastapi.streaming import PlivoFastAPIStreamingHandler

__all__ = ["PlivoFastAPIStreamingHandler"]

