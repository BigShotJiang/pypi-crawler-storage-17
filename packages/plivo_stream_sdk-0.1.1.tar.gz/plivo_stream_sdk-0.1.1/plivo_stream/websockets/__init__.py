"""Websockets module for Plivo Streaming SDK"""

from plivo_stream.websockets.streaming import PlivoWebsocketStreamingHandler

__all__ = ["PlivoWebsocketStreamingHandler"]

