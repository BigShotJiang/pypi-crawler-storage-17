__version__ = "0.23.11"


def get_version() -> str:
    return __version__
