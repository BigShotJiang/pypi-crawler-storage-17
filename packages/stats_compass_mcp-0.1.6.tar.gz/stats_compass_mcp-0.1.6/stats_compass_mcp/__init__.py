"""
stats-compass-mcp: MCP server for stats-compass-core tools.

Exposes data analysis tools to LLMs via the Model Context Protocol.
"""

__version__ = "0.1.0"
