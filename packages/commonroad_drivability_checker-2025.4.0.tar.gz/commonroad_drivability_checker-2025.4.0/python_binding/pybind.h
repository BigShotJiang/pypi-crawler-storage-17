#pragma once

#include <nanobind/nanobind.h>

void export_collision(const nanobind::module_ &module);
