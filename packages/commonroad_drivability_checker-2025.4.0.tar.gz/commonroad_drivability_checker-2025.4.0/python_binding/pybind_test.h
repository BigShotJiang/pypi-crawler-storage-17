#pragma once

#include <nanobind/nanobind.h>

void export_test(nanobind::module_ &module);
