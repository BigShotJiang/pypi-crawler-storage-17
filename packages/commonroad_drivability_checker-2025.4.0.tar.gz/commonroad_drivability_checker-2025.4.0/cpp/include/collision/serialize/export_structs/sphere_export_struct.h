#pragma once
namespace collision {
namespace serialize {
struct SphereExportStruct {
 public:
  double radius;
  double center_x;
  double center_y;
};
}  // namespace serialize
}  // namespace collision
