#pragma once
namespace collision {
namespace serialize {
struct RectangleAABBExportStruct {
 public:
  double rx;
  double ry;
  double center_x;
  double center_y;
};
}  // namespace serialize
}  // namespace collision
