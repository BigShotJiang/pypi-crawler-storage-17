#pragma once
namespace collision {
namespace serialize {
struct VertexExportStruct {
 public:
  double v_x;
  double v_y;
};
}  // namespace serialize
}  // namespace collision
