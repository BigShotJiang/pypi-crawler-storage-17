#pragma once
namespace collision {
namespace serialize {
struct TimeVariantCollisionObjectExportStruct {
 public:
  int time_start_idx;
};
}  // namespace serialize
}  // namespace collision
