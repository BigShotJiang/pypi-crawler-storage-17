#pragma once
namespace collision {
namespace serialize {
struct TriangleExportStruct {
 public:
  double v1_x;
  double v1_y;
  double v2_x;
  double v2_y;
  double v3_x;
  double v3_y;
};
}  // namespace serialize
}  // namespace collision
