#pragma once
namespace collision {
namespace serialize {
struct PointExportStruct {
 public:
  double center_x;
  double center_y;
};
}  // namespace serialize
}  // namespace collision
