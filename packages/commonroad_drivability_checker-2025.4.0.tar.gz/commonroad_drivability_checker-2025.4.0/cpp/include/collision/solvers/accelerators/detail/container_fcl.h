#ifndef CPP_COLLISION_INCLUDE_COLLISION_ACCELERATORS_CONTAINER_FCL_H_
#define CPP_COLLISION_INCLUDE_COLLISION_ACCELERATORS_CONTAINER_FCL_H_

namespace collision {
namespace detail {
namespace accelerators {
class ContainerFCL;
}  // namespace accelerators
}  // namespace detail
}  // namespace collision

#endif /* CPP_COLLISION_INCLUDE_COLLISION_ACCELERATORS_CONTAINER_FCL_H_ */
