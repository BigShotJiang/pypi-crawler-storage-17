
#pragma once

namespace collision {
namespace solvers {
namespace solverBoost {
class BoostObjectInternal {
 public:
  virtual ~BoostObjectInternal(void) {}
};
}  // namespace solverBoost
}  // namespace solvers
}  // namespace collision
