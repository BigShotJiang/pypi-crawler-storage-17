.. _gettingStarted:

###############
Getting Started
###############

.. toctree::
    :maxdepth: 1

    dependencies.rst
    installation.rst
    installation_cpp.rst
