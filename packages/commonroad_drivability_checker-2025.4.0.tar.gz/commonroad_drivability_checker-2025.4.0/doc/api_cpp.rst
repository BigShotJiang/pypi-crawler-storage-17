.. _api_cpp:

#############################
C++ Collision Checker Library
#############################
The complete doxygen documentation can be found `here <./doxygen/html/index.html>`_

