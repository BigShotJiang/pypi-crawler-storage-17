"""CSS and theme resources for Consoul TUI.

This package contains TCSS (Textual CSS) stylesheets and theme definitions.
"""

from __future__ import annotations

__all__: list[str] = []
