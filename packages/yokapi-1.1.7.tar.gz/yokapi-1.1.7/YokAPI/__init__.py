from .scraper.programs import Lisans, Onlisans, NetSihirbaziLisans, NetSihirbaziOnlisans

__all__ = ["Lisans", "Onlisans", "NetSihirbaziLisans", "NetSihirbaziOnlisans"]