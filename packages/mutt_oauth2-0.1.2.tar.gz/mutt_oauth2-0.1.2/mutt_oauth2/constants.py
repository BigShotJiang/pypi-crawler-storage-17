"""Constants."""
from __future__ import annotations

KEYRING_SERVICE_NAME = 'tatsh-mutt-oauth2'
"""
Keyring service name.

:meta hide-value:
"""
