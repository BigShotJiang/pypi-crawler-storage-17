# Changelog

## Version 0.1 (development)

- Stat comparison is up and operational
