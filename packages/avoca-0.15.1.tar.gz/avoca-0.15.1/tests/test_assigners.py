"""Test for the zscore function."""

import pandas as pd
import pytest

from avoca.manager import AssignerManager
from avoca.qa_class.abstract import AbstractQA_Assigner
from avoca.qa_class.invalid import InvalidValues
from avoca.qa_class.zscore import ExtremeValues, XY_Correlations
from avoca.qa_class.rolling import RollingWindow
import avoca.testing.df as df_test
from avoca.testing.utils import make_dt_index

index_all_3 = pd.Index([0, 1, 2], dtype="int64")
index_all_3_dt = make_dt_index(index_all_3)
index_2 = pd.Index([2], dtype="int64")
index_2_dt = index_all_3_dt[index_2]


@pytest.fixture(
    params=[
        (ExtremeValues, {}),
        (XY_Correlations, {}),
        (ExtremeValues, {"use_log_normal": True}),
        (InvalidValues, {}),
        (InvalidValues, {"negative_values": True, "name": "invalid_negative"}),
        (InvalidValues, {"zeroes": True, "name": "invalid_zeros"}),
        (
            InvalidValues,
            {
                "zeroes": True,
                "negative_values": True,
                "name": "invalid_zeros_and_negative",
            },
        ),
        (RollingWindow, {"rolling_window": pd.Timedelta(days=3)}),
        (RollingWindow, {}),
    ]
)
def assigner(
    request: tuple[pytest.FixtureRequest, dict[str, any]],
) -> AbstractQA_Assigner:
    """Fixture to create assigners for testing."""
    assigner_type, kwargs = request.param
    return assigner_type(variable="test_var", compounds=["compA", "compB"], **kwargs)


def test_is_in_documentation(assigner: AbstractQA_Assigner):
    """Test the assigner will appear in the documentation."""

    assert type(assigner).__name__ in AssignerManager._assigners_importpath


def test_simple(assigner: AbstractQA_Assigner):

    df_one_extreme = df_test.df_one_extreme
    df_regular = df_test.df_regular
    if assigner.require_datetime_index:
        df_one_extreme = make_dt_index(df_one_extreme)
        df_regular = make_dt_index(df_regular)

    assigner.fit(df_regular)
    flagged = assigner.assign(df_one_extreme)

    empty_index = (
        df_test.empty_index
        if not assigner.require_datetime_index
        else df_test.empty_index_dt
    )

    comparison_output_a = {
        InvalidValues: empty_index,
        RollingWindow: index_2_dt,
    }
    comparison_output_b = {
        # Also b is outside of the correlation cloud
        XY_Correlations: index_2,
    }

    pd.testing.assert_index_equal(
        flagged["compA"], comparison_output_a.get(type(assigner), index_2)
    )
    pd.testing.assert_index_equal(
        flagged["compB"], comparison_output_b.get(type(assigner), empty_index)
    )


def test_input_dataframe_dt_index(assigner: AbstractQA_Assigner):

    df_regular = df_test.df_regular

    if assigner.require_datetime_index:
        with pytest.raises(ValueError, match="requires a DatetimeIndex"):
            assigner.fit(df_regular)


def test_nan_values_given_fit(assigner: AbstractQA_Assigner):

    df_nan_training = df_test.df_nan_training
    df_regular = df_test.df_regular
    empty_index = df_test.empty_index

    if assigner.require_datetime_index:
        df_nan_training = make_dt_index(df_nan_training)
        df_regular = make_dt_index(df_regular)
        empty_index = df_test.empty_index_dt

    assigner.fit(df_nan_training)
    flagged = assigner.assign(df_regular)

    # Nothing should be flagged
    pd.testing.assert_index_equal(flagged["compA"], empty_index)
    pd.testing.assert_index_equal(flagged["compB"], empty_index)


def test_only_nan_values_given_fit(assigner: AbstractQA_Assigner):

    df_full_nan = df_test.df_full_nan
    df_regular = df_test.df_regular
    empty_index = df_test.empty_index
    if assigner.require_datetime_index:
        df_full_nan = make_dt_index(df_full_nan)
        df_regular = make_dt_index(df_regular)
        empty_index = df_test.empty_index_dt

    assigner.fit(df_full_nan)
    flagged = assigner.assign(df_regular)

    # Nothing should be flagged
    pd.testing.assert_index_equal(flagged["compA"], empty_index)
    pd.testing.assert_index_equal(flagged["compB"], empty_index)


def test_fitting_nans(assigner: AbstractQA_Assigner):
    df_regular = df_test.df_regular
    df_nan_training = df_test.df_nan_training
    df_full_nan = df_test.df_full_nan
    empty_index = df_test.empty_index
    if assigner.require_datetime_index:
        df_regular = make_dt_index(df_regular)
        df_nan_training = make_dt_index(df_nan_training)
        df_full_nan = make_dt_index(df_full_nan)
        empty_index = df_test.empty_index_dt
    assigner.fit(df_regular)

    flagged = assigner.assign(df_nan_training)
    flagged_allnans = assigner.assign(df_full_nan)
    comparison_output_a_one_nan = {
        InvalidValues: index_2,
    }
    comparison_output_a_full_nan = {
        InvalidValues: index_all_3,
    }

    # Nothing should be flagged
    pd.testing.assert_index_equal(
        flagged["compA"],
        comparison_output_a_one_nan.get(type(assigner), empty_index),
    )
    pd.testing.assert_index_equal(flagged["compB"], empty_index)
    pd.testing.assert_index_equal(
        flagged_allnans["compA"],
        comparison_output_a_full_nan.get(type(assigner), empty_index),
    )
    pd.testing.assert_index_equal(flagged_allnans["compB"], empty_index)


def test_zero_values(assigner: AbstractQA_Assigner):
    """Test that zero values are not flagged."""

    df_around_zero = df_test.df_around_zero
    empty_index = df_test.empty_index
    if assigner.require_datetime_index:
        df_around_zero = make_dt_index(df_around_zero)
        empty_index = df_test.empty_index_dt

    assigner.fit(df_around_zero)
    flagged = assigner.assign(df_around_zero)

    comparison_output_a = {
        "invalid_negative": pd.Index([2, 3, 6], dtype="int64"),
        "invalid_zeros": pd.Index([0, 7], dtype="int64"),
        "invalid_zeros_and_negative": pd.Index([0, 2, 3, 6, 7], dtype="int64"),
    }
    comparison_output_b = {
        "invalid_negative": pd.Index([0, 2, 6], dtype="int64"),
        "invalid_zeros": pd.Index([4], dtype="int64"),
        "invalid_zeros_and_negative": pd.Index([0, 2, 4, 6], dtype="int64"),
    }

    # Nothing should be flagged
    pd.testing.assert_index_equal(
        flagged["compA"], comparison_output_a.get(assigner.name, empty_index)
    )
    pd.testing.assert_index_equal(
        flagged["compB"], comparison_output_b.get(assigner.name, empty_index)
    )


def test_inf_values(assigner: AbstractQA_Assigner):
    """Test that inf values are flagged."""

    df_with_inf = df_test.df_with_inf
    empty_index = df_test.empty_index
    if assigner.require_datetime_index:
        df_with_inf = make_dt_index(df_with_inf)
        empty_index = df_test.empty_index_dt

    assigner.fit(df_with_inf)
    flagged = assigner.assign(df_with_inf)

    comparison_output_a = {
        InvalidValues: index_2,
    }

    # Nothing should be flagged
    pd.testing.assert_index_equal(
        flagged["compA"], comparison_output_a.get(type(assigner), empty_index)
    )
    pd.testing.assert_index_equal(flagged["compB"], empty_index)
