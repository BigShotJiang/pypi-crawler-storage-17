from pathlib import Path

import avoca

testdata_dir = Path(*avoca.__path__).parent / "data" / "tests"
