import pandas as pd


def make_dt_index(df: pd.DataFrame | pd.Index) -> pd.DataFrame | pd.Index:
    """Create a datetime index for the dataframe."""
    index = pd.date_range(start="2023-01-01", periods=len(df), freq="h")
    if isinstance(df, pd.Index):
        return index
    return df.set_index(index)
