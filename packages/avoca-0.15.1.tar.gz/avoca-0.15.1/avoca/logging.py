import logging

SUSPISCIOUS = 25
logging.addLevelName(SUSPISCIOUS, "SUSPISCIOUS")
