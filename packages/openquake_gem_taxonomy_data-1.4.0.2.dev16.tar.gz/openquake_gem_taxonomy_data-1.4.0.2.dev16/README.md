# Openquake GEM Building Taxonomy Data

## GEM Building Taxonomy dataset and python classes to access it.

This package provide GEM Building Taxonomy dataset for [oq-gem-taxonomy](https://github.com/gem/oq-gem-taxonomy) package from GEM Taxonomy specifications (repository: [gem_taxonomy/](https://github.com/gem/gem_taxonomy/))

## Licensing

- **Code**: Licensed under the [GNU Affero General Public License v3.0](https://github.com/gem/oq-gem-taxonomy-data/blob/oq-gem-taxonomy-data-1.4/LICENSE).
- **Data**: Licensed under the [Creative Commons Attribution Share Alike 4.0 International](https://github.com/gem/oq-gem-taxonomy-data/blob/oq-gem-taxonomy-data-1.4/DATA_LICENSE).

Please refer to the respective license files for more details.
