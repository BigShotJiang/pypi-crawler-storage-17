from osbot_utils.type_safe.Type_Safe import Type_Safe

class MGraph__Export__Dot__Config__Display(Type_Safe):
    edge_ids    : bool  = False                         # Whether to show edge IDs
    edge_type   : bool  = False                         # Whether to show edge types
    node_value  : bool  = False                         # Whether to show node values
    node_type   : bool  = False                         # Whether to show node types
