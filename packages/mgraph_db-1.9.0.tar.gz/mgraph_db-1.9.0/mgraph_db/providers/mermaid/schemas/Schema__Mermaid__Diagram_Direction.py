from enum import Enum

class Schema__Mermaid__Diagram__Direction(Enum):
    BT = 'BT'
    LR = 'LR'
    TB = 'TB'
    TD = 'TD'
    RL = 'RL'