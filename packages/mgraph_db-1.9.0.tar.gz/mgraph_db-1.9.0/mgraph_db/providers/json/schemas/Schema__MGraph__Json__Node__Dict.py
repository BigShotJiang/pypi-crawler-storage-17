from mgraph_db.providers.json.schemas.Schema__MGraph__Json__Node import Schema__MGraph__Json__Node


class Schema__MGraph__Json__Node__Dict(Schema__MGraph__Json__Node):                 # For JSON objects {}
    pass