from mgraph_db.mgraph.domain.Domain__MGraph__Graph          import Domain__MGraph__Graph
from mgraph_db.providers.simple.models.Model__Simple__Graph import Model__Simple__Graph


class Domain__Simple__Graph(Domain__MGraph__Graph):
    model: Model__Simple__Graph