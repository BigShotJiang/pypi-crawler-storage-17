from osbot_utils.type_safe.Type_Safe import Type_Safe

class Schema__MGraph__Node__Value__Timestamp__Data(Type_Safe):
    value: int                                                                   # Unix timestamp in seconds since epoch