# from typing                                            import Type
# from osbot_utils.type_safe.Type_Safe                   import Type_Safe
# from mgraph_db.query.actions.MGraph__Query__Add        import MGraph__Query__Add
# from mgraph_db.query.actions.MGraph__Query__Filter     import MGraph__Query__Filter
# from mgraph_db.query.actions.MGraph__Query__Navigate   import MGraph__Query__Navigate
#
# class Domain__MGraph__Query__Types(Type_Safe):
#     add_action_type     : Type[MGraph__Query__Add     ]                                  # Type for Add actions
#     filter_action_type  : Type[MGraph__Query__Filter  ]                              # Type for Filter actions
#     navigate_action_type: Type[MGraph__Query__Navigate]                            # Type for Navigate actions