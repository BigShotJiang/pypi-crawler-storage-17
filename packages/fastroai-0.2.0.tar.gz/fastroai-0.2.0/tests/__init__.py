"""FastroAI test suite."""
