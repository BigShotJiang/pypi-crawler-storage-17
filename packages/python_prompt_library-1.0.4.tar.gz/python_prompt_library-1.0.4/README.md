"# This is the README.md file" 

"#PS command to remove build folders"
"#Remove-Item -Recurse -Force dist, build, *.egg-info"

"#PS command to rebuild"
"#python setup.py sdist bdist_wheel"

"Import from pypi
pip install python_prompt_library"

"Import from testpypi
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/python_prompt_library"