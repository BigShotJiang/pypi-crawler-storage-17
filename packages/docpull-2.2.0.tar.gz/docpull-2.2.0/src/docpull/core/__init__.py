"""Core fetcher API for docpull v2.0."""

from .fetcher import Fetcher, fetch_blocking

__all__ = ["Fetcher", "fetch_blocking"]
