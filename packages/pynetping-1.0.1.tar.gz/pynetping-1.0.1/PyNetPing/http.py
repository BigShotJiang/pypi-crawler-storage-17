# Developer: Sreeraj
# GitHub: https://github.com/s-r-e-e-r-a-j

import socket
from typing import Optional
from .utils import now, is_ipv6

def http_ping(host: str, timeout: float) -> Optional[float]:
    family: int = socket.AF_INET6 if is_ipv6(host) else socket.AF_INET
    sock: socket.socket = socket.socket(family, socket.SOCK_STREAM)
    sock.settimeout(timeout)

    start: float = now()
    try:
        sock.connect((host, 80))
        sock.sendall(f"HEAD / HTTP/1.1\r\nHost: {host}\r\n\r\n".encode())
        sock.recv(1)
    except Exception:
        return None
    finally:
        sock.close()

    return (now() - start) * 1000.0
