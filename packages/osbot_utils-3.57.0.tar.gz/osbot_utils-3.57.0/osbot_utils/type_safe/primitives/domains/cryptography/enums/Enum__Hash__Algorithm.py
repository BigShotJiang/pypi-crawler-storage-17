from enum import Enum

class Enum__Hash__Algorithm(Enum):
    MD5    = "md5"
    SHA256 = "sha256"
    SHA384 = "sha384"