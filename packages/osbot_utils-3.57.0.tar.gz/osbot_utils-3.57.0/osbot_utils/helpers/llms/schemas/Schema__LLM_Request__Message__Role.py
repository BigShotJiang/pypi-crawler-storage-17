from enum import Enum


class Schema__LLM_Request__Message__Role(Enum):
    ASSISTANT : str = 'assistant'
    SYSTEM    : str = 'system'
    USER      : str = 'user'


