# todo: this needs refactoring with the Flow_Run__Event events stored in the Schema__Flow__Data. object


# from osbot_utils.type_safe.primitives.domains.identifiers.safe_int.Timestamp_Now      import Timestamp_Now
# from osbot_utils.helpers.flows.schemas.Schema__Flow__Event__Data import Schema__Flow__Event__Data
# from osbot_utils.type_safe.Type_Safe                             import Type_Safe
#
#
# class Schema__Flow__Event(Type_Safe):               # Represents a single event in the flow execution"""
#     event_id    : str
#     event_type  : str
#     event_data  : Schema__Flow__Event__Data
#     timestamp   : Timestamp_Now