"""Version information for netconduit."""

__version__ = "5.0.0"
__protocol_version__ = "1.0"
