#!/bin/sh

# build the archive before distribution
python3 -m build
