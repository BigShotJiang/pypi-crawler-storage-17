#!/bin/sh

# upload the archive previously built
python3 -m twine upload dist/*