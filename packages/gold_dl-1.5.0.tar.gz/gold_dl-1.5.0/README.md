# 📹 gold-dl - The Simplest YouTube Downloader CLI

### Enjoying my project? Please show your appreciation by starring it on GitHub! ⭐



<br />
<br />

> [!NOTE] > `gold-dl` is built on top of `pytubefix`, make sure to have the latest version of `pytubefix` by running:
>
> ```bash
> pip install --upgrade pytubefix
> ```

<a href="https://ibb.co/Q3yRhBsg">
  <img src="https://i.ibb.co/Hf5sRvmS/IMG-20251120-013217-680.jpg"
       alt="Pyutube"
       style="width: 100%;"
       border="0">
</a>

> [!NOTE]
> Have **a new feature**? Please don't hesitate to [tell me](https://github.com/VOLT5775/VoLTGoLD-YT)!

## 🤔 why `gold-dl`?

This command-line wizard lets you download YouTube videos or playlists straight from your `Terminal`, powered by [Pytubefix](https://pytubefix.readthedocs.io/). It works like a charm on Windows, Mac, and Linux, so you can rock it on any platform.

While other tools make you wade through a swamp of settings and configs, `gold-dl` keeps it simple. Just drop in your URL, and voilà! It’ll take you on a smooth ride to your favorite videos, no complex options needed—just fun downloading! 🔥

## 🛠️ Installation

Getting `gold-dl` up and running is a breeze! First, ensure you have [Python](https://www.python.org) installed. Just pop open your terminal and type:

```bash
python --version
```

If you see something like `Python 3.x`, you’re all set! If not, head over to [Python's downloads page](https://www.python.org/downloads/) to grab it.

Once you’re good to go, install `gold-dl` with a single command:

```bash
pip install gold-dl --break-system-packages
```

And just like that, you’re ready to download some awesome videos! 🎉

## 📈 Upgrade

Stay in the loop with the latest features on [GitHub](https://github.com/VOLT5775/VoLTGoLD-YT)! To upgrade your `gold-dl` tool, simply run:

```bash
pip install --upgrade gold-dl --break-system-packages
```

Then you’re all set to keep downloading from your `Terminal`! 🥳

## 🦸 Quick Start

Getting started with `gold-dl` is a piece of cake! Just use the following command style:

```bash
gold-dlp "YOUTUBE_LINK" [PATH]
```

> [!NOTE]
> The `[URL]` is <span style="color:red">[Required]</span> and it should be between `""`<br/>
> The `[PATH]` is optional—if you don’t specify one, it’ll save to your current terminal directory. Easy-peasy!

## 👨‍💻 Usage

#### Arguments

| Arguments | Description                                                                                                          |
| --------- | -------------------------------------------------------------------------------------------------------------------- |
| `URL`     | The `URL` of the YouTube video. This argument is <span style="color:red">[Required]</span>.                          |
| `PATH`    | The `path` to save the video. Defaults to the current working directory. <span style="color:green">[Optional]</span> |

### Options

| Option                                              | Description                            |
| --------------------------------------------------- | -------------------------------------- |
| `-v` <span style="color:cyan">or</span> `--version` | Displays the current version number.   |
| `-a` <span style="color:cyan">or</span> `--audio`   | Download audio only, skipping prompts. |
| `-f` <span style="color:cyan">or</span> `--footage` | Download video only, skipping prompts. |

## 🕵️‍♂️ Examples

For lots of examples, check them out [here](https://github.com/VOLT5775/VoLTGoLD-YT/blob/main/EXAMPLES.md)! Take a deep dive and discover all the ways to use gold-dl. 🚀

## 🥰 Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you want to change.
please follow the [contributing guidelines](https://github.com/VOLT5775/VoLTGoLD-YT/blob/main/CONTRIBUTING.md)

## 📎 License

This project is licensed under the [MIT License](https://github.com/VOLT5775/VoLTGoLD-YT/blob/main/LICENSE).

## 📸 Screenshots

<!-- for pypi only -->
<div style="text-align: center;">
   <p>Download video with specify the save location</p>
   <a href="https://ibb.co/Q3yRhBsg">
      <img src="https://i.ibb.co/Hf5sRvmS/IMG-20251120-013217-680.jpg" alt="Download video with specify the save location">
   </a>
   <p>Chose what type you want to download</p>
   <a href="https://ibb.co/Kb6qjmg">
      <img src="https://ibb.co/Kb6qjmg" alt="Chose what type you want to download">
   </a>
   <p>Chose what what resolution you want to download(if the type is video)</p>
   <a href="https://ibb.co/7ymCS79">
      <img src="https://ibb.co/Kb6qjmg" alt="Chose what resolution you want to download">
   </a>
   <p>If you download a playlist, you can choose what video you want to download, or even all of them</p>
   <a href="https://ibb.co/0qwkQNm">
      <img src="https://i.ibb.co/1ZS3bV7/Screenshot-from-2024-04-11-16-42-29.png" alt="If you download a playlist, you can choose what video you want to download, or even all of them"/>
   </a>
<br /><br />
 <p>Do not know how to use it? just type <code>gold-dlp --help</code></p>
  <a href="https://ibb.co/Q3yRhBsg">
      <img src="https://ibb.co/Kb6qjmg" alt="image5">
   </a>
</div>

## ⏳ Todo List

- [x] **Notification System**
- [x] **Auto Update package if new version available**
- [x] **Support Optional Numbering for Downloaded Playlist Videos**
- [ ] **Improve code health**
- [ ] **Support downloading sounds (mp3 format not a audio/mp4)**
- [ ] **Support Subtitles Download**
- [ ] **Support setting for downloading folder**
- [ ] **Download Thumbnails with Videos and Audio**
