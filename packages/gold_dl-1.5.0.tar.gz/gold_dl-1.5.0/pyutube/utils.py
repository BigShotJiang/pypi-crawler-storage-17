"""
This module contains the utils functions for the pyutube package.
"""

import subprocess
import sys
import os

__app__ = "gold-dl"
__version__ = "1.5.0"

ABORTED_PREFIX = "Aborted"
CANCEL_PREFIX = "Cancel"

FORCE_720P = False


# ---------------------------
# Console helpers (lazy)
# ---------------------------
def _get_consoles():
    from rich.console import Console
    from rich.theme import Theme

    custom_theme = Theme({
        "info": "#64b0f2",
        "warning": "color(3)",
        "success": "green",
    })

    console = Console(theme=custom_theme)
    error_console = Console(stderr=True, style="red")
    return console, error_console


# ---------------------------
# Clear screen
# ---------------------------
def clear() -> None:
    if os.name == "nt":
        os.system("cls")
    else:
        os.system("clear")


# ---------------------------
# Internet check (SAFE FOR BUILD)
# ---------------------------
def is_internet_available() -> bool:
    try:
        import requests
        from yaspin import yaspin
        from yaspin.spinners import Spinners

        with yaspin(
            text="Checking internet connection",
            color="blue",
            spinner=Spinners.earth,
        ):
            requests.get("https://www.google.com", timeout=5)
            return True

    except Exception:
        return False


def check_internet_connection() -> bool:
    console, error_console = _get_consoles()

    if not is_internet_available():
        error_console.print("❗ No internet connection")
        return False

    console.print("✅ There is internet connection", style="success")
    console.print()
    return True


# ---------------------------
# User interaction helpers
# ---------------------------
def file_type() -> str:
    import inquirer

    questions = [
        inquirer.List(
            "file_type",
            message="Choose the file type you want to download",
            choices=["Audio", "Video", CANCEL_PREFIX],
        ),
    ]

    try:
        answer = inquirer.prompt(questions)["file_type"]
    except TypeError:
        return ABORTED_PREFIX
    except Exception as error:
        _, error_console = _get_consoles()
        error_console.print(f"Error: {error}")
        sys.exit(1)

    return answer


def ask_resolution(resolutions: set, sizes) -> str:
    import inquirer

    if FORCE_720P:
        try:
            available = sorted(
                int(r.replace("p", ""))
                for r in resolutions
                if isinstance(r, str) and r.endswith("p")
            )

            target = 720

            if target in available:
                return "720p"

            lower = [r for r in available if r < target]
            if lower:
                return f"{max(lower)}p"

            return f"{max(available)}p"

        except Exception as error:
            _, error_console = _get_consoles()
            error_console.print(f"Auto resolution error: {error}")
            sys.exit(1)

    size_resolution_mapping = dict(zip(resolutions, sizes))

    resolution_choices = [
        f"{size} ~= {resolution}"
        for size, resolution in size_resolution_mapping.items()
    ] + [CANCEL_PREFIX]

    questions = [
        inquirer.List(
            "resolution",
            message="Choose the resolution you want to download",
            choices=resolution_choices,
        ),
    ]

    try:
        answer = inquirer.prompt(questions)["resolution"]
    except TypeError:
        return ABORTED_PREFIX
    except Exception as error:
        _, error_console = _get_consoles()
        error_console.print(f"Error: {error}")
        sys.exit(1)

    return answer.split(" ~= ")[0]


def ask_rename_file(filename: str) -> str:
    import inquirer

    console, _ = _get_consoles()
    console.print(f"'{filename}' is already exists, do you want to:", style="info")

    questions = [
        inquirer.List(
            "rename",
            message="Do you want to",
            choices=["Rename it", "Overwrite it", CANCEL_PREFIX.capitalize()],
        ),
    ]

    return inquirer.prompt(questions)["rename"]


def ask_playlist_video_names(videos):
    import inquirer
    from termcolor import colored

    note = colored("NOTE:", "cyan")
    select_one = colored("<space>", "red")
    select_all = colored("<ctrl+a>", "red")
    invert_selection = colored("<ctrl+i>", "red")
    restart_selection = colored("<ctrl+r>", "red")

    print(
        f"{note} Press {select_one} to select, {select_all} select all, "
        f"{invert_selection} invert, {restart_selection} restart"
    )

    questions = [
        inquirer.Checkbox(
            "names",
            message="Choose the videos you want to download",
            choices=videos,
        ),
    ]

    try:
        answer = inquirer.prompt(questions)["names"]
    except TypeError:
        return ABORTED_PREFIX
    except Exception as error:
        _, error_console = _get_consoles()
        error_console.print(f"Error: {error}")
        sys.exit(1)

    return answer


def ask_for_make_playlist_in_order():
    import inquirer

    questions = [
        inquirer.Confirm(
            "ask_for_make_playlist_in_order",
            message="Do you want to add the number order of the videos?",
            default=False,
        ),
    ]

    try:
        answer = inquirer.prompt(questions)["ask_for_make_playlist_in_order"]
    except TypeError:
        return ABORTED_PREFIX
    except Exception as error:
        _, error_console = _get_consoles()
        error_console.print(f"Error: {error}")
        sys.exit(1)

    return answer


# ---------------------------
# Update checker (SAFE)
# ---------------------------
def check_for_updates() -> None:
    import requests
    from pytubefix import __version__ as pytubefix_version

    console, error_console = _get_consoles()

    libraries = {
        "pyutube": {"version": __version__},
        "pytubefix": {"version": pytubefix_version},
    }

    for library, data in libraries.items():
        try:
            r = requests.get(f"https://pypi.org/pypi/{library}/json", timeout=5)
            if r.status_code != 200:
                continue

            latest = r.json()["info"]["version"]
            if latest != data["version"]:
                console.print(
                    f"👉 New version of {library}: {latest}",
                    style="warning",
                )
        except Exception:
            pass


# ---------------------------
# Main decision helper
# ---------------------------
def asking_video_or_audio() -> bool:
    _, error_console = _get_consoles()

    choice = file_type().lower()
    is_audio = choice.startswith("audio")

    if choice.startswith(CANCEL_PREFIX.lower()):
        error_console.print("❗ Cancel the download...")
        sys.exit(1)

    return is_audio