__version__ = "0.1.1"

from .video import Video

__all__ = ["Video"]
