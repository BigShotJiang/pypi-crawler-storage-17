# PoF

[![Python](https://img.shields.io/badge/Python-3.9%2B-blue.svg)](https://www.python.org/) [![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)  



Probability of Fraud
---

## Quick Start

Install & Use PoF:
```bash
pip install PoF
launch_fraud_scoring()
