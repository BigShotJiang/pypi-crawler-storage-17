"""Monarch Knowledge Graph hub downloader. See README for details."""

# Import download.py to register schemes
from . import download  # noqa: F401
