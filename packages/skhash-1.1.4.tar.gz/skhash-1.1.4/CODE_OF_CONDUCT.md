Code of Conduct
===============

All contributions to - and interactions surrounding - this project will abide by
the [USGS Code of Scientific Conduct][1].

[1]: https://www.usgs.gov/about/organization/science-support/science-quality-and-integrity/code-scientific-conduct
