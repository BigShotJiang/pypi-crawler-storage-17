from liger_kernel.triton.monkey_patch import apply_liger_triton_cache_manager  # noqa: F401
