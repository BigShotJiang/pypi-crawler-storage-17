from .notify_rs import *

__doc__ = notify_rs.__doc__
if hasattr(notify_rs, "__all__"):
    __all__ = notify_rs.__all__