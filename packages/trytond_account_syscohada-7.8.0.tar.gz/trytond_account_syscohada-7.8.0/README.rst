########################
Account SYSCOHADA Module
########################

The *Account SYSCOHADA Module* provides templates for the `chart of account of
OHADA countries <https://plan-comptable-ohada.com/>`_.

.. toctree::
   :maxdepth: 2

   reference
   releases
