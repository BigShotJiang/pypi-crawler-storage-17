"""Communicate with the Nanmai TTS service."""

import aiohttp
from typing import AsyncGenerator, Dict, Union

from .auth import generate_headers
from .constants import API_URL
from .exceptions import NanmaiAPIError, NetworkError


class Communicate:
    """
    Communicate with the Nanmai TTS service.
    Mimics the interface of edge-tts Communicate class.
    """

    def __init__(self, text: str, voice: str = "DeepSeek"):
        """
        Initialize the Communicate instance.

        Args:
            text: Text to synthesize
            voice: Voice to use (DeepSeek or Kimi)
        """
        if not isinstance(text, str):
            raise TypeError("text must be str")
        if not isinstance(voice, str):
            raise TypeError("voice must be str")

        # Validate voice
        if voice not in ["DeepSeek", "Kimi"]:
            raise ValueError(f"Invalid voice: {voice}. Must be 'DeepSeek' or 'Kimi'")

        # Convert full-width characters to half-width (from SpeakUB)
        self.text = self._convert_fullwidth_to_halfwidth(text)
        self.voice = voice

    def _convert_fullwidth_to_halfwidth(self, text: str) -> str:
        """Convert full-width ASCII characters to half-width equivalents."""
        result = []
        for char in text:
            code = ord(char)
            # Full-width ASCII range: U+FF01 to U+FF5E
            if 0xFF01 <= code <= 0xFF5E:
                # Convert to half-width by subtracting 0xFEE0
                halfwidth_code = code - 0xFEE0
                result.append(chr(halfwidth_code))
            elif code == 0x3000:  # Full-width space
                result.append(" ")
            else:
                result.append(char)
        return "".join(result)

    async def stream(self) -> AsyncGenerator[Dict[str, Union[str, bytes]], None]:
        """
        Stream audio data from the Nanmai TTS service.

        Yields:
            Dict containing audio chunks in the format:
            {"type": "audio", "data": bytes}
        """
        # Prepare request data
        data = aiohttp.FormData()
        data.add_field("text", self.text)
        data.add_field("audio_type", "mp3")
        data.add_field("format", "stream")

        # Generate headers
        headers = generate_headers()

        # Construct URL
        url = f"{API_URL}?roleid={self.voice}"

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, data=data, headers=headers) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        raise NanmaiAPIError(f"Nanmai API Error {response.status}: {error_text}")

                    # True streaming: read and yield chunks as they arrive
                    # This allows for lower latency and memory usage
                    chunk_count = 0
                    async for chunk in response.content.iter_chunked(4096):
                        if chunk:  # Skip empty chunks
                            chunk_count += 1
                            yield {"type": "audio", "data": chunk}

                    # Validate that we received at least some data
                    if chunk_count == 0:
                        raise NanmaiAPIError("Empty audio data received")

        except aiohttp.ClientError as e:
            raise NetworkError(f"Network error: {e}") from e
        except Exception as e:
            raise NanmaiAPIError(f"TTS synthesis failed: {e}") from e

    async def save(self, audio_fname: str) -> None:
        """
        Save the audio to a file.

        Args:
            audio_fname: Output filename
        """
        with open(audio_fname, "wb") as f:
            async for chunk in self.stream():
                if chunk["type"] == "audio":
                    f.write(chunk["data"])

    async def get_audio_data(self) -> bytes:
        """
        Get the complete audio data as bytes.
        This is a convenience method for applications that need the full audio at once.

        Returns:
            Complete audio data as bytes
        """
        audio_chunks = []
        async for chunk in self.stream():
            if chunk["type"] == "audio":
                audio_chunks.append(chunk["data"])
        return b"".join(audio_chunks)
