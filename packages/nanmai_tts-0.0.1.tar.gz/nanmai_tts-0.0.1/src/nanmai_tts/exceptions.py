"""Exceptions for the nanmai_tts package."""


class NanmaiTTSException(Exception):
    """Base exception for Nanmai TTS."""
    pass


class NanmaiAPIError(NanmaiTTSException):
    """Exception raised when Nanmai API returns an error."""
    pass


class AuthenticationError(NanmaiTTSException):
    """Exception raised when authentication fails."""
    pass


class NetworkError(NanmaiTTSException):
    """Exception raised when network communication fails."""
    pass
