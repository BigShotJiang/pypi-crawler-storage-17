from syngen.streamlit_app.handlers.handlers import StreamlitHandler  # noqa: F401
