mod dynamic_bit_vector;
pub(crate) mod dynamic_wavelet_matrix;
